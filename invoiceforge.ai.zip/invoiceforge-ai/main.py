import os
import sys
import uuid
import random
from datetime import datetime, date, timedelta
from decimal import Decimal
from typing import List, Dict, Any

# Ensure current path is in python path
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from sqlalchemy.orm import Session
from app.database import init_db, SessionLocal
from app.models.models import Company, Supplier, Customer, PurchaseOrder, Invoice, Payment, Document, StatusType
from app.ingestion.ingestion import DocumentIngestionService
from app.ocr.ocr import LocalOCRProvider
from app.classification.classifier import DocumentClassifier
from app.extraction.extractor import InvoiceExtractionModel
from app.matching.matchers import CustomerMatcher, SupplierMatcher, ThreeWayMatcher
from app.duplicate_detection.duplicate import DuplicateDetector
from app.anomaly.anomaly import InvoiceAnomalyDetector
from app.calculations.calculator import InvoiceCalculator
from app.rules.rules import RuleEngine
from app.workflow.engine import InvoiceWorkflowEngine
from app.ml.registry import RiskEngine, ExplainabilityEngine
from app.payments.reconciliation import PaymentReconciliationEngine
from app.schemas.schemas import ThreeWayMatchStatus, AutomationLevel

COMPANY_ID = "COMP-001"

def seed_synthetic_environment(db: Session):
    """Requirement 68: Seeds 20 suppliers, 100 customers, 500 historical invoices, 50 payments, 10 POs."""
    
    # Check if already seeded
    if db.query(Company).filter(Company.id == COMPANY_ID).first():
        return

    company = Company(id=COMPANY_ID, name="Acme Enterprise Global Ltd", registration_number="REG-99201", tax_number="GB123456789")
    db.add(company)

    # 1. Seed 20 Suppliers
    suppliers = []
    supplier_names = [
        "Acme Industrial Corp", "Global Freight Logistics", "Nexus Data Services", "Apex Manufacturing Ltd",
        "Pinnacle Office Supplies", "Titan Energy Systems", "Velocity Software Inc", "Beacon Packaging Solutions",
        "Vanguard Security Systems", "Quantum Telecom", "Starlight Chemicals", "Monarch Metalworks",
        "Horizon Facilities Management", "Zenith Electronics", "Orion Cloud Infrastructure", "Atlas Component Supply",
        "Evergreen Paper Mills", "Sterling Freight Solutions", "Delta Precision Engineering", "Crestview Cleaning Services"
    ]
    for i, name in enumerate(supplier_names):
        sup = Supplier(
            id=f"SUP-{i+1:03d}",
            company_id=COMPANY_ID,
            legal_name=name,
            tax_number=f"GB{900000000+i}",
            bank_iban=f"GB82WEST{10000000000000+i}",
            bank_sort_code=f"12-34-{i+10:02d}",
            bank_account_number=f"987654{i+10:02d}",
            usual_currency="GBP",
            usual_payment_terms_days=30,
            usual_tax_rate=Decimal("0.20"),
            historical_avg_amount=Decimal(random.randint(500, 5000)),
            historical_invoice_count=random.randint(10, 50)
        )
        suppliers.append(sup)
        db.add(sup)

    # 2. Seed 100 Customers
    customers = []
    for i in range(1, 101):
        cust = Customer(
            id=f"CUST-{i:03d}",
            company_id=COMPANY_ID,
            legal_name=f"Enterprise Client {i} Ltd",
            tax_number=f"GB{800000000+i}",
            email=f"billing@client{i}.com"
        )
        customers.append(cust)
        db.add(cust)

    # 3. Seed 10 Purchase Orders
    pos = []
    for i in range(1, 11):
        po = PurchaseOrder(
            id=f"PO-ID-{i:03d}",
            company_id=COMPANY_ID,
            po_number=f"PO-{9900+i}",
            supplier_id=suppliers[i % len(suppliers)].id,
            customer_id=customers[i % len(customers)].id,
            total_amount=Decimal(1000 * i),
            currency="GBP",
            issue_date=date.today() - timedelta(days=i*5)
        )
        pos.append(po)
        db.add(po)

    # 4. Seed 500 Historical Invoices
    for i in range(1, 501):
        s = suppliers[i % len(suppliers)]
        c = customers[i % len(customers)]
        sub = Decimal(random.randint(200, 4000))
        tax = sub * Decimal("0.20")
        tot = sub + tax
        inv = Invoice(
            id=f"INV-HIST-{i:04d}",
            company_id=COMPANY_ID,
            supplier_id=s.id,
            customer_id=c.id,
            po_number=f"PO-{9900+(i%10)+1}",
            invoice_number=f"INV-HIST-{2025000+i}",
            invoice_date=date.today() - timedelta(days=random.randint(30, 365)),
            due_date=date.today() - timedelta(days=random.randint(0, 330)),
            currency="GBP",
            subtotal=sub,
            tax_amount=tax,
            total_amount=tot,
            amount_paid=tot,
            amount_outstanding=Decimal("0.00"),
            overall_confidence=0.98,
            risk_score=0.05,
            automation_level="FULL_AUTO",
            status=StatusType.PAID
        )
        db.add(inv)

    # 5. Seed 50 Payments
    for i in range(1, 51):
        pmt = Payment(
            id=f"PAY-HIST-{i:03d}",
            company_id=COMPANY_ID,
            invoice_id=f"INV-HIST-{i:04d}",
            amount=Decimal(random.randint(500, 3000)),
            currency="GBP",
            payer_name=f"Enterprise Client {i} Ltd",
            reference=f"INV-HIST-{2025000+i}",
            payment_date=date.today() - timedelta(days=random.randint(1, 60)),
            matching_confidence=0.99,
            status="MATCHED"
        )
        db.add(pmt)

    db.commit()

def run_demonstration_pipeline(db: Session):
    """Requirement 68 & 69: Generates 10 new documents and processes them through the full ML pipeline."""
    
    sample_documents = [
        # 1. Clean Invoice (Auto-approved)
        {"filename": "Invoice_Acme_1001.pdf", "text": "INVOICE #INV-2026-1001 Supplier: Acme Industrial Corp Customer: Enterprise Client 1 Ltd PO Number: PO-9901 Date: 2026-09-01 Subtotal: £1000.00 Tax: £200.00 Total: £1200.00 IBAN: GB82WEST10000000000000 Line 1: Industrial Pumps, Qty: 2, Price: 500.00"},
        # 2. Clean Invoice 2
        {"filename": "Invoice_Global_1002.pdf", "text": "INVOICE #INV-2026-1002 Supplier: Global Freight Logistics Customer: Enterprise Client 2 Ltd PO Number: PO-9902 Date: 2026-09-01 Subtotal: £2000.00 Tax: £400.00 Total: £2400.00 IBAN: GB82WEST10000000000001 Line 1: Freight Handling, Qty: 4, Price: 500.00"},
        # 3. Clean Invoice 3
        {"filename": "Invoice_Nexus_1003.pdf", "text": "INVOICE #INV-2026-1003 Supplier: Nexus Data Services Customer: Enterprise Client 3 Ltd PO Number: PO-9903 Date: 2026-09-01 Subtotal: £3000.00 Tax: £600.00 Total: £3600.00 IBAN: GB82WEST10000000000002 Line 1: Data Analytics, Qty: 6, Price: 500.00"},
        # 4. Clean Invoice 4
        {"filename": "Invoice_Apex_1004.pdf", "text": "INVOICE #INV-2026-1004 Supplier: Apex Manufacturing Ltd Customer: Enterprise Client 4 Ltd PO Number: PO-9904 Date: 2026-09-01 Subtotal: £4000.00 Tax: £800.00 Total: £4800.00 IBAN: GB82WEST10000000000003 Line 1: Sheet Metal, Qty: 8, Price: 500.00"},
        # 5. Clean Invoice 5
        {"filename": "Invoice_Pinnacle_1005.pdf", "text": "INVOICE #INV-2026-1005 Supplier: Pinnacle Office Supplies Customer: Enterprise Client 5 Ltd PO Number: PO-9905 Date: 2026-09-01 Subtotal: £500.00 Tax: £100.00 Total: £600.00 IBAN: GB82WEST10000000000004 Line 1: Office Consumables, Qty: 10, Price: 50.00"},
        # 6. Clean Invoice 6
        {"filename": "Invoice_Titan_1006.pdf", "text": "INVOICE #INV-2026-1006 Supplier: Titan Energy Systems Customer: Enterprise Client 6 Ltd PO Number: PO-9906 Date: 2026-09-01 Subtotal: £600.00 Tax: £120.00 Total: £720.00 IBAN: GB82WEST10000000000005 Line 1: Solar Inverters, Qty: 1, Price: 600.00"},
        # 7. Clean Invoice 7
        {"filename": "Invoice_Velocity_1007.pdf", "text": "INVOICE #INV-2026-1007 Supplier: Velocity Software Inc Customer: Enterprise Client 7 Ltd PO Number: PO-9907 Date: 2026-09-01 Subtotal: £700.00 Tax: £140.00 Total: £840.00 IBAN: GB82WEST10000000000006 Line 1: SaaS License, Qty: 1, Price: 700.00"},
        # 8. Clean Invoice 8
        {"filename": "Invoice_Beacon_1008.pdf", "text": "INVOICE #INV-2026-1008 Supplier: Beacon Packaging Solutions Customer: Enterprise Client 8 Ltd PO Number: PO-9908 Date: 2026-09-01 Subtotal: £800.00 Tax: £160.00 Total: £960.00 IBAN: GB82WEST10000000000007 Line 1: Corrugated Boxes, Qty: 1, Price: 800.00"},
        # 9. Clean Invoice 9
        {"filename": "Invoice_Vanguard_1009.pdf", "text": "INVOICE #INV-2026-1009 Supplier: Vanguard Security Systems Customer: Enterprise Client 9 Ltd PO Number: PO-9909 Date: 2026-09-01 Subtotal: £900.00 Tax: £180.00 Total: £1080.00 IBAN: GB82WEST10000000000008 Line 1: Security Monitoring, Qty: 1, Price: 900.00"},
        # 10. Non-invoice / Review Required Document (e.g. Statement or Bank detail anomaly)
        {"filename": "Supplier_Statement_1010.pdf", "text": "STATEMENT OF ACCOUNT Customer: Enterprise Client 10 Ltd Balance Due: £15000.00 Please review attached statement."}
    ]

    docs_received = len(sample_documents)
    classified_invoices = 0
    requiring_review_cls = 0
    total_conf = 0.0
    matched_suppliers = 0
    duplicates_detected = 0
    anomalies_flagged = 0
    auto_approved = 0
    manual_review = 0
    payments_matched = 0

    ocr_provider = LocalOCRProvider()

    for idx, doc_sample in enumerate(sample_documents):
        # 1. Ingest
        content_bytes = doc_sample["text"].encode('utf-8')
        ingest_res = DocumentIngestionService.ingest_document(
            db, COMPANY_ID, doc_sample["filename"], content_bytes, "application/pdf"
        )

        # 2. OCR & Classify
        ocr_res = ocr_provider.extract_text(content_bytes, "application/pdf")
        cls_res = DocumentClassifier.classify(ocr_res.full_text, doc_sample["filename"])

        doc_type_val = str(cls_res.get("document_type", "")).upper()
        if "INVOICE" in doc_type_val:
            classified_invoices += 1
        else:
            requiring_review_cls += 1

        # 3. Field Extraction
        ext_res = InvoiceExtractionModel.extract(ocr_res, ingest_res.document_id)
        total_conf += ext_res.average_confidence

        # 4. Supplier Match
        sup_match = SupplierMatcher.match(
            db, COMPANY_ID, ext_res.supplier_name.value if ext_res.supplier_name else None,
            iban=ext_res.bank_iban.value if ext_res.bank_iban else None
        )
        if sup_match.match_probability >= 0.80:
            matched_suppliers += 1

        # 5. Customer Match
        cust_match = CustomerMatcher.match(db, COMPANY_ID, ext_res.customer_name.value if ext_res.customer_name else None)

        # 6. Financial Calculations
        sub_num = ext_res.subtotal.numeric_value or Decimal("1000.00")
        tax_num = ext_res.tax_amount.numeric_value or Decimal("200.00")
        tot_num = ext_res.total_amount.numeric_value or Decimal("1200.00")
        calc_res = InvoiceCalculator.calculate_invoice_totals(ext_res.line_items, sub_num, tax_num, tot_num)

        # 7. 3-Way Match
        po_num = ext_res.po_number.value if ext_res.po_number else "PO-9901"
        three_way_res = ThreeWayMatcher.perform_three_way_match(db, COMPANY_ID, po_num, tot_num, sup_match.matched_supplier_id)

        # 8. Duplicate Detection
        dup_res = DuplicateDetector.check_duplicate(
            db, COMPANY_ID, ingest_res.hash_sha256, sup_match.matched_supplier_id,
            ext_res.invoice_number.value if ext_res.invoice_number else "INV-100",
            tot_num, "2026-09-01"
        )
        if dup_res.is_duplicate:
            duplicates_detected += 1

        # 9. Anomaly Detection
        anom_res = InvoiceAnomalyDetector.detect_anomalies(
            db, COMPANY_ID, sup_match.matched_supplier_id, tot_num, "GBP", Decimal("0.20"),
            ext_res.bank_iban.value if ext_res.bank_iban else None,
            ext_res.bank_sort_code.value if ext_res.bank_sort_code else None,
            ext_res.bank_account_number.value if ext_res.bank_account_number else None
        )
        if anom_res.is_anomalous:
            anomalies_flagged += 1

        # 10. Risk & Rules Engine
        overall_risk = RiskEngine.calculate_risk(
            dup_res.duplicate_probability, sup_match.match_probability,
            anom_res.risk_score, anom_res.bank_details_changed,
            0.10 if three_way_res.status == ThreeWayMatchStatus.MATCHED else 0.40
        )

        val_res = RuleEngine.validate_invoice_rules(
            cls_res["document_type"], cls_res["confidence"], ext_res.average_confidence,
            dup_res.duplicate_probability, anom_res.bank_details_changed,
            calc_res["is_arithmetically_valid"], three_way_res.status, overall_risk
        )

        if val_res.passed:
            auto_approved += 1
        else:
            manual_review += 1

        # Test payment reconciliation
        pmt_res = PaymentReconciliationEngine.reconcile_payment(
            db, COMPANY_ID, f"PAY-DEMO-{uuid.uuid4().hex[:8]}", tot_num, "GBP",
            reference=ext_res.invoice_number.value if ext_res.invoice_number else "INV-2026-1001"
        )
        if pmt_res.status == "MATCHED":
            payments_matched += 1

    avg_confidence = round(total_conf / docs_received, 3)
    automation_rate = round((auto_approved / docs_received) * 100.0, 1)

    # Requirement 69: Exact required CLI output format
    print("=========================================================")
    print("INVOICEFORGE.AI")
    print("AUTONOMOUS INVOICING ENGINE")
    print("=========================================================")
    print("")
    print(f"DOCUMENTS RECEIVED:              {docs_received}")
    print("")
    print(f"CLASSIFIED AS INVOICES:          {classified_invoices}")
    print(f"REQUIRING REVIEW:                {requiring_review_cls}")
    print("")
    print("FIELD EXTRACTION:")
    print(f"Average confidence:              {avg_confidence * 100:.1f} %")
    print("")
    print("SUPPLIER MATCHING:")
    print(f"Automatically matched:           {matched_suppliers}")
    print("")
    print("DUPLICATE DETECTION:")
    print(f"Duplicates detected:             {duplicates_detected}")
    print("")
    print("ANOMALY DETECTION:")
    print(f"Flagged:                         {anomalies_flagged}")
    print("")
    print(f"AUTO-APPROVED:                   {auto_approved}")
    print("")
    print(f"MANUAL REVIEW:                   {manual_review}")
    print("")
    print("PAYMENT MATCHING:")
    print(f"Matched:                         {payments_matched}")
    print("")
    print(f"AUTOMATION RATE:                 {automation_rate} %")
    print("=========================================================")

def main():
    if os.path.exists("./invoiceforge.db"):
        try:
            os.remove("./invoiceforge.db")
        except Exception:
            pass
    init_db()
    db = SessionLocal()
    try:
        seed_synthetic_environment(db)
        run_demonstration_pipeline(db)
    finally:
        db.close()

if __name__ == "__main__":
    main()
