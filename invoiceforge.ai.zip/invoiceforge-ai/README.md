# INVOICEFORGE.AI

**AUTONOMOUS MACHINE-LEARNING INVOICING BACKEND**

INVOICEFORGE.AI is a production-oriented backend for complete invoice lifecycle automation with strict architectural separation between probabilistic AI/ML predictions and deterministic financial rules & calculations.

---

## Architectural Principles

1. **AI/ML Layer (Probabilistic)**
   - Document Classification (`INVOICE`, `CREDIT_NOTE`, `RECEIPT`, `PURCHASE_ORDER`, etc.)
   - OCR & Layout Analysis preserving page, bounding box, and text confidence
   - Multi-field Invoice & Line-Item Extraction with source provenance
   - Customer & Supplier Entity Matching with historical graph learning
   - 3-Way Purchase Order Matching
   - Anomaly Detection (Isolation Forest, LOF, robust z-scores)
   - Duplicate Invoice Detection (Cryptographic hashing + field similarity)

2. **Rules & Financial Engine (Authoritative & Deterministic)**
   - `Decimal` precision for all money operations (No `float`)
   - Deterministic arithmetic validation (`sum(line_totals) == subtotal`, `subtotal + tax == total`)
   - Bank Detail Change Verification & Anti-Fraud Security
   - Configurable Rule Engine for approval routing and review queue flagging
   - Audit Logging of all decisions, model versions, and policy rules

---

## System Structure

```
invoiceforge-ai/
├── app/
│   ├── api/                  # FastAPI Endpoints
│   ├── models/               # SQLAlchemy ORM Models
│   ├── schemas/              # Pydantic Schemas
│   ├── ingestion/            # Document Ingestion & Hashing Service
│   ├── ocr/                  # OCR Provider Abstraction
│   ├── extraction/           # Invoice & Line-Item ML Extraction Engine
│   ├── classification/       # Document Classifier
│   ├── matching/             # Customer, Supplier & 3-Way PO Matchers
│   ├── anomaly/              # Anomaly Detection & Supplier Profiling
│   ├── duplicate_detection/  # Hash & Multi-field Duplicate Detector
│   ├── tax/                  # Deterministic Tax Calculator
│   ├── calculations/         # Deterministic Money Engine
│   ├── workflow/             # Invoice Lifecycle State Engine
│   ├── approvals/            # Approval Policy & Routing Engine
│   ├── payments/             # Payment Reconciliation & Unmatched Cash
│   ├── reconciliation/       # Receipt Generation & Credit Notes
│   ├── reminders/            # Automated Payment Reminders & Escalation
│   ├── reporting/            # Daily AI Operations Report & KPI Engine
│   ├── ml/                   # Model Registry & Drift Detection
│   ├── rules/                # Deterministic Rule Engine
│   ├── audit/                # Audit Logger
│   └── security/             # Multi-tenancy & Idempotency
├── models/                   # Saved ML Models & Weights
├── training/                 # Model Training & Feedback Pipelines
├── datasets/                 # Synthetic & Labelled Training Data
├── tests/                    # Pytest Suite
├── main.py                   # Demonstration CLI Runner & Fast API Server
└── config.yaml               # Engine Configuration
```

---

## Running Demonstration Mode

To initialize a synthetic dataset (20 suppliers, 100 customers, 500 historical invoices, 50 payments, 10 POs) and execute 10 new incoming invoices through the full autonomous ML & rules engine:

```bash
python3 invoiceforge-ai/main.py
```

---

## Running Tests

```bash
pytest invoiceforge-ai/tests/
```
