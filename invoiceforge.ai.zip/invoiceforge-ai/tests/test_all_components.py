import pytest
from decimal import Decimal
from datetime import date
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.models.models import Base, Company, Supplier, Customer, PurchaseOrder, Invoice, StatusType
from app.ingestion.ingestion import DocumentIngestionService
from app.classification.classifier import DocumentClassifier
from app.ocr.ocr import LocalOCRProvider
from app.extraction.extractor import InvoiceExtractionModel
from app.matching.matchers import CustomerMatcher, SupplierMatcher, ThreeWayMatcher
from app.duplicate_detection.duplicate import DuplicateDetector
from app.anomaly.anomaly import InvoiceAnomalyDetector
from app.tax.tax import TaxCalculator
from app.calculations.calculator import InvoiceCalculator
from app.rules.rules import RuleEngine
from app.workflow.engine import InvoiceWorkflowEngine
from app.approvals.approvals import ApprovalEngine
from app.payments.reconciliation import PaymentReconciliationEngine
from app.audit.audit import AuditLogger
from app.ml.registry import RiskEngine, ModelRegistry
from app.schemas.schemas import DocumentType, ThreeWayMatchStatus, LineItemSchema

@pytest.fixture
def db_session():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(bind=engine)
    Session = sessionmaker(bind=engine)
    session = Session()
    
    # Seed Company, Supplier, Customer, PO
    comp = Company(id="COMP-TEST", name="Test Corp")
    session.add(comp)
    
    sup = Supplier(
        id="SUP-TEST", company_id="COMP-TEST", legal_name="Acme Industrial Corp",
        bank_iban="GB82WEST12345698765432", bank_sort_code="12-34-56", bank_account_number="98765432",
        usual_currency="GBP", usual_tax_rate=Decimal("0.20"), historical_avg_amount=Decimal("1200.00"),
        historical_invoice_count=10
    )
    session.add(sup)
    
    cust = Customer(id="CUST-TEST", company_id="COMP-TEST", legal_name="Global Tech Solutions Ltd")
    session.add(cust)
    
    po = PurchaseOrder(
        id="PO-TEST", company_id="COMP-TEST", po_number="PO-9910",
        supplier_id="SUP-TEST", customer_id="CUST-TEST", total_amount=Decimal("1200.00"),
        currency="GBP", issue_date=date.today()
    )
    session.add(po)
    session.commit()
    
    yield session
    session.close()

def test_document_hashing_and_ingestion(db_session):
    content = b"PDF INVOICE CONTENT HERE"
    res = DocumentIngestionService.ingest_document(
        db_session, "COMP-TEST", "invoice.pdf", content, "application/pdf"
    )
    assert res.hash_sha256 == DocumentIngestionService.calculate_sha256(content)
    assert res.document_id.startswith("DOC-")

def test_document_classification():
    res = DocumentClassifier.classify("TAX INVOICE Bill To: Acme", "invoice.pdf")
    assert res["document_type"] == DocumentType.INVOICE
    assert res["confidence"] >= 0.85

def test_field_and_line_item_extraction():
    provider = LocalOCRProvider()
    ocr_res = provider.extract_text(b"Invoice #INV-999 Subtotal: 1000.00 Tax: 200.00 Total: 1200.00", "application/pdf")
    ext = InvoiceExtractionModel.extract(ocr_res, "DOC-123")
    assert ext.invoice_number.value is not None
    assert len(ext.line_items) >= 1
    assert ext.average_confidence >= 0.80

def test_customer_and_supplier_matching(db_session):
    sup_res = SupplierMatcher.match(db_session, "COMP-TEST", "Acme Industrial Corp", iban="GB82WEST12345698765432")
    assert sup_res.matched_supplier_id == "SUP-TEST"
    assert sup_res.match_probability >= 0.80

    cust_res = CustomerMatcher.match(db_session, "COMP-TEST", "Global Tech Solutions Ltd")
    assert cust_res.matched_customer_id == "CUST-TEST"

def test_three_way_po_matching(db_session):
    match_res = ThreeWayMatcher.perform_three_way_match(
        db_session, "COMP-TEST", "PO-9910", Decimal("1200.00"), "SUP-TEST"
    )
    assert match_res.status == ThreeWayMatchStatus.MATCHED
    assert match_res.total_matched is True

def test_duplicate_detection(db_session):
    content = b"DUPLICATE TEST FILE"
    doc_hash = DocumentIngestionService.calculate_sha256(content)
    
    dup_res = DuplicateDetector.check_duplicate(
        db_session, "COMP-TEST", doc_hash, "SUP-TEST", "INV-100", Decimal("1200.00"), "2026-09-01"
    )
    assert dup_res.is_duplicate is False or dup_res.duplicate_probability < 0.85

def test_anomaly_detection_bank_change(db_session):
    anom_res = InvoiceAnomalyDetector.detect_anomalies(
        db_session, "COMP-TEST", "SUP-TEST", Decimal("1200.00"), "GBP", Decimal("0.20"),
        extracted_iban="GB99NEWBANK111122223333", extracted_sort_code="12-34-56", extracted_account_number="98765432"
    )
    assert anom_res.bank_details_changed is True
    assert anom_res.risk_score >= 0.50

def test_deterministic_tax_and_money_calculations():
    tax = TaxCalculator.calculate_tax(Decimal("1000.00"), Decimal("0.20"))
    assert tax == Decimal("200.00")

    lines = [
        LineItemSchema(
            line_number=1, description="Item A", quantity=Decimal("2"),
            unit="pcs", unit_price=Decimal("500.00"), discount=Decimal("0.00"),
            tax_rate=Decimal("0.20"), line_total=Decimal("1000.00")
        )
    ]
    calc = InvoiceCalculator.calculate_invoice_totals(lines, extracted_subtotal=Decimal("1000.00"), extracted_total=Decimal("1200.00"))
    assert calc["subtotal"] == Decimal("1000.00")
    assert calc["tax_amount"] == Decimal("200.00")
    assert calc["total_amount"] == Decimal("1200.00")
    assert calc["is_arithmetically_valid"] is True

def test_rule_engine_decision():
    res = RuleEngine.validate_invoice_rules(
        doc_type="INVOICE", classification_confidence=0.98, extraction_confidence=0.95,
        duplicate_probability=0.01, bank_details_changed=False, is_arithmetically_valid=True,
        three_way_match_status=ThreeWayMatchStatus.MATCHED, risk_score=0.10
    )
    assert res.passed is True
    assert res.requires_human_review is False

def test_payment_reconciliation(db_session):
    # Seed invoice
    inv = Invoice(
        id="INV-PAY-1", company_id="COMP-TEST", invoice_number="INV-PAY-1",
        invoice_date=date.today(), due_date=date.today(), currency="GBP",
        subtotal=Decimal("1000.00"), tax_amount=Decimal("200.00"), total_amount=Decimal("1200.00"),
        amount_paid=Decimal("0.00"), amount_outstanding=Decimal("1200.00"),
        status=StatusType.APPROVED
    )
    db_session.add(inv)
    db_session.commit()

    rec = PaymentReconciliationEngine.reconcile_payment(
        db_session, "COMP-TEST", "PAY-001", Decimal("1200.00"), "GBP", reference="INV-PAY-1"
    )
    assert rec.status == "MATCHED"
    assert rec.amount_reconciled == Decimal("1200.00")

def test_audit_logging(db_session):
    event = AuditLogger.log_event(
        db_session, "COMP-TEST", "TEST_ACTOR", "TEST_COMPONENT",
        {"input": "val"}, "PASSED", 0.99
    )
    assert event.id.startswith("AUD-")
    assert event.actor == "TEST_ACTOR"
