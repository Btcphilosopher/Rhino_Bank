import uuid
from datetime import datetime
from decimal import Decimal
from typing import Dict, Any, Optional
from sqlalchemy.orm import Session
from app.models.models import CreditNote, Invoice, StatusType

class ReceiptAndCreditService:
    """Requirements 39 & 40: Receipt Digital Record & Credit Note Engine."""

    @classmethod
    def generate_receipt_record(cls, invoice_id: str, amount_paid: Decimal, currency: str) -> Dict[str, Any]:
        """Requirement 39: Generates digital receipt record upon payment confirmation."""
        receipt_id = f"RCT-{uuid.uuid4().hex[:10].upper()}"
        return {
            "receipt_id": receipt_id,
            "invoice_id": invoice_id,
            "amount_paid": str(amount_paid),
            "currency": currency,
            "issued_at": datetime.utcnow().isoformat(),
            "status": "ISSUED",
            "pdf_reference": f"receipts/{receipt_id}.pdf"
        }

    @classmethod
    def issue_credit_note(
        cls,
        db: Session,
        company_id: str,
        invoice_id: str,
        credit_amount: Decimal,
        reason: str,
        credit_type: str = "FULL"  # FULL, PARTIAL, LINE_ITEM
    ) -> CreditNote:
        """Requirement 40: Issue full, partial, or line-item credit notes linked to original invoice."""
        invoice = db.query(Invoice).filter(
            Invoice.company_id == company_id,
            Invoice.id == invoice_id
        ).first()

        if not invoice:
            raise ValueError(f"Invoice {invoice_id} not found")

        cn_number = f"CN-{uuid.uuid4().hex[:8].upper()}"
        credit_note = CreditNote(
            id=f"CRN-{uuid.uuid4().hex[:10].upper()}",
            company_id=company_id,
            invoice_id=invoice_id,
            credit_note_number=cn_number,
            amount=credit_amount,
            reason=f"[{credit_type}_CREDIT] {reason}",
            created_at=datetime.utcnow()
        )

        # Update invoice balance immutably
        invoice.amount_outstanding = max(Decimal("0.00"), invoice.amount_outstanding - credit_amount)
        if invoice.amount_outstanding == Decimal("0.00"):
            invoice.status = StatusType.CREDITED

        db.add(credit_note)
        db.commit()
        db.refresh(credit_note)

        return credit_note
