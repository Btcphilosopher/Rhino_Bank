import uuid
from datetime import datetime
from decimal import Decimal
from typing import Optional, Dict, Any
from sqlalchemy.orm import Session
from app.models.models import ApprovalRequest, Invoice, StatusType
from app.workflow.engine import InvoiceWorkflowEngine

class ApprovalEngine:
    """Requirements 32, 33, 34: Configurable Approval Policies & Routing Engine."""

    @classmethod
    def evaluate_approval_policy(
        cls,
        db: Session,
        invoice: Invoice,
        is_clean_and_matched: bool,
        tier_1_max: Decimal = Decimal("500.00"),
        tier_2_max: Decimal = Decimal("5000.00")
    ) -> Dict[str, Any]:
        amount = invoice.total_amount

        # Policy 1: Small Amount (0 - £500) -> Auto approve if no rule violations
        if amount <= tier_1_max and is_clean_and_matched:
            return {"requires_approval": False, "policy": "TIER_1_SMALL_AMOUNT_AUTO_APPROVE"}

        # Policy 2: Medium Amount (£500 - £5000) -> Auto approve if perfectly matched
        if amount <= tier_2_max and is_clean_and_matched:
            return {"requires_approval": False, "policy": "TIER_2_MATCHED_INVOICE_AUTO_APPROVE"}

        # Policy 3: Large Amount (£5000+) -> Mandatory Approval
        return {
            "requires_approval": True,
            "policy": "TIER_3_HIGH_VALUE_MANDATORY_APPROVAL",
            "approver_role": "FINANCE_DIRECTOR" if amount >= Decimal("25000.00") else "FINANCE_MANAGER"
        }

    @classmethod
    def create_approval_request(
        cls,
        db: Session,
        invoice_id: str,
        approver: str,
        reason: str,
        risk_score: float
    ) -> ApprovalRequest:
        req = ApprovalRequest(
            id=f"APR-{uuid.uuid4().hex[:10].upper()}",
            invoice_id=invoice_id,
            approver=approver,
            reason=reason,
            risk_score=risk_score,
            decision="PENDING",
            created_at=datetime.utcnow()
        )
        db.add(req)
        db.commit()
        db.refresh(req)
        return req
