import uuid
from typing import Dict, Any, Optional

class MultiTenantContext:
    def __init__(self, company_id: str, user_id: str = "SYSTEM"):
        self.company_id = company_id
        self.user_id = user_id

_idempotency_cache: Dict[str, Any] = {}

class IdempotencyGuard:
    @staticmethod
    def is_processed(idempotency_key: str) -> bool:
        return idempotency_key in _idempotency_cache

    @staticmethod
    def get_result(idempotency_key: str) -> Optional[Any]:
        return _idempotency_cache.get(idempotency_key)

    @staticmethod
    def record_result(idempotency_key: str, result: Any):
        _idempotency_cache[idempotency_key] = result

def mask_sensitive_data(data: Dict[str, Any]) -> Dict[str, Any]:
    """Never log passwords, API secrets, tokens, or full credit card numbers."""
    masked = {}
    for k, v in data.items():
        if any(secret_word in k.lower() for secret_word in ["password", "secret", "token", "key", "cvv"]):
            masked[k] = "***REDACTED***"
        elif isinstance(v, dict):
            masked[k] = mask_sensitive_data(v)
        else:
            masked[k] = v
    return masked
