from decimal import Decimal, ROUND_HALF_UP
from typing import Dict, Any

class TaxCalculator:
    """Requirement 23: Deterministic Tax Engine with explicit rules."""
    
    TAX_RATES = {
        "GB_STANDARD": Decimal("0.20"),
        "GB_REDUCED": Decimal("0.05"),
        "GB_ZERO": Decimal("0.00"),
        "US_STANDARD": Decimal("0.0825"),
        "EU_STANDARD": Decimal("0.21"),
    }

    @classmethod
    def calculate_tax(cls, taxable_amount: Decimal, tax_rate: Decimal) -> Decimal:
        """Deterministic tax calculation."""
        tax = taxable_amount * tax_rate
        return tax.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

    @classmethod
    def validate_tax_rate(cls, extracted_rate: Decimal, jurisdiction: str = "GB") -> Decimal:
        if jurisdiction == "GB":
            return Decimal("0.20")
        return extracted_rate
