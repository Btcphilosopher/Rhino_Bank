import uuid
from datetime import datetime
from typing import Optional, Dict, Any
from sqlalchemy.orm import Session
from app.models.models import Invoice, WorkflowEvent, ReviewItem, StatusType
from app.schemas.schemas import ProcessingStatus, AutomationLevel

class InvoiceWorkflowEngine:
    """Requirements 28, 29, 50, 53: Invoice Workflow & Event Pipeline State Engine."""

    @classmethod
    def transition_state(
        cls,
        db: Session,
        invoice: Invoice,
        to_status: StatusType,
        actor: str = "SYSTEM_WORKFLOW",
        event_name: str = "WORKFLOW_STATE_TRANSITION"
    ) -> Invoice:
        from_state = invoice.status.value if invoice.status else "NONE"
        invoice.status = to_status

        wf_event = WorkflowEvent(
            id=f"EVT-{uuid.uuid4().hex[:10].upper()}",
            invoice_id=invoice.id,
            event_type=event_name,
            from_state=from_state,
            to_state=to_status.value,
            actor=actor,
            timestamp=datetime.utcnow()
        )
        db.add(wf_event)
        db.commit()
        db.refresh(invoice)
        return invoice

    @classmethod
    def route_for_review(
        cls,
        db: Session,
        company_id: str,
        invoice: Invoice,
        reason: str,
        risk_score: float
    ) -> ReviewItem:
        cls.transition_state(
            db, invoice, StatusType.REVIEW_REQUIRED, actor="RULE_ENGINE", event_name="ROUTED_TO_REVIEW_QUEUE"
        )
        
        review_item = ReviewItem(
            id=f"REV-{uuid.uuid4().hex[:10].upper()}",
            invoice_id=invoice.id,
            company_id=company_id,
            reason=reason,
            risk_score=risk_score,
            status="PENDING",
            created_at=datetime.utcnow()
        )
        db.add(review_item)
        db.commit()
        db.refresh(review_item)
        return review_item
