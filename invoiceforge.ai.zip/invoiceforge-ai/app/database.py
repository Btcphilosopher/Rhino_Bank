import os
import sqlite3
import yaml

try:
    import sqlalchemy
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    HAS_SQLALCHEMY = True
except ImportError:
    HAS_SQLALCHEMY = False

CONFIG_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config.yaml")

def load_config():
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, "r") as f:
            return yaml.safe_load(f)
    return {
        "database": {"url": "sqlite:///./invoiceforge.db"},
        "confidence_thresholds": {"high_confidence": 0.95, "medium_confidence": 0.85, "low_confidence": 0.70}
    }

config = load_config()

class StdlibDBQuery:
    def __init__(self, items):
        self._items = items

    def filter(self, *args, **kwargs):
        filtered = []
        for item in self._items:
            match = True
            for k, v in kwargs.items():
                if getattr(item, k, None) != v:
                    match = False
                    break
            if match:
                filtered.append(item)
        return StdlibDBQuery(filtered)

    def first(self):
        return self._items[0] if self._items else None

    def all(self):
        return self._items

    def count(self):
        return len(self._items)

class StdlibDBSession:
    def __init__(self):
        self._store = {}

    def add(self, obj):
        cls_name = obj.__class__.__name__
        if cls_name not in self._store:
            self._store[cls_name] = []
        if obj not in self._store[cls_name]:
            self._store[cls_name].append(obj)

    def query(self, model_cls):
        cls_name = model_cls.__name__
        items = self._store.get(cls_name, [])
        return StdlibDBQuery(items)

    def commit(self):
        pass

    def refresh(self, obj):
        pass

    def close(self):
        pass

_stdlib_global_session = StdlibDBSession()

if HAS_SQLALCHEMY:
    DATABASE_URL = config.get("database", {}).get("url", "sqlite:///./invoiceforge.db")
    connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
    engine = create_engine(DATABASE_URL, connect_args=connect_args)
    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

    def init_db():
        from app.models.models import Base
        Base.metadata.create_all(bind=engine)

    def get_db():
        db = SessionLocal()
        try:
            yield db
        finally:
            db.close()
else:
    def init_db():
        pass

    def SessionLocal():
        return _stdlib_global_session

    def get_db():
        yield _stdlib_global_session
