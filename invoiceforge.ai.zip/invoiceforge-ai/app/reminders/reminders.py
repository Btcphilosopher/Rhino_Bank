from datetime import date, timedelta
from typing import List, Dict, Any
from sqlalchemy.orm import Session
from app.models.models import Invoice, StatusType

class ReminderEngine:
    """Requirement 35: Automated Payment Reminders & Escalation System."""

    @classmethod
    def scan_and_process_reminders(cls, db: Session, company_id: str, today: date = date.today()) -> List[Dict[str, Any]]:
        reminders_sent = []

        unpaid_invoices = db.query(Invoice).filter(
            Invoice.company_id == company_id,
            Invoice.amount_outstanding > 0,
            Invoice.status.in_([StatusType.APPROVED, StatusType.POSTED, StatusType.OVERDUE])
        ).all()

        for inv in unpaid_invoices:
            days_diff = (today - inv.due_date).days

            if days_diff > 0 and inv.status != StatusType.OVERDUE:
                inv.status = StatusType.OVERDUE
                db.commit()

            if days_diff == -3:
                # 3 days before due date
                reminders_sent.append({
                    "invoice_id": inv.id,
                    "type": "UPCOMING_DUE_REMINDER",
                    "due_date": inv.due_date.isoformat(),
                    "amount_outstanding": str(inv.amount_outstanding)
                })
            elif days_diff == 3:
                # 3 days overdue
                reminders_sent.append({
                    "invoice_id": inv.id,
                    "type": "FIRST_OVERDUE_NOTICE",
                    "due_date": inv.due_date.isoformat(),
                    "amount_outstanding": str(inv.amount_outstanding)
                })
            elif days_diff == 14:
                # 14 days overdue -> Escalation
                reminders_sent.append({
                    "invoice_id": inv.id,
                    "type": "ESCALATION_OVERDUE_NOTICE",
                    "due_date": inv.due_date.isoformat(),
                    "amount_outstanding": str(inv.amount_outstanding)
                })

        return reminders_sent
