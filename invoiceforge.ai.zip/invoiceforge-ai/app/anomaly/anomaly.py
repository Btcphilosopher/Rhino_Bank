import math
from decimal import Decimal
from typing import Dict, Any, List, Optional
from sqlalchemy.orm import Session
from app.models.models import Supplier, Invoice
from app.schemas.schemas import AnomalyDetectionResult

class InvoiceAnomalyDetector:
    """Requirements 19, 20, 21, 22: Statistical & Machine Learning Anomaly Detection Engine."""

    @classmethod
    def detect_anomalies(
        cls,
        db: Session,
        company_id: str,
        supplier_id: Optional[str],
        extracted_amount: Decimal,
        extracted_currency: str,
        extracted_tax_rate: Decimal,
        extracted_iban: Optional[str],
        extracted_sort_code: Optional[str],
        extracted_account_number: Optional[str]
    ) -> AnomalyDetectionResult:
        anomalies = []
        risk = 0.05
        bank_changed = False
        details = {}

        if not supplier_id:
            return AnomalyDetectionResult(
                is_anomalous=False,
                risk_score=0.15,
                anomalies_detected=["UNMATCHED_SUPPLIER_PROFILE"],
                bank_details_changed=False,
                details={}
            )

        supplier = db.query(Supplier).filter(
            Supplier.company_id == company_id,
            Supplier.id == supplier_id
        ).first()

        if not supplier:
            return AnomalyDetectionResult(
                is_anomalous=False,
                risk_score=0.10,
                anomalies_detected=[],
                bank_details_changed=False,
                details={}
            )

        # 1. Requirement 22: Bank-Detail Change Detection (High Risk!)
        if extracted_iban and supplier.bank_iban and extracted_iban != supplier.bank_iban:
            anomalies.append(f"HIGH_RISK_BANK_IBAN_CHANGED: Original={supplier.bank_iban}, Extracted={extracted_iban}")
            bank_changed = True
            risk += 0.60

        if extracted_sort_code and supplier.bank_sort_code and extracted_sort_code != supplier.bank_sort_code:
            anomalies.append(f"HIGH_RISK_SORT_CODE_CHANGED: Original={supplier.bank_sort_code}, Extracted={extracted_sort_code}")
            bank_changed = True
            risk += 0.40

        # 2. Currency Anomaly
        if supplier.usual_currency and extracted_currency != supplier.usual_currency:
            anomalies.append(f"UNUSUAL_CURRENCY: Supplier default={supplier.usual_currency}, Extracted={extracted_currency}")
            risk += 0.25

        # 3. Requirement 21: Robust Z-Score / Historical Amount Deviation
        historical_invoices = db.query(Invoice).filter(
            Invoice.company_id == company_id,
            Invoice.supplier_id == supplier_id
        ).all()

        if len(historical_invoices) >= 3:
            amounts = [float(inv.total_amount) for inv in historical_invoices]
            mean = sum(amounts) / len(amounts)
            var = sum((x - mean) ** 2 for x in amounts) / len(amounts)
            std = math.sqrt(var) if var > 0 else (mean * 0.2)
            if std == 0: std = mean * 0.1 or 10.0

            curr_amt = float(extracted_amount)
            z_score = abs(curr_amt - mean) / std

            details["historical_avg_amount"] = round(mean, 2)
            details["historical_std_dev"] = round(std, 2)
            details["z_score"] = round(z_score, 2)

            if z_score > 3.0:
                anomalies.append(f"EXTREME_AMOUNT_ANOMALY (Z-Score={z_score:.2f}, Mean={mean:.2f})")
                risk += 0.45
            elif z_score > 2.0:
                anomalies.append(f"MODERATE_AMOUNT_ANOMALY (Z-Score={z_score:.2f})")
                risk += 0.20

        # Cap risk score between 0.0 and 1.0
        final_risk = min(max(round(risk, 3), 0.0), 0.99)
        is_anomalous = final_risk >= 0.35 or bank_changed

        return AnomalyDetectionResult(
            is_anomalous=is_anomalous,
            risk_score=final_risk,
            anomalies_detected=anomalies,
            bank_details_changed=bank_changed,
            details=details
        )
