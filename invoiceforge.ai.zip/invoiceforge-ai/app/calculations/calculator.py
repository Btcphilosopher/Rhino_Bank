from decimal import Decimal, ROUND_HALF_UP
from typing import List, Dict, Any, Tuple, Optional
from app.schemas.schemas import LineItemSchema
from app.tax.tax import TaxCalculator

class InvoiceCalculator:
    """Requirements 24, 25, 26, 27: Money Engine & Deterministic Calculations."""

    @classmethod
    def calculate_invoice_totals(
        cls,
        line_items: List[LineItemSchema],
        extracted_subtotal: Optional[Decimal] = None,
        extracted_tax: Optional[Decimal] = None,
        extracted_total: Optional[Decimal] = None,
        amount_paid: Decimal = Decimal("0.00"),
        tolerance: Decimal = Decimal("0.05")
    ) -> Dict[str, Any]:
        """Calculates exact line subtotals, tax, totals using Decimal precision."""
        
        computed_subtotal = Decimal("0.00")
        computed_tax = Decimal("0.00")

        validated_lines = []
        for line in line_items:
            # Deterministic line total: (quantity * unit_price) - discount
            l_subtotal = (line.quantity * line.unit_price) - line.discount
            l_subtotal = l_subtotal.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
            
            l_tax = TaxCalculator.calculate_tax(l_subtotal, line.tax_rate)
            l_total = l_subtotal + l_tax

            computed_subtotal += l_subtotal
            computed_tax += l_tax

            validated_lines.append({
                "line_number": line.line_number,
                "description": line.description,
                "quantity": line.quantity,
                "unit": line.unit,
                "unit_price": line.unit_price,
                "discount": line.discount,
                "tax_rate": line.tax_rate,
                "line_subtotal": l_subtotal,
                "line_tax": l_tax,
                "line_total": l_total
            })

        computed_total = computed_subtotal + computed_tax
        amount_outstanding = computed_total - amount_paid

        # Validation checks (Requirement 26)
        line_sum_vs_subtotal_ok = True
        subtotal_tax_vs_total_ok = True
        discrepancies = []

        if extracted_subtotal is not None:
            if abs(computed_subtotal - extracted_subtotal) > tolerance:
                line_sum_vs_subtotal_ok = False
                discrepancies.append(
                    f"Line totals sum ({computed_subtotal}) disagrees with extracted subtotal ({extracted_subtotal})"
                )

        if extracted_total is not None:
            if abs(computed_total - extracted_total) > tolerance:
                subtotal_tax_vs_total_ok = False
                discrepancies.append(
                    f"Subtotal+Tax ({computed_total}) disagrees with extracted total ({extracted_total})"
                )

        return {
            "subtotal": computed_subtotal,
            "tax_amount": computed_tax,
            "total_amount": computed_total,
            "amount_paid": amount_paid,
            "amount_outstanding": amount_outstanding,
            "validated_lines": validated_lines,
            "is_arithmetically_valid": (line_sum_vs_subtotal_ok and subtotal_tax_vs_total_ok),
            "discrepancies": discrepancies
        }
