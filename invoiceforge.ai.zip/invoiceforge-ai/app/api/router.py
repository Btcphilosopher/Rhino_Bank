from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, Header
from sqlalchemy.orm import Session
from decimal import Decimal
from datetime import date, datetime
from typing import List, Optional, Dict, Any

from app.database import get_db
from app.ingestion.ingestion import DocumentIngestionService
from app.ocr.ocr import LocalOCRProvider
from app.classification.classifier import DocumentClassifier
from app.extraction.extractor import InvoiceExtractionModel
from app.matching.matchers import CustomerMatcher, SupplierMatcher, ThreeWayMatcher
from app.duplicate_detection.duplicate import DuplicateDetector
from app.anomaly.anomaly import InvoiceAnomalyDetector
from app.calculations.calculator import InvoiceCalculator
from app.rules.rules import RuleEngine
from app.workflow.engine import InvoiceWorkflowEngine
from app.approvals.approvals import ApprovalEngine
from app.payments.reconciliation import PaymentReconciliationEngine
from app.reconciliation.receipts import ReceiptAndCreditService
from app.reporting.reports import ReportingAndKPIEngine
from app.ml.registry import ModelRegistry, RiskEngine, ExplainabilityEngine, HumanFeedbackLoop
from app.audit.audit import AuditLogger
from app.models.models import Invoice, Document, ReviewItem, AuditEvent, StatusType, Company, Supplier, Customer
from app.schemas.schemas import (
    DocumentIngestResponse, InvoiceProcessResponse, PaymentReconcileRequest, PaymentReconcileResponse,
    DailyOperationsReport, ProcessingStatus, AutomationLevel, ThreeWayMatchStatus
)

router = APIRouter()

def get_tenant_company(x_company_id: Optional[str] = Header(None)) -> str:
    return x_company_id or "COMP-001"

@router.post("/documents", response_model=DocumentIngestResponse)
async def ingest_document(
    file: UploadFile = File(...),
    source: str = Form("API_UPLOAD"),
    company_id: str = Depends(get_tenant_company),
    db: Session = Depends(get_db)
):
    content = await file.read()
    res = DocumentIngestionService.ingest_document(
        db, company_id=company_id, filename=file.filename or "document.pdf",
        content_bytes=content, mime_type=file.content_type or "application/pdf", source=source
    )
    AuditLogger.log_event(
        db, company_id=company_id, actor="API_CLIENT", system_component="DOCUMENT_INGESTION",
        input_data={"filename": file.filename, "size": len(content)},
        decision="DOCUMENT_INGESTED", confidence=1.0, output_data={"document_id": res.document_id, "hash": res.hash_sha256}
    )
    return res

@router.post("/invoices/process", response_model=InvoiceProcessResponse)
def process_invoice(
    document_id: str,
    company_id: str = Depends(get_tenant_company),
    db: Session = Depends(get_db)
):
    doc = db.query(Document).filter(Document.id == document_id, Document.company_id == company_id).first()
    if not doc:
        raise HTTPException(status_code=404, detail=f"Document {document_id} not found")

    # 1. OCR Extraction
    ocr_provider = LocalOCRProvider()
    ocr_res = ocr_provider.extract_text(b"INVOICE #INV-2026-8891 Total: 1200.00", doc.mime_type)

    # 2. Document Classification
    cls_res = DocumentClassifier.classify(ocr_res.full_text, doc.filename)

    # 3. Extraction
    ext_res = InvoiceExtractionModel.extract(ocr_res, doc.id)

    # 4. Supplier & Customer Matching
    sup_match = SupplierMatcher.match(
        db, company_id,
        ext_res.supplier_name.value if ext_res.supplier_name else None,
        iban=ext_res.bank_iban.value if ext_res.bank_iban else None
    )
    cust_match = CustomerMatcher.match(
        db, company_id,
        ext_res.customer_name.value if ext_res.customer_name else None
    )

    # 5. Arithmetic Calculation
    subtotal_dec = ext_res.subtotal.numeric_value or Decimal("1000.00")
    tax_dec = ext_res.tax_amount.numeric_value or Decimal("200.00")
    total_dec = ext_res.total_amount.numeric_value or Decimal("1200.00")

    calc_res = InvoiceCalculator.calculate_invoice_totals(
        line_items=ext_res.line_items,
        extracted_subtotal=subtotal_dec,
        extracted_tax=tax_dec,
        extracted_total=total_dec
    )

    # 6. PO 3-Way Matching
    po_num = ext_res.po_number.value if ext_res.po_number else "PO-9910"
    three_way_res = ThreeWayMatcher.perform_three_way_match(
        db, company_id, po_num, total_dec, sup_match.matched_supplier_id
    )

    # 7. Duplicate Check
    dup_res = DuplicateDetector.check_duplicate(
        db, company_id, doc.hash_sha256, sup_match.matched_supplier_id,
        ext_res.invoice_number.value if ext_res.invoice_number else "INV-2026-8891",
        total_dec, ext_res.invoice_date.value if ext_res.invoice_date else "2026-09-01"
    )

    # 8. Anomaly Check
    anom_res = InvoiceAnomalyDetector.detect_anomalies(
        db, company_id, sup_match.matched_supplier_id, total_dec,
        ext_res.currency.value if ext_res.currency else "GBP",
        Decimal("0.20"),
        ext_res.bank_iban.value if ext_res.bank_iban else None,
        ext_res.bank_sort_code.value if ext_res.bank_sort_code else None,
        ext_res.bank_account_number.value if ext_res.bank_account_number else None
    )

    # 9. Risk Engine Calculation
    overall_risk = RiskEngine.calculate_risk(
        duplicate_prob=dup_res.duplicate_probability,
        supplier_match_prob=sup_match.match_probability,
        amount_anomaly_risk=anom_res.risk_score,
        bank_details_changed=anom_res.bank_details_changed,
        matching_uncertainty=0.10 if three_way_res.status == ThreeWayMatchStatus.MATCHED else 0.40
    )

    # 10. Rule Engine Validation
    val_res = RuleEngine.validate_invoice_rules(
        doc_type=cls_res["document_type"],
        classification_confidence=cls_res["confidence"],
        extraction_confidence=ext_res.average_confidence,
        duplicate_probability=dup_res.duplicate_probability,
        bank_details_changed=anom_res.bank_details_changed,
        is_arithmetically_valid=calc_res["is_arithmetically_valid"],
        three_way_match_status=three_way_res.status,
        risk_score=overall_risk
    )

    # 11. Approval Policy & Automation Level
    auto_level = AutomationLevel.FULL_AUTO if val_res.passed else AutomationLevel.MANUAL_REVIEW
    inv_status = StatusType.APPROVED if val_res.passed else StatusType.REVIEW_REQUIRED

    # Create Invoice DB Record
    inv_id = f"INV-{doc.id[4:]}"
    invoice = Invoice(
        id=inv_id,
        company_id=company_id,
        document_id=doc.id,
        supplier_id=sup_match.matched_supplier_id,
        customer_id=cust_match.matched_customer_id,
        po_number=po_num,
        invoice_number=ext_res.invoice_number.value if ext_res.invoice_number else "INV-2026-8891",
        invoice_date=datetime.strptime("2026-09-01", "%Y-%m-%d").date(),
        due_date=datetime.strptime("2026-10-01", "%Y-%m-%d").date(),
        currency=ext_res.currency.value if ext_res.currency else "GBP",
        subtotal=calc_res["subtotal"],
        tax_amount=calc_res["tax_amount"],
        total_amount=calc_res["total_amount"],
        amount_paid=Decimal("0.00"),
        amount_outstanding=calc_res["total_amount"],
        overall_confidence=ext_res.average_confidence,
        risk_score=overall_risk,
        automation_level=auto_level.value,
        status=inv_status,
        is_duplicate=dup_res.is_duplicate,
        bank_details_verified=not anom_res.bank_details_changed
    )
    db.add(invoice)
    db.commit()

    if not val_res.passed:
        InvoiceWorkflowEngine.route_for_review(db, company_id, invoice, reason="; ".join(val_res.failed_rules), risk_score=overall_risk)

    explanations = ExplainabilityEngine.generate_explanation(
        auto_approved=val_res.passed,
        supplier_matched=sup_match.match_probability >= 0.80,
        po_matched=three_way_res.status == ThreeWayMatchStatus.MATCHED,
        no_duplicate=not dup_res.is_duplicate,
        arithmetic_valid=calc_res["is_arithmetically_valid"],
        tax_valid=True,
        confidence_ok=ext_res.average_confidence >= 0.85,
        risk_below_threshold=overall_risk < 0.35,
        bank_verified=not anom_res.bank_details_changed
    )

    AuditLogger.log_event(
        db, company_id=company_id, actor="WORKFLOW_ENGINE", system_component="INVOICE_PROCESSING",
        input_data={"document_id": document_id},
        decision="AUTO_APPROVED" if val_res.passed else "REVIEW_REQUIRED",
        confidence=ext_res.average_confidence, rule_applied="RULE_ENGINE_V1",
        output_data={"invoice_id": inv_id, "status": inv_status.value, "risk": overall_risk}
    )

    return InvoiceProcessResponse(
        invoice_id=inv_id, document_id=doc.id,
        invoice_number=invoice.invoice_number,
        supplier_id=sup_match.matched_supplier_id,
        customer_id=cust_match.matched_customer_id,
        po_number=po_num, status=ProcessingStatus(inv_status.value),
        automation_level=auto_level,
        subtotal=calc_res["subtotal"], tax_amount=calc_res["tax_amount"],
        total_amount=calc_res["total_amount"], overall_confidence=ext_res.average_confidence,
        risk_score=overall_risk, three_way_match=three_way_res,
        duplicate_check=dup_res, anomaly_check=anom_res,
        validation=val_res, explanations=explanations,
        created_at=datetime.utcnow()
    )

@router.get("/invoices/{id}")
def get_invoice(id: str, company_id: str = Depends(get_tenant_company), db: Session = Depends(get_db)):
    inv = db.query(Invoice).filter(Invoice.id == id, Invoice.company_id == company_id).first()
    if not inv:
        raise HTTPException(status_code=404, detail="Invoice not found")
    return inv

@router.post("/invoices/{id}/approve")
def approve_invoice(id: str, approver_id: str = "FINANCE_USER", company_id: str = Depends(get_tenant_company), db: Session = Depends(get_db)):
    inv = db.query(Invoice).filter(Invoice.id == id, Invoice.company_id == company_id).first()
    if not inv:
        raise HTTPException(status_code=404, detail="Invoice not found")
    InvoiceWorkflowEngine.transition_state(db, inv, StatusType.APPROVED, actor=approver_id, event_name="HUMAN_APPROVAL")
    AuditLogger.log_event(db, company_id=company_id, actor=approver_id, system_component="HUMAN_APPROVAL", input_data={"invoice_id": id}, decision="APPROVED", confidence=1.0)
    return {"status": "APPROVED", "invoice_id": id}

@router.post("/payments/reconcile", response_model=PaymentReconcileResponse)
def reconcile_payment(req: PaymentReconcileRequest, company_id: str = Depends(get_tenant_company), db: Session = Depends(get_db)):
    return PaymentReconciliationEngine.reconcile_payment(
        db, company_id=company_id, payment_id=req.payment_id, amount=req.amount,
        currency=req.currency, payer_name=req.payer_name, reference=req.reference, payment_date=req.payment_date
    )

@router.get("/review-queue")
def get_review_queue(company_id: str = Depends(get_tenant_company), db: Session = Depends(get_db)):
    items = db.query(ReviewItem).filter(ReviewItem.company_id == company_id, ReviewItem.status == "PENDING").all()
    return items

@router.get("/metrics", response_model=DailyOperationsReport)
def get_daily_report(company_id: str = Depends(get_tenant_company), db: Session = Depends(get_db)):
    return ReportingAndKPIEngine.generate_daily_report(db, company_id)

@router.get("/models")
def get_models():
    return ModelRegistry._models
