import hashlib
import uuid
from datetime import datetime
from typing import Dict, Any, Union
from sqlalchemy.orm import Session
from app.models.models import Document, StatusType
from app.schemas.schemas import DocumentIngestResponse, ProcessingStatus

class DocumentIngestionService:
    @staticmethod
    def calculate_sha256(content_bytes: bytes) -> str:
        """Requirement 5: Cryptographic SHA-256 document hashing."""
        return hashlib.sha256(content_bytes).hexdigest()

    @classmethod
    def ingest_document(
        cls,
        db: Session,
        company_id: str,
        filename: str,
        content_bytes: bytes,
        mime_type: str,
        source: str = "API_UPLOAD"
    ) -> DocumentIngestResponse:
        sha256_hash = cls.calculate_sha256(content_bytes)
        
        # Check if hash already exists in DB for this company
        existing_doc = db.query(Document).filter(
            Document.company_id == company_id,
            Document.hash_sha256 == sha256_hash
        ).first()

        doc_id = f"DOC-{uuid.uuid4().hex[:10].upper()}"
        
        document = Document(
            id=doc_id,
            company_id=company_id,
            source=source,
            filename=filename,
            mime_type=mime_type,
            hash_sha256=sha256_hash,
            storage_reference=f"storage/{company_id}/{doc_id}_{filename}",
            retention_policy_days=2555, # 7 years
            received_at=datetime.utcnow(),
            processing_status=StatusType.RECEIVED
        )
        db.add(document)
        db.commit()
        db.refresh(document)

        return DocumentIngestResponse(
            document_id=document.id,
            source=document.source,
            filename=document.filename,
            mime_type=document.mime_type,
            hash_sha256=document.hash_sha256,
            received_at=document.received_at,
            processing_status=ProcessingStatus(document.processing_status),
            company_id=company_id
        )
