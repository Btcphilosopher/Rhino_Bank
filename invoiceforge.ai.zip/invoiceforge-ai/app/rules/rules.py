from typing import List, Dict, Any, Optional
from app.schemas.schemas import RuleValidationResult, DocumentType, ThreeWayMatchStatus

class RuleEngine:
    """Requirements 30 & 31: Deterministic Decision Layer (ML proposes, Rules decide)."""

    @classmethod
    def validate_invoice_rules(
        cls,
        doc_type: str,
        classification_confidence: float,
        extraction_confidence: float,
        duplicate_probability: float,
        bank_details_changed: bool,
        is_arithmetically_valid: bool,
        three_way_match_status: ThreeWayMatchStatus,
        risk_score: float,
        min_confidence_threshold: float = 0.85,
        max_duplicate_threshold: float = 0.80,
        max_risk_threshold: float = 0.35
    ) -> RuleValidationResult:
        
        failed_rules = []
        explanations = []
        requires_review = False

        # Rule 1: Document Classification
        if doc_type != DocumentType.INVOICE.value:
            failed_rules.append("RULE_NON_INVOICE_DOCUMENT")
            explanations.append(f"Document classified as {doc_type}, not INVOICE")
            requires_review = True

        # Rule 2: Low Confidence Extraction
        if classification_confidence < min_confidence_threshold:
            failed_rules.append("RULE_LOW_CLASSIFICATION_CONFIDENCE")
            explanations.append(f"Classification confidence {classification_confidence:.2f} < threshold {min_confidence_threshold}")
            requires_review = True

        if extraction_confidence < min_confidence_threshold:
            failed_rules.append("RULE_LOW_EXTRACTION_CONFIDENCE")
            explanations.append(f"Extraction confidence {extraction_confidence:.2f} < threshold {min_confidence_threshold}")
            requires_review = True

        # Rule 3: Duplicate Risk
        if duplicate_probability >= max_duplicate_threshold:
            failed_rules.append("RULE_POSSIBLE_DUPLICATE_DETECTED")
            explanations.append(f"Duplicate probability {duplicate_probability:.2f} >= threshold {max_duplicate_threshold}")
            requires_review = True

        # Rule 4: Bank Details Changed
        if bank_details_changed:
            failed_rules.append("RULE_BANK_DETAILS_CHANGED_MANDATORY_VERIFICATION")
            explanations.append("Supplier bank payment details differ from historical record - mandatory human verification required")
            requires_review = True

        # Rule 5: Arithmetic Consistency
        if not is_arithmetically_valid:
            failed_rules.append("RULE_ARITHMETIC_TOTAL_MISMATCH")
            explanations.append("Invoice line item arithmetic or subtotal/tax does not match total")
            requires_review = True

        # Rule 6: 3-Way Match
        if three_way_match_status == ThreeWayMatchStatus.MISMATCHED:
            failed_rules.append("RULE_THREE_WAY_MATCH_FAILED")
            explanations.append("Purchase Order 3-Way Match failed or PO missing")
            requires_review = True

        # Rule 7: High Risk Score
        if risk_score >= max_risk_threshold:
            failed_rules.append("RULE_HIGH_RISK_SCORE")
            explanations.append(f"Overall risk score {risk_score:.2f} >= threshold {max_risk_threshold}")
            requires_review = True

        passed = len(failed_rules) == 0

        if passed:
            explanations.append("All deterministic validation rules passed successfully.")

        return RuleValidationResult(
            passed=passed,
            requires_human_review=requires_review,
            failed_rules=failed_rules,
            explanations=explanations
        )
