import uuid
from datetime import datetime
from typing import Dict, Any, Optional
from sqlalchemy.orm import Session
from app.models.models import AuditEvent
from app.security.security import mask_sensitive_data

class AuditLogger:
    @staticmethod
    def log_event(
        db: Session,
        company_id: str,
        actor: str,
        system_component: str,
        input_data: Dict[str, Any],
        decision: str,
        confidence: float,
        rule_applied: Optional[str] = None,
        output_data: Optional[Dict[str, Any]] = None
    ) -> AuditEvent:
        event = AuditEvent(
            id=f"AUD-{uuid.uuid4().hex[:12].upper()}",
            company_id=company_id,
            timestamp=datetime.utcnow(),
            actor=actor,
            system_component=system_component,
            input_data=mask_sensitive_data(input_data or {}),
            decision=decision,
            confidence=float(confidence),
            rule_applied=rule_applied,
            output_data=mask_sensitive_data(output_data or {})
        )
        db.add(event)
        db.commit()
        db.refresh(event)
        return event
