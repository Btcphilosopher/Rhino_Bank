import re
from typing import Dict, Any
from app.schemas.schemas import DocumentType

class DocumentClassifier:
    """Requirement 6: Document Classification Engine with probabilistic confidence scoring."""
    
    @classmethod
    def classify(cls, text_content: str, filename: str = "") -> Dict[str, Any]:
        text_upper = text_content.upper()
        filename_upper = filename.upper()
        
        scores = {
            DocumentType.INVOICE: 0.0,
            DocumentType.CREDIT_NOTE: 0.0,
            DocumentType.RECEIPT: 0.0,
            DocumentType.PURCHASE_ORDER: 0.0,
            DocumentType.DELIVERY_NOTE: 0.0,
            DocumentType.STATEMENT: 0.0,
            DocumentType.UNKNOWN: 0.1
        }
        
        # Rule & Keyword scoring
        if "INVOICE" in text_upper or "INV-" in text_upper or "INVOICE" in filename_upper:
            scores[DocumentType.INVOICE] += 0.85
        if "TAX INVOICE" in text_upper or "BILL TO" in text_upper or "AMOUNT DUE" in text_upper:
            scores[DocumentType.INVOICE] += 0.12
            
        if "CREDIT NOTE" in text_upper or "CREDIT MEMO" in text_upper:
            scores[DocumentType.CREDIT_NOTE] += 0.95
            
        if "RECEIPT" in text_upper or "THANK YOU FOR YOUR PAYMENT" in text_upper:
            scores[DocumentType.RECEIPT] += 0.90
            
        if "PURCHASE ORDER" in text_upper or "PO NUMBER" in text_upper or "PO-" in text_upper:
            scores[DocumentType.PURCHASE_ORDER] += 0.92
            
        if "DELIVERY NOTE" in text_upper or "DISPATCH NOTE" in text_upper or "PACKING SLIP" in text_upper:
            scores[DocumentType.DELIVERY_NOTE] += 0.90
            
        if "STATEMENT OF ACCOUNT" in text_upper or "ACCOUNT STATEMENT" in text_upper:
            scores[DocumentType.STATEMENT] += 0.90

        top_type = max(scores, key=scores.get)
        top_score = min(round(scores[top_type], 3), 0.99)
        
        if top_score < 0.40:
            top_type = DocumentType.UNKNOWN
            top_score = 0.50

        if hasattr(top_type, "value"):
            doc_type_str = str(top_type.value)
        else:
            doc_type_str = str(top_type)

        if "." in doc_type_str:
            doc_type_str = doc_type_str.split(".")[-1]

        return {
            "document_type": doc_type_str,
            "confidence": top_score
        }
