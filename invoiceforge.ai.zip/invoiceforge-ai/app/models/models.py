from datetime import datetime, date
from decimal import Decimal
import enum

try:
    from sqlalchemy import Column, String, Integer, Float, Numeric, DateTime, Date, Boolean, Text, JSON, ForeignKey, Enum as SQLEnum
    from sqlalchemy.orm import declarative_base, relationship
    HAS_SQLALCHEMY = True
    Base = declarative_base()
except ImportError:
    HAS_SQLALCHEMY = False
    Base = object

class DocType(str, enum.Enum):
    INVOICE = "INVOICE"
    CREDIT_NOTE = "CREDIT_NOTE"
    RECEIPT = "RECEIPT"
    PURCHASE_ORDER = "PURCHASE_ORDER"
    DELIVERY_NOTE = "DELIVERY_NOTE"
    STATEMENT = "STATEMENT"
    UNKNOWN = "UNKNOWN"

class StatusType(str, enum.Enum):
    RECEIVED = "RECEIVED"
    PROCESSING = "PROCESSING"
    EXTRACTED = "EXTRACTED"
    VALIDATING = "VALIDATING"
    MATCHING = "MATCHING"
    REVIEW_REQUIRED = "REVIEW_REQUIRED"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    POSTED = "POSTED"
    PAID = "PAID"
    OVERDUE = "OVERDUE"
    CREDITED = "CREDITED"

if HAS_SQLALCHEMY:
    class Company(Base):
        __tablename__ = "companies"
        id = Column(String, primary_key=True)
        name = Column(String, nullable=False)
        registration_number = Column(String, nullable=True)
        tax_number = Column(String, nullable=True)
        country = Column(String, default="GB")
        currency = Column(String, default="GBP")
        created_at = Column(DateTime, default=datetime.utcnow)

    class User(Base):
        __tablename__ = "users"
        id = Column(String, primary_key=True)
        company_id = Column(String, ForeignKey("companies.id"), nullable=False)
        email = Column(String, nullable=False)
        name = Column(String, nullable=False)
        role = Column(String, default="FINANCE_MANAGER")
        created_at = Column(DateTime, default=datetime.utcnow)

    class Supplier(Base):
        __tablename__ = "suppliers"
        id = Column(String, primary_key=True)
        company_id = Column(String, ForeignKey("companies.id"), nullable=False)
        legal_name = Column(String, nullable=False)
        trading_name = Column(String, nullable=True)
        tax_number = Column(String, nullable=True)
        email = Column(String, nullable=True)
        address = Column(String, nullable=True)
        postcode = Column(String, nullable=True)
        bank_iban = Column(String, nullable=True)
        bank_sort_code = Column(String, nullable=True)
        bank_account_number = Column(String, nullable=True)
        usual_currency = Column(String, default="GBP")
        usual_payment_terms_days = Column(Integer, default=30)
        usual_tax_rate = Column(Numeric(5, 4), default=0.20)
        historical_avg_amount = Column(Numeric(12, 2), default=0.00)
        historical_invoice_count = Column(Integer, default=0)
        trust_score = Column(Float, default=0.95)
        template_config = Column(JSON, nullable=True)
        created_at = Column(DateTime, default=datetime.utcnow)

    class Customer(Base):
        __tablename__ = "customers"
        id = Column(String, primary_key=True)
        company_id = Column(String, ForeignKey("companies.id"), nullable=False)
        legal_name = Column(String, nullable=False)
        trading_name = Column(String, nullable=True)
        tax_number = Column(String, nullable=True)
        email = Column(String, nullable=True)
        address = Column(String, nullable=True)
        postcode = Column(String, nullable=True)
        bank_details = Column(String, nullable=True)
        credit_limit = Column(Numeric(12, 2), default=10000.00)
        created_at = Column(DateTime, default=datetime.utcnow)

    class Document(Base):
        __tablename__ = "documents"
        id = Column(String, primary_key=True)
        company_id = Column(String, ForeignKey("companies.id"), nullable=False)
        source = Column(String, default="API_UPLOAD")
        filename = Column(String, nullable=False)
        mime_type = Column(String, nullable=False)
        hash_sha256 = Column(String, nullable=False, index=True)
        file_path = Column(String, nullable=True)
        storage_reference = Column(String, nullable=True)
        retention_policy_days = Column(Integer, default=2555)
        received_at = Column(DateTime, default=datetime.utcnow)
        processing_status = Column(SQLEnum(StatusType), default=StatusType.RECEIVED)

    class DocumentPage(Base):
        __tablename__ = "document_pages"
        id = Column(String, primary_key=True)
        document_id = Column(String, ForeignKey("documents.id"), nullable=False)
        page_number = Column(Integer, nullable=False)
        ocr_text = Column(Text, nullable=True)
        ocr_confidence = Column(Float, default=0.99)
        bounding_boxes = Column(JSON, nullable=True)

    class ExtractedField(Base):
        __tablename__ = "extracted_fields"
        id = Column(String, primary_key=True)
        document_id = Column(String, ForeignKey("documents.id"), nullable=False)
        field_name = Column(String, nullable=False)
        text_value = Column(String, nullable=True)
        numeric_value = Column(Numeric(12, 2), nullable=True)
        confidence = Column(Float, nullable=False)
        page_number = Column(Integer, default=1)
        bounding_box = Column(JSON, nullable=True)
        extraction_method = Column(String, default="ML_NER")

    class Invoice(Base):
        __tablename__ = "invoices"
        id = Column(String, primary_key=True)
        company_id = Column(String, ForeignKey("companies.id"), nullable=False)
        document_id = Column(String, ForeignKey("documents.id"), nullable=True)
        supplier_id = Column(String, ForeignKey("suppliers.id"), nullable=True)
        customer_id = Column(String, ForeignKey("customers.id"), nullable=True)
        po_number = Column(String, nullable=True)
        invoice_number = Column(String, nullable=False, index=True)
        invoice_date = Column(Date, nullable=False)
        due_date = Column(Date, nullable=False)
        currency = Column(String, default="GBP")
        subtotal = Column(Numeric(12, 2), nullable=False)
        tax_amount = Column(Numeric(12, 2), nullable=False)
        discount_amount = Column(Numeric(12, 2), default=0.00)
        total_amount = Column(Numeric(12, 2), nullable=False)
        amount_paid = Column(Numeric(12, 2), default=0.00)
        amount_outstanding = Column(Numeric(12, 2), nullable=False)
        overall_confidence = Column(Float, default=1.0)
        risk_score = Column(Float, default=0.0)
        automation_level = Column(String, default="FULL_AUTO")
        status = Column(SQLEnum(StatusType), default=StatusType.RECEIVED)
        is_duplicate = Column(Boolean, default=False)
        bank_details_verified = Column(Boolean, default=True)
        created_at = Column(DateTime, default=datetime.utcnow)

    class InvoiceLine(Base):
        __tablename__ = "invoice_lines"
        id = Column(String, primary_key=True)
        invoice_id = Column(String, ForeignKey("invoices.id"), nullable=False)
        line_number = Column(Integer, nullable=False)
        description = Column(String, nullable=False)
        quantity = Column(Numeric(12, 4), nullable=False)
        unit = Column(String, default="pcs")
        unit_price = Column(Numeric(12, 4), nullable=False)
        discount = Column(Numeric(12, 2), default=0.00)
        tax_rate = Column(Numeric(5, 4), default=0.20)
        line_total = Column(Numeric(12, 2), nullable=False)

    class PurchaseOrder(Base):
        __tablename__ = "purchase_orders"
        id = Column(String, primary_key=True)
        company_id = Column(String, ForeignKey("companies.id"), nullable=False)
        po_number = Column(String, nullable=False, index=True)
        supplier_id = Column(String, ForeignKey("suppliers.id"), nullable=False)
        customer_id = Column(String, ForeignKey("customers.id"), nullable=False)
        total_amount = Column(Numeric(12, 2), nullable=False)
        currency = Column(String, default="GBP")
        issue_date = Column(Date, nullable=False)
        status = Column(String, default="OPEN")

    class PurchaseOrderLine(Base):
        __tablename__ = "purchase_order_lines"
        id = Column(String, primary_key=True)
        po_id = Column(String, ForeignKey("purchase_orders.id"), nullable=False)
        line_number = Column(Integer, nullable=False)
        description = Column(String, nullable=False)
        quantity = Column(Numeric(12, 4), nullable=False)
        unit_price = Column(Numeric(12, 4), nullable=False)
        line_total = Column(Numeric(12, 2), nullable=False)

    class Payment(Base):
        __tablename__ = "payments"
        id = Column(String, primary_key=True)
        company_id = Column(String, ForeignKey("companies.id"), nullable=False)
        invoice_id = Column(String, ForeignKey("invoices.id"), nullable=True)
        amount = Column(Numeric(12, 2), nullable=False)
        currency = Column(String, default="GBP")
        payer_name = Column(String, nullable=True)
        reference = Column(String, nullable=True)
        payment_date = Column(Date, nullable=False)
        matching_confidence = Column(Float, default=0.0)
        status = Column(String, default="UNMATCHED")
        created_at = Column(DateTime, default=datetime.utcnow)

    class CreditNote(Base):
        __tablename__ = "credit_notes"
        id = Column(String, primary_key=True)
        company_id = Column(String, ForeignKey("companies.id"), nullable=False)
        invoice_id = Column(String, ForeignKey("invoices.id"), nullable=False)
        credit_note_number = Column(String, nullable=False)
        amount = Column(Numeric(12, 2), nullable=False)
        reason = Column(String, nullable=False)
        created_at = Column(DateTime, default=datetime.utcnow)

    class ApprovalRequest(Base):
        __tablename__ = "approval_requests"
        id = Column(String, primary_key=True)
        invoice_id = Column(String, ForeignKey("invoices.id"), nullable=False)
        approver = Column(String, nullable=False)
        reason = Column(String, nullable=False)
        risk_score = Column(Float, nullable=False)
        decision = Column(String, default="PENDING")
        decision_at = Column(DateTime, nullable=True)
        created_at = Column(DateTime, default=datetime.utcnow)

    class WorkflowEvent(Base):
        __tablename__ = "workflow_events"
        id = Column(String, primary_key=True)
        invoice_id = Column(String, ForeignKey("invoices.id"), nullable=False)
        event_type = Column(String, nullable=False)
        from_state = Column(String, nullable=True)
        to_state = Column(String, nullable=False)
        actor = Column(String, default="SYSTEM_WORKFLOW")
        timestamp = Column(DateTime, default=datetime.utcnow)

    class AuditEvent(Base):
        __tablename__ = "audit_events"
        id = Column(String, primary_key=True)
        company_id = Column(String, ForeignKey("companies.id"), nullable=False)
        timestamp = Column(DateTime, default=datetime.utcnow)
        actor = Column(String, nullable=False)
        system_component = Column(String, nullable=False)
        input_data = Column(JSON, nullable=True)
        decision = Column(String, nullable=False)
        confidence = Column(Float, nullable=False)
        rule_applied = Column(String, nullable=True)
        output_data = Column(JSON, nullable=True)

    class MLPrediction(Base):
        __tablename__ = "ml_predictions"
        id = Column(String, primary_key=True)
        document_id = Column(String, ForeignKey("documents.id"), nullable=False)
        model_name = Column(String, nullable=False)
        model_version = Column(String, nullable=False)
        prediction_type = Column(String, nullable=False)
        prediction_data = Column(JSON, nullable=False)
        confidence = Column(Float, nullable=False)
        timestamp = Column(DateTime, default=datetime.utcnow)

    class ModelVersion(Base):
        __tablename__ = "model_versions"
        id = Column(String, primary_key=True)
        model_name = Column(String, nullable=False)
        model_version = Column(String, nullable=False)
        training_dataset_version = Column(String, nullable=False)
        metrics = Column(JSON, nullable=False)
        is_active = Column(Boolean, default=True)
        created_at = Column(DateTime, default=datetime.utcnow)

    class ReviewItem(Base):
        __tablename__ = "review_items"
        id = Column(String, primary_key=True)
        invoice_id = Column(String, ForeignKey("invoices.id"), nullable=False)
        company_id = Column(String, ForeignKey("companies.id"), nullable=False)
        reason = Column(String, nullable=False)
        risk_score = Column(Float, nullable=False)
        status = Column(String, default="PENDING")
        reviewer_id = Column(String, nullable=True)
        resolution_notes = Column(String, nullable=True)
        created_at = Column(DateTime, default=datetime.utcnow)
        resolved_at = Column(DateTime, nullable=True)

    class TrainingLabel(Base):
        __tablename__ = "training_labels"
        id = Column(String, primary_key=True)
        document_id = Column(String, ForeignKey("documents.id"), nullable=False)
        field_name = Column(String, nullable=False)
        predicted_value = Column(String, nullable=True)
        corrected_value = Column(String, nullable=False)
        corrected_by = Column(String, nullable=False)
        timestamp = Column(DateTime, default=datetime.utcnow)

else:
    # Standard Python Dataclass Objects for zero-dependency execution
    class Company:
        def __init__(self, id, name, registration_number=None, tax_number=None, country="GB", currency="GBP"):
            self.id = id; self.name = name; self.registration_number = registration_number
            self.tax_number = tax_number; self.country = country; self.currency = currency

    class Supplier:
        def __init__(self, id, company_id, legal_name, trading_name=None, tax_number=None, email=None,
                     address=None, postcode=None, bank_iban=None, bank_sort_code=None, bank_account_number=None,
                     usual_currency="GBP", usual_payment_terms_days=30, usual_tax_rate=Decimal("0.20"),
                     historical_avg_amount=Decimal("0.00"), historical_invoice_count=0, trust_score=0.95):
            self.id = id; self.company_id = company_id; self.legal_name = legal_name
            self.trading_name = trading_name; self.tax_number = tax_number; self.email = email
            self.address = address; self.postcode = postcode; self.bank_iban = bank_iban
            self.bank_sort_code = bank_sort_code; self.bank_account_number = bank_account_number
            self.usual_currency = usual_currency; self.usual_payment_terms_days = usual_payment_terms_days
            self.usual_tax_rate = usual_tax_rate; self.historical_avg_amount = historical_avg_amount
            self.historical_invoice_count = historical_invoice_count; self.trust_score = trust_score

    class Customer:
        def __init__(self, id, company_id, legal_name, trading_name=None, tax_number=None, email=None, address=None, postcode=None, bank_details=None, credit_limit=Decimal("10000.00")):
            self.id = id; self.company_id = company_id; self.legal_name = legal_name
            self.tax_number = tax_number; self.email = email

    class Document:
        def __init__(self, id, company_id, filename, mime_type, hash_sha256, source="API_UPLOAD", storage_reference=None, retention_policy_days=2555, received_at=None, processing_status=StatusType.RECEIVED):
            self.id = id; self.company_id = company_id; self.filename = filename; self.mime_type = mime_type
            self.hash_sha256 = hash_sha256; self.source = source; self.storage_reference = storage_reference
            self.received_at = received_at or datetime.utcnow(); self.processing_status = processing_status

    class Invoice:
        def __init__(self, id, company_id, document_id=None, supplier_id=None, customer_id=None, po_number=None,
                     invoice_number="INV-001", invoice_date=None, due_date=None, currency="GBP",
                     subtotal=Decimal("0.00"), tax_amount=Decimal("0.00"), total_amount=Decimal("0.00"),
                     amount_paid=Decimal("0.00"), amount_outstanding=Decimal("0.00"), overall_confidence=1.0,
                     risk_score=0.0, automation_level="FULL_AUTO", status=StatusType.RECEIVED, is_duplicate=False, bank_details_verified=True):
            self.id = id; self.company_id = company_id; self.document_id = document_id
            self.supplier_id = supplier_id; self.customer_id = customer_id; self.po_number = po_number
            self.invoice_number = invoice_number; self.invoice_date = invoice_date or date.today()
            self.due_date = due_date or date.today(); self.currency = currency; self.subtotal = subtotal
            self.tax_amount = tax_amount; self.total_amount = total_amount; self.amount_paid = amount_paid
            self.amount_outstanding = amount_outstanding; self.overall_confidence = overall_confidence
            self.risk_score = risk_score; self.automation_level = automation_level; self.status = status
            self.is_duplicate = is_duplicate; self.bank_details_verified = bank_details_verified

    class PurchaseOrder:
        def __init__(self, id, company_id, po_number, supplier_id, customer_id, total_amount, currency="GBP", issue_date=None, status="OPEN"):
            self.id = id; self.company_id = company_id; self.po_number = po_number
            self.supplier_id = supplier_id; self.customer_id = customer_id; self.total_amount = total_amount
            self.currency = currency; self.issue_date = issue_date or date.today(); self.status = status

    class Payment:
        def __init__(self, id, company_id, invoice_id, amount, currency="GBP", payer_name=None, reference=None, payment_date=None, matching_confidence=0.0, status="UNMATCHED"):
            self.id = id; self.company_id = company_id; self.invoice_id = invoice_id
            self.amount = amount; self.currency = currency; self.payer_name = payer_name
            self.reference = reference; self.payment_date = payment_date or date.today()
            self.matching_confidence = matching_confidence; self.status = status

    class CreditNote:
        def __init__(self, id, company_id, invoice_id, credit_note_number, amount, reason, created_at=None):
            self.id = id; self.company_id = company_id; self.invoice_id = invoice_id
            self.credit_note_number = credit_note_number; self.amount = amount; self.reason = reason

    class ApprovalRequest:
        def __init__(self, id, invoice_id, approver, reason, risk_score, decision="PENDING", created_at=None):
            self.id = id; self.invoice_id = invoice_id; self.approver = approver
            self.reason = reason; self.risk_score = risk_score; self.decision = decision

    class WorkflowEvent:
        def __init__(self, id, invoice_id, event_type, from_state=None, to_state="RECEIVED", actor="SYSTEM", timestamp=None):
            self.id = id; self.invoice_id = invoice_id; self.event_type = event_type
            self.from_state = from_state; self.to_state = to_state; self.actor = actor

    class AuditEvent:
        def __init__(self, id, company_id, actor, system_component, input_data, decision, confidence, rule_applied=None, output_data=None, timestamp=None):
            self.id = id; self.company_id = company_id; self.actor = actor
            self.system_component = system_component; self.input_data = input_data; self.decision = decision
            self.confidence = confidence; self.rule_applied = rule_applied; self.output_data = output_data

    class ReviewItem:
        def __init__(self, id, invoice_id, company_id, reason, risk_score, status="PENDING", reviewer_id=None, resolution_notes=None):
            self.id = id; self.invoice_id = invoice_id; self.company_id = company_id
            self.reason = reason; self.risk_score = risk_score; self.status = status

    class MLPrediction: pass
    class ModelVersion: pass
    class TrainingLabel: pass
