from typing import Dict, Any, Optional

class SupplierTemplateEngine:
    """Requirements 63, 64, 65: Supplier Learning & Self-Improving Extraction Templates."""

    _supplier_templates = {
        "SUP-001": {
            "supplier_name": "ACME INDUSTRIAL CORP",
            "invoice_number_location": {"page": 1, "region": "TOP_RIGHT"},
            "invoice_date_location": {"page": 1, "region": "TOP_RIGHT"},
            "subtotal_location": {"page": 1, "region": "BOTTOM_RIGHT"},
            "tax_location": {"page": 1, "region": "BOTTOM_RIGHT"},
            "total_location": {"page": 1, "region": "BOTTOM_RIGHT"},
            "po_location": {"page": 1, "region": "HEADER_CENTER"},
            "number_format_pattern": r"INV-\d{4}-\d{4}",
            "usual_tax_rate": 0.20
        },
        "SUP-002": {
            "supplier_name": "GLOBAL LOGISTICS & SUPPLY",
            "invoice_number_location": {"page": 1, "region": "HEADER_LEFT"},
            "total_location": {"page": 1, "region": "BOTTOM_RIGHT"},
            "number_format_pattern": r"GLS-\d{6}",
            "usual_tax_rate": 0.20
        }
    }

    @classmethod
    def get_template(cls, supplier_id: str) -> Optional[Dict[str, Any]]:
        return cls._supplier_templates.get(supplier_id)

    @classmethod
    def apply_supplier_template(cls, supplier_id: str, raw_extracted: Dict[str, Any]) -> Dict[str, Any]:
        template = cls.get_template(supplier_id)
        if not template:
            return raw_extracted

        # Enhance confidence if field matches supplier's known format pattern
        if "invoice_number" in raw_extracted and "number_format_pattern" in template:
            inv_val = raw_extracted["invoice_number"].value or ""
            import re
            if re.match(template["number_format_pattern"], inv_val):
                raw_extracted["invoice_number"].confidence = min(0.99, raw_extracted["invoice_number"].confidence + 0.10)
                raw_extracted["invoice_number"].extraction_method = "SUPPLIER_TEMPLATE_REGEX"

        return raw_extracted
