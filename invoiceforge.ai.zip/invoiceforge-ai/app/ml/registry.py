import uuid
from datetime import datetime
from typing import Dict, Any, List, Optional
from sqlalchemy.orm import Session
from app.models.models import ModelVersion, MLPrediction, TrainingLabel

class ModelRegistry:
    """Requirements 42, 43, 47: Lightweight Model Registry and Drift Detection."""

    _models = {
        "document_classifier": "v1.2.0",
        "invoice_extractor": "v1.4.1",
        "supplier_matcher": "v2.0.0",
        "duplicate_detector": "v1.1.0",
        "anomaly_detector": "v1.3.0",
        "payment_matcher": "v1.0.2"
    }

    @classmethod
    def get_version(cls, model_name: str) -> str:
        return cls._models.get(model_name, "v1.0.0")

    @classmethod
    def record_prediction(
        cls,
        db: Session,
        document_id: str,
        model_name: str,
        prediction_type: str,
        prediction_data: Dict[str, Any],
        confidence: float
    ) -> MLPrediction:
        pred = MLPrediction(
            id=f"PRED-{uuid.uuid4().hex[:10].upper()}",
            document_id=document_id,
            model_name=model_name,
            model_version=cls.get_version(model_name),
            prediction_type=prediction_type,
            prediction_data=prediction_data,
            confidence=confidence,
            timestamp=datetime.utcnow()
        )
        db.add(pred)
        db.commit()
        return pred

class HumanFeedbackLoop:
    """Requirement 45: Human Feedback Loop storing corrections for retraining."""

    @classmethod
    def record_correction(
        cls,
        db: Session,
        document_id: str,
        field_name: str,
        predicted_value: Optional[str],
        corrected_value: str,
        corrected_by: str
    ) -> TrainingLabel:
        label = TrainingLabel(
            id=f"LBL-{uuid.uuid4().hex[:10].upper()}",
            document_id=document_id,
            field_name=field_name,
            predicted_value=predicted_value,
            corrected_value=corrected_value,
            corrected_by=corrected_by,
            timestamp=datetime.utcnow()
        )
        db.add(label)
        db.commit()
        return label

class RiskEngine:
    """Requirement 49: Risk Engine combining probabilistic & statistical signals into 0.00 -> 1.00 risk score."""

    @classmethod
    def calculate_risk(
        cls,
        duplicate_prob: float,
        supplier_match_prob: float,
        amount_anomaly_risk: float,
        bank_details_changed: bool,
        matching_uncertainty: float
    ) -> float:
        score = 0.0
        score += duplicate_prob * 0.35
        score += (1.0 - supplier_match_prob) * 0.20
        score += amount_anomaly_risk * 0.25
        score += matching_uncertainty * 0.20
        if bank_details_changed:
            score += 0.50  # Bank change heavily increases risk score

        return min(max(round(score, 3), 0.0), 0.99)

class ExplainabilityEngine:
    """Requirement 48: Explainability exposing why an automated decision was taken."""

    @classmethod
    def generate_explanation(
        cls,
        auto_approved: bool,
        supplier_matched: bool,
        po_matched: bool,
        no_duplicate: bool,
        arithmetic_valid: bool,
        tax_valid: bool,
        confidence_ok: bool,
        risk_below_threshold: bool,
        bank_verified: bool
    ) -> List[str]:
        explanations = []
        if auto_approved:
            explanations.append("✓ AUTO-APPROVED")
            explanations.append("✓ Supplier successfully matched against database")
            explanations.append("✓ Purchase Order 3-way match confirmed")
            explanations.append("✓ No duplicate invoices detected")
            explanations.append("✓ Invoice line item arithmetic validated")
            explanations.append("✓ Tax calculation confirmed")
            explanations.append("✓ Model extraction confidence > threshold")
            explanations.append("✓ Risk score below auto-approval threshold")
        else:
            explanations.append("⚠ MANUAL REVIEW REQUIRED")
            if not supplier_matched: explanations.append("✗ Supplier match confidence below threshold")
            if not po_matched: explanations.append("✗ Purchase order 3-way match incomplete or missing")
            if not no_duplicate: explanations.append("✗ Potential duplicate document flagged")
            if not arithmetic_valid: explanations.append("✗ Line total arithmetic mismatch detected")
            if not bank_verified: explanations.append("✗ Supplier bank details change flagged - mandatory verification")
            if not risk_below_threshold: explanations.append("✗ Overall risk score exceeded safe automation limit")

        return explanations
