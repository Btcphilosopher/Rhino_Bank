from enum import Enum
from typing import List, Optional, Dict, Any
from decimal import Decimal
from datetime import datetime, date
from pydantic import BaseModel, Field

class DocumentType(str, Enum):
    INVOICE = "INVOICE"
    CREDIT_NOTE = "CREDIT_NOTE"
    RECEIPT = "RECEIPT"
    PURCHASE_ORDER = "PURCHASE_ORDER"
    DELIVERY_NOTE = "DELIVERY_NOTE"
    STATEMENT = "STATEMENT"
    UNKNOWN = "UNKNOWN"

class ProcessingStatus(str, Enum):
    RECEIVED = "RECEIVED"
    PROCESSING = "PROCESSING"
    EXTRACTED = "EXTRACTED"
    VALIDATING = "VALIDATING"
    MATCHING = "MATCHING"
    REVIEW_REQUIRED = "REVIEW_REQUIRED"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    POSTED = "POSTED"
    PAID = "PAID"
    OVERDUE = "OVERDUE"
    CREDITED = "CREDITED"

class ConfidenceLevel(str, Enum):
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"

class AutomationLevel(str, Enum):
    FULL_AUTO = "FULL_AUTO"
    AUTO_WITH_REVIEW = "AUTO_WITH_REVIEW"
    MANUAL_REVIEW = "MANUAL_REVIEW"
    BLOCKED = "BLOCKED"

class ThreeWayMatchStatus(str, Enum):
    MATCHED = "MATCHED"
    PARTIALLY_MATCHED = "PARTIALLY_MATCHED"
    MISMATCHED = "MISMATCHED"

class ExtractedField(BaseModel):
    field_name: str
    value: Optional[str] = None
    numeric_value: Optional[Decimal] = None
    confidence: float
    page: int = 1
    bounding_box: Optional[List[float]] = None  # [x0, y0, x1, y1]
    extraction_method: str = "OCR_NER"

class LineItemSchema(BaseModel):
    line_number: int
    description: str
    quantity: Decimal
    unit: str = "pcs"
    unit_price: Decimal
    discount: Decimal = Decimal("0.00")
    tax_rate: Decimal = Decimal("0.20")
    line_total: Decimal

class DocumentIngestResponse(BaseModel):
    document_id: str
    source: str
    filename: str
    mime_type: str
    hash_sha256: str
    received_at: datetime
    processing_status: ProcessingStatus
    company_id: str

class ClassificationResult(BaseModel):
    document_id: str
    document_type: DocumentType
    confidence: float
    model_version: str = "v1.0"

class ExtractionResult(BaseModel):
    document_id: str
    supplier_name: Optional[ExtractedField] = None
    customer_name: Optional[ExtractedField] = None
    invoice_number: Optional[ExtractedField] = None
    invoice_date: Optional[ExtractedField] = None
    due_date: Optional[ExtractedField] = None
    currency: Optional[ExtractedField] = None
    subtotal: Optional[ExtractedField] = None
    tax_amount: Optional[ExtractedField] = None
    total_amount: Optional[ExtractedField] = None
    po_number: Optional[ExtractedField] = None
    bank_iban: Optional[ExtractedField] = None
    bank_sort_code: Optional[ExtractedField] = None
    bank_account_number: Optional[ExtractedField] = None
    line_items: List[LineItemSchema] = []
    average_confidence: float

class CustomerMatchResult(BaseModel):
    matched_customer_id: Optional[str] = None
    customer_name: Optional[str] = None
    match_probability: float
    matching_features: List[str] = []

class SupplierMatchResult(BaseModel):
    matched_supplier_id: Optional[str] = None
    supplier_name: Optional[str] = None
    match_probability: float
    matching_features: List[str] = []

class ThreeWayMatchResult(BaseModel):
    status: ThreeWayMatchStatus
    po_id: Optional[str] = None
    delivery_note_id: Optional[str] = None
    discrepancies: List[str] = []
    quantity_matched: bool = True
    price_matched: bool = True
    total_matched: bool = True

class DuplicateDetectionResult(BaseModel):
    is_duplicate: bool
    duplicate_probability: float
    possible_duplicate_ids: List[str] = []
    matching_criteria: List[str] = []

class AnomalyDetectionResult(BaseModel):
    is_anomalous: bool
    risk_score: float  # 0.0 to 1.0
    anomalies_detected: List[str] = []
    bank_details_changed: bool = False
    details: Dict[str, Any] = {}

class RuleValidationResult(BaseModel):
    passed: bool
    requires_human_review: bool
    failed_rules: List[str] = []
    explanations: List[str] = []

class RiskAssessment(BaseModel):
    overall_risk_score: float  # 0.0 to 1.0
    duplicate_risk: float
    supplier_risk: float
    amount_anomaly_risk: float
    bank_change_risk: float
    matching_uncertainty_risk: float
    automation_level: AutomationLevel

class InvoiceProcessResponse(BaseModel):
    invoice_id: str
    document_id: str
    invoice_number: str
    supplier_id: Optional[str] = None
    customer_id: Optional[str] = None
    po_number: Optional[str] = None
    status: ProcessingStatus
    automation_level: AutomationLevel
    subtotal: Decimal
    tax_amount: Decimal
    total_amount: Decimal
    overall_confidence: float
    risk_score: float
    three_way_match: ThreeWayMatchResult
    duplicate_check: DuplicateDetectionResult
    anomaly_check: AnomalyDetectionResult
    validation: RuleValidationResult
    explanations: List[str]
    created_at: datetime

class PaymentReconcileRequest(BaseModel):
    payment_id: str
    amount: Decimal
    currency: str = "GBP"
    payer_name: Optional[str] = None
    reference: Optional[str] = None
    payment_date: date

class PaymentReconcileResponse(BaseModel):
    payment_id: str
    invoice_id: Optional[str] = None
    confidence: float
    status: str  # MATCHED, PARTIAL, UNMATCHED, AMBIGUOUS
    amount_reconciled: Decimal
    remaining_balance: Decimal

class ReviewItemResolveRequest(BaseModel):
    reviewer_id: str
    action: str  # APPROVE, REJECT, CORRECT
    corrections: Optional[Dict[str, Any]] = None
    notes: Optional[str] = None

class DailyOperationsReport(BaseModel):
    report_date: date
    invoices_processed: int
    auto_approved: int
    manual_review: int
    duplicates_detected: int
    anomalies_flagged: int
    matched_payments: int
    unmatched_payments: int
    overdue_invoices_count: int
    overdue_invoices_amount: Decimal
    average_model_confidence: float
    automation_rate_percent: float

class AuditLogEntry(BaseModel):
    id: str
    timestamp: datetime
    company_id: str
    actor: str
    system_component: str
    input_data: Dict[str, Any]
    decision: str
    confidence: float
    rule_applied: Optional[str] = None
    output_data: Dict[str, Any]
