import re
from decimal import Decimal
from datetime import datetime, date
from typing import Optional, Dict, Any, List
from sqlalchemy.orm import Session
from app.models.models import Payment, Invoice, StatusType
from app.schemas.schemas import PaymentReconcileResponse

class PaymentReconciliationEngine:
    """Requirements 36, 37, 38: Payment Matching & Unmatched Cash Engine."""

    @classmethod
    def reconcile_payment(
        cls,
        db: Session,
        company_id: str,
        payment_id: str,
        amount: Decimal,
        currency: str,
        payer_name: Optional[str] = None,
        reference: Optional[str] = None,
        payment_date: date = date.today()
    ) -> PaymentReconcileResponse:
        
        # 1. Search for invoice by exact invoice number in reference string
        target_invoice = None
        match_conf = 0.0
        match_status = "UNMATCHED_CASH"

        if reference:
            inv_matches = re.findall(r"(INV-[A-Za-z0-9\-]+)", reference, re.IGNORECASE)
            if inv_matches:
                inv_num = inv_matches[0].upper()
                target_invoice = db.query(Invoice).filter(
                    Invoice.company_id == company_id,
                    Invoice.invoice_number == inv_num
                ).first()
                if target_invoice:
                    match_conf = 0.98

        # 2. If no reference match, search by exact amount + customer name
        if not target_invoice:
            possible_invoices = db.query(Invoice).filter(
                Invoice.company_id == company_id,
                Invoice.amount_outstanding > Decimal("0.00"),
                Invoice.currency == currency
            ).all()

            matching_amt_invs = [inv for inv in possible_invoices if abs(inv.amount_outstanding - amount) < Decimal("0.01")]
            
            if len(matching_amt_invs) == 1:
                target_invoice = matching_amt_invs[0]
                match_conf = 0.90
            elif len(matching_amt_invs) > 1:
                # Ambiguous! Requirement 38: Never automatically assign ambiguous payments
                match_status = "AMBIGUOUS"
                match_conf = 0.50

        # Execute match if high confidence and non-ambiguous
        amt_reconciled = Decimal("0.00")
        remaining_bal = amount

        if target_invoice and match_conf >= 0.85 and match_status != "AMBIGUOUS":
            amt_reconciled = min(amount, target_invoice.amount_outstanding)
            target_invoice.amount_paid += amt_reconciled
            target_invoice.amount_outstanding -= amt_reconciled

            if target_invoice.amount_outstanding == Decimal("0.00"):
                target_invoice.status = StatusType.PAID
                match_status = "MATCHED"
            else:
                match_status = "PARTIAL"

            remaining_bal = amount - amt_reconciled

        # Record payment entry
        payment_record = Payment(
            id=payment_id,
            company_id=company_id,
            invoice_id=target_invoice.id if (target_invoice and match_status in ["MATCHED", "PARTIAL"]) else None,
            amount=amount,
            currency=currency,
            payer_name=payer_name,
            reference=reference,
            payment_date=payment_date,
            matching_confidence=match_conf,
            status=match_status,
            created_at=datetime.utcnow()
        )
        db.add(payment_record)
        db.commit()

        return PaymentReconcileResponse(
            payment_id=payment_id,
            invoice_id=target_invoice.id if (target_invoice and match_status in ["MATCHED", "PARTIAL"]) else None,
            confidence=round(match_conf, 3),
            status=match_status,
            amount_reconciled=amt_reconciled,
            remaining_balance=remaining_bal
        )
