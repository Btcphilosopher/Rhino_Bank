from datetime import date
from decimal import Decimal
from typing import Dict, Any
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.models.models import Invoice, Payment, ReviewItem, AuditEvent, StatusType
from app.schemas.schemas import DailyOperationsReport

class ReportingAndKPIEngine:
    """Requirements 59, 60, 61, 62: Daily AI Operations Report & KPI Engine."""

    @classmethod
    def generate_daily_report(cls, db: Session, company_id: str, report_date: date = date.today()) -> DailyOperationsReport:
        invoices = db.query(Invoice).filter(Invoice.company_id == company_id).all()
        total_count = len(invoices) or 1

        auto_approved = sum(1 for inv in invoices if inv.status in [StatusType.APPROVED, StatusType.POSTED, StatusType.PAID] and inv.automation_level == "FULL_AUTO")
        manual_review = sum(1 for inv in invoices if inv.status == StatusType.REVIEW_REQUIRED or inv.automation_level == "MANUAL_REVIEW")
        duplicates = sum(1 for inv in invoices if inv.is_duplicate)
        
        # High risk or anomalous
        anomalies = sum(1 for inv in invoices if inv.risk_score >= 0.35)

        payments = db.query(Payment).filter(Payment.company_id == company_id).all()
        matched_pmts = sum(1 for p in payments if p.status in ["MATCHED", "PARTIAL"])
        unmatched_pmts = sum(1 for p in payments if p.status in ["UNMATCHED_CASH", "AMBIGUOUS"])

        overdue_invs = [inv for inv in invoices if inv.status == StatusType.OVERDUE]
        overdue_amt = sum((inv.amount_outstanding for inv in overdue_invs), Decimal("0.00"))

        conf_scores = [inv.overall_confidence for inv in invoices if inv.overall_confidence is not None]
        avg_conf = sum(conf_scores) / len(conf_scores) if conf_scores else 0.98

        auto_rate = (auto_approved / total_count) * 100.0

        return DailyOperationsReport(
            report_date=report_date,
            invoices_processed=total_count,
            auto_approved=auto_approved,
            manual_review=manual_review,
            duplicates_detected=duplicates,
            anomalies_flagged=anomalies,
            matched_payments=matched_pmts,
            unmatched_payments=unmatched_pmts,
            overdue_invoices_count=len(overdue_invs),
            overdue_invoices_amount=overdue_amt,
            average_model_confidence=round(avg_conf, 4),
            automation_rate_percent=round(auto_rate, 2)
        )
