from decimal import Decimal
from typing import Optional, List
from sqlalchemy.orm import Session
from app.models.models import Invoice, Document
from app.schemas.schemas import DuplicateDetectionResult

class DuplicateDetector:
    """Requirements 17 & 18: Cryptographic and Field-Similarity Duplicate Detection Engine."""
    
    @classmethod
    def check_duplicate(
        cls,
        db: Session,
        company_id: str,
        doc_hash: str,
        supplier_id: Optional[str],
        invoice_number: str,
        amount: Decimal,
        invoice_date: str
    ) -> DuplicateDetectionResult:
        dup_ids = []
        matching_criteria = []
        prob = 0.0

        # 1. Cryptographic Hash Match (Exact Duplicate File)
        exact_hash_docs = db.query(Document).filter(
            Document.company_id == company_id,
            Document.hash_sha256 == doc_hash
        ).all()

        # If more than 1 document has this hash, or if an invoice already exists for this hash
        for exact_hash_doc in exact_hash_docs:
            dup_inv = db.query(Invoice).filter(
                Invoice.company_id == company_id,
                Invoice.document_id == exact_hash_doc.id
            ).first()
            if dup_inv:
                matching_criteria.append("EXACT_DOCUMENT_SHA256_HASH")
                prob = 1.0
                dup_ids.append(dup_inv.id)

        # 2. Supplier + Invoice Number Match
        if invoice_number and supplier_id:
            inv_match = db.query(Invoice).filter(
                Invoice.company_id == company_id,
                Invoice.supplier_id == supplier_id,
                Invoice.invoice_number == invoice_number
            ).first()
            
            if inv_match:
                matching_criteria.append("SAME_SUPPLIER_AND_INVOICE_NUMBER")
                prob = max(prob, 0.98)
                if inv_match.id not in dup_ids:
                    dup_ids.append(inv_match.id)

        # 3. Amount + Date + Supplier Match
        if supplier_id and amount:
            amt_match = db.query(Invoice).filter(
                Invoice.company_id == company_id,
                Invoice.supplier_id == supplier_id,
                Invoice.total_amount == amount,
                Invoice.invoice_number == invoice_number
            ).first()
            if amt_match and amt_match.id not in dup_ids:
                matching_criteria.append("SAME_AMOUNT_DATE_AND_SUPPLIER")
                prob = max(prob, 0.95)
                dup_ids.append(amt_match.id)

        is_dup = prob >= 0.85

        return DuplicateDetectionResult(
            is_duplicate=is_dup,
            duplicate_probability=round(prob, 3),
            possible_duplicate_ids=dup_ids,
            matching_criteria=matching_criteria
        )
