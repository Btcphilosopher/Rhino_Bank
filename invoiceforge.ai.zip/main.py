import os
import sys

# Add invoiceforge-ai directory to sys.path
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
INV_DIR = os.path.join(BASE_DIR, "invoiceforge-ai")
sys.path.insert(0, INV_DIR)

from invoiceforge_ai_main import main

if __name__ == "__main__":
    from app.database import init_db, SessionLocal
    from main import main as run_demo
    run_demo()
