/**
 * RHINO SYNTHETIC PRODUCTS
 * Factor-Based P&L Attribution & Greek Decomposition Engine
 */

import { PnlAttributionDecomposition } from '../types/risk';

export function calculatePnlAttribution(
  rateShiftBps: number,
  spreadShiftBps: number,
  volShiftPct: number,
  corrShiftPct: number,
  fxShiftPct: number
): PnlAttributionDecomposition {
  // Model-driven Taylor series attribution
  const ratesGBP = Math.round(2100000 + rateShiftBps * 12500);
  const creditSpreadsGBP = Math.round(5700000 + spreadShiftBps * 48200);
  const volatilityGBP = Math.round(1400000 + volShiftPct * 82000);
  const correlationGBP = Math.round(2000000 + corrShiftPct * 115000);
  const fxGBP = Math.round(900000 + fxShiftPct * 35000);
  const thetaTimeDecayGBP = 700000;
  const gammaConvexityGBP = 150000;
  const residualUnexplainedGBP = -150000;

  const totalPnlGBP =
    ratesGBP +
    creditSpreadsGBP +
    volatilityGBP +
    correlationGBP +
    fxGBP +
    thetaTimeDecayGBP +
    gammaConvexityGBP +
    residualUnexplainedGBP;

  return {
    date: '2026-09-27',
    totalPnlGBP,
    components: {
      ratesGBP,
      creditSpreadsGBP,
      volatilityGBP,
      correlationGBP,
      fxGBP,
      thetaTimeDecayGBP,
      gammaConvexityGBP,
      residualUnexplainedGBP,
    },
    positionAttributions: [
      {
        productId: 'RSP-CDO-01',
        productName: 'RHINO SYNTHETIC CREDIT 01 (Mezzanine 7-15%)',
        productPnlGBP: 4250000,
        dominantFactor: 'CREDIT_SPREADS (142 bps tightening)',
        modelUsed: 'One-Factor Gaussian Copula v3.8.14',
      },
      {
        productId: 'RSP-CDO-01-SENIOR',
        productName: 'RHINO SYNTHETIC CREDIT 01 (Senior 15-30%)',
        productPnlGBP: 2800000,
        dominantFactor: 'BASE_CORRELATION (+2.4%)',
        modelUsed: 'One-Factor Gaussian Copula v3.8.14',
      },
      {
        productId: 'RSP-VAR-04',
        productName: 'FTSE 100 1Y VARIANCE SWAP',
        productPnlGBP: 1400000,
        dominantFactor: 'IMPLIED_VOLATILITY (+1.8% vol rally)',
        modelUsed: 'Black-Scholes Vol Surface Replication',
      },
      {
        productId: 'RSP-HYBRID-01',
        productName: 'RHINO CROSS-ASSET SYNTHETIC 01',
        productPnlGBP: 2350000,
        dominantFactor: 'JOINT_RATES_ENERGY_SPREAD',
        modelUsed: 'Multi-Factor Joint Monte Carlo',
      },
      {
        productId: 'RSP-CMS-02',
        productName: 'GBP 10Y-2Y CMS CURVE STEEPENER',
        productPnlGBP: 2000000,
        dominantFactor: 'GILT_CURVE_STEEPNESS (+14 bps)',
        modelUsed: 'Bachelier Normal Swaption Model',
      },
    ],
  };
}
