/**
 * RHINO SYNTHETIC PRODUCTS
 * Closed-Form Derivatives Pricing Engine
 * Black-Scholes, Black 76, Bachelier, Variance Swaps & Greek Analytics
 */

import { normalCdf, normalPdf } from './gaussianCopula';

export interface OptionPricingResult {
  price: number;
  delta: number;
  gamma: number;
  vega: number;
  theta: number;
  rho: number;
  intrinsicValue: number;
  timeValue: number;
  impliedVol: number;
}

/**
 * Black-Scholes Formula for European Options
 */
export function blackScholes(
  spot: number,
  strike: number,
  timeToExpiry: number,
  volatility: number,
  riskFreeRate: number,
  isCall: boolean
): OptionPricingResult {
  if (timeToExpiry <= 0) {
    const intrinsic = isCall ? Math.max(0, spot - strike) : Math.max(0, strike - spot);
    return {
      price: intrinsic,
      delta: isCall ? (spot > strike ? 1 : 0) : (spot < strike ? -1 : 0),
      gamma: 0,
      vega: 0,
      theta: 0,
      rho: 0,
      intrinsicValue: intrinsic,
      timeValue: 0,
      impliedVol: volatility,
    };
  }

  const sqrtT = Math.sqrt(timeToExpiry);
  const d1 = (Math.log(spot / strike) + (riskFreeRate + 0.5 * volatility * volatility) * timeToExpiry) / (volatility * sqrtT);
  const d2 = d1 - volatility * sqrtT;

  const nd1 = normalCdf(d1);
  const nd2 = normalCdf(d2);
  const nPrimeD1 = normalPdf(d1);
  const df = Math.exp(-riskFreeRate * timeToExpiry);

  let price = 0;
  let delta = 0;
  let rho = 0;
  let theta = 0;

  if (isCall) {
    price = spot * nd1 - strike * df * nd2;
    delta = nd1;
    rho = (strike * timeToExpiry * df * nd2) / 100;
    theta = (-(spot * nPrimeD1 * volatility) / (2 * sqrtT) - riskFreeRate * strike * df * nd2) / 365;
  } else {
    price = strike * df * normalCdf(-d2) - spot * normalCdf(-d1);
    delta = nd1 - 1;
    rho = (-strike * timeToExpiry * df * normalCdf(-d2)) / 100;
    theta = (-(spot * nPrimeD1 * volatility) / (2 * sqrtT) + riskFreeRate * strike * df * normalCdf(-d2)) / 365;
  }

  const gamma = nPrimeD1 / (spot * volatility * sqrtT);
  const vega = (spot * sqrtT * nPrimeD1) / 100; // per 1% vol change
  const intrinsic = isCall ? Math.max(0, spot - strike) : Math.max(0, strike - spot);
  const timeValue = Math.max(0, price - intrinsic);

  return {
    price: Math.max(0, price),
    delta,
    gamma,
    vega,
    theta,
    rho,
    intrinsicValue: intrinsic,
    timeValue,
    impliedVol: volatility,
  };
}

/**
 * Black 76 Formula for Swaptions, Caps/Floors & Commodity Futures Options
 */
export function black76(
  forwardRate: number,
  strike: number,
  timeToExpiry: number,
  volatility: number,
  discountFactor: number,
  isCall: boolean
): number {
  if (timeToExpiry <= 0) {
    return isCall ? Math.max(0, forwardRate - strike) * discountFactor : Math.max(0, strike - forwardRate) * discountFactor;
  }
  const sqrtT = Math.sqrt(timeToExpiry);
  const d1 = (Math.log(forwardRate / strike) + 0.5 * volatility * volatility * timeToExpiry) / (volatility * sqrtT);
  const d2 = d1 - volatility * sqrtT;

  if (isCall) {
    return discountFactor * (forwardRate * normalCdf(d1) - strike * normalCdf(d2));
  } else {
    return discountFactor * (strike * normalCdf(-d2) - forwardRate * normalCdf(-d1));
  }
}

/**
 * Variance Swap Fair Strike & Payoff Pricing
 */
export function priceVarianceSwap(
  spot: number,
  volSurfacePoints: { strike: number; impliedVol: number }[],
  timeYears: number,
  notionalVegaGBP: number,
  realizedVolPct = 18.5
): {
  fairVarianceStrikePct: number;
  fairVolStrikePct: number;
  currentPnlGBP: number;
  vegaExposureGBP: number;
  convexityGBP: number;
} {
  // Approximate fair variance from vol surface smile integration
  const avgVol = volSurfacePoints.reduce((acc, p) => acc + p.impliedVol, 0) / (volSurfacePoints.length || 1);
  const fairVolStrikePct = avgVol * 100;
  const fairVarianceStrikePct = Math.pow(fairVolStrikePct, 2);

  const realizedVariance = Math.pow(realizedVolPct, 2);
  const varianceNotional = notionalVegaGBP / (2 * fairVolStrikePct);

  // Payoff = Variance Notional * (Realized Var - Strike Var)
  const currentPnlGBP = varianceNotional * (realizedVariance - fairVarianceStrikePct);
  const vegaExposureGBP = notionalVegaGBP;
  const convexityGBP = notionalVegaGBP * 0.12;

  return {
    fairVarianceStrikePct,
    fairVolStrikePct,
    currentPnlGBP,
    vegaExposureGBP,
    convexityGBP,
  };
}
