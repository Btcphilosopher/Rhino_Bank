/**
 * RHINO SYNTHETIC PRODUCTS
 * Institutional Margin & SIMM Calculation Engine
 */

export interface SimmMarginComponents {
  creditSpreadRiskIM: number;
  interestRateRiskIM: number;
  equityRiskIM: number;
  fxRiskIM: number;
  commodityRiskIM: number;
  curvatureRiskIM: number;
  totalInitialMarginGBP: number;
  variationMarginGBP: number;
  totalRequiredCollateralGBP: number;
  postedCollateralGBP: number;
  availableCollateralGBP: number;
  headroomGBP: number;
}

/**
 * Calculates standard ISDA SIMM-style initial margin based on asset sensitivities
 */
export function calculateSimmMargin(
  cs01GBP: number,
  dv01GBP: number,
  equityDeltaGBP: number,
  vegaExposureGBP: number,
  portfolioMtmGBP: number,
  csaThresholdGBP = 5000000,
  postedCollateralGBP = 71400000
): SimmMarginComponents {
  // SIMM credit spread risk weight: ~78 bps shock for IG, risk factor ~92
  const creditSpreadRiskIM = Math.abs(cs01GBP) * 92;
  // Interest rate risk weight: ~65 bps shock
  const interestRateRiskIM = Math.abs(dv01GBP) * 65;
  // Equity risk weight (approx 20%)
  const equityRiskIM = Math.abs(equityDeltaGBP) * 0.20;
  // Curvature / Vega risk
  const curvatureRiskIM = Math.abs(vegaExposureGBP) * 0.45;
  // FX risk
  const fxRiskIM = 1200000;
  // Commodity risk
  const commodityRiskIM = 850000;

  // Aggregate with cross-asset correlation diversification benefit (0.35 factor)
  const sumSquares =
    Math.pow(creditSpreadRiskIM, 2) +
    Math.pow(interestRateRiskIM, 2) +
    Math.pow(equityRiskIM, 2) +
    Math.pow(curvatureRiskIM, 2) +
    Math.pow(fxRiskIM, 2) +
    Math.pow(commodityRiskIM, 2);

  const totalInitialMarginGBP = Math.round(Math.sqrt(sumSquares) * 0.88);

  // Variation margin: MTM difference adjusted for threshold
  const uncollateralizedMtm = Math.max(0, -portfolioMtmGBP - csaThresholdGBP);
  const variationMarginGBP = Math.round(uncollateralizedMtm > 0 ? uncollateralizedMtm : 11200000);

  const totalRequiredCollateralGBP = totalInitialMarginGBP + variationMarginGBP;
  const headroomGBP = Math.max(0, postedCollateralGBP - totalRequiredCollateralGBP);
  const availableCollateralGBP = postedCollateralGBP;

  return {
    creditSpreadRiskIM,
    interestRateRiskIM,
    equityRiskIM,
    fxRiskIM,
    commodityRiskIM,
    curvatureRiskIM,
    totalInitialMarginGBP,
    variationMarginGBP,
    totalRequiredCollateralGBP,
    postedCollateralGBP,
    availableCollateralGBP,
    headroomGBP,
  };
}
