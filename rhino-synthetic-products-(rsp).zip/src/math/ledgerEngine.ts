/**
 * RHINO SYNTHETIC PRODUCTS
 * Financial Ledger & Double-Entry Accounting Generator
 */

import { LedgerEntry, LedgerEventType } from '../types/trading';

/**
 * Creates an immutable, double-entry financial ledger entry
 */
export function createLedgerEntry(
  eventType: LedgerEventType,
  debitAccount: string,
  creditAccount: string,
  amountGBP: number,
  description: string,
  tradeId?: string,
  productId?: string
): LedgerEntry {
  const timestamp = new Date().toISOString();
  const rawString = `${timestamp}-${eventType}-${debitAccount}-${creditAccount}-${amountGBP}-${tradeId || ''}`;
  let hashVal = 0;
  for (let i = 0; i < rawString.length; i++) {
    hashVal = (hashVal << 5) - hashVal + rawString.charCodeAt(i);
    hashVal |= 0;
  }
  const auditHash = `0x${Math.abs(hashVal).toString(16).padStart(8, '0').toUpperCase()}RHINO`;

  return {
    entryId: `LEDGER-${Math.random().toString(36).substring(2, 8).toUpperCase()}`,
    timestamp,
    eventType,
    tradeId,
    productId,
    debitAccount,
    creditAccount,
    amountGBP,
    currency: 'GBP',
    description,
    auditHash,
    settled: true,
  };
}
