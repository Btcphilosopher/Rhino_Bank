/**
 * RHINO SYNTHETIC PRODUCTS
 * Credit Curve & Hazard Rate Bootstrapping Engine
 */

export interface CreditCurvePoint {
  tenor: string;
  years: number;
  cdsSpreadBps: number;
  hazardRate: number; // lambda(t)
  survivalProbability: number; // S(t)
  defaultProbability: number; // 1 - S(t)
}

/**
 * Bootstraps constant piecewise hazard rates from standard CDS spreads
 */
export function bootstrapCreditCurve(
  tenors: { tenor: string; years: number; cdsSpreadBps: number }[],
  recoveryRate = 0.40
): CreditCurvePoint[] {
  const result: CreditCurvePoint[] = [];
  let prevSurvival = 1.0;
  let prevTime = 0.0;

  for (const item of tenors) {
    const s = item.cdsSpreadBps / 10000;
    const t = item.years;
    const dt = t - prevTime;

    // Piecewise hazard rate approximation: lambda ~ spread / (1 - R)
    const lambda = s / (1 - recoveryRate);
    const survival = Math.exp(-lambda * t);

    result.push({
      tenor: item.tenor,
      years: t,
      cdsSpreadBps: item.cdsSpreadBps,
      hazardRate: lambda,
      survivalProbability: survival,
      defaultProbability: 1 - survival,
    });

    prevSurvival = survival;
    prevTime = t;
  }

  return result;
}

/**
 * Calculates Single-Name CDS Pricing Legs and CS01
 */
export function priceCDS(
  notionalGBP: number,
  spreadBps: number,
  marketSpreadBps: number,
  tenorYears = 5,
  recoveryRate = 0.40,
  riskFreeRate = 0.045
): {
  pvProtectionLegGBP: number;
  pvPremiumLegGBP: number;
  upfrontAmountGBP: number;
  cleanPricePct: number;
  cs01GBP: number;
  rec01GBP: number;
} {
  const lambda = (marketSpreadBps / 10000) / (1 - recoveryRate);
  const df = (1 - Math.exp(-riskFreeRate * tenorYears)) / riskFreeRate;
  const avgSurvival = (1 + Math.exp(-lambda * tenorYears)) / 2;

  // Premium leg annuity (risky PV01)
  const rpv01 = avgSurvival * df;
  const pvPremiumLegGBP = notionalGBP * (spreadBps / 10000) * rpv01;

  // Protection leg PV
  const pd = 1 - Math.exp(-lambda * tenorYears);
  const pvProtectionLegGBP = notionalGBP * (1 - recoveryRate) * pd * Math.exp(-riskFreeRate * (tenorYears / 2));

  // Upfront to buy protection
  const upfrontAmountGBP = pvProtectionLegGBP - (notionalGBP * (marketSpreadBps / 10000) * rpv01);
  const cleanPricePct = 100 - (upfrontAmountGBP / notionalGBP) * 100;

  const cs01GBP = (notionalGBP * rpv01) / 10000;
  const rec01GBP = -(notionalGBP * pd * 0.01);

  return {
    pvProtectionLegGBP,
    pvPremiumLegGBP,
    upfrontAmountGBP,
    cleanPricePct,
    cs01GBP,
    rec01GBP,
  };
}
