/**
 * RHINO SYNTHETIC PRODUCTS
 * Collateral Optimisation & Haircut Allocation Engine
 */

import { CollateralAsset, CollateralOptimizationResult } from '../types/margin';

/**
 * Optimizes collateral pledge to meet margin requirements with minimum funding drag & highest liquidity retention
 */
export function optimizeCollateralAllocation(
  availableAssets: CollateralAsset[],
  targetMarginGBP: number
): CollateralOptimizationResult {
  // Sort assets by ascending cost of pledging (bps) and descending liquidity tier
  const sorted = [...availableAssets].sort((a, b) => {
    return (a.costOfPledgingBps + a.haircutPct * 100) - (b.costOfPledgingBps + b.haircutPct * 100);
  });

  let remainingToCover = targetMarginGBP;
  let totalAllocatedNominal = 0;
  let totalEffectiveCollateral = 0;
  let weightedFundingCostSum = 0;

  const allocationBreakdown = sorted.map(asset => {
    if (remainingToCover <= 0) {
      return {
        assetType: asset.type,
        assetName: asset.name,
        pledgedValueGBP: 0,
        effectiveCollateralGBP: 0,
        haircutPct: asset.haircutPct,
        fundingCostGBP: 0,
      };
    }

    const maxEffectiveFromAsset = asset.marketValueGBP * (1 - asset.haircutPct);
    const effectiveNeeded = Math.min(remainingToCover, maxEffectiveFromAsset);
    const nominalPledged = effectiveNeeded / (1 - asset.haircutPct);
    const fundingCostGBP = (nominalPledged * asset.costOfPledgingBps) / 10000;

    remainingToCover -= effectiveNeeded;
    totalAllocatedNominal += nominalPledged;
    totalEffectiveCollateral += effectiveNeeded;
    weightedFundingCostSum += fundingCostGBP;

    return {
      assetType: asset.type,
      assetName: asset.name,
      pledgedValueGBP: Math.round(nominalPledged),
      effectiveCollateralGBP: Math.round(effectiveNeeded),
      haircutPct: asset.haircutPct,
      fundingCostGBP: Math.round(fundingCostGBP),
    };
  });

  const blendedFundingCostBps = totalAllocatedNominal > 0
    ? (weightedFundingCostSum / totalAllocatedNominal) * 10000
    : 0;

  const haircutEfficiencyPct = totalAllocatedNominal > 0
    ? (totalEffectiveCollateral / totalAllocatedNominal) * 100
    : 100;

  const totalPoolValue = availableAssets.reduce((s, a) => s + a.marketValueGBP, 0);
  const headroomGBP = Math.max(0, totalPoolValue - totalAllocatedNominal);

  return {
    totalRequiredMarginGBP: targetMarginGBP,
    allocatedCollateralGBP: Math.round(totalAllocatedNominal),
    postHaircutValueGBP: Math.round(totalEffectiveCollateral),
    blendedFundingCostBps: Math.round(blendedFundingCostBps * 10) / 10,
    haircutEfficiencyPct: Math.round(haircutEfficiencyPct * 10) / 10,
    allocationBreakdown,
    headroomGBP: Math.round(headroomGBP),
  };
}
