/**
 * RHINO SYNTHETIC PRODUCTS
 * Market Data Feeds, Yield Curves, Vol Surfaces & Factor Hierarchy
 */

import { FactorHierarchyNode } from '../types/risk';

export interface CurveTenor {
  tenor: string;
  years: number;
  ratePct: number;
}

export const YIELD_CURVE_GBP_SONIA: CurveTenor[] = [
  { tenor: '1M', years: 0.083, ratePct: 4.85 },
  { tenor: '3M', years: 0.25, ratePct: 4.78 },
  { tenor: '6M', years: 0.5, ratePct: 4.65 },
  { tenor: '1Y', years: 1.0, ratePct: 4.45 },
  { tenor: '2Y', years: 2.0, ratePct: 4.22 },
  { tenor: '5Y', years: 5.0, ratePct: 4.10 },
  { tenor: '10Y', years: 10.0, ratePct: 4.28 },
  { tenor: '30Y', years: 30.0, ratePct: 4.58 },
];

export const CDS_CURVE_ITRAXX_IG: CurveTenor[] = [
  { tenor: '1Y', years: 1.0, ratePct: 0.24 }, // 24 bps
  { tenor: '3Y', years: 3.0, ratePct: 0.48 }, // 48 bps
  { tenor: '5Y', years: 5.0, ratePct: 0.62 }, // 62 bps
  { tenor: '7Y', years: 7.0, ratePct: 0.84 }, // 84 bps
  { tenor: '10Y', years: 10.0, ratePct: 1.08 }, // 108 bps
];

export interface VolSurfaceGridPoint {
  strikePct: number; // 80%, 90%, 100% (ATM), 110%, 120%
  tenor: string;
  years: number;
  impliedVolPct: number;
  delta25PutVolPct: number;
  atmVolPct: number;
  delta25CallVolPct: number;
}

export const VOL_SURFACE_FTSE_100: VolSurfaceGridPoint[] = [
  { strikePct: 80, tenor: '1M', years: 0.083, impliedVolPct: 24.8, delta25PutVolPct: 23.2, atmVolPct: 16.5, delta25CallVolPct: 14.8 },
  { strikePct: 90, tenor: '1M', years: 0.083, impliedVolPct: 19.4, delta25PutVolPct: 23.2, atmVolPct: 16.5, delta25CallVolPct: 14.8 },
  { strikePct: 100, tenor: '1M', years: 0.083, impliedVolPct: 16.5, delta25PutVolPct: 23.2, atmVolPct: 16.5, delta25CallVolPct: 14.8 },
  { strikePct: 110, tenor: '1M', years: 0.083, impliedVolPct: 15.2, delta25PutVolPct: 23.2, atmVolPct: 16.5, delta25CallVolPct: 14.8 },
  { strikePct: 120, tenor: '1M', years: 0.083, impliedVolPct: 14.8, delta25PutVolPct: 23.2, atmVolPct: 16.5, delta25CallVolPct: 14.8 },

  { strikePct: 80, tenor: '6M', years: 0.5, impliedVolPct: 23.5, delta25PutVolPct: 22.0, atmVolPct: 17.2, delta25CallVolPct: 15.6 },
  { strikePct: 90, tenor: '6M', years: 0.5, impliedVolPct: 19.8, delta25PutVolPct: 22.0, atmVolPct: 17.2, delta25CallVolPct: 15.6 },
  { strikePct: 100, tenor: '6M', years: 0.5, impliedVolPct: 17.2, delta25PutVolPct: 22.0, atmVolPct: 17.2, delta25CallVolPct: 15.6 },
  { strikePct: 110, tenor: '6M', years: 0.5, impliedVolPct: 16.1, delta25PutVolPct: 22.0, atmVolPct: 17.2, delta25CallVolPct: 15.6 },
  { strikePct: 120, tenor: '6M', years: 0.5, impliedVolPct: 15.5, delta25PutVolPct: 22.0, atmVolPct: 17.2, delta25CallVolPct: 15.6 },

  { strikePct: 80, tenor: '1Y', years: 1.0, impliedVolPct: 22.9, delta25PutVolPct: 21.4, atmVolPct: 17.8, delta25CallVolPct: 16.2 },
  { strikePct: 90, tenor: '1Y', years: 1.0, impliedVolPct: 19.9, delta25PutVolPct: 21.4, atmVolPct: 17.8, delta25CallVolPct: 16.2 },
  { strikePct: 100, tenor: '1Y', years: 1.0, impliedVolPct: 17.8, delta25PutVolPct: 21.4, atmVolPct: 17.8, delta25CallVolPct: 16.2 },
  { strikePct: 110, tenor: '1Y', years: 1.0, impliedVolPct: 16.7, delta25PutVolPct: 21.4, atmVolPct: 17.8, delta25CallVolPct: 16.2 },
  { strikePct: 120, tenor: '1Y', years: 1.0, impliedVolPct: 16.0, delta25PutVolPct: 21.4, atmVolPct: 17.8, delta25CallVolPct: 16.2 },

  { strikePct: 80, tenor: '2Y', years: 2.0, impliedVolPct: 22.1, delta25PutVolPct: 20.8, atmVolPct: 18.2, delta25CallVolPct: 16.8 },
  { strikePct: 90, tenor: '2Y', years: 2.0, impliedVolPct: 19.8, delta25PutVolPct: 20.8, atmVolPct: 18.2, delta25CallVolPct: 16.8 },
  { strikePct: 100, tenor: '2Y', years: 2.0, impliedVolPct: 18.2, delta25PutVolPct: 20.8, atmVolPct: 18.2, delta25CallVolPct: 16.8 },
  { strikePct: 110, tenor: '2Y', years: 2.0, impliedVolPct: 17.3, delta25PutVolPct: 20.8, atmVolPct: 18.2, delta25CallVolPct: 16.8 },
  { strikePct: 120, tenor: '2Y', years: 2.0, impliedVolPct: 16.7, delta25PutVolPct: 20.8, atmVolPct: 18.2, delta25CallVolPct: 16.8 },

  { strikePct: 80, tenor: '5Y', years: 5.0, impliedVolPct: 21.5, delta25PutVolPct: 20.2, atmVolPct: 18.9, delta25CallVolPct: 17.5 },
  { strikePct: 90, tenor: '5Y', years: 5.0, impliedVolPct: 20.0, delta25PutVolPct: 20.2, atmVolPct: 18.9, delta25CallVolPct: 17.5 },
  { strikePct: 100, tenor: '5Y', years: 5.0, impliedVolPct: 18.9, delta25PutVolPct: 20.2, atmVolPct: 18.9, delta25CallVolPct: 17.5 },
  { strikePct: 110, tenor: '5Y', years: 5.0, impliedVolPct: 18.1, delta25PutVolPct: 20.2, atmVolPct: 18.9, delta25CallVolPct: 17.5 },
  { strikePct: 120, tenor: '5Y', years: 5.0, impliedVolPct: 17.6, delta25PutVolPct: 20.2, atmVolPct: 18.9, delta25CallVolPct: 17.5 },
];

/** 8x8 Cross-Asset Correlation Matrix */
export const CROSS_ASSET_FACTORS = [
  'UK 5Y Gilt',
  'US 5Y Treasury',
  'GBP/USD Spot',
  'Brent Crude',
  'UK Power M1',
  'FTSE 100',
  'iTraxx Europe IG',
  'Rhino Base Corr',
];

export const CROSS_ASSET_CORRELATION_MATRIX: number[][] = [
  [ 1.00,  0.82, -0.42,  0.31,  0.28, -0.38,  0.54,  0.25], // UK 5Y Gilt
  [ 0.82,  1.00, -0.58,  0.36,  0.22, -0.44,  0.49,  0.22], // US 5Y Treasury
  [-0.42, -0.58,  1.00, -0.28, -0.19,  0.52, -0.46, -0.18], // GBP/USD Spot
  [ 0.31,  0.36, -0.28,  1.00,  0.74,  0.29,  0.15,  0.12], // Brent Crude
  [ 0.28,  0.22, -0.19,  0.74,  1.00,  0.18,  0.21,  0.15], // UK Power M1
  [-0.38, -0.44,  0.52,  0.29,  0.18,  1.00, -0.68, -0.34], // FTSE 100
  [ 0.54,  0.49, -0.46,  0.15,  0.21, -0.68,  1.00,  0.58], // iTraxx Europe IG
  [ 0.25,  0.22, -0.18,  0.12,  0.15, -0.34,  0.58,  1.00], // Rhino Base Corr
];

/** Factor Hierarchy Tree for Risk Aggregation */
export const FACTOR_HIERARCHY_TREE: FactorHierarchyNode = {
  id: 'MACRO-ROOT',
  name: 'GLOBAL MACRO ENVIRONMENT',
  level: 'MACRO',
  value: 'UK INFLATION 2.4% / BOE BANK RATE 4.75%',
  change24h: '-0.1%',
  riskWeightPct: 100,
  children: [
    {
      id: 'FACTOR-RATES',
      name: 'RATES & YIELD CURVES',
      level: 'CURVE',
      value: 'SONIA 5Y: 4.10%',
      change24h: '+3.2 bps',
      riskWeightPct: 28.5,
      children: [
        { id: 'F-GILT-5Y', name: 'UK 5Y Gilt Benchmark', level: 'UNDERLYING', value: '4.10%', change24h: '+3.2 bps', riskWeightPct: 16.0 },
        { id: 'F-SOFR-5Y', name: 'US SOFR 5Y Curve', level: 'UNDERLYING', value: '3.88%', change24h: '+1.8 bps', riskWeightPct: 12.5 },
      ]
    },
    {
      id: 'FACTOR-CREDIT',
      name: 'STRUCTURED CREDIT & CDS',
      level: 'CREDIT',
      value: 'iTraxx IG: 62.4 bps',
      change24h: '-1.8 bps',
      riskWeightPct: 44.2,
      children: [
        { id: 'F-RHINO-CDO', name: 'Rhino Corporate 100 Basket', level: 'UNDERLYING', value: '142.0 bps', change24h: '-2.4 bps', riskWeightPct: 27.2 },
        { id: 'F-BASE-CORR', name: 'Credit Base Correlation (3-7%)', level: 'CORRELATION', value: '27.4%', change24h: '+0.5%', riskWeightPct: 17.0 },
      ]
    },
    {
      id: 'FACTOR-EQUITY-VOL',
      name: 'EQUITY & VOLATILITY',
      level: 'VOLATILITY',
      value: 'FTSE 100 1Y ATM Vol: 17.8%',
      change24h: '-0.4%',
      riskWeightPct: 15.8,
      children: [
        { id: 'F-FTSE-SPOT', name: 'FTSE 100 Spot Index', level: 'UNDERLYING', value: '8,324.5', change24h: '+0.65%', riskWeightPct: 9.8 },
        { id: 'F-VAR-SWAP', name: 'UK 1Y Variance Strike', level: 'MARKET', value: '316.8 pts', change24h: '-4.2 pts', riskWeightPct: 6.0 },
      ]
    },
    {
      id: 'FACTOR-COMMODITY-FX',
      name: 'COMMODITIES & FX',
      level: 'MARKET',
      value: 'GBP/USD: 1.3120 / Brent: $78.40',
      change24h: '+0.15%',
      riskWeightPct: 11.5,
      children: [
        { id: 'F-GBP-USD', name: 'GBP/USD Spot Rate', level: 'UNDERLYING', value: '1.3120', change24h: '+0.22%', riskWeightPct: 6.5 },
        { id: 'F-BRENT-M1', name: 'Brent Crude Active Month', level: 'UNDERLYING', value: '$78.40/bbl', change24h: '-0.85%', riskWeightPct: 5.0 },
      ]
    }
  ]
};
