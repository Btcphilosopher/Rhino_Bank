/**
 * RHINO SYNTHETIC PRODUCTS
 * Reference Portfolios & Tranche Structures
 */

import { ReferencePortfolio, ReferenceCreditEntity } from '../types/credit';
import { TrancheDefinition } from '../types/product';

const SECTORS = [
  'Aerospace & Defence',
  'Energy & Utilities',
  'Telecommunications',
  'Industrial & Materials',
  'Financial Institutions',
  'Technology & Software',
  'Healthcare & Pharma',
  'Consumer & Retail',
  'Automotive & Transport',
  'Real Estate & Infrastructure',
];

const RATINGS: ('AAA' | 'AA+' | 'AA' | 'A+' | 'A' | 'BBB+' | 'BBB' | 'BBB-' | 'BB+' | 'BB')[] = [
  'AAA', 'AA+', 'AA', 'A+', 'A', 'BBB+', 'BBB', 'BBB-', 'BB+', 'BB'
];

const COMPANY_NAMES = [
  'Rolls-Royce SMR Holdings', 'BAE Systems Synthetic UK', 'Airbus European Aero SPV', 'Babcock Marine Credit',
  'BP Energy Synthetic', 'Shell Global Transition SPV', 'National Grid UK Grid Corp', 'Centrica Energy Flow',
  'SSE Renewables Synthetic', 'Orsted UK Offshore Debt', 'Vodafone Group Synthetic', 'BT Group Infrastructure',
  'Orange UK Holdings', 'Deutsche Telekom Credit SPV', 'Rio Tinto Metals Synth', 'Glencore Commodities SPV',
  'Anglo American Mining', 'AstraZeneca Global Pharma', 'GSK Bioscience Synthetic', 'Diageo Global Brands',
  'Unilever UK Consumer', 'Tesco Retail Infrastructure', 'Compass Group Catering', 'Reckitt Benckiser Synth',
  'Barclays UK Bank SPV', 'NatWest Group Synthetics', 'Lloyds Banking Group Corp', 'Standard Chartered Synth',
  'Prudential Life UK', 'Aviva Insurance Synthetic', 'Legal & General SPV', 'London Stock Exchange Synth',
  'ARM Holdings Semiconductor', 'Sage Group Enterprise', 'Darktrace Cyber Credit', 'Informa Data Services',
  'RELX Information SPV', 'Experian Global Credit', 'Smith & Nephew Medical', 'InterContinental Hotels',
  'Whitbread Hospitality', 'IAG British Airways SPV', 'EasyJet Fleet Synthetic', 'Aston Martin Synthetic',
  'Jaguar Land Rover Corp', 'Melrose Industries UK', 'Spirax-Sarco Engineering', 'Halma Technology SPV',
  'Bunzl Distribution', 'Smiths Group Industrial', 'Johnson Matthey Clean Air', 'Croda International SPV',
  'Severn Trent Water SPV', 'United Utilities Water', 'Pennon Group Utilities', 'DCC Energy & Logistics',
  'Hikma Pharmaceuticals', 'Dechra Pharma Synthetic', 'Next Retail SPV', 'Marks & Spencer Synthetic',
  'Kingfisher DIY Holdings', 'B&M European Value', 'JD Sports Fashion SPV', 'Howden Joinery Group',
  'Taylor Wimpey Housing', 'Barratt Redrow SPV', 'Persimmon Homes Synth', 'Berkeley Group Urban',
  'Segro Industrial REIT', 'Land Securities Group', 'British Land Commercial', 'Derwent London SPV',
  'Great Portland Estates', 'UNITE Group Student SPV', 'Grainger Residential SPV', 'Hammerson Retail SPV',
  'Workspace Group London', 'Assura Healthcare REIT', 'Big Yellow Storage SPV', 'Safestore Holdings',
  'Electrocomponents RS SPV', 'Diploma International', 'Spectris Precision SPV', 'Renishaw Measurement',
  'Rotork Flow Control SPV', 'Weir Group Industrial', 'Bodycote Thermal SPV', 'Vesuvius Flow Control',
  'Morgan Advanced Materials', 'Senior Aerospace SPV', 'TT Electronics Synth', 'Oxford Instruments SPV',
  'Ultra Electronics SPV', 'Chemring Group Defence', 'QinetiQ Group Science', 'Cobham Aerospace SPV',
  'Meggitt Industrial Debt', 'Spectris Instruments', 'Elementis Specialty Chemicals', 'Victrex Polymer Solutions'
];

/** 100 Reference Entities for Rhino Corporate Credit Portfolio 01 */
export const CORPORATE_ENTITIES_100: ReferenceCreditEntity[] = COMPANY_NAMES.map((name, idx) => {
  const rating = RATINGS[idx % RATINGS.length];
  const sector = SECTORS[idx % SECTORS.length];
  const spread5yBps = Math.round(55 + (idx * 1.8) + (rating.startsWith('B') ? 80 : rating.startsWith('A') ? 0 : 25));
  const recoveryRate = 0.40;
  const lambda = (spread5yBps / 10000) / (1 - recoveryRate);
  const pd5y = 1 - Math.exp(-lambda * 5);

  return {
    id: `ENT-${String(idx + 1).padStart(3, '0')}`,
    name,
    ticker: name.split(' ')[0].toUpperCase() + '.LN',
    sector,
    country: 'United Kingdom',
    rating,
    spread5yBps,
    recoveryRate,
    weightPct: 1.0,
    defaultProbability5y: pd5y,
    hazardRate: lambda,
    isDefaulted: false,
    lossGivenDefaultGBP: 100000000 * (1 - recoveryRate), // £60m loss if default
  };
});

/** FLAGSHIP: RHINO CORPORATE CREDIT PORTFOLIO 01 */
export const RHINO_CREDIT_PORTFOLIO_01: ReferencePortfolio = {
  id: 'RHINO-PORTFOLIO-CREDIT-01',
  name: 'RHINO CORPORATE CREDIT PORTFOLIO 01',
  description: '100 Reference UK & European Corporate Entities across 10 Diversified Sectors',
  totalEntities: 100,
  totalNotional: 10000000000, // £10 Billion
  averageSpreadBps: 142,
  averageRating: 'BBB+',
  averageMaturityYears: 5.0,
  sectorConcentrationPct: 12.4,
  baseCorrelation: 0.27, // 27% Base Correlation
  recoveryAssumption: 0.40, // 40% Recovery
  entities: CORPORATE_ENTITIES_100,
};

/** Default Standard Tranche Structure for Synthetic CDO 01 */
export const DEFAULT_CDO_TRANCHES: TrancheDefinition[] = [
  {
    id: 'TR-SUPER-SENIOR',
    name: 'SUPER SENIOR',
    attachmentPoint: 0.30,
    detachmentPoint: 1.00,
    thickness: 0.70,
    notional: 7000000000, // £7.0bn
    couponBps: 28,
    rating: 'AAA',
    paymentPriority: 1,
    expectedLossPct: 0.0012,
    attachmentProbability: 0.0035,
    detachmentProbability: 0.0001,
    currentLossPct: 0.0,
    lossAmount: 0,
    remainingNotional: 7000000000,
    presentValue: 7000000000 * 0.998,
    irr: 0.048,
    cs01: 312000,
    correlationDelta: 420000,
  },
  {
    id: 'TR-SENIOR',
    name: 'SENIOR',
    attachmentPoint: 0.15,
    detachmentPoint: 0.30,
    thickness: 0.15,
    notional: 1500000000, // £1.5bn
    couponBps: 75,
    rating: 'AA',
    paymentPriority: 2,
    expectedLossPct: 0.0145,
    attachmentProbability: 0.052,
    detachmentProbability: 0.004,
    currentLossPct: 0.0,
    lossAmount: 0,
    remainingNotional: 1500000000,
    presentValue: 1500000000 * 0.988,
    irr: 0.056,
    cs01: 520000,
    correlationDelta: 280000,
  },
  {
    id: 'TR-MEZZANINE',
    name: 'MEZZANINE',
    attachmentPoint: 0.07,
    detachmentPoint: 0.15,
    thickness: 0.08,
    notional: 800000000, // £800m
    couponBps: 240,
    rating: 'BBB+',
    paymentPriority: 3,
    expectedLossPct: 0.085,
    attachmentProbability: 0.342,
    detachmentProbability: 0.052,
    currentLossPct: 0.0,
    lossAmount: 0,
    remainingNotional: 800000000,
    presentValue: 800000000 * 0.945,
    irr: 0.078,
    cs01: 640000,
    correlationDelta: 160000,
  },
  {
    id: 'TR-JUNIOR',
    name: 'JUNIOR',
    attachmentPoint: 0.03,
    detachmentPoint: 0.07,
    thickness: 0.04,
    notional: 400000000, // £400m
    couponBps: 580,
    rating: 'BB',
    paymentPriority: 4,
    expectedLossPct: 0.384,
    attachmentProbability: 0.725,
    detachmentProbability: 0.342,
    currentLossPct: 0.0,
    lossAmount: 0,
    remainingNotional: 400000000,
    presentValue: 400000000 * 0.812,
    irr: 0.114,
    cs01: 290000,
    correlationDelta: -95000,
  },
  {
    id: 'TR-EQUITY',
    name: 'EQUITY',
    attachmentPoint: 0.00,
    detachmentPoint: 0.03,
    thickness: 0.03,
    notional: 300000000, // £300m
    couponBps: 1450,
    upfrontFeePct: 38.0,
    rating: 'NR',
    paymentPriority: 5,
    expectedLossPct: 0.892,
    attachmentProbability: 0.998,
    detachmentProbability: 0.725,
    currentLossPct: 0.0,
    lossAmount: 0,
    remainingNotional: 300000000,
    presentValue: 300000000 * 0.420,
    irr: 0.198,
    cs01: 62000,
    correlationDelta: -310000,
  },
];
