/**
 * RHINO SYNTHETIC PRODUCTS (RSP)
 * RHINO BANK — INSTITUTIONAL SYNTHETIC DERIVATIVES WORKSTATION
 * Engineer the Exposure. Price the Risk. Trade the Synthetic.
 */

import React, { useState } from 'react';
import { Header } from './components/Header';
import { Navigation, NavigationTab } from './components/Navigation';
import { FlagshipCdoLab } from './components/FlagshipCdoLab';
import { ProductComposer } from './components/ProductComposer';
import { WaterfallDefaultSimulator } from './components/WaterfallDefaultSimulator';
import { DerivativesLibraryView } from './components/DerivativesLibraryView';
import { CorrelationVolView } from './components/CorrelationVolView';
import { RiskScenariosView } from './components/RiskScenariosView';
import { MarginCollateralView } from './components/MarginCollateralView';
import { CounterpartiesView } from './components/CounterpartiesView';
import { TradingBlotterView } from './components/TradingBlotterView';
import { PnlLedgerView } from './components/PnlLedgerView';
import { ModelGovernanceView } from './components/ModelGovernanceView';
import { QuantAssistantView } from './components/QuantAssistantView';
import { SyntheticFinancialProduct, TrancheDefinition } from './types/product';
import { TradeBlotterEntry } from './types/trading';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavigationTab>('CDO_LAB');

  // Top Bar Executive Portfolio Telemetry
  const [portfolioNav, setPortfolioNav] = useState<number>(10000000000); // £10.0bn
  const [totalMtm, setTotalMtm] = useState<number>(9841000000); // £9.84bn
  const [dailyPnl, setDailyPnl] = useState<number>(12800000); // +£12.8m
  const [cs01, setCs01] = useState<number>(1820000); // £1.82m
  const [corrDelta, setCorrDelta] = useState<number>(940000); // £0.94m
  const [initialMargin, setInitialMargin] = useState<number>(42800000); // £42.8m
  const [variationMargin, setVariationMargin] = useState<number>(11200000); // £11.2m
  const [availableCollateral, setAvailableCollateral] = useState<number>(71400000); // £71.4m

  // Context passing for explainability
  const [explainTrancheName, setExplainTrancheName] = useState<string>('MEZZANINE');

  const handleSelectTrancheForExplanation = (trancheName: string) => {
    setExplainTrancheName(trancheName);
    setActiveTab('WATERFALL_SIM');
  };

  const handleTradeTranche = (tranche: TrancheDefinition, side: 'BUY' | 'SELL') => {
    setActiveTab('TRADING_RFQ');
  };

  const handleIssueProduct = (product: SyntheticFinancialProduct) => {
    setActiveTab('TRADING_RFQ');
  };

  return (
    <div className="min-h-screen bg-[#080b10] text-[#d1d5db] flex flex-col font-mono text-xs selection:bg-amber-500/30 selection:text-amber-200">
      {/* Institutional Top Bar */}
      <Header
        portfolioNav={portfolioNav}
        totalMtm={totalMtm}
        dailyPnl={dailyPnl}
        cs01={cs01}
        corrDelta={corrDelta}
        initialMargin={initialMargin}
        variationMargin={variationMargin}
        availableCollateral={availableCollateral}
        activeTab={activeTab}
        setActiveTab={(t) => setActiveTab(t as NavigationTab)}
      />

      {/* Main Tab Navigation Strip */}
      <Navigation activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Main View Area */}
      <main className="flex-1 overflow-x-hidden">
        {activeTab === 'CDO_LAB' && (
          <FlagshipCdoLab
            onSelectTrancheForExplanation={handleSelectTrancheForExplanation}
            onTradeTranche={handleTradeTranche}
          />
        )}

        {activeTab === 'COMPOSER' && (
          <ProductComposer onIssueProduct={handleIssueProduct} />
        )}

        {activeTab === 'WATERFALL_SIM' && (
          <WaterfallDefaultSimulator initialExplainTranche={explainTrancheName} />
        )}

        {activeTab === 'LIBRARY' && (
          <DerivativesLibraryView />
        )}

        {activeTab === 'CORR_VOL' && (
          <CorrelationVolView />
        )}

        {activeTab === 'RISK_SCENARIOS' && (
          <RiskScenariosView />
        )}

        {activeTab === 'MARGIN_COLLATERAL' && (
          <MarginCollateralView />
        )}

        {activeTab === 'COUNTERPARTIES' && (
          <CounterpartiesView />
        )}

        {activeTab === 'TRADING_RFQ' && (
          <TradingBlotterView />
        )}

        {activeTab === 'PNL_LEDGER' && (
          <PnlLedgerView />
        )}

        {activeTab === 'GOVERNANCE' && (
          <ModelGovernanceView />
        )}

        {activeTab === 'QUANT_AI' && (
          <QuantAssistantView />
        )}
      </main>

      {/* Institutional Footer Disclaimer & System Telemetry Strip */}
      <footer className="border-t border-[#1f2937] bg-[#090d14] px-3 py-1.5 flex flex-wrap items-center justify-between text-[10px] text-gray-400 font-mono">
        <div className="flex items-center space-x-3">
          <span className="text-amber-500 font-bold">RHINO BANK PLC</span>
          <span className="text-gray-600">|</span>
          <span>VENUE: <strong className="text-gray-300">CANARY WHARF SIMULATED RESEARCH FACILITY</strong></span>
          <span className="text-gray-600">|</span>
          <span>CALCULATION PROVENANCE: <strong className="text-cyan-400">0x8F4A9E21BC7891D0</strong></span>
        </div>

        <div className="flex items-center space-x-3 text-gray-500">
          <span>NOT AN OFFER OF SECURITIES • RESEARCH & SIMULATION WORKSTATION ONLY</span>
          <span className="text-gray-600">|</span>
          <span className="text-emerald-400 font-bold">SYSTEM ENGINE: ONLINE</span>
        </div>
      </footer>
    </div>
  );
}
