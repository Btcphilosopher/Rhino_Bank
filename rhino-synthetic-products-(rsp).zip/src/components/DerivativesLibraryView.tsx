/**
 * RHINO SYNTHETIC PRODUCTS
 * Institutional Derivative Product Library
 * Catalog of structured synthetics across Equity, Rates, FX, Commodities, Credit & Cross-Asset Hybrids
 */

import React, { useState } from 'react';
import {
  BookOpen,
  Search,
  Filter,
  ArrowUpRight,
  TrendingUp,
  Shield,
  Layers,
  Zap,
  CheckCircle,
  FileCode
} from 'lucide-react';
import { SYNTHETIC_PRODUCT_LIBRARY } from '../data/productLibrary';
import { SyntheticFinancialProduct, AssetClass } from '../types/product';

interface DerivativesLibraryProps {
  onSelectProduct?: (product: SyntheticFinancialProduct) => void;
}

export const DerivativesLibraryView: React.FC<DerivativesLibraryProps> = ({ onSelectProduct }) => {
  const [selectedAssetClass, setSelectedAssetClass] = useState<AssetClass | 'ALL'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeProduct, setActiveProduct] = useState<SyntheticFinancialProduct>(SYNTHETIC_PRODUCT_LIBRARY[0]);

  const filteredProducts = SYNTHETIC_PRODUCT_LIBRARY.filter(p => {
    const matchesCategory = selectedAssetClass === 'ALL' || p.assetClass === selectedAssetClass;
    const matchesSearch =
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.productType.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const formatGBP = (val: number) => {
    if (Math.abs(val) >= 1e9) return `£${(val / 1e9).toFixed(2)}bn`;
    if (Math.abs(val) >= 1e6) return `£${(val / 1e6).toFixed(1)}m`;
    if (Math.abs(val) >= 1e3) return `£${(val / 1e3).toFixed(0)}k`;
    return `£${val.toFixed(0)}`;
  };

  return (
    <div className="p-3 space-y-3 bg-[#0b0e14] text-gray-200 font-mono text-xs select-none">
      {/* Header & Filter Controls */}
      <div className="bg-[#111827] border border-[#1f2937] p-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="bg-amber-500/10 border border-amber-500/40 p-2 text-amber-400">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-sm font-bold text-gray-100 tracking-wider">
              SYNTHETIC DERIVATIVE PRODUCT LIBRARY
            </h1>
            <p className="text-[11px] text-gray-400 font-sans">
              Comprehensive institutional catalog of pre-modeled synthetic payoffs and structured notes.
            </p>
          </div>
        </div>

        {/* Search & Asset Class Filter Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-gray-400 absolute left-2 top-2" />
            <input
              type="text"
              placeholder="Search library..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="bg-[#0c121d] border border-[#1e293b] pl-7 pr-2 py-1 text-xs text-gray-200 focus:border-amber-500 focus:outline-none w-44"
            />
          </div>

          <div className="flex items-center space-x-1 bg-[#0c121d] border border-[#1e293b] p-0.5">
            {['ALL', 'CREDIT', 'RATES', 'EQUITY', 'FX', 'COMMODITIES', 'HYBRID'].map(cls => (
              <button
                key={cls}
                onClick={() => setSelectedAssetClass(cls as any)}
                className={`px-2 py-1 text-[10px] font-bold border transition ${
                  selectedAssetClass === cls
                    ? 'border-amber-500 bg-amber-950/80 text-amber-300'
                    : 'border-transparent text-gray-400 hover:text-gray-200'
                }`}
              >
                {cls}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Grid: Left Product List / Right Detailed Digital Twin & Valuation */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3">
        {/* Left Column (5 cols): Product Cards */}
        <div className="lg:col-span-5 space-y-2 max-h-[620px] overflow-y-auto">
          {filteredProducts.map(prod => {
            const isSelected = activeProduct.productId === prod.productId;
            return (
              <div
                key={prod.productId}
                onClick={() => setActiveProduct(prod)}
                className={`p-3 border transition-all cursor-pointer ${
                  isSelected
                    ? 'border-amber-500 bg-[#162030]'
                    : 'border-[#1e293b] bg-[#111827] hover:border-gray-600'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-gray-400 text-[10px] font-bold tracking-wider">{prod.productId}</span>
                  <span className="text-[9px] px-1.5 py-0.2 bg-amber-950 text-amber-400 border border-amber-800">
                    {prod.assetClass}
                  </span>
                </div>

                <div className="font-bold text-gray-100 text-xs mt-1">{prod.name}</div>
                <div className="text-[10px] text-gray-400 mt-0.5 font-sans">
                  Issuer: {prod.issuer} • Notional: {formatGBP(prod.notional)}
                </div>

                <div className="grid grid-cols-3 gap-2 text-[10px] mt-2 border-t border-[#1e293b] pt-1.5 text-gray-300">
                  <div>Price: <strong className="text-cyan-300">{prod.pricing.midPrice}%</strong></div>
                  <div>CS01: <strong className="text-amber-400">{formatGBP(prod.risk.cs01)}</strong></div>
                  <div className="text-right">IM: <strong className="text-emerald-400">{formatGBP(prod.margin.initialMargin)}</strong></div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right Column (7 cols): Selected Product Digital Twin & Risk Deck */}
        <div className="lg:col-span-7 space-y-3">
          <div className="bg-[#111827] border border-[#1f2937] p-3 space-y-3">
            <div className="flex items-center justify-between border-b border-[#1f2937] pb-2">
              <div>
                <span className="text-[10px] text-gray-400 font-bold">{activeProduct.productId} (VERSION {activeProduct.version})</span>
                <h2 className="text-sm font-bold text-amber-400">{activeProduct.name}</h2>
              </div>
              <button
                onClick={() => onSelectProduct?.(activeProduct)}
                className="flex items-center space-x-1 px-3 py-1 bg-amber-600 hover:bg-amber-500 text-black font-bold text-xs transition"
              >
                <span>LOAD INTO WORKSTATION</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Economic & Legal Specifications */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
              <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
                <div className="text-gray-400 text-[9px]">TOTAL NOTIONAL</div>
                <div className="font-bold text-gray-100">{formatGBP(activeProduct.notional)}</div>
              </div>
              <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
                <div className="text-gray-400 text-[9px]">MATURITY</div>
                <div className="font-bold text-gray-100">{activeProduct.maturityYears} Years ({activeProduct.maturityDate})</div>
              </div>
              <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
                <div className="text-gray-400 text-[9px]">LEGAL TEMPLATE</div>
                <div className="font-bold text-indigo-300">{activeProduct.legalStatus}</div>
              </div>
              <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
                <div className="text-gray-400 text-[9px]">LIFECYCLE STATE</div>
                <div className="font-bold text-emerald-400">{activeProduct.lifecycleState}</div>
              </div>
            </div>

            {/* Valuation Model & Assumptions */}
            <div className="p-2.5 bg-[#0c121d] border border-[#1e293b] space-y-1.5 text-[11px]">
              <div className="flex items-center justify-between text-xs font-bold text-gray-200">
                <span>VALUATION ENGINE & CALIBRATION</span>
                <span className="text-emerald-400 text-[10px] font-bold">VALIDATED {activeProduct.valuationModel.validationStatus}</span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-[10px] text-gray-400">
                <div>Primary Model: <strong className="text-gray-200">{activeProduct.valuationModel.modelName}</strong></div>
                <div>Challenger Engine: <strong className="text-gray-200">{activeProduct.valuationModel.challengerEngine}</strong></div>
                <div>Calibration Date: <strong className="text-gray-200">{activeProduct.valuationModel.calibrationDate}</strong></div>
                <div>Data Snapshot: <strong className="text-cyan-300">{activeProduct.valuationModel.marketDataSnapshot}</strong></div>
              </div>
            </div>

            {/* Greeks & Risk Sensitivities Deck */}
            <div className="space-y-1.5">
              <div className="text-xs font-bold text-gray-300">GREEKS & SENSITIVITY PROFILE</div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[10px]">
                <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
                  <span className="text-gray-400">CS01 (1bp spread):</span>
                  <div className="font-bold text-amber-400">{formatGBP(activeProduct.risk.cs01)}</div>
                </div>
                <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
                  <span className="text-gray-400">DV01 (1bp rate):</span>
                  <div className="font-bold text-gray-200">{formatGBP(activeProduct.risk.dv01)}</div>
                </div>
                <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
                  <span className="text-gray-400">Correlation Delta (1%):</span>
                  <div className="font-bold text-indigo-300">{formatGBP(activeProduct.risk.correlationDelta)}</div>
                </div>
                <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
                  <span className="text-gray-400">1-Day VaR (99%):</span>
                  <div className="font-bold text-rose-400">{formatGBP(activeProduct.risk.var99)}</div>
                </div>
              </div>
            </div>

            {/* Digital Twin Provenance Audit */}
            <div className="p-2 bg-[#080d14] border border-[#162030] text-[9px] text-gray-400 flex justify-between">
              <span>CALCULATION PROVENANCE: <strong>{activeProduct.provenance.calculationId}</strong></span>
              <span>DIGITAL TWIN HASH: <strong className="text-amber-400 font-mono">{activeProduct.provenance.hash}</strong></span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
