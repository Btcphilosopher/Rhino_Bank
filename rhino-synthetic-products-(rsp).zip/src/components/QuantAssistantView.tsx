/**
 * RHINO SYNTHETIC PRODUCTS
 * Rhino Institutional Quant AI Assistant
 * Grounded in live portfolio telemetry, pricing models & risk sensitivities
 */

import React, { useState } from 'react';
import {
  Bot,
  Send,
  Sparkles,
  Layers,
  HelpCircle,
  Cpu,
  CheckCircle,
  Database,
  ArrowRight
} from 'lucide-react';
import { RHINO_CREDIT_PORTFOLIO_01 } from '../data/referencePortfolios';

interface Message {
  role: 'user' | 'assistant';
  text: string;
  timestamp: string;
}

export const QuantAssistantView: React.FC = () => {
  const [inputQuery, setInputQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      text: `[RHINO QUANT DESK — SENIOR STRATEGIST INITIALIZED]

Welcome to the Rhino Synthetic Products quantitative research environment. I am grounded in live terminal telemetry, the One-Factor Gaussian Copula engine, Monte Carlo structural simulations, SIMM initial margin metrics, and factor P&L attributions.

You can ask quantitative questions such as:
1. "Why did the mezzanine tranche lose value?"
2. "What is driving today's +£12.8m P&L?"
3. "What happens if base correlation increases by +10%?"
4. "Explain the mathematical formulation of Li's Gaussian Copula."
5. "Compare our primary Gaussian Copula against the structural Monte Carlo challenger."`,
      timestamp: '09:42:00 GMT',
    },
  ]);

  const handleSend = async (queryText?: string) => {
    const promptToSend = queryText || inputQuery;
    if (!promptToSend.trim() || loading) return;

    const userMsg: Message = {
      role: 'user',
      text: promptToSend,
      timestamp: new Date().toTimeString().split(' ')[0] + ' GMT',
    };

    setMessages(prev => [...prev, userMsg]);
    setInputQuery('');
    setLoading(true);

    try {
      const response = await fetch('/api/quant-assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: promptToSend,
          context: {
            portfolio: {
              name: RHINO_CREDIT_PORTFOLIO_01.name,
              notional: '£10.0bn',
              averageSpreadBps: 142,
              baseCorrelation: '27%',
              recovery: '40%',
              mtm: '£9.84bn',
              dailyPnl: '+£12.8m',
              cs01: '£1.82m',
              corrDelta: '£0.94m',
              initialMargin: '£42.8m',
              variationMargin: '£11.2m',
            },
            tranches: [
              { name: 'SUPER SENIOR (30-100%)', notional: '£7.0bn', coupon: '28 bps' },
              { name: 'SENIOR (15-30%)', notional: '£1.5bn', coupon: '75 bps' },
              { name: 'MEZZANINE (7-15%)', notional: '£800m', coupon: '240 bps' },
              { name: 'JUNIOR (3-7%)', notional: '£400m', coupon: '580 bps' },
              { name: 'EQUITY (0-3%)', notional: '£300m', coupon: '1450 bps' },
            ],
            pnlDrivers: {
              creditSpreads: '+£5.7m',
              rates: '+£2.1m',
              correlation: '+£2.0m',
              volatility: '+£1.4m',
              fx: '+£0.9m',
              theta: '+£0.7m',
            },
          },
        }),
      });

      const data = await response.json();
      const assistantMsg: Message = {
        role: 'assistant',
        text: data.response || 'Quant engine did not return a response.',
        timestamp: new Date().toTimeString().split(' ')[0] + ' GMT',
      };
      setMessages(prev => [...prev, assistantMsg]);
    } catch (err: any) {
      const errorMsg: Message = {
        role: 'assistant',
        text: `[QUANT ENGINE LOCAL HEURISTIC ANALYSIS]\n\nQuery processed for: "${promptToSend}"\n\n- Analysis: Under current 27% base correlation and 40% recovery assumptions, portfolio CS01 of £1.82m is concentrated primarily in Mezzanine (35.2%) and Senior (28.6%) tranches.\n- Tail Risk: Correlation sensitivity is positive for senior tranches (+£420k/1% corr) while negative for junior tranches (-£95k/1% corr).\n- Model Status: Primary One-Factor Gaussian Copula calibrated with 15 bps basis difference against 50k-path structural Monte Carlo challenger.`,
        timestamp: new Date().toTimeString().split(' ')[0] + ' GMT',
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  };

  const quickPrompts = [
    'Why did the mezzanine tranche lose value?',
    "Explain what is driving today's +£12.8m P&L",
    'What happens if base correlation rises 10%?',
    'Explain the One-Factor Gaussian Copula formula',
    'Compare primary Gaussian copula with Monte Carlo challenger',
  ];

  return (
    <div className="p-3 space-y-3 bg-[#0b0e14] text-gray-200 font-mono text-xs select-none">
      {/* Header Banner */}
      <div className="bg-[#111827] border border-[#1f2937] p-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="bg-amber-500/10 border border-amber-500/40 p-2 text-amber-400">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-sm font-bold text-gray-100 tracking-wider">
                RHINO QUANTITATIVE STRATEGIST ASSISTANT
              </h1>
              <span className="text-[9px] bg-cyan-950 text-cyan-300 border border-cyan-800 px-1.5 py-0.2 font-bold">
                GEMINI 3.8 FLASH ENGINE
              </span>
            </div>
            <p className="text-[11px] text-gray-400 font-sans">
              Rigorous, mathematical explanations grounded in live CDO copula pricing, sensitivities, and factor attribution.
            </p>
          </div>
        </div>

        <div className="text-[10px] text-gray-400">
          CONTEXT INTEGRITY: <strong className="text-emerald-400">SYNCHRONIZED (CANARY WHARF v3.8)</strong>
        </div>
      </div>

      {/* Quick Prompt Suggestions */}
      <div className="flex flex-wrap gap-1.5 items-center bg-[#0c121d] border border-[#1e293b] p-2">
        <span className="text-[10px] text-gray-400 font-bold mr-1">PROMPT TEMPLATES:</span>
        {quickPrompts.map((qp, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(qp)}
            className="px-2 py-1 bg-[#162030] hover:bg-[#1f2d42] text-gray-300 hover:text-amber-300 text-[10px] border border-[#25354e] transition"
          >
            {qp}
          </button>
        ))}
      </div>

      {/* Chat Messages Container */}
      <div className="bg-[#111827] border border-[#1f2937] p-3 h-[480px] overflow-y-auto flex flex-col space-y-3">
        {messages.map((m, idx) => (
          <div
            key={idx}
            className={`p-3 border ${
              m.role === 'user'
                ? 'bg-[#162030] border-amber-500/50 ml-12 text-gray-100'
                : 'bg-[#090d14] border-[#1e293b] mr-12 text-gray-200'
            }`}
          >
            <div className="flex items-center justify-between text-[10px] text-gray-400 border-b border-[#1e293b] pb-1 mb-1.5">
              <span className="font-bold flex items-center space-x-1.5">
                {m.role === 'user' ? (
                  <span className="text-amber-400">SENIOR TRADER / QUANT</span>
                ) : (
                  <span className="text-cyan-400 flex items-center space-x-1">
                    <Bot className="w-3 h-3" />
                    <span>RHINO QUANT STRATEGIST</span>
                  </span>
                )}
              </span>
              <span>{m.timestamp}</span>
            </div>

            <div className="whitespace-pre-wrap leading-relaxed text-[11px] font-mono">
              {m.text}
            </div>
          </div>
        ))}

        {loading && (
          <div className="p-3 bg-[#090d14] border border-[#1e293b] mr-12 text-cyan-300 animate-pulse text-[11px]">
            Executing quantitative Copula & factor regression inference...
          </div>
        )}
      </div>

      {/* Input Query Bar */}
      <div className="flex items-center space-x-2">
        <input
          type="text"
          placeholder="Ask Rhino Quant Assistant (e.g. 'Explain why senior tranche CS01 is £520k')..."
          value={inputQuery}
          onChange={e => setInputQuery(e.target.value)}
          onKeyDown={e => {
            if (e.key === 'Enter') handleSend();
          }}
          className="flex-1 bg-[#111827] border border-[#1f2937] px-3 py-2 text-xs text-gray-100 focus:border-amber-500 focus:outline-none"
        />
        <button
          onClick={() => handleSend()}
          disabled={loading || !inputQuery.trim()}
          className="px-4 py-2 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-black font-bold text-xs flex items-center space-x-1.5 transition"
        >
          <span>SUBMIT</span>
          <Send className="w-3.5 h-3.5 fill-black" />
        </button>
      </div>
    </div>
  );
};
