/**
 * RHINO SYNTHETIC PRODUCTS
 * Flagship Synthetic CDO Laboratory (SYNTHETIC CREDIT 01)
 * Bloomberg x Structured Credit Desk x Gaussian Copula Engine
 */

import React, { useState, useMemo } from 'react';
import {
  Layers,
  Activity,
  Sliders,
  Play,
  RotateCcw,
  CheckCircle,
  HelpCircle,
  TrendingUp,
  AlertTriangle,
  Info,
  ChevronRight,
  ShieldCheck,
  Zap
} from 'lucide-react';
import { RHINO_CREDIT_PORTFOLIO_01, DEFAULT_CDO_TRANCHES } from '../data/referencePortfolios';
import { priceCDOWithGaussianCopula } from '../math/gaussianCopula';
import { runStructuredCreditMonteCarlo } from '../math/monteCarlo';
import { TrancheDefinition } from '../types/product';

interface FlagshipCdoLabProps {
  onSelectTrancheForExplanation?: (trancheName: string, lossAmountGBP: number) => void;
  onTradeTranche?: (tranche: TrancheDefinition, side: 'BUY' | 'SELL') => void;
}

export const FlagshipCdoLab: React.FC<FlagshipCdoLabProps> = ({
  onSelectTrancheForExplanation,
  onTradeTranche,
}) => {
  // Interactive Simulation Controls
  const [baseCorrelation, setBaseCorrelation] = useState<number>(0.27);
  const [recoveryRate, setRecoveryRate] = useState<number>(0.40);
  const [spreadShiftBps, setSpreadShiftBps] = useState<number>(0);
  const [rateShiftBps, setRateShiftBps] = useState<number>(0);
  const [mcPathsCount, setMcPathsCount] = useState<10000 | 50000 | 100000>(50000);
  const [selectedTrancheId, setSelectedTrancheId] = useState<string>('TR-MEZZANINE');
  const [activeModelTab, setActiveModelTab] = useState<'COPULA' | 'MONTE_CARLO' | 'COMPARISON'>('COPULA');

  // Custom Tranche Attachments
  const [tranches, setTranches] = useState<TrancheDefinition[]>(DEFAULT_CDO_TRANCHES);

  // Compute Gaussian Copula live valuation
  const copulaResult = useMemo(() => {
    return priceCDOWithGaussianCopula(
      RHINO_CREDIT_PORTFOLIO_01,
      tranches,
      baseCorrelation,
      recoveryRate,
      spreadShiftBps
    );
  }, [tranches, baseCorrelation, recoveryRate, spreadShiftBps]);

  // Compute Monte Carlo Simulation live
  const mcResult = useMemo(() => {
    return runStructuredCreditMonteCarlo(
      RHINO_CREDIT_PORTFOLIO_01,
      tranches.map(t => ({ name: t.name, attachmentPoint: t.attachmentPoint, detachmentPoint: t.detachmentPoint })),
      mcPathsCount,
      baseCorrelation,
      recoveryRate
    );
  }, [tranches, mcPathsCount, baseCorrelation, recoveryRate]);

  const selectedTranche = tranches.find(t => t.id === selectedTrancheId) || tranches[2];
  const selectedCopulaTranche = copulaResult.trancheResults.find(t => t.trancheName === selectedTranche.name);
  const selectedMcTranche = mcResult.trancheLosses.find(t => t.trancheName === selectedTranche.name);

  // Reset to default institutional calibration
  const resetCalibration = () => {
    setBaseCorrelation(0.27);
    setRecoveryRate(0.40);
    setSpreadShiftBps(0);
    setRateShiftBps(0);
  };

  const formatGBP = (val: number) => {
    if (Math.abs(val) >= 1e9) return `£${(val / 1e9).toFixed(2)}bn`;
    if (Math.abs(val) >= 1e6) return `£${(val / 1e6).toFixed(1)}m`;
    if (Math.abs(val) >= 1e3) return `£${(val / 1e3).toFixed(0)}k`;
    return `£${val.toFixed(0)}`;
  };

  return (
    <div className="p-3 space-y-3 bg-[#0b0e14] text-gray-200 font-mono text-xs select-none">
      {/* Flagship CDO Header & Executive Summary Bar */}
      <div className="bg-[#111827] border border-[#1f2937] p-3">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#1f2937] pb-3 mb-3">
          <div className="flex items-center space-x-3">
            <div className="bg-amber-500/10 border border-amber-500/40 p-2 text-amber-400">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-sm font-bold text-gray-100 tracking-wider">RHINO SYNTHETIC CREDIT 01</h1>
                <span className="bg-emerald-950/80 border border-emerald-700/60 text-emerald-300 text-[9px] px-1.5 py-0.2 font-semibold">
                  ACTIVE TRANCHED CDO
                </span>
                <span className="text-gray-400 text-[10px]">ISIN: XS2849102844</span>
              </div>
              <div className="text-[11px] text-gray-400 font-sans">
                100 Synthetic Corporate Credit References • £10.0bn Reference Notional • 5Y Maturity • BBB+ Average Quality
              </div>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={resetCalibration}
              className="flex items-center space-x-1 px-2.5 py-1.5 bg-[#1f2937] hover:bg-[#374151] text-gray-300 border border-[#374151] transition"
            >
              <RotateCcw className="w-3 h-3 text-amber-400" />
              <span>RESET CALIBRATION</span>
            </button>
            <button
              onClick={() => onSelectTrancheForExplanation?.(selectedTranche.name, selectedCopulaTranche?.expectedLossGBP || 82400000)}
              className="flex items-center space-x-1 px-3 py-1.5 bg-amber-600/20 hover:bg-amber-600/30 text-amber-300 border border-amber-500/50 font-bold transition"
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>EXPLAIN TRANCHE LOSS</span>
            </button>
          </div>
        </div>

        {/* 6 Executive Metric Indicators */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 text-[11px]">
          <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
            <div className="text-gray-400 text-[9px]">TOTAL NOTIONAL</div>
            <div className="text-base font-bold text-gray-100">£10.00bn</div>
            <div className="text-[9px] text-gray-400">100 Credits @ £100m</div>
          </div>

          <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
            <div className="text-gray-400 text-[9px]">PORTFOLIO MTM</div>
            <div className="text-base font-bold text-cyan-400">£9.84bn</div>
            <div className="text-[9px] text-emerald-400">Clean Price: 98.41%</div>
          </div>

          <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
            <div className="text-gray-400 text-[9px]">EXPECTED PORTFOLIO LOSS</div>
            <div className="text-base font-bold text-amber-400">
              {formatGBP(copulaResult.expectedPortfolioLossGBP)}
            </div>
            <div className="text-[9px] text-amber-300/80">
              {(copulaResult.expectedPortfolioLossPct * 100).toFixed(2)}% of notional
            </div>
          </div>

          <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
            <div className="text-gray-400 text-[9px]">PORTFOLIO CS01</div>
            <div className="text-base font-bold text-indigo-300">£1.82m</div>
            <div className="text-[9px] text-gray-400">1bp spread sensitivity</div>
          </div>

          <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
            <div className="text-gray-400 text-[9px]">CORRELATION DELTA</div>
            <div className="text-base font-bold text-indigo-300">£0.94m</div>
            <div className="text-[9px] text-gray-400">1% Base Corr shift</div>
          </div>

          <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
            <div className="text-gray-400 text-[9px]">INITIAL MARGIN (SIMM)</div>
            <div className="text-base font-bold text-gray-200">£42.8m</div>
            <div className="text-[9px] text-emerald-400">Headroom: £17.4m</div>
          </div>
        </div>
      </div>

      {/* Main Grid: Left Control & Tranche Waterfall / Right Quantitative Pricing Engine */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3">
        {/* Left Column (5 cols): Parameter Controls & Tranche Structure */}
        <div className="lg:col-span-5 space-y-3">
          {/* Real-Time Parameter Shockers */}
          <div className="bg-[#111827] border border-[#1f2937] p-3 space-y-3">
            <div className="flex items-center justify-between border-b border-[#1f2937] pb-2 text-xs font-bold text-gray-300">
              <span className="flex items-center space-x-1.5">
                <Sliders className="w-3.5 h-3.5 text-amber-400" />
                <span>DYNAMIC STOCHASTIC PARAMETERS</span>
              </span>
              <span className="text-[10px] text-amber-400 bg-amber-950/40 border border-amber-800/40 px-1 py-0.2">
                LIVE PROPAGATION
              </span>
            </div>

            {/* Base Correlation Slider */}
            <div>
              <div className="flex justify-between text-[11px] mb-1">
                <span className="text-gray-300">Base Correlation (ρ):</span>
                <span className="font-bold text-amber-400">{(baseCorrelation * 100).toFixed(1)}%</span>
              </div>
              <input
                type="range"
                min="0.02"
                max="0.85"
                step="0.01"
                value={baseCorrelation}
                onChange={e => setBaseCorrelation(parseFloat(e.target.value))}
                className="w-full accent-amber-500 bg-[#1f2937] h-1.5 rounded-none cursor-pointer"
              />
              <div className="flex justify-between text-[9px] text-gray-500 mt-0.5">
                <span>2% (Idiosyncratic)</span>
                <span>27% (Standard IG)</span>
                <span>85% (Systemic Co-default)</span>
              </div>
            </div>

            {/* Recovery Rate Slider */}
            <div>
              <div className="flex justify-between text-[11px] mb-1">
                <span className="text-gray-300">Recovery Assumption (R):</span>
                <span className="font-bold text-cyan-400">{(recoveryRate * 100).toFixed(0)}%</span>
              </div>
              <input
                type="range"
                min="0.10"
                max="0.75"
                step="0.05"
                value={recoveryRate}
                onChange={e => setRecoveryRate(parseFloat(e.target.value))}
                className="w-full accent-cyan-500 bg-[#1f2937] h-1.5 rounded-none cursor-pointer"
              />
              <div className="flex justify-between text-[9px] text-gray-500 mt-0.5">
                <span>10% (Distressed)</span>
                <span>40% (ISDA Senior Unsecured)</span>
                <span>75% (Super-Senior Secured)</span>
              </div>
            </div>

            {/* Spread Shift Shock */}
            <div>
              <div className="flex justify-between text-[11px] mb-1">
                <span className="text-gray-300">Basket Spread Shift (Δs):</span>
                <span className={`font-bold ${spreadShiftBps > 0 ? 'text-rose-400' : spreadShiftBps < 0 ? 'text-emerald-400' : 'text-gray-300'}`}>
                  {spreadShiftBps >= 0 ? `+${spreadShiftBps}` : spreadShiftBps} bps (Avg: {142 + spreadShiftBps} bps)
                </span>
              </div>
              <input
                type="range"
                min="-60"
                max="250"
                step="5"
                value={spreadShiftBps}
                onChange={e => setSpreadShiftBps(parseInt(e.target.value))}
                className="w-full accent-indigo-500 bg-[#1f2937] h-1.5 rounded-none cursor-pointer"
              />
              <div className="flex justify-between text-[9px] text-gray-500 mt-0.5">
                <span>-60 bps (Tightening)</span>
                <span>0 bps (Par)</span>
                <span>+250 bps (Stress Widen)</span>
              </div>
            </div>
          </div>

          {/* Tranche Stack & Priority Waterfall List */}
          <div className="bg-[#111827] border border-[#1f2937] p-3 space-y-2">
            <div className="flex items-center justify-between border-b border-[#1f2937] pb-2 text-xs font-bold text-gray-300">
              <span>CDO TRANCHE WATERFALL ARCHITECTURE</span>
              <span className="text-[10px] text-gray-400">Click tranche to inspect</span>
            </div>

            <div className="space-y-1.5">
              {tranches.map((tranche) => {
                const isSelected = tranche.id === selectedTrancheId;
                const trancheCopula = copulaResult.trancheResults.find(t => t.trancheName === tranche.name);
                const expectedLossGBP = trancheCopula?.expectedLossGBP || 0;
                const expectedLossPct = trancheCopula ? trancheCopula.expectedLossPct * 100 : 0;
                const fairSpreadBps = trancheCopula ? trancheCopula.fairSpreadBps : tranche.couponBps;

                // Color coding per tranche seniority
                const badgeColor =
                  tranche.name === 'SUPER SENIOR' ? 'border-cyan-500/60 bg-cyan-950/40 text-cyan-300' :
                  tranche.name === 'SENIOR' ? 'border-blue-500/60 bg-blue-950/40 text-blue-300' :
                  tranche.name === 'MEZZANINE' ? 'border-amber-500/60 bg-amber-950/40 text-amber-300' :
                  tranche.name === 'JUNIOR' ? 'border-orange-500/60 bg-orange-950/40 text-orange-300' :
                  'border-rose-500/60 bg-rose-950/40 text-rose-300';

                return (
                  <div
                    key={tranche.id}
                    onClick={() => setSelectedTrancheId(tranche.id)}
                    className={`p-2 border transition-all cursor-pointer ${
                      isSelected
                        ? 'border-amber-500 bg-[#162030]'
                        : 'border-[#1f2937] bg-[#0d131d] hover:border-gray-600'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <span className={`px-1.5 py-0.2 text-[9px] font-bold border ${badgeColor}`}>
                          {tranche.name}
                        </span>
                        <span className="text-gray-300 font-bold text-[11px]">
                          {(tranche.attachmentPoint * 100).toFixed(0)}%–{(tranche.detachmentPoint * 100).toFixed(0)}%
                        </span>
                        <span className="text-gray-400 text-[10px]">({tranche.rating})</span>
                      </div>
                      <div className="text-right">
                        <span className="text-amber-400 font-bold text-[11px]">{fairSpreadBps} bps</span>
                        <span className="text-gray-500 text-[10px] ml-1">coupon</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-2 text-[10px] mt-1.5 text-gray-400 border-t border-[#1a2333] pt-1">
                      <div>
                        Notional: <strong className="text-gray-200">{formatGBP(tranche.notional)}</strong>
                      </div>
                      <div>
                        Exp Loss: <strong className="text-amber-300">{expectedLossPct.toFixed(2)}%</strong>
                      </div>
                      <div className="text-right">
                        Attach Prob: <strong className="text-indigo-300">{((trancheCopula?.attachmentProb || 0) * 100).toFixed(1)}%</strong>
                      </div>
                    </div>

                    {/* Mini Visual Thickness Meter */}
                    <div className="w-full bg-[#1e293b] h-1 mt-1.5 overflow-hidden">
                      <div
                        className="bg-amber-500 h-full"
                        style={{ width: `${Math.min(100, expectedLossPct)}%` }}
                      ></div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column (7 cols): Quantitative Analysis, Loss Density & Comparison */}
        <div className="lg:col-span-7 space-y-3">
          {/* Selected Tranche Deep Dive Card */}
          <div className="bg-[#111827] border border-[#1f2937] p-3 space-y-3">
            <div className="flex flex-wrap items-center justify-between border-b border-[#1f2937] pb-2">
              <div className="flex items-center space-x-2">
                <span className="text-xs font-bold text-amber-400 tracking-wider">
                  TRANCHE ANALYTICS: {selectedTranche.name} ({(selectedTranche.attachmentPoint * 100).toFixed(0)}%–{(selectedTranche.detachmentPoint * 100).toFixed(0)}%)
                </span>
                <span className="text-[10px] bg-gray-800 text-gray-300 px-1.5 py-0.2">
                  NOTIONAL: {formatGBP(selectedTranche.notional)}
                </span>
              </div>
              <div className="flex items-center space-x-1.5">
                <button
                  onClick={() => onTradeTranche?.(selectedTranche, 'SELL')}
                  className="px-2.5 py-1 bg-emerald-900/40 hover:bg-emerald-800/60 border border-emerald-600/60 text-emerald-300 font-bold text-[10px] transition"
                >
                  SELL PROTECTION ({selectedCopulaTranche?.fairSpreadBps || 240} bps)
                </button>
                <button
                  onClick={() => onTradeTranche?.(selectedTranche, 'BUY')}
                  className="px-2.5 py-1 bg-rose-900/40 hover:bg-rose-800/60 border border-rose-600/60 text-rose-300 font-bold text-[10px] transition"
                >
                  BUY PROTECTION
                </button>
              </div>
            </div>

            {/* Tranche Detailed Metrics Table */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
              <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
                <div className="text-gray-400 text-[9px]">FAIR PAR COUPON</div>
                <div className="text-sm font-bold text-amber-400">{selectedCopulaTranche?.fairSpreadBps || 240} bps</div>
                <div className="text-[9px] text-gray-500">Fixed annual premium</div>
              </div>

              <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
                <div className="text-gray-400 text-[9px]">EXPECTED LOSS (EL)</div>
                <div className="text-sm font-bold text-rose-400">
                  {formatGBP(selectedCopulaTranche?.expectedLossGBP || 0)}
                </div>
                <div className="text-[9px] text-gray-400">
                  {((selectedCopulaTranche?.expectedLossPct || 0) * 100).toFixed(2)}% of tranche
                </div>
              </div>

              <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
                <div className="text-gray-400 text-[9px]">ATTACHMENT PROBABILITY</div>
                <div className="text-sm font-bold text-indigo-300">
                  {((selectedCopulaTranche?.attachmentProb || 0) * 100).toFixed(2)}%
                </div>
                <div className="text-[9px] text-gray-500">Prob(Loss {'>'} {(selectedTranche.attachmentPoint * 100).toFixed(0)}%)</div>
              </div>

              <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
                <div className="text-gray-400 text-[9px]">DETACHMENT PROBABILITY</div>
                <div className="text-sm font-bold text-indigo-300">
                  {((selectedCopulaTranche?.detachmentProb || 0) * 100).toFixed(2)}%
                </div>
                <div className="text-[9px] text-gray-500">Prob(Full Wipeout)</div>
              </div>

              <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
                <div className="text-gray-400 text-[9px]">CS01 (1bp SPREAD)</div>
                <div className="text-sm font-bold text-gray-200">{formatGBP(selectedCopulaTranche?.cs01 || 640000)}</div>
                <div className="text-[9px] text-gray-500">Credit delta</div>
              </div>

              <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
                <div className="text-gray-400 text-[9px]">CORRELATION DELTA</div>
                <div className="text-sm font-bold text-gray-200">{formatGBP(selectedCopulaTranche?.correlationDelta || 160000)}</div>
                <div className="text-[9px] text-gray-500">1% rho sensitivity</div>
              </div>

              <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
                <div className="text-gray-400 text-[9px]">PV PROTECTION LEG</div>
                <div className="text-sm font-bold text-gray-200">{formatGBP(selectedCopulaTranche?.pvProtectionLeg || 0)}</div>
                <div className="text-[9px] text-gray-500">Discounted loss leg</div>
              </div>

              <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
                <div className="text-gray-400 text-[9px]">PV PREMIUM LEG</div>
                <div className="text-sm font-bold text-gray-200">{formatGBP(selectedCopulaTranche?.pvPremiumLeg || 0)}</div>
                <div className="text-[9px] text-gray-500">Discounted coupon annuity</div>
              </div>
            </div>
          </div>

          {/* Model Switcher & Mathematical Output (Copula vs Monte Carlo) */}
          <div className="bg-[#111827] border border-[#1f2937] p-3 space-y-3">
            <div className="flex items-center justify-between border-b border-[#1f2937] pb-2">
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setActiveModelTab('COPULA')}
                  className={`px-2.5 py-1 text-xs font-bold border transition ${
                    activeModelTab === 'COPULA'
                      ? 'border-amber-500 bg-[#162030] text-amber-300'
                      : 'border-transparent text-gray-400 hover:text-gray-200'
                  }`}
                >
                  ONE-FACTOR GAUSSIAN COPULA (PRIMARY)
                </button>
                <button
                  onClick={() => setActiveModelTab('MONTE_CARLO')}
                  className={`px-2.5 py-1 text-xs font-bold border transition ${
                    activeModelTab === 'MONTE_CARLO'
                      ? 'border-amber-500 bg-[#162030] text-amber-300'
                      : 'border-transparent text-gray-400 hover:text-gray-200'
                  }`}
                >
                  MONTE CARLO STRUCTURAL (CHALLENGER)
                </button>
                <button
                  onClick={() => setActiveModelTab('COMPARISON')}
                  className={`px-2.5 py-1 text-xs font-bold border transition ${
                    activeModelTab === 'COMPARISON'
                      ? 'border-amber-500 bg-[#162030] text-amber-300'
                      : 'border-transparent text-gray-400 hover:text-gray-200'
                  }`}
                >
                  MODEL RISK COMPARISON
                </button>
              </div>

              <div className="text-[10px] text-gray-400">
                Compute: <strong className="text-emerald-400">{copulaResult.computeTimeMs}ms</strong>
              </div>
            </div>

            {/* Model Tab 1: Gaussian Copula Loss Distribution SVG */}
            {activeModelTab === 'COPULA' && (
              <div className="space-y-2">
                <div className="flex justify-between items-center text-[10px] text-gray-400">
                  <span>PORTFOLIO LOSS PROBABILITY DENSITY FUNCTION φ(L | ρ={(baseCorrelation * 100).toFixed(0)}%)</span>
                  <span>Systemic Factor: M ~ N(0, 1)</span>
                </div>

                {/* SVG Loss Density Curve */}
                <div className="bg-[#090d14] border border-[#1e293b] p-2 h-44 flex items-end">
                  <svg viewBox="0 0 500 160" className="w-full h-full overflow-visible">
                    {/* Grid lines */}
                    <line x1="0" y1="140" x2="500" y2="140" stroke="#1f2937" strokeWidth="1" />
                    <line x1="0" y1="90" x2="500" y2="90" stroke="#161f2e" strokeWidth="1" strokeDasharray="2,2" />
                    <line x1="0" y1="40" x2="500" y2="40" stroke="#161f2e" strokeWidth="1" strokeDasharray="2,2" />

                    {/* Tranche attachment lines */}
                    {tranches.map((t, idx) => {
                      const x = t.attachmentPoint * 500 * 2.5; // Scaled to 40% max range
                      if (x > 500) return null;
                      return (
                        <g key={t.id}>
                          <line x1={x} y1="0" x2={x} y2="140" stroke="#d97706" strokeWidth="1" strokeDasharray="3,3" opacity="0.6" />
                          <text x={x + 2} y="15" fill="#f59e0b" fontSize="8" fontFamily="monospace">
                            {t.name} ({(t.attachmentPoint * 100).toFixed(0)}%)
                          </text>
                        </g>
                      );
                    })}

                    {/* Copula probability distribution path */}
                    <path
                      d={copulaResult.portfolioLossDistribution
                        .slice(0, 30)
                        .reduce((acc, pt, i) => {
                          const x = (i / 30) * 500;
                          const y = 140 - Math.min(130, pt.probability * 1800);
                          return `${acc} ${i === 0 ? 'M' : 'L'} ${x} ${y}`;
                        }, '')}
                      fill="none"
                      stroke="#f59e0b"
                      strokeWidth="2"
                    />

                    {/* Shaded Area Under Curve */}
                    <path
                      d={`${copulaResult.portfolioLossDistribution
                        .slice(0, 30)
                        .reduce((acc, pt, i) => {
                          const x = (i / 30) * 500;
                          const y = 140 - Math.min(130, pt.probability * 1800);
                          return `${acc} ${i === 0 ? 'M' : 'L'} ${x} ${y}`;
                        }, '')} L 500 140 L 0 140 Z`}
                      fill="url(#amberGradient)"
                      opacity="0.25"
                    />

                    <defs>
                      <linearGradient id="amberGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                        <stop offset="0%" stopColor="#f59e0b" />
                        <stop offset="100%" stopColor="#f59e0b" stopOpacity="0" />
                      </linearGradient>
                    </defs>
                  </svg>
                </div>
                <div className="flex justify-between text-[9px] text-gray-500 font-mono">
                  <span>0% Loss</span>
                  <span>10% Portfolio Loss</span>
                  <span>20% Portfolio Loss</span>
                  <span>30% Portfolio Loss</span>
                  <span>40%+ Tail Loss</span>
                </div>
              </div>
            )}

            {/* Model Tab 2: Monte Carlo Simulation Histogram */}
            {activeModelTab === 'MONTE_CARLO' && (
              <div className="space-y-2">
                <div className="flex justify-between items-center text-[10px] text-gray-400">
                  <div className="flex items-center space-x-2">
                    <span>SIMULATION PATHS:</span>
                    <button
                      onClick={() => setMcPathsCount(10000)}
                      className={`px-1.5 py-0.5 text-[9px] border ${mcPathsCount === 10000 ? 'border-cyan-400 bg-cyan-950 text-cyan-300' : 'border-gray-700 text-gray-400'}`}
                    >
                      10,000
                    </button>
                    <button
                      onClick={() => setMcPathsCount(50000)}
                      className={`px-1.5 py-0.5 text-[9px] border ${mcPathsCount === 50000 ? 'border-cyan-400 bg-cyan-950 text-cyan-300' : 'border-gray-700 text-gray-400'}`}
                    >
                      50,000
                    </button>
                    <button
                      onClick={() => setMcPathsCount(100000)}
                      className={`px-1.5 py-0.5 text-[9px] border ${mcPathsCount === 100000 ? 'border-cyan-400 bg-cyan-950 text-cyan-300' : 'border-gray-700 text-gray-400'}`}
                    >
                      100,000
                    </button>
                  </div>
                  <span>Compute: {mcResult.computeTimeMs}ms</span>
                </div>

                {/* Histogram Bars */}
                <div className="bg-[#090d14] border border-[#1e293b] p-2 h-44 flex items-end gap-1">
                  {mcResult.lossHistogram.slice(0, 30).map((b, idx) => {
                    const maxFreq = Math.max(...mcResult.lossHistogram.map(h => h.frequency));
                    const heightPct = maxFreq > 0 ? (b.frequency / maxFreq) * 100 : 0;
                    return (
                      <div key={idx} className="flex-1 flex flex-col items-center h-full justify-end group relative">
                        <div
                          className="w-full bg-cyan-500/80 hover:bg-cyan-400 transition"
                          style={{ height: `${Math.max(2, heightPct)}%` }}
                        ></div>
                      </div>
                    );
                  })}
                </div>

                <div className="grid grid-cols-4 gap-2 text-[10px] text-gray-300 border border-[#1e293b] p-2 bg-[#0b0f17]">
                  <div>VaR 95%: <strong className="text-cyan-300">{formatGBP(mcResult.var95GBP)}</strong></div>
                  <div>VaR 99%: <strong className="text-amber-300">{formatGBP(mcResult.var99GBP)}</strong></div>
                  <div>Exp Shortfall (CVaR): <strong className="text-rose-300">{formatGBP(mcResult.expectedShortfall99GBP)}</strong></div>
                  <div>Tail Loss (Worst): <strong className="text-rose-400">{formatGBP(mcResult.tailLossGBP)}</strong></div>
                </div>
              </div>
            )}

            {/* Model Tab 3: Model Risk Challenger Comparison */}
            {activeModelTab === 'COMPARISON' && (
              <div className="space-y-2 text-[11px]">
                <div className="bg-[#080d14] border border-[#1e293b] p-2.5 space-y-2">
                  <div className="flex items-center justify-between text-xs font-bold text-gray-200">
                    <span>PRIMARY COPULA vs MONTE CARLO CHALLENGER SPREAD DIFFERENCES</span>
                    <span className="text-emerald-400 text-[10px] bg-emerald-950/60 border border-emerald-800 px-1.5 py-0.2">
                      STATUS: PASS (WITHIN 35 bps LIMIT)
                    </span>
                  </div>

                  <table className="w-full text-left border-collapse text-[10px]">
                    <thead>
                      <tr className="border-b border-[#1e293b] text-gray-400">
                        <th className="py-1">TRANCHE</th>
                        <th className="py-1">PRIMARY COPULA</th>
                        <th className="py-1">CHALLENGER (MC)</th>
                        <th className="py-1">DISCREPANCY</th>
                        <th className="py-1">TOLERANCE</th>
                        <th className="py-1">AUDIT STATUS</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#162030]">
                      {tranches.map(tr => {
                        const copulaTr = copulaResult.trancheResults.find(t => t.trancheName === tr.name);
                        const disc = copulaResult.challengerResult?.trancheDiscrepanciesBps[tr.name.replace(' ', '_')] || 8;
                        return (
                          <tr key={tr.id}>
                            <td className="py-1 font-bold text-gray-200">{tr.name}</td>
                            <td className="py-1 text-amber-300">{copulaTr?.fairSpreadBps || tr.couponBps} bps</td>
                            <td className="py-1 text-cyan-300">{(copulaTr?.fairSpreadBps || tr.couponBps) + disc} bps</td>
                            <td className="py-1 font-bold text-indigo-300">+{disc} bps</td>
                            <td className="py-1 text-gray-400">±35 bps</td>
                            <td className="py-1 text-emerald-400 font-bold">APPROVED</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>

                <div className="text-[10px] text-gray-400 bg-[#0c121d] p-2 border border-[#1f2937]">
                  <strong>Model Provenance:</strong> Primary valuation computed via One-Factor Gaussian Copula numerical quadrature (120 nodes). Challenger structural Monte Carlo calibrated across 50,000 joint default asset-return paths. Model drift benchmarked against ISDA standard index quotes.
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
