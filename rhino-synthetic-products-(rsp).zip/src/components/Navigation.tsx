/**
 * RHINO SYNTHETIC PRODUCTS
 * Institutional Workstation Navigation Tabs
 */

import React from 'react';
import {
  Layers,
  Sliders,
  Flame,
  BookOpen,
  PieChart,
  ShieldAlert,
  Coins,
  Building2,
  ListOrdered,
  FileSpreadsheet,
  CheckCircle2,
  Bot
} from 'lucide-react';

export type NavigationTab =
  | 'CDO_LAB'
  | 'COMPOSER'
  | 'WATERFALL_SIM'
  | 'LIBRARY'
  | 'CORR_VOL'
  | 'RISK_SCENARIOS'
  | 'MARGIN_COLLATERAL'
  | 'COUNTERPARTIES'
  | 'TRADING_RFQ'
  | 'PNL_LEDGER'
  | 'GOVERNANCE'
  | 'QUANT_AI';

interface NavigationProps {
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;
}

export const Navigation: React.FC<NavigationProps> = ({ activeTab, setActiveTab }) => {
  const tabs: { id: NavigationTab; label: string; icon: React.ReactNode; badge?: string }[] = [
    { id: 'CDO_LAB', label: 'SYNTHETIC CREDIT 01', icon: <Layers className="w-3.5 h-3.5" />, badge: 'FLAGSHIP' },
    { id: 'COMPOSER', label: 'PRODUCT COMPOSER', icon: <Sliders className="w-3.5 h-3.5" />, badge: 'FACTORY' },
    { id: 'WATERFALL_SIM', label: 'WATERFALL & DEFAULTS', icon: <Flame className="w-3.5 h-3.5" /> },
    { id: 'LIBRARY', label: 'DERIVATIVE LIBRARY', icon: <BookOpen className="w-3.5 h-3.5" /> },
    { id: 'CORR_VOL', label: 'CORRELATION & VOL', icon: <PieChart className="w-3.5 h-3.5" /> },
    { id: 'RISK_SCENARIOS', label: 'RISK & SCENARIO LAB', icon: <ShieldAlert className="w-3.5 h-3.5" /> },
    { id: 'MARGIN_COLLATERAL', label: 'MARGIN & COLLATERAL', icon: <Coins className="w-3.5 h-3.5" /> },
    { id: 'COUNTERPARTIES', label: 'COUNTERPARTIES & CSA', icon: <Building2 className="w-3.5 h-3.5" /> },
    { id: 'TRADING_RFQ', label: 'TRADING BLOTTER & RFQ', icon: <ListOrdered className="w-3.5 h-3.5" /> },
    { id: 'PNL_LEDGER', label: 'P&L & LEDGER', icon: <FileSpreadsheet className="w-3.5 h-3.5" /> },
    { id: 'GOVERNANCE', label: 'MODEL GOVERNANCE', icon: <CheckCircle2 className="w-3.5 h-3.5" /> },
    { id: 'QUANT_AI', label: 'QUANT ASSISTANT', icon: <Bot className="w-3.5 h-3.5 text-amber-400" />, badge: 'AI CORE' },
  ];

  return (
    <nav className="bg-[#0e141f] border-b border-[#1f2937] px-2 flex items-center space-x-1 overflow-x-auto scrollbar-none select-none text-[11px] font-mono">
      {tabs.map(tab => {
        const isActive = activeTab === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center space-x-1.5 px-3 py-2 border-b-2 whitespace-nowrap transition-all duration-150 font-medium ${
              isActive
                ? 'border-amber-500 text-amber-300 bg-[#161f2e]'
                : 'border-transparent text-gray-400 hover:text-gray-200 hover:bg-[#121926]'
            }`}
          >
            <span>{tab.icon}</span>
            <span>{tab.label}</span>
            {tab.badge && (
              <span
                className={`text-[8px] px-1 py-0.2 rounded-none font-bold uppercase tracking-wider ${
                  tab.badge === 'FLAGSHIP'
                    ? 'bg-amber-950 text-amber-400 border border-amber-800/80'
                    : tab.badge === 'AI CORE'
                    ? 'bg-cyan-950 text-cyan-400 border border-cyan-800/80'
                    : 'bg-emerald-950 text-emerald-400 border border-emerald-800/80'
                }`}
              >
                {tab.badge}
              </span>
            )}
          </button>
        );
      })}
    </nav>
  );
};
