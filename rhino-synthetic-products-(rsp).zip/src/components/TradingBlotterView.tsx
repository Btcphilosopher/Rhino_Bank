/**
 * RHINO SYNTHETIC PRODUCTS
 * Institutional Trading Blotter, Order Book & RFQ Workflow Desk
 */

import React, { useState } from 'react';
import {
  ListOrdered,
  Plus,
  ArrowRight,
  CheckCircle,
  XCircle,
  RefreshCw,
  Send,
  Zap,
  Filter,
  FileCheck
} from 'lucide-react';
import { INITIAL_TRADES, INITIAL_RFQ_ITEMS } from '../data/governanceData';
import { TradeBlotterEntry, RFQItem, TradeAction } from '../types/trading';

interface TradingBlotterProps {
  onExecuteTrade?: (trade: TradeBlotterEntry) => void;
}

export const TradingBlotterView: React.FC<TradingBlotterProps> = ({ onExecuteTrade }) => {
  const [trades, setTrades] = useState<TradeBlotterEntry[]>(INITIAL_TRADES);
  const [rfqs, setRfqs] = useState<RFQItem[]>(INITIAL_RFQ_ITEMS);
  const [activeTab, setActiveTab] = useState<'BLOTTER' | 'RFQ' | 'ORDER_BOOK'>('BLOTTER');
  const [selectedTradeId, setSelectedTradeId] = useState<string | null>(null);

  // New Trade Modal state or inline execution
  const [showNewTradeModal, setShowNewTradeModal] = useState(false);
  const [newTradeProduct, setNewTradeProduct] = useState('RHINO SYNTHETIC CREDIT 01 (Mezzanine 7-15%)');
  const [newTradeSide, setNewTradeSide] = useState<'BUY' | 'SELL'>('SELL');
  const [newTradeNotional, setNewTradeNotional] = useState(100000000);
  const [newTradeCounterparty, setNewTradeCounterparty] = useState('LONDON CAPITAL PARTNERS');

  // Trade Lifecycle Actions
  const handleLifecycleAction = (action: 'NOVATE' | 'UNWIND' | 'TERMINATE' | 'HEDGE', tradeId: string) => {
    setTrades(prev =>
      prev.map(t => {
        if (t.tradeId === tradeId) {
          if (action === 'UNWIND') return { ...t, status: 'UNWOUND' };
          if (action === 'TERMINATE') return { ...t, status: 'TERMINATED' };
          if (action === 'NOVATE') return { ...t, status: 'NOVATED', counterpartyName: 'MANCHESTER CREDIT AG (NOVATED)' };
        }
        return t;
      })
    );
  };

  const handleCreateTrade = (e: React.FormEvent) => {
    e.preventDefault();
    const newEntry: TradeBlotterEntry = {
      tradeId: `TRD-LON-2026-${Math.random().toString(36).substring(2, 6).toUpperCase()}`,
      timestamp: new Date().toTimeString().split(' ')[0] + ' GMT',
      productId: 'RSP-CDO-01',
      productName: newTradeProduct,
      assetClass: 'CREDIT',
      counterpartyId: 'CP-LON-CAPITAL',
      counterpartyName: newTradeCounterparty,
      action: newTradeSide === 'BUY' ? 'BUY_PROTECTION' : 'SELL_PROTECTION',
      side: newTradeSide,
      notionalGBP: newTradeNotional,
      tradePricePct: 98.41,
      spreadBps: 240,
      currentMtmGBP: (newTradeNotional * 98.41) / 100,
      unrealizedPnlGBP: 0,
      initialMarginGBP: Math.round(newTradeNotional * 0.052),
      variationMarginGBP: 0,
      status: 'ACTIVE',
      bookingDesk: 'LONDON_SYNTHETICS_01',
      legalDocumentRef: `ISDA-CONFIRM-2026-${Math.random().toString(36).substring(2, 6).toUpperCase()}`,
    };

    setTrades([newEntry, ...trades]);
    onExecuteTrade?.(newEntry);
    setShowNewTradeModal(false);
  };

  const formatGBP = (val: number) => {
    if (Math.abs(val) >= 1e9) return `£${(val / 1e9).toFixed(2)}bn`;
    if (Math.abs(val) >= 1e6) return `£${(val / 1e6).toFixed(1)}m`;
    if (Math.abs(val) >= 1e3) return `£${(val / 1e3).toFixed(0)}k`;
    return `£${val.toFixed(0)}`;
  };

  return (
    <div className="p-3 space-y-3 bg-[#0b0e14] text-gray-200 font-mono text-xs select-none">
      {/* Header Bar */}
      <div className="bg-[#111827] border border-[#1f2937] p-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="bg-amber-500/10 border border-amber-500/40 p-2 text-amber-400">
            <ListOrdered className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-sm font-bold text-gray-100 tracking-wider">
              INSTITUTIONAL TRADING BLOTTER & RFQ DESK
            </h1>
            <p className="text-[11px] text-gray-400 font-sans">
              Live executed trades blotter, Request for Quote (RFQ) multi-dealer engine, and standardized order books.
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <div className="flex bg-[#0c121d] border border-[#1e293b] p-0.5">
            <button
              onClick={() => setActiveTab('BLOTTER')}
              className={`px-3 py-1 text-xs font-bold transition ${activeTab === 'BLOTTER' ? 'bg-amber-950 text-amber-300 border border-amber-800' : 'text-gray-400'}`}
            >
              TRADING BLOTTER ({trades.length})
            </button>
            <button
              onClick={() => setActiveTab('RFQ')}
              className={`px-3 py-1 text-xs font-bold transition ${activeTab === 'RFQ' ? 'bg-amber-950 text-amber-300 border border-amber-800' : 'text-gray-400'}`}
            >
              REQUEST FOR QUOTE ({rfqs.length})
            </button>
            <button
              onClick={() => setActiveTab('ORDER_BOOK')}
              className={`px-3 py-1 text-xs font-bold transition ${activeTab === 'ORDER_BOOK' ? 'bg-amber-950 text-amber-300 border border-amber-800' : 'text-gray-400'}`}
            >
              SYNTHETIC ORDER BOOK
            </button>
          </div>

          <button
            onClick={() => setShowNewTradeModal(true)}
            className="flex items-center space-x-1 px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-black font-bold border border-amber-400 transition"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>BOOK NEW TRADE</span>
          </button>
        </div>
      </div>

      {/* View 1: Trading Blotter */}
      {activeTab === 'BLOTTER' && (
        <div className="space-y-3">
          <div className="bg-[#111827] border border-[#1f2937] overflow-x-auto">
            <table className="w-full text-left text-[11px] border-collapse whitespace-nowrap">
              <thead className="bg-[#0f172a] text-gray-400 border-b border-[#1f2937]">
                <tr>
                  <th className="p-2">TIME</th>
                  <th className="p-2">TRADE ID</th>
                  <th className="p-2">PRODUCT</th>
                  <th className="p-2">COUNTERPARTY</th>
                  <th className="p-2">SIDE</th>
                  <th className="p-2">NOTIONAL</th>
                  <th className="p-2">PRICE</th>
                  <th className="p-2">SPREAD</th>
                  <th className="p-2">MTM</th>
                  <th className="p-2">P&L</th>
                  <th className="p-2">IM</th>
                  <th className="p-2">STATUS</th>
                  <th className="p-2">ACTIONS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1e293b]">
                {trades.map(trade => (
                  <tr
                    key={trade.tradeId}
                    onClick={() => setSelectedTradeId(trade.tradeId)}
                    className={`hover:bg-[#162030] cursor-pointer ${selectedTradeId === trade.tradeId ? 'bg-[#1a2638]' : ''}`}
                  >
                    <td className="p-2 text-gray-400 font-mono text-[10px]">{trade.timestamp}</td>
                    <td className="p-2 font-bold text-gray-200">{trade.tradeId}</td>
                    <td className="p-2 text-amber-300 font-semibold">{trade.productName}</td>
                    <td className="p-2 text-gray-300">{trade.counterpartyName}</td>
                    <td className="p-2">
                      <span className={`px-1.5 py-0.2 text-[9px] font-bold border ${trade.side === 'BUY' ? 'border-cyan-600 bg-cyan-950 text-cyan-300' : 'border-amber-600 bg-amber-950 text-amber-300'}`}>
                        {trade.action}
                      </span>
                    </td>
                    <td className="p-2 font-bold text-gray-100">{formatGBP(trade.notionalGBP)}</td>
                    <td className="p-2 text-cyan-300">{trade.tradePricePct}%</td>
                    <td className="p-2 text-gray-300">{trade.spreadBps} bps</td>
                    <td className="p-2 text-gray-100">{formatGBP(trade.currentMtmGBP)}</td>
                    <td className="p-2">
                      <span className={`font-bold ${trade.unrealizedPnlGBP >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {trade.unrealizedPnlGBP >= 0 ? '+' : ''}{formatGBP(trade.unrealizedPnlGBP)}
                      </span>
                    </td>
                    <td className="p-2 text-gray-300">{formatGBP(trade.initialMarginGBP)}</td>
                    <td className="p-2">
                      <span className={`px-1.5 py-0.2 text-[9px] font-bold border ${
                        trade.status === 'ACTIVE' ? 'border-emerald-600 bg-emerald-950 text-emerald-300' :
                        trade.status === 'NOVATED' ? 'border-indigo-600 bg-indigo-950 text-indigo-300' :
                        'border-rose-600 bg-rose-950 text-rose-300'
                      }`}>
                        {trade.status}
                      </span>
                    </td>
                    <td className="p-2">
                      <div className="flex items-center space-x-1" onClick={e => e.stopPropagation()}>
                        <button
                          onClick={() => handleLifecycleAction('UNWIND', trade.tradeId)}
                          className="px-1.5 py-0.5 bg-[#1f2937] hover:bg-gray-700 text-gray-300 text-[9px] border border-gray-600"
                        >
                          UNWIND
                        </button>
                        <button
                          onClick={() => handleLifecycleAction('NOVATE', trade.tradeId)}
                          className="px-1.5 py-0.5 bg-[#1f2937] hover:bg-gray-700 text-gray-300 text-[9px] border border-gray-600"
                        >
                          NOVATE
                        </button>
                        <button
                          onClick={() => handleLifecycleAction('TERMINATE', trade.tradeId)}
                          className="px-1.5 py-0.5 bg-rose-950/80 hover:bg-rose-900 text-rose-300 text-[9px] border border-rose-700"
                        >
                          TERMINATE
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* View 2: Request For Quote (RFQ) Engine */}
      {activeTab === 'RFQ' && (
        <div className="space-y-3">
          {rfqs.map(rfq => (
            <div key={rfq.rfqId} className="bg-[#111827] border border-[#1f2937] p-3 space-y-3">
              <div className="flex items-center justify-between border-b border-[#1f2937] pb-2">
                <div>
                  <span className="text-[10px] text-gray-400 font-bold">{rfq.rfqId} • {rfq.timestamp}</span>
                  <h3 className="text-sm font-bold text-amber-400">{rfq.productName}</h3>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-gray-400">NOTIONAL: <strong className="text-gray-100">{formatGBP(rfq.notionalGBP)}</strong></span>
                </div>
              </div>

              <table className="w-full text-left text-[10px] border-collapse">
                <thead className="bg-[#0f172a] text-gray-400">
                  <tr>
                    <th className="p-1.5">DEALER</th>
                    <th className="p-1.5">RATING</th>
                    <th className="p-1.5">BID PRICE</th>
                    <th className="p-1.5">ASK PRICE</th>
                    <th className="p-1.5">SPREAD</th>
                    <th className="p-1.5">IM REQUIRED</th>
                    <th className="p-1.5">ACTION</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1e293b]">
                  {rfq.quotes.map(q => (
                    <tr key={q.quoteId} className="hover:bg-[#162030]">
                      <td className="p-1.5 font-bold text-gray-200">{q.counterpartyName}</td>
                      <td className="p-1.5 text-indigo-300">{q.rating}</td>
                      <td className="p-1.5 text-cyan-300 font-bold">{q.bidPricePct}%</td>
                      <td className="p-1.5 text-amber-300 font-bold">{q.askPricePct}%</td>
                      <td className="p-1.5 text-gray-300">{q.spreadBps} bps</td>
                      <td className="p-1.5 text-gray-400">{formatGBP(q.initialMarginRequiredGBP)}</td>
                      <td className="p-1.5">
                        <button
                          onClick={() => alert(`Executed trade on quote ${q.quoteId} with ${q.counterpartyName}`)}
                          className="px-2 py-0.5 bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-[9px]"
                        >
                          ACCEPT QUOTE
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ))}
        </div>
      )}

      {/* View 3: Synthetic Standardized Order Book */}
      {activeTab === 'ORDER_BOOK' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
          <div className="bg-[#111827] border border-[#1f2937] p-3 space-y-2">
            <h3 className="text-xs font-bold text-amber-400 border-b border-[#1f2937] pb-1">
              iTraxx EUROPE IG 5Y SYNTHETIC TRANCHE (3-7%)
            </h3>
            <table className="w-full text-left text-[10px]">
              <thead className="text-gray-400 bg-[#0f172a]">
                <tr>
                  <th className="p-1">SIZE</th>
                  <th className="p-1 text-cyan-300">BID PRICE</th>
                  <th className="p-1 text-amber-300">ASK PRICE</th>
                  <th className="p-1 text-right">SIZE</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1e293b]">
                <tr><td className="p-1">£50m</td><td className="p-1 text-cyan-300 font-bold">98.42%</td><td className="p-1 text-amber-300 font-bold">98.48%</td><td className="p-1 text-right">£75m</td></tr>
                <tr><td className="p-1">£25m</td><td className="p-1 text-cyan-300">98.38%</td><td className="p-1 text-amber-300">98.52%</td><td className="p-1 text-right">£50m</td></tr>
                <tr><td className="p-1">£100m</td><td className="p-1 text-cyan-300">98.35%</td><td className="p-1 text-amber-300">98.56%</td><td className="p-1 text-right">£120m</td></tr>
              </tbody>
            </table>
          </div>

          <div className="bg-[#111827] border border-[#1f2937] p-3 space-y-2">
            <h3 className="text-xs font-bold text-amber-400 border-b border-[#1f2937] pb-1">
              RHINO BESPOKE MEZZANINE (7-15%)
            </h3>
            <table className="w-full text-left text-[10px]">
              <thead className="text-gray-400 bg-[#0f172a]">
                <tr>
                  <th className="p-1">SIZE</th>
                  <th className="p-1 text-cyan-300">BID SPREAD</th>
                  <th className="p-1 text-amber-300">ASK SPREAD</th>
                  <th className="p-1 text-right">SIZE</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1e293b]">
                <tr><td className="p-1">£80m</td><td className="p-1 text-cyan-300 font-bold">238 bps</td><td className="p-1 text-amber-300 font-bold">242 bps</td><td className="p-1 text-right">£100m</td></tr>
                <tr><td className="p-1">£40m</td><td className="p-1 text-cyan-300">235 bps</td><td className="p-1 text-amber-300">245 bps</td><td className="p-1 text-right">£60m</td></tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Book New Trade Modal */}
      {showNewTradeModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-[#111827] border border-amber-500 w-full max-w-md p-4 space-y-3">
            <div className="flex justify-between items-center border-b border-[#1f2937] pb-2">
              <h3 className="text-xs font-bold text-amber-400">BOOK SYNTHETIC DERIVATIVE TRADE</h3>
              <button onClick={() => setShowNewTradeModal(false)} className="text-gray-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleCreateTrade} className="space-y-3 text-[11px]">
              <div>
                <label className="text-[10px] text-gray-400">PRODUCT</label>
                <select
                  value={newTradeProduct}
                  onChange={e => setNewTradeProduct(e.target.value)}
                  className="w-full bg-[#0c121d] border border-[#1e293b] p-1.5 text-gray-200"
                >
                  <option value="RHINO SYNTHETIC CREDIT 01 (Mezzanine 7-15%)">RHINO SYNTHETIC CREDIT 01 (Mezzanine 7-15%)</option>
                  <option value="RHINO SYNTHETIC CREDIT 01 (Senior 15-30%)">RHINO SYNTHETIC CREDIT 01 (Senior 15-30%)</option>
                  <option value="RHINO BESPOKE CREDIT TRANCHE (5-20%)">RHINO BESPOKE CREDIT TRANCHE (5-20%)</option>
                  <option value="RHINO CROSS-ASSET SYNTHETIC 01">RHINO CROSS-ASSET SYNTHETIC 01</option>
                  <option value="FTSE 100 1Y VARIANCE SWAP">FTSE 100 1Y VARIANCE SWAP</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] text-gray-400">SIDE</label>
                  <select
                    value={newTradeSide}
                    onChange={e => setNewTradeSide(e.target.value as any)}
                    className="w-full bg-[#0c121d] border border-[#1e293b] p-1.5 text-gray-200"
                  >
                    <option value="SELL">SELL PROTECTION</option>
                    <option value="BUY">BUY PROTECTION</option>
                  </select>
                </div>
                <div>
                  <label className="text-[10px] text-gray-400">NOTIONAL (GBP)</label>
                  <input
                    type="number"
                    value={newTradeNotional}
                    onChange={e => setNewTradeNotional(parseFloat(e.target.value) || 10000000)}
                    className="w-full bg-[#0c121d] border border-[#1e293b] p-1.5 text-gray-200"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] text-gray-400">COUNTERPARTY</label>
                <select
                  value={newTradeCounterparty}
                  onChange={e => setNewTradeCounterparty(e.target.value)}
                  className="w-full bg-[#0c121d] border border-[#1e293b] p-1.5 text-gray-200"
                >
                  <option value="LONDON CAPITAL PARTNERS">LONDON CAPITAL PARTNERS (AAA)</option>
                  <option value="MANCHESTER CREDIT AG">MANCHESTER CREDIT AG (A+)</option>
                  <option value="EUROPEAN MACRO FUND">EUROPEAN MACRO FUND (A-)</option>
                  <option value="NORTH ATLANTIC FINANCE">NORTH ATLANTIC FINANCE (BBB+)</option>
                  <option value="ASIA CREDIT PARTNERS">ASIA CREDIT PARTNERS (A)</option>
                </select>
              </div>

              <div className="flex justify-end space-x-2 pt-2 border-t border-[#1f2937]">
                <button
                  type="button"
                  onClick={() => setShowNewTradeModal(false)}
                  className="px-3 py-1.5 bg-[#1f2937] text-gray-300"
                >
                  CANCEL
                </button>
                <button
                  type="submit"
                  className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-500 text-black font-bold"
                >
                  CONFIRM & BOOK
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
