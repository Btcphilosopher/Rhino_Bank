/**
 * RHINO SYNTHETIC PRODUCTS
 * Volatility Surfaces, Credit Hazard Curves & Correlation Desk
 */

import React, { useState } from 'react';
import {
  PieChart,
  Activity,
  Sliders,
  TrendingUp,
  RefreshCw,
  Eye,
  Layers
} from 'lucide-react';
import {
  VOL_SURFACE_FTSE_100,
  YIELD_CURVE_GBP_SONIA,
  CDS_CURVE_ITRAXX_IG,
  CROSS_ASSET_FACTORS,
  CROSS_ASSET_CORRELATION_MATRIX
} from '../data/marketData';
import { bootstrapCreditCurve } from '../math/creditCurve';

export const CorrelationVolView: React.FC = () => {
  const [selectedTenor, setSelectedTenor] = useState<string>('1Y');
  const [creditSpreadShock, setCreditSpreadShock] = useState<number>(0);
  const [correlationShockPct, setCorrelationShockPct] = useState<number>(0);

  // Bootstrapped Credit Curve with dynamic spread shock
  const creditCurvePoints = bootstrapCreditCurve(
    CDS_CURVE_ITRAXX_IG.map(c => ({
      tenor: c.tenor,
      years: c.years,
      cdsSpreadBps: Math.round(c.ratePct * 100 + creditSpreadShock),
    }))
  );

  const volDataForTenor = VOL_SURFACE_FTSE_100.filter(p => p.tenor === selectedTenor);
  const selectedAtmPoint = volDataForTenor.find(p => p.strikePct === 100) || volDataForTenor[2];

  return (
    <div className="p-3 space-y-3 bg-[#0b0e14] text-gray-200 font-mono text-xs select-none">
      {/* Top Banner */}
      <div className="bg-[#111827] border border-[#1f2937] p-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="bg-cyan-500/10 border border-cyan-500/40 p-2 text-cyan-400">
            <PieChart className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-sm font-bold text-gray-100 tracking-wider">
              CORRELATION SURFACES, VOLATILITY SKEW & CREDIT CURVES
            </h1>
            <p className="text-[11px] text-gray-400 font-sans">
              Interactive 3D volatility surface smiles, piecewise hazard rate curves, and cross-asset correlation matrices.
            </p>
          </div>
        </div>

        {/* Shocker Buttons */}
        <div className="flex items-center space-x-2">
          <span className="text-[10px] text-gray-400 font-bold">CORR SHOCK:</span>
          {[-10, 0, 5, 10].map(s => (
            <button
              key={s}
              onClick={() => setCorrelationShockPct(s)}
              className={`px-2 py-1 text-[10px] font-bold border transition ${
                correlationShockPct === s
                  ? 'border-indigo-500 bg-indigo-950 text-indigo-300'
                  : 'border-[#1e293b] text-gray-400 hover:text-gray-200'
              }`}
            >
              {s > 0 ? `+${s}%` : `${s}%`}
            </button>
          ))}
        </div>
      </div>

      {/* 3 Analytics Modules */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3">
        {/* Module 1 (4 cols): Volatility Surface & Smile Skew */}
        <div className="lg:col-span-4 bg-[#111827] border border-[#1f2937] p-3 space-y-3">
          <div className="flex items-center justify-between border-b border-[#1f2937] pb-2 text-xs font-bold text-gray-300">
            <span>FTSE 100 VOLATILITY SURFACE & SKEW</span>
            <div className="flex space-x-1">
              {['1M', '6M', '1Y', '2Y', '5Y'].map(t => (
                <button
                  key={t}
                  onClick={() => setSelectedTenor(t)}
                  className={`px-1.5 py-0.5 text-[9px] border ${
                    selectedTenor === t ? 'border-amber-500 bg-amber-950 text-amber-300 font-bold' : 'border-gray-700 text-gray-400'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          {/* SVG Smile Plot */}
          <div className="bg-[#090d14] border border-[#1e293b] p-2 h-44 flex flex-col justify-between">
            <svg viewBox="0 0 300 130" className="w-full h-full overflow-visible">
              <line x1="0" y1="110" x2="300" y2="110" stroke="#1f2937" strokeWidth="1" />
              <line x1="150" y1="10" x2="150" y2="120" stroke="#374151" strokeWidth="1" strokeDasharray="2,2" />

              {/* Volatility smile curve path */}
              <path
                d={volDataForTenor.reduce((acc, pt, i) => {
                  const x = (i / (volDataForTenor.length - 1)) * 300;
                  // y scaled: 10% vol at y=110, 30% vol at y=10
                  const y = 110 - (pt.impliedVolPct - 10) * 5;
                  return `${acc} ${i === 0 ? 'M' : 'L'} ${x} ${y}`;
                }, '')}
                fill="none"
                stroke="#38bdf8"
                strokeWidth="2"
              />

              {/* Points */}
              {volDataForTenor.map((pt, i) => {
                const x = (i / (volDataForTenor.length - 1)) * 300;
                const y = 110 - (pt.impliedVolPct - 10) * 5;
                return (
                  <circle key={i} cx={x} cy={y} r="3" fill="#38bdf8" stroke="#ffffff" strokeWidth="1" />
                );
              })}
            </svg>

            <div className="flex justify-between text-[9px] text-gray-500 font-mono border-t border-[#1e293b] pt-1">
              <span>80% (25Δ Put)</span>
              <span>100% (ATM: {selectedAtmPoint?.impliedVolPct}%)</span>
              <span>120% (25Δ Call)</span>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-1.5 text-[10px] text-gray-300">
            <div className="bg-[#0b0f17] border border-[#1e293b] p-1.5">
              <span className="text-gray-500 text-[9px]">25Δ PUT VOL</span>
              <div className="font-bold text-cyan-300">{selectedAtmPoint?.delta25PutVolPct}%</div>
            </div>
            <div className="bg-[#0b0f17] border border-[#1e293b] p-1.5">
              <span className="text-gray-500 text-[9px]">ATM VOL</span>
              <div className="font-bold text-amber-400">{selectedAtmPoint?.atmVolPct}%</div>
            </div>
            <div className="bg-[#0b0f17] border border-[#1e293b] p-1.5">
              <span className="text-gray-500 text-[9px]">25Δ CALL VOL</span>
              <div className="font-bold text-cyan-300">{selectedAtmPoint?.delta25CallVolPct}%</div>
            </div>
          </div>
        </div>

        {/* Module 2 (4 cols): Credit Survival & Hazard Rate Curve */}
        <div className="lg:col-span-4 bg-[#111827] border border-[#1f2937] p-3 space-y-3">
          <div className="flex items-center justify-between border-b border-[#1f2937] pb-2 text-xs font-bold text-gray-300">
            <span>CREDIT SURVIVAL & HAZARD RATE CURVE</span>
            <div className="flex space-x-1">
              {[0, 25, 50, 100, 250].map(s => (
                <button
                  key={s}
                  onClick={() => setCreditSpreadShock(s)}
                  className={`px-1 py-0.5 text-[9px] border ${
                    creditSpreadShock === s ? 'border-amber-500 bg-amber-950 text-amber-300 font-bold' : 'border-gray-700 text-gray-400'
                  }`}
                >
                  +{s}bp
                </button>
              ))}
            </div>
          </div>

          {/* SVG Survival Curve Plot */}
          <div className="bg-[#090d14] border border-[#1e293b] p-2 h-44 flex flex-col justify-between">
            <svg viewBox="0 0 300 130" className="w-full h-full overflow-visible">
              <line x1="0" y1="110" x2="300" y2="110" stroke="#1f2937" strokeWidth="1" />

              {/* Survival curve path */}
              <path
                d={creditCurvePoints.reduce((acc, pt, i) => {
                  const x = (pt.years / 10) * 300;
                  // y scaled: 100% survival at y=15, 80% survival at y=110
                  const y = 15 + (1 - pt.survivalProbability) * 450;
                  return `${acc} ${i === 0 ? 'M' : 'L'} ${x} ${Math.min(110, y)}`;
                }, '')}
                fill="none"
                stroke="#10b981"
                strokeWidth="2"
              />

              {creditCurvePoints.map((pt, i) => {
                const x = (pt.years / 10) * 300;
                const y = 15 + (1 - pt.survivalProbability) * 450;
                return (
                  <circle key={i} cx={x} cy={Math.min(110, y)} r="3" fill="#10b981" stroke="#ffffff" strokeWidth="1" />
                );
              })}
            </svg>

            <div className="flex justify-between text-[9px] text-gray-500 font-mono border-t border-[#1e293b] pt-1">
              <span>0Y (100% S)</span>
              <span>5Y CDS ({creditCurvePoints[2]?.cdsSpreadBps} bps)</span>
              <span>10Y (S(t): {(creditCurvePoints[4]?.survivalProbability * 100).toFixed(1)}%)</span>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-1.5 text-[10px] text-gray-300">
            <div className="bg-[#0b0f17] border border-[#1e293b] p-1.5">
              <span className="text-gray-500 text-[9px]">5Y HAZARD (λ)</span>
              <div className="font-bold text-amber-400">{(creditCurvePoints[2]?.hazardRate * 100).toFixed(2)}%</div>
            </div>
            <div className="bg-[#0b0f17] border border-[#1e293b] p-1.5">
              <span className="text-gray-500 text-[9px]">5Y SURVIVAL</span>
              <div className="font-bold text-emerald-400">{(creditCurvePoints[2]?.survivalProbability * 100).toFixed(1)}%</div>
            </div>
            <div className="bg-[#0b0f17] border border-[#1e293b] p-1.5">
              <span className="text-gray-500 text-[9px]">5Y DEF PROB</span>
              <div className="font-bold text-rose-400">{(creditCurvePoints[2]?.defaultProbability * 100).toFixed(1)}%</div>
            </div>
          </div>
        </div>

        {/* Module 3 (4 cols): 8x8 Cross-Asset Correlation Heatmap */}
        <div className="lg:col-span-4 bg-[#111827] border border-[#1f2937] p-3 space-y-3">
          <div className="flex items-center justify-between border-b border-[#1f2937] pb-2 text-xs font-bold text-gray-300">
            <span>CROSS-ASSET CORRELATION MATRIX</span>
            <span className="text-[10px] text-indigo-400 font-bold">8x8 JOINT MATRIX</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-center text-[9px] border-collapse">
              <thead>
                <tr>
                  <th className="text-left text-gray-500 p-1">FACTOR</th>
                  {CROSS_ASSET_FACTORS.map((f, i) => (
                    <th key={i} className="text-gray-400 p-1 font-bold">
                      {f.split(' ')[0]}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {CROSS_ASSET_CORRELATION_MATRIX.map((row, rIdx) => (
                  <tr key={rIdx} className="border-t border-[#1a2333]">
                    <td className="text-left text-gray-300 p-1 font-bold whitespace-nowrap">
                      {CROSS_ASSET_FACTORS[rIdx].split(' ')[0]}
                    </td>
                    {row.map((val, cIdx) => {
                      const shockedVal = rIdx === cIdx ? 1.0 : Math.max(-1, Math.min(1, val + correlationShockPct / 100));
                      // Color mapping
                      const bg =
                        shockedVal >= 0.7 ? 'bg-amber-500/30 text-amber-200' :
                        shockedVal >= 0.3 ? 'bg-amber-900/30 text-amber-300' :
                        shockedVal <= -0.4 ? 'bg-rose-950/60 text-rose-300' :
                        'bg-[#0b0f17] text-gray-400';

                      return (
                        <td key={cIdx} className={`p-1 font-mono ${bg}`}>
                          {shockedVal.toFixed(2)}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="text-[9px] text-gray-400 bg-[#0c121d] p-1.5 border border-[#1e293b]">
            <strong>Eigenvalue Diagnostics:</strong> Positive semi-definite condition verified. Condition number: 4.82. Calibrated to 252 business day rolling exponentially weighted moving average (EWMA).
          </div>
        </div>
      </div>
    </div>
  );
};
