/**
 * RHINO SYNTHETIC PRODUCTS
 * Model Risk Governance, Validation Registry & Digital Twin Auditor
 */

import React, { useState } from 'react';
import {
  CheckCircle2,
  AlertTriangle,
  FileCode,
  Layers,
  Shield,
  Clock,
  Eye,
  Download
} from 'lucide-react';
import { MODEL_RISK_REGISTER } from '../data/governanceData';
import { SYNTHETIC_PRODUCT_LIBRARY } from '../data/productLibrary';
import { ModelRiskRecord } from '../types/governance';

export const ModelGovernanceView: React.FC = () => {
  const [models, setModels] = useState<ModelRiskRecord[]>(MODEL_RISK_REGISTER);
  const [selectedModelId, setSelectedModelId] = useState<string>('RHINO-COPULA-v3.8');
  const [showDigitalTwinModal, setShowDigitalTwinModal] = useState<boolean>(false);

  const selectedModel = models.find(m => m.modelId === selectedModelId) || models[0];

  return (
    <div className="p-3 space-y-3 bg-[#0b0e14] text-gray-200 font-mono text-xs select-none">
      {/* Top Banner */}
      <div className="bg-[#111827] border border-[#1f2937] p-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="bg-emerald-500/10 border border-emerald-500/40 p-2 text-emerald-400">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-sm font-bold text-gray-100 tracking-wider">
              QUANTITATIVE MODEL RISK GOVERNANCE & DIGITAL TWIN REGISTRY
            </h1>
            <p className="text-[11px] text-gray-400 font-sans">
              SR 11-7 / PRA SS1/23 Model Risk Framework • Dual Challenger Validations • Digital Twin Audits.
            </p>
          </div>
        </div>

        <button
          onClick={() => setShowDigitalTwinModal(true)}
          className="flex items-center space-x-1 px-3 py-1.5 bg-[#1f2937] hover:bg-gray-700 text-amber-300 border border-amber-500/60 font-bold transition"
        >
          <FileCode className="w-3.5 h-3.5" />
          <span>INSPECT PRODUCT DIGITAL TWIN (JSON)</span>
        </button>
      </div>

      {/* Model Risk Register Table */}
      <div className="bg-[#111827] border border-[#1f2937] p-3 space-y-2">
        <div className="flex items-center justify-between border-b border-[#1f2937] pb-2 text-xs font-bold text-gray-200">
          <span>APPROVED QUANTITATIVE DERIVATIVES PRICING MODELS</span>
          <span className="text-[10px] text-emerald-400 font-bold">ALL 5 MODELS VALIDATED & CURRENT</span>
        </div>

        <table className="w-full text-left text-[11px] border-collapse">
          <thead className="bg-[#0f172a] text-gray-400 border-b border-[#1f2937]">
            <tr>
              <th className="p-2">MODEL ID</th>
              <th className="p-2">NAME</th>
              <th className="p-2">PRIMARY ENGINE</th>
              <th className="p-2">CHALLENGER</th>
              <th className="p-2">CALIB ERROR</th>
              <th className="p-2">CHALLENGER BASIS</th>
              <th className="p-2">STATUS</th>
              <th className="p-2">AUDIT DATE</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#1e293b]">
            {models.map(m => {
              const isSelected = selectedModelId === m.modelId;
              return (
                <tr
                  key={m.modelId}
                  onClick={() => setSelectedModelId(m.modelId)}
                  className={`hover:bg-[#162030] cursor-pointer ${isSelected ? 'bg-[#1a2638]' : ''}`}
                >
                  <td className="p-2 font-bold text-gray-200">{m.modelId}</td>
                  <td className="p-2 text-amber-300 font-semibold">{m.name}</td>
                  <td className="p-2 text-gray-300 text-[10px]">{m.primaryEngine}</td>
                  <td className="p-2 text-gray-400 text-[10px]">{m.challengerEngine}</td>
                  <td className="p-2 text-cyan-300 font-bold">{m.calibrationErrorBps} bps</td>
                  <td className="p-2 text-indigo-300 font-bold">{m.challengerDiscrepancyBps} bps</td>
                  <td className="p-2">
                    <span className="px-1.5 py-0.2 bg-emerald-950 text-emerald-300 border border-emerald-700 font-bold text-[9px]">
                      {m.status}
                    </span>
                  </td>
                  <td className="p-2 text-gray-400 text-[10px]">{m.lastValidatedDate.split(' ')[0]}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Selected Model Deep Dive Specifications */}
      <div className="bg-[#111827] border border-[#1f2937] p-3 space-y-3">
        <div className="flex items-center justify-between border-b border-[#1f2937] pb-2">
          <div>
            <span className="text-[10px] text-gray-400 font-bold">MODEL GOVERNANCE CARD</span>
            <h3 className="text-sm font-bold text-amber-400">{selectedModel.name} ({selectedModel.modelId})</h3>
          </div>
          <div className="text-right text-[10px] text-gray-400">
            Approved By: <strong className="text-gray-200">{selectedModel.approvedBy}</strong>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-[11px]">
          <div className="p-2.5 bg-[#0c121d] border border-[#1e293b] space-y-1.5">
            <span className="text-xs font-bold text-gray-200">EXPLICIT MATHEMATICAL ASSUMPTIONS</span>
            <ul className="list-disc list-inside text-gray-300 text-[10px] space-y-1">
              {selectedModel.assumptions.map((ass, i) => (
                <li key={i}>{ass}</li>
              ))}
            </ul>
          </div>

          <div className="p-2.5 bg-[#0c121d] border border-[#1e293b] space-y-1.5">
            <span className="text-xs font-bold text-gray-200">CHALLENGER BACKTESTING & TOLERANCES</span>
            <div className="text-[10px] text-gray-300 space-y-1">
              <div className="flex justify-between">
                <span>Challenger Engine:</span>
                <span className="text-gray-200 font-bold">{selectedModel.challengerEngine}</span>
              </div>
              <div className="flex justify-between">
                <span>Observed Model Discrepancy:</span>
                <span className="text-cyan-300 font-bold">{selectedModel.challengerDiscrepancyBps} bps</span>
              </div>
              <div className="flex justify-between">
                <span>Maximum Allowable Discrepancy Limit:</span>
                <span className="text-amber-400 font-bold">±{selectedModel.maxAllowableDiscrepancyBps} bps</span>
              </div>
              <div className="flex justify-between">
                <span>Next Scheduled PRA/Internal Audit:</span>
                <span className="text-emerald-400 font-bold">{selectedModel.nextAuditDate}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Digital Twin Modal */}
      {showDigitalTwinModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-[#111827] border border-amber-500 w-full max-w-2xl p-4 space-y-3 max-h-[85vh] flex flex-col">
            <div className="flex justify-between items-center border-b border-[#1f2937] pb-2">
              <div>
                <h3 className="text-xs font-bold text-amber-400">PRODUCT DIGITAL TWIN (CANONICAL SOURCE OF TRUTH)</h3>
                <span className="text-[10px] text-gray-400">RHINO SYNTHETIC CREDIT 01 • PROVENANCE HASH: 0x8F4A9E21BC7891D0</span>
              </div>
              <button onClick={() => setShowDigitalTwinModal(false)} className="text-gray-400 hover:text-white">✕</button>
            </div>

            <div className="bg-[#090d14] border border-[#1e293b] p-3 overflow-y-auto flex-1 font-mono text-[10px] text-emerald-400">
              <pre>{JSON.stringify(SYNTHETIC_PRODUCT_LIBRARY[0], null, 2)}</pre>
            </div>

            <div className="flex justify-end pt-2 border-t border-[#1f2937]">
              <button
                onClick={() => setShowDigitalTwinModal(false)}
                className="px-3 py-1 bg-amber-600 text-black font-bold text-xs"
              >
                CLOSE INSPECTOR
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
