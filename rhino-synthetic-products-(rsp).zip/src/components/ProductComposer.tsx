/**
 * RHINO SYNTHETIC PRODUCTS
 * Synthetic Product Composer & Structuring Factory
 * Assembles custom financial derivatives from primitive market factors & exposures
 */

import React, { useState, useMemo } from 'react';
import {
  Sliders,
  Plus,
  Trash2,
  Zap,
  TrendingUp,
  Shield,
  Layers,
  FileCode,
  ArrowRight,
  CheckCircle2,
  RefreshCw,
  Cpu
} from 'lucide-react';
import { SyntheticFinancialProduct, AssetClass } from '../types/product';
import { blackScholes } from '../math/blackScholes';
import { normalCdf } from '../math/gaussianCopula';

interface ProductComposerProps {
  onIssueProduct?: (product: SyntheticFinancialProduct) => void;
}

export const ProductComposer: React.FC<ProductComposerProps> = ({ onIssueProduct }) => {
  // Configurable Synthetic Product State
  const [productName, setProductName] = useState('RHINO BESPOKE STRUCTURED EXPOSURE 01');
  const [assetClass, setAssetClass] = useState<AssetClass>('HYBRID');
  const [notionalGBP, setNotionalGBP] = useState(100000000); // £100m
  const [maturityYears, setMaturityYears] = useState(5.0);
  const [currency, setCurrency] = useState('GBP');

  // Structural Building Blocks
  const [hasTranche, setHasTranche] = useState(true);
  const [attachmentPoint, setAttachmentPoint] = useState(0.05); // 5%
  const [detachmentPoint, setDetachmentPoint] = useState(0.20); // 20%
  const [hasBarrier, setHasBarrier] = useState(true);
  const [barrierLevelPct, setBarrierLevelPct] = useState(105); // 105% Autocall
  const [hasOptionOverlay, setHasOptionOverlay] = useState(true);
  const [optionType, setOptionType] = useState<'CALL' | 'PUT' | 'VARIANCE_SWAP'>('PUT');
  const [optionStrikePct, setOptionStrikePct] = useState(95);

  // Live Shock Sliders for Payoff Visualizer
  const [underlyingSpotShockPct, setUnderlyingSpotShockPct] = useState(0); // -40% to +40%
  const [volatilityShockPct, setVolatilityShockPct] = useState(18); // 10% to 50%
  const [correlationAssumption, setCorrelationAssumption] = useState(0.28);
  const [creditSpreadBps, setCreditSpreadBps] = useState(145);

  // Underlying Basket Components
  const [underlyingAssets, setUnderlyingAssets] = useState<{ id: string; name: string; weight: number; baseSpread: number }[]>([
    { id: 'U-1', name: '5Y UK Corporate Credit Index (50 names)', weight: 0.40, baseSpread: 142 },
    { id: 'U-2', name: 'GBP 5Y SONIA Yield Curve', weight: 0.30, baseSpread: 410 },
    { id: 'U-3', name: 'FTSE 100 Large Cap Volatility Surface', weight: 0.30, baseSpread: 18 },
  ]);

  // Compute Live Valuation & Greeks
  const valuation = useMemo(() => {
    const spot = 100 * (1 + underlyingSpotShockPct / 100);
    const vol = volatilityShockPct / 100;
    const r = 0.045; // 4.5% SONIA
    const thickness = detachmentPoint - attachmentPoint;

    // Option component
    const optResult = blackScholes(
      spot,
      optionStrikePct,
      maturityYears,
      vol,
      r,
      optionType === 'CALL'
    );

    // Tranche risk approximation
    const trancheSpreadBps = Math.round(creditSpreadBps * (1 / (thickness * 2.2)) * (1 + (1 - correlationAssumption) * 0.5));
    const indicativePricePct = Math.max(90, Math.min(102, 100 - (optResult.price * 0.15) + (hasBarrier ? 0.8 : 0)));
    const expectedLossAmount = notionalGBP * thickness * 0.042 * (creditSpreadBps / 140);

    // Greeks
    const cs01 = Math.round((notionalGBP * thickness * 4.2) / 10000);
    const dv01 = Math.round((notionalGBP * 0.00045));
    const correlationDelta = Math.round((notionalGBP * thickness * (correlationAssumption - 0.20) * 0.08));
    const delta = optResult.delta * 0.45;
    const vega = optResult.vega * (notionalGBP / 1000000);

    // Margin
    const initialMargin = Math.round(notionalGBP * 0.052);
    const variationMargin = Math.round(Math.abs(notionalGBP * (1 - indicativePricePct / 100)));

    return {
      indicativePricePct: Math.round(indicativePricePct * 100) / 100,
      parSpreadBps: trancheSpreadBps,
      expectedLossAmount,
      cs01,
      dv01,
      correlationDelta,
      delta,
      gamma: optResult.gamma * 0.1,
      vega,
      theta: optResult.theta * (notionalGBP / 100000),
      initialMargin,
      variationMargin,
      optResult,
    };
  }, [
    notionalGBP,
    maturityYears,
    attachmentPoint,
    detachmentPoint,
    hasBarrier,
    barrierLevelPct,
    hasOptionOverlay,
    optionType,
    optionStrikePct,
    underlyingSpotShockPct,
    volatilityShockPct,
    correlationAssumption,
    creditSpreadBps,
  ]);

  // Generate Digital Twin Object & Issue
  const handleIssue = () => {
    const product: SyntheticFinancialProduct = {
      productId: `RSP-SYNTH-${Math.random().toString(36).substring(2, 7).toUpperCase()}`,
      version: 1,
      name: productName,
      productType: 'BESPOKE_STRUCTURED_NOTE',
      issuer: 'RHINO SYNTHETICS DESK',
      counterparty: 'LONDON CAPITAL PARTNERS',
      assetClass,
      notional: notionalGBP,
      currency,
      maturityYears,
      maturityDate: '2031-09-20',
      settlementType: 'CASH',
      legalStatus: 'ISDA_2002_MASTER',
      lifecycleState: 'QUOTABLE',
      failureState: 'NONE',
      underlyingAssets: underlyingAssets.map((u, i) => ({
        id: u.id,
        ticker: `SYNTH-${i + 1}`,
        name: u.name,
        assetClass,
        currency,
        basePrice: 100,
        currentSpreadOrYield: u.baseSpread,
        weight: u.weight,
      })),
      underlyingFactors: [
        { id: 'UF-1', name: 'Credit Basket Spread', category: 'CREDIT_SPREAD', currentValue: creditSpreadBps, unit: 'bps', shockSensitivity: 1.2 },
        { id: 'UF-2', name: 'Implied Volatility', category: 'EQUITY_VOL', currentValue: volatilityShockPct, unit: '%', shockSensitivity: 0.8 },
      ],
      barriers: hasBarrier
        ? [
            {
              id: 'BAR-AUTOCALL',
              type: 'AUTOCALL_TRIGGER',
              threshold: barrierLevelPct / 100,
              observationFrequency: 'QUARTERLY',
              status: 'ACTIVE',
              actionDescription: `Autocall at ${barrierLevelPct}% of initial underlying strike.`,
            },
          ]
        : [],
      collateralTerms: {
        initialMarginPct: 0.052,
        variationMarginThreshold: 1000000,
        minimumTransferAmount: 250000,
        eligibleCollateral: ['CASH_GBP', 'UK_GILTS'],
        haircuts: { CASH_GBP: 0.0, UK_GILTS: 0.015 },
        csaAgreementId: 'CSA-RHINO-GENERIC-2026',
      },
      valuationModel: {
        modelId: 'RHINO-COMPOSER-CORE-v3',
        modelName: 'Hybrid Copula & Black-Scholes Decomposition',
        version: '3.1.0',
        calibrationDate: new Date().toISOString(),
        marketDataSnapshot: 'SNAP-20260927-0800',
        primaryEngine: 'ONE_FACTOR_GAUSSIAN_COPULA',
        challengerEngine: 'Multi-Asset Monte Carlo Simulation',
        validationStatus: 'GREEN',
        assumptions: {
          correlation: correlationAssumption,
          recoveryRate: 0.40,
          hazardCurveId: 'RHINO-SYNTH-CURVE',
          volatilitySmile: 'SMILE-V2',
          discountCurve: 'GBP-SONIA',
        },
      },
      pricing: {
        bidPrice: valuation.indicativePricePct - 0.35,
        midPrice: valuation.indicativePricePct,
        askPrice: valuation.indicativePricePct + 0.35,
        parSpreadBps: valuation.parSpreadBps,
        expectedLossAmount: valuation.expectedLossAmount,
        discountedExpectedLoss: valuation.expectedLossAmount * 0.82,
        pvProtectionLeg: valuation.expectedLossAmount * 0.82,
        pvPremiumLeg: notionalGBP * 0.08,
        mtm: (notionalGBP * valuation.indicativePricePct) / 100,
        irrPct: 8.9,
      },
      risk: {
        delta: valuation.delta,
        gamma: valuation.gamma,
        vega: valuation.vega,
        theta: valuation.theta,
        rho: -12000,
        cs01: valuation.cs01,
        dv01: valuation.dv01,
        correlationDelta: valuation.correlationDelta,
        defaultDelta: 850000,
        recoveryDelta: -32000,
        var95: notionalGBP * 0.024,
        var99: notionalGBP * 0.048,
        expectedShortfall: notionalGBP * 0.062,
      },
      margin: {
        initialMargin: valuation.initialMargin,
        variationMargin: valuation.variationMargin,
        totalCollateralPosted: valuation.initialMargin + valuation.variationMargin,
        availableCollateral: valuation.initialMargin * 1.4,
        headroom: valuation.initialMargin * 0.4,
      },
      provenance: {
        calculationId: `CALC-DIGITAL-TWIN-${Math.random().toString(36).substring(2, 8).toUpperCase()}`,
        createdAt: new Date().toISOString(),
        computeTimeMs: 3.2,
        hash: `0x${Math.random().toString(16).substring(2, 18).toUpperCase()}`,
      },
    };

    onIssueProduct?.(product);
  };

  const formatGBP = (val: number) => {
    if (Math.abs(val) >= 1e9) return `£${(val / 1e9).toFixed(2)}bn`;
    if (Math.abs(val) >= 1e6) return `£${(val / 1e6).toFixed(1)}m`;
    if (Math.abs(val) >= 1e3) return `£${(val / 1e3).toFixed(0)}k`;
    return `£${val.toFixed(0)}`;
  };

  // Generate 2D Payoff Plot Coordinates (Underlying Spot 60% to 140%)
  const payoffPoints = useMemo(() => {
    const pts: { spotPct: number; investorReturnPct: number }[] = [];
    for (let s = 60; s <= 140; s += 2) {
      let ret = 0;
      // Tranche payoff component
      if (hasTranche) {
        ret += 7.5; // Base tranche coupon
      }
      // Option overlay payoff
      if (hasOptionOverlay) {
        if (optionType === 'PUT') {
          // Protected down to strike
          const putGain = Math.max(0, optionStrikePct - s);
          ret += putGain > 0 ? -putGain * 0.7 : (s - 100) * 0.3;
        } else {
          const callGain = Math.max(0, s - optionStrikePct);
          ret += callGain * 0.8;
        }
      }
      // Barrier kick-out/autocall
      if (hasBarrier && s >= barrierLevelPct) {
        ret = 12.5; // Autocall fixed return
      }
      pts.push({ spotPct: s, investorReturnPct: ret });
    }
    return pts;
  }, [hasTranche, hasOptionOverlay, optionType, optionStrikePct, hasBarrier, barrierLevelPct]);

  return (
    <div className="p-3 space-y-3 bg-[#0b0e14] text-gray-200 font-mono text-xs select-none">
      {/* Factory Banner */}
      <div className="bg-[#111827] border border-[#1f2937] p-3 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center space-x-3">
          <div className="bg-amber-500/10 border border-amber-500/40 p-2 text-amber-400">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-sm font-bold text-gray-100 tracking-wider">SYNTHETIC PRODUCT COMPOSER & FACTORY</h1>
            <p className="text-[11px] text-gray-400 font-sans">
              Assemble exotic structured notes, credit tranches, cross-asset overlays, and bespoke risk-transfer synthetics.
            </p>
          </div>
        </div>

        <button
          onClick={handleIssue}
          className="flex items-center space-x-1.5 px-3.5 py-1.5 bg-amber-600 hover:bg-amber-500 text-black font-bold border border-amber-400 shadow-lg shadow-amber-950/50 transition"
        >
          <Zap className="w-3.5 h-3.5 fill-black" />
          <span>ISSUE & CREATE DIGITAL TWIN</span>
        </button>
      </div>

      {/* 3-Column Studio: Left Underlyings / Centre Live Payoff / Right Terms */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3">
        {/* Left Column (3 cols): Underlying Basket & Exposures */}
        <div className="lg:col-span-3 space-y-3">
          <div className="bg-[#111827] border border-[#1f2937] p-3 space-y-3">
            <div className="flex items-center justify-between border-b border-[#1f2937] pb-2 text-xs font-bold text-gray-300">
              <span className="flex items-center space-x-1.5">
                <Layers className="w-3.5 h-3.5 text-amber-400" />
                <span>UNDERLYING BASKET</span>
              </span>
              <span className="text-[10px] text-gray-400">{underlyingAssets.length} Factors</span>
            </div>

            <div className="space-y-2">
              {underlyingAssets.map((u, i) => (
                <div key={u.id} className="p-2 bg-[#0c121d] border border-[#1e293b] space-y-1">
                  <div className="flex justify-between items-start">
                    <span className="font-bold text-gray-200 text-[11px]">{u.name}</span>
                  </div>
                  <div className="flex justify-between text-[10px] text-gray-400">
                    <span>Weight: <strong className="text-amber-400">{(u.weight * 100).toFixed(0)}%</strong></span>
                    <span>Spread/Yield: <strong className="text-cyan-300">{u.baseSpread} bps</strong></span>
                  </div>
                </div>
              ))}
            </div>

            {/* Primitive Building Block Toggles */}
            <div className="space-y-2 border-t border-[#1f2937] pt-3">
              <div className="text-xs font-bold text-gray-300">EXPOSURE BUILDING BLOCKS</div>

              <label className="flex items-center justify-between p-2 bg-[#0c121d] border border-[#1e293b] cursor-pointer">
                <span className="text-[11px] text-gray-300">Credit Tranche Layer</span>
                <input
                  type="checkbox"
                  checked={hasTranche}
                  onChange={e => setHasTranche(e.target.checked)}
                  className="accent-amber-500 w-3.5 h-3.5"
                />
              </label>

              <label className="flex items-center justify-between p-2 bg-[#0c121d] border border-[#1e293b] cursor-pointer">
                <span className="text-[11px] text-gray-300">Option / Volatility Overlay</span>
                <input
                  type="checkbox"
                  checked={hasOptionOverlay}
                  onChange={e => setHasOptionOverlay(e.target.checked)}
                  className="accent-amber-500 w-3.5 h-3.5"
                />
              </label>

              <label className="flex items-center justify-between p-2 bg-[#0c121d] border border-[#1e293b] cursor-pointer">
                <span className="text-[11px] text-gray-300">Autocall / Barrier Trigger</span>
                <input
                  type="checkbox"
                  checked={hasBarrier}
                  onChange={e => setHasBarrier(e.target.checked)}
                  className="accent-amber-500 w-3.5 h-3.5"
                />
              </label>
            </div>
          </div>
        </div>

        {/* Centre Column (5 cols): Dynamic Live Payoff Visualizer */}
        <div className="lg:col-span-5 space-y-3">
          <div className="bg-[#111827] border border-[#1f2937] p-3 space-y-3">
            <div className="flex items-center justify-between border-b border-[#1f2937] pb-2">
              <span className="text-xs font-bold text-gray-300 flex items-center space-x-1.5">
                <TrendingUp className="w-3.5 h-3.5 text-amber-400" />
                <span>DYNAMIC PAYOFF PROFILE & STRESS VISUALIZER</span>
              </span>
              <span className="text-[10px] text-emerald-400 bg-emerald-950/60 border border-emerald-800 px-1 py-0.2">
                MODEL: ANALYTIC BS + COPULA
              </span>
            </div>

            {/* Interactive SVG Payoff Diagram */}
            <div className="bg-[#090d14] border border-[#1e293b] p-3 h-52 flex flex-col justify-between">
              <svg viewBox="0 0 500 180" className="w-full h-full overflow-visible">
                {/* Zero axes */}
                <line x1="0" y1="120" x2="500" y2="120" stroke="#374151" strokeWidth="1" />
                <line x1="250" y1="10" x2="250" y2="170" stroke="#1f2937" strokeWidth="1" strokeDasharray="3,3" />

                {/* Barrier threshold marker */}
                {hasBarrier && (
                  <g>
                    <line x1="380" y1="10" x2="380" y2="170" stroke="#ef4444" strokeWidth="1" strokeDasharray="3,3" />
                    <text x="385" y="25" fill="#ef4444" fontSize="8" fontFamily="monospace">
                      AUTOCALL ({barrierLevelPct}%)
                    </text>
                  </g>
                )}

                {/* Strike marker */}
                {hasOptionOverlay && (
                  <g>
                    <line x1="200" y1="10" x2="200" y2="170" stroke="#818cf8" strokeWidth="1" strokeDasharray="3,3" />
                    <text x="145" y="25" fill="#818cf8" fontSize="8" fontFamily="monospace">
                      STRIKE ({optionStrikePct}%)
                    </text>
                  </g>
                )}

                {/* Payoff Curve */}
                <path
                  d={payoffPoints.reduce((acc, pt, idx) => {
                    const x = (idx / (payoffPoints.length - 1)) * 500;
                    // Y axis scaled: 0% return at y=120, +20% at y=40, -20% at y=160
                    const y = 120 - pt.investorReturnPct * 4;
                    return `${acc} ${idx === 0 ? 'M' : 'L'} ${x} ${Math.max(10, Math.min(170, y))}`;
                  }, '')}
                  fill="none"
                  stroke="#f59e0b"
                  strokeWidth="2.5"
                />

                {/* Current Spot Dot */}
                <circle cx="250" cy="90" r="4" fill="#10b981" stroke="#ffffff" strokeWidth="1" />
                <text x="255" y="85" fill="#10b981" fontSize="9" fontWeight="bold" fontFamily="monospace">
                  SPOT (100%)
                </text>
              </svg>

              <div className="flex justify-between text-[9px] text-gray-500 font-mono border-t border-[#1e293b] pt-1">
                <span>-40% Underlying Crash</span>
                <span>ATM Spot (100%)</span>
                <span>+40% Underlying Rally</span>
              </div>
            </div>

            {/* Shock Testing Sliders */}
            <div className="grid grid-cols-2 gap-3 text-[11px] bg-[#0c121d] p-2.5 border border-[#1e293b]">
              <div>
                <div className="flex justify-between text-[10px] mb-1">
                  <span>Underlying Spot Shock:</span>
                  <span className="font-bold text-amber-400">{underlyingSpotShockPct >= 0 ? `+${underlyingSpotShockPct}` : underlyingSpotShockPct}%</span>
                </div>
                <input
                  type="range"
                  min="-30"
                  max="30"
                  step="2"
                  value={underlyingSpotShockPct}
                  onChange={e => setUnderlyingSpotShockPct(parseInt(e.target.value))}
                  className="w-full accent-amber-500 bg-[#1f2937] h-1 rounded-none cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-[10px] mb-1">
                  <span>Implied Volatility:</span>
                  <span className="font-bold text-cyan-400">{volatilityShockPct}%</span>
                </div>
                <input
                  type="range"
                  min="10"
                  max="50"
                  step="1"
                  value={volatilityShockPct}
                  onChange={e => setVolatilityShockPct(parseInt(e.target.value))}
                  className="w-full accent-cyan-500 bg-[#1f2937] h-1 rounded-none cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-[10px] mb-1">
                  <span>Correlation (ρ):</span>
                  <span className="font-bold text-indigo-300">{(correlationAssumption * 100).toFixed(0)}%</span>
                </div>
                <input
                  type="range"
                  min="0.05"
                  max="0.75"
                  step="0.05"
                  value={correlationAssumption}
                  onChange={e => setCorrelationAssumption(parseFloat(e.target.value))}
                  className="w-full accent-indigo-500 bg-[#1f2937] h-1 rounded-none cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-[10px] mb-1">
                  <span>Credit Spread:</span>
                  <span className="font-bold text-rose-400">{creditSpreadBps} bps</span>
                </div>
                <input
                  type="range"
                  min="50"
                  max="350"
                  step="10"
                  value={creditSpreadBps}
                  onChange={e => setCreditSpreadBps(parseInt(e.target.value))}
                  className="w-full accent-rose-500 bg-[#1f2937] h-1 rounded-none cursor-pointer"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Right Column (4 cols): Contract Specification & Legal Terms */}
        <div className="lg:col-span-4 space-y-3">
          <div className="bg-[#111827] border border-[#1f2937] p-3 space-y-3">
            <div className="flex items-center justify-between border-b border-[#1f2937] pb-2 text-xs font-bold text-gray-300">
              <span className="flex items-center space-x-1.5">
                <FileCode className="w-3.5 h-3.5 text-amber-400" />
                <span>CONTRACT SPECIFICATION</span>
              </span>
              <span className="text-[10px] text-gray-400">VERSION 1.0</span>
            </div>

            <div className="space-y-2">
              <div>
                <label className="text-[10px] text-gray-400">PRODUCT TITLE</label>
                <input
                  type="text"
                  value={productName}
                  onChange={e => setProductName(e.target.value)}
                  className="w-full bg-[#0c121d] border border-[#1e293b] px-2 py-1 text-gray-200 text-xs focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] text-gray-400">NOTIONAL (GBP)</label>
                  <input
                    type="number"
                    value={notionalGBP}
                    onChange={e => setNotionalGBP(parseFloat(e.target.value) || 10000000)}
                    className="w-full bg-[#0c121d] border border-[#1e293b] px-2 py-1 text-gray-200 text-xs focus:border-amber-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-gray-400">MATURITY (YEARS)</label>
                  <select
                    value={maturityYears}
                    onChange={e => setMaturityYears(parseFloat(e.target.value))}
                    className="w-full bg-[#0c121d] border border-[#1e293b] px-2 py-1 text-gray-200 text-xs focus:border-amber-500 focus:outline-none"
                  >
                    <option value="1.0">1.0 Year</option>
                    <option value="3.0">3.0 Years</option>
                    <option value="5.0">5.0 Years</option>
                    <option value="7.0">7.0 Years</option>
                  </select>
                </div>
              </div>

              {/* Tranche Parameters */}
              {hasTranche && (
                <div className="p-2 bg-[#0c121d] border border-[#1e293b] space-y-1.5">
                  <span className="text-[10px] font-bold text-amber-400">TRANCHE ATTACHMENT / DETACHMENT</span>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <span className="text-[9px] text-gray-400">Attachment: {(attachmentPoint * 100).toFixed(0)}%</span>
                      <input
                        type="range"
                        min="0"
                        max="0.20"
                        step="0.01"
                        value={attachmentPoint}
                        onChange={e => setAttachmentPoint(parseFloat(e.target.value))}
                        className="w-full accent-amber-500 h-1 bg-[#1f2937]"
                      />
                    </div>
                    <div>
                      <span className="text-[9px] text-gray-400">Detachment: {(detachmentPoint * 100).toFixed(0)}%</span>
                      <input
                        type="range"
                        min="0.05"
                        max="0.50"
                        step="0.05"
                        value={detachmentPoint}
                        onChange={e => setDetachmentPoint(parseFloat(e.target.value))}
                        className="w-full accent-amber-500 h-1 bg-[#1f2937]"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Option Overlay Parameters */}
              {hasOptionOverlay && (
                <div className="p-2 bg-[#0c121d] border border-[#1e293b] space-y-1.5">
                  <span className="text-[10px] font-bold text-indigo-300">OPTION OVERLAY TERMS</span>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <span className="text-[9px] text-gray-400">Type</span>
                      <select
                        value={optionType}
                        onChange={e => setOptionType(e.target.value as any)}
                        className="w-full bg-[#111827] border border-[#1e293b] text-gray-200 text-[10px] px-1 py-0.5"
                      >
                        <option value="PUT">Put Option (Downside Protection)</option>
                        <option value="CALL">Call Option (Upside Participation)</option>
                      </select>
                    </div>
                    <div>
                      <span className="text-[9px] text-gray-400">Strike: {optionStrikePct}%</span>
                      <input
                        type="range"
                        min="80"
                        max="120"
                        step="5"
                        value={optionStrikePct}
                        onChange={e => setOptionStrikePct(parseInt(e.target.value))}
                        className="w-full accent-indigo-500 h-1 bg-[#1f2937]"
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Consolidated Re-Valuation Bar */}
      <div className="bg-[#111827] border border-[#1f2937] p-3">
        <div className="text-[10px] font-bold text-gray-400 tracking-wider mb-2">
          REAL-TIME QUANTITATIVE VALUATION & RISK METRICS (DIGITAL TWIN TWIN-HASH: 0x98AF01BC)
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2 text-[11px]">
          <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
            <div className="text-gray-400 text-[9px]">INDICATIVE PRICE</div>
            <div className="font-bold text-cyan-300">{valuation.indicativePricePct}%</div>
            <div className="text-[9px] text-gray-500">Par Spread: {valuation.parSpreadBps} bps</div>
          </div>

          <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
            <div className="text-gray-400 text-[9px]">EXPECTED LOSS</div>
            <div className="font-bold text-amber-400">{formatGBP(valuation.expectedLossAmount)}</div>
            <div className="text-[9px] text-gray-500">5Y Cumulative</div>
          </div>

          <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
            <div className="text-gray-400 text-[9px]">CS01 (1bp)</div>
            <div className="font-bold text-gray-200">{formatGBP(valuation.cs01)}</div>
            <div className="text-[9px] text-gray-500">Credit spread delta</div>
          </div>

          <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
            <div className="text-gray-400 text-[9px]">DV01 (1bp)</div>
            <div className="font-bold text-gray-200">{formatGBP(valuation.dv01)}</div>
            <div className="text-[9px] text-gray-500">Rates sensitivity</div>
          </div>

          <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
            <div className="text-gray-400 text-[9px]">CORR DELTA (1%)</div>
            <div className="font-bold text-indigo-300">{formatGBP(valuation.correlationDelta)}</div>
            <div className="text-[9px] text-gray-500">Base correlation</div>
          </div>

          <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
            <div className="text-gray-400 text-[9px]">VEGA EXPOSURE</div>
            <div className="font-bold text-gray-200">{formatGBP(valuation.vega)}</div>
            <div className="text-[9px] text-gray-500">1% Volatility shift</div>
          </div>

          <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
            <div className="text-gray-400 text-[9px]">INITIAL MARGIN</div>
            <div className="font-bold text-gray-200">{formatGBP(valuation.initialMargin)}</div>
            <div className="text-[9px] text-gray-500">SIMM requirement</div>
          </div>

          <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
            <div className="text-gray-400 text-[9px]">VARIATION MARGIN</div>
            <div className="font-bold text-gray-200">{formatGBP(valuation.variationMargin)}</div>
            <div className="text-[9px] text-gray-500">Current MTM gap</div>
          </div>
        </div>
      </div>
    </div>
  );
};
