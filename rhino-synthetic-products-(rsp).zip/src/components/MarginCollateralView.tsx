/**
 * RHINO SYNTHETIC PRODUCTS
 * Margin Engine & Collateral Optimisation Desk
 */

import React, { useState, useMemo } from 'react';
import {
  Coins,
  ShieldCheck,
  Zap,
  Sliders,
  CheckCircle,
  TrendingDown,
  Layers,
  ArrowRight
} from 'lucide-react';
import { INITIAL_COLLATERAL_INVENTORY } from '../data/counterpartiesData';
import { calculateSimmMargin } from '../math/marginEngine';
import { optimizeCollateralAllocation } from '../math/collateralOptimizer';
import { CollateralAsset } from '../types/margin';

export const MarginCollateralView: React.FC = () => {
  const [collateralInventory, setCollateralInventory] = useState<CollateralAsset[]>(INITIAL_COLLATERAL_INVENTORY);
  const [csaThresholdGBP, setCsaThresholdGBP] = useState<number>(5000000); // £5m
  const [postedCollateralGBP, setPostedCollateralGBP] = useState<number>(71400000); // £71.4m

  // Compute SIMM Margin live
  const marginMetrics = useMemo(() => {
    return calculateSimmMargin(
      1820000, // CS01
      940000,  // DV01
      125000,  // Equity Delta
      340000,  // Vega
      -98410000, // Portfolio MTM
      csaThresholdGBP,
      postedCollateralGBP
    );
  }, [csaThresholdGBP, postedCollateralGBP]);

  // Compute Optimal Collateral Allocation
  const optimization = useMemo(() => {
    return optimizeCollateralAllocation(collateralInventory, marginMetrics.totalRequiredCollateralGBP);
  }, [collateralInventory, marginMetrics.totalRequiredCollateralGBP]);

  const formatGBP = (val: number) => {
    if (Math.abs(val) >= 1e9) return `£${(val / 1e9).toFixed(2)}bn`;
    if (Math.abs(val) >= 1e6) return `£${(val / 1e6).toFixed(1)}m`;
    if (Math.abs(val) >= 1e3) return `£${(val / 1e3).toFixed(0)}k`;
    return `£${val.toFixed(0)}`;
  };

  return (
    <div className="p-3 space-y-3 bg-[#0b0e14] text-gray-200 font-mono text-xs select-none">
      {/* Header Banner */}
      <div className="bg-[#111827] border border-[#1f2937] p-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="bg-amber-500/10 border border-amber-500/40 p-2 text-amber-400">
            <Coins className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-sm font-bold text-gray-100 tracking-wider">
              RHINO MARGIN ENGINE & COLLATERAL OPTIMISATION DESK
            </h1>
            <p className="text-[11px] text-gray-400 font-sans">
              ISDA SIMM Initial Margin decomposition, dynamic Variation Margin netting, and haircut-optimized collateral pledging.
            </p>
          </div>
        </div>

        <div className="bg-[#0b0f17] border border-[#1e293b] px-3 py-1.5 flex items-center space-x-4 text-[11px]">
          <div>
            <span className="text-gray-400 text-[9px]">TOTAL COLLATERAL:</span>
            <div className="font-bold text-gray-100">{formatGBP(postedCollateralGBP)}</div>
          </div>
          <div className="border-l border-[#1e293b] pl-3">
            <span className="text-gray-400 text-[9px]">HEADROOM:</span>
            <div className="font-bold text-emerald-400">{formatGBP(marginMetrics.headroomGBP)}</div>
          </div>
        </div>
      </div>

      {/* 5 Executive Margin Indicators */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-[11px]">
        <div className="bg-[#111827] border border-[#1f2937] p-2.5">
          <div className="text-gray-400 text-[9px]">INITIAL MARGIN (SIMM)</div>
          <div className="text-base font-bold text-gray-100">{formatGBP(marginMetrics.totalInitialMarginGBP)}</div>
          <div className="text-[9px] text-gray-500">Sensitivity-based risk</div>
        </div>

        <div className="bg-[#111827] border border-[#1f2937] p-2.5">
          <div className="text-gray-400 text-[9px]">VARIATION MARGIN</div>
          <div className="text-base font-bold text-cyan-300">{formatGBP(marginMetrics.variationMarginGBP)}</div>
          <div className="text-[9px] text-gray-500">Daily MTM gap</div>
        </div>

        <div className="bg-[#111827] border border-[#1f2937] p-2.5">
          <div className="text-gray-400 text-[9px]">TOTAL REQUIRED MARGIN</div>
          <div className="text-base font-bold text-amber-400">{formatGBP(marginMetrics.totalRequiredCollateralGBP)}</div>
          <div className="text-[9px] text-gray-500">IM + VM Requirement</div>
        </div>

        <div className="bg-[#111827] border border-[#1f2937] p-2.5">
          <div className="text-gray-400 text-[9px]">AVAILABLE COLLATERAL</div>
          <div className="text-base font-bold text-gray-200">{formatGBP(marginMetrics.availableCollateralGBP)}</div>
          <div className="text-[9px] text-emerald-400">100% Eligible Assets</div>
        </div>

        <div className="bg-[#111827] border border-[#1f2937] p-2.5 bg-emerald-950/20">
          <div className="text-gray-400 text-[9px]">COLLATERAL HEADROOM</div>
          <div className="text-base font-bold text-emerald-400">{formatGBP(marginMetrics.headroomGBP)}</div>
          <div className="text-[9px] text-emerald-300">Surplus Capacity</div>
        </div>
      </div>

      {/* Grid: Left SIMM Risk Buckets / Right Collateral Optimization Table */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3">
        {/* Left Column (5 cols): SIMM Risk Buckets */}
        <div className="lg:col-span-5 space-y-3">
          <div className="bg-[#111827] border border-[#1f2937] p-3 space-y-2.5">
            <div className="flex items-center justify-between border-b border-[#1f2937] pb-2 text-xs font-bold text-gray-300">
              <span>ISDA SIMM RISK CLASS DECOMPOSITION</span>
              <span className="text-[10px] text-emerald-400 font-bold">MODEL: SIMM-v2.6</span>
            </div>

            <div className="space-y-1.5">
              {[
                { name: 'Credit Spread Risk (CS01)', value: marginMetrics.creditSpreadRiskIM, pct: 45.2, color: 'bg-amber-500' },
                { name: 'Interest Rate Risk (DV01)', value: marginMetrics.interestRateRiskIM, pct: 28.5, color: 'bg-cyan-500' },
                { name: 'Equity & Volatility Risk', value: marginMetrics.equityRiskIM, pct: 14.8, color: 'bg-indigo-500' },
                { name: 'Curvature & Vega Convexity', value: marginMetrics.curvatureRiskIM, pct: 7.2, color: 'bg-purple-500' },
                { name: 'Cross-Asset FX & Commodity', value: marginMetrics.fxRiskIM + marginMetrics.commodityRiskIM, pct: 4.3, color: 'bg-emerald-500' },
              ].map((b, i) => (
                <div key={i} className="p-2 bg-[#0c121d] border border-[#1e293b] text-[10px]">
                  <div className="flex justify-between mb-1">
                    <span className="font-bold text-gray-200">{b.name}</span>
                    <span className="text-gray-300">{formatGBP(b.value)} ({b.pct}%)</span>
                  </div>
                  <div className="w-full bg-[#1e293b] h-1.5">
                    <div className={`${b.color} h-full`} style={{ width: `${b.pct}%` }}></div>
                  </div>
                </div>
              ))}
            </div>

            <div className="text-[10px] text-gray-400 bg-[#080d14] p-2 border border-[#1e293b]">
              <strong>Diversification Benefit:</strong> Cross-bucket intra-asset correlations reduced standalone margin requirements from £61.8m to £42.8m (30.7% netting efficiency).
            </div>
          </div>
        </div>

        {/* Right Column (7 cols): Collateral Optimiser Table */}
        <div className="lg:col-span-7 space-y-3">
          <div className="bg-[#111827] border border-[#1f2937] p-3 space-y-3">
            <div className="flex items-center justify-between border-b border-[#1f2937] pb-2">
              <div>
                <span className="text-xs font-bold text-amber-400">OPTIMAL COLLATERAL ALLOCATION SOLVER</span>
                <p className="text-[10px] text-gray-400">Minimizes funding drag subject to regulatory haircut constraints</p>
              </div>
              <div className="text-right">
                <span className="text-[9px] text-gray-400">BLENDED FUNDING COST</span>
                <div className="text-sm font-bold text-emerald-400">{optimization.blendedFundingCostBps} bps</div>
              </div>
            </div>

            <table className="w-full text-left text-[10px] border-collapse">
              <thead className="bg-[#0f172a] text-gray-400">
                <tr>
                  <th className="p-1.5">ASSET CLASS</th>
                  <th className="p-1.5">MARKET VALUE</th>
                  <th className="p-1.5">HAIRCUT</th>
                  <th className="p-1.5">PLEDGED NOMINAL</th>
                  <th className="p-1.5">EFFECTIVE MARGIN</th>
                  <th className="p-1.5">FUNDING COST</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1e293b]">
                {optimization.allocationBreakdown.map((item, idx) => (
                  <tr key={idx} className="hover:bg-[#162030]">
                    <td className="p-1.5 font-bold text-gray-200">{item.assetName}</td>
                    <td className="p-1.5 text-gray-300">
                      {formatGBP(collateralInventory.find(c => c.type === item.assetType)?.marketValueGBP || 0)}
                    </td>
                    <td className="p-1.5 text-rose-400 font-bold">{(item.haircutPct * 100).toFixed(1)}%</td>
                    <td className="p-1.5 text-amber-300 font-bold">{formatGBP(item.pledgedValueGBP)}</td>
                    <td className="p-1.5 text-emerald-400 font-bold">{formatGBP(item.effectiveCollateralGBP)}</td>
                    <td className="p-1.5 text-gray-300">{formatGBP(item.fundingCostGBP)}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            <div className="grid grid-cols-3 gap-2 text-[10px] p-2 bg-[#0c121d] border border-[#1e293b]">
              <div>Total Pledged Nominal: <strong className="text-gray-200">{formatGBP(optimization.allocatedCollateralGBP)}</strong></div>
              <div>Effective Post-Haircut Value: <strong className="text-emerald-400">{formatGBP(optimization.postHaircutValueGBP)}</strong></div>
              <div>Haircut Efficiency: <strong className="text-cyan-300">{optimization.haircutEfficiencyPct}%</strong></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
