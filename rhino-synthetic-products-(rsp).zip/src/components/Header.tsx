/**
 * RHINO SYNTHETIC PRODUCTS
 * Institutional Terminal Top Bar & Live Telemetry
 */

import React, { useState, useEffect } from 'react';
import { Shield, Activity, Cpu, Database, Compass, ChevronRight } from 'lucide-react';

interface HeaderProps {
  portfolioNav: number;
  totalMtm: number;
  dailyPnl: number;
  cs01: number;
  corrDelta: number;
  initialMargin: number;
  variationMargin: number;
  availableCollateral: number;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  portfolioNav,
  totalMtm,
  dailyPnl,
  cs01,
  corrDelta,
  initialMargin,
  variationMargin,
  availableCollateral,
  activeTab,
  setActiveTab,
}) => {
  const [timeString, setTimeString] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeString(
        now.toTimeString().split(' ')[0] + ' GMT'
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const formatCurrencyM = (val: number) => {
    const isNeg = val < 0;
    const absVal = Math.abs(val);
    if (absVal >= 1e9) {
      return `${isNeg ? '-' : ''}£${(absVal / 1e9).toFixed(2)}bn`;
    }
    return `${isNeg ? '-' : ''}£${(absVal / 1e6).toFixed(1)}m`;
  };

  const headroom = availableCollateral - (initialMargin + variationMargin);

  return (
    <header className="border-b border-[#1f2937] bg-[#0d1117] sticky top-0 z-50 select-none">
      {/* Top Utility Strip */}
      <div className="flex flex-wrap items-center justify-between px-3 py-1 bg-[#080b10] border-b border-[#161f2e] text-[10px] text-gray-400 font-mono">
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-1.5 text-amber-500 font-bold tracking-wider">
            <span className="inline-block w-2 h-2 rounded-none bg-amber-500 animate-pulse"></span>
            <span>RHINO BANK</span>
            <span className="text-gray-500 text-[9px]">/</span>
            <span className="text-gray-300">CANARY WHARF LEVEL 38</span>
          </div>
          <span className="text-gray-600">|</span>
          <span className="text-gray-400">DESK: <strong className="text-gray-200">LONDON SYNTHETICS & STRUCTURED CREDIT</strong></span>
          <span className="text-gray-600">|</span>
          <span className="text-gray-400">MODEL CORE: <strong className="text-emerald-400">v3.8.14 (VALIDATED)</strong></span>
          <span className="text-gray-600">|</span>
          <span className="bg-amber-950/60 border border-amber-800/60 text-amber-300 px-1.5 py-0.2 rounded-none text-[9px] font-semibold tracking-wide">
            SIMULATED RESEARCH ENVIRONMENT
          </span>
        </div>

        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-1 text-gray-300">
            <Database className="w-3 h-3 text-cyan-400" />
            <span>DATA SNAPSHOT: <strong className="text-cyan-300">2026-09-27 08:00 UTC</strong></span>
          </div>
          <span className="text-gray-600">|</span>
          <div className="flex items-center space-x-1 text-amber-400 font-bold">
            <Activity className="w-3 h-3" />
            <span>{timeString || '09:42:17 GMT'}</span>
          </div>
        </div>
      </div>

      {/* Main Title & Executive Metrics Bar */}
      <div className="px-3 py-2 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center space-x-3">
          <div className="border border-amber-600/80 bg-gradient-to-br from-amber-950/40 to-black px-2.5 py-1 flex items-center space-x-2">
            <Shield className="w-4 h-4 text-amber-500" />
            <div>
              <div className="text-amber-400 font-bold tracking-widest text-xs font-mono">RHINO SYNTHETIC PRODUCTS</div>
              <div className="text-[9px] text-gray-400 tracking-wider font-sans">ENGINEER THE EXPOSURE • PRICE THE RISK • TRADE THE SYNTHETIC</div>
            </div>
          </div>
        </div>

        {/* Dense Institutional Key Performance Indicators */}
        <div className="flex items-stretch divide-x divide-[#1e293b] border border-[#1e293b] bg-[#0b0f17] text-xs font-mono">
          <div className="px-2.5 py-1 text-left">
            <div className="text-[9px] text-gray-400 tracking-wider">PORTFOLIO NAV</div>
            <div className="font-bold text-gray-100">{formatCurrencyM(portfolioNav)}</div>
          </div>

          <div className="px-2.5 py-1 text-left">
            <div className="text-[9px] text-gray-400 tracking-wider">PORTFOLIO MTM</div>
            <div className="font-bold text-cyan-300">{formatCurrencyM(totalMtm)}</div>
          </div>

          <div className="px-2.5 py-1 text-left">
            <div className="text-[9px] text-gray-400 tracking-wider">DAILY P&L</div>
            <div className={`font-bold ${dailyPnl >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              {dailyPnl >= 0 ? '+' : ''}{formatCurrencyM(dailyPnl)}
            </div>
          </div>

          <div className="px-2.5 py-1 text-left">
            <div className="text-[9px] text-gray-400 tracking-wider">CS01 (1bp)</div>
            <div className="font-bold text-amber-400">{formatCurrencyM(cs01)}</div>
          </div>

          <div className="px-2.5 py-1 text-left">
            <div className="text-[9px] text-gray-400 tracking-wider">CORR DELTA (1%)</div>
            <div className="font-bold text-indigo-300">{formatCurrencyM(corrDelta)}</div>
          </div>

          <div className="px-2.5 py-1 text-left">
            <div className="text-[9px] text-gray-400 tracking-wider">INITIAL MARGIN</div>
            <div className="font-bold text-gray-200">{formatCurrencyM(initialMargin)}</div>
          </div>

          <div className="px-2.5 py-1 text-left">
            <div className="text-[9px] text-gray-400 tracking-wider">VARIATION MARGIN</div>
            <div className="font-bold text-gray-300">{formatCurrencyM(variationMargin)}</div>
          </div>

          <div className="px-2.5 py-1 text-left bg-[#080d14]">
            <div className="text-[9px] text-gray-400 tracking-wider">COLLATERAL HEADROOM</div>
            <div className="font-bold text-emerald-400">{formatCurrencyM(headroom)}</div>
          </div>
        </div>
      </div>
    </header>
  );
};
