/**
 * RHINO SYNTHETIC PRODUCTS
 * CDO Tranche Waterfall & Credit Default Simulator
 * Simulates sequential corporate defaults and provides drillable loss attribution
 */

import React, { useState, useMemo } from 'react';
import {
  Flame,
  AlertOctagon,
  Shield,
  Layers,
  ChevronDown,
  ChevronRight,
  HelpCircle,
  FileSpreadsheet,
  RotateCcw,
  Zap
} from 'lucide-react';
import { RHINO_CREDIT_PORTFOLIO_01, DEFAULT_CDO_TRANCHES } from '../data/referencePortfolios';
import { DefaultEventLog } from '../types/credit';

interface WaterfallSimulatorProps {
  initialExplainTranche?: string;
}

export const WaterfallDefaultSimulator: React.FC<WaterfallSimulatorProps> = ({ initialExplainTranche }) => {
  // Default count selection
  const [defaultScenario, setDefaultScenario] = useState<1 | 5 | 10 | 25 | 50 | 75>(5);
  const [inspectedTranche, setInspectedTranche] = useState<string>(initialExplainTranche || 'MEZZANINE');
  const [selectedEntityId, setSelectedEntityId] = useState<string | null>(null);

  const recoveryRate = 0.40; // 40% recovery
  const notionalPerEntity = 100000000; // £100m
  const lossPerDefaultGBP = notionalPerEntity * (1 - recoveryRate); // £60m loss per default

  // Compute Default Events and Waterfall Tranche Losses
  const simulation = useMemo(() => {
    const defaultedEntities = RHINO_CREDIT_PORTFOLIO_01.entities.slice(0, defaultScenario);
    const totalPortfolioLossGBP = defaultScenario * lossPerDefaultGBP;
    const totalPortfolioLossPct = (totalPortfolioLossGBP / RHINO_CREDIT_PORTFOLIO_01.totalNotional) * 100;

    // Tranches loss allocation in sequential subordination priority
    let unallocatedLossGBP = totalPortfolioLossGBP;

    // Ordered by seniority (Absorption starts at lowest: Equity -> Junior -> Mezzanine -> Senior -> Super Senior)
    const trancheAbsorptionOrder = ['EQUITY', 'JUNIOR', 'MEZZANINE', 'SENIOR', 'SUPER SENIOR'];

    const trancheLosses: Record<string, {
      name: string;
      initialNotionalGBP: number;
      lossAbsorbedGBP: number;
      remainingNotionalGBP: number;
      impairmentPct: number;
      attachmentPoint: number;
      detachmentPoint: number;
      status: 'INTACT' | 'PARTIALLY_IMPAIRED' | 'FULLY_WIPED';
    }> = {};

    DEFAULT_CDO_TRANCHES.forEach(tr => {
      trancheLosses[tr.name] = {
        name: tr.name,
        initialNotionalGBP: tr.notional,
        lossAbsorbedGBP: 0,
        remainingNotionalGBP: tr.notional,
        impairmentPct: 0,
        attachmentPoint: tr.attachmentPoint,
        detachmentPoint: tr.detachmentPoint,
        status: 'INTACT',
      };
    });

    trancheAbsorptionOrder.forEach(tName => {
      const tr = trancheLosses[tName];
      if (!tr) return;

      const lossToAbsorb = Math.min(unallocatedLossGBP, tr.initialNotionalGBP);
      tr.lossAbsorbedGBP = lossToAbsorb;
      tr.remainingNotionalGBP = tr.initialNotionalGBP - lossToAbsorb;
      tr.impairmentPct = (lossToAbsorb / tr.initialNotionalGBP) * 100;

      if (tr.remainingNotionalGBP === 0) {
        tr.status = 'FULLY_WIPED';
      } else if (tr.lossAbsorbedGBP > 0) {
        tr.status = 'PARTIALLY_IMPAIRED';
      } else {
        tr.status = 'INTACT';
      }

      unallocatedLossGBP -= lossToAbsorb;
    });

    // Generate Step-by-Step Default Audit Logs
    const auditLogs: DefaultEventLog[] = [];
    let runningLossGBP = 0;

    defaultedEntities.forEach((entity, idx) => {
      runningLossGBP += lossPerDefaultGBP;
      const runningLossPct = (runningLossGBP / RHINO_CREDIT_PORTFOLIO_01.totalNotional) * 100;

      // Determine which tranche is absorbing this specific default
      let activeTrancheName = 'EQUITY';
      if (runningLossGBP > 300000000) activeTrancheName = 'JUNIOR';
      if (runningLossGBP > 700000000) activeTrancheName = 'MEZZANINE';
      if (runningLossGBP > 1500000000) activeTrancheName = 'SENIOR';
      if (runningLossGBP > 3000000000) activeTrancheName = 'SUPER SENIOR';

      auditLogs.push({
        timestamp: `T+${idx * 3 + 4}d`,
        step: idx + 1,
        entityId: entity.id,
        entityName: entity.name,
        entitySector: entity.sector,
        rating: entity.rating,
        notionalImpactGBP: notionalPerEntity,
        recoveryAmountGBP: notionalPerEntity * recoveryRate,
        lossAmountGBP: lossPerDefaultGBP,
        cumulativeLossGBP: runningLossGBP,
        cumulativeLossPct: runningLossPct,
        trancheImpacts: Object.values(trancheLosses).map(t => ({
          trancheName: t.name,
          lossAbsorbedGBP: t.lossAbsorbedGBP,
          remainingNotionalGBP: t.remainingNotionalGBP,
          impairmentPct: t.impairmentPct,
        })),
        waterfallNotes: `Default #${idx + 1} (${entity.name}, ${entity.sector}) generated £60m net loss. Subordination absorbed by ${activeTrancheName}.`,
      });
    });

    return {
      defaultedEntities,
      totalPortfolioLossGBP,
      totalPortfolioLossPct,
      trancheLosses,
      auditLogs,
    };
  }, [defaultScenario]);

  const formatGBP = (val: number) => {
    if (Math.abs(val) >= 1e9) return `£${(val / 1e9).toFixed(2)}bn`;
    if (Math.abs(val) >= 1e6) return `£${(val / 1e6).toFixed(1)}m`;
    if (Math.abs(val) >= 1e3) return `£${(val / 1e3).toFixed(0)}k`;
    return `£${val.toFixed(0)}`;
  };

  return (
    <div className="p-3 space-y-3 bg-[#0b0e14] text-gray-200 font-mono text-xs select-none">
      {/* Scenario Control Top Bar */}
      <div className="bg-[#111827] border border-[#1f2937] p-3 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#1f2937] pb-3">
          <div className="flex items-center space-x-3">
            <div className="bg-rose-500/10 border border-rose-500/40 p-2 text-rose-400">
              <Flame className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-sm font-bold text-gray-100 tracking-wider">
                SYNTHETIC CREDIT DEFAULT SIMULATOR & WATERFALL ENGINE
              </h1>
              <p className="text-[11px] text-gray-400 font-sans">
                Simulate sequential default events across 100 corporate reference entities and audit exact waterfall loss allocation.
              </p>
            </div>
          </div>

          {/* Default Count Scenario Selector */}
          <div className="flex items-center space-x-1 bg-[#0c121d] border border-[#1e293b] p-1">
            <span className="text-[10px] text-gray-400 px-2 font-bold">SCENARIO:</span>
            {[1, 5, 10, 25, 50, 75].map(num => (
              <button
                key={num}
                onClick={() => setDefaultScenario(num as any)}
                className={`px-2.5 py-1 text-[11px] font-bold border transition ${
                  defaultScenario === num
                    ? 'border-rose-500 bg-rose-950/80 text-rose-300'
                    : 'border-transparent text-gray-400 hover:text-gray-200'
                }`}
              >
                {num === 75 ? 'SYSTEMIC' : `${num} DEFAULT${num > 1 ? 'S' : ''}`}
              </button>
            ))}
          </div>
        </div>

        {/* 4 Summary Waterfall Metrics */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
          <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
            <div className="text-gray-400 text-[9px]">DEFAULTS INTRODUCED</div>
            <div className="text-base font-bold text-rose-400">{defaultScenario} Entities</div>
            <div className="text-[9px] text-gray-500">Notional: {formatGBP(defaultScenario * notionalPerEntity)}</div>
          </div>

          <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
            <div className="text-gray-400 text-[9px]">GROSS RECOVERY (40%)</div>
            <div className="text-base font-bold text-emerald-400">
              {formatGBP(defaultScenario * notionalPerEntity * recoveryRate)}
            </div>
            <div className="text-[9px] text-gray-500">ISDA Senior Unsecured Par</div>
          </div>

          <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
            <div className="text-gray-400 text-[9px]">NET PORTFOLIO LOSS</div>
            <div className="text-base font-bold text-amber-400">{formatGBP(simulation.totalPortfolioLossGBP)}</div>
            <div className="text-[9px] text-amber-300">{simulation.totalPortfolioLossPct.toFixed(2)}% of Portfolio</div>
          </div>

          <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
            <div className="text-gray-400 text-[9px]">HIGHEST IMPAIRED LAYER</div>
            <div className="text-base font-bold text-indigo-300">
              {simulation.trancheLosses['SUPER SENIOR'].lossAbsorbedGBP > 0 ? 'SUPER SENIOR' :
               simulation.trancheLosses['SENIOR'].lossAbsorbedGBP > 0 ? 'SENIOR' :
               simulation.trancheLosses['MEZZANINE'].lossAbsorbedGBP > 0 ? 'MEZZANINE' :
               simulation.trancheLosses['JUNIOR'].lossAbsorbedGBP > 0 ? 'JUNIOR' : 'EQUITY'}
            </div>
            <div className="text-[9px] text-emerald-400">Higher Layers Unaffected</div>
          </div>
        </div>
      </div>

      {/* Main Layout: Left Tranche Waterfall Stack / Right Why Did Tranche Lose Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3">
        {/* Left Column (5 cols): Visual Waterfall Tranches */}
        <div className="lg:col-span-5 space-y-3">
          <div className="bg-[#111827] border border-[#1f2937] p-3 space-y-2">
            <div className="flex items-center justify-between border-b border-[#1f2937] pb-2 text-xs font-bold text-gray-300">
              <span>LOSS PROPAGATION WATERFALL</span>
              <span className="text-[10px] text-gray-400">Sequential Subordination</span>
            </div>

            {/* Tranches Rendered from Top (Super Senior) down to Bottom (Equity) */}
            {['SUPER SENIOR', 'SENIOR', 'MEZZANINE', 'JUNIOR', 'EQUITY'].map(tName => {
              const tr = simulation.trancheLosses[tName];
              const isSelected = inspectedTranche === tName;

              return (
                <div
                  key={tName}
                  onClick={() => setInspectedTranche(tName)}
                  className={`p-2.5 border transition-all cursor-pointer ${
                    isSelected
                      ? 'border-amber-500 bg-[#162030]'
                      : 'border-[#1e293b] bg-[#0c121d] hover:border-gray-600'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <span className="font-bold text-gray-200 text-xs">{tr.name}</span>
                      <span className="text-gray-400 text-[10px]">
                        ({(tr.attachmentPoint * 100).toFixed(0)}%–{(tr.detachmentPoint * 100).toFixed(0)}%)
                      </span>
                    </div>

                    <div className="flex items-center space-x-2">
                      <span
                        className={`text-[9px] px-1.5 py-0.2 font-bold border ${
                          tr.status === 'INTACT'
                            ? 'border-emerald-600 bg-emerald-950 text-emerald-400'
                            : tr.status === 'PARTIALLY_IMPAIRED'
                            ? 'border-amber-600 bg-amber-950 text-amber-400'
                            : 'border-rose-600 bg-rose-950 text-rose-400'
                        }`}
                      >
                        {tr.status}
                      </span>
                      <span className="font-bold text-gray-100 text-xs">
                        {formatGBP(tr.remainingNotionalGBP)}
                      </span>
                    </div>
                  </div>

                  {/* Progress Bar of Loss Absorption */}
                  <div className="w-full bg-[#1e293b] h-2 mt-2 overflow-hidden flex">
                    <div
                      className="bg-rose-600 h-full transition-all duration-300"
                      style={{ width: `${tr.impairmentPct}%` }}
                    ></div>
                    <div
                      className="bg-emerald-600/70 h-full transition-all duration-300"
                      style={{ width: `${100 - tr.impairmentPct}%` }}
                    ></div>
                  </div>

                  <div className="flex justify-between text-[10px] text-gray-400 mt-1.5">
                    <span>Loss Absorbed: <strong className="text-rose-400">{formatGBP(tr.lossAbsorbedGBP)}</strong> ({tr.impairmentPct.toFixed(1)}%)</span>
                    <span>Capacity: <strong className="text-gray-300">{formatGBP(tr.initialNotionalGBP)}</strong></span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column (7 cols): Audit Inspector: "WHY DID THIS TRANCHE LOSE £Xm?" */}
        <div className="lg:col-span-7 space-y-3">
          <div className="bg-[#111827] border border-[#1f2937] p-3 space-y-3">
            <div className="flex items-center justify-between border-b border-[#1f2937] pb-2">
              <div className="flex items-center space-x-2">
                <HelpCircle className="w-4 h-4 text-amber-400" />
                <span className="text-xs font-bold text-amber-400 tracking-wider">
                  WATERFALL EXPLAINABILITY: {inspectedTranche} TRANCHE
                </span>
              </div>
              <span className="text-[10px] text-gray-400">
                Loss Absorbed: <strong className="text-rose-400">{formatGBP(simulation.trancheLosses[inspectedTranche]?.lossAbsorbedGBP || 0)}</strong>
              </span>
            </div>

            {/* Explanation Rationale Box */}
            <div className="p-3 bg-[#0c121d] border border-[#1e293b] text-[11px] space-y-2">
              <div className="text-gray-200 font-semibold">
                Audit Trail Breakdown for {inspectedTranche} Tranche:
              </div>
              <p className="text-gray-300 text-[10px] leading-relaxed">
                Under the current scenario with <strong className="text-rose-400">{defaultScenario} credit defaults</strong>, total reference portfolio losses reached <strong className="text-amber-300">{formatGBP(simulation.totalPortfolioLossGBP)}</strong> ({simulation.totalPortfolioLossPct.toFixed(2)}% of £10.0bn).
              </p>
              <div className="p-2 bg-[#080d14] border border-[#1a2333] space-y-1 text-[10px]">
                <div className="flex justify-between">
                  <span className="text-gray-400">Subordination Cushion (Prior Layers):</span>
                  <span className="text-gray-200 font-bold">
                    {formatGBP(simulation.trancheLosses[inspectedTranche].attachmentPoint * RHINO_CREDIT_PORTFOLIO_01.totalNotional)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Losses Penetrating Subordination:</span>
                  <span className="text-rose-400 font-bold">
                    {formatGBP(simulation.trancheLosses[inspectedTranche].lossAbsorbedGBP)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Remaining Protective Capacity:</span>
                  <span className="text-emerald-400 font-bold">
                    {formatGBP(simulation.trancheLosses[inspectedTranche].remainingNotionalGBP)}
                  </span>
                </div>
              </div>
            </div>

            {/* Defaulted Entities Audit Table */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-[10px] text-gray-400 font-bold">
                <span>UNDERLYING DEFAULTED ENTITIES & RECOVERY SETTLEMENTS</span>
                <span>{simulation.defaultedEntities.length} Names Defaulted</span>
              </div>

              <div className="max-h-56 overflow-y-auto border border-[#1e293b] divide-y divide-[#162030] bg-[#090d14]">
                <table className="w-full text-left text-[10px]">
                  <thead className="bg-[#0f172a] text-gray-400 sticky top-0">
                    <tr>
                      <th className="p-1.5">#</th>
                      <th className="p-1.5">ENTITY NAME</th>
                      <th className="p-1.5">SECTOR</th>
                      <th className="p-1.5">RATING</th>
                      <th className="p-1.5">NOTIONAL</th>
                      <th className="p-1.5">RECOVERY (40%)</th>
                      <th className="p-1.5">NET LOSS</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1a2333]">
                    {simulation.defaultedEntities.map((entity, i) => (
                      <tr
                        key={entity.id}
                        onClick={() => setSelectedEntityId(entity.id)}
                        className={`hover:bg-[#162030] cursor-pointer ${selectedEntityId === entity.id ? 'bg-[#1b283d]' : ''}`}
                      >
                        <td className="p-1.5 text-gray-500 font-mono">{i + 1}</td>
                        <td className="p-1.5 font-bold text-gray-200">{entity.name}</td>
                        <td className="p-1.5 text-gray-400">{entity.sector}</td>
                        <td className="p-1.5">
                          <span className="text-amber-400 font-semibold">{entity.rating}</span>
                        </td>
                        <td className="p-1.5 text-gray-300">£100.0m</td>
                        <td className="p-1.5 text-emerald-400">£40.0m</td>
                        <td className="p-1.5 text-rose-400 font-bold">£60.0m</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
