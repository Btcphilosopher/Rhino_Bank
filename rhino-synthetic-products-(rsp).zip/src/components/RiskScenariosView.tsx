/**
 * RHINO SYNTHETIC PRODUCTS
 * Risk Engine, Institutional Stress Scenario Lab & Factor Hierarchy
 */

import React, { useState } from 'react';
import {
  ShieldAlert,
  Flame,
  Activity,
  AlertTriangle,
  Layers,
  ChevronRight,
  TrendingDown,
  Compass,
  Zap
} from 'lucide-react';
import { STRESS_SCENARIOS } from '../data/governanceData';
import { FACTOR_HIERARCHY_TREE } from '../data/marketData';
import { StressScenario, ScenarioId, FactorHierarchyNode } from '../types/risk';

export const RiskScenariosView: React.FC = () => {
  const [selectedScenarioId, setSelectedScenarioId] = useState<ScenarioId>('CREDIT_CRISIS');
  const [activeTab, setActiveTab] = useState<'SCENARIOS' | 'FACTOR_TREE'>('SCENARIOS');

  const selectedScenario = STRESS_SCENARIOS.find(s => s.id === selectedScenarioId) || STRESS_SCENARIOS[1];

  // Dynamic Portfolio Stress Calculation
  const baseMtmGBP = 9841000000;
  const stressImpactGBP =
    (selectedScenario.creditSpreadShockBps * -1820000) +
    (selectedScenario.rateShockBps * -940000) +
    (selectedScenario.correlationShockPct * 940000) +
    (selectedScenario.volShockPct * 250000) +
    (selectedScenario.defaultCountShock * -60000000);

  const stressedMtmGBP = baseMtmGBP + stressImpactGBP;
  const pnlImpactPct = (stressImpactGBP / baseMtmGBP) * 100;

  const formatGBP = (val: number) => {
    const isNeg = val < 0;
    const absVal = Math.abs(val);
    if (absVal >= 1e9) return `${isNeg ? '-' : ''}£${(absVal / 1e9).toFixed(2)}bn`;
    if (absVal >= 1e6) return `${isNeg ? '-' : ''}£${(absVal / 1e6).toFixed(1)}m`;
    if (absVal >= 1e3) return `${isNeg ? '-' : ''}£${(absVal / 1e3).toFixed(0)}k`;
    return `${isNeg ? '-' : ''}£${absVal.toFixed(0)}`;
  };

  // Render Factor Tree Recursively
  const renderFactorNode = (node: FactorHierarchyNode, depth = 0) => {
    return (
      <div key={node.id} className="space-y-1" style={{ marginLeft: `${depth * 14}px` }}>
        <div className="flex items-center justify-between p-2 bg-[#0c121d] border border-[#1e293b] hover:border-gray-600 transition">
          <div className="flex items-center space-x-2">
            <span className="text-[9px] px-1.5 py-0.2 bg-[#1f2937] text-gray-300 font-bold border border-gray-600">
              {node.level}
            </span>
            <span className="font-bold text-gray-200 text-xs">{node.name}</span>
          </div>
          <div className="flex items-center space-x-4 text-[10px]">
            <span className="text-cyan-300 font-bold">{node.value}</span>
            <span className="text-gray-400">Risk Weight: <strong className="text-amber-400">{node.riskWeightPct}%</strong></span>
          </div>
        </div>
        {node.children && node.children.map(child => renderFactorNode(child, depth + 1))}
      </div>
    );
  };

  return (
    <div className="p-3 space-y-3 bg-[#0b0e14] text-gray-200 font-mono text-xs select-none">
      {/* Header Banner */}
      <div className="bg-[#111827] border border-[#1f2937] p-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="bg-rose-500/10 border border-rose-500/40 p-2 text-rose-400">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-sm font-bold text-gray-100 tracking-wider">
              INSTITUTIONAL RISK ENGINE & SCENARIO LAB
            </h1>
            <p className="text-[11px] text-gray-400 font-sans">
              Re-run entire synthetic derivative book through macro stress tests and factor hierarchies.
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => setActiveTab('SCENARIOS')}
            className={`px-3 py-1.5 text-xs font-bold border transition ${
              activeTab === 'SCENARIOS' ? 'border-rose-500 bg-rose-950 text-rose-300' : 'border-[#1e293b] text-gray-400'
            }`}
          >
            STRESS SCENARIO LAB
          </button>
          <button
            onClick={() => setActiveTab('FACTOR_TREE')}
            className={`px-3 py-1.5 text-xs font-bold border transition ${
              activeTab === 'FACTOR_TREE' ? 'border-amber-500 bg-amber-950 text-amber-300' : 'border-[#1e293b] text-gray-400'
            }`}
          >
            FACTOR HIERARCHY TREE
          </button>
        </div>
      </div>

      {activeTab === 'SCENARIOS' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-3">
          {/* Left Column (5 cols): Scenario Picker */}
          <div className="lg:col-span-5 space-y-2 max-h-[600px] overflow-y-auto">
            <div className="text-[10px] text-gray-400 font-bold uppercase tracking-wider mb-1">
              SELECT MACRO / MARKET STRESS SCENARIO
            </div>

            {STRESS_SCENARIOS.map(sc => {
              const isSelected = sc.id === selectedScenarioId;
              return (
                <div
                  key={sc.id}
                  onClick={() => setSelectedScenarioId(sc.id)}
                  className={`p-2.5 border transition-all cursor-pointer ${
                    isSelected
                      ? 'border-rose-500 bg-[#1f1620]'
                      : 'border-[#1e293b] bg-[#111827] hover:border-gray-600'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-gray-200 text-xs">{sc.name}</span>
                    <span className="text-[10px] text-gray-400 font-mono">
                      {sc.creditSpreadShockBps !== 0 ? `Spreads ${sc.creditSpreadShockBps > 0 ? '+' : ''}${sc.creditSpreadShockBps}bp` : 'Par'}
                    </span>
                  </div>
                  <p className="text-[10px] text-gray-400 mt-1 font-sans">{sc.description}</p>
                </div>
              );
            })}
          </div>

          {/* Right Column (7 cols): Stressed Re-valuation & Factor Drivers */}
          <div className="lg:col-span-7 space-y-3">
            <div className="bg-[#111827] border border-[#1f2937] p-3 space-y-3">
              <div className="flex items-center justify-between border-b border-[#1f2937] pb-2">
                <div>
                  <span className="text-[9px] text-gray-400 font-bold">ACTIVE STRESS TEST</span>
                  <h2 className="text-sm font-bold text-rose-400">{selectedScenario.name}</h2>
                </div>
                <div className="text-right">
                  <div className="text-[9px] text-gray-400">STRESSED P&L IMPACT</div>
                  <div className={`text-base font-bold ${stressImpactGBP >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {stressImpactGBP >= 0 ? '+' : ''}{formatGBP(stressImpactGBP)} ({pnlImpactPct.toFixed(2)}%)
                  </div>
                </div>
              </div>

              {/* 4 Stressed Metric Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
                <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
                  <span className="text-gray-400 text-[9px]">BASE MTM</span>
                  <div className="font-bold text-gray-200">{formatGBP(baseMtmGBP)}</div>
                </div>
                <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
                  <span className="text-gray-400 text-[9px]">STRESSED MTM</span>
                  <div className="font-bold text-cyan-300">{formatGBP(stressedMtmGBP)}</div>
                </div>
                <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
                  <span className="text-gray-400 text-[9px]">ESTIMATED MARGIN CALL</span>
                  <div className="font-bold text-amber-400">{formatGBP(Math.abs(stressImpactGBP * 0.45))}</div>
                </div>
                <div className="bg-[#0b0f17] border border-[#1e293b] p-2">
                  <span className="text-gray-400 text-[9px]">COUNTERPARTY RISK</span>
                  <div className="font-bold text-rose-400">
                    {selectedScenario.defaultCountShock > 5 ? 'HIGH WATCHLIST' : 'MANAGEABLE'}
                  </div>
                </div>
              </div>

              {/* Stressed Shock Parameters Table */}
              <div className="p-2.5 bg-[#0c121d] border border-[#1e293b] space-y-1.5 text-[11px]">
                <div className="text-xs font-bold text-gray-200">APPLIED FACTOR SHOCKS</div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-[10px] text-gray-300">
                  <div>Credit Spread Shock: <strong className="text-rose-400">{selectedScenario.creditSpreadShockBps} bps</strong></div>
                  <div>Yield Curve Shock: <strong className="text-cyan-300">{selectedScenario.rateShockBps} bps</strong></div>
                  <div>Correlation Shock: <strong className="text-indigo-300">{selectedScenario.correlationShockPct}%</strong></div>
                  <div>Volatility Shock: <strong className="text-amber-400">+{selectedScenario.volShockPct}%</strong></div>
                  <div>Simulated Defaults: <strong className="text-rose-400">{selectedScenario.defaultCountShock} Entities</strong></div>
                  <div>Liquidity Haircut Shock: <strong className="text-gray-400">+{selectedScenario.liquidityHaircutPct}%</strong></div>
                </div>
              </div>

              {/* Stress Factor Loss Contribution Bar Chart */}
              <div className="space-y-1.5">
                <div className="text-xs font-bold text-gray-300">FACTOR ATTRIBUTION OF STRESS LOSS</div>
                <div className="space-y-1">
                  {[
                    { factor: 'Credit Spread Widening (CS01)', loss: Math.abs(selectedScenario.creditSpreadShockBps * 1820000), color: 'bg-rose-500' },
                    { factor: 'Direct Reference Defaults', loss: selectedScenario.defaultCountShock * 60000000, color: 'bg-orange-500' },
                    { factor: 'Yield Curve Rate Shift (DV01)', loss: Math.abs(selectedScenario.rateShockBps * 940000), color: 'bg-blue-500' },
                    { factor: 'Correlation & Volatility Dislocation', loss: Math.abs(selectedScenario.correlationShockPct * 940000), color: 'bg-indigo-500' },
                  ].map((item, idx) => {
                    const totalLoss = Math.abs(stressImpactGBP) || 1;
                    const pct = Math.min(100, (item.loss / totalLoss) * 100);
                    return (
                      <div key={idx} className="p-1.5 bg-[#090d14] border border-[#1e293b] text-[10px]">
                        <div className="flex justify-between mb-1">
                          <span>{item.factor}</span>
                          <span className="font-bold text-gray-200">{formatGBP(item.loss)} ({pct.toFixed(1)}%)</span>
                        </div>
                        <div className="w-full bg-[#1e293b] h-1.5">
                          <div className={`${item.color} h-full`} style={{ width: `${pct}%` }}></div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* Factor Hierarchy Tree View */
        <div className="bg-[#111827] border border-[#1f2937] p-3 space-y-3">
          <div className="flex items-center justify-between border-b border-[#1f2937] pb-2">
            <h2 className="text-xs font-bold text-amber-400">
              FACTOR HIERARCHY & RISK PROPAGATION TOPOLOGY
            </h2>
            <span className="text-[10px] text-gray-400">Macro → Market → Underlying → Curve → Volatility → Credit</span>
          </div>

          <div className="space-y-2">
            {renderFactorNode(FACTOR_HIERARCHY_TREE)}
          </div>
        </div>
      )}
    </div>
  );
};
