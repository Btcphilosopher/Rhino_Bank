/**
 * RHINO SYNTHETIC PRODUCTS
 * Counterparties, Netting Engine & Basel Credit Exposure Desk
 */

import React, { useState } from 'react';
import {
  Building2,
  Shield,
  Layers,
  ChevronRight,
  TrendingUp,
  AlertTriangle,
  FileCheck
} from 'lucide-react';
import { SIMULATED_COUNTERPARTIES } from '../data/counterpartiesData';
import { CounterpartyProfile } from '../types/counterparty';

export const CounterpartiesView: React.FC = () => {
  const [selectedCpId, setSelectedCpId] = useState<string>('CP-LON-CAPITAL');

  const selectedCp = SIMULATED_COUNTERPARTIES.find(c => c.id === selectedCpId) || SIMULATED_COUNTERPARTIES[1];

  const formatGBP = (val: number) => {
    if (Math.abs(val) >= 1e9) return `£${(val / 1e9).toFixed(2)}bn`;
    if (Math.abs(val) >= 1e6) return `£${(val / 1e6).toFixed(1)}m`;
    if (Math.abs(val) >= 1e3) return `£${(val / 1e3).toFixed(0)}k`;
    return `£${val.toFixed(0)}`;
  };

  return (
    <div className="p-3 space-y-3 bg-[#0b0e14] text-gray-200 font-mono text-xs select-none">
      {/* Header Banner */}
      <div className="bg-[#111827] border border-[#1f2937] p-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="bg-indigo-500/10 border border-indigo-500/40 p-2 text-indigo-400">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-sm font-bold text-gray-100 tracking-wider">
              INSTITUTIONAL COUNTERPARTIES & NETTING ENGINE
            </h1>
            <p className="text-[11px] text-gray-400 font-sans">
              ISDA Master Netting Sets, Credit Valuation Adjustment (CVA/DVA/FVA), and Potential Future Exposure (PFE).
            </p>
          </div>
        </div>

        <div className="text-[10px] text-gray-400">
          REGULATORY FRAMEWORK: <strong className="text-gray-200">BASEL III / SA-CCR COMPLIANT SIMULATION</strong>
        </div>
      </div>

      {/* Main Grid: Left Counterparties Directory / Right Selected Netting Deck */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3">
        {/* Left Column (5 cols): Counterparty Cards */}
        <div className="lg:col-span-5 space-y-2">
          {SIMULATED_COUNTERPARTIES.map(cp => {
            const isSelected = cp.id === selectedCpId;
            return (
              <div
                key={cp.id}
                onClick={() => setSelectedCpId(cp.id)}
                className={`p-3 border transition-all cursor-pointer ${
                  isSelected
                    ? 'border-amber-500 bg-[#162030]'
                    : 'border-[#1e293b] bg-[#111827] hover:border-gray-600'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="font-bold text-gray-200 text-xs">{cp.shortCode}</span>
                    <span className="text-[10px] px-1.5 py-0.2 bg-indigo-950 text-indigo-300 border border-indigo-800">
                      {cp.rating}
                    </span>
                  </div>
                  <span className="text-[10px] text-emerald-400 font-bold">
                    Net: {formatGBP(cp.netMtmGBP)}
                  </span>
                </div>

                <div className="text-[11px] text-gray-300 font-sans mt-1">{cp.name}</div>

                <div className="grid grid-cols-3 gap-2 text-[10px] mt-2 border-t border-[#1e293b] pt-1.5 text-gray-400">
                  <div>Gross MTM: <strong className="text-gray-200">{formatGBP(cp.grossMtmGBP)}</strong></div>
                  <div>Collateral: <strong className="text-emerald-400">{formatGBP(cp.collateralHeldGBP)}</strong></div>
                  <div className="text-right">Uncollateralized: <strong className="text-rose-400">{formatGBP(cp.currentExposureGBP)}</strong></div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right Column (7 cols): Detailed Netting Set & Basel Exposures */}
        <div className="lg:col-span-7 space-y-3">
          <div className="bg-[#111827] border border-[#1f2937] p-3 space-y-3">
            <div className="flex items-center justify-between border-b border-[#1f2937] pb-2">
              <div>
                <span className="text-[9px] text-gray-400 font-bold">NETTING SET INSPECTOR</span>
                <h2 className="text-sm font-bold text-amber-400">{selectedCp.name}</h2>
              </div>
              <span className="text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-800 px-2 py-0.5 font-bold">
                ENFORCEABLE ISDA MASTER CSA
              </span>
            </div>

            {/* 4 Netting Cards (Section 22: Gross MTM, Net MTM, Collateral, Current Exposure) */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
              <div className="bg-[#0b0f17] border border-[#1e293b] p-2.5">
                <span className="text-gray-400 text-[9px]">GROSS MTM</span>
                <div className="text-base font-bold text-gray-100">{formatGBP(selectedCp.grossMtmGBP)}</div>
                <div className="text-[9px] text-gray-500">Un-netted replacement</div>
              </div>

              <div className="bg-[#0b0f17] border border-[#1e293b] p-2.5">
                <span className="text-gray-400 text-[9px]">NET MTM</span>
                <div className="text-base font-bold text-cyan-300">{formatGBP(selectedCp.netMtmGBP)}</div>
                <div className="text-[9px] text-gray-500">Post-bilateral netting</div>
              </div>

              <div className="bg-[#0b0f17] border border-[#1e293b] p-2.5">
                <span className="text-gray-400 text-[9px]">COLLATERAL HELD</span>
                <div className="text-base font-bold text-emerald-400">{formatGBP(selectedCp.collateralHeldGBP)}</div>
                <div className="text-[9px] text-gray-500">Pledged Cash & Gilts</div>
              </div>

              <div className="bg-[#0b0f17] border border-[#1e293b] p-2.5">
                <span className="text-gray-400 text-[9px]">CURRENT EXPOSURE</span>
                <div className="text-base font-bold text-rose-400">{formatGBP(selectedCp.currentExposureGBP)}</div>
                <div className="text-[9px] text-gray-500">Net replacement cost</div>
              </div>
            </div>

            {/* XVA & Potential Future Exposure Deck */}
            <div className="p-3 bg-[#0c121d] border border-[#1e293b] space-y-2">
              <div className="text-xs font-bold text-gray-200">BASEL III XVA & FUTURE EXPOSURE METRICS</div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[10px]">
                <div className="bg-[#080d14] border border-[#1a2333] p-2">
                  <span className="text-gray-400">PFE 95% (Peak):</span>
                  <div className="font-bold text-indigo-300">{formatGBP(selectedCp.potentialFutureExposureGBP)}</div>
                </div>
                <div className="bg-[#080d14] border border-[#1a2333] p-2">
                  <span className="text-gray-400">CVA (Credit Adj):</span>
                  <div className="font-bold text-rose-400">{formatGBP(selectedCp.cvaGBP)}</div>
                </div>
                <div className="bg-[#080d14] border border-[#1a2333] p-2">
                  <span className="text-gray-400">DVA (Debit Adj):</span>
                  <div className="font-bold text-emerald-400">{formatGBP(selectedCp.dvaGBP)}</div>
                </div>
                <div className="bg-[#080d14] border border-[#1a2333] p-2">
                  <span className="text-gray-400">FVA (Funding Adj):</span>
                  <div className="font-bold text-amber-400">{formatGBP(selectedCp.fvaGBP)}</div>
                </div>
              </div>
            </div>

            {/* CSA Contract Terms Summary */}
            <div className="p-2.5 bg-[#080d14] border border-[#162030] text-[10px] space-y-1">
              <div className="flex justify-between">
                <span className="text-gray-400">CSA Valuation Frequency:</span>
                <span className="text-gray-200 font-bold">{selectedCp.csaType}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Threshold & MTA:</span>
                <span className="text-gray-200">Threshold: {formatGBP(selectedCp.csaThresholdGBP)} | MTA: {formatGBP(selectedCp.mtaGBP)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Independent Amount (Initial Margin):</span>
                <span className="text-gray-200 font-bold">{formatGBP(selectedCp.independentAmountGBP)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Wrong-Way Risk Profile:</span>
                <span className="text-emerald-400 font-bold">{selectedCp.wrongWayRiskScore}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
