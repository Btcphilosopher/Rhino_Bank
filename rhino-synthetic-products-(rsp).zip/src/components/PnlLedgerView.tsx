/**
 * RHINO SYNTHETIC PRODUCTS
 * P&L Attribution Engine & Double-Entry Financial Ledger
 * Deep drillable auditability from total P&L down to mathematical factor contributions and ledger events
 */

import React, { useState } from 'react';
import {
  FileSpreadsheet,
  TrendingUp,
  Layers,
  ChevronRight,
  ShieldCheck,
  CheckCircle2,
  HelpCircle,
  Database
} from 'lucide-react';
import { calculatePnlAttribution } from '../math/pnlAttribution';
import { INITIAL_LEDGER_ENTRIES } from '../data/governanceData';
import { LedgerEntry } from '../types/trading';

export const PnlLedgerView: React.FC = () => {
  const [selectedFactor, setSelectedFactor] = useState<string>('CREDIT_SPREADS');
  const [activeTab, setActiveTab] = useState<'PNL_ATTRIBUTION' | 'FINANCIAL_LEDGER'>('PNL_ATTRIBUTION');
  const [ledgerList, setLedgerList] = useState<LedgerEntry[]>(INITIAL_LEDGER_ENTRIES);

  const attribution = calculatePnlAttribution(0, 0, 0, 0, 0);

  const formatGBP = (val: number) => {
    const isNeg = val < 0;
    const absVal = Math.abs(val);
    if (absVal >= 1e9) return `${isNeg ? '-' : ''}£${(absVal / 1e9).toFixed(2)}bn`;
    if (absVal >= 1e6) return `${isNeg ? '-' : ''}£${(absVal / 1e6).toFixed(1)}m`;
    if (absVal >= 1e3) return `${isNeg ? '-' : ''}£${(absVal / 1e3).toFixed(0)}k`;
    return `${isNeg ? '-' : ''}£${absVal.toFixed(0)}`;
  };

  return (
    <div className="p-3 space-y-3 bg-[#0b0e14] text-gray-200 font-mono text-xs select-none">
      {/* Header Bar */}
      <div className="bg-[#111827] border border-[#1f2937] p-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="bg-emerald-500/10 border border-emerald-500/40 p-2 text-emerald-400">
            <FileSpreadsheet className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-sm font-bold text-gray-100 tracking-wider">
              P&L ATTRIBUTION & AUDITABLE FINANCIAL LEDGER
            </h1>
            <p className="text-[11px] text-gray-400 font-sans">
              Rhino-grade mathematical transparency: Factor Greek decomposition & double-entry accounting events.
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => setActiveTab('PNL_ATTRIBUTION')}
            className={`px-3 py-1.5 text-xs font-bold border transition ${
              activeTab === 'PNL_ATTRIBUTION' ? 'border-emerald-500 bg-emerald-950 text-emerald-300' : 'border-[#1e293b] text-gray-400'
            }`}
          >
            EXPLAIN P&L DECOMPOSITION
          </button>
          <button
            onClick={() => setActiveTab('FINANCIAL_LEDGER')}
            className={`px-3 py-1.5 text-xs font-bold border transition ${
              activeTab === 'FINANCIAL_LEDGER' ? 'border-amber-500 bg-amber-950 text-amber-300' : 'border-[#1e293b] text-gray-400'
            }`}
          >
            IMMUTABLE LEDGER ({ledgerList.length} EVENTS)
          </button>
        </div>
      </div>

      {activeTab === 'PNL_ATTRIBUTION' ? (
        <div className="space-y-3">
          {/* Total P&L Banner */}
          <div className="bg-[#111827] border border-[#1f2937] p-3">
            <div className="flex flex-wrap items-center justify-between border-b border-[#1f2937] pb-2 mb-2">
              <div>
                <span className="text-[10px] text-gray-400 font-bold">TOTAL PORTFOLIO DAILY P&L (2026-09-27)</span>
                <div className="text-xl font-bold text-emerald-400">
                  +{formatGBP(attribution.totalPnlGBP)}
                </div>
              </div>
              <span className="text-[10px] text-gray-400 bg-[#0c121d] border border-[#1e293b] px-2 py-1">
                EXPLAINABILITY COVERAGE: <strong className="text-emerald-400">99.8% ATTRIBUTABLE</strong>
              </span>
            </div>

            {/* Factor Decomposition Strip (Section 29 & 43) */}
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2 text-[11px]">
              <div
                onClick={() => setSelectedFactor('CREDIT_SPREADS')}
                className={`p-2 border cursor-pointer transition ${selectedFactor === 'CREDIT_SPREADS' ? 'border-amber-500 bg-[#162030]' : 'border-[#1e293b] bg-[#0b0f17]'}`}
              >
                <div className="text-gray-400 text-[9px]">CREDIT SPREADS</div>
                <div className="font-bold text-emerald-400">+{formatGBP(attribution.components.creditSpreadsGBP)}</div>
                <div className="text-[9px] text-gray-500">44.5% driver</div>
              </div>

              <div
                onClick={() => setSelectedFactor('RATES')}
                className={`p-2 border cursor-pointer transition ${selectedFactor === 'RATES' ? 'border-amber-500 bg-[#162030]' : 'border-[#1e293b] bg-[#0b0f17]'}`}
              >
                <div className="text-gray-400 text-[9px]">YIELD CURVES (RATES)</div>
                <div className="font-bold text-emerald-400">+{formatGBP(attribution.components.ratesGBP)}</div>
                <div className="text-[9px] text-gray-500">16.4% driver</div>
              </div>

              <div
                onClick={() => setSelectedFactor('CORRELATION')}
                className={`p-2 border cursor-pointer transition ${selectedFactor === 'CORRELATION' ? 'border-amber-500 bg-[#162030]' : 'border-[#1e293b] bg-[#0b0f17]'}`}
              >
                <div className="text-gray-400 text-[9px]">BASE CORRELATION</div>
                <div className="font-bold text-emerald-400">+{formatGBP(attribution.components.correlationGBP)}</div>
                <div className="text-[9px] text-gray-500">15.6% driver</div>
              </div>

              <div
                onClick={() => setSelectedFactor('VOLATILITY')}
                className={`p-2 border cursor-pointer transition ${selectedFactor === 'VOLATILITY' ? 'border-amber-500 bg-[#162030]' : 'border-[#1e293b] bg-[#0b0f17]'}`}
              >
                <div className="text-gray-400 text-[9px]">VOLATILITY SMILE</div>
                <div className="font-bold text-emerald-400">+{formatGBP(attribution.components.volatilityGBP)}</div>
                <div className="text-[9px] text-gray-500">10.9% driver</div>
              </div>

              <div
                onClick={() => setSelectedFactor('FX')}
                className={`p-2 border cursor-pointer transition ${selectedFactor === 'FX' ? 'border-amber-500 bg-[#162030]' : 'border-[#1e293b] bg-[#0b0f17]'}`}
              >
                <div className="text-gray-400 text-[9px]">FX RATE (GBP/USD)</div>
                <div className="font-bold text-emerald-400">+{formatGBP(attribution.components.fxGBP)}</div>
                <div className="text-[9px] text-gray-500">7.0% driver</div>
              </div>

              <div
                onClick={() => setSelectedFactor('THETA')}
                className={`p-2 border cursor-pointer transition ${selectedFactor === 'THETA' ? 'border-amber-500 bg-[#162030]' : 'border-[#1e293b] bg-[#0b0f17]'}`}
              >
                <div className="text-gray-400 text-[9px]">THETA (TIME DECAY)</div>
                <div className="font-bold text-emerald-400">+{formatGBP(attribution.components.thetaTimeDecayGBP)}</div>
                <div className="text-[9px] text-gray-500">5.5% driver</div>
              </div>

              <div
                onClick={() => setSelectedFactor('RESIDUAL')}
                className={`p-2 border cursor-pointer transition ${selectedFactor === 'RESIDUAL' ? 'border-amber-500 bg-[#162030]' : 'border-[#1e293b] bg-[#0b0f17]'}`}
              >
                <div className="text-gray-400 text-[9px]">RESIDUAL UNEXPLAINED</div>
                <div className="font-bold text-rose-400">{formatGBP(attribution.components.residualUnexplainedGBP)}</div>
                <div className="text-[9px] text-gray-500">Cross-gamma basis</div>
              </div>
            </div>
          </div>

          {/* Deep Drilldown Table: Factor -> Position -> Model -> Assumptions */}
          <div className="bg-[#111827] border border-[#1f2937] p-3 space-y-2">
            <div className="flex items-center justify-between border-b border-[#1f2937] pb-2 text-xs font-bold text-gray-200">
              <span>POSITION-LEVEL CONTRIBUTION BREAKDOWN ({selectedFactor})</span>
              <span className="text-[10px] text-gray-400">Click to view model provenance</span>
            </div>

            <table className="w-full text-left text-[11px] border-collapse">
              <thead className="bg-[#0f172a] text-gray-400">
                <tr>
                  <th className="p-2">PRODUCT NAME</th>
                  <th className="p-2">DOMINANT FACTOR DRIVER</th>
                  <th className="p-2">VALUATION MODEL</th>
                  <th className="p-2 text-right">ATTRIBUTED P&L</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1e293b]">
                {attribution.positionAttributions.map((pos, idx) => (
                  <tr key={idx} className="hover:bg-[#162030] cursor-pointer">
                    <td className="p-2 font-bold text-gray-200">{pos.productName}</td>
                    <td className="p-2 text-amber-300">{pos.dominantFactor}</td>
                    <td className="p-2 text-cyan-300 font-mono text-[10px]">{pos.modelUsed}</td>
                    <td className="p-2 text-right font-bold text-emerald-400">
                      +{formatGBP(pos.productPnlGBP)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* View 2: Financial Ledger */
        <div className="bg-[#111827] border border-[#1f2937] p-3 space-y-3">
          <div className="flex items-center justify-between border-b border-[#1f2937] pb-2 text-xs font-bold text-gray-200">
            <span>DOUBLE-ENTRY ACCOUNTING LEDGER & AUDIT TRAIL</span>
            <span className="text-[10px] text-emerald-400 font-bold">ALL LEDGER EVENTS VERIFIED</span>
          </div>

          <table className="w-full text-left text-[10px] border-collapse">
            <thead className="bg-[#0f172a] text-gray-400 border-b border-[#1f2937]">
              <tr>
                <th className="p-2">TIMESTAMP</th>
                <th className="p-2">ENTRY ID</th>
                <th className="p-2">EVENT TYPE</th>
                <th className="p-2">DEBIT ACCOUNT</th>
                <th className="p-2">CREDIT ACCOUNT</th>
                <th className="p-2">AMOUNT</th>
                <th className="p-2">AUDIT HASH</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e293b]">
              {ledgerList.map(entry => (
                <tr key={entry.entryId} className="hover:bg-[#162030]">
                  <td className="p-2 text-gray-400">{entry.timestamp}</td>
                  <td className="p-2 font-bold text-gray-200">{entry.entryId}</td>
                  <td className="p-2">
                    <span className="px-1.5 py-0.2 bg-[#1f2937] text-amber-300 border border-gray-600 font-bold">
                      {entry.eventType}
                    </span>
                  </td>
                  <td className="p-2 text-cyan-300">{entry.debitAccount}</td>
                  <td className="p-2 text-indigo-300">{entry.creditAccount}</td>
                  <td className="p-2 font-bold text-gray-100">{formatGBP(entry.amountGBP)}</td>
                  <td className="p-2 font-mono text-emerald-400 text-[9px]">{entry.auditHash}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
