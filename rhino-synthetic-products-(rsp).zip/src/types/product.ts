/**
 * RHINO SYNTHETIC PRODUCTS (RSP)
 * Core Financial Domain Types & Data Contracts
 */

export type ProductLifecycleState =
  | 'IDEA'
  | 'SPECIFICATION'
  | 'MODELLED'
  | 'VALIDATED'
  | 'PRICED'
  | 'RISK_APPROVED'
  | 'QUOTABLE'
  | 'ISSUED'
  | 'TRADED'
  | 'MARGINED'
  | 'MARKED_TO_MARKET'
  | 'STRESSED'
  | 'MATURED'
  | 'TERMINATED';

export type ProductFailureState =
  | 'NONE'
  | 'MODEL_FAILURE'
  | 'DATA_FAILURE'
  | 'VALIDATION_FAILURE'
  | 'LIQUIDITY_FAILURE'
  | 'LIMIT_BREACH'
  | 'COLLATERAL_SHORTFALL'
  | 'COUNTERPARTY_DEFAULT'
  | 'EARLY_TERMINATION';

export type AssetClass = 'CREDIT' | 'RATES' | 'EQUITY' | 'FX' | 'COMMODITIES' | 'HYBRID';

export type SettlementType = 'CASH' | 'PHYSICAL' | 'AUCTION_SETTLED' | 'SYNTHETIC_CDS_SETTLEMENT';

export type LegalStatus = 'ISDA_2002_MASTER' | 'ISDA_2014_CREDIT_DERIVATIVES' | 'GMRA' | 'BESPOKE_SIMULATED_SCHEDULE';

export interface UnderlyingFactor {
  id: string;
  name: string;
  category: 'MACRO' | 'YIELD_CURVE' | 'CREDIT_SPREAD' | 'EQUITY_VOL' | 'FX_RATE' | 'COMMODITY' | 'CORRELATION';
  currentValue: number;
  unit: string;
  shockSensitivity: number; // Sensitivity factor
}

export interface UnderlyingAsset {
  id: string;
  ticker: string;
  name: string;
  assetClass: AssetClass;
  currency: string;
  basePrice: number;
  currentSpreadOrYield: number; // bps or %
  rating?: string;
  sector?: string;
  weight: number; // percentage in basket
  recoveryRate?: number; // e.g. 0.40
}

export interface TrancheDefinition {
  id: string;
  name: string; // e.g. 'EQUITY', 'JUNIOR', 'MEZZANINE', 'SENIOR', 'SUPER_SENIOR'
  attachmentPoint: number; // fraction 0.0 to 1.0 (e.g. 0.07 for 7%)
  detachmentPoint: number; // fraction 0.0 to 1.0 (e.g. 0.15 for 15%)
  thickness: number; // detachment - attachment
  notional: number; // in GBP/USD
  couponBps: number; // annual spread in bps (e.g. 350 bps)
  upfrontFeePct?: number;
  rating: string;
  paymentPriority: number; // 1 = highest priority payment
  expectedLossPct: number; // Calculated by copula/MC
  attachmentProbability: number;
  detachmentProbability: number;
  currentLossPct: number; // Current accumulated loss under default scenario
  lossAmount: number; // In currency
  remainingNotional: number;
  presentValue: number;
  irr: number;
  cs01: number;
  correlationDelta: number;
}

export interface BarrierOrTrigger {
  id: string;
  type: 'UP_AND_OUT' | 'DOWN_AND_IN' | 'AUTOCALL_TRIGGER' | 'LOSS_ACCELERATOR' | 'CREDIT_EVENT_TRIGGER' | 'SUBORDINATION_BREACH';
  threshold: number;
  observationFrequency: 'DAILY' | 'MONTHLY' | 'QUARTERLY' | 'CONTINUOUS';
  status: 'ACTIVE' | 'BREACHED' | 'UNTRIGGERED';
  actionDescription: string;
}

export interface ValuationModelMeta {
  modelId: string;
  modelName: string;
  version: string;
  calibrationDate: string;
  marketDataSnapshot: string;
  primaryEngine: 'ONE_FACTOR_GAUSSIAN_COPULA' | 'BASE_CORRELATION_COPULA' | 'MONTE_CARLO_STRUCTURAL' | 'BLACK_76' | 'BACHELIER' | 'REDUCED_FORM_INTENSITY' | 'HULL_WHITE_LATTICE';
  challengerEngine: string;
  validationStatus: 'GREEN' | 'WATCH' | 'BREACH' | 'SUSPENDED';
  assumptions: {
    correlation: number;
    recoveryRate: number;
    hazardCurveId: string;
    volatilitySmile: string;
    discountCurve: string;
  };
}

export interface CollateralAndMarginTerms {
  initialMarginPct: number; // e.g. 4.2%
  variationMarginThreshold: number; // in GBP
  minimumTransferAmount: number;
  eligibleCollateral: ('CASH_GBP' | 'UK_GILTS' | 'US_TREASURIES' | 'AAA_BONDS' | 'EQUITIES')[];
  haircuts: Record<string, number>; // e.g. { 'UK_GILTS': 0.015, 'EQUITIES': 0.15 }
  csaAgreementId: string;
}

export interface SyntheticFinancialProduct {
  productId: string;
  version: number;
  name: string;
  productType:
    | 'SYNTHETIC_CDO'
    | 'BESPOKE_CREDIT_TRANCHE'
    | 'INDEX_TRANCHE'
    | 'FIRST_TO_DEFAULT'
    | 'NTH_TO_DEFAULT'
    | 'CREDIT_LINKED_NOTE'
    | 'VARIANCE_SWAP'
    | 'AUTOCALLABLE'
    | 'CROSS_ASSET_HYBRID'
    | 'CMS_SPREAD_STRUCTURE'
    | 'RISK_REVERSAL_FX'
    | 'COMMODITY_CRACK_SPREAD'
    | 'BESPOKE_STRUCTURED_NOTE';
  issuer: string;
  counterparty: string;
  assetClass: AssetClass;
  notional: number;
  currency: string;
  maturityYears: number;
  maturityDate: string;
  settlementType: SettlementType;
  legalStatus: LegalStatus;
  lifecycleState: ProductLifecycleState;
  failureState: ProductFailureState;
  underlyingAssets: UnderlyingAsset[];
  underlyingFactors: UnderlyingFactor[];
  tranches?: TrancheDefinition[];
  barriers: BarrierOrTrigger[];
  collateralTerms: CollateralAndMarginTerms;
  valuationModel: ValuationModelMeta;
  pricing: {
    bidPrice: number;
    midPrice: number;
    askPrice: number;
    parSpreadBps: number;
    expectedLossAmount: number;
    discountedExpectedLoss: number;
    pvProtectionLeg: number;
    pvPremiumLeg: number;
    mtm: number;
    irrPct: number;
  };
  risk: {
    delta: number;
    gamma: number;
    vega: number;
    theta: number;
    rho: number;
    cs01: number; // Credit Spread 01 (1bp spread shift)
    dv01: number; // Dollar Value 01 (1bp rate shift)
    correlationDelta: number; // 1% correlation shift
    defaultDelta: number; // 1 entity default shock
    recoveryDelta: number; // 1% recovery shift
    var95: number; // 1-day 95% Value at Risk
    var99: number; // 1-day 99% Value at Risk
    expectedShortfall: number; // CVaR
  };
  margin: {
    initialMargin: number;
    variationMargin: number;
    totalCollateralPosted: number;
    availableCollateral: number;
    headroom: number;
  };
  provenance: {
    calculationId: string;
    createdAt: string;
    computeTimeMs: number;
    hash: string;
  };
}
