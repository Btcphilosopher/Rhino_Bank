/**
 * RHINO SYNTHETIC PRODUCTS
 * Counterparties, Netting Sets, CSA & Basel Credit Risk Types
 */

export interface CounterpartyProfile {
  id: string;
  name: string;
  shortCode: string;
  jurisdiction: string;
  rating: 'AAA' | 'AA+' | 'AA' | 'AA-' | 'A+' | 'A' | 'A-' | 'BBB+' | 'BBB' | 'BBB-' | 'BB+' | 'BB' | 'B+' | 'CCC' | 'NR' | string;
  pd1yPct: number; // 1-year Probability of Default
  lgdPct: number; // Loss Given Default (e.g. 45%)
  exposureLimitGBP: number;
  grossMtmGBP: number;
  netMtmGBP: number;
  collateralHeldGBP: number;
  collateralPostedGBP: number;
  currentExposureGBP: number;
  potentialFutureExposureGBP: number; // PFE 95%
  cvaGBP: number; // Credit Valuation Adjustment
  dvaGBP: number; // Debit Valuation Adjustment
  fvaGBP: number; // Funding Valuation Adjustment
  wrongWayRiskScore: 'LOW' | 'MEDIUM' | 'HIGH';
  nettingAgreement: 'ISDA_MASTER_NETTING' | 'BILATERAL_ENFORCEABLE';
  csaType: 'DAILY_TWO_WAY_VM' | 'MONTHLY_ONE_WAY' | 'UNCOLLATERALIZED';
  csaThresholdGBP: number;
  mtaGBP: number; // Minimum Transfer Amount
  independentAmountGBP: number;
  status: 'ACTIVE' | 'WATCHLIST' | 'RESTRICTED' | 'DEFAULTED';
}

export interface NettingSet {
  nettingSetId: string;
  counterpartyId: string;
  counterpartyName: string;
  tradesCount: number;
  grossPositiveMtmGBP: number;
  grossNegativeMtmGBP: number;
  netMtmGBP: number;
  collateralBalanceGBP: number;
  netReplacementCostGBP: number;
  potentialFutureExposureGBP: number;
  cvaGBP: number;
}
