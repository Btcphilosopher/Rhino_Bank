/**
 * RHINO SYNTHETIC PRODUCTS
 * Risk, Scenarios, Stress Testing & P&L Attribution Types
 */

export interface GreeksAndSensitivities {
  delta: number;
  gamma: number;
  vega: number;
  theta: number;
  rho: number;
  cs01: number; // £/bp
  dv01: number; // £/bp
  correlationDelta: number; // £/1%
  defaultDelta: number; // £/default
  recoveryDelta: number; // £/1%
  liquidityScore: number; // 0-100
  bidAskSpreadBps: number;
}

export type ScenarioId =
  | 'BASE_CASE'
  | 'CREDIT_CRISIS'
  | 'RATES_UP_200BP'
  | 'RATES_DOWN_200BP'
  | 'VOLATILITY_SHOCK'
  | 'CORRELATION_BREAK'
  | 'GBP_CRISIS'
  | 'ENERGY_SHOCK'
  | 'GLOBAL_RECESSION'
  | 'LIQUIDITY_FREEZE'
  | 'COUNTERPARTY_DEFAULT';

export interface StressScenario {
  id: ScenarioId;
  name: string;
  description: string;
  equityShockPct: number;
  rateShockBps: number;
  creditSpreadShockBps: number;
  volShockPct: number;
  correlationShockPct: number;
  fxShockPct: number;
  defaultCountShock: number;
  recoveryShockPct: number;
  liquidityHaircutPct: number;
}

export interface ScenarioRunResult {
  scenarioId: ScenarioId;
  scenarioName: string;
  baseMtmGBP: number;
  stressedMtmGBP: number;
  pnlImpactGBP: number;
  pnlImpactPct: number;
  trancheLossesGBP: Record<string, number>;
  var99ImpactGBP: number;
  marginCallExpectedGBP: number;
  counterpartyDefaultRisk: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  factorDrivers: { factor: string; contributionGBP: number; pct: number }[];
}

export interface PnlAttributionDecomposition {
  date: string;
  totalPnlGBP: number;
  components: {
    ratesGBP: number;
    creditSpreadsGBP: number;
    volatilityGBP: number;
    correlationGBP: number;
    fxGBP: number;
    thetaTimeDecayGBP: number;
    gammaConvexityGBP: number;
    residualUnexplainedGBP: number;
  };
  positionAttributions: {
    productId: string;
    productName: string;
    productPnlGBP: number;
    dominantFactor: string;
    modelUsed: string;
  }[];
}

export interface FactorHierarchyNode {
  id: string;
  name: string;
  level: 'MACRO' | 'MARKET' | 'UNDERLYING' | 'CURVE' | 'VOLATILITY' | 'CORRELATION' | 'CREDIT' | 'LIQUIDITY';
  value: string | number;
  change24h: string;
  riskWeightPct: number;
  children?: FactorHierarchyNode[];
}
