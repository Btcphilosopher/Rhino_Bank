/**
 * RHINO SYNTHETIC PRODUCTS
 * Credit Portfolio, Hazard Curve & Copula Simulation Types
 */

export interface ReferenceCreditEntity {
  id: string;
  name: string;
  ticker: string;
  sector: string;
  country: string;
  rating: 'AAA' | 'AA+' | 'AA' | 'A+' | 'A' | 'BBB+' | 'BBB' | 'BBB-' | 'BB+' | 'BB' | 'B+' | 'CCC';
  spread5yBps: number;
  recoveryRate: number; // e.g. 0.40 (40%)
  weightPct: number;
  defaultProbability5y: number;
  hazardRate: number; // constant intensity lambda
  isDefaulted: boolean;
  defaultTimeYear?: number;
  lossGivenDefaultGBP: number;
}

export interface ReferencePortfolio {
  id: string;
  name: string;
  description: string;
  totalEntities: number;
  totalNotional: number; // e.g. 10,000,000,000 (£10bn)
  averageSpreadBps: number;
  averageRating: string;
  averageMaturityYears: number;
  sectorConcentrationPct: number;
  baseCorrelation: number; // e.g. 0.27 (27%)
  recoveryAssumption: number; // e.g. 0.40 (40%)
  entities: ReferenceCreditEntity[];
}

export interface CopulaCalculationResult {
  calculationId: string;
  model: string;
  correlation: number;
  recovery: number;
  hazardCurveVersion: string;
  portfolioLossDistribution: { lossPct: number; probability: number; cumulativeProb: number }[];
  expectedPortfolioLossPct: number;
  expectedPortfolioLossGBP: number;
  trancheResults: {
    trancheName: string;
    attachment: number;
    detachment: number;
    fairSpreadBps: number;
    expectedLossPct: number;
    expectedLossGBP: number;
    attachmentProb: number;
    detachmentProb: number;
    lossGivenDefaultGBP: number;
    cs01: number;
    correlationDelta: number;
    recoveryDelta: number;
    pvProtectionLeg: number;
    pvPremiumLeg: number;
  }[];
  challengerResult?: {
    model: string;
    expectedPortfolioLossPct: number;
    trancheDiscrepanciesBps: Record<string, number>;
  };
  computeTimeMs: number;
}

export interface DefaultEventLog {
  timestamp: string;
  step: number;
  entityId: string;
  entityName: string;
  entitySector: string;
  rating: string;
  notionalImpactGBP: number;
  recoveryAmountGBP: number;
  lossAmountGBP: number;
  cumulativeLossGBP: number;
  cumulativeLossPct: number;
  trancheImpacts: {
    trancheName: string;
    lossAbsorbedGBP: number;
    remainingNotionalGBP: number;
    impairmentPct: number;
  }[];
  waterfallNotes: string;
}
