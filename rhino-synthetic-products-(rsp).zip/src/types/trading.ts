/**
 * RHINO SYNTHETIC PRODUCTS
 * Trading Blotter, RFQ, Order Book & Double-Entry Ledger Types
 */

export type TradeStatus = 'ACTIVE' | 'PENDING_CONFIRMATION' | 'ALLOCATED' | 'NOVATED' | 'UNWOUND' | 'TERMINATED' | 'MATURED';
export type TradeAction = 'BUY_PROTECTION' | 'SELL_PROTECTION' | 'BUY_CALL' | 'BUY_PUT' | 'RECEIVE_FIXED' | 'PAY_FIXED' | 'LONG_VARIANCE';

export interface TradeBlotterEntry {
  tradeId: string;
  timestamp: string;
  productId: string;
  productName: string;
  assetClass: string;
  counterpartyId: string;
  counterpartyName: string;
  trancheName?: string;
  action: TradeAction;
  side: 'BUY' | 'SELL';
  notionalGBP: number;
  tradePricePct: number;
  spreadBps: number;
  currentMtmGBP: number;
  unrealizedPnlGBP: number;
  initialMarginGBP: number;
  variationMarginGBP: number;
  status: TradeStatus;
  bookingDesk: 'LONDON_SYNTHETICS_01' | 'BESPOKE_CREDIT_DESK' | 'CROSS_ASSET_STRUCTURING';
  legalDocumentRef: string;
}

export interface RFQQuote {
  quoteId: string;
  counterpartyId: string;
  counterpartyName: string;
  rating: string;
  bidPricePct: number;
  askPricePct: number;
  spreadBps: number;
  validUntil: string;
  status: 'ACTIVE' | 'ACCEPTED' | 'REJECTED' | 'EXPIRED';
  initialMarginRequiredGBP: number;
  confidenceScore: number;
}

export interface RFQItem {
  rfqId: string;
  timestamp: string;
  productName: string;
  assetClass: string;
  notionalGBP: number;
  maturityYears: number;
  structureSummary: string;
  quotes: RFQQuote[];
  status: 'OPEN' | 'TRADED' | 'EXPIRED' | 'CANCELLED';
  selectedQuoteId?: string;
}

export type LedgerEventType =
  | 'TRADE_EXECUTION'
  | 'PREMIUM_PAYMENT'
  | 'PREMIUM_RECEIPT'
  | 'COLLATERAL_DEPOSIT'
  | 'COLLATERAL_WITHDRAWAL'
  | 'VARIATION_MARGIN_CALL'
  | 'MTM_REVALUATION'
  | 'CREDIT_DEFAULT_LOSS'
  | 'RECOVERY_SETTLEMENT'
  | 'TRANCHE_COUPON_DISTRIBUTION'
  | 'TERMINATION_FEE'
  | 'NOVATION_TRANSFER';

export interface LedgerEntry {
  entryId: string;
  timestamp: string;
  eventType: LedgerEventType;
  tradeId?: string;
  productId?: string;
  debitAccount: string;
  creditAccount: string;
  amountGBP: number;
  currency: 'GBP' | 'USD' | 'EUR';
  description: string;
  auditHash: string;
  settled: boolean;
}
