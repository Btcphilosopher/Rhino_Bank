/**
 * RHINO SYNTHETIC PRODUCTS
 * Margin Engine, Collateral Assets & Haircut Optimization Types
 */

export type CollateralAssetType =
  | 'CASH_GBP'
  | 'CASH_USD'
  | 'UK_GILTS_10Y'
  | 'UK_GILTS_5Y'
  | 'US_TREASURIES_10Y'
  | 'GERMAN_BUNDS'
  | 'AAA_SUPRANATIONAL'
  | 'CORP_BONDS_AA'
  | 'FTSE_100_EQUITIES';

export interface CollateralAsset {
  id: string;
  type: CollateralAssetType;
  name: string;
  nominalGBP: number;
  marketValueGBP: number;
  haircutPct: number;
  haircutValueGBP: number;
  currency: string;
  liquidityTier: 'TIER_1_CASH' | 'TIER_2_SOVEREIGN' | 'TIER_3_HIGH_GRADE' | 'TIER_4_EQUITY';
  yieldPct: number;
  costOfPledgingBps: number;
  allocatedAmountGBP: number;
}

export interface CollateralOptimizationResult {
  totalRequiredMarginGBP: number;
  allocatedCollateralGBP: number;
  postHaircutValueGBP: number;
  blendedFundingCostBps: number;
  haircutEfficiencyPct: number;
  allocationBreakdown: {
    assetType: CollateralAssetType;
    assetName: string;
    pledgedValueGBP: number;
    effectiveCollateralGBP: number;
    haircutPct: number;
    fundingCostGBP: number;
  }[];
  headroomGBP: number;
}

export interface MarginCallRecord {
  callId: string;
  timestamp: string;
  counterpartyId: string;
  counterpartyName: string;
  direction: 'OUTBOUND_DEMAND' | 'INBOUND_RECEIVED';
  imRequiredGBP: number;
  vmRequiredGBP: number;
  collateralPledgedGBP: number;
  netDiscrepancyGBP: number;
  status: 'PENDING_SETTLEMENT' | 'MATCHED' | 'DISPUTED' | 'SETTLED';
  disputeReason?: string;
}
