/**
 * RHINO SYNTHETIC PRODUCTS
 * Model Risk Governance, Validation & Digital Twin Types
 */

export interface ModelRiskRecord {
  modelId: string;
  name: string;
  category: 'STRUCTURED_CREDIT' | 'INTEREST_RATES' | 'EQUITY_VOLATILITY' | 'CORRELATION_COPULA' | 'MARGIN_SIMM' | 'COUNTERPARTY_CVA';
  version: string;
  primaryEngine: string;
  challengerEngine: string;
  status: 'GREEN' | 'WATCH' | 'BREACH' | 'SUSPENDED';
  lastValidatedDate: string;
  dataSnapshotTimestamp: string;
  calibrationErrorBps: number;
  backtestPnlErrorPct: number;
  challengerDiscrepancyBps: number;
  maxAllowableDiscrepancyBps: number;
  approvedBy: string;
  nextAuditDate: string;
  assumptions: string[];
  exceptionsCount: number;
}

export interface DigitalTwinAudit {
  productId: string;
  productVersion: number;
  digitalTwinUid: string;
  timestamp: string;
  economicTermsHash: string;
  legalTermsHash: string;
  modelDefinitionHash: string;
  marketDataSnapshotHash: string;
  lastCalculatedMtmGBP: number;
  lastCalculatedIM_GBP: number;
  ledgerIntegrityVerified: boolean;
  provenanceLogs: {
    event: string;
    timestamp: string;
    operatorOrSystem: string;
    detail: string;
  }[];
}
