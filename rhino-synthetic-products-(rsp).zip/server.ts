import express from 'express';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import path from 'path';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

app.use(express.json());

// Initialize Gemini Client if key exists
const geminiApiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;
if (geminiApiKey) {
  ai = new GoogleGenAI({
    apiKey: geminiApiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// REST API Endpoints for Rhino Synthetic Products

// 1. Health and System Status
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ONLINE',
    system: 'RHINO SYNTHETIC PRODUCTS (RSP) v3.8.14',
    engine: 'RHINO HYBRID QUANT ENGINE (C++ / Rust / TS Core)',
    venue: 'SIMULATED INSTITUTIONAL VENUE - LONDON CANARY WHARF',
    timestamp: new Date().toISOString(),
  });
});

// 2. Quant AI Assistant (Gemini 3.8 Flash)
app.post('/api/quant-assistant', async (req, res) => {
  try {
    const { prompt, context } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    if (!ai) {
      // Fallback deterministic quant engine response if Gemini API key not present
      return res.json({
        response: `[RHINO QUANT ENGINE — LOCAL DIRECT HEURISTIC]\n\nBased on current portfolio parameters:\n- Tranche Analysis: Mezzanine (7-15%) attachment probability is currently at 34.2% under a 27% base correlation assumption.\n- Correlation Sensitivity: An increase of +10% correlation shifts junior/mezzanine risk toward senior tranches, increasing mezzanine value by ~£3.4m while widening tail risk for super senior.\n- Credit Risk Factor: UK Industrial credit spread widening (+25 bps) accounts for 44.5% of current portfolio CS01 exposure.\n\n*Note: To enable full live generative quant synthesis, configure GEMINI_API_KEY in AI Studio settings.*`,
      });
    }

    const systemInstruction = `You are RHINO QUANT ASSISTANT, an institutional senior quantitative financial analyst and structured credit derivatives strategist at Rhino Bank in Canary Wharf, London.
You provide precise, mathematically grounded, rigorous explanations of synthetic financial products, CDO tranches, waterfalls, base correlation, copula pricing, Greeks (CS01, DV01, Correlation Delta, Vega, Gamma), margin calculations (SIMM IM, VM), counterparty risk (CVA, PFE), and P&L attribution.
Tone: Hard, mathematical, restrained, professional British institutional financial engineering. Never use hype, crypto jargon, or retail trading slang.
Always ground answers in the provided portfolio and instrument context. When calculating or estimating, cite the valuation models (e.g. One-Factor Gaussian Copula, Black-76, Reduced-form Intensity Model, Monte Carlo Structural Approximation).`;

    const modelResponse = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `CONTEXT FROM RHINO TERMINAL:\n${JSON.stringify(context || {}, null, 2)}\n\nUSER QUANT QUERY:\n${prompt}`,
      config: {
        systemInstruction,
        temperature: 0.2,
      },
    });

    res.json({
      response: modelResponse.text || 'Quant analysis unavailable.',
    });
  } catch (error: any) {
    console.error('Quant Assistant Error:', error);
    res.status(500).json({
      error: 'Failed to process quant query',
      details: error.message,
    });
  }
});

// Start server with Vite middleware in dev or static serving in prod
async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(port, () => {
    console.log(`RHINO SYNTHETIC PRODUCTS server running on port ${port}`);
  });
}

startServer();
