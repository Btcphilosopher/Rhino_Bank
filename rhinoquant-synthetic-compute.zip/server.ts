import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import {
  INITIAL_PROVIDERS,
  INITIAL_PACKAGES,
  INITIAL_PURCHASE_ORDERS,
  INITIAL_METERING_RECORDS,
  INITIAL_AUDIT_EVENTS,
  SEED_VERSION
} from './src/state/initialData.ts';
import { optimizeCapacityAllocation, calculateEconomics, calculateBackingSummary } from './src/engines/capacityOptimizer.ts';
import { synthesizeInfrastructureDesign } from './src/engines/infrastructureSynthesis.ts';
import { performReconciliation } from './src/engines/meteringReconciliation.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

  app.use(express.json());

  // In-memory persistent state for API operations
  let packages = [...INITIAL_PACKAGES];
  let providers = [...INITIAL_PROVIDERS];
  let purchaseOrders = [...INITIAL_PURCHASE_ORDERS];
  let meteringRecords = [...INITIAL_METERING_RECORDS];
  let auditEvents = [...INITIAL_AUDIT_EVENTS];

  // REST API v1 Endpoints
  // 1. System
  app.get('/api/v1/system/health', (_req, res) => {
    res.json({
      status: 'HEALTHY',
      service: 'RhinoQuant Synthetic Compute',
      version: SEED_VERSION,
      timestamp: new Date().toISOString(),
      uptimeSeconds: process.uptime(),
    });
  });

  app.get('/api/v1/system/capabilities', (_req, res) => {
    res.json({
      multiProviderAggregation: true,
      physicalInfrastructureSynthesis: true,
      constraintOptimisationEngine: true,
      dualSignatureGovernance: true,
      realtimeMeteringReconciliation: true,
      supportedAccelerators: [
        'NVIDIA_H100_SXM5_80GB',
        'NVIDIA_H200_SXM5_141GB',
        'NVIDIA_B200_NVL_192GB',
        'NVIDIA_GB200_NVL72',
      ],
      supportedRegions: [
        'US-East (Virginia)',
        'US-West (Phoenix)',
        'EU-Central (Frankfurt)',
        'Nordic-Green (Reykjavik)',
      ],
    });
  });

  // 2. Capacity
  app.get('/api/v1/capacity/inventory', (_req, res) => {
    res.json(providers);
  });

  app.get('/api/v1/capacity/providers', (_req, res) => {
    res.json(providers.map((p) => ({ id: p.id, name: p.providerName, region: p.region, availableUnits: p.availableUnits })));
  });

  app.post('/api/v1/capacity/match', (req, res) => {
    const workload = req.body;
    const result = optimizeCapacityAllocation(workload, providers);
    res.json(result);
  });

  // 3. Packages
  app.get('/api/v1/packages', (_req, res) => {
    res.json(packages);
  });

  app.get('/api/v1/packages/:package_id', (req, res) => {
    const pkg = packages.find((p) => p.id === req.params.package_id);
    if (!pkg) return res.status(404).json({ error: 'Package not found' });
    res.json(pkg);
  });

  app.post('/api/v1/packages', (req, res) => {
    const { name, customer, workload } = req.body;
    const optResult = optimizeCapacityAllocation(workload, providers);

    let infraDesign = undefined;
    if (optResult.shortfall.hasShortfall) {
      infraDesign = synthesizeInfrastructureDesign({
        shortfallGPUs: optResult.shortfall.shortfallGPUs,
        acceleratorType: workload.acceleratorType,
        region: workload.region,
      });
    }

    const economics = calculateEconomics(
      workload,
      optResult.totalExistingOpexUSD,
      infraDesign ? infraDesign.capexTotalUSD : 0,
      infraDesign ? infraDesign.totalPowerDemandKW : 0
    );

    const backing = calculateBackingSummary(
      workload.acceleratorCount,
      workload.durationHours,
      optResult.allocations,
      optResult.shortfall.hasShortfall
    );

    const packageId = `PKG-${Math.floor(100000 + Math.random() * 900000)}`;
    economics.packageId = packageId;
    backing.packageId = packageId;

    const startDate = new Date();
    startDate.setDate(startDate.getDate() + 7);
    const endDate = new Date(startDate);
    endDate.setHours(endDate.getHours() + workload.durationHours);

    const newPkg = {
      id: packageId,
      packageName: name || 'Custom Synthetic Package',
      customerName: customer || 'Institutional Client',
      workload,
      status: 'OPTIMIZED',
      version: 1,
      createdAt: new Date().toISOString(),
      targetStartDate: startDate.toISOString().split('T')[0],
      targetCompletionDate: endDate.toISOString().split('T')[0],
      providerAllocations: optResult.allocations,
      shortfall: optResult.shortfall,
      infrastructureDesign: infraDesign,
      associatedPOIds: [],
      economics,
      backing,
      notes: 'Assembled via RhinoQuant v1 API',
    };

    packages.unshift(newPkg as any);
    res.status(201).json(newPkg);
  });

  app.get('/api/v1/packages/:package_id/economics', (req, res) => {
    const pkg = packages.find((p) => p.id === req.params.package_id);
    if (!pkg) return res.status(404).json({ error: 'Package not found' });
    res.json(pkg.economics);
  });

  app.get('/api/v1/packages/:package_id/backing', (req, res) => {
    const pkg = packages.find((p) => p.id === req.params.package_id);
    if (!pkg) return res.status(404).json({ error: 'Package not found' });
    res.json(pkg.backing);
  });

  // 4. Procurement & POs
  app.get('/api/v1/procurement/purchase-orders', (_req, res) => {
    res.json(purchaseOrders);
  });

  app.get('/api/v1/procurement/purchase-orders/:po_id', (req, res) => {
    const po = purchaseOrders.find((p) => p.poId === req.params.po_id);
    if (!po) return res.status(404).json({ error: 'PO not found' });
    res.json(po);
  });

  // 5. Reconciliation
  app.get('/api/v1/reconciliation/summary', (_req, res) => {
    const summary = performReconciliation(meteringRecords);
    res.json(summary);
  });

  app.get('/api/v1/audit/events', (_req, res) => {
    res.json(auditEvents);
  });

  // Mount Vite development middlewares or serve static build
  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`RhinoQuant Synthetic Compute server running at http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
