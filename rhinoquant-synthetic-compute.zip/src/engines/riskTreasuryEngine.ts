import { RiskAlert, ComputePackage, PurchaseOrder } from '../types';

export interface StressScenarioConfig {
  electricityPriceShockPct: number; // e.g. +25%
  hardwareCostShockPct: number; // e.g. +20%
  shipmentDelayDays: number; // e.g. 90 days
  providerCapacityLossPct: number; // e.g. -30%
  utilizationDropPct: number; // e.g. -20%
}

export interface StressSimulationResult {
  scenarioName: string;
  initialPortfolioMarginUSD: number;
  stressedPortfolioMarginUSD: number;
  marginErosionUSD: number;
  marginErosionPct: number;
  liquidityImpactUSD: number;
  delayedPackageCount: number;
  unbackedObligationIncreaseHours: number;
  criticalAlertsGenerated: RiskAlert[];
}

export function evaluateStressScenario(
  packages: ComputePackage[],
  purchaseOrders: PurchaseOrder[],
  config: StressScenarioConfig
): StressSimulationResult {
  let initialMargin = 0;
  let stressedMargin = 0;
  let delayedPackages = 0;
  let unbackedHoursDelta = 0;
  const criticalAlerts: RiskAlert[] = [];

  packages.forEach((pkg) => {
    const baseMargin = pkg.economics.grossMarginUSD;
    initialMargin += baseMargin;

    // Apply power shock
    const extraPowerOpex = pkg.economics.powerOpexUSD * (config.electricityPriceShockPct / 100);

    // Apply hardware CapEx shock (spread over contract)
    const extraCapex = (pkg.economics.physicalInfrastructureCapexUSD * (config.hardwareCostShockPct / 100)) * 0.25;

    // Apply provider capacity loss: if provider capacity is cut, shortfall must be filled via spot market (+45% premium)
    const providerReplacementPenalty = pkg.providerAllocations.reduce((acc, a) => {
      const lostHours = a.gpuHours * (config.providerCapacityLossPct / 100);
      return acc + (lostHours * a.unitCostUSD * 0.45);
    }, 0);

    const totalErosion = extraPowerOpex + extraCapex + providerReplacementPenalty;
    const pkgStressedMargin = baseMargin - totalErosion;
    stressedMargin += pkgStressedMargin;

    if (config.shipmentDelayDays > 30 && pkg.shortfall.hasShortfall) {
      delayedPackages += 1;
      unbackedHoursDelta += pkg.shortfall.shortfallGPUs * pkg.workload.durationHours;
      criticalAlerts.push({
        id: `ALT-STR-${pkg.id}`,
        severity: 'CRITICAL',
        category: 'SUPPLY_CHAIN',
        title: `Delivery Compromised: ${pkg.packageName}`,
        description: `Simulated supplier delay of ${config.shipmentDelayDays} days breaches SLA completion window (${pkg.targetCompletionDate}). Backing tier downgraded to AT_RISK.`,
        affectedEntityId: pkg.id,
        entityType: 'PACKAGE',
        timestamp: new Date().toISOString(),
        recommendedAction: 'Invoke forward capacity reservation hedges or negotiate staged phased delivery.',
      });
    }

    if (pkgStressedMargin < 0) {
      criticalAlerts.push({
        id: `ALT-NEG-${pkg.id}`,
        severity: 'HIGH',
        category: 'MARGIN_LEAKAGE',
        title: `Negative Unit Margin: ${pkg.packageName}`,
        description: `Under ${config.electricityPriceShockPct}% power shock, package margins invert to -$${Math.abs(Math.round(pkgStressedMargin)).toLocaleString()}.`,
        affectedEntityId: pkg.id,
        entityType: 'PACKAGE',
        timestamp: new Date().toISOString(),
        recommendedAction: 'Trigger power-index pass-through contractual clause.',
      });
    }
  });

  const marginErosionUSD = initialMargin - stressedMargin;
  const marginErosionPct = initialMargin > 0 ? Math.round((marginErosionUSD / initialMargin) * 1000) / 10 : 0;
  const liquidityImpactUSD = marginErosionUSD + (unbackedHoursDelta * 2.2);

  return {
    scenarioName: `Compound Macro Stress (Power +${config.electricityPriceShockPct}%, HW +${config.hardwareCostShockPct}%, Delay +${config.shipmentDelayDays}d)`,
    initialPortfolioMarginUSD: Math.round(initialMargin),
    stressedPortfolioMarginUSD: Math.round(stressedMargin),
    marginErosionUSD: Math.round(marginErosionUSD),
    marginErosionPct,
    liquidityImpactUSD: Math.round(liquidityImpactUSD),
    delayedPackageCount: delayedPackages,
    unbackedObligationIncreaseHours: unbackedHoursDelta,
    criticalAlertsGenerated: criticalAlerts,
  };
}
