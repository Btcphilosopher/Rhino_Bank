import {
  AcceleratorType,
  BOMItem,
  InfrastructureDesign,
  GeographicRegion
} from '../types';

export interface InfrastructureDesignOptions {
  shortfallGPUs: number;
  acceleratorType: AcceleratorType;
  region: GeographicRegion;
  designPreference?: 'BALANCED' | 'LOWEST_CAPEX' | 'FASTEST_DEPLOYMENT' | 'HIGHEST_DENSITY';
}

/**
 * Designs physical high-performance compute clusters to resolve capacity shortfalls.
 * Computes exact thermodynamic, electrical, mechanical, and network fabric parameters.
 */
export function synthesizeInfrastructureDesign(
  options: InfrastructureDesignOptions
): InfrastructureDesign {
  const { shortfallGPUs, acceleratorType } = options;

  // GPUs per physical server node (Standard 8-way HGX / SXM5 or 4-way PCIe)
  const gpusPerServer = acceleratorType === 'NVIDIA_GB200_NVL72' ? 72 : 8;
  const serverNodeCount = Math.max(1, Math.ceil(shortfallGPUs / gpusPerServer));
  const effectiveGPUs = serverNodeCount * gpusPerServer;

  // Rack packaging: Typically 4 server nodes per 48U rack (approx 10U per 8-GPU chassis + cabling + switches)
  // For GB200 NVL72, 1 integrated rack per 72 GPUs
  const serversPerRack = acceleratorType === 'NVIDIA_GB200_NVL72' ? 1 : 4;
  const rackCount = Math.max(1, Math.ceil(serverNodeCount / serversPerRack));

  // Thermal & Electrical modeling (Watts)
  // H100 8-way server draws approx 10.2 kW peak; H200 draws 10.5 kW; GB200 rack draws 120 kW
  let serverDrawKw = 10.2;
  let serverMassKg = 135; // kg per 4U/8U server chassis
  let serverCostUSD = 295000;
  let serverModel = 'Supermicro GPU SuperServer SYS-821GE-TNHR (8x H100 SXM5 80GB)';

  if (acceleratorType === 'NVIDIA_H200_SXM5_141GB') {
    serverDrawKw = 10.8;
    serverMassKg = 138;
    serverCostUSD = 345000;
    serverModel = 'Dell PowerEdge XE9680 (8x H200 SXM5 141GB)';
  } else if (acceleratorType === 'NVIDIA_B200_NVL_192GB') {
    serverDrawKw = 12.5;
    serverMassKg = 145;
    serverCostUSD = 410000;
    serverModel = 'Celestica Apex NVL HGX B200 (8x B200 NVL 192GB)';
  } else if (acceleratorType === 'NVIDIA_GB200_NVL72') {
    serverDrawKw = 120.0;
    serverMassKg = 1450;
    serverCostUSD = 2850000;
    serverModel = 'NVIDIA GB200 NVL72 Integrated Liquid Rack (72x Blackwell GPUs)';
  }

  // Network switches: Quantum-2 800G InfiniBand (64 ports per switch, non-blocking fat-tree leaf-spine)
  const leafSwitchCount = Math.max(2, Math.ceil((serverNodeCount * 8) / 32));
  const spineSwitchCount = Math.max(2, Math.ceil(leafSwitchCount / 2));
  const totalSwitches = leafSwitchCount + spineSwitchCount;

  // Power Demand
  const computePowerKW = serverNodeCount * serverDrawKw;
  const networkPowerKW = totalSwitches * 1.8;
  const cduPumpPowerKW = rackCount * 2.5;
  const totalPowerDemandKW = Math.round((computePowerKW + networkPowerKW + cduPumpPowerKW) * 10) / 10;
  const peakPowerDemandKW = Math.round(totalPowerDemandKW * 1.15 * 10) / 10;

  // Cooling Capacity Required (kW heat rejection = 98% of electrical power)
  const coolingCapacityRequiredKW = Math.round(peakPowerDemandKW * 0.98 * 10) / 10;

  // Physical mass and floor loading
  const totalServerMass = serverNodeCount * serverMassKg;
  const rackFrameMass = rackCount * 180;
  const switchMass = totalSwitches * 28;
  const cduMass = rackCount * 220;
  const totalMassKg = totalServerMass + rackFrameMass + switchMass + cduMass;
  // Standard data center rack footprint: ~2.2 m² including hot/cold aisle clearance
  const floorAreaSqm = rackCount * 2.2;
  const floorLoadKgPerSqm = Math.round(totalMassKg / floorAreaSqm);

  // Hierarchical Bill of Materials (BOM)
  const bom: BOMItem[] = [
    {
      sku: 'SRV-GPU-8X',
      componentCategory: 'accelerator_server',
      name: serverModel,
      manufacturer: acceleratorType === 'NVIDIA_H200_SXM5_141GB' ? 'Dell Technologies' : 'Supermicro',
      quantity: serverNodeCount,
      unit: 'Server Node',
      leadTimeWeeks: 4,
      unitCostUSD: serverCostUSD,
      totalCostUSD: serverNodeCount * serverCostUSD,
      powerDrawWattsPerUnit: Math.round(serverDrawKw * 1000),
      massKgPerUnit: serverMassKg,
      warrantyYears: 3,
      supplierCandidates: ['Supermicro Enterprise Direct', 'Dell Technologies OEM', 'Celestica Global'],
      selectedSupplier: 'Supermicro Enterprise Direct',
      technicalCompatibilityValidated: true,
    },
    {
      sku: 'NET-IB-Q2-800G',
      componentCategory: 'switch_fabric',
      name: 'NVIDIA Quantum-2 QM9700 800Gb/s 64-Port InfiniBand Managed Switch',
      manufacturer: 'NVIDIA Networking',
      quantity: totalSwitches,
      unit: 'Switch',
      leadTimeWeeks: 3,
      unitCostUSD: 42500,
      totalCostUSD: totalSwitches * 42500,
      powerDrawWattsPerUnit: 1800,
      massKgPerUnit: 28,
      warrantyYears: 5,
      supplierCandidates: ['NVIDIA Networking Direct', 'World Wide Technology', 'Wiwynn'],
      selectedSupplier: 'NVIDIA Networking Direct',
      technicalCompatibilityValidated: true,
    },
    {
      sku: 'OPT-TRANS-800G',
      componentCategory: 'optical_transceiver',
      name: '800G OSFP 2xFR4 Single-Mode Optical Transceivers (SMF 500m)',
      manufacturer: 'Coherent Corp',
      quantity: serverNodeCount * 8 * 2,
      unit: 'Transceiver',
      leadTimeWeeks: 2,
      unitCostUSD: 980,
      totalCostUSD: serverNodeCount * 8 * 2 * 980,
      powerDrawWattsPerUnit: 14,
      massKgPerUnit: 0.15,
      warrantyYears: 3,
      supplierCandidates: ['Coherent Corp', 'Innolight Technology', 'Finisar'],
      selectedSupplier: 'Coherent Corp',
      technicalCompatibilityValidated: true,
    },
    {
      sku: 'CAB-MPO-MTP32',
      componentCategory: 'cabling_harness',
      name: 'High-Density MTP/MPO-32 Pre-terminated Trunk Fiber Cabling (15m)',
      manufacturer: 'Panduit',
      quantity: serverNodeCount * 8,
      unit: 'Assembly',
      leadTimeWeeks: 1,
      unitCostUSD: 380,
      totalCostUSD: serverNodeCount * 8 * 380,
      powerDrawWattsPerUnit: 0,
      massKgPerUnit: 1.2,
      warrantyYears: 10,
      supplierCandidates: ['Panduit', 'Corning Optical', 'CommScope'],
      selectedSupplier: 'Panduit',
      technicalCompatibilityValidated: true,
    },
    {
      sku: 'ENC-48U-HEAVY',
      componentCategory: 'rack_enclosure',
      name: 'Rittal TS IT Pro 48U Seismic Server Cabinet (1500kg Dynamic Load)',
      manufacturer: 'Rittal GmbH',
      quantity: rackCount,
      unit: 'Cabinet',
      leadTimeWeeks: 2,
      unitCostUSD: 5200,
      totalCostUSD: rackCount * 5200,
      powerDrawWattsPerUnit: 0,
      massKgPerUnit: 180,
      warrantyYears: 10,
      supplierCandidates: ['Rittal GmbH', 'Schneider Electric', 'Vertiv Corp'],
      selectedSupplier: 'Rittal GmbH',
      technicalCompatibilityValidated: true,
    },
    {
      sku: 'CDU-DLC-120KW',
      componentCategory: 'cdu_cooling',
      name: 'Vertiv Liebert XDU 120kW In-Rack Coolant Distribution Unit (N+1 Redundant Pumps)',
      manufacturer: 'Vertiv Corp',
      quantity: Math.max(1, Math.ceil(coolingCapacityRequiredKW / 100)),
      unit: 'CDU Unit',
      leadTimeWeeks: 5,
      unitCostUSD: 48000,
      totalCostUSD: Math.max(1, Math.ceil(coolingCapacityRequiredKW / 100)) * 48000,
      powerDrawWattsPerUnit: 2500,
      massKgPerUnit: 220,
      warrantyYears: 5,
      supplierCandidates: ['Vertiv Corp', 'CoolIT Systems', 'Motivair Corporation'],
      selectedSupplier: 'Vertiv Corp',
      technicalCompatibilityValidated: true,
    },
    {
      sku: 'PDU-3P-63A',
      componentCategory: 'pdu_power_strip',
      name: 'Server Technology PRO4X 3-Phase 400V 63A Intelligent Managed Rack PDU',
      manufacturer: 'Legrand / Server Tech',
      quantity: rackCount * 2, // 2N feed per rack
      unit: 'PDU Pair',
      leadTimeWeeks: 2,
      unitCostUSD: 3400,
      totalCostUSD: rackCount * 2 * 3400,
      powerDrawWattsPerUnit: 25,
      massKgPerUnit: 14,
      warrantyYears: 5,
      supplierCandidates: ['Legrand', 'Schneider Electric', 'Raritan'],
      selectedSupplier: 'Legrand',
      technicalCompatibilityValidated: true,
    },
    {
      sku: 'SVC-COMMISSION-L4',
      componentCategory: 'commissioning_service',
      name: 'Level-4 Mission Critical Commissioning, Burn-in & NCCL Stress Testing (72h)',
      manufacturer: 'RhinoQuant Infrastructure Ops',
      quantity: 1,
      unit: 'Engagement',
      leadTimeWeeks: 1,
      unitCostUSD: 35000 + serverNodeCount * 2500,
      totalCostUSD: 35000 + serverNodeCount * 2500,
      powerDrawWattsPerUnit: 0,
      massKgPerUnit: 0,
      warrantyYears: 1,
      supplierCandidates: ['RhinoQuant Infrastructure Ops Certified'],
      selectedSupplier: 'RhinoQuant Infrastructure Ops Certified',
      technicalCompatibilityValidated: true,
    },
  ];

  const capexHardwareUSD = bom
    .filter((b) => b.componentCategory !== 'commissioning_service')
    .reduce((acc, b) => acc + b.totalCostUSD, 0);

  const capexInstallationUSD = bom
    .filter((b) => b.componentCategory === 'commissioning_service')
    .reduce((acc, b) => acc + b.totalCostUSD, 0) + (rackCount * 7500); // facility electrical cabling

  const capexTotalUSD = capexHardwareUSD + capexInstallationUSD;
  const maxLeadTime = Math.max(...bom.map((b) => b.leadTimeWeeks));

  const facilityReadinessCheck = {
    powerAvailable: totalPowerDemandKW <= 450, // Substation check: 450kW reserve threshold
    cduLoopReady: true,
    floorLoadingFeasible: floorLoadKgPerSqm <= 1800, // Standard raised floor rating is 1800-2000 kg/m²
    fiberPathClear: true,
    overallPass: totalPowerDemandKW <= 450 && floorLoadKgPerSqm <= 1800,
    notes: totalPowerDemandKW <= 450
      ? `Facility electrical envelope verified: ${totalPowerDemandKW} kW demand within dedicated 500 kW facility substation tap. Floor loading (${floorLoadKgPerSqm} kg/m²) compliant with 1800 kg/m² seismic rating.`
      : `Warning: Total power ${totalPowerDemandKW} kW exceeds single row electrical drop limit of 450 kW. Staged breaker upgrade required.`,
  };

  return {
    id: `DSG-${Math.floor(100000 + Math.random() * 900000)}`,
    designName: `Cluster Synthesis: ${effectiveGPUs}x ${acceleratorType.replace(/_/g, ' ')}`,
    architectureTier:
      acceleratorType === 'NVIDIA_GB200_NVL72'
        ? 'NVIDIA_GB200_NVL72'
        : acceleratorType === 'NVIDIA_H200_SXM5_141GB'
        ? 'NVIDIA_HGX_H200'
        : 'NVIDIA_HGX_H100',
    targetGPUExpansion: effectiveGPUs,
    serverNodeCount,
    rackCount,
    totalPowerDemandKW,
    peakPowerDemandKW,
    coolingCapacityRequiredKW,
    coolingType: 'DIRECT_LIQUID_COOLING',
    cduRedundancy: 'N+1',
    totalMassKg,
    floorLoadKgPerSqm,
    networkFabricTier: 'Quantum-2 800G Non-Blocking Fat-Tree (1:1 Oversubscription)',
    oversubscriptionRatio: '1:1 Non-Blocking',
    bom,
    capexHardwareUSD,
    capexInstallationUSD,
    capexTotalUSD,
    estimatedLeadTimeWeeks: maxLeadTime,
    facilityReadinessCheck,
  };
}
