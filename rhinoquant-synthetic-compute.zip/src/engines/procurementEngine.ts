import { PurchaseOrder, POStatus, BOMItem, SupplierQuote } from '../types';

export const PO_LIFECYCLE_STEPS: POStatus[] = [
  'REQUIREMENT',
  'BOM_DRAFT',
  'TECHNICAL_REVIEW',
  'RFQ_ISSUED',
  'QUOTES_RECEIVED',
  'COMMERCIAL_REVIEW',
  'APPROVAL_PENDING',
  'PO_APPROVED',
  'PO_SUBMITTED',
  'SUPPLIER_CONFIRMED',
  'IN_TRANSIT',
  'RECEIVED',
  'INSTALLED',
  'COMMISSIONED',
  'ACCEPTED',
];

export function generateQuotesForBOM(bomItems: BOMItem[]): SupplierQuote[] {
  const quotes: SupplierQuote[] = [];

  bomItems.forEach((item, idx) => {
    // Generate 2-3 supplier quotations per major item
    const suppliers = item.supplierCandidates.length > 0
      ? item.supplierCandidates
      : ['Supermicro OEM', 'Dell OEM', 'NVIDIA Enterprise'];

    suppliers.forEach((supplier, sIdx) => {
      // Vary price and lead time deterministically
      const priceVariance = 1 + (sIdx === 0 ? 0 : sIdx === 1 ? -0.03 : 0.04);
      const leadVariance = sIdx === 0 ? 0 : sIdx === 1 ? 1 : -1;
      const unitPrice = Math.round(item.unitCostUSD * priceVariance);

      const expDate = new Date();
      expDate.setDate(expDate.getDate() + 14);

      quotes.push({
        quoteId: `QTE-${idx + 1}-${sIdx + 1}`,
        rfqId: `RFQ-${item.sku}`,
        supplierName: supplier,
        bomSku: item.sku,
        itemName: item.name,
        quantity: item.quantity,
        quotedUnitPriceUSD: unitPrice,
        quotedTotalUSD: unitPrice * item.quantity,
        leadTimeWeeks: Math.max(1, item.leadTimeWeeks + leadVariance),
        paymentTerms: sIdx === 1 ? 'Net 30 with 20% deposit' : 'Net 45 upon delivery',
        quoteExpiryDate: expDate.toISOString().split('T')[0],
        warrantyTerms: `${item.warrantyYears} Years 24/7 NBD On-Site Replacement`,
        confidenceScore: sIdx === 0 ? 98 : sIdx === 1 ? 92 : 89,
        status: sIdx === 0 ? 'SELECTED' : 'PENDING',
      });
    });
  });

  return quotes;
}

export function createPurchaseOrderFromBOM(
  bomItems: BOMItem[],
  packageId?: string,
  designId?: string
): PurchaseOrder {
  const totalAmount = bomItems.reduce((acc, b) => acc + b.totalCostUSD, 0);
  const maxLeadTime = Math.max(...bomItems.map((b) => b.leadTimeWeeks));

  const deliveryDate = new Date();
  deliveryDate.setDate(deliveryDate.getDate() + maxLeadTime * 7);

  const poItems = bomItems.map((b) => ({
    sku: b.sku,
    description: `${b.name} (${b.manufacturer})`,
    quantity: b.quantity,
    unitPriceUSD: b.unitCostUSD,
    totalUSD: b.totalCostUSD,
  }));

  const milestones = [
    { milestone: 'BOM Technical Validation & Compatibility Signoff', completed: true, timestamp: new Date().toISOString() },
    { milestone: 'Dual Authorisation Executed (Infra & Finance)', completed: false },
    { milestone: 'Supplier Binding Order Transmission', completed: false },
    { milestone: 'Factory Acceptance Testing & Dispatch', completed: false },
    { milestone: 'Data Centre Delivery & Physical Inspection', completed: false },
    { milestone: 'Rack Mounting, Power Connection & CDU Loop Hookup', completed: false },
    { milestone: '72h NCCL Cluster Burn-in & Workload Acceptance', completed: false },
  ];

  return {
    poId: `PO-${Math.floor(100000 + Math.random() * 900000)}`,
    packageId,
    infrastructureDesignId: designId,
    poNumber: `RQ-PO-2026-${Math.floor(1000 + Math.random() * 9000)}`,
    supplierName: 'Consolidated Infrastructure Consortium (Supermicro / Vertiv / Coherent)',
    currency: 'USD',
    totalAmountUSD: totalAmount,
    itemCount: bomItems.length,
    items: poItems,
    status: 'APPROVAL_PENDING',
    leadTimeWeeks: maxLeadTime,
    estimatedDeliveryDate: deliveryDate.toISOString().split('T')[0],
    createdDate: new Date().toISOString().split('T')[0],
    requiresDualApproval: totalAmount > 250000,
    approvalSignatures: [
      {
        role: 'HEAD_OF_INFRASTRUCTURE',
        signee: 'Dr. Marcus Vance (VP Infrastructure Engineering)',
        timestamp: new Date().toISOString(),
      },
    ],
    trackingMilestones: milestones,
  };
}
