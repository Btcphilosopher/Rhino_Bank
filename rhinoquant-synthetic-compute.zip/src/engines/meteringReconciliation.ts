import { MeteringRecord } from '../types';

export interface ReconciliationSummary {
  totalAllocatedGpuHours: number;
  totalMeasuredGpuHours: number;
  utilizationEfficiencyPct: number;
  totalProviderInvoicedUSD: number;
  totalCustomerBilledUSD: number;
  netMarginRealizedUSD: number;
  marginRealizedPct: number;
  discrepancyExceptionsCount: number;
  totalDiscrepancyUSD: number;
  exceptionsList: MeteringRecord[];
}

export function performReconciliation(records: MeteringRecord[]): ReconciliationSummary {
  let totalAllocatedHours = 0;
  let totalMeasuredHours = 0;
  let totalProviderInvoice = 0;
  let totalCustomerBilled = 0;
  let totalDiscrepancy = 0;
  const exceptions: MeteringRecord[] = [];

  records.forEach((rec) => {
    totalAllocatedHours += rec.allocatedUnits * 24; // standard 24h sample period
    totalMeasuredHours += rec.measuredGpuHours;
    totalProviderInvoice += rec.providerInvoicedAmountUSD;
    totalCustomerBilled += rec.customerBillableAmountUSD;

    if (rec.internalLedgerReconciliationStatus !== 'RECONCILED' || Math.abs(rec.discrepancyUSD) > 50) {
      exceptions.push(rec);
      totalDiscrepancy += Math.abs(rec.discrepancyUSD);
    }
  });

  const netMargin = totalCustomerBilled - totalProviderInvoice;
  const marginPct = totalCustomerBilled > 0
    ? Math.round((netMargin / totalCustomerBilled) * 1000) / 10
    : 0;

  const utilizationEfficiency = totalAllocatedHours > 0
    ? Math.round((totalMeasuredHours / totalAllocatedHours) * 1000) / 10
    : 0;

  return {
    totalAllocatedGpuHours: totalAllocatedHours,
    totalMeasuredGpuHours: totalMeasuredHours,
    utilizationEfficiencyPct: utilizationEfficiency,
    totalProviderInvoicedUSD: Math.round(totalProviderInvoice),
    totalCustomerBilledUSD: Math.round(totalCustomerBilled),
    netMarginRealizedUSD: Math.round(netMargin),
    marginRealizedPct: marginPct,
    discrepancyExceptionsCount: exceptions.length,
    totalDiscrepancyUSD: Math.round(totalDiscrepancy),
    exceptionsList: exceptions,
  };
}
