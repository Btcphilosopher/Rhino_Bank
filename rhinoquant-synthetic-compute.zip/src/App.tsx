import React, { useState } from 'react';
import { AppStoreProvider, useAppStore } from './state/store';
import { Header } from './components/Header';
import { WorkflowBanner } from './components/WorkflowBanner';
import { WorkspacePackageFactory } from './components/WorkspacePackageFactory';
import { WorkspaceComputeExchange } from './components/WorkspaceComputeExchange';
import { WorkspaceSupplyInfrastructure } from './components/WorkspaceSupplyInfrastructure';
import { WorkspaceProcurementDesk } from './components/WorkspaceProcurementDesk';
import { WorkspaceInfrastructureEngineering } from './components/WorkspaceInfrastructureEngineering';
import { WorkspaceQuantitativeEconomics } from './components/WorkspaceQuantitativeEconomics';
import { WorkspaceForwardContracts } from './components/WorkspaceForwardContracts';
import { WorkspacePortfolioTreasury } from './components/WorkspacePortfolioTreasury';
import { WorkspaceRiskControl } from './components/WorkspaceRiskControl';
import { WorkspaceMeteringReconciliation } from './components/WorkspaceMeteringReconciliation';
import { WorkspaceAuditGovernance } from './components/WorkspaceAuditGovernance';
import { ModalPackageBuilder } from './components/ModalPackageBuilder';
import { ModalPOApproval } from './components/ModalPOApproval';
import { PurchaseOrder } from './types';

const AppContent: React.FC = () => {
  const { activeWorkspace } = useAppStore();

  const [isPackageBuilderOpen, setIsPackageBuilderOpen] = useState(false);
  const [poToApprove, setPoToApprove] = useState<PurchaseOrder | null>(null);

  return (
    <div className="min-h-screen bg-[#0b0f17] text-slate-100 flex flex-col font-sans selection:bg-sky-500/30 selection:text-sky-200">
      {/* Top Header */}
      <Header onOpenPackageBuilder={() => setIsPackageBuilderOpen(true)} />

      {/* End-to-End Workflow Execution Banner */}
      <WorkflowBanner />

      {/* Main Viewport Content */}
      <main className="flex-1 max-w-[1720px] w-full mx-auto px-6 py-6">
        {activeWorkspace === 'package_factory' && (
          <WorkspacePackageFactory onOpenCreateModal={() => setIsPackageBuilderOpen(true)} />
        )}
        {activeWorkspace === 'exchange' && <WorkspaceComputeExchange />}
        {activeWorkspace === 'supply_infra' && <WorkspaceSupplyInfrastructure />}
        {activeWorkspace === 'procurement' && (
          <WorkspaceProcurementDesk onOpenApprovalModal={(po) => setPoToApprove(po)} />
        )}
        {activeWorkspace === 'infra_engineering' && <WorkspaceInfrastructureEngineering />}
        {activeWorkspace === 'economics' && <WorkspaceQuantitativeEconomics />}
        {activeWorkspace === 'forward_contracts' && <WorkspaceForwardContracts />}
        {activeWorkspace === 'portfolio_treasury' && <WorkspacePortfolioTreasury />}
        {activeWorkspace === 'risk_control' && <WorkspaceRiskControl />}
        {activeWorkspace === 'metering' && <WorkspaceMeteringReconciliation />}
        {activeWorkspace === 'audit' && <WorkspaceAuditGovernance />}
      </main>

      {/* Institutional Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/60 py-4 px-6 text-slate-500 text-xs font-mono">
        <div className="max-w-[1720px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-400">RHINOQUANT SYNTHETIC COMPUTE</span>
            <span>·</span>
            <span>Institutional Multi-Asset Infrastructure Platform</span>
          </div>

          <div className="flex items-center gap-4 text-[11px]">
            <span>Deterministic Seed: 2026.04.1</span>
            <span>·</span>
            <span>Dual-Authorisation Governance Active</span>
            <span>·</span>
            <span className="text-slate-400">© 2026 RhinoQuant Infrastructure Exchange</span>
          </div>
        </div>
      </footer>

      {/* Interactive Modals */}
      <ModalPackageBuilder
        isOpen={isPackageBuilderOpen}
        onClose={() => setIsPackageBuilderOpen(false)}
      />

      <ModalPOApproval
        isOpen={poToApprove !== null}
        po={poToApprove}
        onClose={() => setPoToApprove(null)}
      />
    </div>
  );
};

export default function App() {
  return (
    <AppStoreProvider>
      <AppContent />
    </AppStoreProvider>
  );
}
