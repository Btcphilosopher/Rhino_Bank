export type WorkloadClass =
  | 'large_model_training'
  | 'ai_inference'
  | 'fine_tuning'
  | 'high_performance_computing'
  | 'scientific_simulation'
  | 'rendering'
  | 'data_processing';

export type AcceleratorType =
  | 'NVIDIA_H100_SXM5_80GB'
  | 'NVIDIA_H200_SXM5_141GB'
  | 'NVIDIA_B200_NVL_192GB'
  | 'NVIDIA_GB200_NVL72'
  | 'NVIDIA_A100_80GB_SXM4'
  | 'NVIDIA_L40S_48GB';

export type InterconnectTopology =
  | 'NVLink4_InfiniBand_800G'
  | 'NVLink5_InfiniBand_800G'
  | 'NVLink3_InfiniBand_200G'
  | 'PCIe5_RoCEv2_400G'
  | 'Standard_Ethernet_100G';

export type GeographicRegion =
  | 'US-East (Virginia)'
  | 'US-West (Phoenix)'
  | 'EU-Central (Frankfurt)'
  | 'Nordic-Green (Reykjavik)'
  | 'AP-Southeast (Singapore)';

export type BackingClassification =
  | 'COMMISSIONED'
  | 'PROVIDER_CONFIRMED'
  | 'SUPPLIER_CONFIRMED'
  | 'PURCHASE_APPROVED'
  | 'PLANNED'
  | 'UNBACKED'
  | 'AT_RISK';

export type PackageStatus =
  | 'DRAFT'
  | 'FEASIBILITY_ANALYZING'
  | 'OPTIMIZED'
  | 'COMMERCIAL_APPROVED'
  | 'RESERVATIONS_COMMITTED'
  | 'INFRASTRUCTURE_PENDING'
  | 'COMMISSIONING'
  | 'OPERATIONAL'
  | 'COMPLETED'
  | 'INFEASIBLE';

export type POStatus =
  | 'REQUIREMENT'
  | 'BOM_DRAFT'
  | 'TECHNICAL_REVIEW'
  | 'RFQ_ISSUED'
  | 'QUOTES_RECEIVED'
  | 'COMMERCIAL_REVIEW'
  | 'APPROVAL_PENDING'
  | 'PO_APPROVED'
  | 'PO_SUBMITTED'
  | 'SUPPLIER_CONFIRMED'
  | 'IN_TRANSIT'
  | 'RECEIVED'
  | 'INSTALLED'
  | 'COMMISSIONED'
  | 'ACCEPTED';

export type Currency = 'USD' | 'EUR' | 'GBP';

export interface WorkloadRequirement {
  workloadClass: WorkloadClass;
  workloadName: string;
  acceleratorType: AcceleratorType;
  acceleratorCount: number;
  memoryMinGBPerGPU: number;
  interconnect: InterconnectTopology;
  minNetworkThroughputGbps: number;
  storageCapacityTB: number;
  storageMinIOPS: number;
  region: GeographicRegion;
  dataResidencyStrict: boolean;
  startDate: string; // ISO string
  durationHours: number;
  targetMaxBudgetUSD: number;
  sloAvailabilityPct: number;
  maxLatencyMs: number;
}

export interface ProviderInventoryItem {
  id: string;
  providerName: string;
  providerType: 'gpu_cloud' | 'public_cloud' | 'bare_metal' | 'colocation' | 'private_dc';
  region: GeographicRegion;
  facilityName: string;
  acceleratorType: AcceleratorType;
  totalInstalledUnits: number;
  operationalUnits: number;
  availableUnits: number;
  reservedUnits: number;
  allocatedUnits: number;
  pricePerGPUHourUSD: number;
  minimumCommitmentHours: number;
  reservationExpiryHours: number;
  interconnect: InterconnectTopology;
  pueRating: number;
  cleanEnergyPct: number;
  lastTelemetryTimestamp: string;
  freshnessStatus: 'FRESH' | 'STALE' | 'VERIFYING';
  supportedOperations: {
    inventoryDiscovery: boolean;
    realtimeReservation: boolean;
    telemetryMetering: boolean;
    provisioningApi: boolean;
  };
}

export interface ProviderAllocation {
  providerId: string;
  providerName: string;
  facility: string;
  acceleratorType: AcceleratorType;
  allocatedGPUs: number;
  gpuHours: number;
  unitCostUSD: number;
  totalCostUSD: number;
  reservationId?: string;
  reservationStatus: 'UNCOMMITTED' | 'HELD_PENDING_APPROVAL' | 'CONFIRMED' | 'ACTIVE';
}

export interface InfrastructureShortfall {
  hasShortfall: boolean;
  requiredGPUs: number;
  allocatedGPUs: number;
  shortfallGPUs: number;
  shortfallReason: string;
  recommendedPhysicalExpansion: boolean;
}

export interface BOMItem {
  sku: string;
  componentCategory:
    | 'accelerator_server'
    | 'gpu_module'
    | 'switch_fabric'
    | 'optical_transceiver'
    | 'cabling_harness'
    | 'rack_enclosure'
    | 'cdu_cooling'
    | 'pdu_power_strip'
    | 'facility_pdu'
    | 'commissioning_service';
  name: string;
  manufacturer: string;
  quantity: number;
  unit: string;
  leadTimeWeeks: number;
  unitCostUSD: number;
  totalCostUSD: number;
  powerDrawWattsPerUnit: number;
  massKgPerUnit: number;
  warrantyYears: number;
  supplierCandidates: string[];
  selectedSupplier: string;
  technicalCompatibilityValidated: boolean;
}

export interface InfrastructureDesign {
  id: string;
  designName: string;
  architectureTier: 'NVIDIA_HGX_H100' | 'NVIDIA_HGX_H200' | 'NVIDIA_GB200_NVL72';
  targetGPUExpansion: number;
  serverNodeCount: number;
  rackCount: number;
  totalPowerDemandKW: number;
  peakPowerDemandKW: number;
  coolingCapacityRequiredKW: number;
  coolingType: 'DIRECT_LIQUID_COOLING' | 'REAR_DOOR_HEAT_EXCHANGER' | 'HYBRID_AIR_LIQUID';
  cduRedundancy: 'N+1' | '2N';
  totalMassKg: number;
  floorLoadKgPerSqm: number;
  networkFabricTier: string;
  oversubscriptionRatio: string;
  bom: BOMItem[];
  capexHardwareUSD: number;
  capexInstallationUSD: number;
  capexTotalUSD: number;
  estimatedLeadTimeWeeks: number;
  facilityReadinessCheck: {
    powerAvailable: boolean;
    cduLoopReady: boolean;
    floorLoadingFeasible: boolean;
    fiberPathClear: boolean;
    overallPass: boolean;
    notes: string;
  };
}

export interface SupplierQuote {
  quoteId: string;
  rfqId: string;
  supplierName: string;
  bomSku: string;
  itemName: string;
  quantity: number;
  quotedUnitPriceUSD: number;
  quotedTotalUSD: number;
  leadTimeWeeks: number;
  paymentTerms: string;
  quoteExpiryDate: string;
  warrantyTerms: string;
  confidenceScore: number;
  status: 'PENDING' | 'SELECTED' | 'REJECTED';
}

export interface PurchaseOrder {
  poId: string;
  packageId?: string;
  infrastructureDesignId?: string;
  poNumber: string;
  supplierName: string;
  currency: Currency;
  totalAmountUSD: number;
  itemCount: number;
  items: Array<{
    sku: string;
    description: string;
    quantity: number;
    unitPriceUSD: number;
    totalUSD: number;
  }>;
  status: POStatus;
  leadTimeWeeks: number;
  estimatedDeliveryDate: string;
  createdDate: string;
  requiresDualApproval: boolean;
  approvalSignatures: Array<{
    role: 'HEAD_OF_INFRASTRUCTURE' | 'CHIEF_FINANCIAL_OFFICER' | 'HEAD_OF_TRADING';
    signee: string;
    timestamp: string;
  }>;
  trackingMilestones: Array<{
    milestone: string;
    completed: boolean;
    timestamp?: string;
  }>;
}

export interface PackageEconomics {
  packageId: string;
  totalGPUHours: number;
  customerContractPriceUSD: number;
  effectivePricePerGPUHourUSD: number;
  existingProviderOpexUSD: number;
  physicalInfrastructureCapexUSD: number;
  powerOpexUSD: number;
  coolingAndFacilityOpexUSD: number;
  staffingAndMaintenanceUSD: number;
  totalCostOfDeliveryUSD: number;
  grossMarginUSD: number;
  grossMarginPct: number;
  paybackPeriodMonths: number;
  irrPct: number;
  npvUSD: number;
  breakEvenUtilizationPct: number;
  sensitivityPowerIncrease25PctMargin: number;
  sensitivityHardwareCostIncrease20PctMargin: number;
}

export interface ContractBackingSummary {
  contractId: string;
  packageId: string;
  contractedGPUHours: number;
  commissionedGPUHours: number;
  providerConfirmedGPUHours: number;
  supplierConfirmedGPUHours: number;
  purchaseApprovedGPUHours: number;
  plannedGPUHours: number;
  unbackedGPUHours: number;
  backingRatioPct: number; // (commissioned + providerConfirmed + supplierConfirmed) / total
  overallClassification: BackingClassification;
  earliestFeasibleDeliveryDate: string;
  latestFeasibleDeliveryDate: string;
  criticalDependency: string;
  alertCount: number;
}

export interface ComputePackage {
  id: string;
  packageName: string;
  customerName: string;
  workload: WorkloadRequirement;
  status: PackageStatus;
  version: number;
  createdAt: string;
  targetStartDate: string;
  targetCompletionDate: string;
  providerAllocations: ProviderAllocation[];
  shortfall: InfrastructureShortfall;
  infrastructureDesign?: InfrastructureDesign;
  associatedPOIds: string[];
  economics: PackageEconomics;
  backing: ContractBackingSummary;
  notes: string;
}

export interface MeteringRecord {
  id: string;
  timestamp: string;
  packageId: string;
  providerId: string;
  allocatedUnits: number;
  measuredGpuHours: number;
  cpuHours: number;
  memoryTBHours: number;
  networkEgressGB: number;
  powerDrawnKWh: number;
  providerInvoicedAmountUSD: number;
  customerBillableAmountUSD: number;
  internalLedgerReconciliationStatus: 'RECONCILED' | 'EXCEPTION_OVERAGE' | 'PENDING_AUDIT';
  discrepancyUSD: number;
  notes?: string;
}

export interface RiskAlert {
  id: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  category: 'CAPACITY_BACKING' | 'SUPPLY_CHAIN' | 'FACILITY_POWER' | 'MARGIN_LEAKAGE' | 'COUNTERPARTY';
  title: string;
  description: string;
  affectedEntityId: string;
  entityType: 'PACKAGE' | 'PO' | 'DATA_CENTRE' | 'PROVIDER';
  timestamp: string;
  recommendedAction: string;
}

export interface AuditEvent {
  id: string;
  timestamp: string;
  operator: string;
  role: string;
  action: string;
  targetEntityType: string;
  targetEntityId: string;
  summary: string;
  prevValueState?: string;
  newValueState?: string;
  auditHash: string;
}
