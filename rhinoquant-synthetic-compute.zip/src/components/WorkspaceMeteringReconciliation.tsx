import React, { useState } from 'react';
import { useAppStore } from '../state/store';
import { MeteringRecord } from '../types';
import { Activity, CheckCircle2, AlertTriangle, ShieldCheck, DollarSign, FileCheck, ArrowRight } from 'lucide-react';

export const WorkspaceMeteringReconciliation: React.FC = () => {
  const {
    meteringRecords,
    reconciliationSummary,
    resolveMeteringException
  } = useAppStore();

  const [resolvingId, setResolvingId] = useState<string | null>(null);
  const [resolutionNote, setResolutionNote] = useState('');

  const handleResolve = (id: string) => {
    if (!resolutionNote.trim()) return;
    resolveMeteringException(id, resolutionNote);
    setResolvingId(null);
    setResolutionNote('');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">Metering, Billing & Multi-Ledger Reconciliation</h1>
          <p className="text-xs text-slate-400 mt-1">
            Continuous reconciliation of provider invoices, physical sensor telemetry, contractual entitlements, and customer billables.
          </p>
        </div>

        <div className="font-mono text-xs text-slate-300 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded">
          Telemetry Efficiency: <strong className="text-emerald-400">{reconciliationSummary.utilizationEfficiencyPct}%</strong> · Exceptions: <strong className={reconciliationSummary.discrepancyExceptionsCount > 0 ? 'text-amber-400' : 'text-slate-300'}>{reconciliationSummary.discrepancyExceptionsCount}</strong>
        </div>
      </div>

      {/* Reconciliation Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 font-mono">
        <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded">
          <div className="text-[10px] uppercase text-slate-400">Measured Workload Usage</div>
          <div className="text-xl font-bold text-sky-400 tabular-nums mt-0.5">
            {reconciliationSummary.totalMeasuredGpuHours.toLocaleString()} <span className="text-xs font-normal text-slate-400">GPU-h</span>
          </div>
          <div className="text-[11px] text-slate-500 font-sans mt-0.5">Allocated entitlement: {reconciliationSummary.totalAllocatedGpuHours.toLocaleString()} GPU-h</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded">
          <div className="text-[10px] uppercase text-slate-400">Provider Invoices Received</div>
          <div className="text-xl font-bold text-slate-200 tabular-nums mt-0.5">
            ${reconciliationSummary.totalProviderInvoicedUSD.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500 font-sans mt-0.5">Billed by CoreWeave & Nebius</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded">
          <div className="text-[10px] uppercase text-slate-400">Customer Billable Invoiced</div>
          <div className="text-xl font-bold text-emerald-400 tabular-nums mt-0.5">
            ${reconciliationSummary.totalCustomerBilledUSD.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500 font-sans mt-0.5">Delivered contract milestone revenue</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded">
          <div className="text-[10px] uppercase text-slate-400">Reconciled Net Spread</div>
          <div className="text-xl font-bold text-emerald-400 tabular-nums mt-0.5">
            ${reconciliationSummary.netMarginRealizedUSD.toLocaleString()} <span className="text-xs font-normal text-slate-400">({reconciliationSummary.marginRealizedPct}%)</span>
          </div>
          <div className="text-[11px] text-slate-500 font-sans mt-0.5">Zero unhedged margin leakage</div>
        </div>
      </div>

      {/* Discrepancy Exception Resolution Dialog (if resolving) */}
      {resolvingId && (
        <div className="bg-slate-900 border border-sky-800 p-4 rounded text-xs space-y-3">
          <div className="font-semibold text-slate-200 flex items-center justify-between">
            <span>Audit Exception Settlement for Record: {resolvingId}</span>
            <button onClick={() => setResolvingId(null)} className="text-slate-400 hover:text-white">Cancel</button>
          </div>
          <p className="text-slate-300">
            Provide the audit justification for settling this invoice discrepancy (e.g. credit memo received from provider or billable contract amendment).
          </p>
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="e.g. CoreWeave issued $184.20 credit memo for disputed cross-AZ transit."
              value={resolutionNote}
              onChange={(e) => setResolutionNote(e.target.value)}
              className="flex-1 bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-slate-200 focus:outline-none focus:border-sky-500"
            />
            <button
              onClick={() => handleResolve(resolvingId)}
              className="px-4 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded"
            >
              Signoff Settlement
            </button>
          </div>
        </div>
      )}

      {/* Telemetry & Invoicing Audit Ledger */}
      <div className="overflow-x-auto rounded border border-slate-800 bg-slate-950">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="border-b border-slate-800 bg-slate-900/80 text-slate-400 font-mono text-[11px]">
              <th className="py-2.5 px-4 font-medium">Record ID & Package</th>
              <th className="py-2.5 px-3 font-medium">Provider</th>
              <th className="py-2.5 px-3 font-medium text-right">Measured Telemetry</th>
              <th className="py-2.5 px-3 font-medium text-right">Power Drawn</th>
              <th className="py-2.5 px-3 font-medium text-right">Provider Charge</th>
              <th className="py-2.5 px-3 font-medium text-right">Customer Billable</th>
              <th className="py-2.5 px-3 font-medium text-center">Status</th>
              <th className="py-2.5 px-4 font-medium text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 font-sans">
            {meteringRecords.map((rec) => {
              const hasDiscrepancy = rec.internalLedgerReconciliationStatus !== 'RECONCILED' || rec.discrepancyUSD !== 0;
              return (
                <tr key={rec.id} className="hover:bg-slate-900/40 transition-colors">
                  <td className="py-3 px-4">
                    <div className="font-mono text-slate-200 font-bold">{rec.id}</div>
                    <div className="text-[11px] text-slate-400 font-mono">{rec.packageId}</div>
                    {rec.notes && <div className="text-[10px] text-slate-500 mt-0.5 line-clamp-1">{rec.notes}</div>}
                  </td>
                  <td className="py-3 px-3 font-mono text-slate-300">
                    {rec.providerId}
                  </td>
                  <td className="py-3 px-3 text-right font-mono tabular-nums">
                    <div className="text-slate-200 font-semibold">{rec.measuredGpuHours.toLocaleString()} GPU-h</div>
                    <div className="text-[10px] text-slate-500">{rec.networkEgressGB.toLocaleString()} GB Egress</div>
                  </td>
                  <td className="py-3 px-3 text-right font-mono tabular-nums text-amber-400">
                    {rec.powerDrawnKWh.toLocaleString()} kWh
                  </td>
                  <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-300">
                    ${rec.providerInvoicedAmountUSD.toLocaleString()}
                  </td>
                  <td className="py-3 px-3 text-right font-mono tabular-nums text-emerald-400 font-semibold">
                    ${rec.customerBillableAmountUSD.toLocaleString()}
                  </td>
                  <td className="py-3 px-3 text-center">
                    <span
                      className={`font-mono text-[10px] px-2 py-0.5 rounded border ${
                        !hasDiscrepancy
                          ? 'bg-emerald-950 text-emerald-400 border-emerald-800'
                          : 'bg-amber-950 text-amber-400 border-amber-800 font-bold'
                      }`}
                    >
                      {rec.internalLedgerReconciliationStatus}
                    </span>
                    {hasDiscrepancy && (
                      <div className="text-[10px] text-amber-400 font-mono mt-0.5 tabular-nums">
                        +${rec.discrepancyUSD.toFixed(2)} variance
                      </div>
                    )}
                  </td>
                  <td className="py-3 px-4 text-right">
                    {hasDiscrepancy ? (
                      <button
                        onClick={() => setResolvingId(rec.id)}
                        className="px-2.5 py-1 text-xs font-semibold text-slate-900 bg-amber-400 hover:bg-amber-300 rounded"
                      >
                        Settle Variance
                      </button>
                    ) : (
                      <span className="text-[11px] font-mono text-slate-500 flex items-center justify-end gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                        <span>Reconciled</span>
                      </span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
