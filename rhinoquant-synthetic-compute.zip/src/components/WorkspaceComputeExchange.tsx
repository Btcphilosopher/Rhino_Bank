import React, { useState } from 'react';
import { useAppStore } from '../state/store';
import { ProviderInventoryItem, GeographicRegion, AcceleratorType } from '../types';
import { RefreshCw, CheckCircle, AlertTriangle, ShieldCheck, Cpu } from 'lucide-react';

export const WorkspaceComputeExchange: React.FC = () => {
  const { providers } = useAppStore();
  const [selectedRegion, setSelectedRegion] = useState<string>('ALL');
  const [selectedAccelerator, setSelectedAccelerator] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  // Regional metrics aggregation
  const totalOperational = providers.reduce((acc, p) => acc + p.operationalUnits, 0);
  const totalAvailable = providers.reduce((acc, p) => acc + p.availableUnits, 0);
  const totalReserved = providers.reduce((acc, p) => acc + p.reservedUnits, 0);
  const avgPUE = (providers.reduce((acc, p) => acc + p.pueRating, 0) / providers.length).toFixed(2);
  const avgCleanEnergy = Math.round(providers.reduce((acc, p) => acc + p.cleanEnergyPct, 0) / providers.length);

  const filteredProviders = providers.filter((p) => {
    if (selectedRegion !== 'ALL' && p.region !== selectedRegion) return false;
    if (selectedAccelerator !== 'ALL' && p.acceleratorType !== selectedAccelerator) return false;
    if (searchQuery && !p.providerName.toLowerCase().includes(searchQuery.toLowerCase()) && !p.facilityName.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Workspace Header & High-Density Metrics */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">Multi-Data-Centre Capacity Exchange</h1>
          <p className="text-xs text-slate-400 mt-1">
            Provider-neutral aggregated orderbook across certified hyperscale, GPU cloud, and bare-metal facilities.
          </p>
        </div>

        {/* Headline Telemetry Figures */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 bg-slate-900 border border-slate-800 p-2.5 rounded">
          <div className="px-3">
            <div className="text-[10px] uppercase font-mono text-slate-400">Total Operational</div>
            <div className="text-base font-bold font-mono text-white tabular-nums">{totalOperational.toLocaleString()} <span className="text-xs font-normal text-slate-400">GPUs</span></div>
          </div>
          <div className="px-3 border-l border-slate-800">
            <div className="text-[10px] uppercase font-mono text-slate-400">Available Spot</div>
            <div className="text-base font-bold font-mono text-emerald-400 tabular-nums">{totalAvailable.toLocaleString()} <span className="text-xs font-normal text-slate-400">GPUs</span></div>
          </div>
          <div className="px-3 border-l border-slate-800">
            <div className="text-[10px] uppercase font-mono text-slate-400">Contracted / Reserved</div>
            <div className="text-base font-bold font-mono text-sky-400 tabular-nums">{totalReserved.toLocaleString()} <span className="text-xs font-normal text-slate-400">GPUs</span></div>
          </div>
          <div className="px-3 border-l border-slate-800">
            <div className="text-[10px] uppercase font-mono text-slate-400">Weighted PUE / Green</div>
            <div className="text-base font-bold font-mono text-slate-200 tabular-nums">{avgPUE} <span className="text-xs font-normal text-slate-400">/ {avgCleanEnergy}%</span></div>
          </div>
        </div>
      </div>

      {/* Filter and Control Strip */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/60 p-3 rounded border border-slate-800 text-xs">
        <div className="flex flex-wrap items-center gap-3">
          <input
            type="text"
            placeholder="Search provider, campus, or facility..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="px-3 py-1.5 bg-slate-950 border border-slate-700 rounded text-slate-200 placeholder-slate-500 focus:outline-none focus:border-sky-500 w-64"
          />

          <div className="flex items-center gap-1.5">
            <span className="text-slate-400 font-mono">Region:</span>
            <select
              value={selectedRegion}
              onChange={(e) => setSelectedRegion(e.target.value)}
              className="bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-sky-500"
            >
              <option value="ALL">All Regions</option>
              <option value="US-East (Virginia)">US-East (Virginia)</option>
              <option value="US-West (Phoenix)">US-West (Phoenix)</option>
              <option value="EU-Central (Frankfurt)">EU-Central (Frankfurt)</option>
              <option value="Nordic-Green (Reykjavik)">Nordic-Green (Reykjavik)</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-slate-400 font-mono">Hardware:</span>
            <select
              value={selectedAccelerator}
              onChange={(e) => setSelectedAccelerator(e.target.value)}
              className="bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-sky-500"
            >
              <option value="ALL">All Accelerators</option>
              <option value="NVIDIA_H100_SXM5_80GB">NVIDIA H100 SXM5 80GB</option>
              <option value="NVIDIA_H200_SXM5_141GB">NVIDIA H200 SXM5 141GB</option>
              <option value="NVIDIA_GB200_NVL72">NVIDIA GB200 NVL72</option>
            </select>
          </div>
        </div>

        <div className="text-slate-400 font-mono text-[11px]">
          Showing {filteredProviders.length} active provider adapters · Telemetry sync interval 30s
        </div>
      </div>

      {/* High-Density Data Grid */}
      <div className="overflow-x-auto rounded border border-slate-800 bg-slate-950">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="border-b border-slate-800 bg-slate-900/80 text-slate-400 font-mono text-[11px]">
              <th className="py-2.5 px-4 font-medium">Provider & Facility</th>
              <th className="py-2.5 px-3 font-medium">Region</th>
              <th className="py-2.5 px-3 font-medium">Accelerator & Fabric</th>
              <th className="py-2.5 px-3 font-medium text-right">Available / Total</th>
              <th className="py-2.5 px-3 font-medium text-right">Spot Rate</th>
              <th className="py-2.5 px-3 font-medium text-center">Min Commit</th>
              <th className="py-2.5 px-3 font-medium text-center">Efficiency</th>
              <th className="py-2.5 px-3 font-medium text-center">Telemetry</th>
              <th className="py-2.5 px-4 font-medium text-right">API Operations</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 font-sans">
            {filteredProviders.map((prov) => {
              const utilPct = Math.round(((prov.totalInstalledUnits - prov.availableUnits) / prov.totalInstalledUnits) * 100);
              return (
                <tr key={prov.id} className="hover:bg-slate-900/40 transition-colors">
                  <td className="py-3 px-4">
                    <div className="font-semibold text-slate-200">{prov.providerName}</div>
                    <div className="text-[11px] text-slate-400 font-mono">{prov.facilityName}</div>
                  </td>
                  <td className="py-3 px-3 text-slate-300">
                    <span className="font-mono text-[11px]">{prov.region}</span>
                  </td>
                  <td className="py-3 px-3">
                    <div className="text-sky-300 font-medium">{prov.acceleratorType.replace(/_/g, ' ')}</div>
                    <div className="text-[10px] text-slate-500 font-mono">{prov.interconnect.replace(/_/g, ' ')}</div>
                  </td>
                  <td className="py-3 px-3 text-right">
                    <div className="font-mono tabular-nums font-bold text-emerald-400">
                      {prov.availableUnits} <span className="text-slate-500 font-normal">/ {prov.totalInstalledUnits}</span>
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono">{utilPct}% allocated</div>
                  </td>
                  <td className="py-3 px-3 text-right">
                    <div className="font-mono tabular-nums font-bold text-slate-100">
                      ${prov.pricePerGPUHourUSD.toFixed(2)}
                    </div>
                    <div className="text-[10px] text-slate-500 font-mono">per GPU-hour</div>
                  </td>
                  <td className="py-3 px-3 text-center font-mono text-[11px] text-slate-300">
                    {prov.minimumCommitmentHours}h ({Math.round(prov.minimumCommitmentHours / 24)}d)
                  </td>
                  <td className="py-3 px-3 text-center">
                    <div className="font-mono text-[11px] text-slate-200">PUE {prov.pueRating}</div>
                    <div className="text-[10px] text-emerald-400 font-mono">{prov.cleanEnergyPct}% clean energy</div>
                  </td>
                  <td className="py-3 px-3 text-center">
                    <span className="font-mono text-[11px] text-emerald-400 flex items-center justify-center gap-1">
                      <CheckCircle className="w-3 h-3 text-emerald-400" />
                      <span>{prov.freshnessStatus}</span>
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5 text-[10px] font-mono text-slate-400">
                      <span className="px-1.5 py-0.5 bg-slate-800 rounded border border-slate-700" title="Real-time reservation locking supported">
                        RESERVABLE
                      </span>
                      <span className="px-1.5 py-0.5 bg-slate-800 rounded border border-slate-700" title="Telemetry ingestion active">
                        METERED
                      </span>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
