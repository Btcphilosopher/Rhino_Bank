import React, { useState } from 'react';
import { useAppStore } from '../state/store';
import { AlertOctagon, ShieldAlert, Zap, TrendingDown, Clock, ArrowRight, RotateCcw } from 'lucide-react';
import { StressScenarioConfig } from '../engines/riskTreasuryEngine';

export const WorkspaceRiskControl: React.FC = () => {
  const {
    riskAlerts,
    activeStressResult,
    runStressScenario,
    clearStressScenario
  } = useAppStore();

  const [powerShock, setPowerShock] = useState(25);
  const [hardwareShock, setHardwareShock] = useState(20);
  const [delayDays, setDelayDays] = useState(90);
  const [providerLoss, setProviderLoss] = useState(30);

  const handleRunStress = () => {
    const config: StressScenarioConfig = {
      electricityPriceShockPct: powerShock,
      hardwareCostShockPct: hardwareShock,
      shipmentDelayDays: delayDays,
      providerCapacityLossPct: providerLoss,
      utilizationDropPct: 15,
    };
    runStressScenario(config);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">Cross-Domain Risk Control & Scenario Stress Engine</h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time monitoring of unbacked delivery commitments, supply-chain bottlenecks, power volatility, and liquidity shocks.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {activeStressResult && (
            <button
              onClick={clearStressScenario}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono text-slate-300 bg-slate-800 hover:bg-slate-700 rounded border border-slate-700"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Scenario</span>
            </button>
          )}

          <div className="font-mono text-xs text-slate-300 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded">
            Active Risk Alerts: <strong className="text-amber-400">{riskAlerts.length}</strong>
          </div>
        </div>
      </div>

      {/* Stress Test Simulator Controls */}
      <div className="bg-slate-900/80 border border-slate-800 rounded p-4 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="font-semibold text-sm text-slate-200">Portfolio Stress Parameter Configuration</div>
          <span className="font-mono text-xs text-slate-400">Monte Carlo & Deterministic Macro Shocks</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs font-mono">
          <div className="space-y-1.5 bg-slate-950 p-3 rounded border border-slate-800">
            <div className="flex justify-between text-slate-300">
              <span>Electricity Price Shock:</span>
              <span className="text-amber-400 font-bold">+{powerShock}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              step="5"
              value={powerShock}
              onChange={(e) => setPowerShock(Number(e.target.value))}
              className="w-full accent-amber-400"
            />
          </div>

          <div className="space-y-1.5 bg-slate-950 p-3 rounded border border-slate-800">
            <div className="flex justify-between text-slate-300">
              <span>Hardware CapEx Cost Shock:</span>
              <span className="text-amber-400 font-bold">+{hardwareShock}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="50"
              step="5"
              value={hardwareShock}
              onChange={(e) => setHardwareShock(Number(e.target.value))}
              className="w-full accent-amber-400"
            />
          </div>

          <div className="space-y-1.5 bg-slate-950 p-3 rounded border border-slate-800">
            <div className="flex justify-between text-slate-300">
              <span>Supplier Shipment Delay:</span>
              <span className="text-rose-400 font-bold">+{delayDays} Days</span>
            </div>
            <input
              type="range"
              min="0"
              max="180"
              step="15"
              value={delayDays}
              onChange={(e) => setDelayDays(Number(e.target.value))}
              className="w-full accent-rose-400"
            />
          </div>

          <div className="space-y-1.5 bg-slate-950 p-3 rounded border border-slate-800">
            <div className="flex justify-between text-slate-300">
              <span>Provider Capacity Outage:</span>
              <span className="text-rose-400 font-bold">-{providerLoss}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="60"
              step="10"
              value={providerLoss}
              onChange={(e) => setProviderLoss(Number(e.target.value))}
              className="w-full accent-rose-400"
            />
          </div>
        </div>

        <div className="flex justify-end">
          <button
            onClick={handleRunStress}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-slate-900 bg-amber-400 hover:bg-amber-300 rounded transition-colors shadow-sm"
          >
            <AlertOctagon className="w-3.5 h-3.5" />
            <span>Simulate Portfolio Stress</span>
          </button>
        </div>
      </div>

      {/* Stress Results Display (if active) */}
      {activeStressResult && (
        <div className="bg-amber-950/20 border border-amber-900/60 rounded p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-amber-900/40 pb-2">
            <div className="font-semibold text-sm text-amber-300 flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-400" />
              <span>Stress Test Findings: {activeStressResult.scenarioName}</span>
            </div>
            <span className="font-mono text-xs text-amber-400 font-bold">
              Margin Erosion: -${activeStressResult.marginErosionUSD.toLocaleString()} USD ({activeStressResult.marginErosionPct}%)
            </span>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 font-mono text-xs">
            <div className="p-2.5 rounded bg-slate-950 border border-slate-800">
              <div className="text-slate-400">Baseline Portfolio Margin:</div>
              <div className="text-slate-200 font-bold mt-0.5">${activeStressResult.initialPortfolioMarginUSD.toLocaleString()}</div>
            </div>
            <div className="p-2.5 rounded bg-slate-950 border border-slate-800">
              <div className="text-slate-400">Stressed Portfolio Margin:</div>
              <div className="text-amber-400 font-bold mt-0.5">${activeStressResult.stressedPortfolioMarginUSD.toLocaleString()}</div>
            </div>
            <div className="p-2.5 rounded bg-slate-950 border border-slate-800">
              <div className="text-slate-400">Compromised Packages:</div>
              <div className="text-rose-400 font-bold mt-0.5">{activeStressResult.delayedPackageCount} Packages Breached</div>
            </div>
            <div className="p-2.5 rounded bg-slate-950 border border-slate-800">
              <div className="text-slate-400">Estimated Liquidity Drain:</div>
              <div className="text-rose-300 font-bold mt-0.5">-${activeStressResult.liquidityImpactUSD.toLocaleString()}</div>
            </div>
          </div>
        </div>
      )}

      {/* Active Operational Risk Alerts Register */}
      <div className="bg-slate-900/60 border border-slate-800 rounded p-4">
        <h3 className="text-sm font-semibold text-slate-200 border-b border-slate-800 pb-2 mb-3">
          Active Institutional Risk Register & SLO Breaches
        </h3>
        <div className="space-y-2.5">
          {riskAlerts.map((alert) => (
            <div
              key={alert.id}
              className={`p-3 rounded border text-xs flex flex-col md:flex-row md:items-center justify-between gap-3 ${
                alert.severity === 'CRITICAL'
                  ? 'bg-rose-950/30 border-rose-900/60 text-rose-200'
                  : alert.severity === 'HIGH'
                  ? 'bg-amber-950/30 border-amber-900/60 text-amber-200'
                  : 'bg-slate-950 border-slate-800 text-slate-300'
              }`}
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span
                    className={`font-mono text-[10px] px-1.5 py-0.5 rounded font-bold ${
                      alert.severity === 'CRITICAL'
                        ? 'bg-rose-900 text-rose-100'
                        : alert.severity === 'HIGH'
                        ? 'bg-amber-900 text-amber-100'
                        : 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    {alert.severity}
                  </span>
                  <span className="font-semibold text-slate-100">{alert.title}</span>
                  <span className="text-[10px] font-mono text-slate-500">[{alert.category}]</span>
                </div>
                <div className="text-[11px] text-slate-300 leading-relaxed font-sans">{alert.description}</div>
              </div>

              <div className="shrink-0 text-right font-mono text-[11px]">
                <div className="text-sky-400 font-medium">Action: {alert.recommendedAction}</div>
                <div className="text-slate-500 text-[10px] mt-0.5">{new Date(alert.timestamp).toLocaleTimeString()}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
