import React, { useState } from 'react';
import { useAppStore } from '../state/store';
import { Play, StepForward, RotateCcw, ChevronDown, ChevronUp, CheckCircle2, Clock } from 'lucide-react';

export const WorkflowBanner: React.FC = () => {
  const {
    workflowProgress,
    runEndToEndWorkflow,
    stepWorkflow,
    resetWorkflow
  } = useAppStore();

  const [expanded, setExpanded] = useState(false);

  const pct = Math.round((workflowProgress.currentStep / workflowProgress.totalSteps) * 100);

  return (
    <div className="bg-slate-900 border-b border-slate-800 text-slate-300">
      <div className="max-w-[1720px] mx-auto px-6 py-2.5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          {/* Status Kicker & Current Step */}
          <div className="flex items-center gap-3 min-w-0">
            <div className="flex items-center gap-2 font-mono text-xs">
              <span className="text-slate-400 font-medium">End-to-End Orchestration</span>
              <span className="text-slate-600">/</span>
              <span className="text-sky-400 font-semibold">{workflowProgress.stepTitle}</span>
            </div>

            <div className="hidden md:flex items-center gap-2 text-xs text-slate-400">
              <span>·</span>
              <span className="truncate max-w-md">{workflowProgress.stepDescription}</span>
            </div>
          </div>

          {/* Progress Bar & Actions */}
          <div className="flex items-center gap-4 shrink-0">
            <div className="hidden sm:flex items-center gap-2">
              <div className="w-28 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-sky-500 transition-all duration-300 rounded-full"
                  style={{ width: `${pct}%` }}
                />
              </div>
              <span className="text-[11px] font-mono text-slate-400 tabular-nums">{pct}%</span>
            </div>

            <div className="flex items-center gap-1.5">
              {!workflowProgress.isRunning ? (
                <button
                  onClick={runEndToEndWorkflow}
                  className="flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-slate-900 bg-emerald-400 hover:bg-emerald-300 rounded transition-colors"
                >
                  <Play className="w-3 h-3 fill-slate-900" />
                  <span>Run 21-Step</span>
                </button>
              ) : (
                <span className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800 rounded">
                  <Clock className="w-3 h-3 animate-spin" />
                  <span>Executing...</span>
                </span>
              )}

              <button
                onClick={stepWorkflow}
                disabled={workflowProgress.isRunning}
                className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded transition-colors disabled:opacity-50"
              >
                <StepForward className="w-3 h-3" />
                <span>Step Next</span>
              </button>

              <button
                onClick={resetWorkflow}
                title="Reset workflow runner"
                className="p-1 text-slate-400 hover:text-slate-200 bg-slate-800/60 hover:bg-slate-800 rounded border border-slate-700 transition-colors"
              >
                <RotateCcw className="w-3 h-3" />
              </button>

              <button
                onClick={() => setExpanded(!expanded)}
                className="flex items-center gap-1 px-2 py-1 text-xs text-slate-400 hover:text-slate-200 transition-colors"
              >
                <span>Logs ({workflowProgress.logs.length})</span>
                {expanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
              </button>
            </div>
          </div>
        </div>

        {/* Expandable Execution Logs */}
        {expanded && (
          <div className="mt-3 pt-3 border-t border-slate-800/80">
            <div className="bg-slate-950 rounded border border-slate-800 p-3 max-h-48 overflow-y-auto font-mono text-xs space-y-1.5">
              {workflowProgress.logs.map((log, idx) => (
                <div key={idx} className="flex items-start gap-2.5">
                  <span className="text-slate-500 tabular-nums shrink-0">{log.timestamp}</span>
                  <span
                    className={
                      log.type === 'success'
                        ? 'text-emerald-400'
                        : log.type === 'warn'
                        ? 'text-amber-400'
                        : 'text-slate-300'
                    }
                  >
                    {log.type === 'success' && <CheckCircle2 className="w-3 h-3 inline mr-1 text-emerald-400" />}
                    {log.message}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
