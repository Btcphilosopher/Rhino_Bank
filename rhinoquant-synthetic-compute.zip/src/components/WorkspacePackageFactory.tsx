import React from 'react';
import { useAppStore } from '../state/store';
import { Layers, CheckCircle2, AlertOctagon, ArrowRight, Shield, Zap, DollarSign, Calendar, Server } from 'lucide-react';

interface WorkspacePackageFactoryProps {
  onOpenCreateModal: () => void;
}

export const WorkspacePackageFactory: React.FC<WorkspacePackageFactoryProps> = ({ onOpenCreateModal }) => {
  const {
    packages,
    selectedPackageId,
    setSelectedPackageId,
    reservePackageCapacity,
    generatePOForPackage,
    setActiveWorkspace
  } = useAppStore();

  const selectedPackage = packages.find((p) => p.id === selectedPackageId) || packages[0];

  if (!selectedPackage) {
    return (
      <div className="p-12 text-center border border-slate-800 rounded bg-slate-900/40">
        <h3 className="text-base font-semibold text-slate-200">No Compute Packages Assembled</h3>
        <p className="text-xs text-slate-400 mt-1 mb-4">Create a new institutional package to begin capacity orchestration.</p>
        <button
          onClick={onOpenCreateModal}
          className="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white rounded text-xs font-semibold"
        >
          Synthesize New Package
        </button>
      </div>
    );
  }

  const { workload, shortfall, providerAllocations, economics, backing } = selectedPackage;

  return (
    <div className="space-y-6">
      {/* Workspace Header & Package Selector Bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold tracking-tight text-white">{selectedPackage.packageName}</h1>
            <span className="font-mono text-xs text-slate-400">({selectedPackage.id})</span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Customer: <strong className="text-slate-200">{selectedPackage.customerName}</strong> · Delivery Window: <span className="font-mono text-slate-300">{selectedPackage.targetStartDate} to {selectedPackage.targetCompletionDate}</span>
          </p>
        </div>

        {/* Package Selector & Create Button */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-400 font-mono">Select Package:</span>
            <select
              value={selectedPackageId}
              onChange={(e) => setSelectedPackageId(e.target.value)}
              className="bg-slate-900 border border-slate-700 rounded px-3 py-1.5 text-slate-200 text-xs font-medium focus:outline-none focus:border-sky-500"
            >
              {packages.map((pkg) => (
                <option key={pkg.id} value={pkg.id}>
                  {pkg.packageName} ({pkg.workload.acceleratorCount}x {pkg.workload.acceleratorType.split('_')[1]})
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={onOpenCreateModal}
            className="px-3 py-1.5 text-xs font-semibold text-white bg-sky-600 hover:bg-sky-500 rounded border border-sky-400/40 transition-colors whitespace-nowrap"
          >
            + Assemble New
          </button>
        </div>
      </div>

      {/* Package KPI Strip */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <div className="bg-slate-900/80 border border-slate-800 p-3 rounded">
          <div className="text-[10px] uppercase font-mono text-slate-400">Total Workload Demand</div>
          <div className="text-lg font-bold font-mono text-white tabular-nums mt-0.5">
            {workload.acceleratorCount} <span className="text-xs font-normal text-slate-400">GPUs</span>
          </div>
          <div className="text-[11px] text-slate-400 font-mono">{workload.durationHours} hours ({Math.round(workload.durationHours / 24)} days)</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-3 rounded">
          <div className="text-[10px] uppercase font-mono text-slate-400">Provider Cloud Fulfilled</div>
          <div className="text-lg font-bold font-mono text-emerald-400 tabular-nums mt-0.5">
            {shortfall.allocatedGPUs} <span className="text-xs font-normal text-slate-400">GPUs</span>
          </div>
          <div className="text-[11px] text-slate-400 font-mono">
            {Math.round((shortfall.allocatedGPUs / workload.acceleratorCount) * 100)}% existing cloud
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-3 rounded">
          <div className="text-[10px] uppercase font-mono text-slate-400">Physical DC Shortfall</div>
          <div className={`text-lg font-bold font-mono tabular-nums mt-0.5 ${shortfall.hasShortfall ? 'text-amber-400' : 'text-slate-400'}`}>
            {shortfall.shortfallGPUs} <span className="text-xs font-normal text-slate-400">GPUs</span>
          </div>
          <div className="text-[11px] text-slate-400 font-mono">
            {shortfall.hasShortfall ? 'Physical expansion required' : 'Fully allocated'}
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-3 rounded">
          <div className="text-[10px] uppercase font-mono text-slate-400">Customer Contract Value</div>
          <div className="text-lg font-bold font-mono text-sky-400 tabular-nums mt-0.5">
            ${economics.customerContractPriceUSD.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-400 font-mono">${economics.effectivePricePerGPUHourUSD}/GPU-hr</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-3 rounded">
          <div className="text-[10px] uppercase font-mono text-slate-400">Package Margin & IRR</div>
          <div className="text-lg font-bold font-mono text-emerald-400 tabular-nums mt-0.5">
            {economics.grossMarginPct}% <span className="text-xs font-normal text-slate-400">margin</span>
          </div>
          <div className="text-[11px] text-slate-400 font-mono">IRR {economics.irrPct}% · Payback {economics.paybackPeriodMonths}mo</div>
        </div>
      </div>

      {/* Main Two-Column Architectural View */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Workload Specifications & Provider Allocations (2/3 width) */}
        <div className="lg:col-span-2 space-y-6">
          {/* Workload Profile Contract */}
          <div className="bg-slate-900/60 border border-slate-800 rounded p-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
              <div className="font-semibold text-sm text-slate-200">Workload & Hardware Invariant Specification</div>
              <span className="font-mono text-xs text-sky-400 font-medium">{workload.workloadClass.toUpperCase().replace(/_/g, ' ')}</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs font-sans">
              <div>
                <span className="text-slate-400 block text-[11px]">Accelerator Class</span>
                <span className="font-mono text-slate-200 font-medium">{workload.acceleratorType.replace(/_/g, ' ')}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">Interconnect & Fabric</span>
                <span className="font-mono text-slate-200 font-medium">{workload.interconnect.replace(/_/g, ' ')}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">Geographic Region</span>
                <span className="font-mono text-slate-200 font-medium">{workload.region}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">High-Perf Storage</span>
                <span className="font-mono text-slate-200 font-medium">{workload.storageCapacityTB} TB NVMe ({workload.storageMinIOPS.toLocaleString()} IOPS)</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">Data Residency</span>
                <span className="font-mono text-slate-200 font-medium">{workload.dataResidencyStrict ? 'Strict (In-Region Bound)' : 'Flexible'}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">Availability SLA Target</span>
                <span className="font-mono text-slate-200 font-medium">{workload.sloAvailabilityPct}% Guaranteed Uptime</span>
              </div>
            </div>
          </div>

          {/* Allocation Breakdown: Multi-Provider Allocations */}
          <div className="bg-slate-900/60 border border-slate-800 rounded p-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
              <div className="font-semibold text-sm text-slate-200">Third-Party Cloud Provider Allocations</div>
              <div className="flex items-center gap-2">
                {selectedPackage.status !== 'RESERVATIONS_COMMITTED' && selectedPackage.status !== 'OPERATIONAL' ? (
                  <button
                    onClick={() => reservePackageCapacity(selectedPackage.id)}
                    className="px-2.5 py-1 text-xs font-semibold text-slate-900 bg-sky-400 hover:bg-sky-300 rounded transition-colors"
                  >
                    Lock Provider Reservations
                  </button>
                ) : (
                  <span className="text-xs font-mono text-emerald-400 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Reservations Committed</span>
                  </span>
                )}
              </div>
            </div>

            {providerAllocations.length === 0 ? (
              <div className="text-xs text-slate-400 py-3 text-center">No third-party cloud providers allocated. 100% capacity satisfied through physical infrastructure.</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-400 font-mono text-[11px]">
                      <th className="py-2 font-medium">Provider & Location</th>
                      <th className="py-2 text-right font-medium">Allocated Units</th>
                      <th className="py-2 text-right font-medium">Rate ($/GPU-h)</th>
                      <th className="py-2 text-right font-medium">Total Cost</th>
                      <th className="py-2 text-center font-medium">Reservation State</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/40">
                    {providerAllocations.map((alloc, idx) => (
                      <tr key={idx} className="hover:bg-slate-900/40">
                        <td className="py-2.5">
                          <div className="font-medium text-slate-200">{alloc.providerName}</div>
                          <div className="text-[11px] text-slate-400 font-mono">{alloc.facility}</div>
                        </td>
                        <td className="py-2.5 text-right font-mono tabular-nums text-slate-200 font-semibold">
                          {alloc.allocatedGPUs} GPUs
                        </td>
                        <td className="py-2.5 text-right font-mono tabular-nums text-slate-300">
                          ${alloc.unitCostUSD.toFixed(2)}
                        </td>
                        <td className="py-2.5 text-right font-mono tabular-nums text-sky-400 font-medium">
                          ${Math.round(alloc.totalCostUSD).toLocaleString()}
                        </td>
                        <td className="py-2.5 text-center">
                          <span
                            className={`font-mono text-[11px] px-2 py-0.5 rounded ${
                              alloc.reservationStatus === 'CONFIRMED' || alloc.reservationStatus === 'ACTIVE'
                                ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800'
                                : 'bg-amber-950/60 text-amber-400 border border-amber-800'
                            }`}
                          >
                            {alloc.reservationStatus}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Physical Shortfall Synthesis & Backing Status (1/3 width) */}
        <div className="space-y-6">
          {/* Physical Infrastructure Shortfall Box */}
          <div className="bg-slate-900/60 border border-slate-800 rounded p-4 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="font-semibold text-sm text-slate-200">Physical Infrastructure Synthesis</div>
              <span className={`font-mono text-xs ${shortfall.hasShortfall ? 'text-amber-400 font-bold' : 'text-emerald-400'}`}>
                {shortfall.hasShortfall ? 'EXPANSION TRIGGERED' : 'NO EXPANSION'}
              </span>
            </div>

            {shortfall.hasShortfall && selectedPackage.infrastructureDesign ? (
              <div className="space-y-3">
                <p className="text-xs text-slate-300 leading-relaxed">
                  Available cloud providers could not supply {shortfall.shortfallGPUs} required GPUs in {workload.region}. RhinoQuant infrastructure engine synthesized a physical expansion design:
                </p>

                <div className="bg-slate-950 p-3 rounded border border-slate-800 font-mono text-xs space-y-1.5">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Design Name:</span>
                    <span className="text-slate-200">{selectedPackage.infrastructureDesign.designName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Server Nodes:</span>
                    <span className="text-slate-200">{selectedPackage.infrastructureDesign.serverNodeCount}x 8-GPU Nodes</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Rack Count:</span>
                    <span className="text-slate-200">{selectedPackage.infrastructureDesign.rackCount} Cabinets (48U)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Power Demand:</span>
                    <span className="text-slate-200">{selectedPackage.infrastructureDesign.totalPowerDemandKW} kW</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Hardware CapEx:</span>
                    <span className="text-emerald-400 font-semibold">${selectedPackage.infrastructureDesign.capexTotalUSD.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Lead Time:</span>
                    <span className="text-slate-200">{selectedPackage.infrastructureDesign.estimatedLeadTimeWeeks} Weeks</span>
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-2">
                  <button
                    onClick={() => setActiveWorkspace('infra_engineering')}
                    className="w-full flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded transition-colors"
                  >
                    <span>Inspect Rack Engineering</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => {
                      generatePOForPackage(selectedPackage.id);
                      setActiveWorkspace('procurement');
                    }}
                    className="w-full flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold text-white bg-sky-600 hover:bg-sky-500 rounded transition-colors"
                  >
                    <span>Create Purchase Order</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="text-xs text-slate-400 py-4 text-center">
                All {workload.acceleratorCount} GPUs fulfilled via confirmed provider allocations. No hardware procurement required.
              </div>
            )}
          </div>

          {/* Delivery Assurance & Backing Status */}
          <div className="bg-slate-900/60 border border-slate-800 rounded p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div className="font-semibold text-sm text-slate-200">Obligation Backing Tier</div>
              <span className="font-mono text-xs font-bold text-sky-400">{backing.overallClassification}</span>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between text-slate-300">
                <span>Contract Backing Ratio:</span>
                <span className="font-mono font-bold text-emerald-400">{backing.backingRatioPct}%</span>
              </div>
              <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
                <div
                  className="bg-emerald-500 h-full rounded-full"
                  style={{ width: `${Math.min(100, backing.backingRatioPct)}%` }}
                />
              </div>

              <div className="font-mono text-[11px] text-slate-400 pt-2 space-y-1">
                <div>· Provider Confirmed: {backing.providerConfirmedGPUHours.toLocaleString()} GPU-h</div>
                <div>· Supplier Confirmed: {backing.supplierConfirmedGPUHours.toLocaleString()} GPU-h</div>
                <div>· Commissioned Ready: {backing.commissionedGPUHours.toLocaleString()} GPU-h</div>
                <div>· Unbacked Risk: {backing.unbackedGPUHours.toLocaleString()} GPU-h</div>
              </div>

              <div className="border-t border-slate-800/80 pt-2 mt-2">
                <span className="text-[11px] text-slate-400 block">Critical Path Dependency:</span>
                <span className="text-xs text-amber-300 font-medium">{backing.criticalDependency}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
