import React from 'react';
import { useAppStore } from '../state/store';
import { Server, Activity, ShieldCheck, Clock, Zap, Thermometer, Database } from 'lucide-react';

export const WorkspaceSupplyInfrastructure: React.FC = () => {
  const { providers, packages } = useAppStore();

  const totalContractedGpuHours = packages.reduce((acc, p) => acc + p.backing.contractedGPUHours, 0);
  const totalCommissionedHours = packages.reduce((acc, p) => acc + p.backing.commissionedGPUHours, 0);
  const totalSupplierConfirmedHours = packages.reduce((acc, p) => acc + p.backing.supplierConfirmedGPUHours, 0);
  const totalProviderConfirmedHours = packages.reduce((acc, p) => acc + p.backing.providerConfirmedGPUHours, 0);

  // Group capacity by region
  const regionalData = [
    { region: 'US-East (Virginia)', totalGpu: 2848, availableGpu: 232, powerEnvelopeKw: 1200, powerUsedKw: 920, cduRedundancy: '2N' },
    { region: 'US-West (Phoenix)', totalGpu: 1024, availableGpu: 64, powerEnvelopeKw: 450, powerUsedKw: 360, cduRedundancy: 'N+1' },
    { region: 'EU-Central (Frankfurt)', totalGpu: 1536, availableGpu: 96, powerEnvelopeKw: 650, powerUsedKw: 510, cduRedundancy: 'N+1' },
    { region: 'Nordic-Green (Reykjavik)', totalGpu: 2048, availableGpu: 192, powerEnvelopeKw: 900, powerUsedKw: 680, cduRedundancy: '2N' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">Supply & Physical Infrastructure Orchestration</h1>
          <p className="text-xs text-slate-400 mt-1">
            Global operational inventory reconciled with physical deployment schedules and facility resource envelopes.
          </p>
        </div>
        <div className="font-mono text-xs text-slate-300 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded">
          Active Packages: <strong className="text-sky-400">{packages.length}</strong> · Total Obligation: <strong className="text-white">{totalContractedGpuHours.toLocaleString()} GPU-h</strong>
        </div>
      </div>

      {/* Side-by-Side Balance Strip */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded">
          <div className="flex items-center gap-2 text-slate-400 text-xs font-mono mb-1">
            <Server className="w-4 h-4 text-sky-400" />
            <span>COMMISSIONED READY</span>
          </div>
          <div className="text-xl font-bold font-mono text-white tabular-nums">
            {totalCommissionedHours.toLocaleString()} <span className="text-xs font-normal text-slate-400">GPU-h</span>
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-1">Operational hardware running live jobs</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded">
          <div className="flex items-center gap-2 text-slate-400 text-xs font-mono mb-1">
            <Activity className="w-4 h-4 text-emerald-400" />
            <span>PROVIDER RESERVED</span>
          </div>
          <div className="text-xl font-bold font-mono text-emerald-400 tabular-nums">
            {totalProviderConfirmedHours.toLocaleString()} <span className="text-xs font-normal text-slate-400">GPU-h</span>
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-1">Confirmed cloud provider spot/reserved locks</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded">
          <div className="flex items-center gap-2 text-slate-400 text-xs font-mono mb-1">
            <Clock className="w-4 h-4 text-amber-400" />
            <span>SUPPLIER IN-FLIGHT</span>
          </div>
          <div className="text-xl font-bold font-mono text-amber-400 tabular-nums">
            {totalSupplierConfirmedHours.toLocaleString()} <span className="text-xs font-normal text-slate-400">GPU-h</span>
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-1">Approved purchase orders in transit or build</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded">
          <div className="flex items-center gap-2 text-slate-400 text-xs font-mono mb-1">
            <ShieldCheck className="w-4 h-4 text-indigo-400" />
            <span>NET ASSURANCE RATIO</span>
          </div>
          <div className="text-xl font-bold font-mono text-indigo-300 tabular-nums">
            {Math.round(((totalCommissionedHours + totalProviderConfirmedHours + totalSupplierConfirmedHours) / totalContractedGpuHours) * 100)}%
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-1">100% obligations covered by verified backing</div>
        </div>
      </div>

      {/* Regional Facility Capacity & Power/Cooling Envelopes */}
      <div className="bg-slate-900/60 border border-slate-800 rounded p-4">
        <h3 className="text-sm font-semibold text-slate-200 mb-3">Regional Site Envelopes & Power/Cooling Headroom</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {regionalData.map((reg, idx) => {
            const powerUtilPct = Math.round((reg.powerUsedKw / reg.powerEnvelopeKw) * 100);
            return (
              <div key={idx} className="bg-slate-950 border border-slate-800 p-3.5 rounded font-mono text-xs space-y-2.5">
                <div className="font-bold text-slate-200 border-b border-slate-800/80 pb-1.5 flex justify-between items-center">
                  <span>{reg.region}</span>
                  <span className="text-[10px] text-sky-400">{reg.cduRedundancy} CDU</span>
                </div>

                <div className="flex justify-between">
                  <span className="text-slate-400">Total Installed:</span>
                  <span className="text-slate-200">{reg.totalGpu} GPUs</span>
                </div>

                <div className="flex justify-between">
                  <span className="text-slate-400">Available Spot:</span>
                  <span className="text-emerald-400 font-semibold">{reg.availableGpu} GPUs</span>
                </div>

                <div className="pt-1">
                  <div className="flex justify-between text-[11px] mb-1">
                    <span className="text-slate-400">Power Envelope:</span>
                    <span className="text-slate-300">{reg.powerUsedKw} / {reg.powerEnvelopeKw} kW ({powerUtilPct}%)</span>
                  </div>
                  <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${powerUtilPct > 85 ? 'bg-amber-400' : 'bg-sky-400'}`}
                      style={{ width: `${powerUtilPct}%` }}
                    />
                  </div>
                </div>

                <div className="text-[10px] text-slate-400 pt-1 border-t border-slate-800/60 flex items-center justify-between">
                  <span>Substation Tap Headroom:</span>
                  <span className="text-slate-300 font-semibold">{reg.powerEnvelopeKw - reg.powerUsedKw} kW</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
