import React, { useState } from 'react';
import { useAppStore } from '../state/store';
import {
  WorkloadClass,
  AcceleratorType,
  InterconnectTopology,
  GeographicRegion,
  WorkloadRequirement
} from '../types';
import { X, Layers, Cpu, Globe, Server, Check } from 'lucide-react';

interface ModalPackageBuilderProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ModalPackageBuilder: React.FC<ModalPackageBuilderProps> = ({ isOpen, onClose }) => {
  const { createNewPackage, setActiveWorkspace } = useAppStore();

  const [packageName, setPackageName] = useState('Frontier Multi-Node Synthetic Cluster');
  const [customerName, setCustomerName] = useState('DeepGenesis Labs Inc. (San Francisco)');
  const [workloadClass, setWorkloadClass] = useState<WorkloadClass>('large_model_training');
  const [acceleratorType, setAcceleratorType] = useState<AcceleratorType>('NVIDIA_H100_SXM5_80GB');
  const [acceleratorCount, setAcceleratorCount] = useState<number>(256);
  const [interconnect, setInterconnect] = useState<InterconnectTopology>('NVLink4_InfiniBand_800G');
  const [region, setRegion] = useState<GeographicRegion>('US-East (Virginia)');
  const [dataResidencyStrict, setDataResidencyStrict] = useState<boolean>(true);
  const [durationDays, setDurationDays] = useState<number>(30);
  const [targetBudgetUSD, setTargetBudgetUSD] = useState<number>(850000);
  const [storageCapacityTB, setStorageCapacityTB] = useState<number>(1200);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const workloadReq: WorkloadRequirement = {
      workloadClass,
      workloadName: `${packageName} (${workloadClass})`,
      acceleratorType,
      acceleratorCount,
      memoryMinGBPerGPU: acceleratorType === 'NVIDIA_H200_SXM5_141GB' ? 141 : 80,
      interconnect,
      minNetworkThroughputGbps: 800,
      storageCapacityTB,
      storageMinIOPS: 350000,
      region,
      dataResidencyStrict,
      startDate: new Date().toISOString(),
      durationHours: durationDays * 24,
      targetMaxBudgetUSD: targetBudgetUSD,
      sloAvailabilityPct: 99.95,
      maxLatencyMs: 20,
    };

    createNewPackage(packageName, customerName, workloadReq);
    setActiveWorkspace('package_factory');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 rounded-lg max-w-2xl w-full shadow-2xl overflow-hidden my-8">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/80">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded bg-sky-950 border border-sky-800 text-sky-400">
              <Layers className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Assemble Institutional Compute Package</h2>
              <p className="text-[11px] text-slate-400">Specify requirements to trigger multi-provider optimization and physical synthesis.</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs font-sans">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-slate-300 font-medium mb-1">Package Name</label>
              <input
                type="text"
                required
                value={packageName}
                onChange={(e) => setPackageName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-slate-200 focus:outline-none focus:border-sky-500"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">Customer Entity</label>
              <input
                type="text"
                required
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-slate-200 focus:outline-none focus:border-sky-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-slate-300 font-medium mb-1">Workload Archetype</label>
              <select
                value={workloadClass}
                onChange={(e) => setWorkloadClass(e.target.value as WorkloadClass)}
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-slate-200 focus:outline-none focus:border-sky-500"
              >
                <option value="large_model_training">Large-Model Training (Dense / MoE)</option>
                <option value="ai_inference">Low-Latency Distributed Inference</option>
                <option value="fine_tuning">Domain Adaptation / Fine-Tuning</option>
                <option value="high_performance_computing">HPC & Numerical Astrophysics</option>
                <option value="scientific_simulation">Biochemical Molecular Simulation</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">Accelerator Architecture</label>
              <select
                value={acceleratorType}
                onChange={(e) => setAcceleratorType(e.target.value as AcceleratorType)}
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-slate-200 focus:outline-none focus:border-sky-500 font-mono"
              >
                <option value="NVIDIA_H100_SXM5_80GB">NVIDIA H100 SXM5 80GB</option>
                <option value="NVIDIA_H200_SXM5_141GB">NVIDIA H200 SXM5 141GB</option>
                <option value="NVIDIA_B200_NVL_192GB">NVIDIA B200 NVL 192GB</option>
                <option value="NVIDIA_GB200_NVL72">NVIDIA GB200 NVL72</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-slate-300 font-medium mb-1">GPU Accelerator Count</label>
              <input
                type="number"
                min="16"
                max="2048"
                step="8"
                value={acceleratorCount}
                onChange={(e) => setAcceleratorCount(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-slate-200 focus:outline-none focus:border-sky-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">Interconnect Fabric</label>
              <select
                value={interconnect}
                onChange={(e) => setInterconnect(e.target.value as InterconnectTopology)}
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-slate-200 focus:outline-none focus:border-sky-500 font-mono text-[11px]"
              >
                <option value="NVLink4_InfiniBand_800G">NVLink4 + 800G InfiniBand</option>
                <option value="NVLink5_InfiniBand_800G">NVLink5 + 800G InfiniBand</option>
                <option value="PCIe5_RoCEv2_400G">PCIe5 + 400G RoCEv2</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">Geographic Region</label>
              <select
                value={region}
                onChange={(e) => setRegion(e.target.value as GeographicRegion)}
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-slate-200 focus:outline-none focus:border-sky-500"
              >
                <option value="US-East (Virginia)">US-East (Virginia)</option>
                <option value="US-West (Phoenix)">US-West (Phoenix)</option>
                <option value="EU-Central (Frankfurt)">EU-Central (Frankfurt)</option>
                <option value="Nordic-Green (Reykjavik)">Nordic-Green (Reykjavik)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-slate-300 font-medium mb-1">Contract Duration (Days)</label>
              <input
                type="number"
                min="3"
                max="365"
                value={durationDays}
                onChange={(e) => setDurationDays(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-slate-200 focus:outline-none focus:border-sky-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">Target Budget ($ USD)</label>
              <input
                type="number"
                min="10000"
                step="10000"
                value={targetBudgetUSD}
                onChange={(e) => setTargetBudgetUSD(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-slate-200 focus:outline-none focus:border-sky-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">High-Speed Storage (TB)</label>
              <input
                type="number"
                min="100"
                max="5000"
                value={storageCapacityTB}
                onChange={(e) => setStorageCapacityTB(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-slate-200 focus:outline-none focus:border-sky-500 font-mono"
              />
            </div>
          </div>

          <div className="flex items-center gap-2 pt-2">
            <input
              type="checkbox"
              id="strictResidency"
              checked={dataResidencyStrict}
              onChange={(e) => setDataResidencyStrict(e.target.checked)}
              className="rounded bg-slate-950 border-slate-700 accent-sky-500"
            />
            <label htmlFor="strictResidency" className="text-slate-300 cursor-pointer">
              Enforce strict data residency (Hard constraint: zero compute allocation outside {region})
            </label>
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-slate-400 hover:text-white transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white font-semibold rounded shadow-md transition-colors"
            >
              Solve Capacity & Synthesize Package
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
