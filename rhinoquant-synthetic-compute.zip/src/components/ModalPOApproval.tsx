import React, { useState } from 'react';
import { useAppStore } from '../state/store';
import { PurchaseOrder } from '../types';
import { X, ShieldCheck, UserCheck, CheckCircle2 } from 'lucide-react';

interface ModalPOApprovalProps {
  isOpen: boolean;
  po: PurchaseOrder | null;
  onClose: () => void;
}

export const ModalPOApproval: React.FC<ModalPOApprovalProps> = ({ isOpen, po, onClose }) => {
  const { approvePO } = useAppStore();

  const [role, setRole] = useState<'CHIEF_FINANCIAL_OFFICER' | 'HEAD_OF_INFRASTRUCTURE'>('CHIEF_FINANCIAL_OFFICER');
  const [signeeName, setSigneeName] = useState('Evelyn Sterling (Chief Financial Officer)');

  if (!isOpen || !po) return null;

  const handleRoleChange = (newRole: 'CHIEF_FINANCIAL_OFFICER' | 'HEAD_OF_INFRASTRUCTURE') => {
    setRole(newRole);
    if (newRole === 'CHIEF_FINANCIAL_OFFICER') {
      setSigneeName('Evelyn Sterling (Chief Financial Officer)');
    } else {
      setSigneeName('Dr. Marcus Vance (VP Infrastructure Engineering)');
    }
  };

  const handleSign = (e: React.FormEvent) => {
    e.preventDefault();
    approvePO(po.poId, role, signeeName);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 rounded-lg max-w-lg w-full shadow-2xl overflow-hidden my-8">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/80">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded bg-amber-950 border border-amber-800 text-amber-400">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Dual Authorisation Execution</h2>
              <p className="text-[11px] text-slate-400">Mandatory dual governance sign-off for capital expenditure above $250,000 USD.</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSign} className="p-6 space-y-4 text-xs font-sans">
          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1.5 font-mono">
            <div className="flex justify-between text-slate-400">
              <span>PO Identifier:</span>
              <span className="text-slate-200 font-bold">{po.poNumber}</span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>Total Financial Liability:</span>
              <span className="text-emerald-400 font-bold">${po.totalAmountUSD.toLocaleString()} USD</span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>Supplier Entity:</span>
              <span className="text-slate-200">{po.supplierName}</span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>Current Status:</span>
              <span className="text-amber-400">{po.status}</span>
            </div>
          </div>

          <div>
            <label className="block text-slate-300 font-medium mb-1">Authorising Governance Officer Role</label>
            <select
              value={role}
              onChange={(e) => handleRoleChange(e.target.value as any)}
              className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-slate-200 focus:outline-none focus:border-amber-500 font-mono"
            >
              <option value="CHIEF_FINANCIAL_OFFICER">Chief Financial Officer (Capital Release)</option>
              <option value="HEAD_OF_INFRASTRUCTURE">Head of Infrastructure (Technical Validation)</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-300 font-medium mb-1">Authoriser Legal Name & Title</label>
            <input
              type="text"
              required
              value={signeeName}
              onChange={(e) => setSigneeName(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-slate-200 focus:outline-none focus:border-amber-500"
            />
          </div>

          <div className="p-3 bg-slate-950/60 rounded border border-slate-800 text-[11px] text-slate-400 leading-relaxed">
            By executing this cryptographic dual-approval, you certify that technical compatibility, facility substation envelopes, and budgetary limits have been inspected and reconciled against the underlying compute package contract.
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-slate-400 hover:text-white transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded shadow-md transition-colors flex items-center gap-1.5"
            >
              <UserCheck className="w-4 h-4" />
              <span>Sign & Authorise PO</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
