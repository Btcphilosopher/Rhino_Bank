import React from 'react';
import { useAppStore } from '../state/store';
import { Server, Cpu, Zap, Thermometer, Layers, CheckCircle2, Shield, AlertTriangle } from 'lucide-react';

export const WorkspaceInfrastructureEngineering: React.FC = () => {
  const { packages, selectedPackageId } = useAppStore();
  const pkg = packages.find((p) => p.id === selectedPackageId) || packages[0];
  const design = pkg?.infrastructureDesign;

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">Physical Infrastructure Engineering & Facility Synthesis</h1>
          <p className="text-xs text-slate-400 mt-1">
            Thermodynamic, electrical, mechanical, and network fabric validation for physical cluster deployments.
          </p>
        </div>

        {design && (
          <div className="font-mono text-xs text-slate-300 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded">
            Target Expansion: <strong className="text-sky-400">{design.targetGPUExpansion} GPUs</strong> · Total Mass: <strong className="text-white">{design.totalMassKg.toLocaleString()} kg</strong>
          </div>
        )}
      </div>

      {!design ? (
        <div className="p-12 text-center border border-slate-800 rounded bg-slate-900/40 text-slate-400 text-xs">
          The selected package does not require physical infrastructure expansion (100% satisfied via cloud capacity).
        </div>
      ) : (
        <div className="space-y-6">
          {/* Engineering Parameter KPIs */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            <div className="bg-slate-900/80 border border-slate-800 p-3 rounded font-mono">
              <div className="text-[10px] uppercase text-slate-400 flex items-center gap-1">
                <Zap className="w-3.5 h-3.5 text-amber-400" />
                <span>Peak Power Demand</span>
              </div>
              <div className="text-lg font-bold text-white tabular-nums mt-0.5">
                {design.peakPowerDemandKW} <span className="text-xs font-normal text-slate-400">kW</span>
              </div>
              <div className="text-[11px] text-slate-500 font-sans">Continuous steady state: {design.totalPowerDemandKW} kW</div>
            </div>

            <div className="bg-slate-900/80 border border-slate-800 p-3 rounded font-mono">
              <div className="text-[10px] uppercase text-slate-400 flex items-center gap-1">
                <Thermometer className="w-3.5 h-3.5 text-sky-400" />
                <span>Cooling Rejection</span>
              </div>
              <div className="text-lg font-bold text-sky-300 tabular-nums mt-0.5">
                {design.coolingCapacityRequiredKW} <span className="text-xs font-normal text-slate-400">kW</span>
              </div>
              <div className="text-[11px] text-slate-500 font-sans">Direct-to-Chip Liquid ({design.cduRedundancy} CDU)</div>
            </div>

            <div className="bg-slate-900/80 border border-slate-800 p-3 rounded font-mono">
              <div className="text-[10px] uppercase text-slate-400 flex items-center gap-1">
                <Server className="w-3.5 h-3.5 text-indigo-400" />
                <span>Rack Density</span>
              </div>
              <div className="text-lg font-bold text-indigo-300 tabular-nums mt-0.5">
                {design.rackCount} <span className="text-xs font-normal text-slate-400">Racks (48U)</span>
              </div>
              <div className="text-[11px] text-slate-500 font-sans">{design.serverNodeCount}x 8-GPU chassis installed</div>
            </div>

            <div className="bg-slate-900/80 border border-slate-800 p-3 rounded font-mono">
              <div className="text-[10px] uppercase text-slate-400 flex items-center gap-1">
                <Layers className="w-3.5 h-3.5 text-emerald-400" />
                <span>Floor Mass Load</span>
              </div>
              <div className="text-lg font-bold text-emerald-300 tabular-nums mt-0.5">
                {design.floorLoadKgPerSqm} <span className="text-xs font-normal text-slate-400">kg/m²</span>
              </div>
              <div className="text-[11px] text-slate-500 font-sans">Seismic rated limit: 1,800 kg/m²</div>
            </div>

            <div className="bg-slate-900/80 border border-slate-800 p-3 rounded font-mono">
              <div className="text-[10px] uppercase text-slate-400 flex items-center gap-1">
                <Cpu className="w-3.5 h-3.5 text-purple-400" />
                <span>Fabric Topology</span>
              </div>
              <div className="text-lg font-bold text-purple-300 tabular-nums mt-0.5">
                800G IB
              </div>
              <div className="text-[11px] text-slate-500 font-sans">{design.oversubscriptionRatio}</div>
            </div>
          </div>

          {/* Detailed Engineering View: SVG Rack Elevation + Facility Validation */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* SVG Rack Elevation Diagram (1/3 width) */}
            <div className="bg-slate-900/60 border border-slate-800 rounded p-4">
              <h3 className="text-sm font-semibold text-slate-200 border-b border-slate-800 pb-2 mb-3">
                48U Enterprise Liquid-Cooled Rack Elevation
              </h3>

              <div className="bg-slate-950 p-3 rounded border border-slate-800/80 flex justify-center">
                <svg viewBox="0 0 280 480" className="w-full max-w-[260px] h-auto text-slate-200">
                  {/* Outer 48U Frame */}
                  <rect x="20" y="20" width="240" height="440" rx="4" fill="#0f172a" stroke="#334155" strokeWidth="2" />
                  <rect x="26" y="26" width="228" height="428" rx="2" fill="#090d16" stroke="#1e293b" />

                  {/* RU markers & Header */}
                  <text x="140" y="42" textAnchor="middle" fill="#94a3b8" fontSize="10" fontFamily="monospace">48U SEISMIC FRAME - RITTAL</text>

                  {/* Leaf InfiniBand Switches (RU 45-48) */}
                  <rect x="36" y="55" width="208" height="30" rx="2" fill="#1e1b4b" stroke="#4338ca" />
                  <text x="140" y="74" textAnchor="middle" fill="#a5b4fc" fontSize="9" fontFamily="monospace">Quantum-2 800G Spine/Leaf Switches</text>

                  {/* Server Nodes: 8-GPU Chassis (RU 20-44) */}
                  <rect x="36" y="95" width="208" height="52" rx="2" fill="#0f263e" stroke="#0284c7" />
                  <text x="140" y="125" textAnchor="middle" fill="#7dd3fc" fontSize="9" fontFamily="monospace">Server Node 01: 8x H100 SXM5</text>

                  <rect x="36" y="155" width="208" height="52" rx="2" fill="#0f263e" stroke="#0284c7" />
                  <text x="140" y="185" textAnchor="middle" fill="#7dd3fc" fontSize="9" fontFamily="monospace">Server Node 02: 8x H100 SXM5</text>

                  <rect x="36" y="215" width="208" height="52" rx="2" fill="#0f263e" stroke="#0284c7" />
                  <text x="140" y="245" textAnchor="middle" fill="#7dd3fc" fontSize="9" fontFamily="monospace">Server Node 03: 8x H100 SXM5</text>

                  <rect x="36" y="275" width="208" height="52" rx="2" fill="#0f263e" stroke="#0284c7" />
                  <text x="140" y="305" textAnchor="middle" fill="#7dd3fc" fontSize="9" fontFamily="monospace">Server Node 04: 8x H100 SXM5</text>

                  {/* CDU Liquid Cooling Unit at Bottom (RU 1-12) */}
                  <rect x="36" y="340" width="208" height="85" rx="3" fill="#064e3b" stroke="#059669" />
                  <text x="140" y="375" textAnchor="middle" fill="#6ee7b7" fontSize="10" fontFamily="monospace" fontWeight="bold">Vertiv Liebert 120kW CDU</text>
                  <text x="140" y="395" textAnchor="middle" fill="#a7f3d0" fontSize="8" fontFamily="monospace">N+1 Pumps · Direct-to-Chip Loop</text>
                  <text x="140" y="410" textAnchor="middle" fill="#a7f3d0" fontSize="8" fontFamily="monospace">Secondary Supply 32°C / Return 45°C</text>

                  {/* Dual 3-Phase PDU Side Strips */}
                  <line x1="28" y1="50" x2="28" y2="440" stroke="#f59e0b" strokeWidth="3" />
                  <line x1="252" y1="50" x2="252" y2="440" stroke="#f59e0b" strokeWidth="3" />
                </svg>
              </div>
            </div>

            {/* Facility Envelope Readiness & Bill of Engineering (2/3 width) */}
            <div className="lg:col-span-2 space-y-6">
              {/* Facility Readiness Check */}
              <div className="bg-slate-900/60 border border-slate-800 rounded p-4">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
                  <h3 className="text-sm font-semibold text-slate-200">Data Centre Facility Envelope Validation</h3>
                  <span className="font-mono text-xs text-emerald-400 flex items-center gap-1 font-bold">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>OVERALL PASS</span>
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3 font-mono text-xs mb-3">
                  <div className="p-2.5 rounded bg-slate-950 border border-slate-800">
                    <div className="text-slate-400 text-[11px]">Substation Electrical Tap:</div>
                    <div className="text-emerald-400 font-bold mt-1">✓ PASS ({design.totalPowerDemandKW} kW within 450 kW line)</div>
                  </div>
                  <div className="p-2.5 rounded bg-slate-950 border border-slate-800">
                    <div className="text-slate-400 text-[11px]">CDU Closed Hydronic Loop:</div>
                    <div className="text-emerald-400 font-bold mt-1">✓ PASS (Primary chilled water available)</div>
                  </div>
                  <div className="p-2.5 rounded bg-slate-950 border border-slate-800">
                    <div className="text-slate-400 text-[11px]">Seismic Floor Weight Capacity:</div>
                    <div className="text-emerald-400 font-bold mt-1">✓ PASS ({design.floorLoadKgPerSqm} kg/m² &lt; 1,800 kg/m²)</div>
                  </div>
                  <div className="p-2.5 rounded bg-slate-950 border border-slate-800">
                    <div className="text-slate-400 text-[11px]">MTP/MPO Fiber Optical Path:</div>
                    <div className="text-emerald-400 font-bold mt-1">✓ PASS (Zero optical attenuation alerts)</div>
                  </div>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed font-sans bg-slate-950/60 p-3 rounded border border-slate-800/80">
                  {design.facilityReadinessCheck.notes}
                </p>
              </div>

              {/* Bill of Engineering Breakdown */}
              <div className="bg-slate-900/60 border border-slate-800 rounded p-4">
                <h3 className="text-sm font-semibold text-slate-200 border-b border-slate-800 pb-2 mb-3">
                  Engineering Component Specifications
                </h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-left">
                    <thead>
                      <tr className="border-b border-slate-800 text-slate-400 font-mono text-[11px]">
                        <th className="py-2">Category & Component</th>
                        <th className="py-2 text-right">Units</th>
                        <th className="py-2 text-right">Power Draw</th>
                        <th className="py-2 text-right">Mass (kg)</th>
                        <th className="py-2 text-center">Compatibility</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/40">
                      {design.bom.map((b, idx) => (
                        <tr key={idx} className="hover:bg-slate-900/40">
                          <td className="py-2.5">
                            <div className="font-semibold text-slate-200">{b.name}</div>
                            <div className="text-[10px] text-slate-500 font-mono">{b.componentCategory} · {b.manufacturer}</div>
                          </td>
                          <td className="py-2.5 text-right font-mono tabular-nums text-slate-200">{b.quantity} {b.unit}</td>
                          <td className="py-2.5 text-right font-mono tabular-nums text-amber-400">{b.powerDrawWattsPerUnit} W</td>
                          <td className="py-2.5 text-right font-mono tabular-nums text-slate-300">{b.massKgPerUnit} kg</td>
                          <td className="py-2.5 text-center">
                            <span className="font-mono text-[10px] text-emerald-400 px-1.5 py-0.5 rounded bg-emerald-950/60 border border-emerald-800">
                              VERIFIED
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
