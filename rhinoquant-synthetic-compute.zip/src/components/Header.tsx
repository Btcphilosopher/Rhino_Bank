import React from 'react';
import { useAppStore, WorkspaceId } from '../state/store';
import { Layers, RotateCcw, Play } from 'lucide-react';

interface HeaderProps {
  onOpenPackageBuilder: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenPackageBuilder }) => {
  const {
    activeWorkspace,
    setActiveWorkspace,
    resetToDeterministicSeed,
    workflowProgress,
    runEndToEndWorkflow
  } = useAppStore();

  const navItems: Array<{ id: WorkspaceId; label: string }> = [
    { id: 'package_factory', label: 'Package Factory' },
    { id: 'exchange', label: 'Compute Exchange' },
    { id: 'supply_infra', label: 'Supply & Infra' },
    { id: 'procurement', label: 'Procurement Desk' },
    { id: 'infra_engineering', label: 'Engineering' },
    { id: 'economics', label: 'Economics' },
    { id: 'forward_contracts', label: 'Contracts' },
    { id: 'portfolio_treasury', label: 'Portfolio' },
    { id: 'risk_control', label: 'Risk Control' },
    { id: 'metering', label: 'Reconciliation' },
    { id: 'audit', label: 'Audit' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-slate-950/95 backdrop-blur-md border-b border-slate-800/80 px-6 py-3 transition-colors">
      <div className="flex items-center justify-between gap-8 max-w-[1720px] mx-auto">
        {/* Zone 1: Single text element wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => setActiveWorkspace('package_factory')}
            className="flex items-center gap-2.5 text-left group focus:outline-none"
          >
            <div className="w-8 h-8 rounded bg-gradient-to-br from-slate-800 to-slate-900 border border-slate-700 flex items-center justify-center text-sky-400 font-bold text-sm tracking-wider">
              RQ
            </div>
            <div className="flex flex-col">
              <span className="text-base font-bold tracking-tight text-white group-hover:text-sky-300 transition-colors whitespace-nowrap">
                RHINOQUANT
              </span>
              <span className="text-[10px] uppercase tracking-widest text-slate-400 font-mono -mt-1">
                Synthetic Compute
              </span>
            </div>
          </button>
        </div>

        {/* Zone 2: Navigation Links (single line, clean typography) */}
        <nav className="hidden xl:flex items-center gap-1 overflow-x-auto py-1 scrollbar-none">
          {navItems.map((item) => {
            const isActive = activeWorkspace === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveWorkspace(item.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
                  isActive
                    ? 'bg-slate-800 text-sky-400 border border-slate-700/80 font-semibold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Primary Actions */}
        <div className="flex items-center gap-2.5 shrink-0">
          <button
            onClick={resetToDeterministicSeed}
            title="Reset environment to verified deterministic seed"
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-mono text-slate-400 hover:text-slate-200 bg-slate-900/80 border border-slate-800 rounded hover:bg-slate-800 transition-colors whitespace-nowrap"
          >
            <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
            <span>Reset Seed</span>
          </button>

          {!workflowProgress.isRunning ? (
            <button
              onClick={runEndToEndWorkflow}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-200 bg-slate-800/90 border border-slate-700 rounded hover:bg-slate-700 hover:text-white transition-colors whitespace-nowrap shadow-sm"
            >
              <Play className="w-3 h-3 text-emerald-400 fill-emerald-400" />
              <span>Run Pipeline</span>
            </button>
          ) : (
            <div className="flex items-center gap-2 px-3 py-1.5 text-xs font-mono text-emerald-400 bg-emerald-950/40 border border-emerald-800/50 rounded whitespace-nowrap">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <span>Pipeline Stage {workflowProgress.currentStep}/21</span>
            </div>
          )}

          <button
            onClick={onOpenPackageBuilder}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-white bg-sky-600 hover:bg-sky-500 rounded border border-sky-400/40 transition-colors whitespace-nowrap shadow-sm shadow-sky-950"
          >
            <Layers className="w-3.5 h-3.5" />
            <span>New Compute Package</span>
          </button>
        </div>
      </div>

      {/* Mobile / Tablet Horizontal Workspace Bar */}
      <div className="flex xl:hidden items-center gap-1 overflow-x-auto pt-2 pb-1 scrollbar-none border-t border-slate-800/50 mt-2">
        {navItems.map((item) => {
          const isActive = activeWorkspace === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveWorkspace(item.id)}
              className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
                isActive
                  ? 'bg-slate-800 text-sky-400 border border-slate-700'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {item.label}
            </button>
          );
        })}
      </div>
    </header>
  );
};
