import React, { useState } from 'react';
import { useAppStore } from '../state/store';
import { ShieldCheck, Lock, FileText, CheckCircle2, Search, Hash } from 'lucide-react';
import { SEED_VERSION } from '../state/initialData';

export const WorkspaceAuditGovernance: React.FC = () => {
  const { auditEvents } = useAppStore();
  const [filterAction, setFilterAction] = useState('ALL');
  const [search, setSearch] = useState('');

  const filteredEvents = auditEvents.filter((e) => {
    if (filterAction !== 'ALL' && e.action !== filterAction) return false;
    if (search && !e.summary.toLowerCase().includes(search.toLowerCase()) && !e.operator.toLowerCase().includes(search.toLowerCase())) {
      return false;
    }
    return true;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">Audit Trail, Governance & State Provenance</h1>
          <p className="text-xs text-slate-400 mt-1">
            Append-only cryptographically hashed transaction ledger documenting dual-authorisations, model runs, and PO commitments.
          </p>
        </div>

        <div className="font-mono text-xs text-slate-300 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded">
          Seed Provenance: <strong className="text-sky-400">{SEED_VERSION}</strong> · Audit Records: <strong className="text-white">{auditEvents.length}</strong>
        </div>
      </div>

      {/* Governance Invariants Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 font-mono text-xs">
        <div className="bg-slate-900/80 border border-slate-800 p-3 rounded">
          <div className="text-slate-400 text-[10px] uppercase">Dual Authorisation Policy</div>
          <div className="text-emerald-400 font-bold mt-1 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>ENFORCED ($250k+ CapEx Threshold)</span>
          </div>
          <div className="text-[11px] text-slate-500 font-sans mt-1">Requires concurrent sign-off from Infra VP and CFO.</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-3 rounded">
          <div className="text-slate-400 text-[10px] uppercase">Double-Selling Prevention Lock</div>
          <div className="text-sky-400 font-bold mt-1 flex items-center gap-1.5">
            <Lock className="w-4 h-4 text-sky-400" />
            <span>TRANSACTIONAL RESERVATION</span>
          </div>
          <div className="text-[11px] text-slate-500 font-sans mt-1">Hard atomicity on available GPU unit inventory.</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-3 rounded">
          <div className="text-slate-400 text-[10px] uppercase">State Reproducibility Seed</div>
          <div className="text-slate-200 font-bold mt-1 flex items-center gap-1.5">
            <Hash className="w-4 h-4 text-slate-400" />
            <span>DETERMINISTIC 2026.04</span>
          </div>
          <div className="text-[11px] text-slate-500 font-sans mt-1">All solver constraints & BOM outputs reproducible.</div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/60 p-3 rounded border border-slate-800 text-xs">
        <div className="flex items-center gap-3">
          <input
            type="text"
            placeholder="Search operator, event or target ID..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="px-3 py-1.5 bg-slate-950 border border-slate-700 rounded text-slate-200 placeholder-slate-500 focus:outline-none focus:border-sky-500 w-64"
          />

          <div className="flex items-center gap-1.5">
            <span className="text-slate-400 font-mono">Action Filter:</span>
            <select
              value={filterAction}
              onChange={(e) => setFilterAction(e.target.value)}
              className="bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-sky-500"
            >
              <option value="ALL">All Actions</option>
              <option value="CREATE_COMPUTE_PACKAGE">CREATE_COMPUTE_PACKAGE</option>
              <option value="VALIDATE_INFRASTRUCTURE_SYNTHESIS">VALIDATE_INFRASTRUCTURE_SYNTHESIS</option>
              <option value="DUAL_SIGNATURE_PO_APPROVAL">DUAL_SIGNATURE_PO_APPROVAL</option>
              <option value="RUN_PORTFOLIO_STRESS_TEST">RUN_PORTFOLIO_STRESS_TEST</option>
              <option value="RESOLVE_METERING_EXCEPTION">RESOLVE_METERING_EXCEPTION</option>
            </select>
          </div>
        </div>

        <div className="text-slate-400 font-mono text-[11px]">
          Showing {filteredEvents.length} verifiable audit logs
        </div>
      </div>

      {/* Append-Only Event Feed */}
      <div className="space-y-2 font-mono text-xs">
        {filteredEvents.map((evt) => (
          <div key={evt.id} className="p-3 bg-slate-950 rounded border border-slate-800 hover:border-slate-700 transition-colors">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-900 pb-2 mb-2">
              <div className="flex items-center gap-2">
                <span className="text-sky-400 font-bold">{evt.id}</span>
                <span className="text-slate-500">·</span>
                <span className="text-slate-200 font-semibold">{evt.action}</span>
                <span className="text-slate-500">·</span>
                <span className="text-amber-400 text-[11px]">[{evt.role}]</span>
              </div>
              <div className="flex items-center gap-3 text-slate-500 text-[11px]">
                <span className="text-slate-400">{evt.operator}</span>
                <span className="text-slate-600">|</span>
                <span>{new Date(evt.timestamp).toLocaleString()}</span>
              </div>
            </div>

            <div className="text-slate-300 font-sans text-xs leading-relaxed">
              {evt.summary}
            </div>

            <div className="mt-2 pt-2 border-t border-slate-900 flex items-center justify-between text-[10px] text-slate-500">
              <div className="flex items-center gap-2">
                <span>Target: <strong className="text-slate-400">{evt.targetEntityType} ({evt.targetEntityId})</strong></span>
              </div>
              <div className="flex items-center gap-1 font-mono">
                <Hash className="w-3 h-3 text-slate-600" />
                <span className="text-slate-400">{evt.auditHash}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
