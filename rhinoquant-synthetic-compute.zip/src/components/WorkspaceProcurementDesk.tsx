import React, { useState } from 'react';
import { useAppStore } from '../state/store';
import { PurchaseOrder, POStatus } from '../types';
import { PO_LIFECYCLE_STEPS } from '../engines/procurementEngine';
import { CheckCircle2, Clock, ShieldCheck, FileText, ArrowRight, UserCheck } from 'lucide-react';

interface WorkspaceProcurementDeskProps {
  onOpenApprovalModal: (po: PurchaseOrder) => void;
}

export const WorkspaceProcurementDesk: React.FC<WorkspaceProcurementDeskProps> = ({ onOpenApprovalModal }) => {
  const {
    purchaseOrders,
    selectedPOId,
    setSelectedPOId,
    advancePOMilestone,
    approvePO
  } = useAppStore();

  const selectedPO = purchaseOrders.find((p) => p.poId === selectedPOId) || purchaseOrders[0];

  const currentStepIdx = selectedPO ? PO_LIFECYCLE_STEPS.indexOf(selectedPO.status) : 0;

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">Procurement Desk & Capital Equipment Supply</h1>
          <p className="text-xs text-slate-400 mt-1">
            Institutional purchase order lifecycle, dual-authorisation controls, and physical commissioning milestone tracking.
          </p>
        </div>

        {/* PO Selector */}
        {purchaseOrders.length > 0 && (
          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-400 font-mono">Active PO:</span>
            <select
              value={selectedPO?.poId}
              onChange={(e) => setSelectedPOId(e.target.value)}
              className="bg-slate-900 border border-slate-700 rounded px-3 py-1.5 text-slate-200 text-xs font-mono font-medium focus:outline-none focus:border-sky-500"
            >
              {purchaseOrders.map((po) => (
                <option key={po.poId} value={po.poId}>
                  {po.poNumber} - ${po.totalAmountUSD.toLocaleString()} ({po.status})
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      {!selectedPO ? (
        <div className="p-12 text-center border border-slate-800 rounded bg-slate-900/40 text-slate-400 text-xs">
          No purchase orders issued yet. Generate a purchase order from a package with physical infrastructure shortfall.
        </div>
      ) : (
        <div className="space-y-6">
          {/* PO Overview Header Strip */}
          <div className="bg-slate-900/80 border border-slate-800 rounded p-4">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-3">
                  <span className="text-lg font-bold font-mono text-white">{selectedPO.poNumber}</span>
                  <span className="font-mono text-xs px-2 py-0.5 rounded bg-sky-950 text-sky-400 border border-sky-800">
                    {selectedPO.status}
                  </span>
                  {selectedPO.requiresDualApproval && (
                    <span className="font-mono text-xs px-2 py-0.5 rounded bg-amber-950 text-amber-400 border border-amber-800 flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3" />
                      <span>DUAL APPROVAL REQUIRED</span>
                    </span>
                  )}
                </div>
                <div className="text-xs text-slate-400 mt-1">
                  Supplier Consortium: <strong className="text-slate-200">{selectedPO.supplierName}</strong> · Lead Time: <span className="font-mono text-slate-200">{selectedPO.leadTimeWeeks} Weeks</span> · Est Delivery: <span className="font-mono text-slate-200">{selectedPO.estimatedDeliveryDate}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2.5">
                {selectedPO.status === 'APPROVAL_PENDING' && (
                  <button
                    onClick={() => onOpenApprovalModal(selectedPO)}
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-900 bg-amber-400 hover:bg-amber-300 rounded transition-colors shadow-sm"
                  >
                    <UserCheck className="w-3.5 h-3.5" />
                    <span>Execute Dual Approval</span>
                  </button>
                )}

                {selectedPO.status !== 'ACCEPTED' && (
                  <button
                    onClick={() => advancePOMilestone(selectedPO.poId)}
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-sky-600 hover:bg-sky-500 rounded transition-colors shadow-sm"
                  >
                    <span>Advance Next Milestone</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>

            {/* Lifecycle Timeline Progress */}
            <div className="mt-4 pt-4 border-t border-slate-800">
              <div className="text-[10px] uppercase font-mono text-slate-400 mb-2">
                Procurement State Machine Stage ({currentStepIdx + 1} of {PO_LIFECYCLE_STEPS.length})
              </div>
              <div className="grid grid-cols-5 md:grid-cols-8 lg:grid-cols-15 gap-1">
                {PO_LIFECYCLE_STEPS.map((step, idx) => {
                  const isDone = idx <= currentStepIdx;
                  const isCurrent = idx === currentStepIdx;
                  return (
                    <div
                      key={step}
                      title={step}
                      className={`text-center py-1 px-0.5 rounded text-[9px] font-mono truncate transition-colors ${
                        isCurrent
                          ? 'bg-sky-500 text-slate-950 font-bold'
                          : isDone
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-900'
                          : 'bg-slate-950 text-slate-600 border border-slate-900'
                      }`}
                    >
                      {step.replace(/_/g, ' ').substring(0, 8)}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Two-Column: Line Items (BOM) & Tracking Milestones */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left 2 Cols: Line Items */}
            <div className="lg:col-span-2 bg-slate-900/60 border border-slate-800 rounded p-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
                <h3 className="text-sm font-semibold text-slate-200">Contracted Bill of Materials Line Items</h3>
                <span className="font-mono text-xs text-sky-400 font-bold">
                  Total Commitment: ${selectedPO.totalAmountUSD.toLocaleString()} USD
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-400 font-mono text-[11px]">
                      <th className="py-2">SKU & Item Description</th>
                      <th className="py-2 text-right">Quantity</th>
                      <th className="py-2 text-right">Unit Price</th>
                      <th className="py-2 text-right">Extended Total</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/40">
                    {selectedPO.items.map((item, idx) => (
                      <tr key={idx} className="hover:bg-slate-900/40">
                        <td className="py-2.5">
                          <div className="font-semibold text-slate-200">{item.description}</div>
                          <div className="font-mono text-[10px] text-slate-500">{item.sku}</div>
                        </td>
                        <td className="py-2.5 text-right font-mono tabular-nums text-slate-200">
                          {item.quantity}
                        </td>
                        <td className="py-2.5 text-right font-mono tabular-nums text-slate-300">
                          ${item.unitPriceUSD.toLocaleString()}
                        </td>
                        <td className="py-2.5 text-right font-mono tabular-nums text-emerald-400 font-bold">
                          ${item.totalUSD.toLocaleString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Right Col: Dual Signatures & Physical Commissioning Milestones */}
            <div className="space-y-6">
              {/* Dual Approval Signatures */}
              <div className="bg-slate-900/60 border border-slate-800 rounded p-4 space-y-3">
                <h3 className="text-sm font-semibold text-slate-200 border-b border-slate-800 pb-2">
                  Dual Governance Signatures
                </h3>
                <div className="space-y-2 text-xs">
                  {selectedPO.approvalSignatures.map((sig, idx) => (
                    <div key={idx} className="bg-slate-950 p-2.5 rounded border border-slate-800">
                      <div className="flex items-center justify-between text-[11px] font-mono text-emerald-400">
                        <span>{sig.role.replace(/_/g, ' ')}</span>
                        <span>SIGNED</span>
                      </div>
                      <div className="font-medium text-slate-200 mt-0.5">{sig.signee}</div>
                      <div className="text-[10px] text-slate-500 font-mono mt-0.5">{new Date(sig.timestamp).toLocaleString()}</div>
                    </div>
                  ))}

                  {selectedPO.approvalSignatures.length < 2 && (
                    <div className="bg-amber-950/30 p-2.5 rounded border border-amber-900/60 text-amber-300 text-xs">
                      Awaiting dual sign-off from Chief Financial Officer for material expenditure release ($250k+ threshold).
                    </div>
                  )}
                </div>
              </div>

              {/* Physical Commissioning Milestones */}
              <div className="bg-slate-900/60 border border-slate-800 rounded p-4 space-y-3">
                <h3 className="text-sm font-semibold text-slate-200 border-b border-slate-800 pb-2">
                  Deployment & Commissioning Gates
                </h3>
                <div className="space-y-2 font-mono text-xs">
                  {selectedPO.trackingMilestones.map((ms, idx) => (
                    <div
                      key={idx}
                      className={`flex items-start gap-2.5 p-2 rounded border ${
                        ms.completed
                          ? 'bg-slate-950/80 border-slate-800 text-slate-200'
                          : 'bg-slate-950/30 border-slate-900 text-slate-500'
                      }`}
                    >
                      <CheckCircle2
                        className={`w-3.5 h-3.5 mt-0.5 shrink-0 ${
                          ms.completed ? 'text-emerald-400' : 'text-slate-700'
                        }`}
                      />
                      <div>
                        <div className="text-[11px] leading-tight">{ms.milestone}</div>
                        {ms.timestamp && <div className="text-[10px] text-slate-500 mt-0.5">{ms.timestamp}</div>}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
