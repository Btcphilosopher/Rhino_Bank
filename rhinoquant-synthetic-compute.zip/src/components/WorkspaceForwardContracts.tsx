import React from 'react';
import { useAppStore } from '../state/store';
import { FileText, Shield, Calendar, ArrowRight, CheckCircle2, Clock } from 'lucide-react';

export const WorkspaceForwardContracts: React.FC = () => {
  const { packages, selectedPackageId, setSelectedPackageId } = useAppStore();

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">Forward Capacity Contracts & Delivery Registry</h1>
          <p className="text-xs text-slate-400 mt-1">
            Standardised, versioned bilateral compute purchase agreements with physical asset backing and delivery milestones.
          </p>
        </div>

        <div className="font-mono text-xs text-slate-300 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded">
          Active Forward Contracts: <strong className="text-sky-400">{packages.length}</strong>
        </div>
      </div>

      <div className="overflow-x-auto rounded border border-slate-800 bg-slate-950">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="border-b border-slate-800 bg-slate-900/80 text-slate-400 font-mono text-[11px]">
              <th className="py-2.5 px-4">Contract ID & Customer</th>
              <th className="py-2.5 px-3">Underlying Product</th>
              <th className="py-2.5 px-3">Delivery Term</th>
              <th className="py-2.5 px-3 text-right">Contracted Volume</th>
              <th className="py-2.5 px-3 text-right">Contract Value</th>
              <th className="py-2.5 px-3 text-center">Backing Classification</th>
              <th className="py-2.5 px-3 text-center">Assurance Ratio</th>
              <th className="py-2.5 px-4 text-center">Contract Lifecycle</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 font-sans">
            {packages.map((pkg) => {
              const { backing, workload, economics } = pkg;
              return (
                <tr
                  key={pkg.id}
                  onClick={() => setSelectedPackageId(pkg.id)}
                  className={`hover:bg-slate-900/50 cursor-pointer transition-colors ${
                    selectedPackageId === pkg.id ? 'bg-slate-900/60' : ''
                  }`}
                >
                  <td className="py-3 px-4">
                    <div className="font-mono text-sky-400 font-bold">{backing.contractId}</div>
                    <div className="font-semibold text-slate-200 mt-0.5">{pkg.customerName}</div>
                    <div className="text-[10px] text-slate-500 font-mono">{pkg.packageName}</div>
                  </td>
                  <td className="py-3 px-3">
                    <div className="text-slate-200 font-medium">{workload.acceleratorCount}x {workload.acceleratorType.split('_')[1]}</div>
                    <div className="text-[10px] text-slate-400 font-mono">{workload.region}</div>
                  </td>
                  <td className="py-3 px-3 font-mono text-[11px] text-slate-300">
                    <div>{pkg.targetStartDate}</div>
                    <div className="text-slate-500">to {pkg.targetCompletionDate}</div>
                  </td>
                  <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-200">
                    <div className="font-bold">{backing.contractedGPUHours.toLocaleString()}</div>
                    <div className="text-[10px] text-slate-500 font-sans">GPU-Hours</div>
                  </td>
                  <td className="py-3 px-3 text-right font-mono tabular-nums">
                    <div className="text-emerald-400 font-bold">${economics.customerContractPriceUSD.toLocaleString()}</div>
                    <div className="text-[10px] text-slate-500">${economics.effectivePricePerGPUHourUSD}/GPU-h</div>
                  </td>
                  <td className="py-3 px-3 text-center">
                    <span
                      className={`font-mono text-[10px] px-2 py-0.5 rounded border ${
                        backing.overallClassification === 'COMMISSIONED'
                          ? 'bg-emerald-950 text-emerald-400 border-emerald-800'
                          : backing.overallClassification === 'SUPPLIER_CONFIRMED' || backing.overallClassification === 'PROVIDER_CONFIRMED'
                          ? 'bg-sky-950 text-sky-400 border-sky-800'
                          : 'bg-amber-950 text-amber-400 border-amber-800'
                      }`}
                    >
                      {backing.overallClassification}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-center font-mono tabular-nums">
                    <div className="text-xs font-bold text-slate-200">{backing.backingRatioPct}%</div>
                    <div className="w-16 bg-slate-900 h-1.5 rounded-full mx-auto mt-1 overflow-hidden">
                      <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${backing.backingRatioPct}%` }} />
                    </div>
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span
                      className={`font-mono text-[10px] px-2 py-0.5 rounded ${
                        pkg.status === 'OPERATIONAL'
                          ? 'bg-emerald-950/80 text-emerald-400 font-bold'
                          : 'bg-slate-800 text-slate-300'
                      }`}
                    >
                      {pkg.status}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
