import React from 'react';
import { useAppStore } from '../state/store';
import { DollarSign, Landmark, Briefcase, TrendingUp, ShieldAlert, ArrowUpRight } from 'lucide-react';

export const WorkspacePortfolioTreasury: React.FC = () => {
  const { packages, purchaseOrders } = useAppStore();

  const totalContractedReceivablesUSD = packages.reduce((acc, p) => acc + p.economics.customerContractPriceUSD, 0);
  const totalProcurementCommittedUSD = purchaseOrders.reduce((acc, p) => acc + p.totalAmountUSD, 0);
  const totalProviderOpexUSD = packages.reduce((acc, p) => acc + p.economics.existingProviderOpexUSD, 0);
  const totalPortfolioGrossMarginUSD = packages.reduce((acc, p) => acc + p.economics.grossMarginUSD, 0);
  const treasuryLiquidityReserveUSD = 4500000; // $4.5M institutional treasury facility

  // Counterparty exposure table
  const counterparties = [
    { name: 'CoreWeave Inc.', role: 'GPU Cloud Provider', committedExposureUSD: 441600, creditRating: 'A-', collateralTerms: 'Net 30' },
    { name: 'Nebius Group N.V.', role: 'European Grid Provider', committedExposureUSD: 89241, creditRating: 'A', collateralTerms: 'Pre-funded reserve' },
    { name: 'Supermicro Enterprise OEM', role: 'Hardware Manufacturer', committedExposureUSD: 1385000, creditRating: 'AA-', collateralTerms: '30% deposit, 70% delivery' },
    { name: 'Equinix Metal', role: 'Colocation & Bare Metal', committedExposureUSD: 81792, creditRating: 'A+', collateralTerms: 'Master Services Agreement' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">Portfolio Treasury & Working Capital Allocation</h1>
          <p className="text-xs text-slate-400 mt-1">
            Cash-flow maturity schedules, provider counterparty exposures, and liquidity reserves for synthetic compute liabilities.
          </p>
        </div>

        <div className="font-mono text-xs text-slate-300 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded">
          Treasury Revolving Facility: <strong className="text-emerald-400">${treasuryLiquidityReserveUSD.toLocaleString()} USD</strong>
        </div>
      </div>

      {/* Treasury Balance KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 font-mono">
        <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded">
          <div className="text-[10px] uppercase text-slate-400">Total Customer Receivables</div>
          <div className="text-xl font-bold text-sky-400 tabular-nums mt-0.5">
            ${totalContractedReceivablesUSD.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500 font-sans mt-0.5">Contracted forward revenues</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded">
          <div className="text-[10px] uppercase text-slate-400">Hardware CapEx Committed</div>
          <div className="text-xl font-bold text-slate-200 tabular-nums mt-0.5">
            ${totalProcurementCommittedUSD.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500 font-sans mt-0.5">Approved purchase order liabilities</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded">
          <div className="text-[10px] uppercase text-slate-400">Provider Cloud Liabilities</div>
          <div className="text-xl font-bold text-amber-400 tabular-nums mt-0.5">
            ${totalProviderOpexUSD.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500 font-sans mt-0.5">Committed provider reservation OPEX</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded">
          <div className="text-[10px] uppercase text-slate-400">Net Portfolio Value Added</div>
          <div className="text-xl font-bold text-emerald-400 tabular-nums mt-0.5">
            ${totalPortfolioGrossMarginUSD.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500 font-sans mt-0.5">Net cash contribution across all packages</div>
        </div>
      </div>

      {/* Counterparty Exposure & Treasury Cashflow Schedule */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Counterparty Concentration Register */}
        <div className="bg-slate-900/60 border border-slate-800 rounded p-4">
          <h3 className="text-sm font-semibold text-slate-200 border-b border-slate-800 pb-2 mb-3">
            Counterparty Credit & Delivery Concentration
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 font-mono text-[11px]">
                  <th className="py-2">Counterparty</th>
                  <th className="py-2">Role</th>
                  <th className="py-2 text-right">Exposure ($)</th>
                  <th className="py-2 text-center">Credit Rating</th>
                  <th className="py-2 text-right">Settlement Terms</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/40">
                {counterparties.map((cp, idx) => (
                  <tr key={idx} className="hover:bg-slate-900/40">
                    <td className="py-2.5 font-semibold text-slate-200">{cp.name}</td>
                    <td className="py-2.5 text-slate-400 text-[11px]">{cp.role}</td>
                    <td className="py-2.5 text-right font-mono tabular-nums text-slate-200 font-bold">
                      ${cp.committedExposureUSD.toLocaleString()}
                    </td>
                    <td className="py-2.5 text-center font-mono text-[11px] text-sky-400">{cp.creditRating}</td>
                    <td className="py-2.5 text-right font-mono text-[11px] text-slate-400">{cp.collateralTerms}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* 12-Month Cashflow Maturity Profile */}
        <div className="bg-slate-900/60 border border-slate-800 rounded p-4 font-mono text-xs space-y-3">
          <h3 className="text-sm font-semibold text-slate-200 border-b border-slate-800 pb-2 font-sans">
            Working Capital 4-Quarter Maturity Schedule
          </h3>
          
          <div className="space-y-2">
            <div className="flex justify-between items-center p-2 rounded bg-slate-950 border border-slate-800">
              <div>
                <span className="font-bold text-slate-200">Q4 2026 (Immediate Delivery):</span>
                <div className="text-[11px] text-slate-400 font-sans">Hardware procurement + Frontier 70B cluster deployment</div>
              </div>
              <div className="text-right">
                <div className="text-emerald-400 font-bold">+$525,559 Net Inflow</div>
                <div className="text-[10px] text-slate-500">$1.63M in / $1.11M out</div>
              </div>
            </div>

            <div className="flex justify-between items-center p-2 rounded bg-slate-950 border border-slate-800">
              <div>
                <span className="font-bold text-slate-200">Q1 2027 (Ongoing Utilization):</span>
                <div className="text-[11px] text-slate-400 font-sans">Sustained pre-training recurring billings & amortized power</div>
              </div>
              <div className="text-right">
                <div className="text-emerald-400 font-bold">+$418,200 Net Inflow</div>
                <div className="text-[10px] text-slate-500">$640k in / $222k out</div>
              </div>
            </div>

            <div className="flex justify-between items-center p-2 rounded bg-slate-950 border border-slate-800">
              <div>
                <span className="font-bold text-slate-200">Q2 2027 - Q3 2027 (Long-Term Yield):</span>
                <div className="text-[11px] text-slate-400 font-sans">Secondary capacity renewal cycles and colocation dividends</div>
              </div>
              <div className="text-right">
                <div className="text-emerald-400 font-bold">+$890,000 Net Inflow</div>
                <div className="text-[10px] text-slate-500">$1.28M in / $390k out</div>
              </div>
            </div>
          </div>

          <div className="text-[11px] text-slate-400 pt-2 font-sans border-t border-slate-800/80">
            RhinoQuant maintains a minimum 1.5x working capital liquidity coverage ratio against unhedged spot reservations.
          </div>
        </div>
      </div>
    </div>
  );
};
