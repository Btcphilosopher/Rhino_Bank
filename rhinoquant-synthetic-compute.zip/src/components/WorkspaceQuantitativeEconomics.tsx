import React from 'react';
import { useAppStore } from '../state/store';
import { DollarSign, TrendingUp, Percent, Shield, ArrowDownRight, ArrowUpRight } from 'lucide-react';

export const WorkspaceQuantitativeEconomics: React.FC = () => {
  const { packages, selectedPackageId } = useAppStore();
  const pkg = packages.find((p) => p.id === selectedPackageId) || packages[0];
  const econ = pkg?.economics;

  if (!econ) {
    return (
      <div className="p-12 text-center text-xs text-slate-400">
        No economic valuation available. Select a compute package.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">Quantitative Financial Engine & Unit Economics</h1>
          <p className="text-xs text-slate-400 mt-1">
            Cash-flow schedules, capital expenditure amortization, IRR, NPV, and sensitivity matrices for package: <strong className="text-slate-200">{pkg.packageName}</strong>.
          </p>
        </div>

        <div className="font-mono text-xs text-slate-300 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded">
          Contract Revenue: <strong className="text-sky-400">${econ.customerContractPriceUSD.toLocaleString()} USD</strong> · Net Margin: <strong className="text-emerald-400">{econ.grossMarginPct}%</strong>
        </div>
      </div>

      {/* Financial KPI Dashboard */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 font-mono">
        <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded">
          <div className="text-[10px] uppercase text-slate-400">Gross Delivered Margin</div>
          <div className="text-xl font-bold text-emerald-400 tabular-nums mt-0.5">
            ${econ.grossMarginUSD.toLocaleString()} <span className="text-xs font-normal text-slate-400">({econ.grossMarginPct}%)</span>
          </div>
          <div className="text-[11px] text-slate-500 font-sans mt-0.5">Target hurdle: 25.0%</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded">
          <div className="text-[10px] uppercase text-slate-400">Internal Rate of Return (IRR)</div>
          <div className="text-xl font-bold text-sky-400 tabular-nums mt-0.5">
            {econ.irrPct}%
          </div>
          <div className="text-[11px] text-slate-500 font-sans mt-0.5">Net Present Value: ${econ.npvUSD.toLocaleString()}</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded">
          <div className="text-[10px] uppercase text-slate-400">Physical CapEx Payback</div>
          <div className="text-xl font-bold text-slate-200 tabular-nums mt-0.5">
            {econ.paybackPeriodMonths} <span className="text-xs font-normal text-slate-400">Months</span>
          </div>
          <div className="text-[11px] text-slate-500 font-sans mt-0.5">Amortized over 36-month hardware life</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded">
          <div className="text-[10px] uppercase text-slate-400">Break-Even Utilization</div>
          <div className="text-xl font-bold text-amber-400 tabular-nums mt-0.5">
            {econ.breakEvenUtilizationPct}%
          </div>
          <div className="text-[11px] text-slate-500 font-sans mt-0.5">Required cluster job occupancy</div>
        </div>
      </div>

      {/* Financial Statement & Cost Allocation Structure */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Waterfall Cost Allocation */}
        <div className="bg-slate-900/60 border border-slate-800 rounded p-4">
          <h3 className="text-sm font-semibold text-slate-200 border-b border-slate-800 pb-2 mb-3">
            Contract Economic Waterfall ($ USD)
          </h3>
          <div className="space-y-2.5 font-mono text-xs">
            <div className="flex justify-between items-center py-1.5 border-b border-slate-800/80">
              <span className="text-slate-300 font-semibold">1. Customer Contract Gross Revenue:</span>
              <span className="text-sky-400 font-bold">${econ.customerContractPriceUSD.toLocaleString()}</span>
            </div>

            <div className="flex justify-between items-center py-1 text-slate-400 pl-4">
              <span>- Third-Party Provider Cloud OPEX:</span>
              <span className="text-slate-300">${econ.existingProviderOpexUSD.toLocaleString()}</span>
            </div>

            <div className="flex justify-between items-center py-1 text-slate-400 pl-4">
              <span>- Hardware Amortization / CapEx Allocation:</span>
              <span className="text-slate-300">${Math.round(econ.physicalInfrastructureCapexUSD * 0.25).toLocaleString()}</span>
            </div>

            <div className="flex justify-between items-center py-1 text-slate-400 pl-4">
              <span>- Data Centre Electricity & PUE OPEX:</span>
              <span className="text-slate-300">${econ.powerOpexUSD.toLocaleString()}</span>
            </div>

            <div className="flex justify-between items-center py-1 text-slate-400 pl-4">
              <span>- Liquid Cooling & Facility Colocation:</span>
              <span className="text-slate-300">${econ.coolingAndFacilityOpexUSD.toLocaleString()}</span>
            </div>

            <div className="flex justify-between items-center py-1 text-slate-400 pl-4 border-b border-slate-800/60 pb-2">
              <span>- Engineering Staffing & Maintenance (24/7 SLA):</span>
              <span className="text-slate-300">${econ.staffingAndMaintenanceUSD.toLocaleString()}</span>
            </div>

            <div className="flex justify-between items-center py-1.5 border-b border-slate-800/80 font-bold">
              <span className="text-slate-200">Total Cost of Delivery:</span>
              <span className="text-amber-400">${econ.totalCostOfDeliveryUSD.toLocaleString()}</span>
            </div>

            <div className="flex justify-between items-center py-2 bg-emerald-950/40 border border-emerald-800/60 p-2 rounded font-bold text-sm">
              <span className="text-emerald-300">Net Contribution Margin:</span>
              <span className="text-emerald-400">${econ.grossMarginUSD.toLocaleString()} ({econ.grossMarginPct}%)</span>
            </div>
          </div>
        </div>

        {/* Sensitivity & Stress Matrix */}
        <div className="bg-slate-900/60 border border-slate-800 rounded p-4 space-y-4">
          <h3 className="text-sm font-semibold text-slate-200 border-b border-slate-800 pb-2">
            Quantitative Stress & Sensitivity Matrix
          </h3>
          <p className="text-xs text-slate-300 leading-relaxed font-sans">
            Stress-testing contract profitability under macroeconomic power shocks and supply chain component price inflation:
          </p>

          <div className="space-y-3 font-mono text-xs">
            <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-1">
              <div className="flex justify-between text-slate-200 font-semibold">
                <span>Scenario A: Regional Electricity Tariff +25%</span>
                <span className="text-emerald-400">{econ.sensitivityPowerIncrease25PctMargin}% Margin</span>
              </div>
              <div className="text-[11px] text-slate-400 font-sans">
                Impact: -$46,125 USD in additional power cost. Margin contracts by 3.4% but remains well above 25% hurdle.
              </div>
            </div>

            <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-1">
              <div className="flex justify-between text-slate-200 font-semibold">
                <span>Scenario B: Server Hardware Replacement Cost +20%</span>
                <span className="text-emerald-400">{econ.sensitivityHardwareCostIncrease20PctMargin}% Margin</span>
              </div>
              <div className="text-[11px] text-slate-400 font-sans">
                Impact: Hardware CapEx buffer absorbed by 3-year depreciation schedule; IRR adjusts from 38.6% to 34.2%.
              </div>
            </div>

            <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-1">
              <div className="flex justify-between text-slate-200 font-semibold">
                <span>Scenario C: Job Utilization Drops to 65%</span>
                <span className="text-amber-400">Break-Even Threshold (62.4%)</span>
              </div>
              <div className="text-[11px] text-slate-400 font-sans">
                Fixed capacity reservations cover minimum commitments; optional spot overflow can be released without penalty.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
