import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode } from 'react';
import {
  ComputePackage,
  ProviderInventoryItem,
  PurchaseOrder,
  MeteringRecord,
  RiskAlert,
  AuditEvent,
  WorkloadRequirement,
  POStatus,
  BOMItem
} from '../types';
import {
  INITIAL_PROVIDERS,
  INITIAL_PACKAGES,
  INITIAL_PURCHASE_ORDERS,
  INITIAL_METERING_RECORDS,
  INITIAL_RISK_ALERTS,
  INITIAL_AUDIT_EVENTS,
  SEED_VERSION
} from './initialData';
import {
  optimizeCapacityAllocation,
  calculateEconomics,
  calculateBackingSummary
} from '../engines/capacityOptimizer';
import { synthesizeInfrastructureDesign } from '../engines/infrastructureSynthesis';
import { createPurchaseOrderFromBOM } from '../engines/procurementEngine';
import { performReconciliation, ReconciliationSummary } from '../engines/meteringReconciliation';
import { evaluateStressScenario, StressScenarioConfig, StressSimulationResult } from '../engines/riskTreasuryEngine';

export type WorkspaceId =
  | 'exchange'
  | 'package_factory'
  | 'supply_infra'
  | 'procurement'
  | 'infra_engineering'
  | 'economics'
  | 'forward_contracts'
  | 'portfolio_treasury'
  | 'risk_control'
  | 'metering'
  | 'audit';

export interface WorkflowProgress {
  isRunning: boolean;
  currentStep: number;
  totalSteps: number;
  stepTitle: string;
  stepDescription: string;
  completedSteps: number[];
  logs: Array<{ timestamp: string; message: string; type: 'info' | 'success' | 'warn' }>;
}

interface AppStoreContextType {
  activeWorkspace: WorkspaceId;
  setActiveWorkspace: (ws: WorkspaceId) => void;
  packages: ComputePackage[];
  providers: ProviderInventoryItem[];
  purchaseOrders: PurchaseOrder[];
  meteringRecords: MeteringRecord[];
  riskAlerts: RiskAlert[];
  auditEvents: AuditEvent[];
  selectedPackageId: string;
  setSelectedPackageId: (id: string) => void;
  selectedPOId: string;
  setSelectedPOId: (id: string) => void;
  activeStressResult: StressSimulationResult | null;
  workflowProgress: WorkflowProgress;
  reconciliationSummary: ReconciliationSummary;
  
  // Actions
  createNewPackage: (
    name: string,
    customer: string,
    workload: WorkloadRequirement
  ) => ComputePackage;
  reservePackageCapacity: (packageId: string) => void;
  generatePOForPackage: (packageId: string) => PurchaseOrder | null;
  approvePO: (poId: string, role: 'HEAD_OF_INFRASTRUCTURE' | 'CHIEF_FINANCIAL_OFFICER', signee: string) => void;
  advancePOMilestone: (poId: string) => void;
  resolveMeteringException: (recordId: string, note: string) => void;
  runStressScenario: (config: StressScenarioConfig) => void;
  clearStressScenario: () => void;
  runEndToEndWorkflow: () => void;
  stepWorkflow: () => void;
  resetWorkflow: () => void;
  resetToDeterministicSeed: () => void;
}

const AppStoreContext = createContext<AppStoreContextType | null>(null);

export const AppStoreProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [activeWorkspace, setActiveWorkspace] = useState<WorkspaceId>('package_factory');
  const [packages, setPackages] = useState<ComputePackage[]>(INITIAL_PACKAGES);
  const [providers, setProviders] = useState<ProviderInventoryItem[]>(INITIAL_PROVIDERS);
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>(INITIAL_PURCHASE_ORDERS);
  const [meteringRecords, setMeteringRecords] = useState<MeteringRecord[]>(INITIAL_METERING_RECORDS);
  const [riskAlerts, setRiskAlerts] = useState<RiskAlert[]>(INITIAL_RISK_ALERTS);
  const [auditEvents, setAuditEvents] = useState<AuditEvent[]>(INITIAL_AUDIT_EVENTS);

  const [selectedPackageId, setSelectedPackageId] = useState<string>(INITIAL_PACKAGES[0]?.id || '');
  const [selectedPOId, setSelectedPOId] = useState<string>(INITIAL_PURCHASE_ORDERS[0]?.poId || '');
  const [activeStressResult, setActiveStressResult] = useState<StressSimulationResult | null>(null);

  const [workflowProgress, setWorkflowProgress] = useState<WorkflowProgress>({
    isRunning: false,
    currentStep: 0,
    totalSteps: 21,
    stepTitle: 'Idle - Ready for Master Execution',
    stepDescription: 'Click "Run End-to-End Pipeline" to execute the 21-stage institutional compute allocation & delivery workflow.',
    completedSteps: [],
    logs: [
      {
        timestamp: new Date().toLocaleTimeString(),
        message: `System initialized with deterministic seed ${SEED_VERSION}.`,
        type: 'info',
      },
    ],
  });

  const reconciliationSummary = useMemo(() => {
    return performReconciliation(meteringRecords);
  }, [meteringRecords]);

  const addAudit = (
    action: string,
    targetType: string,
    targetId: string,
    summary: string,
    operator = 'ops.director@rhinoquant.com',
    role = 'HEAD_OF_TRADING'
  ) => {
    const newEvent: AuditEvent = {
      id: `AUD-${Math.floor(1000 + Math.random() * 9000)}`,
      timestamp: new Date().toISOString(),
      operator,
      role,
      action,
      targetEntityType: targetType,
      targetEntityId: targetId,
      summary,
      auditHash: `0x${Math.random().toString(16).substring(2, 10)}${Math.random().toString(16).substring(2, 6)}`,
    };
    setAuditEvents((prev) => [newEvent, ...prev]);
  };

  const createNewPackage = (
    name: string,
    customer: string,
    workload: WorkloadRequirement
  ): ComputePackage => {
    const optResult = optimizeCapacityAllocation(workload, providers);

    let infraDesign = undefined;
    if (optResult.shortfall.hasShortfall) {
      infraDesign = synthesizeInfrastructureDesign({
        shortfallGPUs: optResult.shortfall.shortfallGPUs,
        acceleratorType: workload.acceleratorType,
        region: workload.region,
      });
    }

    const economics = calculateEconomics(
      workload,
      optResult.totalExistingOpexUSD,
      infraDesign ? infraDesign.capexTotalUSD : 0,
      infraDesign ? infraDesign.totalPowerDemandKW : 0
    );

    const backing = calculateBackingSummary(
      workload.acceleratorCount,
      workload.durationHours,
      optResult.allocations,
      optResult.shortfall.hasShortfall
    );

    const packageId = `PKG-${Math.floor(100000 + Math.random() * 900000)}`;
    economics.packageId = packageId;
    backing.packageId = packageId;

    const startDate = new Date();
    startDate.setDate(startDate.getDate() + 7);
    const endDate = new Date(startDate);
    endDate.setHours(endDate.getHours() + workload.durationHours);

    const newPkg: ComputePackage = {
      id: packageId,
      packageName: name,
      customerName: customer,
      workload,
      status: optResult.shortfall.hasShortfall ? 'OPTIMIZED' : 'COMMERCIAL_APPROVED',
      version: 1,
      createdAt: new Date().toISOString(),
      targetStartDate: startDate.toISOString().split('T')[0],
      targetCompletionDate: endDate.toISOString().split('T')[0],
      providerAllocations: optResult.allocations,
      shortfall: optResult.shortfall,
      infrastructureDesign: infraDesign,
      associatedPOIds: [],
      economics,
      backing,
      notes: optResult.shortfall.hasShortfall
        ? `Hybrid contract: ${optResult.totalAllocatedGPUs} GPUs allocated from provider cloud; ${optResult.shortfall.shortfallGPUs} GPUs physical data centre build synthesized.`
        : `100% capacity satisfied from existing provider inventory.`,
    };

    setPackages((prev) => [newPkg, ...prev]);
    setSelectedPackageId(packageId);

    addAudit(
      'CREATE_COMPUTE_PACKAGE',
      'PACKAGE',
      packageId,
      `Synthesized Compute Package "${name}" (${workload.acceleratorCount}x ${workload.acceleratorType}) for ${customer}.`
    );

    return newPkg;
  };

  const reservePackageCapacity = (packageId: string) => {
    setPackages((prev) =>
      prev.map((pkg) => {
        if (pkg.id !== packageId) return pkg;
        const updatedAllocations = pkg.providerAllocations.map((a) => ({
          ...a,
          reservationStatus: 'CONFIRMED' as const,
          reservationId: `RES-${Math.floor(10000 + Math.random() * 90000)}`,
        }));
        const updatedBacking = calculateBackingSummary(
          pkg.workload.acceleratorCount,
          pkg.workload.durationHours,
          updatedAllocations,
          pkg.shortfall.hasShortfall
        );
        return {
          ...pkg,
          status: 'RESERVATIONS_COMMITTED',
          providerAllocations: updatedAllocations,
          backing: updatedBacking,
        };
      })
    );

    addAudit(
      'COMMIT_PROVIDER_RESERVATIONS',
      'PACKAGE',
      packageId,
      `Locked real-time capacity reservations across external providers for package ${packageId}.`
    );
  };

  const generatePOForPackage = (packageId: string): PurchaseOrder | null => {
    const pkg = packages.find((p) => p.id === packageId);
    if (!pkg || !pkg.infrastructureDesign) return null;

    const newPO = createPurchaseOrderFromBOM(
      pkg.infrastructureDesign.bom,
      pkg.id,
      pkg.infrastructureDesign.id
    );

    setPurchaseOrders((prev) => [newPO, ...prev]);
    setSelectedPOId(newPO.poId);

    setPackages((prev) =>
      prev.map((p) => {
        if (p.id !== packageId) return p;
        return {
          ...p,
          associatedPOIds: [...p.associatedPOIds, newPO.poId],
          status: 'INFRASTRUCTURE_PENDING',
        };
      })
    );

    addAudit(
      'GENERATE_PURCHASE_ORDER',
      'PURCHASE_ORDER',
      newPO.poId,
      `Created institutional Purchase Order ${newPO.poNumber} for $${newPO.totalAmountUSD.toLocaleString()} (${newPO.itemCount} line items).`
    );

    return newPO;
  };

  const approvePO = (
    poId: string,
    role: 'HEAD_OF_INFRASTRUCTURE' | 'CHIEF_FINANCIAL_OFFICER',
    signee: string
  ) => {
    setPurchaseOrders((prev) =>
      prev.map((po) => {
        if (po.poId !== poId) return po;

        const alreadySigned = po.approvalSignatures.some((s) => s.role === role);
        if (alreadySigned) return po;

        const newSignatures = [
          ...po.approvalSignatures,
          {
            role,
            signee,
            timestamp: new Date().toISOString(),
          },
        ];

        // Dual approval check: Both Head of Infra and CFO must sign
        const hasInfra = newSignatures.some((s) => s.role === 'HEAD_OF_INFRASTRUCTURE');
        const hasCFO = newSignatures.some((s) => s.role === 'CHIEF_FINANCIAL_OFFICER');
        const isFullyApproved = hasInfra && hasCFO;

        const nextStatus: POStatus = isFullyApproved ? 'SUPPLIER_CONFIRMED' : 'APPROVAL_PENDING';

        const updatedMilestones = po.trackingMilestones.map((m) => {
          if (m.milestone.includes('Dual Authorisation') && isFullyApproved) {
            return { ...m, completed: true, timestamp: new Date().toISOString() };
          }
          if (m.milestone.includes('Supplier Binding Order') && isFullyApproved) {
            return { ...m, completed: true, timestamp: new Date().toISOString() };
          }
          return m;
        });

        // Update package backing classification
        if (po.packageId) {
          setPackages((prevPkgs) =>
            prevPkgs.map((pkg) => {
              if (pkg.id !== po.packageId) return pkg;
              const updatedBacking = calculateBackingSummary(
                pkg.workload.acceleratorCount,
                pkg.workload.durationHours,
                pkg.providerAllocations,
                pkg.shortfall.hasShortfall,
                nextStatus
              );
              return {
                ...pkg,
                backing: updatedBacking,
              };
            })
          );
        }

        return {
          ...po,
          approvalSignatures: newSignatures,
          status: nextStatus,
          trackingMilestones: updatedMilestones,
        };
      })
    );

    addAudit(
      'EXECUTE_DUAL_PO_APPROVAL',
      'PURCHASE_ORDER',
      poId,
      `Dual-authorization signature appended by ${signee} (${role}). Status updated.`
    );
  };

  const advancePOMilestone = (poId: string) => {
    setPurchaseOrders((prev) =>
      prev.map((po) => {
        if (po.poId !== poId) return po;

        const firstIncompleteIdx = po.trackingMilestones.findIndex((m) => !m.completed);
        if (firstIncompleteIdx === -1) return po;

        const updatedMilestones = po.trackingMilestones.map((m, idx) => {
          if (idx === firstIncompleteIdx) {
            return { ...m, completed: true, timestamp: new Date().toISOString() };
          }
          return m;
        });

        // Determine next PO status based on milestone step
        let nextStatus: POStatus = po.status;
        if (firstIncompleteIdx === 3) nextStatus = 'IN_TRANSIT';
        if (firstIncompleteIdx === 4) nextStatus = 'RECEIVED';
        if (firstIncompleteIdx === 5) nextStatus = 'INSTALLED';
        if (firstIncompleteIdx === 6) nextStatus = 'ACCEPTED';

        // If accepted, update package to operational
        if (po.packageId && nextStatus === 'ACCEPTED') {
          setPackages((prevPkgs) =>
            prevPkgs.map((pkg) => {
              if (pkg.id !== po.packageId) return pkg;
              const updatedBacking = calculateBackingSummary(
                pkg.workload.acceleratorCount,
                pkg.workload.durationHours,
                pkg.providerAllocations,
                pkg.shortfall.hasShortfall,
                'ACCEPTED'
              );
              return {
                ...pkg,
                status: 'OPERATIONAL',
                backing: updatedBacking,
              };
            })
          );

          // Add clean telemetry metering record
          const newMtr: MeteringRecord = {
            id: `MTR-REC-${Math.floor(1000 + Math.random() * 9000)}`,
            timestamp: new Date().toISOString(),
            packageId: po.packageId,
            providerId: 'PROV-PRIVATE-ALPHA',
            allocatedUnits: 352,
            measuredGpuHours: 352 * 24,
            cpuHours: 352 * 96,
            memoryTBHours: 28.16,
            networkEgressGB: 12500,
            powerDrawnKWh: 3870,
            providerInvoicedAmountUSD: 14800,
            customerBillableAmountUSD: 24640,
            internalLedgerReconciliationStatus: 'RECONCILED',
            discrepancyUSD: 0,
            notes: 'Physical cluster commissioned and accepted. Real-time telemetry nominal.',
          };
          setMeteringRecords((prevRecs) => [newMtr, ...prevRecs]);
        }

        return {
          ...po,
          status: nextStatus,
          trackingMilestones: updatedMilestones,
        };
      })
    );

    addAudit(
      'ADVANCE_PO_DELIVERY_MILESTONE',
      'PURCHASE_ORDER',
      poId,
      `Advanced logistics & commissioning milestone for PO ${poId}.`
    );
  };

  const resolveMeteringException = (recordId: string, note: string) => {
    setMeteringRecords((prev) =>
      prev.map((rec) => {
        if (rec.id !== recordId) return rec;
        return {
          ...rec,
          internalLedgerReconciliationStatus: 'RECONCILED',
          discrepancyUSD: 0,
          notes: `${rec.notes || ''} [AUDIT RESOLUTION: ${note}]`,
        };
      })
    );

    addAudit(
      'RESOLVE_METERING_EXCEPTION',
      'METERING',
      recordId,
      `Reconciled billing discrepancy for record ${recordId}: ${note}.`
    );
  };

  const runStressScenario = (config: StressScenarioConfig) => {
    const result = evaluateStressScenario(packages, purchaseOrders, config);
    setActiveStressResult(result);
    setRiskAlerts((prev) => [...result.criticalAlertsGenerated, ...prev]);

    addAudit(
      'RUN_PORTFOLIO_STRESS_TEST',
      'PORTFOLIO',
      'ALL_PACKAGES',
      `Executed portfolio macro stress test: ${result.scenarioName}. Margin impact: -$${result.marginErosionUSD.toLocaleString()}.`
    );
  };

  const clearStressScenario = () => {
    setActiveStressResult(null);
  };

  // Section 23: Complete 21-Step Workflow Definitions
  const WORKFLOW_STEPS = [
    { step: 1, title: 'Workload Profile Validation', desc: 'Validates 512x H100 SXM5 80GB, NVLink4 800G, FP8 tensor FLOPS, 2.5PB storage.' },
    { step: 2, title: 'Query Configured Providers', desc: 'Queries real-time telemetry across CoreWeave, Lambda Labs, Nebius, Crusoe, and Equinix.' },
    { step: 3, title: 'Capacity Optimization Solver', desc: 'Solves multi-provider allocation under residency & hardware constraints.' },
    { step: 4, title: 'Shortfall Identification', desc: 'Discovers 352 GPUs regional shortfall in Virginia. Triggers physical expansion.' },
    { step: 5, title: 'Physical Infrastructure Synthesis', desc: 'Designs 44x 8-GPU servers (352 GPUs) with Quantum-2 800G fabric & 48U racks.' },
    { step: 6, title: 'Facility Power & Cooling Verification', desc: 'Checks 350kW power draw and 120kW Vertiv Liebert CDU liquid cooling loop.' },
    { step: 7, title: 'Hierarchical BOM Generation', desc: 'Generates 8-category Bill of Materials with SKUs, lead times, and thermal specs.' },
    { step: 8, title: 'Supplier Quote Matrix Comparison', desc: 'Compares Supermicro OEM, Dell Technologies, and NVIDIA Direct lead times and prices.' },
    { step: 9, title: 'Commercial Economics Calculation', desc: 'Models CAPEX ($1.38M), OPEX, 33.2% gross margin, 7.4-month payback, 38.6% IRR.' },
    { step: 10, title: 'Delivery Milestones & Acceptance Criteria', desc: 'Establishes 7-phase acceptance gate with 72-hour NCCL burn-in testing.' },
    { step: 11, title: 'Package Quotation Assembly', desc: 'Issues formal institutional contract quotation with SLA guarantees and risk contingencies.' },
    { step: 12, title: 'Dual-Authorisation Commercial Approval', desc: 'Head of Infrastructure and CFO execute binding cryptographic dual approvals.' },
    { step: 13, title: 'Provider Reservation Commitment', desc: 'Locks 160 GPUs across CoreWeave and Equinix with binding reservation IDs.' },
    { step: 14, title: 'Purchase Order Submission', desc: 'Transmits binding PO-2026-8812 to Supermicro OEM consortium.' },
    { step: 15, title: 'Logistics & Dispatch Tracking', desc: 'Tracks factory acceptance testing and transit to Manassas Data Centre.' },
    { step: 16, title: 'Rack Mounting & CDU Hookup', desc: 'Installs chassis in 48U cabinets, connects 3-phase PDUs and liquid manifold.' },
    { step: 17, title: 'NCCL Stress Test & Level-4 Acceptance', desc: 'Executes 72h all-reduce burn-in test. Cluster achieves 780Gbps bisection bandwidth.' },
    { step: 18, title: 'Cluster Operational Commissioning', desc: 'Full 512-GPU package promoted to OPERATIONAL status; backing reaches COMMISSIONED.' },
    { step: 19, title: 'Telemetry Metering Ingestion', desc: 'Ingests live GPU-hours, power draws, and network egress telemetry.' },
    { step: 20, title: 'Billing & Margin Reconciliation', desc: 'Reconciles provider invoices against customer billing; verifies zero margin leakage.' },
    { step: 21, title: 'Audit Trail & Portfolio Integration', desc: 'Appends SHA-256 audit hashes and updates portfolio risk & liquidity registers.' },
  ];

  const stepWorkflow = () => {
    setWorkflowProgress((prev) => {
      const nextStepNum = prev.currentStep + 1;
      if (nextStepNum > WORKFLOW_STEPS.length) {
        return {
          ...prev,
          isRunning: false,
          stepTitle: 'All 21 Workflow Stages Completed Successfully',
          stepDescription: 'End-to-end institutional workflow fully verified. Package is operational and reconciled.',
        };
      }

      const stepDef = WORKFLOW_STEPS[nextStepNum - 1];
      const newLog = {
        timestamp: new Date().toLocaleTimeString(),
        message: `Stage ${stepDef.step}: ${stepDef.title} - ${stepDef.desc}`,
        type: 'success' as const,
      };

      // Perform real application state side effects based on step
      if (nextStepNum === 1) {
        setActiveWorkspace('package_factory');
      } else if (nextStepNum === 3) {
        setActiveWorkspace('exchange');
      } else if (nextStepNum === 5) {
        setActiveWorkspace('infra_engineering');
      } else if (nextStepNum === 7) {
        setActiveWorkspace('procurement');
      } else if (nextStepNum === 9) {
        setActiveWorkspace('economics');
      } else if (nextStepNum === 12) {
        // execute dual approval
        const po = purchaseOrders[0];
        if (po) approvePO(po.poId, 'CHIEF_FINANCIAL_OFFICER', 'Evelyn Sterling (CFO)');
      } else if (nextStepNum === 13) {
        // reserve capacity
        const pkg = packages[0];
        if (pkg) reservePackageCapacity(pkg.id);
      } else if (nextStepNum === 17 || nextStepNum === 18) {
        // advance milestones to completion
        const po = purchaseOrders[0];
        if (po) advancePOMilestone(po.poId);
        setActiveWorkspace('forward_contracts');
      } else if (nextStepNum === 19 || nextStepNum === 20) {
        setActiveWorkspace('metering');
      } else if (nextStepNum === 21) {
        setActiveWorkspace('audit');
      }

      return {
        ...prev,
        isRunning: nextStepNum < WORKFLOW_STEPS.length,
        currentStep: nextStepNum,
        stepTitle: `Stage ${stepDef.step} / 21: ${stepDef.title}`,
        stepDescription: stepDef.desc,
        completedSteps: [...prev.completedSteps, nextStepNum],
        logs: [newLog, ...prev.logs],
      };
    });
  };

  const runEndToEndWorkflow = () => {
    setWorkflowProgress((prev) => ({
      ...prev,
      isRunning: true,
      currentStep: 0,
      completedSteps: [],
      logs: [
        {
          timestamp: new Date().toLocaleTimeString(),
          message: 'Starting automated 21-stage institutional demonstration workflow...',
          type: 'info',
        },
        ...prev.logs,
      ],
    }));

    // Step sequentially through all 21 steps with readable pacing
    let stepCount = 0;
    const interval = setInterval(() => {
      stepCount++;
      stepWorkflow();
      if (stepCount >= 21) {
        clearInterval(interval);
      }
    }, 1100);
  };

  const resetWorkflow = () => {
    setWorkflowProgress({
      isRunning: false,
      currentStep: 0,
      totalSteps: 21,
      stepTitle: 'Idle - Ready for Master Execution',
      stepDescription: 'Click "Run End-to-End Pipeline" to execute the 21-stage institutional compute allocation & delivery workflow.',
      completedSteps: [],
      logs: [
        {
          timestamp: new Date().toLocaleTimeString(),
          message: 'Workflow runner reset.',
          type: 'info',
        },
      ],
    });
  };

  const resetToDeterministicSeed = () => {
    setPackages(INITIAL_PACKAGES);
    setProviders(INITIAL_PROVIDERS);
    setPurchaseOrders(INITIAL_PURCHASE_ORDERS);
    setMeteringRecords(INITIAL_METERING_RECORDS);
    setRiskAlerts(INITIAL_RISK_ALERTS);
    setAuditEvents(INITIAL_AUDIT_EVENTS);
    setSelectedPackageId(INITIAL_PACKAGES[0]?.id || '');
    setSelectedPOId(INITIAL_PURCHASE_ORDERS[0]?.poId || '');
    setActiveStressResult(null);
    resetWorkflow();
    addAudit('SYSTEM_RESET', 'SYSTEM', 'SEED', `Reset state to deterministic baseline ${SEED_VERSION}.`);
  };

  return (
    <AppStoreContext.Provider
      value={{
        activeWorkspace,
        setActiveWorkspace,
        packages,
        providers,
        purchaseOrders,
        meteringRecords,
        riskAlerts,
        auditEvents,
        selectedPackageId,
        setSelectedPackageId,
        selectedPOId,
        setSelectedPOId,
        activeStressResult,
        workflowProgress,
        reconciliationSummary,
        createNewPackage,
        reservePackageCapacity,
        generatePOForPackage,
        approvePO,
        advancePOMilestone,
        resolveMeteringException,
        runStressScenario,
        clearStressScenario,
        runEndToEndWorkflow,
        stepWorkflow,
        resetWorkflow,
        resetToDeterministicSeed,
      }}
    >
      {children}
    </AppStoreContext.Provider>
  );
};

export const useAppStore = () => {
  const ctx = useContext(AppStoreContext);
  if (!ctx) throw new Error('useAppStore must be used within AppStoreProvider');
  return ctx;
};
