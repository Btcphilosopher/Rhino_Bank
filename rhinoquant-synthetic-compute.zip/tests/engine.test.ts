import assert from 'node:assert';
import { optimizeCapacityAllocation, calculateEconomics, calculateBackingSummary } from '../src/engines/capacityOptimizer.ts';
import { synthesizeInfrastructureDesign } from '../src/engines/infrastructureSynthesis.ts';
import { performReconciliation } from '../src/engines/meteringReconciliation.ts';
import { evaluateStressScenario } from '../src/engines/riskTreasuryEngine.ts';
import { INITIAL_PROVIDERS, INITIAL_PACKAGES, INITIAL_PURCHASE_ORDERS, INITIAL_METERING_RECORDS } from '../src/state/initialData.ts';
import { WorkloadRequirement } from '../src/types/index.ts';

console.log('--- RUNNING RHINOQUANT QUANTITATIVE TEST SUITE ---');

// Test 1: Capacity Matching & Shortfall Detection
console.log('Test 1: Capacity Matching & Shortfall Detection');
const testReq: WorkloadRequirement = {
  workloadClass: 'large_model_training',
  workloadName: 'Validation Test Cluster',
  acceleratorType: 'NVIDIA_H100_SXM5_80GB',
  acceleratorCount: 512,
  memoryMinGBPerGPU: 80,
  interconnect: 'NVLink4_InfiniBand_800G',
  minNetworkThroughputGbps: 800,
  storageCapacityTB: 1000,
  storageMinIOPS: 100000,
  region: 'US-East (Virginia)',
  dataResidencyStrict: true,
  startDate: new Date().toISOString(),
  durationHours: 720,
  targetMaxBudgetUSD: 2000000,
  sloAvailabilityPct: 99.95,
  maxLatencyMs: 15,
};

const optResult = optimizeCapacityAllocation(testReq, INITIAL_PROVIDERS);
assert.strictEqual(optResult.shortfall.hasShortfall, true, 'Must detect shortfall when requested capacity exceeds regional available supply');
assert.strictEqual(optResult.shortfall.requiredGPUs, 512, 'Required GPUs must match request');
assert.strictEqual(optResult.shortfall.allocatedGPUs + optResult.shortfall.shortfallGPUs, 512, 'Allocated + Shortfall must equal requested count');
console.log('✓ Passed: Capacity matching correctly identified shortfall of', optResult.shortfall.shortfallGPUs, 'GPUs');

// Test 2: Physical Infrastructure Synthesis & Thermodynamic Invariants
console.log('Test 2: Physical Infrastructure Synthesis & Thermodynamic Invariants');
const design = synthesizeInfrastructureDesign({
  shortfallGPUs: optResult.shortfall.shortfallGPUs,
  acceleratorType: 'NVIDIA_H100_SXM5_80GB',
  region: 'US-East (Virginia)',
});
assert.ok(design.serverNodeCount > 0, 'Server node count must be positive');
assert.ok(design.rackCount > 0, 'Rack count must be positive');
assert.ok(design.totalPowerDemandKW > 0, 'Power demand must be positive');
assert.ok(design.coolingCapacityRequiredKW > 0, 'Cooling rejection must be calculated');
assert.ok(design.bom.length >= 7, 'BOM must include full hierarchical hardware categories');
assert.ok(design.capexTotalUSD > 0, 'CapEx total must be positive');
console.log('✓ Passed: Infrastructure synthesis generated', design.rackCount, 'racks,', design.totalPowerDemandKW, 'kW power, CapEx $', design.capexTotalUSD);

// Test 3: Quantitative Economics & Unit Margins
console.log('Test 3: Quantitative Economics & Unit Margins');
const econ = calculateEconomics(testReq, optResult.totalExistingOpexUSD, design.capexTotalUSD, design.totalPowerDemandKW);
assert.ok(econ.customerContractPriceUSD > econ.totalCostOfDeliveryUSD, 'Contract price must exceed total cost of delivery');
assert.ok(econ.grossMarginUSD > 0, 'Gross margin must be positive');
assert.ok(econ.grossMarginPct > 20, 'Gross margin percentage must meet hurdle rate');
assert.ok(econ.paybackPeriodMonths > 0, 'Payback period must be positive');
console.log('✓ Passed: Package margin is', econ.grossMarginPct, '%, Net margin $', econ.grossMarginUSD);

// Test 4: Obligation Backing Classification Transitions
console.log('Test 4: Obligation Backing Classification Transitions');
const plannedBacking = calculateBackingSummary(512, 720, optResult.allocations, true);
assert.strictEqual(plannedBacking.overallClassification, 'PLANNED', 'Initial unapproved backing must be PLANNED');

const confirmedAllocations = optResult.allocations.map(a => ({ ...a, reservationStatus: 'CONFIRMED' as const }));

const approvedBacking = calculateBackingSummary(512, 720, confirmedAllocations, true, 'PO_APPROVED');
assert.strictEqual(approvedBacking.overallClassification, 'PURCHASE_APPROVED', 'PO_APPROVED state must update backing classification');

const commissionedBacking = calculateBackingSummary(512, 720, confirmedAllocations, true, 'ACCEPTED');
assert.strictEqual(commissionedBacking.overallClassification, 'COMMISSIONED', 'Accepted deployment must reach COMMISSIONED status');
console.log('✓ Passed: Backing state machine transitions correctly verified');

// Test 5: Telemetry Metering & Reconciliation
console.log('Test 5: Telemetry Metering & Reconciliation');
const reconSummary = performReconciliation(INITIAL_METERING_RECORDS);
assert.ok(reconSummary.totalMeasuredGpuHours > 0, 'Total measured hours must be positive');
assert.strictEqual(reconSummary.discrepancyExceptionsCount, 1, 'Initial seeded records must have 1 overage discrepancy exception');
assert.strictEqual(reconSummary.totalDiscrepancyUSD, 184, 'Discrepancy amount must match invoice deviation');
console.log('✓ Passed: Reconciliation flagged exact variance of $', reconSummary.totalDiscrepancyUSD);

// Test 6: Cross-Domain Macro Stress Testing
console.log('Test 6: Cross-Domain Macro Stress Testing');
const stressResult = evaluateStressScenario(INITIAL_PACKAGES, INITIAL_PURCHASE_ORDERS, {
  electricityPriceShockPct: 25,
  hardwareCostShockPct: 20,
  shipmentDelayDays: 90,
  providerCapacityLossPct: 30,
  utilizationDropPct: 15,
});
assert.ok(stressResult.marginErosionUSD > 0, 'Stress shock must produce margin erosion');
assert.ok(stressResult.criticalAlertsGenerated.length > 0, 'Stress scenario must generate risk alerts');
console.log('✓ Passed: Stress scenario eroded $', stressResult.marginErosionUSD, 'with', stressResult.criticalAlertsGenerated.length, 'critical alerts');

console.log('--- ALL 6 QUANTITATIVE TEST SUITES PASSED CLEANLY ---');
