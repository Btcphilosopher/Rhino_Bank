import express from "express";
import path from "path";
import fs from "fs/promises";
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy initialize GoogleGenAI to prevent startup crashes if GEMINI_API_KEY is missing
let aiClient: GoogleGenAI | null = null;

function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is required. Please set it in your environment or Secrets tab.");
    }
    aiClient = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// --------------------------------------------------------
// API ENDPOINTS
// --------------------------------------------------------

// Healthcheck endpoint
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", environment: process.env.NODE_ENV || "development" });
});

// Endpoint to fetch R script list and contents for the code viewer
app.get("/api/r-files", async (req, res) => {
  try {
    const baseDir = path.join(process.cwd(), "RhinoQuantInflation");
    const rDir = path.join(baseDir, "R");

    const files = [
      { name: "main.R", path: path.join(baseDir, "main.R") },
      { name: "R/data_import.R", path: path.join(rDir, "data_import.R") },
      { name: "R/forecast_engine.R", path: path.join(rDir, "forecast_engine.R") },
      { name: "R/econometrics.R", path: path.join(rDir, "econometrics.R") },
      { name: "R/inflation_engine.R", path: path.join(rDir, "inflation_engine.R") },
      { name: "R/scenario_analysis.R", path: path.join(rDir, "scenario_analysis.R") },
    ];

    const fileContents = await Promise.all(
      files.map(async (f) => {
        try {
          const content = await fs.readFile(f.path, "utf-8");
          return { name: f.name, content };
        } catch (err) {
          return { name: f.name, content: `# Error loading ${f.name}` };
        }
      })
    );

    res.json(fileContents);
  } catch (error: any) {
    res.status(500).json({ error: "Failed to load R source files", details: error.message });
  }
});

// Server-side Gemini intelligence route to generate bespoke economic brief
app.post("/api/gemini/report", async (req, res) => {
  const { region, metric, method, horizon, bankRate, energyShock, wageGrowth, baselineInflation, reportType } = req.body;

  try {
    const ai = getGeminiClient();

    const systemPrompt = `You are a Senior Macroeconomist, Quantitative Investment Strategist, and Principal Analytical Advisor for Rhino Bank.
You are tasked with generating an executive economic brief or committee memo regarding inflation risks across Yorkshire and the Humber.
Maintain a formal, authoritative, and central-bank quality tone. Be analytical, referencing the economic data and specific local areas of Yorkshire (e.g., Leeds, Sheffield, Barnsley, York, Hull, etc.).
Structure your briefing beautifully with markdown headings, analytical bullet points, risk metrics, and banking asset recommendations.`;

    const userPrompt = `Generate a "${reportType || "Monthly inflation Outlook"}" for the geographic region "${region || "Yorkshire & Humber"}".

Key Diagnostic and Simulation Parameters for this Run:
- Target Analytical metric: ${metric || "Composite CPI Inflation"}
- Applied Forecasting Engine: ${method || "Statistical Ensemble (ARIMA-ETS-ML)"}
- Horizon Projection: ${horizon || "12-Month Outlook"}
- Base Baseline Inflation rate: ${baselineInflation || 2.4}%

Active Simulation Shocks & Stressed Macroeconomic Inputs:
- Bank of England Rate Shock: +${bankRate || 0.0}% (Total implied policy rate: ${5.25 + (Number(bankRate) || 0)}%)
- Energy/Utility Costs Shock: +${energyShock || 0.0}%
- Regional Average Nominal Wage Growth Acceleration: +${wageGrowth || 0.0}%
- Implied Real Wage Impact: ${((Number(wageGrowth) || 0) - (Number(baselineInflation) || 0)).toFixed(2)}%

Please deliver:
1. EXECUTIVE METRIC SYNOPSIS: Summarize current inflation and project where it is headed in ${horizon} based on these parameters.
2. SECTORAL TRANSMISSION PATHWAYS: Analyze how the utility shock (+${energyShock}%) and wage growth impact goods vs services inflation in places like Leeds (West Yorkshire), Sheffield (South Yorkshire), and Hull (Humber Corridor).
3. STRESS IMPACT ON BANKING PORTFOLIO: Detail specifically how this scenario affects Rhino Bank's regional Mortgage books, Commercial Real Estate exposure, and SME loan default risk.
4. QUANTITATIVE INVESTMENT AND LENDING RECOMMENDATIONS: Provide 3 concrete, actionable actions for the Treasury and Risk Committees (e.g., deposit pricing, loan underwriting, sovereign hedging).`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: userPrompt,
      config: {
        systemInstruction: systemPrompt,
        temperature: 0.7,
      },
    });

    res.json({ report: response.text });
  } catch (error: any) {
    console.error("Gemini report generation failed:", error);
    res.status(500).json({
      error: "AI Report Generation Failed",
      message: error.message || "An error occurred inside the Gemini SDK.",
      keyMissing: !process.env.GEMINI_API_KEY,
    });
  }
});

// --------------------------------------------------------
// MIDDLEWARES & DEV ROUTING
// --------------------------------------------------------

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`RhinoQuant Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
});
