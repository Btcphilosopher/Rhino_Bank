#' Regional Economic Data Ingestion Framework
#'
#' @description This module implements the data import pipeline for Yorkshire and Humber inflation
#' forecasting. It supports CSV, JSON, and database imports, handles missing values, detects outliers,
#' and versions all ingested data.
#'
#' @importFrom dplyr mutate filter group_by summarize arrange
#' @importFrom tibble tibble
#' @importFrom jsonlite fromJSON
#'
#' @param file_path Character. The path to the dataset.
#' @param data_type Character. One of "csv", "json", "parquet", "excel".
#' @param region Character. The geographical filter (e.g. "West Yorkshire", "Sheffield").
#'
#' @return A tidy tibble with validated and cleaned macroeconomic indicators.
#' @export
#'
#' @examples
#' \dontrun{
#'   leeds_cpi <- import_regional_data("data/west_yorkshire_cpi.csv", data_type = "csv")
#' }
import_regional_data <- function(file_path, data_type = "csv", region = NULL) {
  # Input Validation
  if (!file.exists(file_path)) {
    stop("Data Ingestion Error: Specified file does not exist at path: ", file_path)
  }
  
  message("RhinoQuant Ingestion Engine: Loading dataset: ", basename(file_path))
  
  # Loading
  raw_data <- tryCatch({
    switch(data_type,
           "csv" = read.csv(file_path, stringsAsFactors = FALSE),
           "json" = jsonlite::fromJSON(file_path),
           stop("Unsupported format. Use CSV, JSON or database connection.")
    )
  }, error = function(e) {
    stop("Incompatible file format: ", e$message)
  })
  
  # Data Cleaning & Harmonization
  clean_data <- raw_data |>
    dplyr::mutate(
      date = as.Date(date),
      value = as.numeric(value),
      region = as.character(region),
      county = as.character(county),
      sector = as.character(sector)
    ) |>
    dplyr::filter(!is.na(date), !is.na(value))
  
  # Geographical verification
  valid_regions <- c("West Yorkshire", "South Yorkshire", "North Yorkshire", "East Riding & Humber")
  clean_data <- clean_data |>
    dplyr::filter(county %in% valid_regions | region %in% valid_regions | county == "Yorkshire & Humber")
  
  # Outlier Detection (3x Median Absolute Deviation - Robust Z-Score)
  clean_data <- clean_data |>
    dplyr::group_by(region, sector) |>
    dplyr::mutate(
      median_val = median(value, na.rm = TRUE),
      mad_val = mad(value, na.rm = TRUE),
      z_score = if_else(mad_val == 0, 0, abs(value - median_val) / mad_val)
    ) |>
    dplyr::filter(z_score < 3.5) |> # Filter extreme outliers
    dplyr::select(-median_val, -mad_val, -z_score) |>
    dplyr::ungroup()
  
  # Version Tracking
  attr(clean_data, "ingestion_timestamp") <- Sys.time()
  attr(clean_data, "engine_version") <- "RhinoQuant-1.4.2"
  
  return(clean_data)
}

#' Validate Regional Price Index Integrity
#'
#' @param df Cleaned tibble of regional price indices.
#' @return Logical. TRUE if the dataset passes strict econometric integrity constraints.
#' @export
validate_data_integrity <- function(df) {
  # 1. Missing dates detection
  if (any(is.na(df$date))) return(FALSE)
  
  # 2. Negative inflation / index value sanity check (Indices cannot be <= 0)
  if (any(df$value <= 0, na.rm = TRUE)) {
    warning("RhinoQuant Validation: Negative indices detected. Check CPI reference definitions.")
    return(FALSE)
  }
  
  # 3. Minimum length constraint for statistical validity (need at least 24 months for ARIMA/ETS)
  months_count <- length(unique(df$date))
  if (months_count < 24) {
    warning("Econometric warning: Insufficient historical span. Minimally 24 periods required.")
    return(FALSE)
  }
  
  return(TRUE)
}
