#' Yorkshire Regional Econometric Diagnostics
#'
#' @description Implements specialized econometric diagnostics for Yorkshire inflation monitoring.
#' Includes cointegration testing, Granger causality, rolling regressions, structural break detection,
#' and additive/multiplicative decomposition.
#'
#' @importFrom stats ts decompose lm residuals cor filter
#'
#' @export
detect_structural_breaks <- function(series, dates) {
  # Robust Chow-type Breakpoint Search (using rolling residuals variance changes)
  n <- length(series)
  if (n < 12) return(NULL)
  
  # Rolling regression break test
  # Finds the point in time that minimizes sum of squared residuals for two separate linear trends
  ssr <- numeric(n)
  ssr[] <- Inf
  
  # Search from index 6 to n-6
  for (i in 6:(n - 6)) {
    # Left segment
    t_left <- 1:i
    y_left <- series[1:i]
    fit_left <- lm(y_left ~ t_left)
    ssr_left <- sum(residuals(fit_left)^2)
    
    # Right segment
    t_right <- (i + 1):n
    y_right <- series[(i + 1):n]
    fit_right <- lm(y_right ~ t_right)
    ssr_right <- sum(residuals(fit_right)^2)
    
    ssr[i] <- ssr_left + ssr_right
  }
  
  break_idx <- which.min(ssr)
  break_date <- dates[break_idx]
  
  # Calculate F-statistic
  fit_all <- lm(series ~ seq_along(series))
  ssr_all <- sum(residuals(fit_all)^2)
  ssr_unrestricted <- ssr[break_idx]
  
  # Chow test F stat
  k <- 2 # number of coefficients (intercept + slope)
  f_stat <- ((ssr_all - ssr_unrestricted) / k) / (ssr_unrestricted / (n - 2 * k))
  p_val <- stats::pf(f_stat, k, n - 2 * k, lower.tail = FALSE)
  
  list(
    break_index = break_idx,
    break_date = break_date,
    f_statistic = f_stat,
    p_value = p_val,
    is_significant = p_val < 0.05
  )
}

#' Regional Cointegration & Linkage Analysis
#'
#' @description Tests if a local regional indicator cointegrates with UK baseline CPI.
#' Uses Engle-Granger 2-step methodology: regresses regional index on national index and
#' tests if residuals are stationary (ADF test simulation).
#'
#' @param regional_values Numeric vector. Regional index series.
#' @param national_values Numeric vector. National index series.
#'
#' @return List containing cointegration coefficients, residual t-stat, and cointegration status.
#' @export
test_cointegration <- function(regional_values, national_values) {
  if (length(regional_values) != length(national_values)) {
    stop("Econometric constraint: Series lengths must be identical for linkage testing.")
  }
  
  # Step 1: Cointegrating regression
  fit <- stats::lm(regional_values ~ national_values)
  res <- stats::residuals(fit)
  
  # Step 2: Test residuals stationarity (ADF-type autoregressive coefficient)
  n <- length(res)
  dy <- diff(res)
  y_lag <- res[1:(n - 1)]
  
  adf_fit <- stats::lm(dy ~ y_lag - 1) # No intercept since residuals have zero mean
  coef_val <- summary(adf_fit)$coefficients[1, 1]
  t_stat <- summary(adf_fit)$coefficients[1, 3]
  
  # Critical value for Engle-Granger cointegration test (2 variables, no trend) is approx -3.34 for 5% level
  is_cointegrated <- t_stat < -3.2
  
  list(
    beta_coefficient = coef_val,
    residual_t_statistic = t_stat,
    is_cointegrated = is_cointegrated,
    long_run_multiplier = as.numeric(fit$coefficients[2]),
    intercept = as.numeric(fit$coefficients[1])
  )
}

#' Granger Causality Simulation
#'
#' @description Evaluates whether changes in sector A (e.g. Energy costs) Granger-cause changes
#' in sector B (e.g. Regional CPI).
#'
#' @param cause_series Numeric vector. Potential Granger cause.
#' @param effect_series Numeric vector. Potential Granger effect.
#' @param max_lag Integer. Lag specification (defaults to 3 periods).
#'
#' @return List containing causality status and statistical relevance metrics.
#' @export
granger_causality <- function(cause_series, effect_series, max_lag = 3) {
  n <- length(cause_series)
  if (n <= max_lag + 2) return(NULL)
  
  # Unrestricted model: effect ~ effect_lags + cause_lags
  # Restricted model: effect ~ effect_lags
  
  y <- effect_series[(max_lag + 1):n]
  
  # Build lag design matrix
  X_effect_lags <- matrix(NA, nrow = n - max_lag, ncol = max_lag)
  X_cause_lags <- matrix(NA, nrow = n - max_lag, ncol = max_lag)
  
  for (lag in 1:max_lag) {
    X_effect_lags[, lag] <- effect_series[(max_lag - lag + 1):(n - lag)]
    X_cause_lags[, lag] <- cause_series[(max_lag - lag + 1):(n - lag)]
  }
  
  # Fits
  fit_restricted <- stats::lm(y ~ X_effect_lags)
  fit_unrestricted <- stats::lm(y ~ X_effect_lags + X_cause_lags)
  
  ssr_r <- sum(residuals(fit_restricted)^2)
  ssr_ur <- sum(residuals(fit_unrestricted)^2)
  
  # F-test
  df_num <- max_lag
  df_den <- n - 2 * max_lag - 1
  f_stat <- ((ssr_r - ssr_ur) / df_num) / (ssr_ur / df_den)
  p_val <- stats::pf(f_stat, df_num, df_den, lower.tail = FALSE)
  
  list(
    f_statistic = f_stat,
    p_value = p_val,
    causality_verified = p_val < 0.05,
    lags_analyzed = max_lag
  )
}
