#' Scenario Analysis and Portfolio Stress Testing Engine
#'
#' @description Models the macroeconomic impact of inflation shocks, interest rate adjustments,
#' and wage shifts on Rhino Bank's loan books, interest rate margins, and mortgage performance.
#'
#' @export
run_portfolio_stress_test <- function(baseline_inflation,
                                      inflation_shock,
                                      bank_rate_shock,
                                      wage_growth_shock,
                                      portfolio_sizes = list(mortgage = 1200, commercial = 850, sme = 450)) {
  # Elasticities derived from historical stress periods and historical regional data
  # 1. Mortgage default probability elasticity relative to disposable income contraction (inflation - wage gap)
  # 2. Commercial debt service coverage ratio (DSCR) degradation under combined rates + energy shocks
  
  net_disposable_squeeze <- inflation_shock - wage_growth_shock
  
  # Calculate stress multipliers
  mortgage_default_multiplier <- 1.0 + (max(0, net_disposable_squeeze) * 0.15) + (bank_rate_shock * 0.25)
  commercial_credit_downgrade_prob <- 0.02 + (inflation_shock * 0.005) + (bank_rate_shock * 0.012)
  sme_impairment_multiplier <- 1.0 + (net_disposable_squeeze * 0.22) + (bank_rate_shock * 0.18)
  
  # Expected Loss (EL) shifts
  # Assumes standard baseline Loss Given Default (LGD) of 30% for mortgage, 45% for commercial, 50% for SME
  # Assumes standard baseline Probability of Default (PD) of 1.5% for mortgages, 3.2% for commercial, 4.5% for SME
  
  base_pd_m <- 0.015
  base_pd_c <- 0.032
  base_pd_s <- 0.045
  
  stressed_pd_m <- min(0.15, base_pd_m * mortgage_default_multiplier)
  stressed_pd_c <- min(0.20, base_pd_c * (1.0 + commercial_credit_downgrade_prob * 10))
  stressed_pd_s <- min(0.25, base_pd_s * sme_impairment_multiplier)
  
  base_el_m <- portfolio_sizes$mortgage * base_pd_m * 0.30
  stressed_el_m <- portfolio_sizes$mortgage * stressed_pd_m * 0.30
  
  base_el_c <- portfolio_sizes$commercial * base_pd_c * 0.45
  stressed_el_c <- portfolio_sizes$commercial * stressed_pd_c * 0.45
  
  base_el_s <- portfolio_sizes$sme * base_pd_s * 0.50
  stressed_el_s <- portfolio_sizes$sme * stressed_pd_s * 0.50
  
  # Net Interest Margin (NIM) impact: NIM contracts if deposit beta is high or funding costs spikes faster than asset yields
  funding_cost_premium <- bank_rate_shock * 0.85 + (inflation_shock * 0.10)
  asset_yield_repricing <- bank_rate_shock * 0.60 # Only 60% of mortgages are tracker/variable, others are fixed-rate
  nim_compression <- asset_yield_repricing - funding_cost_premium # If negative, NIM contracts
  
  list(
    scenario_parameters = list(
      inflation_shock = inflation_shock,
      bank_rate_shock = bank_rate_shock,
      wage_growth_shock = wage_growth_shock,
      real_wage_growth = wage_growth_shock - inflation_shock
    ),
    credit_impact = list(
      mortgages = list(
        stressed_pd = stressed_pd_m,
        expected_loss_variance = stressed_el_m - base_el_m,
        capital_requirement_multiplier = 1.0 + (stressed_pd_m - base_pd_m) * 2.5
      ),
      commercial = list(
        stressed_pd = stressed_pd_c,
        expected_loss_variance = stressed_el_c - base_el_c,
        capital_requirement_multiplier = 1.0 + (stressed_pd_c - base_pd_c) * 1.8
      ),
      sme = list(
        stressed_pd = stressed_pd_s,
        expected_loss_variance = stressed_el_s - base_el_s,
        capital_requirement_multiplier = 1.0 + (stressed_pd_s - base_pd_s) * 3.0
      )
    ),
    treasury_funding_impact = list(
      funding_cost_increase_bps = funding_cost_premium * 100,
      nim_delta_percent = nim_compression,
      estimated_capital_erosion_m = (stressed_el_m + stressed_el_c + stressed_el_s) - (base_el_m + base_el_c + base_el_s)
    )
  )
}
