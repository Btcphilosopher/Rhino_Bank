#' Yorkshire & Humber Sectoral Inflation Decomposition Engine
#'
#' @description Computes composite, sector-specific, and core inflation proxies.
#' Decomposes price increases across multiple categories and constructs regional weights.
#'
#' @export
calculate_cpi_decomposition <- function(sector_values, weights) {
  # Input checklist validation
  if (length(sector_values) != length(weights)) {
    stop("Weight alignment exception: Number of sectors must match number of weights.")
  }
  
  # Normalize weights to sum to 1.0
  norm_weights <- weights / sum(weights)
  
  # Composite inflation calculation (weighted sum)
  total_inflation <- sum(sector_values * norm_weights, na.rm = TRUE)
  
  # Contributions
  contributions <- sector_values * norm_weights
  contribution_pct <- contributions / total_inflation
  
  # Construct diagnostic output
  decomposition <- data.frame(
    sector = names(sector_values),
    raw_inflation = sector_values,
    allocated_weight = norm_weights,
    absolute_contribution = contributions,
    percentage_contribution = contribution_pct,
    stringsAsFactors = FALSE
  )
  
  # Calculate Core inflation proxy (excluding highly volatile items: Energy & Food)
  volatile_sectors <- c("Energy Costs", "Food Prices", "Fuel Prices")
  non_volatile_idx <- !names(sector_values) %in% volatile_sectors
  
  core_weights <- norm_weights[non_volatile_idx]
  core_weights_norm <- core_weights / sum(core_weights)
  core_inflation_proxy <- sum(sector_values[non_volatile_idx] * core_weights_norm, na.rm = TRUE)
  
  list(
    composite_inflation = total_inflation,
    core_inflation_proxy = core_inflation_proxy,
    sector_decomposition = decomposition,
    volatile_share = sum(decomposition$allocated_weight[decomposition$sector %in% volatile_sectors])
  )
}

#' Monthly to Annualized Inflation Transition
#'
#' @param current_index Numeric. The price index at period t.
#' @param past_index Numeric. The price index at period t - n.
#' @param periods Integer. The time delta (1 for monthly, 12 for annual inflation).
#'
#' @export
calculate_inflation_rate <- function(current_index, past_index, periods = 12) {
  if (any(current_index <= 0) || any(past_index <= 0)) {
    stop("Invalid price index value: Indices must be positive real numbers.")
  }
  
  rate <- ((current_index / past_index) - 1) * 100
  return(rate)
}
