#!/usr/bin/env Rscript
# ==============================================================================
# RhinoQuant Yorkshire Inflation Forecasting Platform - Executive Launcher
# Author: Rhino Bank Quantitative Macroeconomic Intelligence Division
# Branded: RhinoQuant Yorkshire Inflation
# ==============================================================================

# 1. Environment Initialization
message("==============================================================================")
message("   RHINOQUANT YORKSHIRE INFLATION FORECASTING PLATFORM - INITIALIZING CORE    ")
message("==============================================================================")

source("R/data_import.R")
source("R/inflation_engine.R")
source("R/forecast_engine.R")
source("R/econometrics.R")
source("R/scenario_analysis.R")

# 2. Setup Mock Dataset for demonstration
create_demonstration_data <- function() {
  set.seed(42)
  dates <- seq(as.Date("2022-01-01"), as.Date("2026-06-01"), by = "month")
  n <- length(dates)
  
  # Base national CPI index starting at 100 with 3.5% drift and AR(1) seasonal residuals
  national_index <- numeric(n)
  national_index[1] <- 100
  for (i in 2:n) {
    national_index[i] <- national_index[i-1] * (1 + 0.003 + rnorm(1, 0, 0.002))
  }
  
  # West Yorkshire CPI (leeds centric) with slight premium + structural energy cost breaks
  west_york_index <- national_index * (1.02 + sin(1:n / 6) * 0.015 + cumsum(rnorm(n, 0.0005, 0.001)))
  
  data.frame(
    date = dates,
    national_cpi = national_index,
    west_yorkshire = west_york_index,
    sector_energy = 100 * (1 + cumsum(rnorm(n, 0.01, 0.015))),
    stringsAsFactors = FALSE
  )
}

# 3. Execution Pipeline Demo
demo_pipeline <- function() {
  message("\n[Step 1] Loading regional indicators...")
  df <- create_demonstration_data()
  
  message("Loaded ", nrow(df), " observation epochs (spanning ", min(df$date), " to ", max(df$date), ")")
  
  message("\n[Step 2] Testing Cointegration (West Yorkshire link to UK Base)...")
  coin_test <- test_cointegration(df$west_yorkshire, df$national_cpi)
  message("Long-Run Multiplier: ", round(coin_test$long_run_multiplier, 4))
  message("Residual t-stat: ", round(coin_test$residual_t_statistic, 2))
  message("Cointegration Statistically Verified: ", coin_test$is_cointegrated)
  
  message("\n[Step 3] Running Structural Break Detection...")
  breaks <- detect_structural_breaks(df$west_yorkshire, df$date)
  message("Optimal Structural Breakpoint Detected at Epoch: ", breaks$break_date)
  message("Chow-Test Significance (P-Value): ", format.pval(breaks$p_value))
  
  message("\n[Step 4] Running 12-Month ARIMA Inflation Forecast for Leeds/West Yorkshire...")
  fc_res <- forecast_inflation(df$west_yorkshire, frequency = 12, horizon = 12, method = "ensemble")
  message("Point Forecasts (next 3 periods): ", paste(round(fc_res$point[1:3], 2), collapse = ", "))
  message("Forecast Uncertainty Interval Confidence: 95%")
  message("Model Specification: ", fc_res$model_desc)
  
  message("\n[Step 5] Triggering Banking Portfolio Stress Test under Severe Scenario...")
  # Severe scenario: 8% inflation shock, 2.5% central interest rate spike, 1.5% lag in real wages
  stress_res <- run_portfolio_stress_test(
    baseline_inflation = 2.0,
    inflation_shock = 8.0,
    bank_rate_shock = 2.5,
    wage_growth_shock = 1.5
  )
  message("Stressed expected mortgage PD: ", round(stress_res$credit_impact$mortgages$stressed_pd * 100, 2), "%")
  message("Estimated capital erosion on regional loan books: M$", round(stress_res$treasury_funding_impact$estimated_capital_erosion_m, 2))
  
  message("\n==============================================================================")
  message("                  DEMONSTRATION RUN COMPLETE - SYSTEM INTEGRITY OK            ")
  message("==============================================================================")
}

# Execute if run as script
if (!interactive()) {
  demo_pipeline()
}
