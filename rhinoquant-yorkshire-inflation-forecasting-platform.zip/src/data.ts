import { YorkshireRegion, LocalAuthority, HistoricalDataPoint, SectorWeight, ScenarioPreset, SectorName } from "./types";

// Local Authority coverage mapping
export const localAuthorities: LocalAuthority[] = [
  // West Yorkshire
  { id: "leeds", name: "Leeds", parentRegion: "West Yorkshire", cpiWeight: 0.35, baselineCpi: 114.2, exposureM: 520 },
  { id: "bradford", name: "Bradford", parentRegion: "West Yorkshire", cpiWeight: 0.25, baselineCpi: 115.8, exposureM: 310 },
  { id: "wakefield", name: "Wakefield", parentRegion: "West Yorkshire", cpiWeight: 0.15, baselineCpi: 113.1, exposureM: 190 },
  { id: "kirklees", name: "Kirklees", parentRegion: "West Yorkshire", cpiWeight: 0.15, baselineCpi: 114.5, exposureM: 175 },
  { id: "calderdale", name: "Calderdale", parentRegion: "West Yorkshire", cpiWeight: 0.10, baselineCpi: 112.9, exposureM: 115 },

  // South Yorkshire
  { id: "sheffield", name: "Sheffield", parentRegion: "South Yorkshire", cpiWeight: 0.45, baselineCpi: 113.8, exposureM: 410 },
  { id: "doncaster", name: "Doncaster", parentRegion: "South Yorkshire", cpiWeight: 0.22, baselineCpi: 115.1, exposureM: 205 },
  { id: "rotherham", name: "Rotherham", parentRegion: "South Yorkshire", cpiWeight: 0.18, baselineCpi: 114.9, exposureM: 160 },
  { id: "barnsley", name: "Barnsley", parentRegion: "South Yorkshire", cpiWeight: 0.15, baselineCpi: 115.5, exposureM: 140 },

  // North Yorkshire
  { id: "york", name: "York", parentRegion: "North Yorkshire", cpiWeight: 0.28, baselineCpi: 112.4, exposureM: 290 },
  { id: "harrogate", name: "Harrogate", parentRegion: "North Yorkshire", cpiWeight: 0.22, baselineCpi: 111.9, exposureM: 210 },
  { id: "middlesbrough", name: "Middlesbrough", parentRegion: "North Yorkshire", cpiWeight: 0.18, baselineCpi: 117.2, exposureM: 165 },
  { id: "scarborough", name: "Scarborough", parentRegion: "North Yorkshire", cpiWeight: 0.12, baselineCpi: 113.6, exposureM: 95 },
  { id: "whitby", name: "Whitby", parentRegion: "North Yorkshire", cpiWeight: 0.08, baselineCpi: 114.0, exposureM: 55 },
  { id: "skipton", name: "Skipton", parentRegion: "North Yorkshire", cpiWeight: 0.06, baselineCpi: 112.5, exposureM: 50 },
  { id: "selby", name: "Selby", parentRegion: "North Yorkshire", cpiWeight: 0.06, baselineCpi: 113.2, exposureM: 70 },

  // East Riding & Humber
  { id: "hull", name: "Hull", parentRegion: "East Riding & Humber", cpiWeight: 0.45, baselineCpi: 116.4, exposureM: 280 },
  { id: "beverley", name: "Beverley", parentRegion: "East Riding & Humber", cpiWeight: 0.25, baselineCpi: 112.1, exposureM: 145 },
  { id: "goole", name: "Goole", parentRegion: "East Riding & Humber", cpiWeight: 0.15, baselineCpi: 115.0, exposureM: 80 },
  { id: "bridlington", name: "Bridlington", parentRegion: "East Riding & Humber", cpiWeight: 0.15, baselineCpi: 114.3, exposureM: 75 }
];

// Baseline regional sectors
export const baselineSectors: Record<YorkshireRegion, SectorWeight[]> = {
  "Yorkshire & Humber": [
    { name: "Housing & Utilities", weight: 30, currentInflation: 3.8, volatility: "Medium" },
    { name: "Energy & Fuel", weight: 15, currentInflation: 6.2, volatility: "High" },
    { name: "Food & Agriculture", weight: 20, currentInflation: 4.5, volatility: "Medium" },
    { name: "Labor & Services", weight: 20, currentInflation: 4.8, volatility: "Medium" },
    { name: "Manufacturing & Industrial", weight: 15, currentInflation: 3.1, volatility: "Low" }
  ],
  "West Yorkshire": [
    { name: "Housing & Utilities", weight: 28, currentInflation: 4.2, volatility: "Medium" },
    { name: "Energy & Fuel", weight: 12, currentInflation: 5.8, volatility: "High" },
    { name: "Food & Agriculture", weight: 18, currentInflation: 4.1, volatility: "Medium" },
    { name: "Labor & Services", weight: 27, currentInflation: 5.4, volatility: "High" },
    { name: "Manufacturing & Industrial", weight: 15, currentInflation: 2.8, volatility: "Low" }
  ],
  "South Yorkshire": [
    { name: "Housing & Utilities", weight: 26, currentInflation: 3.5, volatility: "Medium" },
    { name: "Energy & Fuel", weight: 18, currentInflation: 6.9, volatility: "High" },
    { name: "Food & Agriculture", weight: 22, currentInflation: 4.8, volatility: "Medium" },
    { name: "Labor & Services", weight: 18, currentInflation: 4.2, volatility: "Low" },
    { name: "Manufacturing & Industrial", weight: 20, currentInflation: 4.3, volatility: "High" }
  ],
  "North Yorkshire": [
    { name: "Housing & Utilities", weight: 35, currentInflation: 3.2, volatility: "Low" },
    { name: "Energy & Fuel", weight: 14, currentInflation: 5.5, volatility: "High" },
    { name: "Food & Agriculture", weight: 22, currentInflation: 4.3, volatility: "Medium" },
    { name: "Labor & Services", weight: 19, currentInflation: 4.6, volatility: "Medium" },
    { name: "Manufacturing & Industrial", weight: 10, currentInflation: 2.1, volatility: "Low" }
  ],
  "East Riding & Humber": [
    { name: "Housing & Utilities", weight: 25, currentInflation: 3.6, volatility: "Medium" },
    { name: "Energy & Fuel", weight: 20, currentInflation: 7.2, volatility: "High" },
    { name: "Food & Agriculture", weight: 18, currentInflation: 4.4, volatility: "Medium" },
    { name: "Labor & Services", weight: 15, currentInflation: 3.9, volatility: "Low" },
    { name: "Manufacturing & Industrial", weight: 22, currentInflation: 4.5, volatility: "High" }
  ]
};

// Generate highly realistic historical monthly inflation indicators spanning Jan 2022 to Jun 2026
export const generateHistoricalData = (region: YorkshireRegion): HistoricalDataPoint[] => {
  const dates = [
    "2022-01-01", "2022-02-01", "2022-03-01", "2022-04-01", "2022-05-01", "2022-06-01",
    "2022-07-01", "2022-08-01", "2022-09-01", "2022-10-01", "2022-11-01", "2022-12-01",
    "2023-01-01", "2023-02-01", "2023-03-01", "2023-04-01", "2023-05-01", "2023-06-01",
    "2023-07-01", "2023-08-01", "2023-09-01", "2023-10-01", "2023-11-01", "2023-12-01",
    "2024-01-01", "2024-02-01", "2024-03-01", "2024-04-01", "2024-05-01", "2024-06-01",
    "2024-07-01", "2024-08-01", "2024-09-01", "2024-10-01", "2024-11-01", "2024-12-01",
    "2025-01-01", "2025-02-01", "2025-03-01", "2025-04-01", "2025-05-01", "2025-06-01",
    "2025-07-01", "2025-08-01", "2025-09-01", "2025-10-01", "2025-11-01", "2025-12-01",
    "2026-01-01", "2026-02-01", "2026-03-01", "2026-04-01", "2026-05-01", "2026-06-01"
  ];

  // Specific regional modifiers to represent econometric structural variations
  let baseIndex = 100;
  let regionalMultiplier = 1.0;
  let seasonalShift = 0.0;

  switch (region) {
    case "West Yorkshire":
      regionalMultiplier = 1.015;
      seasonalShift = 0.02;
      break;
    case "South Yorkshire":
      regionalMultiplier = 1.008;
      seasonalShift = -0.01;
      break;
    case "North Yorkshire":
      regionalMultiplier = 0.985;
      seasonalShift = -0.04;
      break;
    case "East Riding & Humber":
      regionalMultiplier = 1.025;
      seasonalShift = 0.05;
      break;
    default:
      regionalMultiplier = 1.0;
  }

  return dates.map((date, idx) => {
    // Re-create the UK inflation cycle: spiking late 2022/early 2023 (energy shock), then cooling, then stabilizing in 2025/2026
    const nationalBase = 100 * Math.pow(1.0035, idx); // general trend
    let priceShock = 0;
    
    // Wave shocks representing global utility surge of 2022
    if (idx >= 4 && idx <= 16) {
      priceShock = Math.sin((idx - 4) * Math.PI / 12) * 8.5; 
    } else if (idx > 16 && idx <= 36) {
      priceShock = 8.5 * Math.exp(-(idx - 16) * 0.1) + Math.cos(idx / 2) * 1.5;
    } else {
      priceShock = 1.5 + Math.sin(idx / 3) * 0.5;
    }

    const nationalCPI = Number((nationalBase + priceShock).toFixed(2));
    
    // regional variations with structural noise
    const regionCPI = Number((nationalCPI * regionalMultiplier + Math.sin(idx / 4) * 0.8 + seasonalShift).toFixed(2));

    // Sectoral price indexes
    const baseEnergyShock = idx >= 5 && idx <= 18 ? Math.sin((idx - 5) * Math.PI / 13) * 22 : Math.max(2.0, Math.sin(idx) * 3);
    const sectors: Record<SectorName, number> = {
      "Housing & Utilities": Number((regionCPI * 0.95 + Math.sin(idx / 6) * 1.5).toFixed(2)),
      "Energy & Fuel": Number((regionCPI * (1.0 + baseEnergyShock / 100) + Math.cos(idx / 2) * 2.5).toFixed(2)),
      "Food & Agriculture": Number((regionCPI * 1.02 + Math.sin(idx / 3) * 2).toFixed(2)),
      "Labor & Services": Number((regionCPI * 0.98 + (idx * 0.05)).toFixed(2)),
      "Manufacturing & Industrial": Number((regionCPI * 0.96 + Math.cos(idx / 4) * 1.2).toFixed(2)),
    };

    return {
      date,
      compositeCPI: regionCPI,
      nationalCPI,
      sectors
    };
  });
};

// Scenario presets matching core instructions
export const scenarioPresets: ScenarioPreset[] = [
  {
    name: "Baseline Policy Stability",
    description: "Standard macroeconomic assumptions with Bank of England Rate held at 5.25%. Cooling utility indices and moderate real wages growth.",
    bankRateShock: 0,
    energyShock: -5.0,
    wageGrowthShock: 2.8,
    supplyChainShock: 0
  },
  {
    name: "Energy Costs Utility Shock",
    description: "Geopolitical tensions cause sudden 35% surge in crude oil, gas, and electricity prices, triggering an immediate manufacturing squeeze in South Yorkshire.",
    bankRateShock: 0.75,
    energyShock: 35.0,
    wageGrowthShock: 1.5,
    supplyChainShock: 20.0
  },
  {
    name: "Labor Market Wage Spiral",
    description: "Severe skilled labor shortage across West Yorkshire digital and tech hubs sparks a 7.5% nominal wage growth, prompting monetary tightening.",
    bankRateShock: 1.5,
    energyShock: 2.0,
    wageGrowthShock: 7.5,
    supplyChainShock: 5.0
  },
  {
    name: "Global Supply Chain Lockdown",
    description: "Port congestion and logistical blockages squeeze Humber industrial corridors, accelerating input prices and transport costs by 25%.",
    bankRateShock: 0.5,
    energyShock: 15.0,
    wageGrowthShock: 2.0,
    supplyChainShock: 25.0
  },
  {
    name: "Aggressive Quantitative Squeeze",
    description: "The Monetary Policy Committee hikes the Bank Rate by 2.0% to suppress aggregate consumer demand, inducing a cooling of the regional housing markets.",
    bankRateShock: 2.0,
    energyShock: -8.0,
    wageGrowthShock: 1.0,
    supplyChainShock: -5.0
  }
];
