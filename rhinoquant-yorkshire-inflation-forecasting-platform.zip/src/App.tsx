/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from "react";
import { 
  TrendingUp, 
  MapPin, 
  Activity, 
  FileText, 
  Terminal, 
  Sliders, 
  Landmark, 
  Scale, 
  Layers, 
  Settings, 
  ArrowUpRight, 
  Flame, 
  Coins,
  ShieldAlert,
  Menu,
  X
} from "lucide-react";
import { 
  ResponsiveContainer, 
  BarChart, 
  CartesianGrid, 
  XAxis, 
  YAxis, 
  Tooltip as RechartsTooltip, 
  Bar, 
  Cell 
} from "recharts";

import { YorkshireRegion, ForecastMethod, SectorWeight, ScenarioPreset } from "./types";
import { generateHistoricalData, baselineSectors, localAuthorities } from "./data";

// Subcomponents
import MapEngine from "./components/MapEngine";
import RCodeExplorer from "./components/RCodeExplorer";
import ReportGenerator from "./components/ReportGenerator";
import ForecastingPanel from "./components/ForecastingPanel";
import ScenarioSimulator from "./components/ScenarioSimulator";
import BankingImpactCard from "./components/BankingImpactCard";

export default function App() {
  // Navigation State
  const [activeTab, setActiveTab] = useState<string>("overview");
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);

  // Economic Parameters State
  const [selectedRegion, setSelectedRegion] = useState<YorkshireRegion>("Yorkshire & Humber");
  const [forecastMethod, setForecastMethod] = useState<ForecastMethod>("ensemble");
  const [forecastHorizon, setForecastHorizon] = useState<number>(12);

  // Stress Shocks State
  const [bankRate, setBankRate] = useState<number>(0);
  const [energyShock, setEnergyShock] = useState<number>(0);
  const [wageGrowth, setWageGrowth] = useState<number>(0);
  const [currentPresetName, setCurrentPresetName] = useState<string>("Baseline Policy Stability");

  // Load simulated historical data based on selection
  const historicalData = useMemo(() => {
    return generateHistoricalData(selectedRegion);
  }, [selectedRegion]);

  // Compute actual annualized inflation rate based on latest historical data
  // Annual Inflation = ((Index_t / Index_{t-12}) - 1) * 100
  const cpiMetrics = useMemo(() => {
    const n = historicalData.length;
    if (n < 13) return { currentCPI: 114.5, annualInflation: 3.4, coreInflation: 2.8, nationalInflation: 3.2 };

    const currentIdx = historicalData[n - 1].compositeCPI;
    const pastIdx = historicalData[n - 13].compositeCPI;
    const annualInflation = ((currentIdx / pastIdx) - 1) * 100;

    const currentNatIdx = historicalData[n - 1].nationalCPI;
    const pastNatIdx = historicalData[n - 13].nationalCPI;
    const nationalInflation = ((currentNatIdx / pastNatIdx) - 1) * 100;

    // Calculate core proxy (with utility offsets subtracted)
    const rawSectors = baselineSectors[selectedRegion];
    const energyW = rawSectors.find(s => s.name === "Energy & Fuel")?.weight || 15;
    const energyInf = rawSectors.find(s => s.name === "Energy & Fuel")?.currentInflation || 6.2;
    
    const coreInflation = annualInflation - (energyInf * (energyW / 100) * 0.15);

    return {
      currentCPI: Number(currentIdx.toFixed(1)),
      annualInflation: Number(annualInflation.toFixed(2)),
      coreInflation: Number(coreInflation.toFixed(2)),
      nationalInflation: Number(nationalInflation.toFixed(2))
    };
  }, [historicalData, selectedRegion]);

  // Adjust current sector inflation rates based on manual energy/wage shocks
  const adjustedSectors = useMemo<SectorWeight[]>(() => {
    const base = baselineSectors[selectedRegion];
    return base.map((sector) => {
      let currentInflation = sector.currentInflation;

      // Elasticity-based shifts
      if (sector.name === "Energy & Fuel") {
        currentInflation += energyShock * 0.85; // direct fuel premium
      } else if (sector.name === "Labor & Services") {
        currentInflation += wageGrowth * 0.70; // high wage-price elasticity
      } else if (sector.name === "Housing & Utilities") {
        currentInflation += energyShock * 0.15 + bankRate * 0.10; // secondary cost-push + variable rate repricing
      } else if (sector.name === "Manufacturing & Industrial") {
        currentInflation += energyShock * 0.25 + wageGrowth * 0.15; // material + labor inputs
      } else if (sector.name === "Food & Agriculture") {
        currentInflation += energyShock * 0.12; // fertilizer and logistics
      }

      return {
        ...sector,
        currentInflation: Number(currentInflation.toFixed(2))
      };
    });
  }, [selectedRegion, energyShock, wageGrowth, bankRate]);

  // Contribution matrix (Weighted Inflation Contribution)
  // Contribution = AdjustedSectorInflation * (Weight / 100)
  const contributionData = useMemo(() => {
    let totalComputed = 0;
    const sectorsWithContrib = adjustedSectors.map((s) => {
      const absoluteContrib = Number((s.currentInflation * (s.weight / 100)).toFixed(2));
      totalComputed += absoluteContrib;
      return {
        name: s.name,
        inflation: s.currentInflation,
        weight: s.weight,
        contribution: absoluteContrib
      };
    });

    return {
      totalComputed: Number(totalComputed.toFixed(2)),
      chartData: sectorsWithContrib
    };
  }, [adjustedSectors]);

  // Dynamic county-level inflation list for GIS reference
  const countyInflationRates = useMemo<Record<YorkshireRegion, number>>(() => {
    return {
      "Yorkshire & Humber": cpiMetrics.annualInflation,
      "West Yorkshire": Number((cpiMetrics.annualInflation * 1.05 + wageGrowth * 0.1).toFixed(2)),
      "South Yorkshire": Number((cpiMetrics.annualInflation * 1.02 + energyShock * 0.15).toFixed(2)),
      "North Yorkshire": Number((cpiMetrics.annualInflation * 0.96 + bankRate * -0.05).toFixed(2)),
      "East Riding & Humber": Number((cpiMetrics.annualInflation * 1.08 + energyShock * 0.2).toFixed(2)),
    };
  }, [cpiMetrics.annualInflation, wageGrowth, energyShock, bankRate]);

  const handleLoadPreset = (preset: ScenarioPreset) => {
    setBankRate(preset.bankRateShock);
    setEnergyShock(preset.energyShock);
    setWageGrowth(preset.wageGrowthShock);
    setCurrentPresetName(preset.name);
  };

  const navItems = [
    { id: "overview", label: "Executive Overview", icon: Scale },
    { id: "forecasts", label: "Forecasting Engine", icon: TrendingUp },
    { id: "scenarios", label: "Scenario & Shocks", icon: Sliders },
    { id: "banking", label: "Banking Applications", icon: Landmark },
    { id: "gis", label: "GIS Choropleth Map", icon: MapPin },
    { id: "rcore", label: "Econometric R Core", icon: Terminal },
  ];

  return (
    <div className="min-h-screen bg-[#0F0F0F] text-[#D9D4CF] flex flex-col font-sans selection:bg-[#B87333]/30">
      
      {/* Upper Navigation Strip (Header) */}
      <header className="bg-[#121212] border-b border-[#2A2A2A] px-6 py-4 sticky top-0 z-40 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-none bg-[#B87333] flex items-center justify-center border border-[#B87333]/30">
            <Landmark className="w-5 h-5 text-black font-black" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-sm font-black tracking-[0.2em] text-[#D9D4CF] uppercase">RhinoQuant</h1>
              <span className="text-[9px] font-mono bg-[#1A1A1A] text-[#B87333] px-1.5 py-0.5 rounded-none border border-[#B87333]/30 font-bold tracking-wider">
                YORKSHIRE CORE
              </span>
            </div>
            <p className="text-[9px] text-[#888] font-mono uppercase tracking-wider">Macroeconomic Intelligence Platform • Rhino Bank</p>
          </div>
        </div>

        {/* Global County Selector (Shiny UI style header) */}
        <div className="hidden lg:flex items-center space-x-3 bg-[#0F0F0F] px-3 py-1.5 rounded-none border border-[#2A2A2A]">
          <span className="text-[9px] font-mono uppercase text-[#555] font-bold tracking-wider">Analysis Scope:</span>
          <select
            value={selectedRegion}
            onChange={(e) => setSelectedRegion(e.target.value as YorkshireRegion)}
            className="bg-transparent text-[#D9D4CF] border-none text-xs font-bold uppercase tracking-wider focus:outline-none focus:ring-0 pr-6"
          >
            <option value="Yorkshire & Humber" className="bg-[#0F0F0F]">Yorkshire & Humber (Region-wide)</option>
            <option value="West Yorkshire" className="bg-[#0F0F0F]">West Yorkshire (Leeds, Bradford)</option>
            <option value="South Yorkshire" className="bg-[#0F0F0F]">South Yorkshire (Sheffield, Barnsley)</option>
            <option value="North Yorkshire" className="bg-[#0F0F0F]">North Yorkshire (York, Harrogate)</option>
            <option value="East Riding & Humber" className="bg-[#0F0F0F]">East Riding & Humber (Hull, Beverley)</option>
          </select>
        </div>

        {/* Mobile menu trigger */}
        <button 
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="lg:hidden p-2 text-stone-400 hover:text-stone-200 focus:outline-none"
        >
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </header>

      {/* Main Container Layout */}
      <div className="flex-1 flex flex-col lg:flex-row">
        
        {/* Left Sidebar Menu */}
        <aside className={`w-full lg:w-64 bg-[#121212] border-r border-[#2A2A2A] shrink-0 p-4 lg:block ${mobileMenuOpen ? "block" : "hidden lg:block"}`}>
          <div className="text-[9px] font-mono text-[#555] uppercase tracking-[0.2em] font-bold mb-4 px-2.5">
            Analytical Modules
          </div>
          <nav className="space-y-1">
            {navItems.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full text-left px-3 py-2.5 rounded-none text-xs font-black uppercase tracking-widest transition flex items-center space-x-2.5 ${
                    isActive
                      ? "bg-[#B87333] text-black"
                      : "text-[#888] hover:bg-[#0F0F0F] hover:text-[#D9D4CF]"
                  }`}
                >
                  <item.icon className="w-4 h-4 shrink-0" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Quick Metrics HUD */}
          <div className="mt-8 border-t border-[#2A2A2A] pt-6 space-y-4 px-2">
            <div className="text-[9px] font-mono text-[#555] uppercase tracking-[0.2em] font-bold">
              Live Indicators
            </div>
            <div className="space-y-3">
              <div>
                <div className="text-[9px] uppercase tracking-wider text-[#555] font-bold">YoY CPI Inflation</div>
                <div className="text-xl font-black font-mono text-[#B87333] tracking-tighter mt-0.5">
                  {cpiMetrics.annualInflation.toFixed(2)}%
                </div>
              </div>
              <div>
                <div className="text-[9px] uppercase tracking-wider text-[#555] font-bold">National CPI Variance</div>
                <div className="text-sm font-black font-mono text-[#D9D4CF] mt-0.5">
                  {cpiMetrics.annualInflation > cpiMetrics.nationalInflation ? "+" : ""}
                  {(cpiMetrics.annualInflation - cpiMetrics.nationalInflation).toFixed(2)}% vs UK
                </div>
              </div>
              <div>
                <div className="text-[9px] uppercase tracking-wider text-[#555] font-bold">Core Proxy (ex Energy)</div>
                <div className="text-sm font-black font-mono text-[#D9D4CF] mt-0.5">
                  {cpiMetrics.coreInflation.toFixed(2)}%
                </div>
              </div>
            </div>
          </div>
        </aside>

        {/* Right Dashboard Workspace */}
        <main className="flex-1 p-6 lg:p-8 overflow-y-auto space-y-6">
          
          {/* Top Banner (Geography HUD) */}
          <div className="bg-[#121212] border border-[#2A2A2A] rounded-none p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center space-x-2 text-[9px] text-[#B87333] font-mono uppercase tracking-widest font-bold">
                <MapPin className="w-3.5 h-3.5" />
                <span>Selected scope: {selectedRegion}</span>
              </div>
              <h2 className="text-lg font-black uppercase tracking-wider text-white mt-1">
                Regional Macroeconomic Dashboard
              </h2>
            </div>
            
            {/* Mobile/Responsive Scope Trigger */}
            <div className="lg:hidden flex items-center space-x-2 bg-[#0F0F0F] px-3 py-2 rounded-none border border-[#2A2A2A] w-full md:w-auto">
              <span className="text-[9px] font-mono uppercase text-[#555] font-bold tracking-wider">Scope:</span>
              <select
                value={selectedRegion}
                onChange={(e) => setSelectedRegion(e.target.value as YorkshireRegion)}
                className="bg-transparent text-[#D9D4CF] border-none text-xs font-bold uppercase tracking-wider focus:outline-none w-full"
              >
                <option value="Yorkshire & Humber" className="bg-[#0F0F0F]">Yorkshire & Humber</option>
                <option value="West Yorkshire" className="bg-[#0F0F0F]">West Yorkshire</option>
                <option value="South Yorkshire" className="bg-[#0F0F0F]">South Yorkshire</option>
                <option value="North Yorkshire" className="bg-[#0F0F0F]">North Yorkshire</option>
                <option value="East Riding & Humber" className="bg-[#0F0F0F]">East Riding & Humber</option>
              </select>
            </div>
          </div>

          {/* Tab Render Switcher */}
          {activeTab === "overview" && (
            <div className="space-y-6">
              
              {/* Executive Indicators Grid */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="bg-[#121212] p-5 rounded-none border border-[#2A2A2A]">
                  <div className="text-[9px] uppercase tracking-[0.15em] text-[#555] font-bold">Composite YoY Inflation</div>
                  <div className="text-2xl font-black font-mono text-[#D9D4CF] tracking-tighter mt-1.5">
                    {cpiMetrics.annualInflation}%
                  </div>
                  <div className="text-[10px] text-[#888] mt-1">Weighted regional CPI aggregation</div>
                </div>

                <div className="bg-[#121212] p-5 rounded-none border border-[#2A2A2A]">
                  <div className="text-[9px] uppercase tracking-[0.15em] text-[#555] font-bold">Core Proxy Index</div>
                  <div className="text-2xl font-black font-mono text-[#D9D4CF] tracking-tighter mt-1.5">
                    {cpiMetrics.coreInflation}%
                  </div>
                  <div className="text-[10px] text-[#888] mt-1">Volatile sectors (Energy & Food) excluded</div>
                </div>

                <div className="bg-[#121212] p-5 rounded-none border border-[#2A2A2A]">
                  <div className="text-[9px] uppercase tracking-[0.15em] text-[#555] font-bold">Active Shocks Index Offset</div>
                  <div className="text-2xl font-black font-mono mt-1.5 text-[#B87333] tracking-tighter">
                    +{contributionData.totalComputed.toFixed(1)}%
                  </div>
                  <div className="text-[10px] text-[#888] mt-1">Implied index contribution load</div>
                </div>

                <div className="bg-[#121212] p-5 rounded-none border border-[#2A2A2A]">
                  <div className="text-[9px] uppercase tracking-[0.15em] text-[#555] font-bold">Risk Assessment</div>
                  <div className="text-2xl font-black tracking-tight mt-1.5 flex items-center space-x-1.5 text-emerald-500">
                    <Coins className="w-5 h-5 shrink-0" />
                    <span className="text-lg font-black uppercase">RE-STRESSED</span>
                  </div>
                  <div className="text-[10px] text-[#888] mt-1">Regulatory ratios recalculating</div>
                </div>
              </div>

              {/* Central Overview Analytical Split */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                
                {/* Sector Allocation Table */}
                <div className="lg:col-span-7 bg-[#121212] p-6 rounded-none border border-[#2A2A2A] flex flex-col justify-between">
                  <div>
                    <h3 className="text-[10px] uppercase tracking-[0.25em] text-[#B87333] font-bold mb-4">
                      Constituent Sector weights & Cost-Push inflation
                    </h3>
                    <div className="space-y-4">
                      {adjustedSectors.map((sector) => {
                        const isVolatile = sector.volatility === "High";
                        return (
                          <div key={sector.name} className="space-y-1.5">
                            <div className="flex items-center justify-between text-xs">
                              <span className="font-bold text-white uppercase tracking-wide text-xs">{sector.name}</span>
                              <div className="space-x-4 font-mono text-[11px]">
                                <span className="text-[#555] font-bold">Weight: {sector.weight}%</span>
                                <span className={sector.currentInflation > 5.0 ? "text-[#B87333] font-bold" : "text-[#888]"}>
                                  YoY: {sector.currentInflation}%
                                </span>
                                <span className={`px-1.5 py-0.5 rounded-none text-[9px] font-bold uppercase tracking-wider ${
                                  isVolatile ? "bg-rose-950/40 text-rose-400" : "bg-[#0F0F0F] text-[#555]"
                                }`}>
                                  {sector.volatility}
                                </span>
                              </div>
                            </div>
                            <div className="h-1 bg-[#0F0F0F] rounded-none overflow-hidden">
                              <div 
                                className="h-full bg-[#B87333] transition-all duration-500"
                                style={{ width: `${Math.min(100, Math.max(10, sector.currentInflation * 8))}%` }}
                              ></div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  <div className="mt-4 pt-4 border-t border-[#2A2A2A] text-[10px] text-[#888] leading-relaxed">
                    Sectors adjust elastically based on the global energy cap and service wage-spiral coefficients. Heavy manufacturing models exhibit high fuel volatility.
                  </div>
                </div>

                {/* Contribution visualizer (Waterfall-like Recharts) */}
                <div className="lg:col-span-5 bg-[#121212] p-6 rounded-none border border-[#2A2A2A]">
                  <h3 className="text-[10px] uppercase tracking-[0.25em] text-[#B87333] font-bold mb-4">
                    Sector contributions to total index
                  </h3>
                  <div className="h-[210px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={contributionData.chartData}
                        layout="vertical"
                        margin={{ top: 5, right: 5, left: -25, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" stroke="#1F1F1F" />
                        <XAxis type="number" stroke="#555" fontSize={9} />
                        <YAxis type="category" dataKey="name" stroke="#555" fontSize={8} width={90} />
                        <RechartsTooltip
                          contentStyle={{ backgroundColor: "#121212", borderColor: "#2A2A2A" }}
                          labelStyle={{ color: "#888", fontSize: "10px" }}
                          itemStyle={{ fontSize: "11px", color: "#D9D4CF" }}
                        />
                        <Bar dataKey="contribution" fill="#B87333">
                          {contributionData.chartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.contribution > 1.2 ? "#B87333" : "#8C4F1A"} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="text-[10px] text-[#555] font-mono text-center mt-2">
                    Implied absolute contribution points (Sum: {contributionData.totalComputed}% Index YoY)
                  </div>
                </div>

              </div>

              {/* Secondary HUD: GIS Overview segment */}
              <div className="border-t border-stone-800 pt-6">
                <MapEngine
                  selectedRegion={selectedRegion}
                  onRegionSelect={setSelectedRegion}
                  activeMetric="inflation"
                  inflationRates={countyInflationRates}
                />
              </div>

            </div>
          )}

          {activeTab === "forecasts" && (
            <div className="space-y-6">
              <ForecastingPanel
                historicalData={historicalData}
                region={selectedRegion}
                horizonMonths={forecastHorizon}
                method={forecastMethod}
                onMethodChange={setForecastMethod}
                onHorizonChange={setForecastHorizon}
                bankRateShock={bankRate}
                energyShock={energyShock}
                wageGrowthShock={wageGrowth}
              />
              <ReportGenerator
                region={selectedRegion}
                metric="Composite Regional Inflation"
                method={forecastMethod}
                horizon={`${forecastHorizon}-Month Forecast`}
                bankRate={bankRate}
                energyShock={energyShock}
                wageGrowth={wageGrowth}
                baselineInflation={cpiMetrics.annualInflation}
              />
            </div>
          )}

          {activeTab === "scenarios" && (
            <div className="space-y-6">
              <ScenarioSimulator
                bankRate={bankRate}
                energyShock={energyShock}
                wageGrowth={wageGrowth}
                onBankRateChange={setBankRate}
                onEnergyShockChange={setEnergyShock}
                onWageGrowthChange={setWageGrowth}
                onLoadPreset={handleLoadPreset}
                currentPresetName={currentPresetName}
              />
              <BankingImpactCard
                bankRate={bankRate}
                energyShock={energyShock}
                wageGrowth={wageGrowth}
                baselineInflation={cpiMetrics.annualInflation}
              />
            </div>
          )}

          {activeTab === "banking" && (
            <div className="space-y-6">
              <BankingImpactCard
                bankRate={bankRate}
                energyShock={energyShock}
                wageGrowth={wageGrowth}
                baselineInflation={cpiMetrics.annualInflation}
              />
              
              {/* Additional Banking Context */}
              <div className="bg-[#121212] p-6 rounded-none border border-[#2A2A2A]">
                <h3 className="text-[10px] uppercase tracking-[0.25em] text-[#B87333] font-bold mb-4">
                  Rhino Bank Credit Exposure Framework
                </h3>
                <p className="text-xs text-[#888] leading-relaxed mb-4">
                  This framework mirrors Rhino Bank's internal stress matrices for regional mortgage books, corporate SME portfolios, and treasury funding desks. Under Basel rules, as Probability of Default (PD) increases, Capital Requirement multipliers adjust recursively to shield the balance sheet from write-downs.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div className="bg-[#0F0F0F] p-4 rounded-none border border-[#2A2A2A] space-y-2">
                    <span className="font-bold text-[#D9D4CF] uppercase block tracking-[0.15em] text-[10px]">Mortgage Loan to Value (LTV) Risk</span>
                    <p className="text-[#888] leading-relaxed">
                      LTV books across West Yorkshire remain sensitive to interest rate hikes. Real wage squeezes restrict aggregate household debt servicing, leading to marginal stress in Bradford and Wakefield portfolios.
                    </p>
                  </div>
                  <div className="bg-[#0F0F0F] p-4 rounded-none border border-[#2A2A2A] space-y-2">
                    <span className="font-bold text-[#D9D4CF] uppercase block tracking-[0.15em] text-[10px]">SME Working Capital Limits</span>
                    <p className="text-[#888] leading-relaxed">
                      SME capital requirement multipliers expand when energy caps surge. Wholesale logistics corridors in Goole and Hull face cashflow pinches, demanding responsive inventory credit limits from Rhino business desks.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === "gis" && (
            <div className="space-y-6">
              <MapEngine
                selectedRegion={selectedRegion}
                onRegionSelect={setSelectedRegion}
                activeMetric="inflation"
                inflationRates={countyInflationRates}
              />
            </div>
          )}

          {activeTab === "rcore" && (
            <div className="space-y-6">
              <RCodeExplorer />
            </div>
          )}

        </main>
      </div>

      {/* Footer / Copyright bar */}
      <footer className="bg-[#121212] border-t border-[#2A2A2A] px-6 py-4 flex flex-col md:flex-row items-center justify-between text-xs text-[#555]">
        <div>
          © 2026 Rhino Bank plc. Internal macroeconomic modeling, quantitative research and risk system.
        </div>
        <div className="font-mono text-[9px] uppercase tracking-wider text-[#888] mt-2 md:mt-0">
          Platform version: 1.4.2-YORKSHIRE_FUTURIST • Rscript integrated
        </div>
      </footer>

    </div>
  );
}
