/**
 * Yorkshire Inflation Forecasting Platform - Global Type Definitions
 */

export type YorkshireRegion = 
  | "Yorkshire & Humber"
  | "West Yorkshire"
  | "South Yorkshire"
  | "North Yorkshire"
  | "East Riding & Humber";

export interface LocalAuthority {
  id: string;
  name: string;
  parentRegion: YorkshireRegion;
  cpiWeight: number; // contribution to regional index (0-1)
  baselineCpi: number; // Current baseline index
  exposureM: number; // Rhino Bank lending exposure in millions
}

export type SectorName = 
  | "Housing & Utilities"
  | "Energy & Fuel"
  | "Food & Agriculture"
  | "Labor & Services"
  | "Manufacturing & Industrial";

export interface SectorWeight {
  name: SectorName;
  weight: number; // 0-100
  currentInflation: number; // annualized %
  volatility: "Low" | "Medium" | "High";
}

export interface HistoricalDataPoint {
  date: string; // YYYY-MM-DD
  compositeCPI: number;
  nationalCPI: number;
  sectors: Record<SectorName, number>;
}

export type ForecastMethod = 
  | "arima" 
  | "ets" 
  | "random_forest" 
  | "xgboost" 
  | "ensemble";

export interface ForecastPoint {
  date: string;
  point: number;
  lower80: number;
  upper80: number;
  lower95: number;
  upper95: number;
}

export interface ScenarioPreset {
  name: string;
  description: string;
  bankRateShock: number; // %
  energyShock: number; // %
  wageGrowthShock: number; // %
  supplyChainShock: number; // %
}

export interface StressTestResult {
  mortgages: {
    stressedPd: number;
    expectedLossDeltaM: number;
    capitalReqMultiplier: number;
    riskStatus: "Stable" | "Warning" | "Critical";
  };
  commercial: {
    stressedPd: number;
    expectedLossDeltaM: number;
    capitalReqMultiplier: number;
    riskStatus: "Stable" | "Warning" | "Critical";
  };
  sme: {
    stressedPd: number;
    expectedLossDeltaM: number;
    capitalReqMultiplier: number;
    riskStatus: "Stable" | "Warning" | "Critical";
  };
  treasury: {
    fundingCostIncreaseBps: number;
    nimDeltaPercent: number;
    capitalErosionM: number;
    portfolioBeta: number;
  };
}

export interface RFileContent {
  name: string;
  content: string;
}
