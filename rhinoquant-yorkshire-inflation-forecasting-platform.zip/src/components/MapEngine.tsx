import React, { useState } from "react";
import { YorkshireRegion, LocalAuthority } from "../types";
import { localAuthorities } from "../data";
import { MapPin, ShieldAlert, Award, TrendingUp, Landmark } from "lucide-react";

interface MapEngineProps {
  selectedRegion: YorkshireRegion;
  onRegionSelect: (region: YorkshireRegion) => void;
  activeMetric: "inflation" | "exposure" | "weight";
  inflationRates: Record<YorkshireRegion, number>;
}

export default function MapEngine({
  selectedRegion,
  onRegionSelect,
  activeMetric,
  inflationRates,
}: MapEngineProps) {
  const [hoveredRegion, setHoveredRegion] = useState<YorkshireRegion | null>(null);

  // Parent counties metadata
  const counties: { name: YorkshireRegion; d: string; color: string; labelX: number; labelY: number }[] = [
    {
      name: "North Yorkshire",
      // Large northern sweep
      d: "M 80 50 L 220 30 L 260 70 L 290 100 L 220 150 L 150 140 L 90 120 Z",
      color: "fill-[#1C1C1C]",
      labelX: 160,
      labelY: 85,
    },
    {
      name: "West Yorkshire",
      // Industrial west
      d: "M 70 130 L 140 145 L 170 180 L 120 220 L 60 190 Z",
      color: "fill-[#242424]",
      labelX: 110,
      labelY: 175,
    },
    {
      name: "South Yorkshire",
      // Steel mills south
      d: "M 130 225 L 175 185 L 210 200 L 220 250 L 160 260 Z",
      color: "fill-[#2A2A2A]",
      labelX: 175,
      labelY: 225,
    },
    {
      name: "East Riding & Humber",
      // Eastern corridor / coastal estuary
      d: "M 225 155 L 295 105 L 320 160 L 270 210 L 215 195 Z",
      color: "fill-[#1E1E1E]",
      labelX: 265,
      labelY: 155,
    },
  ];

  // Calculate stats for the selected or hovered region
  const currentFocus = hoveredRegion || selectedRegion;

  const filteredLAs = localAuthorities.filter((la) => {
    if (currentFocus === "Yorkshire & Humber") return true;
    return la.parentRegion === currentFocus;
  });

  const totalExposure = filteredLAs.reduce((sum, la) => sum + la.exposureM, 0);
  const avgCpi = filteredLAs.reduce((sum, la) => sum + la.baselineCpi, 0) / filteredLAs.length;

  const getMetricColor = (val: number, type: "inflation" | "exposure") => {
    if (type === "inflation") {
      if (val > 5.5) return "text-red-500 font-bold";
      if (val > 4.0) return "text-[#B87333] font-bold";
      return "text-emerald-500 font-bold";
    } else {
      if (val > 300) return "text-[#B87333]";
      return "text-[#888]";
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 bg-[#121212] p-6 rounded-none border border-[#2A2A2A]">
      {/* Interactive Map Visualizer */}
      <div className="lg:col-span-7 flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-[10px] uppercase tracking-[0.3em] text-[#B87333] font-bold">
              GIS Choropleth & Local Authority Registry
            </h3>
            <div className="flex items-center space-x-2 text-xs text-[#888]">
              <span className="w-2.5 h-2.5 bg-[#B87333] rounded-none inline-block"></span>
              <span className="font-bold uppercase tracking-wider text-[10px]">Active Selection</span>
            </div>
          </div>
          <p className="text-xs text-[#888] mb-6">
            Hover or click on a sub-region to load county econometric diagnostics, local authority subdivisions, and Rhino Bank's mortgage exposures.
          </p>
        </div>

        {/* SVG Map Area */}
        <div className="relative aspect-[4/3] w-full max-w-md mx-auto bg-[#0F0F0F] rounded-none p-4 border border-[#2A2A2A] overflow-hidden flex items-center justify-center">
          <svg
            viewBox="0 0 360 300"
            className="w-full h-full select-none"
            style={{ filter: "drop-shadow(0px 8px 16px rgba(0,0,0,0.4))" }}
          >
            {/* Outline of Yorkshire estuary context */}
            <path
              d="M 215 195 L 230 200 L 250 200 L 270 210"
              fill="none"
              stroke="#c87d55"
              strokeWidth="3.5"
              strokeOpacity="0.4"
              strokeDasharray="4 3"
            />
            {/* Humber Bridge Anchor */}
            <circle cx="255" cy="203" r="4" fill="#c87d55" />
            <text x="250" y="217" className="text-[7px] fill-[#555] font-mono tracking-tight text-center font-bold">
              HUMBER ESTUARY
            </text>

            {/* Counties Render */}
            {counties.map((c) => {
              const isSelected = selectedRegion === c.name;
              const isHovered = hoveredRegion === c.name;
              
              // Determine fill based on metrics
              let fillOpacity = "0.2";
              let strokeColor = "stroke-[#2A2A2A]";
              let strokeWidth = "1";
              let customColor = c.color;

              if (isSelected) {
                fillOpacity = "0.85";
                strokeColor = "stroke-[#B87333]";
                strokeWidth = "2.5";
                customColor = "fill-[#B87333]";
              } else if (isHovered) {
                fillOpacity = "0.45";
                strokeColor = "stroke-[#B87333]/60";
                strokeWidth = "1.5";
                customColor = "fill-[#B87333]";
              }

              return (
                <g key={c.name} className="cursor-pointer">
                  <path
                    d={c.d}
                    className={`${customColor} transition-all duration-300 ease-out`}
                    fillOpacity={fillOpacity}
                    stroke={strokeColor}
                    strokeWidth={strokeWidth}
                    onMouseEnter={() => setHoveredRegion(c.name)}
                    onMouseLeave={() => setHoveredRegion(null)}
                    onClick={() => onRegionSelect(c.name)}
                  />
                  {/* County Name Label */}
                  <text
                    x={c.labelX}
                    y={c.labelY}
                    textAnchor="middle"
                    className={`text-[8.5px] font-bold tracking-wider pointer-events-none transition-colors duration-300 ${
                      isSelected ? "fill-black" : "fill-[#D9D4CF]"
                    }`}
                  >
                    {c.name}
                  </text>
                  {/* Embedded Metric Mini Badge */}
                  <text
                    x={c.labelX}
                    y={c.labelY + 11}
                    textAnchor="middle"
                    className={`text-[8px] font-mono pointer-events-none ${
                      isSelected ? "fill-black font-black" : "fill-[#B87333]"
                    }`}
                  >
                    {inflationRates[c.name]?.toFixed(1)}% YoY
                  </text>
                </g>
              );
            })}

            {/* Interactive Pin Overlays */}
            <g transform="translate(145, 160)" className="pointer-events-none">
              <circle cx="0" cy="0" r="3.5" fill="#B87333" className="animate-ping absolute" />
              <circle cx="0" cy="0" r="2.5" fill="#B87333" />
              <text x="6" y="2.5" className="text-[7.5px] font-semibold fill-[#888]">Leeds</text>
            </g>
            <g transform="translate(195, 235)" className="pointer-events-none">
              <circle cx="0" cy="0" r="2.5" fill="#555" />
              <text x="6" y="2.5" className="text-[7.5px] fill-[#555] font-bold">Sheffield</text>
            </g>
            <g transform="translate(205, 120)" className="pointer-events-none">
              <circle cx="0" cy="0" r="2.5" fill="#555" />
              <text x="6" y="2.5" className="text-[7.5px] fill-[#555] font-bold">York</text>
            </g>
            <g transform="translate(290, 185)" className="pointer-events-none">
              <circle cx="0" cy="0" r="2.5" fill="#555" />
              <text x="-24" y="2.5" className="text-[7.5px] fill-[#555] font-bold">Hull</text>
            </g>
          </svg>
          <div className="absolute bottom-2 right-2 text-[10px] font-mono text-[#555]">
            Coded Vector GIS Overlay
          </div>
        </div>
      </div>

      {/* Regional Metadata Panel */}
      <div className="lg:col-span-5 flex flex-col justify-between space-y-4">
        <div className="space-y-4">
          <div className="border-b border-[#2A2A2A] pb-3">
            <div className="text-[9px] font-mono uppercase text-[#B87333] tracking-[0.2em] font-bold">Geographic Segment focus</div>
            <h4 className="text-xl font-black uppercase tracking-tight text-white">{currentFocus}</h4>
          </div>

          {/* Quick Metrics */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-[#0F0F0F] p-4 rounded-none border border-[#2A2A2A]">
              <div className="text-[9px] text-[#555] uppercase tracking-wider font-bold flex items-center space-x-1">
                <TrendingUp className="w-3 h-3 text-[#B87333]" />
                <span>County YoY CPI</span>
              </div>
              <div className="text-2xl font-black font-mono tracking-tighter text-[#B87333] mt-1">
                {inflationRates[currentFocus === "Yorkshire & Humber" ? "Yorkshire & Humber" : currentFocus]?.toFixed(2)}%
              </div>
            </div>
            <div className="bg-[#0F0F0F] p-4 rounded-none border border-[#2A2A2A]">
              <div className="text-[9px] text-[#555] uppercase tracking-wider font-bold flex items-center space-x-1">
                <Landmark className="w-3 h-3 text-[#B87333]" />
                <span>Rhino Exposure</span>
              </div>
              <div className="text-2xl font-black font-mono tracking-tighter text-white mt-1">
                £{totalExposure.toLocaleString()}M
              </div>
            </div>
          </div>

          {/* Local Authority breakdown */}
          <div className="space-y-2">
            <div className="text-[10px] font-bold text-[#888] uppercase tracking-wider mb-2">
              Constituent Local Authorities ({filteredLAs.length})
            </div>
            <div className="max-h-[175px] overflow-y-auto space-y-1.5 pr-1 text-xs">
              {filteredLAs.map((la) => (
                <div
                  key={la.id}
                  className="flex items-center justify-between bg-[#131313] p-2 rounded-none border border-[#222] hover:border-[#B87333] transition"
                >
                  <div className="flex items-center space-x-2">
                    <MapPin className="w-3 h-3 text-[#B87333]" />
                    <span className="text-[#D9D4CF] font-bold">{la.name}</span>
                  </div>
                  <div className="flex items-center space-x-4 font-mono text-[11px]">
                    <span className="text-[#555]" title="Regional Weight">W: {(la.cpiWeight * 100).toFixed(0)}%</span>
                    <span className="text-[#888]" title="Current Price Index">Index: {la.baselineCpi}</span>
                    <span className={getMetricColor(la.exposureM, "exposure")} title="Bank Exposure">
                      £{la.exposureM}M
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Banking risk message */}
        <div className="bg-[#1A1A1A] p-4 rounded-none border-l-4 border-[#B87333] text-xs flex items-start space-x-2.5">
          <ShieldAlert className="w-4 h-4 text-[#B87333] shrink-0 mt-0.5" />
          <p className="text-[#D9D4CF] leading-relaxed">
            <span className="font-bold text-[#B87333] uppercase tracking-wider">Treasury Notice:</span> South Yorkshire displays elevated manufacturing cost exposures. Combined West Yorkshire credit positions total <span className="font-bold">£1.31B</span> across Leeds, Bradford, and Wakefield.
          </p>
        </div>
      </div>
    </div>
  );
}
