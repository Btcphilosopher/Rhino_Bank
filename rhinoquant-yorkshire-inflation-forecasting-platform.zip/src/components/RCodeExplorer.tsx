import React, { useState, useEffect } from "react";
import { Terminal, Copy, Check, FileCode, Play, AlertCircle } from "lucide-react";
import { RFileContent } from "../types";

export default function RCodeExplorer() {
  const [files, setFiles] = useState<RFileContent[]>([]);
  const [selectedFileIndex, setSelectedFileIndex] = useState(0);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);
  const [isExecuting, setIsExecuting] = useState(false);
  const [terminalLogs, setTerminalLogs] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState<"code" | "terminal">("code");

  useEffect(() => {
    // Fetch the real R file contents from the Express API
    const loadRFiles = async () => {
      try {
        const res = await fetch("/api/r-files");
        const data = await res.json();
        setFiles(data);
      } catch (err) {
        console.error("Failed to load R files:", err);
      } finally {
        setLoading(false);
      }
    };
    loadRFiles();
  }, []);

  const handleCopy = () => {
    if (files.length === 0) return;
    navigator.clipboard.writeText(files[selectedFileIndex].content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const runPipelineSim = () => {
    setIsExecuting(true);
    setActiveTab("terminal");
    setTerminalLogs([
      "rhinoquant@intelligence-node-leeds:~$ Rscript /RhinoQuantInflation/main.R",
      "==============================================================================",
      "   RHINOQUANT YORKSHIRE INFLATION FORECASTING PLATFORM - INITIALIZING CORE    ",
      "==============================================================================",
      "   [SYSTEM] Sourcing internal modules: data_import.R, econometrics.R...",
      "   [SYSTEM] Core workspace package requirements verified: forecast, stats, dlyr.",
      "   [SYSTEM] Data engine timestamp attribute tracking engaged."
    ]);

    const steps = [
      {
        delay: 800,
        log: "\n[Step 1] Loading regional indicators...\nLoaded 54 observation epochs (spanning 2022-01-01 to 2026-06-01)\nOutliers check: 3x Median Absolute Deviation applied. Zero extreme records pruned."
      },
      {
        delay: 1600,
        log: "\n[Step 2] Testing Cointegration (West Yorkshire link to UK Base)...\nCo-integrating regression: West Yorkshire ~ UK_CPI\nResidual t-statistic: -3.42 (Critical Value threshold: -3.2)\nCointegration Statistically Verified: TRUE\nLong-Run Multiplier (Beta): 1.0185\nIntercept offset: 0.925"
      },
      {
        delay: 2400,
        log: "\n[Step 3] Running Structural Break Detection...\nSearching for optimal breakpoint with Chow rolling residual variance minimize...\nOptimal Structural Breakpoint Detected at Epoch: 2023-01-01 (Energy Price Cap adjust)\nChow-Test Significance (F-Stat: 14.82, P-Value: 0.00041)\nStructural break is statistically significant: TRUE"
      },
      {
        delay: 3200,
        log: "\n[Step 4] Running 12-Month ARIMA Inflation Forecast for Leeds/West Yorkshire...\nARIMA(1,1,2)(0,1,1)[12] with drift selected by AIC minimization\nPoint Forecasts (next 3 periods): 115.12, 115.48, 115.91\nForecast Uncertainty Interval Confidence: 95%\nModel Specification: auto.arima(ts_series, seasonal=TRUE)\nForecast AIC: 142.1 | BIC: 148.5"
      },
      {
        delay: 4000,
        log: "\n[Step 5] Triggering Banking Portfolio Stress Test under Severe Scenario...\nStress multipliers applied: Mortgage defaults (x1.85), SME Impairment (x1.92)\nExpected mortgage probability of default (PD): 2.78% (Baseline: 1.50%)\nEstimated capital erosion on regional loan books: M$22.84\nNet Interest Margin degradation: -45bps (Funding beta pressure)\n\n==============================================================================\n                  DEMONSTRATION RUN COMPLETE - SYSTEM INTEGRITY OK            \n=============================================================================="
      }
    ];

    steps.forEach((step) => {
      setTimeout(() => {
        setTerminalLogs((prev) => [...prev, step.log]);
        if (step.delay === 4000) {
          setIsExecuting(false);
        }
      }, step.delay);
    });
  };

  const activeFile = files[selectedFileIndex];

  return (
    <div className="bg-[#121212] rounded-none border border-[#2A2A2A] overflow-hidden flex flex-col h-[520px]">
      {/* Header and trigger */}
      <div className="bg-[#151515] px-4 py-3 border-b border-[#2A2A2A] flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Terminal className="w-4 h-4 text-[#B87333]" />
          <h3 className="text-[10px] uppercase tracking-[0.3em] text-white font-bold">
            RhinoQuant Enterprise R Econometric Library
          </h3>
        </div>
        <div className="flex space-x-2">
          <button
            onClick={() => setActiveTab("code")}
            className={`px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider rounded-none transition ${
              activeTab === "code"
                ? "bg-[#0F0F0F] text-[#B87333] border border-[#2A2A2A]"
                : "text-[#888] hover:text-[#D9D4CF]"
            }`}
          >
            Source Code
          </button>
          <button
            onClick={() => setActiveTab("terminal")}
            className={`px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider rounded-none transition ${
              activeTab === "terminal"
                ? "bg-[#0F0F0F] text-[#B87333] border border-[#2A2A2A]"
                : "text-[#888] hover:text-[#D9D4CF]"
            }`}
          >
            R Console
          </button>
          <button
            onClick={runPipelineSim}
            disabled={isExecuting}
            className="flex items-center space-x-1 px-3 py-1 bg-[#B87333] hover:bg-[#D28E4D] disabled:bg-[#1A1A1A] disabled:text-[#555] text-black font-black uppercase tracking-widest text-xs rounded-none transition"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>{isExecuting ? "Executing..." : "Run R script"}</span>
          </button>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar file tree */}
        <div className="w-60 border-r border-[#2A2A2A] bg-[#151515] p-3 overflow-y-auto">
          <div className="text-[9px] font-mono uppercase text-[#555] font-bold tracking-wider mb-2 px-2">
            R Project Files (/RhinoQuantInflation)
          </div>
          {loading ? (
            <div className="space-y-2 p-2">
              <div className="h-6 bg-[#0F0F0F] rounded-none animate-pulse"></div>
              <div className="h-6 bg-[#0F0F0F] rounded-none animate-pulse"></div>
              <div className="h-6 bg-[#0F0F0F] rounded-none animate-pulse"></div>
            </div>
          ) : (
            <div className="space-y-1">
              {files.map((file, idx) => (
                <button
                  key={file.name}
                  onClick={() => {
                    setSelectedFileIndex(idx);
                    setActiveTab("code");
                  }}
                  className={`w-full text-left px-2.5 py-2 rounded-none text-xs flex items-center space-x-2 transition ${
                    selectedFileIndex === idx && activeTab === "code"
                      ? "bg-[#0F0F0F] text-[#B87333] font-bold"
                      : "text-[#888] hover:bg-[#121212] hover:text-[#D9D4CF]"
                  }`}
                >
                  <FileCode className="w-3.5 h-3.5 shrink-0" />
                  <span className="truncate">{file.name}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Workspace Display Area */}
        <div className="flex-1 bg-[#0F0F0F] overflow-auto relative">
          {activeTab === "code" ? (
            <>
              {activeFile ? (
                <>
                  <div className="absolute top-3 right-3 z-10">
                    <button
                      onClick={handleCopy}
                      className="p-1.5 bg-[#121212] hover:bg-[#1A1A1A] rounded-none border border-[#2A2A2A] text-[#888] hover:text-[#D9D4CF] transition"
                      title="Copy code to clipboard"
                    >
                      {copied ? (
                        <Check className="w-4 h-4 text-[#B87333]" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                  <pre className="p-4 font-mono text-[11px] leading-relaxed text-[#D9D4CF]">
                    <code>{activeFile.content}</code>
                  </pre>
                </>
              ) : (
                <div className="flex items-center justify-center h-full text-[#555] text-xs uppercase tracking-wider font-bold">
                  Select an R file from the project panel.
                </div>
              )}
            </>
          ) : (
            <div className="p-4 font-mono text-[11px] text-emerald-500 leading-relaxed bg-[#0A0A0A] h-full flex flex-col justify-between">
              <div className="flex-1 overflow-auto space-y-1.5 scrollbar-thin">
                {terminalLogs.length === 0 ? (
                  <div className="text-[#555] italic">
                    Console idle. Click "Run R script" to launch econometric test pipelines and model validations.
                  </div>
                ) : (
                  terminalLogs.map((log, idx) => (
                    <div key={idx} className="whitespace-pre-wrap">
                      {log}
                    </div>
                  ))
                )}
              </div>
              <div className="border-t border-[#111] pt-2 flex items-center justify-between text-[10px] text-[#555]">
                <span>R environment: v4.3.1 (Tidyverse, forecast, xgboost loaded)</span>
                {isExecuting && (
                  <span className="flex items-center space-x-1 animate-pulse text-[#B87333] font-bold">
                    <span className="w-1.5 h-1.5 bg-[#B87333] rounded-none inline-block"></span>
                    <span>RSCRIPT EXECUTING...</span>
                  </span>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
