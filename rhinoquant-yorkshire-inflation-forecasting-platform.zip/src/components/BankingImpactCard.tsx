import React, { useMemo } from "react";
import { StressTestResult } from "../types";
import { ShieldAlert, CheckCircle, AlertTriangle, HelpCircle, Landmark, Briefcase, Key, Activity } from "lucide-react";

interface BankingImpactCardProps {
  bankRate: number;
  energyShock: number;
  wageGrowth: number;
  baselineInflation: number;
  portfolioSizes?: {
    mortgage: number;
    commercial: number;
    sme: number;
  };
}

export default function BankingImpactCard({
  bankRate,
  energyShock,
  wageGrowth,
  baselineInflation,
  portfolioSizes = { mortgage: 1200, commercial: 850, sme: 450 }, // millions
}: BankingImpactCardProps) {
  // Compute portfolio impacts in TypeScript using identical elasticities as R script
  const impact = useMemo<StressTestResult>(() => {
    const netDisposableSqueeze = energyShock * 0.15 + baselineInflation - wageGrowth;

    // Multipliers
    const mortgageMult = 1.0 + (Math.max(0, netDisposableSqueeze) * 0.15) + (bankRate * 0.25);
    const commMult = 1.0 + (baselineInflation * 0.08) + (bankRate * 0.12);
    const smeMult = 1.0 + (netDisposableSqueeze * 0.22) + (bankRate * 0.18);

    // Basel credit parameters (baseline PDs)
    const basePdM = 0.0150; // 1.5%
    const basePdC = 0.0320; // 3.2%
    const basePdS = 0.0450; // 4.5%

    // Stressed PDs
    const stressedPdM = Math.min(0.12, basePdM * mortgageMult);
    const stressedPdC = Math.min(0.15, basePdC * commMult);
    const stressedPdS = Math.min(0.18, basePdS * smeMult);

    // Expected Loss changes (Basel formula: Exposure * PD * LGD)
    // LGD assumptions: Mortgage = 30%, Commercial = 45%, SME = 50%
    const lgdM = 0.30;
    const lgdC = 0.45;
    const lgdS = 0.50;

    const baseLossM = portfolioSizes.mortgage * basePdM * lgdM;
    const stressedLossM = portfolioSizes.mortgage * stressedPdM * lgdM;

    const baseLossC = portfolioSizes.commercial * basePdC * lgdC;
    const stressedLossC = portfolioSizes.commercial * stressedPdC * lgdC;

    const baseLossS = portfolioSizes.sme * basePdS * lgdS;
    const stressedLossS = portfolioSizes.sme * stressedPdS * lgdS;

    // NIM compression (funding cost beta vs variable yields)
    const fundingCostPremium = bankRate * 0.85 + (baselineInflation * 0.10);
    const assetYieldRepricing = bankRate * 0.60;
    const nimDelta = assetYieldRepricing - fundingCostPremium;

    // Status mapping
    const getStatus = (pd: number, thresh: number): "Stable" | "Warning" | "Critical" => {
      if (pd > thresh * 2) return "Critical";
      if (pd > thresh * 1.3) return "Warning";
      return "Stable";
    };

    return {
      mortgages: {
        stressedPd: stressedPdM,
        expectedLossDeltaM: Number((stressedLossM - baseLossM).toFixed(2)),
        capitalReqMultiplier: Number(mortgageMult.toFixed(2)),
        riskStatus: getStatus(stressedPdM, basePdM),
      },
      commercial: {
        stressedPd: stressedPdC,
        expectedLossDeltaM: Number((stressedLossC - baseLossC).toFixed(2)),
        capitalReqMultiplier: Number(commMult.toFixed(2)),
        riskStatus: getStatus(stressedPdC, basePdC),
      },
      sme: {
        stressedPd: stressedPdS,
        expectedLossDeltaM: Number((stressedLossS - baseLossS).toFixed(2)),
        capitalReqMultiplier: Number(smeMult.toFixed(2)),
        riskStatus: getStatus(stressedPdS, basePdS),
      },
      treasury: {
        fundingCostIncreaseBps: Number((fundingCostPremium * 100).toFixed(0)),
        nimDeltaPercent: Number(nimDelta.toFixed(2)),
        capitalErosionM: Number(((stressedLossM - baseLossM) + (stressedLossC - baseLossC) + (stressedLossS - baseLossS)).toFixed(2)),
        portfolioBeta: Number((1.0 + bankRate * 0.1).toFixed(2)),
      },
    };
  }, [bankRate, energyShock, wageGrowth, baselineInflation, portfolioSizes]);

  const getStatusBadge = (status: "Stable" | "Warning" | "Critical") => {
    switch (status) {
      case "Critical":
        return (
          <span className="flex items-center space-x-1 px-2.5 py-1 rounded-none bg-[#1A1A1A] text-rose-500 border-l-4 border-rose-500 text-[9px] font-black uppercase tracking-widest">
            <ShieldAlert className="w-3 h-3" />
            <span>CRITICAL</span>
          </span>
        );
      case "Warning":
        return (
          <span className="flex items-center space-x-1 px-2.5 py-1 rounded-none bg-[#1A1A1A] text-[#B87333] border-l-4 border-[#B87333] text-[9px] font-black uppercase tracking-widest">
            <AlertTriangle className="w-3 h-3 text-[#B87333]" />
            <span>ELEVATED</span>
          </span>
        );
      case "Stable":
      default:
        return (
          <span className="flex items-center space-x-1 px-2.5 py-1 rounded-none bg-[#1A1A1A] text-emerald-500 border-l-4 border-emerald-500 text-[9px] font-black uppercase tracking-widest">
            <CheckCircle className="w-3 h-3" />
            <span>STABLE</span>
          </span>
        );
    }
  };

  return (
    <div className="bg-[#121212] p-6 rounded-none border border-[#2A2A2A] space-y-6">
      <div className="flex items-center justify-between border-b border-[#2A2A2A] pb-4">
        <div>
          <h3 className="text-[10px] uppercase tracking-[0.3em] text-[#B87333] font-bold flex items-center space-x-1.5">
            <Landmark className="w-4 h-4 text-[#B87333]" />
            <span>Rhino Bank Lending stress Diagnostic</span>
          </h3>
          <p className="text-xs text-[#888] mt-1">
            Basel expected loss (EL) and regulatory capital adjustments under the simulated macro scenarios.
          </p>
        </div>
      </div>

      {/* Credit portfolios stack */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Mortgages */}
        <div className="bg-[#131313] p-4 rounded-none border border-[#2A2A2A] space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-black text-white uppercase tracking-wider flex items-center space-x-1.5">
              <Key className="w-3.5 h-3.5 text-[#B87333]" />
              <span>Mortgages</span>
            </span>
            {getStatusBadge(impact.mortgages.riskStatus)}
          </div>
          <div className="space-y-2 font-mono text-xs">
            <div className="flex justify-between border-b border-[#222] pb-1.5">
              <span className="text-[#555] font-bold">Book Exposure:</span>
              <span className="text-[#D9D4CF]">£{portfolioSizes.mortgage}M</span>
            </div>
            <div className="flex justify-between border-b border-[#222] pb-1.5">
              <span className="text-[#555] font-bold">Stressed PD:</span>
              <span className="text-[#D9D4CF]">{(impact.mortgages.stressedPd * 100).toFixed(2)}%</span>
            </div>
            <div className="flex justify-between border-b border-[#222] pb-1.5">
              <span className="text-[#555] font-bold">Capital Mult:</span>
              <span className="text-[#B87333] font-black">{(impact.mortgages.capitalReqMultiplier).toFixed(2)}x</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#555] font-bold">Loss Delta:</span>
              <span className="text-rose-500 font-bold">+£{impact.mortgages.expectedLossDeltaM}M</span>
            </div>
          </div>
        </div>

        {/* Commercial CRE */}
        <div className="bg-[#131313] p-4 rounded-none border border-[#2A2A2A] space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-black text-white uppercase tracking-wider flex items-center space-x-1.5">
              <Landmark className="w-3.5 h-3.5 text-[#B87333]" />
              <span>Commercial CRE</span>
            </span>
            {getStatusBadge(impact.commercial.riskStatus)}
          </div>
          <div className="space-y-2 font-mono text-xs">
            <div className="flex justify-between border-b border-[#222] pb-1.5">
              <span className="text-[#555] font-bold">Book Exposure:</span>
              <span className="text-[#D9D4CF]">£{portfolioSizes.commercial}M</span>
            </div>
            <div className="flex justify-between border-b border-[#222] pb-1.5">
              <span className="text-[#555] font-bold">Stressed PD:</span>
              <span className="text-[#D9D4CF]">{(impact.commercial.stressedPd * 100).toFixed(2)}%</span>
            </div>
            <div className="flex justify-between border-b border-[#222] pb-1.5">
              <span className="text-[#555] font-bold">Capital Mult:</span>
              <span className="text-[#B87333] font-black">{(impact.commercial.capitalReqMultiplier).toFixed(2)}x</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#555] font-bold">Loss Delta:</span>
              <span className="text-rose-500 font-bold">+£{impact.commercial.expectedLossDeltaM}M</span>
            </div>
          </div>
        </div>

        {/* SME Corporate */}
        <div className="bg-[#131313] p-4 rounded-none border border-[#2A2A2A] space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-black text-white uppercase tracking-wider flex items-center space-x-1.5">
              <Briefcase className="w-3.5 h-3.5 text-[#B87333]" />
              <span>SME Portfolios</span>
            </span>
            {getStatusBadge(impact.sme.riskStatus)}
          </div>
          <div className="space-y-2 font-mono text-xs">
            <div className="flex justify-between border-b border-[#222] pb-1.5">
              <span className="text-[#555] font-bold">Book Exposure:</span>
              <span className="text-[#D9D4CF]">£{portfolioSizes.sme}M</span>
            </div>
            <div className="flex justify-between border-b border-[#222] pb-1.5">
              <span className="text-[#555] font-bold">Stressed PD:</span>
              <span className="text-[#D9D4CF]">{(impact.sme.stressedPd * 100).toFixed(2)}%</span>
            </div>
            <div className="flex justify-between border-b border-[#222] pb-1.5">
              <span className="text-[#555] font-bold">Capital Mult:</span>
              <span className="text-[#B87333] font-black">{(impact.sme.capitalReqMultiplier).toFixed(2)}x</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#555] font-bold">Loss Delta:</span>
              <span className="text-rose-500 font-bold">+£{impact.sme.expectedLossDeltaM}M</span>
            </div>
          </div>
        </div>
      </div>

      {/* Treasury funding summary panel */}
      <div className="bg-[#0F0F0F] p-5 rounded-none border border-[#2A2A2A] grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="space-y-1.5">
          <div className="text-[10px] text-[#555] uppercase tracking-[0.2em] font-bold">Treasury Funding Premium</div>
          <div className="text-xl font-black font-mono tracking-tighter text-white">+{impact.treasury.fundingCostIncreaseBps} BPS</div>
          <p className="text-[10px] text-[#888]">Simulated marginal deposit rate increase</p>
        </div>

        <div className="space-y-1.5">
          <div className="text-[10px] text-[#555] uppercase tracking-[0.2em] font-bold">Net Interest Margin (NIM) Delta</div>
          <div className={`text-xl font-black font-mono tracking-tighter ${impact.treasury.nimDeltaPercent >= 0 ? "text-emerald-500" : "text-[#B87333]"}`}>
            {impact.treasury.nimDeltaPercent >= 0 ? "+" : ""}{impact.treasury.nimDeltaPercent.toFixed(2)}%
          </div>
          <p className="text-[10px] text-[#888]">Assets repricing minus liability rates premium</p>
        </div>

        <div className="space-y-1.5">
          <div className="text-[10px] text-[#555] uppercase tracking-[0.2em] font-bold">Capital Reserves Erosion</div>
          <div className="text-xl font-black font-mono tracking-tighter text-rose-500">£{impact.treasury.capitalErosionM}M</div>
          <p className="text-[10px] text-[#888]">Estimated write-down in expected credit loss</p>
        </div>
      </div>
    </div>
  );
}
