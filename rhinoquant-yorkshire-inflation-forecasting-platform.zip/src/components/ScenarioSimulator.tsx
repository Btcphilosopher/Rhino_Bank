import React from "react";
import { ScenarioPreset } from "../types";
import { scenarioPresets } from "../data";
import { Sliders, HelpCircle, Flame, DollarSign, Briefcase, Zap } from "lucide-react";

interface ScenarioSimulatorProps {
  bankRate: number;
  energyShock: number;
  wageGrowth: number;
  onBankRateChange: (val: number) => void;
  onEnergyShockChange: (val: number) => void;
  onWageGrowthChange: (val: number) => void;
  onLoadPreset: (preset: ScenarioPreset) => void;
  currentPresetName: string;
}

export default function ScenarioSimulator({
  bankRate,
  energyShock,
  wageGrowth,
  onBankRateChange,
  onEnergyShockChange,
  onWageGrowthChange,
  onLoadPreset,
  currentPresetName,
}: ScenarioSimulatorProps) {
  // Implied real wage gap calculation
  const realWageGap = wageGrowth - (energyShock * 0.15 + 2.0);

  return (
    <div className="bg-[#121212] p-6 rounded-none border border-[#2A2A2A] space-y-6">
      <div className="flex items-center justify-between border-b border-[#2A2A2A] pb-4">
        <div>
          <h3 className="text-[10px] uppercase tracking-[0.3em] text-[#B87333] font-bold flex items-center space-x-1.5">
            <Sliders className="w-4 h-4 text-[#B87333]" />
            <span>Macroeconomic Scenario Simulator</span>
          </h3>
          <p className="text-xs text-[#888] mt-1">
            Apply monetary rate changes, global supply shocks, or wage spirals to overlay stress projections.
          </p>
        </div>
      </div>

      {/* Preset Pickers */}
      <div className="space-y-2.5">
        <label className="text-[9px] uppercase text-[#555] font-bold tracking-[0.15em] block">
          Simulation Presets (Rhino Quant Guidelines)
        </label>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
          {scenarioPresets.map((preset) => {
            const isActive = currentPresetName === preset.name;
            return (
              <button
                key={preset.name}
                onClick={() => onLoadPreset(preset)}
                className={`p-2.5 rounded-none text-left border transition flex flex-col justify-between h-[80px] ${
                  isActive
                    ? "bg-[#1A1A1A] border-[#B87333] text-[#B87333]"
                    : "bg-[#0F0F0F] border-[#2A2A2A] text-[#888] hover:border-[#B87333] hover:text-[#D9D4CF]"
                }`}
              >
                <span className="text-[10px] font-black uppercase tracking-wider line-clamp-2 leading-tight">
                  {preset.name}
                </span>
                <span className="text-[8.5px] text-[#555] font-mono mt-1 font-bold">
                  BR: {preset.bankRateShock >= 0 ? "+" : ""}{preset.bankRateShock}%
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Manual Sliders */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
        {/* Bank Rate */}
        <div className="bg-[#0F0F0F] p-4 rounded-none border border-[#2A2A2A] space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2 text-[10px] font-black uppercase tracking-wider text-white">
              <DollarSign className="w-3.5 h-3.5 text-[#B87333]" />
              <span>BOE policy Rate Shock</span>
            </div>
            <span className="text-xs font-mono font-bold text-[#B87333]">
              {bankRate >= 0 ? "+" : ""}{bankRate.toFixed(2)}%
            </span>
          </div>
          <input
            type="range"
            min="-1.50"
            max="3.00"
            step="0.25"
            value={bankRate}
            onChange={(e) => onBankRateChange(parseFloat(e.target.value))}
            className="w-full accent-[#B87333] h-1 bg-[#1A1A1A] rounded-none cursor-pointer"
          />
          <div className="flex justify-between text-[9px] font-mono text-[#555]">
            <span>-1.50% (Easing)</span>
            <span>+3.00% (Tightening)</span>
          </div>
        </div>

        {/* Energy Cost */}
        <div className="bg-[#0F0F0F] p-4 rounded-none border border-[#2A2A2A] space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2 text-[10px] font-black uppercase tracking-wider text-white">
              <Flame className="w-3.5 h-3.5 text-[#B87333]" />
              <span>Energy & Utilities Shock</span>
            </div>
            <span className="text-xs font-mono font-bold text-[#B87333]">
              {energyShock >= 0 ? "+" : ""}{energyShock.toFixed(0)}%
            </span>
          </div>
          <input
            type="range"
            min="-20"
            max="60"
            step="5"
            value={energyShock}
            onChange={(e) => onEnergyShockChange(parseInt(e.target.value))}
            className="w-full accent-[#B87333] h-1 bg-[#1A1A1A] rounded-none cursor-pointer"
          />
          <div className="flex justify-between text-[9px] font-mono text-[#555]">
            <span>-20% (Abundance)</span>
            <span>+60% (Extreme Shock)</span>
          </div>
        </div>

        {/* Wage Growth */}
        <div className="bg-[#0F0F0F] p-4 rounded-none border border-[#2A2A2A] space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2 text-[10px] font-black uppercase tracking-wider text-white">
              <Briefcase className="w-3.5 h-3.5 text-[#B87333]" />
              <span>Wage Spiral Rate</span>
            </div>
            <span className="text-xs font-mono font-bold text-[#B87333]">
              {wageGrowth >= 0 ? "+" : ""}{wageGrowth.toFixed(1)}%
            </span>
          </div>
          <input
            type="range"
            min="-1.0"
            max="8.0"
            step="0.5"
            value={wageGrowth}
            onChange={(e) => onWageGrowthChange(parseFloat(e.target.value))}
            className="w-full accent-[#B87333] h-1 bg-[#1A1A1A] rounded-none cursor-pointer"
          />
          <div className="flex justify-between text-[9px] font-mono text-[#555]">
            <span>-1.0% (Stagnation)</span>
            <span>+8.0% (Wage Spiral)</span>
          </div>
        </div>
      </div>

      {/* Real-time Economic Indicator Projections */}
      <div className="bg-[#1A1A1A] p-4 rounded-none border-l-4 border-[#B87333] flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Zap className="w-5 h-5 text-[#B87333] animate-pulse shrink-0" />
          <div>
            <div className="text-[9px] text-[#555] uppercase tracking-[0.2em] font-bold">
              Implied Real Wage Discretionary Cap
            </div>
            <div className="text-xs font-black uppercase text-[#D9D4CF] mt-0.5">
              {realWageGap > 0 ? "Real Wage Buffer: " : "Real Disposable Deficit: "}
              <span className={realWageGap > 0 ? "text-emerald-500" : "text-rose-500"}>
                {realWageGap.toFixed(2)}%
              </span>
            </div>
          </div>
        </div>
        <div className="text-[10px] font-mono text-[#888] max-w-sm text-right leading-relaxed hidden md:block">
          Net disposable income compression models the direct household credit pressure, driving mortgage defaults across West Yorkshire industrial cohorts.
        </div>
      </div>
    </div>
  );
}
