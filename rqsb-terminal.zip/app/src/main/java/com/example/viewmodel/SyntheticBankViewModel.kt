package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.engine.*
import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class TerminalUiState(
    val currentScreen: String = "SBANK", // SBANK, BAL, ECOBAL, SYNBAL, DNA, DEPOSIT, LOAN, CREDIT, SRATES, SCDO, FUND, COLL, LEV, CAPITAL, LIQ, IRRBB, CCR, STRESS, REPLICATE, ECON, AI
    val bankState: SyntheticBankState = SyntheticBankState(),
    val commandInput: String = "",
    val terminalLog: List<String> = listOf(
        "RHINOQUANT SYNTHETIC BANKING OS [RQSB-V4.2] INITIALIZED",
        "ALL ENGINES ONLINE: LEGAL, ECOBAL, SYNBAL, RWA, LCR, IRRBB, CCR",
        "TYPE SBANK <GO> OR COMMAND TO NAVIGATE"
    ),
    val selectedStressScenarioIndex: Int = 0,
    val aiQueryInput: String = "What is our synthetic leverage?",
    val aiResponse: AiCopilotEngine.AiResponse? = null
)

class SyntheticBankViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(
        TerminalUiState(
            bankState = initializeDefaultBank()
        )
    )
    val uiState: StateFlow<TerminalUiState> = _uiState.asStateFlow()

    init {
        // Pre-run baseline AI query
        executeAiQuery("What is our synthetic leverage?")
    }

    private fun initializeDefaultBank(): SyntheticBankState {
        val initialDeposits = listOf(
            DepositSegment("DEP-1", "Retail Term", 20850.0, 3.2, 2.0, 4.5, 8.0, 0.40, 92.0),
            DepositSegment("DEP-2", "Corporate Operational", 18250.0, 3.8, 0.5, 1.2, 22.0, 0.75, 74.0),
            DepositSegment("DEP-3", "Institutional Wholesale", 7820.0, 4.4, 0.2, 0.4, 38.0, 0.95, 52.0),
            DepositSegment("DEP-4", "Interbank / Broker Escrow", 5220.0, 4.6, 0.1, 0.1, 55.0, 0.98, 41.0)
        )

        val initialCdo = listOf(
            CDOTranche("TR-1", "Equity Tranche (0-3%)", TrancheSeniority.EQUITY, 0.0, 3.0, 150.0, 950.0, "SOLD_PROTECTION", 8.4, 180.0),
            CDOTranche("TR-2", "Mezzanine (3-7%)", TrancheSeniority.MEZZANINE, 3.0, 7.0, 200.0, 420.0, "BOUGHT_PROTECTION", 2.8, 90.0),
            CDOTranche("TR-3", "Senior (7-15%)", TrancheSeniority.SENIOR, 7.0, 15.0, 400.0, 160.0, "SOLD_PROTECTION", 0.6, 60.0),
            CDOTranche("TR-4", "Super Senior (15-100%)", TrancheSeniority.SUPER_SENIOR, 15.0, 100.0, 4250.0, 45.0, "SOLD_PROTECTION", 0.05, 110.0)
        )

        val initialCounterparties = listOf(
            CounterpartyExposure("CCP_LCH_CLEARNET", "AAA", 7400.0, 4800.0, 4200.0, 1250.0, 18.2, 14.1),
            CounterpartyExposure("GOLDMAN_SACHS_PARIS", "AA-", 4100.0, 3400.0, 2900.0, 840.0, 22.4, 19.8),
            CounterpartyExposure("JPMORGAN_CHASE_LDN", "AA+", 3800.0, 2900.0, 2600.0, 720.0, 15.6, 12.0),
            CounterpartyExposure("BARCLAYS_CAPITAL_UK", "A+", 2800.0, 2100.0, 1850.0, 560.0, 28.1, 11.2),
            CounterpartyExposure("BNP_PARIBAS_TREAS", "AA", 2500.0, 1950.0, 1700.0, 480.0, 14.5, 16.0),
            CounterpartyExposure("CITIGROUP_GLOBAL_NY", "A+", 2200.0, 1700.0, 1500.0, 410.0, 26.2, 18.5)
        )

        return SyntheticBankState(
            deposits = initialDeposits,
            cdoTranches = initialCdo,
            counterparties = initialCounterparties
        )
    }

    fun onCommandInputChange(input: String) {
        _uiState.update { it.copy(commandInput = input) }
    }

    fun onAiQueryInputChange(input: String) {
        _uiState.update { it.copy(aiQueryInput = input) }
    }

    fun submitCommand() {
        val input = _uiState.value.commandInput.trim()
        if (input.isEmpty()) return

        val result = RqqlParser.executeCommand(input, _uiState.value.bankState)
        _uiState.update { current ->
            val logs = current.terminalLog.toMutableList()
            logs.add("> $input")

            when (result) {
                is TerminalCommandResult.Success -> {
                    logs.add("[OK] ${result.message}")
                    current.copy(
                        commandInput = "",
                        bankState = result.updatedState ?: current.bankState,
                        terminalLog = logs.takeLast(50)
                    )
                }
                is TerminalCommandResult.Navigation -> {
                    logs.add("[NAV] SWITCH TO SCREEN: ${result.targetScreen}")
                    current.copy(
                        commandInput = "",
                        currentScreen = result.targetScreen,
                        terminalLog = logs.takeLast(50)
                    )
                }
                is TerminalCommandResult.Error -> {
                    logs.add("[ERR] ${result.error}")
                    current.copy(
                        commandInput = "",
                        terminalLog = logs.takeLast(50)
                    )
                }
            }
        }
    }

    fun navigateTo(screen: String) {
        _uiState.update { it.copy(currentScreen = screen) }
    }

    fun selectStressScenario(index: Int) {
        _uiState.update { it.copy(selectedStressScenarioIndex = index) }
    }

    fun executeAiQuery(query: String) {
        viewModelScope.launch {
            val response = AiCopilotEngine.answerQuery(query, _uiState.value.bankState)
            _uiState.update { it.copy(aiResponse = response, aiQueryInput = query) }
        }
    }

    fun addBalanceItem(type: String, amount: Double) {
        val cmd = "ADD $type ${amount.toInt()}M"
        _uiState.update { it.copy(commandInput = cmd) }
        submitCommand()
    }

    fun hedgeDuration(years: Double) {
        val cmd = "HEDGE DURATION ${years}Y"
        _uiState.update { it.copy(commandInput = cmd) }
        submitCommand()
    }
}
