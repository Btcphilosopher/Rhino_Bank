package com.example.engine

import com.example.model.SyntheticBankState

object AiCopilotEngine {

    data class AiResponse(
        val question: String,
        val summary: String,
        val calculations: List<Pair<String, String>>,
        val recommendations: List<String>
    )

    fun answerQuery(query: String, state: SyntheticBankState): AiResponse {
        val q = query.lowercase().trim()
        val legal = FinancialEngines.computeLegalBalanceSheet(state)
        val eco = FinancialEngines.computeEconomicBalanceSheet(state)
        val synth = FinancialEngines.computeSyntheticBalanceSheet(state)
        val cap = FinancialEngines.computeCapitalAdequacy(state)
        val liq = FinancialEngines.computeLiquidity(state)
        val risk = FinancialEngines.computeRiskMetrics(state)
        val econ = FinancialEngines.computeBankEconomics(state)

        return when {
            q.contains("leverage") -> {
                AiResponse(
                    question = query,
                    summary = "Synthetic Leverage is ${String.format("%.1fx", synth.syntheticLeverage)}, significantly higher than Accounting Leverage (${String.format("%.1fx", legal.accountingLeverage)}) due to embedded derivative exposures.",
                    calculations = listOf(
                        "Accounting Leverage" to "${String.format("%.1fx", legal.accountingLeverage)} (Total Assets / Equity)",
                        "Economic Leverage" to "${String.format("%.1fx", eco.economicLeverage)} (Gross Economic Assets / Net Capital)",
                        "Synthetic Leverage" to "${String.format("%.1fx", synth.syntheticLeverage)} (Includes Gross Notional & Delta Cash Equiv)",
                        "Stress Leverage" to "${String.format("%.1fx", risk.stressLeverage)} (Post-Shock Capital Depletion)"
                    ),
                    recommendations = listOf(
                        "Derivative Gross Notional ($${synth.totalDerivativeGrossNotional.toInt()}M) embeds hidden leverage not visible on standard Balance Sheet.",
                        "Consider novating or compression of IRS and CDS portfolios via CCP to reduce gross leverage."
                    )
                )
            }

            q.contains("credit spread") || q.contains("200bp") || q.contains("widens") -> {
                val shockBps = 200.0
                val loss = (state.physicalSecurities + state.physicalLoans + state.cdsNotional) * (shockBps / 10000.0) * 3.5
                val postCet1 = (state.cet1Capital - loss * 0.8) / (cap.totalRwa * 1.1) * 100.0
                AiResponse(
                    question = query,
                    summary = "A +200bps credit spread shock inflicts an estimated mark-to-market loss of \$${loss.toInt()}M, eroding CET1 ratio to ${String.format("%.1f%%", postCet1)}.",
                    calculations = listOf(
                        "Net CS01" to "\$${String.format("%.2f", risk.cs01Thousands)}k per bp",
                        "Physical Credit Exposure" to "\$${state.physicalLoans.toInt()}M Loans + \$${state.physicalSecurities.toInt()}M Bonds",
                        "Synthetic Credit (CDS/CDX)" to "\$${state.cdsNotional.toInt()}M Notional",
                        "Post-Stress CET1 Ratio" to "${String.format("%.1f%%", postCet1)} (Regulatory Min: 4.5% + 2.5% CCB)"
                    ),
                    recommendations = listOf(
                        "Buy iTraxx / CDX senior tranche protection to neutralize CS01.",
                        "Rebalance leveraged corporate loans towards floating-rate infra debt with collateral covenants."
                    )
                )
            }

            q.contains("deposit") && (q.contains("fall") || q.contains("30%") || q.contains("outflow")) -> {
                val outflow = state.customerDeposits * 0.30
                val postHqla = state.cashAndHqla - outflow
                val postSurvival = if (outflow > 0) (postHqla / (outflow / 30.0)).toInt() else 0
                AiResponse(
                    question = query,
                    summary = "A 30% sudden deposit run-off drains \$${outflow.toInt()}M of liquidity. Available HQLA drops to \$${postHqla.toInt()}M with survival horizon compressed to $postSurvival days.",
                    calculations = listOf(
                        "Total Deposit Base" to "\$${state.customerDeposits.toInt()}M",
                        "30% Run-off Magnitude" to "\$${outflow.toInt()}M",
                        "Unencumbered HQLA Buffer" to "\$${state.cashAndHqla.toInt()}M",
                        "Post-Run Survival Horizon" to "$postSurvival Days (Liquidity Waterfall Activated)"
                    ),
                    recommendations = listOf(
                        "Activate Central Bank Discount Window / Standing Repo Facility immediately.",
                        "Enact Synthetic Deposit hedges using term repo and pre-committed lines."
                    )
                )
            }

            q.contains("profit") || q.contains("fell") || q.contains("nii") -> {
                AiResponse(
                    question = query,
                    summary = "Economic Profit is currently \$${econ.economicProfit.toInt()}M vs Accounting Profit of \$${econ.accountingProfit.toInt()}M. The gap is driven by economic capital charges and liquidity carry cost.",
                    calculations = listOf(
                        "Net Interest Income" to "\$${econ.netInterestIncome.toInt()}M",
                        "Funding & Carry Costs" to "-\$${econ.fundingCosts.toInt()}M",
                        "Liquidity Carry Cost" to "-\$${econ.liquidityCarryCost.toInt()}M",
                        "Capital Hurdle Charge (10%)" to "-\$${((state.cet1Capital + state.at1Capital) * 0.10).toInt()}M",
                        "RAROC" to "${String.format("%.1f%%", econ.rarocPct)}"
                    ),
                    recommendations = listOf(
                        "Wholesale funding costs (5.2%) compress NII margins. Shift toward term retail deposits.",
                        "Reprice low-margin corporate facilities to exceed 12% RAROC threshold."
                    )
                )
            }

            q.contains("counterparty") || q.contains("largest") -> {
                AiResponse(
                    question = query,
                    summary = "Largest counterparty exposure is \$${risk.largestCounterpartyExp.toInt()}M with CCP_LCH (Clearing House) followed by GS_PARIS (\$3,400M) and JPM_LDN (\$2,900M).",
                    calculations = listOf(
                        "LCH Gross / Net Exposure" to "\$7,400M Gross / \$4,800M Net",
                        "Collateral Held (CVA mitigant)" to "\$4,200M variation margin",
                        "Potential Future Exposure (PFE 95%)" to "\$1,250M",
                        "Total Counterparty RWA" to "\$${cap.counterpartyRwa.toInt()}M"
                    ),
                    recommendations = listOf(
                        "Ensure daily collateral thresholds remain zero with two-way CSA agreements.",
                        "Diversify interest rate swap clearing across Eurex and CME to avoid single-CCP concentration."
                    )
                )
            }

            else -> {
                AiResponse(
                    question = query,
                    summary = "Synthesis of RQSB Programmable Balance Sheet: Legal Assets \$${legal.totalAssets.toInt()}M, Synthetic Exposure \$${synth.syntheticExposureAssets.toInt()}M, CET1 ${String.format("%.1f%%", cap.cet1RatioPct)}, LCR ${String.format("%.0f%%", liq.lcrPct)}.",
                    calculations = listOf(
                        "Economic Capital Surplus" to "+\$${cap.capitalSurplus.toInt()}M",
                        "Survival Horizon" to "${liq.survivalHorizonDays} Days",
                        "Net Duration (DV01)" to "\$${String.format("%.2f", risk.dv01Thousands)}k / bp",
                        "RAROC vs Hurdle" to "${String.format("%.1f%%", econ.rarocPct)} vs 12.0%"
                    ),
                    recommendations = listOf(
                        "Query specific topics: 'What is our synthetic leverage?', 'What happens if deposits fall 30%?', 'What happens if credit spreads widen 200bp?'",
                        "Execute command STRESS <GO> or REPLICATE <GO> in the terminal."
                    )
                )
            }
        }
    }
}
