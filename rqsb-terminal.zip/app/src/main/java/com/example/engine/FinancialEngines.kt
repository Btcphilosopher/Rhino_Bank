package com.example.engine

import com.example.model.*
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

data class BalanceSheetReport(
    val totalAssets: Double,
    val totalLiabilities: Double,
    val totalEquity: Double,
    val accountingLeverage: Double
)

data class EconomicBalanceSheetReport(
    val grossEconomicAssets: Double,
    val grossEconomicLiabilities: Double,
    val netEconomicCapital: Double,
    val economicLeverage: Double,
    val derivativeDeltaExposure: Double,
    val contingentExposure: Double
)

data class SyntheticBalanceSheetReport(
    val syntheticExposureAssets: Double,
    val syntheticExposureLiabilities: Double,
    val syntheticLeverage: Double,
    val totalDerivativeGrossNotional: Double,
    val cashEquivalentExposure: Double
)

data class CapitalAdequacyReport(
    val cet1RatioPct: Double,
    val tier1RatioPct: Double,
    val totalCapitalRatioPct: Double,
    val leverageRatioPct: Double,
    val creditRwa: Double,
    val marketRwa: Double,
    val opRwa: Double,
    val counterpartyRwa: Double,
    val totalRwa: Double,
    val capitalSurplus: Double
)

data class LiquidityReport(
    val availableHqla: Double,
    val lcrPct: Double,
    val nsfrPct: Double,
    val survivalHorizonDays: Int,
    val net30dStressGap: Double,
    val intradayBuffer: Double
)

data class RiskMetricsReport(
    val dv01Thousands: Double,
    val cs01Thousands: Double,
    val var99Percent10d: Double,
    val expectedShortfall: Double,
    val largestCounterpartyExp: Double,
    val stressLeverage: Double
)

data class BankEconomicsReport(
    val netInterestIncome: Double,
    val netFeeIncome: Double,
    val tradingPnl: Double,
    val totalRevenue: Double,
    val fundingCosts: Double,
    val creditExpectedLoss: Double,
    val liquidityCarryCost: Double,
    val operatingCost: Double,
    val accountingProfit: Double,
    val economicProfit: Double,
    val roePct: Double,
    val rarocPct: Double
)

data class BankDna(
    val assetExposures: Map<String, Double>,   // Class -> %
    val fundingMix: Map<String, Double>,       // Source -> %
    val durationYears: Double,
    val creditBeta: Double,
    val syntheticMultiplier: Double
)

data class StressSimulationResult(
    val scenario: StressScenario,
    val assetMarkToMarketLoss: Double,
    val creditSpreadLoss: Double,
    val ratesLoss: Double,
    val depositOutflow: Double,
    val repoHaircutShortfall: Double,
    val additionalMarginCall: Double,
    val totalLiquidityShock: Double,
    val postStressCet1RatioPct: Double,
    val postStressSurvivalDays: Int,
    val postStressLeverage: Double,
    val solvencyStatus: String // "SOLVENT", "CRITICAL_CAPITAL", "INSOLVENT"
)

object FinancialEngines {

    fun computeLegalBalanceSheet(state: SyntheticBankState): BalanceSheetReport {
        val totalAssets = state.cashAndHqla + state.physicalLoans + state.physicalSecurities +
                state.derivativeAssetsMtM + state.otherAssets
        val totalLiabilities = state.customerDeposits + state.wholesaleFunding + state.repoFunding +
                state.derivativeLiabilitiesMtM + state.otherLiabilities
        val totalEquity = state.cet1Capital + state.at1Capital + state.tier2Capital
        val leverage = if (totalEquity > 0) totalAssets / totalEquity else 0.0
        return BalanceSheetReport(
            totalAssets = totalAssets,
            totalLiabilities = totalLiabilities,
            totalEquity = totalEquity,
            accountingLeverage = leverage
        )
    }

    fun computeEconomicBalanceSheet(state: SyntheticBankState): EconomicBalanceSheetReport {
        val legal = computeLegalBalanceSheet(state)
        val derivativeDeltaExposure = (state.irsNotional * 0.12) + (state.cdsNotional * 0.40) + (state.trsNotional * 0.95)
        val contingentExposure = state.contingentCommitments * 0.50 // Credit conversion factor 50%
        val grossEconomicAssets = legal.totalAssets + derivativeDeltaExposure + contingentExposure
        val grossEconomicLiabilities = legal.totalLiabilities + (derivativeDeltaExposure * 0.35)
        val netEconomicCapital = grossEconomicAssets - grossEconomicLiabilities
        val economicLeverage = if (netEconomicCapital > 0) grossEconomicAssets / netEconomicCapital else 0.0

        return EconomicBalanceSheetReport(
            grossEconomicAssets = grossEconomicAssets,
            grossEconomicLiabilities = grossEconomicLiabilities,
            netEconomicCapital = netEconomicCapital,
            economicLeverage = economicLeverage,
            derivativeDeltaExposure = derivativeDeltaExposure,
            contingentExposure = contingentExposure
        )
    }

    fun computeSyntheticBalanceSheet(state: SyntheticBankState): SyntheticBalanceSheetReport {
        val grossNotional = state.irsNotional + state.cdsNotional + state.trsNotional
        val cashEquivalentExposure = (state.irsNotional * 0.18) + (state.cdsNotional * 0.85) + (state.trsNotional * 1.0)
        val totalSynthAssets = state.physicalLoans + state.physicalSecurities + cashEquivalentExposure + state.cashAndHqla
        val totalSynthLiabilities = state.customerDeposits + state.wholesaleFunding + state.repoFunding + (cashEquivalentExposure * 0.45)
        val equity = state.cet1Capital + state.at1Capital
        val synthLev = if (equity > 0) (totalSynthAssets + grossNotional * 0.10) / equity else 0.0

        return SyntheticBalanceSheetReport(
            syntheticExposureAssets = totalSynthAssets,
            syntheticExposureLiabilities = totalSynthLiabilities,
            syntheticLeverage = synthLev,
            totalDerivativeGrossNotional = grossNotional,
            cashEquivalentExposure = cashEquivalentExposure
        )
    }

    fun computeCapitalAdequacy(state: SyntheticBankState): CapitalAdequacyReport {
        // Standardised & Internal Model RWA weights
        val creditRwa = (state.physicalLoans * 0.65) + (state.physicalSecurities * 0.20) + (state.contingentCommitments * 0.45)
        val marketRwa = (state.derivativeAssetsMtM * 1.8) + (state.trsNotional * 0.15) + (state.physicalSecurities * 0.12)
        val counterpartyRwa = ((state.derivativeAssetsMtM + state.repoFunding) * 0.42) + (state.cdsNotional * 0.08)
        val opRwa = (state.physicalLoans + state.customerDeposits) * 0.04
        val totalRwa = creditRwa + marketRwa + counterpartyRwa + opRwa

        val cet1Ratio = if (totalRwa > 0) (state.cet1Capital / totalRwa) * 100.0 else 0.0
        val tier1Ratio = if (totalRwa > 0) ((state.cet1Capital + state.at1Capital) / totalRwa) * 100.0 else 0.0
        val totalCapRatio = if (totalRwa > 0) ((state.cet1Capital + state.at1Capital + state.tier2Capital) / totalRwa) * 100.0 else 0.0
        
        val totalExposure = state.cashAndHqla + state.physicalLoans + state.physicalSecurities +
                (state.irsNotional + state.cdsNotional + state.trsNotional) * 0.15 + state.contingentCommitments
        val leverageRatio = if (totalExposure > 0) (state.cet1Capital / totalExposure) * 100.0 else 0.0

        val requiredCapital = totalRwa * 0.105 // 10.5% Basel III Pillar 1 + Conservation Buffer
        val capitalSurplus = (state.cet1Capital + state.at1Capital) - requiredCapital

        return CapitalAdequacyReport(
            cet1RatioPct = cet1Ratio,
            tier1RatioPct = tier1Ratio,
            totalCapitalRatioPct = totalCapRatio,
            leverageRatioPct = leverageRatio,
            creditRwa = creditRwa,
            marketRwa = marketRwa,
            opRwa = opRwa,
            counterpartyRwa = counterpartyRwa,
            totalRwa = totalRwa,
            capitalSurplus = capitalSurplus
        )
    }

    fun computeLiquidity(state: SyntheticBankState): LiquidityReport {
        val hqla = state.cashAndHqla
        // 30-day net stressed cash outflows
        val depositRunoff = state.customerDeposits * 0.10 // 10% average run-off
        val wholesaleRunoff = state.wholesaleFunding * 0.25 // 25% wholesale non-renewal
        val repoUnwind = state.repoFunding * 0.20
        val derivativeMarginCall = (state.derivativeLiabilitiesMtM + state.irsNotional * 0.015) * 0.35
        val contingentDraw = state.contingentCommitments * 0.15
        val totalOutflows = depositRunoff + wholesaleRunoff + repoUnwind + derivativeMarginCall + contingentDraw

        // 30-day contracted inflows (capped at 75% of outflows under LCR rules)
        val loanRepayments = (state.physicalLoans * 0.02)
        val securityMaturities = (state.physicalSecurities * 0.03)
        val cappedInflows = min(loanRepayments + securityMaturities, totalOutflows * 0.75)

        val net30dStressGap = cappedInflows - totalOutflows
        val netOutflow = max(totalOutflows - cappedInflows, 1.0)
        val lcr = (hqla / netOutflow) * 100.0

        // NSFR = Available Stable Funding / Required Stable Funding
        val asf = (state.cet1Capital + state.at1Capital + state.tier2Capital) +
                (state.customerDeposits * 0.90) + (state.wholesaleFunding * 0.50)
        val rsf = (hqla * 0.05) + (state.physicalSecurities * 0.50) + (state.physicalLoans * 0.85) +
                (state.derivativeAssetsMtM * 1.0) + (state.contingentCommitments * 0.10)
        val nsfr = (asf / rsf) * 100.0

        // Daily burn rate under extreme stress
        val dailyBurn = totalOutflows / 30.0
        val survivalDays = if (dailyBurn > 0) (hqla / dailyBurn).toInt() else 999

        return LiquidityReport(
            availableHqla = hqla,
            lcrPct = lcr,
            nsfrPct = nsfr,
            survivalHorizonDays = survivalDays,
            net30dStressGap = net30dStressGap,
            intradayBuffer = hqla * 0.25
        )
    }

    fun computeRiskMetrics(state: SyntheticBankState): RiskMetricsReport {
        // Physical loans + bonds DV01
        val assetDv01 = (state.physicalLoans * 0.0001 * 3.2) + (state.physicalSecurities * 0.0001 * 5.8)
        // Swap net duration hedge
        val swapDv01 = state.irsNotional * 0.0001 * state.irsDurationYears
        val netDv01 = (assetDv01 + swapDv01) * 1000.0 // in $k

        // CS01: Credit spread 01
        val bondCs01 = state.physicalSecurities * 0.0001 * 4.5
        val loanCs01 = state.physicalLoans * 0.0001 * 2.8
        val cdsCs01 = state.cdsNotional * 0.0001 * 3.5
        val netCs01 = (bondCs01 + loanCs01 + cdsCs01) * 1000.0 // in $k

        // Parametric VaR (99%, 10-day) using correlated asset factors
        val basePortfolioVol = 0.038
        val var99 = (state.physicalLoans + state.physicalSecurities + state.trsNotional) * basePortfolioVol * 2.33 * sqrt(10.0 / 252.0)
        val es99 = var99 * 1.28 // Expected Shortfall (CVaR)

        val largestCounterparty = state.counterparties.maxOfOrNull { it.netExposure } ?: 4800.0

        val synthReport = computeSyntheticBalanceSheet(state)
        val stressLeverage = synthReport.syntheticLeverage * 1.36

        return RiskMetricsReport(
            dv01Thousands = netDv01,
            cs01Thousands = netCs01,
            var99Percent10d = var99,
            expectedShortfall = es99,
            largestCounterpartyExp = largestCounterparty,
            stressLeverage = stressLeverage
        )
    }

    fun computeBankEconomics(state: SyntheticBankState): BankEconomicsReport {
        val loanYield = state.physicalLoans * 0.058
        val securitiesYield = state.physicalSecurities * 0.046
        val hqlaYield = state.cashAndHqla * 0.042
        val interestIncome = loanYield + securitiesYield + hqlaYield

        val depositCost = state.customerDeposits * 0.031
        val wholesaleCost = state.wholesaleFunding * 0.052
        val repoCost = state.repoFunding * 0.048
        val interestExpense = depositCost + wholesaleCost + repoCost
        val netInterestIncome = interestIncome - interestExpense

        val feeIncome = 420.0
        val tradingPnl = 840.0 + (state.trsNotional * 0.02)
        val totalRevenue = netInterestIncome + feeIncome + tradingPnl

        val creditEl = (state.physicalLoans * 0.0042) + (state.cdsNotional * 0.0025)
        val liquidityCost = state.cashAndHqla * 0.008
        val operatingCost = 850.0

        val accountingProfit = totalRevenue - interestExpense - operatingCost - creditEl
        val capitalCharge = (state.cet1Capital + state.at1Capital) * 0.10 // 10% hurdle rate
        val economicProfit = accountingProfit - capitalCharge - liquidityCost

        val equity = state.cet1Capital + state.at1Capital
        val roe = if (equity > 0) (accountingProfit / equity) * 100.0 else 0.0
        val ec = computeCapitalAdequacy(state).totalRwa * 0.10
        val raroc = if (ec > 0) ((accountingProfit - creditEl) / ec) * 100.0 else 0.0

        return BankEconomicsReport(
            netInterestIncome = netInterestIncome,
            netFeeIncome = feeIncome,
            tradingPnl = tradingPnl,
            totalRevenue = totalRevenue,
            fundingCosts = interestExpense,
            creditExpectedLoss = creditEl,
            liquidityCarryCost = liquidityCost,
            operatingCost = operatingCost,
            accountingProfit = accountingProfit,
            economicProfit = economicProfit,
            roePct = roe,
            rarocPct = raroc
        )
    }

    fun computeBankDna(state: SyntheticBankState): BankDna {
        val totalAssets = state.physicalLoans + state.physicalSecurities + state.cashAndHqla +
                state.derivativeAssetsMtM + state.trsNotional
        val creditPct = ((state.physicalLoans * 0.70 + state.cdsNotional * 0.3) / totalAssets) * 100.0
        val ratesPct = ((state.physicalSecurities * 0.60 + state.irsNotional * 0.15) / totalAssets) * 100.0
        val equityPct = ((state.trsNotional * 0.8) / totalAssets) * 100.0
        val realEstatePct = 8.5
        val infraPct = 6.0
        val hqlaPct = (state.cashAndHqla / totalAssets) * 100.0

        val totalFunding = state.customerDeposits + state.wholesaleFunding + state.repoFunding + state.cet1Capital
        val depPct = (state.customerDeposits / totalFunding) * 100.0
        val repoPct = (state.repoFunding / totalFunding) * 100.0
        val wholesalePct = (state.wholesaleFunding / totalFunding) * 100.0
        val capPct = (state.cet1Capital / totalFunding) * 100.0

        val synth = computeSyntheticBalanceSheet(state)

        return BankDna(
            assetExposures = mapOf(
                "Credit" to creditPct,
                "Rates" to ratesPct,
                "Equity TRS" to equityPct,
                "Real Estate" to realEstatePct,
                "Infrastructure" to infraPct,
                "Liquidity/HQLA" to hqlaPct
            ),
            fundingMix = mapOf(
                "Deposits" to depPct,
                "Repo" to repoPct,
                "Wholesale Debt" to wholesalePct,
                "Capital" to capPct
            ),
            durationYears = 1.82,
            creditBeta = 1.14,
            syntheticMultiplier = synth.syntheticLeverage / 12.0
        )
    }

    fun runStressScenario(state: SyntheticBankState, scenario: StressScenario): StressSimulationResult {
        // 1. Asset MtM loss from equity and credit spreads
        val eqLoss = state.trsNotional * (scenario.equityShockPct / 100.0) * -1.0
        val csLoss = (state.physicalSecurities + state.physicalLoans + state.cdsNotional) * (scenario.creditSpreadShockBps / 10000.0) * 3.5
        val ratesLoss = (state.physicalSecurities * 0.0001 * 5.5 + state.irsNotional * 0.0001 * state.irsDurationYears) * scenario.ratesShockBps * 10.0

        val totalAssetLoss = eqLoss + csLoss + ratesLoss

        // 2. Liquidity outflows & margin calls
        val depositLoss = state.customerDeposits * (scenario.depositOutflowPct / 100.0)
        val repoHaircutLoss = state.repoFunding * (scenario.repoHaircutIncreasePct / 100.0)
        val marginCalls = state.derivativeLiabilitiesMtM * (scenario.marginShockPct / 100.0)
        val totalLiqShock = depositLoss + repoHaircutLoss + marginCalls

        // Capital impact
        val postCet1 = max(0.0, state.cet1Capital - totalAssetLoss * 0.8)
        val rwa = computeCapitalAdequacy(state).totalRwa * 1.15 // RWA expands in stress
        val postCet1Ratio = (postCet1 / rwa) * 100.0

        val postHqla = max(0.0, state.cashAndHqla - totalLiqShock)
        val dailyStressBurn = totalLiqShock / 30.0
        val postDays = if (dailyStressBurn > 0) (postHqla / dailyStressBurn).toInt() else 0

        val solvency = when {
            postCet1Ratio < 4.5 || postHqla <= 0 -> "INSOLVENT"
            postCet1Ratio < 8.0 || postDays < 15 -> "CRITICAL_CAPITAL"
            else -> "SOLVENT"
        }

        val synth = computeSyntheticBalanceSheet(state)

        return StressSimulationResult(
            scenario = scenario,
            assetMarkToMarketLoss = totalAssetLoss,
            creditSpreadLoss = csLoss,
            ratesLoss = ratesLoss,
            depositOutflow = depositLoss,
            repoHaircutShortfall = repoHaircutLoss,
            additionalMarginCall = marginCalls,
            totalLiquidityShock = totalLiqShock,
            postStressCet1RatioPct = postCet1Ratio,
            postStressSurvivalDays = postDays,
            postStressLeverage = synth.syntheticLeverage * 1.45,
            solvencyStatus = solvency
        )
    }
}
