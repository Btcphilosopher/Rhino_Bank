package com.example.engine

import com.example.model.SyntheticBankState

sealed class TerminalCommandResult {
    data class Success(val message: String, val updatedState: SyntheticBankState? = null) : TerminalCommandResult()
    data class Error(val error: String) : TerminalCommandResult()
    data class Navigation(val targetScreen: String) : TerminalCommandResult()
}

object RqqlParser {

    fun executeCommand(rawInput: String, currentState: SyntheticBankState): TerminalCommandResult {
        val trimmed = rawInput.trim()
        if (trimmed.isEmpty()) return TerminalCommandResult.Error("EMPTY_COMMAND: Enter mnemonic or RQQL syntax (e.g. SBANK <GO>, STRESS RATES +100BP)")

        val upper = trimmed.uppercase()

        // Terminal navigation mnemonics
        if (upper.endsWith("<GO>")) {
            val code = upper.replace("<GO>", "").trim()
            return when (code) {
                "SBANK", "MAIN" -> TerminalCommandResult.Navigation("SBANK")
                "BAL" -> TerminalCommandResult.Navigation("BAL")
                "ECOBAL" -> TerminalCommandResult.Navigation("ECOBAL")
                "SYNBAL" -> TerminalCommandResult.Navigation("SYNBAL")
                "DNA" -> TerminalCommandResult.Navigation("DNA")
                "DEPOSIT" -> TerminalCommandResult.Navigation("DEPOSIT")
                "LOAN" -> TerminalCommandResult.Navigation("LOAN")
                "CREDIT" -> TerminalCommandResult.Navigation("CREDIT")
                "SRATES" -> TerminalCommandResult.Navigation("SRATES")
                "SCDO" -> TerminalCommandResult.Navigation("SCDO")
                "FUND", "REPO" -> TerminalCommandResult.Navigation("FUND")
                "COLL" -> TerminalCommandResult.Navigation("COLL")
                "LEV" -> TerminalCommandResult.Navigation("LEV")
                "CAPITAL", "RWA" -> TerminalCommandResult.Navigation("CAPITAL")
                "LIQ", "LSTRESS" -> TerminalCommandResult.Navigation("LIQ")
                "IRRBB" -> TerminalCommandResult.Navigation("IRRBB")
                "CCR", "CONC", "NETWORK" -> TerminalCommandResult.Navigation("CCR")
                "STRESS" -> TerminalCommandResult.Navigation("STRESS")
                "REPLICATE" -> TerminalCommandResult.Navigation("REPLICATE")
                "RAROC", "ECON", "P&L", "ALLOC", "OPTIMISE" -> TerminalCommandResult.Navigation("ECON")
                "AI" -> TerminalCommandResult.Navigation("AI")
                else -> TerminalCommandResult.Error("UNKNOWN_MNEMONIC: $code <GO>. Type SBANK <GO> for overview.")
            }
        }

        // Action commands (RQQL)
        val tokens = upper.split("\\s+".toRegex())
        val command = tokens[0]

        try {
            when (command) {
                "ADD" -> {
                    if (tokens.size < 3) return TerminalCommandResult.Error("SYNTAX: ADD [DEPOSITS|LOANS|UST|IRS|CDS|TRS] [AMOUNT_M]")
                    val asset = tokens[1]
                    val amountStr = tokens.last().replace("$", "").replace("M", "").replace("BN", "000")
                    val amount = amountStr.toDoubleOrNull() ?: return TerminalCommandResult.Error("INVALID_AMOUNT: $amountStr")

                    return when (asset) {
                        "DEPOSITS", "DEPOSIT" -> {
                            val next = currentState.copy(customerDeposits = currentState.customerDeposits + amount)
                            TerminalCommandResult.Success("ADDED DEPOSITS +$${amount}M. New Total: $${next.customerDeposits}M", next)
                        }
                        "LOANS", "LOAN" -> {
                            val next = currentState.copy(physicalLoans = currentState.physicalLoans + amount)
                            TerminalCommandResult.Success("ADDED PHYSICAL LOANS +$${amount}M. New Total: $${next.physicalLoans}M", next)
                        }
                        "UST", "BONDS", "SECURITIES" -> {
                            val next = currentState.copy(physicalSecurities = currentState.physicalSecurities + amount)
                            TerminalCommandResult.Success("ADDED GOV SECURITIES/UST +$${amount}M. New Total: $${next.physicalSecurities}M", next)
                        }
                        "IRS" -> {
                            val next = currentState.copy(irsNotional = currentState.irsNotional + amount)
                            TerminalCommandResult.Success("ADDED IRS NOTIONAL +$${amount}M. Total Gross IRS: $${next.irsNotional}M", next)
                        }
                        "CDS" -> {
                            val next = currentState.copy(cdsNotional = currentState.cdsNotional + amount)
                            TerminalCommandResult.Success("ADDED CDS NOTIONAL +$${amount}M. Total Gross CDS: $${next.cdsNotional}M", next)
                        }
                        "TRS" -> {
                            val next = currentState.copy(trsNotional = currentState.trsNotional + amount)
                            TerminalCommandResult.Success("ADDED TRS NOTIONAL +$${amount}M. Total Gross TRS: $${next.trsNotional}M", next)
                        }
                        else -> TerminalCommandResult.Error("UNSUPPORTED_ASSET: $asset. Options: DEPOSITS, LOANS, UST, IRS, CDS, TRS")
                    }
                }

                "FUND" -> {
                    if (tokens.size < 3) return TerminalCommandResult.Error("SYNTAX: FUND [REPO|WHOLESALE] [AMOUNT_M]")
                    val type = tokens[1]
                    val amountStr = tokens.last().replace("$", "").replace("M", "").replace("BN", "000")
                    val amount = amountStr.toDoubleOrNull() ?: return TerminalCommandResult.Error("INVALID_AMOUNT: $amountStr")

                    return when (type) {
                        "REPO" -> {
                            val next = currentState.copy(repoFunding = currentState.repoFunding + amount)
                            TerminalCommandResult.Success("FUNDED VIA REPO +$${amount}M. Total Repo: $${next.repoFunding}M", next)
                        }
                        "WHOLESALE" -> {
                            val next = currentState.copy(wholesaleFunding = currentState.wholesaleFunding + amount)
                            TerminalCommandResult.Success("FUNDED VIA WHOLESALE +$${amount}M. Total Wholesale: $${next.wholesaleFunding}M", next)
                        }
                        else -> TerminalCommandResult.Error("UNSUPPORTED_FUNDING: $type. Options: REPO, WHOLESALE")
                    }
                }

                "HEDGE" -> {
                    // e.g. HEDGE DURATION -2Y
                    if (tokens.contains("DURATION")) {
                        val years = tokens.last().replace("Y", "").toDoubleOrNull() ?: -2.0
                        val next = currentState.copy(irsDurationYears = years)
                        return TerminalCommandResult.Success("UPDATED SWAP OVERLAY NET DURATION TO ${years}Y", next)
                    }
                    return TerminalCommandResult.Error("SYNTAX: HEDGE DURATION [-2Y]")
                }

                "STRESS" -> {
                    return TerminalCommandResult.Navigation("STRESS")
                }

                "SHOW" -> {
                    val target = tokens.getOrNull(1) ?: "SBANK"
                    return when (target) {
                        "ECOBAL" -> TerminalCommandResult.Navigation("ECOBAL")
                        "SYNBAL" -> TerminalCommandResult.Navigation("SYNBAL")
                        "DNA" -> TerminalCommandResult.Navigation("DNA")
                        "LEVERAGE" -> TerminalCommandResult.Navigation("LEV")
                        "LIQUIDITY" -> TerminalCommandResult.Navigation("LIQ")
                        "COUNTERPARTY" -> TerminalCommandResult.Navigation("CCR")
                        "CAPITAL" -> TerminalCommandResult.Navigation("CAPITAL")
                        else -> TerminalCommandResult.Navigation("SBANK")
                    }
                }

                "OPTIMISE", "OPTIMIZE" -> {
                    return TerminalCommandResult.Navigation("ECON")
                }

                "REPLICATE" -> {
                    return TerminalCommandResult.Navigation("REPLICATE")
                }

                "RESET" -> {
                    return TerminalCommandResult.Success("BANK STATE RESET TO BASELINE BENCHMARK", SyntheticBankState())
                }

                else -> {
                    return TerminalCommandResult.Error("UNKNOWN_COMMAND: '$command'. Type SBANK <GO> or help.")
                }
            }
            return TerminalCommandResult.Error("COMMAND_UNRESOLVED")
        } catch (e: Exception) {
            return TerminalCommandResult.Error("COMMAND_EXECUTION_FAILURE: ${e.message}")
        }
    }
}
