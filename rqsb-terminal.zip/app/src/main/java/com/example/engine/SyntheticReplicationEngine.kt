package com.example.engine

import com.example.model.*

object SyntheticReplicationEngine {

    data class ReplicationSolution(
        val targetName: String,
        val targetAmount: Double,
        val buildingBlocks: List<String>,
        val replicationErrorBps: Double,
        val annualCostSavingsBps: Double,
        val capitalReliefPct: Double,
        val syntheticLeverageIncrease: Double,
        val liquidityImpact: String,
        val notes: String
    )

    fun replicateCorporateLoan(amount: Double = 500.0): ReplicationSolution {
        return ReplicationSolution(
            targetName = "Physical Corporate IG Loan (\$${amount.toInt()}M)",
            targetAmount = amount,
            buildingBlocks = listOf(
                "Buy Liquid US Treasury (\$${amount.toInt()}M)",
                "Sell Protection via CDS IG Basket (\$${amount.toInt()}M)",
                "Fund via 3M Repo (\$${(amount * 0.95).toInt()}M @ SOFR + 15bps)",
                "Payer IRS SOFR hedge to match loan spread curve"
            ),
            replicationErrorBps = 3.5,
            annualCostSavingsBps = 48.0,
            capitalReliefPct = 35.0, // Risk-weight reduced from 100% to 35% on funded synthetic credit
            syntheticLeverageIncrease = 1.8,
            liquidityImpact = "LCR Neutral (HQLA retained in repo collateral)",
            notes = "Synthetic loan reproduces credit spread + floating benchmark without physical origination and legal servicing friction."
        )
    }

    fun replicateFixedRateMortgage(amount: Double = 1000.0): ReplicationSolution {
        return ReplicationSolution(
            targetName = "30Y Fixed Residential Mortgage Book (\$${amount.toInt()}M)",
            targetAmount = amount,
            buildingBlocks = listOf(
                "Originate Floating-rate Mortgage (\$${amount.toInt()}M)",
                "Receiver Interest Rate Swap 10Y/30Y benchmark (\$${(amount * 0.85).toInt()}M)",
                "Purchase Prepayment Swaption Collar (Delta hedge prepayment optionality)",
                "Deposit Hedge via Stable Retail Tranche"
            ),
            replicationErrorBps = 7.2,
            annualCostSavingsBps = 32.0,
            capitalReliefPct = 20.0,
            syntheticLeverageIncrease = 1.2,
            liquidityImpact = "Superior (Swaps are CCP cleared, high liquidity vs whole-loan)",
            notes = "Eliminates negative convexity of fixed mortgage using swaption collar while capturing NII spread."
        )
    }

    fun replicateDepositLiability(amount: Double = 1000.0): ReplicationSolution {
        return ReplicationSolution(
            targetName = "Fixed-Term High-Yield Deposit (\$${amount.toInt()}M)",
            targetAmount = amount,
            buildingBlocks = listOf(
                "Short 3M SOFR Futures / Overnight Index Swap (\$${amount.toInt()}M)",
                "Tri-party Reverse Repo against OTR Treasuries (\$${(amount * 0.98).toInt()}M)",
                "Synthetic Liquidity Call Option (Contingent liquidity backstop)"
            ),
            replicationErrorBps = 2.1,
            annualCostSavingsBps = 25.0,
            capitalReliefPct = 12.0,
            syntheticLeverageIncrease = 1.05,
            liquidityImpact = "Immediate intraday liquidity (unencumbered collateral)",
            notes = "Replicates deposit liability cash flows without deposit insurance assessments (FDIC fees) or branch operating drag."
        )
    }
}
