package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.FinancialEngines
import com.example.model.SyntheticBankState
import com.example.ui.components.MetricCell
import com.example.ui.components.SectionHeader
import com.example.ui.components.TerminalTableRow
import com.example.ui.theme.*

@Composable
fun BankDnaScreen(
    state: SyntheticBankState,
    modifier: Modifier = Modifier
) {
    val dna = FinancialEngines.computeBankDna(state)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Text(
                text = "SYNTHETIC BANK ECONOMIC FINGERPRINT (DNA)",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = TerminalGold,
                    fontSize = 12.sp
                )
            )
            Text(
                text = "Identifies the bank by its economic essence rather than its legal accounting facade.",
                style = MaterialTheme.typography.bodySmall.copy(
                    fontFamily = FontFamily.Monospace,
                    color = TerminalSteel,
                    fontSize = 10.sp
                )
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                MetricCell(
                    label = "Net Duration",
                    value = "${dna.durationYears} Years",
                    subValue = "Rate Sensitivity",
                    valueColor = TerminalBlue,
                    modifier = Modifier.weight(1f)
                )
                MetricCell(
                    label = "Credit Beta",
                    value = "${dna.creditBeta}x",
                    subValue = "IG/HY Sensitivity",
                    valueColor = TerminalAmber,
                    modifier = Modifier.weight(1f)
                )
                MetricCell(
                    label = "Synth Multiplier",
                    value = "${String.format("%.2fx", dna.syntheticMultiplier)}",
                    subValue = "Derivative Gearing",
                    valueColor = TerminalPurple,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Asset Exposure DNA
        item {
            SectionHeader(title = "Asset Exposure DNA Distribution", code = "ASSETS")
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, TerminalBorder)
            ) {
                TerminalTableRow("ECONOMIC EXPOSURE CLASS", "PROPORTION", "BAR VISUALISATION", isHeader = true)
                dna.assetExposures.forEach { (assetClass, pct) ->
                    val bars = "█".repeat((pct / 5).toInt().coerceIn(1, 15))
                    TerminalTableRow(assetClass, String.format("%.1f%%", pct), bars, textColor = TerminalGold)
                }
            }
        }

        // Funding DNA
        item {
            SectionHeader(title = "Funding DNA Composition", code = "FUNDING")
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, TerminalBorder)
            ) {
                TerminalTableRow("LIABILITY & CAPITAL SOURCE", "PROPORTION", "BAR VISUALISATION", isHeader = true)
                dna.fundingMix.forEach { (fundingSource, pct) ->
                    val bars = "█".repeat((pct / 5).toInt().coerceIn(1, 15))
                    TerminalTableRow(fundingSource, String.format("%.1f%%", pct), bars, textColor = TerminalBlue)
                }
            }
        }

        // Qualitative Classification
        item {
            SectionHeader(title = "Synthetic Taxonomy Diagnosis", code = "DIAGNOSIS")
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface)
                    .border(1.dp, TerminalBorder)
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "• Primary Archetype: CREDIT-INTERMEDIATED SYNTHETIC ARBITRAGE BANK",
                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, color = TerminalGreen, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                )
                Text(
                    text = "• 67% of credit exposure is funded via stable retail deposits, with 33% levered via wholesale repo.",
                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, color = TerminalWhite, fontSize = 10.sp)
                )
                Text(
                    text = "• Duration mismatch is effectively hedged via receiver OIS swaps and payer swaptions.",
                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, color = TerminalSteel, fontSize = 10.sp)
                )
            }
        }
    }
}
