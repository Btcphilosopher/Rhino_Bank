package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.AiCopilotEngine
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*

@Composable
fun AiCopilotScreen(
    queryInput: String,
    onQueryChange: (String) -> Unit,
    onSubmitQuery: (String) -> Unit,
    response: AiCopilotEngine.AiResponse?,
    modifier: Modifier = Modifier
) {
    val presetQuestions = listOf(
        "What is our synthetic leverage?",
        "What happens if credit spreads widen 200bp?",
        "What happens if deposits fall 30%?",
        "Why did economic profit fall?",
        "What is our largest counterparty?"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Text(
                text = "AI SYNTHETIC BANK COPILOT & QUANTITATIVE REASONING [AI <GO>]",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = TerminalGold,
                    fontSize = 12.sp
                )
            )
            Text(
                text = "Direct algorithmic reasoning hooked directly into the RQSB quantitative balance sheet engine.",
                style = MaterialTheme.typography.bodySmall.copy(
                    fontFamily = FontFamily.Monospace,
                    color = TerminalSteel,
                    fontSize = 10.sp
                )
            )
        }

        // Query Input Field & Button
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface)
                    .border(1.dp, TerminalBorder)
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OutlinedTextField(
                    value = queryInput,
                    onValueChange = onQueryChange,
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Query Quantitative Engines...", color = TerminalSteel, fontFamily = FontFamily.Monospace, fontSize = 11.sp) },
                    textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace, color = TerminalWhite, fontSize = 12.sp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = TerminalGold,
                        unfocusedBorderColor = TerminalBorder,
                        focusedContainerColor = TerminalSurfaceVariant,
                        unfocusedContainerColor = TerminalSurfaceVariant
                    ),
                    singleLine = true
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Button(
                        onClick = { onSubmitQuery(queryInput) },
                        colors = ButtonDefaults.buttonColors(containerColor = TerminalGold),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text("EXECUTE QUERY", color = Color.Black, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                    }
                }
            }
        }

        // Preset Query Buttons
        item {
            SectionHeader(title = "Benchmark Quantitative Inquiries", code = "PRESETS")
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                presetQuestions.forEach { preset ->
                    Button(
                        onClick = {
                            onQueryChange(preset)
                            onSubmitQuery(preset)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = TerminalSurfaceVariant),
                        shape = RoundedCornerShape(2.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "> $preset",
                            modifier = Modifier.fillMaxWidth(),
                            style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, color = TerminalBlue, fontSize = 10.sp)
                        )
                    }
                }
            }
        }

        // Response Display
        if (response != null) {
            item {
                SectionHeader(title = "Quantitative Diagnosis & Proof", code = "RESULT")
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(TerminalSurface)
                        .border(1.dp, TerminalBorder)
                        .padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = response.summary,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = TerminalGold,
                            fontSize = 11.sp
                        )
                    )

                    HorizontalDivider(color = TerminalBorder, modifier = Modifier.padding(vertical = 4.dp))

                    Text(
                        text = "UNDERLYING ENGINE FORMULAS & NUMERICAL REFERENCES:",
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, color = TerminalSteel, fontSize = 9.sp)
                    )

                    response.calculations.forEach { (metric, value) ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(metric, style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, color = TerminalSteel, fontSize = 10.sp))
                            Text(value, style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, color = TerminalWhite, fontWeight = FontWeight.Bold, fontSize = 10.sp))
                        }
                    }

                    HorizontalDivider(color = TerminalBorder, modifier = Modifier.padding(vertical = 4.dp))

                    Text(
                        text = "PORTFOLIO & CAPITAL ACTIONS:",
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, color = TerminalSteel, fontSize = 9.sp)
                    )

                    response.recommendations.forEach { rec ->
                        Text("• $rec", style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, color = TerminalGreen, fontSize = 10.sp))
                    }
                }
            }
        }
    }
}
