package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val TerminalColorScheme = darkColorScheme(
    primary = TerminalGold,
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF272115),
    onPrimaryContainer = TerminalGold,
    secondary = TerminalBlue,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF0C2438),
    onSecondaryContainer = TerminalBlue,
    tertiary = TerminalPurple,
    background = TerminalBackground,
    onBackground = TerminalWhite,
    surface = TerminalSurface,
    onSurface = TerminalWhite,
    surfaceVariant = TerminalSurfaceVariant,
    onSurfaceVariant = TerminalSteel,
    outline = TerminalBorder,
    error = TerminalRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = TerminalColorScheme,
        typography = Typography,
        content = content
    )
}
