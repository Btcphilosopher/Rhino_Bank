package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.FinancialEngines
import com.example.model.SyntheticBankState
import com.example.ui.components.MetricCell
import com.example.ui.components.SectionHeader
import com.example.ui.components.TerminalTableRow
import com.example.ui.theme.*

@Composable
fun MainTerminalScreen(
    state: SyntheticBankState,
    onNavigate: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val legal = FinancialEngines.computeLegalBalanceSheet(state)
    val eco = FinancialEngines.computeEconomicBalanceSheet(state)
    val synth = FinancialEngines.computeSyntheticBalanceSheet(state)
    val cap = FinancialEngines.computeCapitalAdequacy(state)
    val liq = FinancialEngines.computeLiquidity(state)
    val risk = FinancialEngines.computeRiskMetrics(state)
    val econ = FinancialEngines.computeBankEconomics(state)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Quick Screen Nav Bar
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurfaceVariant)
                    .border(1.dp, TerminalBorder)
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                listOf(
                    "BAL" to "BAL",
                    "ECOBAL" to "ECOBAL",
                    "SYNBAL" to "SYNBAL",
                    "DNA" to "DNA",
                    "DEPOSIT" to "DEPOSIT",
                    "SCDO" to "SCDO",
                    "SRATES" to "SRATES",
                    "STRESS" to "STRESS",
                    "REPLICATE" to "REPLICATE",
                    "AI" to "AI"
                ).forEach { (label, scr) ->
                    Box(
                        modifier = Modifier
                            .background(TerminalSurface, RoundedCornerShape(2.dp))
                            .border(1.dp, TerminalBorder, RoundedCornerShape(2.dp))
                            .clickable { onNavigate(scr) }
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.sp,
                                color = TerminalGold,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            }
        }

        // Summary Headline Strip
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                MetricCell(
                    label = "CET1 Ratio",
                    value = String.format("%.1f%%", cap.cet1RatioPct),
                    subValue = "Min: 7.0%",
                    valueColor = if (cap.cet1RatioPct > 10.5) TerminalGreen else TerminalAmber,
                    modifier = Modifier.weight(1f)
                )
                MetricCell(
                    label = "LCR",
                    value = String.format("%.0f%%", liq.lcrPct),
                    subValue = "Min: 100%",
                    valueColor = if (liq.lcrPct >= 100) TerminalGreen else TerminalRed,
                    modifier = Modifier.weight(1f)
                )
                MetricCell(
                    label = "RAROC",
                    value = String.format("%.1f%%", econ.rarocPct),
                    subValue = "Hurdle: 12%",
                    valueColor = TerminalGold,
                    modifier = Modifier.weight(1f)
                )
                MetricCell(
                    label = "Synth Lev",
                    value = String.format("%.1fx", synth.syntheticLeverage),
                    subValue = "Acct: ${String.format("%.1fx", legal.accountingLeverage)}",
                    valueColor = TerminalPurple,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Balance Sheet Overview
        item {
            SectionHeader(title = "Accounting Balance Sheet", code = "BAL <GO>")
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, TerminalBorder)
            ) {
                TerminalTableRow("ITEM", "AMOUNT (\$M)", "SHARE", isHeader = true)
                TerminalTableRow("Physical Loans", "$${state.physicalLoans.toInt()}M", "${String.format("%.1f%%", (state.physicalLoans / legal.totalAssets) * 100)}")
                TerminalTableRow("Liquid Securities / Gov Bonds", "$${state.physicalSecurities.toInt()}M", "${String.format("%.1f%%", (state.physicalSecurities / legal.totalAssets) * 100)}")
                TerminalTableRow("Cash & Unencumbered HQLA", "$${state.cashAndHqla.toInt()}M", "${String.format("%.1f%%", (state.cashAndHqla / legal.totalAssets) * 100)}")
                TerminalTableRow("Derivative MtM Assets", "$${state.derivativeAssetsMtM.toInt()}M", "${String.format("%.1f%%", (state.derivativeAssetsMtM / legal.totalAssets) * 100)}")
                TerminalTableRow("TOTAL ASSETS", "$${legal.totalAssets.toInt()}M", "100.0%", textColor = TerminalGold)
                HorizontalDivider(color = TerminalBorder, thickness = 1.dp)
                TerminalTableRow("Customer Deposits", "$${state.customerDeposits.toInt()}M", "${String.format("%.1f%%", (state.customerDeposits / legal.totalLiabilities) * 100)}")
                TerminalTableRow("Wholesale & Interbank Debt", "$${state.wholesaleFunding.toInt()}M", "${String.format("%.1f%%", (state.wholesaleFunding / legal.totalLiabilities) * 100)}")
                TerminalTableRow("Repo Collateralised Funding", "$${state.repoFunding.toInt()}M", "${String.format("%.1f%%", (state.repoFunding / legal.totalLiabilities) * 100)}")
                TerminalTableRow("TOTAL LIABILITIES", "$${legal.totalLiabilities.toInt()}M", "100.0%", textColor = TerminalSteel)
                HorizontalDivider(color = TerminalBorder, thickness = 1.dp)
                TerminalTableRow("Total Capital (CET1 + AT1 + T2)", "$${legal.totalEquity.toInt()}M", "CET1: $${state.cet1Capital.toInt()}M", textColor = TerminalGreen)
            }
        }

        // Economic & Synthetic Overlay
        item {
            SectionHeader(title = "Economic & Synthetic Balance Sheet", code = "ECOBAL / SYNBAL")
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, TerminalBorder)
            ) {
                TerminalTableRow("METRIC", "CONVENTIONAL", "SYNTHETIC", isHeader = true)
                TerminalTableRow("Total Gross Exposure", "$${legal.totalAssets.toInt()}M", "$${synth.syntheticExposureAssets.toInt()}M", textColor = TerminalBlue)
                TerminalTableRow("Balance Sheet Leverage", "${String.format("%.1fx", legal.accountingLeverage)}", "${String.format("%.1fx", synth.syntheticLeverage)}", textColor = TerminalAmber)
                TerminalTableRow("IRS Interest Rate Swaps", "--", "$${state.irsNotional.toInt()}M Notional", textColor = TerminalWhite)
                TerminalTableRow("CDS / Synthetic Credit", "--", "$${state.cdsNotional.toInt()}M Notional", textColor = TerminalWhite)
                TerminalTableRow("TRS Equity Synthetic", "--", "$${state.trsNotional.toInt()}M Notional", textColor = TerminalWhite)
                TerminalTableRow("Contingent Guarantees & Lines", "--", "$${state.contingentCommitments.toInt()}M Draw", textColor = TerminalWhite)
            }
        }

        // Quantitative Risk & Sensitivity
        item {
            SectionHeader(title = "Quantitative Risk & Sensitivity", code = "RISK <GO>")
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                MetricCell(
                    label = "Net DV01",
                    value = "$${String.format("%.2f", risk.dv01Thousands)}k",
                    subValue = "Per 1bp Rate Move",
                    valueColor = TerminalBlue,
                    modifier = Modifier.weight(1f)
                )
                MetricCell(
                    label = "Net CS01",
                    value = "$${String.format("%.2f", risk.cs01Thousands)}k",
                    subValue = "Per 1bp Spread Move",
                    valueColor = TerminalAmber,
                    modifier = Modifier.weight(1f)
                )
                MetricCell(
                    label = "Parametric VaR 99%",
                    value = "$${risk.var99Percent10d.toInt()}M",
                    subValue = "10-Day Horizon",
                    valueColor = TerminalRed,
                    modifier = Modifier.weight(1f)
                )
                MetricCell(
                    label = "Expected Shortfall",
                    value = "$${risk.expectedShortfall.toInt()}M",
                    subValue = "Tail CVaR (99%)",
                    valueColor = TerminalRed,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Liquidity & Stress Horizon
        item {
            SectionHeader(title = "Liquidity & Stress Horizon", code = "LIQ <GO>")
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                MetricCell(
                    label = "Survival Horizon",
                    value = "${liq.survivalHorizonDays} Days",
                    subValue = "Under Outflow Stress",
                    valueColor = if (liq.survivalHorizonDays > 30) TerminalGreen else TerminalRed,
                    modifier = Modifier.weight(1f)
                )
                MetricCell(
                    label = "30D Net Stress Gap",
                    value = "$${liq.net30dStressGap.toInt()}M",
                    subValue = "Outflow vs Inflow",
                    valueColor = TerminalAmber,
                    modifier = Modifier.weight(1f)
                )
                MetricCell(
                    label = "NSFR Ratio",
                    value = "${String.format("%.1f%%", liq.nsfrPct)}",
                    subValue = "Min: 100%",
                    valueColor = if (liq.nsfrPct >= 100) TerminalGreen else TerminalRed,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}
