package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.SyntheticReplicationEngine
import com.example.ui.components.MetricCell
import com.example.ui.components.SectionHeader
import com.example.ui.components.TerminalTableRow
import com.example.ui.theme.*

@Composable
fun SyntheticReplicationScreen(
    modifier: Modifier = Modifier
) {
    val solCorpLoan = SyntheticReplicationEngine.replicateCorporateLoan(500.0)
    val solMortgage = SyntheticReplicationEngine.replicateFixedRateMortgage(1000.0)
    val solDeposit = SyntheticReplicationEngine.replicateDepositLiability(1000.0)

    val solutions = listOf(solCorpLoan, solMortgage, solDeposit)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Text(
                text = "SYNTHETIC ASSET & LIABILITY REPLICATION ENGINE [REPLICATE <GO>]",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = TerminalGold,
                    fontSize = 12.sp
                )
            )
            Text(
                text = "Reproducing banking assets & liabilities using liquid derivatives, repo, and contingent building blocks.",
                style = MaterialTheme.typography.bodySmall.copy(
                    fontFamily = FontFamily.Monospace,
                    color = TerminalSteel,
                    fontSize = 10.sp
                )
            )
        }

        solutions.forEach { sol ->
            item {
                SectionHeader(title = sol.targetName, code = "REPLICATED")
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(TerminalSurface)
                        .border(1.dp, TerminalBorder)
                        .padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "CONSTRUCTIVE BUILDING BLOCKS:",
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, color = TerminalSteel, fontWeight = FontWeight.Bold)
                    )
                    sol.buildingBlocks.forEach { block ->
                        Text(
                            text = "  + $block",
                            style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, color = TerminalWhite, fontSize = 10.sp)
                        )
                    }

                    HorizontalDivider(color = TerminalBorder, modifier = Modifier.padding(vertical = 4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        MetricCell(
                            label = "Replication Error",
                            value = "${sol.replicationErrorBps} bps",
                            subValue = "Tracking Error",
                            valueColor = TerminalGreen,
                            modifier = Modifier.weight(1f)
                        )
                        MetricCell(
                            label = "Cost Savings",
                            value = "+${sol.annualCostSavingsBps} bps",
                            subValue = "Origination Relief",
                            valueColor = TerminalGold,
                            modifier = Modifier.weight(1f)
                        )
                        MetricCell(
                            label = "Capital Relief",
                            value = "-${sol.capitalReliefPct}%",
                            subValue = "RWA Reduction",
                            valueColor = TerminalBlue,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Text(
                        text = "Notes: ${sol.notes}",
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, color = TerminalSteel, fontSize = 9.sp)
                    )
                }
            }
        }
    }
}
