package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.FinancialEngines
import com.example.model.SyntheticBankState
import com.example.ui.components.MetricCell
import com.example.ui.components.SectionHeader
import com.example.ui.components.TerminalTableRow
import com.example.ui.theme.*

@Composable
fun BalanceSheetComparisonScreen(
    state: SyntheticBankState,
    modifier: Modifier = Modifier
) {
    val legal = FinancialEngines.computeLegalBalanceSheet(state)
    val eco = FinancialEngines.computeEconomicBalanceSheet(state)
    val synth = FinancialEngines.computeSyntheticBalanceSheet(state)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Text(
                text = "TRI-BALANCE SHEET RECONCILIATION ENGINE [BAL / ECOBAL / SYNBAL]",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = TerminalGold,
                    fontSize = 12.sp
                )
            )
            Text(
                text = "Reconciles Accounting Legal Ownership vs Economic Risk vs Engineered Synthetic Exposures",
                style = MaterialTheme.typography.bodySmall.copy(
                    fontFamily = FontFamily.Monospace,
                    color = TerminalSteel,
                    fontSize = 10.sp
                )
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                MetricCell(
                    label = "1. Legal Bal (BAL)",
                    value = "$${legal.totalAssets.toInt()}M",
                    subValue = "Lev: ${String.format("%.1fx", legal.accountingLeverage)}",
                    valueColor = TerminalWhite,
                    modifier = Modifier.weight(1f)
                )
                MetricCell(
                    label = "2. Economic (ECOBAL)",
                    value = "$${eco.grossEconomicAssets.toInt()}M",
                    subValue = "Lev: ${String.format("%.1fx", eco.economicLeverage)}",
                    valueColor = TerminalBlue,
                    modifier = Modifier.weight(1f)
                )
                MetricCell(
                    label = "3. Synthetic (SYNBAL)",
                    value = "$${synth.syntheticExposureAssets.toInt()}M",
                    subValue = "Lev: ${String.format("%.1fx", synth.syntheticLeverage)}",
                    valueColor = TerminalPurple,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            SectionHeader(title = "Comparative Line Item Mapping", code = "RECON <GO>")
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, TerminalBorder)
            ) {
                TerminalTableRow("BALANCE SHEET ELEMENT", "LEGAL (BAL)", "ECONOMIC (ECOBAL)", "SYNTHETIC (SYNBAL)", isHeader = true)
                TerminalTableRow("Physical Loans Book", "$${state.physicalLoans.toInt()}M", "$${state.physicalLoans.toInt()}M", "$${state.physicalLoans.toInt()}M")
                TerminalTableRow("Government Bonds / Securities", "$${state.physicalSecurities.toInt()}M", "$${state.physicalSecurities.toInt()}M", "$${state.physicalSecurities.toInt()}M")
                TerminalTableRow("Liquid HQLA Cash Reserves", "$${state.cashAndHqla.toInt()}M", "$${state.cashAndHqla.toInt()}M", "$${state.cashAndHqla.toInt()}M")
                TerminalTableRow("IRS Interest Rate Swaps", "$${state.derivativeAssetsMtM.toInt()}M (MtM)", "$${(state.irsNotional * 0.12).toInt()}M (Delta)", "$${(state.irsNotional * 0.18).toInt()}M (CashEq)", textColor = TerminalBlue)
                TerminalTableRow("CDS Credit Default Swaps", "--", "$${(state.cdsNotional * 0.40).toInt()}M (Delta)", "$${(state.cdsNotional * 0.85).toInt()}M (CashEq)", textColor = TerminalBlue)
                TerminalTableRow("Equity Total Return Swaps", "--", "$${(state.trsNotional * 0.95).toInt()}M (Delta)", "$${state.trsNotional.toInt()}M (Gross)", textColor = TerminalBlue)
                TerminalTableRow("Contingent Guarantees & Lines", "--", "$${(state.contingentCommitments * 0.50).toInt()}M (CCF)", "$${state.contingentCommitments.toInt()}M (Gross)", textColor = TerminalAmber)
                HorizontalDivider(color = TerminalBorder)
                TerminalTableRow("TOTAL ASSET EXPOSURE", "$${legal.totalAssets.toInt()}M", "$${eco.grossEconomicAssets.toInt()}M", "$${synth.syntheticExposureAssets.toInt()}M", textColor = TerminalGold)
                TerminalTableRow("TOTAL LIABILITIES / FUNDING", "$${legal.totalLiabilities.toInt()}M", "$${eco.grossEconomicLiabilities.toInt()}M", "$${synth.syntheticExposureLiabilities.toInt()}M", textColor = TerminalSteel)
                TerminalTableRow("LEVERAGE RATIO", "${String.format("%.1fx", legal.accountingLeverage)}", "${String.format("%.1fx", eco.economicLeverage)}", "${String.format("%.1fx", synth.syntheticLeverage)}", textColor = TerminalPurple)
            }
        }

        item {
            SectionHeader(title = "Institutional Insights", code = "INSIGHT")
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface)
                    .border(1.dp, TerminalBorder)
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "• Accounting Balance Sheet (BAL) only records net derivative fair value ($${state.derivativeAssetsMtM.toInt()}M) and omits off-balance sheet contingent commitments.",
                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, color = TerminalWhite, fontSize = 10.sp)
                )
                Text(
                    text = "• Synthetic Balance Sheet (SYNBAL) reveals true institutional footprint of $${synth.syntheticExposureAssets.toInt()}M (+${String.format("%.1f%%", ((synth.syntheticExposureAssets - legal.totalAssets) / legal.totalAssets) * 100)} over legal assets).",
                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, color = TerminalGold, fontSize = 10.sp)
                )
                Text(
                    text = "• Synthetic Leverage of ${String.format("%.1fx", synth.syntheticLeverage)} reflects unrecorded derivative multiplier effect.",
                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, color = TerminalPurple, fontSize = 10.sp)
                )
            }
        }
    }
}
