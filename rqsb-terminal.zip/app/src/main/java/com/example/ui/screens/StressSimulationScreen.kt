package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.FinancialEngines
import com.example.model.StressScenario
import com.example.model.SyntheticBankState
import com.example.ui.components.MetricCell
import com.example.ui.components.SectionHeader
import com.example.ui.components.TerminalTableRow
import com.example.ui.theme.*

@Composable
fun StressSimulationScreen(
    state: SyntheticBankState,
    selectedIndex: Int,
    onSelectScenario: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val scenarios = listOf(
        StressScenario(
            name = "GFC 2.0 Global Credit & Liquidity Freeze",
            equityShockPct = -35.0,
            creditSpreadShockBps = 350.0,
            ratesShockBps = 150.0,
            depositOutflowPct = 30.0,
            repoHaircutIncreasePct = 15.0,
            marginShockPct = 60.0
        ),
        StressScenario(
            name = "Stagflationary Rate Shock & Deposit Run",
            equityShockPct = -20.0,
            creditSpreadShockBps = 180.0,
            ratesShockBps = 250.0,
            depositOutflowPct = 25.0,
            repoHaircutIncreasePct = 8.0,
            marginShockPct = 40.0
        ),
        StressScenario(
            name = "Sovereign Debt Crisis & CDS Widening",
            equityShockPct = -15.0,
            creditSpreadShockBps = 280.0,
            ratesShockBps = 75.0,
            depositOutflowPct = 15.0,
            repoHaircutIncreasePct = 12.0,
            marginShockPct = 50.0
        )
    )

    val activeScenario = scenarios.getOrElse(selectedIndex) { scenarios[0] }
    val result = FinancialEngines.runStressScenario(state, activeScenario)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Text(
                text = "MACRO & LIQUIDITY STRESS TESTING TRANSMISSION ENGINE",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = TerminalGold,
                    fontSize = 12.sp
                )
            )
            Text(
                text = "MARKET SHOCK -> POSITION MTM -> DERIVATIVE MARGIN -> LIQUIDITY DRAIN -> CAPITAL EROSION -> SOLVENCY",
                style = MaterialTheme.typography.bodySmall.copy(
                    fontFamily = FontFamily.Monospace,
                    color = TerminalSteel,
                    fontSize = 9.sp
                )
            )
        }

        // Scenario Selector Pills
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                scenarios.forEachIndexed { idx, sc ->
                    val isSelected = idx == selectedIndex
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(if (isSelected) TerminalSurfaceVariant else TerminalSurface, RoundedCornerShape(4.dp))
                            .border(1.dp, if (isSelected) TerminalGold else TerminalBorder, RoundedCornerShape(4.dp))
                            .clickable { onSelectScenario(idx) }
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "[SCENARIO $idx] ${sc.name}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) TerminalGold else TerminalWhite
                                )
                            )
                            Text(
                                text = "Equities ${sc.equityShockPct.toInt()}% | Spreads +${sc.creditSpreadShockBps.toInt()}bp | Dep -${sc.depositOutflowPct.toInt()}%",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 9.sp,
                                    color = TerminalSteel
                                )
                            )
                        }
                    }
                }
            }
        }

        // Transmission Summary
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                MetricCell(
                    label = "Solvency Status",
                    value = result.solvencyStatus,
                    subValue = if (result.solvencyStatus == "SOLVENT") "Survives Stress" else "Action Required",
                    valueColor = when (result.solvencyStatus) {
                        "SOLVENT" -> TerminalGreen
                        "CRITICAL_CAPITAL" -> TerminalAmber
                        else -> TerminalRed
                    },
                    modifier = Modifier.weight(1f)
                )
                MetricCell(
                    label = "Post-Shock CET1",
                    value = String.format("%.1f%%", result.postStressCet1RatioPct),
                    subValue = "Min: 7.0%",
                    valueColor = if (result.postStressCet1RatioPct > 7.0) TerminalGreen else TerminalRed,
                    modifier = Modifier.weight(1f)
                )
                MetricCell(
                    label = "Post-Shock Horizon",
                    value = "${result.postStressSurvivalDays} Days",
                    subValue = "Liquidity Drain",
                    valueColor = if (result.postStressSurvivalDays >= 30) TerminalGreen else TerminalAmber,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Stress Breakdown
        item {
            SectionHeader(title = "Stress Loss Transmission Ledger", code = "TRANSMISSION")
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, TerminalBorder)
            ) {
                TerminalTableRow("TRANSMISSION VECTOR", "SHOCK MAGNITUDE", "CAPITAL / LIQUIDITY IMPACT", isHeader = true)
                TerminalTableRow("Equity TRS Loss", "${activeScenario.equityShockPct.toInt()}%", "-$${(state.trsNotional * (activeScenario.equityShockPct / 100.0) * -1.0).toInt()}M (Capital)", textColor = TerminalRed)
                TerminalTableRow("Credit Spread Widening", "+${activeScenario.creditSpreadShockBps.toInt()} bps", "-$${result.creditSpreadLoss.toInt()}M (Capital)", textColor = TerminalRed)
                TerminalTableRow("Rates / Duration Shock", "+${activeScenario.ratesShockBps.toInt()} bps", "-$${result.ratesLoss.toInt()}M (Capital)", textColor = TerminalRed)
                HorizontalDivider(color = TerminalBorder)
                TerminalTableRow("Deposit Run-Off Outflow", "-${activeScenario.depositOutflowPct.toInt()}%", "-$${result.depositOutflow.toInt()}M (Cash Outflow)", textColor = TerminalAmber)
                TerminalTableRow("Repo Haircut Expansion", "+${activeScenario.repoHaircutIncreasePct.toInt()}%", "-$${result.repoHaircutShortfall.toInt()}M (Collateral Call)", textColor = TerminalAmber)
                TerminalTableRow("Derivative Variation Margin Call", "+${activeScenario.marginShockPct.toInt()}%", "-$${result.additionalMarginCall.toInt()}M (Cash Margin)", textColor = TerminalAmber)
                HorizontalDivider(color = TerminalBorder)
                TerminalTableRow("TOTAL CAPITAL EROSION", "--", "-$${result.assetMarkToMarketLoss.toInt()}M", textColor = TerminalRed)
                TerminalTableRow("TOTAL LIQUIDITY RUN", "--", "-$${result.totalLiquidityShock.toInt()}M", textColor = TerminalAmber)
                TerminalTableRow("POST-STRESS SYNTHETIC LEV", "--", String.format("%.1fx", result.postStressLeverage), textColor = TerminalPurple)
            }
        }
    }
}
