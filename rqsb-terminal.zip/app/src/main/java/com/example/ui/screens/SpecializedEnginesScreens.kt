package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CDOTranche
import com.example.model.DepositSegment
import com.example.model.SyntheticBankState
import com.example.ui.components.MetricCell
import com.example.ui.components.SectionHeader
import com.example.ui.components.TerminalTableRow
import com.example.ui.theme.*

@Composable
fun DepositEngineScreen(
    state: SyntheticBankState,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Text(
                text = "DEPOSIT MODELLING & BEHAVIOURAL RUNOFF ENGINE [DEPOSIT <GO>]",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = TerminalGold,
                    fontSize = 12.sp
                )
            )
            Text(
                text = "Models contractual vs behavioural maturity, beta sensitivity, and stress runoff probabilities.",
                style = MaterialTheme.typography.bodySmall.copy(
                    fontFamily = FontFamily.Monospace,
                    color = TerminalSteel,
                    fontSize = 10.sp
                )
            )
        }

        item {
            SectionHeader(title = "Deposit Segments & Elasticity Profile", code = "SEGMENTS")
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, TerminalBorder)
            ) {
                TerminalTableRow("SEGMENT TYPE", "BALANCE (\$M)", "BETA", "STRESS RUNOFF", isHeader = true)
                state.deposits.forEach { dep ->
                    TerminalTableRow(
                        dep.type,
                        "$${dep.balance.toInt()}M",
                        "${dep.depositBeta}x",
                        "${dep.withdrawalProbabilityStress}%",
                        textColor = if (dep.withdrawalProbabilityStress > 30.0) TerminalRed else TerminalWhite
                    )
                }
            }
        }
    }
}

@Composable
fun SyntheticCdoScreen(
    state: SyntheticBankState,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Text(
                text = "SYNTHETIC CDO & TRANCHE STRUCTURING ENGINE [SCDO <GO>]",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = TerminalGold,
                    fontSize = 12.sp
                )
            )
            Text(
                text = "Attachment/detachment slicing of synthetic credit portfolios (Equity, Mezzanine, Senior).",
                style = MaterialTheme.typography.bodySmall.copy(
                    fontFamily = FontFamily.Monospace,
                    color = TerminalSteel,
                    fontSize = 10.sp
                )
            )
        }

        item {
            SectionHeader(title = "CDO Tranche Structure & Capital Impact", code = "TRANCHES")
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, TerminalBorder)
            ) {
                TerminalTableRow("TRANCHE", "NOTIONAL", "ATTACH/DETACH", "SPREAD", isHeader = true)
                state.cdoTranches.forEach { tr ->
                    TerminalTableRow(
                        tr.name,
                        "$${tr.notional.toInt()}M",
                        "${tr.attachmentPoint.toInt()}% - ${tr.detachmentPoint.toInt()}%",
                        "${tr.spreadBps.toInt()} bps",
                        textColor = when (tr.seniority) {
                            com.example.model.TrancheSeniority.EQUITY -> TerminalRed
                            com.example.model.TrancheSeniority.MEZZANINE -> TerminalAmber
                            else -> TerminalGreen
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun CounterpartyRiskScreen(
    state: SyntheticBankState,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Text(
                text = "COUNTERPARTY CREDIT RISK & CVA/PFE MATRIX [CCR <GO>]",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = TerminalGold,
                    fontSize = 12.sp
                )
            )
            Text(
                text = "Current Exposure, Potential Future Exposure (PFE), Netting Sets, Collateral & CVA/DVA.",
                style = MaterialTheme.typography.bodySmall.copy(
                    fontFamily = FontFamily.Monospace,
                    color = TerminalSteel,
                    fontSize = 10.sp
                )
            )
        }

        item {
            SectionHeader(title = "Top Institutional Counterparties", code = "TOP_EXPOSURES")
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, TerminalBorder)
            ) {
                TerminalTableRow("COUNTERPARTY", "RATING", "NET EXP", "COLLATERAL", isHeader = true)
                state.counterparties.forEach { cp ->
                    TerminalTableRow(
                        cp.name,
                        cp.rating,
                        "$${cp.netExposure.toInt()}M",
                        "$${cp.collateralHeld.toInt()}M",
                        textColor = TerminalWhite
                    )
                }
            }
        }
    }
}
