package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Terminal Grade Institutional Color Palette: Deep Navy, Graphite, Amber, Steel, Emerald, Crimson
val TerminalBackground = Color(0xFF090D16)      // Ultra-deep institutional navy
val TerminalSurface = Color(0xFF0F172A)         // Graphite Slate
val TerminalSurfaceVariant = Color(0xFF1E293B)  // Lighter Slate
val TerminalBorder = Color(0xFF334155)          // Fine grid border
val TerminalGold = Color(0xFFE2B04A)            // Muted Institutional Gold / Accent
val TerminalSteel = Color(0xFF94A3B8)           // Steel text / secondary
val TerminalWhite = Color(0xFFF8FAFC)           // Off-white primary text
val TerminalGreen = Color(0xFF10B981)           // Restrained Emerald for profits/positive delta
val TerminalRed = Color(0xFFF43F5E)             // Restrained Crimson for stress/loss/risk
val TerminalBlue = Color(0xFF38BDF8)            // Cyan/Muted Blue for synthetic/rates
val TerminalPurple = Color(0xFFA78BFA)          // Lavender for derivatives/tranches
val TerminalAmber = Color(0xFFF59E0B)           // Restrained Amber for warnings/leverage
