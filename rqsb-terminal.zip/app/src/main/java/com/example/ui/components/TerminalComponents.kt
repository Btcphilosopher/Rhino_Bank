package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun MetricCell(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    subValue: String? = null,
    valueColor: Color = TerminalWhite,
    isWarning: Boolean = false
) {
    Column(
        modifier = modifier
            .background(TerminalSurface, RoundedCornerShape(4.dp))
            .border(1.dp, if (isWarning) TerminalAmber else TerminalBorder, RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        Text(
            text = label.uppercase(),
            style = MaterialTheme.typography.labelSmall.copy(
                fontFamily = FontFamily.Monospace,
                fontSize = 9.sp,
                color = TerminalSteel,
                fontWeight = FontWeight.Medium
            ),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium.copy(
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = valueColor
            ),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        if (subValue != null) {
            Text(
                text = subValue,
                style = MaterialTheme.typography.bodySmall.copy(
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp,
                    color = TerminalSteel
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun SectionHeader(title: String, code: String? = null, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(TerminalSurfaceVariant)
            .border(1.dp, TerminalBorder)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title.uppercase(),
            style = MaterialTheme.typography.labelMedium.copy(
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = TerminalGold,
                fontSize = 11.sp
            )
        )
        if (code != null) {
            Text(
                text = "<$code>",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontFamily = FontFamily.Monospace,
                    color = TerminalBlue,
                    fontSize = 10.sp
                )
            )
        }
    }
}

@Composable
fun TerminalTableRow(
    col1: String,
    col2: String,
    col3: String? = null,
    col4: String? = null,
    isHeader: Boolean = false,
    textColor: Color = TerminalWhite,
    onRowClick: (() -> Unit)? = null
) {
    val bg = if (isHeader) TerminalSurfaceVariant else TerminalSurface
    val fontStyle = if (isHeader) FontWeight.Bold else FontWeight.Normal
    val baseColor = if (isHeader) TerminalSteel else textColor

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(bg)
            .then(if (onRowClick != null) Modifier.clickable { onRowClick() } else Modifier)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = col1,
            modifier = Modifier.weight(2.0f),
            style = MaterialTheme.typography.bodySmall.copy(
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                fontWeight = fontStyle,
                color = baseColor
            ),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = col2,
            modifier = Modifier.weight(1.2f),
            style = MaterialTheme.typography.bodySmall.copy(
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                fontWeight = fontStyle,
                color = baseColor,
                textAlign = TextAlign.End
            ),
            maxLines = 1
        )
        if (col3 != null) {
            Text(
                text = col3,
                modifier = Modifier.weight(1.0f),
                style = MaterialTheme.typography.bodySmall.copy(
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    fontWeight = fontStyle,
                    color = baseColor,
                    textAlign = TextAlign.End
                ),
                maxLines = 1
            )
        }
        if (col4 != null) {
            Text(
                text = col4,
                modifier = Modifier.weight(1.0f),
                style = MaterialTheme.typography.bodySmall.copy(
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    fontWeight = fontStyle,
                    color = baseColor,
                    textAlign = TextAlign.End
                ),
                maxLines = 1
            )
        }
    }
}
