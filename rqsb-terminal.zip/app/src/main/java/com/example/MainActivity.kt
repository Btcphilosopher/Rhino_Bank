package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.viewmodel.SyntheticBankViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: SyntheticBankViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()

                // Intercept back navigation
                if (uiState.currentScreen != "SBANK") {
                    BackHandler {
                        viewModel.navigateTo("SBANK")
                    }
                }

                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(TerminalBackground),
                    topBar = {
                        TerminalHeaderBar(
                            currentScreen = uiState.currentScreen,
                            onNavigate = { viewModel.navigateTo(it) }
                        )
                    },
                    bottomBar = {
                        TerminalCommandBar(
                            commandInput = uiState.commandInput,
                            onInputChange = { viewModel.onCommandInputChange(it) },
                            onSubmit = { viewModel.submitCommand() }
                        )
                    },
                    containerColor = TerminalBackground
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (uiState.currentScreen) {
                            "SBANK" -> MainTerminalScreen(
                                state = uiState.bankState,
                                onNavigate = { viewModel.navigateTo(it) }
                            )
                            "BAL", "ECOBAL", "SYNBAL", "LEV" -> BalanceSheetComparisonScreen(
                                state = uiState.bankState
                            )
                            "STRESS" -> StressSimulationScreen(
                                state = uiState.bankState,
                                selectedIndex = uiState.selectedStressScenarioIndex,
                                onSelectScenario = { viewModel.selectStressScenario(it) }
                            )
                            "DNA" -> BankDnaScreen(
                                state = uiState.bankState
                            )
                            "REPLICATE" -> SyntheticReplicationScreen()
                            "DEPOSIT" -> DepositEngineScreen(
                                state = uiState.bankState
                            )
                            "SCDO" -> SyntheticCdoScreen(
                                state = uiState.bankState
                            )
                            "CCR", "NETWORK", "CONC" -> CounterpartyRiskScreen(
                                state = uiState.bankState
                            )
                            "AI" -> AiCopilotScreen(
                                queryInput = uiState.aiQueryInput,
                                onQueryChange = { viewModel.onAiQueryInputChange(it) },
                                onSubmitQuery = { viewModel.executeAiQuery(it) },
                                response = uiState.aiResponse
                            )
                            else -> MainTerminalScreen(
                                state = uiState.bankState,
                                onNavigate = { viewModel.navigateTo(it) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TerminalHeaderBar(
    currentScreen: String,
    onNavigate: (String) -> Unit
) {
    Surface(
        color = TerminalSurface,
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .border(1.dp, TerminalBorder)
    ) {
        Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "RHINOQUANT SYNTHETIC BANK",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = TerminalGold,
                            fontSize = 11.sp
                        )
                    )
                    Text(
                        text = "RQSB / $currentScreen <GO>",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontFamily = FontFamily.Monospace,
                            color = TerminalBlue,
                            fontSize = 10.sp
                        )
                    )
                }

                Text(
                    text = "12 OCT 2026 | LONDON DESK",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = FontFamily.Monospace,
                        color = TerminalSteel,
                        fontSize = 9.sp
                    )
                )
            }
        }
    }
}

@Composable
fun TerminalCommandBar(
    commandInput: String,
    onInputChange: (String) -> Unit,
    onSubmit: () -> Unit
) {
    Surface(
        color = TerminalSurface,
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .border(1.dp, TerminalBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = "RQQL>",
                style = MaterialTheme.typography.labelMedium.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = TerminalGold,
                    fontSize = 11.sp
                )
            )

            OutlinedTextField(
                value = commandInput,
                onValueChange = onInputChange,
                modifier = Modifier
                    .weight(1f)
                    .testTag("terminal_command_input"),
                placeholder = {
                    Text(
                        "e.g. SBANK <GO>, STRESS <GO>, ADD LOANS 500M",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = TerminalSteel
                    )
                },
                textStyle = MaterialTheme.typography.bodySmall.copy(
                    fontFamily = FontFamily.Monospace,
                    color = TerminalWhite,
                    fontSize = 11.sp
                ),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = TerminalGold,
                    unfocusedBorderColor = TerminalBorder,
                    focusedContainerColor = TerminalSurfaceVariant,
                    unfocusedContainerColor = TerminalSurfaceVariant
                )
            )

            IconButton(
                onClick = onSubmit,
                modifier = Modifier
                    .size(36.dp)
                    .background(TerminalGold, RoundedCornerShape(4.dp))
                    .testTag("submit_command_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = "Execute Command",
                    tint = Color.Black,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}
