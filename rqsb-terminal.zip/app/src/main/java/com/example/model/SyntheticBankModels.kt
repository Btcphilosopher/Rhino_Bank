package com.example.model

import java.util.UUID

enum class Currency { USD, EUR, GBP, JPY, CHF }
enum class AccountingTreatment { AMORTISED_COST, FVOCI, FVTPL, OFF_BALANCE_SHEET }
enum class RiskClass { SOVEREIGN, FINANCIAL, CORPORATE_IG, CORPORATE_HY, STRUCTURED, EQUITIES, RATES, FX }
enum class AssetClass { LOAN, BOND, CDS, IRS, TRS, REPO, DEPOSIT, WHOLESALE_DEBT, EQUITY, CONTINGENT, CDO_TRANCHE }
enum class BankingBook { RETAIL, CORP, CREDIT, RATES, FX, EQUITY, COMMODITY, SECURITISATION, TREASURY, MARKETS }
enum class TrancheSeniority { EQUITY, MEZZANINE, SENIOR, SUPER_SENIOR }

data class Instrument(
    val id: String = UUID.randomUUID().toString().take(8),
    val name: String,
    val book: BankingBook,
    val assetClass: AssetClass,
    val currency: Currency = Currency.USD,
    val legalEntity: String = "RHINOQUANT_SYNTH_BANK_UK_LTD",
    val counterparty: String = "CCP_LCH",
    val notional: Double,               // in millions or billions, consistent scale ($M)
    val marketValue: Double,            // MtM ($M)
    val cashEquivalentExposure: Double, // Delta-adjusted exposure ($M)
    val interestRateOrCoupon: Double,   // %
    val maturityYears: Double,          // Years
    val duration: Double,               // Effective Duration in Years
    val dv01: Double,                   // Dollar Value of an 01 ($k)
    val cs01: Double,                   // Credit Spread 01 ($k)
    val pd: Double,                     // Annual Probability of Default (%)
    val lgd: Double = 0.45,             // Loss Given Default
    val accountingTreatment: AccountingTreatment = AccountingTreatment.FVTPL,
    val riskClass: RiskClass = RiskClass.FINANCIAL,
    val isSynthetic: Boolean = false,
    val isContingent: Boolean = false,
    val initialMarginRequired: Double = 0.0,
    val variationMargin: Double = 0.0
)

data class DepositSegment(
    val id: String,
    val type: String,                   // Retail, Corporate, Institutional, Financial
    val balance: Double,                // $M
    val interestRate: Double,           // %
    val contractualMaturityYears: Double,
    val behaviouralMaturityYears: Double,
    val withdrawalProbabilityStress: Double, // % under stress run-off
    val depositBeta: Double,            // sensitivity to policy rate
    val stabilityScore: Double          // 0 to 100
)

data class CDOTranche(
    val id: String,
    val name: String,
    val seniority: TrancheSeniority,
    val attachmentPoint: Double,        // % e.g. 0.0, 3.0, 7.0, 15.0
    val detachmentPoint: Double,        // % e.g. 3.0, 7.0, 15.0, 100.0
    val notional: Double,               // $M
    val spreadBps: Double,              // bps
    val position: String,               // "BOUGHT_PROTECTION" (Short Credit) or "SOLD_PROTECTION" (Long Credit)
    val expectedLoss: Double,           // %
    val capitalImpact: Double           // $M RWA charge
)

data class CounterpartyExposure(
    val name: String,
    val rating: String,                 // AAA, AA, A, BBB, BB
    val grossExposure: Double,          // $M
    val netExposure: Double,            // $M after netting
    val collateralHeld: Double,         // $M
    val pfe: Double,                    // Potential Future Exposure ($M)
    val cva: Double,                    // Credit Valuation Adjustment ($M)
    val dva: Double                     // Debit Valuation Adjustment ($M)
)

data class StressScenario(
    val name: String,
    val equityShockPct: Double,         // e.g. -25%
    val creditSpreadShockBps: Double,   // e.g. +200 bps
    val ratesShockBps: Double,          // e.g. +150 bps
    val depositOutflowPct: Double,      // e.g. 25%
    val repoHaircutIncreasePct: Double, // e.g. 10%
    val marginShockPct: Double          // e.g. +50%
)

data class SyntheticBankState(
    val bankName: String = "RHINOQUANT SYNTHETIC BANK",
    val mnemonic: String = "SBANK",
    val asOfDate: String = "12 OCT 2026",
    val baseCurrency: Currency = Currency.USD,
    
    // Core Balance Sheet Items ($M)
    val cashAndHqla: Double = 9620.0,
    val physicalLoans: Double = 41260.0,
    val physicalSecurities: Double = 18840.0,
    val derivativeAssetsMtM: Double = 3170.0,
    val otherAssets: Double = 4180.0,
    
    val customerDeposits: Double = 52140.0,
    val wholesaleFunding: Double = 10260.0,
    val repoFunding: Double = 4810.0,
    val derivativeLiabilitiesMtM: Double = 2970.0,
    val otherLiabilities: Double = 1680.0,
    
    // Capital ($M)
    val cet1Capital: Double = 6890.0,
    val at1Capital: Double = 1420.0,
    val tier2Capital: Double = 840.0,
    
    // Synthetic & Contingent overlay ($M notional)
    val irsNotional: Double = 45000.0,
    val irsDurationYears: Double = -2.4, // Net duration effect of swaps
    val cdsNotional: Double = 22000.0,   // Net protection sold/bought
    val trsNotional: Double = 9500.0,
    val contingentCommitments: Double = 7500.0, // Undrawn facilities & guarantees
    
    // Dynamic books and portfolios
    val instruments: List<Instrument> = emptyList(),
    val deposits: List<DepositSegment> = emptyList(),
    val cdoTranches: List<CDOTranche> = emptyList(),
    val counterparties: List<CounterpartyExposure> = emptyList()
)
