/**
 * RhinoQuant — Synthetic ETF Laboratory Core Domain Types
 */

export type Sector = 
  | 'INDUSTRIALS'
  | 'ENERGY'
  | 'TECHNOLOGY'
  | 'FINANCIALS'
  | 'HEALTHCARE'
  | 'UTILITIES'
  | 'MATERIALS'
  | 'CONSUMER'
  | 'INFRASTRUCTURE'
  | 'TRANSPORTATION';

export type Country = 'UK' | 'DE' | 'FR' | 'IT' | 'US' | 'JP' | 'SG' | 'CH' | 'CA' | 'AU';

export type WeightingMethod = 
  | 'MARKET_CAP'
  | 'EQUAL'
  | 'PRICE'
  | 'INVERSE_VOLATILITY'
  | 'RISK_PARITY'
  | 'FACTOR'
  | 'MOMENTUM'
  | 'QUALITY'
  | 'CUSTOM';

export type RebalanceFrequency = 'DAILY' | 'WEEKLY' | 'MONTHLY' | 'QUARTERLY' | 'ANNUAL' | 'EVENT_DRIVEN';

export type SimulationModel = 
  | 'GBM'
  | 'STOCHASTIC_VOL'
  | 'JUMP_DIFFUSION'
  | 'FACTOR_MODEL'
  | 'REGIME_SWITCHING'
  | 'CORRELATED_MULTI_ASSET';

export interface FactorExposures {
  market: number;
  size: number;
  value: number;
  momentum: number;
  quality: number;
  lowVol: number;
  profitability: number;
  investment: number;
}

export interface Security {
  identifier: string; // e.g. RQ-UK-001
  name: string;
  country: Country;
  currency: string;
  sector: Sector;
  industry: string;
  marketCap: number; // in USD millions
  price: number;
  volatility: number; // annualized e.g. 0.18
  beta: number; // vs broad market
  dividendYield: number; // e.g. 0.025 (2.5%)
  liquidity: number; // 30-day avg daily volume in USD
  factorExposures: FactorExposures;
  correlationGroup: string;
}

export interface UniverseRule {
  id: string;
  field: 'marketCap' | 'volatility' | 'beta' | 'dividendYield' | 'liquidity' | 'country' | 'sector';
  operator: '>' | '<' | '>=' | '<=' | 'IN' | 'NOT_IN' | 'EQUALS';
  value: number | string | string[];
}

export interface IndexConstraints {
  maxConstituentWeight: number; // e.g. 0.10 (10%)
  minConstituentWeight: number; // e.g. 0.005 (0.5%)
  sectorCaps: Record<string, number>; // sector -> max weight e.g. 0.30
  countryCaps: Record<string, number>; // country -> max weight
  turnoverLimit: number; // max per rebalance e.g. 0.20
  liquidityLimit: number; // max weight based on ADV e.g. 0.05
}

export interface IndexMethodology {
  weightingMethod: WeightingMethod;
  targetFactors?: (keyof FactorExposures)[];
  constraints: IndexConstraints;
  customFormula?: string;
}

export interface ETFDefinition {
  id: string; // e.g. RQ-IND
  ticker: string;
  name: string;
  description: string;
  baseCurrency: string;
  benchmarkId: string;
  universeId: string;
  methodology: IndexMethodology;
  rebalanceFrequency: RebalanceFrequency;
  expenseRatio: number; // annualized e.g. 0.0035 (35 bps)
  managementFee: number; // annualized e.g. 0.0015
  slippageBps: number; // transaction slippage e.g. 5 bps
  spreadBps: number; // bid-ask spread impact e.g. 4 bps
  commissionBps: number; // broker execution commission
  dividendPolicy: 'REINVEST' | 'DISTRIBUTE';
  cashTargetPct: number; // cash drag target e.g. 0.01 (1%)
  creationRedemptionFeeBps: number;
}

export interface PortfolioHolding {
  securityIdentifier: string;
  name: string;
  sector: Sector;
  country: Country;
  weight: number;
  shares: number;
  price: number;
  marketValue: number;
  volatility: number;
  beta: number;
  dividendYield: number;
  factorExposures: FactorExposures;
}

export interface NAVPoint {
  day: number;
  date: string;
  navPerShare: number;
  indexValue: number;
  benchmarkValue: number;
  cashBalance: number;
  accruedDividends: number;
  cumulativeFees: number;
  cumulativeTransactionCosts: number;
  rebalanceDrag: number;
  trackingDifferencePct: number;
  marketPrice: number;
  premiumDiscountPct: number;
}

export interface OrderBookLevel {
  price: number;
  size: number;
  ordersCount: number;
}

export interface SecondaryMarketState {
  bidPrice: number;
  askPrice: number;
  midPrice: number;
  spreadBps: number;
  lastTradedPrice: number;
  volume24h: number;
  premiumDiscountPct: number;
  bidDepth: OrderBookLevel[];
  askDepth: OrderBookLevel[];
}

export interface CreationRedemptionOrder {
  id: string;
  type: 'CREATION' | 'REDEMPTION';
  apIdentifier: string; // Authorised Participant ID e.g. AP-BARCLAYS-01
  shares: number;
  totalNavValue: number;
  cashInLieuPct: number;
  creationFee: number;
  basketComponents: { securityIdentifier: string; requiredShares: number; value: number }[];
  cashComponent: number;
  status: 'PENDING' | 'SETTLED' | 'CANCELLED';
  timestamp: string;
}

export interface RiskMetrics {
  annualizedVolatility: number;
  betaToBenchmark: number;
  trackingError: number;
  maxDrawdown: number;
  var95Historical: number;
  var99Historical: number;
  var95Parametric: number;
  var99Parametric: number;
  cvar95: number;
  sharpeRatio: number;
  sortinoRatio: number;
  informationRatio: number;
  downsideDeviation: number;
  herfindahlIndex: number;
  annualizedTurnover: number;
  liquidityScore: number; // 0 to 100
}

export interface FactorAttribution {
  market: number;
  size: number;
  value: number;
  momentum: number;
  quality: number;
  lowVol: number;
  sectorResidual: number;
  alpha: number;
}

export interface PerformanceAttribution {
  totalReturn: number;
  benchmarkReturn: number;
  excessReturn: number;
  allocationEffect: number; // Brinson sector allocation
  selectionEffect: number; // Stock selection effect
  rebalanceEffect: number;
  feeDrag: number;
  transactionCostsDrag: number;
  cashDrag: number;
  dividendDrag: number;
  unexplainedResidual: number;
}

export interface StressScenario {
  id: string;
  name: string;
  type: 'EQUITY_SHOCK' | 'RATE_SHOCK' | 'VOLATILITY_SHOCK' | 'LIQUIDITY_CRISIS' | 'CORRELATION_BREAK' | 'SECTOR_COLLAPSE' | 'GLOBAL_RISK_OFF' | 'INFLATION_SHOCK';
  description: string;
  shocks: {
    broadMarketPct: number;
    sectorShocksPct?: Record<string, number>;
    volatilityMultiplier: number;
    rateShiftBps: number;
    spreadMultiplier: number;
  };
}

export interface ScenarioResult {
  scenarioId: string;
  scenarioName: string;
  etfReturnPct: number;
  benchmarkReturnPct: number;
  navChangePct: number;
  trackingErrorPct: number;
  maxDrawdownPct: number;
  liquidityImpactBps: number;
  factorImpacts: FactorAttribution;
}

export interface MonteCarloPath {
  pathId: number;
  finalNav: number;
  maxDrawdown: number;
  annualizedReturn: number;
  volatility: number;
  timeSeries: number[]; // e.g. 252 steps
}

export interface MonteCarloResult {
  randomSeed: number;
  numPaths: number;
  timeHorizonDays: number;
  percentiles: {
    p5: number[];
    p25: number[];
    p50: number[];
    p75: number[];
    p95: number[];
  };
  finalNavStats: {
    mean: number;
    median: number;
    p5: number;
    p95: number;
    stdDev: number;
    skewness: number;
    kurtosis: number;
    var99Tail: number;
  };
  drawdownDistribution: { bin: string; count: number }[];
}

export interface ResearchProject {
  id: string; // e.g. RQ-ETF-00041
  title: string;
  version: string; // e.g. v1.0
  status: 'DRAFT' | 'PUBLISHED' | 'ARCHIVED';
  isImmutable: boolean;
  hypothesis: string;
  universeId: string;
  etfDefinition: ETFDefinition;
  simulationModel: SimulationModel;
  randomSeed: number;
  horizonDays: number;
  scenarioIds: string[];
  notes: string;
  createdAt: string;
  updatedAt: string;
  manifestHash: string;
}

export interface SimulationManifest {
  manifestId: string;
  researchId: string;
  etfTicker: string;
  datasetVersion: string;
  simulationModel: SimulationModel;
  randomSeed: number;
  parameters: {
    horizonDays: number;
    numPaths: number;
    expenseRatioBps: number;
    rebalanceFreq: string;
  };
  softwareVersion: string;
  sha256Hash: string;
  timestamp: string;
}

export interface AuditRecord {
  id: string;
  timestamp: string;
  actor: string;
  action: string;
  objectType: 'RESEARCH' | 'UNIVERSE' | 'METHODOLOGY' | 'ETF' | 'SIMULATION' | 'REBALANCE';
  objectId: string;
  details: string;
  manifestHash: string;
}

export interface EligibilityReport {
  totalInitialSecurities: number;
  passedSecuritiesCount: number;
  rejectedSecuritiesCount: number;
  appliedRules: { rule: UniverseRule; passedCount: number; failedCount: number }[];
  eligibleSecurities: Security[];
}
