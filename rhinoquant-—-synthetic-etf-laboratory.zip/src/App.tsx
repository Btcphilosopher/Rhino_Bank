import React, { useState } from 'react';
import { Header } from './components/Header';
import { Navigation, WorkspaceTab } from './components/Navigation';
import { ResearchWorkspace } from './components/ResearchWorkspace';
import { UniverseWorkspace } from './components/UniverseWorkspace';
import { ConstructorWorkspace } from './components/ConstructorWorkspace';
import { SimulationWorkspace } from './components/SimulationWorkspace';
import { PriceAndNavWorkspace } from './components/PriceAndNavWorkspace';
import { RiskWorkspace } from './components/RiskWorkspace';
import { AttributionWorkspace } from './components/AttributionWorkspace';
import { ScenarioWorkspace } from './components/ScenarioWorkspace';
import { MonteCarloWorkspace } from './components/MonteCarloWorkspace';
import { NotebookWorkspace } from './components/NotebookWorkspace';
import { ReportsWorkspace } from './components/ReportsWorkspace';
import { AuditAndCliWorkspace } from './components/AuditAndCliWorkspace';
import { RestApiWorkspace } from './components/RestApiWorkspace';

import { ResearchProject, ETFDefinition, AuditRecord } from './types';
import { INITIAL_RESEARCH_PROJECTS, INITIAL_AUDIT_LOGS, INITIAL_ETFS } from './data/mockData';
import { createSimulationManifest } from './engine/reproducibility';

export default function App() {
  const [projects, setProjects] = useState<ResearchProject[]>(INITIAL_RESEARCH_PROJECTS);
  const [activeProject, setActiveProject] = useState<ResearchProject>(INITIAL_RESEARCH_PROJECTS[0]);
  const [activeTab, setActiveTab] = useState<WorkspaceTab>('RESEARCH');
  const [auditLogs, setAuditLogs] = useState<AuditRecord[]>(INITIAL_AUDIT_LOGS);

  // Update research project
  const handleUpdateProject = (updated: ResearchProject) => {
    setActiveProject(updated);
    setProjects(projects.map(p => p.id === updated.id ? updated : p));
  };

  // Update active ETF definition
  const handleUpdateEtf = (updatedEtf: ETFDefinition) => {
    const manifest = createSimulationManifest(activeProject.id, updatedEtf.ticker, activeProject.simulationModel, activeProject.randomSeed, { horizonDays: activeProject.horizonDays });
    
    const updatedProj: ResearchProject = {
      ...activeProject,
      etfDefinition: updatedEtf,
      updatedAt: new Date().toISOString(),
      manifestHash: manifest.sha256Hash
    };

    handleUpdateProject(updatedProj);

    // Audit log
    const newLog: AuditRecord = {
      id: `AUD-${Math.floor(Math.random() * 8999 + 1000)}`,
      timestamp: new Date().toISOString(),
      actor: 'QUANT_RESEARCHER',
      action: 'RECONSTRUCT_PORTFOLIO',
      objectType: 'ETF',
      objectId: updatedEtf.id,
      details: `Reconstructed methodology: ${updatedEtf.methodology.weightingMethod}, Cap: ${((updatedEtf.methodology.constraints.maxConstituentWeight || 0) * 100).toFixed(1)}%`,
      manifestHash: manifest.sha256Hash
    };

    setAuditLogs([newLog, ...auditLogs]);
  };

  // Publish immutable version
  const handlePublishVersion = (versionTag: string) => {
    const manifest = createSimulationManifest(activeProject.id, activeProject.etfDefinition.ticker, activeProject.simulationModel, activeProject.randomSeed, { horizonDays: activeProject.horizonDays });

    const publishedProj: ResearchProject = {
      ...activeProject,
      version: versionTag,
      status: 'PUBLISHED',
      isImmutable: true,
      updatedAt: new Date().toISOString(),
      manifestHash: manifest.sha256Hash
    };

    handleUpdateProject(publishedProj);

    const newLog: AuditRecord = {
      id: `AUD-${Math.floor(Math.random() * 8999 + 1000)}`,
      timestamp: new Date().toISOString(),
      actor: 'QUANT_RESEARCHER',
      action: 'PUBLISH_RESEARCH_VERSION',
      objectType: 'RESEARCH',
      objectId: activeProject.id,
      details: `Published version ${versionTag} as immutable research object.`,
      manifestHash: manifest.sha256Hash
    };

    setAuditLogs([newLog, ...auditLogs]);
  };

  // Create new research idea
  const handleNewProject = () => {
    const newId = `RQ-ETF-${String(projects.length + 43).padStart(5, '0')}`;
    const baseEtf = INITIAL_ETFS[1]; // RQ100 base
    const manifest = createSimulationManifest(newId, baseEtf.ticker, 'GBM', 2026, { horizonDays: 252 });

    const newProj: ResearchProject = {
      id: newId,
      title: 'New Synthetic Global Equity Research Strategy',
      version: 'v1.0',
      status: 'DRAFT',
      isImmutable: false,
      hypothesis: 'Formulate new synthetic ETF hypothesis (e.g. Construct broad market float-adjusted index with factor targeting).',
      universeId: 'UNIV-GLOBAL-TOP',
      etfDefinition: baseEtf,
      simulationModel: 'GBM',
      randomSeed: 2026,
      horizonDays: 252,
      scenarioIds: ['SCEN-EQ-01', 'SCEN-RATE-01', 'SCEN-VOL-01'],
      notes: 'Draft research notes.',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      manifestHash: manifest.sha256Hash
    };

    setProjects([newProj, ...projects]);
    setActiveProject(newProj);
    setActiveTab('RESEARCH');

    const newLog: AuditRecord = {
      id: `AUD-${Math.floor(Math.random() * 8999 + 1000)}`,
      timestamp: new Date().toISOString(),
      actor: 'QUANT_RESEARCHER',
      action: 'CREATE_RESEARCH_PROJECT',
      objectType: 'RESEARCH',
      objectId: newId,
      details: `Created research hypothesis: ${newProj.title}`,
      manifestHash: manifest.sha256Hash
    };

    setAuditLogs([newLog, ...auditLogs]);
  };

  return (
    <div className="min-h-screen bg-[#090d16] text-slate-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* Terminal Top Bar */}
      <Header
        activeProject={activeProject}
        projects={projects}
        onSelectProject={(p) => setActiveProject(p)}
        onNewProject={handleNewProject}
      />

      {/* Primary Workspace Navigation Tabs */}
      <Navigation
        activeTab={activeTab}
        onTabChange={(tab) => setActiveTab(tab)}
      />

      {/* Active Workspace View */}
      <main className="flex-1 overflow-x-hidden">
        {activeTab === 'RESEARCH' && (
          <ResearchWorkspace
            project={activeProject}
            onUpdateProject={handleUpdateProject}
            onPublishVersion={handlePublishVersion}
          />
        )}

        {activeTab === 'UNIVERSE' && (
          <UniverseWorkspace />
        )}

        {activeTab === 'CONSTRUCT' && (
          <ConstructorWorkspace
            etf={activeProject.etfDefinition}
            onUpdateEtf={handleUpdateEtf}
          />
        )}

        {activeTab === 'SIMULATE' && (
          <SimulationWorkspace />
        )}

        {activeTab === 'PRICE_NAV' && (
          <PriceAndNavWorkspace
            etf={activeProject.etfDefinition}
          />
        )}

        {activeTab === 'RISK' && (
          <RiskWorkspace
            etf={activeProject.etfDefinition}
          />
        )}

        {activeTab === 'ATTRIBUTION' && (
          <AttributionWorkspace
            etf={activeProject.etfDefinition}
          />
        )}

        {activeTab === 'SCENARIOS' && (
          <ScenarioWorkspace
            etf={activeProject.etfDefinition}
          />
        )}

        {activeTab === 'MONTE_CARLO' && (
          <MonteCarloWorkspace
            etf={activeProject.etfDefinition}
          />
        )}

        {activeTab === 'NOTEBOOK' && (
          <NotebookWorkspace />
        )}

        {activeTab === 'REPORTS' && (
          <ReportsWorkspace
            project={activeProject}
          />
        )}

        {activeTab === 'AUDIT_CLI' && (
          <AuditAndCliWorkspace
            auditLogs={auditLogs}
          />
        )}

        {activeTab === 'REST_API' && (
          <RestApiWorkspace />
        )}
      </main>

      {/* Institutional Terminal Footer */}
      <footer className="border-t border-slate-800/80 bg-[#070a12] px-4 py-2 font-mono text-[10px] text-slate-500 flex flex-wrap justify-between items-center gap-2">
        <div>
          <span>RHINOQUANT SYNTHETIC ETF LABORATORY</span> • <span>RHINO BANK INSTITUTIONAL ECOSYSTEM</span>
        </div>
        <div className="flex items-center space-x-3">
          <span>PARQUET DATA ENGINE: OK</span>
          <span>FASTAPI: 0.110.0</span>
          <span>RUST NUMERICAL: ACTIVE</span>
          <span className="text-slate-400">MANIFEST: {activeProject.manifestHash.slice(0, 10)}</span>
        </div>
      </footer>
    </div>
  );
}
