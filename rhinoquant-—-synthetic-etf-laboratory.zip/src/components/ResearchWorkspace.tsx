import React, { useState } from 'react';
import { ResearchProject, ETFDefinition } from '../types';
import { ShieldCheck, GitCommit, FileCode, CheckCircle2, AlertTriangle, Layers, ArrowRight, Lock } from 'lucide-react';

interface ResearchWorkspaceProps {
  project: ResearchProject;
  onUpdateProject: (p: ResearchProject) => void;
  onPublishVersion: (versionTag: string) => void;
}

export const ResearchWorkspace: React.FC<ResearchWorkspaceProps> = ({
  project,
  onUpdateProject,
  onPublishVersion
}) => {
  const [hypothesis, setHypothesis] = useState(project.hypothesis);
  const [notes, setNotes] = useState(project.notes);
  const [versionTag, setVersionTag] = useState('v1.1');
  const [showPublishModal, setShowPublishModal] = useState(false);

  const etf = project.etfDefinition;

  return (
    <div className="p-4 space-y-4 max-w-7xl mx-auto">
      {/* Workspace Header Banner */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-xs font-mono font-bold text-blue-400 bg-blue-950/80 border border-blue-800 px-2 py-0.5 rounded">
              {project.id}
            </span>
            <h1 className="text-lg font-bold text-slate-100 font-sans">{project.title}</h1>
            <span className={`text-xs font-mono px-2 py-0.5 rounded ${
              project.isImmutable 
                ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-800' 
                : 'bg-amber-950/80 text-amber-400 border border-amber-800'
            }`}>
              {project.version} ({project.status})
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1 font-mono">
            Created: {project.createdAt.split('T')[0]} • Manifest SHA256: <span className="text-slate-300">{project.manifestHash}</span>
          </p>
        </div>

        <div className="flex items-center space-x-2">
          {!project.isImmutable && (
            <button
              onClick={() => setShowPublishModal(true)}
              className="bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs px-3 py-1.5 rounded flex items-center space-x-1 transition cursor-pointer"
            >
              <Lock className="h-3.5 w-3.5" />
              <span>PUBLISH IMMUTABLE VERSION</span>
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left Column: Research Hypothesis & Notes */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-xs font-mono font-bold uppercase text-slate-300">QUANTITATIVE HYPOTHESIS FORMULATION</span>
              {project.isImmutable && (
                <span className="text-[10px] font-mono text-emerald-400 flex items-center space-x-1">
                  <ShieldCheck className="h-3.5 w-3.5" />
                  <span>IMMUTABLE RECORD</span>
                </span>
              )}
            </div>

            <textarea
              value={hypothesis}
              disabled={project.isImmutable}
              onChange={(e) => {
                setHypothesis(e.target.value);
                onUpdateProject({ ...project, hypothesis: e.target.value });
              }}
              rows={4}
              className="w-full bg-slate-950 border border-slate-800 rounded p-3 text-xs font-mono text-slate-200 focus:border-blue-500 focus:outline-none disabled:opacity-75 disabled:cursor-not-allowed"
              placeholder="Formulate thesis (e.g. Construct a synthetic ETF representing European industrial infrastructure...)"
            />
          </div>

          {/* Research Notes & Assumptions */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-xs font-mono font-bold uppercase text-slate-300">RESEARCH NOTES & SIMULATION ASSUMPTIONS</span>
            </div>

            <textarea
              value={notes}
              disabled={project.isImmutable}
              onChange={(e) => {
                setNotes(e.target.value);
                onUpdateProject({ ...project, notes: e.target.value });
              }}
              rows={5}
              className="w-full bg-slate-950 border border-slate-800 rounded p-3 text-xs font-mono text-slate-200 focus:border-blue-500 focus:outline-none disabled:opacity-75 disabled:cursor-not-allowed"
              placeholder="Record methodological assumptions, benchmark notes, drag estimates..."
            />
          </div>

          {/* Reproducibility Manifest Box */}
          <div className="bg-slate-950 border border-slate-800 rounded-lg p-4 font-mono text-xs space-y-2">
            <div className="flex items-center justify-between text-slate-400 border-b border-slate-800 pb-2">
              <span className="font-bold text-blue-400">REPRODUCIBILITY MANIFEST</span>
              <span className="text-[10px] text-slate-500">SHA256 CHECKSUM</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-300">
              <div><span className="text-slate-500">ETF TICKER:</span> {etf.ticker}</div>
              <div><span className="text-slate-500">UNIVERSE:</span> {etf.universeId}</div>
              <div><span className="text-slate-500">WEIGHTING:</span> {etf.methodology.weightingMethod}</div>
              <div><span className="text-slate-500">REBALANCE:</span> {etf.rebalanceFrequency}</div>
              <div><span className="text-slate-500">EXPENSE RATIO:</span> {(etf.expenseRatio * 10000).toFixed(0)} bps</div>
              <div><span className="text-slate-500">RANDOM SEED:</span> {project.randomSeed}</div>
            </div>
            <div className="bg-slate-900 p-2 rounded text-[10px] text-slate-400 break-all border border-slate-800">
              Manifest Hash: {project.manifestHash}
            </div>
          </div>
        </div>

        {/* Right Column: Instrument Specification Details */}
        <div className="space-y-4">
          <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-4 space-y-3 font-mono text-xs">
            <span className="font-bold text-slate-200 uppercase block border-b border-slate-800 pb-2">SYNTHETIC ETF SPECIFICATION</span>
            
            <div className="space-y-2">
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">IDENTIFIER:</span>
                <span className="font-bold text-blue-400">{etf.id}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">NAME:</span>
                <span className="text-slate-200 font-sans text-right max-w-[180px] truncate">{etf.name}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">BASE CURRENCY:</span>
                <span className="text-slate-200">{etf.baseCurrency}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">BENCHMARK:</span>
                <span className="text-slate-200">{etf.benchmarkId}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">METHODOLOGY:</span>
                <span className="text-blue-300 font-bold">{etf.methodology.weightingMethod}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">MAX CONSTITUENT CAP:</span>
                <span className="text-slate-200">{((etf.methodology.constraints.maxConstituentWeight || 0) * 100).toFixed(1)}%</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">REBALANCE FREQUENCY:</span>
                <span className="text-slate-200">{etf.rebalanceFrequency}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">TOTAL FEE DRAG:</span>
                <span className="text-amber-400">{((etf.expenseRatio + etf.managementFee) * 10000).toFixed(0)} bps</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-400">DIVIDEND POLICY:</span>
                <span className="text-slate-200">{etf.dividendPolicy}</span>
              </div>
            </div>
          </div>

          {/* Research Version History Log */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-4 space-y-3 font-mono text-xs">
            <span className="font-bold text-slate-200 uppercase block border-b border-slate-800 pb-2">VERSION HISTORY & LINEAGE</span>
            
            <div className="space-y-2">
              <div className="p-2 bg-slate-950 border border-emerald-800/60 rounded flex items-start justify-between">
                <div>
                  <div className="font-bold text-emerald-400">v1.0 (PUBLISHED)</div>
                  <div className="text-[10px] text-slate-400">2026-10-01 • Initial baseline model</div>
                </div>
                <Lock className="h-3.5 w-3.5 text-emerald-400 mt-0.5" />
              </div>

              <div className="p-2 bg-slate-950/50 border border-slate-800 rounded flex items-start justify-between">
                <div>
                  <div className="font-bold text-slate-300">v1.1 (DRAFT)</div>
                  <div className="text-[10px] text-slate-400">Current work-in-progress</div>
                </div>
                <span className="text-[10px] text-amber-400 bg-amber-950 px-1.5 py-0.5 rounded">EDITABLE</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Publish Version Modal */}
      {showPublishModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900 border border-slate-800 rounded-lg max-w-md w-full p-5 space-y-4 font-mono text-xs">
            <div className="flex justify-between items-center border-b border-slate-800 pb-2">
              <span className="font-bold text-slate-100 uppercase text-sm">PUBLISH RESEARCH VERSION</span>
              <button onClick={() => setShowPublishModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <p className="text-slate-300">
              Publishing will lock version <strong className="text-blue-400">{versionTag}</strong> as an immutable research object. Once published, methodology parameters and hypothesis cannot be modified.
            </p>

            <div className="space-y-1">
              <label className="text-slate-400 text-[11px]">VERSION TAG:</label>
              <input
                type="text"
                value={versionTag}
                onChange={(e) => setVersionTag(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-slate-200 focus:border-blue-500 focus:outline-none"
              />
            </div>

            <div className="flex justify-end space-x-2 pt-2">
              <button
                onClick={() => setShowPublishModal(false)}
                className="px-3 py-1.5 bg-slate-800 text-slate-300 rounded hover:bg-slate-700"
              >
                CANCEL
              </button>
              <button
                onClick={() => {
                  onPublishVersion(versionTag);
                  setShowPublishModal(false);
                }}
                className="px-3 py-1.5 bg-emerald-600 text-white font-bold rounded hover:bg-emerald-500"
              >
                CONFIRM & LOCK
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
