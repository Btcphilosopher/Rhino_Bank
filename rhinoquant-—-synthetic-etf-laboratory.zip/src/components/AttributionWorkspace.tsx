import React, { useMemo } from 'react';
import { ETFDefinition, PortfolioHolding, FactorAttribution, PerformanceAttribution } from '../types';
import { SYNTHETIC_UNIVERSE } from '../engine/securitiesUniverse';
import { evaluateEligibility, calculateRawWeights, applyConstraintsAndNormalize } from '../engine/indexEngine';
import { calculateFactorAttribution, calculatePerformanceAttribution } from '../engine/attributionEngine';
import { BarChart, Layers, ArrowUpRight, ArrowDownRight, Award } from 'lucide-react';

interface AttributionWorkspaceProps {
  etf: ETFDefinition;
}

export const AttributionWorkspace: React.FC<AttributionWorkspaceProps> = ({ etf }) => {
  const { factorAttribution, performanceAttribution } = useMemo(() => {
    const eligibility = evaluateEligibility(SYNTHETIC_UNIVERSE, [{ id: 'r1', field: 'marketCap', operator: '>=', value: 5000 }]);
    const raw = calculateRawWeights(eligibility.eligibleSecurities, etf.methodology);
    const holdings = applyConstraintsAndNormalize(raw, etf.methodology);
    const factors = calculateFactorAttribution(holdings);
    const perf = calculatePerformanceAttribution(0.142, 0.128, etf.expenseRatio, etf.slippageBps);
    return { factorAttribution: factors, performanceAttribution: perf };
  }, [etf]);

  const factorItems = [
    { name: 'MARKET (BETA)', val: factorAttribution.market },
    { name: 'SIZE (SMB)', val: factorAttribution.size },
    { name: 'VALUE (HML)', val: factorAttribution.value },
    { name: 'MOMENTUM (UMD)', val: factorAttribution.momentum },
    { name: 'QUALITY (RMW)', val: factorAttribution.quality },
    { name: 'LOW VOLATILITY', val: factorAttribution.lowVol }
  ];

  return (
    <div className="p-4 space-y-4 max-w-7xl mx-auto font-mono text-xs">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column: Fama-French Factor Exposures */}
        <div className="lg:col-span-6 bg-slate-900/80 border border-slate-800 rounded-lg p-4 space-y-4">
          <span className="font-bold uppercase text-slate-200 block border-b border-slate-800 pb-2">
            FAMA-FRENCH 5-FACTOR + MOMENTUM EXPOSURES
          </span>

          <div className="space-y-3">
            {factorItems.map(item => (
              <div key={item.name} className="space-y-1 bg-slate-950 p-2.5 rounded border border-slate-800">
                <div className="flex justify-between items-center text-[11px]">
                  <span className="text-slate-300 font-bold">{item.name}</span>
                  <span className={`font-bold ${item.val >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                    {item.val >= 0 ? '+' : ''}{item.val.toFixed(2)}
                  </span>
                </div>
                <div className="w-full bg-slate-900 h-2 rounded overflow-hidden relative">
                  <div
                    className={`h-full rounded ${item.val >= 0 ? 'bg-emerald-500' : 'bg-red-500'}`}
                    style={{ width: `${Math.min(Math.abs(item.val) * 50, 100)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column: Brinson-Fachler Performance Attribution Waterfall */}
        <div className="lg:col-span-6 bg-slate-900/80 border border-slate-800 rounded-lg p-4 space-y-4">
          <span className="font-bold uppercase text-slate-200 block border-b border-slate-800 pb-2">
            BRINSON PERFORMANCE ATTRIBUTION WATERFALL
          </span>

          <div className="space-y-2 text-[11px]">
            <div className="flex justify-between p-2 bg-slate-950 border border-slate-800 rounded">
              <span className="text-slate-400">BENCHMARK RETURN:</span>
              <span className="text-slate-200 font-bold">{(performanceAttribution.benchmarkReturn * 100).toFixed(2)}%</span>
            </div>

            <div className="flex justify-between p-2 bg-slate-950 border border-slate-800 rounded">
              <span className="text-slate-400">+ SECTOR ALLOCATION EFFECT:</span>
              <span className="text-emerald-400 font-bold">+{(performanceAttribution.allocationEffect * 100).toFixed(2)}%</span>
            </div>

            <div className="flex justify-between p-2 bg-slate-950 border border-slate-800 rounded">
              <span className="text-slate-400">+ STOCK SELECTION EFFECT:</span>
              <span className="text-emerald-400 font-bold">+{(performanceAttribution.selectionEffect * 100).toFixed(2)}%</span>
            </div>

            <div className="flex justify-between p-2 bg-slate-950 border border-slate-800 rounded">
              <span className="text-slate-400">+ REBALANCE ALPHA EFFECT:</span>
              <span className="text-emerald-400 font-bold">+{(performanceAttribution.rebalanceEffect * 100).toFixed(2)}%</span>
            </div>

            <div className="flex justify-between p-2 bg-slate-950 border border-slate-800 rounded">
              <span className="text-slate-400">- EXPENSE RATIO DRAG:</span>
              <span className="text-red-400 font-bold">{(performanceAttribution.feeDrag * 100).toFixed(2)}%</span>
            </div>

            <div className="flex justify-between p-2 bg-slate-950 border border-slate-800 rounded">
              <span className="text-slate-400">- TRANSACTION FRICTION DRAG:</span>
              <span className="text-red-400 font-bold">{(performanceAttribution.transactionCostsDrag * 100).toFixed(2)}%</span>
            </div>

            <div className="flex justify-between p-2.5 bg-blue-950/80 border border-blue-800 rounded font-bold text-sm text-blue-300 mt-2">
              <span>FINAL ETF TOTAL RETURN:</span>
              <span>{(performanceAttribution.totalReturn * 100).toFixed(2)}%</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
