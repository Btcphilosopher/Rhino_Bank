import React, { useState, useMemo } from 'react';
import { ETFDefinition, NAVPoint, SecondaryMarketState, CreationRedemptionOrder } from '../types';
import { SYNTHETIC_UNIVERSE } from '../engine/securitiesUniverse';
import { evaluateEligibility, calculateRawWeights, applyConstraintsAndNormalize } from '../engine/indexEngine';
import { generateSyntheticPricePaths } from '../engine/marketSimulation';
import { simulateEtfNavSeries, generateOrderBook, simulateCreationRedemption } from '../engine/navEngine';
import { DollarSign, Layers, ArrowUpRight, ArrowDownRight, RefreshCw, Layers3, CheckCircle2 } from 'lucide-react';

interface PriceAndNavWorkspaceProps {
  etf: ETFDefinition;
}

export const PriceAndNavWorkspace: React.FC<PriceAndNavWorkspaceProps> = ({ etf }) => {
  const [sharesCount, setSharesCount] = useState<number>(50000);
  const [activeOrder, setActiveOrder] = useState<CreationRedemptionOrder | null>(null);

  // Holdings & NAV Points
  const { navPoints, holdings } = useMemo(() => {
    const eligibility = evaluateEligibility(SYNTHETIC_UNIVERSE, [{ id: 'r1', field: 'marketCap', operator: '>=', value: 5000 }]);
    const raw = calculateRawWeights(eligibility.eligibleSecurities, etf.methodology);
    const h = applyConstraintsAndNormalize(raw, etf.methodology);
    const pricePaths = generateSyntheticPricePaths(SYNTHETIC_UNIVERSE.slice(0, 50), 'GBM', 2026, 252);
    const points = simulateEtfNavSeries(etf, h, pricePaths, 252);
    return { navPoints: points, holdings: h };
  }, [etf]);

  const latestNav = navPoints[navPoints.length - 1] || {
    navPerShare: 100.42,
    marketPrice: 100.57,
    premiumDiscountPct: 0.15,
    trackingDifferencePct: 0.83,
    cumulativeFees: 35000,
    cumulativeTransactionCosts: 18000
  };

  const orderBook: SecondaryMarketState = useMemo(() => {
    return generateOrderBook(latestNav.navPerShare, etf.spreadBps);
  }, [latestNav, etf]);

  const handleSimulateApOrder = (type: 'CREATION' | 'REDEMPTION') => {
    const ord = simulateCreationRedemption(etf, holdings, type, sharesCount);
    setActiveOrder(ord);
  };

  return (
    <div className="p-4 space-y-4 max-w-7xl mx-auto font-mono text-xs">
      {/* Top Key Indicator Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        <div className="bg-slate-900/90 border border-slate-800 p-3 rounded space-y-1">
          <span className="text-[10px] text-slate-400 uppercase">NAV PER SHARE</span>
          <div className="text-lg font-bold text-slate-100">${latestNav.navPerShare.toFixed(2)}</div>
          <span className="text-[10px] text-slate-500">Net Asset Value</span>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 p-3 rounded space-y-1">
          <span className="text-[10px] text-slate-400 uppercase">SECONDARY MARKET PRICE</span>
          <div className="text-lg font-bold text-blue-400">${latestNav.marketPrice.toFixed(2)}</div>
          <span className="text-[10px] text-slate-500">Simulated Trading Price</span>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 p-3 rounded space-y-1">
          <span className="text-[10px] text-slate-400 uppercase">PREMIUM / DISCOUNT</span>
          <div className={`text-lg font-bold ${latestNav.premiumDiscountPct >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
            {latestNav.premiumDiscountPct >= 0 ? '+' : ''}{latestNav.premiumDiscountPct.toFixed(2)}%
          </div>
          <span className="text-[10px] text-slate-500">Arb Opportunity Window</span>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 p-3 rounded space-y-1">
          <span className="text-[10px] text-slate-400 uppercase">BID-ASK SPREAD</span>
          <div className="text-lg font-bold text-amber-400">{orderBook.spreadBps} bps</div>
          <span className="text-[10px] text-slate-500">${(orderBook.askPrice - orderBook.bidPrice).toFixed(2)} Spread</span>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 p-3 rounded space-y-1">
          <span className="text-[10px] text-slate-400 uppercase">TRACKING DIFFERENCE</span>
          <div className="text-lg font-bold text-purple-400">{latestNav.trackingDifferencePct.toFixed(2)}%</div>
          <span className="text-[10px] text-slate-500">vs Benchmark Index</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column: Order Book & Secondary Market Depth */}
        <div className="lg:col-span-5 bg-slate-900/80 border border-slate-800 rounded-lg p-4 space-y-4">
          <span className="font-bold uppercase text-slate-200 block border-b border-slate-800 pb-2">
            SECONDARY MARKET ORDER BOOK DEPTH
          </span>

          <div className="grid grid-cols-2 gap-3 text-[11px]">
            {/* Bids */}
            <div className="space-y-1">
              <span className="text-emerald-400 font-bold block border-b border-slate-800 pb-1">BIDS (BUY DEPTH)</span>
              {orderBook.bidDepth.map((b, idx) => (
                <div key={idx} className="flex justify-between p-1 bg-emerald-950/20 border border-emerald-900/40 rounded">
                  <span className="text-emerald-400 font-bold">${b.price.toFixed(2)}</span>
                  <span className="text-slate-300">{b.size.toLocaleString()}</span>
                </div>
              ))}
            </div>

            {/* Asks */}
            <div className="space-y-1">
              <span className="text-red-400 font-bold block border-b border-slate-800 pb-1">ASKS (SELL DEPTH)</span>
              {orderBook.askDepth.map((a, idx) => (
                <div key={idx} className="flex justify-between p-1 bg-red-950/20 border border-red-900/40 rounded">
                  <span className="text-red-400 font-bold">${a.price.toFixed(2)}</span>
                  <span className="text-slate-300">{a.size.toLocaleString()}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Primary Market AP Creation / Redemption Simulator */}
          <div className="bg-slate-950 border border-slate-800 p-3 rounded space-y-3 pt-3">
            <span className="font-bold text-slate-200 block border-b border-slate-800 pb-1 uppercase">
              AUTHORISED PARTICIPANT (AP) BASKET ARBITRAGE
            </span>

            <div className="space-y-2">
              <label className="text-slate-400 text-[10px] block">CREATION / REDEMPTION SHARES BLOCK:</label>
              <input
                type="number"
                value={sharesCount}
                onChange={(e) => setSharesCount(parseInt(e.target.value) || 10000)}
                className="w-full bg-slate-900 border border-slate-800 text-slate-200 rounded px-2 py-1 focus:border-blue-500 focus:outline-none"
              />

              <div className="grid grid-cols-2 gap-2 pt-1">
                <button
                  onClick={() => handleSimulateApOrder('CREATION')}
                  className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-1.5 rounded transition cursor-pointer"
                >
                  CREATE SHARES
                </button>
                <button
                  onClick={() => handleSimulateApOrder('REDEMPTION')}
                  className="bg-red-600 hover:bg-red-500 text-white font-bold py-1.5 rounded transition cursor-pointer"
                >
                  REDEEM SHARES
                </button>
              </div>
            </div>

            {/* Active Order Results */}
            {activeOrder && (
              <div className="bg-slate-900 p-2.5 rounded border border-blue-800 space-y-1 text-[11px] text-slate-300">
                <div className="flex justify-between font-bold text-blue-400">
                  <span>{activeOrder.id}</span>
                  <span className="text-emerald-400">{activeOrder.status}</span>
                </div>
                <div><span className="text-slate-500">NAV VALUE:</span> ${activeOrder.totalNavValue.toLocaleString()}</div>
                <div><span className="text-slate-500">CASH COMPONENT:</span> ${activeOrder.cashComponent.toLocaleString()}</div>
                <div><span className="text-slate-500">AP FEE:</span> ${activeOrder.creationFee.toLocaleString()}</div>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: NAV vs Benchmark Time Series Chart */}
        <div className="lg:col-span-7 bg-slate-900/80 border border-slate-800 rounded-lg p-4 space-y-4">
          <span className="font-bold uppercase text-slate-200 block border-b border-slate-800 pb-2">
            252-DAY NAV TIME SERIES VS BENCHMARK INDEX
          </span>

          {/* SVG Chart */}
          <div className="bg-slate-950 p-3 rounded border border-slate-800 h-[340px] flex flex-col justify-between relative">
            <svg className="w-full h-full overflow-visible" viewBox="0 0 500 230" preserveAspectRatio="none">
              {/* Grid Lines */}
              <line x1="0" y1="46" x2="500" y2="46" stroke="#1e293b" strokeDasharray="3 3" />
              <line x1="0" y1="92" x2="500" y2="92" stroke="#1e293b" strokeDasharray="3 3" />
              <line x1="0" y1="138" x2="500" y2="138" stroke="#1e293b" strokeDasharray="3 3" />
              <line x1="0" y1="184" x2="500" y2="184" stroke="#1e293b" strokeDasharray="3 3" />

              {/* NAV Line */}
              <polyline
                fill="none"
                stroke="#3b82f6"
                strokeWidth="2"
                points={navPoints.map((p, idx) => {
                  const x = (idx / (navPoints.length - 1)) * 500;
                  const y = 230 - ((p.navPerShare - 90) / 40) * 210;
                  return `${x.toFixed(1)},${y.toFixed(1)}`;
                }).join(' ')}
              />

              {/* Benchmark Line */}
              <polyline
                fill="none"
                stroke="#64748b"
                strokeWidth="1.5"
                strokeDasharray="4 2"
                points={navPoints.map((p, idx) => {
                  const x = (idx / (navPoints.length - 1)) * 500;
                  const y = 230 - ((p.benchmarkValue - 90) / 40) * 210;
                  return `${x.toFixed(1)},${y.toFixed(1)}`;
                }).join(' ')}
              />
            </svg>

            <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-2">
              <span>DAY 0 ($100.00)</span>
              <span>DAY 126</span>
              <span>DAY 252 (${latestNav.navPerShare.toFixed(2)})</span>
            </div>
          </div>

          <div className="flex items-center space-x-4 text-[11px]">
            <div className="flex items-center space-x-1.5">
              <span className="h-2.5 w-5 bg-blue-500 rounded-sm" />
              <span className="text-slate-200 font-bold">SYNTHETIC ETF NAV</span>
            </div>
            <div className="flex items-center space-x-1.5">
              <span className="h-0.5 w-5 bg-slate-400 border-b border-dashed border-slate-400" />
              <span className="text-slate-400">BENCHMARK INDEX</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
