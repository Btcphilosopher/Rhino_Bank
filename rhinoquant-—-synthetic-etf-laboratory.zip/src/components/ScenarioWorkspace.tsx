import React, { useState, useMemo } from 'react';
import { ETFDefinition, StressScenario, ScenarioResult } from '../types';
import { PRESET_SCENARIOS, runStressScenario } from '../engine/scenarioEngine';
import { SYNTHETIC_UNIVERSE } from '../engine/securitiesUniverse';
import { evaluateEligibility, calculateRawWeights, applyConstraintsAndNormalize } from '../engine/indexEngine';
import { ShieldAlert, AlertTriangle, Play, RefreshCw, Layers } from 'lucide-react';

interface ScenarioWorkspaceProps {
  etf: ETFDefinition;
}

export const ScenarioWorkspace: React.FC<ScenarioWorkspaceProps> = ({ etf }) => {
  const [selectedScenarios, setSelectedScenarios] = useState<string[]>(['SCEN-EQ-01', 'SCEN-RATE-01', 'SCEN-VOL-01', 'SCEN-LIQ-01']);

  const holdings = useMemo(() => {
    const eligibility = evaluateEligibility(SYNTHETIC_UNIVERSE, [{ id: 'r1', field: 'marketCap', operator: '>=', value: 5000 }]);
    const raw = calculateRawWeights(eligibility.eligibleSecurities, etf.methodology);
    return applyConstraintsAndNormalize(raw, etf.methodology);
  }, [etf]);

  const results: ScenarioResult[] = useMemo(() => {
    return PRESET_SCENARIOS
      .filter(scen => selectedScenarios.includes(scen.id))
      .map(scen => runStressScenario(scen, holdings));
  }, [selectedScenarios, holdings]);

  const toggleScenario = (id: string) => {
    if (selectedScenarios.includes(id)) {
      setSelectedScenarios(selectedScenarios.filter(s => s !== id));
    } else {
      setSelectedScenarios([...selectedScenarios, id]);
    }
  };

  return (
    <div className="p-4 space-y-4 max-w-7xl mx-auto font-mono text-xs">
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-base font-bold text-slate-100 font-sans">RHINOQUANT SCENARIO STRESS LABORATORY</h1>
          <p className="text-slate-400 text-[11px]">
            Stress test <strong className="text-blue-400">{etf.ticker}</strong> under macroeconomic shocks, volatility spikes, and liquidity freezes.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column: Preset Scenarios Selector */}
        <div className="lg:col-span-4 bg-slate-900/80 border border-slate-800 rounded-lg p-4 space-y-3">
          <span className="font-bold uppercase text-slate-200 block border-b border-slate-800 pb-2">
            PRESET SCENARIO MATRIX
          </span>

          <div className="space-y-2">
            {PRESET_SCENARIOS.map(scen => {
              const isSelected = selectedScenarios.includes(scen.id);
              return (
                <div
                  key={scen.id}
                  onClick={() => toggleScenario(scen.id)}
                  className={`p-2.5 rounded border cursor-pointer transition space-y-1 ${
                    isSelected
                      ? 'bg-blue-950/60 border-blue-600 text-slate-100'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="flex justify-between items-center font-bold">
                    <span className="text-blue-400">{scen.name}</span>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded ${isSelected ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400'}`}>
                      {isSelected ? 'ACTIVE' : 'SELECT'}
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400 line-clamp-2">{scen.description}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Side-by-Side Scenario Impact Comparison */}
        <div className="lg:col-span-8 bg-slate-900/80 border border-slate-800 rounded-lg p-4 space-y-4">
          <span className="font-bold uppercase text-slate-200 block border-b border-slate-800 pb-2">
            SCENARIO STRESS IMPACT COMPARISON MATRIX
          </span>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-slate-300">
              <thead className="bg-slate-950 text-slate-400 text-[10px] uppercase border-b border-slate-800">
                <tr>
                  <th className="py-2.5 px-3">SCENARIO NAME</th>
                  <th className="py-2.5 px-3 text-right">ETF RETURN</th>
                  <th className="py-2.5 px-3 text-right">BENCHMARK</th>
                  <th className="py-2.5 px-3 text-right">MAX DRAWDOWN</th>
                  <th className="py-2.5 px-3 text-right">SPREAD IMPACT</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                {results.map((res) => (
                  <tr key={res.scenarioId} className="hover:bg-slate-800/40 transition">
                    <td className="py-2 px-3 font-bold text-blue-300">{res.scenarioName}</td>
                    <td className={`py-2 px-3 text-right font-bold ${res.etfReturnPct >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                      {res.etfReturnPct >= 0 ? '+' : ''}{res.etfReturnPct}%
                    </td>
                    <td className="py-2 px-3 text-right text-slate-300">{res.benchmarkReturnPct}%</td>
                    <td className="py-2 px-3 text-right text-red-400">{res.maxDrawdownPct}%</td>
                    <td className="py-2 px-3 text-right text-amber-400">+{res.liquidityImpactBps} bps</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
