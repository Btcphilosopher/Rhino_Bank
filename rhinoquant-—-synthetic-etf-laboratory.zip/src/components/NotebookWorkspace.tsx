import React, { useState } from 'react';
import { Play, Code, CheckCircle2, FileText, RefreshCw, Terminal } from 'lucide-react';

interface CodeCell {
  id: string;
  language: 'python' | 'r';
  title: string;
  code: string;
  output?: string;
  isExecuting?: boolean;
}

export const NotebookWorkspace: React.FC = () => {
  const [cells, setCells] = useState<CodeCell[]>([
    {
      id: 'cell-1',
      language: 'python',
      title: 'Cell 1: Fama-French 5-Factor OLS Regression Analysis',
      code: `import numpy as np
import pandas as pd
import statsmodels.api as sm

# Load synthetic ETF NAV returns & Fama-French benchmark factors
df = pd.read_parquet('rhinoquant/data/etf_nav_returns.parquet')
X = df[['Mkt-RF', 'SMB', 'HML', 'RMW', 'CMA']]
X = sm.add_constant(X)
y = df['RQ-IND-RF']

model = sm.OLS(y, X).fit()
print(model.summary())`,
      output: `                            OLS Regression Results                            
==============================================================================
Dep. Variable:              RQ-IND-RF   R-squared:                       0.892
Model:                            OLS   Adj. R-squared:                  0.889
Method:                 Least Squares   F-statistic:                     312.4
==============================================================================
                 coef    std err          t      P>|t|      [0.025      0.975]
------------------------------------------------------------------------------
const          0.0018      0.0004      4.500      0.000      0.0010      0.0026
Mkt-RF         0.9820      0.0210     46.762      0.000      0.9407      1.0233
SMB           -0.3420      0.0380     -9.000      0.000     -0.4168     -0.2672
HML            0.2840      0.0410      6.927      0.000      0.2033      0.3647
RMW            0.1850      0.0350      5.286      0.000      0.1161      0.2539
CMA           -0.1210      0.0320     -3.781      0.000     -0.1840     -0.0580
==============================================================================`
    },
    {
      id: 'cell-2',
      language: 'r',
      title: 'Cell 2: R Econometric GARCH(1,1) Volatility Clustering Model',
      code: `library(rugarch)
library(xts)

# Fit GARCH(1,1) model to synthetic ETF NAV log returns
spec <- ugarchspec(variance.model = list(model = "sGARCH", garchOrder = c(1, 1)),
                   mean.model = list(armaOrder = c(0, 0)))
fit <- ugarchfit(spec = spec, data = etf_returns)
print(fit)`,
      output: `*----------------------------------*
*        GARCH Model Fit           *
*----------------------------------*

Optimal Parameters:
------------------------------------
        Estimate  Std. Error  t value Pr(>|t|)
mu      0.000452    0.000210   2.1524  0.03137
omega   0.000004    0.000001   4.0000  0.00006
alpha1  0.082150    0.021000   3.9119  0.00009
beta1   0.895400    0.025000  35.8160  0.00000

Persistence: 0.977550 (High Volatility Clustering Detected)`
    }
  ]);

  const runCell = (id: string) => {
    setCells(cells.map(c => {
      if (c.id === id) {
        return { ...c, isExecuting: true };
      }
      return c;
    }));

    setTimeout(() => {
      setCells(cells.map(c => {
        if (c.id === id) {
          return { ...c, isExecuting: false };
        }
        return c;
      }));
    }, 600);
  };

  return (
    <div className="p-4 space-y-4 max-w-7xl mx-auto font-mono text-xs">
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-base font-bold text-slate-100 font-sans">QUANTITATIVE RESEARCH NOTEBOOK</h1>
          <p className="text-slate-400 text-[11px]">
            Python 3.12 / R 4.4 Kernel • NumPy, SciPy, Statsmodels, Rugarch Execution Environment
          </p>
        </div>
      </div>

      <div className="space-y-4">
        {cells.map((cell) => (
          <div key={cell.id} className="bg-slate-900/80 border border-slate-800 rounded-lg overflow-hidden space-y-2">
            {/* Cell Header */}
            <div className="bg-slate-950 px-4 py-2 border-b border-slate-800 flex justify-between items-center">
              <span className="font-bold text-slate-200">{cell.title}</span>
              <button
                onClick={() => runCell(cell.id)}
                disabled={cell.isExecuting}
                className="bg-blue-600 hover:bg-blue-500 text-white font-bold px-3 py-1 rounded flex items-center space-x-1 cursor-pointer disabled:opacity-50"
              >
                <Play className="h-3 w-3" />
                <span>{cell.isExecuting ? 'RUNNING...' : 'EXECUTE CELL'}</span>
              </button>
            </div>

            {/* Code Textarea */}
            <div className="px-4 py-2">
              <textarea
                value={cell.code}
                onChange={(e) => {
                  const val = e.target.value;
                  setCells(cells.map(c => c.id === cell.id ? { ...c, code: val } : c));
                }}
                rows={7}
                className="w-full bg-[#080c14] border border-slate-800/80 rounded p-3 text-slate-200 text-xs font-mono focus:border-blue-500 focus:outline-none"
              />
            </div>

            {/* Output Panel */}
            {cell.output && (
              <div className="px-4 pb-4">
                <div className="bg-black/90 border border-slate-800 rounded p-3 text-emerald-400 font-mono text-[11px] overflow-x-auto whitespace-pre">
                  {cell.output}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
