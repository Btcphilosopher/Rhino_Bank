import React, { useState, useMemo } from 'react';
import { ETFDefinition, MonteCarloResult } from '../types';
import { runMonteCarloSimulation } from '../engine/monteCarloEngine';
import { Play, RefreshCw, BarChart2, Activity, ShieldCheck, Layers } from 'lucide-react';

interface MonteCarloWorkspaceProps {
  etf: ETFDefinition;
}

export const MonteCarloWorkspace: React.FC<MonteCarloWorkspaceProps> = ({ etf }) => {
  const [numPaths, setNumPaths] = useState<number>(1000);
  const [seed, setSeed] = useState<number>(525134);

  const result: MonteCarloResult = useMemo(() => {
    return runMonteCarloSimulation(100.0, 0.085, 0.142, numPaths, 252, seed);
  }, [numPaths, seed]);

  const p = result.percentiles;

  return (
    <div className="p-4 space-y-4 max-w-7xl mx-auto font-mono text-xs">
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-base font-bold text-slate-100 font-sans">RHINOQUANT MONTE CARLO LABORATORY</h1>
          <p className="text-slate-400 text-[11px]">
            Simulated <strong className="text-blue-400">{numPaths.toLocaleString()} Stochastic Paths</strong> • Seed <strong className="text-blue-400">{seed}</strong>
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <select
            value={numPaths}
            onChange={(e) => setNumPaths(parseInt(e.target.value))}
            className="bg-slate-950 border border-slate-800 text-slate-200 rounded px-2.5 py-1 text-xs"
          >
            <option value="500">500 PATHS</option>
            <option value="1000">1,000 PATHS</option>
            <option value="2500">2,500 PATHS</option>
          </select>

          <button
            onClick={() => setSeed(Math.floor(Math.random() * 899999 + 100000))}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded flex items-center space-x-1 cursor-pointer"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            <span>RE-SEED SIMULATION</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column: Fan Chart */}
        <div className="lg:col-span-8 bg-slate-900/80 border border-slate-800 rounded-lg p-4 space-y-4">
          <span className="font-bold uppercase text-slate-200 block border-b border-slate-800 pb-2">
            MONTE CARLO NAV PERCENTILE FAN CHART (5TH TO 95TH PERCENTILE BANDS)
          </span>

          <div className="bg-slate-950 p-3 rounded border border-slate-800 h-[340px] flex flex-col justify-between relative">
            <svg className="w-full h-full overflow-visible" viewBox="0 0 500 230" preserveAspectRatio="none">
              {/* Grid Lines */}
              <line x1="0" y1="46" x2="500" y2="46" stroke="#1e293b" strokeDasharray="3 3" />
              <line x1="0" y1="92" x2="500" y2="92" stroke="#1e293b" strokeDasharray="3 3" />
              <line x1="0" y1="138" x2="500" y2="138" stroke="#1e293b" strokeDasharray="3 3" />
              <line x1="0" y1="184" x2="500" y2="184" stroke="#1e293b" strokeDasharray="3 3" />

              {/* 5th to 95th Percentile Shaded Area */}
              <polygon
                fill="rgba(59, 130, 246, 0.15)"
                points={`
                  ${p.p95.map((val, idx) => `${(idx / 251) * 500},${230 - ((val - 70) / 100) * 210}`).join(' ')} 
                  ${p.p5.slice().reverse().map((val, idx) => `${((251 - idx) / 251) * 500},${230 - ((val - 70) / 100) * 210}`).join(' ')}
                `}
              />

              {/* 25th to 75th Percentile Shaded Area */}
              <polygon
                fill="rgba(59, 130, 246, 0.35)"
                points={`
                  ${p.p75.map((val, idx) => `${(idx / 251) * 500},${230 - ((val - 70) / 100) * 210}`).join(' ')} 
                  ${p.p25.slice().reverse().map((val, idx) => `${((251 - idx) / 251) * 500},${230 - ((val - 70) / 100) * 210}`).join(' ')}
                `}
              />

              {/* Median Line p50 */}
              <polyline
                fill="none"
                stroke="#3b82f6"
                strokeWidth="2.5"
                points={p.p50.map((val, idx) => `${(idx / 251) * 500},${230 - ((val - 70) / 100) * 210}`).join(' ')}
              />
            </svg>

            <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-2">
              <span>DAY 0 ($100.00)</span>
              <span>DAY 126</span>
              <span>DAY 252 (MEDIAN ${result.finalNavStats.median.toFixed(2)})</span>
            </div>
          </div>

          <div className="flex items-center space-x-4 text-[11px]">
            <div className="flex items-center space-x-1.5">
              <span className="h-3 w-3 bg-blue-500 rounded-sm" />
              <span className="text-slate-200 font-bold">MEDIAN (P50)</span>
            </div>
            <div className="flex items-center space-x-1.5">
              <span className="h-3 w-3 bg-blue-600/40 rounded-sm" />
              <span className="text-slate-300">P25 - P75 BAND</span>
            </div>
            <div className="flex items-center space-x-1.5">
              <span className="h-3 w-3 bg-blue-600/20 rounded-sm" />
              <span className="text-slate-400">P5 - P95 TAIL BAND</span>
            </div>
          </div>
        </div>

        {/* Right Column: Final NAV & Tail Stats */}
        <div className="lg:col-span-4 bg-slate-900/80 border border-slate-800 rounded-lg p-4 space-y-4">
          <span className="font-bold uppercase text-slate-200 block border-b border-slate-800 pb-2">
            FINAL NAV DISTRIBUTION STATS
          </span>

          <div className="space-y-2 text-[11px]">
            <div className="flex justify-between p-2 bg-slate-950 border border-slate-800 rounded">
              <span className="text-slate-400">MEAN FINAL NAV:</span>
              <span className="text-slate-100 font-bold">${result.finalNavStats.mean.toFixed(2)}</span>
            </div>

            <div className="flex justify-between p-2 bg-slate-950 border border-slate-800 rounded">
              <span className="text-slate-400">MEDIAN FINAL NAV:</span>
              <span className="text-blue-400 font-bold">${result.finalNavStats.median.toFixed(2)}</span>
            </div>

            <div className="flex justify-between p-2 bg-slate-950 border border-slate-800 rounded">
              <span className="text-slate-400">5TH PERCENTILE (TAIL):</span>
              <span className="text-red-400 font-bold">${result.finalNavStats.p5.toFixed(2)}</span>
            </div>

            <div className="flex justify-between p-2 bg-slate-950 border border-slate-800 rounded">
              <span className="text-slate-400">95TH PERCENTILE:</span>
              <span className="text-emerald-400 font-bold">${result.finalNavStats.p95.toFixed(2)}</span>
            </div>

            <div className="flex justify-between p-2 bg-slate-950 border border-slate-800 rounded">
              <span className="text-slate-400">STD DEV:</span>
              <span className="text-slate-200">${result.finalNavStats.stdDev.toFixed(2)}</span>
            </div>
          </div>

          {/* Drawdown Distribution */}
          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-2 text-[11px]">
            <span className="font-bold text-slate-300 block uppercase border-b border-slate-800 pb-1">MAX DRAWDOWN HISTOGRAM</span>
            {result.drawdownDistribution.map(dd => (
              <div key={dd.bin} className="flex justify-between items-center text-slate-400">
                <span>{dd.bin}:</span>
                <span className="text-slate-200 font-bold">{dd.count} paths</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
