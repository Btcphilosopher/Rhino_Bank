import React, { useMemo } from 'react';
import { ETFDefinition, NAVPoint, PortfolioHolding, RiskMetrics } from '../types';
import { SYNTHETIC_UNIVERSE } from '../engine/securitiesUniverse';
import { evaluateEligibility, calculateRawWeights, applyConstraintsAndNormalize } from '../engine/indexEngine';
import { generateSyntheticPricePaths } from '../engine/marketSimulation';
import { simulateEtfNavSeries } from '../engine/navEngine';
import { calculateRiskMetrics } from '../engine/riskEngine';
import { ShieldAlert, TrendingDown, Activity, Award, BarChart3, PieChart, Layers } from 'lucide-react';

interface RiskWorkspaceProps {
  etf: ETFDefinition;
}

export const RiskWorkspace: React.FC<RiskWorkspaceProps> = ({ etf }) => {
  const { riskMetrics, holdings, navPoints } = useMemo(() => {
    const eligibility = evaluateEligibility(SYNTHETIC_UNIVERSE, [{ id: 'r1', field: 'marketCap', operator: '>=', value: 5000 }]);
    const raw = calculateRawWeights(eligibility.eligibleSecurities, etf.methodology);
    const h = applyConstraintsAndNormalize(raw, etf.methodology);
    const pricePaths = generateSyntheticPricePaths(SYNTHETIC_UNIVERSE.slice(0, 50), 'GBM', 2026, 252);
    const points = simulateEtfNavSeries(etf, h, pricePaths, 252);
    const metrics = calculateRiskMetrics(points, h);
    return { riskMetrics: metrics, holdings: h, navPoints: points };
  }, [etf]);

  return (
    <div className="p-4 space-y-4 max-w-7xl mx-auto font-mono text-xs">
      {/* Risk Metrics Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
        <div className="bg-slate-900/90 border border-slate-800 p-3 rounded space-y-1">
          <span className="text-[10px] text-slate-400 uppercase block">VOLATILITY (ANN)</span>
          <div className="text-base font-bold text-slate-100">{(riskMetrics.annualizedVolatility * 100).toFixed(1)}%</div>
          <span className="text-[10px] text-slate-500">1-Yr Forecast Std Dev</span>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 p-3 rounded space-y-1">
          <span className="text-[10px] text-slate-400 uppercase block">BETA TO BENCHMARK</span>
          <div className="text-base font-bold text-blue-400">{riskMetrics.betaToBenchmark.toFixed(2)}</div>
          <span className="text-[10px] text-slate-500">Market Sensitivity</span>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 p-3 rounded space-y-1">
          <span className="text-[10px] text-slate-400 uppercase block">TRACKING ERROR</span>
          <div className="text-base font-bold text-amber-400">{(riskMetrics.trackingError * 100).toFixed(2)}%</div>
          <span className="text-[10px] text-slate-500">Vol of Active Excess</span>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 p-3 rounded space-y-1">
          <span className="text-[10px] text-slate-400 uppercase block">MAX DRAWDOWN</span>
          <div className="text-base font-bold text-red-400">{(riskMetrics.maxDrawdown * 100).toFixed(1)}%</div>
          <span className="text-[10px] text-slate-500">Peak-to-Trough Loss</span>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 p-3 rounded space-y-1">
          <span className="text-[10px] text-slate-400 uppercase block">SHARPE RATIO</span>
          <div className="text-base font-bold text-emerald-400">{riskMetrics.sharpeRatio.toFixed(2)}</div>
          <span className="text-[10px] text-slate-500">Rf = 3.50%</span>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 p-3 rounded space-y-1">
          <span className="text-[10px] text-slate-400 uppercase block">SORTINO RATIO</span>
          <div className="text-base font-bold text-emerald-400">{riskMetrics.sortinoRatio.toFixed(2)}</div>
          <span className="text-[10px] text-slate-500">Downside Vol Ratio</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column: Value at Risk (VaR) & Expected Shortfall (CVaR) */}
        <div className="lg:col-span-6 bg-slate-900/80 border border-slate-800 rounded-lg p-4 space-y-4">
          <span className="font-bold uppercase text-slate-200 block border-b border-slate-800 pb-2">
            TAIL RISK METRICS: VALUE AT RISK (VaR) & CVaR
          </span>

          <div className="grid grid-cols-2 gap-3 text-[11px]">
            <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-2">
              <span className="font-bold text-amber-400 block border-b border-slate-800 pb-1">HISTORICAL VaR (95%)</span>
              <div className="text-lg font-bold text-slate-100">{(riskMetrics.var95Historical * 100).toFixed(2)}%</div>
              <p className="text-[10px] text-slate-500">Maximum expected 1-day loss at 95% confidence level.</p>
            </div>

            <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-2">
              <span className="font-bold text-red-400 block border-b border-slate-800 pb-1">HISTORICAL VaR (99%)</span>
              <div className="text-lg font-bold text-slate-100">{(riskMetrics.var99Historical * 100).toFixed(2)}%</div>
              <p className="text-[10px] text-slate-500">Extreme 1-day tail loss limit at 99% confidence level.</p>
            </div>

            <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-2">
              <span className="font-bold text-blue-400 block border-b border-slate-800 pb-1">PARAMETRIC VaR (95%)</span>
              <div className="text-lg font-bold text-slate-100">{(riskMetrics.var95Parametric * 100).toFixed(2)}%</div>
              <p className="text-[10px] text-slate-500">Gaussian analytical VaR model estimation.</p>
            </div>

            <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-2">
              <span className="font-bold text-purple-400 block border-b border-slate-800 pb-1">EXPECTED SHORTFALL (CVaR)</span>
              <div className="text-lg font-bold text-slate-100">{(riskMetrics.cvar95 * 100).toFixed(2)}%</div>
              <p className="text-[10px] text-slate-500">Average loss beyond the 95% VaR threshold.</p>
            </div>
          </div>
        </div>

        {/* Right Column: Concentration & Liquidity Profile */}
        <div className="lg:col-span-6 bg-slate-900/80 border border-slate-800 rounded-lg p-4 space-y-4">
          <span className="font-bold uppercase text-slate-200 block border-b border-slate-800 pb-2">
            CONCENTRATION & LIQUIDITY EXPOSURE
          </span>

          <div className="space-y-3 font-mono text-[11px]">
            <div className="flex justify-between items-center bg-slate-950 p-2.5 rounded border border-slate-800">
              <span className="text-slate-400">HERFINDAHL-HIRSCHMAN INDEX (HHI):</span>
              <span className="text-blue-400 font-bold">{riskMetrics.herfindahlIndex.toFixed(4)}</span>
            </div>

            <div className="flex justify-between items-center bg-slate-950 p-2.5 rounded border border-slate-800">
              <span className="text-slate-400">INFORMATION RATIO:</span>
              <span className="text-emerald-400 font-bold">{riskMetrics.informationRatio.toFixed(2)}</span>
            </div>

            <div className="flex justify-between items-center bg-slate-950 p-2.5 rounded border border-slate-800">
              <span className="text-slate-400">ANNUALIZED TURNOVER RATE:</span>
              <span className="text-amber-400 font-bold">{(riskMetrics.annualizedTurnover * 100).toFixed(1)}%</span>
            </div>

            <div className="space-y-1 bg-slate-950 p-2.5 rounded border border-slate-800">
              <div className="flex justify-between text-slate-300">
                <span>PORTFOLIO LIQUIDITY SCORE:</span>
                <span className="text-emerald-400 font-bold">{riskMetrics.liquidityScore} / 100</span>
              </div>
              <div className="w-full bg-slate-900 h-2 rounded overflow-hidden">
                <div
                  className="bg-emerald-500 h-full rounded"
                  style={{ width: `${riskMetrics.liquidityScore}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
