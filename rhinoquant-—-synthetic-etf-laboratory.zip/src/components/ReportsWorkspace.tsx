import React, { useMemo } from 'react';
import { ResearchProject, ETFDefinition } from '../types';
import { SYNTHETIC_UNIVERSE } from '../engine/securitiesUniverse';
import { evaluateEligibility, calculateRawWeights, applyConstraintsAndNormalize } from '../engine/indexEngine';
import { generateSyntheticPricePaths } from '../engine/marketSimulation';
import { simulateEtfNavSeries } from '../engine/navEngine';
import { calculateRiskMetrics } from '../engine/riskEngine';
import { Printer, Download, ShieldCheck, FileText, CheckCircle2 } from 'lucide-react';

interface ReportsWorkspaceProps {
  project: ResearchProject;
}

export const ReportsWorkspace: React.FC<ReportsWorkspaceProps> = ({ project }) => {
  const etf = project.etfDefinition;

  const { risk, holdings, navPoints } = useMemo(() => {
    const eligibility = evaluateEligibility(SYNTHETIC_UNIVERSE, [{ id: 'r1', field: 'marketCap', operator: '>=', value: 5000 }]);
    const raw = calculateRawWeights(eligibility.eligibleSecurities, etf.methodology);
    const h = applyConstraintsAndNormalize(raw, etf.methodology);
    const pricePaths = generateSyntheticPricePaths(SYNTHETIC_UNIVERSE.slice(0, 50), 'GBM', 2026, 252);
    const points = simulateEtfNavSeries(etf, h, pricePaths, 252);
    const r = calculateRiskMetrics(points, h);
    return { risk: r, holdings: h, navPoints: points };
  }, [etf]);

  const latestNav = navPoints[navPoints.length - 1] || { navPerShare: 100.42, marketPrice: 100.57 };

  return (
    <div className="p-4 space-y-4 max-w-5xl mx-auto font-mono text-xs">
      {/* Printable Actions Bar */}
      <div className="no-print bg-slate-900/90 border border-slate-800 rounded-lg p-4 flex justify-between items-center">
        <div>
          <h1 className="text-base font-bold text-slate-100 font-sans">INSTITUTIONAL RESEARCH REPORT</h1>
          <p className="text-slate-400 text-[11px]">Comprehensive Quantitative Methodology & Audit Dossier</p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => window.print()}
            className="bg-blue-600 hover:bg-blue-500 text-white font-bold px-3 py-1.5 rounded flex items-center space-x-1 cursor-pointer"
          >
            <Printer className="h-4 w-4" />
            <span>PRINT / SAVE PDF</span>
          </button>
        </div>
      </div>

      {/* Printable Report Document Body */}
      <div className="bg-slate-950 border border-slate-800 rounded-lg p-6 space-y-6 text-slate-200">
        {/* Document Header */}
        <div className="border-b border-slate-800 pb-4 flex justify-between items-start">
          <div>
            <div className="text-xs text-blue-400 font-bold uppercase tracking-wider">RHINOQUANT QUANTITATIVE RESEARCH</div>
            <h1 className="text-xl font-bold font-sans text-slate-100 mt-1">{etf.name}</h1>
            <div className="text-slate-400 text-[11px] mt-1">Research Project: {project.id} • Version: {project.version}</div>
          </div>

          <div className="text-right text-[10px] text-slate-400 space-y-0.5">
            <div>DATE: {new Date().toISOString().split('T')[0]}</div>
            <div>STATUS: <span className="text-emerald-400 font-bold">{project.status}</span></div>
            <div>CHECKSUM: <span className="text-slate-300 font-mono">{project.manifestHash.slice(0, 12)}...</span></div>
          </div>
        </div>

        {/* Executive Summary */}
        <div className="space-y-2">
          <h2 className="font-bold text-slate-100 uppercase border-b border-slate-800 pb-1 text-xs">1. EXECUTIVE SUMMARY & HYPOTHESIS</h2>
          <p className="text-slate-300 text-xs font-mono leading-relaxed bg-slate-900/60 p-3 rounded border border-slate-800">
            {project.hypothesis}
          </p>
        </div>

        {/* Methodology & Specifications */}
        <div className="space-y-2">
          <h2 className="font-bold text-slate-100 uppercase border-b border-slate-800 pb-1 text-xs">2. INDEX METHODOLOGY & SPECIFICATIONS</h2>
          <div className="grid grid-cols-2 gap-4 text-[11px]">
            <div className="space-y-1">
              <div><span className="text-slate-500">TICKER:</span> {etf.ticker}</div>
              <div><span className="text-slate-500">BASE CURRENCY:</span> {etf.baseCurrency}</div>
              <div><span className="text-slate-500">BENCHMARK INDEX:</span> {etf.benchmarkId}</div>
              <div><span className="text-slate-500">WEIGHTING SCHEME:</span> {etf.methodology.weightingMethod}</div>
            </div>
            <div className="space-y-1">
              <div><span className="text-slate-500">MAX CONSTITUENT CAP:</span> {((etf.methodology.constraints.maxConstituentWeight || 0) * 100).toFixed(1)}%</div>
              <div><span className="text-slate-500">REBALANCE FREQUENCY:</span> {etf.rebalanceFrequency}</div>
              <div><span className="text-slate-500">EXPENSE RATIO:</span> {(etf.expenseRatio * 10000).toFixed(0)} bps</div>
              <div><span className="text-slate-500">DIVIDEND POLICY:</span> {etf.dividendPolicy}</div>
            </div>
          </div>
        </div>

        {/* Top Holdings Table */}
        <div className="space-y-2">
          <h2 className="font-bold text-slate-100 uppercase border-b border-slate-800 pb-1 text-xs">3. TOP CONSTITUENT HOLDINGS ALLOCATION</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-slate-300 text-[10px]">
              <thead className="bg-slate-900 uppercase border-b border-slate-800 text-slate-400">
                <tr>
                  <th className="py-1.5 px-2">ID</th>
                  <th className="py-1.5 px-2">NAME</th>
                  <th className="py-1.5 px-2">SECTOR</th>
                  <th className="py-1.5 px-2 text-right">WEIGHT</th>
                  <th className="py-1.5 px-2 text-right">MARKET VAL</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono">
                {holdings.slice(0, 8).map(h => (
                  <tr key={h.securityIdentifier}>
                    <td className="py-1 px-2 text-blue-400 font-bold">{h.securityIdentifier}</td>
                    <td className="py-1 px-2 text-slate-200">{h.name}</td>
                    <td className="py-1 px-2">{h.sector}</td>
                    <td className="py-1 px-2 text-right font-bold text-emerald-400">{(h.weight * 100).toFixed(2)}%</td>
                    <td className="py-1 px-2 text-right text-slate-300">${(h.marketValue / 1000000).toFixed(2)}M</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Risk Metrics Summary */}
        <div className="space-y-2">
          <h2 className="font-bold text-slate-100 uppercase border-b border-slate-800 pb-1 text-xs">4. QUANTITATIVE RISK & PERFORMANCE PROFILE</h2>
          <div className="grid grid-cols-3 gap-2 text-[10px]">
            <div className="bg-slate-900 p-2 rounded border border-slate-800">
              <span className="text-slate-400 block">ANNUALIZED VOLATILITY:</span>
              <span className="font-bold text-slate-100 font-mono text-xs">{(risk.annualizedVolatility * 100).toFixed(1)}%</span>
            </div>
            <div className="bg-slate-900 p-2 rounded border border-slate-800">
              <span className="text-slate-400 block">TRACKING ERROR:</span>
              <span className="font-bold text-amber-400 font-mono text-xs">{(risk.trackingError * 100).toFixed(2)}%</span>
            </div>
            <div className="bg-slate-900 p-2 rounded border border-slate-800">
              <span className="text-slate-400 block">SHARPE RATIO:</span>
              <span className="font-bold text-emerald-400 font-mono text-xs">{risk.sharpeRatio.toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* Reproducibility Manifest Footer */}
        <div className="border-t border-slate-800 pt-4 text-[10px] text-slate-500 space-y-1">
          <div className="font-bold text-slate-400">REPRODUCIBILITY MANIFEST MAN-{project.id}</div>
          <div>SIMULATION ENGINE: RhinoQuant v2.4.0-RUST-PY-01 • RANDOM SEED: {project.randomSeed}</div>
          <div className="break-all font-mono text-slate-400 bg-slate-900 p-2 rounded border border-slate-800">
            SHA256: {project.manifestHash}
          </div>
        </div>
      </div>
    </div>
  );
};
