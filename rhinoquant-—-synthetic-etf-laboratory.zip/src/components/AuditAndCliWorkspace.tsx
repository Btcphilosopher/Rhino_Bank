import React, { useState } from 'react';
import { AuditRecord } from '../types';
import { Terminal, Shield, FileCheck, Send, Layers } from 'lucide-react';

interface AuditAndCliWorkspaceProps {
  auditLogs: AuditRecord[];
}

export const AuditAndCliWorkspace: React.FC<AuditAndCliWorkspaceProps> = ({ auditLogs }) => {
  const [cliInput, setCliInput] = useState('rhinoquant research');
  const [terminalHistory, setTerminalHistory] = useState<Array<{ cmd: string; output: string }>>([
    {
      cmd: 'rhinoquant research',
      output: `RHINOQUANT RESEARCH TERMINAL v2.4.0
Active Projects: 2
[1] RQ-ETF-00041: European Industrial Infrastructure Volatility-Weighted Strategy (v1.0 PUBLISHED)
[2] RQ-ETF-00042: Synthetic AI Hardware & Grid Power Compute Factor ETF (v1.1 PUBLISHED)`
    }
  ]);

  const handleRunCommand = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!cliInput.trim()) return;

    try {
      const res = await fetch('/api/v1/cli', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command: cliInput })
      });
      const data = await res.json();
      setTerminalHistory(prev => [...prev, { cmd: cliInput, output: data.output || 'Done.' }]);
    } catch (err) {
      setTerminalHistory(prev => [...prev, { cmd: cliInput, output: `Error executing command.` }]);
    }

    setCliInput('');
  };

  return (
    <div className="p-4 space-y-4 max-w-7xl mx-auto font-mono text-xs">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column: Interactive Terminal CLI */}
        <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-lg overflow-hidden flex flex-col h-[520px]">
          {/* Terminal Title Bar */}
          <div className="bg-slate-950 px-3 py-2 border-b border-slate-800 flex items-center justify-between text-slate-300">
            <div className="flex items-center space-x-2">
              <Terminal className="h-4 w-4 text-blue-400" />
              <span className="font-bold">RHINOQUANT TERMINAL CLI</span>
            </div>
            <span className="text-[10px] text-slate-500">BASH / PYTHON REPL</span>
          </div>

          {/* Terminal Output Logs */}
          <div className="flex-1 bg-black p-3 space-y-3 overflow-y-auto font-mono text-[11px] text-slate-200">
            {terminalHistory.map((item, idx) => (
              <div key={idx} className="space-y-1">
                <div className="flex items-center space-x-1.5 text-blue-400">
                  <span className="text-emerald-400 font-bold">researcher@rhinoquant:~$</span>
                  <span className="font-bold">{item.cmd}</span>
                </div>
                <div className="text-emerald-400/90 whitespace-pre-wrap pl-3 border-l border-emerald-900/60">
                  {item.output}
                </div>
              </div>
            ))}
          </div>

          {/* Terminal Input Form */}
          <form onSubmit={handleRunCommand} className="bg-slate-950 p-2 border-t border-slate-800 flex items-center space-x-2">
            <span className="text-emerald-400 font-bold pl-1">&gt;</span>
            <input
              type="text"
              value={cliInput}
              onChange={(e) => setCliInput(e.target.value)}
              placeholder="e.g. rhinoquant construct, rhinoquant simulate, rhinoquant risk"
              className="w-full bg-transparent text-slate-100 text-xs focus:outline-none font-mono"
            />
            <button type="submit" className="bg-blue-600 hover:bg-blue-500 text-white p-1 rounded cursor-pointer">
              <Send className="h-3.5 w-3.5" />
            </button>
          </form>
        </div>

        {/* Right Column: Immutable Audit Trail */}
        <div className="lg:col-span-6 bg-slate-900/80 border border-slate-800 rounded-lg p-4 space-y-3 h-[520px] flex flex-col">
          <span className="font-bold uppercase text-slate-200 block border-b border-slate-800 pb-2">
            IMMUTABLE EVENT AUDIT LOG
          </span>

          <div className="flex-1 overflow-y-auto space-y-2 pr-1">
            {auditLogs.map((log) => (
              <div key={log.id} className="bg-slate-950 p-2.5 rounded border border-slate-800 space-y-1 text-[11px]">
                <div className="flex justify-between items-center text-slate-400">
                  <span className="font-bold text-blue-400">{log.action}</span>
                  <span className="text-[10px] text-slate-500">{log.timestamp.replace('T', ' ').slice(0, 16)}</span>
                </div>
                <p className="text-slate-300">{log.details}</p>
                <div className="text-[10px] text-slate-500 font-mono flex justify-between pt-1 border-t border-slate-800/60">
                  <span>ACTOR: {log.actor}</span>
                  <span className="text-emerald-400">{log.manifestHash.slice(0, 10)}...</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
