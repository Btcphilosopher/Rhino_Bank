import React from 'react';
import { ResearchProject } from '../types';
import { Terminal, Shield, FileCheck, RefreshCw, Cpu, Database, Search } from 'lucide-react';

interface HeaderProps {
  activeProject: ResearchProject;
  projects: ResearchProject[];
  onSelectProject: (p: ResearchProject) => void;
  onNewProject: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeProject,
  projects,
  onSelectProject,
  onNewProject
}) => {
  return (
    <header className="border-b border-slate-800 bg-[#0c121e] px-4 py-2.5 text-slate-200">
      <div className="flex flex-wrap items-center justify-between gap-3">
        {/* Logo & Product Identity */}
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2 bg-blue-950/60 border border-blue-800/60 px-2.5 py-1 rounded text-blue-400 font-mono text-xs font-bold tracking-wider">
            <Terminal className="h-4 w-4 text-blue-400" />
            <span>RHINOQUANT</span>
          </div>
          <div className="h-4 w-px bg-slate-800 hidden sm:block" />
          <div className="hidden md:flex flex-col">
            <span className="text-xs font-semibold uppercase tracking-widest text-slate-300">Synthetic ETF Laboratory</span>
            <span className="text-[10px] text-slate-500 font-mono">RESEARCH • CONSTRUCTION • SIMULATION • ANALYTICS</span>
          </div>
        </div>

        {/* Active Research Project Selector */}
        <div className="flex items-center space-x-2 bg-slate-900/80 border border-slate-800 px-3 py-1 rounded">
          <span className="text-[10px] font-mono uppercase text-slate-400">RESEARCH:</span>
          <select
            value={activeProject.id}
            onChange={(e) => {
              const selected = projects.find(p => p.id === e.target.value);
              if (selected) onSelectProject(selected);
            }}
            className="bg-transparent text-xs font-mono font-bold text-blue-300 focus:outline-none cursor-pointer"
          >
            {projects.map(p => (
              <option key={p.id} value={p.id} className="bg-slate-900 text-slate-200 font-mono">
                {p.id} — {p.title} ({p.version})
              </option>
            ))}
          </select>

          <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${
            activeProject.isImmutable 
              ? 'bg-emerald-950/80 border border-emerald-800/80 text-emerald-400' 
              : 'bg-amber-950/80 border border-amber-800/80 text-amber-400'
          }`}>
            {activeProject.version} {activeProject.isImmutable ? 'IMMUTABLE' : 'DRAFT'}
          </span>
        </div>

        {/* Right Status & Manifest Hash */}
        <div className="flex items-center space-x-3 text-xs font-mono">
          <div className="hidden lg:flex items-center space-x-1.5 text-slate-400 bg-slate-950 border border-slate-800 px-2 py-1 rounded">
            <Shield className="h-3.5 w-3.5 text-emerald-400" />
            <span className="text-[10px] text-slate-400">MANIFEST:</span>
            <span className="text-[10px] text-slate-300 font-semibold">{activeProject.manifestHash.slice(0, 14)}...</span>
          </div>

          <div className="flex items-center space-x-1 text-slate-400">
            <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-[10px] uppercase text-slate-400">ENGINE: LIVE</span>
          </div>

          <button
            onClick={onNewProject}
            className="bg-blue-600 hover:bg-blue-500 text-white font-mono text-xs px-2.5 py-1 rounded font-medium transition flex items-center space-x-1 cursor-pointer"
          >
            <span>+ NEW ETF IDEA</span>
          </button>
        </div>
      </div>
    </header>
  );
};
