import React, { useState } from 'react';
import { Send, Terminal, Play, Code2, Copy, Check } from 'lucide-react';

interface Endpoint {
  method: 'GET' | 'POST';
  path: string;
  description: string;
  sampleBody?: object;
}

const ENDPOINTS: Endpoint[] = [
  {
    method: 'GET',
    path: '/api/v1/research',
    description: 'Retrieve all research projects and immutable hypothesis objects.'
  },
  {
    method: 'POST',
    path: '/api/v1/research',
    description: 'Create a new research project hypothesis.',
    sampleBody: {
      title: 'European Infrastructure Volatility Strategy',
      hypothesis: 'Construct synthetic ETF with quarterly rebalancing.',
      universeId: 'UNIV-EU-IND'
    }
  },
  {
    method: 'GET',
    path: '/api/v1/universes',
    description: 'Query master synthetic 250 security universe dataset.'
  },
  {
    method: 'POST',
    path: '/api/v1/etfs/construct',
    description: 'Filter universe, apply index methodology rules, and construct portfolio holdings.',
    sampleBody: {
      rules: [{ id: 'r1', field: 'marketCap', operator: '>=', value: 5000 }],
      methodology: { weightingMethod: 'INVERSE_VOLATILITY', constraints: { maxConstituentWeight: 0.08 } }
    }
  },
  {
    method: 'POST',
    path: '/api/v1/etfs/simulate',
    description: 'Generate multi-asset stochastic market price paths and calculate daily NAV time series.',
    sampleBody: {
      etfId: 'RQ-IND',
      model: 'GBM',
      horizonDays: 252,
      seed: 2026
    }
  },
  {
    method: 'POST',
    path: '/api/v1/scenarios',
    description: 'Execute stress testing laboratory against 8 preset market shocks.',
    sampleBody: { etfId: 'RQ-IND' }
  },
  {
    method: 'POST',
    path: '/api/v1/monte-carlo',
    description: 'Execute 1,000+ path Monte Carlo simulation and compute percentile fan bands.',
    sampleBody: { numPaths: 1000, seed: 525134, horizonDays: 252 }
  },
  {
    method: 'GET',
    path: '/api/v1/audit',
    description: 'Fetch immutable event log audit trail.'
  }
];

export const RestApiWorkspace: React.FC = () => {
  const [selectedEndpoint, setSelectedEndpoint] = useState<Endpoint>(ENDPOINTS[0]);
  const [requestBody, setRequestBody] = useState<string>(
    JSON.stringify(ENDPOINTS[0].sampleBody || {}, null, 2)
  );
  const [responseJson, setResponseJson] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const handleSelectEndpoint = (ep: Endpoint) => {
    setSelectedEndpoint(ep);
    setRequestBody(JSON.stringify(ep.sampleBody || {}, null, 2));
    setResponseJson('');
  };

  const handleExecuteRequest = async () => {
    setIsLoading(true);
    try {
      const options: RequestInit = {
        method: selectedEndpoint.method,
        headers: { 'Content-Type': 'application/json' }
      };

      if (selectedEndpoint.method === 'POST' && requestBody.trim()) {
        options.body = requestBody;
      }

      const res = await fetch(selectedEndpoint.path, options);
      const data = await res.json();
      setResponseJson(JSON.stringify(data, null, 2));
    } catch (err) {
      setResponseJson(JSON.stringify({ error: 'Request failed', details: String(err) }, null, 2));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="p-4 space-y-4 max-w-7xl mx-auto font-mono text-xs">
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-base font-bold text-slate-100 font-sans">FASTAPI / OPENAPI REST EXPLORER</h1>
          <p className="text-slate-400 text-[11px]">
            Live Institutional REST API Endpoints • JSON Data Payloads
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column: Endpoint List */}
        <div className="lg:col-span-4 bg-slate-900/80 border border-slate-800 rounded-lg p-4 space-y-3">
          <span className="font-bold uppercase text-slate-200 block border-b border-slate-800 pb-2">
            API ENDPOINT CATALOG
          </span>

          <div className="space-y-1.5">
            {ENDPOINTS.map((ep, idx) => {
              const isSelected = selectedEndpoint.path === ep.path && selectedEndpoint.method === ep.method;
              return (
                <div
                  key={idx}
                  onClick={() => handleSelectEndpoint(ep)}
                  className={`p-2 rounded border cursor-pointer transition space-y-1 ${
                    isSelected
                      ? 'bg-blue-950/60 border-blue-600 text-slate-100'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center space-x-2 font-bold">
                    <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                      ep.method === 'GET' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-blue-950 text-blue-400 border border-blue-800'
                    }`}>
                      {ep.method}
                    </span>
                    <span className="text-slate-200 truncate">{ep.path}</span>
                  </div>
                  <p className="text-[10px] text-slate-500 truncate">{ep.description}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Request Runner & JSON Response Inspector */}
        <div className="lg:col-span-8 bg-slate-900/80 border border-slate-800 rounded-lg p-4 space-y-4">
          <div className="flex justify-between items-center border-b border-slate-800 pb-2">
            <div className="flex items-center space-x-2 font-bold text-sm">
              <span className={`px-2 py-0.5 rounded text-xs ${
                selectedEndpoint.method === 'GET' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-blue-950 text-blue-400 border border-blue-800'
              }`}>
                {selectedEndpoint.method}
              </span>
              <span className="text-slate-100">{selectedEndpoint.path}</span>
            </div>

            <button
              onClick={handleExecuteRequest}
              disabled={isLoading}
              className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-4 py-1.5 rounded flex items-center space-x-1.5 cursor-pointer disabled:opacity-50"
            >
              <Play className="h-3.5 w-3.5" />
              <span>{isLoading ? 'SENDING...' : 'TEST ENDPOINT'}</span>
            </button>
          </div>

          {/* Request Body Editor (if POST) */}
          {selectedEndpoint.method === 'POST' && (
            <div className="space-y-1">
              <span className="text-slate-400 text-[10px] font-bold uppercase block">REQUEST JSON BODY:</span>
              <textarea
                value={requestBody}
                onChange={(e) => setRequestBody(e.target.value)}
                rows={5}
                className="w-full bg-slate-950 border border-slate-800 rounded p-3 text-slate-200 font-mono text-xs focus:border-blue-500 focus:outline-none"
              />
            </div>
          )}

          {/* Response Inspector */}
          <div className="space-y-1">
            <span className="text-slate-400 text-[10px] font-bold uppercase block">RESPONSE PAYLOAD:</span>
            <div className="bg-black/90 border border-slate-800 rounded p-3 h-[280px] overflow-y-auto font-mono text-[11px] text-emerald-400 whitespace-pre">
              {responseJson || '// Click "TEST ENDPOINT" to send request...'}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
