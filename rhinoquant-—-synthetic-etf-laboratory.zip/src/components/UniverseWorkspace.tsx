import React, { useState, useMemo } from 'react';
import { Security, UniverseRule, EligibilityReport } from '../types';
import { SYNTHETIC_UNIVERSE } from '../engine/securitiesUniverse';
import { evaluateEligibility } from '../engine/indexEngine';
import { Filter, Search, ShieldAlert, CheckCircle, Sliders, Download, Layers } from 'lucide-react';

interface UniverseWorkspaceProps {
  onApplyRulesToConstructor?: (rules: UniverseRule[]) => void;
}

export const UniverseWorkspace: React.FC<UniverseWorkspaceProps> = ({ onApplyRulesToConstructor }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSector, setSelectedSector] = useState<string>('ALL');
  const [selectedCountry, setSelectedCountry] = useState<string>('ALL');

  // Interactive Eligibility Rule Builder State
  const [rules, setRules] = useState<UniverseRule[]>([
    { id: 'r1', field: 'marketCap', operator: '>=', value: 5000 },
    { id: 'r2', field: 'volatility', operator: '<=', value: 0.38 },
    { id: 'r3', field: 'liquidity', operator: '>=', value: 10000000 }
  ]);

  const eligibilityReport: EligibilityReport = useMemo(() => {
    return evaluateEligibility(SYNTHETIC_UNIVERSE, rules);
  }, [rules]);

  // Filtered table data
  const filteredSecurities = useMemo(() => {
    return eligibilityReport.eligibleSecurities.filter(s => {
      const matchSearch = s.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          s.identifier.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          s.industry.toLowerCase().includes(searchTerm.toLowerCase());
      const matchSector = selectedSector === 'ALL' || s.sector === selectedSector;
      const matchCountry = selectedCountry === 'ALL' || s.country === selectedCountry;
      return matchSearch && matchSector && matchCountry;
    });
  }, [eligibilityReport, searchTerm, selectedSector, selectedCountry]);

  const handleAddRule = () => {
    const newRule: UniverseRule = {
      id: `rule-${Date.now()}`,
      field: 'marketCap',
      operator: '>=',
      value: 10000
    };
    setRules([...rules, newRule]);
  };

  const handleRemoveRule = (id: string) => {
    setRules(rules.filter(r => r.id !== id));
  };

  const handleRuleChange = (id: string, updated: Partial<UniverseRule>) => {
    setRules(rules.map(r => r.id === id ? { ...r, ...updated } : r));
  };

  return (
    <div className="p-4 space-y-4 max-w-7xl mx-auto font-mono text-xs">
      {/* Header Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-base font-bold text-slate-100 font-sans">SYNTHETIC SECURITIES UNIVERSE</h1>
          <p className="text-slate-400 text-[11px]">
            Master Universe: <strong className="text-blue-400">250 Synthetic Instruments</strong> Across UK, Europe, US, Asia.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <div className="bg-slate-950 border border-slate-800 px-3 py-1.5 rounded flex items-center space-x-2">
            <span className="text-slate-400">ELIGIBLE:</span>
            <span className="font-bold text-emerald-400 text-sm">{eligibilityReport.passedSecuritiesCount}</span>
            <span className="text-slate-500">/ 250</span>
          </div>

          <button
            onClick={() => {
              const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(filteredSecurities, null, 2));
              const downloadAnchor = document.createElement('a');
              downloadAnchor.setAttribute("href", dataStr);
              downloadAnchor.setAttribute("download", `rhinoquant_universe_${Date.now()}.json`);
              document.body.appendChild(downloadAnchor);
              downloadAnchor.click();
              downloadAnchor.remove();
            }}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded flex items-center space-x-1 cursor-pointer"
          >
            <Download className="h-3.5 w-3.5" />
            <span>EXPORT PARQUET/JSON</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left Panel: Visual Eligibility Rule Builder */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-4 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="font-bold uppercase text-slate-200 flex items-center space-x-1.5">
              <Sliders className="h-4 w-4 text-blue-400" />
              <span>ELIGIBILITY RULE BUILDER</span>
            </span>
            <button
              onClick={handleAddRule}
              className="text-[10px] bg-blue-950 text-blue-400 border border-blue-800 px-2 py-0.5 rounded hover:bg-blue-900 cursor-pointer"
            >
              + ADD RULE
            </button>
          </div>

          <div className="space-y-3">
            {rules.map((rule, idx) => (
              <div key={rule.id} className="bg-slate-950 border border-slate-800 rounded p-2.5 space-y-2">
                <div className="flex items-center justify-between text-[11px] text-slate-400">
                  <span>RULE #{idx + 1}</span>
                  <button onClick={() => handleRemoveRule(rule.id)} className="text-red-400 hover:text-red-300 cursor-pointer">✕</button>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  {/* Field Selector */}
                  <select
                    value={rule.field}
                    onChange={(e) => handleRuleChange(rule.id, { field: e.target.value as any })}
                    className="bg-slate-900 border border-slate-800 text-slate-200 rounded px-2 py-1 text-[11px]"
                  >
                    <option value="marketCap">Market Cap ($M)</option>
                    <option value="volatility">Volatility (Ann.)</option>
                    <option value="beta">Beta vs Mkt</option>
                    <option value="dividendYield">Div Yield</option>
                    <option value="liquidity">30d ADV ($)</option>
                  </select>

                  {/* Operator Selector */}
                  <select
                    value={rule.operator}
                    onChange={(e) => handleRuleChange(rule.id, { operator: e.target.value as any })}
                    className="bg-slate-900 border border-slate-800 text-slate-200 rounded px-2 py-1 text-[11px]"
                  >
                    <option value=">=">&gt;=</option>
                    <option value="<=">&lt;=</option>
                    <option value=">">&gt;</option>
                    <option value="<">&lt;</option>
                  </select>

                  {/* Value Input */}
                  <input
                    type="number"
                    value={rule.value as number}
                    onChange={(e) => handleRuleChange(rule.id, { value: parseFloat(e.target.value) || 0 })}
                    className="bg-slate-900 border border-slate-800 text-slate-200 rounded px-2 py-1 text-[11px] focus:border-blue-500 focus:outline-none"
                  />
                </div>
              </div>
            ))}
          </div>

          {/* Eligibility Report Summary */}
          <div className="bg-slate-950 border border-slate-800 rounded p-3 space-y-2 text-[11px]">
            <span className="font-bold text-slate-300 block uppercase border-b border-slate-800 pb-1">RULE IMPACT REPORT</span>
            {eligibilityReport.appliedRules.map((item, idx) => (
              <div key={idx} className="flex justify-between items-center text-slate-400">
                <span>{item.rule.field} {item.rule.operator} {item.rule.value}:</span>
                <span className="text-emerald-400 font-bold">{item.passedCount} pass</span>
              </div>
            ))}
            <div className="pt-2 border-t border-slate-800 flex justify-between font-bold text-slate-200">
              <span>FINAL REJECTED:</span>
              <span className="text-red-400">{eligibilityReport.rejectedSecuritiesCount}</span>
            </div>
          </div>
        </div>

        {/* Right Panel: Securities Table */}
        <div className="lg:col-span-2 bg-slate-900/80 border border-slate-800 rounded-lg p-4 space-y-3">
          {/* Search & Sector Filters */}
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
            <div className="flex items-center space-x-2 bg-slate-950 border border-slate-800 px-3 py-1.5 rounded w-full sm:w-64">
              <Search className="h-3.5 w-3.5 text-slate-400" />
              <input
                type="text"
                placeholder="Search ticker, name, industry..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="bg-transparent text-slate-200 text-xs focus:outline-none w-full"
              />
            </div>

            <div className="flex items-center space-x-2">
              <span className="text-slate-400 text-[11px]">SECTOR:</span>
              <select
                value={selectedSector}
                onChange={(e) => setSelectedSector(e.target.value)}
                className="bg-slate-950 border border-slate-800 text-slate-200 rounded px-2 py-1 text-xs"
              >
                <option value="ALL">ALL SECTORS</option>
                <option value="INDUSTRIALS">INDUSTRIALS</option>
                <option value="ENERGY">ENERGY</option>
                <option value="TECHNOLOGY">TECHNOLOGY</option>
                <option value="INFRASTRUCTURE">INFRASTRUCTURE</option>
                <option value="FINANCIALS">FINANCIALS</option>
                <option value="UTILITIES">UTILITIES</option>
              </select>

              <select
                value={selectedCountry}
                onChange={(e) => setSelectedCountry(e.target.value)}
                className="bg-slate-950 border border-slate-800 text-slate-200 rounded px-2 py-1 text-xs"
              >
                <option value="ALL">ALL REGIONS</option>
                <option value="UK">UK (GBP)</option>
                <option value="DE">DE (EUR)</option>
                <option value="FR">FR (EUR)</option>
                <option value="US">US (USD)</option>
                <option value="JP">JP (JPY)</option>
              </select>
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto max-h-[500px] overflow-y-auto">
            <table className="w-full text-left text-slate-300">
              <thead className="bg-slate-950 text-slate-400 text-[10px] uppercase sticky top-0 border-b border-slate-800">
                <tr>
                  <th className="py-2 px-2">ID</th>
                  <th className="py-2 px-2">NAME</th>
                  <th className="py-2 px-2">SECTOR</th>
                  <th className="py-2 px-2 text-right">MKT CAP ($M)</th>
                  <th className="py-2 px-2 text-right">PRICE</th>
                  <th className="py-2 px-2 text-right">VOL (ANN)</th>
                  <th className="py-2 px-2 text-right">BETA</th>
                  <th className="py-2 px-2 text-right">DIV YLD</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                {filteredSecurities.map((s) => (
                  <tr key={s.identifier} className="hover:bg-slate-800/40 transition">
                    <td className="py-1.5 px-2 text-blue-400 font-bold">{s.identifier}</td>
                    <td className="py-1.5 px-2 text-slate-200 font-sans max-w-[160px] truncate">{s.name}</td>
                    <td className="py-1.5 px-2">
                      <span className="bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded text-[10px]">
                        {s.sector}
                      </span>
                    </td>
                    <td className="py-1.5 px-2 text-right text-slate-200 font-bold">${s.marketCap.toLocaleString()}</td>
                    <td className="py-1.5 px-2 text-right text-slate-300">${s.price.toFixed(2)}</td>
                    <td className="py-1.5 px-2 text-right text-slate-300">{(s.volatility * 100).toFixed(1)}%</td>
                    <td className="py-1.5 px-2 text-right text-slate-300">{s.beta.toFixed(2)}</td>
                    <td className="py-1.5 px-2 text-right text-emerald-400">{(s.dividendYield * 100).toFixed(2)}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
