import React, { useState, useMemo } from 'react';
import { ETFDefinition, WeightingMethod, RebalanceFrequency, PortfolioHolding, Security } from '../types';
import { SYNTHETIC_UNIVERSE } from '../engine/securitiesUniverse';
import { evaluateEligibility, calculateRawWeights, applyConstraintsAndNormalize } from '../engine/indexEngine';
import { Sliders, CheckCircle, PieChart, Layers, Download, RefreshCw, FileText } from 'lucide-react';

interface ConstructorWorkspaceProps {
  etf: ETFDefinition;
  onUpdateEtf: (updated: ETFDefinition) => void;
}

export const ConstructorWorkspace: React.FC<ConstructorWorkspaceProps> = ({ etf, onUpdateEtf }) => {
  const [weightingMethod, setWeightingMethod] = useState<WeightingMethod>(etf.methodology.weightingMethod);
  const [maxWeight, setMaxWeight] = useState<number>(etf.methodology.constraints.maxConstituentWeight || 0.08);
  const [rebalanceFreq, setRebalanceFreq] = useState<RebalanceFrequency>(etf.rebalanceFrequency);
  const [expenseRatioBps, setExpenseRatioBps] = useState<number>(etf.expenseRatio * 10000);
  const [slippageBps, setSlippageBps] = useState<number>(etf.slippageBps);
  const [minMarketCap, setMinMarketCap] = useState<number>(5000);

  // Re-calculate portfolio holdings live based on parameters
  const holdings: PortfolioHolding[] = useMemo(() => {
    const eligibility = evaluateEligibility(SYNTHETIC_UNIVERSE, [
      { id: 'mktcap', field: 'marketCap', operator: '>=', value: minMarketCap }
    ]);

    const updatedMethodology = {
      weightingMethod,
      constraints: {
        maxConstituentWeight: maxWeight,
        minConstituentWeight: 0.005,
        sectorCaps: etf.methodology.constraints.sectorCaps,
        countryCaps: etf.methodology.constraints.countryCaps,
        turnoverLimit: 0.20,
        liquidityLimit: 0.05
      }
    };

    const raw = calculateRawWeights(eligibility.eligibleSecurities, updatedMethodology);
    return applyConstraintsAndNormalize(raw, updatedMethodology, 100000000);
  }, [weightingMethod, maxWeight, minMarketCap, etf]);

  // Sector breakdown aggregation
  const sectorBreakdown = useMemo(() => {
    const map: Record<string, number> = {};
    holdings.forEach(h => {
      map[h.sector] = (map[h.sector] || 0) + h.weight;
    });
    return Object.entries(map).map(([sector, weight]) => ({
      sector,
      weightPct: Number((weight * 100).toFixed(2))
    })).sort((a, b) => b.weightPct - a.weightPct);
  }, [holdings]);

  const handleApplyChanges = () => {
    const updated: ETFDefinition = {
      ...etf,
      rebalanceFrequency: rebalanceFreq,
      expenseRatio: expenseRatioBps / 10000,
      slippageBps,
      methodology: {
        ...etf.methodology,
        weightingMethod,
        constraints: {
          ...etf.methodology.constraints,
          maxConstituentWeight: maxWeight
        }
      }
    };
    onUpdateEtf(updated);
  };

  return (
    <div className="p-4 space-y-4 max-w-7xl mx-auto font-mono text-xs">
      {/* Header Studio Banner */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-base font-bold text-slate-100 font-sans">SYNTHETIC ETF CONSTRUCTOR STUDIO</h1>
          <p className="text-slate-400 text-[11px]">
            Building <strong className="text-blue-400">{etf.ticker}</strong> — {etf.name}
          </p>
        </div>

        <button
          onClick={handleApplyChanges}
          className="bg-blue-600 hover:bg-blue-500 text-white font-bold px-4 py-2 rounded flex items-center space-x-2 transition cursor-pointer"
        >
          <RefreshCw className="h-4 w-4" />
          <span>RE-CONSTRUCT PORTFOLIO</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column: Methodology Controls */}
        <div className="lg:col-span-5 bg-slate-900/80 border border-slate-800 rounded-lg p-4 space-y-4">
          <span className="font-bold uppercase text-slate-200 block border-b border-slate-800 pb-2">
            METHODOLOGY & PARAMETERS
          </span>

          <div className="space-y-3">
            {/* 1. Weighting Method Picker */}
            <div className="space-y-1">
              <label className="text-slate-400 text-[11px] block">1. WEIGHTING METHODOLOGY:</label>
              <select
                value={weightingMethod}
                onChange={(e) => setWeightingMethod(e.target.value as WeightingMethod)}
                className="w-full bg-slate-950 border border-slate-800 text-slate-100 font-bold rounded px-3 py-1.5 focus:border-blue-500 focus:outline-none cursor-pointer"
              >
                <option value="MARKET_CAP">MARKET_CAP (Market Cap Weighted)</option>
                <option value="INVERSE_VOLATILITY">INVERSE_VOLATILITY (Volatility Adjusted)</option>
                <option value="EQUAL">EQUAL (Equal Weighted 1/N)</option>
                <option value="RISK_PARITY">RISK_PARITY (Equal Risk Contribution)</option>
                <option value="FACTOR">FACTOR (Multi-Factor Score)</option>
                <option value="MOMENTUM">MOMENTUM (12M Momentum Factor)</option>
                <option value="QUALITY">QUALITY (ROIC / Low Debt Quality)</option>
              </select>
            </div>

            {/* 2. Max Constituent Cap Slider */}
            <div className="space-y-1 bg-slate-950 p-2.5 rounded border border-slate-800">
              <div className="flex justify-between items-center text-slate-300">
                <span>2. MAX CONSTITUENT WEIGHT CAP:</span>
                <span className="text-blue-400 font-bold">{(maxWeight * 100).toFixed(1)}%</span>
              </div>
              <input
                type="range"
                min="0.02"
                max="0.25"
                step="0.005"
                value={maxWeight}
                onChange={(e) => setMaxWeight(parseFloat(e.target.value))}
                className="w-full accent-blue-500 cursor-pointer"
              />
            </div>

            {/* 3. Min Universe Market Cap Filter */}
            <div className="space-y-1 bg-slate-950 p-2.5 rounded border border-slate-800">
              <div className="flex justify-between items-center text-slate-300">
                <span>3. MIN MARKET CAP FILTER:</span>
                <span className="text-blue-400 font-bold">${minMarketCap.toLocaleString()}M</span>
              </div>
              <input
                type="range"
                min="1000"
                max="50000"
                step="1000"
                value={minMarketCap}
                onChange={(e) => setMinMarketCap(parseInt(e.target.value))}
                className="w-full accent-blue-500 cursor-pointer"
              />
            </div>

            {/* 4. Rebalance Frequency */}
            <div className="space-y-1">
              <label className="text-slate-400 text-[11px] block">4. REBALANCE FREQUENCY:</label>
              <select
                value={rebalanceFreq}
                onChange={(e) => setRebalanceFreq(e.target.value as RebalanceFrequency)}
                className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded px-3 py-1.5 focus:border-blue-500 focus:outline-none"
              >
                <option value="DAILY">DAILY</option>
                <option value="WEEKLY">WEEKLY</option>
                <option value="MONTHLY">MONTHLY</option>
                <option value="QUARTERLY">QUARTERLY</option>
                <option value="ANNUAL">ANNUAL</option>
              </select>
            </div>

            {/* 5. Fees & Slippage Controls */}
            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800">
              <div>
                <label className="text-slate-400 text-[10px] block">EXPENSE RATIO (BPS):</label>
                <input
                  type="number"
                  value={expenseRatioBps}
                  onChange={(e) => setExpenseRatioBps(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded px-2 py-1 text-xs"
                />
              </div>

              <div>
                <label className="text-slate-400 text-[10px] block">SLIPPAGE (BPS):</label>
                <input
                  type="number"
                  value={slippageBps}
                  onChange={(e) => setSlippageBps(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded px-2 py-1 text-xs"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Live Portfolio Breakdown & Constituent Table */}
        <div className="lg:col-span-7 space-y-4">
          {/* Sector Distribution Bar */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-4 space-y-3">
            <span className="font-bold uppercase text-slate-200 block border-b border-slate-800 pb-2">
              SECTOR DISTRIBUTION ({holdings.length} CONSTITUENTS)
            </span>

            <div className="space-y-2">
              {sectorBreakdown.map(sb => (
                <div key={sb.sector} className="space-y-1">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-slate-300 font-bold">{sb.sector}</span>
                    <span className="text-blue-400">{sb.weightPct}%</span>
                  </div>
                  <div className="w-full bg-slate-950 h-2 rounded overflow-hidden">
                    <div
                      className="bg-blue-500 h-full rounded transition-all duration-300"
                      style={{ width: `${Math.min(sb.weightPct, 100)}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Constituent Holdings Table */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-4 space-y-3">
            <span className="font-bold uppercase text-slate-200 block border-b border-slate-800 pb-2">
              CONSTITUENT WEIGHTS & SHARES ALLOCATION ($100M PORTFOLIO)
            </span>

            <div className="overflow-x-auto max-h-[300px] overflow-y-auto">
              <table className="w-full text-left text-slate-300">
                <thead className="bg-slate-950 text-slate-400 text-[10px] uppercase sticky top-0 border-b border-slate-800">
                  <tr>
                    <th className="py-2 px-2">ID</th>
                    <th className="py-2 px-2">NAME</th>
                    <th className="py-2 px-2 text-right">WEIGHT</th>
                    <th className="py-2 px-2 text-right">SHARES</th>
                    <th className="py-2 px-2 text-right">MARKET VAL</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                  {holdings.map((h) => (
                    <tr key={h.securityIdentifier} className="hover:bg-slate-800/40 transition">
                      <td className="py-1.5 px-2 text-blue-400 font-bold">{h.securityIdentifier}</td>
                      <td className="py-1.5 px-2 text-slate-200 font-sans max-w-[180px] truncate">{h.name}</td>
                      <td className="py-1.5 px-2 text-right font-bold text-emerald-400">{(h.weight * 100).toFixed(2)}%</td>
                      <td className="py-1.5 px-2 text-right text-slate-300">{h.shares.toLocaleString()}</td>
                      <td className="py-1.5 px-2 text-right text-slate-200">${(h.marketValue / 1000000).toFixed(2)}M</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
