import React from 'react';

export type WorkspaceTab = 
  | 'RESEARCH'
  | 'UNIVERSE'
  | 'CONSTRUCT'
  | 'SIMULATE'
  | 'PRICE_NAV'
  | 'RISK'
  | 'ATTRIBUTION'
  | 'SCENARIOS'
  | 'MONTE_CARLO'
  | 'NOTEBOOK'
  | 'REPORTS'
  | 'AUDIT_CLI'
  | 'REST_API';

interface NavigationProps {
  activeTab: WorkspaceTab;
  onTabChange: (tab: WorkspaceTab) => void;
}

const TABS: { id: WorkspaceTab; label: string; badge?: string }[] = [
  { id: 'RESEARCH', label: 'RESEARCH' },
  { id: 'UNIVERSE', label: 'UNIVERSE' },
  { id: 'CONSTRUCT', label: 'CONSTRUCT' },
  { id: 'SIMULATE', label: 'SIMULATE' },
  { id: 'PRICE_NAV', label: 'PRICE & NAV' },
  { id: 'RISK', label: 'RISK' },
  { id: 'ATTRIBUTION', label: 'ATTRIBUTION' },
  { id: 'SCENARIOS', label: 'SCENARIOS' },
  { id: 'MONTE_CARLO', label: 'MONTE CARLO' },
  { id: 'NOTEBOOK', label: 'NOTEBOOK' },
  { id: 'REPORTS', label: 'REPORTS' },
  { id: 'AUDIT_CLI', label: 'AUDIT & CLI' },
  { id: 'REST_API', label: 'REST API' }
];

export const Navigation: React.FC<NavigationProps> = ({ activeTab, onTabChange }) => {
  return (
    <nav className="border-b border-slate-800 bg-[#090d16] px-2 overflow-x-auto no-scrollbar">
      <div className="flex space-x-1 min-w-max py-1.5 font-mono text-xs font-semibold">
        {TABS.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`px-3 py-1.5 rounded transition flex items-center space-x-1.5 cursor-pointer whitespace-nowrap ${
                isActive
                  ? 'bg-blue-600 text-white shadow-sm border border-blue-500'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
