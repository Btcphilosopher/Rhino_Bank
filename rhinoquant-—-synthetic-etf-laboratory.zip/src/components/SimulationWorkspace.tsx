import React, { useState, useMemo } from 'react';
import { Security, SimulationModel } from '../types';
import { SYNTHETIC_UNIVERSE } from '../engine/securitiesUniverse';
import { generateSyntheticPricePaths, analyzeCorrelationMatrix } from '../engine/marketSimulation';
import { Activity, Sliders, Cpu, BarChart2, ShieldCheck, RefreshCw } from 'lucide-react';

export const SimulationWorkspace: React.FC = () => {
  const [model, setModel] = useState<SimulationModel>('GBM');
  const [seed, setSeed] = useState<number>(2026);
  const [horizonDays, setHorizonDays] = useState<number>(252);

  // Generate price paths
  const pricePaths = useMemo(() => {
    return generateSyntheticPricePaths(SYNTHETIC_UNIVERSE.slice(0, 10), model, seed, horizonDays);
  }, [model, seed, horizonDays]);

  // Analyze matrix
  const diagnostics = useMemo(() => {
    return analyzeCorrelationMatrix(SYNTHETIC_UNIVERSE.slice(0, 10));
  }, []);

  const keys = Object.keys(pricePaths);

  return (
    <div className="p-4 space-y-4 max-w-7xl mx-auto font-mono text-xs">
      {/* Header Banner */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-base font-bold text-slate-100 font-sans">SYNTHETIC MARKET SIMULATION ENGINE</h1>
          <p className="text-slate-400 text-[11px]">
            Multi-Asset Stochastic Engine • Deterministic Random Seed <strong className="text-blue-400">{seed}</strong>
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => setSeed(Math.floor(Math.random() * 899999 + 100000))}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded flex items-center space-x-1 cursor-pointer"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            <span>RANDOMIZE SEED</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Model Selector & Parameters */}
        <div className="lg:col-span-4 bg-slate-900/80 border border-slate-800 rounded-lg p-4 space-y-4">
          <span className="font-bold uppercase text-slate-200 block border-b border-slate-800 pb-2">
            STOCHASTIC MODEL ASSUMPTIONS
          </span>

          <div className="space-y-3">
            <div className="space-y-1">
              <label className="text-slate-400 text-[11px] block">STOCHASTIC MODEL:</label>
              <select
                value={model}
                onChange={(e) => setModel(e.target.value as SimulationModel)}
                className="w-full bg-slate-950 border border-slate-800 text-blue-400 font-bold rounded px-3 py-1.5 focus:border-blue-500 focus:outline-none cursor-pointer"
              >
                <option value="GBM">GBM (Geometric Brownian Motion)</option>
                <option value="STOCHASTIC_VOL">STOCHASTIC_VOL (Heston Stochastic Volatility)</option>
                <option value="JUMP_DIFFUSION">JUMP_DIFFUSION (Merton Jump Diffusion)</option>
                <option value="REGIME_SWITCHING">REGIME_SWITCHING (Markov Regime Switching)</option>
                <option value="FACTOR_MODEL">FACTOR_MODEL (Correlated Factor Diffusion)</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-slate-400 text-[11px] block">DETERMINISTIC SEED:</label>
              <input
                type="number"
                value={seed}
                onChange={(e) => setSeed(parseInt(e.target.value) || 2026)}
                className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded px-3 py-1.5 focus:border-blue-500 focus:outline-none"
              />
            </div>

            <div className="space-y-1">
              <label className="text-slate-400 text-[11px] block">HORIZON (TRADING DAYS):</label>
              <select
                value={horizonDays}
                onChange={(e) => setHorizonDays(parseInt(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded px-3 py-1.5 focus:border-blue-500 focus:outline-none"
              >
                <option value="126">126 DAYS (6 MONTHS)</option>
                <option value="252">252 DAYS (1 YEAR)</option>
                <option value="504">504 DAYS (2 YEARS)</option>
              </select>
            </div>

            {/* Model Description Box */}
            <div className="bg-slate-950 p-3 rounded border border-slate-800 text-[11px] text-slate-400 space-y-1">
              <span className="font-bold text-slate-300 block uppercase">MODEL ASSUMPTIONS:</span>
              <p>
                {model === 'GBM' && 'Standard log-normal price diffusion with constant drift and volatility.'}
                {model === 'STOCHASTIC_VOL' && 'Heston model with mean-reverting stochastic variance and fat-tailed return distributions.'}
                {model === 'JUMP_DIFFUSION' && 'Poisson jump arrivals capturing sudden structural market gaps and liquidity shocks.'}
                {model === 'REGIME_SWITCHING' && 'Two-state Markov model alternating between low-volatility bull and high-volatility bear regimes.'}
                {model === 'FACTOR_MODEL' && 'Multi-factor covariance structure driving systematic constituent asset returns.'}
              </p>
            </div>
          </div>

          {/* Matrix Diagnostics */}
          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-2 text-[11px]">
            <span className="font-bold text-slate-300 block uppercase border-b border-slate-800 pb-1">COVARIANCE EIGEN-ANALYSIS</span>
            <div className="flex justify-between text-slate-400">
              <span>POSITIVE DEFINITE:</span>
              <span className="text-emerald-400 font-bold">{diagnostics.isPositiveDefinite ? 'YES (VALIDATED)' : 'NO'}</span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>CONDITION NUMBER:</span>
              <span className="text-blue-400 font-bold">{diagnostics.conditionNumber}</span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>MAX EIGENVALUE:</span>
              <span className="text-slate-200">{diagnostics.eigenvalues[0]}</span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>MIN EIGENVALUE:</span>
              <span className="text-slate-200">{diagnostics.eigenvalues[diagnostics.eigenvalues.length - 1]}</span>
            </div>
          </div>
        </div>

        {/* Price Path Visualizer Chart */}
        <div className="lg:col-span-8 bg-slate-900/80 border border-slate-800 rounded-lg p-4 space-y-4">
          <span className="font-bold uppercase text-slate-200 block border-b border-slate-800 pb-2">
            SIMULATED ASSET PRICE PATHS (SAMPLE 8 SECURITIES)
          </span>

          {/* SVG Price Paths Chart */}
          <div className="bg-slate-950 p-3 rounded border border-slate-800 h-[360px] flex flex-col justify-between relative">
            <svg className="w-full h-full overflow-visible" viewBox="0 0 500 250" preserveAspectRatio="none">
              {/* Grid Lines */}
              <line x1="0" y1="50" x2="500" y2="50" stroke="#1e293b" strokeDasharray="3 3" />
              <line x1="0" y1="100" x2="500" y2="100" stroke="#1e293b" strokeDasharray="3 3" />
              <line x1="0" y1="150" x2="500" y2="150" stroke="#1e293b" strokeDasharray="3 3" />
              <line x1="0" y1="200" x2="500" y2="200" stroke="#1e293b" strokeDasharray="3 3" />

              {/* Paths */}
              {keys.slice(0, 8).map((secKey, idx) => {
                const path = pricePaths[secKey];
                if (!path || path.length === 0) return null;

                const minVal = 10;
                const maxVal = 500;
                const points = path.map((val, t) => {
                  const x = (t / (horizonDays - 1)) * 500;
                  const y = 250 - ((val - minVal) / (maxVal - minVal)) * 230 - 10;
                  return `${x.toFixed(1)},${y.toFixed(1)}`;
                }).join(' ');

                const colors = ['#3b82f6', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6', '#06b6d4', '#f97316', '#64748b'];

                return (
                  <polyline
                    key={secKey}
                    fill="none"
                    stroke={colors[idx % colors.length]}
                    strokeWidth="1.5"
                    points={points}
                    opacity="0.85"
                  />
                );
              })}
            </svg>

            <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-2">
              <span>DAY 0</span>
              <span>DAY {Math.floor(horizonDays / 2)}</span>
              <span>DAY {horizonDays}</span>
            </div>
          </div>

          {/* Legend */}
          <div className="flex flex-wrap gap-2 text-[10px]">
            {keys.slice(0, 8).map((secKey, idx) => {
              const colors = ['#3b82f6', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6', '#06b6d4', '#f97316', '#64748b'];
              return (
                <div key={secKey} className="flex items-center space-x-1.5 bg-slate-950 border border-slate-800 px-2 py-0.5 rounded">
                  <span className="h-2 w-2 rounded-full" style={{ backgroundColor: colors[idx % colors.length] }} />
                  <span className="text-slate-300 font-bold">{secKey}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
