import { ResearchProject, ETFDefinition, AuditRecord } from '../types';
import { SYNTHETIC_UNIVERSE } from '../engine/securitiesUniverse';
import { evaluateEligibility, calculateRawWeights, applyConstraintsAndNormalize } from '../engine/indexEngine';

export const INITIAL_ETFS: ETFDefinition[] = [
  {
    id: 'RQ-IND',
    ticker: 'RQ-IND',
    name: 'RhinoQuant European Industrial Infrastructure Synthetic ETF',
    description: 'Construct a synthetic ETF representing European industrial infrastructure with volatility-adjusted weighting and quarterly rebalancing.',
    baseCurrency: 'EUR',
    benchmarkId: 'STOXX-EUROPE-600-IND',
    universeId: 'UNIV-EU-IND',
    methodology: {
      weightingMethod: 'INVERSE_VOLATILITY',
      constraints: {
        maxConstituentWeight: 0.08, // 8% cap
        minConstituentWeight: 0.005,
        sectorCaps: { INDUSTRIALS: 0.60, INFRASTRUCTURE: 0.40 },
        countryCaps: { UK: 0.35, DE: 0.35, FR: 0.30 },
        turnoverLimit: 0.20,
        liquidityLimit: 0.05
      }
    },
    rebalanceFrequency: 'QUARTERLY',
    expenseRatio: 0.0035, // 35 bps
    managementFee: 0.0015,
    slippageBps: 5,
    spreadBps: 4,
    commissionBps: 1.5,
    dividendPolicy: 'REINVEST',
    cashTargetPct: 0.01,
    creationRedemptionFeeBps: 2.0
  },
  {
    id: 'RQ100',
    ticker: 'RQ100',
    name: 'RhinoQuant Broad Synthetic Top 100 Equity ETF',
    description: 'Broad market float-adjusted synthetic index ETF tracking top 100 global securities.',
    baseCurrency: 'USD',
    benchmarkId: 'MSCI-WORLD-100',
    universeId: 'UNIV-GLOBAL-TOP',
    methodology: {
      weightingMethod: 'MARKET_CAP',
      constraints: {
        maxConstituentWeight: 0.10,
        minConstituentWeight: 0.002,
        sectorCaps: {},
        countryCaps: {},
        turnoverLimit: 0.15,
        liquidityLimit: 0.05
      }
    },
    rebalanceFrequency: 'QUARTERLY',
    expenseRatio: 0.0015,
    managementFee: 0.0005,
    slippageBps: 3,
    spreadBps: 2,
    commissionBps: 1.0,
    dividendPolicy: 'REINVEST',
    cashTargetPct: 0.005,
    creationRedemptionFeeBps: 1.5
  },
  {
    id: 'RQ-AI',
    ticker: 'RQ-AI',
    name: 'RhinoQuant Synthetic Artificial Intelligence & Compute ETF',
    description: 'High-beta synthetic technology ETF capturing hardware, semiconductors, software, and energy grid compute demand.',
    baseCurrency: 'USD',
    benchmarkId: 'NASDAQ-100-TECH',
    universeId: 'UNIV-TECH-AI',
    methodology: {
      weightingMethod: 'FACTOR',
      targetFactors: ['quality', 'momentum'],
      constraints: {
        maxConstituentWeight: 0.12,
        minConstituentWeight: 0.01,
        sectorCaps: { TECHNOLOGY: 0.75 },
        countryCaps: {},
        turnoverLimit: 0.30,
        liquidityLimit: 0.08
      }
    },
    rebalanceFrequency: 'MONTHLY',
    expenseRatio: 0.0045,
    managementFee: 0.0020,
    slippageBps: 8,
    spreadBps: 6,
    commissionBps: 2.0,
    dividendPolicy: 'REINVEST',
    cashTargetPct: 0.015,
    creationRedemptionFeeBps: 2.5
  },
  {
    id: 'RQ-RAIL',
    ticker: 'RQ-RAIL',
    name: 'RhinoQuant Synthetic Railway & Freight Transit ETF',
    description: 'Specialised industrial transport ETF tracking railway infrastructure, rolling stock, and freight logistics.',
    baseCurrency: 'GBP',
    benchmarkId: 'FTSE-RAIL-LOGISTICS',
    universeId: 'UNIV-UK-RAIL',
    methodology: {
      weightingMethod: 'EQUAL',
      constraints: {
        maxConstituentWeight: 0.10,
        minConstituentWeight: 0.02,
        sectorCaps: {},
        countryCaps: {},
        turnoverLimit: 0.20,
        liquidityLimit: 0.05
      }
    },
    rebalanceFrequency: 'SEMI_ANNUAL' as any,
    expenseRatio: 0.0040,
    managementFee: 0.0018,
    slippageBps: 6,
    spreadBps: 5,
    commissionBps: 2.0,
    dividendPolicy: 'DISTRIBUTE',
    cashTargetPct: 0.02,
    creationRedemptionFeeBps: 3.0
  },
  {
    id: 'RQ-ENERGY',
    ticker: 'RQ-ENERGY',
    name: 'RhinoQuant Synthetic Clean Grid & Energy Transition ETF',
    description: 'Equal-risk parity synthetic energy ETF balancing oil majors, hydrogen, solar grid, and nuclear technology.',
    baseCurrency: 'EUR',
    benchmarkId: 'EURO-ENERGY-COMPOSITE',
    universeId: 'UNIV-ENERGY-TRANSITION',
    methodology: {
      weightingMethod: 'RISK_PARITY',
      constraints: {
        maxConstituentWeight: 0.09,
        minConstituentWeight: 0.01,
        sectorCaps: { ENERGY: 0.60, UTILITIES: 0.40 },
        countryCaps: {},
        turnoverLimit: 0.25,
        liquidityLimit: 0.05
      }
    },
    rebalanceFrequency: 'QUARTERLY',
    expenseRatio: 0.0038,
    managementFee: 0.0016,
    slippageBps: 6,
    spreadBps: 4,
    commissionBps: 1.8,
    dividendPolicy: 'REINVEST',
    cashTargetPct: 0.01,
    creationRedemptionFeeBps: 2.2
  },
  {
    id: 'RQ-VALUE',
    ticker: 'RQ-VALUE',
    name: 'RhinoQuant Synthetic Deep Value Factor ETF',
    description: 'Systematic value factor ETF selecting lowest P/E and highest FCF yield equities with profitability quality screens.',
    baseCurrency: 'USD',
    benchmarkId: 'MSCI-WORLD-VALUE',
    universeId: 'UNIV-GLOBAL-VALUE',
    methodology: {
      weightingMethod: 'FACTOR',
      targetFactors: ['value', 'quality'],
      constraints: {
        maxConstituentWeight: 0.05,
        minConstituentWeight: 0.005,
        sectorCaps: {},
        countryCaps: {},
        turnoverLimit: 0.35,
        liquidityLimit: 0.04
      }
    },
    rebalanceFrequency: 'SEMI_ANNUAL' as any,
    expenseRatio: 0.0030,
    managementFee: 0.0012,
    slippageBps: 4,
    spreadBps: 3,
    commissionBps: 1.2,
    dividendPolicy: 'DISTRIBUTE',
    cashTargetPct: 0.01,
    creationRedemptionFeeBps: 2.0
  },
  {
    id: 'RQ-QUALITY',
    ticker: 'RQ-QUALITY',
    name: 'RhinoQuant Synthetic High Quality Factor ETF',
    description: 'Targeting robust balance sheets, low debt-to-equity, and steady return on invested capital.',
    baseCurrency: 'USD',
    benchmarkId: 'MSCI-QUALITY-INDEX',
    universeId: 'UNIV-QUALITY-HIGH',
    methodology: {
      weightingMethod: 'QUALITY',
      constraints: {
        maxConstituentWeight: 0.06,
        minConstituentWeight: 0.005,
        sectorCaps: {},
        countryCaps: {},
        turnoverLimit: 0.20,
        liquidityLimit: 0.05
      }
    },
    rebalanceFrequency: 'ANNUAL',
    expenseRatio: 0.0025,
    managementFee: 0.0010,
    slippageBps: 3,
    spreadBps: 3,
    commissionBps: 1.0,
    dividendPolicy: 'REINVEST',
    cashTargetPct: 0.005,
    creationRedemptionFeeBps: 1.8
  },
  {
    id: 'RQ-LOWVOL',
    ticker: 'RQ-LOWVOL',
    name: 'RhinoQuant Synthetic Minimum Volatility ETF',
    description: 'Optimised minimum-variance portfolio minimizing forecast variance via covariance estimation.',
    baseCurrency: 'EUR',
    benchmarkId: 'STOXX-LOW-VOLATILITY',
    universeId: 'UNIV-LOWVOL-EU',
    methodology: {
      weightingMethod: 'INVERSE_VOLATILITY',
      constraints: {
        maxConstituentWeight: 0.04,
        minConstituentWeight: 0.005,
        sectorCaps: { UTILITIES: 0.30, CONSUMER: 0.30 },
        countryCaps: {},
        turnoverLimit: 0.25,
        liquidityLimit: 0.03
      }
    },
    rebalanceFrequency: 'QUARTERLY',
    expenseRatio: 0.0028,
    managementFee: 0.0010,
    slippageBps: 3,
    spreadBps: 3,
    commissionBps: 1.0,
    dividendPolicy: 'REINVEST',
    cashTargetPct: 0.005,
    creationRedemptionFeeBps: 1.5
  },
  {
    id: 'RQ-GLOBAL',
    ticker: 'RQ-GLOBAL',
    name: 'RhinoQuant Synthetic Global Diversified Equity ETF',
    description: 'Multi-country, multi-currency synthetic global equity index across 10 sovereign jurisdictions.',
    baseCurrency: 'USD',
    benchmarkId: 'FTSE-ALL-WORLD',
    universeId: 'UNIV-GLOBAL-ALL',
    methodology: {
      weightingMethod: 'MARKET_CAP',
      constraints: {
        maxConstituentWeight: 0.07,
        minConstituentWeight: 0.001,
        sectorCaps: {},
        countryCaps: { US: 0.55, UK: 0.15, DE: 0.10, JP: 0.10 },
        turnoverLimit: 0.10,
        liquidityLimit: 0.05
      }
    },
    rebalanceFrequency: 'QUARTERLY',
    expenseRatio: 0.0012,
    managementFee: 0.0004,
    slippageBps: 2,
    spreadBps: 2,
    commissionBps: 0.8,
    dividendPolicy: 'REINVEST',
    cashTargetPct: 0.005,
    creationRedemptionFeeBps: 1.2
  },
  {
    id: 'RQ-UKINFRA',
    ticker: 'RQ-UKINFRA',
    name: 'RhinoQuant Synthetic UK Sovereign Infrastructure ETF',
    description: 'Sterling-denominated synthetic fund tracking UK ports, clean power grids, water networks, and telecom towers.',
    baseCurrency: 'GBP',
    benchmarkId: 'FTSE-UK-INFRASTRUCTURE',
    universeId: 'UNIV-UK-INFRA',
    methodology: {
      weightingMethod: 'EQUAL',
      constraints: {
        maxConstituentWeight: 0.12,
        minConstituentWeight: 0.02,
        sectorCaps: { INFRASTRUCTURE: 0.70, UTILITIES: 0.30 },
        countryCaps: { UK: 1.00 },
        turnoverLimit: 0.15,
        liquidityLimit: 0.05
      }
    },
    rebalanceFrequency: 'QUARTERLY',
    expenseRatio: 0.0032,
    managementFee: 0.0012,
    slippageBps: 4,
    spreadBps: 3,
    commissionBps: 1.2,
    dividendPolicy: 'DISTRIBUTE',
    cashTargetPct: 0.01,
    creationRedemptionFeeBps: 2.0
  }
];

export const INITIAL_RESEARCH_PROJECTS: ResearchProject[] = [
  {
    id: 'RQ-ETF-00041',
    title: 'European Industrial Infrastructure Volatility-Weighted Strategy',
    version: 'v1.0',
    status: 'PUBLISHED',
    isImmutable: true,
    hypothesis: 'Construct a synthetic ETF representing European industrial infrastructure with volatility-adjusted weighting and quarterly rebalancing to reduce tail drawdown risk.',
    universeId: 'UNIV-EU-IND',
    etfDefinition: INITIAL_ETFS[0],
    simulationModel: 'GBM',
    randomSeed: 2026,
    horizonDays: 252,
    scenarioIds: ['SCEN-EQ-01', 'SCEN-RATE-01', 'SCEN-VOL-01', 'SCEN-LIQ-01'],
    notes: 'Published initial research version v1.0. Backtested against STOXX Europe 600 Industrials benchmark. Rebalance drag estimated at 18 bps per annum.',
    createdAt: '2026-10-01T09:15:00Z',
    updatedAt: '2026-10-01T14:30:00Z',
    manifestHash: '0x8f3a12b9005251348f3a'
  },
  {
    id: 'RQ-ETF-00042',
    title: 'Synthetic AI Hardware & Grid Power Compute Factor ETF',
    version: 'v1.1',
    status: 'PUBLISHED',
    isImmutable: true,
    hypothesis: 'High-beta momentum and quality factor tilt on semiconductor and grid power infrastructure equity basket.',
    universeId: 'UNIV-TECH-AI',
    etfDefinition: INITIAL_ETFS[2],
    simulationModel: 'STOCHASTIC_VOL',
    randomSeed: 91823,
    horizonDays: 252,
    scenarioIds: ['SCEN-VOL-01', 'SCEN-RATE-01', 'SCEN-SEC-01'],
    notes: 'Tested under stochastic volatility (Heston model). High momentum factor exposure results in 18.2% forecast volatility.',
    createdAt: '2026-10-02T10:00:00Z',
    updatedAt: '2026-10-02T16:00:00Z',
    manifestHash: '0x41e8c7120052513441e8'
  }
];

export const INITIAL_AUDIT_LOGS: AuditRecord[] = [
  {
    id: 'AUD-901',
    timestamp: '2026-10-01T09:15:00Z',
    actor: 'DR_HENRY_VANE_QUANT',
    action: 'CREATE_RESEARCH_PROJECT',
    objectType: 'RESEARCH',
    objectId: 'RQ-ETF-00041',
    details: 'Formulated hypothesis: European Industrial Infrastructure with Volatility-Adjusted Weighting.',
    manifestHash: '0x8f3a12b9005251348f3a'
  },
  {
    id: 'AUD-902',
    timestamp: '2026-10-01T11:20:00Z',
    actor: 'DR_HENRY_VANE_QUANT',
    action: 'CONSTRUCT_ETF',
    objectType: 'ETF',
    objectId: 'RQ-IND',
    details: 'Applied 8.0% max constituent cap, inverse vol weighting, and quarterly rebalance frequency.',
    manifestHash: '0x8f3a12b9005251348f3a'
  },
  {
    id: 'AUD-903',
    timestamp: '2026-10-01T14:30:00Z',
    actor: 'DR_HENRY_VANE_QUANT',
    action: 'PUBLISH_RESEARCH_VERSION',
    objectType: 'RESEARCH',
    objectId: 'RQ-ETF-00041',
    details: 'Locked version v1.0 as immutable research manifest object.',
    manifestHash: '0x8f3a12b9005251348f3a'
  }
];
