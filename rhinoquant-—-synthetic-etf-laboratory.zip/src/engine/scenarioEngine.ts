import { StressScenario, ScenarioResult, PortfolioHolding } from '../types';

export const PRESET_SCENARIOS: StressScenario[] = [
  {
    id: 'SCEN-EQ-01',
    name: 'EQUITY SHOCK',
    type: 'EQUITY_SHOCK',
    description: 'Severe global equity downturn (-20.0% broad market drawdown with high beta amplification).',
    shocks: { broadMarketPct: -0.20, volatilityMultiplier: 2.2, rateShiftBps: -50, spreadMultiplier: 3.0 }
  },
  {
    id: 'SCEN-RATE-01',
    name: 'RATE SHOCK',
    type: 'RATE_SHOCK',
    description: 'Aggressive Central Bank monetary tightening (+200 bps hawkish surprise across yield curve).',
    shocks: { broadMarketPct: -0.08, volatilityMultiplier: 1.5, rateShiftBps: 200, spreadMultiplier: 1.8 }
  },
  {
    id: 'SCEN-VOL-01',
    name: 'VOLATILITY SPIKE',
    type: 'VOLATILITY_SHOCK',
    description: 'VIX double-spike event (+100% implied volatility jump with option market dislocation).',
    shocks: { broadMarketPct: -0.12, volatilityMultiplier: 2.5, rateShiftBps: 0, spreadMultiplier: 2.5 }
  },
  {
    id: 'SCEN-LIQ-01',
    name: 'LIQUIDITY CRISIS',
    type: 'LIQUIDITY_CRISIS',
    description: 'Primary/Secondary market liquidity freeze with AP creation basket arbitrage breakdown.',
    shocks: { broadMarketPct: -0.15, volatilityMultiplier: 2.0, rateShiftBps: -25, spreadMultiplier: 6.0 }
  },
  {
    id: 'SCEN-CORR-01',
    name: 'CORRELATION BREAK',
    type: 'CORRELATION_BREAK',
    description: 'Diversification collapse with all constituent asset correlations approaching 1.0.',
    shocks: { broadMarketPct: -0.18, volatilityMultiplier: 1.8, rateShiftBps: 25, spreadMultiplier: 2.0 }
  },
  {
    id: 'SCEN-SEC-01',
    name: 'SECTOR COLLAPSE',
    type: 'SECTOR_COLLAPSE',
    description: 'Targeted sector regulatory and supply chain shock (-35.0% sector drawdown).',
    shocks: {
      broadMarketPct: -0.06,
      sectorShocksPct: { INDUSTRIALS: -0.35, ENERGY: -0.28, INFRASTRUCTURE: -0.30 },
      volatilityMultiplier: 1.9,
      rateShiftBps: 0,
      spreadMultiplier: 2.2
    }
  },
  {
    id: 'SCEN-RISKOFF-01',
    name: 'GLOBAL RISK-OFF',
    type: 'GLOBAL_RISK_OFF',
    description: 'Geopolitical panic driving safe-haven capital flight into sovereign debt and USD.',
    shocks: { broadMarketPct: -0.22, volatilityMultiplier: 2.8, rateShiftBps: -100, spreadMultiplier: 3.5 }
  },
  {
    id: 'SCEN-INFL-01',
    name: 'INFLATION SHOCK',
    type: 'INFLATION_SHOCK',
    description: 'Stagflationary commodity shock (+40% energy prices with margin compression).',
    shocks: { broadMarketPct: -0.10, volatilityMultiplier: 1.6, rateShiftBps: 150, spreadMultiplier: 2.0 }
  }
];

/**
 * Execute stress scenario on portfolio holdings
 */
export function runStressScenario(
  scenario: StressScenario,
  holdings: PortfolioHolding[]
): ScenarioResult {
  const { broadMarketPct, sectorShocksPct, spreadMultiplier } = scenario.shocks;

  let weightedReturn = 0;

  holdings.forEach(h => {
    let shockPct = broadMarketPct * h.beta;

    if (sectorShocksPct && sectorShocksPct[h.sector]) {
      shockPct = sectorShocksPct[h.sector];
    }

    weightedReturn += h.weight * shockPct;
  });

  const bmkReturn = broadMarketPct;
  const etfReturnPct = Number((weightedReturn * 100).toFixed(2));
  const benchmarkReturnPct = Number((bmkReturn * 100).toFixed(2));
  const navChangePct = etfReturnPct;
  const trackingErrorPct = Number((Math.abs(etfReturnPct - benchmarkReturnPct) * 0.4 + 0.5).toFixed(2));
  const maxDrawdownPct = Number((Math.min(etfReturnPct * 1.2, etfReturnPct)).toFixed(2));
  const liquidityImpactBps = Number((5 * spreadMultiplier * 3.5).toFixed(1));

  return {
    scenarioId: scenario.id,
    scenarioName: scenario.name,
    etfReturnPct,
    benchmarkReturnPct,
    navChangePct,
    trackingErrorPct,
    maxDrawdownPct,
    liquidityImpactBps,
    factorImpacts: {
      market: Number((etfReturnPct * 0.8).toFixed(2)),
      size: -1.2,
      value: 0.8,
      momentum: -2.5,
      quality: 1.4,
      lowVol: 2.1,
      sectorResidual: -0.5,
      alpha: 0.2
    }
  };
}
