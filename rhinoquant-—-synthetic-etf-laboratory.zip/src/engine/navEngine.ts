import { ETFDefinition, PortfolioHolding, NAVPoint, SecondaryMarketState, CreationRedemptionOrder } from '../types';

/**
 * Simulate daily NAV time series given price paths, expense ratios, rebalance frequency, and transaction costs
 */
export function simulateEtfNavSeries(
  etf: ETFDefinition,
  initialHoldings: PortfolioHolding[],
  pricePaths: Record<string, number[]>,
  horizonDays: number = 252
): NAVPoint[] {
  const navPoints: NAVPoint[] = [];

  let currentNavPerShare = 100.0;
  let currentIndexValue = 100.0;
  let currentBenchmarkValue = 100.0;
  let totalSharesOutstanding = 1000000; // 1M shares initial
  let totalPortfolioValue = currentNavPerShare * totalSharesOutstanding;

  let cashBalance = totalPortfolioValue * etf.cashTargetPct;
  let accruedDividends = 0;
  let cumulativeFees = 0;
  let cumulativeTransactionCosts = 0;
  let rebalanceDragTotal = 0;

  const dailyExpenseRatio = (etf.expenseRatio + etf.managementFee) / 252;
  const rebalanceIntervalDays = etf.rebalanceFrequency === 'DAILY' ? 1 
    : etf.rebalanceFrequency === 'WEEKLY' ? 5 
    : etf.rebalanceFrequency === 'MONTHLY' ? 21 
    : etf.rebalanceFrequency === 'QUARTERLY' ? 63 
    : 252;

  // Track holdings quantities
  let holdings = initialHoldings.map(h => ({ ...h }));

  for (let day = 0; day < horizonDays; day++) {
    // 1. Calculate constituent asset price moves for today
    let weightedAssetReturn = 0;
    let benchmarkReturn = 0;

    let grossEquitiesValue = 0;

    holdings.forEach(h => {
      const path = pricePaths[h.securityIdentifier];
      if (path && path[day]) {
        const todayPrice = path[day];
        const prevPrice = day > 0 ? path[day - 1] : path[0];
        const assetReturn = (todayPrice - prevPrice) / prevPrice;
        
        weightedAssetReturn += h.weight * assetReturn;
        h.price = todayPrice;
        h.marketValue = h.shares * todayPrice;
        grossEquitiesValue += h.marketValue;

        // Dividend accrual (annualized yield / 252)
        const dailyDivYield = h.dividendYield / 252;
        accruedDividends += h.marketValue * dailyDivYield;
      }
    });

    // Synthetic benchmark move
    const samplePathKey = Object.keys(pricePaths)[0];
    if (samplePathKey && pricePaths[samplePathKey][day]) {
      const pToday = pricePaths[samplePathKey][day];
      const pPrev = day > 0 ? pricePaths[samplePathKey][day - 1] : pToday;
      benchmarkReturn = 0.85 * weightedAssetReturn + 0.15 * ((pToday - pPrev) / pPrev);
    } else {
      benchmarkReturn = weightedAssetReturn;
    }

    currentIndexValue *= (1 + weightedAssetReturn);
    currentBenchmarkValue *= (1 + benchmarkReturn);

    // 2. Rebalancing check
    if (day > 0 && day % rebalanceIntervalDays === 0) {
      // Rebalance back to target weights
      let rebalanceVolume = 0;
      const targetEquitiesVal = totalPortfolioValue * (1 - etf.cashTargetPct);
      
      holdings.forEach(h => {
        const targetVal = targetEquitiesVal * h.weight;
        const currentVal = h.shares * h.price;
        const diffVal = Math.abs(targetVal - currentVal);
        rebalanceVolume += diffVal;
        h.shares = Math.floor(targetVal / h.price);
      });

      // Apply slippage + commission friction
      const totalFrictionBps = etf.slippageBps + etf.commissionBps;
      const rebalanceCost = rebalanceVolume * (totalFrictionBps / 10000);
      cumulativeTransactionCosts += rebalanceCost;
      rebalanceDragTotal += rebalanceCost;
      cashBalance = Math.max(0, cashBalance - rebalanceCost);
    }

    // 3. Fee drag
    const dailyFeeAmount = (grossEquitiesValue + cashBalance) * dailyExpenseRatio;
    cumulativeFees += dailyFeeAmount;
    cashBalance = Math.max(0, cashBalance - dailyFeeAmount);

    // 4. Update Portfolio Total Value & NAV
    totalPortfolioValue = grossEquitiesValue + cashBalance + accruedDividends;
    currentNavPerShare = totalPortfolioValue / totalSharesOutstanding;

    // 5. Secondary market price simulation (nav + noise / spread / liquidity impact)
    const marketNoise = Math.sin(day * 0.3) * 0.0015;
    const marketPrice = currentNavPerShare * (1 + marketNoise + (etf.spreadBps / 20000));
    const premiumDiscountPct = ((marketPrice - currentNavPerShare) / currentNavPerShare) * 100;
    const trackingDiffPct = ((currentNavPerShare - currentBenchmarkValue) / currentBenchmarkValue) * 100;

    const dateStr = new Date(Date.now() + day * 86400000).toISOString().split('T')[0];

    navPoints.push({
      day,
      date: dateStr,
      navPerShare: Number(currentNavPerShare.toFixed(2)),
      indexValue: Number(currentIndexValue.toFixed(2)),
      benchmarkValue: Number(currentBenchmarkValue.toFixed(2)),
      cashBalance: Number(cashBalance.toFixed(2)),
      accruedDividends: Number(accruedDividends.toFixed(2)),
      cumulativeFees: Number(cumulativeFees.toFixed(2)),
      cumulativeTransactionCosts: Number(cumulativeTransactionCosts.toFixed(2)),
      rebalanceDrag: Number(rebalanceDragTotal.toFixed(2)),
      trackingDifferencePct: Number(trackingDiffPct.toFixed(3)),
      marketPrice: Number(marketPrice.toFixed(2)),
      premiumDiscountPct: Number(premiumDiscountPct.toFixed(3))
    });
  }

  return navPoints;
}

/**
 * Generate synthetic order book for secondary market simulation
 */
export function generateOrderBook(navPerShare: number, spreadBps: number = 5): SecondaryMarketState {
  const halfSpread = (navPerShare * (spreadBps / 10000)) / 2;
  const bidPrice = Number((navPerShare - halfSpread).toFixed(2));
  const askPrice = Number((navPerShare + halfSpread).toFixed(2));
  const midPrice = Number(navPerShare.toFixed(2));

  const bidDepth = [
    { price: Number((bidPrice - 0.01).toFixed(2)), size: 12500, ordersCount: 8 },
    { price: Number((bidPrice - 0.03).toFixed(2)), size: 28000, ordersCount: 14 },
    { price: Number((bidPrice - 0.05).toFixed(2)), size: 45000, ordersCount: 22 },
    { price: Number((bidPrice - 0.08).toFixed(2)), size: 82000, ordersCount: 35 },
    { price: Number((bidPrice - 0.12).toFixed(2)), size: 150000, ordersCount: 50 }
  ];

  const askDepth = [
    { price: Number((askPrice + 0.01).toFixed(2)), size: 14000, ordersCount: 9 },
    { price: Number((askPrice + 0.03).toFixed(2)), size: 31000, ordersCount: 16 },
    { price: Number((askPrice + 0.05).toFixed(2)), size: 48000, ordersCount: 24 },
    { price: Number((askPrice + 0.08).toFixed(2)), size: 90000, ordersCount: 38 },
    { price: Number((askPrice + 0.12).toFixed(2)), size: 165000, ordersCount: 54 }
  ];

  return {
    bidPrice,
    askPrice,
    midPrice,
    spreadBps,
    lastTradedPrice: Number((midPrice + 0.01).toFixed(2)),
    volume24h: 485000,
    premiumDiscountPct: Number((((midPrice - navPerShare) / navPerShare) * 100).toFixed(3)),
    bidDepth,
    askDepth
  };
}

/**
 * Simulate Authorised Participant Creation/Redemption Order
 */
export function simulateCreationRedemption(
  etf: ETFDefinition,
  holdings: PortfolioHolding[],
  type: 'CREATION' | 'REDEMPTION',
  sharesCount: number = 50000
): CreationRedemptionOrder {
  const latestNav = 100.42;
  const totalNavValue = sharesCount * latestNav;
  const creationFee = totalNavValue * (etf.creationRedemptionFeeBps / 10000);

  const basketComponents = holdings.slice(0, 8).map(h => {
    const componentValue = totalNavValue * h.weight;
    const requiredShares = Math.floor(componentValue / h.price);
    return {
      securityIdentifier: h.securityIdentifier,
      requiredShares,
      value: Number((requiredShares * h.price).toFixed(2))
    };
  });

  const basketEquitiesValue = basketComponents.reduce((acc, c) => acc + c.value, 0);
  const cashComponent = Number((totalNavValue - basketEquitiesValue).toFixed(2));

  return {
    id: `ORD-AP-${Math.floor(Math.random() * 899999 + 100000)}`,
    type,
    apIdentifier: 'AP-BARCLAYS-CAPITAL-01',
    shares: sharesCount,
    totalNavValue: Number(totalNavValue.toFixed(2)),
    cashInLieuPct: etf.cashTargetPct * 100,
    creationFee: Number(creationFee.toFixed(2)),
    basketComponents,
    cashComponent,
    status: 'SETTLED',
    timestamp: new Date().toISOString()
  };
}
