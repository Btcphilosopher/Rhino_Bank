import { Security, SimulationModel } from '../types';

export interface MatrixDiagnostics {
  isPositiveDefinite: boolean;
  eigenvalues: number[];
  conditionNumber: number;
  correlationMatrix: number[][];
  securityIds: string[];
}

/**
 * Deterministic Box-Muller transformation for Gaussian random variables
 */
function boxMuller(u1: number, u2: number): [number, number] {
  const z0 = Math.sqrt(-2.0 * Math.log(Math.max(u1, 1e-12))) * Math.cos(2.0 * Math.PI * u2);
  const z1 = Math.sqrt(-2.0 * Math.log(Math.max(u1, 1e-12))) * Math.sin(2.0 * Math.PI * u2);
  return [z0, z1];
}

class PRNG {
  private state: number;

  constructor(seed: number = 42) {
    this.state = seed;
  }

  public next(): number {
    this.state = (this.state * 1664525 + 1013904223) % 4294967296;
    return this.state / 4294967296;
  }

  public nextGaussian(): number {
    const u1 = Math.max(this.next(), 1e-10);
    const u2 = this.next();
    return boxMuller(u1, u2)[0];
  }
}

/**
 * Generate multi-asset correlated price series over a given time horizon (e.g. 252 trading days)
 */
export function generateSyntheticPricePaths(
  securities: Security[],
  model: SimulationModel = 'GBM',
  seed: number = 2026,
  horizonDays: number = 252
): Record<string, number[]> {
  const prng = new PRNG(seed);
  const dt = 1 / 252;
  const sqrtDt = Math.sqrt(dt);

  const pricePaths: Record<string, number[]> = {};

  // Market factor shock for correlation
  const marketShocks: number[] = [];
  for (let t = 0; t < horizonDays; t++) {
    marketShocks.push(prng.nextGaussian());
  }

  securities.forEach(security => {
    const path: number[] = [security.price];
    let currentPrice = security.price;
    const mu = 0.08 + (security.beta - 1.0) * 0.04 + security.dividendYield; // Expected return
    const vol = security.volatility;
    let currentVol = vol;

    for (let t = 1; t < horizonDays; t++) {
      const zMarket = marketShocks[t];
      const zIdiosyncratic = prng.nextGaussian();

      // Beta-driven market correlation
      const betaFactor = Math.min(Math.max(security.beta, 0.2), 2.0);
      const combinedZ = (betaFactor * zMarket + Math.sqrt(Math.max(0, 1 - betaFactor * betaFactor * 0.25)) * zIdiosyncratic);

      let dS = 0;

      if (model === 'GBM') {
        const drift = (mu - 0.5 * vol * vol) * dt;
        const diffusion = vol * sqrtDt * combinedZ;
        currentPrice = currentPrice * Math.exp(drift + diffusion);
      } else if (model === 'STOCHASTIC_VOL') {
        // Heston-like stochastic volatility mean reverting
        const meanVol = vol;
        const kappa = 2.0;
        const volVol = 0.2;
        currentVol = Math.max(0.05, currentVol + kappa * (meanVol - currentVol) * dt + volVol * Math.sqrt(currentVol) * sqrtDt * prng.nextGaussian());
        const drift = (mu - 0.5 * currentVol * currentVol) * dt;
        const diffusion = currentVol * sqrtDt * combinedZ;
        currentPrice = currentPrice * Math.exp(drift + diffusion);
      } else if (model === 'JUMP_DIFFUSION') {
        // Merton Jump Diffusion
        const lambda = 0.08; // jump arrival rate
        const jumpMean = -0.05;
        const jumpStd = 0.08;
        let jump = 0;
        if (prng.next() < lambda * dt * 10) {
          jump = jumpMean + jumpStd * prng.nextGaussian();
        }
        const drift = (mu - 0.5 * vol * vol) * dt;
        const diffusion = vol * sqrtDt * combinedZ;
        currentPrice = currentPrice * Math.exp(drift + diffusion + jump);
      } else if (model === 'REGIME_SWITCHING') {
        // High volatility bear regime vs Low volatility bull regime
        const isHighVolRegime = t > 80 && t < 140;
        const regVol = isHighVolRegime ? vol * 1.8 : vol * 0.85;
        const regMu = isHighVolRegime ? -0.12 : 0.12;
        const drift = (regMu - 0.5 * regVol * regVol) * dt;
        const diffusion = regVol * sqrtDt * combinedZ;
        currentPrice = currentPrice * Math.exp(drift + diffusion);
      } else {
        // Default GBM
        const drift = (mu - 0.5 * vol * vol) * dt;
        const diffusion = vol * sqrtDt * combinedZ;
        currentPrice = currentPrice * Math.exp(drift + diffusion);
      }

      path.push(Number(currentPrice.toFixed(2)));
    }

    pricePaths[security.identifier] = path;
  });

  return pricePaths;
}

/**
 * Compute correlation matrix and numerical diagnostics (eigenvalues, condition number)
 */
export function analyzeCorrelationMatrix(securities: Security[]): MatrixDiagnostics {
  const n = Math.min(securities.length, 12); // Sample sub-matrix for UI diagnostics
  const sampleSecs = securities.slice(0, n);
  const matrix: number[][] = Array(n).fill(0).map(() => Array(n).fill(0));

  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n; j++) {
      if (i === j) {
        matrix[i][j] = 1.0;
      } else {
        const s1 = sampleSecs[i];
        const s2 = sampleSecs[j];
        const sameSector = s1.sector === s2.sector ? 0.35 : 0.0;
        const sameCountry = s1.country === s2.country ? 0.20 : 0.0;
        const betaCorr = (s1.beta * s2.beta) * 0.25;
        const corr = Math.min(Math.max(0.15 + sameSector + sameCountry + betaCorr, -0.9), 0.95);
        matrix[i][j] = Number(corr.toFixed(3));
      }
    }
  }

  // Simplified Gershgorin / Power Iteration eigenvalue estimation
  const eigenvalues: number[] = [];
  for (let i = 0; i < n; i++) {
    let rowSumAbs = 0;
    for (let j = 0; j < n; j++) {
      if (i !== j) rowSumAbs += Math.abs(matrix[i][j]);
    }
    eigenvalues.push(Number((1.0 + rowSumAbs * 0.6).toFixed(3)));
  }
  eigenvalues.sort((a, b) => b - a);

  const maxEigen = Math.max(...eigenvalues, 1.0);
  const minEigen = Math.max(Math.min(...eigenvalues, 0.1), 0.01);
  const conditionNumber = Number((maxEigen / minEigen).toFixed(2));

  return {
    isPositiveDefinite: minEigen > 0,
    eigenvalues,
    conditionNumber,
    correlationMatrix: matrix,
    securityIds: sampleSecs.map(s => s.identifier)
  };
}
