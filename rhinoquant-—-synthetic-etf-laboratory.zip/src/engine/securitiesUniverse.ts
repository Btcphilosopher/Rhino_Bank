import { Security, Sector, Country, FactorExposures } from '../types';

// Deterministic seed PRNG for synthetic universe generation
class SeededRandom {
  private seed: number;

  constructor(seed: number = 42) {
    this.seed = seed;
  }

  public next(): number {
    this.seed = (this.seed * 9301 + 49297) % 233280;
    return this.seed / 233280;
  }

  public nextRange(min: number, max: number): number {
    return min + this.next() * (max - min);
  }

  public nextInt(min: number, max: number): number {
    return Math.floor(this.nextRange(min, max + 1));
  }
}

const SECTORS: Sector[] = [
  'INDUSTRIALS',
  'ENERGY',
  'TECHNOLOGY',
  'FINANCIALS',
  'HEALTHCARE',
  'UTILITIES',
  'MATERIALS',
  'CONSUMER',
  'INFRASTRUCTURE',
  'TRANSPORTATION'
];

const SECTOR_INDUSTRIES: Record<Sector, string[]> = {
  INDUSTRIALS: ['Heavy Machinery', 'Aerospace & Defense', 'Electrical Equipment', 'Building Products', 'Industrial Conglomerates'],
  ENERGY: ['Oil & Gas Exploration', 'Renewable Infrastructure', 'Energy Equipment', 'Pipelines & Storage', 'Refining'],
  TECHNOLOGY: ['Semiconductors', 'Enterprise Software', 'Quantum Hardware', 'Cloud Infrastructure', 'Cybersecurity'],
  FINANCIALS: ['Investment Banking', 'Commercial Banking', 'Asset Management', 'Insurance', 'Market Infrastructure'],
  HEALTHCARE: ['Pharmaceuticals', 'Medical Devices', 'Biotechnology', 'Healthcare Systems', 'Life Sciences'],
  UTILITIES: ['Electric Utilities', 'Water Utilities', 'Renewable Power', 'Gas Utilities', 'Grid Infrastructure'],
  MATERIALS: ['Specialty Chemicals', 'Steel & Metals', 'Construction Materials', 'Mining', 'Forest Products'],
  CONSUMER: ['Automotive', 'E-Commerce', 'Consumer Goods', 'Retail Platforms', 'Leisure & Travel'],
  INFRASTRUCTURE: ['Digital Infrastructure', 'Port Terminals', 'Clean Energy Grids', 'Telecom Towers', 'Water Infrastructure'],
  TRANSPORTATION: ['Freight Rail', 'Air Freight', 'Container Shipping', 'Logistics Infrastructure', 'Public Transit']
};

const COUNTRIES: { country: Country; currency: string; codePrefix: string }[] = [
  { country: 'UK', currency: 'GBP', codePrefix: 'RQ-UK' },
  { country: 'DE', currency: 'EUR', codePrefix: 'RQ-EU' },
  { country: 'FR', currency: 'EUR', codePrefix: 'RQ-EU' },
  { country: 'IT', currency: 'EUR', codePrefix: 'RQ-EU' },
  { country: 'US', currency: 'USD', codePrefix: 'RQ-US' },
  { country: 'JP', currency: 'JPY', codePrefix: 'RQ-AS' },
  { country: 'SG', currency: 'SGD', codePrefix: 'RQ-AS' },
  { country: 'CH', currency: 'CHF', codePrefix: 'RQ-EU' },
  { country: 'CA', currency: 'CAD', codePrefix: 'RQ-US' },
  { country: 'AU', currency: 'AUD', codePrefix: 'RQ-AS' }
];

const COMPANY_PREFIXES = [
  'Vanguard', 'Apex', 'Titan', 'Zephyr', 'Aegis', 'Nexus', 'Helix', 'Sovereign',
  'Orion', 'Solaria', 'TransAtlantic', 'Europia', 'Caledonia', 'Albion', 'Bavaria',
  'Nippon', 'Pacific', 'Nordic', 'Meridian', 'Ironclad', 'Omni', 'Veritas', 'Kinetix',
  'Aero', 'Quantum', 'Hydro', 'Strata', 'Terra', 'Atlas', 'Prometheus', 'Hyperion'
];

const COMPANY_SUFFIXES = [
  'Holdings', 'Systems', 'Industries', 'Infrastructure', 'Networks', 'Capital',
  'Energy', 'Logistics', 'Technologies', 'Dynamics', 'Solutions', 'Group',
  'Resources', 'Engineering', 'Corporation', 'Partners', 'Services', 'Global'
];

/**
 * Generate 250 synthetic securities with realistic quantitative attributes
 */
export function generateSyntheticUniverse(seed: number = 2026): Security[] {
  const prng = new SeededRandom(seed);
  const securities: Security[] = [];

  for (let i = 1; i <= 250; i++) {
    const countryObj = COUNTRIES[i % COUNTRIES.length];
    const sector = SECTORS[prng.nextInt(0, SECTORS.length - 1)];
    const industries = SECTOR_INDUSTRIES[sector];
    const industry = industries[prng.nextInt(0, industries.length - 1)];
    
    const prefix = COMPANY_PREFIXES[prng.nextInt(0, COMPANY_PREFIXES.length - 1)];
    const suffix = COMPANY_SUFFIXES[prng.nextInt(0, COMPANY_SUFFIXES.length - 1)];
    const name = `${prefix} ${suffix} plc`;
    
    const codeNum = String(i).padStart(3, '0');
    const identifier = `${countryObj.codePrefix}-${codeNum}`;

    // Synthetic financial distributions
    const isMegaCap = prng.next() > 0.85;
    const isLargeCap = prng.next() > 0.5;
    
    let marketCap: number;
    if (isMegaCap) {
      marketCap = prng.nextRange(100000, 750000); // $100B - $750B
    } else if (isLargeCap) {
      marketCap = prng.nextRange(15000, 100000); // $15B - $100B
    } else {
      marketCap = prng.nextRange(1500, 15000); // $1.5B - $15B
    }

    const price = Number(prng.nextRange(12.50, 480.00).toFixed(2));
    const volatility = Number(prng.nextRange(0.12, 0.48).toFixed(4));
    const beta = Number(prng.nextRange(0.55, 1.75).toFixed(2));
    const dividendYield = Number(prng.nextRange(0.005, 0.058).toFixed(4));
    
    // Liquidity: ADV roughly proportional to market cap with stochastic noise
    const liquidity = Number((marketCap * prng.nextRange(0.002, 0.012) * 1000000).toFixed(0));

    // Factor exposures (Fama-French 5 + Momentum + Quality + LowVol)
    const factorExposures: FactorExposures = {
      market: Number((beta + prng.nextRange(-0.1, 0.1)).toFixed(2)),
      size: Number((marketCap < 20000 ? prng.nextRange(0.3, 0.8) : prng.nextRange(-0.8, -0.2)).toFixed(2)),
      value: Number(prng.nextRange(-0.6, 0.7).toFixed(2)),
      momentum: Number(prng.nextRange(-0.5, 0.8).toFixed(2)),
      quality: Number((marketCap > 50000 ? prng.nextRange(0.2, 0.8) : prng.nextRange(-0.4, 0.4)).toFixed(2)),
      lowVol: Number((-1.2 * (volatility - 0.22) + prng.nextRange(-0.2, 0.2)).toFixed(2)),
      profitability: Number(prng.nextRange(-0.3, 0.85).toFixed(2)),
      investment: Number(prng.nextRange(-0.4, 0.6).toFixed(2))
    };

    securities.push({
      identifier,
      name,
      country: countryObj.country,
      currency: countryObj.currency,
      sector,
      industry,
      marketCap: Math.round(marketCap),
      price,
      volatility,
      beta,
      dividendYield,
      liquidity,
      factorExposures,
      correlationGroup: `${sector}_${countryObj.country}`
    });
  }

  return securities;
}

export const SYNTHETIC_UNIVERSE = generateSyntheticUniverse(2026);
