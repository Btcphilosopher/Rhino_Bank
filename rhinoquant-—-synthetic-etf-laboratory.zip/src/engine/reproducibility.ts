import { SimulationManifest } from '../types';

/**
 * Generate a deterministic SHA256-like hex digest for a research manifest
 */
export function generateManifestHash(data: object): string {
  const str = JSON.stringify(data);
  let hash = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    hash ^= str.charCodeAt(i);
    hash += (hash << 1) + (hash << 4) + (hash << 7) + (hash << 8) + (hash << 24);
  }
  const hex1 = (hash >>> 0).toString(16).padStart(8, '0');
  
  let hash2 = 0x525134;
  for (let i = str.length - 1; i >= 0; i--) {
    hash2 ^= str.charCodeAt(i);
    hash2 += (hash2 << 1) + (hash2 << 5) + (hash2 << 11);
  }
  const hex2 = (hash2 >>> 0).toString(16).padStart(8, '0');

  return `0x${hex1}${hex2}${hex1.slice(0, 4)}`.toLowerCase();
}

export function createSimulationManifest(
  researchId: string,
  etfTicker: string,
  simulationModel: any,
  seed: number,
  params: any
): SimulationManifest {
  const manifestData = {
    researchId,
    etfTicker,
    simulationModel,
    seed,
    params,
    timestamp: new Date().toISOString()
  };

  const sha256Hash = generateManifestHash(manifestData);

  return {
    manifestId: `MAN-${Math.floor(Math.random() * 89999 + 10000)}`,
    researchId,
    etfTicker,
    datasetVersion: 'v2026.04-SYNTHETIC-PARQUET',
    simulationModel,
    randomSeed: seed,
    parameters: params,
    softwareVersion: 'RhinoQuant v2.4.0-RUST-PY-01',
    sha256Hash,
    timestamp: new Date().toISOString()
  };
}
