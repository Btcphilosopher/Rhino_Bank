import { Security, UniverseRule, IndexMethodology, PortfolioHolding, EligibilityReport } from '../types';

/**
 * Filter universe based on structured rules and return complete eligibility report
 */
export function evaluateEligibility(securities: Security[], rules: UniverseRule[]): EligibilityReport {
  const passedSecurities: Security[] = [];
  const rulePassedCounts: Record<string, number> = {};
  const ruleFailedCounts: Record<string, number> = {};

  rules.forEach(r => {
    rulePassedCounts[r.id] = 0;
    ruleFailedCounts[r.id] = 0;
  });

  securities.forEach(security => {
    let satisfiesAll = true;

    for (const rule of rules) {
      const val = security[rule.field as keyof Security];
      let rulePassed = false;

      if (rule.operator === '>') {
        rulePassed = (val as number) > (rule.value as number);
      } else if (rule.operator === '<') {
        rulePassed = (val as number) < (rule.value as number);
      } else if (rule.operator === '>=') {
        rulePassed = (val as number) >= (rule.value as number);
      } else if (rule.operator === '<=') {
        rulePassed = (val as number) <= (rule.value as number);
      } else if (rule.operator === 'EQUALS') {
        rulePassed = val === rule.value;
      } else if (rule.operator === 'IN') {
        const arr = Array.isArray(rule.value) ? rule.value : [rule.value];
        rulePassed = arr.includes(val as string);
      } else if (rule.operator === 'NOT_IN') {
        const arr = Array.isArray(rule.value) ? rule.value : [rule.value];
        rulePassed = !arr.includes(val as string);
      }

      if (rulePassed) {
        rulePassedCounts[rule.id]++;
      } else {
        ruleFailedCounts[rule.id]++;
        satisfiesAll = false;
      }
    }

    if (satisfiesAll) {
      passedSecurities.push(security);
    }
  });

  return {
    totalInitialSecurities: securities.length,
    passedSecuritiesCount: passedSecurities.length,
    rejectedSecuritiesCount: securities.length - passedSecurities.length,
    appliedRules: rules.map(r => ({
      rule: r,
      passedCount: rulePassedCounts[r.id] || 0,
      failedCount: ruleFailedCounts[r.id] || 0
    })),
    eligibleSecurities: passedSecurities
  };
}

/**
 * Calculate raw target constituent weights based on methodology
 */
export function calculateRawWeights(
  eligibleSecurities: Security[],
  methodology: IndexMethodology
): { security: Security; rawWeight: number }[] {
  if (eligibleSecurities.length === 0) return [];

  const method = methodology.weightingMethod;

  if (method === 'EQUAL') {
    const w = 1 / eligibleSecurities.length;
    return eligibleSecurities.map(s => ({ security: s, rawWeight: w }));
  }

  if (method === 'MARKET_CAP') {
    const totalCap = eligibleSecurities.reduce((acc, s) => acc + s.marketCap, 0);
    return eligibleSecurities.map(s => ({ security: s, rawWeight: s.marketCap / totalCap }));
  }

  if (method === 'PRICE') {
    const totalPrice = eligibleSecurities.reduce((acc, s) => acc + s.price, 0);
    return eligibleSecurities.map(s => ({ security: s, rawWeight: s.price / totalPrice }));
  }

  if (method === 'INVERSE_VOLATILITY' || method === 'RISK_PARITY') {
    const invVols = eligibleSecurities.map(s => 1 / Math.max(s.volatility, 0.01));
    const sumInvVol = invVols.reduce((a, b) => a + b, 0);
    return eligibleSecurities.map((s, idx) => ({ security: s, rawWeight: invVols[idx] / sumInvVol }));
  }

  if (method === 'MOMENTUM') {
    const scores = eligibleSecurities.map(s => Math.max(s.factorExposures.momentum + 2.0, 0.1));
    const totalScore = scores.reduce((a, b) => a + b, 0);
    return eligibleSecurities.map((s, idx) => ({ security: s, rawWeight: scores[idx] / totalScore }));
  }

  if (method === 'QUALITY') {
    const scores = eligibleSecurities.map(s => Math.max(s.factorExposures.quality + 2.0, 0.1));
    const totalScore = scores.reduce((a, b) => a + b, 0);
    return eligibleSecurities.map((s, idx) => ({ security: s, rawWeight: scores[idx] / totalScore }));
  }

  if (method === 'FACTOR') {
    const targetFactors = methodology.targetFactors || ['quality', 'momentum'];
    const scores = eligibleSecurities.map(s => {
      let combined = 0;
      targetFactors.forEach(f => {
        combined += s.factorExposures[f] || 0;
      });
      return Math.max(combined + 3.0, 0.1);
    });
    const totalScore = scores.reduce((a, b) => a + b, 0);
    return eligibleSecurities.map((s, idx) => ({ security: s, rawWeight: scores[idx] / totalScore }));
  }

  // Default equal weight
  const defaultW = 1 / eligibleSecurities.length;
  return eligibleSecurities.map(s => ({ security: s, rawWeight: defaultW }));
}

/**
 * Apply constraints (capping, sector caps, country caps) and normalize weights to 1.0 (100%)
 */
export function applyConstraintsAndNormalize(
  rawWeights: { security: Security; rawWeight: number }[],
  methodology: IndexMethodology,
  targetPortfolioNav: number = 100000000 // $100M portfolio
): PortfolioHolding[] {
  if (rawWeights.length === 0) return [];

  const constraints = methodology.constraints;
  let weights = rawWeights.map(item => ({ ...item, weight: item.rawWeight }));

  // 1. Apply Max Constituent Weight Cap
  if (constraints.maxConstituentWeight > 0) {
    let excess = 0;
    weights.forEach(item => {
      if (item.weight > constraints.maxConstituentWeight) {
        excess += item.weight - constraints.maxConstituentWeight;
        item.weight = constraints.maxConstituentWeight;
      }
    });

    if (excess > 0) {
      const nonCapped = weights.filter(item => item.weight < constraints.maxConstituentWeight);
      const sumNonCapped = nonCapped.reduce((acc, item) => acc + item.weight, 0);
      if (sumNonCapped > 0) {
        nonCapped.forEach(item => {
          item.weight += excess * (item.weight / sumNonCapped);
        });
      }
    }
  }

  // 2. Apply Sector Caps if defined
  if (constraints.sectorCaps && Object.keys(constraints.sectorCaps).length > 0) {
    const sectorWeights: Record<string, number> = {};
    weights.forEach(item => {
      const sec = item.security.sector;
      sectorWeights[sec] = (sectorWeights[sec] || 0) + item.weight;
    });

    Object.entries(constraints.sectorCaps).forEach(([sector, maxSectorWeight]) => {
      if ((sectorWeights[sector] || 0) > maxSectorWeight) {
        const currentSectorWeight = sectorWeights[sector];
        const scale = maxSectorWeight / currentSectorWeight;
        weights.forEach(item => {
          if (item.security.sector === sector) {
            item.weight *= scale;
          }
        });
      }
    });
  }

  // Normalize final weights sum to 1.0
  const totalSum = weights.reduce((acc, item) => acc + item.weight, 0);
  weights.forEach(item => {
    item.weight = item.weight / totalSum;
  });

  // Construct PortfolioHoldings
  return weights.map(item => {
    const mktVal = targetPortfolioNav * item.weight;
    const shares = Math.floor(mktVal / item.security.price);
    return {
      securityIdentifier: item.security.identifier,
      name: item.security.name,
      sector: item.security.sector,
      country: item.security.country,
      weight: item.weight,
      shares,
      price: item.security.price,
      marketValue: mktVal,
      volatility: item.security.volatility,
      beta: item.security.beta,
      dividendYield: item.security.dividendYield,
      factorExposures: item.security.factorExposures
    };
  });
}
