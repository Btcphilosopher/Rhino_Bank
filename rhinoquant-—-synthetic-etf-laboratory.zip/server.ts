import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import { SYNTHETIC_UNIVERSE } from './src/engine/securitiesUniverse';
import { evaluateEligibility, calculateRawWeights, applyConstraintsAndNormalize } from './src/engine/indexEngine';
import { generateSyntheticPricePaths, analyzeCorrelationMatrix } from './src/engine/marketSimulation';
import { simulateEtfNavSeries, generateOrderBook, simulateCreationRedemption } from './src/engine/navEngine';
import { calculateRiskMetrics } from './src/engine/riskEngine';
import { calculateFactorAttribution, calculatePerformanceAttribution } from './src/engine/attributionEngine';
import { PRESET_SCENARIOS, runStressScenario } from './src/engine/scenarioEngine';
import { runMonteCarloSimulation } from './src/engine/monteCarloEngine';
import { createSimulationManifest } from './src/engine/reproducibility';
import { INITIAL_ETFS, INITIAL_RESEARCH_PROJECTS, INITIAL_AUDIT_LOGS } from './src/data/mockData';

async function startServer() {
  const app = express();
  app.use(express.json());

  let researchProjects = [...INITIAL_RESEARCH_PROJECTS];
  let etfs = [...INITIAL_ETFS];
  let auditLogs = [...INITIAL_AUDIT_LOGS];

  // API Endpoints
  app.get('/api/v1/health', (req: Request, res: Response) => {
    res.json({
      status: 'OPERATIONAL',
      platform: 'RhinoQuant Synthetic ETF Laboratory',
      engine: 'Python/Rust/TypeScript Quantitative Engine v2.4.0',
      timestamp: new Date().toISOString()
    });
  });

  // GET /api/v1/research
  app.get('/api/v1/research', (req: Request, res: Response) => {
    res.json({ count: researchProjects.length, researchProjects });
  });

  // GET /api/v1/research/:id
  app.get('/api/v1/research/:id', (req: Request, res: Response) => {
    const proj = researchProjects.find(p => p.id === req.params.id);
    if (!proj) return res.status(404).json({ error: 'Research project not found' });
    res.json(proj);
  });

  // POST /api/v1/research
  app.post('/api/v1/research', (req: Request, res: Response) => {
    const { title, hypothesis, universeId, etfId, notes } = req.body;
    const baseEtf = etfs.find(e => e.id === etfId) || etfs[0];
    
    const newId = `RQ-ETF-${String(researchProjects.length + 42).padStart(5, '0')}`;
    const manifest = createSimulationManifest(newId, baseEtf.ticker, 'GBM', 2026, { horizonDays: 252 });

    const newProject = {
      id: newId,
      title: title || 'New Synthetic ETF Research',
      version: 'v1.0',
      status: 'DRAFT' as const,
      isImmutable: false,
      hypothesis: hypothesis || 'Formulate quantitative research hypothesis.',
      universeId: universeId || 'UNIV-EU-IND',
      etfDefinition: baseEtf,
      simulationModel: 'GBM' as const,
      randomSeed: 2026,
      horizonDays: 252,
      scenarioIds: ['SCEN-EQ-01', 'SCEN-RATE-01', 'SCEN-VOL-01'],
      notes: notes || 'Draft research notes.',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      manifestHash: manifest.sha256Hash
    };

    researchProjects.unshift(newProject);
    auditLogs.unshift({
      id: `AUD-${Math.floor(Math.random() * 8999 + 1000)}`,
      timestamp: new Date().toISOString(),
      actor: 'QUANT_RESEARCHER',
      action: 'CREATE_RESEARCH_PROJECT',
      objectType: 'RESEARCH',
      objectId: newId,
      details: `Created research hypothesis: ${newProject.title}`,
      manifestHash: manifest.sha256Hash
    });

    res.status(201).json(newProject);
  });

  // GET /api/v1/universes
  app.get('/api/v1/universes', (req: Request, res: Response) => {
    res.json({
      universeId: 'RQ-SYNTHETIC-GLOBAL-250',
      totalSecurities: SYNTHETIC_UNIVERSE.length,
      sampleSecurities: SYNTHETIC_UNIVERSE.slice(0, 20)
    });
  });

  // POST /api/v1/etfs/construct
  app.post('/api/v1/etfs/construct', (req: Request, res: Response) => {
    const { rules, methodology, targetNav = 100000000 } = req.body;
    const rulesToApply = rules || [
      { id: 'r1', field: 'marketCap', operator: '>=', value: 5000 },
      { id: 'r2', field: 'volatility', operator: '<=', value: 0.35 }
    ];

    const eligibility = evaluateEligibility(SYNTHETIC_UNIVERSE, rulesToApply);
    const rawWeights = calculateRawWeights(eligibility.eligibleSecurities, methodology || { weightingMethod: 'INVERSE_VOLATILITY', constraints: { maxConstituentWeight: 0.08, minConstituentWeight: 0.005, sectorCaps: {}, countryCaps: {}, turnoverLimit: 0.2, liquidityLimit: 0.05 } });
    const holdings = applyConstraintsAndNormalize(rawWeights, methodology || { weightingMethod: 'INVERSE_VOLATILITY', constraints: { maxConstituentWeight: 0.08, minConstituentWeight: 0.005, sectorCaps: {}, countryCaps: {}, turnoverLimit: 0.2, liquidityLimit: 0.05 } }, targetNav);

    res.json({
      eligibilityReport: eligibility,
      constituentsCount: holdings.length,
      topHoldings: holdings.slice(0, 10),
      allHoldings: holdings
    });
  });

  // POST /api/v1/etfs/simulate
  app.post('/api/v1/etfs/simulate', (req: Request, res: Response) => {
    const { etfId, model = 'GBM', horizonDays = 252, seed = 2026 } = req.body;
    const etf = etfs.find(e => e.id === etfId) || etfs[0];
    
    const eligibility = evaluateEligibility(SYNTHETIC_UNIVERSE, [
      { id: 'r1', field: 'marketCap', operator: '>=', value: 5000 }
    ]);
    const raw = calculateRawWeights(eligibility.eligibleSecurities, etf.methodology);
    const holdings = applyConstraintsAndNormalize(raw, etf.methodology);

    const pricePaths = generateSyntheticPricePaths(SYNTHETIC_UNIVERSE.slice(0, 50), model, seed, horizonDays);
    const navPoints = simulateEtfNavSeries(etf, holdings, pricePaths, horizonDays);
    const risk = calculateRiskMetrics(navPoints, holdings);
    const manifest = createSimulationManifest(etf.id, etf.ticker, model, seed, { horizonDays });

    res.json({
      etfId: etf.id,
      ticker: etf.ticker,
      simulationModel: model,
      seed,
      horizonDays,
      navPoints,
      riskMetrics: risk,
      manifest
    });
  });

  // POST /api/v1/scenarios
  app.post('/api/v1/scenarios', (req: Request, res: Response) => {
    const eligibility = evaluateEligibility(SYNTHETIC_UNIVERSE, [{ id: 'r1', field: 'marketCap', operator: '>=', value: 5000 }]);
    const raw = calculateRawWeights(eligibility.eligibleSecurities, INITIAL_ETFS[0].methodology);
    const holdings = applyConstraintsAndNormalize(raw, INITIAL_ETFS[0].methodology);

    const results = PRESET_SCENARIOS.map(scen => runStressScenario(scen, holdings));
    res.json({ scenarioCount: results.length, scenarioResults: results });
  });

  // POST /api/v1/monte-carlo
  app.post('/api/v1/monte-carlo', (req: Request, res: Response) => {
    const { numPaths = 1000, seed = 525134, horizonDays = 252 } = req.body;
    const mc = runMonteCarloSimulation(100.0, 0.085, 0.142, numPaths, horizonDays, seed);
    res.json(mc);
  });

  // GET /api/v1/audit
  app.get('/api/v1/audit', (req: Request, res: Response) => {
    res.json({ count: auditLogs.length, auditLogs });
  });

  // POST /api/v1/cli
  app.post('/api/v1/cli', (req: Request, res: Response) => {
    const { command } = req.body;
    const cmdStr = (command || '').trim();

    if (cmdStr.startsWith('rhinoquant research')) {
      return res.json({ output: `RHINOQUANT RESEARCH TERMINAL\nActive Projects: 2\n[1] RQ-ETF-00041: European Industrial Infrastructure Volatility-Weighted Strategy (v1.0 PUBLISHED)\n[2] RQ-ETF-00042: Synthetic AI Hardware & Grid Power Compute Factor ETF (v1.1 PUBLISHED)` });
    }
    if (cmdStr.startsWith('rhinoquant construct')) {
      return res.json({ output: `RHINOQUANT CONSTRUCT ENGINE\nTarget ETF: RQ-IND\nSelected Universe: 250 Securities\nFiltered Eligible: 68 Securities\nMethodology: INVERSE_VOLATILITY\nTop Weight: RQ-EU-004 (7.98% Cap Applied)\nSum Weights: 100.00%` });
    }
    if (cmdStr.startsWith('rhinoquant simulate')) {
      return res.json({ output: `RHINOQUANT SIMULATION ENGINE\nModel: Geometric Brownian Motion (GBM)\nRandom Seed: 2026\nHorizon: 252 Days\nFinal NAV: 114.28\nBenchmark: 112.80\nTracking Error: 0.83%\nManifest Hash: 0x8f3a12b9005251348f3a` });
    }
    if (cmdStr.startsWith('rhinoquant risk')) {
      return res.json({ output: `RHINOQUANT RISK METRICS\nAnnualized Volatility: 14.2%\nBeta to Benchmark: 0.98\nMax Drawdown: -6.8%\nVaR 95% (Historical): -1.42%\nCVaR 95%: -1.85%\nSharpe Ratio: 1.45\nHerfindahl Index: 0.038` });
    }
    if (cmdStr.startsWith('rhinoquant scenario')) {
      return res.json({ output: `RHINOQUANT SCENARIO LAB\nExecuted 8 Preset Shocks:\n- EQUITY SHOCK: NAV Change -18.2%\n- RATE SHOCK (+200bps): NAV Change -7.4%\n- VOLATILITY SPIKE: NAV Change -11.1%\n- LIQUIDITY CRISIS: NAV Change -14.8%` });
    }

    res.json({ output: `RhinoQuant CLI v2.4.0\nUnknown command: '${cmdStr}'\nSupported commands: rhinoquant research, rhinoquant universe, rhinoquant construct, rhinoquant simulate, rhinoquant nav, rhinoquant risk, rhinoquant scenario, rhinoquant monte-carlo, rhinoquant audit` });
  });

  // Mount Vite Middleware in Development Mode
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static('dist'));
  }

  const PORT = parseInt(process.env.PORT || '3000', 10);
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`RhinoQuant Dev Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
