package com.example.domain.engine

import kotlin.math.pow

object MortgageAmortizationCalculator {
    data class AmortizationResult(
        val monthlyPaymentStandard: Double,
        val totalInterestPaidStandard: Double,
        val monthlyPaymentWithOverpayment: Double,
        val totalInterestPaidWithOverpayment: Double,
        val interestSaved: Double,
        val monthsSaved: Int,
        val originalTermMonths: Int,
        val newTermMonths: Int
    )

    fun calculate(
        principal: Double,
        annualRatePercent: Double,
        termYears: Int,
        monthlyOverpayment: Double = 0.0
    ): AmortizationResult {
        val monthlyRate = (annualRatePercent / 100.0) / 12.0
        val totalMonths = termYears * 12

        // Standard monthly payment formula: P * r * (1+r)^n / ((1+r)^n - 1)
        val standardMonthlyPayment = if (monthlyRate > 0) {
            val factor = (1.0 + monthlyRate).pow(totalMonths.toDouble())
            principal * (monthlyRate * factor) / (factor - 1.0)
        } else {
            principal / totalMonths
        }

        val totalInterestStandard = (standardMonthlyPayment * totalMonths) - principal

        if (monthlyOverpayment <= 0.0) {
            return AmortizationResult(
                monthlyPaymentStandard = standardMonthlyPayment,
                totalInterestPaidStandard = totalInterestStandard,
                monthlyPaymentWithOverpayment = standardMonthlyPayment,
                totalInterestPaidWithOverpayment = totalInterestStandard,
                interestSaved = 0.0,
                monthsSaved = 0,
                originalTermMonths = totalMonths,
                newTermMonths = totalMonths
            )
        }

        // Simulate overpayment month-by-month
        var balance = principal
        val actualPayment = standardMonthlyPayment + monthlyOverpayment
        var monthsCount = 0
        var totalInterestWithOverpayment = 0.0

        while (balance > 0.01 && monthsCount < totalMonths) {
            monthsCount++
            val interestForMonth = balance * monthlyRate
            totalInterestWithOverpayment += interestForMonth
            val principalForMonth = actualPayment - interestForMonth

            balance -= principalForMonth
            if (balance < 0) {
                balance = 0.0
            }
        }

        val monthsSaved = totalMonths - monthsCount
        val interestSaved = (totalInterestStandard - totalInterestWithOverpayment).coerceAtLeast(0.0)

        return AmortizationResult(
            monthlyPaymentStandard = standardMonthlyPayment,
            totalInterestPaidStandard = totalInterestStandard,
            monthlyPaymentWithOverpayment = actualPayment,
            totalInterestPaidWithOverpayment = totalInterestWithOverpayment,
            interestSaved = interestSaved,
            monthsSaved = monthsSaved,
            originalTermMonths = totalMonths,
            newTermMonths = monthsCount
        )
    }
}

object PrivateNotePricingEngine {
    data class NotePricingResult(
        val pricePercent: Double,
        val yieldToMaturityPct: Double,
        val annualCashFlow: Double,
        val macaulayDurationYears: Double,
        val modifiedDuration: Double,
        val accruedInterest: Double,
        val expectedAnnualIncome: Double
    )

    fun priceNote(
        faceValue: Double,
        couponRate: Double,
        maturityYears: Int,
        benchmarkGiltYieldPct: Double = 4.15,
        creditSpreadBps: Int = 110
    ): NotePricingResult {
        val discountRate = (benchmarkGiltYieldPct + (creditSpreadBps / 100.0)) / 100.0
        val coupon = faceValue * couponRate

        var pvCashFlows = 0.0
        var weightedTime = 0.0

        for (t in 1..maturityYears) {
            val cf = if (t == maturityYears) coupon + faceValue else coupon
            val discountFactor = (1.0 + discountRate).pow(t.toDouble())
            val pv = cf / discountFactor
            pvCashFlows += pv
            weightedTime += t * pv
        }

        val pricePercent = (pvCashFlows / faceValue) * 100.0
        val macDuration = if (pvCashFlows > 0) weightedTime / pvCashFlows else maturityYears.toDouble()
        val modDuration = macDuration / (1.0 + discountRate)
        val accrued = coupon * (180.0 / 365.0)

        return NotePricingResult(
            pricePercent = pricePercent,
            yieldToMaturityPct = (benchmarkGiltYieldPct + (creditSpreadBps / 100.0)),
            annualCashFlow = coupon,
            macaulayDurationYears = macDuration,
            modifiedDuration = modDuration,
            accruedInterest = accrued,
            expectedAnnualIncome = coupon
        )
    }
}
