package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Scottish Futurist Banking Palette - Edinburgh New Town & Modern Finance
val RhinoNavy = Color(0xFF0A192F)
val RhinoNavyDark = Color(0xFF050C18)
val RhinoNavyLight = Color(0xFF142B47)

val ScottishBlue = Color(0xFF005EB8)
val ScottishBlueLight = Color(0xFF2882DE)
val ScottishBlueMuted = Color(0xFF0B4F6C)

val EdinburghStone = Color(0xFFEAE3D2)
val EdinburghStoneLight = Color(0xFFF7F4EE)
val EdinburghStoneDark = Color(0xFFD3C8B4)

val ForestGreen = Color(0xFF0D3B2E)
val ForestGreenLight = Color(0xFF1B5E4B)
val MintGain = Color(0xFF1E7E55)

val BrassGold = Color(0xFFC59B27)
val BrassGoldLight = Color(0xFFE5B94E)
val BrassGoldDark = Color(0xFF9E7B1A)
val AmberAccent = Color(0xFFD97706)

val GraphiteDark = Color(0xFF111827)
val GraphiteMedium = Color(0xFF1F2937)
val GraphiteMuted = Color(0xFF4B5563)
val GraphiteBorder = Color(0xFFE5E7EB)

val WarmWhite = Color(0xFFFBF9F5)
val SurfaceCardLight = Color(0xFFFFFFFF)
val SurfaceCardDark = Color(0xFF101F33)

val SoftRed = Color(0xFFB91C1C)
val SoftRedBackground = Color(0xFFFEF2F2)
val SoftGreenBackground = Color(0xFFF0FDF4)
