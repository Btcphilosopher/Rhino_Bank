package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.ContactRecipientEntity
import com.example.ui.RhinoBankingViewModel
import com.example.ui.components.PaymentPipelineView
import com.example.ui.components.ScottishCard
import com.example.ui.components.SyntheticInstitutionBadge
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun PayScreen(
    viewModel: RhinoBankingViewModel,
    modifier: Modifier = Modifier
) {
    val contacts by viewModel.contacts.collectAsState()
    val accounts by viewModel.accounts.collectAsState()
    val pipelineState by viewModel.paymentPipeline.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedContact by remember { mutableStateOf<ContactRecipientEntity?>(null) }
    var recipientNameInput by remember { mutableStateOf("") }
    var recipientAccountInput by remember { mutableStateOf("") }
    var amountInput by remember { mutableStateOf("") }
    var referenceInput by remember { mutableStateOf("") }
    var selectedPaymentMethod by remember { mutableStateOf("Rhino Current Account") } // or "Digital Sterling"
    var isReviewingPayment by remember { mutableStateOf(false) }

    val filteredContacts = contacts.filter {
        it.name.contains(searchQuery, ignoreCase = true) ||
                it.rhinoHandle.contains(searchQuery, ignoreCase = true)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(WarmWhite)
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "PAYMENTS & SETTLEMENT",
                style = MaterialTheme.typography.labelSmall,
                color = BrassGold,
                letterSpacing = 1.5.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Send Sterling & Digital Money",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold,
                color = GraphiteDark
            )
            Spacer(modifier = Modifier.height(4.dp))
            SyntheticInstitutionBadge(text = "DOUBLE-ENTRY LEDGER • CONSENSUS SETTLEMENT")
        }

        // Active Payment Pipeline View
        item {
            PaymentPipelineView(
                state = pipelineState,
                onDismiss = { viewModel.resetPaymentPipeline() }
            )
        }

        if (!isReviewingPayment) {
            // Recipient Search
            item {
                Text(
                    text = "Who are you paying?",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = GraphiteDark
                )
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search contacts, name, sort code...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = GraphiteMedium) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_search_recipient"),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = RhinoNavy,
                        unfocusedBorderColor = GraphiteBorder
                    ),
                    singleLine = true
                )
            }

            // Contacts List
            item {
                Text(
                    text = "Recent Contacts",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = GraphiteDark
                )
            }

            items(filteredContacts) { contact ->
                ScottishCard(
                    onClick = {
                        selectedContact = contact
                        recipientNameInput = contact.name
                        recipientAccountInput = if (contact.rhinoHandle.isNotBlank()) contact.rhinoHandle else "${contact.sortCode} ${contact.accountNumber}"
                    },
                    backgroundColor = if (selectedContact?.id == contact.id) EdinburghStoneLight else SurfaceCardLight,
                    borderColor = if (selectedContact?.id == contact.id) RhinoNavy else GraphiteBorder,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(RhinoNavy),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = contact.avatarInitials,
                                style = MaterialTheme.typography.titleMedium,
                                color = WarmWhite,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = contact.name,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = GraphiteDark
                            )
                            Text(
                                text = if (contact.rhinoHandle.isNotBlank()) contact.rhinoHandle else "${contact.sortCode} • ${contact.accountNumber}",
                                style = MaterialTheme.typography.bodySmall,
                                color = GraphiteMuted
                            )
                        }
                    }
                }
            }

            // Custom Recipient Entry
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Payment Details",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = GraphiteDark
                )
                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = recipientNameInput,
                    onValueChange = {
                        recipientNameInput = it
                        selectedContact = null
                    },
                    label = { Text("Recipient Name / Business") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_recipient_name"),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = RhinoNavy)
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = recipientAccountInput,
                    onValueChange = { recipientAccountInput = it },
                    label = { Text("Sort Code & Account / Digital Sterling Handle") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_recipient_account"),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = RhinoNavy)
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = amountInput,
                    onValueChange = { amountInput = it },
                    label = { Text("Amount (£)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_payment_amount"),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = RhinoNavy)
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = referenceInput,
                    onValueChange = { referenceInput = it },
                    label = { Text("Reference") },
                    placeholder = { Text("e.g. Invoice #9982, Dinner") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_payment_reference"),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = RhinoNavy)
                )
            }

            // Payment Source Selection
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Payment Source",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = GraphiteDark
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    ScottishCard(
                        onClick = { selectedPaymentMethod = "Rhino Current Account" },
                        backgroundColor = if (selectedPaymentMethod == "Rhino Current Account") RhinoNavy else SurfaceCardLight,
                        borderColor = if (selectedPaymentMethod == "Rhino Current Account") BrassGold else GraphiteBorder,
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "Current Account",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (selectedPaymentMethod == "Rhino Current Account") WarmWhite else GraphiteDark
                            )
                            Text(
                                text = "£12,421.40",
                                style = MaterialTheme.typography.bodySmall,
                                color = if (selectedPaymentMethod == "Rhino Current Account") EdinburghStone else GraphiteMuted
                            )
                        }
                    }

                    ScottishCard(
                        onClick = { selectedPaymentMethod = "Digital Sterling" },
                        backgroundColor = if (selectedPaymentMethod == "Digital Sterling") RhinoNavy else SurfaceCardLight,
                        borderColor = if (selectedPaymentMethod == "Digital Sterling") BrassGold else GraphiteBorder,
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "Digital Sterling",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (selectedPaymentMethod == "Digital Sterling") WarmWhite else GraphiteDark
                            )
                            Text(
                                text = "£1,200.00",
                                style = MaterialTheme.typography.bodySmall,
                                color = if (selectedPaymentMethod == "Digital Sterling") EdinburghStone else GraphiteMuted
                            )
                        }
                    }
                }
            }

            // Review Button
            item {
                val amountVal = amountInput.toDoubleOrNull() ?: 0.0
                val canReview = recipientNameInput.isNotBlank() && amountVal > 0.0

                Button(
                    onClick = { isReviewingPayment = true },
                    enabled = canReview,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("btn_review_payment"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = RhinoNavy,
                        disabledContainerColor = GraphiteMuted
                    )
                ) {
                    Text(
                        text = "Review Payment",
                        style = MaterialTheme.typography.titleMedium,
                        color = WarmWhite,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        } else {
            // Payment Review Flow
            item {
                ScottishCard(
                    backgroundColor = RhinoNavy,
                    borderColor = BrassGold,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp)
                    ) {
                        Text(
                            text = "REVIEW PAYMENT DETAILS",
                            style = MaterialTheme.typography.labelSmall,
                            color = BrassGold,
                            letterSpacing = 1.2.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        val amt = amountInput.toDoubleOrNull() ?: 0.0
                        Text(
                            text = "£${String.format(Locale.UK, "%,.2f", amt)}",
                            style = MaterialTheme.typography.displayMedium,
                            color = WarmWhite,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(16.dp))
                        ReviewItem(label = "Recipient", value = recipientNameInput)
                        ReviewItem(label = "Destination", value = recipientAccountInput.ifBlank { "80-22-60 (Rhino Internal)" })
                        ReviewItem(label = "Source", value = selectedPaymentMethod)
                        ReviewItem(label = "Reference", value = referenceInput.ifBlank { "Payment" })
                        ReviewItem(label = "Settlement Engine", value = "Rhino Consensus (0.4s Finality)")
                        ReviewItem(label = "Transfer Fee", value = "£0.00 (Zero Fee)")
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = { isReviewingPayment = false },
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = GraphiteMedium)
                    ) {
                        Text("Back", color = WarmWhite)
                    }

                    Button(
                        onClick = {
                            val amt = amountInput.toDoubleOrNull() ?: 0.0
                            val fromAccId = if (selectedPaymentMethod == "Digital Sterling") "ACC-DIGITAL-01" else "ACC-CURRENT-01"

                            viewModel.executePayment(
                                fromAccountId = fromAccId,
                                recipientName = recipientNameInput,
                                recipientAccount = recipientAccountInput,
                                amount = amt,
                                reference = referenceInput,
                                paymentMethod = selectedPaymentMethod,
                                category = "Payment",
                                onSuccess = {
                                    isReviewingPayment = false
                                    recipientNameInput = ""
                                    amountInput = ""
                                    referenceInput = ""
                                },
                                onError = {}
                            )
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("btn_confirm_pay"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = BrassGold)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = RhinoNavy)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Confirm", color = RhinoNavy, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun ReviewItem(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium, color = EdinburghStoneDark)
        Text(text = value, style = MaterialTheme.typography.bodyMedium, color = WarmWhite, fontWeight = FontWeight.Bold)
    }
}
