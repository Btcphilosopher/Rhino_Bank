package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.entity.AccountEntity
import com.example.data.local.entity.AccountType
import com.example.data.local.entity.TransactionEntity
import com.example.ui.RhinoBankingViewModel
import com.example.ui.components.ScottishCard
import com.example.ui.components.SyntheticInstitutionBadge
import com.example.ui.components.TransactionRowItem
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun HomeScreen(
    viewModel: RhinoBankingViewModel,
    onNavigateToPay: () -> Unit,
    onNavigateToSave: () -> Unit,
    onNavigateToInvest: () -> Unit,
    onNavigateToDigitalSterling: () -> Unit,
    onNavigateToCards: () -> Unit,
    onNavigateToWealth: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accounts by viewModel.accounts.collectAsState()
    val transactions by viewModel.transactions.collectAsState()
    val notifications by viewModel.notifications.collectAsState()
    val unreadCount = notifications.count { !it.isRead }

    val currentAccount = accounts.find { it.accountType == AccountType.CURRENT }
    val savingsAccount = accounts.find { it.accountType == AccountType.SAVINGS_EASY_ACCESS }
    val investAccount = accounts.find { it.accountType == AccountType.INVESTMENT }
    val digitalAccount = accounts.find { it.accountType == AccountType.DIGITAL_STERLING }
    val notesAccount = accounts.find { it.accountType == AccountType.PRIVATE_NOTE }

    val totalAvailable = (currentAccount?.balance ?: 0.0) +
            (savingsAccount?.balance ?: 0.0) +
            (digitalAccount?.balance ?: 0.0)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(WarmWhite)
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Custom crest logo
                    Image(
                        painter = painterResource(id = R.drawable.img_rhino_crest),
                        contentDescription = "Rhino Bank Crest",
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp)),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "RHINO FREE BANK",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = RhinoNavy,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Good morning, Tom",
                            style = MaterialTheme.typography.bodySmall,
                            color = GraphiteMuted
                        )
                    }
                }

                Surface(
                    color = EdinburghStoneLight,
                    shape = RoundedCornerShape(20.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GraphiteBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .clickable { onNavigateToWealth() }
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "EDINBURGH",
                            style = MaterialTheme.typography.labelSmall,
                            color = RhinoNavy,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        item {
            SyntheticInstitutionBadge()
        }

        // Hero Balance Header
        item {
            ScottishCard(
                backgroundColor = RhinoNavy,
                borderColor = BrassGold,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "TOTAL AVAILABLE LIQUIDITY",
                            style = MaterialTheme.typography.labelSmall,
                            color = EdinburghStoneDark,
                            letterSpacing = 1.2.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Surface(
                            color = Color(0xFF132A4A),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "80-22-60 • 80201944",
                                style = MaterialTheme.typography.labelSmall,
                                color = BrassGold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "£${String.format(Locale.UK, "%,.2f", totalAvailable)}",
                        style = MaterialTheme.typography.displayMedium,
                        fontWeight = FontWeight.Bold,
                        color = WarmWhite
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Quick Actions inside hero card
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        HeroActionButton(
                            icon = Icons.Default.ArrowUpward,
                            label = "Pay",
                            testTag = "btn_quick_pay",
                            onClick = onNavigateToPay
                        )
                        HeroActionButton(
                            icon = Icons.Default.SwapHoriz,
                            label = "Convert",
                            testTag = "btn_quick_convert",
                            onClick = onNavigateToDigitalSterling
                        )
                        HeroActionButton(
                            icon = Icons.Default.Add,
                            label = "Save",
                            testTag = "btn_quick_save",
                            onClick = onNavigateToSave
                        )
                        HeroActionButton(
                            icon = Icons.Default.CreditCard,
                            label = "Cards",
                            testTag = "btn_quick_cards",
                            onClick = onNavigateToCards
                        )
                    }
                }
            }
        }

        // Contextual Financial Intelligence Banner
        item {
            Surface(
                color = Color(0xFFF0FDF4),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBBF7D0)),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToWealth() }
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = ForestGreen,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Financial Intelligence Alert",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = ForestGreen
                        )
                        Text(
                            text = "Mortgage payment of £1,540.00 due Friday. Overpaying £200/mo saves £28,420 in interest.",
                            style = MaterialTheme.typography.bodySmall,
                            color = GraphiteDark
                        )
                    }
                }
            }
        }

        // Account Breakdown Section
        item {
            Column {
                Text(
                    text = "Your Accounts & Holdings",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = GraphiteDark
                )
                Spacer(modifier = Modifier.height(10.dp))

                AccountSummaryRow(
                    title = "Rhino Current Account",
                    subtitle = "80-22-60 • 80201944",
                    amount = currentAccount?.balance ?: 12421.40,
                    tag = "2.10% APY",
                    onClick = onNavigateToPay
                )
                Spacer(modifier = Modifier.height(8.dp))

                AccountSummaryRow(
                    title = "Easy Access Savings",
                    subtitle = "80-22-60 • 80201955",
                    amount = savingsAccount?.balance ?: 7400.00,
                    tag = "4.85% APY",
                    tagColor = MintGain,
                    onClick = onNavigateToSave
                )
                Spacer(modifier = Modifier.height(8.dp))

                AccountSummaryRow(
                    title = "Digital Sterling Wallet",
                    subtitle = "Simulated BoE Interoperable",
                    amount = digitalAccount?.balance ?: 1200.00,
                    tag = "Instant 0.4s",
                    tagColor = ScottishBlue,
                    onClick = onNavigateToDigitalSterling
                )
                Spacer(modifier = Modifier.height(8.dp))

                AccountSummaryRow(
                    title = "Rhino Invest Portfolio",
                    subtitle = "UK & Global Equities, Gilts",
                    amount = investAccount?.balance ?: 84821.40,
                    tag = "+8.4% YTD",
                    tagColor = MintGain,
                    onClick = onNavigateToInvest
                )
                Spacer(modifier = Modifier.height(8.dp))

                AccountSummaryRow(
                    title = "Private Note Desk",
                    subtitle = "Rhino Edinburgh Note 01",
                    amount = notesAccount?.balance ?: 5000.00,
                    tag = "5.25% Coupon",
                    tagColor = BrassGold,
                    onClick = onNavigateToInvest
                )
            }
        }

        // Recent Activity Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Recent Activity",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = GraphiteDark
                )
                Text(
                    text = "See all",
                    style = MaterialTheme.typography.bodyMedium,
                    color = ScottishBlue,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable { onNavigateToPay() }
                )
            }
        }

        items(transactions.take(5)) { tx ->
            TransactionRowItem(
                tx = tx,
                onClick = { viewModel.selectTransaction(tx) }
            )
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun HeroActionButton(
    icon: ImageVector,
    label: String,
    testTag: String,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .testTag(testTag)
            .clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(Color(0xFF152A47))
                .border(1.dp, EdinburghStoneDark, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = BrassGold,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = EdinburghStoneLight,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun AccountSummaryRow(
    title: String,
    subtitle: String,
    amount: Double,
    tag: String,
    tagColor: Color = GraphiteMedium,
    onClick: () -> Unit
) {
    ScottishCard(
        onClick = onClick,
        backgroundColor = SurfaceCardLight,
        borderColor = GraphiteBorder,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = GraphiteDark
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = GraphiteMuted
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "£${String.format(Locale.UK, "%,.2f", amount)}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = GraphiteDark
                )
                Spacer(modifier = Modifier.height(2.dp))
                Surface(
                    color = tagColor.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = tag,
                        style = MaterialTheme.typography.labelSmall,
                        color = tagColor,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
