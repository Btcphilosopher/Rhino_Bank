package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = BrassGold,
    onPrimary = RhinoNavyDark,
    primaryContainer = RhinoNavyLight,
    onPrimaryContainer = EdinburghStone,
    secondary = ScottishBlueLight,
    onSecondary = RhinoNavyDark,
    secondaryContainer = RhinoNavyLight,
    onSecondaryContainer = EdinburghStoneLight,
    tertiary = ForestGreenLight,
    onTertiary = Color.White,
    background = RhinoNavyDark,
    onBackground = EdinburghStone,
    surface = RhinoNavy,
    onSurface = EdinburghStoneLight,
    surfaceVariant = SurfaceCardDark,
    onSurfaceVariant = EdinburghStoneDark,
    outline = GraphiteMuted
)

private val LightColorScheme = lightColorScheme(
    primary = RhinoNavy,
    onPrimary = WarmWhite,
    primaryContainer = EdinburghStoneLight,
    onPrimaryContainer = RhinoNavyDark,
    secondary = ScottishBlue,
    onSecondary = WarmWhite,
    secondaryContainer = EdinburghStone,
    onSecondaryContainer = RhinoNavyDark,
    tertiary = ForestGreen,
    onTertiary = WarmWhite,
    background = WarmWhite,
    onBackground = GraphiteDark,
    surface = SurfaceCardLight,
    onSurface = GraphiteDark,
    surfaceVariant = EdinburghStoneLight,
    onSurfaceVariant = GraphiteMedium,
    outline = GraphiteBorder
)

@Composable
fun RhinoBankTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

// Backwards compatibility alias
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    RhinoBankTheme(darkTheme = darkTheme, content = content)
}
