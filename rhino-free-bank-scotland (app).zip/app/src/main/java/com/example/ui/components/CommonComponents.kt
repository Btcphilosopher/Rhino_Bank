package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocalCafe
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.TransactionEntity
import com.example.data.local.entity.TransactionType
import com.example.ui.PaymentPipelineState
import com.example.ui.theme.BrassGold
import com.example.ui.theme.EdinburghStone
import com.example.ui.theme.EdinburghStoneDark
import com.example.ui.theme.EdinburghStoneLight
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.GraphiteBorder
import com.example.ui.theme.GraphiteDark
import com.example.ui.theme.GraphiteMedium
import com.example.ui.theme.GraphiteMuted
import com.example.ui.theme.MintGain
import com.example.ui.theme.RhinoNavy
import com.example.ui.theme.RhinoNavyDark
import com.example.ui.theme.RhinoNavyLight
import com.example.ui.theme.ScottishBlue
import com.example.ui.theme.SoftRed
import com.example.ui.theme.WarmWhite
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SyntheticInstitutionBadge(
    modifier: Modifier = Modifier,
    text: String = "SYNTHETIC FINANCIAL INSTITUTION • EDINBURGH"
) {
    Surface(
        modifier = modifier.testTag("synthetic_badge"),
        color = EdinburghStoneLight,
        shape = RoundedCornerShape(4.dp),
        border = BorderStroke(1.dp, EdinburghStoneDark)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(BrassGold)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.labelSmall,
                color = GraphiteMedium,
                letterSpacing = 1.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun ScottishCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    backgroundColor: Color = Color.White,
    borderColor: Color = GraphiteBorder,
    content: @Composable () -> Unit
) {
    val cardModifier = if (onClick != null) {
        modifier.clickable { onClick() }
    } else modifier

    Card(
        modifier = cardModifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = backgroundColor),
        border = BorderStroke(1.dp, borderColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        content()
    }
}

@Composable
fun TransactionRowItem(
    tx: TransactionEntity,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isPositive = tx.amount > 0
    val icon = when (tx.type) {
        TransactionType.INCOMING_TRANSFER, TransactionType.INVESTMENT_DIVIDEND, TransactionType.NOTE_COUPON, TransactionType.INTEREST_EARNED -> Icons.Default.ArrowDownward
        TransactionType.OUTGOING_PAYMENT -> Icons.Default.ArrowUpward
        TransactionType.CARD_PURCHASE -> Icons.Default.CreditCard
        TransactionType.DIGITAL_STERLING_TRANSFER, TransactionType.DIGITAL_STERLING_CONVERSION -> Icons.Default.AccountBalance
        TransactionType.SAVINGS_TRANSFER -> Icons.Default.TrendingUp
        TransactionType.MORTGAGE_REPAYMENT -> Icons.Default.AccountBalance
        else -> Icons.Default.Receipt
    }

    val iconBg = if (isPositive) Color(0xFFEDF7ED) else Color(0xFFF3F4F6)
    val iconTint = if (isPositive) MintGain else GraphiteMedium

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 12.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(iconBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = tx.title,
                    tint = iconTint,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = tx.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = GraphiteDark,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = tx.subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = GraphiteMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Column(horizontalAlignment = Alignment.End) {
            val amountText = if (isPositive) "+£${String.format(Locale.UK, "%,.2f", tx.amount)}"
            else "-£${String.format(Locale.UK, "%,.2f", kotlin.math.abs(tx.amount))}"

            Text(
                text = amountText,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = if (isPositive) MintGain else GraphiteDark
            )
            Spacer(modifier = Modifier.height(2.dp))
            val dateStr = SimpleDateFormat("d MMM", Locale.UK).format(Date(tx.timestamp))
            Text(
                text = dateStr,
                style = MaterialTheme.typography.bodySmall,
                color = GraphiteMuted
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransactionDetailSheet(
    tx: TransactionEntity?,
    onDismiss: () -> Unit
) {
    if (tx == null) return
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = WarmWhite,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = tx.title,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = GraphiteDark
                    )
                    Text(
                        text = tx.category,
                        style = MaterialTheme.typography.bodyMedium,
                        color = GraphiteMuted
                    )
                }
                Surface(
                    color = if (tx.amount > 0) Color(0xFFEDF7ED) else Color(0xFFF3F4F6),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = tx.status.name,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (tx.amount > 0) MintGain else GraphiteMedium,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            val formattedAmount = if (tx.amount > 0) "+£${String.format(Locale.UK, "%,.2f", tx.amount)}"
            else "-£${String.format(Locale.UK, "%,.2f", kotlin.math.abs(tx.amount))}"

            Text(
                text = formattedAmount,
                style = MaterialTheme.typography.displayMedium,
                fontWeight = FontWeight.Bold,
                color = if (tx.amount > 0) MintGain else GraphiteDark
            )

            val dateFull = SimpleDateFormat("dd MMMM yyyy, HH:mm", Locale.UK).format(Date(tx.timestamp))
            Text(
                text = dateFull,
                style = MaterialTheme.typography.bodySmall,
                color = GraphiteMuted
            )

            Spacer(modifier = Modifier.height(24.dp))
            HorizontalDivider(color = GraphiteBorder)
            Spacer(modifier = Modifier.height(16.dp))

            DetailRow(label = "Payment Method", value = tx.paymentMethod)
            DetailRow(label = "Counterparty", value = tx.counterpartyName)
            if (tx.counterpartyAccount.isNotBlank()) {
                DetailRow(label = "Account / Identifier", value = tx.counterpartyAccount)
            }
            if (tx.reference.isNotBlank()) {
                DetailRow(label = "Reference", value = tx.reference)
            }
            DetailRow(label = "Location", value = tx.location)
            DetailRow(label = "Consensus Validator", value = "${tx.validatorName} (Block #${tx.blockHeight})")
            if (tx.auditHash.isNotBlank()) {
                DetailRow(label = "Cryptographic Proof", value = "SHA256:${tx.auditHash.take(16)}...")
            }

            Spacer(modifier = Modifier.height(16.dp))
            if (tx.receiptNotes.isNotBlank()) {
                Surface(
                    color = EdinburghStoneLight,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = tx.receiptNotes,
                        style = MaterialTheme.typography.bodySmall,
                        color = GraphiteMedium,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium, color = GraphiteMuted)
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            color = GraphiteDark
        )
    }
}

@Composable
fun PaymentPipelineView(
    state: PaymentPipelineState,
    onDismiss: () -> Unit
) {
    if (!state.isProcessing && state.completedTransaction == null && state.errorMessage == null) return

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        shape = RoundedCornerShape(16.dp),
        color = RhinoNavy,
        border = BorderStroke(1.dp, BrassGold)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "RHINO SETTLEMENT PIPELINE",
                style = MaterialTheme.typography.labelSmall,
                color = BrassGold,
                letterSpacing = 1.5.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(16.dp))

            state.stepDescriptions.forEachIndexed { index, desc ->
                val isCompleted = index < state.currentStepIndex || (index == state.currentStepIndex && state.completedTransaction != null)
                val isCurrent = index == state.currentStepIndex && state.isProcessing
                val isPending = index > state.currentStepIndex

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(
                                when {
                                    isCompleted -> MintGain
                                    isCurrent -> ScottishBlue
                                    else -> GraphiteMedium
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isCompleted) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        } else if (isCurrent) {
                            CircularProgressIndicator(
                                color = Color.White,
                                strokeWidth = 2.dp,
                                modifier = Modifier.size(14.dp)
                            )
                        } else {
                            Text(
                                text = "${index + 1}",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = desc,
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (isCompleted || isCurrent) Color.White else GraphiteMuted,
                        fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }

            if (state.completedTransaction != null) {
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "£${String.format(Locale.UK, "%,.2f", kotlin.math.abs(state.completedTransaction.amount))} Settled",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = BrassGold
                )
                Text(
                    text = "Consensus Finality Confirmed in 0.4s",
                    style = MaterialTheme.typography.bodySmall,
                    color = EdinburghStone
                )
            }

            if (state.errorMessage != null) {
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = state.errorMessage,
                    style = MaterialTheme.typography.bodyMedium,
                    color = SoftRed
                )
            }
        }
    }
}
