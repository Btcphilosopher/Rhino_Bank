package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.InvestmentHoldingEntity
import com.example.data.local.entity.PrivateNoteEntity
import com.example.ui.RhinoBankingViewModel
import com.example.ui.components.ScottishCard
import com.example.ui.components.SyntheticInstitutionBadge
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun InvestScreen(
    viewModel: RhinoBankingViewModel,
    modifier: Modifier = Modifier
) {
    val investments by viewModel.investments.collectAsState()
    val privateNotes by viewModel.privateNotes.collectAsState()
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Portfolio, 1: Private Note Desk

    var selectedNoteForPurchase by remember { mutableStateOf<PrivateNoteEntity?>(null) }
    var purchaseAmountInput by remember { mutableStateOf("") }
    var purchaseResultMsg by remember { mutableStateOf<String?>(null) }

    val totalPortfolioVal = investments.sumOf { it.units * it.currentPrice } +
            privateNotes.sumOf { it.customerInvestedAmount }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(WarmWhite)
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "RHINO INVEST & SECURITIES",
                style = MaterialTheme.typography.labelSmall,
                color = BrassGold,
                letterSpacing = 1.5.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Edinburgh Capital Desk",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold,
                color = GraphiteDark
            )
            Spacer(modifier = Modifier.height(4.dp))
            SyntheticInstitutionBadge(text = "EQUITIES • GILTS • PRIVATE NOTES")
        }

        // Tabs
        item {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = WarmWhite,
                contentColor = RhinoNavy,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = RhinoNavy
                    )
                }
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Holdings & Assets", fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("tab_portfolio")
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Private Note Desk", fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("tab_private_notes")
                )
            }
        }

        // Hero Summary Card
        item {
            ScottishCard(
                backgroundColor = RhinoNavy,
                borderColor = BrassGold,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Text(
                        text = "TOTAL PORTFOLIO VALUE",
                        style = MaterialTheme.typography.labelSmall,
                        color = EdinburghStoneDark,
                        letterSpacing = 1.2.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "£${String.format(Locale.UK, "%,.2f", totalPortfolioVal)}",
                        style = MaterialTheme.typography.displayMedium,
                        fontWeight = FontWeight.Bold,
                        color = WarmWhite
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Annual Yield", style = MaterialTheme.typography.bodySmall, color = EdinburghStoneDark)
                            Text("+5.20% p.a.", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MintGain)
                        }
                        Column {
                            Text("1-Year Growth", style = MaterialTheme.typography.bodySmall, color = EdinburghStoneDark)
                            Text("+8.40% (£6,420)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = BrassGold)
                        }
                    }
                }
            }
        }

        if (selectedTab == 0) {
            // Holdings List
            item {
                Text(
                    text = "Active Securities & Funds",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = GraphiteDark
                )
            }

            items(investments) { inv ->
                val currentVal = inv.units * inv.currentPrice
                val pnl = currentVal - (inv.units * inv.averageCostPrice)

                ScottishCard(
                    backgroundColor = SurfaceCardLight,
                    borderColor = GraphiteBorder,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = inv.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = GraphiteDark
                                )
                                Text(
                                    text = "${inv.assetClass} • ISIN: ${inv.isin}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = GraphiteMuted
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "£${String.format(Locale.UK, "%,.2f", currentVal)}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = GraphiteDark
                                )
                                Text(
                                    text = if (pnl >= 0) "+£${String.format(Locale.UK, "%.2f", pnl)}" else "-£${String.format(Locale.UK, "%.2f", kotlin.math.abs(pnl))}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (pnl >= 0) MintGain else Color.Red,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = inv.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = GraphiteMedium
                        )
                    }
                }
            }
        } else {
            // Private Note Desk
            item {
                Text(
                    text = "Flagship Private Notes",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = GraphiteDark
                )
                Text(
                    text = "Fixed income paper issued by Rhino Free Bank Scotland PLC.",
                    style = MaterialTheme.typography.bodySmall,
                    color = GraphiteMuted
                )
            }

            items(privateNotes) { note ->
                ScottishCard(
                    onClick = { selectedNoteForPurchase = note },
                    backgroundColor = SurfaceCardLight,
                    borderColor = BrassGold,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = note.instrumentName,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = GraphiteDark
                                )
                                Text(
                                    text = note.instrumentCode,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = GraphiteMuted,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            Surface(
                                color = Color(0xFFFEF3C7),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = "${String.format(Locale.UK, "%.2f", note.couponRate * 100)}% Coupon",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = BrassGold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Maturity", style = MaterialTheme.typography.bodySmall, color = GraphiteMuted)
                                Text("${note.maturityYears} Years", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = GraphiteDark)
                            }
                            Column {
                                Text("Seniority", style = MaterialTheme.typography.bodySmall, color = GraphiteMuted)
                                Text(note.seniority, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = GraphiteDark)
                            }
                            Column {
                                Text("Your Investment", style = MaterialTheme.typography.bodySmall, color = GraphiteMuted)
                                Text("£${String.format(Locale.UK, "%,.2f", note.customerInvestedAmount)}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = ScottishBlue)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Collateral: ${note.collateralSummary}",
                            style = MaterialTheme.typography.bodySmall,
                            color = GraphiteMedium
                        )
                    }
                }
            }

            // Purchase Dialog / Modal
            if (selectedNoteForPurchase != null) {
                item {
                    ScottishCard(
                        backgroundColor = SurfaceCardLight,
                        borderColor = BrassGold,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "Subscribe: ${selectedNoteForPurchase?.instrumentName}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = GraphiteDark
                            )
                            Text(
                                text = "Min Investment: £${String.format(Locale.UK, "%,.0f", selectedNoteForPurchase?.minInvestment)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = GraphiteMuted
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = purchaseAmountInput,
                                onValueChange = { purchaseAmountInput = it },
                                label = { Text("Investment Amount (£)") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("input_note_amount"),
                                shape = RoundedCornerShape(8.dp)
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { selectedNoteForPurchase = null },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = GraphiteMuted)
                                ) {
                                    Text("Cancel")
                                }

                                Button(
                                    onClick = {
                                        val amt = purchaseAmountInput.toDoubleOrNull() ?: 1000.0
                                        viewModel.purchasePrivateNote(selectedNoteForPurchase!!.instrumentCode, amt) { res ->
                                            purchaseResultMsg = res
                                            selectedNoteForPurchase = null
                                            purchaseAmountInput = ""
                                        }
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("btn_confirm_note_purchase"),
                                    colors = ButtonDefaults.buttonColors(containerColor = BrassGold)
                                ) {
                                    Text("Subscribe", color = RhinoNavy, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            if (purchaseResultMsg != null) {
                item {
                    Surface(
                        color = Color(0xFFF0FDF4),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = purchaseResultMsg!!,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MintGain,
                            modifier = Modifier.padding(12.dp),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
