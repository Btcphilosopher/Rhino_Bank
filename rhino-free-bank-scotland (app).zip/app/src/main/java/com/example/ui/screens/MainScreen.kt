package com.example.ui.screens

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Wallet
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.RhinoBankingViewModel
import com.example.ui.components.TransactionDetailSheet
import com.example.ui.theme.BrassGold
import com.example.ui.theme.EdinburghStoneDark
import com.example.ui.theme.GraphiteMuted
import com.example.ui.theme.RhinoNavy
import com.example.ui.theme.WarmWhite

enum class RhinoNavDestination(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Default.Home),
    PAY("Pay", Icons.Default.Payments),
    SAVE("Save", Icons.Default.Savings),
    INVEST("Invest", Icons.Default.ShowChart),
    DIGITAL_STERLING("Digital £", Icons.Default.Wallet),
    WEALTH("Wealth", Icons.Default.AccountBalance),
    CARDS("Cards", Icons.Default.CreditCard)
}

@Composable
fun MainScreen(
    viewModel: RhinoBankingViewModel,
    modifier: Modifier = Modifier
) {
    var selectedIndex by remember { mutableIntStateOf(0) }
    val selectedTransaction by viewModel.selectedTransaction.collectAsState()

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = RhinoNavy,
                tonalElevation = 8.dp
            ) {
                RhinoNavDestination.entries.forEachIndexed { index, destination ->
                    val isSelected = selectedIndex == index
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { selectedIndex = index },
                        icon = {
                            Icon(
                                imageVector = destination.icon,
                                contentDescription = destination.label,
                                tint = if (isSelected) BrassGold else EdinburghStoneDark
                            )
                        },
                        label = {
                            Text(
                                text = destination.label,
                                color = if (isSelected) BrassGold else EdinburghStoneDark
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = RhinoNavy
                        ),
                        modifier = Modifier.testTag("nav_${destination.name.lowercase()}")
                    )
                }
            }
        }
    ) { innerPadding ->
        val contentModifier = Modifier.padding(innerPadding)

        when (RhinoNavDestination.entries[selectedIndex]) {
            RhinoNavDestination.HOME -> HomeScreen(
                viewModel = viewModel,
                onNavigateToPay = { selectedIndex = 1 },
                onNavigateToSave = { selectedIndex = 2 },
                onNavigateToInvest = { selectedIndex = 3 },
                onNavigateToDigitalSterling = { selectedIndex = 4 },
                onNavigateToWealth = { selectedIndex = 5 },
                onNavigateToCards = { selectedIndex = 6 },
                modifier = contentModifier
            )
            RhinoNavDestination.PAY -> PayScreen(viewModel = viewModel, modifier = contentModifier)
            RhinoNavDestination.SAVE -> SaveScreen(viewModel = viewModel, modifier = contentModifier)
            RhinoNavDestination.INVEST -> InvestScreen(viewModel = viewModel, modifier = contentModifier)
            RhinoNavDestination.DIGITAL_STERLING -> DigitalSterlingScreen(viewModel = viewModel, modifier = contentModifier)
            RhinoNavDestination.WEALTH -> WealthScreen(viewModel = viewModel, modifier = contentModifier)
            RhinoNavDestination.CARDS -> CardsScreen(viewModel = viewModel, modifier = contentModifier)
        }

        // Transaction Detail Bottom Sheet
        if (selectedTransaction != null) {
            TransactionDetailSheet(
                tx = selectedTransaction,
                onDismiss = { viewModel.selectTransaction(null) }
            )
        }
    }
}
