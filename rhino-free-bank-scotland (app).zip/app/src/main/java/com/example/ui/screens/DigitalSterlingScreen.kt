package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Nfc
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.RhinoBankingViewModel
import com.example.ui.components.ScottishCard
import com.example.ui.components.SyntheticInstitutionBadge
import com.example.ui.components.TransactionRowItem
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun DigitalSterlingScreen(
    viewModel: RhinoBankingViewModel,
    modifier: Modifier = Modifier
) {
    val wallet by viewModel.digitalWallet.collectAsState()
    val transactions by viewModel.transactions.collectAsState()
    val digitalTxs = transactions.filter { it.accountId == "ACC-DIGITAL-01" }

    var convertAmountInput by remember { mutableStateOf("") }
    var isConvertingToDigital by remember { mutableStateOf(true) }
    var conversionMsg by remember { mutableStateOf<String?>(null) }

    var offlineMerchantInput by remember { mutableStateOf("") }
    var offlineAmountInput by remember { mutableStateOf("") }
    var offlineMsg by remember { mutableStateOf<String?>(null) }

    val onlineBalance = wallet?.onlineBalance ?: 1200.00
    val offlineBalance = wallet?.offlineBalance ?: 120.00

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(WarmWhite)
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "DIGITAL STERLING WALLET",
                style = MaterialTheme.typography.labelSmall,
                color = BrassGold,
                letterSpacing = 1.5.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Interoperable Digital Money",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold,
                color = GraphiteDark
            )
            Spacer(modifier = Modifier.height(4.dp))
            SyntheticInstitutionBadge(text = "SIMULATED BANK OF ENGLAND INTEROPERABLE CORE")
        }

        // Digital Wallet Card
        item {
            ScottishCard(
                backgroundColor = RhinoNavy,
                borderColor = ScottishBlue,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ONLINE DIGITAL STERLING",
                            style = MaterialTheme.typography.labelSmall,
                            color = EdinburghStoneDark,
                            letterSpacing = 1.2.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = wallet?.walletAddress ?: "dgbp:rhino:scot:99a820b",
                            style = MaterialTheme.typography.labelSmall,
                            color = ScottishBlue,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "£${String.format(Locale.UK, "%,.2f", onlineBalance)}",
                        style = MaterialTheme.typography.displayMedium,
                        fontWeight = FontWeight.Bold,
                        color = WarmWhite
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Offline Reserve (NFC)", style = MaterialTheme.typography.bodySmall, color = EdinburghStoneDark)
                            Text("£${String.format(Locale.UK, "%.2f", offlineBalance)}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = BrassGold)
                        }
                        Column {
                            Text("Settlement Speed", style = MaterialTheme.typography.bodySmall, color = EdinburghStoneDark)
                            Text("0.4s Instant Finality", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MintGain)
                        }
                    }
                }
            }
        }

        // Interoperability Conversion Bridge
        item {
            ScottishCard(
                backgroundColor = SurfaceCardLight,
                borderColor = GraphiteBorder,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Deposit ↔ Digital Sterling Bridge",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = GraphiteDark
                        )
                        Icon(Icons.Default.SwapHoriz, contentDescription = null, tint = ScottishBlue)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = convertAmountInput,
                        onValueChange = { convertAmountInput = it },
                        label = { Text("Amount (£)") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_convert_amount"),
                        shape = RoundedCornerShape(8.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                val amt = convertAmountInput.toDoubleOrNull() ?: 50.0
                                viewModel.convertDigitalSterling(amt, toDigitalSterling = true) {
                                    conversionMsg = it
                                    convertAmountInput = ""
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_move_to_digital"),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = RhinoNavy)
                        ) {
                            Text("Deposit → Digital", style = MaterialTheme.typography.labelMedium)
                        }

                        Button(
                            onClick = {
                                val amt = convertAmountInput.toDoubleOrNull() ?: 50.0
                                viewModel.convertDigitalSterling(amt, toDigitalSterling = false) {
                                    conversionMsg = it
                                    convertAmountInput = ""
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_redeem_to_deposit"),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = ScottishBlue)
                        ) {
                            Text("Digital → Deposit", style = MaterialTheme.typography.labelMedium)
                        }
                    }

                    if (conversionMsg != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = conversionMsg!!, style = MaterialTheme.typography.bodySmall, color = MintGain, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Offline Mode (NFC Tap simulation)
        item {
            ScottishCard(
                backgroundColor = SurfaceCardLight,
                borderColor = BrassGold,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Nfc, contentDescription = null, tint = BrassGold, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Offline Tap-to-Pay (Simulated NFC)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = GraphiteDark
                            )
                            Text(
                                text = "BoE 2025 local enclave technology demo",
                                style = MaterialTheme.typography.bodySmall,
                                color = GraphiteMuted
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = offlineMerchantInput,
                        onValueChange = { offlineMerchantInput = it },
                        label = { Text("Merchant / Venue Name") },
                        placeholder = { Text("e.g. Waverley Station Cafe") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = offlineAmountInput,
                        onValueChange = { offlineAmountInput = it },
                        label = { Text("Amount (£)") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            val amt = offlineAmountInput.toDoubleOrNull() ?: 5.0
                            val merchant = offlineMerchantInput.ifBlank { "Edinburgh Merchant" }
                            viewModel.executeOfflineDigitalTap(amt, merchant) {
                                offlineMsg = it
                                offlineAmountInput = ""
                                offlineMerchantInput = ""
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("btn_offline_tap"),
                        colors = ButtonDefaults.buttonColors(containerColor = BrassGold)
                    ) {
                        Text("Simulate NFC Tap Payment", color = RhinoNavy, fontWeight = FontWeight.Bold)
                    }

                    if (offlineMsg != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = offlineMsg!!, style = MaterialTheme.typography.bodySmall, color = MintGain, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Network Status
        item {
            ScottishCard(
                backgroundColor = Color(0xFFF8FAFC),
                borderColor = GraphiteBorder,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Rhino Sterling Validation Network Status", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = GraphiteDark)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("25 Active Scottish Validators", style = MaterialTheme.typography.bodySmall, color = GraphiteMuted)
                        Text("99.98% Uptime", style = MaterialTheme.typography.bodySmall, color = MintGain, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Recent Digital Sterling Activity
        item {
            Text(
                text = "Digital Sterling Transactions",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = GraphiteDark
            )
        }

        items(digitalTxs) { tx ->
            TransactionRowItem(
                tx = tx,
                onClick = { viewModel.selectTransaction(tx) }
            )
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
