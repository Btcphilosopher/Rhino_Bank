package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.SavingsGoalEntity
import com.example.ui.RhinoBankingViewModel
import com.example.ui.components.ScottishCard
import com.example.ui.components.SyntheticInstitutionBadge
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun SaveScreen(
    viewModel: RhinoBankingViewModel,
    modifier: Modifier = Modifier
) {
    val accounts by viewModel.accounts.collectAsState()
    val savingsGoals by viewModel.savingsGoals.collectAsState()

    val savingsAccount = accounts.find { it.accountNumber == "80201955" }
    val savingsBalance = savingsAccount?.balance ?: 7400.00
    val totalGoalSaved = savingsGoals.sumOf { it.currentAmount }

    var isAddingGoal by remember { mutableStateOf(false) }
    var newGoalName by remember { mutableStateOf("") }
    var newGoalTarget by remember { mutableStateOf("") }
    var newGoalMonthly by remember { mutableStateOf("") }

    var selectedGoalForContrib by remember { mutableStateOf<SavingsGoalEntity?>(null) }
    var contribAmountInput by remember { mutableStateOf("") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(WarmWhite)
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "SAVINGS & RESERVES",
                style = MaterialTheme.typography.labelSmall,
                color = BrassGold,
                letterSpacing = 1.5.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Edinburgh Capital Reserve",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold,
                color = GraphiteDark
            )
            Spacer(modifier = Modifier.height(4.dp))
            SyntheticInstitutionBadge(text = "4.85% APY • DAILY COMPOUNDING")
        }

        // Main Savings Overview Card
        item {
            ScottishCard(
                backgroundColor = RhinoNavy,
                borderColor = BrassGold,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Text(
                        text = "EASY ACCESS SAVINGS",
                        style = MaterialTheme.typography.labelSmall,
                        color = EdinburghStoneDark,
                        letterSpacing = 1.2.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "£${String.format(Locale.UK, "%,.2f", savingsBalance)}",
                        style = MaterialTheme.typography.displayMedium,
                        fontWeight = FontWeight.Bold,
                        color = WarmWhite
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Current APY Rate", style = MaterialTheme.typography.bodySmall, color = EdinburghStoneDark)
                            Text("4.85% p.a.", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MintGain)
                        }
                        Column {
                            Text("Est. Annual Interest", style = MaterialTheme.typography.bodySmall, color = EdinburghStoneDark)
                            val annualInterest = savingsBalance * 0.0485
                            Text("£${String.format(Locale.UK, "%,.2f", annualInterest)}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = BrassGold)
                        }
                    }
                }
            }
        }

        // Goals Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Savings Goals",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = GraphiteDark
                )

                Button(
                    onClick = { isAddingGoal = !isAddingGoal },
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = RhinoNavy),
                    modifier = Modifier.testTag("btn_add_goal")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Add, contentDescription = null, tint = WarmWhite, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (isAddingGoal) "Cancel" else "New Goal", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }

        // Add New Goal Form
        if (isAddingGoal) {
            item {
                ScottishCard(
                    backgroundColor = SurfaceCardLight,
                    borderColor = ScottishBlue,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Create Goal",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = GraphiteDark
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = newGoalName,
                            onValueChange = { newGoalName = it },
                            label = { Text("Goal Name (e.g., Edinburgh House)") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = newGoalTarget,
                            onValueChange = { newGoalTarget = it },
                            label = { Text("Target Amount (£)") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = newGoalMonthly,
                            onValueChange = { newGoalMonthly = it },
                            label = { Text("Monthly Contribution (£)") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = {
                                val targetVal = newGoalTarget.toDoubleOrNull() ?: 5000.0
                                val monthlyVal = newGoalMonthly.toDoubleOrNull() ?: 250.0
                                if (newGoalName.isNotBlank()) {
                                    viewModel.createSavingsGoal(newGoalName, targetVal, monthlyVal, "Goal")
                                    newGoalName = ""
                                    newGoalTarget = ""
                                    newGoalMonthly = ""
                                    isAddingGoal = false
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = RhinoNavy)
                        ) {
                            Text("Save Goal", color = WarmWhite, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Savings Goals List
        items(savingsGoals) { goal ->
            val progress = (goal.currentAmount / goal.targetAmount).toFloat().coerceIn(0f, 1f)

            ScottishCard(
                onClick = { selectedGoalForContrib = goal },
                backgroundColor = SurfaceCardLight,
                borderColor = GraphiteBorder,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFE0F2FE)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (goal.category == "Property") Icons.Default.Home else Icons.Default.Shield,
                                    contentDescription = null,
                                    tint = ScottishBlue,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = goal.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = GraphiteDark
                                )
                                Text(
                                    text = "Target: £${String.format(Locale.UK, "%,.0f", goal.targetAmount)} • £${String.format(Locale.UK, "%.0f", goal.monthlyContribution)}/mo",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = GraphiteMuted
                                )
                            }
                        }

                        Text(
                            text = "£${String.format(Locale.UK, "%,.2f", goal.currentAmount)}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = GraphiteDark
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = ScottishBlue,
                        trackColor = Color(0xFFE2E8F0)
                    )

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "${(progress * 100).toInt()}% achieved • Tap to contribute",
                        style = MaterialTheme.typography.labelSmall,
                        color = GraphiteMedium
                    )
                }
            }
        }

        // Quick Contribution Input
        if (selectedGoalForContrib != null) {
            item {
                ScottishCard(
                    backgroundColor = SurfaceCardLight,
                    borderColor = BrassGold,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Contribute to ${selectedGoalForContrib?.name}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = GraphiteDark
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = contribAmountInput,
                            onValueChange = { contribAmountInput = it },
                            label = { Text("Contribution Amount (£)") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { selectedGoalForContrib = null },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = GraphiteMuted)
                            ) {
                                Text("Cancel")
                            }

                            Button(
                                onClick = {
                                    val amt = contribAmountInput.toDoubleOrNull() ?: 100.0
                                    viewModel.contributeToGoal(selectedGoalForContrib!!.id, amt) {
                                        selectedGoalForContrib = null
                                        contribAmountInput = ""
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = BrassGold)
                            ) {
                                Text("Transfer", color = RhinoNavy, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
