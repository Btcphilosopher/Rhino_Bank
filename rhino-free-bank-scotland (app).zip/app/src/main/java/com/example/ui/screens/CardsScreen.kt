package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Nfc
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.CardEntity
import com.example.ui.RhinoBankingViewModel
import com.example.ui.components.ScottishCard
import com.example.ui.components.SyntheticInstitutionBadge
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun CardsScreen(
    viewModel: RhinoBankingViewModel,
    modifier: Modifier = Modifier
) {
    val cards by viewModel.cards.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(WarmWhite)
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "RHINO CARD MANAGEMENT",
                style = MaterialTheme.typography.labelSmall,
                color = BrassGold,
                letterSpacing = 1.5.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Edinburgh Private Cards",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold,
                color = GraphiteDark
            )
            Spacer(modifier = Modifier.height(4.dp))
            SyntheticInstitutionBadge(text = "WORLD ELITE DEBIT & SINGLE-USE VIRTUAL")
        }

        items(cards) { card ->
            // Card Visual
            val cardBg = if (card.cardColorTheme == "NavyGold") RhinoNavy else Color(0xFF0D3B2E)

            ScottishCard(
                backgroundColor = if (card.isFrozen) GraphiteMedium else cardBg,
                borderColor = BrassGold,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "RHINO FREE BANK SCOTLAND",
                            style = MaterialTheme.typography.labelSmall,
                            color = BrassGold,
                            letterSpacing = 1.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Icon(Icons.Default.CreditCard, contentDescription = null, tint = WarmWhite)
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Text(
                        text = "•••• •••• •••• ${card.cardNumberLast4}",
                        style = MaterialTheme.typography.headlineMedium,
                        color = WarmWhite,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 2.sp
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("CARD HOLDER", style = MaterialTheme.typography.labelSmall, color = EdinburghStoneDark)
                            Text(card.cardHolder, style = MaterialTheme.typography.bodyMedium, color = WarmWhite, fontWeight = FontWeight.Bold)
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text("EXPIRES", style = MaterialTheme.typography.labelSmall, color = EdinburghStoneDark)
                            Text(card.expiry, style = MaterialTheme.typography.bodyMedium, color = WarmWhite, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Card Controls
            ScottishCard(
                backgroundColor = SurfaceCardLight,
                borderColor = GraphiteBorder,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Card Controls • ${card.cardType}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = GraphiteDark)
                    Spacer(modifier = Modifier.height(12.dp))

                    // Freeze Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (card.isFrozen) Icons.Default.Lock else Icons.Default.LockOpen,
                                contentDescription = null,
                                tint = if (card.isFrozen) SoftRed else MintGain
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Freeze Card", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = GraphiteDark)
                                Text(if (card.isFrozen) "Card is temporarily locked" else "Card is active", style = MaterialTheme.typography.bodySmall, color = GraphiteMuted)
                            }
                        }

                        Switch(
                            checked = card.isFrozen,
                            onCheckedChange = { viewModel.toggleCardFreeze(card) },
                            colors = SwitchDefaults.colors(checkedThumbColor = SoftRed),
                            modifier = Modifier.testTag("switch_freeze_${card.id}")
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Contactless Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Nfc, contentDescription = null, tint = ScottishBlue)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("Contactless Payments", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = GraphiteDark)
                        }

                        Switch(
                            checked = card.isContactlessEnabled,
                            onCheckedChange = { viewModel.toggleCardContactless(card) },
                            colors = SwitchDefaults.colors(checkedThumbColor = ScottishBlue)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Online Payments Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.ShoppingBag, contentDescription = null, tint = BrassGold)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("Online & App Payments", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = GraphiteDark)
                        }

                        Switch(
                            checked = card.isOnlineEnabled,
                            onCheckedChange = { viewModel.toggleCardOnline(card) },
                            colors = SwitchDefaults.colors(checkedThumbColor = BrassGold)
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
