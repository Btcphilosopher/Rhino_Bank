package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.RhinoBankingViewModel
import com.example.ui.components.ScottishCard
import com.example.ui.components.SyntheticInstitutionBadge
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun WealthScreen(
    viewModel: RhinoBankingViewModel,
    modifier: Modifier = Modifier
) {
    val accounts by viewModel.accounts.collectAsState()
    val mortgage by viewModel.mortgage.collectAsState()
    val privateNotes by viewModel.privateNotes.collectAsState()
    val investments by viewModel.investments.collectAsState()
    val simulatedOverpayment by viewModel.simulatedOverpayment.collectAsState()

    val currentBalance = accounts.find { it.id == "ACC-CURRENT-01" }?.balance ?: 12421.40
    val savingsBalance = accounts.find { it.id == "ACC-SAVINGS-01" }?.balance ?: 7400.00
    val digitalBalance = accounts.find { it.id == "ACC-DIGITAL-01" }?.balance ?: 1200.00
    val investBalance = accounts.find { it.id == "ACC-INVEST-01" }?.balance ?: 84821.40
    val notesBalance = privateNotes.sumOf { it.customerInvestedAmount }

    val propValuation = mortgage?.propertyValuation ?: 420000.0
    val mtgBalance = mortgage?.currentPrincipalRemaining ?: 284000.0
    val propertyEquity = propValuation - mtgBalance

    val totalAssets = currentBalance + savingsBalance + digitalBalance + investBalance + notesBalance + propValuation
    val totalLiabilities = mtgBalance
    val netWorth = totalAssets - totalLiabilities

    val amortization = viewModel.getAmortizationCalculation()

    var aiQueryInput by remember { mutableStateOf("") }
    val aiHistory by viewModel.aiHistory.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(WarmWhite)
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "CONSOLIDATED WEALTH & MORTGAGE",
                style = MaterialTheme.typography.labelSmall,
                color = BrassGold,
                letterSpacing = 1.5.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Edinburgh Net Worth Terminal",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold,
                color = GraphiteDark
            )
            Spacer(modifier = Modifier.height(4.dp))
            SyntheticInstitutionBadge(text = "UNIFIED PRIVATE BANKING BALANCE SHEET")
        }

        // Net Worth Card
        item {
            ScottishCard(
                backgroundColor = RhinoNavy,
                borderColor = BrassGold,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Text(
                        text = "CONSOLIDATED NET WORTH",
                        style = MaterialTheme.typography.labelSmall,
                        color = EdinburghStoneDark,
                        letterSpacing = 1.2.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "£${String.format(Locale.UK, "%,.2f", netWorth)}",
                        style = MaterialTheme.typography.displayMedium,
                        fontWeight = FontWeight.Bold,
                        color = WarmWhite
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Total Assets", style = MaterialTheme.typography.bodySmall, color = EdinburghStoneDark)
                            Text("£${String.format(Locale.UK, "%,.0f", totalAssets)}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MintGain)
                        }
                        Column {
                            Text("Total Liabilities", style = MaterialTheme.typography.bodySmall, color = EdinburghStoneDark)
                            Text("-£${String.format(Locale.UK, "%,.0f", totalLiabilities)}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = BrassGold)
                        }
                    }
                }
            }
        }

        // Asset Breakdown Table
        item {
            ScottishCard(
                backgroundColor = SurfaceCardLight,
                borderColor = GraphiteBorder,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Asset Distribution", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = GraphiteDark)
                    Spacer(modifier = Modifier.height(10.dp))

                    AssetRow("Liquid Accounts (Current, Savings, Digital)", currentBalance + savingsBalance + digitalBalance)
                    AssetRow("Rhino Invest & Securities", investBalance)
                    AssetRow("Rhino Private Notes", notesBalance)
                    AssetRow("Edinburgh Property Valuation", propValuation)
                    AssetRow("Heriot Row Mortgage Debt", -mtgBalance, isNegative = true)
                }
            }
        }

        // Mortgage Overpayment Simulator
        item {
            ScottishCard(
                backgroundColor = SurfaceCardLight,
                borderColor = ScottishBlue,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Rhino Home • Heriot Row Facility", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = GraphiteDark)
                            Text("14 Heriot Row, EH3 6HR • LTV 67.6%", style = MaterialTheme.typography.bodySmall, color = GraphiteMuted)
                        }
                        Icon(Icons.Default.Home, contentDescription = null, tint = ScottishBlue)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Mortgage Balance", style = MaterialTheme.typography.bodySmall, color = GraphiteMuted)
                            Text("£${String.format(Locale.UK, "%,.2f", mtgBalance)}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("Standard Monthly", style = MaterialTheme.typography.bodySmall, color = GraphiteMuted)
                            Text("£1,540.00", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("Rate", style = MaterialTheme.typography.bodySmall, color = GraphiteMuted)
                            Text("4.25% Fixed", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = ScottishBlue)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Simulate Monthly Overpayment: £${String.format(Locale.UK, "%.0f", simulatedOverpayment)}/mo",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = RhinoNavy
                    )

                    Slider(
                        value = simulatedOverpayment.toFloat(),
                        onValueChange = { viewModel.setSimulatedOverpayment(it.toDouble()) },
                        valueRange = 0f..1000f,
                        steps = 20,
                        colors = SliderDefaults.colors(thumbColor = RhinoNavy, activeTrackColor = ScottishBlue),
                        modifier = Modifier.testTag("slider_overpayment")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Surface(
                        color = Color(0xFFF0FDF4),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "Interest Saved: £${String.format(Locale.UK, "%,.2f", amortization.interestSaved)}",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MintGain
                            )
                            Text(
                                text = "Term Shortened: ${amortization.monthsSaved / 12} years and ${amortization.monthsSaved % 12} months earlier payoff",
                                style = MaterialTheme.typography.bodySmall,
                                color = GraphiteDark
                            )
                        }
                    }
                }
            }
        }

        // Rhino Intelligence AI Assistant Section
        item {
            ScottishCard(
                backgroundColor = RhinoNavy,
                borderColor = BrassGold,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = BrassGold)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "RHINO INTELLIGENCE AI",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = WarmWhite
                        )
                    }
                    Text(
                        text = "Query unified core ledger data directly with verified citations.",
                        style = MaterialTheme.typography.bodySmall,
                        color = EdinburghStoneDark
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // AI Query Input
                    OutlinedTextField(
                        value = aiQueryInput,
                        onValueChange = { aiQueryInput = it },
                        placeholder = { Text("e.g. How much did I spend on food? Show net worth.") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_ai_query"),
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BrassGold,
                            unfocusedBorderColor = GraphiteBorder,
                            focusedContainerColor = Color(0xFF132A4A),
                            unfocusedContainerColor = Color(0xFF132A4A),
                            focusedTextColor = WarmWhite,
                            unfocusedTextColor = WarmWhite
                        ),
                        trailingIcon = {
                            IconButton(
                                onClick = {
                                    if (aiQueryInput.isNotBlank()) {
                                        viewModel.askRhinoIntelligence(aiQueryInput)
                                        aiQueryInput = ""
                                    }
                                },
                                modifier = Modifier.testTag("btn_ask_ai")
                            ) {
                                Icon(Icons.Default.Send, contentDescription = "Ask", tint = BrassGold)
                            }
                        }
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    aiHistory.takeLast(3).forEach { resp ->
                        Surface(
                            color = Color(0xFF132B4A),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "Q: ${resp.question}",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = BrassGold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = resp.answer,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = WarmWhite
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = resp.citation,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = EdinburghStoneDark,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun AssetRow(label: String, amount: Double, isNegative: Boolean = false) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium, color = GraphiteMedium)
        Text(
            text = if (isNegative) "-£${String.format(Locale.UK, "%,.2f", kotlin.math.abs(amount))}" else "£${String.format(Locale.UK, "%,.2f", amount)}",
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            color = if (isNegative) Color.Red else GraphiteDark
        )
    }
}
