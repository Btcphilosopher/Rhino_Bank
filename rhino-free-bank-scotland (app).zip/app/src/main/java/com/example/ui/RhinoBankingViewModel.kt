package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.RhinoDatabase
import com.example.data.local.entity.AccountEntity
import com.example.data.local.entity.AuditLedgerEntity
import com.example.data.local.entity.CardEntity
import com.example.data.local.entity.ContactRecipientEntity
import com.example.data.local.entity.DigitalSterlingWalletEntity
import com.example.data.local.entity.FxRateEntity
import com.example.data.local.entity.InvestmentHoldingEntity
import com.example.data.local.entity.MortgageEntity
import com.example.data.local.entity.NotificationEntity
import com.example.data.local.entity.PrivateNoteEntity
import com.example.data.local.entity.SavingsGoalEntity
import com.example.data.local.entity.TransactionEntity
import com.example.data.repository.RhinoBankingRepository
import com.example.domain.engine.MortgageAmortizationCalculator
import com.example.domain.engine.PrivateNotePricingEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class PaymentPipelineState(
    val isProcessing: Boolean = false,
    val currentStepIndex: Int = 0,
    val stepDescriptions: List<String> = listOf(
        "Initiating Payment Request",
        "Biometric & Risk Assessment",
        "Double-Entry Ledger Journal Entry",
        "Rhino Consensus Validation (Edinburgh-01)",
        "Settlement Finality Confirmed"
    ),
    val completedTransaction: TransactionEntity? = null,
    val errorMessage: String? = null
)

data class AiChatResponse(
    val question: String,
    val answer: String,
    val citation: String,
    val timestamp: Long = System.currentTimeMillis()
)

class RhinoBankingViewModel(application: Application) : AndroidViewModel(application) {

    private val db = RhinoDatabase.getDatabase(application)
    private val repository = RhinoBankingRepository(db.bankingDao())

    val accounts: StateFlow<List<AccountEntity>> = repository.allAccounts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val transactions: StateFlow<List<TransactionEntity>> = repository.allTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val savingsGoals: StateFlow<List<SavingsGoalEntity>> = repository.allSavingsGoals
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val investments: StateFlow<List<InvestmentHoldingEntity>> = repository.allInvestments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val privateNotes: StateFlow<List<PrivateNoteEntity>> = repository.allPrivateNotes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val mortgage: StateFlow<MortgageEntity?> = repository.primaryMortgage
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val cards: StateFlow<List<CardEntity>> = repository.allCards
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val digitalWallet: StateFlow<DigitalSterlingWalletEntity?> = repository.digitalSterlingWallet
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val fxRates: StateFlow<List<FxRateEntity>> = repository.allFxRates
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<NotificationEntity>> = repository.allNotifications
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val auditEntries: StateFlow<List<AuditLedgerEntity>> = repository.allAuditEntries
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val contacts: StateFlow<List<ContactRecipientEntity>> = repository.allContacts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Payment Pipeline State
    private val _paymentPipeline = MutableStateFlow(PaymentPipelineState())
    val paymentPipeline = _paymentPipeline.asStateFlow()

    // Selected Transaction for Detail Modal
    private val _selectedTransaction = MutableStateFlow<TransactionEntity?>(null)
    val selectedTransaction = _selectedTransaction.asStateFlow()

    // AI Responses History
    private val _aiHistory = MutableStateFlow<List<AiChatResponse>>(emptyList())
    val aiHistory = _aiHistory.asStateFlow()

    // Interactive Mortgage Overpayment State
    private val _simulatedOverpayment = MutableStateFlow(200.0)
    val simulatedOverpayment = _simulatedOverpayment.asStateFlow()

    private val _simulatedInterestRate = MutableStateFlow(4.25)
    val simulatedInterestRate = _simulatedInterestRate.asStateFlow()

    init {
        // Trigger initial seed if needed
        viewModelScope.launch {
            db.seedInitialData()
        }
    }

    fun selectTransaction(tx: TransactionEntity?) {
        _selectedTransaction.value = tx
    }

    fun setSimulatedOverpayment(amount: Double) {
        _simulatedOverpayment.value = amount
    }

    fun setSimulatedInterestRate(rate: Double) {
        _simulatedInterestRate.value = rate
    }

    fun getAmortizationCalculation(): MortgageAmortizationCalculator.AmortizationResult {
        val currentMtg = mortgage.value
        val principal = currentMtg?.currentPrincipalRemaining ?: 284000.0
        val rate = _simulatedInterestRate.value
        val years = currentMtg?.termRemainingYears ?: 22
        val overpayment = _simulatedOverpayment.value
        return MortgageAmortizationCalculator.calculate(principal, rate, years, overpayment)
    }

    fun executePayment(
        fromAccountId: String,
        recipientName: String,
        recipientAccount: String,
        amount: Double,
        reference: String,
        paymentMethod: String,
        category: String,
        onSuccess: (TransactionEntity) -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            _paymentPipeline.value = PaymentPipelineState(isProcessing = true, currentStepIndex = 0)

            // Step 1: Authentication & Risk
            kotlinx.coroutines.delay(350)
            _paymentPipeline.value = _paymentPipeline.value.copy(currentStepIndex = 1)

            // Step 2: Double-entry ledger journal
            kotlinx.coroutines.delay(350)
            _paymentPipeline.value = _paymentPipeline.value.copy(currentStepIndex = 2)

            // Step 3: Consensus validation
            kotlinx.coroutines.delay(400)
            _paymentPipeline.value = _paymentPipeline.value.copy(currentStepIndex = 3)

            // Step 4: Finality settlement
            val result = repository.executePayment(
                fromAccountId = fromAccountId,
                recipientName = recipientName,
                recipientAccountOrHandle = recipientAccount,
                amount = amount,
                reference = reference,
                paymentMethod = paymentMethod,
                category = category
            )

            result.onSuccess { tx ->
                _paymentPipeline.value = _paymentPipeline.value.copy(
                    currentStepIndex = 4,
                    isProcessing = false,
                    completedTransaction = tx
                )
                onSuccess(tx)
            }.onFailure { err ->
                _paymentPipeline.value = _paymentPipeline.value.copy(
                    isProcessing = false,
                    errorMessage = err.message ?: "Payment failed"
                )
                onError(err.message ?: "Payment failed")
            }
        }
    }

    fun resetPaymentPipeline() {
        _paymentPipeline.value = PaymentPipelineState()
    }

    fun convertDigitalSterling(amount: Double, toDigitalSterling: Boolean, onResult: (String) -> Unit) {
        viewModelScope.launch {
            val res = repository.convertDigitalSterling(amount, toDigitalSterling)
            res.onSuccess { onResult(it) }.onFailure { onResult("Error: ${it.message}") }
        }
    }

    fun executeOfflineDigitalTap(amount: Double, merchant: String, onResult: (String) -> Unit) {
        viewModelScope.launch {
            val res = repository.executeOfflineDigitalPayment(amount, merchant)
            res.onSuccess { onResult(it) }.onFailure { onResult("Error: ${it.message}") }
        }
    }

    fun purchasePrivateNote(instrumentCode: String, amount: Double, onResult: (String) -> Unit) {
        viewModelScope.launch {
            val res = repository.purchasePrivateNote(instrumentCode, amount)
            res.onSuccess { onResult(it) }.onFailure { onResult("Error: ${it.message}") }
        }
    }

    fun createSavingsGoal(name: String, target: Double, monthly: Double, category: String) {
        viewModelScope.launch {
            val goal = SavingsGoalEntity(
                id = "GOAL-" + java.util.UUID.randomUUID().toString().take(6).uppercase(),
                name = name,
                targetAmount = target,
                currentAmount = 0.0,
                monthlyContribution = monthly,
                targetDateEpoch = System.currentTimeMillis() + (365L * 86400000L),
                category = category
            )
            repository.createSavingsGoal(goal)
        }
    }

    fun contributeToGoal(goalId: String, amount: Double, onResult: (String) -> Unit) {
        viewModelScope.launch {
            val res = repository.contributeToSavingsGoal(goalId, amount)
            res.onSuccess { onResult(it) }.onFailure { onResult("Error: ${it.message}") }
        }
    }

    fun toggleCardFreeze(card: CardEntity) {
        viewModelScope.launch {
            repository.updateCard(card.copy(isFrozen = !card.isFrozen))
        }
    }

    fun toggleCardContactless(card: CardEntity) {
        viewModelScope.launch {
            repository.updateCard(card.copy(isContactlessEnabled = !card.isContactlessEnabled))
        }
    }

    fun toggleCardOnline(card: CardEntity) {
        viewModelScope.launch {
            repository.updateCard(card.copy(isOnlineEnabled = !card.isOnlineEnabled))
        }
    }

    fun askRhinoIntelligence(query: String) {
        val q = query.trim().lowercase()
        val currentBalance = accounts.value.find { it.id == "ACC-CURRENT-01" }?.balance ?: 12421.40
        val savingsBalance = accounts.value.find { it.id == "ACC-SAVINGS-01" }?.balance ?: 7400.00
        val investBalance = accounts.value.find { it.id == "ACC-INVEST-01" }?.balance ?: 84821.40
        val digitalBalance = accounts.value.find { it.id == "ACC-DIGITAL-01" }?.balance ?: 1200.00
        val notesBalance = privateNotes.value.sumOf { it.customerInvestedAmount }
        val mtg = mortgage.value
        val mtgBalance = mtg?.currentPrincipalRemaining ?: 284000.0
        val propertyVal = mtg?.propertyValuation ?: 420000.0
        val netWorth = currentBalance + savingsBalance + investBalance + digitalBalance + notesBalance + (propertyVal - mtgBalance)

        val (answer, citation) = when {
            "food" in q || "groceries" in q || "spend" in q -> {
                val foodTxs = transactions.value.filter { it.category == "Groceries" || it.category == "Dining" }
                val totalSpent = foodTxs.sumOf { kotlin.math.abs(it.amount) }
                Pair(
                    "You have spent £${String.format("%.2f", totalSpent)} on food and dining this month across ${foodTxs.size} transactions, including £46.20 at Tesco Broughton and £4.80 at Artisan Roast.",
                    "Source: Ledger Records (ACC-CURRENT-01, ACC-DIGITAL-01)"
                )
            }
            "mortgage" in q || "overpay" in q -> {
                val calc = getAmortizationCalculation()
                Pair(
                    "Your current mortgage on Heriot Row is £${String.format("%,.2f", mtgBalance)} at 4.25%. With an overpayment of £${String.format("%.0f", _simulatedOverpayment.value)}/month, you will save £${String.format("%,.2f", calc.interestSaved)} in interest and pay off the loan ${calc.monthsSaved / 12} years and ${calc.monthsSaved % 12} months earlier.",
                    "Source: Amortization Engine • Heriot Row Facility (MTG-EDIN-0941)"
                )
            }
            "net worth" in q || "wealth" in q || "total" in q -> {
                Pair(
                    "Your total estimated net worth is £${String.format("%,.2f", netWorth)}. This comprises £${String.format("%,.2f", currentBalance + savingsBalance + digitalBalance)} liquid funds, £${String.format("%,.2f", investBalance + notesBalance)} investments and private notes, and £${String.format("%,.2f", propertyVal - mtgBalance)} net property equity.",
                    "Source: Rhino Unified Wealth Consolidated Balance Sheet"
                )
            }
            "digital sterling" in q || "wallet" in q -> {
                Pair(
                    "You have £${String.format("%.2f", digitalBalance)} in Digital Sterling online, with £120.00 pre-loaded for offline NFC payments. Simulated network finality is currently 0.4 seconds across 25 Scottish nodes.",
                    "Source: Digital Sterling Wallet (dgbp:rhino:scot:99a820b)"
                )
            }
            "note" in q || "private note" in q -> {
                Pair(
                    "You hold £5,000 in Rhino Edinburgh Note 01 earning 5.25% semi-annual coupon. It has generated £131.25 in accrued interest with 4.38 years modified duration.",
                    "Source: Rhino Private Placement Desk (RHINO-EDIN-01)"
                )
            }
            else -> {
                Pair(
                    "Based on your active accounts, you have £${String.format("%,.2f", currentBalance)} available in your Current Account, £${String.format("%,.2f", savingsBalance)} in Savings earning 4.85% APY, and your upcoming mortgage payment of £1,540.00 is due this Friday.",
                    "Source: Rhino Customer Core Ledger"
                )
            }
        }

        _aiHistory.value = _aiHistory.value + AiChatResponse(
            question = query,
            answer = answer,
            citation = citation
        )
    }
}
