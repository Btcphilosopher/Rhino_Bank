package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class AccountType {
    CURRENT,
    SAVINGS_EASY_ACCESS,
    SAVINGS_FIXED,
    DIGITAL_STERLING,
    INVESTMENT,
    PRIVATE_NOTE,
    MORTGAGE,
    BUSINESS_CURRENT,
    TREASURY
}

@Entity(tableName = "accounts")
data class AccountEntity(
    @PrimaryKey val id: String, // e.g. "ACC-CURRENT-01"
    val accountNumber: String, // e.g. "80201944"
    val sortCode: String, // e.g. "80-22-60" (Edinburgh Central)
    val iban: String, // e.g. "GB80RHIN80226080201944"
    val accountName: String,
    val accountType: AccountType,
    val balance: Double,
    val currency: String = "GBP",
    val apyRate: Double = 0.0, // interest rate
    val isPrimary: Boolean = false,
    val lastUpdated: Long = System.currentTimeMillis()
)
