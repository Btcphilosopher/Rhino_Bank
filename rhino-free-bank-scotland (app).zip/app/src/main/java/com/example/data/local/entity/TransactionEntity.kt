package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TransactionType {
    INCOMING_TRANSFER,
    OUTGOING_PAYMENT,
    CARD_PURCHASE,
    SAVINGS_TRANSFER,
    INVESTMENT_PURCHASE,
    INVESTMENT_DIVIDEND,
    NOTE_SUBSCRIPTION,
    NOTE_COUPON,
    DIGITAL_STERLING_CONVERSION,
    DIGITAL_STERLING_TRANSFER,
    MORTGAGE_REPAYMENT,
    FX_EXCHANGE,
    INTEREST_EARNED
}

enum class TransactionStatus {
    PENDING,
    AUTHENTICATED,
    RISK_CLEARED,
    LEDGER_RECORDED,
    CONSENSUS_ATTESTED,
    COMPLETED,
    FAILED
}

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey val id: String, // e.g. "TX-2026-98124"
    val accountId: String,
    val title: String, // e.g. "Tesco", "Salary", "Edinburgh Coffee"
    val subtitle: String, // e.g. "Card payment • Groceries", "Direct credit"
    val amount: Double, // Negative for debits, positive for credits
    val currency: String = "GBP",
    val type: TransactionType,
    val status: TransactionStatus,
    val timestamp: Long,
    val counterpartyName: String,
    val counterpartyAccount: String = "",
    val reference: String = "",
    val category: String = "General",
    val location: String = "Edinburgh, UK",
    val paymentMethod: String = "Rhino Current Account",
    val fee: Double = 0.0,
    val auditHash: String = "",
    val blockHeight: Long = 0L,
    val validatorName: String = "EDINBURGH-01",
    val receiptNotes: String = ""
)
