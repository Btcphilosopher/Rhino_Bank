package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.dao.RhinoBankingDao
import com.example.data.local.entity.AccountEntity
import com.example.data.local.entity.AccountType
import com.example.data.local.entity.AuditLedgerEntity
import com.example.data.local.entity.CardEntity
import com.example.data.local.entity.ContactRecipientEntity
import com.example.data.local.entity.DigitalSterlingWalletEntity
import com.example.data.local.entity.FxRateEntity
import com.example.data.local.entity.InvestmentHoldingEntity
import com.example.data.local.entity.MortgageEntity
import com.example.data.local.entity.NotificationEntity
import com.example.data.local.entity.PrivateNoteEntity
import com.example.data.local.entity.SavingsGoalEntity
import com.example.data.local.entity.TransactionEntity
import com.example.data.local.entity.TransactionStatus
import com.example.data.local.entity.TransactionType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        AccountEntity::class,
        TransactionEntity::class,
        SavingsGoalEntity::class,
        InvestmentHoldingEntity::class,
        PrivateNoteEntity::class,
        MortgageEntity::class,
        CardEntity::class,
        DigitalSterlingWalletEntity::class,
        FxRateEntity::class,
        NotificationEntity::class,
        AuditLedgerEntity::class,
        ContactRecipientEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class RhinoDatabase : RoomDatabase() {
    abstract fun bankingDao(): RhinoBankingDao

    companion object {
        @Volatile
        private var INSTANCE: RhinoDatabase? = null

        fun getDatabase(context: Context): RhinoDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    RhinoDatabase::class.java,
                    "rhino_bank_scotland.db"
                ).addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        CoroutineScope(Dispatchers.IO).launch {
                            getDatabase(context).seedInitialData()
                        }
                    }
                }).build()
                INSTANCE = instance
                instance
            }
        }
    }

    suspend fun seedInitialData() {
        val dao = bankingDao()
        val now = System.currentTimeMillis()

        // 1. Accounts
        val accounts = listOf(
            AccountEntity(
                id = "ACC-CURRENT-01",
                accountNumber = "80201944",
                sortCode = "80-22-60",
                iban = "GB80RHIN80226080201944",
                accountName = "Rhino Current Account",
                accountType = AccountType.CURRENT,
                balance = 12421.40,
                apyRate = 2.10,
                isPrimary = true,
                lastUpdated = now
            ),
            AccountEntity(
                id = "ACC-SAVINGS-01",
                accountNumber = "80201955",
                sortCode = "80-22-60",
                iban = "GB80RHIN80226080201955",
                accountName = "Easy Access Savings",
                accountType = AccountType.SAVINGS_EASY_ACCESS,
                balance = 7400.00,
                apyRate = 4.85,
                isPrimary = false,
                lastUpdated = now
            ),
            AccountEntity(
                id = "ACC-DIGITAL-01",
                accountNumber = "80201966",
                sortCode = "80-22-60",
                iban = "GB80RHIN80226080201966",
                accountName = "Digital Sterling Wallet",
                accountType = AccountType.DIGITAL_STERLING,
                balance = 1200.00,
                apyRate = 0.0,
                isPrimary = false,
                lastUpdated = now
            ),
            AccountEntity(
                id = "ACC-INVEST-01",
                accountNumber = "80201977",
                sortCode = "80-22-60",
                iban = "GB80RHIN80226080201977",
                accountName = "Rhino Invest Portfolio",
                accountType = AccountType.INVESTMENT,
                balance = 84821.40,
                apyRate = 8.40,
                isPrimary = false,
                lastUpdated = now
            ),
            AccountEntity(
                id = "ACC-NOTES-01",
                accountNumber = "80201988",
                sortCode = "80-22-60",
                iban = "GB80RHIN80226080201988",
                accountName = "Private Notes Desk",
                accountType = AccountType.PRIVATE_NOTE,
                balance = 5000.00,
                apyRate = 5.25,
                isPrimary = false,
                lastUpdated = now
            )
        )
        dao.insertAccounts(accounts)

        // 2. Transactions
        val dayMillis = 86400000L
        val transactions = listOf(
            TransactionEntity(
                id = "TX-2026-001",
                accountId = "ACC-CURRENT-01",
                title = "Salary Deposit",
                subtitle = "Edinburgh Financial Tech • Direct Credit",
                amount = 4250.00,
                type = TransactionType.INCOMING_TRANSFER,
                status = TransactionStatus.COMPLETED,
                timestamp = now - (1L * dayMillis),
                counterpartyName = "Edinburgh FinTech Labs Ltd",
                counterpartyAccount = "80-11-22 99482100",
                reference = "SAL-SEP-2026",
                category = "Income",
                location = "Edinburgh, UK",
                paymentMethod = "Faster Payments Direct",
                auditHash = "b84f3e...991a",
                blockHeight = 142091L
            ),
            TransactionEntity(
                id = "TX-2026-002",
                accountId = "ACC-CURRENT-01",
                title = "Tesco Superstore",
                subtitle = "Card Payment • Groceries",
                amount = -46.20,
                type = TransactionType.CARD_PURCHASE,
                status = TransactionStatus.COMPLETED,
                timestamp = now - (2L * dayMillis),
                counterpartyName = "Tesco Broughton",
                counterpartyAccount = "POS-TESCO-EDIN",
                reference = "GROCERY-0941",
                category = "Groceries",
                location = "Broughton Rd, Edinburgh",
                paymentMethod = "Rhino Debit Card (*9842)",
                auditHash = "71f82c...310d",
                blockHeight = 142084L
            ),
            TransactionEntity(
                id = "TX-2026-003",
                accountId = "ACC-CURRENT-01",
                title = "Scottish Power",
                subtitle = "Direct Debit • Utilities",
                amount = -123.00,
                type = TransactionType.OUTGOING_PAYMENT,
                status = TransactionStatus.COMPLETED,
                timestamp = now - (3L * dayMillis),
                counterpartyName = "Scottish Power Energy Retail",
                counterpartyAccount = "80-00-01 44556677",
                reference = "SP-ENERGY-66219",
                category = "Utilities",
                location = "Glasgow, UK",
                paymentMethod = "Direct Debit",
                auditHash = "99ae41...55c2",
                blockHeight = 142055L
            ),
            TransactionEntity(
                id = "TX-2026-004",
                accountId = "ACC-INVEST-01",
                title = "Rhino Invest Dividend",
                subtitle = "Scottish Infrastructure Gilt Income",
                amount = 82.40,
                type = TransactionType.INVESTMENT_DIVIDEND,
                status = TransactionStatus.COMPLETED,
                timestamp = now - (4L * dayMillis),
                counterpartyName = "Rhino Asset Management",
                counterpartyAccount = "TREASURY-01",
                reference = "DIV-SCOT-Q3",
                category = "Investments",
                location = "Edinburgh, UK",
                paymentMethod = "Portfolio Credit",
                auditHash = "32dd10...ea88",
                blockHeight = 142010L
            ),
            TransactionEntity(
                id = "TX-2026-005",
                accountId = "ACC-CURRENT-01",
                title = "Transfer to Savings",
                subtitle = "Easy Access Savings Reserve",
                amount = -500.00,
                type = TransactionType.SAVINGS_TRANSFER,
                status = TransactionStatus.COMPLETED,
                timestamp = now - (5L * dayMillis),
                counterpartyName = "Easy Access Savings",
                counterpartyAccount = "80-22-60 80201955",
                reference = "MONTHLY-SAVE-EDIN",
                category = "Savings",
                location = "Edinburgh, UK",
                paymentMethod = "Internal Book Transfer",
                auditHash = "55ac91...33fd",
                blockHeight = 141980L
            ),
            TransactionEntity(
                id = "TX-2026-006",
                accountId = "ACC-DIGITAL-01",
                title = "Edinburgh Coffee Roast",
                subtitle = "Digital Sterling Settlement",
                amount = -4.80,
                type = TransactionType.DIGITAL_STERLING_TRANSFER,
                status = TransactionStatus.COMPLETED,
                timestamp = now - (6L * 3600000L),
                counterpartyName = "Artisan Roast George St",
                counterpartyAccount = "dgbp:rhino:artisan:01",
                reference = "COFFEE-POS-89",
                category = "Dining",
                location = "George St, Edinburgh",
                paymentMethod = "Digital Sterling (0.4s finality)",
                auditHash = "ec441b...7721",
                blockHeight = 142105L
            )
        )
        dao.insertTransactions(transactions)

        // 3. Savings Goals
        val savingsGoals = listOf(
            SavingsGoalEntity(
                id = "GOAL-EDIN-HOME",
                name = "Edinburgh House",
                targetAmount = 12000.00,
                currentAmount = 7200.00,
                monthlyContribution = 500.00,
                targetDateEpoch = now + (365L * 2L * dayMillis),
                iconName = "home",
                category = "Property"
            ),
            SavingsGoalEntity(
                id = "GOAL-EMERGENCY",
                name = "Emergency Reserve",
                targetAmount = 5000.00,
                currentAmount = 4500.00,
                monthlyContribution = 250.00,
                targetDateEpoch = now + (90L * dayMillis),
                iconName = "shield",
                category = "Reserve"
            ),
            SavingsGoalEntity(
                id = "GOAL-HIGHLANDS",
                name = "Highlands & Islands Trip",
                targetAmount = 1800.00,
                currentAmount = 1200.00,
                monthlyContribution = 200.00,
                targetDateEpoch = now + (120L * dayMillis),
                iconName = "travel",
                category = "Travel"
            )
        )
        dao.insertSavingsGoals(savingsGoals)

        // 4. Investments
        val investments = listOf(
            InvestmentHoldingEntity(
                symbol = "SCOT-INFRA-GILT",
                name = "Scottish Clean Energy & Grid Gilt",
                assetClass = "Infrastructure",
                units = 250.0,
                averageCostPrice = 98.20,
                currentPrice = 104.50,
                dailyChangePercent = 0.45,
                annualDividendYield = 5.40,
                incomeYtd = 1350.00,
                riskRating = "Low-Medium (2/5)",
                isin = "GB00RHIN7721",
                description = "High-grade Scottish renewable power grid bonds with index-linked yields."
            ),
            InvestmentHoldingEntity(
                symbol = "RHINO-EQUITY-INDEX",
                name = "Rhino Scotland & UK Blue Chip",
                assetClass = "UK Equities",
                units = 180.0,
                averageCostPrice = 142.00,
                currentPrice = 168.20,
                dailyChangePercent = 0.82,
                annualDividendYield = 3.80,
                incomeYtd = 1140.00,
                riskRating = "Medium (3/5)",
                isin = "GB00RHIN9910",
                description = "Diversified index basket of leading Scottish and British enterprise leaders."
            ),
            InvestmentHoldingEntity(
                symbol = "GLB-TECH-INNOV",
                name = "Global CleanTech & Robotics Fund",
                assetClass = "Global Equities",
                units = 95.0,
                averageCostPrice = 210.00,
                currentPrice = 248.80,
                dailyChangePercent = -0.15,
                annualDividendYield = 1.90,
                incomeYtd = 450.00,
                riskRating = "High (4/5)",
                isin = "IE00RHIN3381",
                description = "Global frontier technologies, semiconductors, and sustainable energy."
            )
        )
        dao.insertInvestments(investments)

        // 5. Private Notes
        val privateNotes = listOf(
            PrivateNoteEntity(
                instrumentCode = "RHINO-EDIN-01",
                instrumentName = "Rhino Edinburgh Note 01",
                issuer = "Rhino Free Bank Scotland PLC",
                faceValueTotal = 100000000.0,
                couponRate = 0.0525, // 5.25%
                maturityYears = 5,
                paymentFrequency = "Semi-Annual",
                minInvestment = 1000.0,
                collateralSummary = "Synthetic Scottish Municipal & Infrastructure Receivables",
                seniority = "Senior Secured",
                creditProfile = "AA- Synthetic",
                durationYears = 4.38,
                convexity = 22.4,
                creditSpreadBps = 110,
                customerInvestedAmount = 5000.0,
                accruedInterest = 131.25,
                markToMarketPrice = 101.40
            ),
            PrivateNoteEntity(
                instrumentCode = "RHINO-INFRA-07",
                instrumentName = "Rhino Highlands Grid Note",
                issuer = "Rhino Free Bank Scotland PLC",
                faceValueTotal = 50000000.0,
                couponRate = 0.0610, // 6.10%
                maturityYears = 7,
                paymentFrequency = "Quarterly",
                minInvestment = 2500.0,
                collateralSummary = "Offshore Wind Generation & Battery Storage Contracts",
                seniority = "First Lien Senior",
                creditProfile = "A+ Synthetic",
                durationYears = 5.82,
                convexity = 36.1,
                creditSpreadBps = 165,
                customerInvestedAmount = 0.0,
                accruedInterest = 0.0,
                markToMarketPrice = 100.00
            )
        )
        dao.insertPrivateNotes(privateNotes)

        // 6. Mortgage
        val mortgage = MortgageEntity(
            id = "MTG-EDIN-0941",
            propertyAddress = "14 Heriot Row, Edinburgh New Town, EH3 6HR",
            propertyValuation = 420000.00,
            originalPrincipal = 320000.00,
            currentPrincipalRemaining = 284000.00,
            interestRate = 4.25,
            termRemainingYears = 22,
            monthlyPayment = 1540.00,
            monthlyOverpayment = 0.0
        )
        dao.insertMortgage(mortgage)

        // 7. Cards
        val cards = listOf(
            CardEntity(
                id = "CARD-RHINO-01",
                cardNumberLast4 = "9842",
                cardHolder = "TOM MACINTYRE",
                expiry = "09/29",
                cvv = "482",
                cardType = "Rhino Debit • World Elite",
                isFrozen = false,
                isContactlessEnabled = true,
                isOnlineEnabled = true,
                isAtmEnabled = true,
                dailyLimit = 2500.0,
                monthlySpent = 742.80,
                cardColorTheme = "NavyGold",
                travelModeActive = false,
                travelDestination = "United Kingdom"
            ),
            CardEntity(
                id = "CARD-RHINO-02",
                cardNumberLast4 = "3310",
                cardHolder = "TOM MACINTYRE",
                expiry = "11/30",
                cvv = "192",
                cardType = "Rhino Virtual Single-Use",
                isFrozen = false,
                isContactlessEnabled = false,
                isOnlineEnabled = true,
                isAtmEnabled = false,
                dailyLimit = 500.0,
                monthlySpent = 120.00,
                cardColorTheme = "DarkEmerald",
                travelModeActive = false,
                travelDestination = "United Kingdom"
            )
        )
        dao.insertCards(cards)

        // 8. Digital Sterling Wallet
        val wallet = DigitalSterlingWalletEntity(
            walletAddress = "dgbp:rhino:scot:99a820b",
            onlineBalance = 1200.00,
            offlineBalance = 120.00,
            offlineLimit = 250.00,
            deviceKeyId = "DEV-SECURE-ENCLAVE-EDIN-09",
            isLocked = false,
            totalSettledTransactions = 48,
            lastSyncTimestamp = now
        )
        dao.insertDigitalSterlingWallet(wallet)

        // 9. FX Rates
        val fxRates = listOf(
            FxRateEntity("GBP/EUR", "GBP", "EUR", 1.1845, 1.1842, 1.1848, 6.0, 0.22, "€"),
            FxRateEntity("GBP/USD", "GBP", "USD", 1.3120, 1.3117, 1.3123, 6.0, -0.15, "$"),
            FxRateEntity("GBP/CHF", "GBP", "CHF", 1.1210, 1.1206, 1.1214, 8.0, 0.08, "CHF"),
            FxRateEntity("GBP/JPY", "GBP", "JPY", 192.40, 192.35, 192.45, 10.0, 0.41, "¥"),
            FxRateEntity("GBP/AUD", "GBP", "AUD", 1.9480, 1.9472, 1.9488, 16.0, -0.05, "A$")
        )
        dao.insertFxRates(fxRates)

        // 10. Notifications
        val notifications = listOf(
            NotificationEntity(
                id = "NOTIF-01",
                title = "Mortgage Payment Due",
                message = "Your scheduled mortgage payment of £1,540.00 is due this Friday.",
                category = "Mortgage",
                timestamp = now - (2 * 3600000L),
                isRead = false,
                actionDeepLink = "MORTGAGE"
            ),
            NotificationEntity(
                id = "NOTIF-02",
                title = "Investment Dividend Received",
                message = "£82.40 dividend received from Scottish Clean Energy Gilt.",
                category = "Invest",
                timestamp = now - (1L * dayMillis),
                isRead = false,
                actionDeepLink = "INVEST"
            ),
            NotificationEntity(
                id = "NOTIF-03",
                title = "Salary Credited",
                message = "£4,250.00 credited to Rhino Current Account from Edinburgh FinTech Labs.",
                category = "Money",
                timestamp = now - (2L * dayMillis),
                isRead = true,
                actionDeepLink = "HOME"
            )
        )
        dao.insertNotifications(notifications)

        // 11. Contacts
        val contacts = listOf(
            ContactRecipientEntity("CONT-01", "Fiona Campbell", "80-11-22", "99120044", "@fiona_edin", "dgbp:rhino:fiona:01", "Personal", "FC"),
            ContactRecipientEntity("CONT-02", "Artisan Roast Edinburgh", "80-22-60", "33445566", "@artisanroast", "dgbp:rhino:artisan:01", "Business", "AR"),
            ContactRecipientEntity("CONT-03", "Scottish Power", "80-00-01", "44556677", "@scottishpower", "", "Utility", "SP"),
            ContactRecipientEntity("CONT-04", "Alastair MacLeod", "80-33-11", "77889900", "@alastair_m", "dgbp:rhino:alastair:02", "Personal", "AM")
        )
        dao.insertContacts(contacts)

        // 12. Audit ledger seed
        val auditEntries = listOf(
            AuditLedgerEntity(
                auditId = "AUDIT-2026-991",
                timestamp = now - (1L * dayMillis),
                eventType = "INCOMING_SALARY_SETTLEMENT",
                debitAccountId = "CENTRAL-CLEARING-EDIN",
                creditAccountId = "ACC-CURRENT-01",
                amount = 4250.00,
                reference = "SAL-SEP-2026",
                blockHeight = 142091L,
                validatorName = "EDINBURGH-01",
                cryptographicHash = "SHA256:7f4a2108849bca7120a1ce"
            ),
            AuditLedgerEntity(
                auditId = "AUDIT-2026-992",
                timestamp = now - (2L * dayMillis),
                eventType = "POS_CARD_SETTLEMENT",
                debitAccountId = "ACC-CURRENT-01",
                creditAccountId = "TESCO-MERCHANT-POOL",
                amount = 46.20,
                reference = "GROCERY-0941",
                blockHeight = 142084L,
                validatorName = "GLASGOW-01",
                cryptographicHash = "SHA256:1a998fe240bcd00174aa91"
            )
        )
        dao.insertAuditEntries(auditEntries)
    }
}
