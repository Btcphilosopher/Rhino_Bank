package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "fx_rates")
data class FxRateEntity(
    @PrimaryKey val currencyPair: String, // e.g. "GBP/EUR", "GBP/USD", "GBP/CHF"
    val baseCurrency: String,
    val quoteCurrency: String,
    val spotRate: Double,
    val bidRate: Double,
    val offerRate: Double,
    val spreadBps: Double,
    val change24hPct: Double,
    val currencySymbol: String
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey val id: String,
    val title: String,
    val message: String,
    val category: String, // "Money", "Mortgage", "Invest", "Security", "DigitalSterling"
    val timestamp: Long,
    val isRead: Boolean = false,
    val actionDeepLink: String = ""
)

@Entity(tableName = "audit_ledger")
data class AuditLedgerEntity(
    @PrimaryKey val auditId: String, // e.g. "LEDGER-AUDIT-9921"
    val timestamp: Long,
    val eventType: String,
    val debitAccountId: String,
    val creditAccountId: String,
    val amount: Double,
    val currency: String = "GBP",
    val reference: String,
    val blockHeight: Long,
    val validatorName: String,
    val cryptographicHash: String,
    val isReconciled: Boolean = true
)

@Entity(tableName = "contacts")
data class ContactRecipientEntity(
    @PrimaryKey val id: String,
    val name: String,
    val accountNumber: String,
    val sortCode: String,
    val rhinoHandle: String = "",
    val digitalSterlingAddress: String = "",
    val category: String = "Personal", // "Personal", "Business", "Utility"
    val avatarInitials: String = ""
)
