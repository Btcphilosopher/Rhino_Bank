package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "digital_sterling_wallet")
data class DigitalSterlingWalletEntity(
    @PrimaryKey val walletAddress: String, // e.g. "dgbp:rhino:scot:99a820b"
    val onlineBalance: Double, // e.g. £1,200.00
    val offlineBalance: Double, // e.g. £120.00
    val offlineLimit: Double = 250.00,
    val deviceKeyId: String = "DEV-SECURE-ENCLAVE-EDIN-09",
    val isLocked: Boolean = false,
    val totalSettledTransactions: Int = 48,
    val lastSyncTimestamp: Long = System.currentTimeMillis()
)
