package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cards")
data class CardEntity(
    @PrimaryKey val id: String, // e.g. "CARD-RHINO-01"
    val cardNumberLast4: String, // e.g. "9842"
    val cardHolder: String, // e.g. "TOM MACINTYRE"
    val expiry: String, // e.g. "09/29"
    val cvv: String = "482",
    val cardType: String = "Rhino Debit • World Elite",
    val isFrozen: Boolean = false,
    val isContactlessEnabled: Boolean = true,
    val isOnlineEnabled: Boolean = true,
    val isAtmEnabled: Boolean = true,
    val dailyLimit: Double = 2500.0,
    val monthlySpent: Double = 742.80,
    val cardColorTheme: String = "NavyGold", // "NavyGold", "DarkEmerald", "ObsidianSteel"
    val travelModeActive: Boolean = false,
    val travelDestination: String = "United Kingdom"
)
