package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "private_notes")
data class PrivateNoteEntity(
    @PrimaryKey val instrumentCode: String, // e.g. "RHINO-EDIN-01", "RHINO-INFRA-07"
    val instrumentName: String, // e.g. "Rhino Edinburgh Note 01"
    val issuer: String = "Rhino Free Bank Scotland PLC",
    val faceValueTotal: Double = 100000000.0, // £100M
    val couponRate: Double = 0.0525, // 5.25%
    val maturityYears: Int = 5,
    val paymentFrequency: String = "Semi-Annual",
    val minInvestment: Double = 1000.0,
    val collateralSummary: String = "Scottish Green Infrastructure & Municipal Receivables",
    val seniority: String = "Senior Secured",
    val creditProfile: String = "AA- Synthetic",
    val durationYears: Double = 4.38,
    val convexity: Double = 22.4,
    val creditSpreadBps: Int = 110,
    val customerInvestedAmount: Double = 0.0, // amount customer currently holds
    val accruedInterest: Double = 0.0,
    val markToMarketPrice: Double = 101.40, // 101.4%
    val issueDateEpoch: Long = System.currentTimeMillis() - (180L * 86400000L),
    val maturityDateEpoch: Long = System.currentTimeMillis() + (365L * 4L * 86400000L)
)
