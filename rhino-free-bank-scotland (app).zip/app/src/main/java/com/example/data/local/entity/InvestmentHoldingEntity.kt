package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "investments")
data class InvestmentHoldingEntity(
    @PrimaryKey val symbol: String, // e.g. "SCOT-INFRA-GILT", "FTSE100-SCOT", "GLB-CLEANTECH"
    val name: String,
    val assetClass: String, // "UK Equities", "Global Equities", "Bonds", "Infrastructure", "Gilts"
    val units: Double,
    val averageCostPrice: Double,
    val currentPrice: Double,
    val dailyChangePercent: Double,
    val annualDividendYield: Double,
    val incomeYtd: Double,
    val riskRating: String = "Medium (3/5)",
    val isin: String = "GB00RHIN7721",
    val description: String = ""
)
