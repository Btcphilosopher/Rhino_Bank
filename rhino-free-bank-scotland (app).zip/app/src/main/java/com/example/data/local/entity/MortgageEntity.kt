package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "mortgages")
data class MortgageEntity(
    @PrimaryKey val id: String, // e.g. "MTG-EDIN-0941"
    val propertyAddress: String, // e.g. "14 Heriot Row, Edinburgh New Town, EH3 6HR"
    val propertyValuation: Double, // e.g. £420,000.00
    val originalPrincipal: Double, // e.g. £320,000.00
    val currentPrincipalRemaining: Double, // e.g. £284,000.00
    val interestRate: Double, // e.g. 4.25%
    val termRemainingYears: Int, // e.g. 22
    val monthlyPayment: Double, // e.g. £1,540.00
    val monthlyOverpayment: Double = 0.0,
    val nextPaymentDateEpoch: Long = System.currentTimeMillis() + (5L * 86400000L), // due in 5 days (Friday)
    val fixedUntilEpoch: Long = System.currentTimeMillis() + (365L * 3L * 86400000L)
)
