package com.example.data.repository

import com.example.data.local.dao.RhinoBankingDao
import com.example.data.local.entity.AccountEntity
import com.example.data.local.entity.AccountType
import com.example.data.local.entity.AuditLedgerEntity
import com.example.data.local.entity.CardEntity
import com.example.data.local.entity.ContactRecipientEntity
import com.example.data.local.entity.DigitalSterlingWalletEntity
import com.example.data.local.entity.FxRateEntity
import com.example.data.local.entity.InvestmentHoldingEntity
import com.example.data.local.entity.MortgageEntity
import com.example.data.local.entity.NotificationEntity
import com.example.data.local.entity.PrivateNoteEntity
import com.example.data.local.entity.SavingsGoalEntity
import com.example.data.local.entity.TransactionEntity
import com.example.data.local.entity.TransactionStatus
import com.example.data.local.entity.TransactionType
import kotlinx.coroutines.flow.Flow
import java.security.MessageDigest
import java.util.UUID

class RhinoBankingRepository(private val dao: RhinoBankingDao) {

    val allAccounts: Flow<List<AccountEntity>> = dao.getAllAccounts()
    val allTransactions: Flow<List<TransactionEntity>> = dao.getAllTransactions()
    val allSavingsGoals: Flow<List<SavingsGoalEntity>> = dao.getAllSavingsGoals()
    val allInvestments: Flow<List<InvestmentHoldingEntity>> = dao.getAllInvestments()
    val allPrivateNotes: Flow<List<PrivateNoteEntity>> = dao.getAllPrivateNotes()
    val primaryMortgage: Flow<MortgageEntity?> = dao.getPrimaryMortgage()
    val allCards: Flow<List<CardEntity>> = dao.getAllCards()
    val digitalSterlingWallet: Flow<DigitalSterlingWalletEntity?> = dao.getDigitalSterlingWallet()
    val allFxRates: Flow<List<FxRateEntity>> = dao.getAllFxRates()
    val allNotifications: Flow<List<NotificationEntity>> = dao.getAllNotifications()
    val allAuditEntries: Flow<List<AuditLedgerEntity>> = dao.getAllAuditEntries()
    val allContacts: Flow<List<ContactRecipientEntity>> = dao.getAllContacts()

    suspend fun getTransactionById(txId: String): TransactionEntity? = dao.getTransactionById(txId)

    // Execute Payment with Double-Entry Ledger & Simulated Validation Finality
    suspend fun executePayment(
        fromAccountId: String,
        recipientName: String,
        recipientAccountOrHandle: String,
        amount: Double,
        reference: String,
        paymentMethod: String,
        category: String = "General"
    ): Result<TransactionEntity> {
        val account = dao.getAccountById(fromAccountId) ?: return Result.failure(Exception("Source account not found"))
        if (account.balance < amount) {
            return Result.failure(Exception("Insufficient funds in ${account.accountName}"))
        }

        val now = System.currentTimeMillis()
        val txId = "TX-" + UUID.randomUUID().toString().take(8).uppercase()
        val auditHash = computeSha256("$txId:$fromAccountId:$recipientAccountOrHandle:$amount:$now")
        val blockHeight = 142100L + (now % 1000)

        // 1. Update account balance
        val updatedAccount = account.copy(
            balance = account.balance - amount,
            lastUpdated = now
        )
        dao.updateAccount(updatedAccount)

        // 2. Create Double-Entry Audit Ledger Record
        val auditEntry = AuditLedgerEntity(
            auditId = "LEDGER-AUDIT-${UUID.randomUUID().toString().take(6).uppercase()}",
            timestamp = now,
            eventType = "PAYMENT_SETTLEMENT",
            debitAccountId = fromAccountId,
            creditAccountId = recipientAccountOrHandle,
            amount = amount,
            reference = reference,
            blockHeight = blockHeight,
            validatorName = "EDINBURGH-01",
            cryptographicHash = "SHA256:$auditHash"
        )
        dao.insertAuditEntry(auditEntry)

        // 3. Create Transaction Record
        val tx = TransactionEntity(
            id = txId,
            accountId = fromAccountId,
            title = recipientName,
            subtitle = "$paymentMethod • Settled",
            amount = -amount,
            type = TransactionType.OUTGOING_PAYMENT,
            status = TransactionStatus.COMPLETED,
            timestamp = now,
            counterpartyName = recipientName,
            counterpartyAccount = recipientAccountOrHandle,
            reference = reference.ifBlank { "Payment" },
            category = category,
            location = "Edinburgh, UK",
            paymentMethod = paymentMethod,
            fee = 0.0,
            auditHash = auditHash,
            blockHeight = blockHeight,
            validatorName = "EDINBURGH-01",
            receiptNotes = "Validated by Rhino Edinburgh Consensus. Finality 0.4s."
        )
        dao.insertTransaction(tx)

        // 4. Notification
        dao.insertNotification(
            NotificationEntity(
                id = "NOTIF-${UUID.randomUUID().toString().take(6)}",
                title = "Payment Sent",
                message = "£${String.format("%.2f", amount)} sent to $recipientName ($paymentMethod).",
                category = "Payments",
                timestamp = now,
                isRead = false,
                actionDeepLink = "HOME"
            )
        )

        return Result.success(tx)
    }

    // Interoperability conversion: Current Account <-> Digital Sterling
    suspend fun convertDigitalSterling(
        amount: Double,
        toDigitalSterling: Boolean
    ): Result<String> {
        val currentAccount = dao.getAccountById("ACC-CURRENT-01") ?: return Result.failure(Exception("Current account not found"))
        val digitalAccount = dao.getAccountById("ACC-DIGITAL-01") ?: return Result.failure(Exception("Digital Sterling account not found"))
        val wallet = dao.getAccountById("ACC-DIGITAL-01") // check balance

        val now = System.currentTimeMillis()

        if (toDigitalSterling) {
            if (currentAccount.balance < amount) {
                return Result.failure(Exception("Insufficient current account balance"))
            }
            dao.updateAccount(currentAccount.copy(balance = currentAccount.balance - amount, lastUpdated = now))
            dao.updateAccount(digitalAccount.copy(balance = digitalAccount.balance + amount, lastUpdated = now))

            dao.insertTransaction(
                TransactionEntity(
                    id = "TX-CONV-" + UUID.randomUUID().toString().take(6).uppercase(),
                    accountId = "ACC-CURRENT-01",
                    title = "Move to Digital Sterling",
                    subtitle = "Instant Reserve Allocation",
                    amount = -amount,
                    type = TransactionType.DIGITAL_STERLING_CONVERSION,
                    status = TransactionStatus.COMPLETED,
                    timestamp = now,
                    counterpartyName = "Rhino Digital Sterling Wallet",
                    counterpartyAccount = "ACC-DIGITAL-01",
                    reference = "CONVERT-MINT-DGBP",
                    category = "Transfer",
                    paymentMethod = "Rhino Interoperability Bridge",
                    auditHash = computeSha256("CONV:$now:$amount"),
                    blockHeight = 142120L
                )
            )
        } else {
            if (digitalAccount.balance < amount) {
                return Result.failure(Exception("Insufficient Digital Sterling balance"))
            }
            dao.updateAccount(digitalAccount.copy(balance = digitalAccount.balance - amount, lastUpdated = now))
            dao.updateAccount(currentAccount.copy(balance = currentAccount.balance + amount, lastUpdated = now))

            dao.insertTransaction(
                TransactionEntity(
                    id = "TX-CONV-" + UUID.randomUUID().toString().take(6).uppercase(),
                    accountId = "ACC-DIGITAL-01",
                    title = "Redeem to Current Account",
                    subtitle = "Commercial Deposit Interoperability",
                    amount = -amount,
                    type = TransactionType.DIGITAL_STERLING_CONVERSION,
                    status = TransactionStatus.COMPLETED,
                    timestamp = now,
                    counterpartyName = "Rhino Current Account",
                    counterpartyAccount = "ACC-CURRENT-01",
                    reference = "REDEEM-BURN-DGBP",
                    category = "Transfer",
                    paymentMethod = "Rhino Interoperability Bridge",
                    auditHash = computeSha256("REDEEM:$now:$amount"),
                    blockHeight = 142125L
                )
            )
        }
        return Result.success("Converted £${String.format("%.2f", amount)} successfully")
    }

    // Offline Digital Sterling payment simulation (NFC Tap-to-Pay)
    suspend fun executeOfflineDigitalPayment(
        amount: Double,
        merchantName: String
    ): Result<String> {
        val now = System.currentTimeMillis()
        val txId = "TX-OFFLINE-" + UUID.randomUUID().toString().take(6).uppercase()

        // Create transaction record marked as offline local confirmation
        val tx = TransactionEntity(
            id = txId,
            accountId = "ACC-DIGITAL-01",
            title = merchantName,
            subtitle = "Offline Secure Enclave NFC • Local Proof",
            amount = -amount,
            type = TransactionType.DIGITAL_STERLING_TRANSFER,
            status = TransactionStatus.COMPLETED,
            timestamp = now,
            counterpartyName = merchantName,
            counterpartyAccount = "NFC-POS-MERCHANT-OFFLINE",
            reference = "OFFLINE-TAP-$txId",
            category = "Dining",
            location = "Edinburgh (Offline Mode)",
            paymentMethod = "Digital Sterling Offline Token",
            auditHash = computeSha256("OFFLINE:$txId:$amount:$now"),
            receiptNotes = "Signed via Device Secure Key DEV-SECURE-ENCLAVE-EDIN-09. Synchronised to chain on connection."
        )
        dao.insertTransaction(tx)

        return Result.success("Offline payment of £${String.format("%.2f", amount)} completed locally")
    }

    // Purchase Private Note
    suspend fun purchasePrivateNote(instrumentCode: String, amount: Double): Result<String> {
        val currentAccount = dao.getAccountById("ACC-CURRENT-01") ?: return Result.failure(Exception("Current account not found"))
        if (currentAccount.balance < amount) {
            return Result.failure(Exception("Insufficient balance in current account"))
        }
        val note = dao.getPrivateNoteByCode(instrumentCode) ?: return Result.failure(Exception("Note not found"))
        if (amount < note.minInvestment) {
            return Result.failure(Exception("Minimum investment is £${String.format("%.2f", note.minInvestment)}"))
        }

        val now = System.currentTimeMillis()
        dao.updateAccount(currentAccount.copy(balance = currentAccount.balance - amount, lastUpdated = now))

        // Update note holding
        val updatedNote = note.copy(
            customerInvestedAmount = note.customerInvestedAmount + amount
        )
        dao.updatePrivateNote(updatedNote)

        // Insert transaction
        dao.insertTransaction(
            TransactionEntity(
                id = "TX-NOTE-" + UUID.randomUUID().toString().take(6).uppercase(),
                accountId = "ACC-CURRENT-01",
                title = "Subscription: ${note.instrumentName}",
                subtitle = "${String.format("%.2f", note.couponRate * 100)}% Coupon • ${note.maturityYears}yr",
                amount = -amount,
                type = TransactionType.NOTE_SUBSCRIPTION,
                status = TransactionStatus.COMPLETED,
                timestamp = now,
                counterpartyName = note.issuer,
                counterpartyAccount = note.instrumentCode,
                reference = "NOTE-SUB-${note.instrumentCode}",
                category = "Investments",
                paymentMethod = "Private Placement Desk",
                auditHash = computeSha256("NOTE:$instrumentCode:$amount:$now"),
                blockHeight = 142135L
            )
        )

        return Result.success("Purchased £${String.format("%.2f", amount)} of ${note.instrumentName}")
    }

    // Update Mortgage Overpayment
    suspend fun updateMortgageOverpayment(monthlyOverpayment: Double) {
        val mortgageFlow = dao.getPrimaryMortgage()
        // Simple update
    }

    // Toggle Card Controls
    suspend fun toggleCardFreeze(cardId: String, freeze: Boolean) {
        val cards = listOf<CardEntity>()
        // dao.updateCard
    }

    suspend fun updateCard(card: CardEntity) {
        dao.updateCard(card)
    }

    // Create Savings Goal
    suspend fun createSavingsGoal(goal: SavingsGoalEntity) {
        dao.insertSavingsGoal(goal)
    }

    suspend fun contributeToSavingsGoal(goalId: String, amount: Double): Result<String> {
        val currentAccount = dao.getAccountById("ACC-CURRENT-01") ?: return Result.failure(Exception("Current account not found"))
        if (currentAccount.balance < amount) {
            return Result.failure(Exception("Insufficient funds in current account"))
        }
        val now = System.currentTimeMillis()
        dao.updateAccount(currentAccount.copy(balance = currentAccount.balance - amount, lastUpdated = now))

        // Record transaction
        dao.insertTransaction(
            TransactionEntity(
                id = "TX-GOAL-" + UUID.randomUUID().toString().take(6).uppercase(),
                accountId = "ACC-CURRENT-01",
                title = "Savings Goal Contribution",
                subtitle = "Transferred to goal reserve",
                amount = -amount,
                type = TransactionType.SAVINGS_TRANSFER,
                status = TransactionStatus.COMPLETED,
                timestamp = now,
                counterpartyName = "Savings Reserve",
                reference = "GOAL-CONTRIB",
                category = "Savings"
            )
        )
        return Result.success("Contributed £${String.format("%.2f", amount)}")
    }

    private fun computeSha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
