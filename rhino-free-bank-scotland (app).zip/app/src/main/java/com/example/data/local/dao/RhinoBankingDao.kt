package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.AccountEntity
import com.example.data.local.entity.AuditLedgerEntity
import com.example.data.local.entity.CardEntity
import com.example.data.local.entity.ContactRecipientEntity
import com.example.data.local.entity.DigitalSterlingWalletEntity
import com.example.data.local.entity.FxRateEntity
import com.example.data.local.entity.InvestmentHoldingEntity
import com.example.data.local.entity.MortgageEntity
import com.example.data.local.entity.NotificationEntity
import com.example.data.local.entity.PrivateNoteEntity
import com.example.data.local.entity.SavingsGoalEntity
import com.example.data.local.entity.TransactionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface RhinoBankingDao {
    // Accounts
    @Query("SELECT * FROM accounts ORDER BY isPrimary DESC, id ASC")
    fun getAllAccounts(): Flow<List<AccountEntity>>

    @Query("SELECT * FROM accounts WHERE id = :id LIMIT 1")
    suspend fun getAccountById(id: String): AccountEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAccounts(accounts: List<AccountEntity>)

    @Update
    suspend fun updateAccount(account: AccountEntity)

    // Transactions
    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE accountId = :accountId ORDER BY timestamp DESC")
    fun getTransactionsByAccount(accountId: String): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE id = :txId LIMIT 1")
    suspend fun getTransactionById(txId: String): TransactionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(tx: TransactionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransactions(txs: List<TransactionEntity>)

    // Savings Goals
    @Query("SELECT * FROM savings_goals ORDER BY targetAmount DESC")
    fun getAllSavingsGoals(): Flow<List<SavingsGoalEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavingsGoal(goal: SavingsGoalEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavingsGoals(goals: List<SavingsGoalEntity>)

    @Update
    suspend fun updateSavingsGoal(goal: SavingsGoalEntity)

    // Investments
    @Query("SELECT * FROM investments")
    fun getAllInvestments(): Flow<List<InvestmentHoldingEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvestments(investments: List<InvestmentHoldingEntity>)

    @Update
    suspend fun updateInvestment(investment: InvestmentHoldingEntity)

    // Private Notes
    @Query("SELECT * FROM private_notes")
    fun getAllPrivateNotes(): Flow<List<PrivateNoteEntity>>

    @Query("SELECT * FROM private_notes WHERE instrumentCode = :code LIMIT 1")
    suspend fun getPrivateNoteByCode(code: String): PrivateNoteEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrivateNotes(notes: List<PrivateNoteEntity>)

    @Update
    suspend fun updatePrivateNote(note: PrivateNoteEntity)

    // Mortgage
    @Query("SELECT * FROM mortgages LIMIT 1")
    fun getPrimaryMortgage(): Flow<MortgageEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMortgage(mortgage: MortgageEntity)

    @Update
    suspend fun updateMortgage(mortgage: MortgageEntity)

    // Cards
    @Query("SELECT * FROM cards ORDER BY id ASC")
    fun getAllCards(): Flow<List<CardEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCards(cards: List<CardEntity>)

    @Update
    suspend fun updateCard(card: CardEntity)

    // Digital Sterling Wallet
    @Query("SELECT * FROM digital_sterling_wallet LIMIT 1")
    fun getDigitalSterlingWallet(): Flow<DigitalSterlingWalletEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDigitalSterlingWallet(wallet: DigitalSterlingWalletEntity)

    @Update
    suspend fun updateDigitalSterlingWallet(wallet: DigitalSterlingWalletEntity)

    // FX Rates
    @Query("SELECT * FROM fx_rates")
    fun getAllFxRates(): Flow<List<FxRateEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFxRates(rates: List<FxRateEntity>)

    // Notifications
    @Query("SELECT * FROM notifications ORDER BY timestamp DESC")
    fun getAllNotifications(): Flow<List<NotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotifications(notifications: List<NotificationEntity>)

    @Query("UPDATE notifications SET isRead = 1 WHERE id = :id")
    suspend fun markNotificationAsRead(id: String)

    // Audit Ledger
    @Query("SELECT * FROM audit_ledger ORDER BY timestamp DESC")
    fun getAllAuditEntries(): Flow<List<AuditLedgerEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditEntry(entry: AuditLedgerEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditEntries(entries: List<AuditLedgerEntity>)

    // Contacts
    @Query("SELECT * FROM contacts ORDER BY name ASC")
    fun getAllContacts(): Flow<List<ContactRecipientEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContacts(contacts: List<ContactRecipientEntity>)
}
