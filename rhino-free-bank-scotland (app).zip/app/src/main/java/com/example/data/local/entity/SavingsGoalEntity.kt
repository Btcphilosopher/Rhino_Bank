package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "savings_goals")
data class SavingsGoalEntity(
    @PrimaryKey val id: String,
    val name: String, // e.g. "Edinburgh House", "Emergency Reserve"
    val targetAmount: Double,
    val currentAmount: Double,
    val monthlyContribution: Double,
    val targetDateEpoch: Long, // timestamp
    val iconName: String = "home",
    val colorHex: String = "#0A192F",
    val category: String = "Property"
)
