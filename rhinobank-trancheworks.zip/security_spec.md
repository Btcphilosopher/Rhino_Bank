# RhinoBank TrancheWorks — Firestore Security Specification

## 1. Data Invariants
1. **User Isolation & RBAC**: Users can only read/create their own `/users/{userId}` document and cannot self-assign `admin` or `checker` roles (except the bootstrapped admin `tom@ahyx.org` with verified email).
2. **Deal Ownership**: Every `/deals/{dealId}` record is owned by `ownerId == request.auth.uid` (or accessed by an admin). No unauthenticated reads or writes are permitted.
3. **Master Gate Sync**: Every sub-collection (`/tapes/`, `/structures/`, `/simulations/`, `/surveillance/`, `/approvals/`) verifies parent `/deals/{dealId}` existence and ownership (`get(...).data.ownerId == request.auth.uid || isAdmin()`).
4. **Immutable Snapshots**:
   - Collateral tapes (`/tapes/{tapeId}`) are immutable once created (`allow update: if false`).
   - Simulation snapshots (`/simulations/{simId}`) are immutable once created (`allow update: if false`).
   - Finalized surveillance periods (`isFinalized == true`) cannot be modified (`existing().isFinalized == false` required for updates unless admin).
5. **Maker-Checker Integrity**:
   - Approval requests cannot be created with pre-approved status (`status == 'pending'` on create).
   - Once decided (`status in ['approved', 'rejected']`), an approval record is terminally locked (`existing().status == 'pending'`).
   - A maker cannot approve their own request unless they are an admin override (`request.auth.uid != existing().makerUid || isAdmin()`).
6. **Temporal Integrity & Path Hardening**: All document IDs enforce `isValidId()` (`<= 128` chars, `^[a-zA-Z0-9_-]+$`), strings have explicit `.size()` bounds, arrays have `.size()` caps, and `createdAt` / `updatedAt` validate against `request.time`.

## 2. The "Dirty Dozen" Adversarial Payloads
1. **Self-Role Escalation**: User creates `/users/{uid}` with `role: "admin"` -> **DENIED**.
2. **Unverified Email Write**: Token with `email_verified: false` writes to `/deals/d1` -> **DENIED**.
3. **ID Poisoning**: Creating `/deals/` with a 2KB junk ID -> **DENIED** by `isValidId()`.
4. **Owner Spoofing**: Creating `/deals/d2` with `ownerId: "victim-uid"` -> **DENIED**.
5. **Shadow Update / Ghost Field**: Updating `/deals/d1` with an extra field `isApprovedOverride: true` -> **DENIED** by `affectedKeys().hasOnly(...)`.
6. **Tape Tampering**: Sending `update` to `/deals/d1/tapes/t1` to alter historical assets -> **DENIED**.
7. **Orphan Subcollection Write**: Creating `/deals/nonexistent/tapes/t1` -> **DENIED** by parent `get()`.
8. **Finalized Report Overwrite**: Updating `/deals/d1/surveillance/p1` when `isFinalized == true` -> **DENIED**.
9. **Pre-Approved Maker Request**: Creating `/deals/d1/approvals/a1` with `status: "approved"` -> **DENIED**.
10. **Self-Approval Bypass**: Maker attempting to approve own request as non-admin -> **DENIED**.
11. **Array Exhaustion**: Sending `assets` array of 500 elements to `/tapes/t1` -> **DENIED** (`<= 200` bound).
12. **Blanket List Scraping**: Listing `/deals` without `where('ownerId', '==', uid)` -> **DENIED** by `allow list` resource check.
