import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { onAuthStateChanged, type User } from 'firebase/auth';
import {
  Activity,
  BarChart3,
  Briefcase,
  Compass,
  Database,
  FileSpreadsheet,
  GitBranch,
  Layers,
  LogIn,
  LogOut,
} from 'lucide-react';
import { BrandCrest } from './components/BrandCrest.tsx';
import { ErrorBoundary } from './components/ErrorBoundary.tsx';
import { CollateralView } from './components/views/CollateralView.tsx';
import { DealsView } from './components/views/DealsView.tsx';
import { ReportsView } from './components/views/ReportsView.tsx';
import { ScenariosView } from './components/views/ScenariosView.tsx';
import { StructureView } from './components/views/StructureView.tsx';
import { SurveillanceView } from './components/views/SurveillanceView.tsx';
import { ValuationView } from './components/views/ValuationView.tsx';
import { WaterfallView } from './components/views/WaterfallView.tsx';
import { runMonteCarloSimulation } from './engine/quantEngine.ts';
import {
  DEFAULT_BASE_ASSUMPTIONS,
  buildStandardCashWaterfallRules,
  buildSyntheticWaterfallRules,
  createInitialSeedBundle,
  type SeedWorkspaceBundle,
} from './engine/seedData.ts';
import type {
  ApprovalRequestRecord,
  AssetClass,
  CollateralAsset,
  CollateralTape,
  DealAssumptions,
  DealRecord,
  DealStructure,
  OptimizationCandidate,
  SimulationRunResult,
  StructureType,
  SurveillancePeriodRecord,
  TrancheDefinition,
  WaterfallRule,
} from './engine/types.ts';
import { recomputeAttachmentPoints } from './engine/waterfall.ts';
import {
  auth,
  signInWithGoogle,
  signOutUser,
  testFirestoreConnection,
} from './lib/firebase.ts';
import {
  createApprovalInFirestore,
  decideApprovalInFirestore,
  ensureUserProfile,
  loadUserWorkspaceFromFirestore,
  persistCollateralTapeToFirestore,
  persistSimulationToFirestore,
  persistStructureToFirestore,
  persistSurveillanceToFirestore,
} from './lib/firestoreStore.ts';
import { formatCurrency } from './lib/format.ts';

type SectionId =
  | 'Deals'
  | 'Collateral'
  | 'Structure'
  | 'Waterfall'
  | 'Valuation'
  | 'Scenarios'
  | 'Surveillance'
  | 'Reports';

const NAV_ITEMS: { id: SectionId; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: 'Deals', label: 'Deals', icon: Briefcase },
  { id: 'Collateral', label: 'Collateral', icon: Database },
  { id: 'Structure', label: 'Structure', icon: Layers },
  { id: 'Waterfall', label: 'Waterfall', icon: GitBranch },
  { id: 'Valuation', label: 'Valuation', icon: BarChart3 },
  { id: 'Scenarios', label: 'Scenarios', icon: Compass },
  { id: 'Surveillance', label: 'Surveillance', icon: Activity },
  { id: 'Reports', label: 'Reports', icon: FileSpreadsheet },
];

function TrancheWorksWorkspace() {
  const initialSeed = useMemo(() => createInitialSeedBundle(), []);
  const [workspace, setWorkspace] = useState<SeedWorkspaceBundle>(initialSeed);
  const [activeDealId, setActiveDealId] = useState<string>(initialSeed.deals[0].id);
  const [activeSection, setActiveSection] = useState<SectionId>('Deals');

  const [simulationsByDeal, setSimulationsByDeal] = useState<Record<string, SimulationRunResult>>({});
  const [isSimulating, setIsSimulating] = useState<boolean>(false);

  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [userRole, setUserRole] = useState<'analyst' | 'structurer' | 'checker' | 'admin'>('structurer');
  const [authLoading, setAuthLoading] = useState<boolean>(false);
  const [syncNotice, setSyncNotice] = useState<string>('');

  // Verify Firestore connectivity on boot
  useEffect(() => {
    testFirestoreConnection();
  }, []);

  // Auth listener & Firestore hydration
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user) {
        setAuthLoading(true);
        try {
          const role = await ensureUserProfile(user);
          setUserRole(role);
          const loaded = await loadUserWorkspaceFromFirestore(user.uid, createInitialSeedBundle());
          setWorkspace({
            deals: loaded.deals,
            tapesByDeal: loaded.tapesByDeal,
            structuresByDeal: loaded.structuresByDeal,
            surveillanceByDeal: loaded.surveillanceByDeal,
            approvalsByDeal: loaded.approvalsByDeal,
          });
          if (loaded.deals.length > 0) {
            setActiveDealId(loaded.deals[0].id);
          }
          const latestSims: Record<string, SimulationRunResult> = {};
          for (const [dId, sims] of Object.entries(loaded.simulationsByDeal)) {
            if (sims.length > 0) {
              latestSims[dId] = sims[sims.length - 1];
            }
          }
          setSimulationsByDeal((prev) => ({ ...prev, ...latestSims }));
          setSyncNotice('Cloud workspace synchronized');
        } catch (err) {
          console.error('Firestore hydration error:', err);
          setSyncNotice('Using local workspace session');
        } finally {
          setAuthLoading(false);
        }
      } else {
        setUserRole('structurer');
        setSyncNotice('');
      }
    });
    return () => unsub();
  }, []);

  const activeDeal = useMemo(
    () => workspace.deals.find((d) => d.id === activeDealId) ?? workspace.deals[0],
    [workspace.deals, activeDealId]
  );

  const dealTapes = workspace.tapesByDeal[activeDeal.id] ?? [];
  const activeTape =
    dealTapes.find((t) => t.id === activeDeal.activeTapeId) ?? dealTapes[dealTapes.length - 1];

  const dealStructures = workspace.structuresByDeal[activeDeal.id] ?? [];
  const activeStructure =
    dealStructures.find((s) => s.id === activeDeal.activeStructureId) ?? dealStructures[0];

  const dealSurveillance = workspace.surveillanceByDeal[activeDeal.id] ?? [];
  const dealApprovals = workspace.approvalsByDeal[activeDeal.id] ?? [];

  // Run initial baseline simulation for active deal if not yet computed
  useEffect(() => {
    if (!activeDeal || !activeTape || !activeStructure) return;
    if (simulationsByDeal[activeDeal.id]) return;

    const sim = runMonteCarloSimulation({
      deal: activeDeal,
      assets: activeTape.assets,
      tranches: activeStructure.tranches,
      rules: activeStructure.waterfallRules,
      assumptions: activeStructure.assumptions,
      scenarioName: 'Base Calibration',
      seed: 202611,
      numPaths: 200,
    });
    setSimulationsByDeal((prev) => ({ ...prev, [activeDeal.id]: sim }));
  }, [activeDeal, activeTape, activeStructure, simulationsByDeal]);

  const handleRunSimulation = useCallback(
    async (params: {
      seed: number;
      numPaths: number;
      scenarioName: string;
      assumptions: DealAssumptions;
    }) => {
      if (!activeDeal || !activeTape || !activeStructure) return;
      setIsSimulating(true);
      try {
        // Dispatch to Express background simulation worker API
        const res = await fetch('/api/v1/simulations', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            deal: activeDeal,
            assets: activeTape.assets,
            tranches: activeStructure.tranches,
            rules: activeStructure.waterfallRules,
            assumptions: params.assumptions,
            scenarioName: params.scenarioName,
            seed: params.seed,
            numPaths: params.numPaths,
          }),
        });

        let result: SimulationRunResult | null = null;
        if (res.ok) {
          const { jobId } = (await res.json()) as { jobId: string };
          for (let attempt = 0; attempt < 40; attempt++) {
            await new Promise((r) => setTimeout(r, 80));
            const poll = await fetch(`/api/v1/simulations/${jobId}`);
            if (poll.ok) {
              const job = (await poll.json()) as {
                status: string;
                result?: SimulationRunResult;
                error?: string;
              };
              if (job.status === 'completed' && job.result) {
                result = job.result;
                break;
              }
              if (job.status === 'failed') {
                throw new Error(job.error ?? 'Worker simulation failed');
              }
            }
          }
        }

        if (!result) {
          result = runMonteCarloSimulation({
            deal: activeDeal,
            assets: activeTape.assets,
            tranches: activeStructure.tranches,
            rules: activeStructure.waterfallRules,
            assumptions: params.assumptions,
            scenarioName: params.scenarioName,
            seed: params.seed,
            numPaths: params.numPaths,
          });
        }

        setSimulationsByDeal((prev) => ({ ...prev, [activeDeal.id]: result! }));
        if (currentUser) {
          await persistSimulationToFirestore(currentUser.uid, activeDeal.id, result);
        }
      } finally {
        setIsSimulating(false);
      }
    },
    [activeDeal, activeTape, activeStructure, currentUser]
  );

  const handleSelectTapeVersion = (tapeId: string) => {
    setWorkspace((prev) => ({
      ...prev,
      deals: prev.deals.map((d) => (d.id === activeDeal.id ? { ...d, activeTapeId: tapeId } : d)),
    }));
  };

  const handleCommitNewTape = async (
    assets: CollateralAsset[],
    sourceFormat: 'csv' | 'json',
    sourceFileName: string
  ) => {
    const nextVersion = dealTapes.length + 1;
    const totalPrincipal = assets.reduce((s, a) => s + a.principalOutstanding, 0);
    const newTape: CollateralTape = {
      id: `tape_${activeDeal.id}_v${nextVersion}_${Date.now().toString().slice(-4)}`,
      dealId: activeDeal.id,
      versionNumber: nextVersion,
      sourceFormat,
      sourceFileName,
      totalPrincipal,
      assetCount: assets.length,
      validationSummary: { errorCount: 0, warningCount: 0, currency: activeDeal.currency },
      assets,
      createdAt: new Date().toISOString(),
    };

    setWorkspace((prev) => ({
      ...prev,
      deals: prev.deals.map((d) =>
        d.id === activeDeal.id
          ? { ...d, activeTapeId: newTape.id, targetPoolNotional: totalPrincipal }
          : d
      ),
      tapesByDeal: {
        ...prev.tapesByDeal,
        [activeDeal.id]: [...dealTapes, newTape],
      },
    }));

    if (currentUser) {
      await persistCollateralTapeToFirestore(currentUser.uid, activeDeal.id, newTape);
    }
  };

  const handleSelectStructure = (structureId: string) => {
    setWorkspace((prev) => ({
      ...prev,
      deals: prev.deals.map((d) =>
        d.id === activeDeal.id ? { ...d, activeStructureId: structureId } : d
      ),
    }));
  };

  const updateActiveStructure = async (patch: Partial<DealStructure>) => {
    const updated: DealStructure = {
      ...activeStructure,
      ...patch,
      versionNumber: activeStructure.versionNumber + 1,
      updatedAt: new Date().toISOString(),
    };
    setWorkspace((prev) => ({
      ...prev,
      structuresByDeal: {
        ...prev.structuresByDeal,
        [activeDeal.id]: dealStructures.map((s) => (s.id === activeStructure.id ? updated : s)),
      },
    }));
    if (currentUser) {
      await persistStructureToFirestore(currentUser.uid, activeDeal.id, updated);
    }
  };

  const handleUpdateTranches = (tranches: TrancheDefinition[]) => {
    updateActiveStructure({ tranches });
  };

  const handleUpdateRules = (waterfallRules: WaterfallRule[]) => {
    updateActiveStructure({ waterfallRules });
  };

  const handleUpdateAssumptions = (assumptions: DealAssumptions) => {
    updateActiveStructure({ assumptions });
  };

  const handleApplyOptimizedStructure = (
    cand: OptimizationCandidate,
    updatedTranches: TrancheDefinition[]
  ) => {
    const newRules =
      activeDeal.structureType === 'synthetic'
        ? buildSyntheticWaterfallRules(updatedTranches)
        : buildStandardCashWaterfallRules(updatedTranches);

    updateActiveStructure({
      name: `Optimized · ${cand.label}`,
      tranches: updatedTranches,
      waterfallRules: newRules,
    });
    setActiveSection('Structure');
  };

  const handleCreateDeal = (input: {
    name: string;
    code: string;
    assetClass: AssetClass;
    structureType: StructureType;
    targetPoolNotional: number;
    reinvestmentPeriods: number;
    maturityPeriods: number;
    ocTriggerRatio: number;
    icTriggerRatio: number;
  }) => {
    const nowIso = new Date().toISOString();
    const dealId = `deal_${Date.now()}`;
    const baseTape = initialSeed.tapesByDeal[
      input.assetClass === 'corporate_debt'
        ? 'deal_aic_2026_a'
        : input.assetClass === 'equipment_finance'
        ? 'deal_vfs_2026_1'
        : 'deal_rst_2026_1'
    ][0];

    const scale = input.targetPoolNotional / baseTape.totalPrincipal;
    const scaledAssets = baseTape.assets.map((a, idx) => ({
      ...a,
      assetId: `${input.code.slice(0, 4)}-${String(idx + 1).padStart(3, '0')}`,
      principalOutstanding: Math.round(a.principalOutstanding * scale),
    }));
    const actualSum = scaledAssets.reduce((s, a) => s + a.principalOutstanding, 0);

    const tranches = recomputeAttachmentPoints(
      [
        {
          id: `${dealId}_a`,
          code: input.structureType === 'synthetic' ? 'Super-Senior Swap (Unfunded)' : 'Class A Senior',
          seniority: 'senior',
          notional: Math.round(actualSum * 0.7),
          issuePricePct: 100,
          couponType: input.structureType === 'synthetic' ? 'fixed' : 'floating',
          spreadOrCouponBps: input.structureType === 'synthetic' ? 60 : 150,
          maturityPeriods: input.maturityPeriods,
          paymentPriority: 1,
          principalPriority: 1,
          isDeferrable: false,
          lossAllocationOrder: 1,
          redemptionProvision: 'Non-Call 2Y',
          isFunded: input.structureType !== 'synthetic',
          referenceNotional: actualSum,
          attachmentPct: 30,
          detachmentPct: 100,
        },
        {
          id: `${dealId}_b`,
          code: 'Class B Mezzanine',
          seniority: 'mezzanine',
          notional: Math.round(actualSum * 0.14),
          issuePricePct: 99.5,
          couponType: 'floating',
          spreadOrCouponBps: 310,
          maturityPeriods: input.maturityPeriods,
          paymentPriority: 2,
          principalPriority: 2,
          isDeferrable: true,
          lossAllocationOrder: 2,
          redemptionProvision: 'Callable Par',
          isFunded: true,
          referenceNotional: actualSum,
          attachmentPct: 16,
          detachmentPct: 30,
        },
        {
          id: `${dealId}_c`,
          code: 'Class C Junior',
          seniority: 'junior',
          notional: Math.round(actualSum * 0.08),
          issuePricePct: 98.0,
          couponType: 'floating',
          spreadOrCouponBps: 530,
          maturityPeriods: input.maturityPeriods,
          paymentPriority: 3,
          principalPriority: 3,
          isDeferrable: true,
          lossAllocationOrder: 3,
          redemptionProvision: 'Callable @ 101',
          isFunded: true,
          referenceNotional: actualSum,
          attachmentPct: 8,
          detachmentPct: 16,
        },
        {
          id: `${dealId}_eq`,
          code: 'Subordinated Equity',
          seniority: 'equity',
          notional: actualSum - Math.round(actualSum * 0.92),
          issuePricePct: 96.5,
          couponType: 'residual',
          spreadOrCouponBps: 0,
          maturityPeriods: input.maturityPeriods,
          paymentPriority: 4,
          principalPriority: 4,
          isDeferrable: false,
          lossAllocationOrder: 4,
          redemptionProvision: 'Residual',
          isFunded: true,
          referenceNotional: actualSum,
          attachmentPct: 0,
          detachmentPct: 8,
        },
      ],
      actualSum
    );

    const tapeId = `tape_${dealId}_v1`;
    const structId = `struct_${dealId}_base`;

    const newDeal: DealRecord = {
      id: dealId,
      name: input.name,
      code: input.code,
      assetClass: input.assetClass,
      structureType: input.structureType,
      currency: 'USD',
      targetPoolNotional: actualSum,
      reinvestmentPeriods: input.reinvestmentPeriods,
      maturityPeriods: input.maturityPeriods,
      periodFrequency: 'quarterly',
      status: 'draft',
      version: 1,
      activeTapeId: tapeId,
      activeStructureId: structId,
      reserveTarget: Math.round(actualSum * 0.015),
      reserveBalance: Math.round(actualSum * 0.015),
      annualSeniorFeeBps: 45,
      annualTrusteeFee: 180000,
      ocTriggerRatio: input.ocTriggerRatio,
      icTriggerRatio: input.icTriggerRatio,
      issuanceExpenses: Math.round(actualSum * 0.006),
      createdAt: nowIso,
      updatedAt: nowIso,
    };

    const newTape: CollateralTape = {
      id: tapeId,
      dealId,
      versionNumber: 1,
      sourceFormat: 'seed',
      sourceFileName: `${input.code.toLowerCase()}_seed_v1.csv`,
      totalPrincipal: actualSum,
      assetCount: scaledAssets.length,
      validationSummary: { errorCount: 0, warningCount: 0, currency: 'USD' },
      assets: scaledAssets,
      createdAt: nowIso,
    };

    const newStruct: DealStructure = {
      id: structId,
      dealId,
      name: 'Base Capital Structure (70 / 14 / 8 / 8)',
      versionNumber: 1,
      isBase: true,
      tranches,
      waterfallRules:
        input.structureType === 'synthetic'
          ? buildSyntheticWaterfallRules(tranches)
          : buildStandardCashWaterfallRules(tranches),
      assumptions: { ...DEFAULT_BASE_ASSUMPTIONS },
      createdAt: nowIso,
      updatedAt: nowIso,
    };

    setWorkspace((prev) => ({
      ...prev,
      deals: [newDeal, ...prev.deals],
      tapesByDeal: { ...prev.tapesByDeal, [dealId]: [newTape] },
      structuresByDeal: { ...prev.structuresByDeal, [dealId]: [newStruct] },
      surveillanceByDeal: { ...prev.surveillanceByDeal, [dealId]: [] },
      approvalsByDeal: { ...prev.approvalsByDeal, [dealId]: [] },
    }));
    setActiveDealId(dealId);
  };

  const handleAddSurveillancePeriod = async (period: SurveillancePeriodRecord) => {
    setWorkspace((prev) => ({
      ...prev,
      surveillanceByDeal: {
        ...prev.surveillanceByDeal,
        [activeDeal.id]: [...dealSurveillance, period],
      },
    }));
    if (currentUser) {
      await persistSurveillanceToFirestore(currentUser.uid, activeDeal.id, period);
    }
  };

  const handleFinalizeSurveillancePeriod = async (periodId: string) => {
    const target = dealSurveillance.find((p) => p.id === periodId);
    if (!target || target.isFinalized) return;
    const finalized = { ...target, isFinalized: true };
    setWorkspace((prev) => ({
      ...prev,
      surveillanceByDeal: {
        ...prev.surveillanceByDeal,
        [activeDeal.id]: dealSurveillance.map((p) => (p.id === periodId ? finalized : p)),
      },
    }));
    if (currentUser) {
      await persistSurveillanceToFirestore(currentUser.uid, activeDeal.id, finalized);
    }
  };

  const handleLogSubstitution = async (
    periodId: string,
    removedAssetId: string,
    addedObligor: string,
    notionalDelta: number
  ) => {
    const target = dealSurveillance.find((p) => p.id === periodId);
    if (!target || target.isFinalized) return;
    const removedAsset = activeTape.assets.find((a) => a.assetId === removedAssetId);
    const updated: SurveillancePeriodRecord = {
      ...target,
      substitutions: [
        ...target.substitutions,
        {
          id: `sub_${Date.now()}`,
          removedAssetId,
          removedObligor: removedAsset?.obligorName ?? removedAssetId,
          addedAssetId: `SUB-${String(activeTape.assets.length + 1).padStart(3, '0')}`,
          addedObligor,
          notionalDelta,
          approvedBy: currentUser?.email ?? 'structuring.desk@rhinobank.internal',
          timestamp: new Date().toISOString(),
        },
      ],
    };
    setWorkspace((prev) => ({
      ...prev,
      surveillanceByDeal: {
        ...prev.surveillanceByDeal,
        [activeDeal.id]: dealSurveillance.map((p) => (p.id === periodId ? updated : p)),
      },
    }));
    if (currentUser) {
      await persistSurveillanceToFirestore(currentUser.uid, activeDeal.id, updated);
    }
  };

  const handleSubmitApproval = async (
    actionType: ApprovalRequestRecord['actionType'],
    summary: string
  ) => {
    const rec: ApprovalRequestRecord = {
      id: `appr_${Date.now()}`,
      dealId: activeDeal.id,
      makerUid: currentUser?.uid ?? 'local_analyst',
      makerEmail: currentUser?.email ?? 'structuring.desk@rhinobank.internal',
      actionType,
      summary,
      payloadDiff: { structureId: activeStructure.id, version: activeStructure.versionNumber },
      status: 'pending',
      createdAt: new Date().toISOString(),
    };
    setWorkspace((prev) => ({
      ...prev,
      approvalsByDeal: {
        ...prev.approvalsByDeal,
        [activeDeal.id]: [rec, ...dealApprovals],
      },
    }));
    if (currentUser) {
      await createApprovalInFirestore(currentUser.uid, activeDeal.id, rec);
    }
  };

  const handleDecideApproval = async (
    approvalId: string,
    decision: 'approved' | 'rejected',
    note: string
  ) => {
    const email = currentUser?.email ?? 'risk.checker@rhinobank.internal';
    const uid = currentUser?.uid ?? 'local_checker';
    setWorkspace((prev) => ({
      ...prev,
      approvalsByDeal: {
        ...prev.approvalsByDeal,
        [activeDeal.id]: dealApprovals.map((a) =>
          a.id === approvalId
            ? {
                ...a,
                status: decision,
                checkerUid: uid,
                checkerEmail: email,
                decisionNote: note,
                decidedAt: new Date().toISOString(),
              }
            : a
        ),
      },
    }));
    if (currentUser) {
      await decideApprovalInFirestore(uid, email, activeDeal.id, approvalId, decision, note);
    }
  };

  return (
    <div className="min-h-screen bg-[#0B0D10] text-[#F4F1EA] flex flex-col">
      {/* Top Institutional Navigation Bar (Strict 3-Zone Contract) */}
      <header className="h-14 border-b border-white/10 bg-[#0F1218] px-6 flex items-center justify-between gap-8 shrink-0 no-print">
        {/* Zone 1: Single-line Brand Wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <BrandCrest className="w-7 h-7" />
          <span className="font-display text-base font-semibold tracking-tight text-[#F4F1EA] whitespace-nowrap shrink-0">
            RhinoBank TrancheWorks
          </span>
        </div>

        {/* Zone 2: Active Deal Context & Switcher */}
        <div className="hidden md:flex items-center gap-4 text-xs">
          <label className="flex items-center gap-2">
            <span className="text-[#A1A6B3] whitespace-nowrap">Active Deal</span>
            <select
              aria-label="Select Active Deal"
              value={activeDeal.id}
              onChange={(e) => setActiveDealId(e.target.value)}
              className="bg-[#161B24] border border-white/15 rounded px-3 py-1.5 text-xs text-[#F4F1EA] font-medium focus:outline-none focus:border-[#C8A253]"
            >
              {workspace.deals.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.code} · {d.name} ({d.structureType === 'cash' ? 'Cash' : 'Synthetic'})
                </option>
              ))}
            </select>
          </label>
          <span className="text-white/15" aria-hidden="true">
            |
          </span>
          <span className="font-mono text-[#D2CFC7] whitespace-nowrap">
            {formatCurrency(activeTape?.totalPrincipal ?? activeDeal.targetPoolNotional, activeDeal.currency, true)}
          </span>
          {syncNotice && (
            <>
              <span className="text-white/15" aria-hidden="true">
                ·
              </span>
              <span className="text-[#6CC4B5] whitespace-nowrap">{syncNotice}</span>
            </>
          )}
        </div>

        {/* Zone 3: Primary Auth / Cloud Persistence Action */}
        <div className="flex items-center gap-3 shrink-0">
          {currentUser ? (
            <button
              type="button"
              onClick={() => signOutUser()}
              className="inline-flex items-center gap-2 px-3.5 py-1.5 text-xs font-medium bg-[#171C25] border border-white/15 text-[#F4F1EA] rounded hover:border-[#C8A253] whitespace-nowrap shrink-0"
            >
              <LogOut className="w-3.5 h-3.5 text-[#C8A253]" />
              <span className="max-w-[160px] truncate">{currentUser.email}</span>
            </button>
          ) : (
            <button
              type="button"
              disabled={authLoading}
              onClick={() => signInWithGoogle()}
              className="inline-flex items-center gap-2 px-4 py-1.5 text-xs font-semibold bg-[#C8A253] text-[#0B0D10] rounded hover:bg-[#D9B76E] transition-colors whitespace-nowrap shrink-0"
            >
              <LogIn className="w-3.5 h-3.5" />
              {authLoading ? 'Connecting...' : 'Sign in to Persist'}
            </button>
          )}
        </div>
      </header>

      {/* Main Split: Left Institutional Section Rail + Content Viewport */}
      <div className="flex-1 flex min-h-0">
        {/* Sidebar Rail */}
        <aside className="w-56 border-r border-white/10 bg-[#0E1116] p-4 flex flex-col justify-between shrink-0 no-print">
          <nav aria-label="Workspace Sections" className="space-y-1">
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveSection(item.id)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
                    isActive
                      ? 'bg-[#C8A253]/15 text-[#F4F1EA] border border-[#C8A253]/50'
                      : 'text-[#A1A6B3] hover:text-[#F4F1EA] hover:bg-white/[0.03] border border-transparent'
                  }`}
                >
                  <Icon
                    className={`w-4 h-4 shrink-0 ${
                      isActive ? 'text-[#C8A253]' : 'text-[#7B8291]'
                    }`}
                  />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          <div className="pt-4 border-t border-white/10 space-y-2 text-[11px] text-[#8E95A3]">
            <div className="font-medium text-[#D2CFC7] truncate">{activeDeal.code}</div>
            <div>
              Tape v{activeTape?.versionNumber ?? 1} · Struct v{activeStructure?.versionNumber ?? 1}
            </div>
            <div>
              {activeDeal.structureType === 'synthetic'
                ? 'Synthetic Protection SPV'
                : 'Cash Asset-Backed SPV'}
            </div>
          </div>
        </aside>

        {/* Primary Viewport */}
        <main className="flex-1 overflow-y-auto p-6 lg:p-8 max-w-[1440px]">
          {activeSection === 'Deals' && (
            <DealsView
              deals={workspace.deals}
              activeDealId={activeDeal.id}
              onSelectDeal={(id) => setActiveDealId(id)}
              onCreateDeal={handleCreateDeal}
              onNavigateSection={(sec) => setActiveSection(sec as SectionId)}
              approvals={dealApprovals}
              userRole={userRole}
              currentUserEmail={currentUser?.email ?? 'structuring.desk@rhinobank.internal'}
              onSubmitApproval={handleSubmitApproval}
              onDecideApproval={handleDecideApproval}
            />
          )}

          {activeSection === 'Collateral' && activeTape && (
            <CollateralView
              deal={activeDeal}
              tapes={dealTapes}
              activeTape={activeTape}
              onSelectTapeVersion={handleSelectTapeVersion}
              onCommitNewTape={handleCommitNewTape}
            />
          )}

          {activeSection === 'Structure' && activeTape && activeStructure && (
            <StructureView
              deal={activeDeal}
              assets={activeTape.assets}
              structures={dealStructures}
              activeStructure={activeStructure}
              onSelectStructure={handleSelectStructure}
              onUpdateTranches={handleUpdateTranches}
            />
          )}

          {activeSection === 'Waterfall' && activeTape && activeStructure && (
            <WaterfallView
              deal={activeDeal}
              assets={activeTape.assets}
              structure={activeStructure}
              onUpdateRules={handleUpdateRules}
            />
          )}

          {activeSection === 'Valuation' && activeTape && activeStructure && (
            <ValuationView
              deal={activeDeal}
              assets={activeTape.assets}
              structure={activeStructure}
              latestSimulation={simulationsByDeal[activeDeal.id] ?? null}
              isSimulating={isSimulating}
              onRunSimulation={handleRunSimulation}
              onUpdateAssumptions={handleUpdateAssumptions}
            />
          )}

          {activeSection === 'Scenarios' && activeTape && activeStructure && (
            <ScenariosView
              deal={activeDeal}
              assets={activeTape.assets}
              structures={dealStructures}
              activeStructure={activeStructure}
              onApplyOptimizedStructure={handleApplyOptimizedStructure}
            />
          )}

          {activeSection === 'Surveillance' && activeTape && activeStructure && (
            <SurveillanceView
              deal={activeDeal}
              assets={activeTape.assets}
              structure={activeStructure}
              periods={dealSurveillance}
              onAddPeriod={handleAddSurveillancePeriod}
              onFinalizePeriod={handleFinalizeSurveillancePeriod}
              onLogSubstitution={handleLogSubstitution}
            />
          )}

          {activeSection === 'Reports' && activeTape && activeStructure && (
            <ReportsView
              deal={activeDeal}
              tape={activeTape}
              structure={activeStructure}
              latestSimulation={simulationsByDeal[activeDeal.id] ?? null}
              surveillancePeriods={dealSurveillance}
            />
          )}
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <TrancheWorksWorkspace />
    </ErrorBoundary>
  );
}
