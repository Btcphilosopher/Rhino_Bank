export function BrandCrest({ className = 'w-7 h-7' }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 36 36"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <rect x="1.5" y="1.5" width="33" height="33" rx="4" stroke="#C8A253" strokeWidth="1.5" />
      <path
        d="M8 24.5L13.5 14L19 18.5L25.5 10.5L28 13.5V24.5H8Z"
        fill="#C8A253"
        fillOpacity="0.16"
        stroke="#C8A253"
        strokeWidth="1.5"
        strokeLinejoin="round"
      />
      <path d="M8 27.5H28" stroke="#F4F1EA" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  );
}
