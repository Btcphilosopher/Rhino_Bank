import React, { useState } from 'react';
import { BarChart3, BookOpen, Play, RefreshCw } from 'lucide-react';
import type {
  CollateralAsset,
  DealAssumptions,
  DealRecord,
  DealStructure,
  SimulationRunResult,
} from '../../engine/types.ts';
import {
  SENIORITY_META,
  formatBps,
  formatCurrency,
  formatPct,
} from '../../lib/format.ts';

interface ValuationViewProps {
  deal: DealRecord;
  assets: CollateralAsset[];
  structure: DealStructure;
  latestSimulation: SimulationRunResult | null;
  isSimulating: boolean;
  onRunSimulation: (params: {
    seed: number;
    numPaths: number;
    scenarioName: string;
    assumptions: DealAssumptions;
  }) => void;
  onUpdateAssumptions: (assumptions: DealAssumptions) => void;
}

export function ValuationView({
  deal,
  structure,
  latestSimulation,
  isSimulating,
  onRunSimulation,
  onUpdateAssumptions,
}: ValuationViewProps) {
  const [seed, setSeed] = useState<number>(202611);
  const [numPaths, setNumPaths] = useState<number>(250);
  const [scenarioName, setScenarioName] = useState<string>('Base Calibration');
  const [showMethodology, setShowMethodology] = useState<boolean>(false);

  const assumptions = structure.assumptions;

  const updateRealWorld = <K extends keyof DealAssumptions>(
    key: K,
    val: DealAssumptions[K]
  ) => {
    onUpdateAssumptions({ ...assumptions, [key]: val });
  };

  const maxHistProb = Math.max(
    1,
    ...(latestSimulation?.lossHistogram.map((b) => b.probabilityPct) ?? [1])
  );

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-white/10 pb-5">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-[#F4F1EA]">
            Quantitative Valuation & Monte Carlo Risk Engine
          </h1>
          <p className="mt-1 text-sm text-[#A1A6B3]">
            Seeded Gaussian factor copula simulation separating real-world credit loss projections from market-pricing discount curves.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={() => setShowMethodology((v) => !v)}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium bg-[#141820] border border-white/15 text-[#F4F1EA] rounded hover:border-[#C8A253]"
          >
            <BookOpen className="w-3.5 h-3.5 text-[#C8A253]" />
            {showMethodology ? 'Hide Model Docs' : 'Calibration & Docs'}
          </button>
          <button
            type="button"
            disabled={isSimulating}
            onClick={() =>
              onRunSimulation({
                seed,
                numPaths,
                scenarioName,
                assumptions,
              })
            }
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold bg-[#C8A253] text-[#0B0D10] rounded hover:bg-[#D9B76E] disabled:opacity-50"
          >
            {isSimulating ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Play className="w-3.5 h-3.5" />
            )}
            {isSimulating ? 'Running Worker...' : 'Execute Monte Carlo Run'}
          </button>
        </div>
      </div>

      {/* Methodology Documentation Drawer */}
      {showMethodology && (
        <div className="bg-[#141820] border border-[#C8A253]/40 rounded-lg p-6 space-y-3 text-xs text-[#D2CFC7] leading-relaxed">
          <h2 className="text-sm font-semibold text-[#F4F1EA]">
            Distributions, Copula Calibration & Accounting Boundaries
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <p>
                <strong className="text-[#F4F1EA]">1. Two-Factor Gaussian Default Copula:</strong>{' '}
                Each obligor latent variable is drawn as{' '}
                <span className="font-mono text-[#E3B469]">
                  Z_i = sqrt(rho_macro)*M + sqrt(rho_cluster)*C_g + sqrt(1 - rho_macro - rho_cluster)*eps_i
                </span>
                , mapping shared supply-chain dependencies and economic groups into correlated default timing.
              </p>
              <p>
                <strong className="text-[#F4F1EA]">2. Stochastic Recovery & Recovery Lags:</strong>{' '}
                Conditional on default, recovery severity is sampled around each asset’s assumed recovery rate (std dev 10%, clamped [5%, 95%]) and lands in the Principal Account after the configured recovery lag (quarters).
              </p>
            </div>
            <div className="space-y-2">
              <p>
                <strong className="text-[#F4F1EA]">3. Deterministic PRNG Reproducibility:</strong>{' '}
                All Monte Carlo draws use a seeded Mulberry32 generator (<span className="font-mono">seed = {seed}</span>), guaranteeing bit-exact reproducibility across runs and audit snapshots.
              </p>
              <p>
                <strong className="text-[#F4F1EA]">4. Analytical Market Spread Disclaimer:</strong>{' '}
                Discounted Present Values and Model-Implied Spreads are analytical model outputs derived from user-supplied discount curves and real-world expected cash flows. They are <strong>not</strong> executable market quotes.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Split Parameter Controls: Real-World vs Market Pricing */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Simulation & Real-World Assumptions */}
        <div className="lg:col-span-8 bg-[#141820] border border-white/10 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-white/10 pb-2.5">
            <h2 className="text-sm font-semibold text-[#F4F1EA]">
              Real-World Credit & Cash-Flow Assumptions
            </h2>
            <span className="text-[11px] font-mono text-[#84B3E0]">
              Drives Default Timing, Recoveries & Waterfall
            </span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
            <label className="space-y-1">
              <span className="text-[#A1A6B3] block">PRNG Seed</span>
              <input
                type="number"
                value={seed}
                onChange={(e) => setSeed(Number(e.target.value))}
                className="w-full bg-[#0B0D10] border border-white/15 rounded px-2.5 py-1.5 font-mono text-[#F4F1EA]"
              />
            </label>
            <label className="space-y-1">
              <span className="text-[#A1A6B3] block">Monte Carlo Paths</span>
              <select
                value={numPaths}
                onChange={(e) => setNumPaths(Number(e.target.value))}
                className="w-full bg-[#0B0D10] border border-white/15 rounded px-2.5 py-1.5 font-mono text-[#F4F1EA]"
              >
                <option value={100}>100 paths</option>
                <option value={250}>250 paths</option>
                <option value={500}>500 paths</option>
                <option value={1000}>1,000 paths</option>
              </select>
            </label>
            <label className="space-y-1">
              <span className="text-[#A1A6B3] block">PD Multiplier</span>
              <input
                type="number"
                step={0.1}
                min={0.2}
                max={5}
                value={assumptions.pdMultiplier}
                onChange={(e) => updateRealWorld('pdMultiplier', Number(e.target.value))}
                className="w-full bg-[#0B0D10] border border-white/15 rounded px-2.5 py-1.5 font-mono text-[#F4F1EA]"
              />
            </label>
            <label className="space-y-1">
              <span className="text-[#A1A6B3] block">Recovery Multiplier</span>
              <input
                type="number"
                step={0.05}
                min={0.2}
                max={1.5}
                value={assumptions.recoveryMultiplier}
                onChange={(e) => updateRealWorld('recoveryMultiplier', Number(e.target.value))}
                className="w-full bg-[#0B0D10] border border-white/15 rounded px-2.5 py-1.5 font-mono text-[#F4F1EA]"
              />
            </label>
            <label className="space-y-1">
              <span className="text-[#A1A6B3] block">Default Correlation (Rho)</span>
              <input
                type="number"
                step={0.02}
                min={0.02}
                max={0.8}
                value={assumptions.defaultCorrelationRho}
                onChange={(e) => updateRealWorld('defaultCorrelationRho', Number(e.target.value))}
                className="w-full bg-[#0B0D10] border border-white/15 rounded px-2.5 py-1.5 font-mono text-[#F4F1EA]"
              />
            </label>
            <label className="space-y-1">
              <span className="text-[#A1A6B3] block">Cluster Shock Factor</span>
              <input
                type="number"
                step={0.1}
                min={0.5}
                max={3.0}
                value={assumptions.clusterShockFactor}
                onChange={(e) => updateRealWorld('clusterShockFactor', Number(e.target.value))}
                className="w-full bg-[#0B0D10] border border-white/15 rounded px-2.5 py-1.5 font-mono text-[#F4F1EA]"
              />
            </label>
            <label className="space-y-1">
              <span className="text-[#A1A6B3] block">Rate Shock (bps)</span>
              <input
                type="number"
                step={25}
                min={-300}
                max={500}
                value={assumptions.rateShockBps}
                onChange={(e) => updateRealWorld('rateShockBps', Number(e.target.value))}
                className="w-full bg-[#0B0D10] border border-white/15 rounded px-2.5 py-1.5 font-mono text-[#F4F1EA]"
              />
            </label>
            <label className="space-y-1">
              <span className="text-[#A1A6B3] block">Scenario Label</span>
              <input
                type="text"
                value={scenarioName}
                onChange={(e) => setScenarioName(e.target.value)}
                className="w-full bg-[#0B0D10] border border-white/15 rounded px-2.5 py-1.5 text-xs text-[#F4F1EA]"
              />
            </label>
          </div>
        </div>

        {/* Market Pricing Curve Assumptions (Strictly Separated) */}
        <div className="lg:col-span-4 bg-[#141820] border border-white/10 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-white/10 pb-2.5">
            <h2 className="text-sm font-semibold text-[#F4F1EA]">
              Market-Pricing Curve
            </h2>
            <span className="text-[11px] font-mono text-[#E3B469]">
              PV & Spreads Only
            </span>
          </div>
          <div className="space-y-3 text-xs">
            <label className="flex items-center justify-between gap-3">
              <span className="text-[#A1A6B3]">Risk-Free Curve (bps)</span>
              <input
                type="number"
                step={10}
                value={assumptions.riskFreeCurveBps}
                onChange={(e) => updateRealWorld('riskFreeCurveBps', Number(e.target.value))}
                className="w-24 bg-[#0B0D10] border border-white/15 rounded px-2.5 py-1.5 font-mono text-right text-[#F4F1EA]"
              />
            </label>
            <label className="flex items-center justify-between gap-3">
              <span className="text-[#A1A6B3]">Liquidity Premium (bps)</span>
              <input
                type="number"
                step={5}
                value={assumptions.liquidityPremiumBps}
                onChange={(e) => updateRealWorld('liquidityPremiumBps', Number(e.target.value))}
                className="w-24 bg-[#0B0D10] border border-white/15 rounded px-2.5 py-1.5 font-mono text-right text-[#F4F1EA]"
              />
            </label>
            <label className="flex items-center justify-between gap-3">
              <span className="text-[#A1A6B3]">Market Risk Prem (bps)</span>
              <input
                type="number"
                step={10}
                value={assumptions.marketSpreadAdjustmentBps}
                onChange={(e) =>
                  updateRealWorld('marketSpreadAdjustmentBps', Number(e.target.value))
                }
                className="w-24 bg-[#0B0D10] border border-white/15 rounded px-2.5 py-1.5 font-mono text-right text-[#F4F1EA]"
              />
            </label>
            <p className="text-[11px] text-[#A1A6B3] pt-1 border-t border-white/10">
              Total Analytical Discount Rate:{' '}
              <span className="font-mono text-[#F4F1EA]">
                {formatBps(
                  assumptions.riskFreeCurveBps +
                    assumptions.liquidityPremiumBps +
                    assumptions.marketSpreadAdjustmentBps
                )}
              </span>
            </p>
          </div>
        </div>
      </div>

      {/* Simulation Results */}
      {latestSimulation ? (
        <>
          {/* Portfolio Summary Strip */}
          <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
            <div className="bg-[#141820] border border-white/10 rounded-lg p-4">
              <div className="text-xs text-[#A1A6B3]">Mean Pool Net Loss</div>
              <div className="text-xl font-mono font-semibold text-[#F4F1EA] mt-1">
                {formatPct(latestSimulation.summaryMetrics.meanPoolLossPct)}
              </div>
            </div>
            <div className="bg-[#141820] border border-white/10 rounded-lg p-4">
              <div className="text-xs text-[#A1A6B3]">P95 / P99 Tail Loss</div>
              <div className="text-xl font-mono font-semibold text-[#DF8787] mt-1">
                {formatPct(latestSimulation.summaryMetrics.p95PoolLossPct, 1)} /{' '}
                {formatPct(latestSimulation.summaryMetrics.p99PoolLossPct, 1)}
              </div>
            </div>
            <div className="bg-[#141820] border border-white/10 rounded-lg p-4">
              <div className="text-xs text-[#A1A6B3]">OC Breach Path Freq</div>
              <div className="text-xl font-mono font-semibold text-[#E3B469] mt-1">
                {formatPct(latestSimulation.summaryMetrics.ocBreachPathPct, 1)}
              </div>
            </div>
            <div className="bg-[#141820] border border-white/10 rounded-lg p-4">
              <div className="text-xs text-[#A1A6B3]">Liquidity Shortfall Freq</div>
              <div className="text-xl font-mono font-semibold text-[#F4F1EA] mt-1">
                {formatPct(latestSimulation.summaryMetrics.liquidityShortfallPathPct, 1)}
              </div>
            </div>
            <div className="bg-[#141820] border border-white/10 rounded-lg p-4">
              <div className="text-xs text-[#A1A6B3]">Issuer Net Arbitrage</div>
              <div className="text-xl font-mono font-semibold text-[#6CC4B5] mt-1">
                {formatBps(latestSimulation.summaryMetrics.issuerNetFundingSpreadBps)}
              </div>
            </div>
            <div className="bg-[#141820] border border-white/10 rounded-lg p-4">
              <div className="text-xs text-[#A1A6B3]">Run Metadata</div>
              <div className="text-xs font-mono text-[#D2CFC7] mt-1.5">
                Seed {latestSimulation.seed} · {latestSimulation.numPaths} paths ·{' '}
                {latestSimulation.summaryMetrics.executionTimeMs}ms
              </div>
            </div>
          </div>

          {/* Tranche Valuation Table (Real-World vs Market Pricing Clearly Demarcated) */}
          <div className="bg-[#141820] border border-white/10 rounded-lg overflow-hidden">
            <div className="px-5 py-3.5 border-b border-white/10 flex flex-wrap items-center justify-between gap-3">
              <h3 className="text-sm font-semibold text-[#F4F1EA]">
                Tranche-by-Tranche Quantitative Output ({latestSimulation.modelVersion})
              </h3>
              <span className="text-[11px] text-[#E3B469]">
                Analytical Estimates Only · Simulated Values Are Not Executable Market Quotes
              </span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-[#101319] border-b border-white/10">
                    <th colSpan={2} className="py-1.5 px-3 text-[11px] text-[#A1A6B3] border-r border-white/10">
                      Tranche Identity
                    </th>
                    <th colSpan={6} className="py-1.5 px-3 text-[11px] text-[#84B3E0] bg-[#4B83B8]/10 border-r border-white/10">
                      Real-World Risk & Cash-Flow Projections
                    </th>
                    <th colSpan={3} className="py-1.5 px-3 text-[11px] text-[#E3B469] bg-[#C8A253]/10">
                      Market-Pricing Valuation (Analytical)
                    </th>
                  </tr>
                  <tr className="border-b border-white/10 text-[#A1A6B3] bg-[#101319]">
                    <th className="py-2.5 px-3">Tranche</th>
                    <th className="py-2.5 px-3 text-right border-r border-white/10">Notional</th>
                    <th className="py-2.5 px-3 text-right">Exp Loss ($)</th>
                    <th className="py-2.5 px-3 text-right">Exp Loss (%)</th>
                    <th className="py-2.5 px-3 text-right">Impair Prob</th>
                    <th className="py-2.5 px-3 text-right">Int Shortfall</th>
                    <th className="py-2.5 px-3 text-right">WAL (Yrs)</th>
                    <th className="py-2.5 px-3 text-right border-r border-white/10">Real-World IRR</th>
                    <th className="py-2.5 px-3 text-right">Discounted PV</th>
                    <th className="py-2.5 px-3 text-right">Model Px (%)</th>
                    <th className="py-2.5 px-3 text-right">Implied Spread</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {latestSimulation.trancheMetrics.map((tm) => {
                    const meta = SENIORITY_META[tm.seniority];
                    return (
                      <tr key={tm.trancheId} className="hover:bg-white/[0.02]">
                        <td className="py-2.5 px-3">
                          <div className="font-medium text-[#F4F1EA]">{tm.code}</div>
                          <div className={`text-[11px] ${meta.textClass}`}>
                            {meta.label} ({tm.attachmentPct.toFixed(1)}–{tm.detachmentPct.toFixed(1)}%)
                          </div>
                        </td>
                        <td className="py-2.5 px-3 font-mono text-right text-[#F4F1EA] border-r border-white/10">
                          {formatCurrency(tm.initialNotional, deal.currency, true)}
                        </td>
                        <td className="py-2.5 px-3 font-mono text-right text-[#D2CFC7]">
                          {formatCurrency(tm.expectedPrincipalLoss, deal.currency)}
                        </td>
                        <td className="py-2.5 px-3 font-mono text-right text-[#F4F1EA]">
                          {formatPct(tm.expectedLossPct)}
                        </td>
                        <td className="py-2.5 px-3 font-mono text-right text-[#E3B469]">
                          {formatPct(tm.probabilityOfImpairment)}
                        </td>
                        <td className="py-2.5 px-3 font-mono text-right text-[#DF8787]">
                          {formatCurrency(tm.expectedInterestShortfall, deal.currency)}
                        </td>
                        <td className="py-2.5 px-3 font-mono text-right text-[#D2CFC7]">
                          {tm.weightedAverageLifeYears.toFixed(2)}
                        </td>
                        <td className="py-2.5 px-3 font-mono text-right text-[#6CC4B5] border-r border-white/10">
                          {formatPct(tm.realWorldIrrPct)}
                        </td>
                        <td className="py-2.5 px-3 font-mono text-right text-[#F4F1EA]">
                          {formatCurrency(tm.discountedPresentValue, deal.currency, true)}
                        </td>
                        <td className="py-2.5 px-3 font-mono text-right text-[#D2CFC7]">
                          {tm.discountedPricePct.toFixed(2)}%
                        </td>
                        <td className="py-2.5 px-3 font-mono text-right text-[#E3B469]">
                          {formatBps(tm.modelImpliedSpreadBps)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Loss Distribution Histogram */}
          <div className="bg-[#141820] border border-white/10 rounded-lg p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-[#C8A253]" />
                <h3 className="text-sm font-semibold text-[#F4F1EA]">
                  Simulated Collateral Net Loss Distribution ({latestSimulation.numPaths} Paths)
                </h3>
              </div>
              <span className="text-xs font-mono text-[#A1A6B3]">
                Mean {formatPct(latestSimulation.summaryMetrics.meanPoolLossPct)} · P99{' '}
                {formatPct(latestSimulation.summaryMetrics.p99PoolLossPct)}
              </span>
            </div>

            <div className="grid grid-cols-9 gap-2 items-end h-44 pt-4">
              {latestSimulation.lossHistogram.map((bin) => {
                const heightPct = Math.max(4, Math.round((bin.probabilityPct / maxHistProb) * 100));
                return (
                  <div key={bin.bucketLabel} className="flex flex-col items-center h-full justify-end gap-1.5">
                    <span className="text-[11px] font-mono text-[#D2CFC7]">
                      {bin.probabilityPct.toFixed(1)}%
                    </span>
                    <div
                      className="w-full bg-[#C8A253]/80 hover:bg-[#C8A253] rounded-t transition-all"
                      style={{ height: `${heightPct}%` }}
                      title={`${bin.bucketLabel}: ${bin.pathCount} paths (${bin.probabilityPct.toFixed(1)}%)`}
                    />
                    <span className="text-[11px] font-mono text-[#A1A6B3] whitespace-nowrap">
                      {bin.bucketLabel}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </>
      ) : (
        <div className="bg-[#141820] border border-white/10 rounded-lg p-12 text-center space-y-3">
          <p className="text-sm text-[#A1A6B3]">
            No Monte Carlo simulation has been executed yet for this structure.
          </p>
          <button
            type="button"
            onClick={() =>
              onRunSimulation({
                seed,
                numPaths,
                scenarioName,
                assumptions,
              })
            }
            className="px-4 py-2 text-xs font-semibold bg-[#C8A253] text-[#0B0D10] rounded"
          >
            Run Initial Simulation
          </button>
        </div>
      )}
    </div>
  );
}
