import React, { useMemo, useState } from 'react';
import {
  AlertOctagon,
  ArrowDown,
  ArrowUp,
  CheckCircle2,
  Plus,
  Trash2,
  Zap,
} from 'lucide-react';
import type {
  CollateralAsset,
  DealRecord,
  DealStructure,
  WaterfallRule,
} from '../../engine/types.ts';
import { runContractualWaterfall } from '../../engine/waterfall.ts';
import { formatCurrencyExact, formatRatio } from '../../lib/format.ts';

interface WaterfallViewProps {
  deal: DealRecord;
  assets: CollateralAsset[];
  structure: DealStructure;
  onUpdateRules: (rules: WaterfallRule[]) => void;
}

export function WaterfallView({
  deal,
  assets,
  structure,
  onUpdateRules,
}: WaterfallViewProps) {
  const [accountTab, setAccountTab] = useState<'all' | 'interest' | 'principal'>('all');
  const [selectedPeriod, setSelectedPeriod] = useState<number>(1);
  const [injectBreachShock, setInjectBreachShock] = useState<boolean>(false);

  const periodShocks = useMemo(() => {
    if (!injectBreachShock) return undefined;
    // Inject a Period 3 & 4 clustered default shock with delayed recovery to demonstrate OC/IC diversion
    return [
      {},
      {},
      { defaultFractionOverride: 0.08, recoveryRateOverride: 0.3 },
      { defaultFractionOverride: 0.11, recoveryRateOverride: 0.25 },
    ];
  }, [injectBreachShock]);

  const waterfallResult = useMemo(
    () =>
      runContractualWaterfall({
        deal,
        assets,
        tranches: structure.tranches,
        rules: structure.waterfallRules,
        assumptions: structure.assumptions,
        periodShocks,
      }),
    [deal, assets, structure, periodShocks]
  );

  const activePeriod =
    waterfallResult.periods.find((p) => p.period === selectedPeriod) ??
    waterfallResult.periods[0];

  const sortedRules = useMemo(
    () => [...structure.waterfallRules].sort((a, b) => a.priority - b.priority),
    [structure.waterfallRules]
  );

  const visibleRules = useMemo(
    () =>
      sortedRules.filter((r) => (accountTab === 'all' ? true : r.account === accountTab)),
    [sortedRules, accountTab]
  );

  const commitRules = (next: WaterfallRule[]) => {
    onUpdateRules(next.map((r, i) => ({ ...r, priority: i + 1 })));
  };

  const handleMoveRule = (ruleId: string, dir: -1 | 1) => {
    const idx = sortedRules.findIndex((r) => r.id === ruleId);
    const target = idx + dir;
    if (idx === -1 || target < 0 || target >= sortedRules.length) return;
    const copy = [...sortedRules];
    const [moved] = copy.splice(idx, 1);
    copy.splice(target, 0, moved);
    commitRules(copy);
  };

  const handleRuleChange = <K extends keyof WaterfallRule>(
    ruleId: string,
    key: K,
    value: WaterfallRule[K]
  ) => {
    commitRules(sortedRules.map((r) => (r.id === ruleId ? { ...r, [key]: value } : r)));
  };

  const handleAddRule = () => {
    const id = `wf_custom_${Date.now().toString().slice(-4)}`;
    commitRules([
      ...sortedRules,
      {
        id,
        priority: sortedRules.length + 1,
        name: 'Custom Reserve / Expense Priority',
        account: 'interest',
        ruleType: 'fee_expense',
        condition: 'always',
        sourceAccount: 'interest',
        destination: 'Reserve / Custom Account',
        calculationMethod: 'fixed_amount',
        repaymentMode: 'sequential',
        shortfallTreatment: 'unpaid_shortfall',
        fixedAmount: 50000,
      },
    ]);
  };

  const handleDeleteRule = (ruleId: string) => {
    if (sortedRules.length <= 2) return;
    commitRules(sortedRules.filter((r) => r.id !== ruleId));
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-white/10 pb-5">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-[#F4F1EA]">
            Contractual Waterfall Designer & Period Audit
          </h1>
          <p className="mt-1 text-sm text-[#A1A6B3]">
            Configure priority-of-payments across Interest and Principal accounts with cycle detection, strict cash conservation, and step-by-step shortfall accounting.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={() => {
              setInjectBreachShock((v) => !v);
              setSelectedPeriod((prev) => (!injectBreachShock ? 4 : prev));
            }}
            className={`inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded border transition-colors ${
              injectBreachShock
                ? 'bg-[#B85A5A]/20 border-[#B85A5A] text-[#DF8787]'
                : 'bg-[#141820] border-white/15 text-[#E3B469] hover:border-[#E3B469]'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            {injectBreachShock ? 'Clear Q3-Q4 Breach Stress' : 'Demonstrate OC Breach Diversion'}
          </button>
          <button
            type="button"
            onClick={handleAddRule}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold bg-[#C8A253] text-[#0B0D10] rounded hover:bg-[#D9B76E]"
          >
            <Plus className="w-3.5 h-3.5" /> Add Waterfall Rule
          </button>
        </div>
      </div>

      {/* Verification & Engine Mode Banner */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-[#141820] border border-white/10 rounded-lg p-4">
          <div className="text-xs text-[#A1A6B3]">Vehicle Accounting Mode</div>
          <div className="text-sm font-semibold text-[#F4F1EA] mt-1">
            {deal.structureType === 'synthetic'
              ? 'Synthetic CDO (Protection Swap + CLN)'
              : 'Cash CDO (Interest & Principal Accounts)'}
          </div>
        </div>
        <div className="bg-[#141820] border border-white/10 rounded-lg p-4">
          <div className="text-xs text-[#A1A6B3]">Cash Conservation Check</div>
          <div className="flex items-center gap-1.5 text-sm font-mono font-semibold text-[#6CC4B5] mt-1">
            <CheckCircle2 className="w-4 h-4" />
            Max Error: ${waterfallResult.maxCashConservationError.toFixed(6)}
          </div>
        </div>
        <div className="bg-[#141820] border border-white/10 rounded-lg p-4">
          <div className="text-xs text-[#A1A6B3]">Rule Graph Integrity</div>
          <div className="text-sm font-semibold mt-1">
            {waterfallResult.ruleCycleDetected ? (
              <span className="text-[#DF8787]">{waterfallResult.ruleCycleError}</span>
            ) : (
              <span className="text-[#6CC4B5]">Acyclic Priority Order Verified</span>
            )}
          </div>
        </div>
        <div className="bg-[#141820] border border-white/10 rounded-lg p-4">
          <div className="text-xs text-[#A1A6B3]">Total Cash Diverted (OC/IC Cure)</div>
          <div
            className={`text-sm font-mono font-semibold mt-1 ${
              waterfallResult.totalDivertedCash > 0 ? 'text-[#E3B469]' : 'text-[#F4F1EA]'
            }`}
          >
            {formatCurrencyExact(waterfallResult.totalDivertedCash, deal.currency)}
          </div>
        </div>
      </div>

      {/* Rule Editor Table */}
      <div className="bg-[#141820] border border-white/10 rounded-lg overflow-hidden">
        <div className="px-5 py-3.5 border-b border-white/10 flex flex-wrap items-center justify-between gap-3">
          <h2 className="text-sm font-semibold text-[#F4F1EA]">
            Contractual Priority of Payments ({sortedRules.length} Rules)
          </h2>
          <div className="flex gap-1 bg-[#0B0D10] p-1 rounded border border-white/10 text-xs">
            {(['all', 'interest', 'principal'] as const).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setAccountTab(t)}
                className={`px-3 py-1 rounded capitalize transition-colors ${
                  accountTab === t
                    ? 'bg-[#C8A253] text-[#0B0D10] font-semibold'
                    : 'text-[#A1A6B3] hover:text-[#F4F1EA]'
                }`}
              >
                {t === 'all' ? 'All Rules' : `${t} Account`}
              </button>
            ))}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-white/10 text-[#A1A6B3] bg-[#101319]">
                <th className="py-2.5 px-3">Prio</th>
                <th className="py-2.5 px-3">Account</th>
                <th className="py-2.5 px-3">Rule Description</th>
                <th className="py-2.5 px-3">Condition</th>
                <th className="py-2.5 px-3">Repayment Mode</th>
                <th className="py-2.5 px-3">Shortfall Treatment</th>
                <th className="py-2.5 px-3 text-right">Order / Edit</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {visibleRules.map((rule) => (
                <tr key={rule.id} className="hover:bg-white/[0.02]">
                  <td className="py-2.5 px-3 font-mono text-[#C8A253] font-semibold">
                    #{rule.priority}
                  </td>
                  <td className="py-2.5 px-3">
                    <select
                      value={rule.account}
                      onChange={(e) =>
                        handleRuleChange(
                          rule.id,
                          'account',
                          e.target.value as WaterfallRule['account']
                        )
                      }
                      className="bg-[#0B0D10] border border-white/15 rounded px-2 py-1 text-xs text-[#F4F1EA]"
                    >
                      <option value="interest">Interest</option>
                      <option value="principal">Principal</option>
                    </select>
                  </td>
                  <td className="py-2.5 px-3">
                    <input
                      type="text"
                      value={rule.name}
                      onChange={(e) => handleRuleChange(rule.id, 'name', e.target.value)}
                      className="w-full min-w-[220px] bg-[#0B0D10] border border-white/10 rounded px-2 py-1 text-xs text-[#F4F1EA]"
                    />
                  </td>
                  <td className="py-2.5 px-3">
                    <select
                      value={rule.condition}
                      onChange={(e) =>
                        handleRuleChange(
                          rule.id,
                          'condition',
                          e.target.value as WaterfallRule['condition']
                        )
                      }
                      className="bg-[#0B0D10] border border-white/15 rounded px-2 py-1 text-xs text-[#D2CFC7]"
                    >
                      <option value="always">Always</option>
                      <option value="test_pass">OC & IC Pass</option>
                      <option value="test_fail">OC or IC Fail</option>
                      <option value="oc_test_pass">OC Test Pass</option>
                      <option value="oc_test_fail">OC Test Fail</option>
                      <option value="in_reinvestment">In Reinvestment</option>
                      <option value="post_reinvestment">Post-Reinvestment</option>
                      <option value="early_amort_triggered">Early Amort Triggered</option>
                    </select>
                  </td>
                  <td className="py-2.5 px-3">
                    <select
                      value={rule.repaymentMode}
                      onChange={(e) =>
                        handleRuleChange(
                          rule.id,
                          'repaymentMode',
                          e.target.value as WaterfallRule['repaymentMode']
                        )
                      }
                      className="bg-[#0B0D10] border border-white/15 rounded px-2 py-1 text-xs text-[#D2CFC7]"
                    >
                      <option value="sequential">Sequential</option>
                      <option value="pro_rata">Permitted Pro-Rata</option>
                    </select>
                  </td>
                  <td className="py-2.5 px-3">
                    <select
                      value={rule.shortfallTreatment}
                      onChange={(e) =>
                        handleRuleChange(
                          rule.id,
                          'shortfallTreatment',
                          e.target.value as WaterfallRule['shortfallTreatment']
                        )
                      }
                      className="bg-[#0B0D10] border border-white/15 rounded px-2 py-1 text-xs text-[#D2CFC7]"
                    >
                      <option value="unpaid_shortfall">Unpaid Shortfall</option>
                      <option value="defer_pik">Defer to PIK</option>
                      <option value="draw_reserve">Draw Reserve</option>
                      <option value="divert_next">Divert to Principal</option>
                    </select>
                  </td>
                  <td className="py-2.5 px-3 text-right whitespace-nowrap">
                    <div className="inline-flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => handleMoveRule(rule.id, -1)}
                        className="p-1 border border-white/10 rounded hover:border-[#C8A253]"
                        aria-label="Move rule up"
                      >
                        <ArrowUp className="w-3 h-3" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleMoveRule(rule.id, 1)}
                        className="p-1 border border-white/10 rounded hover:border-[#C8A253]"
                        aria-label="Move rule down"
                      >
                        <ArrowDown className="w-3 h-3" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDeleteRule(rule.id)}
                        className="p-1 border border-white/10 rounded text-[#DF8787] hover:border-[#B85A5A]"
                        aria-label="Delete rule"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Period-by-Period Execution Debugger */}
      {activePeriod && (
        <div className="bg-[#141820] border border-white/10 rounded-lg p-6 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/10 pb-4">
            <div>
              <h3 className="text-base font-semibold text-[#F4F1EA]">
                Period-by-Period Contractual Execution Trace
              </h3>
              <p className="text-xs text-[#A1A6B3]">
                Inspect Cash Available → Rule Applied → Payment Made → Unpaid / Deferred → Remaining Cash for any reporting period.
              </p>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {waterfallResult.periods.map((p) => {
                const breached = !p.ocTestPassed || !p.icTestPassed;
                return (
                  <button
                    key={p.period}
                    type="button"
                    onClick={() => setSelectedPeriod(p.period)}
                    className={`px-2.5 py-1 text-xs font-mono rounded border transition-colors ${
                      selectedPeriod === p.period
                        ? 'bg-[#C8A253] text-[#0B0D10] border-[#C8A253] font-semibold'
                        : breached
                        ? 'bg-[#B85A5A]/20 text-[#DF8787] border-[#B85A5A]/50'
                        : 'bg-[#0B0D10] text-[#D2CFC7] border-white/10 hover:border-white/30'
                    }`}
                  >
                    {p.periodLabel}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Period Summary Header */}
          <div className="grid grid-cols-2 md:grid-cols-6 gap-4 text-xs bg-[#0B0D10] border border-white/10 rounded p-4">
            <div>
              <div className="text-[#A1A6B3]">Interest Available</div>
              <div className="font-mono text-sm font-semibold text-[#F4F1EA] mt-0.5">
                {formatCurrencyExact(activePeriod.interestAccountAvailable, deal.currency)}
              </div>
            </div>
            <div>
              <div className="text-[#A1A6B3]">Principal Available</div>
              <div className="font-mono text-sm font-semibold text-[#F4F1EA] mt-0.5">
                {formatCurrencyExact(activePeriod.principalAccountAvailable, deal.currency)}
              </div>
            </div>
            <div>
              <div className="text-[#A1A6B3]">OC Ratio (Min {formatRatio(deal.ocTriggerRatio, 2)})</div>
              <div
                className={`font-mono text-sm font-semibold mt-0.5 ${
                  activePeriod.ocTestPassed ? 'text-[#6CC4B5]' : 'text-[#DF8787]'
                }`}
              >
                {formatRatio(activePeriod.ocRatioBefore)} ·{' '}
                {activePeriod.ocTestPassed ? 'PASS' : 'BREACH'}
              </div>
            </div>
            <div>
              <div className="text-[#A1A6B3]">IC Ratio (Min {formatRatio(deal.icTriggerRatio, 2)})</div>
              <div
                className={`font-mono text-sm font-semibold mt-0.5 ${
                  activePeriod.icTestPassed ? 'text-[#6CC4B5]' : 'text-[#DF8787]'
                }`}
              >
                {formatRatio(activePeriod.icRatioBefore)} ·{' '}
                {activePeriod.icTestPassed ? 'PASS' : 'BREACH'}
              </div>
            </div>
            <div>
              <div className="text-[#A1A6B3]">Diverted to Cure</div>
              <div className="font-mono text-sm font-semibold text-[#E3B469] mt-0.5">
                {formatCurrencyExact(activePeriod.diversionAmount, deal.currency)}
              </div>
            </div>
            <div>
              <div className="text-[#A1A6B3]">Ending Reserve</div>
              <div className="font-mono text-sm font-semibold text-[#F4F1EA] mt-0.5">
                {formatCurrencyExact(activePeriod.endingReserve, deal.currency)}
              </div>
            </div>
          </div>

          {deal.structureType === 'synthetic' && (
            <div className="bg-[#1C222D] border border-[#4B83B8]/40 rounded p-4 grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
              <div>
                <div className="text-[#84B3E0]">Reference Portfolio Notional</div>
                <div className="font-mono font-semibold text-[#F4F1EA] mt-0.5">
                  {formatCurrencyExact(activePeriod.syntheticReferenceNotional, deal.currency)}
                </div>
              </div>
              <div>
                <div className="text-[#84B3E0]">Funded Collateral Account</div>
                <div className="font-mono font-semibold text-[#F4F1EA] mt-0.5">
                  {formatCurrencyExact(activePeriod.syntheticFundedCollateral, deal.currency)}
                </div>
              </div>
              <div>
                <div className="text-[#84B3E0]">Credit Event Loss Settled</div>
                <div className="font-mono font-semibold text-[#DF8787] mt-0.5">
                  {formatCurrencyExact(activePeriod.syntheticLossSettled, deal.currency)}
                </div>
              </div>
              <div>
                <div className="text-[#84B3E0]">Unfunded Swap Counterparty Exp</div>
                <div className="font-mono font-semibold text-[#F4F1EA] mt-0.5">
                  {formatCurrencyExact(activePeriod.syntheticCounterpartyExposure, deal.currency)}
                </div>
              </div>
            </div>
          )}

          {(!activePeriod.ocTestPassed || !activePeriod.icTestPassed) && (
            <div className="flex items-start gap-2.5 bg-[#B85A5A]/15 border border-[#B85A5A]/50 rounded p-3.5 text-xs text-[#F4F1EA]">
              <AlertOctagon className="w-4 h-4 text-[#DF8787] shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-[#DF8787]">Coverage-Test Breach Diversion Active: </span>
                Junior and Equity residual distributions are suspended.{' '}
                <span className="font-mono">{formatCurrencyExact(activePeriod.diversionAmount, deal.currency)}</span>{' '}
                was diverted into the Principal Account for senior cure, and unpaid deferrable coupons were capitalized into PIK balance.
              </div>
            </div>
          )}

          {/* Step-by-Step Rule Execution Ledger */}
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-white/10 text-[#A1A6B3] bg-[#101319]">
                  <th className="py-2 px-3">Step</th>
                  <th className="py-2 px-3">Rule Applied</th>
                  <th className="py-2 px-3">Condition</th>
                  <th className="py-2 px-3 text-right">Cash Available</th>
                  <th className="py-2 px-3 text-right">Requested</th>
                  <th className="py-2 px-3 text-right">Payment Made</th>
                  <th className="py-2 px-3 text-right">Unpaid / PIK</th>
                  <th className="py-2 px-3 text-right">Remaining Cash</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {activePeriod.auditLines.map((line) => (
                  <tr
                    key={`${line.priority}_${line.ruleId}`}
                    className={line.conditionMet ? 'hover:bg-white/[0.02]' : 'opacity-50'}
                  >
                    <td className="py-2 px-3 font-mono text-[#C8A253]">#{line.priority}</td>
                    <td className="py-2 px-3 text-[#F4F1EA]">{line.ruleName}</td>
                    <td className="py-2 px-3 text-[#A1A6B3]">
                      {line.conditionEvaluated} ({line.conditionMet ? 'Met' : 'Skipped'})
                    </td>
                    <td className="py-2 px-3 font-mono text-right text-[#D2CFC7]">
                      {formatCurrencyExact(line.cashAvailable, deal.currency)}
                    </td>
                    <td className="py-2 px-3 font-mono text-right text-[#D2CFC7]">
                      {formatCurrencyExact(line.ruleRequestedAmount, deal.currency)}
                    </td>
                    <td className="py-2 px-3 font-mono text-right text-[#6CC4B5] font-medium">
                      {formatCurrencyExact(line.paymentMade, deal.currency)}
                    </td>
                    <td className="py-2 px-3 font-mono text-right text-[#E3B469]">
                      {line.deferredToPik > 0
                        ? `${formatCurrencyExact(line.deferredToPik, deal.currency)} PIK`
                        : formatCurrencyExact(line.unpaidAmount, deal.currency)}
                    </td>
                    <td className="py-2 px-3 font-mono text-right text-[#F4F1EA]">
                      {formatCurrencyExact(line.remainingCash, deal.currency)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
