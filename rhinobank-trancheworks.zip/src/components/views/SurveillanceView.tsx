import React, { useState } from 'react';
import {
  AlertTriangle,
  ArrowLeftRight,
  Lock,
  Plus,
  Unlock,
} from 'lucide-react';
import type {
  CollateralAsset,
  DealRecord,
  DealStructure,
  SurveillancePeriodRecord,
} from '../../engine/types.ts';
import { formatCurrency, formatRatio } from '../../lib/format.ts';

interface SurveillanceViewProps {
  deal: DealRecord;
  assets: CollateralAsset[];
  structure: DealStructure;
  periods: SurveillancePeriodRecord[];
  onAddPeriod: (period: SurveillancePeriodRecord) => void;
  onFinalizePeriod: (periodId: string) => void;
  onLogSubstitution: (
    periodId: string,
    removedAssetId: string,
    addedObligor: string,
    notionalDelta: number
  ) => void;
}

export function SurveillanceView({
  deal,
  assets,
  structure,
  periods,
  onAddPeriod,
  onFinalizePeriod,
  onLogSubstitution,
}: SurveillanceViewProps) {
  const [selectedPeriodId, setSelectedPeriodId] = useState<string>(
    periods[periods.length - 1]?.id ?? ''
  );
  const [showAddForm, setShowAddForm] = useState(false);
  const [showSubForm, setShowSubForm] = useState(false);

  const [periodLabel, setPeriodLabel] = useState(`2027 Q${periods.length + 1}`);
  const [actualCollections, setActualCollections] = useState(1980000);
  const [actualDefaults, setActualDefaults] = useState(1250000);
  const [actualRecoveries, setActualRecoveries] = useState(410000);
  const [delinq30, setDelinq30] = useState(2100000);
  const [delinq60, setDelinq60] = useState(950000);

  const [subRemovedId, setSubRemovedId] = useState(assets[0]?.assetId ?? '');
  const [subAddedObligor, setSubAddedObligor] = useState('Kyoto EUV Precision Optics KK');
  const [subNotionalDelta, setSubNotionalDelta] = useState(0);

  const activePeriod =
    periods.find((p) => p.id === selectedPeriodId) ?? periods[periods.length - 1];

  const handleCreatePeriod = (e: React.FormEvent) => {
    e.preventDefault();
    const prev = periods[periods.length - 1];
    const prevPool = prev?.endingPoolBalance ?? deal.targetPoolNotional;
    const endingPool = Math.max(0, prevPool - actualDefaults + actualRecoveries * 0.5);
    const ratedDebt = structure.tranches
      .filter((t) => t.seniority === 'senior' || t.seniority === 'mezzanine')
      .reduce((s, t) => s + t.notional, 0);
    const ocRatio = (endingPool + deal.reserveBalance) / Math.max(1, ratedDebt);
    const icRatio = actualCollections / Math.max(1, 1268250);

    const breaches = [];
    if (ocRatio < deal.ocTriggerRatio) {
      breaches.push({
        code: 'OC_BREACH',
        testName: 'Senior + Mezzanine OC Test',
        threshold: deal.ocTriggerRatio,
        observed: Number(ocRatio.toFixed(3)),
        actionTaken: 'Diverted excess interest to senior principal paydown; junior PIK active.',
      });
    }
    if (icRatio < deal.icTriggerRatio) {
      breaches.push({
        code: 'IC_BREACH',
        testName: 'Interest Coverage Test',
        threshold: deal.icTriggerRatio,
        observed: Number(icRatio.toFixed(3)),
        actionTaken: 'Junior & equity interest distributions blocked.',
      });
    }

    const newRec: SurveillancePeriodRecord = {
      id: `surv_${deal.id}_p${periods.length + 1}_${Date.now().toString().slice(-4)}`,
      dealId: deal.id,
      periodNumber: periods.length + 1,
      periodLabel,
      asOfDate: new Date().toISOString().slice(0, 10),
      isFinalized: false,
      actualCollections,
      projectedCollections: 2050000,
      actualDefaults,
      projectedDefaults: 580000,
      actualRecoveries,
      projectedRecoveries: 520000,
      endingPoolBalance: endingPool,
      delinquency30Plus: delinq30,
      delinquency60Plus: delinq60,
      ocRatio: Number(ocRatio.toFixed(3)),
      icRatio: Number(icRatio.toFixed(3)),
      reserveBalance: deal.reserveBalance,
      trancheDistributions: structure.tranches.map((t) => ({
        code: t.code,
        interestPaid:
          breaches.length > 0 && (t.seniority === 'junior' || t.seniority === 'equity')
            ? 0
            : Math.round((t.notional * (t.spreadOrCouponBps + 425)) / 40000),
        principalPaid: 0,
        endingBalance: t.notional,
      })),
      breaches,
      substitutions: [],
      forecastSnapshot: {
        modelVersion: 'TW-QUANT-2.4.0',
        seed: 202611 + periods.length,
        assumedPdMultiplier: structure.assumptions.pdMultiplier,
        assumedRecoveryMultiplier: structure.assumptions.recoveryMultiplier,
        frozenAt: new Date().toISOString(),
      },
      createdAt: new Date().toISOString(),
    };

    onAddPeriod(newRec);
    setSelectedPeriodId(newRec.id);
    setShowAddForm(false);
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-white/10 pb-5">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-[#F4F1EA]">
            Post-Issuance Surveillance & Actuals Reconciliation
          </h1>
          <p className="mt-1 text-sm text-[#A1A6B3]">
            Reconcile actual collections against frozen period forecasts, monitor OC/IC test breaches, and preserve immutable investor reporting snapshots.
          </p>
        </div>
        <div className="flex flex-wrap gap-3">
          {activePeriod && !activePeriod.isFinalized && (
            <button
              type="button"
              onClick={() => setShowSubForm((v) => !v)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium bg-[#141820] border border-white/15 text-[#F4F1EA] rounded hover:border-[#C8A253]"
            >
              <ArrowLeftRight className="w-3.5 h-3.5 text-[#C8A253]" /> Log Substitution
            </button>
          )}
          <button
            type="button"
            onClick={() => setShowAddForm((v) => !v)}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold bg-[#C8A253] text-[#0B0D10] rounded hover:bg-[#D9B76E]"
          >
            <Plus className="w-3.5 h-3.5" /> Import Period Actuals
          </button>
        </div>
      </div>

      {/* Import Actual Collections Form */}
      {showAddForm && (
        <form
          onSubmit={handleCreatePeriod}
          className="bg-[#141820] border border-[#C8A253]/40 rounded-lg p-6 space-y-4"
        >
          <h2 className="text-sm font-semibold text-[#F4F1EA]">
            Import Actual Servicing Remittance & Reconcile
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-6 gap-4 text-xs">
            <label className="space-y-1">
              <span className="text-[#A1A6B3] block">Period Label</span>
              <input
                type="text"
                required
                value={periodLabel}
                onChange={(e) => setPeriodLabel(e.target.value)}
                className="w-full bg-[#0B0D10] border border-white/15 rounded px-2.5 py-1.5 text-[#F4F1EA]"
              />
            </label>
            <label className="space-y-1">
              <span className="text-[#A1A6B3] block">Actual Collections ($)</span>
              <input
                type="number"
                value={actualCollections}
                onChange={(e) => setActualCollections(Number(e.target.value))}
                className="w-full bg-[#0B0D10] border border-white/15 rounded px-2.5 py-1.5 font-mono text-[#F4F1EA]"
              />
            </label>
            <label className="space-y-1">
              <span className="text-[#A1A6B3] block">Actual Defaults ($)</span>
              <input
                type="number"
                value={actualDefaults}
                onChange={(e) => setActualDefaults(Number(e.target.value))}
                className="w-full bg-[#0B0D10] border border-white/15 rounded px-2.5 py-1.5 font-mono text-[#F4F1EA]"
              />
            </label>
            <label className="space-y-1">
              <span className="text-[#A1A6B3] block">Actual Recoveries ($)</span>
              <input
                type="number"
                value={actualRecoveries}
                onChange={(e) => setActualRecoveries(Number(e.target.value))}
                className="w-full bg-[#0B0D10] border border-white/15 rounded px-2.5 py-1.5 font-mono text-[#F4F1EA]"
              />
            </label>
            <label className="space-y-1">
              <span className="text-[#A1A6B3] block">30+ DPD ($)</span>
              <input
                type="number"
                value={delinq30}
                onChange={(e) => setDelinq30(Number(e.target.value))}
                className="w-full bg-[#0B0D10] border border-white/15 rounded px-2.5 py-1.5 font-mono text-[#F4F1EA]"
              />
            </label>
            <label className="space-y-1">
              <span className="text-[#A1A6B3] block">60+ DPD ($)</span>
              <input
                type="number"
                value={delinq60}
                onChange={(e) => setDelinq60(Number(e.target.value))}
                className="w-full bg-[#0B0D10] border border-white/15 rounded px-2.5 py-1.5 font-mono text-[#F4F1EA]"
              />
            </label>
          </div>
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-3 py-1.5 text-xs border border-white/15 rounded text-[#A1A6B3]"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 text-xs font-semibold bg-[#C8A253] text-[#0B0D10] rounded"
            >
              Reconcile & Save Period
            </button>
          </div>
        </form>
      )}

      {/* Collateral Substitution Form */}
      {showSubForm && activePeriod && !activePeriod.isFinalized && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            onLogSubstitution(activePeriod.id, subRemovedId, subAddedObligor, subNotionalDelta);
            setShowSubForm(false);
          }}
          className="bg-[#141820] border border-[#C8A253]/40 rounded-lg p-5 space-y-4"
        >
          <h2 className="text-sm font-semibold text-[#F4F1EA]">
            Record Collateral Substitution ({activePeriod.periodLabel})
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <label className="space-y-1">
              <span className="text-[#A1A6B3] block">Removed Asset</span>
              <select
                value={subRemovedId}
                onChange={(e) => setSubRemovedId(e.target.value)}
                className="w-full bg-[#0B0D10] border border-white/15 rounded px-2.5 py-2 text-[#F4F1EA]"
              >
                {assets.map((a) => (
                  <option key={a.assetId} value={a.assetId}>
                    {a.assetId} · {a.obligorName} ({formatCurrency(a.principalOutstanding, deal.currency, true)})
                  </option>
                ))}
              </select>
            </label>
            <label className="space-y-1">
              <span className="text-[#A1A6B3] block">Replacement Obligor</span>
              <input
                type="text"
                required
                value={subAddedObligor}
                onChange={(e) => setSubAddedObligor(e.target.value)}
                className="w-full bg-[#0B0D10] border border-white/15 rounded px-2.5 py-2 text-[#F4F1EA]"
              />
            </label>
            <label className="space-y-1">
              <span className="text-[#A1A6B3] block">Notional Delta ($)</span>
              <input
                type="number"
                value={subNotionalDelta}
                onChange={(e) => setSubNotionalDelta(Number(e.target.value))}
                className="w-full bg-[#0B0D10] border border-white/15 rounded px-2.5 py-2 font-mono text-[#F4F1EA]"
              />
            </label>
          </div>
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setShowSubForm(false)}
              className="px-3 py-1.5 text-xs border border-white/15 rounded text-[#A1A6B3]"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 text-xs font-semibold bg-[#C8A253] text-[#0B0D10] rounded"
            >
              Record Substitution
            </button>
          </div>
        </form>
      )}

      {periods.length === 0 ? (
        <div className="bg-[#141820] border border-white/10 rounded-lg p-12 text-center space-y-3">
          <p className="text-sm text-[#A1A6B3]">
            No post-issuance surveillance remittances recorded for {deal.code} yet.
          </p>
          <button
            type="button"
            onClick={() => setShowAddForm(true)}
            className="px-4 py-2 text-xs font-semibold bg-[#C8A253] text-[#0B0D10] rounded"
          >
            Log First Remittance Period
          </button>
        </div>
      ) : (
        <>
          {/* Historical Periods Timeline Table */}
          <div className="bg-[#141820] border border-white/10 rounded-lg overflow-hidden">
            <div className="px-5 py-3.5 border-b border-white/10 flex items-center justify-between">
              <h2 className="text-sm font-semibold text-[#F4F1EA]">
                Historical & Active Surveillance Ledger
              </h2>
              <span className="text-xs text-[#A1A6B3]">
                Finalized periods freeze forecast assumptions permanently against future model revisions.
              </span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-white/10 text-[#A1A6B3] bg-[#101319]">
                    <th className="py-2.5 px-3">Period</th>
                    <th className="py-2.5 px-3">Snapshot Lock</th>
                    <th className="py-2.5 px-3 text-right">Actual / Proj Coll</th>
                    <th className="py-2.5 px-3 text-right">Actual / Proj Def</th>
                    <th className="py-2.5 px-3 text-right">Recoveries</th>
                    <th className="py-2.5 px-3 text-right">Ending Pool</th>
                    <th className="py-2.5 px-3 text-right">OC Ratio</th>
                    <th className="py-2.5 px-3 text-right">IC Ratio</th>
                    <th className="py-2.5 px-3 text-right">Breaches</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {periods.map((p) => {
                    const isSelected = p.id === activePeriod?.id;
                    const ocFail = p.ocRatio < deal.ocTriggerRatio;
                    const icFail = p.icRatio < deal.icTriggerRatio;
                    return (
                      <tr
                        key={p.id}
                        onClick={() => setSelectedPeriodId(p.id)}
                        className={`cursor-pointer ${
                          isSelected ? 'bg-[#C8A253]/10' : 'hover:bg-white/[0.02]'
                        }`}
                      >
                        <td className="py-2.5 px-3 font-medium text-[#F4F1EA]">
                          {p.periodLabel}
                          <div className="text-[11px] font-mono text-[#A1A6B3]">{p.asOfDate}</div>
                        </td>
                        <td className="py-2.5 px-3">
                          {p.isFinalized ? (
                            <span className="inline-flex items-center gap-1 text-[#6CC4B5]">
                              <Lock className="w-3 h-3" /> Finalized
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-[#E3B469]">
                              <Unlock className="w-3 h-3" /> Open Draft
                            </span>
                          )}
                        </td>
                        <td className="py-2.5 px-3 font-mono text-right text-[#F4F1EA]">
                          {formatCurrency(p.actualCollections, deal.currency, true)} /{' '}
                          <span className="text-[#A1A6B3]">
                            {formatCurrency(p.projectedCollections, deal.currency, true)}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 font-mono text-right text-[#DF8787]">
                          {formatCurrency(p.actualDefaults, deal.currency, true)} /{' '}
                          <span className="text-[#A1A6B3]">
                            {formatCurrency(p.projectedDefaults, deal.currency, true)}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 font-mono text-right text-[#6CC4B5]">
                          {formatCurrency(p.actualRecoveries, deal.currency, true)}
                        </td>
                        <td className="py-2.5 px-3 font-mono text-right text-[#F4F1EA]">
                          {formatCurrency(p.endingPoolBalance, deal.currency, true)}
                        </td>
                        <td
                          className={`py-2.5 px-3 font-mono text-right font-semibold ${
                            ocFail ? 'text-[#DF8787]' : 'text-[#6CC4B5]'
                          }`}
                        >
                          {formatRatio(p.ocRatio)}
                        </td>
                        <td
                          className={`py-2.5 px-3 font-mono text-right font-semibold ${
                            icFail ? 'text-[#DF8787]' : 'text-[#6CC4B5]'
                          }`}
                        >
                          {formatRatio(p.icRatio)}
                        </td>
                        <td className="py-2.5 px-3 font-mono text-right">
                          {p.breaches.length > 0 ? (
                            <span className="text-[#DF8787] font-semibold">
                              {p.breaches.length} Active
                            </span>
                          ) : (
                            <span className="text-[#A1A6B3]">None</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Selected Period Detail Inspector */}
          {activePeriod && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Breaches, Substitutions & Frozen Forecast Snapshot */}
              <div className="lg:col-span-6 bg-[#141820] border border-white/10 rounded-lg p-6 space-y-5">
                <div className="flex items-center justify-between border-b border-white/10 pb-3">
                  <div>
                    <h3 className="text-base font-semibold text-[#F4F1EA]">
                      {activePeriod.periodLabel} — Governance & Breaches
                    </h3>
                    <div className="text-xs font-mono text-[#A1A6B3] mt-0.5">
                      Frozen Forecast: {activePeriod.forecastSnapshot.modelVersion} · Seed{' '}
                      {activePeriod.forecastSnapshot.seed} · PD Mult{' '}
                      {activePeriod.forecastSnapshot.assumedPdMultiplier}x
                    </div>
                  </div>
                  {!activePeriod.isFinalized && (
                    <button
                      type="button"
                      onClick={() => onFinalizePeriod(activePeriod.id)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-[#C8A253] text-[#0B0D10] rounded hover:bg-[#D9B76E]"
                    >
                      <Lock className="w-3.5 h-3.5" /> Finalize & Lock Period
                    </button>
                  )}
                </div>

                {activePeriod.breaches.length > 0 ? (
                  <div className="space-y-3">
                    {activePeriod.breaches.map((b) => (
                      <div
                        key={b.code}
                        className="bg-[#B85A5A]/15 border border-[#B85A5A]/50 rounded p-3.5 space-y-1 text-xs"
                      >
                        <div className="flex items-center justify-between font-semibold text-[#DF8787]">
                          <span className="inline-flex items-center gap-1.5">
                            <AlertTriangle className="w-3.5 h-3.5" /> {b.testName}
                          </span>
                          <span className="font-mono">
                            {formatRatio(b.observed)} &lt; {formatRatio(b.threshold)}
                          </span>
                        </div>
                        <p className="text-[#F4F1EA]">{b.actionTaken}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-xs text-[#6CC4B5] bg-[#3D9A8B]/10 border border-[#3D9A8B]/30 rounded p-3">
                    All contractual OC & IC coverage tests passed in {activePeriod.periodLabel}.
                  </div>
                )}

                <div className="space-y-2 pt-2 border-t border-white/10">
                  <div className="text-xs font-semibold text-[#F4F1EA]">
                    Collateral Substitutions ({activePeriod.substitutions.length})
                  </div>
                  {activePeriod.substitutions.length === 0 ? (
                    <p className="text-xs text-[#A1A6B3]">No substitutions executed in this period.</p>
                  ) : (
                    activePeriod.substitutions.map((s) => (
                      <div
                        key={s.id}
                        className="text-xs bg-[#0B0D10] border border-white/10 rounded p-3 space-y-1"
                      >
                        <div className="font-medium text-[#F4F1EA]">
                          Removed {s.removedAssetId} ({s.removedObligor}) → Added {s.addedAssetId} ({s.addedObligor})
                        </div>
                        <div className="text-[11px] font-mono text-[#A1A6B3]">
                          Notional Δ: {formatCurrency(s.notionalDelta, deal.currency)} · Approved by{' '}
                          {s.approvedBy}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Tranche Distribution Ledger */}
              <div className="lg:col-span-6 bg-[#141820] border border-white/10 rounded-lg overflow-hidden">
                <div className="px-5 py-3.5 border-b border-white/10 text-sm font-semibold text-[#F4F1EA]">
                  {activePeriod.periodLabel} — Actual Tranche Distributions
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="border-b border-white/10 text-[#A1A6B3] bg-[#101319]">
                        <th className="py-2.5 px-4">Tranche</th>
                        <th className="py-2.5 px-3 text-right">Interest Paid</th>
                        <th className="py-2.5 px-3 text-right">Principal Paid</th>
                        <th className="py-2.5 px-4 text-right">Ending Balance</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {activePeriod.trancheDistributions.map((td) => (
                        <tr key={td.code} className="hover:bg-white/[0.02]">
                          <td className="py-2.5 px-4 font-medium text-[#F4F1EA]">{td.code}</td>
                          <td className="py-2.5 px-3 font-mono text-right text-[#6CC4B5]">
                            {formatCurrency(td.interestPaid, deal.currency)}
                          </td>
                          <td className="py-2.5 px-3 font-mono text-right text-[#84B3E0]">
                            {formatCurrency(td.principalPaid, deal.currency)}
                          </td>
                          <td className="py-2.5 px-4 font-mono text-right text-[#F4F1EA]">
                            {formatCurrency(td.endingBalance, deal.currency)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
