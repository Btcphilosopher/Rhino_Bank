import React, { useState } from 'react';
import {
  ArrowRight,
  CheckCircle2,
  FilePlus2,
  ShieldCheck,
  XCircle,
} from 'lucide-react';
import type {
  ApprovalRequestRecord,
  AssetClass,
  DealRecord,
  StructureType,
} from '../../engine/types.ts';
import { ASSET_CLASS_LABELS, formatBps, formatCurrency, formatRatio } from '../../lib/format.ts';

interface DealsViewProps {
  deals: DealRecord[];
  activeDealId: string;
  onSelectDeal: (dealId: string) => void;
  onCreateDeal: (input: {
    name: string;
    code: string;
    assetClass: AssetClass;
    structureType: StructureType;
    targetPoolNotional: number;
    reinvestmentPeriods: number;
    maturityPeriods: number;
    ocTriggerRatio: number;
    icTriggerRatio: number;
  }) => void;
  onNavigateSection: (section: string) => void;
  approvals: ApprovalRequestRecord[];
  userRole: 'analyst' | 'structurer' | 'checker' | 'admin';
  currentUserEmail: string;
  onSubmitApproval: (actionType: ApprovalRequestRecord['actionType'], summary: string) => void;
  onDecideApproval: (approvalId: string, decision: 'approved' | 'rejected', note: string) => void;
}

export function DealsView({
  deals,
  activeDealId,
  onSelectDeal,
  onCreateDeal,
  onNavigateSection,
  approvals,
  userRole,
  currentUserEmail,
  onSubmitApproval,
  onDecideApproval,
}: DealsViewProps) {
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [assetClass, setAssetClass] = useState<AssetClass>('semiconductor');
  const [structureType, setStructureType] = useState<StructureType>('cash');
  const [targetPoolNotional, setTargetPoolNotional] = useState(100000000);
  const [reinvestmentPeriods, setReinvestmentPeriods] = useState(6);
  const [maturityPeriods, setMaturityPeriods] = useState(20);
  const [ocTriggerRatio, setOcTriggerRatio] = useState(1.16);
  const [icTriggerRatio, setIcTriggerRatio] = useState(1.25);

  const [approvalSummary, setApprovalSummary] = useState('');
  const [approvalType, setApprovalType] =
    useState<ApprovalRequestRecord['actionType']>('structure_update');
  const [decisionNotes, setDecisionNotes] = useState<Record<string, string>>({});

  const activeDeal = deals.find((d) => d.id === activeDealId) ?? deals[0];

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !code.trim()) return;
    onCreateDeal({
      name: name.trim(),
      code: code.trim().toUpperCase(),
      assetClass,
      structureType,
      targetPoolNotional,
      reinvestmentPeriods,
      maturityPeriods,
      ocTriggerRatio,
      icTriggerRatio,
    });
    setName('');
    setCode('');
    setShowCreateForm(false);
  };

  return (
    <div className="space-y-8">
      {/* Header Row */}
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-white/10 pb-5">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-[#F4F1EA]">
            Transaction Origination & Deal Registry
          </h1>
          <p className="mt-1 text-sm text-[#A1A6B3] max-w-2xl">
            Configure asset-class CDO vehicles across Cash and Synthetic structures, manage versioned deal terms, and enforce Maker-Checker sign-off.
          </p>
        </div>
        <button
          type="button"
          onClick={() => setShowCreateForm((v) => !v)}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold bg-[#C8A253] text-[#0B0D10] rounded hover:bg-[#D9B76E] transition-colors whitespace-nowrap shrink-0"
        >
          <FilePlus2 className="w-4 h-4" />
          {showCreateForm ? 'Close Deal Builder' : 'New Transaction'}
        </button>
      </div>

      {/* New Deal Drawer */}
      {showCreateForm && (
        <form
          onSubmit={handleCreate}
          className="bg-[#141820] border border-[#C8A253]/40 rounded-lg p-6 space-y-5"
        >
          <div className="flex items-center justify-between">
            <h2 className="text-base font-semibold text-[#F4F1EA]">Configure New CDO Transaction</h2>
            <span className="text-xs text-[#A1A6B3]">Initializes Base Tranches & Contractual Waterfall</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <label className="space-y-1.5 text-xs">
              <span className="text-[#A1A6B3] block">Transaction Name</span>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Pacific Fab Equipment Trust 2026-2"
                className="w-full bg-[#0B0D10] border border-white/15 rounded px-3 py-2 text-sm text-[#F4F1EA] focus:outline-none focus:border-[#C8A253]"
              />
            </label>
            <label className="space-y-1.5 text-xs">
              <span className="text-[#A1A6B3] block">Deal Ticker / Code</span>
              <input
                type="text"
                required
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="e.g. PFET-2026-2"
                className="w-full bg-[#0B0D10] border border-white/15 rounded px-3 py-2 text-sm font-mono text-[#F4F1EA] focus:outline-none focus:border-[#C8A253]"
              />
            </label>
            <label className="space-y-1.5 text-xs">
              <span className="text-[#A1A6B3] block">Asset Class</span>
              <select
                value={assetClass}
                onChange={(e) => setAssetClass(e.target.value as AssetClass)}
                className="w-full bg-[#0B0D10] border border-white/15 rounded px-3 py-2 text-sm text-[#F4F1EA] focus:outline-none focus:border-[#C8A253]"
              >
                <option value="semiconductor">Semiconductor Financing</option>
                <option value="corporate_debt">Corporate Debt</option>
                <option value="equipment_finance">Equipment Finance</option>
              </select>
            </label>
            <label className="space-y-1.5 text-xs">
              <span className="text-[#A1A6B3] block">Vehicle Structure Type</span>
              <select
                value={structureType}
                onChange={(e) => setStructureType(e.target.value as StructureType)}
                className="w-full bg-[#0B0D10] border border-white/15 rounded px-3 py-2 text-sm text-[#F4F1EA] focus:outline-none focus:border-[#C8A253]"
              >
                <option value="cash">Cash CDO (Asset-Backed SPV)</option>
                <option value="synthetic">Synthetic CDO (CLN + Protection Swap)</option>
              </select>
            </label>
            <label className="space-y-1.5 text-xs">
              <span className="text-[#A1A6B3] block">Target Pool Notional (USD)</span>
              <input
                type="number"
                min={1000000}
                step={1000000}
                value={targetPoolNotional}
                onChange={(e) => setTargetPoolNotional(Number(e.target.value))}
                className="w-full bg-[#0B0D10] border border-white/15 rounded px-3 py-2 text-sm font-mono text-[#F4F1EA] focus:outline-none focus:border-[#C8A253]"
              />
            </label>
            <div className="grid grid-cols-2 gap-3">
              <label className="space-y-1.5 text-xs">
                <span className="text-[#A1A6B3] block">Reinvest (Q)</span>
                <input
                  type="number"
                  min={0}
                  max={24}
                  value={reinvestmentPeriods}
                  onChange={(e) => setReinvestmentPeriods(Number(e.target.value))}
                  className="w-full bg-[#0B0D10] border border-white/15 rounded px-3 py-2 text-sm font-mono text-[#F4F1EA] focus:outline-none focus:border-[#C8A253]"
                />
              </label>
              <label className="space-y-1.5 text-xs">
                <span className="text-[#A1A6B3] block">Maturity (Q)</span>
                <input
                  type="number"
                  min={4}
                  max={60}
                  value={maturityPeriods}
                  onChange={(e) => setMaturityPeriods(Number(e.target.value))}
                  className="w-full bg-[#0B0D10] border border-white/15 rounded px-3 py-2 text-sm font-mono text-[#F4F1EA] focus:outline-none focus:border-[#C8A253]"
                />
              </label>
            </div>
            <label className="space-y-1.5 text-xs">
              <span className="text-[#A1A6B3] block">OC Trigger Ratio</span>
              <input
                type="number"
                step={0.01}
                min={1.0}
                max={2.0}
                value={ocTriggerRatio}
                onChange={(e) => setOcTriggerRatio(Number(e.target.value))}
                className="w-full bg-[#0B0D10] border border-white/15 rounded px-3 py-2 text-sm font-mono text-[#F4F1EA] focus:outline-none focus:border-[#C8A253]"
              />
            </label>
            <label className="space-y-1.5 text-xs">
              <span className="text-[#A1A6B3] block">IC Trigger Ratio</span>
              <input
                type="number"
                step={0.01}
                min={1.0}
                max={2.5}
                value={icTriggerRatio}
                onChange={(e) => setIcTriggerRatio(Number(e.target.value))}
                className="w-full bg-[#0B0D10] border border-white/15 rounded px-3 py-2 text-sm font-mono text-[#F4F1EA] focus:outline-none focus:border-[#C8A253]"
              />
            </label>
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => setShowCreateForm(false)}
              className="px-4 py-2 text-xs text-[#A1A6B3] hover:text-[#F4F1EA] border border-white/10 rounded"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-semibold bg-[#C8A253] text-[#0B0D10] rounded hover:bg-[#D9B76E]"
            >
              Create Deal & Seed Tape
            </button>
          </div>
        </form>
      )}

      {/* Active Deal Summary Strip */}
      {activeDeal && (
        <div className="bg-[#141820] border border-white/10 rounded-lg p-6">
          <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-white/10">
            <div>
              <div className="text-xs text-[#A1A6B3] flex items-center gap-2">
                <span className="font-mono text-[#C8A253]">{activeDeal.code}</span>
                <span>·</span>
                <span>{ASSET_CLASS_LABELS[activeDeal.assetClass]}</span>
                <span>·</span>
                <span>{activeDeal.structureType === 'cash' ? 'Cash CDO' : 'Synthetic CDO'}</span>
                <span>·</span>
                <span>v{activeDeal.version}</span>
              </div>
              <h2 className="text-xl font-semibold text-[#F4F1EA] mt-1">{activeDeal.name}</h2>
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => onNavigateSection('Collateral')}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-[#1C222D] text-[#F4F1EA] border border-white/10 rounded hover:border-[#C8A253]/60 transition-colors"
              >
                Inspect Collateral <ArrowRight className="w-3.5 h-3.5 text-[#C8A253]" />
              </button>
              <button
                type="button"
                onClick={() => onNavigateSection('Structure')}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-[#1C222D] text-[#F4F1EA] border border-white/10 rounded hover:border-[#C8A253]/60 transition-colors"
              >
                Edit Capital Stack <ArrowRight className="w-3.5 h-3.5 text-[#C8A253]" />
              </button>
              <button
                type="button"
                onClick={() => onNavigateSection('Valuation')}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-[#C8A253] text-[#0B0D10] rounded hover:bg-[#D9B76E] transition-colors"
              >
                Run Quantitative Engine
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-6 gap-6 pt-5">
            <div>
              <div className="text-xs text-[#A1A6B3]">Target Notional</div>
              <div className="text-lg font-mono font-semibold text-[#F4F1EA] mt-0.5">
                {formatCurrency(activeDeal.targetPoolNotional, activeDeal.currency, true)}
              </div>
            </div>
            <div>
              <div className="text-xs text-[#A1A6B3]">Reinvest / Maturity</div>
              <div className="text-lg font-mono font-semibold text-[#F4F1EA] mt-0.5">
                {activeDeal.reinvestmentPeriods}Q / {activeDeal.maturityPeriods}Q
              </div>
            </div>
            <div>
              <div className="text-xs text-[#A1A6B3]">Cash Reserve Target</div>
              <div className="text-lg font-mono font-semibold text-[#F4F1EA] mt-0.5">
                {formatCurrency(activeDeal.reserveTarget, activeDeal.currency, true)}
              </div>
            </div>
            <div>
              <div className="text-xs text-[#A1A6B3]">Senior Mgmt Fee</div>
              <div className="text-lg font-mono font-semibold text-[#F4F1EA] mt-0.5">
                {formatBps(activeDeal.annualSeniorFeeBps)}
              </div>
            </div>
            <div>
              <div className="text-xs text-[#A1A6B3]">OC Coverage Trigger</div>
              <div className="text-lg font-mono font-semibold text-[#F4F1EA] mt-0.5">
                {formatRatio(activeDeal.ocTriggerRatio, 2)}
              </div>
            </div>
            <div>
              <div className="text-xs text-[#A1A6B3]">IC Coverage Trigger</div>
              <div className="text-lg font-mono font-semibold text-[#F4F1EA] mt-0.5">
                {formatRatio(activeDeal.icTriggerRatio, 2)}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Portfolio Deal Table */}
      <div className="bg-[#141820] border border-white/10 rounded-lg overflow-hidden">
        <div className="px-6 py-4 border-b border-white/10 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-[#F4F1EA]">Configured Transactions</h3>
          <span className="text-xs text-[#A1A6B3] font-mono">{deals.length} active deals</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-white/10 text-xs text-[#A1A6B3] bg-[#101319]">
                <th className="py-3 px-4 font-medium">Deal Code</th>
                <th className="py-3 px-4 font-medium">Transaction Name</th>
                <th className="py-3 px-4 font-medium">Asset Class</th>
                <th className="py-3 px-4 font-medium">Vehicle Type</th>
                <th className="py-3 px-4 font-medium text-right">Notional</th>
                <th className="py-3 px-4 font-medium text-right">OC / IC Trigger</th>
                <th className="py-3 px-4 font-medium">Status</th>
                <th className="py-3 px-4 font-medium text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-sm">
              {deals.map((d) => {
                const isSelected = d.id === activeDealId;
                return (
                  <tr
                    key={d.id}
                    className={`transition-colors ${
                      isSelected ? 'bg-[#C8A253]/10' : 'hover:bg-white/[0.02]'
                    }`}
                  >
                    <td className="py-3 px-4 font-mono text-xs text-[#C8A253] font-medium">
                      {d.code}
                    </td>
                    <td className="py-3 px-4 font-medium text-[#F4F1EA]">{d.name}</td>
                    <td className="py-3 px-4 text-xs text-[#D2CFC7]">
                      {ASSET_CLASS_LABELS[d.assetClass]}
                    </td>
                    <td className="py-3 px-4 text-xs">
                      {d.structureType === 'cash' ? 'Cash CDO' : 'Synthetic CDO (CLN + CDS)'}
                    </td>
                    <td className="py-3 px-4 font-mono text-right text-[#F4F1EA]">
                      {formatCurrency(d.targetPoolNotional, d.currency)}
                    </td>
                    <td className="py-3 px-4 font-mono text-right text-xs text-[#D2CFC7]">
                      {formatRatio(d.ocTriggerRatio, 2)} / {formatRatio(d.icTriggerRatio, 2)}
                    </td>
                    <td className="py-3 px-4 text-xs capitalize text-[#D2CFC7]">{d.status}</td>
                    <td className="py-3 px-4 text-right">
                      <button
                        type="button"
                        onClick={() => onSelectDeal(d.id)}
                        className={`px-3 py-1 text-xs rounded transition-colors ${
                          isSelected
                            ? 'bg-[#C8A253] text-[#0B0D10] font-semibold'
                            : 'border border-white/15 text-[#F4F1EA] hover:border-[#C8A253]'
                        }`}
                      >
                        {isSelected ? 'Active Workspace' : 'Open Deal'}
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Maker-Checker Governance Ledger */}
      <div className="bg-[#141820] border border-white/10 rounded-lg p-6 space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/10 pb-4">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-5 h-5 text-[#C8A253]" />
            <div>
              <h3 className="text-base font-semibold text-[#F4F1EA]">
                Maker-Checker Material Change Governance
              </h3>
              <p className="text-xs text-[#A1A6B3]">
                Signed-in role: <span className="text-[#F4F1EA] font-medium capitalize">{userRole}</span> ({currentUserEmail}) · Makers cannot self-approve unless Admin override is enforced.
              </p>
            </div>
          </div>
        </div>

        {/* Submit Approval Form */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (!approvalSummary.trim()) return;
            onSubmitApproval(approvalType, approvalSummary.trim());
            setApprovalSummary('');
          }}
          className="grid grid-cols-1 md:grid-cols-12 gap-3 items-end"
        >
          <label className="md:col-span-3 space-y-1 text-xs">
            <span className="text-[#A1A6B3] block">Material Change Category</span>
            <select
              value={approvalType}
              onChange={(e) =>
                setApprovalType(e.target.value as ApprovalRequestRecord['actionType'])
              }
              className="w-full bg-[#0B0D10] border border-white/15 rounded px-3 py-2 text-xs text-[#F4F1EA]"
            >
              <option value="structure_update">Capital Structure Modification</option>
              <option value="waterfall_update">Waterfall Priority Revision</option>
              <option value="collateral_substitution">Collateral Substitution</option>
              <option value="period_finalization">Surveillance Period Lock</option>
              <option value="deal_activation">Deal Activation Sign-Off</option>
            </select>
          </label>
          <label className="md:col-span-7 space-y-1 text-xs">
            <span className="text-[#A1A6B3] block">Change Summary for Checker Review</span>
            <input
              type="text"
              value={approvalSummary}
              onChange={(e) => setApprovalSummary(e.target.value)}
              placeholder="Describe structural, waterfall, or collateral change requiring four-eyes approval..."
              className="w-full bg-[#0B0D10] border border-white/15 rounded px-3 py-2 text-xs text-[#F4F1EA]"
            />
          </label>
          <button
            type="submit"
            className="md:col-span-2 px-4 py-2 text-xs font-semibold bg-[#1E2530] border border-[#C8A253]/50 text-[#F4F1EA] rounded hover:bg-[#C8A253] hover:text-[#0B0D10] transition-colors"
          >
            Submit for Review
          </button>
        </form>

        {/* Approval Records Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-white/10 text-[#A1A6B3]">
                <th className="py-2.5 px-3 font-medium">Action</th>
                <th className="py-2.5 px-3 font-medium">Summary</th>
                <th className="py-2.5 px-3 font-medium">Maker</th>
                <th className="py-2.5 px-3 font-medium">Status</th>
                <th className="py-2.5 px-3 font-medium text-right">Checker Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {approvals.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-6 text-center text-[#A1A6B3]">
                    No pending or historical governance requests for this deal.
                  </td>
                </tr>
              ) : (
                approvals.map((ap) => (
                  <tr key={ap.id} className="hover:bg-white/[0.02]">
                    <td className="py-3 px-3 font-mono text-[#D2CFC7]">{ap.actionType}</td>
                    <td className="py-3 px-3 text-[#F4F1EA] max-w-md">{ap.summary}</td>
                    <td className="py-3 px-3 text-[#A1A6B3]">{ap.makerEmail}</td>
                    <td className="py-3 px-3">
                      <span
                        className={
                          ap.status === 'approved'
                            ? 'text-[#6CC4B5] font-medium'
                            : ap.status === 'rejected'
                            ? 'text-[#DF8787] font-medium'
                            : 'text-[#E3B469] font-medium'
                        }
                      >
                        {ap.status === 'approved'
                          ? 'Approved'
                          : ap.status === 'rejected'
                          ? 'Rejected'
                          : 'Pending Checker'}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right">
                      {ap.status === 'pending' ? (
                        <div className="inline-flex items-center gap-2">
                          <input
                            type="text"
                            placeholder="Decision note..."
                            value={decisionNotes[ap.id] ?? ''}
                            onChange={(e) =>
                              setDecisionNotes((prev) => ({ ...prev, [ap.id]: e.target.value }))
                            }
                            className="bg-[#0B0D10] border border-white/15 rounded px-2 py-1 text-xs w-36 text-[#F4F1EA]"
                          />
                          <button
                            type="button"
                            onClick={() =>
                              onDecideApproval(
                                ap.id,
                                'approved',
                                decisionNotes[ap.id] || 'Verified by Checker'
                              )
                            }
                            className="inline-flex items-center gap-1 px-2.5 py-1 bg-[#3D9A8B]/20 border border-[#3D9A8B]/50 text-[#6CC4B5] rounded hover:bg-[#3D9A8B]/30"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" /> Approve
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              onDecideApproval(
                                ap.id,
                                'rejected',
                                decisionNotes[ap.id] || 'Returned for revision'
                              )
                            }
                            className="inline-flex items-center gap-1 px-2.5 py-1 bg-[#B85A5A]/20 border border-[#B85A5A]/50 text-[#DF8787] rounded hover:bg-[#B85A5A]/30"
                          >
                            <XCircle className="w-3.5 h-3.5" /> Reject
                          </button>
                        </div>
                      ) : (
                        <span className="text-[#A1A6B3]">
                          {ap.checkerEmail ?? 'Checker'} · {ap.decisionNote}
                        </span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
