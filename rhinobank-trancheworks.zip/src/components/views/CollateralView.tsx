import React, { useMemo, useState } from 'react';
import { AlertTriangle, CheckCircle2, Download, Search, Upload } from 'lucide-react';
import {
  computePoolAnalytics,
  parseCollateralImport,
  serializeAssetsToCsv,
} from '../../engine/collateral.ts';
import type {
  CollateralAsset,
  CollateralTape,
  CollateralValidationResult,
  ConcentrationBucket,
  DealRecord,
} from '../../engine/types.ts';
import { formatBps, formatCurrency, formatPct } from '../../lib/format.ts';

interface CollateralViewProps {
  deal: DealRecord;
  tapes: CollateralTape[];
  activeTape: CollateralTape;
  onSelectTapeVersion: (tapeId: string) => void;
  onCommitNewTape: (
    assets: CollateralAsset[],
    sourceFormat: 'csv' | 'json',
    sourceFileName: string
  ) => void;
}

export function CollateralView({
  deal,
  tapes,
  activeTape,
  onSelectTapeVersion,
  onCommitNewTape,
}: CollateralViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [sectorFilter, setSectorFilter] = useState('all');
  const [concentrationTab, setConcentrationTab] = useState<
    'economicGroup' | 'sector' | 'geography' | 'maturity' | 'sharedDependency'
  >('economicGroup');

  const [showImporter, setShowImporter] = useState(false);
  const [importFormat, setImportFormat] = useState<'csv' | 'json'>('csv');
  const [importText, setImportText] = useState('');
  const [importFileName, setImportFileName] = useState('custom_tape_import.csv');
  const [validationResult, setValidationResult] = useState<CollateralValidationResult | null>(null);

  const analytics = useMemo(() => computePoolAnalytics(activeTape.assets), [activeTape.assets]);

  const sectors = useMemo(
    () => ['all', ...Array.from(new Set(activeTape.assets.map((a) => a.sector)))],
    [activeTape.assets]
  );

  const filteredAssets = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return activeTape.assets.filter((a) => {
      if (sectorFilter !== 'all' && a.sector !== sectorFilter) return false;
      if (!q) return true;
      return (
        a.assetId.toLowerCase().includes(q) ||
        a.obligorName.toLowerCase().includes(q) ||
        a.economicGroup.toLowerCase().includes(q) ||
        a.sharedDependency.toLowerCase().includes(q) ||
        a.geography.toLowerCase().includes(q) ||
        a.sector.toLowerCase().includes(q)
      );
    });
  }, [activeTape.assets, searchQuery, sectorFilter]);

  const concentrationRows: ConcentrationBucket[] = useMemo(() => {
    switch (concentrationTab) {
      case 'economicGroup':
        return analytics.byEconomicGroup;
      case 'sector':
        return analytics.bySector;
      case 'geography':
        return analytics.byGeography;
      case 'maturity':
        return analytics.byMaturityBucket;
      case 'sharedDependency':
        return analytics.bySharedDependency;
    }
  }, [analytics, concentrationTab]);

  const handleLoadSampleWithErrors = () => {
    const sample = activeTape.assets.slice(0, 4).map((a) => ({ ...a }));
    // Inject deliberate validation errors to demonstrate validation gate
    sample[1].assetId = sample[0].assetId; // duplicate ID
    sample[2].currency = 'EUR'; // unit mismatch
    sample[3].originationDate = '2030-05-01';
    sample[3].maturityDate = '2026-01-01'; // inconsistent dates
    setImportFormat('json');
    setImportFileName('error_demonstration_tape.json');
    const json = JSON.stringify(sample, null, 2);
    setImportText(json);
    setValidationResult(parseCollateralImport(json, 'json', deal.currency));
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImportFileName(file.name);
    const fmt = file.name.toLowerCase().endsWith('.json') ? 'json' : 'csv';
    setImportFormat(fmt);
    const reader = new FileReader();
    reader.onload = () => {
      const content = String(reader.result ?? '');
      setImportText(content);
      try {
        setValidationResult(parseCollateralImport(content, fmt, deal.currency));
      } catch (err) {
        setValidationResult({
          valid: false,
          errorCount: 1,
          warningCount: 0,
          issues: [
            {
              rowIndex: 0,
              assetId: 'PARSE',
              field: 'file',
              severity: 'error',
              message: err instanceof Error ? err.message : 'Unable to parse file.',
            },
          ],
          assets: [],
          analytics: computePoolAnalytics([]),
        });
      }
    };
    reader.readAsText(file);
  };

  const handleDownloadCsv = () => {
    const csv = serializeAssetsToCsv(activeTape.assets);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${deal.code}_tape_v${activeTape.versionNumber}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleUpdateAssetAssumption = (
    assetId: string,
    field: 'assumedAnnualPd' | 'assumedRecoveryRate' | 'assumedPrepaymentCpr',
    value: number
  ) => {
    const updated = activeTape.assets.map((a) =>
      a.assetId === assetId ? { ...a, [field]: value } : a
    );
    onCommitNewTape(updated, 'json', `assumption_override_v${activeTape.versionNumber + 1}.json`);
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-white/10 pb-5">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-[#F4F1EA]">
            Collateral Pool Manager & Tape Validation
          </h1>
          <p className="mt-1 text-sm text-[#A1A6B3]">
            {deal.structureType === 'synthetic'
              ? 'Reference Portfolio Obligations (credit risk transferred via CDS/CLN; NOT assets owned by the SPV).'
              : 'SPV Collateral Portfolio with strict separation between observed contractual terms and model assumptions.'}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <select
            aria-label="Select Collateral Tape Version"
            value={activeTape.id}
            onChange={(e) => onSelectTapeVersion(e.target.value)}
            className="bg-[#141820] border border-white/15 rounded px-3 py-2 text-xs font-mono text-[#F4F1EA]"
          >
            {tapes.map((t) => (
              <option key={t.id} value={t.id}>
                v{t.versionNumber} · {t.sourceFileName} ({t.assetCount} assets)
              </option>
            ))}
          </select>
          <button
            type="button"
            onClick={handleDownloadCsv}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium bg-[#141820] border border-white/15 text-[#F4F1EA] rounded hover:border-[#C8A253]"
          >
            <Download className="w-3.5 h-3.5" /> Export CSV
          </button>
          <button
            type="button"
            onClick={() => setShowImporter((v) => !v)}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold bg-[#C8A253] text-[#0B0D10] rounded hover:bg-[#D9B76E]"
          >
            <Upload className="w-3.5 h-3.5" /> {showImporter ? 'Close Importer' : 'Import CSV / JSON'}
          </button>
        </div>
      </div>

      {/* Importer & Validator Panel */}
      {showImporter && (
        <div className="bg-[#141820] border border-[#C8A253]/40 rounded-lg p-6 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-semibold text-[#F4F1EA]">
                Collateral Tape Ingestion & Validation Gate
              </h2>
              <p className="text-xs text-[#A1A6B3]">
                Validates currency units, duplicate Asset IDs, missing fields, date ordering, and assumption bounds before creating a new immutable tape version.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleLoadSampleWithErrors}
                className="px-3 py-1.5 text-xs bg-[#1C222D] border border-white/15 rounded text-[#E3B469] hover:border-[#E3B469]"
              >
                Load Invalid Test Sample
              </button>
              <label className="px-3 py-1.5 text-xs bg-[#1C222D] border border-white/15 rounded text-[#F4F1EA] cursor-pointer hover:border-[#C8A253]">
                Upload File
                <input
                  type="file"
                  accept=".csv,.json"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <label className="text-xs space-y-1">
              <span className="text-[#A1A6B3] block">Format</span>
              <select
                value={importFormat}
                onChange={(e) => setImportFormat(e.target.value as 'csv' | 'json')}
                className="w-full bg-[#0B0D10] border border-white/15 rounded px-3 py-2 text-xs text-[#F4F1EA]"
              >
                <option value="csv">CSV (Comma-Separated)</option>
                <option value="json">Structured JSON</option>
              </select>
            </label>
            <label className="md:col-span-2 text-xs space-y-1">
              <span className="text-[#A1A6B3] block">Preserved Source Filename</span>
              <input
                type="text"
                value={importFileName}
                onChange={(e) => setImportFileName(e.target.value)}
                className="w-full bg-[#0B0D10] border border-white/15 rounded px-3 py-2 text-xs font-mono text-[#F4F1EA]"
              />
            </label>
          </div>

          <textarea
            rows={6}
            value={importText}
            onChange={(e) => setImportText(e.target.value)}
            placeholder="Paste CSV or structured JSON collateral records here..."
            className="w-full bg-[#0B0D10] border border-white/15 rounded p-3 text-xs font-mono text-[#F4F1EA] focus:outline-none focus:border-[#C8A253]"
          />

          <div className="flex flex-wrap items-center justify-between gap-3">
            <button
              type="button"
              onClick={() => {
                try {
                  setValidationResult(parseCollateralImport(importText, importFormat, deal.currency));
                } catch (err) {
                  setValidationResult({
                    valid: false,
                    errorCount: 1,
                    warningCount: 0,
                    issues: [
                      {
                        rowIndex: 0,
                        assetId: 'SYNTAX',
                        field: 'payload',
                        severity: 'error',
                        message: err instanceof Error ? err.message : 'Syntax error.',
                      },
                    ],
                    assets: [],
                    analytics: computePoolAnalytics([]),
                  });
                }
              }}
              className="px-4 py-2 text-xs font-semibold bg-[#1E2530] border border-white/15 text-[#F4F1EA] rounded hover:border-[#C8A253]"
            >
              Validate Tape
            </button>

            {validationResult?.valid && (
              <button
                type="button"
                onClick={() => {
                  onCommitNewTape(validationResult.assets, importFormat, importFileName);
                  setShowImporter(false);
                }}
                className="px-4 py-2 text-xs font-semibold bg-[#3D9A8B] text-[#0B0D10] rounded hover:bg-[#53B8A7]"
              >
                Commit Immutable Tape v{tapes.length + 1} ({validationResult.assets.length} Assets)
              </button>
            )}
          </div>

          {validationResult && (
            <div className="bg-[#0B0D10] border border-white/10 rounded p-4 space-y-3">
              <div className="flex items-center gap-2 text-xs font-medium">
                {validationResult.valid ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-[#6CC4B5]" />
                    <span className="text-[#6CC4B5]">
                      Validation Passed: {validationResult.assets.length} records totaling{' '}
                      {formatCurrency(validationResult.analytics.totalPrincipal, deal.currency)}
                    </span>
                  </>
                ) : (
                  <>
                    <AlertTriangle className="w-4 h-4 text-[#DF8787]" />
                    <span className="text-[#DF8787]">
                      Validation Failed: {validationResult.errorCount} errors,{' '}
                      {validationResult.warningCount} warnings
                    </span>
                  </>
                )}
              </div>
              {validationResult.issues.length > 0 && (
                <ul className="space-y-1.5 text-xs font-mono max-h-40 overflow-y-auto">
                  {validationResult.issues.map((iss, idx) => (
                    <li
                      key={idx}
                      className={iss.severity === 'error' ? 'text-[#DF8787]' : 'text-[#E3B469]'}
                    >
                      Row {iss.rowIndex} [{iss.assetId}] ({iss.field}): {iss.message}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}
        </div>
      )}

      {/* Pool KPI Strip */}
      <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
        <div className="bg-[#141820] border border-white/10 rounded-lg p-4">
          <div className="text-xs text-[#A1A6B3]">
            {deal.structureType === 'synthetic' ? 'Reference Notional' : 'Observed Pool Principal'}
          </div>
          <div className="text-xl font-mono font-semibold text-[#F4F1EA] mt-1">
            {formatCurrency(analytics.totalPrincipal, deal.currency, true)}
          </div>
        </div>
        <div className="bg-[#141820] border border-white/10 rounded-lg p-4">
          <div className="text-xs text-[#A1A6B3]">Assets / Economic Groups</div>
          <div className="text-xl font-mono font-semibold text-[#F4F1EA] mt-1">
            {analytics.assetCount} / {analytics.uniqueEconomicGroups}
          </div>
        </div>
        <div className="bg-[#141820] border border-white/10 rounded-lg p-4">
          <div className="text-xs text-[#A1A6B3]">Observed WA All-In Coupon</div>
          <div className="text-xl font-mono font-semibold text-[#F4F1EA] mt-1">
            {formatBps(analytics.weightedAvgCouponBps)}
          </div>
        </div>
        <div className="bg-[#141820] border border-white/10 rounded-lg p-4">
          <div className="text-xs text-[#A1A6B3]">Observed WA Maturity</div>
          <div className="text-xl font-mono font-semibold text-[#F4F1EA] mt-1">
            {(analytics.weightedAvgMaturityPeriods / 4).toFixed(2)} Yrs
          </div>
        </div>
        <div className="bg-[#141820] border border-white/10 rounded-lg p-4">
          <div className="text-xs text-[#A1A6B3]">Assumed WA Annual PD</div>
          <div className="text-xl font-mono font-semibold text-[#E3B469] mt-1">
            {formatPct(analytics.weightedAvgAssumedPd * 100)}
          </div>
        </div>
        <div className="bg-[#141820] border border-white/10 rounded-lg p-4">
          <div className="text-xs text-[#A1A6B3]">Assumed WA Recovery</div>
          <div className="text-xl font-mono font-semibold text-[#6CC4B5] mt-1">
            {formatPct(analytics.weightedAvgAssumedRecovery * 100)}
          </div>
        </div>
      </div>

      {/* Concentration Breakdown */}
      <div className="bg-[#141820] border border-white/10 rounded-lg p-6 space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-semibold text-[#F4F1EA]">
              Portfolio Concentration & Shared Dependency Analysis
            </h3>
            <p className="text-xs text-[#A1A6B3]">
              Roll-up by economic obligor group, sector, geography, maturity horizon, and shared supply-chain customer dependencies.
            </p>
          </div>
          <div className="flex flex-wrap gap-1 bg-[#0B0D10] p-1 rounded border border-white/10">
            {[
              { id: 'economicGroup', label: 'Economic Obligor' },
              { id: 'sector', label: 'Sector' },
              { id: 'geography', label: 'Geography' },
              { id: 'maturity', label: 'Maturity' },
              { id: 'sharedDependency', label: 'Shared Dependency' },
            ].map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setConcentrationTab(tab.id as typeof concentrationTab)}
                className={`px-3 py-1.5 text-xs rounded transition-colors whitespace-nowrap shrink-0 ${
                  concentrationTab === tab.id
                    ? 'bg-[#C8A253] text-[#0B0D10] font-semibold'
                    : 'text-[#A1A6B3] hover:text-[#F4F1EA]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-3">
          {concentrationRows.slice(0, 10).map((row) => (
            <div key={row.label} className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-[#F4F1EA] font-medium truncate max-w-[240px]">
                  {row.label}
                </span>
                <span className="font-mono text-[#D2CFC7]">
                  {formatCurrency(row.principal, deal.currency, true)} · {formatPct(row.sharePct, 1)} ·{' '}
                  <span className="text-[#A1A6B3]">{row.assetCount} assets</span>
                </span>
              </div>
              <div className="w-full h-2 bg-[#0B0D10] rounded overflow-hidden">
                <div
                  className="h-full bg-[#C8A253]"
                  style={{ width: `${Math.min(100, row.sharePct * 2.5)}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Dense Searchable Asset Tape (Observed vs Assumptions explicitly grouped) */}
      <div className="bg-[#141820] border border-white/10 rounded-lg overflow-hidden">
        <div className="p-4 border-b border-white/10 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3 flex-1 min-w-[260px]">
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-[#A1A6B3] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search asset ID, obligor, economic group, dependency..."
                className="w-full bg-[#0B0D10] border border-white/15 rounded pl-9 pr-3 py-1.5 text-xs text-[#F4F1EA] focus:outline-none focus:border-[#C8A253]"
              />
            </div>
            <select
              value={sectorFilter}
              onChange={(e) => setSectorFilter(e.target.value)}
              className="bg-[#0B0D10] border border-white/15 rounded px-3 py-1.5 text-xs text-[#F4F1EA]"
            >
              {sectors.map((s) => (
                <option key={s} value={s}>
                  {s === 'all' ? 'All Sectors' : s}
                </option>
              ))}
            </select>
          </div>
          <div className="text-xs text-[#A1A6B3] font-mono">
            Showing {filteredAssets.length} of {activeTape.assets.length} records · Blue header = Observed Contractual · Gold header = Model Assumptions
          </div>
        </div>

        <div className="overflow-x-auto max-h-[520px]">
          <table className="w-full text-left border-collapse text-xs">
            <thead className="sticky top-0 bg-[#101319] z-10 border-b border-white/10">
              <tr>
                <th colSpan={7} className="py-1.5 px-3 text-[11px] font-semibold text-[#84B3E0] border-r border-white/10 bg-[#4B83B8]/10">
                  Observed Contractual Terms
                </th>
                <th colSpan={4} className="py-1.5 px-3 text-[11px] font-semibold text-[#E3B469] bg-[#C8A253]/10">
                  Explicit Model Assumptions (Editable)
                </th>
              </tr>
              <tr className="border-b border-white/10 text-[#A1A6B3]">
                <th className="py-2.5 px-3 font-medium">Asset ID</th>
                <th className="py-2.5 px-3 font-medium">Obligor & Economic Group</th>
                <th className="py-2.5 px-3 font-medium">Shared Dependency</th>
                <th className="py-2.5 px-3 font-medium">Geo / Sector</th>
                <th className="py-2.5 px-3 font-medium text-right">Principal</th>
                <th className="py-2.5 px-3 font-medium text-right">Coupon</th>
                <th className="py-2.5 px-3 font-medium border-r border-white/10">Status</th>
                <th className="py-2.5 px-3 font-medium text-right">Annual PD %</th>
                <th className="py-2.5 px-3 font-medium text-right">Recovery %</th>
                <th className="py-2.5 px-3 font-medium text-right">Lag (Q)</th>
                <th className="py-2.5 px-3 font-medium text-right">CPR %</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filteredAssets.map((a) => (
                <tr key={a.assetId} className="hover:bg-white/[0.02]">
                  <td className="py-2.5 px-3 font-mono text-[#F4F1EA]">{a.assetId}</td>
                  <td className="py-2.5 px-3">
                    <div className="font-medium text-[#F4F1EA]">{a.obligorName}</div>
                    <div className="text-[11px] text-[#A1A6B3]">
                      {a.economicGroup} · {a.seniority.replace('_', ' ')}
                    </div>
                  </td>
                  <td className="py-2.5 px-3 text-[#D2CFC7]">{a.sharedDependency}</td>
                  <td className="py-2.5 px-3">
                    <div className="text-[#F4F1EA]">{a.geography}</div>
                    <div className="text-[11px] text-[#A1A6B3]">{a.sector}</div>
                  </td>
                  <td className="py-2.5 px-3 font-mono text-right text-[#F4F1EA]">
                    {formatCurrency(a.principalOutstanding, a.currency)}
                  </td>
                  <td className="py-2.5 px-3 font-mono text-right text-[#D2CFC7]">
                    {a.interestType === 'floating' ? `SOFR+${a.spreadOrCouponBps}` : `${a.spreadOrCouponBps} Fix`}
                  </td>
                  <td className="py-2.5 px-3 border-r border-white/10">
                    <span
                      className={
                        a.delinquencyStatus === 'current'
                          ? 'text-[#6CC4B5]'
                          : a.delinquencyStatus === 'defaulted'
                          ? 'text-[#DF8787]'
                          : 'text-[#E3B469]'
                      }
                    >
                      {a.delinquencyStatus}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 font-mono text-right">
                    <input
                      type="number"
                      step={0.1}
                      min={0}
                      max={50}
                      value={(a.assumedAnnualPd * 100).toFixed(2)}
                      onChange={(e) =>
                        handleUpdateAssetAssumption(
                          a.assetId,
                          'assumedAnnualPd',
                          Math.max(0, Math.min(1, Number(e.target.value) / 100))
                        )
                      }
                      className="w-16 bg-[#0B0D10] border border-white/10 rounded px-1.5 py-0.5 text-right text-xs font-mono text-[#E3B469]"
                    />
                  </td>
                  <td className="py-2.5 px-3 font-mono text-right">
                    <input
                      type="number"
                      step={1}
                      min={0}
                      max={100}
                      value={(a.assumedRecoveryRate * 100).toFixed(0)}
                      onChange={(e) =>
                        handleUpdateAssetAssumption(
                          a.assetId,
                          'assumedRecoveryRate',
                          Math.max(0, Math.min(1, Number(e.target.value) / 100))
                        )
                      }
                      className="w-14 bg-[#0B0D10] border border-white/10 rounded px-1.5 py-0.5 text-right text-xs font-mono text-[#6CC4B5]"
                    />
                  </td>
                  <td className="py-2.5 px-3 font-mono text-right text-[#D2CFC7]">
                    {a.assumedRecoveryLagPeriods}
                  </td>
                  <td className="py-2.5 px-3 font-mono text-right text-[#D2CFC7]">
                    {(a.assumedPrepaymentCpr * 100).toFixed(1)}%
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
