import React, { useMemo, useState } from 'react';
import {
  ArrowDown,
  ArrowUp,
  GitFork,
  Layers,
  Merge,
  Plus,
  Trash2,
} from 'lucide-react';
import type {
  CollateralAsset,
  DealRecord,
  DealStructure,
  TrancheDefinition,
  TrancheSeniority,
} from '../../engine/types.ts';
import { computeCapitalReconciliation, recomputeAttachmentPoints } from '../../engine/waterfall.ts';
import { SENIORITY_META, formatBps, formatCurrency, formatPct } from '../../lib/format.ts';

interface StructureViewProps {
  deal: DealRecord;
  assets: CollateralAsset[];
  structures: DealStructure[];
  activeStructure: DealStructure;
  onSelectStructure: (structureId: string) => void;
  onUpdateTranches: (updatedTranches: TrancheDefinition[]) => void;
}

export function StructureView({
  deal,
  assets,
  structures,
  activeStructure,
  onSelectStructure,
  onUpdateTranches,
}: StructureViewProps) {
  const [selectedTrancheId, setSelectedTrancheId] = useState<string>(
    activeStructure.tranches[0]?.id ?? ''
  );

  const poolNotional = useMemo(
    () => assets.reduce((s, a) => s + a.principalOutstanding, 0) || deal.targetPoolNotional,
    [assets, deal.targetPoolNotional]
  );

  const tranches = useMemo(
    () =>
      recomputeAttachmentPoints(
        [...activeStructure.tranches].sort((a, b) => a.paymentPriority - b.paymentPriority),
        poolNotional
      ),
    [activeStructure.tranches, poolNotional]
  );

  const selectedTranche = tranches.find((t) => t.id === selectedTrancheId) ?? tranches[0];

  const reconciliation = useMemo(
    () => computeCapitalReconciliation(deal, assets, tranches),
    [deal, assets, tranches]
  );

  const totalCapitalStack = tranches.reduce((s, t) => s + t.notional, 0) || 1;

  const commitTranches = (next: TrancheDefinition[]) => {
    const normalized = next.map((t, idx) => ({
      ...t,
      paymentPriority: idx + 1,
      principalPriority: idx + 1,
      lossAllocationOrder: idx + 1,
    }));
    onUpdateTranches(recomputeAttachmentPoints(normalized, poolNotional));
  };

  const handleResizeTranche = (trancheId: string, newNotional: number) => {
    const safeVal = Math.max(500_000, Math.round(newNotional));
    commitTranches(tranches.map((t) => (t.id === trancheId ? { ...t, notional: safeVal } : t)));
  };

  const handleSplitTranche = (trancheId: string) => {
    const idx = tranches.findIndex((t) => t.id === trancheId);
    if (idx === -1) return;
    const orig = tranches[idx];
    if (orig.notional < 1_000_000) return;
    const halfA = Math.round(orig.notional * 0.6);
    const halfB = orig.notional - halfA;
    const partA: TrancheDefinition = {
      ...orig,
      id: `${orig.id}_a_${Date.now().toString().slice(-3)}`,
      code: `${orig.code} (1)`,
      notional: halfA,
    };
    const partB: TrancheDefinition = {
      ...orig,
      id: `${orig.id}_b_${Date.now().toString().slice(-3)}`,
      code: `${orig.code} (2)`,
      notional: halfB,
      spreadOrCouponBps: orig.seniority === 'equity' ? 0 : orig.spreadOrCouponBps + 35,
    };
    const next = [...tranches.slice(0, idx), partA, partB, ...tranches.slice(idx + 1)];
    commitTranches(next);
    setSelectedTrancheId(partA.id);
  };

  const handleMergeWithNext = (trancheId: string) => {
    const idx = tranches.findIndex((t) => t.id === trancheId);
    if (idx === -1 || idx >= tranches.length - 1) return;
    const a = tranches[idx];
    const b = tranches[idx + 1];
    const mergedNotional = a.notional + b.notional;
    const weightedSpread = Math.round(
      (a.spreadOrCouponBps * a.notional + b.spreadOrCouponBps * b.notional) /
        Math.max(1, mergedNotional)
    );
    const merged: TrancheDefinition = {
      ...a,
      code: `${a.code.replace(/ \(1\)$/, '')} Merged`,
      notional: mergedNotional,
      spreadOrCouponBps: weightedSpread,
    };
    const next = [...tranches.slice(0, idx), merged, ...tranches.slice(idx + 2)];
    commitTranches(next);
    setSelectedTrancheId(merged.id);
  };

  const handleReorder = (trancheId: string, dir: -1 | 1) => {
    const idx = tranches.findIndex((t) => t.id === trancheId);
    const target = idx + dir;
    if (idx === -1 || target < 0 || target >= tranches.length) return;
    const copy = [...tranches];
    const [moved] = copy.splice(idx, 1);
    copy.splice(target, 0, moved);
    commitTranches(copy);
  };

  const handleAddTranche = () => {
    const newId = `tr_new_${Date.now().toString().slice(-4)}`;
    const insertIdx = Math.max(0, tranches.length - 1);
    const newTranche: TrancheDefinition = {
      id: newId,
      code: `Class D Mezz-${tranches.length}`,
      seniority: 'junior',
      notional: 4_000_000,
      issuePricePct: 98.0,
      couponType: 'floating',
      spreadOrCouponBps: 480,
      maturityPeriods: deal.maturityPeriods,
      paymentPriority: insertIdx + 1,
      principalPriority: insertIdx + 1,
      isDeferrable: true,
      lossAllocationOrder: insertIdx + 1,
      redemptionProvision: 'Callable Par',
      isFunded: true,
      referenceNotional: poolNotional,
      attachmentPct: 0,
      detachmentPct: 0,
    };
    const next = [...tranches.slice(0, insertIdx), newTranche, ...tranches.slice(insertIdx)];
    commitTranches(next);
    setSelectedTrancheId(newId);
  };

  const handleDeleteTranche = (trancheId: string) => {
    if (tranches.length <= 2) return;
    const next = tranches.filter((t) => t.id !== trancheId);
    commitTranches(next);
    setSelectedTrancheId(next[0].id);
  };

  const handleFieldChange = <K extends keyof TrancheDefinition>(
    trancheId: string,
    key: K,
    val: TrancheDefinition[K]
  ) => {
    commitTranches(tranches.map((t) => (t.id === trancheId ? { ...t, [key]: val } : t)));
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-white/10 pb-5">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-[#F4F1EA]">
            Capital Structure & Visual Tranche Builder
          </h1>
          <p className="mt-1 text-sm text-[#A1A6B3]">
            Directly edit tranche thickness, priority, attachment/detachment bands, deferral rules, and funded status. Neutral identifiers are enforced unless an external rating is supplied.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <select
            aria-label="Select Alternative Capital Structure"
            value={activeStructure.id}
            onChange={(e) => onSelectStructure(e.target.value)}
            className="bg-[#141820] border border-white/15 rounded px-3 py-2 text-xs text-[#F4F1EA]"
          >
            {structures.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
          <button
            type="button"
            onClick={handleAddTranche}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold bg-[#C8A253] text-[#0B0D10] rounded hover:bg-[#D9B76E]"
          >
            <Plus className="w-3.5 h-3.5" /> Add Tranche
          </button>
        </div>
      </div>

      {/* Main Split: Interactive Visual Capital Stack Diagram + Tranche Terms Editor */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: Visual Capital Stack Diagram (5 cols) */}
        <div className="lg:col-span-5 bg-[#141820] border border-white/10 rounded-lg p-6 space-y-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-[#C8A253]" />
              <h2 className="text-sm font-semibold text-[#F4F1EA]">
                Interactive Capital Stack Diagram
              </h2>
            </div>
            <span className="text-xs font-mono text-[#A1A6B3]">
              Ref Pool: {formatCurrency(poolNotional, deal.currency, true)}
            </span>
          </div>

          {/* Side-by-side Asset Pool vs Liabilities Stack */}
          <div className="grid grid-cols-12 gap-3 items-stretch">
            {/* Asset / Reference Column */}
            <div className="col-span-3 flex flex-col justify-between bg-[#1A202B] border border-white/15 rounded p-3 min-h-[420px]">
              <div className="text-[11px] font-medium text-[#A1A6B3]">
                {deal.structureType === 'synthetic' ? 'Reference Risk' : 'Collateral Pool'}
              </div>
              <div className="my-auto text-center space-y-1">
                <div className="text-sm font-mono font-semibold text-[#F4F1EA]">
                  {formatCurrency(poolNotional, deal.currency, true)}
                </div>
                <div className="text-[11px] text-[#A1A6B3]">100.0%</div>
                {deal.structureType === 'synthetic' && (
                  <div className="text-[10px] text-[#E3B469] pt-2">
                    Funded Coll: {formatCurrency(reconciliation.collateralAssets, deal.currency, true)}
                  </div>
                )}
              </div>
              <div className="text-[11px] font-mono text-[#6CC4B5] border-t border-white/10 pt-2">
                +{formatCurrency(deal.reserveBalance, deal.currency, true)} Res
              </div>
            </div>

            {/* Proportional Editable Tranche Blocks */}
            <div className="col-span-9 flex flex-col gap-1.5 min-h-[420px]">
              {tranches.map((tr, idx) => {
                const meta = SENIORITY_META[tr.seniority];
                const sharePct = (tr.notional / totalCapitalStack) * 100;
                const heightPx = Math.max(54, Math.round((sharePct / 100) * 380));
                const isSelected = tr.id === selectedTranche?.id;
                return (
                  <div
                    key={tr.id}
                    onClick={() => setSelectedTrancheId(tr.id)}
                    style={{ minHeight: `${heightPx}px` }}
                    className={`rounded border p-2.5 cursor-pointer transition-all flex flex-col justify-between ${
                      meta.bgClass
                    } ${
                      isSelected
                        ? 'border-[#C8A253] ring-1 ring-[#C8A253]'
                        : `${meta.borderClass} hover:border-white/40`
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <span className="text-[11px] font-mono text-[#A1A6B3]">
                          P{tr.paymentPriority}
                        </span>
                        <span className="text-xs font-semibold text-[#F4F1EA] truncate">
                          {tr.code}
                        </span>
                        {tr.suppliedRating && (
                          <span className="text-[11px] font-mono text-[#E3B469]">
                            [{tr.suppliedRating}]
                          </span>
                        )}
                      </div>
                      <span className={`text-[11px] font-medium shrink-0 ${meta.textClass}`}>
                        {meta.label} · {tr.isFunded ? 'Funded' : 'Unfunded'}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-2 pt-1.5">
                      <div className="text-xs font-mono text-[#F4F1EA]">
                        {formatCurrency(tr.notional, deal.currency, true)}{' '}
                        <span className="text-[#A1A6B3]">
                          ({formatPct((tr.notional / poolNotional) * 100, 1)})
                        </span>
                      </div>
                      <div className="text-[11px] font-mono text-[#D2CFC7]">
                        Attach {tr.attachmentPct.toFixed(1)}%–{tr.detachmentPct.toFixed(1)}% ·{' '}
                        {tr.couponType === 'residual'
                          ? 'Residual'
                          : tr.couponType === 'floating'
                          ? `+${tr.spreadOrCouponBps}bps`
                          : `${tr.spreadOrCouponBps}bps`}
                      </div>
                    </div>

                    {/* Direct inline stack manipulation controls */}
                    {isSelected && (
                      <div
                        className="flex flex-wrap items-center gap-1.5 pt-2 mt-1.5 border-t border-white/10"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <button
                          type="button"
                          onClick={() => handleResizeTranche(tr.id, tr.notional - 1_000_000)}
                          className="px-2 py-0.5 text-[11px] font-mono bg-[#0B0D10]/80 border border-white/15 rounded hover:border-[#C8A253]"
                        >
                          -$1M
                        </button>
                        <button
                          type="button"
                          onClick={() => handleResizeTranche(tr.id, tr.notional + 1_000_000)}
                          className="px-2 py-0.5 text-[11px] font-mono bg-[#0B0D10]/80 border border-white/15 rounded hover:border-[#C8A253]"
                        >
                          +$1M
                        </button>
                        <button
                          type="button"
                          onClick={() => handleSplitTranche(tr.id)}
                          title="Split Tranche 60/40"
                          className="inline-flex items-center gap-1 px-2 py-0.5 text-[11px] bg-[#0B0D10]/80 border border-white/15 rounded hover:border-[#C8A253]"
                        >
                          <GitFork className="w-3 h-3" /> Split
                        </button>
                        {idx < tranches.length - 1 && (
                          <button
                            type="button"
                            onClick={() => handleMergeWithNext(tr.id)}
                            title="Merge with next tranche below"
                            className="inline-flex items-center gap-1 px-2 py-0.5 text-[11px] bg-[#0B0D10]/80 border border-white/15 rounded hover:border-[#C8A253]"
                          >
                            <Merge className="w-3 h-3" /> Merge Down
                          </button>
                        )}
                        <button
                          type="button"
                          disabled={idx === 0}
                          onClick={() => handleReorder(tr.id, -1)}
                          className="p-1 bg-[#0B0D10]/80 border border-white/15 rounded disabled:opacity-30 hover:border-[#C8A253]"
                          aria-label="Move priority up"
                        >
                          <ArrowUp className="w-3 h-3" />
                        </button>
                        <button
                          type="button"
                          disabled={idx === tranches.length - 1}
                          onClick={() => handleReorder(tr.id, 1)}
                          className="p-1 bg-[#0B0D10]/80 border border-white/15 rounded disabled:opacity-30 hover:border-[#C8A253]"
                          aria-label="Move priority down"
                        >
                          <ArrowDown className="w-3 h-3" />
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          <p className="text-[11px] text-[#A1A6B3] leading-relaxed">
            Attachment & detachment points are defined explicitly relative to Reference Pool Notional = {formatCurrency(poolNotional, deal.currency)}.
          </p>
        </div>

        {/* Right: Selected Tranche Contractual Terms & Reconciliation (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          {selectedTranche && (
            <div className="bg-[#141820] border border-white/10 rounded-lg p-6 space-y-5">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-3">
                <div>
                  <span className="text-xs text-[#C8A253] font-mono">
                    Priority #{selectedTranche.paymentPriority} · {SENIORITY_META[selectedTranche.seniority].label}
                  </span>
                  <h3 className="text-base font-semibold text-[#F4F1EA]">
                    {selectedTranche.code} — Contractual Parameters
                  </h3>
                </div>
                {tranches.length > 2 && (
                  <button
                    type="button"
                    onClick={() => handleDeleteTranche(selectedTranche.id)}
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs text-[#DF8787] border border-[#B85A5A]/40 rounded hover:bg-[#B85A5A]/15"
                  >
                    <Trash2 className="w-3.5 h-3.5" /> Remove Tranche
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                <label className="space-y-1">
                  <span className="text-[#A1A6B3] block">Neutral Tranche Identifier</span>
                  <input
                    type="text"
                    value={selectedTranche.code}
                    onChange={(e) => handleFieldChange(selectedTranche.id, 'code', e.target.value)}
                    className="w-full bg-[#0B0D10] border border-white/15 rounded px-3 py-2 text-xs text-[#F4F1EA]"
                  />
                </label>
                <label className="space-y-1">
                  <span className="text-[#A1A6B3] block">Supplied External Rating (Optional)</span>
                  <input
                    type="text"
                    value={selectedTranche.suppliedRating ?? ''}
                    placeholder="None supplied"
                    onChange={(e) =>
                      handleFieldChange(
                        selectedTranche.id,
                        'suppliedRating',
                        e.target.value.trim() || undefined
                      )
                    }
                    className="w-full bg-[#0B0D10] border border-white/15 rounded px-3 py-2 text-xs font-mono text-[#F4F1EA]"
                  />
                </label>
                <label className="space-y-1">
                  <span className="text-[#A1A6B3] block">Seniority Class</span>
                  <select
                    value={selectedTranche.seniority}
                    onChange={(e) =>
                      handleFieldChange(
                        selectedTranche.id,
                        'seniority',
                        e.target.value as TrancheSeniority
                      )
                    }
                    className="w-full bg-[#0B0D10] border border-white/15 rounded px-3 py-2 text-xs text-[#F4F1EA]"
                  >
                    <option value="senior">Senior</option>
                    <option value="mezzanine">Mezzanine</option>
                    <option value="junior">Junior</option>
                    <option value="equity">Equity / First-Loss</option>
                  </select>
                </label>

                <label className="space-y-1">
                  <span className="text-[#A1A6B3] block">Notional (USD)</span>
                  <input
                    type="number"
                    step={500000}
                    min={500000}
                    value={selectedTranche.notional}
                    onChange={(e) =>
                      handleResizeTranche(selectedTranche.id, Number(e.target.value))
                    }
                    className="w-full bg-[#0B0D10] border border-white/15 rounded px-3 py-2 text-xs font-mono text-[#F4F1EA]"
                  />
                </label>
                <label className="space-y-1">
                  <span className="text-[#A1A6B3] block">Issue Price (% Par)</span>
                  <input
                    type="number"
                    step={0.25}
                    min={50}
                    max={110}
                    value={selectedTranche.issuePricePct}
                    onChange={(e) =>
                      handleFieldChange(selectedTranche.id, 'issuePricePct', Number(e.target.value))
                    }
                    className="w-full bg-[#0B0D10] border border-white/15 rounded px-3 py-2 text-xs font-mono text-[#F4F1EA]"
                  />
                </label>
                <label className="space-y-1">
                  <span className="text-[#A1A6B3] block">Coupon Basis</span>
                  <select
                    value={selectedTranche.couponType}
                    onChange={(e) =>
                      handleFieldChange(
                        selectedTranche.id,
                        'couponType',
                        e.target.value as TrancheDefinition['couponType']
                      )
                    }
                    className="w-full bg-[#0B0D10] border border-white/15 rounded px-3 py-2 text-xs text-[#F4F1EA]"
                  >
                    <option value="floating">Floating (Ref + Spread)</option>
                    <option value="fixed">Fixed Coupon</option>
                    <option value="residual">Residual Equity</option>
                  </select>
                </label>

                <label className="space-y-1">
                  <span className="text-[#A1A6B3] block">Spread / Coupon (bps)</span>
                  <input
                    type="number"
                    step={5}
                    min={0}
                    disabled={selectedTranche.couponType === 'residual'}
                    value={selectedTranche.spreadOrCouponBps}
                    onChange={(e) =>
                      handleFieldChange(
                        selectedTranche.id,
                        'spreadOrCouponBps',
                        Number(e.target.value)
                      )
                    }
                    className="w-full bg-[#0B0D10] border border-white/15 rounded px-3 py-2 text-xs font-mono text-[#F4F1EA] disabled:opacity-40"
                  />
                </label>
                <label className="space-y-1">
                  <span className="text-[#A1A6B3] block">Maturity (Periods)</span>
                  <input
                    type="number"
                    min={1}
                    max={120}
                    value={selectedTranche.maturityPeriods}
                    onChange={(e) =>
                      handleFieldChange(
                        selectedTranche.id,
                        'maturityPeriods',
                        Number(e.target.value)
                      )
                    }
                    className="w-full bg-[#0B0D10] border border-white/15 rounded px-3 py-2 text-xs font-mono text-[#F4F1EA]"
                  />
                </label>
                <label className="space-y-1">
                  <span className="text-[#A1A6B3] block">Redemption Provision</span>
                  <input
                    type="text"
                    value={selectedTranche.redemptionProvision}
                    onChange={(e) =>
                      handleFieldChange(selectedTranche.id, 'redemptionProvision', e.target.value)
                    }
                    className="w-full bg-[#0B0D10] border border-white/15 rounded px-3 py-2 text-xs text-[#F4F1EA]"
                  />
                </label>
              </div>

              <div className="flex flex-wrap items-center gap-6 pt-2 text-xs">
                <label className="inline-flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={selectedTranche.isDeferrable}
                    onChange={(e) =>
                      handleFieldChange(selectedTranche.id, 'isDeferrable', e.target.checked)
                    }
                    className="accent-[#C8A253]"
                  />
                  <span className="text-[#D2CFC7]">Interest-Deferrable (PIK on OC/IC Breach)</span>
                </label>
                <label className="inline-flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={selectedTranche.isFunded}
                    onChange={(e) =>
                      handleFieldChange(selectedTranche.id, 'isFunded', e.target.checked)
                    }
                    className="accent-[#C8A253]"
                  />
                  <span className="text-[#D2CFC7]">
                    Funded Note / CLN (Uncheck for Unfunded CDS Swap)
                  </span>
                </label>
              </div>
            </div>
          )}

          {/* Capital & Funding Proceeds Reconciliation */}
          <div className="bg-[#141820] border border-white/10 rounded-lg p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h3 className="text-sm font-semibold text-[#F4F1EA]">
                Balance Sheet & Issuance Proceeds Reconciliation
              </h3>
              <span
                className={`text-xs font-mono font-medium ${
                  reconciliation.reconciled ? 'text-[#6CC4B5]' : 'text-[#E3B469]'
                }`}
              >
                {reconciliation.reconciled
                  ? 'Reconciled Within Tolerance'
                  : 'Funding Imbalance Detected'}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
              <div className="space-y-2">
                <div className="text-[#A1A6B3] font-medium pb-1 border-b border-white/5">
                  Uses & Vehicle Assets
                </div>
                <div className="flex justify-between">
                  <span className="text-[#D2CFC7]">
                    {deal.structureType === 'synthetic'
                      ? 'Funded Cash Collateral Account'
                      : 'Acquired Collateral Assets'}
                  </span>
                  <span className="font-mono text-[#F4F1EA]">
                    {formatCurrency(reconciliation.collateralAssets, deal.currency)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#D2CFC7]">Liquidity Reserve Account</span>
                  <span className="font-mono text-[#F4F1EA]">
                    {formatCurrency(reconciliation.reserveAccount, deal.currency)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#D2CFC7]">Structuring & Issuance Expenses</span>
                  <span className="font-mono text-[#F4F1EA]">
                    {formatCurrency(reconciliation.issuanceExpenses, deal.currency)}
                  </span>
                </div>
                <div className="flex justify-between pt-2 border-t border-white/10 font-semibold">
                  <span className="text-[#F4F1EA]">Total Vehicle Assets + Reserves</span>
                  <span className="font-mono text-[#F4F1EA]">
                    {formatCurrency(reconciliation.totalAssetsAndReserves, deal.currency)}
                  </span>
                </div>
              </div>

              <div className="space-y-2">
                <div className="text-[#A1A6B3] font-medium pb-1 border-b border-white/5">
                  Sources, Liabilities & Transferred Risk
                </div>
                <div className="flex justify-between">
                  <span className="text-[#D2CFC7]">Funded Notes / CLNs</span>
                  <span className="font-mono text-[#F4F1EA]">
                    {formatCurrency(reconciliation.fundedNotesNotional, deal.currency)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#D2CFC7]">Equity / First-Loss Position</span>
                  <span className="font-mono text-[#F4F1EA]">
                    {formatCurrency(reconciliation.equityNotional, deal.currency)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#D2CFC7]">Unfunded Protection Swap (Off-Balance)</span>
                  <span className="font-mono text-[#84B3E0]">
                    {formatCurrency(reconciliation.unfundedProtectionNotional, deal.currency)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#D2CFC7]">Net Issuance Proceeds (After Fees)</span>
                  <span className="font-mono text-[#F4F1EA]">
                    {formatCurrency(reconciliation.netIssuanceProceeds, deal.currency)}
                  </span>
                </div>
                <div className="flex justify-between pt-2 border-t border-white/10 font-semibold">
                  <span className="text-[#F4F1EA]">Funding Surplus / (Deficit)</span>
                  <span
                    className={`font-mono ${
                      reconciliation.fundingSurplusOrDeficit >= -100000
                        ? 'text-[#6CC4B5]'
                        : 'text-[#DF8787]'
                    }`}
                  >
                    {formatCurrency(reconciliation.fundingSurplusOrDeficit, deal.currency)}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Complete Tranche Summary Table */}
          <div className="bg-[#141820] border border-white/10 rounded-lg overflow-hidden">
            <div className="px-4 py-3 border-b border-white/10 text-xs font-semibold text-[#F4F1EA]">
              Full Capital Stack Schedule
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-white/10 text-[#A1A6B3] bg-[#101319]">
                    <th className="py-2 px-3">Tranche</th>
                    <th className="py-2 px-3 text-right">Notional</th>
                    <th className="py-2 px-3 text-right">Share</th>
                    <th className="py-2 px-3 text-right">Attach–Detach</th>
                    <th className="py-2 px-3 text-right">Coupon</th>
                    <th className="py-2 px-3 text-right">Issue Px</th>
                    <th className="py-2 px-3">Deferral / Funding</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {tranches.map((t) => (
                    <tr
                      key={t.id}
                      onClick={() => setSelectedTrancheId(t.id)}
                      className={`cursor-pointer ${
                        t.id === selectedTranche?.id ? 'bg-[#C8A253]/10' : 'hover:bg-white/[0.02]'
                      }`}
                    >
                      <td className="py-2 px-3 font-medium text-[#F4F1EA]">
                        {t.code}
                        {t.suppliedRating ? ` (${t.suppliedRating})` : ''}
                      </td>
                      <td className="py-2 px-3 font-mono text-right text-[#F4F1EA]">
                        {formatCurrency(t.notional, deal.currency)}
                      </td>
                      <td className="py-2 px-3 font-mono text-right text-[#D2CFC7]">
                        {formatPct((t.notional / poolNotional) * 100, 1)}
                      </td>
                      <td className="py-2 px-3 font-mono text-right text-[#D2CFC7]">
                        {t.attachmentPct.toFixed(1)}%–{t.detachmentPct.toFixed(1)}%
                      </td>
                      <td className="py-2 px-3 font-mono text-right text-[#D2CFC7]">
                        {t.couponType === 'residual' ? 'Residual' : formatBps(t.spreadOrCouponBps)}
                      </td>
                      <td className="py-2 px-3 font-mono text-right text-[#D2CFC7]">
                        {t.issuePricePct.toFixed(2)}%
                      </td>
                      <td className="py-2 px-3 text-[#A1A6B3]">
                        {t.isDeferrable ? 'PIK' : 'Non-Defer'} · {t.isFunded ? 'Funded' : 'Unfunded'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
