import React, { useMemo, useState } from 'react';
import { CheckCircle2, Compass, Play, SlidersHorizontal } from 'lucide-react';
import { optimizeCapitalStructure, runMonteCarloSimulation } from '../../engine/quantEngine.ts';
import type {
  CollateralAsset,
  DealAssumptions,
  DealRecord,
  DealStructure,
  OptimizationCandidate,
  OptimizationConstraints,
  TrancheDefinition,
} from '../../engine/types.ts';
import { recomputeAttachmentPoints } from '../../engine/waterfall.ts';
import { formatBps, formatPct } from '../../lib/format.ts';

interface ScenariosViewProps {
  deal: DealRecord;
  assets: CollateralAsset[];
  structures: DealStructure[];
  activeStructure: DealStructure;
  onApplyOptimizedStructure: (candidate: OptimizationCandidate, updatedTranches: TrancheDefinition[]) => void;
}

interface StressPreset {
  id: string;
  label: string;
  description: string;
  patch: Partial<DealAssumptions>;
}

const STRESS_PRESETS: StressPreset[] = [
  {
    id: 'base',
    label: 'Base Calibration',
    description: 'Baseline contractual assumptions, 24% correlation, normal recovery timing.',
    patch: { pdMultiplier: 1.0, recoveryMultiplier: 1.0, clusterShockFactor: 1.0, defaultCorrelationRho: 0.24, rateShockBps: 0, recoveryLagPeriodsOverride: undefined },
  },
  {
    id: 'cluster_euv',
    label: 'Clustered Defaults (Supply-Chain Shock)',
    description: '2.2x PD, 1.8x cluster shock, 0.48 correlation simulating fab equipment bottleneck.',
    patch: { pdMultiplier: 2.2, recoveryMultiplier: 0.85, clusterShockFactor: 1.8, defaultCorrelationRho: 0.48, rateShockBps: 50, recoveryLagPeriodsOverride: 3 },
  },
  {
    id: 'delayed_recovery_rate_hike',
    label: 'Delayed Recoveries + Rate Hike (+200 bps)',
    description: 'Recovery lag extended to 4 quarters, recovery x0.75, reference rate +200 bps.',
    patch: { pdMultiplier: 1.6, recoveryMultiplier: 0.75, clusterShockFactor: 1.3, defaultCorrelationRho: 0.34, rateShockBps: 200, recoveryLagPeriodsOverride: 4 },
  },
  {
    id: 'concentrated_failure',
    label: 'Concentrated Borrower Failures',
    description: 'Severe idiosyncratic & group stress (PD x2.6, Recovery x0.70, Rho 0.55).',
    patch: { pdMultiplier: 2.6, recoveryMultiplier: 0.7, clusterShockFactor: 2.0, defaultCorrelationRho: 0.55, rateShockBps: 100, recoveryLagPeriodsOverride: 3 },
  },
];

export function ScenariosView({
  deal,
  assets,
  structures,
  activeStructure,
  onApplyOptimizedStructure,
}: ScenariosViewProps) {
  const [selectedPresetId, setSelectedPresetId] = useState<string>('cluster_euv');
  const [customPdMult, setCustomPdMult] = useState<number>(2.2);
  const [customRecMult, setCustomRecMult] = useState<number>(0.85);
  const [customRho, setCustomRho] = useState<number>(0.48);
  const [customRateShock, setCustomRateShock] = useState<number>(50);
  const [customLag, setCustomLag] = useState<number>(3);
  const [comparisonSeed, setComparisonSeed] = useState<number>(202699);

  // Optimizer constraints
  const [constraints, setConstraints] = useState<OptimizationConstraints>({
    maxSeniorImpairmentProb: 2.5,
    maxSeniorWalYears: 4.5,
    minEquityIrrPct: 10.0,
    minOcCushionPct: 2.0,
    minReservePct: 1.0,
  });

  const [optResults, setOptResults] = useState<OptimizationCandidate[] | null>(null);

  const selectPreset = (preset: StressPreset) => {
    setSelectedPresetId(preset.id);
    setCustomPdMult(preset.patch.pdMultiplier ?? 1.0);
    setCustomRecMult(preset.patch.recoveryMultiplier ?? 1.0);
    setCustomRho(preset.patch.defaultCorrelationRho ?? 0.24);
    setCustomRateShock(preset.patch.rateShockBps ?? 0);
    setCustomLag(preset.patch.recoveryLagPeriodsOverride ?? 2);
  };

  const scenarioAssumptions: DealAssumptions = useMemo(
    () => ({
      ...activeStructure.assumptions,
      pdMultiplier: customPdMult,
      recoveryMultiplier: customRecMult,
      defaultCorrelationRho: customRho,
      rateShockBps: customRateShock,
      recoveryLagPeriodsOverride: customLag,
      clusterShockFactor: selectedPresetId === 'base' ? 1.0 : 1.5,
    }),
    [activeStructure.assumptions, customPdMult, customRecMult, customRho, customRateShock, customLag, selectedPresetId]
  );

  // Run fast comparative Monte Carlo across all available structures under the selected stress
  const structureComparisons = useMemo(() => {
    return structures.map((st) => {
      const sim = runMonteCarloSimulation({
        deal,
        assets,
        tranches: st.tranches,
        rules: st.waterfallRules,
        assumptions: scenarioAssumptions,
        scenarioName: selectedPresetId,
        seed: comparisonSeed,
        numPaths: 100,
      });
      const senior = sim.trancheMetrics[0];
      const mezz = sim.trancheMetrics.find((t) => t.seniority === 'mezzanine') ?? sim.trancheMetrics[1];
      const eq = sim.trancheMetrics[sim.trancheMetrics.length - 1];
      return {
        structure: st,
        sim,
        senior,
        mezz,
        eq,
      };
    });
  }, [structures, deal, assets, scenarioAssumptions, selectedPresetId, comparisonSeed]);

  const handleRunOptimizer = () => {
    const res = optimizeCapitalStructure({
      deal,
      assets,
      baseTranches: activeStructure.tranches,
      rules: activeStructure.waterfallRules,
      assumptions: activeStructure.assumptions,
      constraints,
    });
    setOptResults(res);
  };

  const applyCandidate = (cand: OptimizationCandidate) => {
    const totalPool = assets.reduce((s, a) => s + a.principalOutstanding, 0) || deal.targetPoolNotional;
    const base = activeStructure.tranches;
    const sr = base.find((t) => t.seniority === 'senior') ?? base[0];
    const mz = base.find((t) => t.seniority === 'mezzanine') ?? base[1] ?? base[0];
    const jr = base.find((t) => t.seniority === 'junior') ?? base[2] ?? base[0];
    const eq = base.find((t) => t.seniority === 'equity') ?? base[base.length - 1];

    const updated = recomputeAttachmentPoints(
      [
        { ...sr, id: 'opt_sr', code: 'Class A Senior', seniority: 'senior', notional: totalPool * (cand.seniorPct / 100), paymentPriority: 1, principalPriority: 1, lossAllocationOrder: 1 },
        { ...mz, id: 'opt_mz', code: 'Class B Mezzanine', seniority: 'mezzanine', notional: totalPool * (cand.mezzPct / 100), paymentPriority: 2, principalPriority: 2, lossAllocationOrder: 2 },
        { ...jr, id: 'opt_jr', code: 'Class C Junior', seniority: 'junior', notional: totalPool * (cand.juniorPct / 100), paymentPriority: 3, principalPriority: 3, lossAllocationOrder: 3 },
        { ...eq, id: 'opt_eq', code: 'Subordinated Equity', seniority: 'equity', notional: totalPool * (cand.equityPct / 100), paymentPriority: 4, principalPriority: 4, lossAllocationOrder: 4 },
      ],
      totalPool
    );
    onApplyOptimizedStructure(cand, updated);
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-white/10 pb-5">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-[#F4F1EA]">
            Stress Scenarios, Structural Comparison & Optimizer
          </h1>
          <p className="mt-1 text-sm text-[#A1A6B3]">
            Compare alternative capital structures under clustered defaults, delayed recoveries, and rate shocks, and optimize tranche sizing against explicit risk constraints.
          </p>
        </div>
        <div className="flex items-center gap-2 text-xs font-mono text-[#A1A6B3]">
          <span>Deterministic Comparison Seed:</span>
          <input
            type="number"
            value={comparisonSeed}
            onChange={(e) => setComparisonSeed(Number(e.target.value))}
            className="w-24 bg-[#141820] border border-white/15 rounded px-2 py-1 text-[#F4F1EA]"
          />
        </div>
      </div>

      {/* Stress Presets & Custom Parameter Controls */}
      <div className="bg-[#141820] border border-white/10 rounded-lg p-6 space-y-5">
        <div className="flex items-center gap-2">
          <SlidersHorizontal className="w-4 h-4 text-[#C8A253]" />
          <h2 className="text-sm font-semibold text-[#F4F1EA]">Stress Scenario Definition</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          {STRESS_PRESETS.map((preset) => (
            <button
              key={preset.id}
              type="button"
              onClick={() => selectPreset(preset)}
              className={`text-left p-3.5 rounded border transition-colors ${
                selectedPresetId === preset.id
                  ? 'bg-[#C8A253]/15 border-[#C8A253]'
                  : 'bg-[#0B0D10] border-white/10 hover:border-white/25'
              }`}
            >
              <div className="text-xs font-semibold text-[#F4F1EA]">{preset.label}</div>
              <p className="text-[11px] text-[#A1A6B3] mt-1 leading-relaxed">{preset.description}</p>
            </button>
          ))}
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 pt-2 border-t border-white/10 text-xs">
          <label className="space-y-1">
            <span className="text-[#A1A6B3] block">PD Multiplier ({customPdMult}x)</span>
            <input
              type="range"
              min={0.5}
              max={4.0}
              step={0.1}
              value={customPdMult}
              onChange={(e) => setCustomPdMult(Number(e.target.value))}
              className="w-full accent-[#C8A253]"
            />
          </label>
          <label className="space-y-1">
            <span className="text-[#A1A6B3] block">Recovery Mult ({customRecMult}x)</span>
            <input
              type="range"
              min={0.4}
              max={1.3}
              step={0.05}
              value={customRecMult}
              onChange={(e) => setCustomRecMult(Number(e.target.value))}
              className="w-full accent-[#C8A253]"
            />
          </label>
          <label className="space-y-1">
            <span className="text-[#A1A6B3] block">Default Corr Rho ({customRho.toFixed(2)})</span>
            <input
              type="range"
              min={0.05}
              max={0.75}
              step={0.02}
              value={customRho}
              onChange={(e) => setCustomRho(Number(e.target.value))}
              className="w-full accent-[#C8A253]"
            />
          </label>
          <label className="space-y-1">
            <span className="text-[#A1A6B3] block">Rate Shock ({customRateShock} bps)</span>
            <input
              type="range"
              min={-150}
              max={400}
              step={25}
              value={customRateShock}
              onChange={(e) => setCustomRateShock(Number(e.target.value))}
              className="w-full accent-[#C8A253]"
            />
          </label>
          <label className="space-y-1">
            <span className="text-[#A1A6B3] block">Recovery Lag ({customLag} Q)</span>
            <input
              type="range"
              min={0}
              max={6}
              step={1}
              value={customLag}
              onChange={(e) => setCustomLag(Number(e.target.value))}
              className="w-full accent-[#C8A253]"
            />
          </label>
        </div>
      </div>

      {/* Multi-Structure Side-by-Side Comparison */}
      <div className="bg-[#141820] border border-white/10 rounded-lg overflow-hidden">
        <div className="px-5 py-3.5 border-b border-white/10 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-[#F4F1EA]">
            Alternative Capital Structures Under Selected Stress
          </h3>
          <span className="text-xs font-mono text-[#A1A6B3]">
            100 Correlated Copula Paths per Structure
          </span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-white/10 text-[#A1A6B3] bg-[#101319]">
                <th className="py-2.5 px-4">Structure Variant</th>
                <th className="py-2.5 px-3 text-right">Pool Mean Loss</th>
                <th className="py-2.5 px-3 text-right">OC Breach %</th>
                <th className="py-2.5 px-3 text-right">Senior Impair %</th>
                <th className="py-2.5 px-3 text-right">Senior Exp Loss</th>
                <th className="py-2.5 px-3 text-right">Mezz Exp Loss</th>
                <th className="py-2.5 px-3 text-right">Equity IRR</th>
                <th className="py-2.5 px-3 text-right">Issuer Net Spread</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {structureComparisons.map(({ structure, sim, senior, mezz, eq }) => (
                <tr key={structure.id} className="hover:bg-white/[0.02]">
                  <td className="py-3 px-4 font-medium text-[#F4F1EA]">
                    {structure.name}
                    {structure.id === activeStructure.id && (
                      <span className="ml-2 text-[11px] font-mono text-[#C8A253]">(Active)</span>
                    )}
                  </td>
                  <td className="py-3 px-3 font-mono text-right text-[#F4F1EA]">
                    {formatPct(sim.summaryMetrics.meanPoolLossPct)}
                  </td>
                  <td className="py-3 px-3 font-mono text-right text-[#E3B469]">
                    {formatPct(sim.summaryMetrics.ocBreachPathPct, 1)}
                  </td>
                  <td className="py-3 px-3 font-mono text-right text-[#84B3E0]">
                    {formatPct(senior?.probabilityOfImpairment ?? 0)}
                  </td>
                  <td className="py-3 px-3 font-mono text-right text-[#D2CFC7]">
                    {formatPct(senior?.expectedLossPct ?? 0)}
                  </td>
                  <td className="py-3 px-3 font-mono text-right text-[#6CC4B5]">
                    {formatPct(mezz?.expectedLossPct ?? 0)}
                  </td>
                  <td className="py-3 px-3 font-mono text-right text-[#DF8787]">
                    {formatPct(eq?.realWorldIrrPct ?? 0)}
                  </td>
                  <td className="py-3 px-3 font-mono text-right text-[#F4F1EA]">
                    {formatBps(sim.summaryMetrics.issuerNetFundingSpreadBps)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Constrained Capital Structure Optimizer */}
      <div className="bg-[#141820] border border-white/10 rounded-lg p-6 space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/10 pb-4">
          <div className="flex items-center gap-2">
            <Compass className="w-4 h-4 text-[#C8A253]" />
            <div>
              <h3 className="text-base font-semibold text-[#F4F1EA]">
                Constrained Capital-Structure Optimizer & Sensitivity Matrix
              </h3>
              <p className="text-xs text-[#A1A6B3]">
                Evaluates feasible tranche thicknesses and reserve targets against risk & return constraints, reporting PD and correlation sensitivities.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={handleRunOptimizer}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold bg-[#C8A253] text-[#0B0D10] rounded hover:bg-[#D9B76E]"
          >
            <Play className="w-3.5 h-3.5" /> Run Structure Optimization
          </button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 text-xs">
          <label className="space-y-1">
            <span className="text-[#A1A6B3] block">Max Senior Impair Prob (%)</span>
            <input
              type="number"
              step={0.5}
              value={constraints.maxSeniorImpairmentProb}
              onChange={(e) =>
                setConstraints((c) => ({ ...c, maxSeniorImpairmentProb: Number(e.target.value) }))
              }
              className="w-full bg-[#0B0D10] border border-white/15 rounded px-2.5 py-1.5 font-mono text-[#F4F1EA]"
            />
          </label>
          <label className="space-y-1">
            <span className="text-[#A1A6B3] block">Max Senior WAL (Yrs)</span>
            <input
              type="number"
              step={0.25}
              value={constraints.maxSeniorWalYears}
              onChange={(e) =>
                setConstraints((c) => ({ ...c, maxSeniorWalYears: Number(e.target.value) }))
              }
              className="w-full bg-[#0B0D10] border border-white/15 rounded px-2.5 py-1.5 font-mono text-[#F4F1EA]"
            />
          </label>
          <label className="space-y-1">
            <span className="text-[#A1A6B3] block">Min Equity IRR (%)</span>
            <input
              type="number"
              step={1}
              value={constraints.minEquityIrrPct}
              onChange={(e) =>
                setConstraints((c) => ({ ...c, minEquityIrrPct: Number(e.target.value) }))
              }
              className="w-full bg-[#0B0D10] border border-white/15 rounded px-2.5 py-1.5 font-mono text-[#F4F1EA]"
            />
          </label>
          <label className="space-y-1">
            <span className="text-[#A1A6B3] block">Min OC Cushion (%)</span>
            <input
              type="number"
              step={0.5}
              value={constraints.minOcCushionPct}
              onChange={(e) =>
                setConstraints((c) => ({ ...c, minOcCushionPct: Number(e.target.value) }))
              }
              className="w-full bg-[#0B0D10] border border-white/15 rounded px-2.5 py-1.5 font-mono text-[#F4F1EA]"
            />
          </label>
          <label className="space-y-1">
            <span className="text-[#A1A6B3] block">Min Reserve (%)</span>
            <input
              type="number"
              step={0.25}
              value={constraints.minReservePct}
              onChange={(e) =>
                setConstraints((c) => ({ ...c, minReservePct: Number(e.target.value) }))
              }
              className="w-full bg-[#0B0D10] border border-white/15 rounded px-2.5 py-1.5 font-mono text-[#F4F1EA]"
            />
          </label>
        </div>

        {optResults && (
          <div className="overflow-x-auto pt-2">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-white/10 text-[#A1A6B3] bg-[#101319]">
                  <th className="py-2.5 px-3">Candidate Structure</th>
                  <th className="py-2.5 px-3 text-right">Status</th>
                  <th className="py-2.5 px-3 text-right">Sr Impair</th>
                  <th className="py-2.5 px-3 text-right">Sr WAL</th>
                  <th className="py-2.5 px-3 text-right">Equity IRR</th>
                  <th className="py-2.5 px-3 text-right">WACD (bps)</th>
                  <th className="py-2.5 px-3 text-right">OC Cushion</th>
                  <th className="py-2.5 px-3 text-right">PD +50% Eq IRR Δ</th>
                  <th className="py-2.5 px-3 text-right">Rho +0.20 Sr Loss Δ</th>
                  <th className="py-2.5 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {optResults.map((cand, idx) => (
                  <tr
                    key={cand.id}
                    className={idx === 0 && cand.feasible ? 'bg-[#3D9A8B]/10' : 'hover:bg-white/[0.02]'}
                  >
                    <td className="py-2.5 px-3 font-medium text-[#F4F1EA]">
                      {cand.label}
                      {idx === 0 && cand.feasible && (
                        <span className="ml-2 text-[11px] font-mono text-[#6CC4B5]">
                          Recommended
                        </span>
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      {cand.feasible ? (
                        <span className="inline-flex items-center gap-1 text-[#6CC4B5]">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Feasible
                        </span>
                      ) : (
                        <span className="text-[#DF8787]">Infeasible</span>
                      )}
                    </td>
                    <td className="py-2.5 px-3 font-mono text-right text-[#D2CFC7]">
                      {formatPct(cand.seniorImpairmentProb)}
                    </td>
                    <td className="py-2.5 px-3 font-mono text-right text-[#D2CFC7]">
                      {cand.seniorWalYears.toFixed(2)}y
                    </td>
                    <td className="py-2.5 px-3 font-mono text-right text-[#F4F1EA]">
                      {formatPct(cand.equityIrrPct)}
                    </td>
                    <td className="py-2.5 px-3 font-mono text-right text-[#D2CFC7]">
                      {cand.weightedAvgCostOfDebtBps}
                    </td>
                    <td className="py-2.5 px-3 font-mono text-right text-[#D2CFC7]">
                      {formatPct(cand.ocCushionPct)}
                    </td>
                    <td className="py-2.5 px-3 font-mono text-right text-[#E3B469]">
                      {cand.sensitivityDeltaEquityIrrOnPdPlus50 >= 0 ? '+' : ''}
                      {cand.sensitivityDeltaEquityIrrOnPdPlus50.toFixed(2)}%
                    </td>
                    <td className="py-2.5 px-3 font-mono text-right text-[#DF8787]">
                      {cand.sensitivityDeltaSeniorLossOnRhoPlus20 >= 0 ? '+' : ''}
                      {cand.sensitivityDeltaSeniorLossOnRhoPlus20.toFixed(3)}%
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <button
                        type="button"
                        onClick={() => applyCandidate(cand)}
                        className="px-2.5 py-1 text-xs border border-[#C8A253]/60 text-[#F4F1EA] rounded hover:bg-[#C8A253] hover:text-[#0B0D10]"
                      >
                        Apply
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
