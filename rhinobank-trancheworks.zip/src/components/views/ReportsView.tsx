import React, { useEffect, useMemo, useState } from 'react';
import { Code2, Download, FileText, Printer } from 'lucide-react';
import { computePoolAnalytics, serializeAssetsToCsv } from '../../engine/collateral.ts';
import type {
  CollateralTape,
  DealRecord,
  DealStructure,
  SimulationRunResult,
  SurveillancePeriodRecord,
} from '../../engine/types.ts';
import { computeCapitalReconciliation } from '../../engine/waterfall.ts';
import {
  ASSET_CLASS_LABELS,
  formatBps,
  formatCurrency,
  formatPct,
  formatRatio,
} from '../../lib/format.ts';

interface ReportsViewProps {
  deal: DealRecord;
  tape: CollateralTape;
  structure: DealStructure;
  latestSimulation: SimulationRunResult | null;
  surveillancePeriods: SurveillancePeriodRecord[];
}

export function ReportsView({
  deal,
  tape,
  structure,
  latestSimulation,
  surveillancePeriods,
}: ReportsViewProps) {
  const [apiDocs, setApiDocs] = useState<Record<string, unknown> | null>(null);
  const [showApiDocs, setShowApiDocs] = useState(false);

  const analytics = useMemo(() => computePoolAnalytics(tape.assets), [tape.assets]);
  const reconciliation = useMemo(
    () => computeCapitalReconciliation(deal, tape.assets, structure.tranches),
    [deal, tape.assets, structure.tranches]
  );

  const latestSurv = surveillancePeriods[surveillancePeriods.length - 1];

  useEffect(() => {
    if (!showApiDocs || apiDocs) return;
    fetch('/api/v1/docs')
      .then((r) => r.json())
      .then(setApiDocs)
      .catch(() => setApiDocs({ error: 'API docs endpoint unreachable' }));
  }, [showApiDocs, apiDocs]);

  const downloadFile = (content: string, filename: string, mime: string) => {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleExportDealJson = () => {
    const payload = {
      exportedAt: new Date().toISOString(),
      deal,
      tape: { ...tape, assetsCount: tape.assets.length },
      assets: tape.assets,
      structure,
      latestSimulation,
      surveillancePeriods,
    };
    downloadFile(
      JSON.stringify(payload, null, 2),
      `${deal.code}_complete_package.json`,
      'application/json'
    );
  };

  const handleExportInvestorReportMarkdown = () => {
    const lines = [
      `# RhinoBank TrancheWorks — Investor & Structuring Report`,
      `**Transaction:** ${deal.name} (${deal.code})`,
      `**Asset Class:** ${ASSET_CLASS_LABELS[deal.assetClass]} | **Structure:** ${deal.structureType.toUpperCase()} CDO`,
      `**Generated:** ${new Date().toISOString()}`,
      ``,
      `## 1. Capital Reconciliation`,
      `- Collateral / Funded Account: ${formatCurrency(reconciliation.collateralAssets, deal.currency)}`,
      `- Reserve Balance: ${formatCurrency(reconciliation.reserveAccount, deal.currency)}`,
      `- Funded Notes Notional: ${formatCurrency(reconciliation.fundedNotesNotional, deal.currency)}`,
      `- Equity / First-Loss Notional: ${formatCurrency(reconciliation.equityNotional, deal.currency)}`,
      `- Unfunded Protection Swap: ${formatCurrency(reconciliation.unfundedProtectionNotional, deal.currency)}`,
      ``,
      `## 2. Collateral Summary (Tape v${tape.versionNumber})`,
      `- Assets: ${analytics.assetCount} | Economic Groups: ${analytics.uniqueEconomicGroups}`,
      `- Observed WA Coupon: ${formatBps(analytics.weightedAvgCouponBps)}`,
      `- Assumed WA Annual PD: ${formatPct(analytics.weightedAvgAssumedPd * 100)} | Assumed WA Recovery: ${formatPct(analytics.weightedAvgAssumedRecovery * 100)}`,
      ``,
      `## 3. Capital Stack`,
      ...structure.tranches.map(
        (t) =>
          `- ${t.code}: ${formatCurrency(t.notional, deal.currency)} (${t.attachmentPct.toFixed(1)}%-${t.detachmentPct.toFixed(1)}%) | ${t.couponType === 'residual' ? 'Residual' : `${t.spreadOrCouponBps} bps`}`
      ),
    ];

    if (latestSurv) {
      lines.push(
        ``,
        `## 4. Latest Surveillance Period (${latestSurv.periodLabel})`,
        `- OC Ratio: ${formatRatio(latestSurv.ocRatio)} (Trigger ${formatRatio(deal.ocTriggerRatio)})`,
        `- IC Ratio: ${formatRatio(latestSurv.icRatio)} (Trigger ${formatRatio(deal.icTriggerRatio)})`,
        `- Breaches: ${latestSurv.breaches.length > 0 ? latestSurv.breaches.map((b) => b.actionTaken).join(' ') : 'None'}`
      );
    }

    downloadFile(lines.join('\n'), `${deal.code}_investor_report.md`, 'text/markdown');
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-white/10 pb-5 no-print">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-[#F4F1EA]">
            Investor Reporting, Exports & API Documentation
          </h1>
          <p className="mt-1 text-sm text-[#A1A6B3]">
            Generate traceable investor memoranda, export full deal & collateral packages, and inspect live backend REST API specifications.
          </p>
        </div>
        <div className="flex flex-wrap gap-2.5">
          <button
            type="button"
            onClick={() => setShowApiDocs((v) => !v)}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium bg-[#141820] border border-white/15 text-[#F4F1EA] rounded hover:border-[#C8A253]"
          >
            <Code2 className="w-3.5 h-3.5 text-[#C8A253]" />
            {showApiDocs ? 'Hide API Docs' : 'REST API & Python Stack'}
          </button>
          <button
            type="button"
            onClick={() =>
              downloadFile(
                serializeAssetsToCsv(tape.assets),
                `${deal.code}_tape_v${tape.versionNumber}.csv`,
                'text/csv'
              )
            }
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium bg-[#141820] border border-white/15 text-[#F4F1EA] rounded hover:border-[#C8A253]"
          >
            <Download className="w-3.5 h-3.5" /> CSV Tape
          </button>
          <button
            type="button"
            onClick={handleExportDealJson}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium bg-[#141820] border border-white/15 text-[#F4F1EA] rounded hover:border-[#C8A253]"
          >
            <Download className="w-3.5 h-3.5" /> JSON Bundle
          </button>
          <button
            type="button"
            onClick={handleExportInvestorReportMarkdown}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium bg-[#141820] border border-white/15 text-[#F4F1EA] rounded hover:border-[#C8A253]"
          >
            <FileText className="w-3.5 h-3.5" /> Export Memo (.md)
          </button>
          <button
            type="button"
            onClick={() => window.print()}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold bg-[#C8A253] text-[#0B0D10] rounded hover:bg-[#D9B76E]"
          >
            <Printer className="w-3.5 h-3.5" /> Print Investor Report
          </button>
        </div>
      </div>

      {/* API Docs & Python/Docker Stack Reference */}
      {showApiDocs && (
        <div className="bg-[#141820] border border-[#C8A253]/40 rounded-lg p-6 space-y-4 no-print">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-[#F4F1EA]">
              OpenAPI Endpoints & Self-Hosted Python / PostgreSQL Stack
            </h2>
            <span className="text-xs font-mono text-[#6CC4B5]">
              FastAPI + NumPy/SciPy/Pandas + Celery + Postgres 16 in /backend_python & docker-compose.yml
            </span>
          </div>
          <pre className="text-xs font-mono bg-[#0B0D10] border border-white/10 rounded p-4 overflow-x-auto text-[#D2CFC7] max-h-72">
            {JSON.stringify(apiDocs ?? { loading: true }, null, 2)}
          </pre>
        </div>
      )}

      {/* Printable Institutional Investor Report Memorandum */}
      <div className="bg-[#141820] border border-white/10 rounded-lg p-8 space-y-8">
        <div className="flex flex-wrap items-start justify-between gap-4 border-b border-white/10 pb-6">
          <div>
            <div className="text-xs font-mono text-[#C8A253]">
              RHINOBANK TRANCHEWORKS · INSTITUTIONAL INVESTOR MEMORANDUM
            </div>
            <h2 className="text-2xl font-semibold text-[#F4F1EA] mt-1">{deal.name}</h2>
            <div className="text-xs text-[#A1A6B3] mt-1">
              Deal Code: {deal.code} · {ASSET_CLASS_LABELS[deal.assetClass]} ·{' '}
              {deal.structureType === 'cash' ? 'Cash CDO' : 'Synthetic CDO'} · Tape v
              {tape.versionNumber} ({tape.sourceFileName})
            </div>
          </div>
          <div className="text-right text-xs font-mono text-[#A1A6B3]">
            <div>Structure: {structure.name}</div>
            <div>Model Version: {latestSimulation?.modelVersion ?? 'TW-QUANT-2.4.0'}</div>
            {latestSimulation && <div>Reproducible Seed: {latestSimulation.seed}</div>}
          </div>
        </div>

        {/* Section 1: Capital & Funding Reconciliation */}
        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-[#F4F1EA] border-b border-white/10 pb-2">
            1. Capital & Balance Sheet Reconciliation
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
            <div>
              <span className="text-[#A1A6B3] block">
                {deal.structureType === 'synthetic' ? 'Funded Collateral Account' : 'Pool Principal'}
              </span>
              <span className="font-mono text-base font-semibold text-[#F4F1EA]">
                {formatCurrency(reconciliation.collateralAssets, deal.currency)}
              </span>
            </div>
            <div>
              <span className="text-[#A1A6B3] block">Reserve Account</span>
              <span className="font-mono text-base font-semibold text-[#F4F1EA]">
                {formatCurrency(reconciliation.reserveAccount, deal.currency)}
              </span>
            </div>
            <div>
              <span className="text-[#A1A6B3] block">Funded Notes + Equity</span>
              <span className="font-mono text-base font-semibold text-[#F4F1EA]">
                {formatCurrency(reconciliation.totalLiabilitiesAndEquity, deal.currency)}
              </span>
            </div>
            <div>
              <span className="text-[#A1A6B3] block">Unfunded Protection Swap</span>
              <span className="font-mono text-base font-semibold text-[#84B3E0]">
                {formatCurrency(reconciliation.unfundedProtectionNotional, deal.currency)}
              </span>
            </div>
          </div>
        </div>

        {/* Section 2: Collateral Top Concentrations */}
        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-[#F4F1EA] border-b border-white/10 pb-2">
            2. Collateral Pool Concentrations (Top Economic Groups & Shared Dependencies)
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
            <div>
              <div className="text-[#A1A6B3] mb-2">Top Economic Obligor Groups</div>
              <div className="space-y-1.5">
                {analytics.byEconomicGroup.slice(0, 5).map((g) => (
                  <div key={g.label} className="flex justify-between font-mono">
                    <span className="text-[#F4F1EA] font-sans">{g.label}</span>
                    <span className="text-[#D2CFC7]">
                      {formatCurrency(g.principal, deal.currency, true)} ({formatPct(g.sharePct, 1)})
                    </span>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <div className="text-[#A1A6B3] mb-2">Shared Supply-Chain Dependencies</div>
              <div className="space-y-1.5">
                {analytics.bySharedDependency.slice(0, 5).map((g) => (
                  <div key={g.label} className="flex justify-between font-mono">
                    <span className="text-[#F4F1EA] font-sans">{g.label}</span>
                    <span className="text-[#D2CFC7]">
                      {formatCurrency(g.principal, deal.currency, true)} ({formatPct(g.sharePct, 1)})
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Section 3: Tranche Risk & Analytical Valuation */}
        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-[#F4F1EA] border-b border-white/10 pb-2">
            3. Tranche Performance & Model Summary
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-white/10 text-[#A1A6B3]">
                  <th className="py-2 px-2">Tranche</th>
                  <th className="py-2 px-2 text-right">Notional</th>
                  <th className="py-2 px-2 text-right">Attach–Detach</th>
                  <th className="py-2 px-2 text-right">Coupon</th>
                  <th className="py-2 px-2 text-right">Exp Loss %</th>
                  <th className="py-2 px-2 text-right">Impair %</th>
                  <th className="py-2 px-2 text-right">WAL</th>
                  <th className="py-2 px-2 text-right">Real-World IRR</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {structure.tranches.map((t) => {
                  const tm = latestSimulation?.trancheMetrics.find((m) => m.trancheId === t.id);
                  return (
                    <tr key={t.id}>
                      <td className="py-2 px-2 font-medium text-[#F4F1EA]">{t.code}</td>
                      <td className="py-2 px-2 font-mono text-right text-[#F4F1EA]">
                        {formatCurrency(t.notional, deal.currency)}
                      </td>
                      <td className="py-2 px-2 font-mono text-right text-[#D2CFC7]">
                        {t.attachmentPct.toFixed(1)}%–{t.detachmentPct.toFixed(1)}%
                      </td>
                      <td className="py-2 px-2 font-mono text-right text-[#D2CFC7]">
                        {t.couponType === 'residual' ? 'Residual' : formatBps(t.spreadOrCouponBps)}
                      </td>
                      <td className="py-2 px-2 font-mono text-right text-[#D2CFC7]">
                        {tm ? formatPct(tm.expectedLossPct) : '—'}
                      </td>
                      <td className="py-2 px-2 font-mono text-right text-[#E3B469]">
                        {tm ? formatPct(tm.probabilityOfImpairment) : '—'}
                      </td>
                      <td className="py-2 px-2 font-mono text-right text-[#D2CFC7]">
                        {tm ? `${tm.weightedAverageLifeYears.toFixed(2)}y` : '—'}
                      </td>
                      <td className="py-2 px-2 font-mono text-right text-[#6CC4B5]">
                        {tm ? formatPct(tm.realWorldIrrPct) : '—'}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Section 4: Latest Surveillance & Breach Disclosure */}
        {latestSurv && (
          <div className="space-y-3">
            <h3 className="text-sm font-semibold text-[#F4F1EA] border-b border-white/10 pb-2">
              4. Post-Issuance Surveillance ({latestSurv.periodLabel} · As of {latestSurv.asOfDate})
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
              <div>
                <span className="text-[#A1A6B3] block">Ending Pool Principal</span>
                <span className="font-mono font-semibold text-[#F4F1EA]">
                  {formatCurrency(latestSurv.endingPoolBalance, deal.currency)}
                </span>
              </div>
              <div>
                <span className="text-[#A1A6B3] block">Observed OC Ratio</span>
                <span className="font-mono font-semibold text-[#F4F1EA]">
                  {formatRatio(latestSurv.ocRatio)} (Min {formatRatio(deal.ocTriggerRatio)})
                </span>
              </div>
              <div>
                <span className="text-[#A1A6B3] block">Observed IC Ratio</span>
                <span className="font-mono font-semibold text-[#F4F1EA]">
                  {formatRatio(latestSurv.icRatio)} (Min {formatRatio(deal.icTriggerRatio)})
                </span>
              </div>
              <div>
                <span className="text-[#A1A6B3] block">Snapshot Status</span>
                <span className="font-mono font-semibold text-[#6CC4B5]">
                  {latestSurv.isFinalized ? 'Finalized (Immutable)' : 'Open Draft'}
                </span>
              </div>
            </div>
            {latestSurv.breaches.length > 0 && (
              <div className="bg-[#0B0D10] border border-[#B85A5A]/40 rounded p-3 text-xs text-[#DF8787]">
                {latestSurv.breaches.map((b) => (
                  <div key={b.code}>
                    <strong>{b.testName}:</strong> {b.actionTaken}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        <div className="border-t border-white/10 pt-4 text-[11px] text-[#A1A6B3] leading-relaxed">
          Disclosure: Every payment, loss, and valuation figure in this report traces directly to Collateral Tape v{tape.versionNumber}, the active Contractual Waterfall rule set, and explicit real-world / discount curve assumptions. Model-implied spreads are analytical projections and do not represent executable market quotes.
        </div>
      </div>
    </div>
  );
}
