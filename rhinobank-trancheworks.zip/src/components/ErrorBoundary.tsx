import React from 'react';

interface Props {
  children: React.ReactNode;
}

interface State {
  hasError: boolean;
  message: string;
}

export class ErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, message: '' };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, message: error.message };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#0B0D10] text-[#F4F1EA] flex items-center justify-center p-8">
          <div className="max-w-lg w-full bg-[#151921] border border-white/15 rounded-lg p-6 space-y-4">
            <h2 className="text-lg font-semibold text-[#F4F1EA]">
              Application State Exception
            </h2>
            <p className="text-sm text-[#A1A6B3] leading-relaxed">
              An operation encountered a constraint or unexpected error. Details are logged below for audit review.
            </p>
            <pre className="text-xs font-mono bg-[#0B0D10] border border-white/10 rounded p-3 overflow-x-auto text-[#DF8787]">
              {this.state.message}
            </pre>
            <button
              type="button"
              onClick={() => this.setState({ hasError: false, message: '' })}
              className="px-4 py-2 text-xs font-medium bg-[#C8A253] text-[#0B0D10] rounded hover:bg-[#D9B76E] transition-colors"
            >
              Reset View
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
