import {
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
} from 'firebase/firestore';
import type { User } from 'firebase/auth';
import type {
  ApprovalRequestRecord,
  CollateralTape,
  DealRecord,
  DealStructure,
  SimulationRunResult,
  SurveillancePeriodRecord,
} from '../engine/types.ts';
import type { SeedWorkspaceBundle } from '../engine/seedData.ts';
import { OperationType, db, handleFirestoreError } from './firebase.ts';

export async function ensureUserProfile(user: User): Promise<'analyst' | 'structurer' | 'checker' | 'admin'> {
  const path = `users/${user.uid}`;
  try {
    const ref = doc(db, 'users', user.uid);
    const snap = await getDoc(ref);
    if (!snap.exists()) {
      const role = user.email === 'tom@ahyx.org' ? 'admin' : 'structurer';
      await setDoc(ref, {
        uid: user.uid,
        email: user.email ?? 'analyst@rhinobank.internal',
        displayName: user.displayName ?? user.email ?? 'Institutional Analyst',
        role,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      return role;
    }
    const data = snap.data();
    return (data?.role as 'analyst' | 'structurer' | 'checker' | 'admin') ?? 'structurer';
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function loadUserWorkspaceFromFirestore(
  uid: string,
  seedBundle: SeedWorkspaceBundle
): Promise<SeedWorkspaceBundle & { simulationsByDeal: Record<string, SimulationRunResult[]> }> {
  const dealsPath = 'deals';
  try {
    const q = query(collection(db, dealsPath), where('ownerId', '==', uid));
    const snap = await getDocs(q);

    if (snap.empty) {
      // Seed user's Firestore workspace with the 3 institutional deals cleanly
      await seedUserWorkspaceToFirestore(uid, seedBundle);
      return { ...seedBundle, simulationsByDeal: {} };
    }

    const deals: DealRecord[] = [];
    const tapesByDeal: Record<string, CollateralTape[]> = {};
    const structuresByDeal: Record<string, DealStructure[]> = {};
    const surveillanceByDeal: Record<string, SurveillancePeriodRecord[]> = {};
    const approvalsByDeal: Record<string, ApprovalRequestRecord[]> = {};
    const simulationsByDeal: Record<string, SimulationRunResult[]> = {};

    for (const d of snap.docs) {
      const data = d.data();
      const dealId = d.id;
      deals.push({
        ...(data as unknown as DealRecord),
        id: dealId,
        createdAt: data.createdAt?.toDate?.()?.toISOString?.() ?? new Date().toISOString(),
        updatedAt: data.updatedAt?.toDate?.()?.toISOString?.() ?? new Date().toISOString(),
      });

      const [tapesSnap, structsSnap, survSnap, apprSnap, simsSnap] = await Promise.all([
        getDocs(query(collection(db, `deals/${dealId}/tapes`), where('ownerId', '==', uid))),
        getDocs(query(collection(db, `deals/${dealId}/structures`), where('ownerId', '==', uid))),
        getDocs(query(collection(db, `deals/${dealId}/surveillance`), where('ownerId', '==', uid))),
        getDocs(query(collection(db, `deals/${dealId}/approvals`), where('ownerId', '==', uid))),
        getDocs(query(collection(db, `deals/${dealId}/simulations`), where('ownerId', '==', uid))),
      ]);

      tapesByDeal[dealId] = tapesSnap.docs
        .map((td) => {
          const tData = td.data();
          return {
            ...(tData as unknown as CollateralTape),
            id: td.id,
            createdAt: tData.createdAt?.toDate?.()?.toISOString?.() ?? new Date().toISOString(),
          };
        })
        .sort((a, b) => a.versionNumber - b.versionNumber);

      structuresByDeal[dealId] = structsSnap.docs
        .map((sd) => {
          const sData = sd.data();
          return {
            ...(sData as unknown as DealStructure),
            id: sd.id,
            createdAt: sData.createdAt?.toDate?.()?.toISOString?.() ?? new Date().toISOString(),
            updatedAt: sData.updatedAt?.toDate?.()?.toISOString?.() ?? new Date().toISOString(),
          };
        })
        .sort((a, b) => a.versionNumber - b.versionNumber);

      surveillanceByDeal[dealId] = survSnap.docs
        .map((pd) => {
          const pData = pd.data();
          return {
            ...(pData as unknown as SurveillancePeriodRecord),
            id: pd.id,
            createdAt: pData.createdAt?.toDate?.()?.toISOString?.() ?? new Date().toISOString(),
          };
        })
        .sort((a, b) => a.periodNumber - b.periodNumber);

      approvalsByDeal[dealId] = apprSnap.docs.map((ad) => {
        const aData = ad.data();
        return {
          ...(aData as unknown as ApprovalRequestRecord),
          id: ad.id,
          createdAt: aData.createdAt?.toDate?.()?.toISOString?.() ?? new Date().toISOString(),
          decidedAt: aData.decidedAt?.toDate?.()?.toISOString?.(),
        };
      });

      simulationsByDeal[dealId] = simsSnap.docs.map((simd) => {
        const sData = simd.data();
        return {
          ...(sData as unknown as SimulationRunResult),
          id: simd.id,
          createdAt: sData.createdAt?.toDate?.()?.toISOString?.() ?? new Date().toISOString(),
        };
      });
    }

    return {
      deals,
      tapesByDeal,
      structuresByDeal,
      surveillanceByDeal,
      approvalsByDeal,
      simulationsByDeal,
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, dealsPath);
  }
}

export async function seedUserWorkspaceToFirestore(uid: string, bundle: SeedWorkspaceBundle) {
  for (const deal of bundle.deals) {
    const dealId = `${deal.id}_${uid.slice(0, 6)}`;
    const dealPath = `deals/${dealId}`;
    try {
      await setDoc(doc(db, 'deals', dealId), {
        id: dealId,
        ownerId: uid,
        name: deal.name,
        code: deal.code,
        assetClass: deal.assetClass,
        structureType: deal.structureType,
        currency: deal.currency,
        targetPoolNotional: deal.targetPoolNotional,
        reinvestmentPeriods: deal.reinvestmentPeriods,
        maturityPeriods: deal.maturityPeriods,
        periodFrequency: deal.periodFrequency,
        status: deal.status,
        version: deal.version,
        activeTapeId: deal.activeTapeId,
        activeStructureId: deal.activeStructureId,
        reserveTarget: deal.reserveTarget,
        reserveBalance: deal.reserveBalance,
        annualSeniorFeeBps: deal.annualSeniorFeeBps,
        annualTrusteeFee: deal.annualTrusteeFee,
        ocTriggerRatio: deal.ocTriggerRatio,
        icTriggerRatio: deal.icTriggerRatio,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      for (const tape of bundle.tapesByDeal[deal.id] ?? []) {
        await setDoc(doc(db, `deals/${dealId}/tapes`, tape.id), {
          id: tape.id,
          dealId,
          ownerId: uid,
          versionNumber: tape.versionNumber,
          sourceFormat: tape.sourceFormat,
          sourceFileName: tape.sourceFileName,
          totalPrincipal: tape.totalPrincipal,
          assetCount: tape.assetCount,
          validationSummary: tape.validationSummary,
          assets: tape.assets,
          createdAt: serverTimestamp(),
        });
      }

      for (const struct of bundle.structuresByDeal[deal.id] ?? []) {
        await setDoc(doc(db, `deals/${dealId}/structures`, struct.id), {
          id: struct.id,
          dealId,
          ownerId: uid,
          name: struct.name,
          versionNumber: struct.versionNumber,
          isBase: struct.isBase,
          tranches: struct.tranches,
          waterfallRules: struct.waterfallRules,
          assumptions: struct.assumptions,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }

      for (const surv of bundle.surveillanceByDeal[deal.id] ?? []) {
        await setDoc(doc(db, `deals/${dealId}/surveillance`, surv.id), {
          id: surv.id,
          dealId,
          ownerId: uid,
          periodNumber: surv.periodNumber,
          periodLabel: surv.periodLabel,
          asOfDate: surv.asOfDate,
          isFinalized: surv.isFinalized,
          actualCollections: surv.actualCollections,
          actualDefaults: surv.actualDefaults,
          actualRecoveries: surv.actualRecoveries,
          endingPoolBalance: surv.endingPoolBalance,
          delinquency30Plus: surv.delinquency30Plus,
          delinquency60Plus: surv.delinquency60Plus,
          ocRatio: surv.ocRatio,
          icRatio: surv.icRatio,
          reserveBalance: surv.reserveBalance,
          breaches: surv.breaches,
          substitutions: surv.substitutions,
          forecastSnapshot: surv.forecastSnapshot,
          createdAt: serverTimestamp(),
        });
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, dealPath);
    }
  }
}

export async function persistStructureToFirestore(uid: string, dealId: string, struct: DealStructure) {
  const path = `deals/${dealId}/structures/${struct.id}`;
  try {
    const ref = doc(db, `deals/${dealId}/structures`, struct.id);
    const snap = await getDoc(ref);
    if (snap.exists()) {
      await updateDoc(ref, {
        name: struct.name,
        versionNumber: struct.versionNumber,
        isBase: struct.isBase,
        tranches: struct.tranches,
        waterfallRules: struct.waterfallRules,
        assumptions: struct.assumptions,
        updatedAt: serverTimestamp(),
      });
    } else {
      await setDoc(ref, {
        id: struct.id,
        dealId,
        ownerId: uid,
        name: struct.name,
        versionNumber: struct.versionNumber,
        isBase: struct.isBase,
        tranches: struct.tranches,
        waterfallRules: struct.waterfallRules,
        assumptions: struct.assumptions,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function persistCollateralTapeToFirestore(uid: string, dealId: string, tape: CollateralTape) {
  const path = `deals/${dealId}/tapes/${tape.id}`;
  try {
    await setDoc(doc(db, `deals/${dealId}/tapes`, tape.id), {
      id: tape.id,
      dealId,
      ownerId: uid,
      versionNumber: tape.versionNumber,
      sourceFormat: tape.sourceFormat,
      sourceFileName: tape.sourceFileName,
      totalPrincipal: tape.totalPrincipal,
      assetCount: tape.assetCount,
      validationSummary: tape.validationSummary,
      assets: tape.assets.slice(0, 200),
      createdAt: serverTimestamp(),
    });
    await updateDoc(doc(db, 'deals', dealId), {
      activeTapeId: tape.id,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function persistSimulationToFirestore(uid: string, dealId: string, sim: SimulationRunResult) {
  const path = `deals/${dealId}/simulations/${sim.id}`;
  try {
    await setDoc(doc(db, `deals/${dealId}/simulations`, sim.id), {
      id: sim.id,
      dealId,
      ownerId: uid,
      structureId: sim.structureId,
      scenarioName: sim.scenarioName,
      modelVersion: sim.modelVersion,
      seed: sim.seed,
      numPaths: sim.numPaths,
      assumptionsSnapshot: sim.assumptionsSnapshot,
      trancheMetrics: sim.trancheMetrics,
      summaryMetrics: sim.summaryMetrics,
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function persistSurveillanceToFirestore(
  uid: string,
  dealId: string,
  period: SurveillancePeriodRecord
) {
  const path = `deals/${dealId}/surveillance/${period.id}`;
  try {
    const ref = doc(db, `deals/${dealId}/surveillance`, period.id);
    const snap = await getDoc(ref);
    if (snap.exists()) {
      await updateDoc(ref, {
        isFinalized: period.isFinalized,
        actualCollections: period.actualCollections,
        actualDefaults: period.actualDefaults,
        actualRecoveries: period.actualRecoveries,
        endingPoolBalance: period.endingPoolBalance,
        delinquency30Plus: period.delinquency30Plus,
        delinquency60Plus: period.delinquency60Plus,
        ocRatio: period.ocRatio,
        icRatio: period.icRatio,
        reserveBalance: period.reserveBalance,
        breaches: period.breaches,
        substitutions: period.substitutions,
        forecastSnapshot: period.forecastSnapshot,
      });
    } else {
      await setDoc(ref, {
        id: period.id,
        dealId,
        ownerId: uid,
        periodNumber: period.periodNumber,
        periodLabel: period.periodLabel,
        asOfDate: period.asOfDate,
        isFinalized: period.isFinalized,
        actualCollections: period.actualCollections,
        actualDefaults: period.actualDefaults,
        actualRecoveries: period.actualRecoveries,
        endingPoolBalance: period.endingPoolBalance,
        delinquency30Plus: period.delinquency30Plus,
        delinquency60Plus: period.delinquency60Plus,
        ocRatio: period.ocRatio,
        icRatio: period.icRatio,
        reserveBalance: period.reserveBalance,
        breaches: period.breaches,
        substitutions: period.substitutions,
        forecastSnapshot: period.forecastSnapshot,
        createdAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function createApprovalInFirestore(
  uid: string,
  dealId: string,
  approval: ApprovalRequestRecord
) {
  const path = `deals/${dealId}/approvals/${approval.id}`;
  try {
    await setDoc(doc(db, `deals/${dealId}/approvals`, approval.id), {
      id: approval.id,
      dealId,
      ownerId: uid,
      makerUid: uid,
      makerEmail: approval.makerEmail,
      actionType: approval.actionType,
      summary: approval.summary,
      payloadDiff: approval.payloadDiff,
      status: 'pending',
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function decideApprovalInFirestore(
  uid: string,
  email: string,
  dealId: string,
  approvalId: string,
  decision: 'approved' | 'rejected',
  decisionNote: string
) {
  const path = `deals/${dealId}/approvals/${approvalId}`;
  try {
    await updateDoc(doc(db, `deals/${dealId}/approvals`, approvalId), {
      status: decision,
      checkerUid: uid,
      checkerEmail: email,
      decisionNote,
      decidedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}
