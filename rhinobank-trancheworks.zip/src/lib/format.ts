export function formatCurrency(amount: number, currency = 'USD', compact = false): string {
  if (!Number.isFinite(amount)) return '$0';
  if (compact && Math.abs(amount) >= 1_000_000) {
    return `${amount < 0 ? '-' : ''}$${(Math.abs(amount) / 1_000_000).toFixed(2)}M`;
  }
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency,
    maximumFractionDigits: 0,
  }).format(amount);
}

export function formatCurrencyExact(amount: number, currency = 'USD'): string {
  if (!Number.isFinite(amount)) return '$0.00';
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

export function formatPct(val: number, decimals = 2): string {
  if (!Number.isFinite(val)) return '0.00%';
  return `${val.toFixed(decimals)}%`;
}

export function formatBps(bps: number): string {
  if (!Number.isFinite(bps)) return '0 bps';
  return `${Math.round(bps)} bps`;
}

export function formatRatio(ratio: number, decimals = 3): string {
  if (!Number.isFinite(ratio)) return '0.000x';
  return `${ratio.toFixed(decimals)}x`;
}

export const SENIORITY_META: Record<
  'senior' | 'mezzanine' | 'junior' | 'equity',
  { label: string; hex: string; bgClass: string; textClass: string; borderClass: string }
> = {
  senior: {
    label: 'Senior',
    hex: '#4B83B8',
    bgClass: 'bg-[#4B83B8]/18',
    textClass: 'text-[#84B3E0]',
    borderClass: 'border-[#4B83B8]/50',
  },
  mezzanine: {
    label: 'Mezzanine',
    hex: '#3D9A8B',
    bgClass: 'bg-[#3D9A8B]/18',
    textClass: 'text-[#6CC4B5]',
    borderClass: 'border-[#3D9A8B]/50',
  },
  junior: {
    label: 'Junior',
    hex: '#C8923E',
    bgClass: 'bg-[#C8923E]/18',
    textClass: 'text-[#E3B469]',
    borderClass: 'border-[#C8923E]/50',
  },
  equity: {
    label: 'Equity / First-Loss',
    hex: '#B85A5A',
    bgClass: 'bg-[#B85A5A]/18',
    textClass: 'text-[#DF8787]',
    borderClass: 'border-[#B85A5A]/50',
  },
};

export const ASSET_CLASS_LABELS: Record<string, string> = {
  semiconductor: 'Semiconductor Financing',
  corporate_debt: 'Corporate Debt',
  equipment_finance: 'Equipment Finance',
};
