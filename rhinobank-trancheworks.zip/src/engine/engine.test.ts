import { describe, expect, it } from 'vitest';
import { parseCollateralImport, serializeAssetsToCsv } from './collateral.ts';
import { runMonteCarloSimulation } from './quantEngine.ts';
import { createInitialSeedBundle } from './seedData.ts';
import {
  computeCapitalReconciliation,
  detectWaterfallCycles,
  recomputeAttachmentPoints,
  runContractualWaterfall,
} from './waterfall.ts';

describe('RhinoBank TrancheWorks Quantitative & Contractual Engine', () => {
  it('validates USD 100M semiconductor pool and detects CSV errors cleanly', () => {
    const bundle = createInitialSeedBundle();
    const semiTape = bundle.tapesByDeal['deal_rst_2026_1'][0];
    expect(semiTape.assets.length).toBe(40);
    expect(semiTape.totalPrincipal).toBe(100_000_000);

    const csv = serializeAssetsToCsv(semiTape.assets);
    const validRes = parseCollateralImport(csv, 'csv', 'USD');
    expect(validRes.valid).toBe(true);
    expect(validRes.errorCount).toBe(0);
    expect(validRes.analytics.totalPrincipal).toBe(100_000_000);

    // Inject duplicate ID, currency mismatch, and invalid maturity date
    const badAssets = [
      { ...semiTape.assets[0] },
      { ...semiTape.assets[0], currency: 'EUR', originationDate: '2029-01-01', maturityDate: '2026-01-01' },
    ];
    const badRes = parseCollateralImport(JSON.stringify(badAssets), 'json', 'USD');
    expect(badRes.valid).toBe(false);
    expect(badRes.issues.some((i) => i.field === 'assetId')).toBe(true);
    expect(badRes.issues.some((i) => i.field === 'currency')).toBe(true);
    expect(badRes.issues.some((i) => i.field === 'maturityDate')).toBe(true);
  });

  it('reconciles capital stack and separates synthetic reference risk from funded collateral', () => {
    const bundle = createInitialSeedBundle();
    const cashDeal = bundle.deals[0];
    const cashAssets = bundle.tapesByDeal[cashDeal.id][0].assets;
    const cashTranches = bundle.structuresByDeal[cashDeal.id][0].tranches;

    const cashRec = computeCapitalReconciliation(cashDeal, cashAssets, cashTranches);
    expect(cashRec.collateralAssets).toBe(100_000_000);
    expect(cashRec.fundedNotesNotional + cashRec.equityNotional).toBe(100_000_000);
    expect(cashRec.unfundedProtectionNotional).toBe(0);
    expect(cashRec.reconciled).toBe(true);

    // Synthetic CDO check: $68M unfunded swap + $32M funded CLN/equity
    const synDeal = bundle.deals[2];
    const synAssets = bundle.tapesByDeal[synDeal.id][0].assets;
    const synTranches = bundle.structuresByDeal[synDeal.id][0].tranches;
    const synRec = computeCapitalReconciliation(synDeal, synAssets, synTranches);
    expect(synRec.unfundedProtectionNotional).toBe(68_000_000);
    expect(synRec.fundedNotesNotional + synRec.equityNotional).toBe(32_000_000);
    expect(synRec.collateralAssets).toBe(32_000_000);
  });

  it('computes bottom-up attachment and detachment points accurately', () => {
    const bundle = createInitialSeedBundle();
    const tranches = recomputeAttachmentPoints(
      bundle.structuresByDeal['deal_rst_2026_1'][0].tranches,
      100_000_000
    );
    const equity = tranches.find((t) => t.seniority === 'equity')!;
    const junior = tranches.find((t) => t.seniority === 'junior')!;
    const mezz = tranches.find((t) => t.seniority === 'mezzanine')!;
    const a2 = tranches.find((t) => t.code === 'Class A-2 Senior')!;
    const a1 = tranches.find((t) => t.code === 'Class A-1 Senior')!;

    expect(equity.attachmentPct).toBe(0);
    expect(equity.detachmentPct).toBe(8);
    expect(junior.attachmentPct).toBe(8);
    expect(junior.detachmentPct).toBe(16);
    expect(mezz.attachmentPct).toBe(16);
    expect(mezz.detachmentPct).toBe(28);
    expect(a2.attachmentPct).toBe(28);
    expect(a2.detachmentPct).toBe(46);
    expect(a1.attachmentPct).toBe(46);
    expect(a1.detachmentPct).toBe(100);
  });

  it('enforces waterfall cash conservation and detects circular rule dependencies', () => {
    const bundle = createInitialSeedBundle();
    const deal = bundle.deals[0];
    const assets = bundle.tapesByDeal[deal.id][0].assets;
    const struct = bundle.structuresByDeal[deal.id][0];

    const run = runContractualWaterfall({
      deal,
      assets,
      tranches: struct.tranches,
      rules: struct.waterfallRules,
      assumptions: struct.assumptions,
    });

    expect(run.ruleCycleDetected).toBe(false);
    expect(run.periods.length).toBe(20);
    expect(run.maxCashConservationError).toBeLessThan(1e-4);

    // Cycle check
    const cyclicRules = [
      { ...struct.waterfallRules[0], id: 'r1', dependsOnRuleId: 'r2' },
      { ...struct.waterfallRules[1], id: 'r2', dependsOnRuleId: 'r1' },
    ];
    const cycle = detectWaterfallCycles(cyclicRules);
    expect(cycle.hasCycle).toBe(true);
  });

  it('triggers OC coverage-test breach and diverts junior/equity distributions to senior cure', () => {
    const bundle = createInitialSeedBundle();
    const deal = bundle.deals[0];
    const assets = bundle.tapesByDeal[deal.id][0].assets;
    const struct = bundle.structuresByDeal[deal.id][0];

    // Heavy default shock in period 2 so OC drops below 1.16
    const run = runContractualWaterfall({
      deal,
      assets,
      tranches: struct.tranches,
      rules: struct.waterfallRules,
      assumptions: struct.assumptions,
      periodShocks: [
        { defaultFractionOverride: 0.01 },
        { defaultFractionOverride: 0.14, recoveryRateOverride: 0.25 },
      ],
    });

    expect(run.ocBreachPeriods.length).toBeGreaterThan(0);
    expect(run.totalDivertedCash).toBeGreaterThan(0);

    const breachPeriod = run.periods.find((p) => !p.ocTestPassed)!;
    const equityState = breachPeriod.trancheStates.find((t) => t.code === 'Subordinated Equity')!;
    const juniorState = breachPeriod.trancheStates.find((t) => t.code === 'Class C Junior')!;
    expect(breachPeriod.diversionAmount).toBeGreaterThan(0);
    expect(equityState.interestPaid).toBe(0);
    expect(juniorState.interestDeferred).toBeGreaterThan(0);
  });

  it('produces bit-exact reproducible Monte Carlo results for identical seeds', () => {
    const bundle = createInitialSeedBundle();
    const deal = bundle.deals[0];
    const assets = bundle.tapesByDeal[deal.id][0].assets;
    const struct = bundle.structuresByDeal[deal.id][0];

    const run1 = runMonteCarloSimulation({
      deal,
      assets,
      tranches: struct.tranches,
      rules: struct.waterfallRules,
      assumptions: struct.assumptions,
      scenarioName: 'Base Reproducibility Check',
      seed: 98765,
      numPaths: 100,
    });

    const run2 = runMonteCarloSimulation({
      deal,
      assets,
      tranches: struct.tranches,
      rules: struct.waterfallRules,
      assumptions: struct.assumptions,
      scenarioName: 'Base Reproducibility Check',
      seed: 98765,
      numPaths: 100,
    });

    expect(run1.summaryMetrics.meanPoolLossPct).toBe(run2.summaryMetrics.meanPoolLossPct);
    expect(run1.summaryMetrics.p99PoolLossPct).toBe(run2.summaryMetrics.p99PoolLossPct);
    expect(run1.trancheMetrics.map((t) => t.expectedPrincipalLoss)).toEqual(
      run2.trancheMetrics.map((t) => t.expectedPrincipalLoss)
    );
    expect(run1.trancheMetrics.map((t) => t.modelImpliedSpreadBps)).toEqual(
      run2.trancheMetrics.map((t) => t.modelImpliedSpreadBps)
    );
  });
});
