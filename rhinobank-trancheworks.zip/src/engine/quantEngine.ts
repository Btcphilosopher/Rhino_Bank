import type {
  CollateralAsset,
  DealAssumptions,
  DealRecord,
  OptimizationCandidate,
  OptimizationConstraints,
  SimulationRunResult,
  TrancheDefinition,
  TrancheSimulationMetrics,
  WaterfallRule,
} from './types.ts';
import { recomputeAttachmentPoints, runContractualWaterfall } from './waterfall.ts';

export const MODEL_VERSION = 'TW-QUANT-2.4.0';

/** Deterministic Mulberry32 PRNG for reproducible Monte Carlo paths */
export function createSeededRng(seed: number): () => number {
  let state = seed >>> 0;
  return () => {
    state = (state + 0x6d2b79f5) >>> 0;
    let t = Math.imul(state ^ (state >>> 15), 1 | state);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Standard Normal CDF (Abramowitz & Stegun 7.1.26) */
export function normalCdf(x: number): number {
  const sign = x < 0 ? -1 : 1;
  const absX = Math.abs(x) / Math.SQRT2;
  const t = 1 / (1 + 0.3275911 * absX);
  const y =
    1 -
    (((((1.061405429 * t - 1.453152027) * t + 1.421413741) * t - 0.284496736) * t +
      0.254829592) *
      t) *
      Math.exp(-absX * absX);
  return 0.5 * (1 + sign * y);
}

/** Inverse Standard Normal CDF (Acklam rational approximation) */
export function invNormalCdf(p: number): number {
  const clamped = Math.max(1e-9, Math.min(1 - 1e-9, p));
  const a = [
    -3.969683028665376e1, 2.209460984245205e2, -2.759285104469687e2,
    1.38357751867269e2, -3.066479806614716e1, 2.506628277459239,
  ];
  const b = [
    -5.447609879822406e1, 1.615858368580409e2, -1.556989798598866e2,
    6.680131188771972e1, -1.328068155288572e1,
  ];
  const c = [
    -7.784894002430293e-3, -3.223964580411365e-1, -2.400758277161838,
    -2.549732539343734, 4.374664141464968, 2.938163982698783,
  ];
  const d = [
    7.784695709041462e-3, 3.224671290700398e-1, 2.445134137142996, 3.754408661907416,
  ];
  const pLow = 0.02425;
  const pHigh = 1 - pLow;
  if (clamped < pLow) {
    const q = Math.sqrt(-2 * Math.log(clamped));
    return (
      (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) /
      ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1)
    );
  }
  if (clamped <= pHigh) {
    const q = clamped - 0.5;
    const r = q * q;
    return (
      ((((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q) /
      (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1)
    );
  }
  const q = Math.sqrt(-2 * Math.log(1 - clamped));
  return -(
    (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) /
    ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1)
  );
}

function sampleStandardNormal(rng: () => number): number {
  const u1 = Math.max(1e-12, rng());
  const u2 = rng();
  return Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
}

/** Solve periodic IRR via bisection given cash flows starting at t=0 (negative initial outlay) */
export function computeAnnualizedIrr(cashFlows: number[], periodsPerYear: number): number {
  if (cashFlows.length < 2 || cashFlows[0] >= 0) return 0;
  const totalIn = cashFlows.slice(1).reduce((s, c) => s + c, 0);
  if (totalIn <= 0) return -100;

  const npv = (rPerPeriod: number) =>
    cashFlows.reduce((s, cf, idx) => s + cf / Math.pow(1 + rPerPeriod, idx), 0);

  let lo = -0.9;
  let hi = 2.0;
  for (let i = 0; i < 48; i++) {
    const mid = (lo + hi) / 2;
    if (npv(mid) > 0) lo = mid;
    else hi = mid;
  }
  const rPeriod = (lo + hi) / 2;
  const annual = (Math.pow(1 + rPeriod, periodsPerYear) - 1) * 100;
  return Math.max(-99.9, Math.min(250, annual));
}

/** Solve Model-Implied Discount Spread (bps over risk-free curve) matching PV to issue price */
function solveModelImpliedSpreadBps(
  expectedCashFlows: number[],
  issueOutlay: number,
  riskFreeBps: number,
  periodsPerYear: number
): number {
  if (issueOutlay <= 0 || expectedCashFlows.length === 0) return 0;
  const pvAtSpread = (spreadBps: number) => {
    const annualRate = (riskFreeBps + spreadBps) / 10000;
    const rPerPeriod = annualRate / periodsPerYear;
    return expectedCashFlows.reduce(
      (s, cf, idx) => s + cf / Math.pow(1 + rPerPeriod, idx + 1),
      0
    );
  };
  let lo = -400;
  let hi = 6000;
  for (let i = 0; i < 44; i++) {
    const mid = (lo + hi) / 2;
    if (pvAtSpread(mid) > issueOutlay) lo = mid;
    else hi = mid;
  }
  return Math.round((lo + hi) / 2);
}

export function runMonteCarloSimulation(params: {
  deal: DealRecord;
  assets: CollateralAsset[];
  tranches: TrancheDefinition[];
  rules: WaterfallRule[];
  assumptions: DealAssumptions;
  scenarioName: string;
  seed: number;
  numPaths: number;
}): SimulationRunResult {
  const startTime = Date.now();
  const { deal, assets, tranches, rules, assumptions, scenarioName, seed, numPaths } = params;
  const rng = createSeededRng(seed);
  const periodsPerYear = deal.periodFrequency === 'monthly' ? 12 : 4;
  const totalPeriods = deal.maturityPeriods;
  const totalPoolPrincipal = assets.reduce((s, a) => s + a.principalOutstanding, 0) || 1;
  const alignedTranches = recomputeAttachmentPoints(tranches, totalPoolPrincipal);

  // Deterministic base run first for reference
  const deterministicBase = runContractualWaterfall({
    deal,
    assets,
    tranches: alignedTranches,
    rules,
    assumptions,
  });

  // Group indices by sharedDependency for cluster correlation
  const clusterGroups = new Map<string, number>();
  let nextClusterIdx = 0;
  const assetClusterIdx = assets.map((a) => {
    const key = a.sharedDependency !== 'None' ? a.sharedDependency : a.economicGroup;
    if (!clusterGroups.has(key)) {
      clusterGroups.set(key, nextClusterIdx++);
    }
    return clusterGroups.get(key)!;
  });

  // Accumulators per tranche across paths
  const nTranches = alignedTranches.length;
  const sumPrincipalLoss = new Array(nTranches).fill(0);
  const impairCount = new Array(nTranches).fill(0);
  const sumInterestShortfall = new Array(nTranches).fill(0);
  const sumWalNumerator = new Array(nTranches).fill(0);
  const sumWalDenom = new Array(nTranches).fill(0);
  const sumCashFlowsPerTranche: number[][] = alignedTranches.map(() =>
    new Array(totalPeriods).fill(0)
  );
  const trancheLossesByPath: number[][] = alignedTranches.map(() => []);
  const breachExposedCount = new Array(nTranches).fill(0);

  const poolLossPctByPath: number[] = [];
  let sumTotalDefaults = 0;
  let sumTotalRecoveries = 0;
  let ocBreachPaths = 0;
  let icBreachPaths = 0;
  let liquidityShortfallPaths = 0;

  const rhoMacro = Math.max(0.02, Math.min(0.85, assumptions.defaultCorrelationRho));
  const rhoCluster = Math.min(0.35, 0.12 * assumptions.clusterShockFactor);
  const rhoIdio = Math.max(0.05, 1 - rhoMacro - rhoCluster);

  for (let path = 0; path < numPaths; path++) {
    // Draw asset-level default times via correlated factor copula
    const macroFactor = sampleStandardNormal(rng);
    const clusterFactors = Array.from({ length: nextClusterIdx }, () => sampleStandardNormal(rng));
    const rateJitterBps = sampleStandardNormal(rng) * 35;

    // Track per-period asset default indicators (0 or 1)
    const periodDefaultAmounts: number[][] = Array.from({ length: totalPeriods }, () =>
      new Array(assets.length).fill(0)
    );
    const periodRecoveryRates: number[][] = Array.from({ length: totalPeriods }, () =>
      new Array(assets.length).fill(0)
    );

    for (let aIdx = 0; aIdx < assets.length; aIdx++) {
      const a = assets[aIdx];
      if (a.delinquencyStatus === 'defaulted') continue;

      const z =
        Math.sqrt(rhoMacro) * macroFactor +
        Math.sqrt(rhoCluster) * clusterFactors[assetClusterIdx[aIdx]] +
        Math.sqrt(rhoIdio) * sampleStandardNormal(rng);

      const u = normalCdf(z);
      const effAnnualPd = Math.min(
        0.85,
        a.assumedAnnualPd * assumptions.pdMultiplier * assumptions.clusterShockFactor
      );
      const periodHazard = 1 - Math.pow(1 - effAnnualPd, 1 / periodsPerYear);
      // Cumulative PD up to asset maturity
      const cumPd = 1 - Math.pow(1 - periodHazard, Math.min(totalPeriods, a.maturityPeriods));

      if (u < cumPd) {
        // Map u within [0, cumPd] to default period 1..maturity
        const ratio = u / Math.max(1e-9, cumPd);
        const defPeriod = Math.min(
          totalPeriods - 1,
          Math.max(0, Math.floor(ratio * Math.min(totalPeriods, a.maturityPeriods)))
        );
        periodDefaultAmounts[defPeriod][aIdx] = a.principalOutstanding;
        const recJitter = sampleStandardNormal(rng) * 0.1;
        const sampledRec = Math.max(
          0.05,
          Math.min(0.95, a.assumedRecoveryRate * assumptions.recoveryMultiplier + recJitter)
        );
        periodRecoveryRates[defPeriod][aIdx] = sampledRec;
      }
    }

    const periodShocks = Array.from({ length: totalPeriods }, (_, pIdx) => ({
      assetDefaultAmounts: periodDefaultAmounts[pIdx],
      assetRecoveryRates: periodRecoveryRates[pIdx],
      baseRateOverrideBps: Math.max(0, assumptions.referenceRateBps + assumptions.rateShockBps + rateJitterBps),
    }));

    const pathRun = runContractualWaterfall({
      deal,
      assets,
      tranches: alignedTranches,
      rules,
      assumptions,
      periodShocks,
    });

    const netLoss = Math.max(0, pathRun.totalCollateralDefaults - pathRun.totalCollateralRecoveries);
    poolLossPctByPath.push((netLoss / totalPoolPrincipal) * 100);
    sumTotalDefaults += pathRun.totalCollateralDefaults;
    sumTotalRecoveries += pathRun.totalCollateralRecoveries;
    if (pathRun.ocBreachPeriods.length > 0) ocBreachPaths++;
    if (pathRun.icBreachPeriods.length > 0) icBreachPaths++;

    let pathHadLiquidityShortfall = false;
    const tranchePrinPaid = new Array(nTranches).fill(0);
    const trancheShortfall = new Array(nTranches).fill(0);
    const trancheLoss = new Array(nTranches).fill(0);

    for (let pIdx = 0; pIdx < pathRun.periods.length; pIdx++) {
      const pRes = pathRun.periods[pIdx];
      const tYears = (pIdx + 1) / periodsPerYear;
      for (let tIdx = 0; tIdx < nTranches; tIdx++) {
        const ts = pRes.trancheStates[tIdx];
        if (!ts) continue;
        tranchePrinPaid[tIdx] += ts.principalPaid;
        trancheShortfall[tIdx] += ts.interestShortfall;
        trancheLoss[tIdx] += ts.lossAllocated;
        if (ts.interestShortfall > 1) pathHadLiquidityShortfall = true;
        sumWalNumerator[tIdx] += ts.principalPaid * tYears;
        sumWalDenom[tIdx] += ts.principalPaid;
        sumCashFlowsPerTranche[tIdx][pIdx] += ts.interestPaid + ts.principalPaid;
      }
    }

    if (pathHadLiquidityShortfall) liquidityShortfallPaths++;

    for (let tIdx = 0; tIdx < nTranches; tIdx++) {
      const tr = alignedTranches[tIdx];
      let loss = trancheLoss[tIdx];
      if (deal.structureType === 'cash' && tr.seniority !== 'equity') {
        const unrecoveredBal = Math.max(0, tr.notional - tranchePrinPaid[tIdx]);
        loss = Math.max(loss, unrecoveredBal);
      } else if (tr.seniority === 'equity') {
        loss = Math.max(loss, Math.max(0, tr.notional - tranchePrinPaid[tIdx]));
      }
      sumPrincipalLoss[tIdx] += loss;
      trancheLossesByPath[tIdx].push((loss / Math.max(1, tr.notional)) * 100);
      if (loss > tr.notional * 0.001) impairCount[tIdx]++;
      sumInterestShortfall[tIdx] += trancheShortfall[tIdx];
      if (pathRun.ocBreachPeriods.length > 0 || pathRun.icBreachPeriods.length > 0) {
        breachExposedCount[tIdx]++;
      }
    }
  }

  poolLossPctByPath.sort((a, b) => a - b);
  const p95PoolLossPct = poolLossPctByPath[Math.min(poolLossPctByPath.length - 1, Math.floor(0.95 * numPaths))] ?? 0;
  const p99PoolLossPct = poolLossPctByPath[Math.min(poolLossPctByPath.length - 1, Math.floor(0.99 * numPaths))] ?? 0;
  const meanPoolLossPct = poolLossPctByPath.reduce((s, x) => s + x, 0) / Math.max(1, numPaths);

  const marketDiscountCurveBps =
    assumptions.riskFreeCurveBps +
    assumptions.liquidityPremiumBps +
    assumptions.marketSpreadAdjustmentBps;

  const trancheMetrics: TrancheSimulationMetrics[] = alignedTranches.map((tr, tIdx) => {
    const expLoss = sumPrincipalLoss[tIdx] / numPaths;
    const expLossPct = tr.notional > 0 ? (expLoss / tr.notional) * 100 : 0;
    const impProb = (impairCount[tIdx] / numPaths) * 100;
    const expShortfall = sumInterestShortfall[tIdx] / numPaths;
    const wal = sumWalDenom[tIdx] > 0 ? sumWalNumerator[tIdx] / sumWalDenom[tIdx] : totalPeriods / periodsPerYear;
    const meanCashFlows = sumCashFlowsPerTranche[tIdx].map((s) => s / numPaths);
    const issueOutlay = tr.isFunded ? tr.notional * (tr.issuePricePct / 100) : tr.notional;
    const realWorldIrrPct = computeAnnualizedIrr([-issueOutlay, ...meanCashFlows], periodsPerYear);

    const rMarketPerPeriod = marketDiscountCurveBps / 10000 / periodsPerYear;
    const discountedPv = meanCashFlows.reduce(
      (s, cf, idx) => s + cf / Math.pow(1 + rMarketPerPeriod, idx + 1),
      0
    );
    const discountedPricePct = tr.notional > 0 ? (discountedPv / tr.notional) * 100 : 0;
    const impliedSpreadBps = solveModelImpliedSpreadBps(
      meanCashFlows,
      issueOutlay,
      assumptions.riskFreeCurveBps,
      periodsPerYear
    );

    const sortedLosses = [...trancheLossesByPath[tIdx]].sort((a, b) => a - b);
    const p95LossPct = sortedLosses[Math.min(sortedLosses.length - 1, Math.floor(0.95 * numPaths))] ?? 0;
    const p99LossPct = sortedLosses[Math.min(sortedLosses.length - 1, Math.floor(0.99 * numPaths))] ?? 0;

    return {
      trancheId: tr.id,
      code: tr.code,
      seniority: tr.seniority,
      initialNotional: tr.notional,
      issuePricePct: tr.issuePricePct,
      attachmentPct: tr.attachmentPct,
      detachmentPct: tr.detachmentPct,
      isFunded: tr.isFunded,
      expectedPrincipalLoss: expLoss,
      expectedLossPct: expLossPct,
      probabilityOfImpairment: impProb,
      expectedInterestShortfall: expShortfall,
      weightedAverageLifeYears: wal,
      realWorldIrrPct,
      coverageBreachExposurePct: (breachExposedCount[tIdx] / numPaths) * 100,
      p95LossPct,
      p99LossPct,
      discountedPresentValue: discountedPv,
      discountedPricePct,
      modelImpliedSpreadBps: impliedSpreadBps,
    };
  });

  // Histogram bins (0-2%, 2-4%, ..., 18%+)
  const binEdges = [0, 2, 4, 6, 8, 10, 12, 15, 20, 100];
  const lossHistogram = binEdges.slice(0, -1).map((minPct, i) => {
    const maxPct = binEdges[i + 1];
    const count = poolLossPctByPath.filter((v) => v >= minPct && (i === binEdges.length - 2 ? v <= maxPct : v < maxPct)).length;
    return {
      bucketLabel: maxPct === 100 ? `${minPct}%+` : `${minPct}-${maxPct}%`,
      minPct,
      maxPct,
      pathCount: count,
      probabilityPct: (count / numPaths) * 100,
    };
  });

  const debtTranches = alignedTranches.filter((t) => t.seniority !== 'equity');
  const debtNotional = debtTranches.reduce((s, t) => s + t.notional, 0) || 1;
  const wAvgDebtCostBps = debtTranches.reduce(
    (s, t) =>
      s +
      (t.notional / debtNotional) *
        (t.couponType === 'floating' ? assumptions.referenceRateBps + t.spreadOrCouponBps : t.spreadOrCouponBps),
    0
  );
  const avgAssetYieldBps =
    assets.reduce((s, a) => {
      const c = a.interestType === 'floating' ? assumptions.referenceRateBps + a.spreadOrCouponBps : a.spreadOrCouponBps;
      return s + (a.principalOutstanding / totalPoolPrincipal) * c;
    }, 0);

  return {
    id: `sim_${seed}_${Date.now()}`,
    dealId: deal.id,
    structureId: deal.activeStructureId,
    scenarioName,
    modelVersion: MODEL_VERSION,
    seed,
    numPaths,
    assumptionsSnapshot: { ...assumptions },
    trancheMetrics,
    summaryMetrics: {
      meanPoolLossPct,
      p95PoolLossPct,
      p99PoolLossPct,
      meanTotalDefaults: sumTotalDefaults / numPaths,
      meanTotalRecoveries: sumTotalRecoveries / numPaths,
      ocBreachPathPct: (ocBreachPaths / numPaths) * 100,
      icBreachPathPct: (icBreachPaths / numPaths) * 100,
      liquidityShortfallPathPct: (liquidityShortfallPaths / numPaths) * 100,
      issuerNetFundingSpreadBps: Math.round(avgAssetYieldBps - wAvgDebtCostBps),
      executionTimeMs: Date.now() - startTime,
    },
    lossHistogram,
    deterministicBase,
    createdAt: new Date().toISOString(),
  };
}

export function optimizeCapitalStructure(params: {
  deal: DealRecord;
  assets: CollateralAsset[];
  baseTranches: TrancheDefinition[];
  rules: WaterfallRule[];
  assumptions: DealAssumptions;
  constraints: OptimizationConstraints;
}): OptimizationCandidate[] {
  const { deal, assets, baseTranches, rules, assumptions, constraints } = params;
  const totalPool = assets.reduce((s, a) => s + a.principalOutstanding, 0) || deal.targetPoolNotional;

  // Grid search over feasible senior/mezz/junior/equity splits and reserve ratios
  const grid = [
    { label: 'Conservative Senior 64 / Mezz 16 / Jun 10 / Eq 10', seniorPct: 64, mezzPct: 16, juniorPct: 10, equityPct: 10, reservePct: 2.0 },
    { label: 'Balanced Senior 70 / Mezz 13 / Jun 8 / Eq 9', seniorPct: 70, mezzPct: 13, juniorPct: 8, equityPct: 9, reservePct: 1.5 },
    { label: 'Target Senior 72 / Mezz 12 / Jun 8 / Eq 8', seniorPct: 72, mezzPct: 12, juniorPct: 8, equityPct: 8, reservePct: 1.5 },
    { label: 'Enhanced Equity 74 / Mezz 12 / Jun 7 / Eq 7', seniorPct: 74, mezzPct: 12, juniorPct: 7, equityPct: 7, reservePct: 1.25 },
    { label: 'High-Leverage 78 / Mezz 11 / Jun 6 / Eq 5', seniorPct: 78, mezzPct: 11, juniorPct: 6, equityPct: 5, reservePct: 1.0 },
    { label: 'Thick Mezz Cushion 68 / Mezz 16 / Jun 9 / Eq 7', seniorPct: 68, mezzPct: 16, juniorPct: 9, equityPct: 7, reservePct: 1.75 },
  ];

  const results: OptimizationCandidate[] = [];

  for (let i = 0; i < grid.length; i++) {
    const g = grid[i];
    const seniorTemplate = baseTranches.find((t) => t.seniority === 'senior') ?? baseTranches[0];
    const mezzTemplate = baseTranches.find((t) => t.seniority === 'mezzanine') ?? baseTranches[1] ?? baseTranches[0];
    const juniorTemplate = baseTranches.find((t) => t.seniority === 'junior') ?? baseTranches[2] ?? baseTranches[0];
    const equityTemplate = baseTranches.find((t) => t.seniority === 'equity') ?? baseTranches[baseTranches.length - 1];

    const candTranches: TrancheDefinition[] = recomputeAttachmentPoints(
      [
        { ...seniorTemplate, id: 'opt_sr', code: 'Class A Senior', seniority: 'senior', notional: totalPool * (g.seniorPct / 100), paymentPriority: 1, principalPriority: 1, lossAllocationOrder: 1 },
        { ...mezzTemplate, id: 'opt_mz', code: 'Class B Mezzanine', seniority: 'mezzanine', notional: totalPool * (g.mezzPct / 100), paymentPriority: 2, principalPriority: 2, lossAllocationOrder: 2 },
        { ...juniorTemplate, id: 'opt_jr', code: 'Class C Junior', seniority: 'junior', notional: totalPool * (g.juniorPct / 100), paymentPriority: 3, principalPriority: 3, lossAllocationOrder: 3 },
        { ...equityTemplate, id: 'opt_eq', code: 'Subordinated Equity', seniority: 'equity', notional: totalPool * (g.equityPct / 100), paymentPriority: 4, principalPriority: 4, lossAllocationOrder: 4 },
      ],
      totalPool
    );

    const candDeal: DealRecord = {
      ...deal,
      reserveTarget: totalPool * (g.reservePct / 100),
      reserveBalance: totalPool * (g.reservePct / 100),
    };

    const candRules = rules.map((r) => {
      if (r.trancheId && baseTranches.find((bt) => bt.id === r.trancheId)?.seniority === 'senior') {
        return { ...r, trancheId: 'opt_sr' };
      }
      if (r.trancheId && baseTranches.find((bt) => bt.id === r.trancheId)?.seniority === 'mezzanine') {
        return { ...r, trancheId: 'opt_mz' };
      }
      if (r.trancheId && baseTranches.find((bt) => bt.id === r.trancheId)?.seniority === 'junior') {
        return { ...r, trancheId: 'opt_jr' };
      }
      return r;
    });

    const sim = runMonteCarloSimulation({
      deal: candDeal,
      assets,
      tranches: candTranches,
      rules: candRules,
      assumptions,
      scenarioName: g.label,
      seed: 4200 + i,
      numPaths: 150,
    });

    // Sensitivity 1: +50% PD multiplier
    const simPdStress = runMonteCarloSimulation({
      deal: candDeal,
      assets,
      tranches: candTranches,
      rules: candRules,
      assumptions: { ...assumptions, pdMultiplier: assumptions.pdMultiplier * 1.5 },
      scenarioName: `${g.label} (PD +50%)`,
      seed: 4200 + i,
      numPaths: 100,
    });

    // Sensitivity 2: +0.20 Default Correlation
    const simRhoStress = runMonteCarloSimulation({
      deal: candDeal,
      assets,
      tranches: candTranches,
      rules: candRules,
      assumptions: { ...assumptions, defaultCorrelationRho: Math.min(0.85, assumptions.defaultCorrelationRho + 0.2) },
      scenarioName: `${g.label} (Rho +0.20)`,
      seed: 4200 + i,
      numPaths: 100,
    });

    const sr = sim.trancheMetrics[0];
    const eq = sim.trancheMetrics[sim.trancheMetrics.length - 1];
    const eqStress = simPdStress.trancheMetrics[simPdStress.trancheMetrics.length - 1];
    const srRhoStress = simRhoStress.trancheMetrics[0];

    const ratedNotional = totalPool * ((g.seniorPct + g.mezzPct) / 100);
    const ocRatio = (totalPool + candDeal.reserveBalance) / Math.max(1, ratedNotional);
    const ocCushionPct = (ocRatio - deal.ocTriggerRatio) * 100;

    const debtWeightedCostBps =
      (g.seniorPct * (assumptions.referenceRateBps + seniorTemplate.spreadOrCouponBps) +
        g.mezzPct * (assumptions.referenceRateBps + mezzTemplate.spreadOrCouponBps) +
        g.juniorPct * (assumptions.referenceRateBps + juniorTemplate.spreadOrCouponBps)) /
      Math.max(1, g.seniorPct + g.mezzPct + g.juniorPct);

    const feasible =
      sr.probabilityOfImpairment <= constraints.maxSeniorImpairmentProb &&
      sr.weightedAverageLifeYears <= constraints.maxSeniorWalYears &&
      eq.realWorldIrrPct >= constraints.minEquityIrrPct &&
      ocCushionPct >= constraints.minOcCushionPct &&
      g.reservePct >= constraints.minReservePct;

    const objectiveScore =
      (feasible ? 100 : 0) +
      eq.realWorldIrrPct * 2.2 -
      sr.probabilityOfImpairment * 8.0 -
      debtWeightedCostBps * 0.04 +
      ocCushionPct * 0.5;

    results.push({
      id: `opt_cand_${i}`,
      label: g.label,
      seniorPct: g.seniorPct,
      mezzPct: g.mezzPct,
      juniorPct: g.juniorPct,
      equityPct: g.equityPct,
      reservePct: g.reservePct,
      seniorImpairmentProb: sr.probabilityOfImpairment,
      seniorWalYears: sr.weightedAverageLifeYears,
      equityIrrPct: eq.realWorldIrrPct,
      weightedAvgCostOfDebtBps: Math.round(debtWeightedCostBps),
      ocCushionPct,
      feasible,
      objectiveScore: Math.round(objectiveScore * 100) / 100,
      sensitivityDeltaEquityIrrOnPdPlus50: Math.round((eqStress.realWorldIrrPct - eq.realWorldIrrPct) * 100) / 100,
      sensitivityDeltaSeniorLossOnRhoPlus20: Math.round((srRhoStress.expectedLossPct - sr.expectedLossPct) * 1000) / 1000,
    });
  }

  return results.sort((a, b) => b.objectiveScore - a.objectiveScore);
}
