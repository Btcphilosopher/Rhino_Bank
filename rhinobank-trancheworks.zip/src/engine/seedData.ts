import type {
  ApprovalRequestRecord,
  CollateralAsset,
  CollateralTape,
  DealAssumptions,
  DealRecord,
  DealStructure,
  SurveillancePeriodRecord,
  TrancheDefinition,
  WaterfallRule,
} from './types.ts';
import { recomputeAttachmentPoints } from './waterfall.ts';

export const DEFAULT_BASE_ASSUMPTIONS: DealAssumptions = {
  pdMultiplier: 1.0,
  recoveryMultiplier: 1.0,
  prepaymentCprMultiplier: 1.0,
  defaultCorrelationRho: 0.24,
  clusterShockFactor: 1.0,
  referenceRateBps: 425,
  rateShockBps: 0,
  reinvestmentPricePct: 99.5,
  riskFreeCurveBps: 410,
  liquidityPremiumBps: 45,
  marketSpreadAdjustmentBps: 120,
};

function generateSemiconductorAssets(): CollateralAsset[] {
  const templates: {
    obligor: string;
    group: string;
    sharedDep: string;
    sector: string;
    geo: string;
    principal: number;
    spreadBps: number;
    matQ: number;
    security: string;
    seniority: CollateralAsset['seniority'];
    pd: number;
    rec: number;
    lag: number;
    cpr: number;
    delinq: CollateralAsset['delinquencyStatus'];
    intType: 'fixed' | 'floating';
  }[] = [
    { obligor: 'Hsinchu Wafer Litho Corp', group: 'Hsinchu Precision Holdings', sharedDep: 'EUV Lithography Supply Chain', sector: 'Wafer Fabrication Tools', geo: 'Taiwan', principal: 3500000, spreadBps: 365, matQ: 20, security: 'First Lien EUV Stepper Equipment', seniority: 'senior_secured', pd: 0.014, rec: 0.68, lag: 2, cpr: 0.06, delinq: 'current', intType: 'floating' },
    { obligor: 'Taichung Metrology Systems Ltd', group: 'Hsinchu Precision Holdings', sharedDep: 'EUV Lithography Supply Chain', sector: 'Inspection & Metrology', geo: 'Taiwan', principal: 2600000, spreadBps: 390, matQ: 18, security: 'First Lien Wafer Inspection Fleet', seniority: 'senior_secured', pd: 0.017, rec: 0.65, lag: 2, cpr: 0.06, delinq: 'current', intType: 'floating' },
    { obligor: 'Kansai UltraPure Quartz KK', group: 'Kansai Silicon Group', sharedDep: 'EUV Lithography Supply Chain', sector: 'Photomask & Substrates', geo: 'Japan', principal: 2800000, spreadBps: 345, matQ: 20, security: 'First Lien Cleanroom & Crucible Plant', seniority: 'senior_secured', pd: 0.012, rec: 0.70, lag: 2, cpr: 0.05, delinq: 'current', intType: 'fixed' },
    { obligor: 'Osaka CryoPumps Mfg KK', group: 'Kansai Silicon Group', sharedDep: 'AI HBM Packaging Cluster', sector: 'Vacuum & Thermal Systems', geo: 'Japan', principal: 2400000, spreadBps: 380, matQ: 16, security: 'Equipment Chattel Mortgage', seniority: 'senior_secured', pd: 0.016, rec: 0.64, lag: 2, cpr: 0.07, delinq: 'current', intType: 'floating' },
    { obligor: 'Phoenix Fab Infrastructure LLC', group: 'Sonoran Fab Holdings', sharedDep: 'US CHIPS Foundry Buildout', sector: 'Cleanroom & UPW Utilities', geo: 'United States', principal: 3000000, spreadBps: 410, matQ: 24, security: 'Project Receivables & Plant Lien', seniority: 'senior_secured', pd: 0.019, rec: 0.66, lag: 2, cpr: 0.05, delinq: 'current', intType: 'floating' },
    { obligor: 'Chandler Gas Abatement Inc', group: 'Sonoran Fab Holdings', sharedDep: 'US CHIPS Foundry Buildout', sector: 'Fab Abatement & Chemical', geo: 'United States', principal: 2600000, spreadBps: 435, matQ: 16, security: 'First Lien Equipment Lease Pool', seniority: 'senior_secured', pd: 0.024, rec: 0.60, lag: 3, cpr: 0.08, delinq: 'current', intType: 'floating' },
    { obligor: 'Stuttgart SiC Boule GmbH', group: 'Stuttgart Power Semi AG', sharedDep: 'Automotive SiC Powertrain', sector: 'SiC & GaN Substrates', geo: 'Germany', principal: 3600000, spreadBps: 425, matQ: 20, security: 'First Lien Crystal Growth Furnaces', seniority: 'senior_secured', pd: 0.022, rec: 0.62, lag: 2, cpr: 0.06, delinq: 'current', intType: 'floating' },
    { obligor: 'Dresden Epitaxy Services GmbH', group: 'Stuttgart Power Semi AG', sharedDep: 'Automotive SiC Powertrain', sector: 'Epitaxial Deposition', geo: 'Germany', principal: 2800000, spreadBps: 455, matQ: 18, security: 'Senior Secured Tooling Facility', seniority: 'senior_secured', pd: 0.026, rec: 0.58, lag: 3, cpr: 0.07, delinq: '30dpd', intType: 'floating' },
    { obligor: 'Suwon HBM Interconnect Co', group: 'Gyeonggi Packaging Group', sharedDep: 'AI HBM Packaging Cluster', sector: 'Advanced Packaging & TSV', geo: 'South Korea', principal: 4200000, spreadBps: 395, matQ: 20, security: 'First Lien Hybrid Bonding Lines', seniority: 'senior_secured', pd: 0.018, rec: 0.64, lag: 2, cpr: 0.07, delinq: 'current', intType: 'floating' },
    { obligor: 'Incheon Thermal Substrates Ltd', group: 'Gyeonggi Packaging Group', sharedDep: 'AI HBM Packaging Cluster', sector: 'ABF & Interposer Substrates', geo: 'South Korea', principal: 3100000, spreadBps: 440, matQ: 16, security: 'Second Lien Fab Capacity Loan', seniority: 'second_lien', pd: 0.031, rec: 0.48, lag: 3, cpr: 0.08, delinq: 'current', intType: 'floating' },
    { obligor: 'Eindhoven Optical Modules BV', group: 'Brabant Photonics NV', sharedDep: 'EUV Lithography Supply Chain', sector: 'Lithography Optics', geo: 'Netherlands', principal: 4100000, spreadBps: 350, matQ: 24, security: 'First Lien Precision Mirror Tooling', seniority: 'senior_secured', pd: 0.013, rec: 0.72, lag: 2, cpr: 0.04, delinq: 'current', intType: 'fixed' },
    { obligor: 'Leuven NanoEtch NV', group: 'Brabant Photonics NV', sharedDep: 'EUV Lithography Supply Chain', sector: 'Atomic Layer Etch', geo: 'Belgium', principal: 2400000, spreadBps: 415, matQ: 16, security: 'First Lien ALD Reactor Leases', seniority: 'senior_secured', pd: 0.021, rec: 0.61, lag: 2, cpr: 0.06, delinq: 'current', intType: 'floating' },
    { obligor: 'Austin Wafer Test Robotics Inc', group: 'LoneStar Semi Capital', sharedDep: 'AI HBM Packaging Cluster', sector: 'Automated Test Handlers', geo: 'United States', principal: 3300000, spreadBps: 460, matQ: 14, security: 'First Lien ATE Tester Fleet', seniority: 'senior_secured', pd: 0.025, rec: 0.59, lag: 2, cpr: 0.09, delinq: 'current', intType: 'floating' },
    { obligor: 'San Jose CoWoS Tooling Corp', group: 'Silicon Valley Fab Credit', sharedDep: 'AI HBM Packaging Cluster', sector: 'Die Bonders & Reflow', geo: 'United States', principal: 3500000, spreadBps: 430, matQ: 18, security: 'First Lien Packaging Lines', seniority: 'senior_secured', pd: 0.023, rec: 0.62, lag: 2, cpr: 0.07, delinq: 'current', intType: 'floating' },
    { obligor: 'Penang OSAT Assembly Sdn Bhd', group: 'Malacca Straits OSAT', sharedDep: 'Automotive SiC Powertrain', sector: 'OSAT Back-End Assembly', geo: 'Malaysia', principal: 2700000, spreadBps: 485, matQ: 16, security: 'First Lien Wire-Bond & Mold Lines', seniority: 'senior_secured', pd: 0.032, rec: 0.54, lag: 3, cpr: 0.08, delinq: 'current', intType: 'floating' },
    { obligor: 'Singapore Wafer Fab Logistics Pte', group: 'Malacca Straits OSAT', sharedDep: 'None', sector: 'Cleanroom Automation', geo: 'Singapore', principal: 2300000, spreadBps: 390, matQ: 20, security: 'FOUP AMHS Rail Equipment Lien', seniority: 'senior_secured', pd: 0.018, rec: 0.63, lag: 2, cpr: 0.06, delinq: 'current', intType: 'floating' },
    { obligor: 'Kumamoto Photoresist Chem KK', group: 'Kyushu Specialty Materials', sharedDep: 'EUV Lithography Supply Chain', sector: 'EUV Photoresists & Slurry', geo: 'Japan', principal: 3400000, spreadBps: 375, matQ: 20, security: 'First Lien Synthesis Reactors', seniority: 'senior_secured', pd: 0.015, rec: 0.66, lag: 2, cpr: 0.05, delinq: 'current', intType: 'fixed' },
    { obligor: 'Fukuoka CMP Pad Systems KK', group: 'Kyushu Specialty Materials', sharedDep: 'None', sector: 'CMP Planarization', geo: 'Japan', principal: 2100000, spreadBps: 420, matQ: 14, security: 'Senior Unsecured Working Capital', seniority: 'senior_unsecured', pd: 0.028, rec: 0.45, lag: 3, cpr: 0.07, delinq: 'current', intType: 'floating' },
    { obligor: 'Grenoble SOI Substrates SAS', group: 'Isere Silicon Partners', sharedDep: 'Automotive SiC Powertrain', sector: 'FD-SOI Wafers', geo: 'France', principal: 2900000, spreadBps: 410, matQ: 20, security: 'First Lien Bonding & Anneal Tools', seniority: 'senior_secured', pd: 0.020, rec: 0.62, lag: 2, cpr: 0.06, delinq: 'current', intType: 'floating' },
    { obligor: 'Catania Power Fab Tooling Srl', group: 'Isere Silicon Partners', sharedDep: 'Automotive SiC Powertrain', sector: 'Power Semi Wafer Tools', geo: 'Italy', principal: 2400000, spreadBps: 495, matQ: 16, security: 'Second Lien Ion Implanter Loan', seniority: 'second_lien', pd: 0.035, rec: 0.46, lag: 3, cpr: 0.08, delinq: '60dpd', intType: 'floating' },
    { obligor: 'Boise DRAM Cryo-Etch Inc', group: 'Intermountain Memory Ops', sharedDep: 'AI HBM Packaging Cluster', sector: 'High-Aspect Cryo Etch', geo: 'United States', principal: 3700000, spreadBps: 405, matQ: 22, security: 'First Lien Etch Chamber Leases', seniority: 'senior_secured', pd: 0.019, rec: 0.65, lag: 2, cpr: 0.06, delinq: 'current', intType: 'floating' },
    { obligor: 'Columbus Fab HVAC & Chiller LLC', group: 'Midwest Fab Infrastructure', sharedDep: 'US CHIPS Foundry Buildout', sector: 'Cleanroom & UPW Utilities', geo: 'United States', principal: 2800000, spreadBps: 420, matQ: 20, security: 'First Lien Sub-Fab Utility Plant', seniority: 'senior_secured', pd: 0.021, rec: 0.63, lag: 2, cpr: 0.05, delinq: 'current', intType: 'fixed' },
    { obligor: 'Kaohsiung Leadframe & Mold Corp', group: 'Formosa Back-End Group', sharedDep: 'Automotive SiC Powertrain', sector: 'OSAT Back-End Assembly', geo: 'Taiwan', principal: 2100000, spreadBps: 510, matQ: 12, security: 'First Lien Molding Presses', seniority: 'senior_secured', pd: 0.036, rec: 0.52, lag: 3, cpr: 0.09, delinq: 'current', intType: 'floating' },
    { obligor: 'Tainan Reticle Inspection Co', group: 'Formosa Back-End Group', sharedDep: 'EUV Lithography Supply Chain', sector: 'Inspection & Metrology', geo: 'Taiwan', principal: 2600000, spreadBps: 445, matQ: 16, security: 'First Lien Reticle Defect Scanners', seniority: 'senior_secured', pd: 0.024, rec: 0.60, lag: 2, cpr: 0.07, delinq: 'current', intType: 'floating' },
    { obligor: 'Hillsboro Plasma Deposition Inc', group: 'Pacific NW Tooling Trust', sharedDep: 'US CHIPS Foundry Buildout', sector: 'PVD & CVD Deposition', geo: 'United States', principal: 3200000, spreadBps: 385, matQ: 20, security: 'First Lien PVD Cluster Tools', seniority: 'senior_secured', pd: 0.017, rec: 0.66, lag: 2, cpr: 0.06, delinq: 'current', intType: 'floating' },
    { obligor: 'Syracuse Substrate Polishing LLC', group: 'Midwest Fab Infrastructure', sharedDep: 'US CHIPS Foundry Buildout', sector: 'Wafer Slicing & Polish', geo: 'United States', principal: 1900000, spreadBps: 525, matQ: 14, security: 'Senior Unsecured Term Facility', seniority: 'senior_unsecured', pd: 0.038, rec: 0.42, lag: 3, cpr: 0.08, delinq: 'current', intType: 'floating' },
    { obligor: 'Munich GaN Foundry Systems AG', group: 'Bavaria Microelectronics', sharedDep: 'Automotive SiC Powertrain', sector: 'SiC & GaN Substrates', geo: 'Germany', principal: 2500000, spreadBps: 465, matQ: 18, security: 'First Lien MOCVD Epitaxy Reactors', seniority: 'senior_secured', pd: 0.027, rec: 0.58, lag: 2, cpr: 0.06, delinq: 'current', intType: 'floating' },
    { obligor: 'Zurich RF Acoustic Filter SA', group: 'Helvetia Micro Devices', sharedDep: 'None', sector: 'MEMS & RF Wafer Fab', geo: 'Switzerland', principal: 2200000, spreadBps: 360, matQ: 20, security: 'First Lien Thin-Film Acoustic Line', seniority: 'senior_secured', pd: 0.014, rec: 0.68, lag: 2, cpr: 0.05, delinq: 'current', intType: 'fixed' },
    { obligor: 'Yokohama Probe Card Tech KK', group: 'Kanto Test & Probe', sharedDep: 'AI HBM Packaging Cluster', sector: 'Wafer Probe & Burn-In', geo: 'Japan', principal: 1800000, spreadBps: 470, matQ: 12, security: 'First Lien MEMS Probe Array Tools', seniority: 'senior_secured', pd: 0.029, rec: 0.56, lag: 2, cpr: 0.09, delinq: 'current', intType: 'floating' },
    { obligor: 'Seoul Laser Dicing Systems Co', group: 'Gyeonggi Packaging Group', sharedDep: 'AI HBM Packaging Cluster', sector: 'Stealth Dicing & Singulation', geo: 'South Korea', principal: 1700000, spreadBps: 490, matQ: 14, security: 'First Lien Laser Dicing Fleet', seniority: 'senior_secured', pd: 0.033, rec: 0.55, lag: 3, cpr: 0.08, delinq: 'current', intType: 'floating' },
    { obligor: 'Pyeongtaek Fab Clean-Gas Co', group: 'Han River Fab Utilities', sharedDep: 'AI HBM Packaging Cluster', sector: 'Cleanroom & UPW Utilities', geo: 'South Korea', principal: 2100000, spreadBps: 415, matQ: 20, security: 'First Lien Bulk Specialty Gas Plant', seniority: 'senior_secured', pd: 0.020, rec: 0.63, lag: 2, cpr: 0.05, delinq: 'current', intType: 'floating' },
    { obligor: 'Malta Upstate Thermal Bake LLC', group: 'Sonoran Fab Holdings', sharedDep: 'US CHIPS Foundry Buildout', sector: 'Rapid Thermal Processing', geo: 'United States', principal: 1600000, spreadBps: 460, matQ: 16, security: 'First Lien RTP Furnace Leases', seniority: 'senior_secured', pd: 0.026, rec: 0.59, lag: 2, cpr: 0.07, delinq: 'current', intType: 'floating' },
    { obligor: 'Nagasaki CIS Sensor Fab KK', group: 'Kyushu Specialty Materials', sharedDep: 'None', sector: 'Image Sensor Litho', geo: 'Japan', principal: 2400000, spreadBps: 400, matQ: 18, security: 'First Lien Color Filter Track Tools', seniority: 'senior_secured', pd: 0.018, rec: 0.64, lag: 2, cpr: 0.06, delinq: 'current', intType: 'fixed' },
    { obligor: 'Kulim Analog Wafer Leasing Bhd', group: 'Malacca Straits OSAT', sharedDep: 'Automotive SiC Powertrain', sector: '200mm Analog Fab Tools', geo: 'Malaysia', principal: 1500000, spreadBps: 540, matQ: 12, security: 'Subordinated Mezzanine Equipment Note', seniority: 'subordinated', pd: 0.044, rec: 0.38, lag: 3, cpr: 0.08, delinq: '30dpd', intType: 'floating' },
    { obligor: 'Bristol Compound Semi Foundry', group: 'Albion Photonics Ltd', sharedDep: 'Automotive SiC Powertrain', sector: 'SiC & GaN Substrates', geo: 'United Kingdom', principal: 1400000, spreadBps: 480, matQ: 16, security: 'First Lien InP/GaN Epitaxy Line', seniority: 'senior_secured', pd: 0.030, rec: 0.57, lag: 2, cpr: 0.07, delinq: 'current', intType: 'floating' },
    { obligor: 'Fremont Ion Implant Leasing Co', group: 'Silicon Valley Fab Credit', sharedDep: 'US CHIPS Foundry Buildout', sector: 'Ion Implantation', geo: 'United States', principal: 1600000, spreadBps: 445, matQ: 16, security: 'First Lien High-Current Implanters', seniority: 'senior_secured', pd: 0.025, rec: 0.60, lag: 2, cpr: 0.07, delinq: 'current', intType: 'floating' },
    { obligor: 'Zhubei Wafer Reclaim Corp', group: 'Hsinchu Precision Holdings', sharedDep: 'EUV Lithography Supply Chain', sector: 'Wafer Reclaim & Recycling', geo: 'Taiwan', principal: 1300000, spreadBps: 455, matQ: 14, security: 'First Lien Reclaim Wet-Bench Line', seniority: 'senior_secured', pd: 0.027, rec: 0.58, lag: 2, cpr: 0.08, delinq: 'current', intType: 'floating' },
    { obligor: 'Toulouse Aerospace Rad-Hard Fab', group: 'Isere Silicon Partners', sharedDep: 'None', sector: 'Specialty Rad-Hard CMOS', geo: 'France', principal: 1500000, spreadBps: 430, matQ: 20, security: 'First Lien Specialty Fab Equipment', seniority: 'senior_secured', pd: 0.021, rec: 0.62, lag: 2, cpr: 0.05, delinq: 'current', intType: 'fixed' },
    { obligor: 'Burlington Mask Writer Systems', group: 'LoneStar Semi Capital', sharedDep: 'EUV Lithography Supply Chain', sector: 'Mask Inspection & Writing', geo: 'United States', principal: 1400000, spreadBps: 440, matQ: 18, security: 'First Lien Multi-Beam Mask Writer', seniority: 'senior_secured', pd: 0.022, rec: 0.63, lag: 2, cpr: 0.06, delinq: 'current', intType: 'floating' },
    { obligor: 'Gumi Silicon Ingot Pullers Co', group: 'Han River Fab Utilities', sharedDep: 'None', sector: 'Czochralski Ingot Growers', geo: 'South Korea', principal: 1000000, spreadBps: 505, matQ: 12, security: 'Second Lien Ingot Furnace Facility', seniority: 'second_lien', pd: 0.039, rec: 0.44, lag: 3, cpr: 0.09, delinq: 'current', intType: 'floating' },
  ];

  // Verify exact sum = 100,000,000
  return templates.map((t, i) => ({
    assetId: `SEMI-${String(i + 1).padStart(3, '0')}`,
    obligorId: `OBL-S-${String(i + 1).padStart(3, '0')}`,
    obligorName: t.obligor,
    economicGroup: t.group,
    sharedDependency: t.sharedDep,
    sector: t.sector,
    geography: t.geo,
    currency: 'USD',
    principalOutstanding: t.principal,
    interestType: t.intType,
    baseRateBps: t.intType === 'floating' ? 425 : 0,
    spreadOrCouponBps: t.intType === 'floating' ? t.spreadBps : t.spreadBps + 410,
    paymentSchedule: 'quarterly',
    originationDate: '2026-01-15',
    maturityDate: `${2026 + Math.ceil(t.matQ / 4)}-01-15`,
    maturityPeriods: t.matQ,
    securityType: t.security,
    seniority: t.seniority,
    delinquencyStatus: t.delinq,
    assumedAnnualPd: t.pd,
    assumedRecoveryRate: t.rec,
    assumedRecoveryLagPeriods: t.lag,
    assumedPrepaymentCpr: t.cpr,
    correlationBeta: t.sharedDep === 'None' ? 0.32 : 0.56,
  }));
}

function generateCorporateDebtAssets(): CollateralAsset[] {
  const sectors = ['Aerospace & Defense', 'Enterprise Software', 'Healthcare Services', 'Specialty Chemicals', 'Industrial Automation'];
  const geos = ['United States', 'Germany', 'United Kingdom', 'France', 'Netherlands'];
  const assets: CollateralAsset[] = [];
  for (let i = 0; i < 25; i++) {
    assets.push({
      assetId: `CORP-${String(i + 1).padStart(3, '0')}`,
      obligorId: `OBL-C-${String(i + 1).padStart(3, '0')}`,
      obligorName: `Apex Borrower ${i + 1} Holdings`,
      economicGroup: `Apex Sponsor Group ${Math.floor(i / 2) + 1}`,
      sharedDependency: i % 4 === 0 ? 'European Energy Input Costs' : 'None',
      sector: sectors[i % sectors.length],
      geography: geos[i % geos.length],
      currency: 'USD',
      principalOutstanding: 4000000,
      interestType: 'floating',
      baseRateBps: 425,
      spreadOrCouponBps: 385 + (i % 6) * 25,
      paymentSchedule: 'quarterly',
      originationDate: '2026-02-01',
      maturityDate: '2031-02-01',
      maturityPeriods: 20,
      securityType: i % 5 === 4 ? 'Second Lien Term Loan B' : 'First Lien Senior Secured TLB',
      seniority: i % 5 === 4 ? 'second_lien' : 'senior_secured',
      delinquencyStatus: i === 22 ? '30dpd' : 'current',
      assumedAnnualPd: 0.021 + (i % 5) * 0.004,
      assumedRecoveryRate: i % 5 === 4 ? 0.42 : 0.62,
      assumedRecoveryLagPeriods: 2,
      assumedPrepaymentCpr: 0.12,
      correlationBeta: 0.42,
    });
  }
  return assets;
}

function generateEquipmentFinanceAssets(): CollateralAsset[] {
  const sectors = ['Intermodal Rail & Chassis', 'Automated Port Cranes', 'Cold-Chain Logistics Fleets', 'Medical Imaging Suites', 'Precision CNC Tooling'];
  const geos = ['United States', 'Canada', 'Germany', 'Singapore', 'United Kingdom'];
  const assets: CollateralAsset[] = [];
  for (let i = 0; i < 20; i++) {
    assets.push({
      assetId: `EQPT-${String(i + 1).padStart(3, '0')}`,
      obligorId: `OBL-E-${String(i + 1).padStart(3, '0')}`,
      obligorName: `Vanguard Fleet Lessee ${i + 1}`,
      economicGroup: `Vanguard Operator Cluster ${Math.floor(i / 2) + 1}`,
      sharedDependency: i % 3 === 0 ? 'Trans-Pacific Freight Volume' : 'None',
      sector: sectors[i % sectors.length],
      geography: geos[i % geos.length],
      currency: 'USD',
      principalOutstanding: 5000000,
      interestType: 'fixed',
      baseRateBps: 0,
      spreadOrCouponBps: 760 + (i % 4) * 30,
      paymentSchedule: 'quarterly',
      originationDate: '2026-01-10',
      maturityDate: '2030-01-10',
      maturityPeriods: 16,
      securityType: 'Perfected Equipment Lease Chattel',
      seniority: 'senior_secured',
      delinquencyStatus: 'current',
      assumedAnnualPd: 0.017 + (i % 4) * 0.003,
      assumedRecoveryRate: 0.68,
      assumedRecoveryLagPeriods: 2,
      assumedPrepaymentCpr: 0.06,
      correlationBeta: 0.38,
    });
  }
  return assets;
}

export function buildStandardCashWaterfallRules(tranches: TrancheDefinition[]): WaterfallRule[] {
  const sr = tranches.filter((t) => t.seniority === 'senior');
  const mz = tranches.filter((t) => t.seniority === 'mezzanine');
  const jr = tranches.filter((t) => t.seniority === 'junior');
  const rules: WaterfallRule[] = [];
  let p = 1;

  rules.push({
    id: 'wf_trustee_fee',
    priority: p++,
    name: 'Trustee & Collateral Admin Fixed Fee',
    account: 'interest',
    ruleType: 'fee_expense',
    condition: 'always',
    sourceAccount: 'interest',
    destination: 'Trustee & Admin Expense Account',
    calculationMethod: 'fixed_amount',
    repaymentMode: 'sequential',
    shortfallTreatment: 'draw_reserve',
    fixedAmount: 180000,
  });

  rules.push({
    id: 'wf_servicing_fee',
    priority: p++,
    name: 'Senior Collateral Management Fee (45 bps)',
    account: 'interest',
    ruleType: 'fee_expense',
    condition: 'always',
    sourceAccount: 'interest',
    destination: 'Collateral Manager',
    calculationMethod: 'bps_of_pool',
    repaymentMode: 'sequential',
    shortfallTreatment: 'unpaid_shortfall',
    bpsRate: 45,
  });

  for (const t of sr) {
    rules.push({
      id: `wf_int_${t.id}`,
      priority: p++,
      name: `${t.code} Senior Note Interest`,
      account: 'interest',
      ruleType: 'senior_interest',
      condition: 'always',
      sourceAccount: 'interest',
      destination: t.code,
      trancheId: t.id,
      calculationMethod: 'accrued_coupon',
      repaymentMode: 'sequential',
      shortfallTreatment: 'draw_reserve',
    });
  }

  rules.push({
    id: 'wf_reserve_topup',
    priority: p++,
    name: 'Liquidity Reserve Account Top-Up',
    account: 'interest',
    ruleType: 'reserve_funding',
    condition: 'always',
    sourceAccount: 'interest',
    destination: 'Cash Reserve Account',
    calculationMethod: 'reserve_topup',
    repaymentMode: 'sequential',
    shortfallTreatment: 'unpaid_shortfall',
  });

  for (const t of mz) {
    rules.push({
      id: `wf_int_${t.id}`,
      priority: p++,
      name: `${t.code} Mezzanine Interest`,
      account: 'interest',
      ruleType: 'sub_interest',
      condition: 'test_pass',
      sourceAccount: 'interest',
      destination: t.code,
      trancheId: t.id,
      calculationMethod: 'accrued_coupon',
      repaymentMode: 'sequential',
      shortfallTreatment: t.isDeferrable ? 'defer_pik' : 'unpaid_shortfall',
    });
  }

  rules.push({
    id: 'wf_oc_ic_diversion',
    priority: p++,
    name: 'OC / IC Coverage-Test Breach Diversion to Principal Cure',
    account: 'interest',
    ruleType: 'coverage_diversion',
    condition: 'test_fail',
    sourceAccount: 'interest',
    destination: 'Principal Account (Senior Cure)',
    calculationMethod: 'target_oc_cure',
    repaymentMode: 'sequential',
    shortfallTreatment: 'divert_next',
  });

  for (const t of jr) {
    rules.push({
      id: `wf_int_${t.id}`,
      priority: p++,
      name: `${t.code} Junior Deferrable Interest`,
      account: 'interest',
      ruleType: 'sub_interest',
      condition: 'test_pass',
      sourceAccount: 'interest',
      destination: t.code,
      trancheId: t.id,
      calculationMethod: 'accrued_coupon',
      repaymentMode: 'sequential',
      shortfallTreatment: t.isDeferrable ? 'defer_pik' : 'unpaid_shortfall',
    });

    rules.push({
      id: `wf_pik_cure_${t.id}`,
      priority: p++,
      name: `${t.code} Deferred PIK Interest Cure`,
      account: 'interest',
      ruleType: 'deferred_interest_cure',
      condition: 'test_pass',
      sourceAccount: 'interest',
      destination: t.code,
      trancheId: t.id,
      calculationMethod: 'deferred_interest_balance',
      repaymentMode: 'sequential',
      shortfallTreatment: 'unpaid_shortfall',
    });
  }

  rules.push({
    id: 'wf_equity_residual',
    priority: p++,
    name: 'Subordinated Equity Residual Excess Spread',
    account: 'interest',
    ruleType: 'residual_equity',
    condition: 'test_pass',
    sourceAccount: 'interest',
    destination: 'Subordinated Equity Holders',
    calculationMethod: 'remaining_cash',
    repaymentMode: 'sequential',
    shortfallTreatment: 'unpaid_shortfall',
  });

  // Principal Account Rules
  rules.push({
    id: 'wf_reinvest',
    priority: p++,
    name: 'Eligible Collateral Reinvestment',
    account: 'principal',
    ruleType: 'reinvestment',
    condition: 'in_reinvestment',
    sourceAccount: 'principal',
    destination: 'Collateral Pool Reinvestment',
    calculationMethod: 'reinvest_eligible',
    repaymentMode: 'sequential',
    shortfallTreatment: 'unpaid_shortfall',
  });

  rules.push({
    id: 'wf_early_amort',
    priority: p++,
    name: 'Early Amortisation Sequential Paydown',
    account: 'principal',
    ruleType: 'early_amortisation',
    condition: 'early_amort_triggered',
    sourceAccount: 'principal',
    destination: 'Senior-to-Junior Notes (Sequential)',
    calculationMethod: 'sequential_principal',
    repaymentMode: 'sequential',
    shortfallTreatment: 'unpaid_shortfall',
  });

  rules.push({
    id: 'wf_prin_repay',
    priority: p++,
    name: 'Post-Reinvestment Note Principal Repayment',
    account: 'principal',
    ruleType: 'principal_repayment',
    condition: 'post_reinvestment',
    sourceAccount: 'principal',
    destination: 'Note Holders by Priority',
    calculationMethod: 'sequential_principal',
    repaymentMode: 'sequential',
    shortfallTreatment: 'unpaid_shortfall',
  });

  return rules;
}

export function buildSyntheticWaterfallRules(tranches: TrancheDefinition[]): WaterfallRule[] {
  const sr = tranches.filter((t) => t.seniority === 'senior');
  const mz = tranches.filter((t) => t.seniority === 'mezzanine');
  const jr = tranches.filter((t) => t.seniority === 'junior');
  const rules: WaterfallRule[] = [];
  let p = 1;

  rules.push({
    id: 'swf_admin_fee',
    priority: p++,
    name: 'SPV Custody & Swap Calculation Agent Fee',
    account: 'interest',
    ruleType: 'fee_expense',
    condition: 'always',
    sourceAccount: 'interest',
    destination: 'SPV Admin & Swap Agent',
    calculationMethod: 'fixed_amount',
    repaymentMode: 'sequential',
    shortfallTreatment: 'draw_reserve',
    fixedAmount: 140000,
  });

  for (const t of [...sr, ...mz, ...jr]) {
    rules.push({
      id: `swf_prem_${t.id}`,
      priority: p++,
      name: `${t.code} ${t.isFunded ? 'CLN Coupon & Collateral Yield' : 'Unfunded Swap Protection Premium'}`,
      account: 'interest',
      ruleType: 'synthetic_premium',
      condition: t.seniority === 'senior' ? 'always' : 'test_pass',
      sourceAccount: 'interest',
      destination: t.code,
      trancheId: t.id,
      calculationMethod: 'accrued_coupon',
      repaymentMode: 'sequential',
      shortfallTreatment: t.isDeferrable ? 'defer_pik' : 'unpaid_shortfall',
    });
  }

  rules.push({
    id: 'swf_equity_residual',
    priority: p++,
    name: 'First-Loss CLN Residual Excess Premium',
    account: 'interest',
    ruleType: 'residual_equity',
    condition: 'test_pass',
    sourceAccount: 'interest',
    destination: 'First-Loss Equity CLN',
    calculationMethod: 'remaining_cash',
    repaymentMode: 'sequential',
    shortfallTreatment: 'unpaid_shortfall',
  });

  rules.push({
    id: 'swf_prin_release',
    priority: p++,
    name: 'Funded Collateral Release & CLN Amortisation',
    account: 'principal',
    ruleType: 'principal_repayment',
    condition: 'post_reinvestment',
    sourceAccount: 'principal',
    destination: 'Funded CLN Holders',
    calculationMethod: 'sequential_principal',
    repaymentMode: 'sequential',
    shortfallTreatment: 'unpaid_shortfall',
  });

  return rules;
}

export interface SeedWorkspaceBundle {
  deals: DealRecord[];
  tapesByDeal: Record<string, CollateralTape[]>;
  structuresByDeal: Record<string, DealStructure[]>;
  surveillanceByDeal: Record<string, SurveillancePeriodRecord[]>;
  approvalsByDeal: Record<string, ApprovalRequestRecord[]>;
}

export function createInitialSeedBundle(): SeedWorkspaceBundle {
  const semiAssets = generateSemiconductorAssets();
  const corpAssets = generateCorporateDebtAssets();
  const eqptAssets = generateEquipmentFinanceAssets();

  const poolTotal = 100000000;

  // --- 3 Alternative Capital Structures for RST-2026-1 (USD 100M Semiconductor Pool) ---
  const baseTranches: TrancheDefinition[] = recomputeAttachmentPoints(
    [
      { id: 'tr_a1', code: 'Class A-1 Senior', seniority: 'senior', notional: 54000000, issuePricePct: 100, couponType: 'floating', spreadOrCouponBps: 145, maturityPeriods: 20, paymentPriority: 1, principalPriority: 1, isDeferrable: false, lossAllocationOrder: 1, redemptionProvision: 'Non-Call 2Y / Callable Par', isFunded: true, referenceNotional: poolTotal, attachmentPct: 28, detachmentPct: 100 },
      { id: 'tr_a2', code: 'Class A-2 Senior', seniority: 'senior', notional: 18000000, issuePricePct: 100, couponType: 'floating', spreadOrCouponBps: 190, maturityPeriods: 20, paymentPriority: 2, principalPriority: 2, isDeferrable: false, lossAllocationOrder: 2, redemptionProvision: 'Non-Call 2Y / Callable Par', isFunded: true, referenceNotional: poolTotal, attachmentPct: 28, detachmentPct: 46 },
      { id: 'tr_b', code: 'Class B Mezzanine', seniority: 'mezzanine', notional: 12000000, issuePricePct: 99.25, couponType: 'floating', spreadOrCouponBps: 315, maturityPeriods: 20, paymentPriority: 3, principalPriority: 3, isDeferrable: true, lossAllocationOrder: 3, redemptionProvision: 'Callable Par Post-Reinvest', isFunded: true, referenceNotional: poolTotal, attachmentPct: 16, detachmentPct: 28 },
      { id: 'tr_c', code: 'Class C Junior', seniority: 'junior', notional: 8000000, issuePricePct: 97.5, couponType: 'floating', spreadOrCouponBps: 540, maturityPeriods: 20, paymentPriority: 4, principalPriority: 4, isDeferrable: true, lossAllocationOrder: 4, redemptionProvision: 'Callable @ 101', isFunded: true, referenceNotional: poolTotal, attachmentPct: 8, detachmentPct: 16 },
      { id: 'tr_eq', code: 'Subordinated Equity', seniority: 'equity', notional: 8000000, issuePricePct: 96.0, couponType: 'residual', spreadOrCouponBps: 0, maturityPeriods: 20, paymentPriority: 5, principalPriority: 5, isDeferrable: false, lossAllocationOrder: 5, redemptionProvision: 'Residual Call Option', isFunded: true, referenceNotional: poolTotal, attachmentPct: 0, detachmentPct: 8 },
    ],
    poolTotal
  );

  const conservativeTranches: TrancheDefinition[] = recomputeAttachmentPoints(
    [
      { id: 'tr_c_a', code: 'Class A Senior', seniority: 'senior', notional: 65000000, issuePricePct: 100, couponType: 'floating', spreadOrCouponBps: 135, maturityPeriods: 20, paymentPriority: 1, principalPriority: 1, isDeferrable: false, lossAllocationOrder: 1, redemptionProvision: 'Non-Call 2Y / Callable Par', isFunded: true, referenceNotional: poolTotal, attachmentPct: 35, detachmentPct: 100 },
      { id: 'tr_c_b', code: 'Class B Mezzanine', seniority: 'mezzanine', notional: 15000000, issuePricePct: 99.5, couponType: 'floating', spreadOrCouponBps: 285, maturityPeriods: 20, paymentPriority: 2, principalPriority: 2, isDeferrable: true, lossAllocationOrder: 2, redemptionProvision: 'Callable Par', isFunded: true, referenceNotional: poolTotal, attachmentPct: 20, detachmentPct: 35 },
      { id: 'tr_c_c', code: 'Class C Junior', seniority: 'junior', notional: 10000000, issuePricePct: 98.0, couponType: 'floating', spreadOrCouponBps: 490, maturityPeriods: 20, paymentPriority: 3, principalPriority: 3, isDeferrable: true, lossAllocationOrder: 3, redemptionProvision: 'Callable @ 101', isFunded: true, referenceNotional: poolTotal, attachmentPct: 10, detachmentPct: 20 },
      { id: 'tr_c_eq', code: 'Subordinated Equity', seniority: 'equity', notional: 10000000, issuePricePct: 97.0, couponType: 'residual', spreadOrCouponBps: 0, maturityPeriods: 20, paymentPriority: 4, principalPriority: 4, isDeferrable: false, lossAllocationOrder: 4, redemptionProvision: 'Residual Call Option', isFunded: true, referenceNotional: poolTotal, attachmentPct: 0, detachmentPct: 10 },
    ],
    poolTotal
  );

  const leveragedTranches: TrancheDefinition[] = recomputeAttachmentPoints(
    [
      { id: 'tr_l_a', code: 'Class A Senior', seniority: 'senior', notional: 78000000, issuePricePct: 100, couponType: 'floating', spreadOrCouponBps: 175, maturityPeriods: 20, paymentPriority: 1, principalPriority: 1, isDeferrable: false, lossAllocationOrder: 1, redemptionProvision: 'Non-Call 2Y / Callable Par', isFunded: true, referenceNotional: poolTotal, attachmentPct: 22, detachmentPct: 100 },
      { id: 'tr_l_b', code: 'Class B Mezzanine', seniority: 'mezzanine', notional: 11000000, issuePricePct: 99.0, couponType: 'floating', spreadOrCouponBps: 360, maturityPeriods: 20, paymentPriority: 2, principalPriority: 2, isDeferrable: true, lossAllocationOrder: 2, redemptionProvision: 'Callable Par', isFunded: true, referenceNotional: poolTotal, attachmentPct: 11, detachmentPct: 22 },
      { id: 'tr_l_c', code: 'Class C Junior', seniority: 'junior', notional: 6000000, issuePricePct: 97.0, couponType: 'floating', spreadOrCouponBps: 610, maturityPeriods: 20, paymentPriority: 3, principalPriority: 3, isDeferrable: true, lossAllocationOrder: 3, redemptionProvision: 'Callable @ 101', isFunded: true, referenceNotional: poolTotal, attachmentPct: 5, detachmentPct: 11 },
      { id: 'tr_l_eq', code: 'Subordinated Equity', seniority: 'equity', notional: 5000000, issuePricePct: 95.0, couponType: 'residual', spreadOrCouponBps: 0, maturityPeriods: 20, paymentPriority: 4, principalPriority: 4, isDeferrable: false, lossAllocationOrder: 4, redemptionProvision: 'Residual Call Option', isFunded: true, referenceNotional: poolTotal, attachmentPct: 0, detachmentPct: 5 },
    ],
    poolTotal
  );

  const corpTranches: TrancheDefinition[] = recomputeAttachmentPoints(
    [
      { id: 'corp_a', code: 'Class A Senior', seniority: 'senior', notional: 68000000, issuePricePct: 100, couponType: 'floating', spreadOrCouponBps: 155, maturityPeriods: 20, paymentPriority: 1, principalPriority: 1, isDeferrable: false, lossAllocationOrder: 1, redemptionProvision: 'Non-Call 2Y', isFunded: true, referenceNotional: poolTotal, attachmentPct: 32, detachmentPct: 100 },
      { id: 'corp_b', code: 'Class B Mezzanine', seniority: 'mezzanine', notional: 14000000, issuePricePct: 99.5, couponType: 'floating', spreadOrCouponBps: 295, maturityPeriods: 20, paymentPriority: 2, principalPriority: 2, isDeferrable: true, lossAllocationOrder: 2, redemptionProvision: 'Callable Par', isFunded: true, referenceNotional: poolTotal, attachmentPct: 18, detachmentPct: 32 },
      { id: 'corp_c', code: 'Class C Junior', seniority: 'junior', notional: 9000000, issuePricePct: 98.0, couponType: 'floating', spreadOrCouponBps: 515, maturityPeriods: 20, paymentPriority: 3, principalPriority: 3, isDeferrable: true, lossAllocationOrder: 3, redemptionProvision: 'Callable @ 101', isFunded: true, referenceNotional: poolTotal, attachmentPct: 9, detachmentPct: 18 },
      { id: 'corp_eq', code: 'Subordinated Equity', seniority: 'equity', notional: 9000000, issuePricePct: 96.5, couponType: 'residual', spreadOrCouponBps: 0, maturityPeriods: 20, paymentPriority: 4, principalPriority: 4, isDeferrable: false, lossAllocationOrder: 4, redemptionProvision: 'Residual', isFunded: true, referenceNotional: poolTotal, attachmentPct: 0, detachmentPct: 9 },
    ],
    poolTotal
  );

  const syntheticTranches: TrancheDefinition[] = recomputeAttachmentPoints(
    [
      { id: 'syn_ss', code: 'Super-Senior CDS Swap (Unfunded)', seniority: 'senior', notional: 68000000, issuePricePct: 100, couponType: 'fixed', spreadOrCouponBps: 55, maturityPeriods: 16, paymentPriority: 1, principalPriority: 1, isDeferrable: false, lossAllocationOrder: 1, redemptionProvision: 'Swap Termination', isFunded: false, referenceNotional: poolTotal, attachmentPct: 32, detachmentPct: 100 },
      { id: 'syn_mz', code: 'Class B Funded CLN', seniority: 'mezzanine', notional: 14000000, issuePricePct: 100, couponType: 'floating', spreadOrCouponBps: 310, maturityPeriods: 16, paymentPriority: 2, principalPriority: 2, isDeferrable: false, lossAllocationOrder: 2, redemptionProvision: 'Callable Par', isFunded: true, referenceNotional: poolTotal, attachmentPct: 18, detachmentPct: 32 },
      { id: 'syn_jr', code: 'Class C Funded CLN', seniority: 'junior', notional: 10000000, issuePricePct: 99.0, couponType: 'floating', spreadOrCouponBps: 560, maturityPeriods: 16, paymentPriority: 3, principalPriority: 3, isDeferrable: true, lossAllocationOrder: 3, redemptionProvision: 'Callable @ 101', isFunded: true, referenceNotional: poolTotal, attachmentPct: 8, detachmentPct: 18 },
      { id: 'syn_eq', code: 'First-Loss Equity CLN', seniority: 'equity', notional: 8000000, issuePricePct: 98.0, couponType: 'residual', spreadOrCouponBps: 0, maturityPeriods: 16, paymentPriority: 4, principalPriority: 4, isDeferrable: false, lossAllocationOrder: 4, redemptionProvision: 'Residual CLN', isFunded: true, referenceNotional: poolTotal, attachmentPct: 0, detachmentPct: 8 },
    ],
    poolTotal
  );

  const nowIso = '2026-11-21T00:00:00.000Z';

  const deals: DealRecord[] = [
    {
      id: 'deal_rst_2026_1',
      name: 'RhinoSemiconductor Trust 2026-1',
      code: 'RST-2026-1',
      assetClass: 'semiconductor',
      structureType: 'cash',
      currency: 'USD',
      targetPoolNotional: 100000000,
      reinvestmentPeriods: 6,
      maturityPeriods: 20,
      periodFrequency: 'quarterly',
      status: 'active',
      version: 1,
      activeTapeId: 'tape_rst_v1',
      activeStructureId: 'struct_rst_base',
      reserveTarget: 1500000,
      reserveBalance: 1500000,
      annualSeniorFeeBps: 45,
      annualTrusteeFee: 180000,
      ocTriggerRatio: 1.16,
      icTriggerRatio: 1.25,
      issuanceExpenses: 650000,
      createdAt: nowIso,
      updatedAt: nowIso,
    },
    {
      id: 'deal_aic_2026_a',
      name: 'Apex Industrials CLO 2026-A',
      code: 'AIC-2026-A',
      assetClass: 'corporate_debt',
      structureType: 'cash',
      currency: 'USD',
      targetPoolNotional: 100000000,
      reinvestmentPeriods: 8,
      maturityPeriods: 20,
      periodFrequency: 'quarterly',
      status: 'active',
      version: 1,
      activeTapeId: 'tape_aic_v1',
      activeStructureId: 'struct_aic_base',
      reserveTarget: 1250000,
      reserveBalance: 1250000,
      annualSeniorFeeBps: 40,
      annualTrusteeFee: 150000,
      ocTriggerRatio: 1.18,
      icTriggerRatio: 1.22,
      issuanceExpenses: 600000,
      createdAt: nowIso,
      updatedAt: nowIso,
    },
    {
      id: 'deal_vfs_2026_1',
      name: 'Vanguard Fleet Synthetic 2026-1',
      code: 'VFS-2026-1',
      assetClass: 'equipment_finance',
      structureType: 'synthetic',
      currency: 'USD',
      targetPoolNotional: 100000000,
      reinvestmentPeriods: 4,
      maturityPeriods: 16,
      periodFrequency: 'quarterly',
      status: 'active',
      version: 1,
      activeTapeId: 'tape_vfs_v1',
      activeStructureId: 'struct_vfs_base',
      reserveTarget: 1000000,
      reserveBalance: 1000000,
      annualSeniorFeeBps: 25,
      annualTrusteeFee: 140000,
      ocTriggerRatio: 1.12,
      icTriggerRatio: 1.18,
      issuanceExpenses: 420000,
      createdAt: nowIso,
      updatedAt: nowIso,
    },
  ];

  const tapesByDeal: Record<string, CollateralTape[]> = {
    deal_rst_2026_1: [
      {
        id: 'tape_rst_v1',
        dealId: 'deal_rst_2026_1',
        versionNumber: 1,
        sourceFormat: 'seed',
        sourceFileName: 'rst_2026_1_semiconductor_tape_v1.csv',
        totalPrincipal: 100000000,
        assetCount: semiAssets.length,
        validationSummary: { errorCount: 0, warningCount: 0, currency: 'USD' },
        assets: semiAssets,
        createdAt: nowIso,
      },
    ],
    deal_aic_2026_a: [
      {
        id: 'tape_aic_v1',
        dealId: 'deal_aic_2026_a',
        versionNumber: 1,
        sourceFormat: 'seed',
        sourceFileName: 'aic_2026_a_corporate_loans_v1.csv',
        totalPrincipal: 100000000,
        assetCount: corpAssets.length,
        validationSummary: { errorCount: 0, warningCount: 0, currency: 'USD' },
        assets: corpAssets,
        createdAt: nowIso,
      },
    ],
    deal_vfs_2026_1: [
      {
        id: 'tape_vfs_v1',
        dealId: 'deal_vfs_2026_1',
        versionNumber: 1,
        sourceFormat: 'seed',
        sourceFileName: 'vfs_2026_1_equipment_reference_v1.csv',
        totalPrincipal: 100000000,
        assetCount: eqptAssets.length,
        validationSummary: { errorCount: 0, warningCount: 0, currency: 'USD' },
        assets: eqptAssets,
        createdAt: nowIso,
      },
    ],
  };

  const structuresByDeal: Record<string, DealStructure[]> = {
    deal_rst_2026_1: [
      {
        id: 'struct_rst_base',
        dealId: 'deal_rst_2026_1',
        name: 'Structure 1 · Balanced Mezzanine (72 / 12 / 8 / 8)',
        versionNumber: 1,
        isBase: true,
        tranches: baseTranches,
        waterfallRules: buildStandardCashWaterfallRules(baseTranches),
        assumptions: { ...DEFAULT_BASE_ASSUMPTIONS },
        createdAt: nowIso,
        updatedAt: nowIso,
      },
      {
        id: 'struct_rst_conservative',
        dealId: 'deal_rst_2026_1',
        name: 'Structure 2 · Conservative Senior-Heavy (65 / 15 / 10 / 10)',
        versionNumber: 1,
        isBase: false,
        tranches: conservativeTranches,
        waterfallRules: buildStandardCashWaterfallRules(conservativeTranches),
        assumptions: { ...DEFAULT_BASE_ASSUMPTIONS },
        createdAt: nowIso,
        updatedAt: nowIso,
      },
      {
        id: 'struct_rst_leveraged',
        dealId: 'deal_rst_2026_1',
        name: 'Structure 3 · Leveraged Thin-Equity (78 / 11 / 6 / 5)',
        versionNumber: 1,
        isBase: false,
        tranches: leveragedTranches,
        waterfallRules: buildStandardCashWaterfallRules(leveragedTranches),
        assumptions: { ...DEFAULT_BASE_ASSUMPTIONS },
        createdAt: nowIso,
        updatedAt: nowIso,
      },
    ],
    deal_aic_2026_a: [
      {
        id: 'struct_aic_base',
        dealId: 'deal_aic_2026_a',
        name: 'Base CLO Structure (68 / 14 / 9 / 9)',
        versionNumber: 1,
        isBase: true,
        tranches: corpTranches,
        waterfallRules: buildStandardCashWaterfallRules(corpTranches),
        assumptions: { ...DEFAULT_BASE_ASSUMPTIONS },
        createdAt: nowIso,
        updatedAt: nowIso,
      },
    ],
    deal_vfs_2026_1: [
      {
        id: 'struct_vfs_base',
        dealId: 'deal_vfs_2026_1',
        name: 'Synthetic CLN + Super-Senior Swap (68 Unfunded / 24 Funded / 8 Equity)',
        versionNumber: 1,
        isBase: true,
        tranches: syntheticTranches,
        waterfallRules: buildSyntheticWaterfallRules(syntheticTranches),
        assumptions: { ...DEFAULT_BASE_ASSUMPTIONS },
        createdAt: nowIso,
        updatedAt: nowIso,
      },
    ],
  };

  // Post-issuance surveillance periods for RST-2026-1 (demonstrating Q4 coverage breach & diversion)
  const surveillanceByDeal: Record<string, SurveillancePeriodRecord[]> = {
    deal_rst_2026_1: [
      {
        id: 'surv_rst_q1',
        dealId: 'deal_rst_2026_1',
        periodNumber: 1,
        periodLabel: '2026 Q1',
        asOfDate: '2026-03-31',
        isFinalized: true,
        actualCollections: 2145000,
        projectedCollections: 2120000,
        actualDefaults: 0,
        projectedDefaults: 480000,
        actualRecoveries: 0,
        projectedRecoveries: 0,
        endingPoolBalance: 100000000,
        delinquency30Plus: 1200000,
        delinquency60Plus: 0,
        ocRatio: 1.208,
        icRatio: 1.46,
        reserveBalance: 1500000,
        trancheDistributions: [
          { code: 'Class A-1 Senior', interestPaid: 769500, principalPaid: 0, endingBalance: 54000000 },
          { code: 'Class A-2 Senior', interestPaid: 276750, principalPaid: 0, endingBalance: 18000000 },
          { code: 'Class B Mezzanine', interestPaid: 222000, principalPaid: 0, endingBalance: 12000000 },
          { code: 'Class C Junior', interestPaid: 193000, principalPaid: 0, endingBalance: 8000000 },
          { code: 'Subordinated Equity', interestPaid: 511250, principalPaid: 0, endingBalance: 8000000 },
        ],
        breaches: [],
        substitutions: [],
        forecastSnapshot: {
          modelVersion: 'TW-QUANT-2.4.0',
          seed: 202601,
          assumedPdMultiplier: 1.0,
          assumedRecoveryMultiplier: 1.0,
          frozenAt: '2026-04-05T09:00:00.000Z',
        },
        createdAt: '2026-04-05T09:00:00.000Z',
      },
      {
        id: 'surv_rst_q2',
        dealId: 'deal_rst_2026_1',
        periodNumber: 2,
        periodLabel: '2026 Q2',
        asOfDate: '2026-06-30',
        isFinalized: true,
        actualCollections: 2085000,
        projectedCollections: 2110000,
        actualDefaults: 1400000,
        projectedDefaults: 520000,
        actualRecoveries: 0,
        projectedRecoveries: 240000,
        endingPoolBalance: 98600000,
        delinquency30Plus: 2800000,
        delinquency60Plus: 1100000,
        ocRatio: 1.191,
        icRatio: 1.41,
        reserveBalance: 1500000,
        trancheDistributions: [
          { code: 'Class A-1 Senior', interestPaid: 769500, principalPaid: 0, endingBalance: 54000000 },
          { code: 'Class A-2 Senior', interestPaid: 276750, principalPaid: 0, endingBalance: 18000000 },
          { code: 'Class B Mezzanine', interestPaid: 222000, principalPaid: 0, endingBalance: 12000000 },
          { code: 'Class C Junior', interestPaid: 193000, principalPaid: 0, endingBalance: 8000000 },
          { code: 'Subordinated Equity', interestPaid: 451250, principalPaid: 0, endingBalance: 8000000 },
        ],
        breaches: [],
        substitutions: [
          {
            id: 'sub_q2_1',
            removedAssetId: 'SEMI-034',
            removedObligor: 'Kulim Analog Wafer Leasing Bhd',
            addedAssetId: 'SEMI-041',
            addedObligor: 'Nara Precision EUV Optics KK',
            notionalDelta: 0,
            approvedBy: 'checker@rhinobank.internal',
            timestamp: '2026-06-18T14:22:00.000Z',
          },
        ],
        forecastSnapshot: {
          modelVersion: 'TW-QUANT-2.4.0',
          seed: 202602,
          assumedPdMultiplier: 1.0,
          assumedRecoveryMultiplier: 1.0,
          frozenAt: '2026-07-06T09:00:00.000Z',
        },
        createdAt: '2026-07-06T09:00:00.000Z',
      },
      {
        id: 'surv_rst_q3',
        dealId: 'deal_rst_2026_1',
        periodNumber: 3,
        periodLabel: '2026 Q3',
        asOfDate: '2026-09-30',
        isFinalized: true,
        actualCollections: 1940000,
        projectedCollections: 2090000,
        actualDefaults: 2900000,
        projectedDefaults: 540000,
        actualRecoveries: 620000,
        projectedRecoveries: 450000,
        endingPoolBalance: 96320000,
        delinquency30Plus: 3400000,
        delinquency60Plus: 2400000,
        ocRatio: 1.164,
        icRatio: 1.31,
        reserveBalance: 1500000,
        trancheDistributions: [
          { code: 'Class A-1 Senior', interestPaid: 769500, principalPaid: 0, endingBalance: 54000000 },
          { code: 'Class A-2 Senior', interestPaid: 276750, principalPaid: 0, endingBalance: 18000000 },
          { code: 'Class B Mezzanine', interestPaid: 222000, principalPaid: 0, endingBalance: 12000000 },
          { code: 'Class C Junior', interestPaid: 193000, principalPaid: 0, endingBalance: 8000000 },
          { code: 'Subordinated Equity', interestPaid: 306250, principalPaid: 0, endingBalance: 8000000 },
        ],
        breaches: [],
        substitutions: [],
        forecastSnapshot: {
          modelVersion: 'TW-QUANT-2.4.0',
          seed: 202603,
          assumedPdMultiplier: 1.15,
          assumedRecoveryMultiplier: 0.95,
          frozenAt: '2026-10-05T09:00:00.000Z',
        },
        createdAt: '2026-10-05T09:00:00.000Z',
      },
      {
        id: 'surv_rst_q4',
        dealId: 'deal_rst_2026_1',
        periodNumber: 4,
        periodLabel: '2026 Q4 (Current)',
        asOfDate: '2026-11-20',
        isFinalized: false,
        actualCollections: 1710000,
        projectedCollections: 2070000,
        actualDefaults: 3600000,
        projectedDefaults: 560000,
        actualRecoveries: 480000,
        projectedRecoveries: 720000,
        endingPoolBalance: 93200000,
        delinquency30Plus: 4100000,
        delinquency60Plus: 2900000,
        ocRatio: 1.127,
        icRatio: 1.19,
        reserveBalance: 1500000,
        trancheDistributions: [
          { code: 'Class A-1 Senior', interestPaid: 769500, principalPaid: 279250, endingBalance: 53720750 },
          { code: 'Class A-2 Senior', interestPaid: 276750, principalPaid: 0, endingBalance: 18000000 },
          { code: 'Class B Mezzanine', interestPaid: 222000, principalPaid: 0, endingBalance: 12000000 },
          { code: 'Class C Junior', interestPaid: 0, principalPaid: 0, endingBalance: 8193000 },
          { code: 'Subordinated Equity', interestPaid: 0, principalPaid: 0, endingBalance: 8000000 },
        ],
        breaches: [
          {
            code: 'OC_SENIOR_MEZZ_BREACH',
            testName: 'Senior + Mezzanine OC Coverage Test',
            threshold: 1.16,
            observed: 1.127,
            actionTaken: 'Diverted $279,250 excess interest to Class A-1 principal cure; Class C interest deferred to PIK ($193,000); Equity residual suspended.',
          },
          {
            code: 'IC_COVERAGE_BREACH',
            testName: 'Interest Coverage (IC) Test',
            threshold: 1.25,
            observed: 1.19,
            actionTaken: 'Blocked junior & equity interest distributions under Waterfall Rule #7.',
          },
        ],
        substitutions: [],
        forecastSnapshot: {
          modelVersion: 'TW-QUANT-2.4.0',
          seed: 202604,
          assumedPdMultiplier: 1.35,
          assumedRecoveryMultiplier: 0.90,
          frozenAt: '2026-11-20T10:00:00.000Z',
        },
        createdAt: '2026-11-20T10:00:00.000Z',
      },
    ],
    deal_aic_2026_a: [],
    deal_vfs_2026_1: [],
  };

  const approvalsByDeal: Record<string, ApprovalRequestRecord[]> = {
    deal_rst_2026_1: [
      {
        id: 'appr_rst_1',
        dealId: 'deal_rst_2026_1',
        makerUid: 'analyst_demo',
        makerEmail: 'structuring.desk@rhinobank.internal',
        checkerUid: 'checker_demo',
        checkerEmail: 'risk.committee@rhinobank.internal',
        actionType: 'collateral_substitution',
        summary: 'Substitute SEMI-034 (Kulim 30DPD) with SEMI-041 (Nara Precision EUV Optics KK) at par',
        payloadDiff: { removedAssetId: 'SEMI-034', addedAssetId: 'SEMI-041', notional: 1500000 },
        status: 'approved',
        decisionNote: 'Verified par substitution improves WA recovery rate by +18 bps.',
        createdAt: '2026-06-17T11:00:00.000Z',
        decidedAt: '2026-06-18T14:22:00.000Z',
      },
      {
        id: 'appr_rst_2',
        dealId: 'deal_rst_2026_1',
        makerUid: 'analyst_demo',
        makerEmail: 'structuring.desk@rhinobank.internal',
        actionType: 'period_finalization',
        summary: 'Finalize Q4 2026 Investor Surveillance Report & Lock OC/IC Breach Diversion Ledger',
        payloadDiff: { periodLabel: '2026 Q4', ocObserved: 1.127, divertedToSenior: 279250 },
        status: 'pending',
        createdAt: '2026-11-20T16:40:00.000Z',
      },
    ],
    deal_aic_2026_a: [],
    deal_vfs_2026_1: [],
  };

  return {
    deals,
    tapesByDeal,
    structuresByDeal,
    surveillanceByDeal,
    approvalsByDeal,
  };
}
