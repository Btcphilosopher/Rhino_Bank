import type {
  CapitalReconciliation,
  CollateralAsset,
  DealAssumptions,
  DealRecord,
  PeriodAuditLine,
  StructureType,
  TrancheDefinition,
  TranchePeriodState,
  WaterfallPeriodResult,
  WaterfallRule,
  WaterfallRunResult,
} from './types.ts';

export interface PeriodShock {
  defaultFractionOverride?: number;
  recoveryRateOverride?: number;
  prepaymentCprOverride?: number;
  baseRateOverrideBps?: number;
  /** Optional explicit per-asset default fractions in this period for Monte Carlo */
  assetDefaultAmounts?: number[];
  assetRecoveryRates?: number[];
}

export function detectWaterfallCycles(rules: WaterfallRule[]): { hasCycle: boolean; message?: string } {
  const seenIds = new Set<string>();
  const adj = new Map<string, string>();
  for (const r of rules) {
    if (seenIds.has(r.id)) {
      return { hasCycle: true, message: `Duplicate rule ID "${r.id}".` };
    }
    seenIds.add(r.id);
    if (r.dependsOnRuleId) {
      if (r.dependsOnRuleId === r.id) {
        return { hasCycle: true, message: `Rule "${r.name}" depends on itself.` };
      }
      adj.set(r.id, r.dependsOnRuleId);
    }
  }
  for (const startId of adj.keys()) {
    const visited = new Set<string>();
    let cur: string | undefined = startId;
    while (cur) {
      if (visited.has(cur)) {
        return { hasCycle: true, message: `Circular dependency detected in waterfall rule chain involving "${cur}".` };
      }
      visited.add(cur);
      cur = adj.get(cur);
    }
  }
  return { hasCycle: false };
}

export function computeCapitalReconciliation(
  deal: DealRecord,
  assets: CollateralAsset[],
  tranches: TrancheDefinition[]
): CapitalReconciliation {
  const poolPrincipal = assets.reduce((s, a) => s + a.principalOutstanding, 0);
  const collateralAssets = deal.structureType === 'cash' ? poolPrincipal : 0;
  const fundedNotesNotional = tranches
    .filter((t) => t.isFunded && t.seniority !== 'equity')
    .reduce((s, t) => s + t.notional, 0);
  const unfundedProtectionNotional = tranches
    .filter((t) => !t.isFunded && t.seniority !== 'equity')
    .reduce((s, t) => s + t.notional, 0);
  const equityNotional = tranches
    .filter((t) => t.seniority === 'equity')
    .reduce((s, t) => s + t.notional, 0);

  const syntheticCollateralAccount = deal.structureType === 'synthetic' ? fundedNotesNotional + equityNotional : 0;
  const effectiveAssets = deal.structureType === 'cash' ? collateralAssets : syntheticCollateralAccount;
  const totalAssetsAndReserves = effectiveAssets + deal.reserveBalance;
  const totalLiabilitiesAndEquity = fundedNotesNotional + equityNotional;

  const grossIssuanceProceeds = tranches
    .filter((t) => t.isFunded)
    .reduce((s, t) => s + t.notional * (t.issuePricePct / 100), 0);
  const netIssuanceProceeds = grossIssuanceProceeds - deal.issuanceExpenses;
  const fundingSurplusOrDeficit =
    deal.structureType === 'cash'
      ? netIssuanceProceeds - (collateralAssets + deal.reserveBalance)
      : netIssuanceProceeds - (syntheticCollateralAccount + deal.reserveBalance);

  return {
    collateralAssets: deal.structureType === 'cash' ? collateralAssets : syntheticCollateralAccount,
    reserveAccount: deal.reserveBalance,
    totalAssetsAndReserves,
    fundedNotesNotional,
    unfundedProtectionNotional,
    equityNotional,
    totalLiabilitiesAndEquity,
    grossIssuanceProceeds,
    issuanceExpenses: deal.issuanceExpenses,
    netIssuanceProceeds,
    fundingSurplusOrDeficit,
    reconciled: Math.abs(fundingSurplusOrDeficit) < poolPrincipal * 0.05,
  };
}

export function recomputeAttachmentPoints(
  tranches: TrancheDefinition[],
  referenceNotional: number
): TrancheDefinition[] {
  const ref = referenceNotional > 0 ? referenceNotional : 1;
  // Attachment is computed bottom-up from equity (highest lossAllocationOrder) to senior
  const sortedBottomUp = [...tranches].sort((a, b) => b.lossAllocationOrder - a.lossAllocationOrder);
  let cumulativePct = 0;
  const map = new Map<string, { attachmentPct: number; detachmentPct: number }>();

  for (const t of sortedBottomUp) {
    const thicknessPct = (t.notional / ref) * 100;
    const attachmentPct = Math.round(cumulativePct * 100) / 100;
    const detachmentPct = Math.round(Math.min(100, cumulativePct + thicknessPct) * 100) / 100;
    map.set(t.id, { attachmentPct, detachmentPct });
    cumulativePct += thicknessPct;
  }

  return tranches.map((t) => {
    const pts = map.get(t.id) ?? { attachmentPct: t.attachmentPct, detachmentPct: t.detachmentPct };
    return {
      ...t,
      referenceNotional: ref,
      attachmentPct: pts.attachmentPct,
      detachmentPct: pts.detachmentPct,
    };
  });
}

function evaluateCondition(
  condition: WaterfallRule['condition'],
  ctx: {
    ocTestPassed: boolean;
    icTestPassed: boolean;
    inReinvestment: boolean;
    earlyAmortTriggered: boolean;
  }
): { met: boolean; label: string } {
  switch (condition) {
    case 'always':
      return { met: true, label: 'Always' };
    case 'oc_test_pass':
      return { met: ctx.ocTestPassed, label: 'OC Test Pass' };
    case 'oc_test_fail':
      return { met: !ctx.ocTestPassed, label: 'OC Test Fail' };
    case 'ic_test_pass':
      return { met: ctx.icTestPassed, label: 'IC Test Pass' };
    case 'ic_test_fail':
      return { met: !ctx.icTestPassed, label: 'IC Test Fail' };
    case 'test_pass':
      return { met: ctx.ocTestPassed && ctx.icTestPassed, label: 'OC & IC Pass' };
    case 'test_fail':
      return { met: !ctx.ocTestPassed || !ctx.icTestPassed, label: 'OC or IC Fail' };
    case 'in_reinvestment':
      return { met: ctx.inReinvestment, label: 'Reinvestment Period' };
    case 'post_reinvestment':
      return { met: !ctx.inReinvestment, label: 'Amortisation Period' };
    case 'early_amort_triggered':
      return { met: ctx.earlyAmortTriggered, label: 'Early Amortisation' };
    default:
      return { met: true, label: 'Always' };
  }
}

export function runContractualWaterfall(params: {
  deal: DealRecord;
  assets: CollateralAsset[];
  tranches: TrancheDefinition[];
  rules: WaterfallRule[];
  assumptions: DealAssumptions;
  periodShocks?: PeriodShock[];
}): WaterfallRunResult {
  const { deal, assets, tranches, rules, assumptions, periodShocks } = params;
  const cycleCheck = detectWaterfallCycles(rules);
  const reconciliation = computeCapitalReconciliation(deal, assets, tranches);

  if (cycleCheck.hasCycle) {
    return {
      dealId: deal.id,
      structureId: deal.activeStructureId,
      structureType: deal.structureType,
      periods: [],
      capitalReconciliation: reconciliation,
      maxCashConservationError: 0,
      ruleCycleDetected: true,
      ruleCycleError: cycleCheck.message,
      totalCollateralInterest: 0,
      totalCollateralDefaults: 0,
      totalCollateralRecoveries: 0,
      totalDivertedCash: 0,
      ocBreachPeriods: [],
      icBreachPeriods: [],
    };
  }

  const periodsPerYear = deal.periodFrequency === 'monthly' ? 12 : 4;
  const totalPeriods = deal.maturityPeriods;
  const sortedTranches = [...tranches].sort((a, b) => a.paymentPriority - b.paymentPriority);
  const sortedRules = [...rules].sort((a, b) => a.priority - b.priority);

  // Track active tranche state
  const trancheBalances = new Map<string, number>();
  const deferredInterest = new Map<string, number>();
  for (const t of sortedTranches) {
    trancheBalances.set(t.id, t.notional);
    deferredInterest.set(t.id, 0);
  }

  // Track asset balances for deterministic pool evolution (or synthetic reference notional)
  const assetBalances = assets.map((a) =>
    a.delinquencyStatus === 'defaulted' ? 0 : a.principalOutstanding
  );
  // Pending recoveries indexed by landing period
  const pendingRecoveries = new Map<number, number>();
  for (const a of assets) {
    if (a.delinquencyStatus === 'defaulted') {
      const lag = assumptions.recoveryLagPeriodsOverride ?? a.assumedRecoveryLagPeriods;
      const landPeriod = Math.min(totalPeriods, Math.max(1, lag));
      const rec = a.principalOutstanding * Math.min(1, a.assumedRecoveryRate * assumptions.recoveryMultiplier);
      pendingRecoveries.set(landPeriod, (pendingRecoveries.get(landPeriod) ?? 0) + rec);
    }
  }

  let reserveAccount = deal.reserveBalance;
  let cumulativeSyntheticLoss = 0;
  let maxCashConservationError = 0;
  let totalCollateralInterest = 0;
  let totalCollateralDefaults = 0;
  let totalCollateralRecoveries = 0;
  let totalDivertedCash = 0;
  const ocBreachPeriods: number[] = [];
  const icBreachPeriods: number[] = [];
  const periodResults: WaterfallPeriodResult[] = [];
  let cumulativeDefaultRate = 0;
  const initialPoolPrincipal = assets.reduce((s, a) => s + a.principalOutstanding, 0) || 1;

  for (let p = 1; p <= totalPeriods; p++) {
    const shock = periodShocks?.[p - 1];
    const inReinvestment = p <= deal.reinvestmentPeriods;
    const beginningReserve = reserveAccount;
    const beginningPoolBalance = assetBalances.reduce((s, b) => s + b, 0);

    let scheduledInterest = 0;
    let scheduledPrincipal = 0;
    let prepayments = 0;
    let periodDefaults = 0;

    const effRefRateBps = shock?.baseRateOverrideBps ?? assumptions.referenceRateBps + assumptions.rateShockBps;

    // 1. Evolve Collateral / Reference Portfolio
    for (let idx = 0; idx < assets.length; idx++) {
      const asset = assets[idx];
      const bal = assetBalances[idx];
      if (bal <= 0.0001) continue;

      let defAmt = 0;
      if (shock?.assetDefaultAmounts && shock.assetDefaultAmounts[idx] !== undefined) {
        defAmt = Math.min(bal, shock.assetDefaultAmounts[idx]);
      } else if (shock?.defaultFractionOverride !== undefined) {
        defAmt = bal * shock.defaultFractionOverride;
      } else {
        const annualPd = Math.min(0.95, asset.assumedAnnualPd * assumptions.pdMultiplier * assumptions.clusterShockFactor);
        const periodPd = 1 - Math.pow(1 - annualPd, 1 / periodsPerYear);
        defAmt = bal * periodPd;
      }

      const performingBal = Math.max(0, bal - defAmt);
      periodDefaults += defAmt;

      // Recovery scheduling
      if (defAmt > 0) {
        const baseRec = shock?.assetRecoveryRates?.[idx] ?? shock?.recoveryRateOverride ?? asset.assumedRecoveryRate;
        const effRec = Math.max(0, Math.min(1, baseRec * assumptions.recoveryMultiplier));
        const lag = assumptions.recoveryLagPeriodsOverride ?? asset.assumedRecoveryLagPeriods;
        const recoveryLandPeriod = Math.min(totalPeriods, p + Math.max(0, lag));
        pendingRecoveries.set(
          recoveryLandPeriod,
          (pendingRecoveries.get(recoveryLandPeriod) ?? 0) + defAmt * effRec
        );
      }

      // Interest on performing balance
      const couponBps =
        asset.interestType === 'floating'
          ? Math.max(0, effRefRateBps + asset.spreadOrCouponBps)
          : asset.spreadOrCouponBps;
      scheduledInterest += performingBal * (couponBps / 10000) / periodsPerYear;

      // Prepayment on performing balance
      const annualCpr = Math.min(0.9, (shock?.prepaymentCprOverride ?? asset.assumedPrepaymentCpr) * assumptions.prepaymentCprMultiplier);
      const smm = 1 - Math.pow(1 - annualCpr, 1 / periodsPerYear);
      const prepayAmt = performingBal * smm;
      prepayments += prepayAmt;

      // Scheduled principal amortisation or bullet maturity
      const remainingAfterPrepay = Math.max(0, performingBal - prepayAmt);
      let schedPrin = 0;
      if (!inReinvestment) {
        if (p >= asset.maturityPeriods) {
          schedPrin = remainingAfterPrepay;
        } else {
          const remLife = Math.max(1, asset.maturityPeriods - p + 1);
          schedPrin = remainingAfterPrepay * (1 / remLife) * 0.65;
        }
      }
      scheduledPrincipal += schedPrin;
      assetBalances[idx] = Math.max(0, remainingAfterPrepay - schedPrin);
    }

    const recoveryInflow = pendingRecoveries.get(p) ?? 0;
    totalCollateralInterest += scheduledInterest;
    totalCollateralDefaults += periodDefaults;
    totalCollateralRecoveries += recoveryInflow;
    cumulativeDefaultRate += periodDefaults / initialPoolPrincipal;

    const earlyAmortTriggered = cumulativeDefaultRate > 0.085;

    // 2. Account Inflows (Cash CDO vs Synthetic CDO)
    let interestAccount = 0;
    let principalAccount = 0;
    let syntheticProtectionPremium = 0;
    let syntheticLossSettled = 0;
    let syntheticFundedCollateral = 0;

    if (deal.structureType === 'cash') {
      interestAccount = scheduledInterest;
      principalAccount = scheduledPrincipal + prepayments + recoveryInflow;
    } else {
      // Synthetic CDO: Vehicle does NOT own reference assets!
      // Vehicle earns risk-free yield on Funded Collateral Account + Protection Premium paid by Protection Buyer
      const fundedBalances = sortedTranches
        .filter((t) => t.isFunded && t.seniority !== 'equity')
        .reduce((s, t) => s + (trancheBalances.get(t.id) ?? 0), 0) +
        sortedTranches
          .filter((t) => t.seniority === 'equity')
          .reduce((s, t) => s + (trancheBalances.get(t.id) ?? 0), 0);
      syntheticFundedCollateral = fundedBalances;
      const collateralYield = fundedBalances * (Math.max(0, effRefRateBps) / 10000) / periodsPerYear;
      const totalPremiumCoupon = sortedTranches
        .filter((t) => t.seniority !== 'equity')
        .reduce((s, t) => s + (trancheBalances.get(t.id) ?? 0) * (t.spreadOrCouponBps / 10000) / periodsPerYear, 0);
      syntheticProtectionPremium = totalPremiumCoupon;
      interestAccount = collateralYield + syntheticProtectionPremium;

      // Credit event loss settlement on reference portfolio (net of recovery)
      const periodNetCreditLoss = Math.max(0, periodDefaults - recoveryInflow);
      cumulativeSyntheticLoss += periodNetCreditLoss;
      syntheticLossSettled = periodNetCreditLoss;

      // Principal release when reference assets amortise post-reinvestment
      if (!inReinvestment) {
        const refReduction = scheduledPrincipal + prepayments;
        const scale = initialPoolPrincipal > 0 ? refReduction / initialPoolPrincipal : 0;
        principalAccount = Math.min(fundedBalances, fundedBalances * scale);
      }
    }

    // 3. Pre-waterfall Coverage Tests (OC & IC)
    const performingAndCash =
      deal.structureType === 'cash'
        ? assetBalances.reduce((s, b) => s + b, 0) + principalAccount + reserveAccount
        : syntheticFundedCollateral + reserveAccount;

    const ratedDebtBalance = sortedTranches
      .filter((t) => t.seniority === 'senior' || t.seniority === 'mezzanine')
      .reduce((s, t) => s + (trancheBalances.get(t.id) ?? 0), 0);

    const ocRatioBefore = ratedDebtBalance > 0 ? performingAndCash / ratedDebtBalance : 9.99;
    const seniorMezzInterestDue = sortedTranches
      .filter((t) => t.seniority === 'senior' || t.seniority === 'mezzanine')
      .reduce((s, t) => {
        const bal = trancheBalances.get(t.id) ?? 0;
        const rateBps =
          t.couponType === 'floating'
            ? Math.max(0, effRefRateBps + t.spreadOrCouponBps)
            : t.spreadOrCouponBps;
        return s + (bal * (rateBps / 10000)) / periodsPerYear;
      }, 0);

    const icRatioBefore = seniorMezzInterestDue > 0 ? interestAccount / seniorMezzInterestDue : 9.99;
    const ocTestPassed = ocRatioBefore >= deal.ocTriggerRatio;
    const icTestPassed = icRatioBefore >= deal.icTriggerRatio;

    if (!ocTestPassed) ocBreachPeriods.push(p);
    if (!icTestPassed) icBreachPeriods.push(p);

    // Track per-period tranche metrics
    const trancheBeg = new Map<string, number>();
    const trancheInterestAccrued = new Map<string, number>();
    const trancheInterestPaid = new Map<string, number>();
    const trancheInterestDeferred = new Map<string, number>();
    const trancheInterestShortfall = new Map<string, number>();
    const tranchePrincipalPaid = new Map<string, number>();
    const trancheLossAllocated = new Map<string, number>();

    for (const t of sortedTranches) {
      const bal = trancheBalances.get(t.id) ?? 0;
      trancheBeg.set(t.id, bal);
      const accrued =
        t.couponType === 'residual'
          ? 0
          : (bal *
              (Math.max(
                0,
                t.couponType === 'floating'
                  ? effRefRateBps + t.spreadOrCouponBps
                  : t.spreadOrCouponBps
              ) /
                10000)) /
            periodsPerYear;
      trancheInterestAccrued.set(t.id, accrued);
      trancheInterestPaid.set(t.id, 0);
      trancheInterestDeferred.set(t.id, 0);
      trancheInterestShortfall.set(t.id, 0);
      tranchePrincipalPaid.set(t.id, 0);
      trancheLossAllocated.set(t.id, 0);
    }

    // Synthetic loss settlement against tranches bottom-up (equity first)
    if (deal.structureType === 'synthetic' && syntheticLossSettled > 0) {
      let remLoss = syntheticLossSettled;
      const lossOrder = [...sortedTranches].sort((a, b) => b.lossAllocationOrder - a.lossAllocationOrder);
      for (const t of lossOrder) {
        if (remLoss <= 0) break;
        const curBal = trancheBalances.get(t.id) ?? 0;
        const hit = Math.min(curBal, remLoss);
        if (hit > 0) {
          trancheBalances.set(t.id, curBal - hit);
          trancheLossAllocated.set(t.id, (trancheLossAllocated.get(t.id) ?? 0) + hit);
          remLoss -= hit;
        }
      }
    }

    const startInterestAccount = interestAccount;
    const startPrincipalAccount = principalAccount;
    let feesPaid = 0;
    let diversionAmount = 0;
    let reinvestedPrincipal = 0;
    let equityDistributed = 0;
    let totalExternalPrincipalOut = 0;
    let totalExternalInterestOut = 0;
    const auditLines: PeriodAuditLine[] = [];

    // 4. Execute Contractual Waterfall Rules strictly in Priority Order
    for (const rule of sortedRules) {
      const cond = evaluateCondition(rule.condition, {
        ocTestPassed,
        icTestPassed,
        inReinvestment,
        earlyAmortTriggered,
      });

      const getSourceCash = () => {
        if (rule.sourceAccount === 'interest') return interestAccount;
        if (rule.sourceAccount === 'principal') return principalAccount;
        return reserveAccount;
      };
      const deductSourceCash = (amt: number) => {
        if (rule.sourceAccount === 'interest') interestAccount -= amt;
        else if (rule.sourceAccount === 'principal') principalAccount -= amt;
        else reserveAccount -= amt;
      };

      const cashAvailable = getSourceCash();

      if (!cond.met) {
        auditLines.push({
          priority: rule.priority,
          ruleId: rule.id,
          ruleName: rule.name,
          account: rule.account,
          conditionEvaluated: cond.label,
          conditionMet: false,
          cashAvailable,
          ruleRequestedAmount: 0,
          paymentMade: 0,
          unpaidAmount: 0,
          deferredToPik: 0,
          drawnFromReserve: 0,
          remainingCash: cashAvailable,
          destination: rule.destination,
        });
        continue;
      }

      let requested = 0;
      const targetTranche = rule.trancheId
        ? sortedTranches.find((t) => t.id === rule.trancheId)
        : undefined;

      switch (rule.calculationMethod) {
        case 'fixed_amount':
          requested = (rule.fixedAmount ?? deal.annualTrusteeFee) / periodsPerYear;
          break;
        case 'bps_of_pool':
          requested = (beginningPoolBalance * ((rule.bpsRate ?? deal.annualSeniorFeeBps) / 10000)) / periodsPerYear;
          break;
        case 'accrued_coupon':
          if (targetTranche) {
            requested = Math.max(
              0,
              (trancheInterestAccrued.get(targetTranche.id) ?? 0) -
                (trancheInterestPaid.get(targetTranche.id) ?? 0)
            );
          }
          break;
        case 'deferred_interest_balance':
          if (targetTranche) {
            requested = deferredInterest.get(targetTranche.id) ?? 0;
          }
          break;
        case 'reserve_topup':
          requested = Math.max(0, deal.reserveTarget - reserveAccount);
          break;
        case 'target_oc_cure': {
          // Divert enough cash to cure OC ratio back to trigger threshold
          const targetDebt = performingAndCash / Math.max(0.5, deal.ocTriggerRatio);
          requested = Math.max(0, ratedDebtBalance - targetDebt);
          break;
        }
        case 'reinvest_eligible':
          requested = cashAvailable;
          break;
        case 'sequential_principal':
          requested = sortedTranches
            .filter((t) => t.seniority !== 'equity' && t.isFunded)
            .reduce((s, t) => s + (trancheBalances.get(t.id) ?? 0), 0);
          break;
        case 'pro_rata_principal':
          requested = sortedTranches
            .filter((t) => t.seniority !== 'equity' && t.isFunded)
            .reduce((s, t) => s + (trancheBalances.get(t.id) ?? 0), 0);
          break;
        case 'remaining_cash':
          requested = cashAvailable;
          break;
      }

      let paid = Math.min(cashAvailable, Math.max(0, requested));
      deductSourceCash(paid);

      let unpaid = Math.max(0, requested - paid);
      let drawnFromReserve = 0;
      let deferredToPik = 0;

      // Handle Shortfall Treatment
      if (unpaid > 1e-6 && rule.shortfallTreatment === 'draw_reserve' && reserveAccount > 0) {
        drawnFromReserve = Math.min(reserveAccount, unpaid);
        reserveAccount -= drawnFromReserve;
        paid += drawnFromReserve;
        unpaid -= drawnFromReserve;
      }

      if (unpaid > 1e-6 && rule.shortfallTreatment === 'defer_pik' && targetTranche?.isDeferrable) {
        deferredToPik = unpaid;
        deferredInterest.set(targetTranche.id, (deferredInterest.get(targetTranche.id) ?? 0) + deferredToPik);
        trancheBalances.set(targetTranche.id, (trancheBalances.get(targetTranche.id) ?? 0) + deferredToPik);
        trancheInterestDeferred.set(
          targetTranche.id,
          (trancheInterestDeferred.get(targetTranche.id) ?? 0) + deferredToPik
        );
        unpaid = 0;
      }

      // Apply payment effect by rule type
      if (rule.ruleType === 'fee_expense') {
        feesPaid += paid;
      } else if (rule.ruleType === 'reserve_funding') {
        reserveAccount += paid;
      } else if (rule.ruleType === 'coverage_diversion') {
        // Divert from interest account into principal account (or direct senior principal cure)
        principalAccount += paid;
        diversionAmount += paid;
        totalDivertedCash += paid;
      } else if (rule.ruleType === 'senior_interest' || rule.ruleType === 'sub_interest' || rule.ruleType === 'synthetic_premium') {
        if (targetTranche) {
          trancheInterestPaid.set(targetTranche.id, (trancheInterestPaid.get(targetTranche.id) ?? 0) + paid);
          trancheInterestShortfall.set(
            targetTranche.id,
            (trancheInterestShortfall.get(targetTranche.id) ?? 0) + unpaid
          );
        }
        totalExternalInterestOut += paid;
      } else if (rule.ruleType === 'deferred_interest_cure') {
        if (targetTranche) {
          const curDef = deferredInterest.get(targetTranche.id) ?? 0;
          const cureAmt = Math.min(curDef, paid);
          deferredInterest.set(targetTranche.id, curDef - cureAmt);
          trancheBalances.set(targetTranche.id, Math.max(0, (trancheBalances.get(targetTranche.id) ?? 0) - cureAmt));
          trancheInterestPaid.set(targetTranche.id, (trancheInterestPaid.get(targetTranche.id) ?? 0) + paid);
        }
        totalExternalInterestOut += paid;
      } else if (rule.ruleType === 'reinvestment') {
        // Purchase new performing collateral assets at reinvestmentPricePct
        if (deal.structureType === 'cash' && paid > 0) {
          const parPurchased = paid / (assumptions.reinvestmentPricePct / 100);
          const perAssetAdd = parPurchased / Math.max(1, assets.length);
          for (let idx = 0; idx < assetBalances.length; idx++) {
            assetBalances[idx] += perAssetAdd;
          }
          reinvestedPrincipal += paid;
        }
      } else if (rule.ruleType === 'principal_repayment' || rule.ruleType === 'early_amortisation') {
        let remToPay = paid;
        const debtTranches = sortedTranches
          .filter((t) => t.seniority !== 'equity' && t.isFunded)
          .sort((a, b) => a.principalPriority - b.principalPriority);

        if (rule.repaymentMode === 'pro_rata' && rule.ruleType !== 'early_amortisation' && ocTestPassed && icTestPassed) {
          const totalDebt = debtTranches.reduce((s, t) => s + (trancheBalances.get(t.id) ?? 0), 0);
          if (totalDebt > 0) {
            for (const t of debtTranches) {
              const bal = trancheBalances.get(t.id) ?? 0;
              const share = Math.min(bal, remToPay * (bal / totalDebt));
              trancheBalances.set(t.id, bal - share);
              tranchePrincipalPaid.set(t.id, (tranchePrincipalPaid.get(t.id) ?? 0) + share);
            }
          }
        } else {
          for (const t of debtTranches) {
            if (remToPay <= 0) break;
            const bal = trancheBalances.get(t.id) ?? 0;
            const pay = Math.min(bal, remToPay);
            if (pay > 0) {
              trancheBalances.set(t.id, bal - pay);
              tranchePrincipalPaid.set(t.id, (tranchePrincipalPaid.get(t.id) ?? 0) + pay);
              remToPay -= pay;
            }
          }
        }
        // Any excess principal after all funded debt is retired flows to equity residual principal
        if (remToPay > 0) {
          const eq = sortedTranches.find((t) => t.seniority === 'equity');
          if (eq) {
            const eqBal = trancheBalances.get(eq.id) ?? 0;
            const eqPay = Math.min(eqBal, remToPay);
            trancheBalances.set(eq.id, eqBal - eqPay);
            tranchePrincipalPaid.set(eq.id, (tranchePrincipalPaid.get(eq.id) ?? 0) + eqPay);
          }
        }
        totalExternalPrincipalOut += paid;
      } else if (rule.ruleType === 'residual_equity') {
        const eq = sortedTranches.find((t) => t.seniority === 'equity');
        if (eq) {
          trancheInterestPaid.set(eq.id, (trancheInterestPaid.get(eq.id) ?? 0) + paid);
        }
        equityDistributed += paid;
        totalExternalInterestOut += paid;
      } else if (rule.ruleType === 'synthetic_loss_settlement') {
        // Reserve or collateral account transfers loss settlement to protection buyer
        totalExternalPrincipalOut += paid;
      }

      auditLines.push({
        priority: rule.priority,
        ruleId: rule.id,
        ruleName: rule.name,
        account: rule.account,
        conditionEvaluated: cond.label,
        conditionMet: true,
        cashAvailable,
        ruleRequestedAmount: requested,
        paymentMade: paid,
        unpaidAmount: unpaid,
        deferredToPik,
        drawnFromReserve,
        remainingCash: getSourceCash(),
        destination: rule.destination,
      });
    }

    // End-of-period cash conservation check:
    // (startInterest + startPrincipal + beginningReserve) === (feesPaid + totalExternalInterestOut + totalExternalPrincipalOut + reinvestedPrincipal + interestAccount + principalAccount + reserveAccount)
    const totalInflows = startInterestAccount + startPrincipalAccount + beginningReserve;
    const totalOutflows =
      feesPaid +
      totalExternalInterestOut +
      totalExternalPrincipalOut +
      reinvestedPrincipal;
    const endingIdleAndReserve = interestAccount + principalAccount + reserveAccount;
    const cashConservationResidual = totalInflows - (totalOutflows + endingIdleAndReserve);
    maxCashConservationError = Math.max(maxCashConservationError, Math.abs(cashConservationResidual));

    // Roll forward any idle remaining cash into next period reserve or final equity sweep at maturity
    if (p === totalPeriods) {
      const finalSweep = interestAccount + principalAccount + reserveAccount;
      if (finalSweep > 0) {
        const eq = sortedTranches.find((t) => t.seniority === 'equity');
        if (eq) {
          trancheInterestPaid.set(eq.id, (trancheInterestPaid.get(eq.id) ?? 0) + finalSweep);
        }
        interestAccount = 0;
        principalAccount = 0;
        reserveAccount = 0;
      }
    } else {
      reserveAccount += interestAccount + principalAccount;
      interestAccount = 0;
      principalAccount = 0;
    }

    // Capitalize unpaid accrued coupon to PIK for deferrable tranches when blocked by coverage tests
    for (const t of sortedTranches) {
      if (t.seniority === 'equity') continue;
      const accrued = trancheInterestAccrued.get(t.id) ?? 0;
      const paid = trancheInterestPaid.get(t.id) ?? 0;
      const alreadyDeferred = trancheInterestDeferred.get(t.id) ?? 0;
      const remainingUnpaid = Math.max(0, accrued - paid - alreadyDeferred);
      if (remainingUnpaid > 1e-6) {
        if (t.isDeferrable) {
          deferredInterest.set(t.id, (deferredInterest.get(t.id) ?? 0) + remainingUnpaid);
          trancheBalances.set(t.id, (trancheBalances.get(t.id) ?? 0) + remainingUnpaid);
          trancheInterestDeferred.set(t.id, alreadyDeferred + remainingUnpaid);
        } else {
          trancheInterestShortfall.set(
            t.id,
            Math.max(trancheInterestShortfall.get(t.id) ?? 0, remainingUnpaid)
          );
        }
      }
    }

    // Allocate cash CDO principal writedowns at final maturity if collateral exhausted
    if (p === totalPeriods && deal.structureType === 'cash') {
      const debtLossOrder = [...sortedTranches].sort((a, b) => b.lossAllocationOrder - a.lossAllocationOrder);
      for (const t of debtLossOrder) {
        const remBal = trancheBalances.get(t.id) ?? 0;
        if (remBal > 0 && t.seniority !== 'equity') {
          trancheLossAllocated.set(t.id, (trancheLossAllocated.get(t.id) ?? 0) + remBal);
        }
      }
    }

    const trancheStates: TranchePeriodState[] = sortedTranches.map((t) => ({
      trancheId: t.id,
      code: t.code,
      beginningBalance: trancheBeg.get(t.id) ?? 0,
      interestAccrued: trancheInterestAccrued.get(t.id) ?? 0,
      interestPaid: trancheInterestPaid.get(t.id) ?? 0,
      interestDeferred: trancheInterestDeferred.get(t.id) ?? 0,
      interestShortfall: trancheInterestShortfall.get(t.id) ?? 0,
      principalPaid: tranchePrincipalPaid.get(t.id) ?? 0,
      lossAllocated: trancheLossAllocated.get(t.id) ?? 0,
      endingBalance: trancheBalances.get(t.id) ?? 0,
    }));

    const endingPoolBalance = assetBalances.reduce((s, b) => s + b, 0);
    const refOutstanding = Math.max(0, initialPoolPrincipal - cumulativeSyntheticLoss);
    const counterpartyExposure =
      deal.structureType === 'synthetic'
        ? sortedTranches.filter((t) => !t.isFunded).reduce((s, t) => s + (trancheBalances.get(t.id) ?? 0), 0)
        : 0;

    periodResults.push({
      period: p,
      periodLabel: deal.periodFrequency === 'monthly' ? `M${p}` : `Q${p}`,
      inReinvestment,
      earlyAmortTriggered,
      beginningPoolBalance,
      scheduledInterestInflow: scheduledInterest,
      scheduledPrincipalInflow: scheduledPrincipal,
      prepaymentInflow: prepayments,
      defaultPrincipal: periodDefaults,
      recoveryInflow,
      reinvestedPrincipal,
      endingPoolBalance,
      beginningReserve,
      endingReserve: reserveAccount,
      interestAccountAvailable: startInterestAccount,
      principalAccountAvailable: startPrincipalAccount,
      ocRatioBefore,
      icRatioBefore,
      ocTestPassed,
      icTestPassed,
      diversionAmount,
      feesPaid,
      totalCashInflows: totalInflows,
      totalCashOutflows: totalOutflows,
      cashConservationResidual,
      trancheStates,
      auditLines,
      syntheticReferenceNotional: deal.structureType === 'synthetic' ? refOutstanding : 0,
      syntheticFundedCollateral: deal.structureType === 'synthetic' ? syntheticFundedCollateral : 0,
      syntheticProtectionPremium,
      syntheticLossSettled,
      syntheticCounterpartyExposure: counterpartyExposure,
    });
  }

  return {
    dealId: deal.id,
    structureId: deal.activeStructureId,
    structureType: deal.structureType,
    periods: periodResults,
    capitalReconciliation: reconciliation,
    maxCashConservationError,
    ruleCycleDetected: false,
    totalCollateralInterest,
    totalCollateralDefaults,
    totalCollateralRecoveries,
    totalDivertedCash,
    ocBreachPeriods,
    icBreachPeriods,
  };
}
