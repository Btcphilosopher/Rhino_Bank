export type AssetClass = 'semiconductor' | 'corporate_debt' | 'equipment_finance';
export type StructureType = 'cash' | 'synthetic';
export type PeriodFrequency = 'quarterly' | 'monthly';
export type DealStatus = 'draft' | 'pending_approval' | 'active' | 'amortising';
export type TrancheSeniority = 'senior' | 'mezzanine' | 'junior' | 'equity';
export type DelinquencyStatus = 'current' | '30dpd' | '60dpd' | '90plus' | 'defaulted';

export interface CollateralAsset {
  // Observed / Contractual Information
  assetId: string;
  obligorId: string;
  obligorName: string;
  economicGroup: string;
  sharedDependency: string;
  sector: string;
  geography: string;
  currency: string;
  principalOutstanding: number;
  interestType: 'fixed' | 'floating';
  baseRateBps: number;
  spreadOrCouponBps: number;
  paymentSchedule: 'quarterly' | 'monthly' | 'semi_annual';
  originationDate: string;
  maturityDate: string;
  maturityPeriods: number;
  securityType: string;
  seniority: 'senior_secured' | 'second_lien' | 'senior_unsecured' | 'subordinated';
  delinquencyStatus: DelinquencyStatus;
  suppliedRating?: string;

  // Explicit Model Assumptions (never conflated with observed data)
  assumedAnnualPd: number;
  assumedRecoveryRate: number;
  assumedRecoveryLagPeriods: number;
  assumedPrepaymentCpr: number;
  correlationBeta: number;
}

export interface CollateralValidationIssue {
  rowIndex: number;
  assetId: string;
  field: string;
  severity: 'error' | 'warning';
  message: string;
}

export interface ConcentrationBucket {
  label: string;
  principal: number;
  sharePct: number;
  assetCount: number;
  weightedPd: number;
}

export interface CollateralPoolAnalytics {
  totalPrincipal: number;
  assetCount: number;
  uniqueObligors: number;
  uniqueEconomicGroups: number;
  weightedAvgCouponBps: number;
  weightedAvgSpreadBps: number;
  weightedAvgMaturityPeriods: number;
  weightedAvgAssumedPd: number;
  weightedAvgAssumedRecovery: number;
  weightedAvgPrepaymentCpr: number;
  delinquentPrincipal: number;
  defaultedPrincipal: number;
  byEconomicGroup: ConcentrationBucket[];
  bySector: ConcentrationBucket[];
  byGeography: ConcentrationBucket[];
  byMaturityBucket: ConcentrationBucket[];
  bySharedDependency: ConcentrationBucket[];
  bySeniority: ConcentrationBucket[];
}

export interface CollateralValidationResult {
  valid: boolean;
  errorCount: number;
  warningCount: number;
  issues: CollateralValidationIssue[];
  assets: CollateralAsset[];
  analytics: CollateralPoolAnalytics;
}

export interface CollateralTape {
  id: string;
  dealId: string;
  versionNumber: number;
  sourceFormat: 'csv' | 'json' | 'seed';
  sourceFileName: string;
  totalPrincipal: number;
  assetCount: number;
  validationSummary: {
    errorCount: number;
    warningCount: number;
    currency: string;
  };
  assets: CollateralAsset[];
  createdAt: string;
}

export interface TrancheDefinition {
  id: string;
  code: string;
  suppliedRating?: string;
  seniority: TrancheSeniority;
  notional: number;
  issuePricePct: number;
  couponType: 'floating' | 'fixed' | 'residual';
  spreadOrCouponBps: number;
  maturityPeriods: number;
  paymentPriority: number;
  principalPriority: number;
  isDeferrable: boolean;
  lossAllocationOrder: number;
  redemptionProvision: string;
  isFunded: boolean;
  referenceNotional: number;
  attachmentPct: number;
  detachmentPct: number;
}

export type WaterfallRuleType =
  | 'fee_expense'
  | 'senior_interest'
  | 'reserve_funding'
  | 'coverage_diversion'
  | 'sub_interest'
  | 'deferred_interest_cure'
  | 'principal_repayment'
  | 'reinvestment'
  | 'early_amortisation'
  | 'residual_equity'
  | 'synthetic_premium'
  | 'synthetic_loss_settlement';

export type WaterfallCondition =
  | 'always'
  | 'oc_test_pass'
  | 'oc_test_fail'
  | 'ic_test_pass'
  | 'ic_test_fail'
  | 'test_pass'
  | 'test_fail'
  | 'in_reinvestment'
  | 'post_reinvestment'
  | 'early_amort_triggered';

export type WaterfallCalculationMethod =
  | 'fixed_amount'
  | 'bps_of_pool'
  | 'accrued_coupon'
  | 'reserve_topup'
  | 'target_oc_cure'
  | 'sequential_principal'
  | 'pro_rata_principal'
  | 'reinvest_eligible'
  | 'deferred_interest_balance'
  | 'remaining_cash';

export type ShortfallTreatment = 'unpaid_shortfall' | 'defer_pik' | 'draw_reserve' | 'divert_next';

export interface WaterfallRule {
  id: string;
  priority: number;
  name: string;
  account: 'interest' | 'principal';
  ruleType: WaterfallRuleType;
  condition: WaterfallCondition;
  sourceAccount: 'interest' | 'principal' | 'reserve';
  destination: string;
  trancheId?: string;
  calculationMethod: WaterfallCalculationMethod;
  repaymentMode: 'sequential' | 'pro_rata';
  shortfallTreatment: ShortfallTreatment;
  fixedAmount?: number;
  bpsRate?: number;
  dependsOnRuleId?: string;
}

export interface DealAssumptions {
  // Real-World Projection Assumptions
  pdMultiplier: number;
  recoveryMultiplier: number;
  recoveryLagPeriodsOverride?: number;
  prepaymentCprMultiplier: number;
  defaultCorrelationRho: number;
  clusterShockFactor: number;
  referenceRateBps: number;
  rateShockBps: number;
  reinvestmentPricePct: number;

  // Market Pricing Assumptions (strictly separated from real-world projections)
  riskFreeCurveBps: number;
  liquidityPremiumBps: number;
  marketSpreadAdjustmentBps: number;
}

export interface DealStructure {
  id: string;
  dealId: string;
  name: string;
  versionNumber: number;
  isBase: boolean;
  tranches: TrancheDefinition[];
  waterfallRules: WaterfallRule[];
  assumptions: DealAssumptions;
  createdAt: string;
  updatedAt: string;
}

export interface DealRecord {
  id: string;
  name: string;
  code: string;
  assetClass: AssetClass;
  structureType: StructureType;
  currency: string;
  targetPoolNotional: number;
  reinvestmentPeriods: number;
  maturityPeriods: number;
  periodFrequency: PeriodFrequency;
  status: DealStatus;
  version: number;
  activeTapeId: string;
  activeStructureId: string;
  reserveTarget: number;
  reserveBalance: number;
  annualSeniorFeeBps: number;
  annualTrusteeFee: number;
  ocTriggerRatio: number;
  icTriggerRatio: number;
  issuanceExpenses: number;
  createdAt: string;
  updatedAt: string;
}

export interface PeriodAuditLine {
  priority: number;
  ruleId: string;
  ruleName: string;
  account: 'interest' | 'principal';
  conditionEvaluated: string;
  conditionMet: boolean;
  cashAvailable: number;
  ruleRequestedAmount: number;
  paymentMade: number;
  unpaidAmount: number;
  deferredToPik: number;
  drawnFromReserve: number;
  remainingCash: number;
  destination: string;
}

export interface TranchePeriodState {
  trancheId: string;
  code: string;
  beginningBalance: number;
  interestAccrued: number;
  interestPaid: number;
  interestDeferred: number;
  interestShortfall: number;
  principalPaid: number;
  lossAllocated: number;
  endingBalance: number;
}

export interface WaterfallPeriodResult {
  period: number;
  periodLabel: string;
  inReinvestment: boolean;
  earlyAmortTriggered: boolean;
  beginningPoolBalance: number;
  scheduledInterestInflow: number;
  scheduledPrincipalInflow: number;
  prepaymentInflow: number;
  defaultPrincipal: number;
  recoveryInflow: number;
  reinvestedPrincipal: number;
  endingPoolBalance: number;
  beginningReserve: number;
  endingReserve: number;
  interestAccountAvailable: number;
  principalAccountAvailable: number;
  ocRatioBefore: number;
  icRatioBefore: number;
  ocTestPassed: boolean;
  icTestPassed: boolean;
  diversionAmount: number;
  feesPaid: number;
  totalCashInflows: number;
  totalCashOutflows: number;
  cashConservationResidual: number;
  trancheStates: TranchePeriodState[];
  auditLines: PeriodAuditLine[];
  // Synthetic-specific accounting
  syntheticReferenceNotional: number;
  syntheticFundedCollateral: number;
  syntheticProtectionPremium: number;
  syntheticLossSettled: number;
  syntheticCounterpartyExposure: number;
}

export interface CapitalReconciliation {
  collateralAssets: number;
  reserveAccount: number;
  totalAssetsAndReserves: number;
  fundedNotesNotional: number;
  unfundedProtectionNotional: number;
  equityNotional: number;
  totalLiabilitiesAndEquity: number;
  grossIssuanceProceeds: number;
  issuanceExpenses: number;
  netIssuanceProceeds: number;
  fundingSurplusOrDeficit: number;
  reconciled: boolean;
}

export interface WaterfallRunResult {
  dealId: string;
  structureId: string;
  structureType: StructureType;
  periods: WaterfallPeriodResult[];
  capitalReconciliation: CapitalReconciliation;
  maxCashConservationError: number;
  ruleCycleDetected: boolean;
  ruleCycleError?: string;
  totalCollateralInterest: number;
  totalCollateralDefaults: number;
  totalCollateralRecoveries: number;
  totalDivertedCash: number;
  ocBreachPeriods: number[];
  icBreachPeriods: number[];
}

export interface TrancheSimulationMetrics {
  trancheId: string;
  code: string;
  seniority: TrancheSeniority;
  initialNotional: number;
  issuePricePct: number;
  attachmentPct: number;
  detachmentPct: number;
  isFunded: boolean;
  // Real-world metrics
  expectedPrincipalLoss: number;
  expectedLossPct: number;
  probabilityOfImpairment: number;
  expectedInterestShortfall: number;
  weightedAverageLifeYears: number;
  realWorldIrrPct: number;
  coverageBreachExposurePct: number;
  p95LossPct: number;
  p99LossPct: number;
  // Market pricing metrics (analytical only, not executable quotes)
  discountedPresentValue: number;
  discountedPricePct: number;
  modelImpliedSpreadBps: number;
}

export interface SimulationRunResult {
  id: string;
  dealId: string;
  structureId: string;
  scenarioName: string;
  modelVersion: string;
  seed: number;
  numPaths: number;
  assumptionsSnapshot: DealAssumptions;
  trancheMetrics: TrancheSimulationMetrics[];
  summaryMetrics: {
    meanPoolLossPct: number;
    p95PoolLossPct: number;
    p99PoolLossPct: number;
    meanTotalDefaults: number;
    meanTotalRecoveries: number;
    ocBreachPathPct: number;
    icBreachPathPct: number;
    liquidityShortfallPathPct: number;
    issuerNetFundingSpreadBps: number;
    executionTimeMs: number;
  };
  lossHistogram: { bucketLabel: string; minPct: number; maxPct: number; pathCount: number; probabilityPct: number }[];
  deterministicBase: WaterfallRunResult;
  createdAt: string;
}

export interface OptimizationConstraints {
  maxSeniorImpairmentProb: number;
  maxSeniorWalYears: number;
  minEquityIrrPct: number;
  minOcCushionPct: number;
  minReservePct: number;
}

export interface OptimizationCandidate {
  id: string;
  label: string;
  seniorPct: number;
  mezzPct: number;
  juniorPct: number;
  equityPct: number;
  reservePct: number;
  seniorImpairmentProb: number;
  seniorWalYears: number;
  equityIrrPct: number;
  weightedAvgCostOfDebtBps: number;
  ocCushionPct: number;
  feasible: boolean;
  objectiveScore: number;
  sensitivityDeltaEquityIrrOnPdPlus50: number;
  sensitivityDeltaSeniorLossOnRhoPlus20: number;
}

export interface SurveillanceBreach {
  code: string;
  testName: string;
  threshold: number;
  observed: number;
  actionTaken: string;
}

export interface CollateralSubstitution {
  id: string;
  removedAssetId: string;
  removedObligor: string;
  addedAssetId: string;
  addedObligor: string;
  notionalDelta: number;
  approvedBy: string;
  timestamp: string;
}

export interface SurveillancePeriodRecord {
  id: string;
  dealId: string;
  periodNumber: number;
  periodLabel: string;
  asOfDate: string;
  isFinalized: boolean;
  actualCollections: number;
  projectedCollections: number;
  actualDefaults: number;
  projectedDefaults: number;
  actualRecoveries: number;
  projectedRecoveries: number;
  endingPoolBalance: number;
  delinquency30Plus: number;
  delinquency60Plus: number;
  ocRatio: number;
  icRatio: number;
  reserveBalance: number;
  trancheDistributions: { code: string; interestPaid: number; principalPaid: number; endingBalance: number }[];
  breaches: SurveillanceBreach[];
  substitutions: CollateralSubstitution[];
  forecastSnapshot: {
    modelVersion: string;
    seed: number;
    assumedPdMultiplier: number;
    assumedRecoveryMultiplier: number;
    frozenAt: string;
  };
  createdAt: string;
}

export interface ApprovalRequestRecord {
  id: string;
  dealId: string;
  makerUid: string;
  makerEmail: string;
  checkerUid?: string;
  checkerEmail?: string;
  actionType: 'structure_update' | 'waterfall_update' | 'collateral_substitution' | 'period_finalization' | 'deal_activation';
  summary: string;
  payloadDiff: Record<string, unknown>;
  status: 'pending' | 'approved' | 'rejected';
  decisionNote?: string;
  createdAt: string;
  decidedAt?: string;
}
