import type {
  CollateralAsset,
  CollateralPoolAnalytics,
  CollateralValidationIssue,
  CollateralValidationResult,
  ConcentrationBucket,
} from './types.ts';

const REQUIRED_FIELDS: (keyof CollateralAsset)[] = [
  'assetId',
  'obligorId',
  'obligorName',
  'economicGroup',
  'sector',
  'geography',
  'currency',
  'principalOutstanding',
  'interestType',
  'spreadOrCouponBps',
  'paymentSchedule',
  'originationDate',
  'maturityDate',
  'maturityPeriods',
  'securityType',
  'seniority',
  'delinquencyStatus',
  'assumedAnnualPd',
  'assumedRecoveryRate',
  'assumedRecoveryLagPeriods',
  'assumedPrepaymentCpr',
];

function buildConcentration(
  assets: CollateralAsset[],
  totalPrincipal: number,
  keyFn: (a: CollateralAsset) => string
): ConcentrationBucket[] {
  const map = new Map<string, { principal: number; count: number; weightedPdSum: number }>();
  for (const asset of assets) {
    const k = keyFn(asset) || 'Unspecified';
    const cur = map.get(k) ?? { principal: 0, count: 0, weightedPdSum: 0 };
    cur.principal += asset.principalOutstanding;
    cur.count += 1;
    cur.weightedPdSum += asset.principalOutstanding * asset.assumedAnnualPd;
    map.set(k, cur);
  }
  return Array.from(map.entries())
    .map(([label, v]) => ({
      label,
      principal: v.principal,
      sharePct: totalPrincipal > 0 ? (v.principal / totalPrincipal) * 100 : 0,
      assetCount: v.count,
      weightedPd: v.principal > 0 ? v.weightedPdSum / v.principal : 0,
    }))
    .sort((a, b) => b.principal - a.principal);
}

export function computePoolAnalytics(assets: CollateralAsset[]): CollateralPoolAnalytics {
  const totalPrincipal = assets.reduce((s, a) => s + a.principalOutstanding, 0);
  const safeDenom = totalPrincipal > 0 ? totalPrincipal : 1;

  const obligors = new Set(assets.map((a) => a.obligorId));
  const groups = new Set(assets.map((a) => a.economicGroup));

  let weightedCoupon = 0;
  let weightedSpread = 0;
  let weightedMaturity = 0;
  let weightedPd = 0;
  let weightedRecovery = 0;
  let weightedCpr = 0;
  let delinquentPrincipal = 0;
  let defaultedPrincipal = 0;

  for (const a of assets) {
    const w = a.principalOutstanding / safeDenom;
    const allInCoupon = a.interestType === 'floating' ? a.baseRateBps + a.spreadOrCouponBps : a.spreadOrCouponBps;
    weightedCoupon += w * allInCoupon;
    weightedSpread += w * a.spreadOrCouponBps;
    weightedMaturity += w * a.maturityPeriods;
    weightedPd += w * a.assumedAnnualPd;
    weightedRecovery += w * a.assumedRecoveryRate;
    weightedCpr += w * a.assumedPrepaymentCpr;
    if (a.delinquencyStatus === '30dpd' || a.delinquencyStatus === '60dpd' || a.delinquencyStatus === '90plus') {
      delinquentPrincipal += a.principalOutstanding;
    }
    if (a.delinquencyStatus === 'defaulted') {
      defaultedPrincipal += a.principalOutstanding;
    }
  }

  return {
    totalPrincipal,
    assetCount: assets.length,
    uniqueObligors: obligors.size,
    uniqueEconomicGroups: groups.size,
    weightedAvgCouponBps: weightedCoupon,
    weightedAvgSpreadBps: weightedSpread,
    weightedAvgMaturityPeriods: weightedMaturity,
    weightedAvgAssumedPd: weightedPd,
    weightedAvgAssumedRecovery: weightedRecovery,
    weightedAvgPrepaymentCpr: weightedCpr,
    delinquentPrincipal,
    defaultedPrincipal,
    byEconomicGroup: buildConcentration(assets, totalPrincipal, (a) => a.economicGroup),
    bySector: buildConcentration(assets, totalPrincipal, (a) => a.sector),
    byGeography: buildConcentration(assets, totalPrincipal, (a) => a.geography),
    byMaturityBucket: buildConcentration(assets, totalPrincipal, (a) => {
      if (a.maturityPeriods <= 8) return '0-2Y (<=8Q)';
      if (a.maturityPeriods <= 16) return '2-4Y (9-16Q)';
      if (a.maturityPeriods <= 24) return '4-6Y (17-24Q)';
      return '6Y+ (>24Q)';
    }),
    bySharedDependency: buildConcentration(assets, totalPrincipal, (a) => a.sharedDependency),
    bySeniority: buildConcentration(assets, totalPrincipal, (a) => a.seniority),
  };
}

export function validateCollateralRecords(
  rawRecords: Partial<CollateralAsset>[],
  expectedCurrency = 'USD'
): CollateralValidationResult {
  const issues: CollateralValidationIssue[] = [];
  const seenAssetIds = new Set<string>();
  const validatedAssets: CollateralAsset[] = [];

  rawRecords.forEach((rec, idx) => {
    const assetId = String(rec.assetId ?? `ROW_${idx + 1}`).trim();

    for (const field of REQUIRED_FIELDS) {
      const val = rec[field];
      if (val === undefined || val === null || val === '') {
        issues.push({
          rowIndex: idx + 1,
          assetId,
          field,
          severity: 'error',
          message: `Missing required field "${field}".`,
        });
      }
    }

    if (seenAssetIds.has(assetId)) {
      issues.push({
        rowIndex: idx + 1,
        assetId,
        field: 'assetId',
        severity: 'error',
        message: `Duplicate asset identifier "${assetId}".`,
      });
    }
    seenAssetIds.add(assetId);

    const currency = String(rec.currency ?? expectedCurrency).toUpperCase().trim();
    if (currency !== expectedCurrency) {
      issues.push({
        rowIndex: idx + 1,
        assetId,
        field: 'currency',
        severity: 'error',
        message: `Currency unit mismatch: expected ${expectedCurrency}, found ${currency}.`,
      });
    }

    const principal = Number(rec.principalOutstanding ?? 0);
    if (!Number.isFinite(principal) || principal <= 0) {
      issues.push({
        rowIndex: idx + 1,
        assetId,
        field: 'principalOutstanding',
        severity: 'error',
        message: `Principal outstanding must be positive (found ${rec.principalOutstanding}).`,
      });
    }

    const orig = rec.originationDate ? Date.parse(String(rec.originationDate)) : NaN;
    const mat = rec.maturityDate ? Date.parse(String(rec.maturityDate)) : NaN;
    if (Number.isNaN(orig) || Number.isNaN(mat)) {
      issues.push({
        rowIndex: idx + 1,
        assetId,
        field: 'maturityDate',
        severity: 'error',
        message: `Invalid ISO date format for originationDate (${rec.originationDate}) or maturityDate (${rec.maturityDate}).`,
      });
    } else if (mat <= orig) {
      issues.push({
        rowIndex: idx + 1,
        assetId,
        field: 'maturityDate',
        severity: 'error',
        message: `Inconsistent dates: maturityDate (${rec.maturityDate}) must be after originationDate (${rec.originationDate}).`,
      });
    }

    const pd = Number(rec.assumedAnnualPd ?? 0);
    if (!Number.isFinite(pd) || pd < 0 || pd > 1) {
      issues.push({
        rowIndex: idx + 1,
        assetId,
        field: 'assumedAnnualPd',
        severity: 'error',
        message: `Assumed annual PD must be between 0 and 1 (found ${rec.assumedAnnualPd}).`,
      });
    }

    const recRate = Number(rec.assumedRecoveryRate ?? 0);
    if (!Number.isFinite(recRate) || recRate < 0 || recRate > 1) {
      issues.push({
        rowIndex: idx + 1,
        assetId,
        field: 'assumedRecoveryRate',
        severity: 'error',
        message: `Assumed recovery rate must be between 0 and 1 (found ${rec.assumedRecoveryRate}).`,
      });
    }

    const cpr = Number(rec.assumedPrepaymentCpr ?? 0);
    if (!Number.isFinite(cpr) || cpr < 0 || cpr > 1) {
      issues.push({
        rowIndex: idx + 1,
        assetId,
        field: 'assumedPrepaymentCpr',
        severity: 'error',
        message: `Assumed CPR prepayment rate must be between 0 and 1 (found ${rec.assumedPrepaymentCpr}).`,
      });
    }

    const spread = Number(rec.spreadOrCouponBps ?? 0);
    if (spread < 0 || spread > 5000) {
      issues.push({
        rowIndex: idx + 1,
        assetId,
        field: 'spreadOrCouponBps',
        severity: 'warning',
        message: `Unusual spread/coupon (${spread} bps) flagged for analyst review.`,
      });
    }

    if (!rec.sharedDependency || rec.sharedDependency === 'None') {
      // valid, no warning
    }

    validatedAssets.push({
      assetId,
      obligorId: String(rec.obligorId ?? `OBL_${idx + 1}`).trim(),
      obligorName: String(rec.obligorName ?? 'Unnamed Obligor').trim(),
      economicGroup: String(rec.economicGroup ?? rec.obligorName ?? 'Independent').trim(),
      sharedDependency: String(rec.sharedDependency ?? 'None').trim(),
      sector: String(rec.sector ?? 'General').trim(),
      geography: String(rec.geography ?? 'US').trim(),
      currency,
      principalOutstanding: Number.isFinite(principal) ? principal : 0,
      interestType: rec.interestType === 'fixed' ? 'fixed' : 'floating',
      baseRateBps: Number(rec.baseRateBps ?? (rec.interestType === 'fixed' ? 0 : 425)),
      spreadOrCouponBps: Number.isFinite(spread) ? spread : 0,
      paymentSchedule:
        rec.paymentSchedule === 'monthly' || rec.paymentSchedule === 'semi_annual'
          ? rec.paymentSchedule
          : 'quarterly',
      originationDate: String(rec.originationDate ?? '2026-01-15'),
      maturityDate: String(rec.maturityDate ?? '2031-01-15'),
      maturityPeriods: Math.max(1, Math.round(Number(rec.maturityPeriods ?? 20))),
      securityType: String(rec.securityType ?? 'First Lien Equipment & Receivables').trim(),
      seniority:
        rec.seniority === 'second_lien' ||
        rec.seniority === 'senior_unsecured' ||
        rec.seniority === 'subordinated'
          ? rec.seniority
          : 'senior_secured',
      delinquencyStatus:
        rec.delinquencyStatus === '30dpd' ||
        rec.delinquencyStatus === '60dpd' ||
        rec.delinquencyStatus === '90plus' ||
        rec.delinquencyStatus === 'defaulted'
          ? rec.delinquencyStatus
          : 'current',
      suppliedRating: rec.suppliedRating ? String(rec.suppliedRating).trim() : undefined,
      assumedAnnualPd: Number.isFinite(pd) ? pd : 0.02,
      assumedRecoveryRate: Number.isFinite(recRate) ? recRate : 0.55,
      assumedRecoveryLagPeriods: Math.max(0, Math.round(Number(rec.assumedRecoveryLagPeriods ?? 2))),
      assumedPrepaymentCpr: Number.isFinite(cpr) ? cpr : 0.06,
      correlationBeta: Number.isFinite(Number(rec.correlationBeta))
        ? Number(rec.correlationBeta)
        : 0.45,
    });
  });

  const errorCount = issues.filter((i) => i.severity === 'error').length;
  const warningCount = issues.filter((i) => i.severity === 'warning').length;
  const analytics = computePoolAnalytics(validatedAssets);

  return {
    valid: errorCount === 0 && validatedAssets.length > 0,
    errorCount,
    warningCount,
    issues,
    assets: validatedAssets,
    analytics,
  };
}

export function parseCsvLine(line: string): string[] {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (inQuotes && line[i + 1] === '"') {
        current += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (ch === ',' && !inQuotes) {
      result.push(current.trim());
      current = '';
    } else {
      current += ch;
    }
  }
  result.push(current.trim());
  return result;
}

export function parseCollateralImport(
  rawText: string,
  format: 'csv' | 'json',
  expectedCurrency = 'USD'
): CollateralValidationResult {
  if (format === 'json') {
    const parsed = JSON.parse(rawText);
    const arr = Array.isArray(parsed) ? parsed : Array.isArray(parsed?.assets) ? parsed.assets : [];
    return validateCollateralRecords(arr, expectedCurrency);
  }

  const lines = rawText
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0);
  if (lines.length < 2) {
    return validateCollateralRecords([], expectedCurrency);
  }
  const headers = parseCsvLine(lines[0]);
  const records: Partial<CollateralAsset>[] = lines.slice(1).map((line) => {
    const values = parseCsvLine(line);
    const obj: Record<string, unknown> = {};
    headers.forEach((h, i) => {
      const val = values[i] ?? '';
      if (
        [
          'principalOutstanding',
          'baseRateBps',
          'spreadOrCouponBps',
          'maturityPeriods',
          'assumedAnnualPd',
          'assumedRecoveryRate',
          'assumedRecoveryLagPeriods',
          'assumedPrepaymentCpr',
          'correlationBeta',
        ].includes(h)
      ) {
        obj[h] = val === '' ? undefined : Number(val);
      } else {
        obj[h] = val;
      }
    });
    return obj as Partial<CollateralAsset>;
  });

  return validateCollateralRecords(records, expectedCurrency);
}

export function serializeAssetsToCsv(assets: CollateralAsset[]): string {
  const headers: (keyof CollateralAsset)[] = [
    'assetId',
    'obligorId',
    'obligorName',
    'economicGroup',
    'sharedDependency',
    'sector',
    'geography',
    'currency',
    'principalOutstanding',
    'interestType',
    'baseRateBps',
    'spreadOrCouponBps',
    'paymentSchedule',
    'originationDate',
    'maturityDate',
    'maturityPeriods',
    'securityType',
    'seniority',
    'delinquencyStatus',
    'assumedAnnualPd',
    'assumedRecoveryRate',
    'assumedRecoveryLagPeriods',
    'assumedPrepaymentCpr',
    'correlationBeta',
  ];
  const rows = assets.map((a) =>
    headers
      .map((h) => {
        const val = a[h] ?? '';
        const s = String(val);
        return s.includes(',') ? `"${s.replace(/"/g, '""')}"` : s;
      })
      .join(',')
  );
  return [headers.join(','), ...rows].join('\n');
}
