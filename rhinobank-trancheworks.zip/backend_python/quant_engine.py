from __future__ import annotations

from typing import Any, Dict, List
import numpy as np
from scipy.stats import norm
from scipy.optimize import brentq

from waterfall_engine import execute_contractual_waterfall


def run_monte_carlo_scipy(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Seeded Gaussian factor copula Monte Carlo simulator using NumPy & SciPy."""
    seed = int(payload.get("seed", 202611))
    num_paths = int(payload.get("numPaths", 500))
    rho = float(payload.get("defaultCorrelationRho", 0.24))
    risk_free = float(payload.get("riskFreeCurveBps", 410))
    rng = np.random.default_rng(seed)

    assets = payload["assets"]
    tranches = payload["tranches"]
    n_assets = len(assets)
    total_pool = sum(float(a["principalOutstanding"]) for a in assets) or 1.0

    macro = rng.standard_normal(num_paths)
    idio = rng.standard_normal((num_paths, n_assets))
    z = np.sqrt(rho) * macro[:, None] + np.sqrt(max(0.01, 1.0 - rho)) * idio
    u = norm.cdf(z)

    annual_pds = np.array([float(a["assumedAnnualPd"]) * float(payload.get("pdMultiplier", 1.0)) for a in assets])
    cum_pds = 1.0 - np.power(1.0 - annual_pds, float(payload.get("maturityPeriods", 20)) / 4.0)
    principals = np.array([float(a["principalOutstanding"]) for a in assets])
    rec_rates = np.array([float(a["assumedRecoveryRate"]) * float(payload.get("recoveryMultiplier", 1.0)) for a in assets])

    defaults_matrix = (u < cum_pds[None, :]) * principals[None, :]
    rec_noise = np.clip(rec_rates[None, :] + rng.normal(0, 0.08, size=(num_paths, n_assets)), 0.05, 0.95)
    pool_losses = np.sum(defaults_matrix * (1.0 - rec_noise), axis=1)
    pool_loss_pct = (pool_losses / total_pool) * 100.0

    # Loss allocation across tranches bottom-up
    sorted_loss_order = sorted(tranches, key=lambda t: -t["paymentPriority"])
    tranche_summary: List[Dict[str, Any]] = []
    cum_attach = 0.0
    for t in sorted_loss_order:
        notional = float(t["notional"])
        attach = cum_attach
        detach = cum_attach + notional
        cum_attach = detach
        t_losses = np.clip(pool_losses - attach, 0.0, notional)
        exp_loss = float(np.mean(t_losses))
        imp_prob = float(np.mean(t_losses > notional * 0.001) * 100.0)
        tranche_summary.append({
            "code": t["code"],
            "expectedPrincipalLoss": round(exp_loss, 2),
            "expectedLossPct": round((exp_loss / max(1.0, notional)) * 100.0, 4),
            "probabilityOfImpairment": round(imp_prob, 2),
        })

    base_wf = execute_contractual_waterfall(payload)
    return {
        "seed": seed,
        "numPaths": num_paths,
        "meanPoolLossPct": round(float(np.mean(pool_loss_pct)), 4),
        "p95PoolLossPct": round(float(np.percentile(pool_loss_pct, 95)), 4),
        "p99PoolLossPct": round(float(np.percentile(pool_loss_pct, 99)), 4),
        "trancheMetrics": list(reversed(tranche_summary)),
        "baseWaterfallPeriods": len(base_wf["periods"]),
    }
