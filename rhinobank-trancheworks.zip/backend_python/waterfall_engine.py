from __future__ import annotations

from typing import Any, Dict, List
import numpy as np
from scipy.stats import norm
from scipy.optimize import brentq


def execute_contractual_waterfall(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Deterministic Cash / Synthetic waterfall kernel preserving exact cash conservation."""
    assets = payload["assets"]
    tranches = sorted(payload["tranches"], key=lambda t: t["paymentPriority"])
    total_periods = int(payload.get("maturityPeriods", 20))
    reinvest_periods = int(payload.get("reinvestmentPeriods", 6))
    oc_trigger = float(payload.get("ocTriggerRatio", 1.16))
    ref_rate = float(payload.get("referenceRateBps", 425))
    pd_mult = float(payload.get("pdMultiplier", 1.0))
    rec_mult = float(payload.get("recoveryMultiplier", 1.0))

    asset_bals = np.array([float(a["principalOutstanding"]) for a in assets], dtype=np.float64)
    annual_pds = np.array([min(0.95, float(a["assumedAnnualPd"]) * pd_mult) for a in assets])
    rec_rates = np.array([min(1.0, float(a["assumedRecoveryRate"]) * rec_mult) for a in assets])
    spreads = np.array([float(a["spreadOrCouponBps"]) for a in assets])
    is_floating = np.array([a["interestType"] == "floating" for a in assets])
    cprs = np.array([float(a["assumedPrepaymentCpr"]) for a in assets])
    lags = np.array([int(a["assumedRecoveryLagPeriods"]) for a in assets])

    tranche_bals = {t["id"]: float(t["notional"]) for t in tranches}
    reserve = float(payload.get("reserveBalance", 1500000.0))
    pending_rec = np.zeros(total_periods + 5, dtype=np.float64)
    periods_out: List[Dict[str, Any]] = []
    max_conservation_err = 0.0

    for p in range(1, total_periods + 1):
        in_reinvest = p <= reinvest_periods
        period_pd = 1.0 - np.power(1.0 - annual_pds, 0.25)
        defaults = asset_bals * period_pd
        performing = np.maximum(0.0, asset_bals - defaults)

        for idx, d_amt in enumerate(defaults):
            if d_amt > 0:
                land = min(total_periods, p + int(lags[idx]))
                pending_rec[land] += d_amt * rec_rates[idx]

        coupons = np.where(is_floating, ref_rate + spreads, spreads)
        int_inflow = float(np.sum(performing * (coupons / 10000.0) / 4.0))
        smm = 1.0 - np.power(1.0 - cprs, 0.25)
        prepay = performing * smm
        rem_after_prepay = np.maximum(0.0, performing - prepay)
        sched_prin = np.zeros_like(rem_after_prepay) if in_reinvest else rem_after_prepay * (1.0 / max(1, total_periods - p + 1))
        asset_bals = np.maximum(0.0, rem_after_prepay - sched_prin)

        rec_inflow = float(pending_rec[p])
        prin_inflow = float(np.sum(prepay + sched_prin)) + rec_inflow

        rated_debt = sum(tranche_bals[t["id"]] for t in tranches if t["seniority"] in ("senior", "mezzanine"))
        oc_ratio = (float(np.sum(asset_bals)) + prin_inflow + reserve) / max(1.0, rated_debt)
        oc_pass = oc_ratio >= oc_trigger

        cash_int = int_inflow
        cash_prin = prin_inflow
        beg_res = reserve

        # Senior fee (45 bps)
        fee = min(cash_int, float(np.sum(performing)) * 0.0045 / 4.0)
        cash_int -= fee

        int_paid_map = {t["id"]: 0.0 for t in tranches}
        prin_paid_map = {t["id"]: 0.0 for t in tranches}

        for t in tranches:
            if t["seniority"] == "equity":
                continue
            if not oc_pass and t["seniority"] in ("mezzanine", "junior"):
                continue
            rate = (ref_rate + t["spreadOrCouponBps"]) if t["couponType"] == "floating" else t["spreadOrCouponBps"]
            due = tranche_bals[t["id"]] * (rate / 10000.0) / 4.0
            pay = min(cash_int, due)
            cash_int -= pay
            int_paid_map[t["id"]] = pay

        diverted = 0.0
        if not oc_pass and cash_int > 0:
            diverted = cash_int
            cash_prin += diverted
            cash_int = 0.0

        if oc_pass and cash_int > 0:
            eq = next((t for t in tranches if t["seniority"] == "equity"), None)
            if eq:
                int_paid_map[eq["id"]] = cash_int
                cash_int = 0.0

        if in_reinvest and oc_pass:
            asset_bals += cash_prin / max(1, len(asset_bals))
            reinvested = cash_prin
            cash_prin = 0.0
        else:
            reinvested = 0.0
            rem_prin = cash_prin
            for t in tranches:
                if t["seniority"] == "equity":
                    continue
                pay_p = min(tranche_bals[t["id"]], rem_prin)
                tranche_bals[t["id"]] -= pay_p
                prin_paid_map[t["id"]] = pay_p
                rem_prin -= pay_p
            cash_prin = rem_prin

        total_in = int_inflow + prin_inflow + beg_res
        total_out = fee + sum(int_paid_map.values()) + sum(prin_paid_map.values()) + reinvested
        residual = total_in - (total_out + cash_int + cash_prin + reserve)
        max_conservation_err = max(max_conservation_err, abs(residual))

        periods_out.append({
            "period": p,
            "ocRatio": round(oc_ratio, 4),
            "ocPass": oc_pass,
            "diverted": round(diverted, 2),
            "interestInflow": round(int_inflow, 2),
            "principalInflow": round(prin_inflow, 2),
            "endingPool": round(float(np.sum(asset_bals)), 2),
            "trancheInterestPaid": int_paid_map,
            "tranchePrincipalPaid": prin_paid_map,
        })

    return {
        "periods": periods_out,
        "maxCashConservationError": max_conservation_err,
        "endingTrancheBalances": tranche_bals,
    }
