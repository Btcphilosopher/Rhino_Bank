from __future__ import annotations

from typing import Dict, List, Literal, Optional
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
import pandas as pd

from quant_engine import run_monte_carlo_scipy
from waterfall_engine import execute_contractual_waterfall

app = FastAPI(
    title="RhinoBank TrancheWorks Quantitative API",
    version="2.4.0",
    description="FastAPI + NumPy/SciPy/Pandas backend for CDO structuring, waterfall execution, and seeded Monte Carlo valuation.",
)


class AssetModel(BaseModel):
    assetId: str
    obligorId: str
    obligorName: str
    economicGroup: str
    sharedDependency: str = "None"
    sector: str
    geography: str
    currency: str = "USD"
    principalOutstanding: float = Field(gt=0)
    interestType: Literal["fixed", "floating"]
    baseRateBps: float = 425
    spreadOrCouponBps: float
    maturityPeriods: int = Field(ge=1)
    assumedAnnualPd: float = Field(ge=0, le=1)
    assumedRecoveryRate: float = Field(ge=0, le=1)
    assumedRecoveryLagPeriods: int = Field(ge=0)
    assumedPrepaymentCpr: float = Field(ge=0, le=1)


class TrancheModel(BaseModel):
    id: str
    code: str
    seniority: Literal["senior", "mezzanine", "junior", "equity"]
    notional: float = Field(ge=0)
    issuePricePct: float = Field(gt=0, le=120)
    couponType: Literal["floating", "fixed", "residual"]
    spreadOrCouponBps: float
    paymentPriority: int
    principalPriority: int
    isDeferrable: bool = False
    isFunded: bool = True


class SimulationPayload(BaseModel):
    dealId: str
    structureType: Literal["cash", "synthetic"] = "cash"
    maturityPeriods: int = 20
    reinvestmentPeriods: int = 6
    ocTriggerRatio: float = 1.16
    icTriggerRatio: float = 1.25
    reserveBalance: float = 1500000
    seed: int = 202611
    numPaths: int = Field(default=500, ge=10, le=20000)
    pdMultiplier: float = 1.0
    recoveryMultiplier: float = 1.0
    defaultCorrelationRho: float = 0.24
    referenceRateBps: float = 425
    riskFreeCurveBps: float = 410
    assets: List[AssetModel]
    tranches: List[TrancheModel]


@app.get("/health")
def health():
    return {"service": "rhinobank-trancheworks-py", "status": "healthy", "version": "2.4.0"}


@app.post("/api/v1/collateral/concentrations")
def collateral_concentrations(assets: List[AssetModel]):
    if not assets:
        raise HTTPException(status_code=400, detail="Asset tape cannot be empty.")
    df = pd.DataFrame([a.model_dump() for a in assets])
    total = float(df["principalOutstanding"].sum())
    return {
        "totalPrincipal": total,
        "assetCount": len(df),
        "byEconomicGroup": df.groupby("economicGroup")["principalOutstanding"].sum().sort_values(ascending=False).to_dict(),
        "bySector": df.groupby("sector")["principalOutstanding"].sum().sort_values(ascending=False).to_dict(),
        "byGeography": df.groupby("geography")["principalOutstanding"].sum().sort_values(ascending=False).to_dict(),
        "bySharedDependency": df.groupby("sharedDependency")["principalOutstanding"].sum().sort_values(ascending=False).to_dict(),
    }


@app.post("/api/v1/waterfall/execute")
def run_waterfall(payload: SimulationPayload):
    return execute_contractual_waterfall(payload.model_dump())


@app.post("/api/v1/simulations")
def run_simulation(payload: SimulationPayload):
    return run_monte_carlo_scipy(payload.model_dump())
