from __future__ import annotations

import os
from celery import Celery
from quant_engine import run_monte_carlo_scipy

REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")
celery_app = Celery("trancheworks", broker=REDIS_URL, backend=REDIS_URL)


@celery_app.task(name="trancheworks.run_simulation")
def run_simulation_task(payload: dict):
    return run_monte_carlo_scipy(payload)
