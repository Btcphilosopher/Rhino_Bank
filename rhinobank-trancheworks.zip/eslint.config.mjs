import firebaseRulesPlugin from '@firebase/eslint-plugin-security-rules';

export default [
  {
    ignores: ['dist/**/*', 'node_modules/**/*', 'backend_python/**/*'],
  },
  firebaseRulesPlugin.configs['flat/recommended'],
];
