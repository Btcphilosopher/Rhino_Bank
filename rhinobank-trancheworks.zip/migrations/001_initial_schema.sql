-- RhinoBank TrancheWorks — PostgreSQL Schema Migration 001
-- Supports versioned deals, collateral tapes, structures, simulations, surveillance, and maker-checker governance.

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE deals (
    id TEXT PRIMARY KEY,
    owner_uid TEXT NOT NULL,
    name TEXT NOT NULL,
    code TEXT NOT NULL,
    asset_class TEXT NOT NULL CHECK (asset_class IN ('semiconductor', 'corporate_debt', 'equipment_finance')),
    structure_type TEXT NOT NULL CHECK (structure_type IN ('cash', 'synthetic')),
    currency CHAR(3) NOT NULL DEFAULT 'USD',
    target_pool_notional NUMERIC(18,2) NOT NULL CHECK (target_pool_notional > 0),
    reinvestment_periods INTEGER NOT NULL DEFAULT 6,
    maturity_periods INTEGER NOT NULL DEFAULT 20,
    period_frequency TEXT NOT NULL DEFAULT 'quarterly' CHECK (period_frequency IN ('quarterly', 'monthly')),
    status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'pending_approval', 'active', 'amortising')),
    version INTEGER NOT NULL DEFAULT 1,
    reserve_target NUMERIC(18,2) NOT NULL DEFAULT 0,
    reserve_balance NUMERIC(18,2) NOT NULL DEFAULT 0,
    annual_senior_fee_bps NUMERIC(8,2) NOT NULL DEFAULT 45,
    annual_trustee_fee NUMERIC(18,2) NOT NULL DEFAULT 180000,
    oc_trigger_ratio NUMERIC(8,4) NOT NULL DEFAULT 1.16,
    ic_trigger_ratio NUMERIC(8,4) NOT NULL DEFAULT 1.25,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE collateral_tapes (
    id TEXT PRIMARY KEY,
    deal_id TEXT NOT NULL REFERENCES deals(id) ON DELETE CASCADE,
    version_number INTEGER NOT NULL,
    source_format TEXT NOT NULL CHECK (source_format IN ('csv', 'json', 'seed')),
    source_file_name TEXT NOT NULL,
    total_principal NUMERIC(18,2) NOT NULL,
    asset_count INTEGER NOT NULL,
    validation_summary JSONB NOT NULL DEFAULT '{}'::jsonb,
    assets JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (deal_id, version_number)
);

CREATE TABLE deal_structures (
    id TEXT PRIMARY KEY,
    deal_id TEXT NOT NULL REFERENCES deals(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    version_number INTEGER NOT NULL,
    is_base BOOLEAN NOT NULL DEFAULT FALSE,
    tranches JSONB NOT NULL,
    waterfall_rules JSONB NOT NULL,
    assumptions JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE simulation_runs (
    id TEXT PRIMARY KEY,
    deal_id TEXT NOT NULL REFERENCES deals(id) ON DELETE CASCADE,
    structure_id TEXT NOT NULL REFERENCES deal_structures(id) ON DELETE CASCADE,
    scenario_name TEXT NOT NULL,
    model_version TEXT NOT NULL,
    seed BIGINT NOT NULL,
    num_paths INTEGER NOT NULL,
    assumptions_snapshot JSONB NOT NULL,
    tranche_metrics JSONB NOT NULL,
    summary_metrics JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE surveillance_periods (
    id TEXT PRIMARY KEY,
    deal_id TEXT NOT NULL REFERENCES deals(id) ON DELETE CASCADE,
    period_number INTEGER NOT NULL,
    period_label TEXT NOT NULL,
    as_of_date DATE NOT NULL,
    is_finalized BOOLEAN NOT NULL DEFAULT FALSE,
    actual_collections NUMERIC(18,2) NOT NULL,
    actual_defaults NUMERIC(18,2) NOT NULL,
    actual_recoveries NUMERIC(18,2) NOT NULL,
    ending_pool_balance NUMERIC(18,2) NOT NULL,
    oc_ratio NUMERIC(8,4) NOT NULL,
    ic_ratio NUMERIC(8,4) NOT NULL,
    reserve_balance NUMERIC(18,2) NOT NULL,
    breaches JSONB NOT NULL DEFAULT '[]'::jsonb,
    substitutions JSONB NOT NULL DEFAULT '[]'::jsonb,
    forecast_snapshot JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (deal_id, period_number)
);

CREATE TABLE approval_requests (
    id TEXT PRIMARY KEY,
    deal_id TEXT NOT NULL REFERENCES deals(id) ON DELETE CASCADE,
    maker_uid TEXT NOT NULL,
    maker_email TEXT NOT NULL,
    checker_uid TEXT,
    checker_email TEXT,
    action_type TEXT NOT NULL,
    summary TEXT NOT NULL,
    payload_diff JSONB NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
    decision_note TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    decided_at TIMESTAMPTZ
);

CREATE INDEX idx_tapes_deal ON collateral_tapes(deal_id);
CREATE INDEX idx_structures_deal ON deal_structures(deal_id);
CREATE INDEX idx_sims_deal ON simulation_runs(deal_id);
CREATE INDEX idx_surv_deal ON surveillance_periods(deal_id);
CREATE INDEX idx_approvals_deal ON approval_requests(deal_id, status);
