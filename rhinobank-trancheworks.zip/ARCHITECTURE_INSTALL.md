# RhinoBank TrancheWorks — Architecture & Deployment Guide

## 1. Live Interactive Runtime (Port 3000)
The live hosted workstation runs:
- **Frontend**: React 19 + TypeScript + Tailwind CSS v4 (`src/`)
- **API & Worker Server**: Node.js + Express (`server.ts`) with `/api/v1/*` routes and asynchronous simulation workers
- **Cloud Persistence & Auth**: Firebase Firestore + Firebase Auth (hardened rules in `firestore.rules`, schema IR in `firebase-blueprint.json`)
- **Tests**: Vitest quantitative & contractual verification (`npm test`)

## 2. Python / FastAPI / PostgreSQL / Docker Compose Deployment
Complete reference source for self-hosted institutional deployment is included in:
- `backend_python/main.py` — FastAPI REST endpoints (`/health`, `/api/v1/collateral/concentrations`, `/api/v1/waterfall/execute`, `/api/v1/simulations`)
- `backend_python/quant_engine.py` — NumPy + SciPy (`scipy.stats.norm`, `scipy.optimize.brentq`) Gaussian factor copula simulator
- `backend_python/waterfall_engine.py` — Deterministic contractual waterfall engine
- `backend_python/worker.py` — Celery + Redis background simulation worker
- `migrations/001_initial_schema.sql` — PostgreSQL DDL migration
- `docker-compose.yml` — Multi-container Postgres 16 + Redis 7 + FastAPI + Celery stack

### Quick Start (Self-Hosted Python Stack)
```bash
docker compose up --build
# FastAPI OpenAPI Swagger UI: http://localhost:8000/docs
```

### Quick Start (Node/Vite Live Stack)
```bash
npm install
npm test
npm run dev
```
