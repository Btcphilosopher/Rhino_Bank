import express from 'express';
import fs from 'fs';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { parseCollateralImport, validateCollateralRecords } from './src/engine/collateral.ts';
import { optimizeCapitalStructure, runMonteCarloSimulation } from './src/engine/quantEngine.ts';
import { runContractualWaterfall } from './src/engine/waterfall.ts';
import type {
  CollateralAsset,
  DealAssumptions,
  DealRecord,
  OptimizationConstraints,
  SimulationRunResult,
  TrancheDefinition,
  WaterfallRule,
} from './src/engine/types.ts';

interface SimulationJob {
  jobId: string;
  status: 'queued' | 'running' | 'completed' | 'failed';
  createdAt: string;
  completedAt?: string;
  result?: SimulationRunResult;
  error?: string;
}

const simulationJobs = new Map<string, SimulationJob>();

async function startServer() {
  const app = express();
  const port = Number(process.env.PORT ?? 3000);
  const isProd = process.env.NODE_ENV === 'production';

  app.use(express.json({ limit: '5mb' }));

  app.get('/api/v1/health', (_req, res) => {
    res.json({
      service: 'RhinoBank TrancheWorks API',
      status: 'healthy',
      version: '2.4.0',
      timestamp: new Date().toISOString(),
    });
  });

  app.get('/api/v1/docs', (_req, res) => {
    res.json({
      openapi: '3.1.0',
      info: {
        title: 'RhinoBank TrancheWorks Institutional Structuring API',
        version: '2.4.0',
        description:
          'REST API for collateral validation, deterministic Cash/Synthetic waterfall execution, seeded Monte Carlo simulation workers, and constrained capital-structure optimization.',
      },
      endpoints: [
        {
          method: 'POST',
          path: '/api/v1/collateral/validate',
          summary: 'Validate CSV or JSON collateral tape records and compute concentration analytics',
        },
        {
          method: 'POST',
          path: '/api/v1/waterfall/execute',
          summary: 'Execute deterministic Cash or Synthetic CDO contractual waterfall with cash-conservation verification',
        },
        {
          method: 'POST',
          path: '/api/v1/simulations',
          summary: 'Enqueue seeded Monte Carlo simulation in background worker',
        },
        {
          method: 'GET',
          path: '/api/v1/simulations/:jobId',
          summary: 'Poll simulation worker status and retrieve tranche valuation metrics',
        },
        {
          method: 'POST',
          path: '/api/v1/optimize',
          summary: 'Optimize capital structure subject to impairment, WAL, IRR, and OC cushion constraints',
        },
      ],
    });
  });

  app.post('/api/v1/collateral/validate', (req, res) => {
    try {
      const { rawText, format, records, expectedCurrency } = req.body ?? {};
      const currency = typeof expectedCurrency === 'string' ? expectedCurrency : 'USD';
      if (typeof rawText === 'string' && (format === 'csv' || format === 'json')) {
        const result = parseCollateralImport(rawText, format, currency);
        return res.json(result);
      }
      if (Array.isArray(records)) {
        const result = validateCollateralRecords(records, currency);
        return res.json(result);
      }
      return res.status(400).json({ error: 'Provide either rawText + format (csv|json) or records array.' });
    } catch (err) {
      return res.status(400).json({
        error: err instanceof Error ? err.message : 'Failed to parse collateral payload.',
      });
    }
  });

  app.post('/api/v1/waterfall/execute', (req, res) => {
    try {
      const { deal, assets, tranches, rules, assumptions, periodShocks } = req.body as {
        deal: DealRecord;
        assets: CollateralAsset[];
        tranches: TrancheDefinition[];
        rules: WaterfallRule[];
        assumptions: DealAssumptions;
        periodShocks?: { defaultFractionOverride?: number; recoveryRateOverride?: number }[];
      };

      if (!deal || !Array.isArray(assets) || !Array.isArray(tranches) || !Array.isArray(rules) || !assumptions) {
        return res.status(400).json({ error: 'Missing required deal, assets, tranches, rules, or assumptions payload.' });
      }

      const result = runContractualWaterfall({
        deal,
        assets,
        tranches,
        rules,
        assumptions,
        periodShocks,
      });
      return res.json(result);
    } catch (err) {
      return res.status(500).json({
        error: err instanceof Error ? err.message : 'Waterfall execution failed.',
      });
    }
  });

  app.post('/api/v1/simulations', (req, res) => {
    try {
      const { deal, assets, tranches, rules, assumptions, scenarioName, seed, numPaths } = req.body as {
        deal: DealRecord;
        assets: CollateralAsset[];
        tranches: TrancheDefinition[];
        rules: WaterfallRule[];
        assumptions: DealAssumptions;
        scenarioName?: string;
        seed?: number;
        numPaths?: number;
      };

      if (!deal || !Array.isArray(assets) || !Array.isArray(tranches) || !Array.isArray(rules) || !assumptions) {
        return res.status(400).json({ error: 'Invalid simulation request payload.' });
      }

      const safePaths = Math.max(10, Math.min(2000, Number(numPaths ?? 250)));
      const safeSeed = Number.isFinite(Number(seed)) ? Math.floor(Number(seed)) : 202611;
      const jobId = `job_${safeSeed}_${Date.now()}`;

      const job: SimulationJob = {
        jobId,
        status: 'queued',
        createdAt: new Date().toISOString(),
      };
      simulationJobs.set(jobId, job);

      // Dispatch asynchronously to background worker tick
      setImmediate(() => {
        job.status = 'running';
        try {
          const result = runMonteCarloSimulation({
            deal,
            assets,
            tranches,
            rules,
            assumptions,
            scenarioName: scenarioName ?? 'Custom Simulation',
            seed: safeSeed,
            numPaths: safePaths,
          });
          job.status = 'completed';
          job.completedAt = new Date().toISOString();
          job.result = result;
        } catch (err) {
          job.status = 'failed';
          job.error = err instanceof Error ? err.message : 'Simulation failed';
        }
      });

      return res.status(202).json({ jobId, status: job.status });
    } catch (err) {
      return res.status(500).json({
        error: err instanceof Error ? err.message : 'Failed to enqueue simulation job.',
      });
    }
  });

  app.get('/api/v1/simulations/:jobId', (req, res) => {
    const job = simulationJobs.get(req.params.jobId);
    if (!job) {
      return res.status(404).json({ error: 'Simulation job not found.' });
    }
    return res.json(job);
  });

  app.post('/api/v1/optimize', (req, res) => {
    try {
      const { deal, assets, baseTranches, rules, assumptions, constraints } = req.body as {
        deal: DealRecord;
        assets: CollateralAsset[];
        baseTranches: TrancheDefinition[];
        rules: WaterfallRule[];
        assumptions: DealAssumptions;
        constraints: OptimizationConstraints;
      };

      if (!deal || !Array.isArray(assets) || !Array.isArray(baseTranches) || !Array.isArray(rules) || !assumptions || !constraints) {
        return res.status(400).json({ error: 'Missing required optimization payload.' });
      }

      const candidates = optimizeCapitalStructure({
        deal,
        assets,
        baseTranches,
        rules,
        assumptions,
        constraints,
      });
      return res.json({ candidates });
    } catch (err) {
      return res.status(500).json({
        error: err instanceof Error ? err.message : 'Optimization failed.',
      });
    }
  });

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      const indexFile = path.join(distDir, 'index.html');
      if (fs.existsSync(indexFile)) {
        res.sendFile(indexFile);
      } else {
        res.status(404).send('Build output not found.');
      }
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`RhinoBank TrancheWorks listening on http://0.0.0.0:${port}`);
  });
}

startServer();
