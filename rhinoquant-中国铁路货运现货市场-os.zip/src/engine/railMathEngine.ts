import {
  CargoCategory,
  GeneralizedCostBreakdown,
  SpotQuote,
  FreightForwardPoint,
  RiskVaRMetrics,
  ScenarioParams,
  ScenarioResult,
  MultimodalComparisonItem,
  Station,
  RailSegment,
} from '../types/rail';
import { STATIONS_DATA, RAIL_SEGMENTS, CARGO_SPECS } from '../data/mockRailData';

// Simple graph distance & shortest path finder
export interface PathResult {
  pathStationIds: string[];
  pathSegmentIds: string[];
  totalDistanceKm: number;
  avgCapacityUtilPct: number;
  maxSlopePerMil: number;
  hasElectrified: boolean;
}

export function findOptimalRailPath(originId: string, destId: string): PathResult {
  const origin = STATIONS_DATA.find((s) => s.id === originId) || STATIONS_DATA[0];
  const dest = STATIONS_DATA.find((s) => s.id === destId) || STATIONS_DATA[1];

  // Direct segment match first
  const directSeg = RAIL_SEGMENTS.find(
    (s) =>
      (s.sourceStationId === originId && s.targetStationId === destId) ||
      (s.sourceStationId === destId && s.targetStationId === originId)
  );

  if (directSeg) {
    return {
      pathStationIds: [originId, destId],
      pathSegmentIds: [directSeg.id],
      totalDistanceKm: directSeg.distanceKm,
      avgCapacityUtilPct: directSeg.currentLoadTonsDay / directSeg.designCapacityTonsDay,
      maxSlopePerMil: directSeg.slopeGradientPerMil,
      hasElectrified: directSeg.isElectrified,
    };
  }

  // Multi-hop lookup (e.g. Shanghai -> Zhengzhou -> Chengdu)
  const hop1 = RAIL_SEGMENTS.find(
    (s) => s.sourceStationId === originId || s.targetStationId === originId
  );
  const hop2 = RAIL_SEGMENTS.find(
    (s) => s.sourceStationId === destId || s.targetStationId === destId
  );

  if (hop1 && hop2) {
    const midStationId =
      hop1.sourceStationId === originId ? hop1.targetStationId : hop1.sourceStationId;
    const dist1 = hop1.distanceKm;
    const dist2 = hop2.distanceKm;
    const totalDist = dist1 + dist2;
    const avgUtil =
      (hop1.currentLoadTonsDay / hop1.designCapacityTonsDay +
        hop2.currentLoadTonsDay / hop2.designCapacityTonsDay) /
      2;

    return {
      pathStationIds: [originId, midStationId, destId],
      pathSegmentIds: [hop1.id, hop2.id],
      totalDistanceKm: totalDist,
      avgCapacityUtilPct: avgUtil,
      maxSlopePerMil: Math.max(hop1.slopeGradientPerMil, hop2.slopeGradientPerMil),
      hasElectrified: hop1.isElectrified && hop2.isElectrified,
    };
  }

  // Fallback lat/lng distance calculation if disconnected
  const R = 6371; // Earth radius in km
  const dLat = ((dest.lat - origin.lat) * Math.PI) / 180;
  const dLng = ((dest.lng - origin.lng) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((origin.lat * Math.PI) / 180) *
      Math.cos((dest.lat * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const estimatedRailDist = Math.round(R * c * 1.25); // 1.25 winding factor

  return {
    pathStationIds: [originId, destId],
    pathSegmentIds: ['SEG_CUSTOM'],
    totalDistanceKm: estimatedRailDist,
    avgCapacityUtilPct: 0.82,
    maxSlopePerMil: 8,
    hasElectrified: true,
  };
}

export function calculateSpotQuote(
  originId: string,
  destId: string,
  cargoCategory: CargoCategory = 'STEEL',
  volumeTons: number = 5000,
  dispatchDate: string = 'T+3',
  scenarioParams?: ScenarioParams
): SpotQuote {
  const path = findOptimalRailPath(originId, destId);
  const cargoSpec = CARGO_SPECS.find((c) => c.category === cargoCategory) || CARGO_SPECS[0];

  // Base Railway Tariff parameters based on China Railway Freight Class 1-7
  // Base 1 (固定基价): RMB 15.0..28.0/ton
  // Base 2 (运行基价): RMB 0.08..0.18/ton-km
  let base1 = 18.50;
  let base2 = 0.125;

  if (cargoCategory === 'COAL') {
    base1 = 12.00;
    base2 = 0.085;
  } else if (cargoCategory === 'STEEL') {
    base1 = 22.00;
    base2 = 0.142;
  } else if (cargoCategory === 'CONTAINER') {
    base1 = 28.00;
    base2 = 0.165;
  } else if (cargoCategory === 'CHEMICAL' || cargoCategory === 'HAZARDOUS') {
    base1 = 35.00;
    base2 = 0.210;
  }

  // Adjust for scenario shocks if present
  let capacityMultiplier = 1.0;
  if (scenarioParams) {
    if (cargoCategory === 'COAL') {
      capacityMultiplier += scenarioParams.coalDemandChangePct / 100 * 0.4;
    }
    if (cargoCategory === 'CONTAINER') {
      capacityMultiplier += scenarioParams.containerDemandChangePct / 100 * 0.35;
    }
    if (scenarioParams.keyCorridorCapacityChangePct < 0) {
      capacityMultiplier += Math.abs(scenarioParams.keyCorridorCapacityChangePct) / 100 * 0.6;
    }
  }

  const baseRailwayTariff = Number((base1 + base2 * path.totalDistanceKm).toFixed(2));
  const loadingUnloading = Number((32.0 + (cargoSpec.densityTonsPerCubM < 1.0 ? 8.0 : 0.0)).toFixed(2));
  const terminalYardFee = 18.50;
  const feederTrucking = 48.00; // 两端短驳

  // Estimated hours: Distance / 35 km/h avg commercial speed including marshalling
  const estimatedTransitHours = Math.round((path.totalDistanceKm / 35.0) * (path.avgCapacityUtilPct > 0.85 ? 1.25 : 1.0));

  // Transit time capital charge: Value * 8% per annum * (Hours / 8760)
  const transitTimeCapitalCost = Number(((cargoSpec.valuePerTonRmb * 0.08 * estimatedTransitHours) / 8760).toFixed(2));

  // Congestion Surcharge: Exponential penalty when line utilization exceeds 80%
  const utilOverhead = Math.max(0, path.avgCapacityUtilPct * capacityMultiplier - 0.75);
  const capacityCongestionSurcharge = Number((baseRailwayTariff * Math.pow(utilOverhead, 1.8) * 1.5).toFixed(2));

  // Risk Premium for weather/delay
  const riskPremium = Number((baseRailwayTariff * (scenarioParams?.extremeWeatherActive ? 0.08 : 0.03)).toFixed(2));

  const totalLandedCost = Number(
    (
      baseRailwayTariff +
      loadingUnloading +
      terminalYardFee +
      feederTrucking +
      transitTimeCapitalCost +
      capacityCongestionSurcharge +
      riskPremium
    ).toFixed(2)
  );

  const breakdown: GeneralizedCostBreakdown = {
    baseRailwayTariffRmbTon: baseRailwayTariff,
    loadingUnloadingRmbTon: loadingUnloading,
    terminalYardFeeRmbTon: terminalYardFee,
    feederTruckingRmbTon: feederTrucking,
    transitTimeCapitalCostRmbTon: transitTimeCapitalCost,
    capacityCongestionSurchargeRmbTon: capacityCongestionSurcharge,
    riskPremiumRmbTon: riskPremium,
    totalLandedCostRmbTon: totalLandedCost,
    distanceKm: path.totalDistanceKm,
    estimatedTransitHours,
  };

  return {
    quoteId: `QT_${Date.now().toString().slice(-6)}`,
    originStationId: originId,
    destinationStationId: destId,
    cargoCategory,
    volumeTons,
    dispatchDate,
    breakdown,
    validUntil: '2026-09-30 23:59',
    dataStatus: 'LIVE',
    alternativeRoutesCount: 2,
  };
}

export function getForwardCurve(
  originId: string,
  destId: string,
  cargoCategory: CargoCategory,
  spotRate: number
): FreightForwardPoint[] {
  const tenors: Array<'SPOT' | '7D' | '30D' | '90D' | '180D' | '1Y'> = [
    'SPOT',
    '7D',
    '30D',
    '90D',
    '180D',
    '1Y',
  ];

  // Seasonality factor (winter heating demand for coal / Q4 harvest for grain)
  const seasonFactor = cargoCategory === 'COAL' ? 1.08 : 1.03;

  return tenors.map((tenor, idx) => {
    let multiplier = 1.0;
    if (tenor === '7D') multiplier = 1.015;
    if (tenor === '30D') multiplier = seasonFactor;
    if (tenor === '90D') multiplier = seasonFactor * 1.04;
    if (tenor === '180D') multiplier = 1.06;
    if (tenor === '1Y') multiplier = 1.09;

    const rate = Number((spotRate * multiplier).toFixed(2));
    const spread = Number((rate - spotRate).toFixed(2));

    return {
      tenor,
      dispatchDate: `T+${idx === 0 ? 0 : idx === 1 ? 7 : idx === 2 ? 30 : idx === 3 ? 90 : idx === 4 ? 180 : 365}`,
      rateRmbTon: rate,
      volumeTons: Math.round(50000 * (1 + idx * 0.2)),
      openInterestTons: Math.round(120000 * (1 + idx * 0.35)),
      spreadVsSpotRmbTon: spread,
    };
  });
}

export function calculateElasticity(lineUtilPct: number) {
  // Price elasticity of demand in rail freight
  const dPrice_dDemand = Number((0.45 * Math.exp(lineUtilPct * 2.2)).toFixed(3));
  const dPrice_dCapacity = Number((-0.85 * (1 / (1.05 - Math.min(0.99, lineUtilPct)))).toFixed(3));
  const dTransitTime_dCongestion = Number((1.2 * Math.pow(lineUtilPct, 3.0)).toFixed(3));

  return {
    dPrice_dDemand,
    dPrice_dCapacity,
    dTransitTime_dCongestion,
  };
}

export function calculateRiskVaR(quote: SpotQuote): RiskVaRMetrics {
  const total = quote.breakdown.totalLandedCostRmbTon;
  const hours = quote.breakdown.estimatedTransitHours;

  const priceVaR95RmbTon = Number((total * 0.068).toFixed(2));
  const transitVaR95Hours = Math.round(hours * 0.28);
  const capacityVaR95Pct = 14.5;
  const expectedShortfallRmbTon = Number((total * 0.095).toFixed(2));

  let score = 38;
  if (hours > 60) score += 20;
  if (quote.breakdown.capacityCongestionSurchargeRmbTon > 20) score += 25;

  return {
    priceVaR95RmbTon,
    transitVaR95Hours,
    capacityVaR95Pct,
    expectedShortfallRmbTon,
    overallRiskScore: Math.min(99, score),
    topRiskFactors: [
      '枢纽编组站卡口拥堵 (Bottleneck Congestion)',
      '季节性恶劣天气 (Extreme Weather Window)',
      '返程空箱调运滞后 (Backhaul Container Deficit)',
      '短驳司机与站场卸车能力匹配 (Feeder Capacity Gap)',
    ],
  };
}

export function runScenarioSimulation(params: ScenarioParams): ScenarioResult {
  const avgRateChange = Number(
    (
      params.coalDemandChangePct * 0.35 +
      params.containerDemandChangePct * 0.25 -
      params.keyCorridorCapacityChangePct * 0.5 +
      (params.extremeWeatherActive ? 8.5 : 0)
    ).toFixed(1)
  );

  const bottleneckBefore = 45;
  const bottleneckAfter = Math.min(
    98,
    Math.round(
      bottleneckBefore +
        params.coalDemandChangePct * 0.8 -
        params.keyCorridorCapacityChangePct * 1.2 +
        (params.portCongestionLevel === 'SEVERE' ? 22 : 0)
    )
  );

  const delayHours = Math.round(
    12 +
      (bottleneckAfter > 75 ? (bottleneckAfter - 75) * 1.1 : 0) +
      (params.extremeWeatherActive ? 18 : 0)
  );

  const modalShift = Math.round(25000 * (avgRateChange > 10 ? (avgRateChange - 10) * 0.12 : 0));

  return {
    scenarioTitle: '冲击模拟: 需求/运力/天气组合情景',
    affectedCorridorName: '大秦重载走廊 / 华东-西南东西大干线',
    avgFreightRateChangePct: avgRateChange,
    bottleneckScoreBefore: bottleneckBefore,
    bottleneckScoreAfter: bottleneckAfter,
    avgDelayHoursIncrease: delayHours,
    modalShiftToRoadTonsDay: modalShift,
    topCongestedStations: ['郑州北站 (ZZB)', '太原西站 (TYW)', '成都城厢站 (CDCX)'],
    recommendedMitigation:
      '建议提前15天锁定远期运力(Freight Forward Contract)，分流至焦柳线或长江水路集疏运体系，规避大秦/陇海线高峰堵塞。',
  };
}

export function compareMultimodal(
  originId: string,
  destId: string,
  volumeTons: number = 5000
): MultimodalComparisonItem[] {
  const quote = calculateSpotQuote(originId, destId, 'STEEL', volumeTons);
  const totalRailRmb = quote.breakdown.totalLandedCostRmbTon;
  const railHours = quote.breakdown.estimatedTransitHours;

  return [
    {
      modeName: '铁路整车',
      freightFeeRmbTon: quote.breakdown.baseRailwayTariffRmbTon + quote.breakdown.loadingUnloadingRmbTon,
      transitHours: railHours,
      doorToDoorCostRmbTon: totalRailRmb,
      inventoryCapitalCostRmbTon: quote.breakdown.transitTimeCapitalCostRmbTon,
      onTimeReliabilityPct: 91.5,
      co2KgPerTonKm: 0.018,
    },
    {
      modeName: '铁路集装箱',
      freightFeeRmbTon: Number((totalRailRmb * 0.92).toFixed(2)),
      transitHours: Math.round(railHours * 0.9),
      doorToDoorCostRmbTon: Number((totalRailRmb * 0.95).toFixed(2)),
      inventoryCapitalCostRmbTon: Number((quote.breakdown.transitTimeCapitalCostRmbTon * 0.9).toFixed(2)),
      onTimeReliabilityPct: 94.2,
      co2KgPerTonKm: 0.016,
    },
    {
      modeName: '公路重卡',
      freightFeeRmbTon: Number((totalRailRmb * 1.48).toFixed(2)),
      transitHours: Math.round(railHours * 0.45),
      doorToDoorCostRmbTon: Number((totalRailRmb * 1.52).toFixed(2)),
      inventoryCapitalCostRmbTon: Number((quote.breakdown.transitTimeCapitalCostRmbTon * 0.45).toFixed(2)),
      onTimeReliabilityPct: 88.0,
      co2KgPerTonKm: 0.082,
    },
    {
      modeName: '内河水运',
      freightFeeRmbTon: Number((totalRailRmb * 0.45).toFixed(2)),
      transitHours: Math.round(railHours * 2.8),
      doorToDoorCostRmbTon: Number((totalRailRmb * 0.62).toFixed(2)),
      inventoryCapitalCostRmbTon: Number((quote.breakdown.transitTimeCapitalCostRmbTon * 2.8).toFixed(2)),
      onTimeReliabilityPct: 76.4,
      co2KgPerTonKm: 0.009,
    },
    {
      modeName: '海运沿海',
      freightFeeRmbTon: Number((totalRailRmb * 0.52).toFixed(2)),
      transitHours: Math.round(railHours * 2.2),
      doorToDoorCostRmbTon: Number((totalRailRmb * 0.68).toFixed(2)),
      inventoryCapitalCostRmbTon: Number((quote.breakdown.transitTimeCapitalCostRmbTon * 2.2).toFixed(2)),
      onTimeReliabilityPct: 82.1,
      co2KgPerTonKm: 0.011,
    },
  ];
}
