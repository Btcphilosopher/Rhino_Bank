export type DataProviderStatus =
  | 'LIVE'
  | 'HISTORICAL'
  | 'CACHED'
  | 'SYNTHETIC'
  | 'ESTIMATED'
  | 'MODELLED';

export type StationType =
  | 'MARSHALLING'   // 编组站
  | 'FREIGHT_HUB'    // 货运中心站
  | 'PORT_TERMINAL'  // 港口铁路线
  | 'LOGISTICS_PARK' // 物流园区
  | 'MINE_SIDING'    // 矿区专用线
  | 'INDUSTRIAL_NODE'// 工业园/钢厂
  | 'BORDER_PORT';   // 边境口岸

export interface StationCapability {
  craneMaxTons: number;               // 最大起重能力 (吨)
  forkliftCount: number;             // 叉车保有量
  container20ftCapable: boolean;     // 20英尺集装箱办理能力
  container40ftCapable: boolean;     // 40英尺集装箱办理能力
  sidingTrackCount: number;          // 专用线数量
  cargoYardAreaSqMeters: number;     // 货场面积 (平方米)
  hazardousCargoAllowed: boolean;    // 危化品允许
  coldChainCapable: boolean;         // 冷链设施能力
  dailyHandlingCapacityTons: number; // 日装卸吞吐能力 (吨)
}

export interface StationRestriction {
  restrictionType: 'TEMP_BAN' | 'MAINTENANCE' | 'CARGO_LIMIT' | 'NORMAL';
  noticeTitle: string;
  effectiveFrom: string;
  effectiveTo: string;
  affectedCargos: string[];
  description: string;
}

export interface Station {
  id: string;
  name: string;
  code: string;
  region: '华北' | '东北' | '华东' | '华中' | '华南' | '西南' | '西北';
  province: string;
  city: string;
  lat: number;
  lng: number;
  stationType: StationType;
  capability: StationCapability;
  restriction: StationRestriction;
  currentStockTons: number;
  activeWagonsCount: number;
}

export interface RailSegment {
  id: string;
  name: string;
  sourceStationId: string;
  targetStationId: string;
  distanceKm: number;
  designCapacityTonsDay: number;
  currentLoadTonsDay: number;
  isElectrified: boolean;
  gaugeMm: number; // 标轨 1435
  speedLimitKmH: number;
  slopeGradientPerMil: number; // 坡度 ‰
  status: 'NORMAL' | 'HIGH_DEMAND' | 'CAPACITY_TIGHT' | 'CONGESTED' | 'DISRUPTED';
}

export interface RailCorridor {
  id: string;
  name: string;
  category: '煤炭走廊' | '矿石走廊' | '钢铁走廊' | '粮食走廊' | '集装箱走廊' | '西部陆海新通道' | '中欧班列走廊' | '沿海集疏运';
  segmentIds: string[];
  stationIds: string[];
  totalDistanceKm: number;
  dailyCapacityTons: number;
  currentVolumeTons: number;
  utilizationRate: number; // 0..1
  avgFreightRateRmbTon: number;
  avgTransitHours: number;
  bottleneckScore: number; // 0..100
  alternativeRouteNames: string[];
}

export type CargoCategory =
  | 'COAL'         // 煤炭
  | 'COKE'         // 焦炭
  | 'IRON_ORE'     // 铁矿石
  | 'STEEL'        // 钢材
  | 'GRAIN'        // 粮食
  | 'FERTILIZER'   // 化肥
  | 'CEMENT'       // 水泥
  | 'MINERALS'     // 矿建
  | 'TIMBER'       // 木材
  | 'AUTOMOTIVE'   // 汽车/JSQ车
  | 'MACHINERY'    // 机械设备
  | 'ELECTRONICS'  // 电子产品
  | 'CHEMICAL'     // 化工品
  | 'CONTAINER'    // 标准集装箱
  | 'COLD_CHAIN'   // 冷链食品
  | 'HAZARDOUS'    // 危险货物
  | 'PARCEL';      // 零散快运

export interface CargoSpec {
  category: CargoCategory;
  nameCn: string;
  densityTonsPerCubM: number;
  valuePerTonRmb: number;
  tariffClass: string; // 铁货运价类，如号规 1-7 类
  requiresContainer: boolean;
  requiresSpecialWagon: string;
}

export interface OrderBookItem {
  id: string;
  side: 'BID' | 'ASK';
  shipperOrCarrier: string;
  originStationId: string;
  destinationStationId: string;
  cargoCategory: CargoCategory;
  volumeTons: number;
  priceRmbTon: number;
  dispatchDate: string; // T+1..
  wagonType: 'C70敞车' | 'P70棚车' | 'N70平车' | 'JSQ7特种车' | 'G70罐车' | '20FT集装箱' | '40FT集装箱' | '冷藏箱';
  transitDays: number;
  timestamp: string;
}

export interface GeneralizedCostBreakdown {
  baseRailwayTariffRmbTon: number;  // 基础铁路运费 (基价1 + 基价2*距离)
  loadingUnloadingRmbTon: number;   // 站场装卸作业费
  terminalYardFeeRmbTon: number;    // 站场堆存与整理费
  feederTruckingRmbTon: number;     // 两端公路集疏运费
  transitTimeCapitalCostRmbTon: number; // 货物途在中资金占用/时间沉没成本
  capacityCongestionSurchargeRmbTon: number; // 运力拥堵加价
  riskPremiumRmbTon: number;        // 延误/损耗风险溢价
  totalLandedCostRmbTon: number;    // 全包综合物流成本
  distanceKm: number;
  estimatedTransitHours: number;
}

export interface SpotQuote {
  quoteId: string;
  originStationId: string;
  destinationStationId: string;
  cargoCategory: CargoCategory;
  volumeTons: number;
  dispatchDate: string;
  breakdown: GeneralizedCostBreakdown;
  validUntil: string;
  dataStatus: DataProviderStatus;
  alternativeRoutesCount: number;
}

export interface FreightForwardPoint {
  tenor: 'SPOT' | '7D' | '30D' | '90D' | '180D' | '1Y';
  dispatchDate: string;
  rateRmbTon: number;
  volumeTons: number;
  openInterestTons: number;
  spreadVsSpotRmbTon: number;
}

export interface ContainerBalance {
  stationId: string;
  stationName: string;
  available20ft: number;
  available40ft: number;
  deficit20ft: number; // 正为短缺，负为过剩
  deficit40ft: number;
  repositioningCostRmbUnit: number;
  backhaulMatchRatePct: number;
}

export interface RiskVaRMetrics {
  priceVaR95RmbTon: number;      // 运价 VaR (95%置信度)
  transitVaR95Hours: number;     // 运输时间 VaR
  capacityVaR95Pct: number;      // 运力挤占 VaR
  expectedShortfallRmbTon: number;// 尾部期望损失 (ES)
  overallRiskScore: number;      // 0..100
  topRiskFactors: string[];
}

export interface ScenarioParams {
  coalDemandChangePct: number;       // 煤炭需求变动 %
  containerDemandChangePct: number;  // 集装箱需求变动 %
  keyCorridorCapacityChangePct: number; // 核心走廊运力变动 %
  roadFreightRateChangePct: number;  // 公路运价变动 %
  portCongestionLevel: 'NORMAL' | 'MODERATE' | 'SEVERE';
  extremeWeatherActive: boolean;
}

export interface ScenarioResult {
  scenarioTitle: string;
  affectedCorridorName: string;
  avgFreightRateChangePct: number;
  bottleneckScoreBefore: number;
  bottleneckScoreAfter: number;
  avgDelayHoursIncrease: number;
  modalShiftToRoadTonsDay: number;
  topCongestedStations: string[];
  recommendedMitigation: string;
}

export interface FreightIndexItem {
  code: string;
  name: string;
  currentValue: number;
  changeValue: number;
  changePct: number;
  dailyVolumeTons: number;
  updatedAt: string;
}

export interface MultimodalComparisonItem {
  modeName: '铁路整车' | '铁路集装箱' | '公路重卡' | '内河水运' | '海运沿海';
  freightFeeRmbTon: number;
  transitHours: number;
  doorToDoorCostRmbTon: number;
  inventoryCapitalCostRmbTon: number;
  onTimeReliabilityPct: number;
  co2KgPerTonKm: number;
}
