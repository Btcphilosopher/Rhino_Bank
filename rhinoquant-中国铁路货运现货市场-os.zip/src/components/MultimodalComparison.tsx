import React, { useState } from 'react';
import { MultimodalComparisonItem } from '../types/rail';
import { compareMultimodal } from '../engine/railMathEngine';
import { Truck, ArrowRight, Clock, ShieldCheck, DollarSign, Leaf, Zap } from 'lucide-react';

export const MultimodalComparison: React.FC = () => {
  const [originId, setOriginId] = useState<string>('ST_SH_MH');
  const [destId, setDestId] = useState<string>('ST_CD_CX');
  const [volumeTons, setVolumeTons] = useState<number>(5000);

  const comparisonData: MultimodalComparisonItem[] = compareMultimodal(originId, destId, volumeTons);

  return (
    <div className="space-y-6 font-sans">
      {/* Header */}
      <div className="bg-[#0f141c] border border-slate-800 p-5 rounded-lg flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
            <Truck className="w-5 h-5 text-emerald-500" />
            公铁水多式联运成本与时效对比矩阵 (Rail vs Road vs Water Multimodal Matrix)
          </h2>
          <p className="text-xs text-slate-400 font-mono mt-1">
            Door-to-Door Generalized Logistics Cost = 运费 + 站场接驳 + 在途营运资金占用 (Working Capital) + 碳排放规费
          </p>
        </div>

        <div className="flex items-center gap-3 font-mono text-xs">
          <div>
            <span className="text-slate-500 block text-[10px]">发货规模</span>
            <span className="text-slate-100 font-bold">{volumeTons} 吨</span>
          </div>
        </div>
      </div>

      {/* Multimodal Matrix Table */}
      <div className="bg-[#0f141c] border border-slate-800 rounded-lg p-5 font-mono text-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-900 text-slate-400 border-b border-slate-800 font-sans">
              <tr>
                <th className="p-3">运输模式 (Transport Mode)</th>
                <th className="p-3 text-right">基础运费 (¥/吨)</th>
                <th className="p-3 text-right">门到门全程时间</th>
                <th className="p-3 text-right">资金占用成本 (¥/吨)</th>
                <th className="p-3 text-right">全程到岸成本 (¥/吨)</th>
                <th className="p-3 text-right">准点可靠性 (%)</th>
                <th className="p-3 text-right">碳强度 (kg CO₂/吨公里)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {comparisonData.map((item, idx) => {
                const isRailCarload = item.modeName === '铁路整车';
                return (
                  <tr
                    key={idx}
                    className={isRailCarload ? 'bg-red-950/20 font-bold' : 'hover:bg-slate-900/50'}
                  >
                    <td className="p-3 font-sans text-slate-100 flex items-center gap-2">
                      <span
                        className={`w-2 h-2 rounded-full ${
                          isRailCarload
                            ? 'bg-red-500'
                            : item.modeName.includes('公路')
                            ? 'bg-amber-500'
                            : 'bg-blue-500'
                        }`}
                      ></span>
                      {item.modeName}
                    </td>
                    <td className="p-3 text-right text-slate-200 tabular-nums">¥ {item.freightFeeRmbTon.toFixed(2)}</td>
                    <td className="p-3 text-right text-amber-400 font-bold tabular-nums">
                      {item.transitHours} 小时 ({Math.round(item.transitHours / 24 * 10) / 10} 天)
                    </td>
                    <td className="p-3 text-right text-blue-400 tabular-nums">¥ {item.inventoryCapitalCostRmbTon.toFixed(2)}</td>
                    <td className="p-3 text-right font-black text-sm tabular-nums">
                      <span className={isRailCarload ? 'text-red-400' : 'text-slate-100'}>
                        ¥ {item.doorToDoorCostRmbTon.toFixed(2)}
                      </span>
                    </td>
                    <td className="p-3 text-right text-emerald-400 tabular-nums">{item.onTimeReliabilityPct}%</td>
                    <td className="p-3 text-right text-slate-400 tabular-nums">{item.co2KgPerTonKm}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Conclusion Callout */}
        <div className="mt-5 p-4 bg-slate-900 border border-slate-800 rounded flex items-center justify-between font-sans text-xs">
          <div className="space-y-1">
            <div className="font-bold text-slate-200">
              犀牛量化结论: 上海→成都 5,000 吨发运最优决策
            </div>
            <div className="text-slate-400">
              • 运距 &gt; 800 km 且规模 &gt; 1,000 吨时，<strong className="text-red-400">铁路整车/集装箱</strong> 的全包物流成本较公路重卡节省约 <strong className="text-emerald-400">34%–38%</strong>。
              <br />
              • 内河水运虽运价极低，但运输时间长达 14.8 天，会导致企业营运资金 (Working Capital) 占用增加 ¥18.5/吨，且受枯水期封航影响。
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
