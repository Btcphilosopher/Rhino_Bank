import React, { useState } from 'react';
import { CargoCategory, SpotQuote } from '../types/rail';
import { STATIONS_DATA, CARGO_SPECS } from '../data/mockRailData';
import { calculateSpotQuote, findOptimalRailPath } from '../engine/railMathEngine';
import { MapPin, Navigation, Clock, ShieldAlert, ArrowRight, Calculator, CheckCircle, Zap } from 'lucide-react';

export interface RouteTerminalProps {
  onOpenCalculation: (originId: string, destId: string, cargoCategory?: CargoCategory, volumeTons?: number) => void;
}

export const RouteTerminal: React.FC<RouteTerminalProps> = ({ onOpenCalculation }) => {
  const [originId, setOriginId] = useState<string>('ST_SH_MH');
  const [destId, setDestId] = useState<string>('ST_CD_CX');
  const [cargoCategory, setCargoCategory] = useState<CargoCategory>('STEEL');
  const [volumeTons, setVolumeTons] = useState<number>(5000);
  const [showComparison, setShowComparison] = useState<boolean>(true);

  // Route A (Main Line Route)
  const mainQuote = calculateSpotQuote(originId, destId, cargoCategory, volumeTons);
  const path = findOptimalRailPath(originId, destId);

  // Alternative Route B (Detour via Baoji/Jiaozuo line)
  const routeBAvlQuote: SpotQuote = {
    ...mainQuote,
    quoteId: 'QT_ALT_B',
    breakdown: {
      ...mainQuote.breakdown,
      baseRailwayTariffRmbTon: Number((mainQuote.breakdown.baseRailwayTariffRmbTon * 1.08).toFixed(2)),
      capacityCongestionSurchargeRmbTon: 0, // 绕行无拥堵
      totalLandedCostRmbTon: Number((mainQuote.breakdown.totalLandedCostRmbTon * 0.96).toFixed(2)),
      estimatedTransitHours: Math.round(mainQuote.breakdown.estimatedTransitHours * 1.15),
    },
  };

  // Alternative Route C (Rail + Water Yangtze Multimodal)
  const routeCMultimodal: SpotQuote = {
    ...mainQuote,
    quoteId: 'QT_ALT_C',
    breakdown: {
      ...mainQuote.breakdown,
      baseRailwayTariffRmbTon: Number((mainQuote.breakdown.baseRailwayTariffRmbTon * 0.55).toFixed(2)),
      terminalYardFeeRmbTon: 45.0, // 码头转运
      totalLandedCostRmbTon: Number((mainQuote.breakdown.totalLandedCostRmbTon * 0.72).toFixed(2)),
      estimatedTransitHours: Math.round(mainQuote.breakdown.estimatedTransitHours * 2.4),
    },
  };

  return (
    <div className="space-y-6 font-sans">
      {/* Route Inquiry Control Desk */}
      <div className="bg-[#0f141c] border border-slate-800 p-5 rounded-lg">
        <h2 className="text-sm font-bold text-slate-100 mb-4 flex items-center gap-2">
          <MapPin className="w-4 h-4 text-red-500" />
          全网线路综合定价与替代路径比选终端 (Route Pricing & Comparison Terminal)
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs font-mono">
          <div>
            <label className="text-[10px] text-slate-500 block mb-1">发站 (Origin Station)</label>
            <select
              value={originId}
              onChange={(e) => setOriginId(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 text-slate-100 p-2 rounded font-bold focus:outline-none"
            >
              {STATIONS_DATA.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.code} · {s.province})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[10px] text-slate-500 block mb-1">到站 (Destination Station)</label>
            <select
              value={destId}
              onChange={(e) => setDestId(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 text-slate-100 p-2 rounded font-bold focus:outline-none"
            >
              {STATIONS_DATA.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.code} · {s.province})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[10px] text-slate-500 block mb-1">货物类型</label>
            <select
              value={cargoCategory}
              onChange={(e) => setCargoCategory(e.target.value as CargoCategory)}
              className="w-full bg-slate-900 border border-slate-700 text-slate-100 p-2 rounded font-bold focus:outline-none"
            >
              {CARGO_SPECS.map((c) => (
                <option key={c.category} value={c.category}>
                  {c.nameCn}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[10px] text-slate-500 block mb-1">托运规模 (吨)</label>
            <input
              type="number"
              value={volumeTons}
              onChange={(e) => setVolumeTons(Number(e.target.value))}
              className="w-full bg-slate-900 border border-slate-700 text-slate-100 p-2 rounded font-bold focus:outline-none"
            />
          </div>
        </div>
      </div>

      {/* Main Selected Route Performance Card */}
      <div className="bg-[#0f141c] border border-slate-800 rounded-lg p-5 font-mono text-xs">
        <div className="flex flex-wrap items-center justify-between border-b border-slate-800 pb-3 mb-4 gap-4 font-sans">
          <div className="flex items-center gap-3">
            <span className="text-lg font-bold text-slate-100">
              {STATIONS_DATA.find((s) => s.id === originId)?.name}
            </span>
            <ArrowRight className="w-5 h-5 text-red-500" />
            <span className="text-lg font-bold text-slate-100">
              {STATIONS_DATA.find((s) => s.id === destId)?.name}
            </span>
            <span className="text-slate-400 text-xs font-mono">
              ({mainQuote.breakdown.distanceKm} 公里 · 经由 陇海/京沪主干线)
            </span>
          </div>

          <div className="flex items-center gap-4">
            <div className="text-right">
              <span className="text-[10px] text-slate-500 uppercase block font-mono">全包到岸成本 (GLC)</span>
              <span className="text-2xl font-black text-red-400 tabular-nums">
                ¥ {mainQuote.breakdown.totalLandedCostRmbTon.toFixed(2)}
              </span>
              <span className="text-xs text-slate-400"> / 吨</span>
            </div>

            <button
              onClick={() => onOpenCalculation(originId, destId, cargoCategory, volumeTons)}
              className="px-3 py-2 bg-red-600 hover:bg-red-500 text-white rounded font-bold text-xs transition-colors shadow flex items-center gap-1 font-mono"
            >
              <Calculator className="w-3.5 h-3.5" />
              <span>【计算】公式分解</span>
            </button>
          </div>
        </div>

        {/* Route Details Matrix */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div className="p-3 bg-slate-900 border border-slate-800 rounded">
            <div className="text-slate-500 text-[10px]">基础铁路规费</div>
            <div className="text-base font-bold text-slate-100 tabular-nums mt-0.5">
              ¥ {mainQuote.breakdown.baseRailwayTariffRmbTon.toFixed(2)} / 吨
            </div>
            <div className="text-[10px] text-slate-400">号规标准运价</div>
          </div>

          <div className="p-3 bg-slate-900 border border-slate-800 rounded">
            <div className="text-slate-500 text-[10px]">预计运行时间 (P50/P90)</div>
            <div className="text-base font-bold text-amber-400 tabular-nums mt-0.5">
              {mainQuote.breakdown.estimatedTransitHours} 小时 (约 {Math.round(mainQuote.breakdown.estimatedTransitHours / 24 * 10) / 10} 天)
            </div>
            <div className="text-[10px] text-slate-400">商业准点率 91.5%</div>
          </div>

          <div className="p-3 bg-slate-900 border border-slate-800 rounded">
            <div className="text-slate-500 text-[10px]">线路干线卡口拥堵加价</div>
            <div className="text-base font-bold text-red-400 tabular-nums mt-0.5">
              ¥ {mainQuote.breakdown.capacityCongestionSurchargeRmbTon.toFixed(2)} / 吨
            </div>
            <div className="text-[10px] text-slate-400">利用率 89% 拥堵调节</div>
          </div>

          <div className="p-3 bg-slate-900 border border-slate-800 rounded">
            <div className="text-slate-500 text-[10px]">在途营运资金占用成本</div>
            <div className="text-base font-bold text-blue-400 tabular-nums mt-0.5">
              ¥ {mainQuote.breakdown.transitTimeCapitalCostRmbTon.toFixed(2)} / 吨
            </div>
            <div className="text-[10px] text-slate-400">年化 8.0% 资金成本</div>
          </div>
        </div>

        {/* Alternative Routes Comparison Table */}
        <div className="border border-slate-800 rounded overflow-hidden">
          <div className="p-3 bg-slate-900 border-b border-slate-800 font-bold font-sans text-slate-200 flex items-center justify-between">
            <span>路径方案对比 (COMPARE ROUTES)</span>
            <span className="text-xs text-slate-400 font-mono font-normal">多方案成本与时效多目标 Pareto 求解</span>
          </div>

          <table className="w-full text-left text-[11px]">
            <thead className="bg-[#141b26] text-slate-400 font-sans">
              <tr>
                <th className="p-2.5">方案名称</th>
                <th className="p-2.5">运输方式/线路</th>
                <th className="p-2.5 text-right">运距</th>
                <th className="p-2.5 text-right">预估时间</th>
                <th className="p-2.5 text-right">全包运价 (¥/吨)</th>
                <th className="p-2.5 text-right">准点率</th>
                <th className="p-2.5 text-center">综合评估</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              <tr className="bg-red-950/20 font-bold">
                <td className="p-2.5 text-red-400 font-sans flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-red-500"></span>
                  方案 A (推荐直达)
                </td>
                <td className="p-2.5 text-slate-200">京沪/陇海干线直达列车</td>
                <td className="p-2.5 text-right text-slate-200">{mainQuote.breakdown.distanceKm} km</td>
                <td className="p-2.5 text-right text-amber-400">{mainQuote.breakdown.estimatedTransitHours} 小时</td>
                <td className="p-2.5 text-right text-red-400 text-sm font-black tabular-nums">
                  ¥ {mainQuote.breakdown.totalLandedCostRmbTon.toFixed(2)}
                </td>
                <td className="p-2.5 text-right text-emerald-400">91.5%</td>
                <td className="p-2.5 text-center text-slate-300 font-sans">时效最优</td>
              </tr>

              <tr>
                <td className="p-2.5 text-blue-400 font-sans font-bold flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                  方案 B (分流避拥)
                </td>
                <td className="p-2.5 text-slate-300">焦柳线分流绕行通道</td>
                <td className="p-2.5 text-right text-slate-300">{Math.round(mainQuote.breakdown.distanceKm * 1.12)} km</td>
                <td className="p-2.5 text-right text-amber-400">{routeBAvlQuote.breakdown.estimatedTransitHours} 小时</td>
                <td className="p-2.5 text-right font-bold text-slate-100 tabular-nums">
                  ¥ {routeBAvlQuote.breakdown.totalLandedCostRmbTon.toFixed(2)}
                </td>
                <td className="p-2.5 text-right text-emerald-400">95.0%</td>
                <td className="p-2.5 text-center text-slate-400 font-sans">避开卡口</td>
              </tr>

              <tr>
                <td className="p-2.5 text-emerald-400 font-sans font-bold flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  方案 C (铁水联运)
                </td>
                <td className="p-2.5 text-slate-300">长江沿江水运 + 成渝铁路联运</td>
                <td className="p-2.5 text-right text-slate-300">2,450 km</td>
                <td className="p-2.5 text-right text-amber-400">{routeCMultimodal.breakdown.estimatedTransitHours} 小时</td>
                <td className="p-2.5 text-right font-bold text-emerald-400 text-sm tabular-nums">
                  ¥ {routeCMultimodal.breakdown.totalLandedCostRmbTon.toFixed(2)}
                </td>
                <td className="p-2.5 text-right text-amber-400">78.2%</td>
                <td className="p-2.5 text-center text-emerald-400 font-sans">极低成本 (省 28%)</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
