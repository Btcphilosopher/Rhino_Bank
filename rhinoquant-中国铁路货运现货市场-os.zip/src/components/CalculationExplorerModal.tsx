import React from 'react';
import { SpotQuote } from '../types/rail';
import { Calculator, X, HelpCircle, ArrowRight, CheckCircle2, ShieldCheck } from 'lucide-react';

export interface CalculationExplorerModalProps {
  quote: SpotQuote | null;
  isOpen: boolean;
  onClose: () => void;
}

export const CalculationExplorerModal: React.FC<CalculationExplorerModalProps> = ({
  quote,
  isOpen,
  onClose,
}) => {
  if (!isOpen || !quote) return null;

  const b = quote.breakdown;

  const formulaRows = [
    {
      title: '1. 铁路基础运费 (Base Railway Tariff)',
      value: b.baseRailwayTariffRmbTon,
      unit: '元/吨',
      formula: `基价1 (18.50元) + 基价2 (0.125元/吨公里) × 里程 (${b.distanceKm} 公里)`,
      desc: '依据中国国家铁路集团号规发运计费标准 (1-7号规)',
    },
    {
      title: '2. 站场装卸作业费 (Terminal Handling)',
      value: b.loadingUnloadingRmbTon,
      unit: '元/吨',
      formula: '发站龙门吊/机械装车费 (18.0元) + 到站卸车与搬移费 (14.0元)',
      desc: '包含货场95306标准门到站机械装卸作业规费',
    },
    {
      title: '3. 站场堆存与整理规费 (Terminal Yard Fee)',
      value: b.terminalYardFeeRmbTon,
      unit: '元/吨',
      formula: '免费堆存期(3天)外堆存费 + 货场安全巡查与计量重取费',
      desc: '包含货物入场检斤、磅房过磅及集装箱堆场占用费',
    },
    {
      title: '4. 两端公路集疏运短驳 (Feeder Trucking)',
      value: b.feederTruckingRmbTon,
      unit: '元/吨',
      formula: '发端工厂→货运站重卡短驳 (26元) + 到端货运站→客户仓库短驳 (22元)',
      desc: '实现 Door-to-Door 全包物流的公路两端短距离接驳费用',
    },
    {
      title: '5. 途在货物时间资本沉没成本 (In-Transit Working Capital)',
      value: b.transitTimeCapitalCostRmbTon,
      unit: '元/吨',
      formula: `(货物价值 4,200元/吨 × 年化资金利率 8.0% × 在途时间 ${b.estimatedTransitHours}小时) ÷ 8760小时`,
      desc: '铁路运输时间对企业营运资金 (Working Capital) 占用的隐含财务成本',
    },
    {
      title: '6. 线路运力拥堵加价 (Congestion Capacity Penalty)',
      value: b.capacityCongestionSurchargeRmbTon,
      unit: '元/吨',
      formula: '基础运价 × Math.pow(线路利用率 - 0.75, 1.8) × 1.5 溢价乘数',
      desc: '针对干线利用率 >85% 时的运力供需偏紧拥堵调节成本',
    },
    {
      title: '7. 延误与货损风险溢价 (Delay & Cargo Risk Premium)',
      value: b.riskPremiumRmbTon,
      unit: '元/吨',
      formula: '基础运价 × (3.0% 基础风险比率 + 恶劣天气加成)',
      desc: '针对编组站卡口堵塞、防保押运及在途延误赔付的 VaR 风险缓释成本',
    },
  ];

  const totalCalculated = formulaRows.reduce((acc, row) => acc + row.value, 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-[#0f141c] border border-slate-700/80 rounded-lg max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl text-slate-100 flex flex-col font-sans">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-[#141b26]">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-red-950/60 border border-red-800/60 rounded text-red-400">
              <Calculator className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                【犀牛量化·价格透视引擎】全包综合物流成本数学拆解
              </h3>
              <p className="text-xs text-slate-400 mt-0.5 font-mono">
                Generalized Logistics Cost (GLC) Mathematical Decomposition Model
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Route Summary */}
        <div className="bg-[#0a0d12] px-6 py-3 border-b border-slate-800/80 flex flex-wrap items-center justify-between gap-4 text-xs font-mono">
          <div className="flex items-center gap-4">
            <div>
              <span className="text-slate-500">起点: </span>
              <span className="text-red-400 font-bold">{quote.originStationId}</span>
            </div>
            <ArrowRight className="w-3.5 h-3.5 text-slate-600" />
            <div>
              <span className="text-slate-500">终点: </span>
              <span className="text-emerald-400 font-bold">{quote.destinationStationId}</span>
            </div>
            <div className="border-l border-slate-800 pl-4">
              <span className="text-slate-500">货物: </span>
              <span className="text-slate-200 font-bold">{quote.cargoCategory} ({quote.volumeTons}吨)</span>
            </div>
          </div>
          <div className="flex items-center gap-3 text-slate-300">
            <span>运距: <strong className="text-white">{b.distanceKm} km</strong></span>
            <span>预计时间: <strong className="text-amber-400">{b.estimatedTransitHours} 小时</strong></span>
          </div>
        </div>

        {/* Formula breakdown body */}
        <div className="p-6 space-y-4 font-mono text-xs">
          <div className="text-slate-400 text-[11px] mb-2 font-sans">
            说明: 本系统采用机构级 <span className="text-slate-200 font-bold font-mono">Generalized Logistics Cost (GLC)</span> 全包成本定价模型。点击任意项目可查阅中国铁路计费规则与算法依据。
          </div>

          <div className="space-y-3">
            {formulaRows.map((row, idx) => (
              <div
                key={idx}
                className="p-3 bg-slate-900/80 border border-slate-800/80 rounded hover:border-slate-700 transition-colors"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-slate-200 font-sans">{row.title}</span>
                  <span className="font-bold text-slate-100 tabular-nums text-sm">
                    ¥ {row.value.toFixed(2)} <span className="text-xs text-slate-400 font-normal">{row.unit}</span>
                  </span>
                </div>
                <div className="text-[11px] text-red-400/90 font-mono bg-slate-950/80 p-2 rounded border border-slate-800/50 mb-1">
                  <code>{row.formula}</code>
                </div>
                <div className="text-[10px] text-slate-500 font-sans flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3 text-emerald-500 shrink-0" />
                  <span>{row.desc}</span>
                </div>
              </div>
            ))}
          </div>

          {/* Sum Banner */}
          <div className="mt-6 p-4 bg-gradient-to-r from-red-950/60 via-slate-900 to-slate-900 border border-red-800/80 rounded flex items-center justify-between font-sans">
            <div>
              <div className="text-xs text-slate-400 uppercase tracking-wider">
                最终模型公允全包运价 (Model Fair Freight Rate)
              </div>
              <div className="text-xs text-emerald-400 font-mono mt-0.5">
                数据状态: {quote.dataStatus} · 可验证无黑盒折算
              </div>
            </div>
            <div className="text-right font-mono">
              <span className="text-2xl font-black text-red-400 tabular-nums">
                ¥ {totalCalculated.toFixed(2)}
              </span>
              <span className="text-xs text-slate-400 ml-1">/ 吨</span>
              <div className="text-[10px] text-slate-400 font-normal">
                单次 5,000 吨发运总成本: ¥ {(totalCalculated * quote.volumeTons).toLocaleString('zh-CN')}
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-[#141b26] flex items-center justify-between text-xs text-slate-500 font-sans">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
            <span>算法符合中国铁路 95306 运价规范 & RhinoQuant 运价模型 v3.6</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded font-medium transition-colors font-mono"
          >
            关闭 Explorer
          </button>
        </div>
      </div>
    </div>
  );
};
