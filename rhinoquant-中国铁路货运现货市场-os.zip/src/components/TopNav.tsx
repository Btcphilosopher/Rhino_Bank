import React from 'react';
import { DataProviderStatus } from '../types/rail';
import {
  Activity,
  Layers,
  Database,
  Terminal,
  Zap,
  TrendingUp,
  MapPin,
  ShieldAlert,
  Sliders,
  Cpu,
  Truck,
  Sparkles,
} from 'lucide-react';

export interface TopNavProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  dataStatus: DataProviderStatus;
  setDataStatus: (status: DataProviderStatus) => void;
  marketState: 'NORMAL' | 'HIGH_DEMAND' | 'CAPACITY_TIGHT' | 'CONGESTED' | 'DISRUPTED';
  onOpenFlagshipDemos: () => void;
  onOpenAiAnalyst: () => void;
}

export const TopNav: React.FC<TopNavProps> = ({
  activeTab,
  setActiveTab,
  dataStatus,
  setDataStatus,
  marketState,
  onOpenFlagshipDemos,
  onOpenAiAnalyst,
}) => {
  const navTabs = [
    { id: 'OVERVIEW', label: '实时市场全景', icon: Activity },
    { id: 'SPOT_MARKET', label: '现货订单簿', icon: TrendingUp },
    { id: 'ROUTE_PRICING', label: '路线定价与路线对比', icon: MapPin },
    { id: 'CAPACITY_LAB', label: '运力与瓶颈分析', icon: Cpu },
    { id: 'COMMODITY_LINK', label: '大宗商品联动', icon: Layers },
    { id: 'SCENARIO_LAB', label: '情景与冲击传播', icon: Sliders },
    { id: 'RISK_VAR', label: '货运 VaR 风险树', icon: ShieldAlert },
    { id: 'MULTIMODAL', label: '公铁水多式联运', icon: Truck },
    { id: 'CORPORATE', label: '企业物流优化 Desk', icon: Terminal },
  ];

  const getStatusBadgeColor = (state: string) => {
    switch (state) {
      case 'NORMAL':
        return 'text-emerald-400 border-emerald-800/60 bg-emerald-950/40';
      case 'HIGH_DEMAND':
        return 'text-blue-400 border-blue-800/60 bg-blue-950/40';
      case 'CAPACITY_TIGHT':
        return 'text-amber-400 border-amber-800/60 bg-amber-950/40';
      case 'CONGESTED':
      case 'DISRUPTED':
        return 'text-red-400 border-red-800/60 bg-red-950/40';
      default:
        return 'text-slate-400 border-slate-700 bg-slate-900';
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-[#0a0d12]/95 backdrop-blur border-b border-slate-800/80 px-4 py-2.5">
      <div className="flex items-center justify-between gap-4">
        {/* Zone 1: Brand Title (Single element text wordmark) */}
        <div className="flex items-center gap-3 shrink-0">
          <a
            href="#"
            onClick={(e) => {
              e.preventDefault();
              setActiveTab('OVERVIEW');
            }}
            className="flex items-center gap-2.5 group"
          >
            <div className="w-8 h-8 rounded bg-red-600/20 border border-red-500/40 flex items-center justify-center text-red-500 font-extrabold text-sm tracking-wider group-hover:bg-red-600 group-hover:text-white transition-all shadow-sm shadow-red-900/20">
              犀
            </div>
            <div>
              <div className="text-base font-extrabold tracking-tight text-slate-100 flex items-center gap-2 font-['Syne',sans-serif]">
                RHINOQUANT <span className="text-xs font-medium text-slate-400 font-sans">犀牛量化 · 中国铁路货运现货市场 OS</span>
              </div>
            </div>
          </a>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden xl:flex items-center gap-1 overflow-x-auto py-1 scrollbar-none">
          {navTabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-slate-800 text-red-400 border border-slate-700 shadow-inner font-semibold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-red-400' : 'text-slate-500'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Primary Actions & Data Source Selector */}
        <div className="flex items-center gap-2.5 shrink-0">
          {/* Data Adapter Source Status */}
          <div className="flex items-center gap-1 p-0.5 bg-slate-900/90 rounded border border-slate-800 text-xs font-mono">
            <span className="text-[10px] text-slate-500 px-1.5">适配层</span>
            <select
              value={dataStatus}
              onChange={(e) => setDataStatus(e.target.value as DataProviderStatus)}
              className="bg-transparent text-slate-200 text-xs focus:outline-none cursor-pointer pr-1 font-mono font-semibold"
            >
              <option value="LIVE">LIVE 95306直连</option>
              <option value="HISTORICAL">HISTORICAL 历史基线</option>
              <option value="SYNTHETIC">SYNTHETIC 算法合成</option>
              <option value="MODELLED">MODELLED 远期模型</option>
            </select>
          </div>

          {/* Market State Indicator */}
          <div className={`px-2 py-1 rounded border text-[11px] font-mono font-semibold flex items-center gap-1.5 ${getStatusBadgeColor(marketState)}`}>
            <span className="w-1.5 h-1.5 rounded-full bg-current animate-pulse"></span>
            <span>{marketState}</span>
          </div>

          {/* Flagship Demos Launcher */}
          <button
            onClick={onOpenFlagshipDemos}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-red-950/60 hover:bg-red-900 text-red-200 border border-red-800/60 rounded text-xs font-medium transition-all shadow-sm whitespace-nowrap"
          >
            <Zap className="w-3.5 h-3.5 text-red-400" />
            <span>旗舰演示演示卷</span>
          </button>

          {/* AI Quantitative Analyst Modal Trigger */}
          <button
            onClick={onOpenAiAnalyst}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-blue-950/60 hover:bg-blue-900 text-blue-200 border border-blue-800/60 rounded text-xs font-medium transition-all shadow-sm whitespace-nowrap"
          >
            <Sparkles className="w-3.5 h-3.5 text-blue-400 animate-pulse" />
            <span>Gemini AI 研报</span>
          </button>
        </div>
      </div>

      {/* Mobile & Medium Screen Navigation Overflow Bar */}
      <div className="flex xl:hidden items-center gap-1 overflow-x-auto pt-2 border-t border-slate-800/40 scrollbar-none">
        {navTabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded transition-all whitespace-nowrap ${
                isActive
                  ? 'bg-slate-800 text-red-400 border border-slate-700'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};
