import React, { useState } from 'react';
import { Sparkles, X, Send, Bot, RefreshCw, FileText, CheckCircle } from 'lucide-react';

export interface AIMarketAnalystProps {
  isOpen: boolean;
  onClose: () => void;
  origin?: string;
  destination?: string;
  cargo?: string;
  volume?: number;
  currentRate?: number;
}

export const AIMarketAnalyst: React.FC<AIMarketAnalystProps> = ({
  isOpen,
  onClose,
  origin = '上海闵行站',
  destination = '成都城厢站',
  cargo = '钢材',
  volume = 5000,
  currentRate = 438.5,
}) => {
  const [reportText, setReportText] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [customPrompt, setCustomPrompt] = useState<string>('');

  if (!isOpen) return null;

  const handleGenerateReport = async (overridePrompt?: string) => {
    setLoading(true);
    try {
      const res = await fetch('/api/ai/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          origin,
          destination,
          cargo,
          volume,
          currentRate,
          lineStats: { distanceKm: 2178, utilizationPct: 89.0, transitHours: 62 },
          prompt: overridePrompt || customPrompt,
        }),
      });

      const data = await res.json();
      if (data.success) {
        setReportText(data.text);
      } else {
        setReportText(`研报生成提示: ${data.error || '服务器服务异常'}`);
      }
    } catch (err: any) {
      setReportText(`请求失败: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-[#0f141c] border border-slate-700/80 rounded-lg max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl text-slate-100 flex flex-col font-sans">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-[#141b26]">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-950/80 border border-blue-800/60 rounded text-blue-400">
              <Sparkles className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                Gemini 3.8 Flash 首席量化铁路物流分析师研报
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                RHINOQUANT Market Intelligence Agent · 实时干线量化敏感性分析
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Query Summary Strip */}
        <div className="bg-[#0a0d12] px-6 py-3 border-b border-slate-800/80 text-xs font-mono flex flex-wrap items-center justify-between gap-2">
          <div className="text-slate-300">
            分析路线: <strong className="text-red-400">{origin}</strong> → <strong className="text-emerald-400">{destination}</strong>
          </div>
          <div className="text-slate-400">
            货物: <strong className="text-slate-200">{cargo} ({volume} 吨)</strong> · 预估运价: <strong className="text-amber-400">¥{currentRate}/吨</strong>
          </div>
        </div>

        {/* Report Content Body */}
        <div className="p-6 space-y-4 text-xs font-mono leading-relaxed min-h-[280px] bg-[#070a0f]">
          {loading ? (
            <div className="flex flex-col items-center justify-center py-16 space-y-3">
              <RefreshCw className="w-8 h-8 text-blue-400 animate-spin" />
              <div className="text-slate-300 font-bold font-sans">
                Gemini 3.8 Flash 正在进行 2,178 公里线路瓶颈与 GLC 矩阵全量计算...
              </div>
            </div>
          ) : reportText ? (
            <div className="prose prose-invert max-w-none text-slate-200 text-xs whitespace-pre-wrap font-mono">
              {reportText}
            </div>
          ) : (
            <div className="text-center py-12 space-y-4">
              <FileText className="w-10 h-10 text-slate-600 mx-auto" />
              <div className="text-slate-400 font-sans">
                点击下方按钮启动 Gemini 3.8 神经网络量化研报生成程序。
              </div>
              <button
                onClick={() => handleGenerateReport()}
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded text-xs transition-colors shadow font-sans"
              >
                生成路线量化深度研究报告
              </button>
            </div>
          )}
        </div>

        {/* Custom Input prompt bar */}
        <div className="p-4 bg-[#141b26] border-t border-slate-800 space-y-2">
          <div className="flex items-center gap-2">
            <input
              type="text"
              placeholder="输入自定义研究提问（例：若冬季煤炭发运增加20%，对上海到成都钢材运价影响如何？）"
              value={customPrompt}
              onChange={(e) => setCustomPrompt(e.target.value)}
              className="flex-1 bg-slate-900 border border-slate-700 text-slate-100 p-2 rounded text-xs focus:outline-none font-mono"
            />
            <button
              onClick={() => handleGenerateReport(customPrompt)}
              disabled={loading}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded font-bold text-xs transition-colors flex items-center gap-1 font-sans disabled:opacity-50"
            >
              <Send className="w-3.5 h-3.5" />
              <span>研报推演</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
