import React from 'react';
import { Zap, X, ArrowRight, Play, Calculator, Layers, Truck, ShieldAlert } from 'lucide-react';

export interface FlagshipDemosModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectDemo: (demoId: string) => void;
}

export const FlagshipDemosModal: React.FC<FlagshipDemosModalProps> = ({
  isOpen,
  onClose,
  onSelectDemo,
}) => {
  if (!isOpen) return null;

  const demos = [
    {
      id: 'DEMO_1',
      title: '旗舰演示 1: 上海 → 成都 5,000 吨钢材现货全包运价 (GLC Model)',
      desc: '演示 2,178 公里东西干线基础运价、装卸费、短驳费、在途资金成本与卡口拥堵费的无黑盒分解，以及 A/B/C 替代方案对比。',
      targetTab: 'ROUTE_PRICING',
      icon: Calculator,
      color: 'text-red-400 bg-red-950/60 border-red-800/80',
    },
    {
      id: 'DEMO_2',
      title: '旗舰演示 2: 晋陕蒙煤炭保供走廊 (大秦线 108万吨/日 重载)',
      desc: '演示太原西/大同西至秦皇岛港重载列车发运、翻车机卸车吞吐、集中修运力挤占与远期 Contango 升水曲线。',
      targetTab: 'CAPACITY_LAB',
      icon: Layers,
      color: 'text-amber-400 bg-amber-950/60 border-amber-800/80',
    },
    {
      id: 'DEMO_3',
      title: '旗舰演示 3: 华东-西南集装箱双向箱源调配 (Backhaul Optimization)',
      desc: '演示上海闵行（箱源过剩）与成都城厢/重庆团结村（箱源短缺）20ft/40ft 集装箱重去回程匹配求解，降低空载率。',
      targetTab: 'CORPORATE',
      icon: Zap,
      color: 'text-blue-400 bg-blue-950/60 border-blue-800/80',
    },
    {
      id: 'DEMO_4',
      title: '旗舰演示 4: 铁路 vs 公路重卡 vs 长江水运全到岸成本比价',
      desc: '演示包含运费、转运堆存、资金在途占用与碳排放权规费的全量多式联运（Multimodal）Pareto 矩阵决策。',
      targetTab: 'MULTIMODAL',
      icon: Truck,
      color: 'text-emerald-400 bg-emerald-950/60 border-emerald-800/80',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-in fade-in duration-200 font-sans">
      <div className="bg-[#0f141c] border border-slate-700/80 rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl text-slate-100 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-[#141b26]">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-red-950/80 border border-red-800/60 rounded text-red-400">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                RHINOQUANT 旗舰研报与演示场景卷 (Flagship Scenarios)
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                一键加载机构级中国铁路货运量化研究经典案例
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Demo Cards List */}
        <div className="p-6 space-y-4">
          {demos.map((demo) => {
            const Icon = demo.icon;
            return (
              <div
                key={demo.id}
                onClick={() => {
                  onSelectDemo(demo.targetTab);
                  onClose();
                }}
                className="p-4 bg-slate-900/90 border border-slate-800 hover:border-slate-700 rounded-lg cursor-pointer transition-all hover:scale-[1.01] group space-y-2"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className={`p-1.5 rounded border text-xs font-mono font-bold ${demo.color}`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <h4 className="font-bold text-slate-100 text-sm group-hover:text-red-400 transition-colors">
                      {demo.title}
                    </h4>
                  </div>
                  <Play className="w-4 h-4 text-slate-500 group-hover:text-red-400 transition-colors shrink-0" />
                </div>
                <p className="text-xs text-slate-400 font-mono pl-8">{demo.desc}</p>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
