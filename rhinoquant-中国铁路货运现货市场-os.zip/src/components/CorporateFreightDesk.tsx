import React, { useState } from 'react';
import { ContainerBalance } from '../types/rail';
import { INITIAL_CONTAINER_BALANCES } from '../data/mockRailData';
import { Terminal, CheckCircle2, ArrowRight, RefreshCcw, Layers, Cpu, ShieldCheck } from 'lucide-react';

export const CorporateFreightDesk: React.FC = () => {
  const [balances, setBalances] = useState<ContainerBalance[]>(INITIAL_CONTAINER_BALANCES);
  const [optimizing, setOptimizing] = useState<boolean>(false);

  const handleRunOptimizer = () => {
    setOptimizing(true);
    setTimeout(() => {
      // Simulate MILP optimization algorithm output
      setBalances((prev) =>
        prev.map((b) => ({
          ...b,
          backhaulMatchRatePct: Math.min(98, b.backhaulMatchRatePct + 18),
          deficit20ft: Math.round(b.deficit20ft * 0.25),
        }))
      );
      setOptimizing(false);
    }, 600);
  };

  return (
    <div className="space-y-6 font-sans">
      {/* Header */}
      <div className="bg-[#0f141c] border border-slate-800 p-5 rounded-lg flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
            <Terminal className="w-5 h-5 text-blue-500" />
            企业物流量化优化 Desk (Corporate Freight Optimization Desk)
          </h2>
          <p className="text-xs text-slate-400 font-mono mt-1">
            求解目标: 最小化 [全包物流运费 + 站场重去调运费 + 安全库存持有成本 + 返程空载损耗]
          </p>
        </div>

        <button
          onClick={handleRunOptimizer}
          disabled={optimizing}
          className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded font-bold text-xs font-mono transition-colors shadow flex items-center gap-1.5 disabled:opacity-50"
        >
          <RefreshCcw className={`w-3.5 h-3.5 ${optimizing ? 'animate-spin' : ''}`} />
          <span>{optimizing ? 'MILP 混合整数求解中...' : '求解返程空箱双向优化'}</span>
        </button>
      </div>

      {/* Container Balance & Backhaul Repositioning Matrix */}
      <div className="bg-[#0f141c] border border-slate-800 rounded-lg p-5 font-mono text-xs">
        <h3 className="font-bold font-sans text-slate-200 text-sm border-b border-slate-800 pb-2 mb-4">
          关键节点集装箱箱源平衡与返程匹配率 (Container Balance & Backhaul Match Matrix)
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {balances.map((item) => (
            <div key={item.stationId} className="p-4 bg-slate-900 border border-slate-800 rounded-lg space-y-3">
              <div className="flex items-center justify-between font-sans border-b border-slate-800 pb-2">
                <span className="font-bold text-slate-100">{item.stationName}</span>
                <span
                  className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-bold ${
                    item.deficit20ft > 500
                      ? 'bg-red-950 text-red-400 border border-red-800'
                      : 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                  }`}
                >
                  {item.deficit20ft > 500 ? '箱源短缺' : '箱源充沛'}
                </span>
              </div>

              <div className="space-y-1.5 text-slate-300">
                <div className="flex justify-between">
                  <span className="text-slate-500">可用 20ft / 40ft:</span>
                  <span className="font-bold text-slate-100">
                    {item.available20ft} / {item.available40ft} 箱
                  </span>
                </div>

                <div className="flex justify-between">
                  <span className="text-slate-500">缺口 / 盈余 20ft:</span>
                  <span className={item.deficit20ft > 0 ? 'text-red-400 font-bold' : 'text-emerald-400 font-bold'}>
                    {item.deficit20ft > 0 ? `缺 ${item.deficit20ft}` : `过剩 ${Math.abs(item.deficit20ft)}`}
                  </span>
                </div>

                <div className="flex justify-between">
                  <span className="text-slate-500">双向返程匹配率:</span>
                  <span className="text-emerald-400 font-bold">{item.backhaulMatchRatePct}%</span>
                </div>
              </div>

              {/* Progress bar for backhaul match */}
              <div className="w-full bg-slate-950 h-2 rounded overflow-hidden border border-slate-800">
                <div
                  className="bg-emerald-500 h-full transition-all duration-500"
                  style={{ width: `${item.backhaulMatchRatePct}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
