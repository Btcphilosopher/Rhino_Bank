import React, { useState } from 'react';
import { Layers, ArrowRight, TrendingUp, Cpu, Factory, Flame, ShieldAlert } from 'lucide-react';

export const CommodityRailLinkage: React.FC = () => {
  const [selectedChain, setSelectedChain] = useState<'COAL' | 'STEEL' | 'CONTAINER'>('STEEL');

  return (
    <div className="space-y-6 font-sans">
      {/* Header */}
      <div className="bg-[#0f141c] border border-slate-800 p-5 rounded-lg flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
            <Layers className="w-5 h-5 text-red-500" />
            大宗商品 — 铁路市场联动与中国工业物流网络 (Commodity ↔ Rail Freight)
          </h2>
          <p className="text-xs text-slate-400 font-mono mt-1">
            大宗商品现货价格 → 产销地运量需求 → 铁路重载干线利用率 → 编组站卡口拥堵 → 铁路现货运价
          </p>
        </div>

        {/* Chain Selector */}
        <div className="flex items-center gap-1 bg-slate-900 p-1 rounded border border-slate-800 text-xs font-mono font-bold">
          <button
            onClick={() => setSelectedChain('STEEL')}
            className={`px-3 py-1.5 rounded transition-colors ${
              selectedChain === 'STEEL' ? 'bg-red-900 text-red-100 border border-red-700' : 'text-slate-400 hover:text-white'
            }`}
          >
            钢铁产业链 (Iron Ore & Steel)
          </button>
          <button
            onClick={() => setSelectedChain('COAL')}
            className={`px-3 py-1.5 rounded transition-colors ${
              selectedChain === 'COAL' ? 'bg-amber-900 text-amber-100 border border-amber-700' : 'text-slate-400 hover:text-white'
            }`}
          >
            煤炭产业链 (Coal & Power)
          </button>
          <button
            onClick={() => setSelectedChain('CONTAINER')}
            className={`px-3 py-1.5 rounded transition-colors ${
              selectedChain === 'CONTAINER' ? 'bg-blue-900 text-blue-100 border border-blue-700' : 'text-slate-400 hover:text-white'
            }`}
          >
            集装箱/高端制造 (Container & Auto)
          </button>
        </div>
      </div>

      {/* Industrial Flow Visualization Diagram */}
      <div className="bg-[#0f141c] border border-slate-800 rounded-lg p-6 font-mono text-xs">
        <h3 className="font-bold font-sans text-slate-200 text-sm mb-4">
          {selectedChain === 'STEEL' && '钢铁产业链: 铁矿石进口 → 沿海港口 → 铁路大干线 → 钢厂高炉 → 成品钢材西南发运'}
          {selectedChain === 'COAL' && '煤炭产业链: 晋陕蒙坑口矿区 → 大秦重载铁路 → 渤海湾港口 → 沿海电厂发电'}
          {selectedChain === 'CONTAINER' && '制造产业链: 华东/华南电子零部件 → 郑州/成都枢纽 → 铁路班列 → 欧亚/西部陆海出口'}
        </h3>

        {/* Visual Pipeline Nodes */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 relative">
          <div className="p-4 bg-slate-900 border border-slate-800 rounded text-center space-y-2">
            <div className="text-[10px] text-slate-500 font-bold uppercase">1. 上游源头 (Origin)</div>
            <div className="text-sm font-bold text-slate-100">
              {selectedChain === 'STEEL' && '澳大利亚/巴西铁矿石'}
              {selectedChain === 'COAL' && '晋陕蒙坑口煤矿'}
              {selectedChain === 'CONTAINER' && '长三角电子/光伏集群'}
            </div>
            <div className="text-[10px] text-red-400">产地库存: 280万吨</div>
          </div>

          <div className="p-4 bg-slate-900 border border-slate-800 rounded text-center space-y-2">
            <div className="text-[10px] text-slate-500 font-bold uppercase">2. 铁路集疏运 (Rail Feed)</div>
            <div className="text-sm font-bold text-slate-100">
              {selectedChain === 'STEEL' && '宁波港/天津港专用线'}
              {selectedChain === 'COAL' && '大同西站/太原西站'}
              {selectedChain === 'CONTAINER' && '上海闵行站'}
            </div>
            <div className="text-[10px] text-amber-400">日装车: 3,400 车</div>
          </div>

          <div className="p-4 bg-slate-900 border border-slate-800 rounded text-center space-y-2">
            <div className="text-[10px] text-slate-500 font-bold uppercase">3. 核心干线 (Main Corridor)</div>
            <div className="text-sm font-bold text-slate-100">
              {selectedChain === 'STEEL' && '京沪/陇海东西大干线'}
              {selectedChain === 'COAL' && '大秦2万吨重载铁路'}
              {selectedChain === 'CONTAINER' && '兰新线 / 成渝线'}
            </div>
            <div className="text-[10px] text-emerald-400">干线利用率: 89.0%</div>
          </div>

          <div className="p-4 bg-slate-900 border border-slate-800 rounded text-center space-y-2">
            <div className="text-[10px] text-slate-500 font-bold uppercase">4. 关键枢纽 (Marshalling Hub)</div>
            <div className="text-sm font-bold text-slate-100">
              {selectedChain === 'STEEL' && '郑州北编组站'}
              {selectedChain === 'COAL' && '秦皇岛港翻车机'}
              {selectedChain === 'CONTAINER' && '成都城厢 / 重庆团结村'}
            </div>
            <div className="text-[10px] text-blue-400">编组延误: 4.2小时</div>
          </div>

          <div className="p-4 bg-slate-900 border border-slate-800 rounded text-center space-y-2">
            <div className="text-[10px] text-slate-500 font-bold uppercase">5. 下游消费 (Destination)</div>
            <div className="text-sm font-bold text-slate-100">
              {selectedChain === 'STEEL' && '西南建筑与制造业'}
              {selectedChain === 'COAL' && '东南沿海电厂'}
              {selectedChain === 'CONTAINER' && '东盟 / 中亚出口市场'}
            </div>
            <div className="text-[10px] text-emerald-400">到岸可用天数: 14天</div>
          </div>
        </div>
      </div>
    </div>
  );
};
