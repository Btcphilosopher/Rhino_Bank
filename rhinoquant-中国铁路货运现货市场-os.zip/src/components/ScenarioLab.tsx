import React, { useState } from 'react';
import { ScenarioParams, ScenarioResult } from '../types/rail';
import { runScenarioSimulation } from '../engine/railMathEngine';
import { Sliders, Zap, AlertTriangle, ArrowRight, Play, RefreshCw, Cpu } from 'lucide-react';

export const ScenarioLab: React.FC = () => {
  const [params, setParams] = useState<ScenarioParams>({
    coalDemandChangePct: 20,
    containerDemandChangePct: 15,
    keyCorridorCapacityChangePct: -10,
    roadFreightRateChangePct: -5,
    portCongestionLevel: 'MODERATE',
    extremeWeatherActive: false,
  });

  const result: ScenarioResult = runScenarioSimulation(params);

  const presets = [
    {
      name: '场景 1: 冬季煤炭迎峰度冬保供 (+20% 煤炭需求)',
      apply: () =>
        setParams({
          coalDemandChangePct: 20,
          containerDemandChangePct: 5,
          keyCorridorCapacityChangePct: 0,
          roadFreightRateChangePct: 0,
          portCongestionLevel: 'MODERATE',
          extremeWeatherActive: false,
        }),
    },
    {
      name: '场景 2: 大秦干线集中修 (-15% 运力卡口)',
      apply: () =>
        setParams({
          coalDemandChangePct: 10,
          containerDemandChangePct: 10,
          keyCorridorCapacityChangePct: -15,
          roadFreightRateChangePct: 0,
          portCongestionLevel: 'MODERATE',
          extremeWeatherActive: false,
        }),
    },
    {
      name: '场景 3: 寒潮雨雪极端天气 + 港口封航',
      apply: () =>
        setParams({
          coalDemandChangePct: 15,
          containerDemandChangePct: 15,
          keyCorridorCapacityChangePct: -10,
          roadFreightRateChangePct: +5,
          portCongestionLevel: 'SEVERE',
          extremeWeatherActive: true,
        }),
    },
    {
      name: '场景 4: 公路重卡运价大幅下调 (-12% 竞争)',
      apply: () =>
        setParams({
          coalDemandChangePct: 0,
          containerDemandChangePct: -5,
          keyCorridorCapacityChangePct: 0,
          roadFreightRateChangePct: -12,
          portCongestionLevel: 'NORMAL',
          extremeWeatherActive: false,
        }),
    },
  ];

  return (
    <div className="space-y-6 font-sans">
      {/* Header */}
      <div className="bg-[#0f141c] border border-slate-800 p-5 rounded-lg flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
            <Sliders className="w-5 h-5 text-amber-500" />
            宏观与网络冲击传导实验室 (Scenario Lab & Shock Propagation Engine)
          </h2>
          <p className="text-xs text-slate-400 font-mono mt-1">
            模拟大宗需求突增、干线运力受阻、恶劣天气与公铁竞争对运价、时效与卡口瓶颈的重定向影响
          </p>
        </div>

        {/* Presets dropdown */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 font-mono">经典预设情景:</span>
          <div className="flex flex-wrap gap-1.5">
            {presets.map((preset, idx) => (
              <button
                key={idx}
                onClick={preset.apply}
                className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 text-xs rounded transition-colors font-mono"
              >
                {preset.name.split(':')[0]}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Grid: Sliders Controls (6 Cols) & Results Output (6 Cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 font-mono text-xs">
        {/* Left Sliders Box */}
        <div className="lg:col-span-6 bg-[#0f141c] border border-slate-800 rounded-lg p-5 space-y-4">
          <h3 className="font-bold font-sans text-slate-200 text-sm border-b border-slate-800 pb-2">
            冲击参数设定 (Shock Parameter Configuration)
          </h3>

          <div className="space-y-3">
            <div>
              <div className="flex justify-between mb-1">
                <span className="text-slate-400">煤炭与能源发运需求变动 (%):</span>
                <span className="text-red-400 font-bold tabular-nums">
                  {params.coalDemandChangePct >= 0 ? '+' : ''}
                  {params.coalDemandChangePct}%
                </span>
              </div>
              <input
                type="range"
                min="-30"
                max="50"
                value={params.coalDemandChangePct}
                onChange={(e) => setParams({ ...params, coalDemandChangePct: Number(e.target.value) })}
                className="w-full accent-red-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span className="text-slate-400">集装箱/高端制造需求变动 (%):</span>
                <span className="text-blue-400 font-bold tabular-nums">
                  {params.containerDemandChangePct >= 0 ? '+' : ''}
                  {params.containerDemandChangePct}%
                </span>
              </div>
              <input
                type="range"
                min="-30"
                max="50"
                value={params.containerDemandChangePct}
                onChange={(e) => setParams({ ...params, containerDemandChangePct: Number(e.target.value) })}
                className="w-full accent-blue-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span className="text-slate-400">核心走廊/干线运力调整 (%):</span>
                <span className="text-amber-400 font-bold tabular-nums">
                  {params.keyCorridorCapacityChangePct >= 0 ? '+' : ''}
                  {params.keyCorridorCapacityChangePct}%
                </span>
              </div>
              <input
                type="range"
                min="-40"
                max="30"
                value={params.keyCorridorCapacityChangePct}
                onChange={(e) => setParams({ ...params, keyCorridorCapacityChangePct: Number(e.target.value) })}
                className="w-full accent-amber-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span className="text-slate-400">公路重卡竞争运价变动 (%):</span>
                <span className="text-emerald-400 font-bold tabular-nums">
                  {params.roadFreightRateChangePct >= 0 ? '+' : ''}
                  {params.roadFreightRateChangePct}%
                </span>
              </div>
              <input
                type="range"
                min="-30"
                max="30"
                value={params.roadFreightRateChangePct}
                onChange={(e) => setParams({ ...params, roadFreightRateChangePct: Number(e.target.value) })}
                className="w-full accent-emerald-500 cursor-pointer"
              />
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-800">
              <div>
                <label className="text-[10px] text-slate-500 block mb-1">港口封航/拥堵级别</label>
                <select
                  value={params.portCongestionLevel}
                  onChange={(e) =>
                    setParams({ ...params, portCongestionLevel: e.target.value as 'NORMAL' | 'MODERATE' | 'SEVERE' })
                  }
                  className="w-full bg-slate-900 border border-slate-700 text-slate-100 p-1.5 rounded focus:outline-none"
                >
                  <option value="NORMAL">NORMAL (正常通畅)</option>
                  <option value="MODERATE">MODERATE (中度压港)</option>
                  <option value="SEVERE">SEVERE (严重封航压港)</option>
                </select>
              </div>

              <div className="flex items-center gap-2 pt-4">
                <input
                  type="checkbox"
                  id="weather"
                  checked={params.extremeWeatherActive}
                  onChange={(e) => setParams({ ...params, extremeWeatherActive: e.target.checked })}
                  className="accent-red-500 cursor-pointer w-4 h-4"
                />
                <label htmlFor="weather" className="text-slate-300 font-sans cursor-pointer">
                  激活极端雨雪寒潮窗口
                </label>
              </div>
            </div>
          </div>
        </div>

        {/* Right Simulation Results Box */}
        <div className="lg:col-span-6 bg-[#0f141c] border border-slate-800 rounded-lg p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-4 font-sans">
              <h3 className="font-bold text-slate-100 text-sm flex items-center gap-2">
                <Play className="w-4 h-4 text-emerald-500" />
                网络推演结果 (Shock Propagation Outputs)
              </h3>
              <span className="text-[10px] text-emerald-400 font-mono">实时重新收敛完毕</span>
            </div>

            <div className="space-y-4">
              <div className="p-3 bg-slate-900 border border-slate-800 rounded">
                <div className="text-slate-500 text-[10px]">全国平均铁路运价指数预测变动</div>
                <div className="text-2xl font-black text-red-400 tabular-nums">
                  {result.avgFreightRateChangePct >= 0 ? '+' : ''}
                  {result.avgFreightRateChangePct}%
                </div>
                <div className="text-[10px] text-slate-400 font-sans mt-0.5">
                  全网络干线公允估值随拥堵加价重新寻优
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 bg-slate-900 border border-slate-800 rounded">
                  <div className="text-slate-500 text-[10px]">卡口瓶颈得分 (Bottleneck Score)</div>
                  <div className="text-lg font-bold text-amber-400 tabular-nums">
                    {result.bottleneckScoreBefore} → {result.bottleneckScoreAfter}
                  </div>
                  <div className="text-[10px] text-slate-400 font-sans">
                    {result.bottleneckScoreAfter > 70 ? '卡口处于严重挤占状态' : '处于正常可承载区间'}
                  </div>
                </div>

                <div className="p-3 bg-slate-900 border border-slate-800 rounded">
                  <div className="text-slate-500 text-[10px]">平均途在延误增加</div>
                  <div className="text-lg font-bold text-blue-400 tabular-nums">
                    +{result.avgDelayHoursIncrease} 小时
                  </div>
                  <div className="text-[10px] text-slate-400 font-sans">编组站解体解编周期拉长</div>
                </div>
              </div>

              <div className="p-3 bg-slate-900 border border-slate-800 rounded">
                <div className="text-slate-500 text-[10px] mb-1">受影响最大核心车站卡口</div>
                <div className="flex flex-wrap gap-1.5">
                  {result.topCongestedStations.map((st, i) => (
                    <span key={i} className="px-2 py-0.5 bg-red-950 text-red-300 border border-red-800 rounded text-[11px] font-mono">
                      {st}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4 p-3 bg-slate-900/90 border border-slate-800 rounded text-[11px] text-slate-300 font-sans">
            <strong>建议避险策略: </strong>
            {result.recommendedMitigation}
          </div>
        </div>
      </div>
    </div>
  );
};
