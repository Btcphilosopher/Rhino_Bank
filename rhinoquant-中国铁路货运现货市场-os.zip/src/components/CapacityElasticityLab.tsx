import React, { useState } from 'react';
import { RAIL_CORRIDORS, RAIL_SEGMENTS } from '../data/mockRailData';
import { calculateElasticity } from '../engine/railMathEngine';
import { Cpu, AlertTriangle, TrendingUp, BarChart2, Activity, ShieldAlert } from 'lucide-react';

export const CapacityElasticityLab: React.FC = () => {
  const [selectedUtilPct, setSelectedUtilPct] = useState<number>(0.87);

  const elasticity = calculateElasticity(selectedUtilPct);

  return (
    <div className="space-y-6 font-sans">
      {/* Header */}
      <div className="bg-[#0f141c] border border-slate-800 p-5 rounded-lg flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
            <Cpu className="w-5 h-5 text-blue-500" />
            运力市场与价格弹性引擎 (Capacity Market & Elasticity Engine)
          </h2>
          <p className="text-xs text-slate-400 font-mono mt-1">
            研究: 需求 ↑ → 运力利用率 ↑ → 编组卡口拥堵 ↑ → 在途延误 ↑ → 运价溢价 ↑
          </p>
        </div>

        {/* Dynamic Capacity Utilization Slider */}
        <div className="bg-slate-900 border border-slate-700 p-3 rounded font-mono text-xs flex items-center gap-4">
          <div>
            <span className="text-slate-400 block text-[10px]">模拟全网线路平均利用率 (Capacity Utilisation)</span>
            <span className="text-lg font-bold text-red-400 tabular-nums">
              {(selectedUtilPct * 100).toFixed(1)}%
            </span>
          </div>

          <input
            type="range"
            min="0.50"
            max="0.99"
            step="0.01"
            value={selectedUtilPct}
            onChange={(e) => setSelectedUtilPct(Number(e.target.value))}
            className="w-40 cursor-pointer accent-red-500"
          />
        </div>
      </div>

      {/* Elasticity Matrix Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
        <div className="p-4 bg-[#0f141c] border border-slate-800 rounded-lg">
          <div className="text-slate-400 text-[11px] mb-1">运价-需求弹性 (Price Elasticity of Demand)</div>
          <div className="text-2xl font-black text-red-400 tabular-nums">
            dPrice / dDemand = +{elasticity.dPrice_dDemand}
          </div>
          <p className="text-[11px] text-slate-400 font-sans mt-2">
            含义: 当发货货源需求增加 10% 时，干线运价公允估值将相应上涨{' '}
            <strong className="text-red-300 font-mono">
              {(elasticity.dPrice_dDemand * 10).toFixed(1)}%
            </strong>
          </p>
        </div>

        <div className="p-4 bg-[#0f141c] border border-slate-800 rounded-lg">
          <div className="text-slate-400 text-[11px] mb-1">运价-容量弹性 (Price Elasticity of Capacity)</div>
          <div className="text-2xl font-black text-amber-400 tabular-nums">
            dPrice / dCapacity = {elasticity.dPrice_dCapacity}
          </div>
          <p className="text-[11px] text-slate-400 font-sans mt-2">
            含义: 当干线因维修或天气减少 10% 运力时，边际边际溢价飙升{' '}
            <strong className="text-amber-300 font-mono">
              {Math.abs(elasticity.dPrice_dCapacity * 10).toFixed(1)}%
            </strong>
          </p>
        </div>

        <div className="p-4 bg-[#0f141c] border border-slate-800 rounded-lg">
          <div className="text-slate-400 text-[11px] mb-1">时间-拥堵指数 (Transit-Time Congestion Index)</div>
          <div className="text-2xl font-black text-blue-400 tabular-nums">
            dTime / dCongestion = +{elasticity.dTransitTime_dCongestion}
          </div>
          <p className="text-[11px] text-slate-400 font-sans mt-2">
            含义: 编组站利用率越接近 100%，在途滞留时间呈非线性指数级剧增。
          </p>
        </div>
      </div>

      {/* Corridor Bottleneck Ranking Leaderboard */}
      <div className="bg-[#0f141c] border border-slate-800 rounded-lg p-5 font-mono text-xs">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4 font-sans">
          <h3 className="font-bold text-slate-100 text-sm flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-500" />
            全国核心铁路走廊卡口瓶颈排行榜 (Corridor Bottleneck Leaderboard)
          </h3>
          <span className="text-slate-400 text-xs font-mono">瓶颈得分依据: 运力利用率 + 车站到发线堆积 + 编组延误</span>
        </div>

        <div className="space-y-3">
          {RAIL_CORRIDORS.map((corridor) => {
            const isHigh = corridor.bottleneckScore > 65;
            return (
              <div
                key={corridor.id}
                className="p-3 bg-slate-900 border border-slate-800/90 rounded flex flex-wrap items-center justify-between gap-4"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-8 h-8 rounded font-black font-mono text-xs flex items-center justify-center ${
                      isHigh ? 'bg-red-950 text-red-400 border border-red-800' : 'bg-blue-950 text-blue-400 border border-blue-800'
                    }`}
                  >
                    {corridor.bottleneckScore}
                  </div>
                  <div>
                    <div className="font-bold font-sans text-slate-200 text-sm">{corridor.name}</div>
                    <div className="text-slate-500 text-[11px]">
                      分类: {corridor.category} · 运距: {corridor.totalDistanceKm} km · 替代方案: {corridor.alternativeRouteNames.join(' / ')}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-6">
                  <div>
                    <span className="text-slate-500 block text-[10px]">日运量 / 运力上限</span>
                    <span className="text-slate-200 font-bold tabular-nums">
                      {corridor.currentVolumeTons.toLocaleString()} / {corridor.dailyCapacityTons.toLocaleString()} 吨
                    </span>
                  </div>

                  <div>
                    <span className="text-slate-500 block text-[10px]">利用率 (Util)</span>
                    <span className={`font-bold tabular-nums ${isHigh ? 'text-red-400' : 'text-emerald-400'}`}>
                      {(corridor.utilizationRate * 100).toFixed(1)}%
                    </span>
                  </div>

                  <div>
                    <span className="text-slate-500 block text-[10px]">均价 (¥/吨)</span>
                    <span className="text-slate-100 font-bold tabular-nums">¥ {corridor.avgFreightRateRmbTon.toFixed(1)}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
