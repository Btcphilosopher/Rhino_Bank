import React, { useState } from 'react';
import { CargoCategory, OrderBookItem, SpotQuote } from '../types/rail';
import { INITIAL_ORDER_BOOK, STATIONS_DATA, CARGO_SPECS } from '../data/mockRailData';
import { calculateSpotQuote, getForwardCurve } from '../engine/railMathEngine';
import { TrendingUp, PlusCircle, Calculator, Clock, Layers, ArrowUpRight, ArrowDownRight } from 'lucide-react';

export interface SpotMarketTerminalProps {
  onOpenCalculation: (originId: string, destId: string, cargoCategory?: CargoCategory, volumeTons?: number) => void;
}

export const SpotMarketTerminal: React.FC<SpotMarketTerminalProps> = ({ onOpenCalculation }) => {
  const [orders, setOrders] = useState<OrderBookItem[]>(INITIAL_ORDER_BOOK);
  const [selectedOrigin, setSelectedOrigin] = useState<string>('ST_SH_MH');
  const [selectedDest, setSelectedDest] = useState<string>('ST_CD_CX');
  const [selectedCargo, setSelectedCargo] = useState<CargoCategory>('STEEL');
  const [selectedVolume, setSelectedVolume] = useState<number>(5000);

  // Form states
  const [newSide, setNewSide] = useState<'BID' | 'ASK'>('BID');
  const [newPrice, setNewPrice] = useState<number>(440.0);
  const [newShipper, setNewShipper] = useState<string>('宝武钢铁物流');

  const spotQuote = calculateSpotQuote(selectedOrigin, selectedDest, selectedCargo, selectedVolume);
  const forwardPoints = getForwardCurve(selectedOrigin, selectedDest, selectedCargo, spotQuote.breakdown.totalLandedCostRmbTon);

  const handleAddOrder = (e: React.FormEvent) => {
    e.preventDefault();
    const newOrd: OrderBookItem = {
      id: `ORD_${Date.now().toString().slice(-4)}`,
      side: newSide,
      shipperOrCarrier: newShipper || '匿名机构交易商',
      originStationId: selectedOrigin,
      destinationStationId: selectedDest,
      cargoCategory: selectedCargo,
      volumeTons: selectedVolume,
      priceRmbTon: newPrice,
      dispatchDate: 'T+3',
      wagonType: selectedCargo === 'CONTAINER' ? '40FT集装箱' : 'C70敞车',
      transitDays: 3,
      timestamp: new Date().toLocaleTimeString('zh-CN', { hour12: false }),
    };

    setOrders([newOrd, ...orders]);
  };

  const bids = orders.filter((o) => o.side === 'BID');
  const asks = orders.filter((o) => o.side === 'ASK');

  return (
    <div className="space-y-6 font-sans">
      {/* Route Selector Banner */}
      <div className="bg-[#0f141c] border border-slate-800 p-4 rounded-lg flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-4">
          <div>
            <label className="text-[10px] text-slate-500 font-mono block">发站 (Origin)</label>
            <select
              value={selectedOrigin}
              onChange={(e) => setSelectedOrigin(e.target.value)}
              className="bg-slate-900 border border-slate-700 text-slate-100 rounded px-2 py-1 text-xs font-mono font-bold focus:outline-none"
            >
              {STATIONS_DATA.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.code})
                </option>
              ))}
            </select>
          </div>

          <div className="text-slate-600 font-bold">→</div>

          <div>
            <label className="text-[10px] text-slate-500 font-mono block">到站 (Destination)</label>
            <select
              value={selectedDest}
              onChange={(e) => setSelectedDest(e.target.value)}
              className="bg-slate-900 border border-slate-700 text-slate-100 rounded px-2 py-1 text-xs font-mono font-bold focus:outline-none"
            >
              {STATIONS_DATA.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.code})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[10px] text-slate-500 font-mono block">货物品类 (Cargo Spec)</label>
            <select
              value={selectedCargo}
              onChange={(e) => setSelectedCargo(e.target.value as CargoCategory)}
              className="bg-slate-900 border border-slate-700 text-slate-100 rounded px-2 py-1 text-xs font-mono font-bold focus:outline-none"
            >
              {CARGO_SPECS.map((c) => (
                <option key={c.category} value={c.category}>
                  {c.nameCn}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[10px] text-slate-500 font-mono block">发运规模 (Volume)</label>
            <input
              type="number"
              value={selectedVolume}
              onChange={(e) => setSelectedVolume(Number(e.target.value))}
              className="w-24 bg-slate-900 border border-slate-700 text-slate-100 rounded px-2 py-1 text-xs font-mono font-bold focus:outline-none"
              step="500"
            />
          </div>
        </div>

        {/* Current Model Fair Price Callout */}
        <div className="flex items-center gap-3">
          <div className="text-right">
            <div className="text-[10px] text-slate-400 font-mono uppercase">模型公允现货价格 (Model Fair Spot Rate)</div>
            <div className="text-2xl font-black text-red-400 font-mono tabular-nums">
              ¥ {spotQuote.breakdown.totalLandedCostRmbTon.toFixed(2)}
              <span className="text-xs text-slate-400 font-normal"> / 吨</span>
            </div>
          </div>

          <button
            onClick={() => onOpenCalculation(selectedOrigin, selectedDest, selectedCargo, selectedVolume)}
            className="px-3 py-2 bg-red-600 hover:bg-red-500 text-white font-bold rounded text-xs transition-colors shadow flex items-center gap-1 font-mono"
          >
            <Calculator className="w-3.5 h-3.5" />
            <span>【计算】明细</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Order Book & Term Structure Curve */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Order Book (6 Cols) */}
        <div className="lg:col-span-6 bg-[#0f141c] border border-slate-800 rounded-lg p-4 font-mono text-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-slate-800 pb-2.5 mb-3 font-sans">
              <h3 className="font-bold text-slate-100 flex items-center gap-2 text-sm">
                现货订单簿 (Rail Freight Order Book)
              </h3>
              <span className="text-slate-500 text-xs">买卖买方双向询价与运力挂牌</span>
            </div>

            {/* Order Book Depth Table */}
            <div className="space-y-4">
              {/* Asks (Sell / Carriers) */}
              <div>
                <div className="text-[10px] text-red-400 font-bold mb-1 uppercase tracking-wider flex justify-between">
                  <span>卖方运力挂牌 (ASK / Carrier Offer)</span>
                  <span>单价 (¥/吨)</span>
                </div>
                <div className="space-y-1">
                  {asks.slice(0, 4).map((item) => (
                    <div
                      key={item.id}
                      className="p-2 bg-red-950/20 border border-red-900/40 rounded flex items-center justify-between text-slate-200"
                    >
                      <div className="flex items-center gap-2">
                        <span className="px-1 bg-red-900/60 text-red-300 rounded text-[10px]">ASK</span>
                        <span className="font-sans font-medium text-slate-300">{item.shipperOrCarrier}</span>
                      </div>
                      <div className="flex items-center gap-4">
                        <span className="text-slate-400">{item.volumeTons} 吨 ({item.wagonType})</span>
                        <span className="text-red-400 font-bold tabular-nums">¥ {item.priceRmbTon.toFixed(2)}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Spread Indicator */}
              <div className="p-2 bg-slate-900 border border-slate-800 rounded flex items-center justify-between text-[11px]">
                <span className="text-slate-400">买卖买价价差 (Spread):</span>
                <span className="text-amber-400 font-bold tabular-nums">
                  ¥ {(asks[0]?.priceRmbTon - bids[0]?.priceRmbTon || 1.5).toFixed(2)} / 吨
                </span>
              </div>

              {/* Bids (Buy / Shippers) */}
              <div>
                <div className="text-[10px] text-emerald-400 font-bold mb-1 uppercase tracking-wider flex justify-between">
                  <span>买方货源需求 (BID / Shipper Demand)</span>
                  <span>单价 (¥/吨)</span>
                </div>
                <div className="space-y-1">
                  {bids.slice(0, 4).map((item) => (
                    <div
                      key={item.id}
                      className="p-2 bg-emerald-950/20 border border-emerald-900/40 rounded flex items-center justify-between text-slate-200"
                    >
                      <div className="flex items-center gap-2">
                        <span className="px-1 bg-emerald-900/60 text-emerald-300 rounded text-[10px]">BID</span>
                        <span className="font-sans font-medium text-slate-300">{item.shipperOrCarrier}</span>
                      </div>
                      <div className="flex items-center gap-4">
                        <span className="text-slate-400">{item.volumeTons} 吨 ({item.wagonType})</span>
                        <span className="text-emerald-400 font-bold tabular-nums">¥ {item.priceRmbTon.toFixed(2)}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* New Order Submission Widget */}
          <form onSubmit={handleAddOrder} className="mt-4 pt-3 border-t border-slate-800 space-y-2">
            <div className="text-xs font-bold font-sans text-slate-300">发货需求 / 运力挂单提交</div>
            <div className="grid grid-cols-3 gap-2">
              <select
                value={newSide}
                onChange={(e) => setNewSide(e.target.value as 'BID' | 'ASK')}
                className="bg-slate-900 border border-slate-700 text-slate-100 p-1.5 rounded text-xs focus:outline-none font-bold"
              >
                <option value="BID">BID (买方需求)</option>
                <option value="ASK">ASK (卖方运力)</option>
              </select>
              <input
                type="text"
                placeholder="机构名称"
                value={newShipper}
                onChange={(e) => setNewShipper(e.target.value)}
                className="bg-slate-900 border border-slate-700 text-slate-100 p-1.5 rounded text-xs focus:outline-none"
              />
              <input
                type="number"
                placeholder="报价 (¥/吨)"
                value={newPrice}
                onChange={(e) => setNewPrice(Number(e.target.value))}
                className="bg-slate-900 border border-slate-700 text-slate-100 p-1.5 rounded text-xs focus:outline-none font-bold"
                step="0.5"
              />
            </div>
            <button
              type="submit"
              className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-100 rounded font-bold transition-colors flex items-center justify-center gap-1 font-sans"
            >
              <PlusCircle className="w-3.5 h-3.5 text-red-400" />
              <span>挂牌录入现货订单簿</span>
            </button>
          </form>
        </div>

        {/* Right Column: Term Structure & Freight Forward Curve (6 Cols) */}
        <div className="lg:col-span-6 bg-[#0f141c] border border-slate-800 rounded-lg p-4 font-mono text-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-slate-800 pb-2.5 mb-3 font-sans">
              <div>
                <h3 className="font-bold text-slate-100 text-sm">
                  铁路货运远期价格曲线 (Freight Forward Curve)
                </h3>
                <p className="text-[11px] text-slate-400 font-mono">
                  Spot vs 7D, 30D, 90D, 180D, 1Y 运力锁定期限结构
                </p>
              </div>
            </div>

            {/* Forward Curve Visualization */}
            <div className="bg-[#070a0f] border border-slate-800 rounded p-3 h-48 relative flex items-end justify-between gap-2 px-6">
              {/* SVG Curve Line overlay */}
              <svg className="absolute inset-0 w-full h-full pointer-events-none p-4">
                <path
                  d="M 40,110 Q 120,95 200,75 T 380,35"
                  fill="none"
                  stroke="#ef4444"
                  strokeWidth="2.5"
                />
              </svg>

              {/* Term structure bars & points */}
              {forwardPoints.map((pt) => {
                const heightPct = Math.min(95, Math.max(20, (pt.rateRmbTon / (spotQuote.breakdown.totalLandedCostRmbTon * 1.15)) * 100));
                return (
                  <div key={pt.tenor} className="flex flex-col items-center gap-2 z-10">
                    <div className="text-[10px] text-slate-300 font-bold tabular-nums">
                      ¥ {pt.rateRmbTon.toFixed(1)}
                    </div>
                    <div
                      className="w-8 bg-gradient-to-t from-slate-900 to-red-900/60 border-t-2 border-red-500 rounded-t transition-all hover:bg-red-800/80 cursor-pointer"
                      style={{ height: `${heightPct}%` }}
                    ></div>
                    <div className="text-[10px] text-slate-400 font-bold">{pt.tenor}</div>
                  </div>
                );
              })}
            </div>

            {/* Forward Curve Table Detail */}
            <div className="mt-4 border border-slate-800/80 rounded overflow-hidden">
              <table className="w-full text-left text-[11px]">
                <thead className="bg-slate-900 text-slate-400 border-b border-slate-800 font-sans">
                  <tr>
                    <th className="p-2">期限 (Tenor)</th>
                    <th className="p-2">预计装车日</th>
                    <th className="p-2 text-right">远期运价 (¥/吨)</th>
                    <th className="p-2 text-right">较现货基差 (Spread)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {forwardPoints.map((pt) => (
                    <tr key={pt.tenor} className="hover:bg-slate-900/50">
                      <td className="p-2 font-bold text-slate-200">{pt.tenor}</td>
                      <td className="p-2 text-slate-400">{pt.dispatchDate}</td>
                      <td className="p-2 text-right font-bold text-slate-100 tabular-nums">¥ {pt.rateRmbTon.toFixed(2)}</td>
                      <td className="p-2 text-right font-bold tabular-nums">
                        <span className={pt.spreadVsSpotRmbTon >= 0 ? 'text-red-400' : 'text-emerald-400'}>
                          {pt.spreadVsSpotRmbTon >= 0 ? '+' : ''}
                          {pt.spreadVsSpotRmbTon.toFixed(2)}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="mt-3 p-2 bg-slate-900/80 border border-slate-800 rounded text-[11px] text-slate-400 font-sans">
            <strong>远期合约解读: </strong>由于冬季煤炭保供与四季度干线修，30天与90天远期价格存在正向升水 (Contango)，建议货主提前锁定运力额度。
          </div>
        </div>
      </div>
    </div>
  );
};
