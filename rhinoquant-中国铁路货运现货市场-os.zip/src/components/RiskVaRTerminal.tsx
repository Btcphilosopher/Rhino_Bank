import React, { useState } from 'react';
import { RiskVaRMetrics, SpotQuote } from '../types/rail';
import { calculateSpotQuote, calculateRiskVaR } from '../engine/railMathEngine';
import { ShieldAlert, ChevronRight, ChevronDown, Activity, AlertTriangle, TrendingDown } from 'lucide-react';

export const RiskVaRTerminal: React.FC = () => {
  const [varMethod, setVarMethod] = useState<'PARAMETRIC' | 'HISTORICAL' | 'MONTE_CARLO'>('PARAMETRIC');
  const [expandedNodes, setExpandedNodes] = useState<{ [key: string]: boolean }>({
    TOTAL: true,
    CAPACITY: true,
    DEMAND: false,
    TRANSIT: false,
    COST: false,
  });

  const quote = calculateSpotQuote('ST_SH_MH', 'ST_CD_CX', 'STEEL', 5000);
  const metrics: RiskVaRMetrics = calculateRiskVaR(quote);

  const toggleNode = (nodeKey: string) => {
    setExpandedNodes((prev) => ({ ...prev, [nodeKey]: !prev[nodeKey] }));
  };

  return (
    <div className="space-y-6 font-sans">
      {/* Header */}
      <div className="bg-[#0f141c] border border-slate-800 p-5 rounded-lg flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-red-500" />
            铁路货运 VaR 风险管理与中国铁路风险树 (Freight VaR & Risk Tree)
          </h2>
          <p className="text-xs text-slate-400 font-mono mt-1">
            度量: Price VaR (95%) · Transit-Time VaR · Capacity VaR · Expected Shortfall (ES 尾部损失)
          </p>
        </div>

        {/* VaR Calculation Method Switcher */}
        <div className="flex items-center gap-1 bg-slate-900 p-1 rounded border border-slate-800 text-xs font-mono font-bold">
          <button
            onClick={() => setVarMethod('PARAMETRIC')}
            className={`px-3 py-1.5 rounded transition-colors ${
              varMethod === 'PARAMETRIC' ? 'bg-red-900 text-red-100 border border-red-700' : 'text-slate-400 hover:text-white'
            }`}
          >
            Parametric VaR (参数法)
          </button>
          <button
            onClick={() => setVarMethod('HISTORICAL')}
            className={`px-3 py-1.5 rounded transition-colors ${
              varMethod === 'HISTORICAL' ? 'bg-blue-900 text-blue-100 border border-blue-700' : 'text-slate-400 hover:text-white'
            }`}
          >
            Historical VaR (历史模拟法)
          </button>
          <button
            onClick={() => setVarMethod('MONTE_CARLO')}
            className={`px-3 py-1.5 rounded transition-colors ${
              varMethod === 'MONTE_CARLO' ? 'bg-amber-900 text-amber-100 border border-amber-700' : 'text-slate-400 hover:text-white'
            }`}
          >
            Monte Carlo 10,000次
          </button>
        </div>
      </div>

      {/* Top VaR Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 font-mono text-xs">
        <div className="p-4 bg-[#0f141c] border border-slate-800 rounded-lg">
          <div className="text-slate-500 text-[10px]">运价风险值 (Price VaR 95%)</div>
          <div className="text-2xl font-black text-red-400 tabular-nums">
            ¥ {metrics.priceVaR95RmbTon.toFixed(2)} / 吨
          </div>
          <div className="text-[10px] text-slate-400 font-sans mt-1">95%置信度下最大单日运价跃升</div>
        </div>

        <div className="p-4 bg-[#0f141c] border border-slate-800 rounded-lg">
          <div className="text-slate-500 text-[10px]">途在时间风险 (Transit-Time VaR)</div>
          <div className="text-2xl font-black text-amber-400 tabular-nums">
            +{metrics.transitVaR95Hours} 小时
          </div>
          <div className="text-[10px] text-slate-400 font-sans mt-1">95%置信度下编组最长极端延误</div>
        </div>

        <div className="p-4 bg-[#0f141c] border border-slate-800 rounded-lg">
          <div className="text-slate-500 text-[10px]">尾部期望损失 (Expected Shortfall / ES)</div>
          <div className="text-2xl font-black text-blue-400 tabular-nums">
            ¥ {metrics.expectedShortfallRmbTon.toFixed(2)} / 吨
          </div>
          <div className="text-[10px] text-slate-400 font-sans mt-1">超越 VaR 阈值时的平均极端损失</div>
        </div>

        <div className="p-4 bg-[#0f141c] border border-slate-800 rounded-lg">
          <div className="text-slate-500 text-[10px]">全网综合风险得分 (Risk Score)</div>
          <div className="text-2xl font-black text-emerald-400 tabular-nums">
            {metrics.overallRiskScore} / 100
          </div>
          <div className="text-[10px] text-slate-400 font-sans mt-1">综合卡口利用率与恶劣天气</div>
        </div>
      </div>

      {/* China Freight Risk Tree (中国铁路风险树) */}
      <div className="bg-[#0f141c] border border-slate-800 rounded-lg p-5 font-mono text-xs">
        <h3 className="font-bold font-sans text-slate-200 text-sm border-b border-slate-800 pb-2 mb-4">
          中国铁路风险树 (China Rail Freight Risk Tree) — 点击展开数学分解
        </h3>

        <div className="space-y-2">
          {/* Node 1: Total Freight Risk */}
          <div className="border border-slate-800 rounded p-3 bg-slate-900/90">
            <button
              onClick={() => toggleNode('TOTAL')}
              className="flex items-center justify-between w-full font-bold text-slate-100 text-sm font-sans text-left"
            >
              <span className="flex items-center gap-2">
                {expandedNodes['TOTAL'] ? <ChevronDown className="w-4 h-4 text-red-500" /> : <ChevronRight className="w-4 h-4 text-slate-500" />}
                TOTAL FREIGHT RISK (全国铁路货运总风险度量)
              </span>
              <span className="text-red-400 font-mono text-xs">VaR 占比 100.0%</span>
            </button>

            {expandedNodes['TOTAL'] && (
              <div className="mt-3 pl-6 border-l border-slate-800 space-y-2">
                {/* Child A: Capacity Risk */}
                <div className="p-2.5 bg-slate-950/80 border border-slate-800 rounded">
                  <button
                    onClick={() => toggleNode('CAPACITY')}
                    className="flex items-center justify-between w-full font-bold text-slate-200 font-sans text-xs text-left"
                  >
                    <span className="flex items-center gap-2">
                      {expandedNodes['CAPACITY'] ? <ChevronDown className="w-3.5 h-3.5 text-amber-500" /> : <ChevronRight className="w-3.5 h-3.5 text-slate-500" />}
                      ├── 1. 运力风险 (Capacity Risk)
                    </span>
                    <span className="text-amber-400 font-mono text-[11px]">贡献率 42.5%</span>
                  </button>

                  {expandedNodes['CAPACITY'] && (
                    <div className="mt-2 pl-6 space-y-1 text-[11px] text-slate-400">
                      <div>│ ├── 线路干线通畅度 (Line Utilization Rate: 89.0%)</div>
                      <div>│ ├── 编组站到发线卡口 (Marshalling Yard Congestion Index: 78)</div>
                      <div>│ └── 车辆/车皮周转 (Wagon Turnaround Days: 3.8天)</div>
                    </div>
                  )}
                </div>

                {/* Child B: Demand Risk */}
                <div className="p-2.5 bg-slate-950/80 border border-slate-800 rounded">
                  <button
                    onClick={() => toggleNode('DEMAND')}
                    className="flex items-center justify-between w-full font-bold text-slate-200 font-sans text-xs text-left"
                  >
                    <span className="flex items-center gap-2">
                      {expandedNodes['DEMAND'] ? <ChevronDown className="w-3.5 h-3.5 text-blue-500" /> : <ChevronRight className="w-3.5 h-3.5 text-slate-500" />}
                      ├── 2. 需求风险 (Demand Risk)
                    </span>
                    <span className="text-blue-400 font-mono text-[11px]">贡献率 28.0%</span>
                  </button>

                  {expandedNodes['DEMAND'] && (
                    <div className="mt-2 pl-6 space-y-1 text-[11px] text-slate-400">
                      <div>│ ├── 能源煤炭保供发运 (Coal Supply Mandate)</div>
                      <div>│ ├── 工业制造与钢材需求 (Steel Construction Activity)</div>
                      <div>│ └── 集装箱外贸需求 (Export Container Volume)</div>
                    </div>
                  )}
                </div>

                {/* Child C: Transit Time Risk */}
                <div className="p-2.5 bg-slate-950/80 border border-slate-800 rounded">
                  <button
                    onClick={() => toggleNode('TRANSIT')}
                    className="flex items-center justify-between w-full font-bold text-slate-200 font-sans text-xs text-left"
                  >
                    <span className="flex items-center gap-2">
                      {expandedNodes['TRANSIT'] ? <ChevronDown className="w-3.5 h-3.5 text-purple-500" /> : <ChevronRight className="w-3.5 h-3.5 text-slate-500" />}
                      ├── 3. 时间与延误风险 (Transit Time Risk)
                    </span>
                    <span className="text-purple-400 font-mono text-[11px]">贡献率 18.5%</span>
                  </button>

                  {expandedNodes['TRANSIT'] && (
                    <div className="mt-2 pl-6 space-y-1 text-[11px] text-slate-400">
                      <div>│ ├── 季节性极端雨雪 (Extreme Weather Window)</div>
                      <div>│ └── 卡口解编滞留 (Marshalling Delay Variance)</div>
                    </div>
                  )}
                </div>

                {/* Child D: Cost Risk */}
                <div className="p-2.5 bg-slate-950/80 border border-slate-800 rounded">
                  <button
                    onClick={() => toggleNode('COST')}
                    className="flex items-center justify-between w-full font-bold text-slate-200 font-sans text-xs text-left"
                  >
                    <span className="flex items-center gap-2">
                      {expandedNodes['COST'] ? <ChevronDown className="w-3.5 h-3.5 text-emerald-500" /> : <ChevronRight className="w-3.5 h-3.5 text-slate-500" />}
                      └── 4. 成本与替代运输风险 (Cost & Multimodal Risk)
                    </span>
                    <span className="text-emerald-400 font-mono text-[11px]">贡献率 11.0%</span>
                  </button>

                  {expandedNodes['COST'] && (
                    <div className="mt-2 pl-6 space-y-1 text-[11px] text-slate-400">
                      <div>  ├── 公路重卡柴油运价联动 (Road Truck Fuel Parity)</div>
                      <div>  └── 沿海/内河港口封航接驳 (Port Feedering Cost)</div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
