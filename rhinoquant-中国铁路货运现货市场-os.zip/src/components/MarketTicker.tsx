import React from 'react';
import { FreightIndexItem } from '../types/rail';
import { TrendingUp, TrendingDown, AlertTriangle, ShieldCheck } from 'lucide-react';

export interface MarketTickerProps {
  indices: FreightIndexItem[];
  bottleneckAlerts: string[];
}

export const MarketTicker: React.FC<MarketTickerProps> = ({ indices, bottleneckAlerts }) => {
  return (
    <div className="bg-[#0f141c] border-b border-slate-800/80 px-4 py-1.5 text-xs font-mono flex items-center justify-between overflow-hidden">
      <div className="flex items-center gap-6 overflow-x-auto scrollbar-none py-0.5">
        <div className="flex items-center gap-1.5 shrink-0 text-slate-400 font-bold uppercase tracking-wider text-[11px]">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
          <span>CRFI 实时运价指数</span>
        </div>

        {indices.map((idx) => {
          const isUp = idx.changeValue >= 0;
          return (
            <div key={idx.code} className="flex items-center gap-2 shrink-0 border-r border-slate-800 pr-4">
              <span className="text-slate-400 text-[11px] font-sans">{idx.name.replace('CRFI ', '')}:</span>
              <span className="text-slate-100 font-bold tabular-nums">{idx.currentValue.toFixed(2)}</span>
              <span
                className={`flex items-center text-[11px] font-semibold tabular-nums ${
                  isUp ? 'text-emerald-400' : 'text-red-400'
                }`}
              >
                {isUp ? <TrendingUp className="w-3 h-3 mr-0.5" /> : <TrendingDown className="w-3 h-3 mr-0.5" />}
                {isUp ? '+' : ''}
                {idx.changeValue.toFixed(2)} ({isUp ? '+' : ''}
                {idx.changePct.toFixed(2)}%)
              </span>
            </div>
          );
        })}
      </div>

      <div className="hidden lg:flex items-center gap-2 shrink-0 pl-4 border-l border-slate-800 text-amber-400 text-[11px]">
        <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
        <span className="truncate max-w-xs font-sans text-amber-300/90">
          {bottleneckAlerts[0] || '郑州北编组站繁忙；大秦线日发运突破110万吨'}
        </span>
      </div>
    </div>
  );
};
