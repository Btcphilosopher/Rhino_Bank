import React, { useState } from 'react';
import { Station, RailSegment, RailCorridor } from '../types/rail';
import { STATIONS_DATA, RAIL_SEGMENTS, RAIL_CORRIDORS } from '../data/mockRailData';
import { MapPin, Navigation, Eye, AlertTriangle, Cpu, Train, Layers, ShieldCheck } from 'lucide-react';

export interface DigitalTwinMapProps {
  selectedStationId: string | null;
  onSelectStation: (station: Station) => void;
  onOpenCalculation: (originId: string, destId: string) => void;
}

export const DigitalTwinMap: React.FC<DigitalTwinMapProps> = ({
  selectedStationId,
  onSelectStation,
  onOpenCalculation,
}) => {
  const [mapMode, setMapMode] = useState<'FLOW' | 'CAPACITY' | 'BOTTLENECK' | 'CORRIDOR'>('FLOW');
  const [hoveredStation, setHoveredStation] = useState<Station | null>(null);
  const [hoveredSegment, setHoveredSegment] = useState<RailSegment | null>(null);
  const [originStation, setOriginStation] = useState<string>('ST_SH_MH');
  const [destStation, setDestStation] = useState<string>('ST_CD_CX');

  // Convert lat/lng to SVG map coordinates [0..800, 0..500]
  // China Bounding Box approximately: Lng 80°E to 125°E, Lat 20°N to 45°N
  const projectCoords = (lng: number, lat: number) => {
    const minLng = 80;
    const maxLng = 125;
    const minLat = 20;
    const maxLat = 45;

    const x = ((lng - minLng) / (maxLng - minLng)) * 760 + 20;
    const y = ((maxLat - lat) / (maxLat - minLat)) * 460 + 20;
    return { x, y };
  };

  const getStationColor = (station: Station) => {
    if (station.restriction.restrictionType === 'CARGO_LIMIT') return '#f59e0b';
    if (station.restriction.restrictionType === 'TEMP_BAN') return '#ef4444';
    if (station.stationType === 'MARSHALLING') return '#3b82f6';
    if (station.stationType === 'PORT_TERMINAL') return '#06b6d4';
    if (station.stationType === 'MINE_SIDING') return '#8b5cf6';
    return '#10b981';
  };

  const getSegmentColor = (segment: RailSegment) => {
    const util = segment.currentLoadTonsDay / segment.designCapacityTonsDay;
    if (mapMode === 'BOTTLENECK' || util > 0.88) return '#ef4444';
    if (mapMode === 'CAPACITY') {
      if (util > 0.82) return '#f59e0b';
      return '#3b82f6';
    }
    return '#38bdf8';
  };

  return (
    <div className="bg-[#0f141c] border border-slate-800 rounded-lg p-4 flex flex-col font-sans relative overflow-hidden">
      {/* Map Header & Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-3 border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-red-950/80 border border-red-800/60 rounded text-red-400">
            <Train className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              中国铁路货运网络数字孪生 (China Rail Freight Digital Twin)
            </h2>
            <p className="text-[11px] text-slate-400 font-mono">
              全国核心编组站、大宗重载通道、港口海铁联运 & 实时流量热图
            </p>
          </div>
        </div>

        {/* Layer Mode Selector */}
        <div className="flex items-center gap-1 bg-slate-900 p-1 rounded border border-slate-800 text-xs font-mono">
          <button
            onClick={() => setMapMode('FLOW')}
            className={`px-2.5 py-1 rounded transition-colors ${
              mapMode === 'FLOW' ? 'bg-red-900/60 text-red-200 border border-red-700 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            实时车流 (Flow)
          </button>
          <button
            onClick={() => setMapMode('CAPACITY')}
            className={`px-2.5 py-1 rounded transition-colors ${
              mapMode === 'CAPACITY' ? 'bg-blue-900/60 text-blue-200 border border-blue-700 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            运力利用率 (Capacity)
          </button>
          <button
            onClick={() => setMapMode('BOTTLENECK')}
            className={`px-2.5 py-1 rounded transition-colors ${
              mapMode === 'BOTTLENECK' ? 'bg-amber-900/60 text-amber-200 border border-amber-700 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            卡口瓶颈 (Bottleneck)
          </button>
          <button
            onClick={() => setMapMode('CORRIDOR')}
            className={`px-2.5 py-1 rounded transition-colors ${
              mapMode === 'CORRIDOR' ? 'bg-emerald-900/60 text-emerald-200 border border-emerald-700 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            核心走廊 (Corridors)
          </button>
        </div>
      </div>

      {/* SVG Map Canvas Container */}
      <div className="relative w-full aspect-[16/9] bg-[#070a0f] border border-slate-800/80 rounded overflow-hidden shadow-inner group">
        {/* Background Grid Pattern */}
        <svg className="absolute inset-0 w-full h-full opacity-20 pointer-events-none">
          <defs>
            <pattern id="grid" width="30" height="30" patternUnits="userSpaceOnUse">
              <path d="M 30 0 L 0 0 0 30" fill="none" stroke="#334155" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>

        {/* China Land Outline Aesthetic Sketch */}
        <svg viewBox="0 0 800 500" className="w-full h-full">
          {/* Subtle territory decorative curve */}
          <path
            d="M 120,80 Q 250,50 450,60 T 680,100 Q 750,220 720,380 T 520,440 Q 300,420 180,360 T 80,220 Z"
            fill="#0f172a"
            fillOpacity="0.25"
            stroke="#1e293b"
            strokeWidth="1"
            strokeDasharray="4 4"
          />

          {/* Draw Railway Segments / Lines */}
          {RAIL_SEGMENTS.map((seg) => {
            const sSource = STATIONS_DATA.find((s) => s.id === seg.sourceStationId);
            const sTarget = STATIONS_DATA.find((s) => s.id === seg.targetStationId);
            if (!sSource || !sTarget) return null;

            const p1 = projectCoords(sSource.lng, sSource.lat);
            const p2 = projectCoords(sTarget.lng, sTarget.lat);
            const strokeColor = getSegmentColor(seg);
            const utilPct = Math.round((seg.currentLoadTonsDay / seg.designCapacityTonsDay) * 100);

            return (
              <g key={seg.id} className="cursor-pointer group/seg" onMouseEnter={() => setHoveredSegment(seg)} onMouseLeave={() => setHoveredSegment(null)}>
                {/* Outer halo line */}
                <line
                  x1={p1.x}
                  y1={p1.y}
                  x2={p2.x}
                  y2={p2.y}
                  stroke={strokeColor}
                  strokeWidth={utilPct > 85 ? "4" : "2.5"}
                  strokeOpacity={mapMode === 'CORRIDOR' ? "0.3" : "0.7"}
                  strokeLinecap="round"
                />

                {/* Animated train flow pulses */}
                {mapMode === 'FLOW' && (
                  <line
                    x1={p1.x}
                    y1={p1.y}
                    x2={p2.x}
                    y2={p2.y}
                    stroke="#ffffff"
                    strokeWidth="2"
                    strokeDasharray="6 18"
                    className="animate-pulse"
                  />
                )}
              </g>
            );
          })}

          {/* Draw Stations Nodes */}
          {STATIONS_DATA.map((st) => {
            const p = projectCoords(st.lng, st.lat);
            const nodeColor = getStationColor(st);
            const isSelected = selectedStationId === st.id;

            return (
              <g
                key={st.id}
                transform={`translate(${p.x}, ${p.y})`}
                className="cursor-pointer transition-transform duration-200 hover:scale-125"
                onClick={() => onSelectStation(st)}
                onMouseEnter={() => setHoveredStation(st)}
                onMouseLeave={() => setHoveredStation(null)}
              >
                {/* Pulse ring for selected or restricted station */}
                {(isSelected || st.restriction.restrictionType !== 'NORMAL') && (
                  <circle
                    r="12"
                    fill="none"
                    stroke={st.restriction.restrictionType !== 'NORMAL' ? '#f59e0b' : '#ef4444'}
                    strokeWidth="1.5"
                    className="animate-ping opacity-75"
                  />
                )}

                {/* Core node dot */}
                <circle
                  r={st.stationType === 'MARSHALLING' ? '6' : '4.5'}
                  fill={nodeColor}
                  stroke="#0f172a"
                  strokeWidth="1.5"
                  className="shadow-lg"
                />

                {/* Station Label */}
                <text
                  x="8"
                  y="4"
                  fill="#f1f5f9"
                  fontSize="10"
                  fontFamily="sans-serif"
                  fontWeight={isSelected ? 'bold' : 'normal'}
                  className="select-none pointer-events-none filter drop-shadow-md"
                >
                  {st.name.replace('站', '')}
                </text>
              </g>
            );
          })}
        </svg>

        {/* Hover Segment / Station Floating Card */}
        {hoveredStation && (
          <div className="absolute bottom-3 left-3 bg-[#0f141c]/95 border border-slate-700 p-3 rounded shadow-xl text-xs font-mono max-w-sm backdrop-blur pointer-events-none z-20">
            <div className="flex items-center justify-between border-b border-slate-800 pb-1.5 mb-1.5 font-sans font-bold">
              <span className="text-slate-100">{hoveredStation.name} ({hoveredStation.code})</span>
              <span className="text-red-400">{hoveredStation.region} · {hoveredStation.city}</span>
            </div>
            <div className="space-y-1 text-slate-300">
              <div className="flex justify-between">
                <span className="text-slate-500">类型:</span>
                <span>{hoveredStation.stationType}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">日装卸吞吐能力:</span>
                <span className="text-emerald-400 font-bold">{hoveredStation.capability.dailyHandlingCapacityTons.toLocaleString()} 吨/日</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">起重/专用线:</span>
                <span>{hoveredStation.capability.craneMaxTons}吨起重机 · {hoveredStation.capability.sidingTrackCount}条专用线</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">95306集装箱能力:</span>
                <span>
                  {hoveredStation.capability.container20ftCapable ? '20ft✓ ' : ''}
                  {hoveredStation.capability.container40ftCapable ? '40ft✓' : ''}
                </span>
              </div>
              {hoveredStation.restriction.restrictionType !== 'NORMAL' && (
                <div className="p-1.5 bg-amber-950/80 border border-amber-800/80 rounded text-[11px] text-amber-300 mt-1 font-sans">
                  <strong>公告: </strong>{hoveredStation.restriction.noticeTitle}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Quick Route Inquiry Selector Overlay */}
        <div className="absolute top-3 right-3 bg-[#0f141c]/90 border border-slate-800 p-3 rounded text-xs font-mono shadow-lg backdrop-blur space-y-2 z-10 max-w-xs">
          <div className="font-sans font-bold text-slate-200 border-b border-slate-800 pb-1 flex items-center justify-between">
            <span>快速路线现货测算</span>
            <span className="text-[10px] text-slate-500">Dijkstra 最优路径</span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[10px] text-slate-500">始发站 (Origin)</label>
              <select
                value={originStation}
                onChange={(e) => setOriginStation(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-slate-100 rounded p-1 text-xs focus:outline-none"
              >
                {STATIONS_DATA.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-[10px] text-slate-500">到达站 (Destination)</label>
              <select
                value={destStation}
                onChange={(e) => setDestStation(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-slate-100 rounded p-1 text-xs focus:outline-none"
              >
                {STATIONS_DATA.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
          <button
            onClick={() => onOpenCalculation(originStation, destStation)}
            className="w-full py-1.5 bg-red-600 hover:bg-red-500 text-white rounded font-bold text-xs transition-colors flex items-center justify-center gap-1 shadow-sm font-sans"
          >
            <span>点击【计算】全包运价明细</span>
          </button>
        </div>
      </div>

      {/* Corridor Key Stats Footer Strip */}
      <div className="mt-3 grid grid-cols-2 md:grid-cols-4 gap-2 text-xs font-mono">
        <div className="p-2 bg-slate-900/80 border border-slate-800 rounded">
          <div className="text-[10px] text-slate-500">大秦煤炭通道日运量</div>
          <div className="text-sm font-bold text-slate-100">1,080,000 吨/日</div>
          <div className="text-[10px] text-emerald-400">利用率 90.0% (正常)</div>
        </div>
        <div className="p-2 bg-slate-900/80 border border-slate-800 rounded">
          <div className="text-[10px] text-slate-500">华东-西南东西主通道</div>
          <div className="text-sm font-bold text-slate-100">124,600 吨/日</div>
          <div className="text-[10px] text-amber-400">利用率 89.0% (容量偏紧)</div>
        </div>
        <div className="p-2 bg-slate-900/80 border border-slate-800 rounded">
          <div className="text-[10px] text-slate-500">中欧班列集结走廊</div>
          <div className="text-sm font-bold text-slate-100">97,900 吨/日</div>
          <div className="text-[10px] text-blue-400">平均运距 2,891 km</div>
        </div>
        <div className="p-2 bg-slate-900/80 border border-slate-800 rounded">
          <div className="text-[10px] text-slate-500">全网平均商业车速</div>
          <div className="text-sm font-bold text-slate-100">35.4 km/h</div>
          <div className="text-[10px] text-slate-400">含卡口编组解体时间</div>
        </div>
      </div>
    </div>
  );
};
