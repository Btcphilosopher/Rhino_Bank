import React, { useState } from 'react';
import { DataProviderStatus, Station, SpotQuote, CargoCategory } from './types/rail';
import { STATIONS_DATA, INITIAL_CRFI_INDICES } from './data/mockRailData';
import { calculateSpotQuote } from './engine/railMathEngine';

// Components
import { TopNav } from './components/TopNav';
import { MarketTicker } from './components/MarketTicker';
import { DigitalTwinMap } from './components/DigitalTwinMap';
import { CalculationExplorerModal } from './components/CalculationExplorerModal';
import { SpotMarketTerminal } from './components/SpotMarketTerminal';
import { RouteTerminal } from './components/RouteTerminal';
import { CapacityElasticityLab } from './components/CapacityElasticityLab';
import { CommodityRailLinkage } from './components/CommodityRailLinkage';
import { ScenarioLab } from './components/ScenarioLab';
import { RiskVaRTerminal } from './components/RiskVaRTerminal';
import { MultimodalComparison } from './components/MultimodalComparison';
import { CorporateFreightDesk } from './components/CorporateFreightDesk';
import { AIMarketAnalyst } from './components/AIMarketAnalyst';
import { FlagshipDemosModal } from './components/FlagshipDemosModal';

export function App() {
  const [activeTab, setActiveTab] = useState<string>('OVERVIEW');
  const [dataStatus, setDataStatus] = useState<DataProviderStatus>('LIVE');
  const [marketState, setMarketState] = useState<'NORMAL' | 'HIGH_DEMAND' | 'CAPACITY_TIGHT' | 'CONGESTED' | 'DISRUPTED'>('CAPACITY_TIGHT');

  // Selected station for details
  const [selectedStation, setSelectedStation] = useState<Station | null>(STATIONS_DATA[0]);

  // Calculation Explorer Modal State
  const [explorerQuote, setExplorerQuote] = useState<SpotQuote | null>(null);
  const [isExplorerOpen, setIsExplorerOpen] = useState<boolean>(false);

  // Modals
  const [isAiAnalystOpen, setIsAiAnalystOpen] = useState<boolean>(false);
  const [isFlagshipOpen, setIsFlagshipOpen] = useState<boolean>(false);

  const handleOpenCalculation = (
    originId: string,
    destId: string,
    cargoCategory: CargoCategory = 'STEEL',
    volumeTons: number = 5000
  ) => {
    const quote = calculateSpotQuote(originId, destId, cargoCategory, volumeTons);
    setExplorerQuote(quote);
    setIsExplorerOpen(true);
  };

  const bottleneckAlerts = [
    '【预警】郑州北编组站到发线占用率达 92%，笨重超限货物暂停接卸',
    '【干线】大秦线万吨重载列车日发运量达 108 万吨，港口库存偏高',
    '【西部】成都城厢集装箱短缺 1,800 TEU，返程空箱调运溢价 +¥15/吨',
  ];

  return (
    <div className="min-h-screen bg-[#0a0d12] text-slate-100 flex flex-col font-sans selection:bg-red-900 selection:text-red-100">
      {/* 1. Header Navigation Bar */}
      <TopNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        dataStatus={dataStatus}
        setDataStatus={setDataStatus}
        marketState={marketState}
        onOpenFlagshipDemos={() => setIsFlagshipOpen(true)}
        onOpenAiAnalyst={() => setIsAiAnalystOpen(true)}
      />

      {/* 2. Real-time Market Ticker */}
      <MarketTicker indices={INITIAL_CRFI_INDICES} bottleneckAlerts={bottleneckAlerts} />

      {/* 3. Main Operating Content Workspace */}
      <main className="flex-1 p-4 lg:p-6 max-w-[1800px] w-full mx-auto space-y-6">
        {/* TAB 1: Real-time Overview (数字孪生地图 + 全景状态) */}
        {activeTab === 'OVERVIEW' && (
          <div className="space-y-6">
            <DigitalTwinMap
              selectedStationId={selectedStation?.id || null}
              onSelectStation={(st) => setSelectedStation(st)}
              onOpenCalculation={handleOpenCalculation}
            />

            {/* Selected Station 95306 Capabilities & Restrictions Detail Desk */}
            {selectedStation && (
              <div className="bg-[#0f141c] border border-slate-800 rounded-lg p-5 font-mono text-xs">
                <div className="flex flex-wrap items-center justify-between border-b border-slate-800 pb-3 mb-4 gap-4 font-sans">
                  <div className="flex items-center gap-3">
                    <span className="text-base font-bold text-slate-100">
                      {selectedStation.name} ({selectedStation.code}) 95306 货运节点档案
                    </span>
                    <span className="px-2 py-0.5 bg-slate-800 text-slate-300 rounded text-xs border border-slate-700">
                      {selectedStation.stationType}
                    </span>
                    <span className="text-slate-400 text-xs">
                      {selectedStation.province} · {selectedStation.city} ({selectedStation.region})
                    </span>
                  </div>

                  <button
                    onClick={() => handleOpenCalculation(selectedStation.id, 'ST_CD_CX')}
                    className="px-3 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded font-bold text-xs transition-colors flex items-center gap-1 shadow"
                  >
                    <span>以此站为起点测算到成都运价</span>
                  </button>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-slate-300">
                  <div className="p-3 bg-slate-900 border border-slate-800 rounded space-y-1">
                    <div className="text-slate-500 text-[10px]">起重作业能力 (Crane)</div>
                    <div className="text-sm font-bold text-slate-100">
                      最大起重 {selectedStation.capability.craneMaxTons} 吨
                    </div>
                    <div className="text-[10px] text-slate-400">
                      配备叉车 {selectedStation.capability.forkliftCount} 台
                    </div>
                  </div>

                  <div className="p-3 bg-slate-900 border border-slate-800 rounded space-y-1">
                    <div className="text-slate-500 text-[10px]">95306 集装箱办理</div>
                    <div className="text-sm font-bold text-slate-100">
                      {selectedStation.capability.container20ftCapable ? '20ft 允许 ✓ ' : ''}
                      {selectedStation.capability.container40ftCapable ? '40ft 允许 ✓' : ''}
                    </div>
                    <div className="text-[10px] text-slate-400">
                      货场面积: {(selectedStation.capability.cargoYardAreaSqMeters / 10000).toFixed(1)} 万平米
                    </div>
                  </div>

                  <div className="p-3 bg-slate-900 border border-slate-800 rounded space-y-1">
                    <div className="text-slate-500 text-[10px]">专用线与到发线</div>
                    <div className="text-sm font-bold text-slate-100">
                      专用线 {selectedStation.capability.sidingTrackCount} 条
                    </div>
                    <div className="text-[10px] text-slate-400">
                      日吞吐能力: {selectedStation.capability.dailyHandlingCapacityTons.toLocaleString()} 吨
                    </div>
                  </div>

                  <div className="p-3 bg-slate-900 border border-slate-800 rounded space-y-1">
                    <div className="text-slate-500 text-[10px]">停限装与公告 (95306 Notice)</div>
                    <div className="text-sm font-bold text-amber-400 truncate">
                      {selectedStation.restriction.noticeTitle}
                    </div>
                    <div className="text-[10px] text-slate-400 truncate">
                      {selectedStation.restriction.description}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: Spot Order Book & Term Structure (现货订单簿与远期曲线) */}
        {activeTab === 'SPOT_MARKET' && (
          <SpotMarketTerminal onOpenCalculation={handleOpenCalculation} />
        )}

        {/* TAB 3: Route Terminal & Multi-route Comparison (路线定价与对比) */}
        {activeTab === 'ROUTE_PRICING' && (
          <RouteTerminal onOpenCalculation={handleOpenCalculation} />
        )}

        {/* TAB 4: Capacity & Elasticity Lab (运力与瓶颈分析) */}
        {activeTab === 'CAPACITY_LAB' && <CapacityElasticityLab />}

        {/* TAB 5: Commodity Linkage (大宗商品联动) */}
        {activeTab === 'COMMODITY_LINK' && <CommodityRailLinkage />}

        {/* TAB 6: Scenario Lab (情景与冲击传播) */}
        {activeTab === 'SCENARIO_LAB' && <ScenarioLab />}

        {/* TAB 7: Risk VaR Terminal (货运 VaR 风险树) */}
        {activeTab === 'RISK_VAR' && <RiskVaRTerminal />}

        {/* TAB 8: Multimodal Comparison (公铁水多式联运) */}
        {activeTab === 'MULTIMODAL' && <MultimodalComparison />}

        {/* TAB 9: Corporate Freight Desk (企业物流量化 Desk) */}
        {activeTab === 'CORPORATE' && <CorporateFreightDesk />}
      </main>

      {/* Modal 1: Calculation Explorer Modal (数学分解) */}
      <CalculationExplorerModal
        quote={explorerQuote}
        isOpen={isExplorerOpen}
        onClose={() => setIsExplorerOpen(false)}
      />

      {/* Modal 2: AI Market Analyst (Gemini 3.8 Flash) */}
      <AIMarketAnalyst
        isOpen={isAiAnalystOpen}
        onClose={() => setIsAiAnalystOpen(false)}
        origin="上海闵行站"
        destination="成都城厢站"
        cargo="钢材"
        volume={5000}
        currentRate={438.5}
      />

      {/* Modal 3: Flagship Demos Quick Launcher */}
      <FlagshipDemosModal
        isOpen={isFlagshipOpen}
        onClose={() => setIsFlagshipOpen(false)}
        onSelectDemo={(tabId) => setActiveTab(tabId)}
      />

      {/* Footer System Status Strip */}
      <footer className="border-t border-slate-800/80 bg-[#070a0f] py-3 px-6 text-xs text-slate-500 font-mono flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <span className="text-slate-400 font-bold font-sans">
            犀牛量化 · 中国铁路货运现货 OS
          </span>
          <span>·</span>
          <span>系统时间: 2026-09-23 08:30 CST</span>
          <span>·</span>
          <span>所有算子数学可计算、数据来源明确标注 (LIVE / MODELLED)</span>
        </div>
        <div className="flex items-center gap-4 text-slate-400">
          <span>全网监测节点: 32 Hubs</span>
          <span>订单簿挂牌: 1,240,000 吨</span>
          <span>引擎: Gemini 3.8 Flash Server</span>
        </div>
      </footer>
    </div>
  );
}

export default App;
