import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json({ limit: '10mb' }));

// Initialize Gemini Client server-side
const getAiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY is not configured in environment variables.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
};

// AI Market Intelligence endpoint
app.post('/api/ai/analyze', async (req, res) => {
  try {
    const { origin, destination, cargo, volume, currentRate, lineStats, prompt } = req.body;
    const ai = getAiClient();

    const systemInstruction = `你是一位机构级中国铁路货运量化研究专家（犀牛量化首席铁路物流分析师）。
请基于提供的铁路运量、线路利用率、运价曲线、节点装卸能力与货运走廊状态，用严谨、专业的金融量化与物流经济学语言撰写分析报告。
请输出中文 Markdown 格式，包含：
1. 线路运力瓶颈与拥堵敏感性分析
2. 全包综合物流成本（Generalized Logistics Cost）构成拆解
3. 运价远期曲线（Forward Curve）走势预判与基差策略
4. 供应链风险管理与运力锁定期限建议。`;

    const userMessage = prompt || `请对以下中国铁路货运线路现货市场进行量化分析：
- 发站: ${origin || '上海闵行'}
- 到站: ${destination || '成都城厢'}
- 货物种类: ${cargo || '钢材'} (${volume || 5000} 吨)
- 当前预估运价: ¥${currentRate || 438.5}/吨
- 线路参数: ${JSON.stringify(lineStats || {})}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: userMessage,
      config: {
        systemInstruction,
        temperature: 0.3,
      },
    });

    res.json({ success: true, text: response.text });
  } catch (error: any) {
    console.error('Gemini API error in /api/ai/analyze:', error);
    res.status(500).json({
      success: false,
      error: error.message || '量化分析引擎服务异常',
    });
  }
});

// AI Scenario Simulation endpoint
app.post('/api/ai/scenario', async (req, res) => {
  try {
    const { scenarioTitle, scenarioData, prompt } = req.body;
    const ai = getAiClient();

    const systemInstruction = `你是犀牛量化（RHINOQUANT）铁路市场宏观与网络冲击传导引擎（Shock Propagation Engine）专家。
请根据用户施加的冲击条件（如：煤炭需求上涨20%、大秦线运力减少15%、港口封航、公路运价下调等），推演对全国铁路网络流、运价弹性、节点溢出效应及替代替换走廊的影响。
语言简洁利落，条理清晰，使用专业术语（如：运力弹性 dPrice/dCapacity、多商品流重定向、返程空载率、VaR风险值）。`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt || `分析情景: ${scenarioTitle}\n情景参数: ${JSON.stringify(scenarioData)}`,
      config: {
        systemInstruction,
        temperature: 0.2,
      },
    });

    res.json({ success: true, text: response.text });
  } catch (error: any) {
    console.error('Gemini API error in /api/ai/scenario:', error);
    res.status(500).json({
      success: false,
      error: error.message || '情景推演引擎异常',
    });
  }
});

const PORT = process.env.PORT || 3000;

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    // Dynamic import vite for development middleware
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`[RHINOQUANT SERVER] Running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
