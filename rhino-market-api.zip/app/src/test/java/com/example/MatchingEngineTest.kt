package com.example

import com.example.domain.engine.MatchingEngine
import com.example.domain.model.*
import com.example.domain.units.UnitsEngine
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class MatchingEngineTest {

    private lateinit var matchingEngine: MatchingEngine
    private lateinit var testInstrument: Instrument
    private lateinit var buyer: Participant
    private lateinit var seller: Participant

    @Before
    fun setUp() {
        matchingEngine = MatchingEngine()

        testInstrument = Instrument(
            instrumentId = "UKWHEAT-LINCS-SEP26",
            symbol = "UKWHEAT",
            name = "UK Feed Wheat (Lincolnshire)",
            marketId = "RHINO-SPOT",
            commodityId = "COMM-WHEAT",
            location = "Lincolnshire",
            currency = Currency.GBP,
            unit = CommodityUnit.TONNE,
            deliveryWindow = "Sep 2026",
            minimumQuantity = 10.0,
            maximumQuantity = 10000.0,
            tickSize = 0.25,
            status = MarketStatus.OPEN
        )

        buyer = Participant("P-BUYER", "Buyer Corp", ParticipantRole.TRADER, cashBalance = 1_000_000.0)
        seller = Participant("P-SELLER", "Seller Farm", ParticipantRole.TRADER, cashBalance = 1_000_000.0)
    }

    @Test
    fun `test exact order match invariant`() = runBlocking {
        // Buyer submits BUY 500 @ £213.00
        val buyOrder = Order(
            instrumentId = testInstrument.instrumentId,
            participantId = buyer.participantId,
            side = Side.BUY,
            price = 213.00,
            originalQuantity = 500.0
        )
        val (buyStatus, _) = matchingEngine.submitOrder(buyOrder, testInstrument, buyer)
        assertEquals(OrderStatus.ACCEPTED, buyStatus)
        assertEquals(500.0, buyOrder.remainingQuantity, 0.001)

        // Seller submits SELL 200 @ £213.00
        val sellOrder = Order(
            instrumentId = testInstrument.instrumentId,
            participantId = seller.participantId,
            side = Side.SELL,
            price = 213.00,
            originalQuantity = 200.0
        )
        val (sellStatus, _) = matchingEngine.submitOrder(sellOrder, testInstrument, seller)
        assertEquals(OrderStatus.FILLED, sellStatus)
        assertEquals(0.0, sellOrder.remainingQuantity, 0.001)
        assertEquals(200.0, sellOrder.filledQuantity, 0.001)

        // Remaining buy order quantity should be 300
        assertEquals(300.0, buyOrder.remainingQuantity, 0.001)
        assertEquals(200.0, buyOrder.filledQuantity, 0.001)

        // Check trade tape invariant
        val trades = matchingEngine.getTradesForInstrument(testInstrument.instrumentId)
        assertEquals(1, trades.size)
        val trade = trades.first()
        assertEquals(213.00, trade.price, 0.001)
        assertEquals(200.0, trade.quantity, 0.001)

        // Invariant 1: Total Executed Buy Quantity == Total Executed Sell Quantity
        assertEquals(trade.quantity, sellOrder.filledQuantity, 0.001)

        // Invariant 2: Original Quantity == Filled + Remaining + Cancelled
        assertEquals(buyOrder.originalQuantity, buyOrder.filledQuantity + buyOrder.remainingQuantity, 0.001)
    }

    @Test
    fun `test risk rejection when order exceeds credit limit`() = runBlocking {
        val poorBuyer = Participant("POOR-BUYER", "Small Trader", ParticipantRole.TRADER, cashBalance = 100.0, creditLimit = 500.0)
        val hugeOrder = Order(
            instrumentId = testInstrument.instrumentId,
            participantId = poorBuyer.participantId,
            side = Side.BUY,
            price = 200.00,
            originalQuantity = 1000.0 // Value = £200,000 > credit limit £500
        )

        val (status, err) = matchingEngine.submitOrder(hugeOrder, testInstrument, poorBuyer)
        assertEquals(OrderStatus.REJECTED, status)
        assertNotNull(err)
        assertTrue(err!!.contains("exceeds participant credit limit"))
    }

    @Test
    fun `test explicit unit conversion logic`() {
        // 1000 metric tonnes of wheat to bushels
        val bushels = UnitsEngine.convertQuantity(1000.0, CommodityUnit.TONNE, CommodityUnit.BUSHEL, "WHEAT")
        assertEquals(36743.7, bushels, 10.0)

        val tonnesBack = UnitsEngine.convertQuantity(bushels, CommodityUnit.BUSHEL, CommodityUnit.TONNE, "WHEAT")
        assertEquals(1000.0, tonnesBack, 0.001)
    }
}
