package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.SurveillanceAlert
import com.example.service.EventBus
import com.example.ui.theme.*

@Composable
fun SurveillanceAuditScreen(
    alerts: List<SurveillanceAlert>
) {
    Row(
        modifier = Modifier
            .fillMaxSize()
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // Left Column: Market Surveillance Monitor
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .background(DarkSurfaceCard)
                .border(1.dp, DarkBorderSlate)
                .padding(8.dp)
        ) {
            Text(
                text = "MARKET SURVEILLANCE & ALERTS",
                style = MaterialTheme.typography.labelSmall,
                color = RestrainedAskRed,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text("Monitors wash trades, self-trade prevention, price anomalies, and concentration risks.", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)

            Spacer(modifier = Modifier.height(8.dp))

            if (alerts.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No surveillance alerts triggered.", style = MaterialTheme.typography.bodyMedium, color = TextMuted)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(alerts) { alert ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(DarkGraphiteBackground, RoundedCornerShape(4.dp))
                                .border(1.dp, RestrainedAskRed, RoundedCornerShape(4.dp))
                                .padding(8.dp)
                        ) {
                            Text(alert.alertType, style = MaterialTheme.typography.bodyMedium, color = RestrainedAskRed, fontWeight = FontWeight.Bold)
                            Text(alert.description, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                            Text("Participant: ${alert.participantId} | Inst: ${alert.instrumentId}", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        }
                    }
                }
            }
        }

        // Right Column: Immutable Audit Ledger Overview
        Column(
            modifier = Modifier
                .weight(1.1f)
                .fillMaxHeight()
                .background(DarkSurfaceCard)
                .border(1.dp, DarkBorderSlate)
                .padding(8.dp)
        ) {
            Text(
                text = "IMMUTABLE AUDIT LEDGER (TAMPER-EVIDENT)",
                style = MaterialTheme.typography.labelSmall,
                color = TerminalCyan,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text("Every order, cancellation, match, and market state transition generates a strictly sequenced audit frame.", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)

            Spacer(modifier = Modifier.height(8.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(DarkGraphiteBackground)
                    .padding(8.dp)
            ) {
                Text("Current Event Sequence #: ${EventBus.getCurrentSequence()}", style = MaterialTheme.typography.bodyLarge, color = RestrainedBidGreen, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                Text("• Audit Integrity: PASS", style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                Text("• Sequence Gap Check: ZERO GAPS", style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                Text("• Persistence Sync: SQLite / PostgreSQL Ready", style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
            }
        }
    }
}
