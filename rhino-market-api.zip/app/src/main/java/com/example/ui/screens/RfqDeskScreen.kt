package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.*
import com.example.ui.theme.*

@Composable
fun RfqDeskScreen(
    rfqs: List<RfqRequest>,
    selectedInstrument: Instrument,
    onCreateRfq: (Double, String, String) -> Unit,
    onAwardRfq: (String, String) -> Unit
) {
    var requestedQty by remember { mutableStateOf("2000") }
    var destination by remember { mutableStateOf("Lincolnshire Mill Hub") }
    var deliveryWindow by remember { mutableStateOf("1-15 October 2026") }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // Left Column: RFQ Creation Form
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .background(DarkSurfaceCard)
                .border(1.dp, DarkBorderSlate)
                .padding(8.dp)
        ) {
            Text(
                text = "REQUEST FOR QUOTE (RFQ) DESK",
                style = MaterialTheme.typography.labelSmall,
                color = HighlightGold,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text("Active Instrument: ${selectedInstrument.name}", style = MaterialTheme.typography.bodyMedium, color = TerminalCyan)

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = requestedQty,
                onValueChange = { requestedQty = it },
                label = { Text("Requested Tonnage (${selectedInstrument.unit.symbol})", fontSize = 10.sp) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("rfq_quantity_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = HighlightGold,
                    unfocusedBorderColor = DarkBorderSlate
                )
            )

            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = destination,
                onValueChange = { destination = it },
                label = { Text("Delivery Destination", fontSize = 10.sp) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("rfq_destination_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = HighlightGold,
                    unfocusedBorderColor = DarkBorderSlate
                )
            )

            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = deliveryWindow,
                onValueChange = { deliveryWindow = it },
                label = { Text("Delivery Window", fontSize = 10.sp) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("rfq_delivery_window_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = HighlightGold,
                    unfocusedBorderColor = DarkBorderSlate
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = {
                    val q = requestedQty.toDoubleOrNull() ?: 1000.0
                    onCreateRfq(q, destination, deliveryWindow)
                },
                colors = ButtonDefaults.buttonColors(containerColor = HighlightGold),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("create_rfq_button")
            ) {
                Text("BROADCAST RFQ TO SUPPLIERS", color = DarkGraphiteBackground, fontWeight = FontWeight.Bold)
            }
        }

        // Right Column: Active RFQs & Supplier Quotes
        Column(
            modifier = Modifier
                .weight(1.3f)
                .fillMaxHeight()
                .background(DarkSurfaceCard)
                .border(1.dp, DarkBorderSlate)
                .padding(8.dp)
        ) {
            Text(
                text = "ACTIVE RFQ RESPONSES",
                style = MaterialTheme.typography.labelSmall,
                color = TerminalCyan,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(6.dp))

            if (rfqs.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No active RFQs. Create one using the form.", style = MaterialTheme.typography.bodyMedium, color = TextMuted)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(rfqs) { rfq ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(DarkGraphiteBackground, RoundedCornerShape(4.dp))
                                .border(1.dp, DarkBorderSlate, RoundedCornerShape(4.dp))
                                .padding(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "RFQ: ${rfq.rfqId.take(8)} | Qty: ${rfq.requestedQuantity.toInt()} t",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = rfq.status.name,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (rfq.status == RfqStatus.AWARDED) RestrainedBidGreen else HighlightGold
                                )
                            }

                            Text("Dest: ${rfq.destinationLocation} | Window: ${rfq.targetDeliveryWindow}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)

                            Spacer(modifier = Modifier.height(6.dp))

                            Text("SUPPLIER RESPONSES (${rfq.responses.size}):", style = MaterialTheme.typography.labelSmall, color = TextMuted)

                            rfq.responses.forEach { resp ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .background(DarkSurfaceCard, RoundedCornerShape(2.dp))
                                        .padding(6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(resp.sellerParticipantId, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                                        Text(
                                            "Base £${String.format("%.2f", resp.price)} + Freight £${String.format("%.2f", resp.freightCostPerUnit)}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = TextSecondary
                                        )
                                    }

                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            "£${String.format("%.2f", resp.totalLandedPrice)}/t Landed",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = RestrainedBidGreen,
                                            fontWeight = FontWeight.Bold
                                        )

                                        if (rfq.status != RfqStatus.AWARDED) {
                                            Button(
                                                onClick = { onAwardRfq(rfq.rfqId, resp.quoteId) },
                                                colors = ButtonDefaults.buttonColors(containerColor = RestrainedBidGreen),
                                                modifier = Modifier
                                                    .height(28.dp)
                                                    .testTag("award_rfq_button")
                                            ) {
                                                Text("AWARD", fontSize = 10.sp, color = TextPrimary)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
