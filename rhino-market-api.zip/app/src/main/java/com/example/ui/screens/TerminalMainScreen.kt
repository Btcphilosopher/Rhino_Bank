package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.TerminalHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.MarketViewModel

data class TerminalTabItem(
    val title: String,
    val icon: ImageVector,
    val testTag: String
)

@Composable
fun TerminalMainScreen(viewModel: MarketViewModel) {
    val instruments by viewModel.instruments.collectAsState()
    val selectedInstrument by viewModel.selectedInstrument.collectAsState()
    val participants by viewModel.participants.collectAsState()
    val selectedParticipant by viewModel.selectedParticipant.collectAsState()
    val bbo by viewModel.bbo.collectAsState()
    val asks by viewModel.asks.collectAsState()
    val bids by viewModel.bids.collectAsState()
    val trades by viewModel.trades.collectAsState()
    val positions by viewModel.positions.collectAsState()
    val rfqs by viewModel.rfqs.collectAsState()
    val settlements by viewModel.settlements.collectAsState()
    val alerts by viewModel.surveillanceAlerts.collectAsState()
    val terminalLogs by viewModel.terminalLogs.collectAsState()
    val benchmarkResult by viewModel.benchmarkResult.collectAsState()

    var activeTab by remember { mutableStateOf(0) }

    val tabs = listOf(
        TerminalTabItem("L2 BOOK", Icons.Default.ShowChart, "tab_l2_book"),
        TerminalTabItem("TERMINAL CLI", Icons.Default.Terminal, "tab_terminal_cli"),
        TerminalTabItem("RFQ DESK", Icons.Default.Handshake, "tab_rfq_desk"),
        TerminalTabItem("POS & RISK", Icons.Default.AccountBalanceWallet, "tab_pos_risk"),
        TerminalTabItem("SIM & REPLAY", Icons.Default.SlowMotionVideo, "tab_sim_replay"),
        TerminalTabItem("SETTLEMENT", Icons.Default.LocalShipping, "tab_settlement"),
        TerminalTabItem("AUDIT & RISK", Icons.Default.Shield, "tab_audit_risk"),
        TerminalTabItem("API & BENCHMARK", Icons.Default.Code, "tab_api_benchmark")
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkGraphiteBackground)
    ) {
        // Top Bloomberg Header
        TerminalHeader(
            instruments = instruments,
            selectedInstrument = selectedInstrument,
            onSelectInstrument = { viewModel.selectInstrument(it) },
            participants = participants,
            selectedParticipant = selectedParticipant,
            onSelectParticipant = { viewModel.selectParticipant(it) },
            bbo = bbo
        )

        // Navigation Tab Bar
        ScrollableTabRow(
            selectedTabIndex = activeTab,
            containerColor = DarkSurfaceCard,
            contentColor = TerminalCyan,
            edgePadding = 4.dp
        ) {
            tabs.forEachIndexed { index, tab ->
                Tab(
                    selected = activeTab == index,
                    onClick = { activeTab = index },
                    modifier = Modifier.testTag(tab.testTag),
                    text = {
                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Icon(imageVector = tab.icon, contentDescription = tab.title, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(tab.title, fontSize = 10.sp, fontWeight = if (activeTab == index) androidx.compose.ui.text.font.FontWeight.Bold else androidx.compose.ui.text.font.FontWeight.Normal)
                        }
                    }
                )
            }
        }

        // Screen Body
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            when (activeTab) {
                0 -> OrderBookScreen(
                    selectedInstrument = selectedInstrument,
                    bbo = bbo,
                    asks = asks,
                    bids = bids,
                    trades = trades,
                    onSubmitOrder = { side, price, qty, type ->
                        viewModel.submitOrder(side, price, qty, type)
                    }
                )
                1 -> CommandLineScreen(
                    terminalLogs = terminalLogs,
                    onRunCommand = { cmd -> viewModel.runTerminalCommand(cmd) }
                )
                2 -> RfqDeskScreen(
                    rfqs = rfqs,
                    selectedInstrument = selectedInstrument,
                    onCreateRfq = { qty, dest, win -> viewModel.createRfq(qty, dest, win) },
                    onAwardRfq = { rfqId, quoteId -> viewModel.awardRfq(rfqId, quoteId) }
                )
                3 -> PositionsRiskScreen(
                    selectedParticipant = selectedParticipant,
                    positions = positions
                )
                4 -> SimulatorReplayScreen(
                    isSimRunning = viewModel.simulator.isRunning,
                    currentScenario = viewModel.simulator.currentScenario,
                    onToggleSim = { scenario -> viewModel.toggleSimulator(scenario) },
                    recordedEventCount = viewModel.replayEngine.getRecordedCount(),
                    replayFrameIndex = viewModel.replayEngine.currentFrameIndex,
                    isReplayPlaying = viewModel.replayEngine.isPlaying,
                    onPlayReplay = { viewModel.replayEngine.play { /* handle event replayed */ } },
                    onPauseReplay = { viewModel.replayEngine.pause() },
                    onStepReplay = { viewModel.replayEngine.step { /* step event */ } },
                    onResetReplay = { viewModel.replayEngine.reset() }
                )
                5 -> SettlementScreen(settlements = settlements)
                6 -> SurveillanceAuditScreen(alerts = alerts)
                7 -> DeveloperApiScreen(
                    selectedInstrument = selectedInstrument,
                    benchmarkResult = benchmarkResult,
                    onRunBenchmark = { orderCount -> viewModel.runBenchmarkTest(orderCount) }
                )
            }
        }
    }
}
