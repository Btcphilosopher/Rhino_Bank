package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.BestBidOffer
import com.example.domain.model.Instrument
import com.example.domain.model.Participant
import com.example.ui.theme.*

@Composable
fun TerminalHeader(
    instruments: List<Instrument>,
    selectedInstrument: Instrument,
    onSelectInstrument: (Instrument) -> Unit,
    participants: List<Participant>,
    selectedParticipant: Participant,
    onSelectParticipant: (Participant) -> Unit,
    bbo: BestBidOffer?
) {
    var instrumentMenuExpanded by remember { mutableStateOf(false) }
    var participantMenuExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurfaceCard)
            .border(1.dp, DarkBorderSlate)
            .padding(8.dp)
    ) {
        // Top System Status Line
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(RestrainedBidGreen, shape = RoundedCornerShape(4.dp))
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "RHINO MARKET API.OS | ONLINE",
                    style = MaterialTheme.typography.labelSmall,
                    color = TerminalCyan,
                    fontWeight = FontWeight.Bold
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "ENGINE: DETERMINISTIC P/T",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
                Text(
                    text = "SIM: ACTIVE",
                    style = MaterialTheme.typography.labelSmall,
                    color = HighlightGold
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Selector Bar (Instrument & Participant)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Instrument Selector Dropdown
            Box {
                Row(
                    modifier = Modifier
                        .border(1.dp, TerminalCyan, RoundedCornerShape(4.dp))
                        .background(DarkGraphiteBackground)
                        .clickable { instrumentMenuExpanded = true }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag("instrument_selector"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = selectedInstrument.instrumentId,
                        style = MaterialTheme.typography.bodyLarge,
                        color = TerminalCyan,
                        fontWeight = FontWeight.Bold
                    )
                    Icon(
                        imageVector = Icons.Default.ArrowDropDown,
                        contentDescription = "Select Instrument",
                        tint = TerminalCyan
                    )
                }

                DropdownMenu(
                    expanded = instrumentMenuExpanded,
                    onDismissRequest = { instrumentMenuExpanded = false },
                    modifier = Modifier.background(DarkSurfaceCard)
                ) {
                    instruments.forEach { inst ->
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(inst.instrumentId, color = TextPrimary, fontWeight = FontWeight.Bold)
                                    Text(inst.name, color = TextSecondary, fontSize = 10.sp)
                                }
                            },
                            onClick = {
                                onSelectInstrument(inst)
                                instrumentMenuExpanded = false
                            }
                        )
                    }
                }
            }

            // Participant / Account Selector
            Box {
                Row(
                    modifier = Modifier
                        .border(1.dp, DarkBorderSlate, RoundedCornerShape(4.dp))
                        .background(DarkGraphiteBackground)
                        .clickable { participantMenuExpanded = true }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag("participant_selector"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ACCT: ${selectedParticipant.name}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary
                    )
                    Icon(
                        imageVector = Icons.Default.ArrowDropDown,
                        contentDescription = "Select Account",
                        tint = TextSecondary
                    )
                }

                DropdownMenu(
                    expanded = participantMenuExpanded,
                    onDismissRequest = { participantMenuExpanded = false },
                    modifier = Modifier.background(DarkSurfaceCard)
                ) {
                    participants.forEach { part ->
                        DropdownMenuItem(
                            text = {
                                Text("${part.name} (${part.role})", color = TextPrimary, fontSize = 12.sp)
                            },
                            onClick = {
                                onSelectParticipant(part)
                                participantMenuExpanded = false
                            }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Live BBO Ticker
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(DarkGraphiteBackground, RoundedCornerShape(4.dp))
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TickerItem(
                label = "BID",
                value = bbo?.bestBidPrice?.let { "£${String.format("%.2f", it)}" } ?: "--",
                color = RestrainedBidGreen
            )
            TickerItem(
                label = "ASK",
                value = bbo?.bestAskPrice?.let { "£${String.format("%.2f", it)}" } ?: "--",
                color = RestrainedAskRed
            )
            TickerItem(
                label = "MID",
                value = bbo?.midPrice?.let { "£${String.format("%.2f", it)}" } ?: "--",
                color = TextPrimary
            )
            TickerItem(
                label = "SPREAD",
                value = bbo?.spread?.let { "£${String.format("%.2f", it)}" } ?: "--",
                color = HighlightGold
            )
            TickerItem(
                label = "LAST",
                value = bbo?.lastPrice?.let { "£${String.format("%.2f", it)}" } ?: "--",
                color = TerminalCyan
            )
        }
    }
}

@Composable
private fun TickerItem(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = TextMuted)
        Text(text = value, style = MaterialTheme.typography.bodyMedium, color = color, fontWeight = FontWeight.Bold)
    }
}
