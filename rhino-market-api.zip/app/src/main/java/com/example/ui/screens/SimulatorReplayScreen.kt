package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.SimulationScenario
import com.example.ui.theme.*

@Composable
fun SimulatorReplayScreen(
    isSimRunning: Boolean,
    currentScenario: SimulationScenario,
    onToggleSim: (SimulationScenario) -> Unit,
    recordedEventCount: Int,
    replayFrameIndex: Int,
    isReplayPlaying: Boolean,
    onPlayReplay: () -> Unit,
    onPauseReplay: () -> Unit,
    onStepReplay: () -> Unit,
    onResetReplay: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(4.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // Market Simulator Panel
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(DarkSurfaceCard)
                .border(1.dp, DarkBorderSlate)
                .padding(8.dp)
        ) {
            Text(
                text = "DETERMINISTIC SYNTHETIC MARKET SIMULATOR",
                style = MaterialTheme.typography.labelSmall,
                color = HighlightGold,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text("Generates realistic synthetic order flows with explicit 'dataOrigin = SYNTHETIC' tag.", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)

            Spacer(modifier = Modifier.height(8.dp))

            Text("SELECT SIMULATION SCENARIO:", style = MaterialTheme.typography.labelSmall, color = TextMuted)

            Spacer(modifier = Modifier.height(4.dp))

            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Button(
                        onClick = { onToggleSim(SimulationScenario.NORMAL) },
                        colors = ButtonDefaults.buttonColors(containerColor = if (isSimRunning && currentScenario == SimulationScenario.NORMAL) RestrainedBidGreen else DarkGraphiteBackground),
                        modifier = Modifier.weight(1f)
                    ) { Text("NORMAL MARKET", fontSize = 10.sp) }

                    Button(
                        onClick = { onToggleSim(SimulationScenario.HIGH_DEMAND) },
                        colors = ButtonDefaults.buttonColors(containerColor = if (isSimRunning && currentScenario == SimulationScenario.HIGH_DEMAND) TerminalCyan else DarkGraphiteBackground),
                        modifier = Modifier.weight(1f)
                    ) { Text("HIGH DEMAND", fontSize = 10.sp) }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Button(
                        onClick = { onToggleSim(SimulationScenario.SUPPLY_SHOCK) },
                        colors = ButtonDefaults.buttonColors(containerColor = if (isSimRunning && currentScenario == SimulationScenario.SUPPLY_SHOCK) RestrainedAskRed else DarkGraphiteBackground),
                        modifier = Modifier.weight(1f)
                    ) { Text("SUPPLY SHOCK", fontSize = 10.sp) }

                    Button(
                        onClick = { onToggleSim(SimulationScenario.WEATHER_SHOCK) },
                        colors = ButtonDefaults.buttonColors(containerColor = if (isSimRunning && currentScenario == SimulationScenario.WEATHER_SHOCK) HighlightGold else DarkGraphiteBackground),
                        modifier = Modifier.weight(1f)
                    ) { Text("WEATHER SHOCK", fontSize = 10.sp) }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = if (isSimRunning) "STATUS: RUNNING ($currentScenario)" else "STATUS: STOPPED",
                style = MaterialTheme.typography.bodyLarge,
                color = if (isSimRunning) RestrainedBidGreen else TextMuted,
                fontWeight = FontWeight.Bold
            )
        }

        // Market Replay Engine Panel
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(DarkSurfaceCard)
                .border(1.dp, DarkBorderSlate)
                .padding(8.dp)
        ) {
            Text(
                text = "EVENT-BY-EVENT MARKET REPLAY ENGINE",
                style = MaterialTheme.typography.labelSmall,
                color = TerminalCyan,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text("Reconstructs historical order book, trade tape, and market statistics event by event.", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkGraphiteBackground, RoundedCornerShape(4.dp))
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Recorded Events: $recordedEventCount", style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
                Text("Replay Frame: $replayFrameIndex / $recordedEventCount", style = MaterialTheme.typography.bodyLarge, color = TerminalCyan, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Player Control Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { if (isReplayPlaying) onPauseReplay() else onPlayReplay() },
                    modifier = Modifier.background(TerminalCyan, RoundedCornerShape(4.dp))
                ) {
                    Icon(
                        imageVector = if (isReplayPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = "Play/Pause",
                        tint = DarkGraphiteBackground
                    )
                }

                IconButton(
                    onClick = onStepReplay,
                    modifier = Modifier.background(HighlightGold, RoundedCornerShape(4.dp))
                ) {
                    Icon(
                        imageVector = Icons.Default.SkipNext,
                        contentDescription = "Step Event",
                        tint = DarkGraphiteBackground
                    )
                }

                IconButton(
                    onClick = onResetReplay,
                    modifier = Modifier.background(DarkBorderSlate, RoundedCornerShape(4.dp))
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Reset Replay",
                        tint = TextPrimary
                    )
                }
            }
        }
    }
}
