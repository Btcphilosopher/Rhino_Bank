package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.SettlementInstruction
import com.example.domain.model.SettlementStatus
import com.example.ui.theme.*

@Composable
fun SettlementScreen(
    settlements: List<SettlementInstruction>
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(4.dp)
            .background(DarkSurfaceCard)
            .border(1.dp, DarkBorderSlate)
            .padding(8.dp)
    ) {
        Text(
            text = "PHYSICAL DELIVERY & FINANCIAL SETTLEMENT DESK",
            style = MaterialTheme.typography.labelSmall,
            color = TerminalCyan,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text("Tracks physical delivery, quality test certificates (moisture %, protein %), invoicing, and payment execution.", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)

        Spacer(modifier = Modifier.height(8.dp))

        if (settlements.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No active settlement instructions. Book a trade or award an RFQ to create settlement records.", style = MaterialTheme.typography.bodyMedium, color = TextMuted)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(settlements) { item ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(DarkGraphiteBackground, RoundedCornerShape(4.dp))
                            .border(1.dp, DarkBorderSlate, RoundedCornerShape(4.dp))
                            .padding(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(item.settlementId, style = MaterialTheme.typography.bodyLarge, color = TextPrimary, fontWeight = FontWeight.Bold)
                            Text(item.status.name, style = MaterialTheme.typography.labelSmall, color = RestrainedBidGreen)
                        }

                        Text("Trade: ${item.tradeId} | Buyer: ${item.buyerId} vs Seller: ${item.sellerId}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Text("Quantity: ${item.quantity.toInt()} t @ £${String.format("%.2f", item.contractPrice)}/t = Total £${String.format("%,.2f", item.totalAmount)}", style = MaterialTheme.typography.bodyMedium, color = TerminalCyan)
                        Text("Destination: ${item.deliveryLocation} | Window: ${item.deliveryWindow}", style = MaterialTheme.typography.labelSmall, color = TextMuted)

                        Spacer(modifier = Modifier.height(4.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(DarkSurfaceCard)
                                .padding(4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Moisture: ${item.moistureContent}%", style = MaterialTheme.typography.labelSmall, color = TextPrimary)
                            Text("Protein: ${item.proteinContent}%", style = MaterialTheme.typography.labelSmall, color = TextPrimary)
                            Text(if (item.qualityTestPassed) "PASSED CERT" else "QUALITY DISPUTE", style = MaterialTheme.typography.labelSmall, color = if (item.qualityTestPassed) RestrainedBidGreen else RestrainedAskRed)
                        }
                    }
                }
            }
        }
    }
}
