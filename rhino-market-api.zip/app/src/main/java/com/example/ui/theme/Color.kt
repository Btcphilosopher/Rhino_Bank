package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DarkGraphiteBackground = Color(0xFF0D1117)
val DarkSurfaceCard = Color(0xFF161B22)
val DarkBorderSlate = Color(0xFF30363D)

val RestrainedBidGreen = Color(0xFF2EA043)
val RestrainedBidGreenBg = Color(0xFF102A18)

val RestrainedAskRed = Color(0xFFF85149)
val RestrainedAskRedBg = Color(0xFF331518)

val HighlightGold = Color(0xFFD29922)
val TerminalCyan = Color(0xFF58A6FF)

val TextPrimary = Color(0xFFF0F6FC)
val TextSecondary = Color(0xFF8B949E)
val TextMuted = Color(0xFF484F58)
