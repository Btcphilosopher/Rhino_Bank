package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.Instrument
import com.example.engine.BenchmarkResult
import com.example.service.OpenApiExporter
import com.example.ui.theme.*

@Composable
fun DeveloperApiScreen(
    selectedInstrument: Instrument,
    benchmarkResult: BenchmarkResult?,
    onRunBenchmark: (Int) -> Unit
) {
    var selectedTab by remember { mutableStateOf(0) } // 0: Benchmark, 1: OpenAPI Spec, 2: Python Client, 3: R Client

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(4.dp)
            .background(DarkSurfaceCard)
            .border(1.dp, DarkBorderSlate)
            .padding(8.dp)
    ) {
        Text(
            text = "RHINO MARKET API DEVELOPER & RESEARCH LAB",
            style = MaterialTheme.typography.labelSmall,
            color = TerminalCyan,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(6.dp))

        // Navigation Tab Row
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = DarkGraphiteBackground,
            contentColor = TerminalCyan
        ) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }) {
                Text("BENCHMARK LAB", fontSize = 10.sp, modifier = Modifier.padding(8.dp))
            }
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }) {
                Text("OPENAPI 3.0", fontSize = 10.sp, modifier = Modifier.padding(8.dp))
            }
            Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }) {
                Text("PYTHON CLIENT", fontSize = 10.sp, modifier = Modifier.padding(8.dp))
            }
            Tab(selected = selectedTab == 3, onClick = { selectedTab = 3 }) {
                Text("R RESEARCH CLIENT", fontSize = 10.sp, modifier = Modifier.padding(8.dp))
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        when (selectedTab) {
            0 -> {
                // High Speed Benchmark Lab
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(DarkGraphiteBackground)
                        .padding(10.dp)
                ) {
                    Text("EXECUTION ENGINE LATENCY & THROUGHPUT BENCHMARK", style = MaterialTheme.typography.bodyLarge, color = HighlightGold, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Tests deterministic price/time priority order matching under heavy concurrent order flow.", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { onRunBenchmark(2000) },
                            colors = ButtonDefaults.buttonColors(containerColor = TerminalCyan),
                            modifier = Modifier.testTag("run_benchmark_2000")
                        ) { Text("TEST 2,000 ORDERS", fontSize = 10.sp, color = DarkGraphiteBackground) }

                        Button(
                            onClick = { onRunBenchmark(5000) },
                            colors = ButtonDefaults.buttonColors(containerColor = HighlightGold),
                            modifier = Modifier.testTag("run_benchmark_5000")
                        ) { Text("TEST 5,000 ORDERS", fontSize = 10.sp, color = DarkGraphiteBackground) }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (benchmarkResult != null) {
                        val res = benchmarkResult
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(DarkSurfaceCard, RoundedCornerShape(4.dp))
                                .border(1.dp, TerminalCyan, RoundedCornerShape(4.dp))
                                .padding(10.dp)
                        ) {
                            Text("BENCHMARK METRICS:", style = MaterialTheme.typography.labelSmall, color = TerminalCyan)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("• Orders Evaluated : ${res.totalOrders}", style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                            Text("• Matches Executed : ${res.totalMatches}", style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                            Text("• Total Run Time   : ${res.totalTimeMs} ms", style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                            Text("• Throughput       : ${String.format("%,.0f", res.ordersPerSecond)} orders/sec (${String.format("%,.0f", res.matchesPerSecond)} matches/sec)", style = MaterialTheme.typography.bodyLarge, color = RestrainedBidGreen, fontWeight = FontWeight.Bold)
                            Text("• Median Latency   : ${String.format("%.2f", res.medianLatencyUs)} μs", style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                            Text("• P95 Latency      : ${String.format("%.2f", res.p95LatencyUs)} μs", style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                            Text("• P99 Latency      : ${String.format("%.2f", res.p99LatencyUs)} μs", style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                        }
                    } else {
                        Text("Click a test button above to run latency benchmarks.", style = MaterialTheme.typography.bodyMedium, color = TextMuted)
                    }
                }
            }

            1 -> {
                CodeViewer(title = "OpenAPI 3.0 Specification (JSON)", code = OpenApiExporter.getOpenApiJson())
            }

            2 -> {
                CodeViewer(title = "Python Client Snippet", code = OpenApiExporter.getPythonClientSnippet(selectedInstrument.instrumentId))
            }

            3 -> {
                CodeViewer(title = "R Research Client Snippet", code = OpenApiExporter.getRClientSnippet(selectedInstrument.instrumentId))
            }
        }
    }
}

@Composable
private fun CodeViewer(title: String, code: String) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkGraphiteBackground)
            .padding(8.dp)
    ) {
        Text(title, style = MaterialTheme.typography.labelSmall, color = TerminalCyan, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(4.dp))
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .border(1.dp, DarkBorderSlate)
                .padding(6.dp)
        ) {
            item {
                Text(
                    text = code,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextPrimary
                )
            }
        }
    }
}
