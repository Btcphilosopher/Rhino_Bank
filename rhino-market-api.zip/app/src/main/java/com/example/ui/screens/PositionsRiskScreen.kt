package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.*
import com.example.domain.units.BasisEngine
import com.example.domain.units.UnitsEngine
import com.example.ui.theme.*

@Composable
fun PositionsRiskScreen(
    selectedParticipant: Participant,
    positions: List<Position>
) {
    var convertQtyInput by remember { mutableStateOf("1000") }
    var selectedCrop by remember { mutableStateOf("WHEAT") }
    var localPriceInput by remember { mutableStateOf("213.00") }
    var nationalRefInput by remember { mutableStateOf("208.00") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(4.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // Account Overview Card
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(DarkSurfaceCard)
                .border(1.dp, DarkBorderSlate)
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "PARTICIPANT: ${selectedParticipant.name}",
                    style = MaterialTheme.typography.titleLarge,
                    color = TerminalCyan
                )
                Text(
                    text = "Role: ${selectedParticipant.role} | Currency: ${selectedParticipant.currency.name}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "CASH: £${String.format("%,.2f", selectedParticipant.cashBalance)}",
                    style = MaterialTheme.typography.bodyLarge,
                    color = RestrainedBidGreen,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "CREDIT LIMIT: £${String.format("%,.2f", selectedParticipant.creditLimit)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextMuted
                )
            }
        }

        // Open Positions & Mark-To-Market Table
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1.2f)
                .background(DarkSurfaceCard)
                .border(1.dp, DarkBorderSlate)
                .padding(8.dp)
        ) {
            Text(
                text = "OPEN POSITIONS & MARK-TO-MARKET (MTM) P&L",
                style = MaterialTheme.typography.labelSmall,
                color = HighlightGold,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(6.dp))

            if (positions.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No open positions for ${selectedParticipant.name}", style = MaterialTheme.typography.bodyMedium, color = TextMuted)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(positions) { pos ->
                        val pnlColor = if (pos.unrealisedPnL >= 0) RestrainedBidGreen else RestrainedAskRed
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(DarkGraphiteBackground, RoundedCornerShape(4.dp))
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(pos.instrumentId, style = MaterialTheme.typography.bodyLarge, color = TextPrimary, fontWeight = FontWeight.Bold)
                                Text(
                                    "Net: ${pos.netQuantity.toInt()} t | Avg: £${String.format("%.2f", pos.averagePrice)} | Mark: £${String.format("%.2f", pos.markPrice)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "MTM P&L: £${String.format("%+.2f", pos.unrealisedPnL)}",
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = pnlColor,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Realised: £${String.format("%+.2f", pos.realisedPnL)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextMuted
                                )
                            }
                        }
                    }
                }
            }
        }

        // Units Conversion & Basis Calculator Desk
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(DarkSurfaceCard)
                .border(1.dp, DarkBorderSlate)
                .padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Unit Converter Box
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .background(DarkGraphiteBackground)
                    .border(1.dp, DarkBorderSlate)
                    .padding(6.dp)
            ) {
                Text("EXPLICIT UNITS CONVERSION ENGINE", style = MaterialTheme.typography.labelSmall, color = TerminalCyan, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))

                OutlinedTextField(
                    value = convertQtyInput,
                    onValueChange = { convertQtyInput = it },
                    label = { Text("Quantity in Tonnes", fontSize = 10.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(4.dp))

                val tonnes = convertQtyInput.toDoubleOrNull() ?: 1000.0
                val bushels = UnitsEngine.convertQuantity(tonnes, CommodityUnit.TONNE, CommodityUnit.BUSHEL, selectedCrop)
                val kg = UnitsEngine.convertQuantity(tonnes, CommodityUnit.TONNE, CommodityUnit.KG, selectedCrop)

                Text("• ${tonnes.toInt()} Tonnes = ${String.format("%,.1f", bushels)} Bushels ($selectedCrop)", style = MaterialTheme.typography.labelSmall, color = TextPrimary)
                Text("• ${tonnes.toInt()} Tonnes = ${String.format("%,.0f", kg)} Kg", style = MaterialTheme.typography.labelSmall, color = TextPrimary)
            }

            // Location Basis Calculator Box
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .background(DarkGraphiteBackground)
                    .border(1.dp, DarkBorderSlate)
                    .padding(6.dp)
            ) {
                Text("LOCAL BASIS ENGINE (PRICE - REF)", style = MaterialTheme.typography.labelSmall, color = HighlightGold, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedTextField(
                        value = localPriceInput,
                        onValueChange = { localPriceInput = it },
                        label = { Text("Local Price", fontSize = 9.sp) },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = nationalRefInput,
                        onValueChange = { nationalRefInput = it },
                        label = { Text("National Ref", fontSize = 9.sp) },
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                val locP = localPriceInput.toDoubleOrNull() ?: 213.0
                val refP = nationalRefInput.toDoubleOrNull() ?: 208.0
                val basisCalc = BasisEngine.calculateBasis("Lincolnshire", locP, refP)

                Text(
                    text = "Lincolnshire Basis: ${String.format("%+.2f", basisCalc.basisAmount)} ${basisCalc.currency.symbol}/t",
                    style = MaterialTheme.typography.bodyLarge,
                    color = if (basisCalc.basisAmount >= 0) RestrainedBidGreen else RestrainedAskRed,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
