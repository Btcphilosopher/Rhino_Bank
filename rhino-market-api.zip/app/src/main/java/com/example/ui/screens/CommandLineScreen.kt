package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun CommandLineScreen(
    terminalLogs: List<Pair<String, String>>,
    onRunCommand: (String) -> Unit
) {
    var commandInput by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(terminalLogs.size) {
        if (terminalLogs.isNotEmpty()) {
            listState.animateScrollToItem(terminalLogs.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(4.dp)
            .background(DarkSurfaceCard)
            .border(1.dp, DarkBorderSlate)
            .padding(6.dp)
    ) {
        // Title Bar
        Text(
            text = "RHINO TERMINAL COMMAND LINE (CLI)",
            style = MaterialTheme.typography.labelSmall,
            color = TerminalCyan,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(4.dp))

        // Quick Command Shortcut Chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            val quickCmds = listOf("BOOK", "BUY 500 @ 213.00", "SELL 200 @ 213.00", "QUOTE", "POS", "RISK", "SIM SUPPLY_SHOCK", "BENCHMARK")
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                userScrollEnabled = false
            ) {
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        quickCmds.take(4).forEach { cmd ->
                            SuggestionChip(
                                onClick = { onRunCommand(cmd) },
                                label = { Text(cmd, fontSize = 9.sp, color = TerminalCyan) },
                                modifier = Modifier.height(28.dp)
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        quickCmds.drop(4).forEach { cmd ->
                            SuggestionChip(
                                onClick = { onRunCommand(cmd) },
                                label = { Text(cmd, fontSize = 9.sp, color = HighlightGold) },
                                modifier = Modifier.height(28.dp)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Monospace Output Console Window
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(DarkGraphiteBackground)
                .border(1.dp, DarkBorderSlate)
                .padding(8.dp)
        ) {
            LazyColumn(
                state = listState,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(terminalLogs) { (prompt, response) ->
                    Column {
                        Text(
                            text = prompt,
                            style = MaterialTheme.typography.bodyMedium,
                            color = TerminalCyan,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = response,
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextPrimary
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Command Input Field
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = commandInput,
                onValueChange = { commandInput = it },
                placeholder = { Text("Enter command e.g. BUY 500 @ 213.00", fontSize = 11.sp, color = TextMuted) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = {
                    if (commandInput.isNotBlank()) {
                        onRunCommand(commandInput)
                        commandInput = ""
                    }
                }),
                modifier = Modifier
                    .weight(1f)
                    .testTag("terminal_command_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = TerminalCyan,
                    unfocusedBorderColor = DarkBorderSlate
                )
            )

            Spacer(modifier = Modifier.width(6.dp))

            IconButton(
                onClick = {
                    if (commandInput.isNotBlank()) {
                        onRunCommand(commandInput)
                        commandInput = ""
                    }
                },
                modifier = Modifier
                    .background(TerminalCyan, shape = RoundedCornerShape(4.dp))
                    .testTag("terminal_send_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = "Execute Command",
                    tint = DarkGraphiteBackground
                )
            }
        }
    }
}
