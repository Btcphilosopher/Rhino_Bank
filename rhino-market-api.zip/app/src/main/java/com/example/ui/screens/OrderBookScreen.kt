package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.*
import com.example.ui.theme.*

@Composable
fun OrderBookScreen(
    selectedInstrument: Instrument,
    bbo: BestBidOffer?,
    asks: List<PriceLevel>,
    bids: List<PriceLevel>,
    trades: List<Trade>,
    onSubmitOrder: (Side, Double, Double, OrderType) -> Unit
) {
    var orderSide by remember { mutableStateOf(Side.BUY) }
    var orderType by remember { mutableStateOf(OrderType.LIMIT) }
    var priceInput by remember(selectedInstrument) { mutableStateOf("213.00") }
    var qtyInput by remember(selectedInstrument) { mutableStateOf("500") }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // Left Column: Level 2 Order Book Table
        Column(
            modifier = Modifier
                .weight(1.2f)
                .fillMaxHeight()
                .background(DarkSurfaceCard)
                .border(1.dp, DarkBorderSlate)
                .padding(6.dp)
        ) {
            Text(
                text = "LEVEL 2 ORDER BOOK (${selectedInstrument.symbol})",
                style = MaterialTheme.typography.labelSmall,
                color = TerminalCyan,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Table Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkGraphiteBackground)
                    .padding(vertical = 4.dp, horizontal = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("PRICE (${selectedInstrument.currency.symbol})", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                Text("QTY (${selectedInstrument.unit.symbol})", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                Text("COUNT", style = MaterialTheme.typography.labelSmall, color = TextMuted)
            }

            Spacer(modifier = Modifier.height(2.dp))

            // Asks (Sellers - Red)
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.Bottom
            ) {
                items(asks.take(6).reversed()) { ask ->
                    OrderBookRow(price = ask.price, qty = ask.aggregateQuantity, count = ask.orderCount, isBid = false)
                }
            }

            // BBO Spread Divider
            val spreadText = bbo?.spread?.let { "SPREAD: £${String.format("%.2f", it)}" } ?: "NO SPREAD"
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkGraphiteBackground)
                    .padding(vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = spreadText,
                    style = MaterialTheme.typography.labelSmall,
                    color = HighlightGold,
                    fontWeight = FontWeight.Bold
                )
            }

            // Bids (Buyers - Green)
            LazyColumn(
                modifier = Modifier.weight(1f)
            ) {
                items(bids.take(6)) { bid ->
                    OrderBookRow(price = bid.price, qty = bid.aggregateQuantity, count = bid.orderCount, isBid = true)
                }
            }
        }

        // Right Column: Order Ticket & Live Trade Tape
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight(),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // Order Execution Ticket
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSurfaceCard)
                    .border(1.dp, DarkBorderSlate)
                    .padding(8.dp)
            ) {
                Text(
                    text = "ORDER ENTRY TICKET",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Buy / Sell Side Switcher
                Row(modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = { orderSide = Side.BUY },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (orderSide == Side.BUY) RestrainedBidGreen else DarkGraphiteBackground
                        ),
                        shape = RoundedCornerShape(topStart = 4.dp, bottomStart = 4.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("buy_side_button")
                    ) {
                        Text("BUY", color = TextPrimary, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { orderSide = Side.SELL },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (orderSide == Side.SELL) RestrainedAskRed else DarkGraphiteBackground
                        ),
                        shape = RoundedCornerShape(topEnd = 4.dp, bottomEnd = 4.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("sell_side_button")
                    ) {
                        Text("SELL", color = TextPrimary, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Price Input
                OutlinedTextField(
                    value = priceInput,
                    onValueChange = { priceInput = it },
                    label = { Text("Price (${selectedInstrument.currency.symbol}/t)", fontSize = 10.sp) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("price_input"),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = TerminalCyan,
                        unfocusedBorderColor = DarkBorderSlate
                    )
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Quantity Input
                OutlinedTextField(
                    value = qtyInput,
                    onValueChange = { qtyInput = it },
                    label = { Text("Quantity (${selectedInstrument.unit.symbol})", fontSize = 10.sp) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("quantity_input"),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = TerminalCyan,
                        unfocusedBorderColor = DarkBorderSlate
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Submit Button
                Button(
                    onClick = {
                        val p = priceInput.toDoubleOrNull() ?: 213.0
                        val q = qtyInput.toDoubleOrNull() ?: 100.0
                        onSubmitOrder(orderSide, p, q, orderType)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (orderSide == Side.BUY) RestrainedBidGreen else RestrainedAskRed
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("submit_order_button")
                ) {
                    Text(
                        text = "SUBMIT ${orderSide.name} ORDER",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Live Trade Execution Tape
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(DarkSurfaceCard)
                    .border(1.dp, DarkBorderSlate)
                    .padding(6.dp)
            ) {
                Text(
                    text = "LIVE EXECUTION TAPE",
                    style = MaterialTheme.typography.labelSmall,
                    color = HighlightGold,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(4.dp))

                if (trades.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("No trades executed yet", style = MaterialTheme.typography.bodyMedium, color = TextMuted)
                    }
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        items(trades.take(15)) { trade ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(DarkGraphiteBackground, RoundedCornerShape(2.dp))
                                    .padding(horizontal = 6.dp, vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = trade.executionId,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondary
                                    )
                                    Text(
                                        text = "${trade.buyerParticipantId.take(8)} → ${trade.sellerParticipantId.take(8)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextMuted
                                    )
                                }
                                Text(
                                    text = "£${String.format("%.2f", trade.price)} x ${trade.quantity.toInt()}t",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = RestrainedBidGreen,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun OrderBookRow(price: Double, qty: Double, count: Int, isBid: Boolean) {
    val bgColor = if (isBid) RestrainedBidGreenBg else RestrainedAskRedBg
    val textColor = if (isBid) RestrainedBidGreen else RestrainedAskRed

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(bgColor)
            .padding(horizontal = 6.dp, vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "£${String.format("%.2f", price)}",
            style = MaterialTheme.typography.bodyMedium,
            color = textColor,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "${qty.toInt()}t",
            style = MaterialTheme.typography.bodyMedium,
            color = TextPrimary
        )
        Text(
            text = "$count",
            style = MaterialTheme.typography.labelSmall,
            color = TextMuted
        )
    }
}
