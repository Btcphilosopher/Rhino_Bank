package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.*
import com.example.domain.engine.MatchingEngine
import com.example.domain.model.*
import com.example.domain.units.BasisEngine
import com.example.domain.units.LandedPriceCalculator
import com.example.domain.units.UnitsEngine
import com.example.engine.*
import com.example.service.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MarketViewModel(application: Application) : AndroidViewModel(application) {

    private val database = RhinoDatabase.getDatabase(application)
    val matchingEngine = MatchingEngine()
    val rfqEngine = RfqEngine(matchingEngine)
    val replayEngine = MarketReplayEngine(viewModelScope)
    val simulator = MarketSimulator(matchingEngine, viewModelScope)
    val commandParser = RhinoTerminalCommandParser(matchingEngine, rfqEngine, simulator)

    // State Flows
    private val _instruments = MutableStateFlow(ReferenceDataService.instruments)
    val instruments: StateFlow<List<Instrument>> = _instruments.asStateFlow()

    private val _selectedInstrument = MutableStateFlow(ReferenceDataService.instruments.first())
    val selectedInstrument: StateFlow<Instrument> = _selectedInstrument.asStateFlow()

    private val _participants = MutableStateFlow(ReferenceDataService.participants)
    val participants: StateFlow<List<Participant>> = _participants.asStateFlow()

    private val _selectedParticipant = MutableStateFlow(ReferenceDataService.participants.first())
    val selectedParticipant: StateFlow<Participant> = _selectedParticipant.asStateFlow()

    private val _bbo = MutableStateFlow<BestBidOffer?>(null)
    val bbo: StateFlow<BestBidOffer?> = _bbo.asStateFlow()

    private val _asks = MutableStateFlow<List<PriceLevel>>(emptyList())
    val asks: StateFlow<List<PriceLevel>> = _asks.asStateFlow()

    private val _bids = MutableStateFlow<List<PriceLevel>>(emptyList())
    val bids: StateFlow<List<PriceLevel>> = _bids.asStateFlow()

    private val _trades = MutableStateFlow<List<Trade>>(emptyList())
    val trades: StateFlow<List<Trade>> = _trades.asStateFlow()

    private val _positions = MutableStateFlow<List<Position>>(emptyList())
    val positions: StateFlow<List<Position>> = _positions.asStateFlow()

    private val _rfqs = MutableStateFlow<List<RfqRequest>>(emptyList())
    val rfqs: StateFlow<List<RfqRequest>> = _rfqs.asStateFlow()

    private val _settlements = MutableStateFlow<List<SettlementInstruction>>(emptyList())
    val settlements: StateFlow<List<SettlementInstruction>> = _settlements.asStateFlow()

    private val _surveillanceAlerts = MutableStateFlow<List<SurveillanceAlert>>(emptyList())
    val surveillanceAlerts: StateFlow<List<SurveillanceAlert>> = _surveillanceAlerts.asStateFlow()

    private val _terminalLogs = MutableStateFlow<List<Pair<String, String>>>(
        listOf(
            "SYSTEM" to "RHINO MARKET API.OS ONLINE\nType HELP for available commands."
        )
    )
    val terminalLogs: StateFlow<List<Pair<String, String>>> = _terminalLogs.asStateFlow()

    private val _benchmarkResult = MutableStateFlow<BenchmarkResult?>(null)
    val benchmarkResult: StateFlow<BenchmarkResult?> = _benchmarkResult.asStateFlow()

    init {
        // Collect Market Events from EventBus
        viewModelScope.launch {
            EventBus.events.collect { event ->
                replayEngine.recordEvent(event)

                when (event) {
                    is MarketEvent.OrderBookUpdated -> {
                        if (event.bbo.instrumentId == _selectedInstrument.value.instrumentId) {
                            _bbo.value = event.bbo
                            _asks.value = event.asks
                            _bids.value = event.bids
                        }
                    }
                    is MarketEvent.OrderMatched -> {
                        refreshTradesAndPositions()
                        persistTrade(event.trade)
                    }
                    is MarketEvent.RfqUpdated -> {
                        _rfqs.value = rfqEngine.getAllRfqs()
                    }
                    is MarketEvent.SurveillanceAlertTriggered -> {
                        _surveillanceAlerts.value = matchingEngine.surveillanceEngine.getRecentAlerts()
                    }
                    else -> {}
                }
            }
        }

        // Seed initial market quotes & positions
        seedInitialMarketData()
    }

    fun selectInstrument(instrument: Instrument) {
        _selectedInstrument.value = instrument
        val book = matchingEngine.getOrderBook(instrument.instrumentId)
        val lastPrice = matchingEngine.getTradesForInstrument(instrument.instrumentId).firstOrNull()?.price
        _bbo.value = book.getBbo(lastPrice, null, null)
        _asks.value = book.getAsksSnapshot()
        _bids.value = book.getBidsSnapshot()
        _trades.value = matchingEngine.getTradesForInstrument(instrument.instrumentId)
    }

    fun selectParticipant(participant: Participant) {
        _selectedParticipant.value = participant
        refreshTradesAndPositions()
    }

    fun submitOrder(
        side: Side,
        price: Double,
        quantity: Double,
        orderType: OrderType = OrderType.LIMIT
    ) {
        viewModelScope.launch {
            val order = Order(
                instrumentId = _selectedInstrument.value.instrumentId,
                participantId = _selectedParticipant.value.participantId,
                side = side,
                orderType = orderType,
                price = price,
                originalQuantity = quantity
            )

            val (status, err) = matchingEngine.submitOrder(order, _selectedInstrument.value, _selectedParticipant.value)
            if (err != null) {
                appendTerminalLog("ORDER ERROR", "Rejection: $err")
            } else {
                appendTerminalLog("ORDER SUBMITTED", "${side.name} ${quantity.toInt()}t @ £${String.format("%.2f", price)} ($status)")
            }
            refreshTradesAndPositions()
        }
    }

    fun runTerminalCommand(input: String) {
        viewModelScope.launch {
            val output = commandParser.executeCommand(input, _selectedInstrument.value, _selectedParticipant.value)
            appendTerminalLog("CMD > $input", output)
            refreshTradesAndPositions()
        }
    }

    fun createRfq(requestedQty: Double, destination: String, deliveryWindow: String) {
        viewModelScope.launch {
            val rfq = rfqEngine.createRfq(
                buyerParticipantId = _selectedParticipant.value.participantId,
                instrumentId = _selectedInstrument.value.instrumentId,
                requestedQuantity = requestedQty,
                destinationLocation = destination,
                deliveryWindow = deliveryWindow
            )
            // Auto-generate 2 supplier responses for demonstration
            val baseP = _bbo.value?.bestAskPrice ?: 213.0
            rfqEngine.submitSupplierQuote(rfq.rfqId, "PART-MM01", baseP - 0.50, 4.20, deliveryWindow)
            rfqEngine.submitSupplierQuote(rfq.rfqId, "PART-FARM01", baseP, 3.80, deliveryWindow)

            _rfqs.value = rfqEngine.getAllRfqs()
            appendTerminalLog("RFQ DESK", "Created RFQ ${rfq.rfqId.take(8)} for ${requestedQty.toInt()}t to $destination")
        }
    }

    fun awardRfq(rfqId: String, selectedQuoteId: String) {
        viewModelScope.launch {
            val trade = rfqEngine.awardRfq(rfqId, selectedQuoteId, _selectedInstrument.value)
            if (trade != null) {
                appendTerminalLog("RFQ AWARDED", "Bilateral Trade Booked: ${trade.executionId} @ £${String.format("%.2f", trade.price)}/t")
                refreshTradesAndPositions()
            }
        }
    }

    fun toggleSimulator(scenario: SimulationScenario = SimulationScenario.NORMAL) {
        if (simulator.isRunning) {
            simulator.stopSimulation()
            appendTerminalLog("SIMULATOR", "Stopped synthetic generator.")
        } else {
            simulator.currentScenario = scenario
            simulator.startSimulation(_selectedInstrument.value, ReferenceDataService.participants)
            appendTerminalLog("SIMULATOR", "Started synthetic generator under scenario: ${scenario.name}")
        }
    }

    fun runBenchmarkTest(orderCount: Int = 3000) {
        viewModelScope.launch {
            appendTerminalLog("BENCHMARK", "Executing high-speed order matching benchmark ($orderCount orders)...")
            val res = BenchmarkLab.runBenchmark(orderCount)
            _benchmarkResult.value = res
            appendTerminalLog("BENCHMARK DONE", "Processed ${res.totalOrders} orders in ${res.totalTimeMs}ms (${String.format("%,.0f", res.ordersPerSecond)} ops/sec)")
        }
    }

    private fun refreshTradesAndPositions() {
        _trades.value = matchingEngine.getTradesForInstrument(_selectedInstrument.value.instrumentId)
        _positions.value = matchingEngine.positionEngine.getAllPositionsForParticipant(_selectedParticipant.value.participantId)
    }

    private fun appendTerminalLog(prompt: String, response: String) {
        _terminalLogs.value = (_terminalLogs.value + (prompt to response)).takeLast(80)
    }

    private fun persistTrade(trade: Trade) {
        viewModelScope.launch(Dispatchers.IO) {
            val entity = TradeEntity(
                tradeId = trade.tradeId,
                executionId = trade.executionId,
                instrumentId = trade.instrumentId,
                buyOrderId = trade.buyOrderId,
                sellOrderId = trade.sellOrderId,
                buyerParticipantId = trade.buyerParticipantId,
                sellerParticipantId = trade.sellerParticipantId,
                price = trade.price,
                quantity = trade.quantity,
                totalValue = trade.totalValue,
                currency = trade.currency.name,
                unit = trade.unit.name,
                timestamp = trade.timestamp,
                venue = trade.venue,
                dataOrigin = trade.dataOrigin
            )
            database.tradeDao().insertTrade(entity)
        }
    }

    private fun seedInitialMarketData() {
        viewModelScope.launch {
            val inst = _selectedInstrument.value
            val mm = ReferenceDataService.participants[0] // Rhino Liquidity Maker
            val farmer = ReferenceDataService.participants[1] // Farmer

            // Seed resting bids & asks
            val bidsToSeed = listOf(212.50 to 200.0, 212.25 to 350.0, 212.00 to 500.0, 211.75 to 800.0)
            val asksToSeed = listOf(213.00 to 150.0, 213.25 to 300.0, 213.50 to 450.0, 213.75 to 600.0)

            bidsToSeed.forEach { (price, qty) ->
                val order = Order(instrumentId = inst.instrumentId, participantId = farmer.participantId, side = Side.BUY, price = price, originalQuantity = qty)
                matchingEngine.submitOrder(order, inst, farmer, dataOrigin = "SEED")
            }

            asksToSeed.forEach { (price, qty) ->
                val order = Order(instrumentId = inst.instrumentId, participantId = mm.participantId, side = Side.SELL, price = price, originalQuantity = qty)
                matchingEngine.submitOrder(order, inst, mm, dataOrigin = "SEED")
            }

            refreshTradesAndPositions()
        }
    }
}
