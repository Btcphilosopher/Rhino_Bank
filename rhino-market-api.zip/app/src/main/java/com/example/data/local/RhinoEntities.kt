package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "trades")
data class TradeEntity(
    @PrimaryKey val tradeId: String,
    val executionId: String,
    val instrumentId: String,
    val buyOrderId: String,
    val sellOrderId: String,
    val buyerParticipantId: String,
    val sellerParticipantId: String,
    val price: Double,
    val quantity: Double,
    val totalValue: Double,
    val currency: String,
    val unit: String,
    val timestamp: Long,
    val venue: String,
    val dataOrigin: String
)

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey val orderId: String,
    val instrumentId: String,
    val participantId: String,
    val side: String,
    val orderType: String,
    val price: Double,
    val originalQuantity: Double,
    val remainingQuantity: Double,
    val filledQuantity: Double,
    val timestamp: Long,
    val status: String
)

@Entity(tableName = "order_book_snapshots")
data class SnapshotEntity(
    @PrimaryKey(autoGenerate = true) val snapshotId: Long = 0,
    val instrumentId: String,
    val bestBid: Double?,
    val bestAsk: Double?,
    val midPrice: Double?,
    val spread: Double?,
    val lastPrice: Double?,
    val timestamp: Long
)

@Entity(tableName = "audit_events")
data class AuditEntity(
    @PrimaryKey val eventId: String,
    val sequenceNumber: Long,
    val eventType: String,
    val participantId: String,
    val details: String,
    val timestamp: Long,
    val checksum: String
)

@Entity(tableName = "settlement_instructions")
data class SettlementEntity(
    @PrimaryKey val settlementId: String,
    val tradeId: String,
    val instrumentId: String,
    val buyerId: String,
    val sellerId: String,
    val quantity: Double,
    val contractPrice: Double,
    val totalAmount: Double,
    val currency: String,
    val deliveryLocation: String,
    val deliveryWindow: String,
    val status: String,
    val createdAt: Long
)
