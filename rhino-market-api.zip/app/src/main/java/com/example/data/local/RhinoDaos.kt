package com.example.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TradeDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrade(trade: TradeEntity)

    @Query("SELECT * FROM trades WHERE instrumentId = :instrumentId ORDER BY timestamp DESC")
    fun getTradesForInstrument(instrumentId: String): Flow<List<TradeEntity>>

    @Query("SELECT * FROM trades ORDER BY timestamp DESC")
    fun getAllTrades(): Flow<List<TradeEntity>>
}

@Dao
interface OrderDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: OrderEntity)

    @Query("SELECT * FROM orders WHERE participantId = :participantId ORDER BY timestamp DESC")
    fun getOrdersForParticipant(participantId: String): Flow<List<OrderEntity>>
}

@Dao
interface SnapshotDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSnapshot(snapshot: SnapshotEntity)

    @Query("SELECT * FROM order_book_snapshots WHERE instrumentId = :instrumentId ORDER BY timestamp DESC LIMIT 100")
    fun getSnapshotsForInstrument(instrumentId: String): Flow<List<SnapshotEntity>>
}

@Dao
interface AuditDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAudit(audit: AuditEntity)

    @Query("SELECT * FROM audit_events ORDER BY sequenceNumber DESC LIMIT 100")
    fun getRecentAudits(): Flow<List<AuditEntity>>
}

@Dao
interface SettlementDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSettlement(settlement: SettlementEntity)

    @Query("SELECT * FROM settlement_instructions ORDER BY createdAt DESC")
    fun getAllSettlements(): Flow<List<SettlementEntity>>
}
