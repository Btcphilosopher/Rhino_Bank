package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        TradeEntity::class,
        OrderEntity::class,
        SnapshotEntity::class,
        AuditEntity::class,
        SettlementEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class RhinoDatabase : RoomDatabase() {

    abstract fun tradeDao(): TradeDao
    abstract fun orderDao(): OrderDao
    abstract fun snapshotDao(): SnapshotDao
    abstract fun auditDao(): AuditDao
    abstract fun settlementDao(): SettlementDao

    companion object {
        @Volatile
        private var INSTANCE: RhinoDatabase? = null

        fun getDatabase(context: Context): RhinoDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    RhinoDatabase::class.java,
                    "rhino_market_db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
