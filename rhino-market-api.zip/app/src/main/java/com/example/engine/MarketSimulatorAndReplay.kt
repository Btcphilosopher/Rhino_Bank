package com.example.engine

import com.example.domain.engine.MatchingEngine
import com.example.domain.model.*
import com.example.service.EventBus
import com.example.service.MarketEvent
import kotlinx.coroutines.*
import java.util.UUID
import kotlin.random.Random

/**
 * Simulation Scenario Presets
 */
enum class SimulationScenario {
    NORMAL,
    HIGH_DEMAND,
    SUPPLY_SHOCK,
    WEATHER_SHOCK,
    FREIGHT_SHOCK,
    LIQUIDITY_CRISIS
}

/**
 * Deterministic Synthetic Market Simulator
 */
class MarketSimulator(
    private val matchingEngine: MatchingEngine,
    private val scope: CoroutineScope
) {
    private var simulationJob: Job? = null
    var isRunning: Boolean = false
        private set

    var currentScenario: SimulationScenario = SimulationScenario.NORMAL

    fun startSimulation(instrument: Instrument, participants: List<Participant>) {
        if (isRunning) return
        isRunning = true

        val farmers = participants.filter { it.role == ParticipantRole.FARMER_PRODUCER }
        val processors = participants.filter { it.role == ParticipantRole.PROCESSOR_BUYER }
        val marketMakers = participants.filter { it.role == ParticipantRole.MARKET_MAKER }

        simulationJob = scope.launch(Dispatchers.Default) {
            var basePrice = 212.50

            while (isActive && isRunning) {
                delay(800) // Ticks every 800ms

                // Adjust price drift based on scenario
                val priceNoise = when (currentScenario) {
                    SimulationScenario.NORMAL -> Random.nextDouble(-0.50, 0.50)
                    SimulationScenario.HIGH_DEMAND -> Random.nextDouble(0.10, 1.20)
                    SimulationScenario.SUPPLY_SHOCK -> Random.nextDouble(0.50, 2.50)
                    SimulationScenario.WEATHER_SHOCK -> Random.nextDouble(-1.50, 2.00)
                    SimulationScenario.FREIGHT_SHOCK -> Random.nextDouble(0.20, 1.00)
                    SimulationScenario.LIQUIDITY_CRISIS -> Random.nextDouble(-3.00, 3.00)
                }

                basePrice = Math.max(150.0, basePrice + priceNoise)

                // 1. Market Maker Quotes (Bids & Asks around basePrice)
                val mm = marketMakers.randomOrNull() ?: participants.first()
                val spread = if (currentScenario == SimulationScenario.LIQUIDITY_CRISIS) 3.50 else 0.50

                val bidPrice = Math.round((basePrice - spread / 2) * 4) / 4.0
                val askPrice = Math.round((basePrice + spread / 2) * 4) / 4.0

                val bidOrder = Order(
                    instrumentId = instrument.instrumentId,
                    participantId = mm.participantId,
                    side = Side.BUY,
                    orderType = OrderType.LIMIT,
                    price = bidPrice,
                    originalQuantity = (Random.nextInt(2, 10) * 50).toDouble()
                )

                val askOrder = Order(
                    instrumentId = instrument.instrumentId,
                    participantId = mm.participantId,
                    side = Side.SELL,
                    orderType = OrderType.LIMIT,
                    price = askPrice,
                    originalQuantity = (Random.nextInt(2, 10) * 50).toDouble()
                )

                matchingEngine.submitOrder(bidOrder, instrument, mm, dataOrigin = "SYNTHETIC")
                matchingEngine.submitOrder(askOrder, instrument, mm, dataOrigin = "SYNTHETIC")

                // 2. Occasional Aggressive Farmer Sell or Processor Buy
                if (Random.nextDouble() < 0.4) {
                    val buyer = processors.randomOrNull() ?: participants.first()
                    val buyMarketOrder = Order(
                        instrumentId = instrument.instrumentId,
                        participantId = buyer.participantId,
                        side = Side.BUY,
                        orderType = OrderType.MARKET,
                        price = askPrice,
                        originalQuantity = (Random.nextInt(1, 5) * 50).toDouble()
                    )
                    matchingEngine.submitOrder(buyMarketOrder, instrument, buyer, dataOrigin = "SYNTHETIC")
                } else if (Random.nextDouble() < 0.4) {
                    val seller = farmers.randomOrNull() ?: participants.last()
                    val sellMarketOrder = Order(
                        instrumentId = instrument.instrumentId,
                        participantId = seller.participantId,
                        side = Side.SELL,
                        orderType = OrderType.MARKET,
                        price = bidPrice,
                        originalQuantity = (Random.nextInt(1, 5) * 50).toDouble()
                    )
                    matchingEngine.submitOrder(sellMarketOrder, instrument, seller, dataOrigin = "SYNTHETIC")
                }
            }
        }
    }

    fun stopSimulation() {
        isRunning = false
        simulationJob?.cancel()
        simulationJob = null
    }
}

/**
 * Event-by-Event Market Replay Engine
 */
class MarketReplayEngine(private val scope: CoroutineScope) {
    private val recordedEvents = mutableListOf<MarketEvent>()
    var isPlaying: Boolean = false
        private set
    var currentFrameIndex: Int = 0
        private set
    var replaySpeedMultiplier: Int = 1 // 1x, 5x, 10x

    private var replayJob: Job? = null

    fun recordEvent(event: MarketEvent) {
        synchronized(recordedEvents) {
            recordedEvents.add(event)
        }
    }

    fun getRecordedCount(): Int = synchronized(recordedEvents) { recordedEvents.size }

    fun play(onEventReplayed: (MarketEvent) -> Unit) {
        if (isPlaying) return
        isPlaying = true

        replayJob = scope.launch(Dispatchers.Default) {
            while (isActive && isPlaying && currentFrameIndex < recordedEvents.size) {
                val event = synchronized(recordedEvents) { recordedEvents[currentFrameIndex] }
                currentFrameIndex++
                onEventReplayed(event)

                val delayMs = (500 / replaySpeedMultiplier).toLong().coerceAtLeast(50)
                delay(delayMs)
            }
            isPlaying = false
        }
    }

    fun pause() {
        isPlaying = false
        replayJob?.cancel()
    }

    fun step(onEventReplayed: (MarketEvent) -> Unit) {
        pause()
        synchronized(recordedEvents) {
            if (currentFrameIndex < recordedEvents.size) {
                val event = recordedEvents[currentFrameIndex]
                currentFrameIndex++
                onEventReplayed(event)
            }
        }
    }

    fun reset() {
        pause()
        currentFrameIndex = 0
    }
}

/**
 * Benchmark Latency & Throughput Tester
 */
data class BenchmarkResult(
    val totalOrders: Int,
    val totalMatches: Int,
    val totalTimeMs: Long,
    val ordersPerSecond: Double,
    val matchesPerSecond: Double,
    val medianLatencyUs: Double,
    val p95LatencyUs: Double,
    val p99LatencyUs: Double
)

object BenchmarkLab {
    suspend fun runBenchmark(orderCount: Int = 5000): BenchmarkResult = withContext(Dispatchers.Default) {
        val testEngine = MatchingEngine()
        val testInstrument = Instrument(
            instrumentId = "BENCH-TEST",
            symbol = "BENCH",
            name = "Benchmark Test Instrument",
            marketId = "TEST-MKT",
            commodityId = "TEST-COMM",
            location = "Test Lab",
            currency = Currency.GBP,
            unit = CommodityUnit.TONNE,
            deliveryWindow = "Prompt",
            minimumQuantity = 1.0,
            maximumQuantity = 10000.0,
            tickSize = 0.01,
            status = MarketStatus.OPEN
        )

        val buyer = Participant("BENCH-BUYER", "Buyer Participant", ParticipantRole.TRADER, 10_000_000.0, maxPositionLimit = 1_000_000.0)
        val seller = Participant("BENCH-SELLER", "Seller Participant", ParticipantRole.TRADER, 10_000_000.0, maxPositionLimit = 1_000_000.0)

        val latenciesNanos = LongArray(orderCount)
        var matchCount = 0

        val startTime = System.currentTimeMillis()

        for (i in 0 until orderCount) {
            val isBuy = i % 2 == 0
            val price = 200.0 + (if (isBuy) (i % 20) * 0.1 else (i % 20) * 0.1 - 0.5)
            val order = Order(
                instrumentId = testInstrument.instrumentId,
                participantId = if (isBuy) buyer.participantId else seller.participantId,
                side = if (isBuy) Side.BUY else Side.SELL,
                orderType = OrderType.LIMIT,
                price = price,
                originalQuantity = 10.0
            )

            val t0 = System.nanoTime()
            val (status, _) = testEngine.submitOrder(order, testInstrument, if (isBuy) buyer else seller)
            val t1 = System.nanoTime()

            latenciesNanos[i] = t1 - t0
            if (status == OrderStatus.FILLED || status == OrderStatus.PARTIALLY_FILLED) {
                matchCount++
            }
        }

        val totalTimeMs = (System.currentTimeMillis() - startTime).coerceAtLeast(1)
        latenciesNanos.sort()

        val medianUs = (latenciesNanos[(orderCount * 0.5).toInt()] / 1000.0)
        val p95Us = (latenciesNanos[(orderCount * 0.95).toInt()] / 1000.0)
        val p99Us = (latenciesNanos[(orderCount * 0.99).toInt()] / 1000.0)

        BenchmarkResult(
            totalOrders = orderCount,
            totalMatches = matchCount,
            totalTimeMs = totalTimeMs,
            ordersPerSecond = (orderCount.toDouble() / totalTimeMs) * 1000.0,
            matchesPerSecond = (matchCount.toDouble() / totalTimeMs) * 1000.0,
            medianLatencyUs = medianUs,
            p95LatencyUs = p95Us,
            p99LatencyUs = p99Us
        )
    }
}
