package com.example.engine

import com.example.domain.model.*
import java.util.concurrent.ConcurrentHashMap

/**
 * Pre-Trade Risk Engine: Validates orders prior to matching
 */
class PreTradeRiskEngine {

    data class RiskCheckResult(
        val isAllowed: Boolean,
        val errorCode: String? = null,
        val message: String? = null
    )

    fun validateOrder(
        order: Order,
        instrument: Instrument,
        participant: Participant,
        currentPosition: Position?,
        lastPrice: Double?
    ): RiskCheckResult {
        // 1. Participant Status
        if (participant.isBlocked) {
            return RiskCheckResult(false, "PARTICIPANT_BLOCKED", "Trading suspended for participant ${participant.name}")
        }

        // 2. Instrument & Market State
        if (instrument.status != MarketStatus.OPEN && instrument.status != MarketStatus.CONTINUOUS) {
            return RiskCheckResult(false, "MARKET_CLOSED", "Instrument ${instrument.symbol} is currently ${instrument.status}")
        }

        // 3. Quantity Limits
        if (order.originalQuantity < instrument.minimumQuantity) {
            return RiskCheckResult(
                false,
                "INVALID_QUANTITY",
                "Quantity ${order.originalQuantity} below minimum ${instrument.minimumQuantity} ${instrument.unit.symbol}"
            )
        }
        if (order.originalQuantity > instrument.maximumQuantity) {
            return RiskCheckResult(
                false,
                "INVALID_QUANTITY",
                "Quantity ${order.originalQuantity} exceeds maximum ${instrument.maximumQuantity} ${instrument.unit.symbol}"
            )
        }

        // 4. Price Bands (prevent erroneous fat-finger orders > 15% off last price)
        if (lastPrice != null && lastPrice > 0) {
            val priceDeviationPercent = Math.abs(order.price - lastPrice) / lastPrice
            if (priceDeviationPercent > 0.15 && order.orderType == OrderType.LIMIT) {
                return RiskCheckResult(
                    false,
                    "PRICE_LIMIT",
                    "Price ${order.price} deviates more than 15% from last price ${lastPrice}"
                )
            }
        }

        // 5. Credit Limit Check
        val orderNotionalValue = order.price * order.originalQuantity
        if (orderNotionalValue > participant.creditLimit) {
            return RiskCheckResult(
                false,
                "INSUFFICIENT_CREDIT",
                "Order value ${orderNotionalValue} exceeds participant credit limit ${participant.creditLimit}"
            )
        }

        // 6. Position Limits Check
        val currentNetQty = currentPosition?.netQuantity ?: 0.0
        val projectedNetQty = if (order.side == Side.BUY) currentNetQty + order.originalQuantity else currentNetQty - order.originalQuantity
        if (Math.abs(projectedNetQty) > participant.maxPositionLimit) {
            return RiskCheckResult(
                false,
                "POSITION_LIMIT",
                "Projected position ${Math.abs(projectedNetQty)} exceeds position limit ${participant.maxPositionLimit}"
            )
        }

        return RiskCheckResult(true)
    }
}

/**
 * Position & P&L Engine
 */
class PositionEngine {
    private val positions = ConcurrentHashMap<String, ConcurrentHashMap<String, Position>>() // ParticipantId -> InstrumentId -> Position

    fun getPosition(participantId: String, instrumentId: String): Position {
        return positions.computeIfAbsent(participantId) { ConcurrentHashMap() }
            .computeIfAbsent(instrumentId) { Position(participantId, instrumentId) }
    }

    fun getAllPositionsForParticipant(participantId: String): List<Position> {
        return positions[participantId]?.values?.toList() ?: emptyList()
    }

    fun updatePositionOnTrade(trade: Trade, markPrice: Double) {
        // Update Buyer Position
        val buyerPos = getPosition(trade.buyerParticipantId, trade.instrumentId)
        synchronized(buyerPos) {
            val oldQty = buyerPos.netQuantity
            val tradeQty = trade.quantity
            val tradePrice = trade.price

            if (oldQty >= 0) { // Increasing Long or starting Long
                val newQty = oldQty + tradeQty
                val newTotalCost = (buyerPos.averagePrice * oldQty) + (tradePrice * tradeQty)
                buyerPos.netQuantity = newQty
                buyerPos.averagePrice = if (newQty > 0) newTotalCost / newQty else 0.0
            } else { // Covering Short
                val coveredQty = Math.min(Math.abs(oldQty), tradeQty)
                val realized = (buyerPos.averagePrice - tradePrice) * coveredQty
                buyerPos.realisedPnL += realized

                buyerPos.netQuantity += tradeQty
                if (buyerPos.netQuantity > 0) { // Reversed to Long
                    buyerPos.averagePrice = tradePrice
                } else if (buyerPos.netQuantity == 0.0) {
                    buyerPos.averagePrice = 0.0
                }
            }
            buyerPos.updatePnL(markPrice)
        }

        // Update Seller Position
        val sellerPos = getPosition(trade.sellerParticipantId, trade.instrumentId)
        synchronized(sellerPos) {
            val oldQty = sellerPos.netQuantity
            val tradeQty = trade.quantity
            val tradePrice = trade.price

            if (oldQty <= 0) { // Increasing Short or starting Short
                val newQty = oldQty - tradeQty
                val newTotalCost = (sellerPos.averagePrice * Math.abs(oldQty)) + (tradePrice * tradeQty)
                sellerPos.netQuantity = newQty
                sellerPos.averagePrice = if (newQty != 0.0) newTotalCost / Math.abs(newQty) else 0.0
            } else { // Closing Long
                val closedQty = Math.min(oldQty, tradeQty)
                val realized = (tradePrice - sellerPos.averagePrice) * closedQty
                sellerPos.realisedPnL += realized

                sellerPos.netQuantity -= tradeQty
                if (sellerPos.netQuantity < 0) { // Reversed to Short
                    sellerPos.averagePrice = tradePrice
                } else if (sellerPos.netQuantity == 0.0) {
                    sellerPos.averagePrice = 0.0
                }
            }
            sellerPos.updatePnL(markPrice)
        }
    }

    fun markToMarket(instrumentId: String, currentMarkPrice: Double) {
        positions.values.forEach { participantMap ->
            participantMap[instrumentId]?.let { pos ->
                synchronized(pos) {
                    pos.updatePnL(currentMarkPrice)
                }
            }
        }
    }
}

/**
 * Market Surveillance Engine: Detects wash trading, spoofing, and manipulation
 */
class MarketSurveillanceEngine {
    private val alerts = mutableListOf<SurveillanceAlert>()

    fun checkWashTrade(buyerId: String, sellerId: String, instrumentId: String): SurveillanceAlert? {
        if (buyerId == sellerId) {
            val alert = SurveillanceAlert(
                alertType = "WASH_TRADE_PREVENTED",
                participantId = buyerId,
                instrumentId = instrumentId,
                description = "Self-trade prevented for participant $buyerId on $instrumentId",
                severity = "CRITICAL"
            )
            synchronized(alerts) { alerts.add(alert) }
            return alert
        }
        return null
    }

    fun getRecentAlerts(): List<SurveillanceAlert> = synchronized(alerts) { alerts.takeLast(50) }
}
