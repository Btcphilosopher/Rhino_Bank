package com.example.domain.engine

import com.example.domain.model.*
import com.example.engine.MarketSurveillanceEngine
import com.example.engine.PositionEngine
import com.example.engine.PreTradeRiskEngine
import com.example.service.EventBus
import com.example.service.MarketEvent
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.*
import java.util.concurrent.ConcurrentHashMap

/**
 * OrderBook Level 2 representation
 */
class OrderBook(val instrumentId: String) {
    // Bids sorted by price DESC, then timestamp ASC
    val bidsTree = TreeMap<Double, LinkedList<Order>>(Comparator.reverseOrder())

    // Asks sorted by price ASC, then timestamp ASC
    val asksTree = TreeMap<Double, LinkedList<Order>>()

    private val orderMap = ConcurrentHashMap<String, Order>()

    @Synchronized
    fun addOrder(order: Order) {
        orderMap[order.orderId] = order
        val tree = if (order.side == Side.BUY) bidsTree else asksTree
        tree.computeIfAbsent(order.price) { LinkedList() }.add(order)
    }

    @Synchronized
    fun removeOrder(orderId: String): Order? {
        val order = orderMap.remove(orderId) ?: return null
        val tree = if (order.side == Side.BUY) bidsTree else asksTree
        val list = tree[order.price]
        if (list != null) {
            list.removeIf { it.orderId == orderId }
            if (list.isEmpty()) {
                tree.remove(order.price)
            }
        }
        return order
    }

    @Synchronized
    fun getOrder(orderId: String): Order? = orderMap[orderId]

    @Synchronized
    fun getBestBidPrice(): Double? = bidsTree.firstEntry()?.key

    @Synchronized
    fun getBestAskPrice(): Double? = asksTree.firstEntry()?.key

    @Synchronized
    fun getBestBidQuantity(): Double? = bidsTree.firstEntry()?.value?.sumOf { it.remainingQuantity }

    @Synchronized
    fun getBestAskQuantity(): Double? = asksTree.firstEntry()?.value?.sumOf { it.remainingQuantity }

    @Synchronized
    fun getBidsSnapshot(depth: Int = 10): List<PriceLevel> {
        return bidsTree.entries.take(depth).map { (price, orders) ->
            PriceLevel(
                price = price,
                aggregateQuantity = orders.sumOf { it.remainingQuantity },
                orderCount = orders.size,
                orders = orders.toList()
            )
        }
    }

    @Synchronized
    fun getAsksSnapshot(depth: Int = 10): List<PriceLevel> {
        return asksTree.entries.take(depth).map { (price, orders) ->
            PriceLevel(
                price = price,
                aggregateQuantity = orders.sumOf { it.remainingQuantity },
                orderCount = orders.size,
                orders = orders.toList()
            )
        }
    }

    @Synchronized
    fun getBbo(lastPrice: Double?, lastQty: Double?, vwap: Double?): BestBidOffer {
        val bestBid = getBestBidPrice()
        val bestAsk = getBestAskPrice()
        val mid = if (bestBid != null && bestAsk != null) (bestBid + bestAsk) / 2.0 else null
        val spread = if (bestBid != null && bestAsk != null) bestAsk - bestBid else null

        return BestBidOffer(
            instrumentId = instrumentId,
            bestBidPrice = bestBid,
            bestBidQuantity = getBestBidQuantity(),
            bestAskPrice = bestAsk,
            bestAskQuantity = getBestAskQuantity(),
            midPrice = mid,
            spread = spread,
            lastPrice = lastPrice,
            lastQuantity = lastQty,
            vwap = vwap
        )
    }
}

/**
 * Deterministic Price/Time Priority Matching Engine
 */
class MatchingEngine(
    val riskEngine: PreTradeRiskEngine = PreTradeRiskEngine(),
    val positionEngine: PositionEngine = PositionEngine(),
    val surveillanceEngine: MarketSurveillanceEngine = MarketSurveillanceEngine()
) {
    private val books = ConcurrentHashMap<String, OrderBook>()
    private val trades = mutableListOf<Trade>()
    private val executedVolume = ConcurrentHashMap<String, Double>()
    private val executedTurnover = ConcurrentHashMap<String, Double>()
    private val lastPrices = ConcurrentHashMap<String, Double>()

    private val matchMutex = Mutex()

    fun getOrderBook(instrumentId: String): OrderBook {
        return books.computeIfAbsent(instrumentId) { OrderBook(instrumentId) }
    }

    fun getTradesForInstrument(instrumentId: String): List<Trade> = synchronized(trades) {
        trades.filter { it.instrumentId == instrumentId }.sortedByDescending { it.timestamp }
    }

    fun getAllTrades(): List<Trade> = synchronized(trades) { trades.toList() }

    /**
     * Submit order to matching engine
     */
    suspend fun submitOrder(
        order: Order,
        instrument: Instrument,
        participant: Participant,
        dataOrigin: String = "LIVE"
    ): Pair<OrderStatus, String?> {

        val book = getOrderBook(instrument.instrumentId)
        val lastPrice = lastPrices[instrument.instrumentId]
        val currentPosition = positionEngine.getPosition(participant.participantId, instrument.instrumentId)

        // 1. Risk Check
        val riskCheck = riskEngine.validateOrder(order, instrument, participant, currentPosition, lastPrice)
        if (!riskCheck.isAllowed) {
            order.status = OrderStatus.REJECTED
            val seq = EventBus.nextSequence()
            EventBus.publish(MarketEvent.OrderRejected(order, riskCheck.message ?: "Risk rejection", seq))
            return OrderStatus.REJECTED to riskCheck.message
        }

        order.status = OrderStatus.ACCEPTED
        EventBus.publish(MarketEvent.OrderAccepted(order, EventBus.nextSequence()))

        // 2. Perform Matching Loop deterministically
        matchOrder(order, book, instrument, dataOrigin)

        return order.status to null
    }

    private suspend fun matchOrder(
        incomingOrder: Order,
        book: OrderBook,
        instrument: Instrument,
        dataOrigin: String
    ) = matchMutex.withLock {
        val oppositeTree = if (incomingOrder.side == Side.BUY) book.asksTree else book.bidsTree

        val iterator = oppositeTree.entries.iterator()

        while (iterator.hasNext() && incomingOrder.remainingQuantity > 0.0) {
            val (priceLevelPrice, ordersAtLevel) = iterator.next()

            // Check price matching condition
            val isPriceMatch = if (incomingOrder.side == Side.BUY) {
                incomingOrder.orderType == OrderType.MARKET || incomingOrder.price >= priceLevelPrice
            } else {
                incomingOrder.orderType == OrderType.MARKET || incomingOrder.price <= priceLevelPrice
            }

            if (!isPriceMatch) break // Cannot match further

            val orderListIterator = ordersAtLevel.iterator()
            while (orderListIterator.hasNext() && incomingOrder.remainingQuantity > 0.0) {
                val restingOrder = orderListIterator.next()

                // Self-trade check
                val alert = surveillanceEngine.checkWashTrade(
                    if (incomingOrder.side == Side.BUY) incomingOrder.participantId else restingOrder.participantId,
                    if (incomingOrder.side == Side.SELL) incomingOrder.participantId else restingOrder.participantId,
                    instrument.instrumentId
                )
                if (alert != null) {
                    EventBus.publish(MarketEvent.SurveillanceAlertTriggered(alert))
                    // Cancel incoming order to prevent self-trade
                    incomingOrder.status = OrderStatus.CANCELLED
                    return@withLock
                }

                // Calculate match quantity & match price (resting limit price)
                val matchQty = Math.min(incomingOrder.remainingQuantity, restingOrder.remainingQuantity)
                val matchPrice = restingOrder.price

                // Execute trade
                incomingOrder.remainingQuantity -= matchQty
                incomingOrder.filledQuantity += matchQty

                restingOrder.remainingQuantity -= matchQty
                restingOrder.filledQuantity += matchQty

                if (restingOrder.remainingQuantity == 0.0) {
                    restingOrder.status = OrderStatus.FILLED
                    orderListIterator.remove()
                    book.removeOrder(restingOrder.orderId)
                } else {
                    restingOrder.status = OrderStatus.PARTIALLY_FILLED
                }

                if (incomingOrder.remainingQuantity == 0.0) {
                    incomingOrder.status = OrderStatus.FILLED
                } else {
                    incomingOrder.status = OrderStatus.PARTIALLY_FILLED
                }

                // Create Immutable Trade
                val buyOrder = if (incomingOrder.side == Side.BUY) incomingOrder else restingOrder
                val sellOrder = if (incomingOrder.side == Side.SELL) incomingOrder else restingOrder

                val trade = Trade(
                    instrumentId = instrument.instrumentId,
                    buyOrderId = buyOrder.orderId,
                    sellOrderId = sellOrder.orderId,
                    buyerParticipantId = buyOrder.participantId,
                    sellerParticipantId = sellOrder.participantId,
                    price = matchPrice,
                    quantity = matchQty,
                    totalValue = matchPrice * matchQty,
                    currency = instrument.currency,
                    unit = instrument.unit,
                    dataOrigin = dataOrigin
                )

                synchronized(trades) { trades.add(trade) }

                // Update Stats & Position
                lastPrices[instrument.instrumentId] = matchPrice
                executedVolume[instrument.instrumentId] = (executedVolume[instrument.instrumentId] ?: 0.0) + matchQty
                executedTurnover[instrument.instrumentId] = (executedTurnover[instrument.instrumentId] ?: 0.0) + (matchPrice * matchQty)

                positionEngine.updatePositionOnTrade(trade, matchPrice)

                // Publish Event
                val seq = EventBus.nextSequence()
                EventBus.publish(MarketEvent.OrderMatched(trade, buyOrder, sellOrder, seq))
            }

            if (ordersAtLevel.isEmpty()) {
                iterator.remove()
            }
        }

        // If limit order has remaining quantity and is not IOC/FOK, add to book
        if (incomingOrder.remainingQuantity > 0.0) {
            if (incomingOrder.orderType == OrderType.LIMIT) {
                book.addOrder(incomingOrder)
            } else { // IOC / MARKET unfilled portion is cancelled
                incomingOrder.status = OrderStatus.CANCELLED
            }
        }

        // Broadcast updated order book & BBO
        val vol = executedVolume[instrument.instrumentId] ?: 0.0
        val turnover = executedTurnover[instrument.instrumentId] ?: 0.0
        val vwap = if (vol > 0) turnover / vol else null
        val bbo = book.getBbo(lastPrices[instrument.instrumentId], null, vwap)

        EventBus.publish(
            MarketEvent.OrderBookUpdated(
                bbo = bbo,
                asks = book.getAsksSnapshot(),
                bids = book.getBidsSnapshot(),
                sequenceNumber = EventBus.nextSequence()
            )
        )
    }

    suspend fun cancelOrder(orderId: String, instrumentId: String, participantId: String): Boolean = matchMutex.withLock {
        val book = getOrderBook(instrumentId)
        val order = book.removeOrder(orderId)
        if (order != null) {
            order.status = OrderStatus.CANCELLED
            val seq = EventBus.nextSequence()
            EventBus.publish(MarketEvent.OrderCancelled(orderId, instrumentId, participantId, seq))

            val bbo = book.getBbo(lastPrices[instrumentId], null, null)
            EventBus.publish(
                MarketEvent.OrderBookUpdated(
                    bbo = bbo,
                    asks = book.getAsksSnapshot(),
                    bids = book.getBidsSnapshot(),
                    sequenceNumber = EventBus.nextSequence()
                )
            )
            return true
        }
        return false
    }
}
