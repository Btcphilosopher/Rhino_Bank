package com.example.engine

import com.example.domain.engine.MatchingEngine
import com.example.domain.model.*
import com.example.service.EventBus
import com.example.service.MarketEvent
import java.util.concurrent.ConcurrentHashMap

/**
 * RFQ (Request For Quote) Engine: Bilateral physical commodity trading desk
 */
class RfqEngine(private val matchingEngine: MatchingEngine) {
    private val rfqs = ConcurrentHashMap<String, RfqRequest>()

    fun createRfq(
        buyerParticipantId: String,
        instrumentId: String,
        requestedQuantity: Double,
        destinationLocation: String,
        deliveryWindow: String
    ): RfqRequest {
        val rfq = RfqRequest(
            buyerParticipantId = buyerParticipantId,
            instrumentId = instrumentId,
            requestedQuantity = requestedQuantity,
            destinationLocation = destinationLocation,
            targetDeliveryWindow = deliveryWindow
        )
        rfqs[rfq.rfqId] = rfq
        EventBus.tryPublish(MarketEvent.RfqUpdated(rfq, EventBus.nextSequence()))
        return rfq
    }

    fun submitSupplierQuote(
        rfqId: String,
        sellerParticipantId: String,
        price: Double,
        freightCostPerUnit: Double,
        deliveryWindow: String
    ): RfqResponse? {
        val rfq = rfqs[rfqId] ?: return null
        val response = RfqResponse(
            sellerParticipantId = sellerParticipantId,
            price = price,
            freightCostPerUnit = freightCostPerUnit,
            deliveryWindow = deliveryWindow
        )
        synchronized(rfq) {
            rfq.responses.add(response)
            rfq.status = RfqStatus.QUOTED
        }
        EventBus.tryPublish(MarketEvent.RfqUpdated(rfq, EventBus.nextSequence()))
        return response
    }

    suspend fun awardRfq(rfqId: String, selectedQuoteId: String, instrument: Instrument): Trade? {
        val rfq = rfqs[rfqId] ?: return null
        val response = rfq.responses.find { it.quoteId == selectedQuoteId } ?: return null

        val buyOrder = Order(
            instrumentId = rfq.instrumentId,
            participantId = rfq.buyerParticipantId,
            side = Side.BUY,
            orderType = OrderType.RFQ,
            price = response.totalLandedPrice,
            originalQuantity = rfq.requestedQuantity,
            status = OrderStatus.FILLED
        )

        val sellOrder = Order(
            instrumentId = rfq.instrumentId,
            participantId = response.sellerParticipantId,
            side = Side.SELL,
            orderType = OrderType.RFQ,
            price = response.totalLandedPrice,
            originalQuantity = rfq.requestedQuantity,
            status = OrderStatus.FILLED
        )

        val trade = Trade(
            instrumentId = rfq.instrumentId,
            buyOrderId = buyOrder.orderId,
            sellOrderId = sellOrder.orderId,
            buyerParticipantId = rfq.buyerParticipantId,
            sellerParticipantId = response.sellerParticipantId,
            price = response.totalLandedPrice,
            quantity = rfq.requestedQuantity,
            totalValue = response.totalLandedPrice * rfq.requestedQuantity,
            currency = instrument.currency,
            unit = instrument.unit,
            venue = "RHINO_BILATERAL_RFQ"
        )

        synchronized(rfq) {
            rfq.status = RfqStatus.AWARDED
        }

        matchingEngine.positionEngine.updatePositionOnTrade(trade, response.totalLandedPrice)
        EventBus.publish(MarketEvent.OrderMatched(trade, buyOrder, sellOrder, EventBus.nextSequence()))
        EventBus.publish(MarketEvent.RfqUpdated(rfq, EventBus.nextSequence()))

        return trade
    }

    fun getAllRfqs(): List<RfqRequest> = rfqs.values.toList().sortedByDescending { it.timestamp }
}

/**
 * Settlement & Physical Delivery Engine
 */
class SettlementEngine {
    private val settlements = ConcurrentHashMap<String, SettlementInstruction>()

    fun createSettlementFromTrade(trade: Trade, deliveryLocation: String, deliveryWindow: String): SettlementInstruction {
        val instruction = SettlementInstruction(
            tradeId = trade.tradeId,
            instrumentId = trade.instrumentId,
            buyerId = trade.buyerParticipantId,
            sellerId = trade.sellerParticipantId,
            quantity = trade.quantity,
            contractPrice = trade.price,
            totalAmount = trade.totalValue,
            currency = trade.currency,
            deliveryLocation = deliveryLocation,
            deliveryWindow = deliveryWindow
        )
        settlements[instruction.settlementId] = instruction
        return instruction
    }

    fun updateQualityResults(
        settlementId: String,
        moisturePercent: Double,
        proteinPercent: Double,
        passed: Boolean
    ): SettlementInstruction? {
        val settlement = settlements[settlementId] ?: return null
        synchronized(settlement) {
            settlement.moistureContent = moisturePercent
            settlement.proteinContent = proteinPercent
            settlement.qualityTestPassed = passed
            settlement.status = if (passed) SettlementStatus.QUALITY_TEST_PASSED else SettlementStatus.DISPUTED
        }
        return settlement
    }

    fun advanceSettlementStatus(settlementId: String): SettlementInstruction? {
        val settlement = settlements[settlementId] ?: return null
        synchronized(settlement) {
            val next = when (settlement.status) {
                SettlementStatus.INSTRUCTION_CREATED -> SettlementStatus.QUANTITY_CONFIRMED
                SettlementStatus.QUANTITY_CONFIRMED -> SettlementStatus.QUALITY_TEST_PASSED
                SettlementStatus.QUALITY_TEST_PASSED -> SettlementStatus.INVOICED
                SettlementStatus.INVOICED -> SettlementStatus.PAID
                SettlementStatus.PAID -> SettlementStatus.COMPLETED
                else -> settlement.status
            }
            settlement.status = next
        }
        return settlement
    }

    fun getAllSettlements(): List<SettlementInstruction> = settlements.values.toList().sortedByDescending { it.createdAt }
}
