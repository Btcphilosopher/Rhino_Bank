package com.example.domain.units

import com.example.domain.model.CommodityUnit
import com.example.domain.model.Currency

/**
 * Units Engine: Performs explicit, precise unit conversions without silent rounding or arbitrary assumptions.
 */
object UnitsEngine {

    // Standard conversion factors to base units
    private val weightToTonnes: Map<CommodityUnit, Double> = mapOf(
        CommodityUnit.TONNE to 1.0,
        CommodityUnit.KG to 0.001
    )

    private val energyToMwh: Map<CommodityUnit, Double> = mapOf(
        CommodityUnit.MEGAWATT_HOUR to 1.0
    )

    private val volumeToBarrels: Map<CommodityUnit, Double> = mapOf(
        CommodityUnit.BARREL to 1.0
    )

    /**
     * Convert quantity explicitly from source unit to target unit.
     */
    fun convertQuantity(
        quantity: Double,
        fromUnit: CommodityUnit,
        toUnit: CommodityUnit,
        cropType: String = "WHEAT"
    ): Double {
        if (fromUnit == toUnit) return quantity

        // Bushel conversion is commodity dependent (e.g. Wheat: 1 tonne = 36.7437 bushels, Corn: 39.368)
        if (fromUnit == CommodityUnit.BUSHEL && toUnit == CommodityUnit.TONNE) {
            val bushelsPerTonne = when (cropType.uppercase()) {
                "CORN" -> 39.368
                "BARLEY" -> 45.9296
                else -> 36.7437 // Wheat & Soybeans
            }
            return quantity / bushelsPerTonne
        }
        if (fromUnit == CommodityUnit.TONNE && toUnit == CommodityUnit.BUSHEL) {
            val bushelsPerTonne = when (cropType.uppercase()) {
                "CORN" -> 39.368
                "BARLEY" -> 45.9296
                else -> 36.7437
            }
            return quantity * bushelsPerTonne
        }

        // Weight conversions
        val fromWeight = weightToTonnes[fromUnit]
        val toWeight = weightToTonnes[toUnit]
        if (fromWeight != null && toWeight != null) {
            val tonnes = quantity * fromWeight
            return tonnes / toWeight
        }

        // Energy conversions
        val fromEnergy = energyToMwh[fromUnit]
        val toEnergy = energyToMwh[toUnit]
        if (fromEnergy != null && toEnergy != null) {
            val mwh = quantity * fromEnergy
            return mwh / toEnergy
        }

        // Volume conversions
        val fromVolume = volumeToBarrels[fromUnit]
        val toVolume = volumeToBarrels[toUnit]
        if (fromVolume != null && toVolume != null) {
            val bbl = quantity * fromVolume
            return bbl / toVolume
        }

        return quantity
    }

    /**
     * Price Per Unit conversion
     */
    fun convertPrice(
        pricePerSourceUnit: Double,
        fromUnit: CommodityUnit,
        toUnit: CommodityUnit,
        cropType: String = "WHEAT"
    ): Double {
        if (fromUnit == toUnit) return pricePerSourceUnit
        val convertedQtyOfOneSourceUnit = convertQuantity(1.0, fromUnit, toUnit, cropType)
        return pricePerSourceUnit / convertedQtyOfOneSourceUnit
    }
}

/**
 * Basis Engine: Calculates Basis = Local Price - Reference Price
 */
object BasisEngine {
    data class BasisCalculation(
        val location: String,
        val localPrice: Double,
        val nationalRefPrice: Double,
        val basisAmount: Double, // Local - National
        val currency: Currency = Currency.GBP,
        val unit: CommodityUnit = CommodityUnit.TONNE
    )

    fun calculateBasis(
        location: String,
        localPrice: Double,
        nationalRefPrice: Double,
        currency: Currency = Currency.GBP,
        unit: CommodityUnit = CommodityUnit.TONNE
    ): BasisCalculation {
        val basis = localPrice - nationalRefPrice
        return BasisCalculation(
            location = location,
            localPrice = localPrice,
            nationalRefPrice = nationalRefPrice,
            basisAmount = basis,
            currency = currency,
            unit = unit
        )
    }
}

/**
 * Landed Freight & Logistics Price Calculator
 */
data class LandedPriceBreakdown(
    val baseMarketPrice: Double,
    val freightCost: Double,
    val handlingFee: Double,
    val storageFee: Double,
    val insuranceFee: Double,
    val totalLandedCostPerUnit: Double,
    val totalLandedAmount: Double
)

object LandedPriceCalculator {
    fun calculateLandedPrice(
        quantity: Double,
        basePricePerUnit: Double,
        distanceMiles: Double,
        freightRatePerTonMile: Double = 0.12, // £0.12 per tonne-mile
        handlingPerUnit: Double = 2.50,
        storagePerUnit: Double = 1.80,
        insurancePercent: Double = 0.005 // 0.5% of market value
    ): LandedPriceBreakdown {
        val freightPerUnit = distanceMiles * freightRatePerTonMile
        val insurancePerUnit = basePricePerUnit * insurancePercent
        val totalPerUnit = basePricePerUnit + freightPerUnit + handlingPerUnit + storagePerUnit + insurancePerUnit
        val totalAmount = totalPerUnit * quantity

        return LandedPriceBreakdown(
            baseMarketPrice = basePricePerUnit,
            freightCost = freightPerUnit,
            handlingFee = handlingPerUnit,
            storageFee = storagePerUnit,
            insuranceFee = insurancePerUnit,
            totalLandedCostPerUnit = totalPerUnit,
            totalLandedAmount = totalAmount
        )
    }
}
