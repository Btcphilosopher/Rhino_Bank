package com.example.domain.model

import java.util.UUID

/**
 * Currency Units
 */
enum class Currency(val symbol: String) {
    GBP("£"),
    EUR("€"),
    USD("$")
}

/**
 * Commodity Physical Units
 */
enum class CommodityUnit(val symbol: String) {
    TONNE("t"),
    BUSHEL("bu"),
    KG("kg"),
    BARREL("bbl"),
    MEGAWATT_HOUR("MWh"),
    CONTAINER("TEU")
}

/**
 * Market Lifecycle Status
 */
enum class MarketStatus {
    PRE_OPEN,
    OPEN,
    CONTINUOUS,
    HALTED,
    SUSPENDED,
    CLOSED
}

/**
 * Commodity Specifications
 */
data class CommoditySpec(
    val proteinPercent: Double? = null,
    val moisturePercent: Double? = null,
    val specificWeightKgHl: Double? = null,
    val grade: String? = null,
    val cropYear: Int? = null,
    val origin: String? = null
)

data class Commodity(
    val commodityId: String,
    val name: String,
    val category: String, // AGRICULTURE, METALS, ENERGY, FREIGHT
    val defaultUnit: CommodityUnit = CommodityUnit.TONNE,
    val specification: CommoditySpec? = null
)

/**
 * Rigorous Instrument Definition
 */
data class Instrument(
    val instrumentId: String,         // e.g. UKWHEAT-LINCS-SEP26
    val symbol: String,               // e.g. UKWHEAT
    val name: String,                 // e.g. UK Feed Wheat Lincolnshire Sep 26
    val marketId: String,             // Market Venue ID
    val commodityId: String,          // Underlying commodity
    val location: String,             // Delivery location / regional hub
    val currency: Currency = Currency.GBP,
    val unit: CommodityUnit = CommodityUnit.TONNE,
    val deliveryWindow: String,       // e.g. Sep 2026
    val minimumQuantity: Double = 50.0,
    val maximumQuantity: Double = 10000.0,
    val tickSize: Double = 0.25,      // Minimum price movement
    val pricePrecision: Int = 2,
    val quantityPrecision: Int = 0,
    val settlementType: String = "PHYSICAL", // PHYSICAL or CASH
    val status: MarketStatus = MarketStatus.OPEN,
    val metadata: Map<String, String> = emptyMap()
)

/**
 * Order Side and Order Types
 */
enum class Side {
    BUY,
    SELL
}

enum class OrderType {
    LIMIT,
    MARKET,
    IOC, // Immediate or Cancel
    FOK, // Fill or Kill
    RFQ  // Bilateral RFQ Order
}

enum class OrderStatus {
    NEW,
    ACCEPTED,
    PARTIALLY_FILLED,
    FILLED,
    CANCELLED,
    REJECTED,
    EXPIRED
}

/**
 * Market Participant Roles & Model
 */
enum class ParticipantRole {
    TRADER,
    MARKET_MAKER,
    FARMER_PRODUCER,
    PROCESSOR_BUYER,
    WHOLESALER,
    LOGISTICS,
    RISK_ADMIN,
    SURVEILLANCE
}

data class Participant(
    val participantId: String,
    val name: String,
    val role: ParticipantRole,
    val cashBalance: Double,
    val currency: Currency = Currency.GBP,
    val creditLimit: Double = 1_000_000.0,
    val maxPositionLimit: Double = 50_000.0,
    val isBlocked: Boolean = false
)

/**
 * Order Model
 */
data class Order(
    val orderId: String = UUID.randomUUID().toString(),
    val instrumentId: String,
    val participantId: String,
    val side: Side,
    val orderType: OrderType = OrderType.LIMIT,
    val price: Double,               // Per unit price
    val originalQuantity: Double,
    var remainingQuantity: Double = originalQuantity,
    var filledQuantity: Double = 0.0,
    val timestamp: Long = System.currentTimeMillis(),
    val expiryTime: Long? = null,
    var status: OrderStatus = OrderStatus.NEW,
    val idempotencyKey: String? = null,
    val clientOrderId: String? = null
)

/**
 * Level 2 Price Level Aggregation
 */
data class PriceLevel(
    val price: Double,
    val aggregateQuantity: Double,
    val orderCount: Int,
    val orders: List<Order> = emptyList()
)

/**
 * BBO (Best Bid / Best Ask) Summary
 */
data class BestBidOffer(
    val instrumentId: String,
    val bestBidPrice: Double?,
    val bestBidQuantity: Double?,
    val bestAskPrice: Double?,
    val bestAskQuantity: Double?,
    val midPrice: Double?,
    val spread: Double?,
    val lastPrice: Double?,
    val lastQuantity: Double?,
    val vwap: Double?,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * Immutable Trade Record
 */
data class Trade(
    val tradeId: String = UUID.randomUUID().toString(),
    val executionId: String = "EXEC-${UUID.randomUUID().toString().take(8)}",
    val instrumentId: String,
    val buyOrderId: String,
    val sellOrderId: String,
    val buyerParticipantId: String,
    val sellerParticipantId: String,
    val price: Double,
    val quantity: Double,
    val totalValue: Double = price * quantity,
    val currency: Currency = Currency.GBP,
    val unit: CommodityUnit = CommodityUnit.TONNE,
    val timestamp: Long = System.currentTimeMillis(),
    val venue: String = "RHINO_SPOT_MATCH",
    val dataOrigin: String = "LIVE" // "LIVE" or "SYNTHETIC"
)

/**
 * Executable Quote (Bilateral / OTC / Market Maker)
 */
data class Quote(
    val quoteId: String = UUID.randomUUID().toString(),
    val instrumentId: String,
    val participantId: String,
    val side: Side,
    val price: Double,
    val quantity: Double,
    val timestamp: Long = System.currentTimeMillis(),
    val expiryTimestamp: Long = timestamp + 300_000, // 5 min default
    var status: String = "ACTIVE"
)

/**
 * RFQ (Request For Quote) lifecycle
 */
enum class RfqStatus {
    CREATED,
    OPEN,
    QUOTED,
    NEGOTIATING,
    AWARDED,
    REJECTED,
    EXPIRED,
    CANCELLED
}

data class RfqResponse(
    val quoteId: String = UUID.randomUUID().toString(),
    val sellerParticipantId: String,
    val price: Double,
    val freightCostPerUnit: Double = 0.0,
    val totalLandedPrice: Double = price + freightCostPerUnit,
    val deliveryWindow: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class RfqRequest(
    val rfqId: String = UUID.randomUUID().toString(),
    val buyerParticipantId: String,
    val instrumentId: String,
    val requestedQuantity: Double,
    val destinationLocation: String,
    val targetDeliveryWindow: String,
    var status: RfqStatus = RfqStatus.OPEN,
    val responses: MutableList<RfqResponse> = mutableListOf(),
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * Participant Position & Mark-To-Market P&L
 */
data class Position(
    val participantId: String,
    val instrumentId: String,
    var netQuantity: Double = 0.0,     // Positive = Long, Negative = Short
    var totalCost: Double = 0.0,       // Total purchase outlay
    var averagePrice: Double = 0.0,    // Weighted avg purchase/sale price
    var markPrice: Double = 0.0,       // Current market price
    var realisedPnL: Double = 0.0,
    var unrealisedPnL: Double = 0.0,
    val currency: Currency = Currency.GBP
) {
    fun updatePnL(currentMarkPrice: Double) {
        markPrice = currentMarkPrice
        unrealisedPnL = if (netQuantity != 0.0) {
            (currentMarkPrice - averagePrice) * netQuantity
        } else {
            0.0
        }
    }
}

/**
 * Physical Delivery & Settlement Instruction
 */
enum class SettlementStatus {
    INSTRUCTION_CREATED,
    QUANTITY_CONFIRMED,
    QUALITY_TEST_PASSED,
    INVOICED,
    PAID,
    COMPLETED,
    DISPUTED
}

data class SettlementInstruction(
    val settlementId: String = "SETTLE-${UUID.randomUUID().toString().take(8)}",
    val tradeId: String,
    val instrumentId: String,
    val buyerId: String,
    val sellerId: String,
    val quantity: Double,
    val contractPrice: Double,
    val totalAmount: Double = quantity * contractPrice,
    val currency: Currency = Currency.GBP,
    val deliveryLocation: String,
    val deliveryWindow: String,
    var qualityTestPassed: Boolean = true,
    var moistureContent: Double = 14.2, // e.g. 14.2%
    var proteinContent: Double = 11.5,  // e.g. 11.5%
    var status: SettlementStatus = SettlementStatus.INSTRUCTION_CREATED,
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * OHLCV Candlestick Bar
 */
data class OhlcvBar(
    val instrumentId: String,
    val timestamp: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double,
    val tradeCount: Int,
    val vwap: Double
)

/**
 * Audit & Surveillance Alert
 */
data class AuditEvent(
    val eventId: String = UUID.randomUUID().toString(),
    val sequenceNumber: Long,
    val eventType: String,
    val participantId: String,
    val details: String,
    val timestamp: Long = System.currentTimeMillis(),
    val checksum: String = ""
)

data class SurveillanceAlert(
    val alertId: String = UUID.randomUUID().toString(),
    val alertType: String,
    val participantId: String,
    val instrumentId: String,
    val description: String,
    val severity: String = "WARNING",
    val timestamp: Long = System.currentTimeMillis()
)
