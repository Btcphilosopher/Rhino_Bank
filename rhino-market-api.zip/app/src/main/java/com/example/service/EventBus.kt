package com.example.service

import com.example.domain.model.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

sealed class MarketEvent {
    data class MarketStatusChanged(
        val marketId: String,
        val instrumentId: String,
        val newStatus: MarketStatus,
        val timestamp: Long = System.currentTimeMillis()
    ) : MarketEvent()

    data class OrderAccepted(
        val order: Order,
        val sequenceNumber: Long
    ) : MarketEvent()

    data class OrderRejected(
        val order: Order,
        val reason: String,
        val sequenceNumber: Long
    ) : MarketEvent()

    data class OrderCancelled(
        val orderId: String,
        val instrumentId: String,
        val participantId: String,
        val sequenceNumber: Long
    ) : MarketEvent()

    data class OrderMatched(
        val trade: Trade,
        val buyOrder: Order,
        val sellOrder: Order,
        val sequenceNumber: Long
    ) : MarketEvent()

    data class OrderBookUpdated(
        val bbo: BestBidOffer,
        val asks: List<PriceLevel>,
        val bids: List<PriceLevel>,
        val sequenceNumber: Long
    ) : MarketEvent()

    data class RfqUpdated(
        val rfq: RfqRequest,
        val sequenceNumber: Long
    ) : MarketEvent()

    data class AuditLogged(
        val auditEvent: AuditEvent
    ) : MarketEvent()

    data class SurveillanceAlertTriggered(
        val alert: SurveillanceAlert
    ) : MarketEvent()
}

object EventBus {
    private val _events = MutableSharedFlow<MarketEvent>(extraBufferCapacity = 1000)
    val events: SharedFlow<MarketEvent> = _events.asSharedFlow()

    private var sequenceCounter = 0L

    fun nextSequence(): Long = synchronized(this) {
        ++sequenceCounter
    }

    suspend fun publish(event: MarketEvent) {
        _events.emit(event)
    }

    fun tryPublish(event: MarketEvent) {
        _events.tryEmit(event)
    }

    fun getCurrentSequence(): Long = sequenceCounter
}
