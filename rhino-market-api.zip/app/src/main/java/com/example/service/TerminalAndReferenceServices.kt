package com.example.service

import com.example.domain.engine.MatchingEngine
import com.example.domain.model.*
import com.example.engine.BenchmarkLab
import com.example.engine.MarketSimulator
import com.example.engine.RfqEngine
import com.example.engine.SimulationScenario

/**
 * Reference Data Service: Supplies instruments, commodities, and participants
 */
object ReferenceDataService {

    val commodities = listOf(
        Commodity(
            commodityId = "COMM-UKWHEAT",
            name = "UK Feed Wheat",
            category = "AGRICULTURE",
            defaultUnit = CommodityUnit.TONNE,
            specification = CommoditySpec(
                proteinPercent = 11.5,
                moisturePercent = 14.5,
                specificWeightKgHl = 72.0,
                grade = "UK Feed Wheat Spec A",
                cropYear = 2026,
                origin = "Lincolnshire, UK"
            )
        ),
        Commodity(
            commodityId = "COMM-UKBARLEY",
            name = "UK Feed Barley",
            category = "AGRICULTURE",
            defaultUnit = CommodityUnit.TONNE,
            specification = CommoditySpec(
                moisturePercent = 15.0,
                specificWeightKgHl = 63.0,
                grade = "Malt / Feed Grade 1",
                cropYear = 2026,
                origin = "Yorkshire, UK"
            )
        ),
        Commodity(
            commodityId = "COMM-STEEL",
            name = "Hot Rolled Steel Coil",
            category = "METALS",
            defaultUnit = CommodityUnit.TONNE,
            specification = CommoditySpec(
                grade = "S235JR Structural Steel",
                origin = "Scunthorpe, UK"
            )
        ),
        Commodity(
            commodityId = "COMM-CRUDE",
            name = "Brent Crude Oil",
            category = "ENERGY",
            defaultUnit = CommodityUnit.BARREL,
            specification = CommoditySpec(
                grade = "38.3 API / 0.37% Sulfur",
                origin = "North Sea"
            )
        )
    )

    val instruments = listOf(
        Instrument(
            instrumentId = "UKWHEAT-LINCS-SEP26",
            symbol = "UKWHEAT",
            name = "UK Feed Wheat (Lincolnshire Sep 26)",
            marketId = "RHINO-SPOT-AGRI",
            commodityId = "COMM-UKWHEAT",
            location = "Lincolnshire Farm Storage",
            currency = Currency.GBP,
            unit = CommodityUnit.TONNE,
            deliveryWindow = "1-30 September 2026",
            minimumQuantity = 50.0,
            maximumQuantity = 5000.0,
            tickSize = 0.25,
            status = MarketStatus.OPEN
        ),
        Instrument(
            instrumentId = "UKBARLEY-YORKS-OCT26",
            symbol = "UKBARLEY",
            name = "UK Feed Barley (Yorkshire Oct 26)",
            marketId = "RHINO-SPOT-AGRI",
            commodityId = "COMM-UKBARLEY",
            location = "Yorkshire Silos",
            currency = Currency.GBP,
            unit = CommodityUnit.TONNE,
            deliveryWindow = "1-31 October 2026",
            minimumQuantity = 50.0,
            maximumQuantity = 5000.0,
            tickSize = 0.25,
            status = MarketStatus.OPEN
        ),
        Instrument(
            instrumentId = "STEEL-HRC-NORTH-OCT26",
            symbol = "STEELHRC",
            name = "UK Hot Rolled Coil Steel (Oct 26)",
            marketId = "RHINO-SPOT-METALS",
            commodityId = "COMM-STEEL",
            location = "Scunthorpe Hub",
            currency = Currency.GBP,
            unit = CommodityUnit.TONNE,
            deliveryWindow = "15-31 October 2026",
            minimumQuantity = 20.0,
            maximumQuantity = 2000.0,
            tickSize = 0.50,
            status = MarketStatus.OPEN
        ),
        Instrument(
            instrumentId = "BRENT-SPOT-NORTHSEA",
            symbol = "BRENT",
            name = "Brent Crude Spot (FOB North Sea)",
            marketId = "RHINO-SPOT-ENERGY",
            commodityId = "COMM-CRUDE",
            location = "Sullom Voe Terminal",
            currency = Currency.USD,
            unit = CommodityUnit.BARREL,
            deliveryWindow = "Prompt Loading",
            minimumQuantity = 1000.0,
            maximumQuantity = 100000.0,
            tickSize = 0.01,
            status = MarketStatus.OPEN
        )
    )

    val participants = listOf(
        Participant("PART-MM01", "Rhino Liquidity Maker", ParticipantRole.MARKET_MAKER, 5_000_000.0, Currency.GBP, creditLimit = 10_000_000.0, maxPositionLimit = 100_000.0),
        Participant("PART-FARM01", "Lincolnshire Farmer Co-op", ParticipantRole.FARMER_PRODUCER, 850_000.0, Currency.GBP, creditLimit = 2_000_000.0, maxPositionLimit = 25_000.0),
        Participant("PART-MILL01", "ADM Agri Flour Mills", ParticipantRole.PROCESSOR_BUYER, 3_200_000.0, Currency.GBP, creditLimit = 8_000_000.0, maxPositionLimit = 50_000.0),
        Participant("PART-TRADER01", "RhinoQuant Spec Desk", ParticipantRole.TRADER, 1_500_000.0, Currency.GBP, creditLimit = 5_000_000.0, maxPositionLimit = 30_000.0)
    )
}

/**
 * Rhino Terminal CLI Parser: Translates user commands into market actions
 */
class RhinoTerminalCommandParser(
    private val matchingEngine: MatchingEngine,
    private val rfqEngine: RfqEngine,
    private val simulator: MarketSimulator
) {
    suspend fun executeCommand(
        input: String,
        selectedInstrument: Instrument,
        currentParticipant: Participant
    ): String {
        val tokens = input.trim().split("\\s+".toRegex())
        if (tokens.isEmpty() || tokens[0].isBlank()) return "Type HELP for available terminal commands."

        val cmd = tokens[0].uppercase()

        return when (cmd) {
            "HELP" -> """
                RHINO TERMINAL COMMANDS:
                • MARKET - List available spot market instruments
                • BOOK [instrumentId] - View Level 2 order book depth
                • BUY [qty] @ [price] - Submit limit bid on active instrument
                • SELL [qty] @ [price] - Submit limit offer on active instrument
                • QUOTE - Get current Best Bid & Offer (BBO)
                • TRADES - View recent trade execution tape
                • RFQ NEW [qty] [dest] - Request for quote from suppliers
                • POS - View participant open positions & mark-to-market P&L
                • RISK - Show pre-trade risk and credit utilisation
                • SIM [START|STOP|NORMAL|HIGH_DEMAND|SUPPLY_SHOCK] - Control market simulator
                • BENCHMARK [orderCount] - Run high-speed order engine latency test
                • CLEAR - Clear screen output
            """.trimIndent()

            "MARKET" -> {
                ReferenceDataService.instruments.joinToString("\n") { inst ->
                    "• ${inst.instrumentId.padEnd(22)} | ${inst.name} | ${inst.deliveryWindow}"
                }
            }

            "BOOK" -> {
                val instId = if (tokens.size > 1) tokens[1] else selectedInstrument.instrumentId
                val book = matchingEngine.getOrderBook(instId)
                val bids = book.getBidsSnapshot(5)
                val asks = book.getAsksSnapshot(5)

                val sb = StringBuilder("=== LEVEL 2 ORDER BOOK: $instId ===\n")
                sb.append("ASKS (SELLERS):\n")
                asks.reversed().forEach { ask ->
                    sb.append("   ${String.format("£%.2f", ask.price)} | Qty: ${ask.aggregateQuantity.toInt()} t (${ask.orderCount} orders)\n")
                }
                sb.append("---------------------------------------\n")
                sb.append("BIDS (BUYERS):\n")
                bids.forEach { bid ->
                    sb.append("   ${String.format("£%.2f", bid.price)} | Qty: ${bid.aggregateQuantity.toInt()} t (${bid.orderCount} orders)\n")
                }
                sb.toString()
            }

            "BUY", "SELL" -> {
                // e.g. BUY 500 @ 213.00
                if (tokens.size < 4 || tokens[2] != "@") {
                    return "Usage: $cmd [quantity] @ [price] (e.g. $cmd 500 @ 213.00)"
                }
                val qty = tokens[1].toDoubleOrNull() ?: return "Invalid quantity '${tokens[1]}'"
                val price = tokens[3].toDoubleOrNull() ?: return "Invalid price '${tokens[3]}'"
                val side = if (cmd == "BUY") Side.BUY else Side.SELL

                val order = Order(
                    instrumentId = selectedInstrument.instrumentId,
                    participantId = currentParticipant.participantId,
                    side = side,
                    orderType = OrderType.LIMIT,
                    price = price,
                    originalQuantity = qty
                )

                val (status, err) = matchingEngine.submitOrder(order, selectedInstrument, currentParticipant)
                if (err != null) {
                    "ORDER REJECTED: $err"
                } else {
                    "ORDER SUBMITTED ($status): $cmd ${qty.toInt()} ${selectedInstrument.unit.symbol} @ £${String.format("%.2f", price)} (ID: ${order.orderId.take(8)})"
                }
            }

            "QUOTE" -> {
                val book = matchingEngine.getOrderBook(selectedInstrument.instrumentId)
                val bbo = book.getBbo(null, null, null)
                val bidStr = bbo.bestBidPrice?.let { "£${String.format("%.2f", it)} (${bbo.bestBidQuantity?.toInt()}t)" } ?: "NONE"
                val askStr = bbo.bestAskPrice?.let { "£${String.format("%.2f", it)} (${bbo.bestAskQuantity?.toInt()}t)" } ?: "NONE"
                val spreadStr = bbo.spread?.let { "Spread: £${String.format("%.2f", it)}" } ?: ""
                "BBO [${selectedInstrument.instrumentId}]: BID $bidStr | ASK $askStr | $spreadStr"
            }

            "TRADES" -> {
                val trades = matchingEngine.getTradesForInstrument(selectedInstrument.instrumentId).take(10)
                if (trades.isEmpty()) "No executed trades recorded yet."
                else trades.joinToString("\n") { t ->
                    "TRADE ${t.executionId} | ${String.format("£%.2f", t.price)} x ${t.quantity.toInt()} ${t.unit.symbol} | Buyer: ${t.buyerParticipantId} vs Seller: ${t.sellerParticipantId}"
                }
            }

            "POS" -> {
                val positions = matchingEngine.positionEngine.getAllPositionsForParticipant(currentParticipant.participantId)
                if (positions.isEmpty()) "No open positions for participant ${currentParticipant.name}."
                else positions.joinToString("\n") { pos ->
                    val pnlFormatted = String.format("%+.2f", pos.unrealisedPnL)
                    "• ${pos.instrumentId}: Net ${pos.netQuantity.toInt()} t @ Avg £${String.format("%.2f", pos.averagePrice)} | Unrealised P&L: £$pnlFormatted ${pos.currency}"
                }
            }

            "SIM" -> {
                val sub = tokens.getOrNull(1)?.uppercase() ?: "STATUS"
                when (sub) {
                    "START" -> {
                        simulator.startSimulation(selectedInstrument, ReferenceDataService.participants)
                        "MARKET SIMULATOR STARTED (Scenario: ${simulator.currentScenario})"
                    }
                    "STOP" -> {
                        simulator.stopSimulation()
                        "MARKET SIMULATOR STOPPED"
                    }
                    "NORMAL" -> {
                        simulator.currentScenario = SimulationScenario.NORMAL
                        "SCENARIO CHANGED TO NORMAL"
                    }
                    "SUPPLY_SHOCK" -> {
                        simulator.currentScenario = SimulationScenario.SUPPLY_SHOCK
                        "SCENARIO CHANGED TO SUPPLY SHOCK (Sellers Scarce / Price Spike)"
                    }
                    "HIGH_DEMAND" -> {
                        simulator.currentScenario = SimulationScenario.HIGH_DEMAND
                        "SCENARIO CHANGED TO HIGH DEMAND (Aggressive Buying)"
                    }
                    else -> "Simulator Running: ${simulator.isRunning} | Active Scenario: ${simulator.currentScenario}"
                }
            }

            "BENCHMARK" -> {
                val orderCount = tokens.getOrNull(1)?.toIntOrNull() ?: 2000
                val result = BenchmarkLab.runBenchmark(orderCount)
                """
                === BENCHMARK LAB RESULTS ===
                Orders Evaluated : ${result.totalOrders}
                Matches Executed : ${result.totalMatches}
                Total Run Time   : ${result.totalTimeMs} ms
                Orders / Second  : ${String.format("%,.0f", result.ordersPerSecond)} ops/sec
                Matches / Second : ${String.format("%,.0f", result.matchesPerSecond)} matches/sec
                Median Latency   : ${String.format("%.2f", result.medianLatencyUs)} μs
                P95 Latency      : ${String.format("%.2f", result.p95LatencyUs)} μs
                P99 Latency      : ${String.format("%.2f", result.p99LatencyUs)} μs
                """.trimIndent()
            }

            else -> "Unknown command '$cmd'. Type HELP for command list."
        }
    }
}

/**
 * Exposes OpenAPI 3.0 specification & Python / R client code generators
 */
object OpenApiExporter {

    fun getOpenApiJson(): String = """
    {
      "openapi": "3.0.3",
      "info": {
        "title": "RHINO MARKET API.OS",
        "description": "Institutional Spot Market Execution Engine API",
        "version": "1.0.0"
      },
      "servers": [{ "url": "https://api.rhinomarket.com/v1" }],
      "paths": {
        "/markets": {
          "get": {
            "summary": "Discover available commodity spot markets",
            "responses": { "200": { "description": "List of active markets" } }
          }
        },
        "/instruments/{id}/book": {
          "get": {
            "summary": "Retrieve Level 2 Order Book snapshot",
            "parameters": [{ "name": "id", "in": "path", "required": true, "schema": { "type": "string" } }],
            "responses": { "200": { "description": "Level 2 price depth" } }
          }
        },
        "/orders": {
          "post": {
            "summary": "Submit order to matching engine",
            "requestBody": {
              "required": true,
              "content": { "application/json": { "schema": { "type": "object", "properties": { "instrumentId": { "type": "string" }, "side": { "type": "string" }, "price": { "type": "number" }, "quantity": { "type": "number" } } } } }
            },
            "responses": { "200": { "description": "Order accepted / matched" } }
          }
        }
      }
    }
    """.trimIndent()

    fun getPythonClientSnippet(instrumentId: String): String = """
    # Rhino Market API Python Client
    import json
    import requests

    BASE_URL = "https://api.rhinomarket.com/v1"
    API_KEY = "rhino_sec_live_9a87f"

    headers = {"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"}

    # 1. Fetch Order Book
    response = requests.get(f"{BASE_URL}/instruments/$instrumentId/book", headers=headers)
    book = response.json()
    print("Best Bid:", book.get("bestBidPrice"), "| Best Ask:", book.get("bestAskPrice"))

    # 2. Submit Buy Order
    order_payload = {
        "instrumentId": "$instrumentId",
        "side": "BUY",
        "orderType": "LIMIT",
        "price": 213.00,
        "quantity": 500
    }
    trade_res = requests.post(f"{BASE_URL}/orders", json=order_payload, headers=headers)
    print("Order Result:", trade_res.json())
    """.trimIndent()

    fun getRClientSnippet(instrumentId: String): String =
        "# Rhino Market API R Research Client\n" +
        "library(httr)\n" +
        "library(jsonlite)\n\n" +
        "base_url <- \"https://api.rhinomarket.com/v1\"\n" +
        "res <- GET(paste0(base_url, \"/instruments/$instrumentId/trades\"))\n" +
        "trades <- fromJSON(content(res, \"text\"))\n\n" +
        "# Calculate VWAP\n" +
        "vwap <- sum(trades\$price * trades\$quantity) / sum(trades\$quantity)\n" +
        "cat(sprintf(\"Instrument %s VWAP: £%.2f\\n\", \"$instrumentId\", vwap))\n"
}
