# RHINOQUANT SARON - SWISS FRANC RATES TERMINAL

**RHINOQUANT SARON** is an institutional Swiss-franc interest-rate operating system centred on **SARON (Swiss Average Rate Overnight)**.

Designed for Swiss private banks, treasury desks, asset managers, pension funds, mortgage desks, and quantitative research teams, the platform provides complete market-data architecture, CHF money-market calculations, SARON compounding engines, OIS yield curve bootstrapping, repo analytics, SNB policy transmission modeling, options pricing (Black-76 and Bachelier), risk management (DV01, Key-Rate DV01s, Monte Carlo VaR/CVaR), and the **RhinoQuant Query Language (RQQL)** command palette.

---

## Key Features

1. **SARON Fixing Monitor**: Intraday rate timeline with 12:00, 16:00, and 18:00 official SIX benchmark fixings, repo volume (CHF Bn), quote counts, reference prices, and bid/ask spreads.
2. **SARON Compounding Engine**: Full ACT/360 daily compounding calculator supporting 1W, 1M, 2M, 3M, 6M, 12M, observation shifts, lookback windows, payment lags, Swiss Zurich bank holidays, and a day-by-day observation audit log.
3. **CHF SARON OIS Curve Bootstrapper**: Yield curve construction across ON to 30Y tenors calculating discount factors, zero rates, forward rates, DV01, and convexity.
4. **SNB Policy Terminal**: SNB policy rate vs SARON policy spread monitoring, sight deposit rates, SNB Bills, and transmission mechanism flow diagram.
5. **Swiss Repo & Collateral Analytics**: General Collateral (GC) vs Special repo rates, Swiss Confederation bond collateral valuation ($Collateral\_Value = Market\_Value \times (1 - Haircut)$), haircut schedules, and borrowing capacity optimization.
6. **Derivatives & Options Engine**: SARON OIS Swaps pricer (PV, NPV, Par Rate, DV01/PV01, cashflow schedules), 3M SARON Futures quarterly IMM strip, Caps/Floors & Swaptions pricer (Black-76 and Normal Bachelier models with full Greeks: Delta, Gamma, Vega, Theta, Rho, Volga, Vanna).
7. **Swiss Mortgage Terminal**: Floating SARON mortgage pricer ($Rate = SARON + Margin$), quarterly payment schedules, and rate shock sensitivity (+100bp).
8. **Portfolio Management & Risk**: Real-time Mark-to-Market, Total DV01, Key-Rate DV01 decomposition, 1000-draw Monte Carlo 1D Value-at-Risk (VaR 95%, 99%) and Expected Shortfall (CVaR).
9. **Scenario Stress Engine**: Presets for SNB policy shifts (+25bp, +50bp, -25bp), curve steepener/flattener, repo stress, and custom tenor shocks with instant portfolio repricing.
10. **RQQL Command Console**: Institutional command palette supporting `GET SARON`, `GET SARON COMPOUND(3M)`, `GET CHF OIS CURVE`, `PRICE SARON OIS 5Y`, `DV01 PORTFOLIO`, `STRESS SARON +50BP`, and `FORECAST SARON 12M`.
11. **Research Report Generator**: Automated "RHINOQUANT CHF RATES DAILY" institutional report exporter (PDF, CSV, JSON, Parquet).

---

## Technical Stack

- **Language**: Kotlin 1.9+
- **UI Framework**: Jetpack Compose (Material 3)
- **Architecture**: MVVM / Clean Architecture
- **Concurrency**: Coroutines & StateFlow
- **Theme**: Swiss Institutional Palette (Deep Navy `#0B132B`, Graphite `#151D33`, Swiss Red `#DC2626`, Steel Grey `#64748B`, Crisp Off-White `#F8FAFC`)

---

## Documentation Index

- `docs/ARCHITECTURE.md` - System & Software Architecture
- `docs/SARON.md` - SIX Swiss Exchange SARON Methodology
- `docs/COMPOUNDING.md` - ACT/360 Daily Compounding Mathematics
- `docs/CURVES.md` - CHF OIS Curve Bootstrapping & Interpolation
- `docs/OIS.md` - OIS Swap Pricing & Cashflows
- `docs/REPO.md` - Swiss Repo Market & Spreads
- `docs/COLLATERAL.md` - Collateral Valuation & Haircuts
- `docs/DERIVATIVES.md` - Futures, Caps, Floors & Swaptions
- `docs/RISK.md` - DV01, Key-Rate DV01s & Monte Carlo VaR
- `docs/SNB.md` - SNB Monetary Policy Transmission
- `docs/DATA_MODEL.md` - Strongly-Typed Quantitative Data Models
- `docs/MARKET_DATA.md` - Data Provenance & SIX Data Feed Architecture
- `docs/RQQL.md` - RhinoQuant Query Language Specification
- `docs/TESTING.md` - Quantitative Engine Unit Test Suite
- `docs/SECURITY.md` - Institutional Security & Provenance Controls
- `docs/DEPLOYMENT.md` - Build & Deployment Guide
