package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.saron.data.SaronMarketRepository
import com.example.saron.ui.components.TerminalHeader
import com.example.saron.ui.components.WorkspaceSelector
import com.example.saron.ui.workspaces.*
import com.example.saron.viewmodel.SaronTerminalViewModel
import com.example.saron.viewmodel.TerminalWorkspace
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            RhinoQuantSaronTheme {
                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("terminal_root_scaffold"),
                    containerColor = SwissNavyBackground
                ) { innerPadding ->
                    SaronTerminalApp(
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun SaronTerminalApp(
    viewModel: SaronTerminalViewModel = viewModel(),
    modifier: Modifier = Modifier
) {
    val activeWorkspace by viewModel.activeWorkspace.collectAsState()
    val saronRate by viewModel.repository.saronRate.collectAsState()
    val snbState by viewModel.repository.snbState.collectAsState()
    val rqqlInput by viewModel.rqqlInput.collectAsState()
    val riskSummary by viewModel.riskSummary.collectAsState()
    val activeScenario by viewModel.activeScenario.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SwissNavyBackground)
    ) {
        // Institutional Header Bar
        TerminalHeader(
            saronRate = saronRate,
            snbRate = snbState.policyRatePct,
            rqqlQuery = rqqlInput,
            onExecuteRqql = { query -> viewModel.executeRqql(query) },
            modifier = Modifier.testTag("terminal_header_bar")
        )

        // Workspace Navigation Tab Bar
        WorkspaceSelector(
            activeWorkspace = activeWorkspace,
            onWorkspaceSelected = { workspace -> viewModel.setWorkspace(workspace) },
            modifier = Modifier.testTag("workspace_selector_tabs")
        )

        // Main Workspace Display Container
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            when (activeWorkspace) {
                TerminalWorkspace.OVERVIEW -> OverviewWorkspace(viewModel = viewModel)
                TerminalWorkspace.FIXINGS -> FixingsWorkspace(viewModel = viewModel)
                TerminalWorkspace.COMPOUNDING -> CompoundingWorkspace(viewModel = viewModel)
                TerminalWorkspace.OIS_CURVE -> CurveWorkspace(viewModel = viewModel)
                TerminalWorkspace.REPO_COLLATERAL -> RepoCollateralWorkspace(viewModel = viewModel)
                TerminalWorkspace.DERIVATIVES -> DerivativesWorkspace(viewModel = viewModel)
                TerminalWorkspace.SNB_POLICY -> SnbWorkspace(viewModel = viewModel)
                TerminalWorkspace.MORTGAGES -> MortgageWorkspace(viewModel = viewModel)
                TerminalWorkspace.PORTFOLIO_RISK -> PortfolioRiskWorkspace(viewModel = viewModel)
                TerminalWorkspace.SCENARIOS -> ScenarioWorkspace(viewModel = viewModel)
                TerminalWorkspace.RQQL_CONSOLE -> RqqlWorkspace(viewModel = viewModel)
                TerminalWorkspace.RESEARCH_REPORT -> ResearchReportWorkspace(viewModel = viewModel)
            }
        }

        // Terminal Institutional Bottom Status Bar
        TerminalBottomStatusBar(
            totalDv01 = riskSummary?.totalDv01Chf ?: 0.0,
            policySpreadBp = snbState.policySpreadBp,
            activeScenarioName = activeScenario?.name ?: "BASE CASE"
        )
    }
}

@Composable
fun TerminalBottomStatusBar(
    totalDv01: Double,
    policySpreadBp: Double,
    activeScenarioName: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(SwissSurfaceDark)
            .border(1.dp, SwissBorder)
            .padding(horizontal = 10.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatusItem("TOTAL DV01", "CHF ${String.format("%,.0f", totalDv01)}", SwissGreenPositive)
            StatusItem("POLICY SPREAD", "${String.format("%.1f", policySpreadBp)} bp", SwissAccentBlue)
            StatusItem("SCENARIO", activeScenarioName, SwissAmberWarning)
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(SwissGreenPositive, androidx.compose.foundation.shape.CircleShape)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "SIX REPO FEED: ONLINE (0.01ms)",
                color = SwissTextMuted,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun StatusItem(
    label: String,
    value: String,
    color: Color
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("$label: ", color = SwissTextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        Text(value, color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}
