package com.example.saron.ui.workspaces

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.saron.data.SaronMarketRepository
import com.example.saron.model.StressScenario
import com.example.saron.viewmodel.SaronTerminalViewModel
import com.example.ui.theme.*

@Composable
fun ScenarioWorkspace(
    viewModel: SaronTerminalViewModel,
    modifier: Modifier = Modifier
) {
    val activeScenario by viewModel.activeScenario.collectAsState()
    val positions by viewModel.repository.portfolioPositions.collectAsState()

    val presetScenarios = listOf(
        StressScenario("SCEN-SNB-25UP", "SNB Policy +25 bp", "25 bps rate hike by SNB", snbShiftBp = 25.0, saronShiftBp = 25.0),
        StressScenario("SCEN-SNB-50UP", "SNB Policy +50 bp", "50 bps emergency tightening by SNB", snbShiftBp = 50.0, saronShiftBp = 50.0),
        StressScenario("SCEN-SNB-25DN", "SNB Policy -25 bp", "25 bps rate cut by SNB", snbShiftBp = -25.0, saronShiftBp = -25.0),
        StressScenario("SCEN-STEEPENER", "CHF Curve Steepener", "Short end flat, 10Y/30Y yields rise +30bp", curveShiftType = "Steepener", tenorShocksBp = mapOf("POS-OIS-10Y" to 30.0)),
        StressScenario("SCEN-REPO-STRESS", "Swiss Repo Liquidity Shock", "Repo spreads widen +15 bps", curveShiftType = "RepoStress", saronShiftBp = 15.0)
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Text(
                text = "SWISS RATES STRESS TESTING & MACRO SCENARIO ENGINE",
                color = SwissTextLight,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SwissSurfaceDark, RoundedCornerShape(4.dp))
                    .border(1.dp, SwissBorder, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Text(
                    text = "SELECT INSTITUTIONAL PRESET SHOCK SCENARIO",
                    color = SwissTextMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    presetScenarios.forEach { sc ->
                        val isSel = activeScenario?.id == sc.id
                        Button(
                            onClick = {
                                if (isSel) viewModel.clearScenario() else viewModel.applyStressScenario(sc)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSel) SwissRedPrimary else SwissNavyBackground,
                                contentColor = SwissTextLight
                            ),
                            shape = RoundedCornerShape(2.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("scenario_preset_btn_${sc.id.lowercase()}")
                        ) {
                            Text(
                                text = sc.name,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        item {
            activeScenario?.let { sc ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SwissNavyBackground, RoundedCornerShape(4.dp))
                        .border(1.dp, SwissRedPrimary, RoundedCornerShape(4.dp))
                        .padding(10.dp)
                        .testTag("active_scenario_summary_box")
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ACTIVE SCENARIO: ${sc.name.uppercase()}",
                            color = SwissRedPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Button(
                            onClick = { viewModel.clearScenario() },
                            colors = ButtonDefaults.buttonColors(containerColor = SwissSurfaceVariant),
                            shape = RoundedCornerShape(2.dp),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("RESET SCENARIO", fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                    Text(
                        text = sc.description,
                        color = SwissTextLight,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        item {
            Text(
                text = "REPRICED PORTFOLIO UNDER ACTIVE SCENARIO SHOCK",
                color = SwissTextLight,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SwissSurfaceDark)
                    .padding(6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TableHeader("POSITION", Modifier.weight(1.4f))
                TableHeader("NOTIONAL", Modifier.weight(1.2f))
                TableHeader("ENTRY RATE", Modifier.weight(1f))
                TableHeader("SHOCKED RATE", Modifier.weight(1.1f))
                TableHeader("REPRICED PV", Modifier.weight(1.3f))
                TableHeader("ESTIMATED P&L IMPACT", Modifier.weight(1.4f))
            }
        }

        items(positions) { pos ->
            val totalShiftBp = (activeScenario?.saronShiftBp ?: 0.0) + (activeScenario?.snbShiftBp ?: 0.0) + (activeScenario?.tenorShocksBp?.get(pos.name) ?: 0.0)
            val pnlImpact = pos.dv01Chf * totalShiftBp

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 3.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TableCell(pos.name, Modifier.weight(1.4f), isBold = true)
                TableCell("CHF ${String.format("%,d", pos.notionalChf.toLong())}", Modifier.weight(1.2f))
                TableCell("${String.format("%.2f", pos.entryRatePct)}%", Modifier.weight(1f))
                TableCell("${String.format("%.2f", pos.entryRatePct + (totalShiftBp / 100.0))}%", Modifier.weight(1.1f), color = SwissAmberWarning)
                TableCell("CHF ${String.format("%,.0f", pos.presentValueChf + pnlImpact)}", Modifier.weight(1.3f))
                TableCell("CHF ${String.format("%,.2f", pnlImpact)}", Modifier.weight(1.4f), color = if (pnlImpact >= 0.0) SwissGreenPositive else SwissRedPrimary, isBold = true)
            }
        }
    }
}
