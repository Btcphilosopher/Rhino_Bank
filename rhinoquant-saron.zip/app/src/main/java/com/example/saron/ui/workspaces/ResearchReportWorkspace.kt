package com.example.saron.ui.workspaces

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.saron.data.SaronMarketRepository
import com.example.saron.viewmodel.SaronTerminalViewModel
import com.example.ui.theme.*
import java.time.LocalDate

@Composable
fun ResearchReportWorkspace(
    viewModel: SaronTerminalViewModel,
    modifier: Modifier = Modifier
) {
    val saronRate by viewModel.repository.saronRate.collectAsState()
    val snbState by viewModel.repository.snbState.collectAsState()
    val compResult by viewModel.compResult.collectAsState()

    var exportFormat by remember { mutableStateOf("PDF") }
    var exportStatusText by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "AUTOMATED INSTITUTIONAL RESEARCH REPORT GENERATOR",
                    color = SwissTextLight,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("PDF", "CSV", "JSON", "PARQUET").forEach { fmt ->
                        val isSel = exportFormat == fmt
                        Button(
                            onClick = {
                                exportFormat = fmt
                                exportStatusText = "Exported RHINOQUANT CHF RATES DAILY as $fmt file to local storage"
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = if (isSel) SwissRedPrimary else SwissNavyBackground),
                            shape = RoundedCornerShape(2.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.testTag("report_export_btn_$fmt")
                        ) {
                            Text(fmt, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        exportStatusText?.let { status ->
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SwissGreenPositive.copy(alpha = 0.2f))
                        .border(1.dp, SwissGreenPositive)
                        .padding(6.dp)
                ) {
                    Text(status, color = SwissGreenPositive, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
            }
        }

        item {
            // Report document preview
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SwissNavyBackground, RoundedCornerShape(4.dp))
                    .border(1.dp, SwissBorder, RoundedCornerShape(4.dp))
                    .padding(14.dp)
                    .testTag("research_report_preview_box")
            ) {
                Text("RHINOQUANT CHF RATES DAILY REPORT", color = SwissRedPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp, fontFamily = FontFamily.Monospace)
                Text("VALUATION DATE: ${LocalDate.now()} | ZURICH / BASEL QUANT RESEARCH DESK", color = SwissTextMuted, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                Spacer(modifier = Modifier.height(10.dp))

                Text("1. SARON OVERNIGHT BENCHMARK", color = SwissTextLight, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                Text("The official SIX SARON 18:00 fixing stood at ${String.format("%.4f", saronRate)}% with CHF 8.42 Billion in traded repo volume across 142 transactions. Intraday volatility remained tight at 1.2 bps.", color = SwissTextMuted, fontSize = 11.sp, fontFamily = FontFamily.Monospace)

                Spacer(modifier = Modifier.height(8.dp))
                Text("2. SNB MONETARY POLICY & SPREADS", color = SwissTextLight, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                Text("SNB Policy Target rate is ${snbState.policyRatePct}%. SARON policy spread is ${String.format("%.1f", snbState.policySpreadBp)} bp. Regime classification: ${snbState.regimeName}.", color = SwissTextMuted, fontSize = 11.sp, fontFamily = FontFamily.Monospace)

                Spacer(modifier = Modifier.height(8.dp))
                Text("3. COMPOUNDED SARON RATES", color = SwissTextLight, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                Text("3-Month Compounded SARON stands at ${compResult?.let { String.format("%.4f", it.compoundedRatePct) } ?: "0.9545"}% under ACT/360 day-count rules. Total accrued interest on CHF 100M portfolio: CHF ${compResult?.let { String.format("%,.2f", it.totalAccruedInterestChf) } ?: "241,125"}.", color = SwissTextMuted, fontSize = 11.sp, fontFamily = FontFamily.Monospace)

                Spacer(modifier = Modifier.height(8.dp))
                Text("4. CHF OIS YIELD CURVE & DERIVATIVES", color = SwissTextLight, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                Text("The OIS curve exhibits a slight upward slope from 0.95% ON to 1.15% 5Y and 1.40% 30Y. 3M SARON Futures Sep26 contracts imply 1.050% average overnight rate.", color = SwissTextMuted, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}
