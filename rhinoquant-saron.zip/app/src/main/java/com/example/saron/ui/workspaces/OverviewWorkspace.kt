package com.example.saron.ui.workspaces

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.saron.data.SaronMarketRepository
import com.example.saron.ui.components.OisCurveChart
import com.example.saron.viewmodel.SaronTerminalViewModel
import com.example.saron.viewmodel.TerminalWorkspace
import com.example.ui.theme.*

@Composable
fun OverviewWorkspace(
    viewModel: SaronTerminalViewModel,
    modifier: Modifier = Modifier
) {
    val saronRate by viewModel.repository.saronRate.collectAsState()
    val snbState by viewModel.repository.snbState.collectAsState()
    val curvePoints by viewModel.repository.curvePoints.collectAsState()
    val compResult by viewModel.compResult.collectAsState()
    val riskSummary by viewModel.riskSummary.collectAsState()
    val rqqlResult by viewModel.rqqlResult.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Executive Metrics Bar
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricCard(
                    title = "SARON 18:00 FIXING",
                    value = "${String.format("%.4f", saronRate)}%",
                    subtitle = "Official SIX Benchmark",
                    statusText = "FIXED",
                    statusColor = SwissGreenPositive,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "SNB POLICY RATE",
                    value = "${String.format("%.2f", snbState.policyRatePct)}%",
                    subtitle = "Policy Spread: ${String.format("%.1f", snbState.policySpreadBp)} bp",
                    statusText = snbState.regimeName,
                    statusColor = SwissAccentBlue,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "COMPOUNDED SARON (3M)",
                    value = "${compResult?.let { String.format("%.4f", it.compoundedRatePct) } ?: "0.9545"}%",
                    subtitle = "ACT/360 | CHF 100M",
                    statusText = "AUDITED",
                    statusColor = SwissAmberWarning,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "PORTFOLIO DV01",
                    value = "CHF ${riskSummary?.let { String.format("%,.0f", it.totalDv01Chf) } ?: "2,250"}",
                    subtitle = "1D VaR 99%: CHF ${riskSummary?.let { String.format("%,.0f", it.var99Chf) } ?: "12,400"}",
                    statusText = "RISK OK",
                    statusColor = SwissGreenPositive,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Main OIS Yield Curve Chart Section
        item {
            OisCurveChart(
                curvePoints = curvePoints,
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Market Quick Action Bar & RQQL Result Panel
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SwissSurfaceDark, RoundedCornerShape(4.dp))
                    .border(1.dp, SwissBorder, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "TERMINAL QUICK MODULE SWITCH",
                        color = SwissTextLight,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        QuickNavButton("SARON FIXINGS") { viewModel.setWorkspace(TerminalWorkspace.FIXINGS) }
                        QuickNavButton("COMPOUND CALCULATOR") { viewModel.setWorkspace(TerminalWorkspace.COMPOUNDING) }
                        QuickNavButton("OIS BOOTSTRAP") { viewModel.setWorkspace(TerminalWorkspace.OIS_CURVE) }
                        QuickNavButton("PORTFOLIO RISK") { viewModel.setWorkspace(TerminalWorkspace.PORTFOLIO_RISK) }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // RQQL Console Output Display
                rqqlResult?.let { res ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(SwissNavyBackground, RoundedCornerShape(2.dp))
                            .border(1.dp, SwissBorder, RoundedCornerShape(2.dp))
                            .padding(8.dp)
                            .testTag("overview_rqql_output_box")
                    ) {
                        Column {
                            Text(
                                text = "RQQL CONSOLE OUTPUT [${res.command}]:",
                                color = SwissRedPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = res.summaryText,
                                color = SwissTextLight,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetricCard(
    title: String,
    value: String,
    subtitle: String,
    statusText: String,
    statusColor: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .background(SwissSurfaceDark, RoundedCornerShape(4.dp))
            .border(1.dp, SwissBorder, RoundedCornerShape(4.dp))
            .padding(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                color = SwissTextMuted,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )
            Box(
                modifier = Modifier
                    .background(statusColor.copy(alpha = 0.2f), RoundedCornerShape(2.dp))
                    .padding(horizontal = 4.dp, vertical = 1.dp)
            ) {
                Text(
                    text = statusText,
                    color = statusColor,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = value,
            color = SwissTextLight,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = subtitle,
            color = SwissSteelGrey,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun QuickNavButton(
    label: String,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = SwissSurfaceVariant,
            contentColor = SwissTextLight
        ),
        shape = RoundedCornerShape(2.dp),
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = label,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}
