package com.example.saron.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.saron.viewmodel.TerminalWorkspace
import com.example.ui.theme.*

@Composable
fun WorkspaceSelector(
    activeWorkspace: TerminalWorkspace,
    onWorkspaceSelected: (TerminalWorkspace) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(SwissNavyBackground)
            .border(1.dp, SwissBorder)
            .horizontalScroll(scrollState)
            .padding(horizontal = 4.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        TerminalWorkspace.values().forEach { workspace ->
            val isSelected = workspace == activeWorkspace
            val label = when (workspace) {
                TerminalWorkspace.OVERVIEW -> "OVERVIEW"
                TerminalWorkspace.FIXINGS -> "FIXINGS (18:00)"
                TerminalWorkspace.COMPOUNDING -> "COMPOUNDING"
                TerminalWorkspace.OIS_CURVE -> "OIS CURVE"
                TerminalWorkspace.REPO_COLLATERAL -> "REPO & COLLATERAL"
                TerminalWorkspace.DERIVATIVES -> "DERIVATIVES"
                TerminalWorkspace.SNB_POLICY -> "SNB POLICY"
                TerminalWorkspace.MORTGAGES -> "MORTGAGES"
                TerminalWorkspace.PORTFOLIO_RISK -> "PORTFOLIO & RISK"
                TerminalWorkspace.SCENARIOS -> "SCENARIOS"
                TerminalWorkspace.RQQL_CONSOLE -> "RQQL CONSOLE"
                TerminalWorkspace.RESEARCH_REPORT -> "RESEARCH REPORT"
            }

            Box(
                modifier = Modifier
                    .background(
                        if (isSelected) SwissRedPrimary else SwissSurfaceDark,
                        RoundedCornerShape(2.dp)
                    )
                    .border(
                        1.dp,
                        if (isSelected) SwissRedDark else SwissBorder,
                        RoundedCornerShape(2.dp)
                    )
                    .clickable { onWorkspaceSelected(workspace) }
                    .padding(horizontal = 10.dp, vertical = 6.dp)
                    .testTag("workspace_tab_${workspace.name.lowercase()}"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = label,
                    color = if (isSelected) Color.White else SwissTextMuted,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
