package com.example.saron.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun TerminalHeader(
    saronRate: Double,
    snbRate: Double,
    rqqlQuery: String,
    onExecuteRqql: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchText by remember { mutableStateOf(rqqlQuery) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(SwissSurfaceDark)
            .border(1.dp, SwissBorder)
            .padding(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Swiss Cross Accent Badge
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .background(SwissRedPrimary, RoundedCornerShape(2.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "+",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "RHINOQUANT SARON",
                    color = SwissTextLight,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.testTag("app_title_text")
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "SWISS FRANC RATES TERMINAL",
                    color = SwissTextMuted,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Live Benchmark Badges
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                HeaderTickerBadge(
                    label = "18:00 FIXING",
                    value = "${String.format("%.4f", saronRate)}%",
                    badgeColor = SwissGreenPositive
                )
                HeaderTickerBadge(
                    label = "SNB TARGET",
                    value = "${String.format("%.2f", snbRate)}%",
                    badgeColor = SwissAccentBlue
                )
                HeaderTickerBadge(
                    label = "STATUS",
                    value = "SIMULATED DEMO",
                    badgeColor = SwissAmberWarning
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // RQQL Quick Command Palette Line
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(SwissNavyBackground, RoundedCornerShape(4.dp))
                .border(1.dp, SwissBorder, RoundedCornerShape(4.dp))
                .padding(horizontal = 8.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "RQQL>",
                color = SwissRedPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.width(8.dp))
            OutlinedTextField(
                value = searchText,
                onValueChange = { searchText = it },
                placeholder = {
                    Text(
                        "Enter RQQL command (e.g., GET SARON COMPOUND(3M), PRICE SARON OIS 5Y, STRESS SARON +50BP)",
                        color = SwissSteelGrey,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                },
                modifier = Modifier
                    .weight(1f)
                    .height(40.dp)
                    .testTag("rqql_header_input"),
                textStyle = LocalTextStyle.current.copy(
                    color = SwissTextLight,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                ),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color.Transparent,
                    unfocusedBorderColor = Color.Transparent,
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent
                )
            )
            IconButton(
                onClick = { onExecuteRqql(searchText) },
                modifier = Modifier
                    .size(32.dp)
                    .testTag("rqql_execute_button")
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Execute RQQL Command",
                    tint = SwissGreenPositive
                )
            }
        }
    }
}

@Composable
fun HeaderTickerBadge(
    label: String,
    value: String,
    badgeColor: Color
) {
    Row(
        modifier = Modifier
            .background(SwissNavyBackground, RoundedCornerShape(2.dp))
            .border(1.dp, SwissBorder, RoundedCornerShape(2.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .background(badgeColor, RoundedCornerShape(3.dp))
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = "$label: ",
            color = SwissTextMuted,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = value,
            color = SwissTextLight,
            fontWeight = FontWeight.Bold,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}
