package com.example.saron.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.saron.data.SaronMarketRepository
import com.example.saron.model.*
import com.example.saron.quant.RqqlParser
import com.example.saron.quant.SaronCompoundingEngine
import com.example.saron.quant.RiskAndScenarioEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.LocalDate

enum class TerminalWorkspace {
    OVERVIEW,
    FIXINGS,
    COMPOUNDING,
    OIS_CURVE,
    REPO_COLLATERAL,
    DERIVATIVES,
    SNB_POLICY,
    MORTGAGES,
    PORTFOLIO_RISK,
    SCENARIOS,
    RQQL_CONSOLE,
    RESEARCH_REPORT
}

class SaronTerminalViewModel(
    val repository: SaronMarketRepository = SaronMarketRepository()
) : ViewModel() {

    private val _activeWorkspace = MutableStateFlow(TerminalWorkspace.OVERVIEW)
    val activeWorkspace: StateFlow<TerminalWorkspace> = _activeWorkspace.asStateFlow()

    // Compounding Calculator State
    private val _compStart = MutableStateFlow(LocalDate.now().minusMonths(3))
    val compStart = _compStart.asStateFlow()

    private val _compEnd = MutableStateFlow(LocalDate.now())
    val compEnd = _compEnd.asStateFlow()

    private val _compNotional = MutableStateFlow(100_000_000.0)
    val compNotional = _compNotional.asStateFlow()

    private val _compTenorLabel = MutableStateFlow("3M")
    val compTenorLabel = _compTenorLabel.asStateFlow()

    private val _compObservationShift = MutableStateFlow(0)
    val compObservationShift = _compObservationShift.asStateFlow()

    private val _compLookback = MutableStateFlow(0)
    val compLookback = _compLookback.asStateFlow()

    private val _compResult = MutableStateFlow<SaronCompoundedResult?>(null)
    val compResult = _compResult.asStateFlow()

    // RQQL Terminal State
    private val _rqqlInput = MutableStateFlow("GET SARON COMPOUND(3M)")
    val rqqlInput = _rqqlInput.asStateFlow()

    private val _rqqlResult = MutableStateFlow<RqqlCommandResult?>(null)
    val rqqlResult = _rqqlResult.asStateFlow()

    // Active Stress Scenario
    private val _activeScenario = MutableStateFlow<StressScenario?>(null)
    val activeScenario = _activeScenario.asStateFlow()

    // Portfolio Risk
    private val _riskSummary = MutableStateFlow<RiskSummary?>(null)
    val riskSummary = _riskSummary.asStateFlow()

    init {
        recalculateCompounding()
        recalculateRisk()
        executeRqql("GET SARON COMPOUND(3M)")
    }

    fun setWorkspace(workspace: TerminalWorkspace) {
        _activeWorkspace.value = workspace
    }

    fun updateCompoundingParams(
        start: LocalDate? = null,
        end: LocalDate? = null,
        notional: Double? = null,
        tenor: String? = null,
        shift: Int? = null,
        lookback: Int? = null
    ) {
        start?.let { _compStart.value = it }
        end?.let { _compEnd.value = it }
        notional?.let { _compNotional.value = it }
        tenor?.let { _compTenorLabel.value = it }
        shift?.let { _compObservationShift.value = it }
        lookback?.let { _compLookback.value = it }

        recalculateCompounding()
    }

    fun applyTenorPreset(tenor: String) {
        _compTenorLabel.value = tenor
        val today = LocalDate.now()
        val start = when (tenor) {
            "1W" -> today.minusWeeks(1)
            "1M" -> today.minusMonths(1)
            "2M" -> today.minusMonths(2)
            "3M" -> today.minusMonths(3)
            "6M" -> today.minusMonths(6)
            "12M" -> today.minusYears(1)
            else -> today.minusMonths(3)
        }
        _compStart.value = start
        _compEnd.value = today
        recalculateCompounding()
    }

    fun recalculateCompounding() {
        viewModelScope.launch {
            val result = SaronCompoundingEngine.calculateCompoundedRate(
                startDate = _compStart.value,
                endDate = _compEnd.value,
                notionalChf = _compNotional.value,
                tenorLabel = _compTenorLabel.value,
                observationShiftDays = _compObservationShift.value,
                lookbackDays = _compLookback.value,
                defaultRate = repository.saronRate.value
            )
            _compResult.value = result
        }
    }

    fun executeRqql(query: String) {
        _rqqlInput.value = query
        val result = RqqlParser.executeQuery(
            queryInput = query,
            currentSaronRate = repository.saronRate.value,
            curvePoints = repository.curvePoints.value,
            positions = repository.portfolioPositions.value
        )
        _rqqlResult.value = result
    }

    fun applyStressScenario(scenario: StressScenario) {
        _activeScenario.value = scenario
        val repriced = RiskAndScenarioEngine.repricePortfolioUnderScenario(
            repository.portfolioPositions.value,
            scenario
        )
        _riskSummary.value = RiskAndScenarioEngine.calculatePortfolioRisk(repriced)
    }

    fun clearScenario() {
        _activeScenario.value = null
        recalculateRisk()
    }

    fun recalculateRisk() {
        viewModelScope.launch {
            _riskSummary.value = RiskAndScenarioEngine.calculatePortfolioRisk(
                repository.portfolioPositions.value
            )
        }
    }

    fun executeNewTrade(
        category: InstrumentCategory,
        name: String,
        side: String,
        notional: Double,
        ratePct: Double
    ) {
        val newPos = PortfolioPosition(
            id = "TRADE-${System.currentTimeMillis() % 10000}",
            category = category,
            name = name,
            side = side,
            notionalChf = notional,
            entryRatePct = ratePct,
            currentMarkRatePct = ratePct,
            presentValueChf = 0.0,
            dv01Chf = notional * 0.0001 * 5.0, // 5Y duration approx
            vegaChf = 0.0,
            pnlTodayChf = 0.0,
            pnlMtdChf = 0.0,
            pnlYtdChf = 0.0
        )
        repository.addTradePosition(newPos)
        recalculateRisk()
    }
}
