package com.example.saron.ui.workspaces

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.saron.viewmodel.SaronTerminalViewModel
import com.example.ui.theme.*

@Composable
fun CompoundingWorkspace(
    viewModel: SaronTerminalViewModel,
    modifier: Modifier = Modifier
) {
    val compStart by viewModel.compStart.collectAsState()
    val compEnd by viewModel.compEnd.collectAsState()
    val compNotional by viewModel.compNotional.collectAsState()
    val compTenorLabel by viewModel.compTenorLabel.collectAsState()
    val compShift by viewModel.compObservationShift.collectAsState()
    val compLookback by viewModel.compLookback.collectAsState()
    val compResult by viewModel.compResult.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            // Tenor Presets Selector
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SwissSurfaceDark, RoundedCornerShape(4.dp))
                    .border(1.dp, SwissBorder, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Text(
                    text = "SELECT STANDARD SARON COMPOUND TENOR PRESET",
                    color = SwissTextLight,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("1W", "1M", "2M", "3M", "6M", "12M").forEach { tenor ->
                        val isSel = compTenorLabel == tenor
                        Button(
                            onClick = { viewModel.applyTenorPreset(tenor) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSel) SwissRedPrimary else SwissNavyBackground,
                                contentColor = SwissTextLight
                            ),
                            shape = RoundedCornerShape(2.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("compounding_tenor_btn_$tenor")
                        ) {
                            Text(
                                text = tenor,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        item {
            // Compounding Result Display Box
            compResult?.let { res ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SwissNavyBackground, RoundedCornerShape(4.dp))
                        .border(1.dp, SwissRedPrimary, RoundedCornerShape(4.dp))
                        .padding(12.dp)
                        .testTag("compounding_result_container")
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "COMPOUNDED SARON RATE (${res.tenorLabel})",
                                color = SwissTextMuted,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "${String.format("%.4f", res.compoundedRatePct)}%",
                                color = SwissGreenPositive,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.testTag("compounded_rate_value_text")
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "TOTAL ACCRUED INTEREST",
                                color = SwissTextMuted,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "CHF ${String.format("%,.2f", res.totalAccruedInterestChf)}",
                                color = SwissTextLight,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "PERIOD: ${res.startDate} to ${res.endDate} | NOTIONAL: CHF ${String.format("%,d", res.notionalChf.toLong())} | CALENDAR DAYS: ${res.totalCalendarDays} | BUSINESS DAYS: ${res.totalBusinessDays} | ACT/360 CONVENTION",
                        color = SwissSteelGrey,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        item {
            // Daily Observation Breakdown Table Header
            Text(
                text = "DAILY SARON OBSERVATION AUDIT BREAKDOWN (DAY-BY-DAY AUDIT TRAIL)",
                color = SwissTextLight,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SwissSurfaceDark)
                    .padding(6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TableHeader("DATE", Modifier.weight(1.1f))
                TableHeader("DAY", Modifier.weight(0.9f))
                TableHeader("SARON (%)", Modifier.weight(1f))
                TableHeader("DAYS (n_i)", Modifier.weight(0.9f))
                TableHeader("MULTIPLIER", Modifier.weight(1.2f))
                TableHeader("CUMULATIVE FACTOR", Modifier.weight(1.3f))
                TableHeader("ACCRUED (CHF)", Modifier.weight(1.3f))
            }
        }

        compResult?.dailyAudits?.take(20)?.let { audits ->
            items(audits) { audit ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 6.dp, vertical = 3.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TableCell(audit.date.toString(), Modifier.weight(1.1f))
                    TableCell(audit.dayOfWeek.take(3), Modifier.weight(0.9f))
                    TableCell("${String.format("%.4f", audit.saronRatePct)}%", Modifier.weight(1f), isBold = true, color = SwissGreenPositive)
                    TableCell("${audit.calendarDaysWeight}", Modifier.weight(0.9f))
                    TableCell(String.format("%.7f", audit.dailyMultiplier), Modifier.weight(1.2f))
                    TableCell(String.format("%.7f", audit.cumulativeCompoundedFactor), Modifier.weight(1.3f))
                    TableCell("CHF ${String.format("%,.2f", audit.accruedInterestChf)}", Modifier.weight(1.3f))
                }
            }
        }
    }
}
