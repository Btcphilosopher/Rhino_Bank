package com.example.saron.ui.workspaces

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.saron.viewmodel.SaronTerminalViewModel
import com.example.ui.theme.*

@Composable
fun RqqlWorkspace(
    viewModel: SaronTerminalViewModel,
    modifier: Modifier = Modifier
) {
    val rqqlInput by viewModel.rqqlInput.collectAsState()
    val rqqlResult by viewModel.rqqlResult.collectAsState()

    var textInput by remember { mutableStateOf(rqqlInput) }

    val sampleQueries = listOf(
        "GET SARON",
        "GET SARON(18:00)",
        "GET SARON COMPOUND(3M)",
        "GET CHF OIS CURVE",
        "GET SARON VS SNB",
        "PRICE SARON OIS 5Y",
        "DV01 PORTFOLIO",
        "STRESS SARON +50BP",
        "FORECAST SARON 12M"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Text(
                text = "RHINOQUANT QUANTITATIVE QUERY LANGUAGE (RQQL) CONSOLE",
                color = SwissTextLight,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        item {
            // Command Input Box
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SwissNavyBackground, RoundedCornerShape(4.dp))
                    .border(1.dp, SwissRedPrimary, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("RQQL>", color = SwissRedPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedTextField(
                        value = textInput,
                        onValueChange = { textInput = it },
                        modifier = Modifier.weight(1f).testTag("rqql_console_text_input"),
                        textStyle = LocalTextStyle.current.copy(color = SwissTextLight, fontSize = 13.sp, fontFamily = FontFamily.Monospace),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { viewModel.executeRqql(textInput) },
                        colors = ButtonDefaults.buttonColors(containerColor = SwissGreenPositive),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier.testTag("rqql_console_submit_btn")
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "Run Query", tint = SwissNavyBackground)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("EXECUTE", color = SwissNavyBackground, fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        item {
            // Quick Sample Queries Bar
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SwissSurfaceDark, RoundedCornerShape(4.dp))
                    .border(1.dp, SwissBorder, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Text("QUICK SAMPLE QUERIES (CLICK TO RUN)", color = SwissTextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    sampleQueries.take(5).forEach { q ->
                        Button(
                            onClick = {
                                textInput = q
                                viewModel.executeRqql(q)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = SwissSurfaceVariant),
                            shape = RoundedCornerShape(2.dp),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            modifier = Modifier.testTag("rqql_sample_btn_${q.replace(" ", "_")}")
                        ) {
                            Text(q, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        item {
            // RQQL Result Table Output
            rqqlResult?.let { res ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SwissSurfaceDark, RoundedCornerShape(4.dp))
                        .border(1.dp, SwissBorder, RoundedCornerShape(4.dp))
                        .padding(10.dp)
                        .testTag("rqql_console_result_box")
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("QUERY: ${res.command}", color = SwissRedPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                        Text("EXECUTION TIME: ${res.executionTimeMs} ms", color = SwissSteelGrey, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(res.summaryText, color = SwissTextLight, fontWeight = FontWeight.Bold, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(8.dp))

                    if (res.tableHeaders.isNotEmpty()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(SwissNavyBackground)
                                .padding(6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            res.tableHeaders.forEach { h ->
                                TableHeader(h, Modifier.weight(1f))
                            }
                        }

                        res.tableRows.forEach { row ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 6.dp, vertical = 3.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                row.forEachIndexed { idx, cell ->
                                    TableCell(cell, Modifier.weight(1f), isBold = (idx == 0))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
