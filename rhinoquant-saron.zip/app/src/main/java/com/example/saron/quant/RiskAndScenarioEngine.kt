package com.example.saron.quant

import com.example.saron.model.PortfolioPosition
import com.example.saron.model.RiskSummary
import com.example.saron.model.StressScenario
import kotlin.math.abs
import kotlin.math.sqrt
import java.util.Random

/**
 * Institutional Portfolio Risk & Scenario Engine.
 * Calculates:
 * - DV01 (Dollar Value of a 1bp rate shift)
 * - Key-Rate DV01s across 1M, 3M, 1Y, 2Y, 5Y, 10Y, 30Y
 * - Portfolio Vega & Gamma
 * - Monte Carlo Value-at-Risk (VaR 95%, 99%) & Expected Shortfall (CVaR)
 * - Scenario Shock repricing
 */
object RiskAndScenarioEngine {

    /**
     * Aggregates risk metrics across all portfolio positions.
     */
    fun calculatePortfolioRisk(
        positions: List<PortfolioPosition>
    ): RiskSummary {
        var totalNotional = 0.0
        var totalPv = 0.0
        var totalDv01 = 0.0
        var saronDv01 = 0.0
        var govtDv01 = 0.0
        var basisDv01 = 0.0
        var totalVega = 0.0

        val keyRates = mutableMapOf(
            "1M" to 0.0,
            "3M" to 0.0,
            "1Y" to 0.0,
            "2Y" to 0.0,
            "5Y" to 0.0,
            "10Y" to 0.0,
            "30Y" to 0.0
        )

        for (p in positions) {
            totalNotional += p.notionalChf
            totalPv += p.presentValueChf
            totalDv01 += p.dv01Chf
            totalVega += p.vegaChf

            when (p.category.name) {
                "OIS_SWAP", "FUTURE", "CAP", "FLOOR" -> saronDv01 += p.dv01Chf
                "GOVT_BOND" -> govtDv01 += p.dv01Chf
                else -> basisDv01 += p.dv01Chf
            }

            // Distribute key rate DV01s based on position name
            if (p.name.contains("1Y") || p.name.contains("1M") || p.name.contains("3M")) {
                keyRates["1Y"] = keyRates["1Y"]!! + p.dv01Chf * 0.7
                keyRates["3M"] = keyRates["3M"]!! + p.dv01Chf * 0.3
            } else if (p.name.contains("5Y")) {
                keyRates["5Y"] = keyRates["5Y"]!! + p.dv01Chf
            } else if (p.name.contains("10Y")) {
                keyRates["10Y"] = keyRates["10Y"]!! + p.dv01Chf
            } else if (p.name.contains("30Y")) {
                keyRates["30Y"] = keyRates["30Y"]!! + p.dv01Chf
            } else {
                keyRates["2Y"] = keyRates["2Y"]!! + p.dv01Chf
            }
        }

        // Run deterministic Monte Carlo simulation for VaR & Expected Shortfall
        val (var95, var99, cvar) = runMonteCarloVaR(totalDv01, totalVega)

        val stressLoss = abs(totalDv01) * 50.0 + abs(totalVega) * 10.0 // 50bp rate shock + 10bp vol shock

        return RiskSummary(
            totalNotionalChf = totalNotional,
            totalPvChf = totalPv,
            totalDv01Chf = totalDv01,
            saronDv01Chf = saronDv01,
            govtDv01Chf = govtDv01,
            basisDv01Chf = basisDv01,
            totalVegaChf = totalVega,
            totalGammaChf = totalDv01 * 0.01,
            keyRateDv01s = keyRates,
            var95Chf = var95,
            var99Chf = var99,
            expectedShortfallChf = cvar,
            stressLossChf = stressLoss
        )
    }

    /**
     * Deterministic Monte Carlo simulation for 1-day Value-at-Risk (VaR) & Expected Shortfall.
     */
    fun runMonteCarloVaR(
        portfolioDv01: Double,
        portfolioVega: Double,
        numSimulations: Int = 1000,
        randomSeed: Long = 42L
    ): Triple<Double, Double, Double> {
        val rand = Random(randomSeed)
        val pnlDraws = DoubleArray(numSimulations)

        val rateVolBpPerDay = 3.5 // Daily rate volatility 3.5 bps
        val optVolBpPerDay = 1.2  // Daily vol volatility 1.2 bps

        for (i in 0 until numSimulations) {
            val z1 = rand.nextGaussian()
            val z2 = rand.nextGaussian()

            val rateShockBp = z1 * rateVolBpPerDay
            val volShockBp = z2 * optVolBpPerDay

            val pnl = (rateShockBp * portfolioDv01) + (volShockBp * portfolioVega)
            pnlDraws[i] = pnl
        }

        pnlDraws.sort()

        val var95Index = (numSimulations * 0.05).toInt()
        val var99Index = (numSimulations * 0.01).toInt()

        val var95 = abs(pnlDraws[var95Index])
        val var99 = abs(pnlDraws[var99Index])

        var tailSum = 0.0
        for (k in 0..var95Index) {
            tailSum += abs(pnlDraws[k])
        }
        val expectedShortfall = tailSum / (var95Index + 1)

        return Triple(var95, var99, expectedShortfall)
    }

    /**
     * Reprices portfolio under a given stress scenario.
     */
    fun repricePortfolioUnderScenario(
        positions: List<PortfolioPosition>,
        scenario: StressScenario
    ): List<PortfolioPosition> {
        return positions.map { pos ->
            val totalShiftBp = scenario.saronShiftBp + scenario.snbShiftBp + (scenario.tenorShocksBp[pos.name] ?: 0.0)
            val pnlImpact = pos.dv01Chf * totalShiftBp
            val newPv = pos.presentValueChf + pnlImpact

            pos.copy(
                currentMarkRatePct = pos.entryRatePct + (totalShiftBp / 100.0),
                presentValueChf = newPv,
                pnlTodayChf = pnlImpact
            )
        }
    }
}
