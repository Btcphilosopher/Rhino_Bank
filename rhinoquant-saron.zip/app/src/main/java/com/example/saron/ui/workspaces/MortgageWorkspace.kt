package com.example.saron.ui.workspaces

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.saron.data.SaronMarketRepository
import com.example.saron.viewmodel.SaronTerminalViewModel
import com.example.ui.theme.*

@Composable
fun MortgageWorkspace(
    viewModel: SaronTerminalViewModel,
    modifier: Modifier = Modifier
) {
    val mortgagesList by viewModel.repository.mortgagesList.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Text(
                text = "SWISS FLOATING SARON MORTGAGE PORTFOLIO ANALYTICS (SARON + MARGIN)",
                color = SwissTextLight,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SwissSurfaceDark)
                    .padding(6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TableHeader("ID / CLIENT", Modifier.weight(1.3f))
                TableHeader("PRINCIPAL NOTIONAL", Modifier.weight(1.3f))
                TableHeader("MARGIN", Modifier.weight(0.9f))
                TableHeader("SARON", Modifier.weight(0.9f))
                TableHeader("TOTAL EFFECTIVE RATE", Modifier.weight(1.3f))
                TableHeader("PERIODIC PAYMENT", Modifier.weight(1.3f))
                TableHeader("+100BP SHOCK", Modifier.weight(1.1f))
            }
        }

        items(mortgagesList) { m ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 3.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TableCell("${m.id}\n${m.clientName}", Modifier.weight(1.3f), isBold = true)
                TableCell("CHF ${String.format("%,d", m.principalNotionalChf.toLong())}", Modifier.weight(1.3f))
                TableCell("+${m.marginBp} bp", Modifier.weight(0.9f), color = SwissAmberWarning)
                TableCell("${String.format("%.3f", m.currentCompoundedSaronPct)}%", Modifier.weight(0.9f))
                TableCell("${String.format("%.3f", m.totalEffectiveRatePct)}%", Modifier.weight(1.3f), color = SwissGreenPositive, isBold = true)
                TableCell("CHF ${String.format("%,.2f", m.quarterlyPaymentChf)}", Modifier.weight(1.3f))
                TableCell("+CHF ${String.format("%,.0f", m.sensitivity100bpChf)}", Modifier.weight(1.1f), color = SwissRedPrimary)
            }
        }
    }
}
