package com.example.saron.ui.workspaces

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.saron.data.SaronMarketRepository
import com.example.saron.model.InstrumentCategory
import com.example.saron.viewmodel.SaronTerminalViewModel
import com.example.ui.theme.*

@Composable
fun PortfolioRiskWorkspace(
    viewModel: SaronTerminalViewModel,
    modifier: Modifier = Modifier
) {
    val positions by viewModel.repository.portfolioPositions.collectAsState()
    val riskSummary by viewModel.riskSummary.collectAsState()

    var showTradeTicket by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            // Risk Summary Panel
            riskSummary?.let { risk ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SwissSurfaceDark, RoundedCornerShape(4.dp))
                        .border(1.dp, SwissBorder, RoundedCornerShape(4.dp))
                        .padding(10.dp)
                        .testTag("portfolio_risk_summary_box")
                ) {
                    Text(
                        text = "INSTITUTIONAL RISK DECOMPOSITION & MONTE CARLO VaR",
                        color = SwissTextLight,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        RiskCard("TOTAL DV01", "CHF ${String.format("%,.0f", risk.totalDv01Chf)}", "1bp Rate Shift", SwissGreenPositive, Modifier.weight(1f))
                        RiskCard("SARON CURVE DV01", "CHF ${String.format("%,.0f", risk.saronDv01Chf)}", "OIS Component", SwissAccentBlue, Modifier.weight(1f))
                        RiskCard("1D VaR 99%", "CHF ${String.format("%,.0f", risk.var99Chf)}", "1000 Sim Monte Carlo", SwissAmberWarning, Modifier.weight(1f))
                        RiskCard("EXPECTED SHORTFALL", "CHF ${String.format("%,.0f", risk.expectedShortfallChf)}", "Tail CVaR Loss", SwissRedPrimary, Modifier.weight(1f))
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "PORTFOLIO POSITIONS & REAL-TIME MARK-TO-MARKET",
                    color = SwissTextLight,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )

                Button(
                    onClick = { showTradeTicket = !showTradeTicket },
                    colors = ButtonDefaults.buttonColors(containerColor = SwissRedPrimary),
                    shape = RoundedCornerShape(2.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.testTag("new_trade_ticket_button")
                ) {
                    Text("+ NEW TRADE TICKET", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
            }
        }

        if (showTradeTicket) {
            item {
                TradeTicketPanel(
                    onExecuteTrade = { cat, name, side, notional, rate ->
                        viewModel.executeNewTrade(cat, name, side, notional, rate)
                        showTradeTicket = false
                    },
                    onCancel = { showTradeTicket = false }
                )
            }
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SwissSurfaceDark)
                    .padding(6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TableHeader("ID / INSTRUMENT", Modifier.weight(1.4f))
                TableHeader("SIDE", Modifier.weight(0.8f))
                TableHeader("NOTIONAL", Modifier.weight(1.2f))
                TableHeader("ENTRY RATE", Modifier.weight(1f))
                TableHeader("MARK RATE", Modifier.weight(1f))
                TableHeader("PRESENT VALUE", Modifier.weight(1.3f))
                TableHeader("DV01", Modifier.weight(1f))
            }
        }

        items(positions) { pos ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 3.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TableCell("${pos.id}\n${pos.name}", Modifier.weight(1.4f), isBold = true)
                TableCell(pos.side, Modifier.weight(0.8f), color = if (pos.side.contains("PAY") || pos.side == "SELL") SwissRedPrimary else SwissGreenPositive)
                TableCell("CHF ${String.format("%,d", pos.notionalChf.toLong())}", Modifier.weight(1.2f))
                TableCell("${String.format("%.2f", pos.entryRatePct)}%", Modifier.weight(1f))
                TableCell("${String.format("%.2f", pos.currentMarkRatePct)}%", Modifier.weight(1f))
                TableCell("CHF ${String.format("%,.0f", pos.presentValueChf)}", Modifier.weight(1.3f), isBold = true)
                TableCell("CHF ${String.format("%,.0f", pos.dv01Chf)}", Modifier.weight(1f), color = SwissGreenPositive)
            }
        }
    }
}

@Composable
fun TradeTicketPanel(
    onExecuteTrade: (InstrumentCategory, String, String, Double, Double) -> Unit,
    onCancel: () -> Unit
) {
    var nameText by remember { mutableStateOf("SARON OIS 5Y Swap") }
    var notionalText by remember { mutableStateOf("10000000") }
    var rateText by remember { mutableStateOf("1.15") }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(SwissNavyBackground, RoundedCornerShape(4.dp))
            .border(1.dp, SwissRedPrimary, RoundedCornerShape(4.dp))
            .padding(10.dp)
            .testTag("trade_ticket_form")
    ) {
        Text("NEW SARON DERIVATIVE TRADE TICKET", color = SwissRedPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
        Spacer(modifier = Modifier.height(6.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = nameText,
                onValueChange = { nameText = it },
                label = { Text("Instrument Name", fontSize = 10.sp) },
                modifier = Modifier.weight(1f).testTag("trade_ticket_name_input"),
                textStyle = LocalTextStyle.current.copy(fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            )
            OutlinedTextField(
                value = notionalText,
                onValueChange = { notionalText = it },
                label = { Text("Notional CHF", fontSize = 10.sp) },
                modifier = Modifier.weight(1f).testTag("trade_ticket_notional_input"),
                textStyle = LocalTextStyle.current.copy(fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            )
            OutlinedTextField(
                value = rateText,
                onValueChange = { rateText = it },
                label = { Text("Fixed Rate (%)", fontSize = 10.sp) },
                modifier = Modifier.weight(1f).testTag("trade_ticket_rate_input"),
                textStyle = LocalTextStyle.current.copy(fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
            Button(onClick = onCancel, colors = ButtonDefaults.buttonColors(containerColor = SwissSurfaceVariant)) {
                Text("CANCEL", fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Button(
                onClick = {
                    val notional = notionalText.toDoubleOrNull() ?: 10_000_000.0
                    val rate = rateText.toDoubleOrNull() ?: 1.15
                    onExecuteTrade(InstrumentCategory.OIS_SWAP, nameText, "RECEIVE_FIXED", notional, rate)
                },
                colors = ButtonDefaults.buttonColors(containerColor = SwissGreenPositive),
                modifier = Modifier.testTag("trade_ticket_confirm_btn")
            ) {
                Text("EXECUTE TRADE", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun RiskCard(
    title: String,
    value: String,
    subtitle: String,
    color: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .background(SwissNavyBackground, RoundedCornerShape(2.dp))
            .border(1.dp, SwissBorder, RoundedCornerShape(2.dp))
            .padding(6.dp)
    ) {
        Text(title, color = SwissTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Text(value, color = color, fontSize = 15.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        Text(subtitle, color = SwissSteelGrey, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
    }
}
