package com.example.saron.ui.workspaces

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.saron.data.SaronMarketRepository
import com.example.saron.viewmodel.SaronTerminalViewModel
import com.example.ui.theme.*

@Composable
fun RepoCollateralWorkspace(
    viewModel: SaronTerminalViewModel,
    modifier: Modifier = Modifier
) {
    val repoQuotes by viewModel.repository.repoQuotes.collectAsState()
    val collateralAssets by viewModel.repository.collateralAssets.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Text(
                text = "SWISS REPO MARKET RATES & GENERAL COLLATERAL (GC) SPREADS",
                color = SwissTextLight,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SwissSurfaceDark)
                    .padding(6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TableHeader("TERM", Modifier.weight(0.8f))
                TableHeader("REPO RATE", Modifier.weight(1f))
                TableHeader("COLLATERAL TYPE", Modifier.weight(1.5f))
                TableHeader("HAIRCUT", Modifier.weight(1f))
                TableHeader("VOLUME (CHF M)", Modifier.weight(1.2f))
                TableHeader("SPECIALNESS", Modifier.weight(1f))
            }
        }

        items(repoQuotes) { q ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 3.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TableCell(q.tenor, Modifier.weight(0.8f), isBold = true)
                TableCell("${String.format("%.3f", q.ratePct)}%", Modifier.weight(1f), color = SwissGreenPositive)
                TableCell(q.collateralType, Modifier.weight(1.5f))
                TableCell("${q.haircutPct}%", Modifier.weight(1f))
                TableCell("CHF ${String.format("%,.0f", q.volumeChfM)}M", Modifier.weight(1.2f))
                TableCell("${String.format("%.1f", q.specialnessBp)} bp", Modifier.weight(1f), color = if (q.specialnessBp > 0) SwissRedPrimary else SwissTextMuted)
            }
        }

        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "SWISS CONFEDERATION & SNB ELIGIBLE COLLATERAL BASKET ANALYTICS",
                color = SwissTextLight,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SwissSurfaceDark)
                    .padding(6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TableHeader("ISIN / ISSUER", Modifier.weight(1.5f))
                TableHeader("MATURITY", Modifier.weight(1f))
                TableHeader("PRICE", Modifier.weight(0.9f))
                TableHeader("HAIRCUT", Modifier.weight(0.9f))
                TableHeader("MARKET VALUE", Modifier.weight(1.3f))
                TableHeader("COLLATERAL VALUE", Modifier.weight(1.3f))
            }
        }

        items(collateralAssets) { asset ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 3.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TableCell("${asset.isin}\n${asset.issuer}", Modifier.weight(1.5f), isBold = true)
                TableCell(asset.maturityDate.toString(), Modifier.weight(1f))
                TableCell("${asset.marketPricePct}%", Modifier.weight(0.9f))
                TableCell("${asset.haircutPct}%", Modifier.weight(0.9f))
                TableCell("CHF ${String.format("%,.0f", asset.marketValueChf)}", Modifier.weight(1.3f))
                TableCell("CHF ${String.format("%,.0f", asset.collateralValueChf)}", Modifier.weight(1.3f), color = SwissGreenPositive, isBold = true)
            }
        }
    }
}
