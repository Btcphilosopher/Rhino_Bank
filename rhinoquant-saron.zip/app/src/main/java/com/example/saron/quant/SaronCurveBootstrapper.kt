package com.example.saron.quant

import com.example.saron.model.SaronCurvePoint
import java.time.LocalDate
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.pow

/**
 * CHF SARON OIS Yield Curve Bootstrapper & Discount Factor Engine.
 * Constructs discount factors DF(t), zero rates R_zero(t), forward rates F(t1, t2),
 * DV01, and convexity across the standard benchmark tenors:
 * ON, 1W, 1M, 3M, 6M, 9M, 1Y, 2Y, 3Y, 4Y, 5Y, 7Y, 10Y, 15Y, 20Y, 30Y.
 */
object SaronCurveBootstrapper {

    data class TenorSpec(val code: String, val years: Double)

    val BENCHMARK_TENORS = listOf(
        TenorSpec("ON", 1.0 / 360.0),
        TenorSpec("1W", 7.0 / 360.0),
        TenorSpec("1M", 30.0 / 360.0),
        TenorSpec("3M", 90.0 / 360.0),
        TenorSpec("6M", 180.0 / 360.0),
        TenorSpec("9M", 270.0 / 360.0),
        TenorSpec("1Y", 1.0),
        TenorSpec("2Y", 2.0),
        TenorSpec("3Y", 3.0),
        TenorSpec("4Y", 4.0),
        TenorSpec("5Y", 5.0),
        TenorSpec("7Y", 7.0),
        TenorSpec("10Y", 10.0),
        TenorSpec("15Y", 15.0),
        TenorSpec("20Y", 20.0),
        TenorSpec("30Y", 30.0)
    )

    /**
     * Bootstrap CHF OIS Curve from par market quotes.
     *
     * @param valuationDate Valuation date
     * @param marketQuotes Map of Tenor Code -> Par Rate in percent (e.g., "1Y" -> 0.985)
     */
    fun bootstrapCurve(
        valuationDate: LocalDate,
        marketQuotes: Map<String, Double>
    ): List<SaronCurvePoint> {
        val points = mutableListOf<SaronCurvePoint>()

        // Default quotes if unprovided
        val defaultParQuotes = mapOf(
            "ON" to 0.950,
            "1W" to 0.952,
            "1M" to 0.955,
            "3M" to 0.965,
            "6M" to 0.975,
            "9M" to 0.980,
            "1Y" to 0.985,
            "2Y" to 1.020,
            "3Y" to 1.060,
            "4Y" to 1.110,
            "5Y" to 1.150,
            "7Y" to 1.220,
            "10Y" to 1.280,
            "15Y" to 1.340,
            "20Y" to 1.380,
            "30Y" to 1.400
        )

        val mergedQuotes = defaultParQuotes + marketQuotes

        var prevDf = 1.0
        var prevYears = 0.0

        for (spec in BENCHMARK_TENORS) {
            val parQuote = mergedQuotes[spec.code] ?: 0.95
            val t = spec.years
            val matDate = valuationDate.plusDays((t * 365.25).toLong())

            // Discount factor calculation for short-end (<=1Y) vs long-end (>1Y)
            val df: Double = if (t <= 1.0) {
                // Short term OIS: DF(t) = 1 / (1 + parQuote * t / 100)
                1.0 / (1.0 + (parQuote / 100.0) * t)
            } else {
                // Multi-year OIS bootstrap: S = (1 - DF(N)) / \sum DF(i)
                // Approximating continuous discounting zero rate
                val approxZeroRate = parQuote / 100.0
                exp(-approxZeroRate * t)
            }

            // Zero rate (Continuous / Annual): R_zero = -ln(DF) / t
            val zeroRatePct = if (t > 0) (-ln(df) / t) * 100.0 else parQuote

            // Instantaneous forward rate approximation from previous tenor
            val forwardRatePct = if (t > prevYears) {
                val deltaT = t - prevYears
                val fwdDf = df / prevDf
                if (fwdDf > 0) (-ln(fwdDf) / deltaT) * 100.0 else zeroRatePct
            } else {
                zeroRatePct
            }

            // DV01 calculation for CHF 10M Notional: Notional * t * DF * 0.0001
            val dv01 = 10_000_000.0 * t * df * 0.0001

            // Convexity calculation: Notional * t^2 * DF
            val convexity = t * t * df

            points.add(
                SaronCurvePoint(
                    tenor = spec.code,
                    maturityYears = t,
                    maturityDate = matDate,
                    parMarketQuotePct = parQuote,
                    zeroRatePct = zeroRatePct,
                    discountFactor = df,
                    forwardRatePct = forwardRatePct,
                    dv01Per10m = dv01,
                    convexity = convexity
                )
            )

            prevDf = df
            prevYears = t
        }

        return points
    }

    /**
     * Interpolate discount factor at an arbitrary maturity time (years).
     */
    fun interpolateDiscountFactor(curve: List<SaronCurvePoint>, targetYears: Double): Double {
        if (curve.isEmpty()) return 1.0
        if (targetYears <= 0.0) return 1.0
        if (targetYears <= curve.first().maturityYears) return curve.first().discountFactor

        for (i in 0 until curve.size - 1) {
            val p1 = curve[i]
            val p2 = curve[i + 1]
            if (targetYears >= p1.maturityYears && targetYears <= p2.maturityYears) {
                // Log-linear discount factor interpolation
                val fraction = (targetYears - p1.maturityYears) / (p2.maturityYears - p1.maturityYears)
                return exp(ln(p1.discountFactor) * (1.0 - fraction) + ln(p2.discountFactor) * fraction)
            }
        }

        // Extrapolate beyond last tenor
        val last = curve.last()
        val secondLast = curve[curve.size - 2]
        val rate = -ln(last.discountFactor / secondLast.discountFactor) / (last.maturityYears - secondLast.maturityYears)
        return last.discountFactor * exp(-rate * (targetYears - last.maturityYears))
    }
}
