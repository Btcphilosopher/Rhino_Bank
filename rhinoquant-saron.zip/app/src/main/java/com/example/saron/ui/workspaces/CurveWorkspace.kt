package com.example.saron.ui.workspaces

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.saron.data.SaronMarketRepository
import com.example.saron.ui.components.OisCurveChart
import com.example.saron.viewmodel.SaronTerminalViewModel
import com.example.ui.theme.*

@Composable
fun CurveWorkspace(
    viewModel: SaronTerminalViewModel,
    modifier: Modifier = Modifier
) {
    val curvePoints by viewModel.repository.curvePoints.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            OisCurveChart(
                curvePoints = curvePoints,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("curve_workspace_ois_chart")
            )
        }

        item {
            Text(
                text = "BOOTSTRAPPED CHF SARON OIS YIELD CURVE & DISCOUNT FACTORS",
                color = SwissTextLight,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SwissSurfaceDark)
                    .padding(6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TableHeader("TENOR", Modifier.weight(0.8f))
                TableHeader("MATURITY", Modifier.weight(1.1f))
                TableHeader("PAR RATE", Modifier.weight(1f))
                TableHeader("ZERO RATE", Modifier.weight(1f))
                TableHeader("DISCOUNT FACTOR", Modifier.weight(1.3f))
                TableHeader("FORWARD RATE", Modifier.weight(1.1f))
                TableHeader("DV01 / CHF 10M", Modifier.weight(1.3f))
            }
        }

        items(curvePoints) { pt ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 3.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TableCell(pt.tenor, Modifier.weight(0.8f), isBold = true)
                TableCell(pt.maturityDate.toString(), Modifier.weight(1.1f))
                TableCell("${String.format("%.3f", pt.parMarketQuotePct)}%", Modifier.weight(1f), color = SwissAccentBlue)
                TableCell("${String.format("%.3f", pt.zeroRatePct)}%", Modifier.weight(1f), color = SwissAmberWarning)
                TableCell(String.format("%.6f", pt.discountFactor), Modifier.weight(1.3f))
                TableCell("${String.format("%.3f", pt.forwardRatePct)}%", Modifier.weight(1.1f), color = SwissRedPrimary)
                TableCell("CHF ${String.format("%,.0f", pt.dv01Per10m)}", Modifier.weight(1.3f))
            }
        }
    }
}
