package com.example.saron.ui.workspaces

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.saron.data.SaronMarketRepository
import com.example.saron.model.SaronFixing
import com.example.saron.viewmodel.SaronTerminalViewModel
import com.example.ui.theme.*
import java.time.LocalDate

@Composable
fun FixingsWorkspace(
    viewModel: SaronTerminalViewModel,
    modifier: Modifier = Modifier
) {
    val saronRate by viewModel.repository.saronRate.collectAsState()

    val dummyFixings = listOf(
        SaronFixing(LocalDate.now(), 0.9530, 0.9540, saronRate, 0.9610, 0.9490, 100.045, 8.42, 142, 1280, 0.8, 1.2, 0.05),
        SaronFixing(LocalDate.now().minusDays(1), 0.9520, 0.9535, 0.9540, 0.9590, 0.9480, 100.040, 8.10, 138, 1210, 0.7, 1.1, -0.10),
        SaronFixing(LocalDate.now().minusDays(2), 0.9510, 0.9525, 0.9550, 0.9620, 0.9490, 100.050, 7.95, 129, 1150, 0.9, 1.4, 0.15),
        SaronFixing(LocalDate.now().minusDays(3), 0.9500, 0.9510, 0.9535, 0.9580, 0.9470, 100.035, 8.30, 145, 1300, 0.8, 1.0, -0.05)
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FixingCard("12:00 FIXING", "0.9530%", "PROVISIONAL", SwissAmberWarning, Modifier.weight(1f))
                FixingCard("16:00 FIXING", "0.9540%", "PROVISIONAL", SwissAmberWarning, Modifier.weight(1f))
                FixingCard("18:00 FIXING", "${String.format("%.4f", saronRate)}%", "OFFICIAL FIXING", SwissGreenPositive, Modifier.weight(1f))
                FixingCard("REPO VOLUME", "CHF 8.42 Bn", "142 TRADES", SwissAccentBlue, Modifier.weight(1f))
            }
        }

        item {
            // SIX Repo Market Intraday Timeline
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SwissSurfaceDark, RoundedCornerShape(4.dp))
                    .border(1.dp, SwissBorder, RoundedCornerShape(4.dp))
                    .padding(8.dp)
                    .testTag("fixings_intraday_timeline_container")
            ) {
                Text(
                    text = "SIX REPO MARKET INTRADAY TIMELINE & FIXING SNAPSHOTS",
                    color = SwissTextLight,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(8.dp))

                val timeline = listOf(
                    "08:30" to "Market Open (Quotes Ingested)",
                    "10:00" to "Intraday Traded Volume: CHF 2.1 Bn (SARON: 0.9515%)",
                    "12:00" to "FIRST FIXING PUBLISHED: 0.9530% (PROVISIONAL)",
                    "14:30" to "Peak Liquidity Window (Quote Count: 850)",
                    "16:00" to "SECOND FIXING PUBLISHED: 0.9540% (PROVISIONAL)",
                    "18:00" to "OFFICIAL BENCHMARK FIXING PUBLISHED: 0.9545% (FINAL DERIVATIVES VALUATION)"
                )

                timeline.forEach { (time, desc) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = time,
                            color = SwissRedPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.width(60.dp)
                        )
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .background(if (time.contains("18:00")) SwissGreenPositive else SwissSteelGrey, RoundedCornerShape(3.dp))
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = desc,
                            color = if (time.contains("18:00")) SwissTextLight else SwissTextMuted,
                            fontWeight = if (time.contains("18:00")) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        item {
            // Historical Fixings Table
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SwissSurfaceDark, RoundedCornerShape(4.dp))
                    .border(1.dp, SwissBorder, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Text(
                    text = "HISTORICAL SIX SARON BENCHMARK FIXINGS AUDIT",
                    color = SwissTextLight,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SwissNavyBackground)
                        .padding(6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TableHeader("DATE", Modifier.weight(1.2f))
                    TableHeader("12:00", Modifier.weight(1f))
                    TableHeader("16:00", Modifier.weight(1f))
                    TableHeader("18:00 (OFFICIAL)", Modifier.weight(1.3f))
                    TableHeader("HIGH / LOW", Modifier.weight(1.2f))
                    TableHeader("VOLUME", Modifier.weight(1f))
                    TableHeader("TRADES", Modifier.weight(0.8f))
                }

                dummyFixings.forEach { fix ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 6.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TableCell(fix.date.toString(), Modifier.weight(1.2f))
                        TableCell("${String.format("%.4f", fix.fixing1200)}%", Modifier.weight(1f))
                        TableCell("${String.format("%.4f", fix.fixing1600)}%", Modifier.weight(1f))
                        TableCell("${String.format("%.4f", fix.fixing1800Official)}%", Modifier.weight(1.3f), isBold = true, color = SwissGreenPositive)
                        TableCell("${String.format("%.2f", fix.intradayHigh)}/${String.format("%.2f", fix.intradayLow)}", Modifier.weight(1.2f))
                        TableCell("CHF ${fix.repoVolumeChfBn}B", Modifier.weight(1f))
                        TableCell("${fix.transactionCount}", Modifier.weight(0.8f))
                    }
                }
            }
        }
    }
}

@Composable
fun FixingCard(
    title: String,
    value: String,
    statusText: String,
    statusColor: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .background(SwissSurfaceDark, RoundedCornerShape(4.dp))
            .border(1.dp, SwissBorder, RoundedCornerShape(4.dp))
            .padding(8.dp)
    ) {
        Text(title, color = SwissTextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        Spacer(modifier = Modifier.height(2.dp))
        Text(value, color = SwissTextLight, fontSize = 16.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        Spacer(modifier = Modifier.height(2.dp))
        Text(statusText, color = statusColor, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}

@Composable
fun TableHeader(text: String, modifier: Modifier = Modifier) {
    Text(text = text, color = SwissTextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = modifier)
}

@Composable
fun TableCell(
    text: String,
    modifier: Modifier = Modifier,
    isBold: Boolean = false,
    color: androidx.compose.ui.graphics.Color = SwissTextLight
) {
    Text(
        text = text,
        color = color,
        fontSize = 11.sp,
        fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
        fontFamily = FontFamily.Monospace,
        modifier = modifier
    )
}
