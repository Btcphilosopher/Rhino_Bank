package com.example.saron.quant

import com.example.saron.model.SnbPolicyState

/**
 * Swiss National Bank Policy Transmission & Spread Analytics Engine.
 * Monitors:
 * - Policy Spread: SARON - SNB Policy Rate
 * - Sight Deposit Spread: SARON - SNB Sight Deposit Rate
 * - Regime Classification: NEGATIVE_RATES, NORMALISATION, RAPID_TIGHTENING, EASING, LOW_RATES
 * - Policy transmission alert threshold triggers
 */
object SnbTransmissionEngine {

    /**
     * Evaluates current SNB policy transmission status.
     */
    fun evaluatePolicyState(
        saronRatePct: Double = 0.9545,
        snbPolicyRatePct: Double = 1.0000,
        sightDepositRatePct: Double = 1.0000,
        snbBillsBn: Double = 84.5,
        repoOpsBn: Double = 42.1,
        alertThresholdBp: Double = 5.0
    ): SnbPolicyState {

        val policySpreadBp = (saronRatePct - snbPolicyRatePct) * 100.0
        val sightDepositSpreadBp = (saronRatePct - sightDepositRatePct) * 100.0

        val regimeName = when {
            snbPolicyRatePct < 0.0 -> "NEGATIVE-RATE ERA"
            snbPolicyRatePct in 0.0..0.75 -> "LOW-RATE / ACCORD"
            snbPolicyRatePct in 0.75..1.50 -> "POLICY NORMALISATION"
            snbPolicyRatePct > 1.50 -> "TIGHTENING REGIME"
            else -> "STABLE POLICY"
        }

        val isAlert = Math.abs(policySpreadBp) >= alertThresholdBp
        val alertMsg = if (isAlert) {
            val direction = if (policySpreadBp > 0) "ABOVE" else "BELOW"
            "ALERT: SARON is ${String.format("%.1f", Math.abs(policySpreadBp))} bp $direction SNB Policy Target!"
        } else {
            "Policy Spread within normal band (±${alertThresholdBp} bp)"
        }

        return SnbPolicyState(
            policyRatePct = snbPolicyRatePct,
            sightDepositRatePct = sightDepositRatePct,
            saronRatePct = saronRatePct,
            policySpreadBp = policySpreadBp,
            sightDepositSpreadBp = sightDepositSpreadBp,
            snbBillsOutstandingChfBn = snbBillsBn,
            repoOpsVolumeChfBn = repoOpsBn,
            regimeName = regimeName,
            isAlertTriggered = isAlert,
            alertMessage = alertMsg
        )
    }
}
