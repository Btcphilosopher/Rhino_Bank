package com.example.saron.ui.workspaces

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.saron.data.SaronMarketRepository
import com.example.saron.viewmodel.SaronTerminalViewModel
import com.example.ui.theme.*

@Composable
fun DerivativesWorkspace(
    viewModel: SaronTerminalViewModel,
    modifier: Modifier = Modifier
) {
    val futuresList by viewModel.repository.futuresList.collectAsState()
    val optionsList by viewModel.repository.optionsList.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Text(
                text = "SARON 3M FUTURES QUARTERLY IMM STRIP",
                color = SwissTextLight,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SwissSurfaceDark)
                    .padding(6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TableHeader("CONTRACT CODE", Modifier.weight(1f))
                TableHeader("EXPIRY DATE", Modifier.weight(1.1f))
                TableHeader("PRICE QUOTE", Modifier.weight(1f))
                TableHeader("IMPLIED SARON", Modifier.weight(1.1f))
                TableHeader("BASIS TO SPOT", Modifier.weight(1.1f))
                TableHeader("VOLUME / OPEN INT", Modifier.weight(1.4f))
            }
        }

        items(futuresList) { fut ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 3.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TableCell(fut.code, Modifier.weight(1f), isBold = true)
                TableCell(fut.expiryDate.toString(), Modifier.weight(1.1f))
                TableCell(String.format("%.3f", fut.priceQuote), Modifier.weight(1f), color = SwissAccentBlue)
                TableCell("${String.format("%.3f", fut.impliedSaronRatePct)}%", Modifier.weight(1.1f), color = SwissGreenPositive, isBold = true)
                TableCell("${String.format("%.1f", fut.basisToSpotBp)} bp", Modifier.weight(1.1f))
                TableCell("${fut.volumeContracts} / ${fut.openInterestContracts}", Modifier.weight(1.4f))
            }
        }

        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "SARON CAPS, FLOORS & SWAPTIONS PRICING & GREEKS (BACHELIER MODEL)",
                color = SwissTextLight,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SwissSurfaceDark)
                    .padding(6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TableHeader("INSTRUMENT", Modifier.weight(1.2f))
                TableHeader("STRIKE", Modifier.weight(0.9f))
                TableHeader("NORMAL VOL", Modifier.weight(1f))
                TableHeader("PREMIUM (CHF)", Modifier.weight(1.3f))
                TableHeader("DELTA", Modifier.weight(0.9f))
                TableHeader("VEGA / BP", Modifier.weight(1.1f))
                TableHeader("THETA / DAY", Modifier.weight(1.1f))
            }
        }

        items(optionsList) { opt ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 3.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TableCell(opt.id, Modifier.weight(1.2f), isBold = true)
                TableCell("${opt.strikeRatePct}%", Modifier.weight(0.9f))
                TableCell("${opt.impliedVolBpOrPct} bps", Modifier.weight(1f))
                TableCell("CHF ${String.format("%,.0f", opt.premiumChf)}", Modifier.weight(1.3f), color = SwissGreenPositive, isBold = true)
                TableCell(String.format("%.3f", opt.delta), Modifier.weight(0.9f))
                TableCell("CHF ${String.format("%.1f", opt.vegaChfPerBp)}", Modifier.weight(1.1f))
                TableCell("CHF ${String.format("%.1f", opt.thetaChfPerDay)}", Modifier.weight(1.1f))
            }
        }
    }
}
