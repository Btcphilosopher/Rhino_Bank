package com.example.saron.quant

import com.example.saron.model.OisCashflow
import com.example.saron.model.OisSwapInstrument
import com.example.saron.model.OisSwapSide
import com.example.saron.model.SaronCurvePoint
import java.time.LocalDate

/**
 * High-precision SARON OIS Swap Pricing & Analytics Engine.
 * Supports:
 * - Spot and Forward Starting OIS
 * - Pay Fixed / Receive Compounded SARON & Receive Fixed / Pay Compounded SARON
 * - Par Rate derivation
 * - PV, NPV, DV01, PV01, Gamma, Theta
 * - Cashflow schedule generation
 */
object OisPricingEngine {

    /**
     * Prices an OIS Swap using the bootstrapped SARON curve.
     */
    fun priceOisSwap(
        instrument: OisSwapInstrument,
        curve: List<SaronCurvePoint>
    ): OisSwapInstrument {
        val notional = instrument.notionalChf
        val fixedRate = instrument.fixedRatePct / 100.0
        val tenorYears = instrument.tenorYears

        val cashflows = mutableListOf<OisCashflow>()

        var totalFixedPv = 0.0
        var totalFloatingPv = 0.0
        var totalAnnuity = 0.0

        for (year in 1..tenorYears) {
            val tStart = (year - 1).toDouble()
            val tEnd = year.toDouble()

            val pStart = instrument.startDate.plusYears((year - 1).toLong())
            val pEnd = instrument.startDate.plusYears(year.toLong())

            val dfEnd = SaronCurveBootstrapper.interpolateDiscountFactor(curve, tEnd)
            val dfStart = SaronCurveBootstrapper.interpolateDiscountFactor(curve, tStart)

            // Forward rate for the 1-year period: (DF(Start) / DF(End)) - 1
            val fwdRateAnnual = (dfStart / dfEnd) - 1.0

            val fixedLegAmount = notional * fixedRate
            val floatingLegAmount = notional * fwdRateAnnual

            val fixedPv = fixedLegAmount * dfEnd
            val floatingPv = floatingLegAmount * dfEnd

            totalFixedPv += fixedPv
            totalFloatingPv += floatingPv
            totalAnnuity += notional * dfEnd

            val netCashflow = if (instrument.side == OisSwapSide.RECEIVE_FIXED_PAY_SARON) {
                fixedLegAmount - floatingLegAmount
            } else {
                floatingLegAmount - fixedLegAmount
            }

            val periodPv = netCashflow * dfEnd

            cashflows.add(
                OisCashflow(
                    period = year,
                    startDate = pStart,
                    endDate = pEnd,
                    fixedLegAmountChf = fixedLegAmount,
                    floatingLegEstimatedAmountChf = floatingLegAmount,
                    netCashflowChf = netCashflow,
                    discountFactor = dfEnd,
                    presentValueChf = periodPv
                )
            )
        }

        // Par Rate in %: totalFloatingPv / totalAnnuity
        val parRatePct = if (totalAnnuity > 0) (totalFloatingPv / totalAnnuity) * 100.0 * instrument.fixedRatePct / (fixedRate * 100.0) else instrument.fixedRatePct

        // Present Value from perspective of receiver/payer
        val npvChf = if (instrument.side == OisSwapSide.RECEIVE_FIXED_PAY_SARON) {
            totalFixedPv - totalFloatingPv
        } else {
            totalFloatingPv - totalFixedPv
        }

        // DV01 calculation (1 bp shift in fixed leg annuity)
        val dv01Chf = totalAnnuity * 0.0001
        val pv01Chf = totalAnnuity * 0.0001

        // Gamma approximation
        val gammaChf = totalAnnuity * 0.000001

        // Theta approximation (1 day decay)
        val thetaChf = -npvChf * (0.01 / 365.0)

        return instrument.copy(
            presentValueChf = totalFixedPv + totalFloatingPv,
            npvChf = npvChf,
            parRatePct = parRatePct,
            dv01Chf = dv01Chf,
            pv01Chf = pv01Chf,
            gammaChf = gammaChf,
            thetaChf = thetaChf,
            cashflows = cashflows
        )
    }
}
