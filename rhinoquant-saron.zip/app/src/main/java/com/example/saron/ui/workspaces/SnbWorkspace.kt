package com.example.saron.ui.workspaces

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.saron.data.SaronMarketRepository
import com.example.saron.viewmodel.SaronTerminalViewModel
import com.example.ui.theme.*

@Composable
fun SnbWorkspace(
    viewModel: SaronTerminalViewModel,
    modifier: Modifier = Modifier
) {
    val snbState by viewModel.repository.snbState.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Text(
                text = "SWISS NATIONAL BANK (SNB) MONETARY POLICY & TRANSMISSION TERMINAL",
                color = SwissTextLight,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PolicyMetric("SNB POLICY RATE", "${String.format("%.2f", snbState.policyRatePct)}%", "Official Target Rate", SwissAccentBlue, Modifier.weight(1f))
                PolicyMetric("SARON FIXING", "${String.format("%.4f", snbState.saronRatePct)}%", "Overnight Secured Rate", SwissGreenPositive, Modifier.weight(1f))
                PolicyMetric("POLICY SPREAD", "${String.format("%.1f", snbState.policySpreadBp)} bp", "SARON - Policy Rate", if (snbState.isAlertTriggered) SwissRedPrimary else SwissAmberWarning, Modifier.weight(1f))
                PolicyMetric("SNB BILLS", "CHF ${snbState.snbBillsOutstandingChfBn}B", "Liquidity Sterilisation", SwissTextLight, Modifier.weight(1f))
            }
        }

        item {
            // SNB Transmission Diagram Box
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SwissSurfaceDark, RoundedCornerShape(4.dp))
                    .border(1.dp, SwissBorder, RoundedCornerShape(4.dp))
                    .padding(12.dp)
                    .testTag("snb_transmission_flow_container")
            ) {
                Text(
                    text = "SNB MONETARY POLICY TRANSMISSION MECHANISM FLOW",
                    color = SwissTextLight,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(10.dp))

                val stages = listOf(
                    "1. SNB POLICY RATE TARGET" to "${snbState.policyRatePct}% (Set by SNB Governing Board)",
                    "2. SNB LIQUIDITY OPERATIONS" to "SNB Repo Operations (CHF ${snbState.repoOpsVolumeChfBn}B) & SNB Bills (CHF ${snbState.snbBillsOutstandingChfBn}B)",
                    "3. CHF REPO MARKET & SARON" to "SIX Repo Platform Trading -> Official SARON Fixing (${String.format("%.4f", snbState.saronRatePct)}%)",
                    "4. CHF OIS SWAP YIELD CURVE" to "SARON OIS Bootstrapped Curve (1W to 30Y Benchmark)",
                    "5. CHF BANK FUNDING & CREDIT" to "CHF Mortgages (SARON + Margin), Corporate Loans & Confederation Bonds"
                )

                stages.forEachIndexed { idx, (title, desc) ->
                    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(20.dp)
                                    .background(SwissRedPrimary, RoundedCornerShape(2.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("${idx + 1}", color = androidx.compose.ui.graphics.Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(title, color = SwissTextLight, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                        }
                        Text(desc, color = SwissTextMuted, fontSize = 11.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(start = 28.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun PolicyMetric(
    label: String,
    value: String,
    subtitle: String,
    color: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .background(SwissSurfaceDark, RoundedCornerShape(4.dp))
            .border(1.dp, SwissBorder, RoundedCornerShape(4.dp))
            .padding(8.dp)
    ) {
        Text(label, color = SwissTextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        Spacer(modifier = Modifier.height(2.dp))
        Text(value, color = color, fontSize = 18.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        Spacer(modifier = Modifier.height(2.dp))
        Text(subtitle, color = SwissSteelGrey, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
    }
}
