package com.example.saron.data

import com.example.saron.model.*
import com.example.saron.quant.BlackBachelierOptionsEngine
import com.example.saron.quant.SaronCurveBootstrapper
import com.example.saron.quant.SnbTransmissionEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.time.LocalDate

/**
 * Data Repository for Swiss Market Data, SARON Fixings, Curves, Repo, Derivatives, and Portfolios.
 * Maintains deterministic simulated market data feeds with live parameter controls.
 */
class SaronMarketRepository {

    private val _saronRate = MutableStateFlow(0.9545)
    val saronRate: StateFlow<Double> = _saronRate

    private val _saronFixing1800 = MutableStateFlow(0.9545)
    val saronFixing1800: StateFlow<Double> = _saronFixing1800

    private val _curvePoints = MutableStateFlow<List<SaronCurvePoint>>(emptyList())
    val curvePoints: StateFlow<List<SaronCurvePoint>> = _curvePoints

    private val _repoQuotes = MutableStateFlow<List<RepoMarketQuote>>(emptyList())
    val repoQuotes: StateFlow<List<RepoMarketQuote>> = _repoQuotes

    private val _collateralAssets = MutableStateFlow<List<CollateralAsset>>(emptyList())
    val collateralAssets: StateFlow<List<CollateralAsset>> = _collateralAssets

    private val _snbState = MutableStateFlow(SnbTransmissionEngine.evaluatePolicyState())
    val snbState: StateFlow<SnbPolicyState> = _snbState

    private val _futuresList = MutableStateFlow<List<SaronFutureContract>>(emptyList())
    val futuresList: StateFlow<List<SaronFutureContract>> = _futuresList

    private val _optionsList = MutableStateFlow<List<SaronOptionContract>>(emptyList())
    val optionsList: StateFlow<List<SaronOptionContract>> = _optionsList

    private val _mortgagesList = MutableStateFlow<List<ChfMortgagePosition>>(emptyList())
    val mortgagesList: StateFlow<List<ChfMortgagePosition>> = _mortgagesList

    private val _portfolioPositions = MutableStateFlow<List<PortfolioPosition>>(emptyList())
    val portfolioPositions: StateFlow<List<PortfolioPosition>> = _portfolioPositions

    init {
        refreshMarketData()
    }

    fun refreshMarketData(customSaron: Double? = null) {
        val activeSaron = customSaron ?: 0.9545
        _saronRate.value = activeSaron
        _saronFixing1800.value = activeSaron

        // Bootstrap OIS Curve
        val bootstrapped = SaronCurveBootstrapper.bootstrapCurve(
            valuationDate = LocalDate.now(),
            marketQuotes = mapOf(
                "ON" to activeSaron,
                "1W" to activeSaron + 0.002,
                "1M" to activeSaron + 0.005,
                "3M" to activeSaron + 0.015,
                "6M" to activeSaron + 0.025,
                "1Y" to activeSaron + 0.035,
                "2Y" to 1.020,
                "5Y" to 1.150,
                "10Y" to 1.280,
                "30Y" to 1.400
            )
        )
        _curvePoints.value = bootstrapped

        // Repo Market
        _repoQuotes.value = listOf(
            RepoMarketQuote("ON", activeSaron - 0.01, "GC", 2.0, 4820.0, 0.0, -1.0, -1.0),
            RepoMarketQuote("1W", activeSaron + 0.005, "GC", 2.0, 1250.0, 0.0, 0.5, 0.5),
            RepoMarketQuote("2W", activeSaron + 0.010, "GC", 2.5, 800.0, 0.0, 1.0, 1.0),
            RepoMarketQuote("1M", activeSaron + 0.020, "GC", 2.5, 1450.0, 0.0, 2.0, 2.0),
            RepoMarketQuote("3M", activeSaron + 0.035, "Special - CH Govt 1.25% 2030", 3.0, 620.0, 15.0, 3.5, 3.5)
        )

        // Collateral Assets
        _collateralAssets.value = listOf(
            CollateralAsset("CH0550418141", "Swiss Confederation (Eidgenossenschaft)", LocalDate.of(2030, 6, 27), 101.45, 1.12, 1.5, true, 50_000_000.0, 50_725_000.0, 49_964_125.0),
            CollateralAsset("CH0341440182", "Canton of Zurich", LocalDate.of(2028, 11, 15), 100.20, 1.25, 2.5, true, 25_000_000.0, 25_050_000.0, 24_423_750.0),
            CollateralAsset("CH0428193821", "Pfandbriefbank Schweizerischer Hypothekarinstitute", LocalDate.of(2032, 4, 10), 99.80, 1.35, 3.0, true, 30_000_000.0, 29_940_000.0, 29_041_800.0)
        )

        // SNB Policy State
        _snbState.value = SnbTransmissionEngine.evaluatePolicyState(saronRatePct = activeSaron)

        // Futures Contracts
        _futuresList.value = listOf(
            SaronFutureContract("F3M-H26", LocalDate.of(2026, 3, 18), 99.045, 0.955, 1.0, 12450, 45200),
            SaronFutureContract("F3M-M26", LocalDate.of(2026, 6, 17), 99.020, 0.980, 3.5, 8920, 31800),
            SaronFutureContract("F3M-U26", LocalDate.of(2026, 9, 16), 98.950, 1.050, 10.5, 6100, 22400),
            SaronFutureContract("F3M-Z26", LocalDate.of(2026, 12, 16), 98.850, 1.150, 20.5, 4300, 18100)
        )

        // Options Contracts
        val rawCap = SaronOptionContract("OPT-CAP-1Y", OptionType.CAP, 50_000_000.0, 1.25, LocalDate.now().plusYears(1), 1, PricingModel.BACHELIER_NORMAL, 22.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        val rawSwaption = SaronOptionContract("OPT-SWP-5Y", OptionType.PAYER_SWAPTION, 25_000_000.0, 1.30, LocalDate.now().plusYears(1), 5, PricingModel.BACHELIER_NORMAL, 28.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)

        _optionsList.value = listOf(
            BlackBachelierOptionsEngine.priceOption(rawCap, activeSaron),
            BlackBachelierOptionsEngine.priceOption(rawSwaption, activeSaron)
        )

        // Mortgages List
        _mortgagesList.value = listOf(
            ChfMortgagePosition("MORTG-ZH-01", "Zurich Real Estate Fund AG", 15_000_000.0, 85.0, 3, activeSaron, activeSaron + 0.85, 67_668.75, 15_000_000.0, 37_500.0),
            ChfMortgagePosition("MORTG-BS-02", "Basel Commercial Holdings", 8_500_000.0, 75.0, 3, activeSaron, activeSaron + 0.75, 36_220.63, 8_500_000.0, 21_250.0),
            ChfMortgagePosition("MORTG-GE-03", "Geneva Private Treasury S.A.", 22_000_000.0, 95.0, 1, activeSaron, activeSaron + 0.95, 34_915.83, 22_000_000.0, 55_000.0)
        )

        // Portfolio Positions
        _portfolioPositions.value = listOf(
            PortfolioPosition("POS-OIS-5Y", InstrumentCategory.OIS_SWAP, "SARON OIS 5Y Receiver", "RECEIVE_FIXED", 50_000_000.0, 1.15, 1.12, 142_500.0, 4_250.0, 120.0, 1_250.0, 18_400.0, 142_500.0),
            PortfolioPosition("POS-OIS-10Y", InstrumentCategory.OIS_SWAP, "SARON OIS 10Y Payer", "PAY_FIXED", 30_000_000.0, 1.25, 1.28, -85_000.0, -2_820.0, 0.0, -900.0, -12_100.0, -85_000.0),
            PortfolioPosition("POS-FUT-U26", InstrumentCategory.FUTURE, "SARON Future Sep26 Long", "BUY", 20_000_000.0, 98.90, 98.95, 25_000.0, 500.0, 0.0, 500.0, 3_200.0, 25_000.0),
            PortfolioPosition("POS-CAP-1Y", InstrumentCategory.CAP, "SARON 1Y 1.25% Cap", "BUY", 50_000_000.0, 1.25, 1.25, 68_400.0, 850.0, 142.0, -120.0, 1_800.0, 12_400.0)
        )
    }

    fun addTradePosition(position: PortfolioPosition) {
        val current = _portfolioPositions.value.toMutableList()
        current.add(position)
        _portfolioPositions.value = current
    }
}
