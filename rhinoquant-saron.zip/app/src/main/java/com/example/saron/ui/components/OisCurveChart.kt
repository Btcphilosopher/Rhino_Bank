package com.example.saron.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.saron.model.SaronCurvePoint
import com.example.ui.theme.*

@Composable
fun OisCurveChart(
    curvePoints: List<SaronCurvePoint>,
    modifier: Modifier = Modifier
) {
    var selectedIndex by remember { mutableStateOf<Int?>(null) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(SwissSurfaceDark, RoundedCornerShape(4.dp))
            .border(1.dp, SwissBorder, RoundedCornerShape(4.dp))
            .padding(8.dp)
            .testTag("ois_curve_chart_container")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "CHF SARON OIS YIELD CURVE",
                color = SwissTextLight,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
            )

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                LegendItem(label = "Par Rate", color = SwissAccentBlue)
                LegendItem(label = "Zero Rate", color = SwissAmberWarning)
                LegendItem(label = "Forward Rate", color = SwissRedPrimary)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (curvePoints.isNotEmpty()) {
            val minRate = (curvePoints.minOf { minOf(it.parMarketQuotePct, it.zeroRatePct, it.forwardRatePct) } - 0.1).coerceAtLeast(0.0)
            val maxRate = curvePoints.maxOf { maxOf(it.parMarketQuotePct, it.zeroRatePct, it.forwardRatePct) } + 0.2

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(curvePoints) {
                            detectTapGestures { offset ->
                                val pointWidth = size.width / (curvePoints.size - 1).coerceAtLeast(1)
                                val idx = (offset.x / pointWidth).toInt().coerceIn(0, curvePoints.size - 1)
                                selectedIndex = idx
                            }
                        }
                ) {
                    val w = size.width
                    val h = size.height
                    val n = curvePoints.size

                    // Draw grid lines
                    val gridLines = 4
                    for (i in 0..gridLines) {
                        val y = h * i / gridLines
                        drawLine(
                            color = SwissBorder,
                            start = Offset(0f, y),
                            end = Offset(w, y),
                            strokeWidth = 1f
                        )
                    }

                    fun getPointOffset(index: Int, ratePct: Double): Offset {
                        val x = (w * index / (n - 1).coerceAtLeast(1))
                        val normY = ((ratePct - minRate) / (maxRate - minRate)).coerceIn(0.0, 1.0)
                        val y = h - (normY * h).toFloat()
                        return Offset(x, y)
                    }

                    // Draw Par Rate Path
                    val parPath = Path()
                    curvePoints.forEachIndexed { idx, point ->
                        val pt = getPointOffset(idx, point.parMarketQuotePct)
                        if (idx == 0) parPath.moveTo(pt.x, pt.y) else parPath.lineTo(pt.x, pt.y)
                    }
                    drawPath(parPath, SwissAccentBlue, style = Stroke(width = 3f))

                    // Draw Zero Rate Path
                    val zeroPath = Path()
                    curvePoints.forEachIndexed { idx, point ->
                        val pt = getPointOffset(idx, point.zeroRatePct)
                        if (idx == 0) zeroPath.moveTo(pt.x, pt.y) else zeroPath.lineTo(pt.x, pt.y)
                    }
                    drawPath(zeroPath, SwissAmberWarning, style = Stroke(width = 2f))

                    // Draw Forward Rate Path
                    val fwdPath = Path()
                    curvePoints.forEachIndexed { idx, point ->
                        val pt = getPointOffset(idx, point.forwardRatePct)
                        if (idx == 0) fwdPath.moveTo(pt.x, pt.y) else fwdPath.lineTo(pt.x, pt.y)
                    }
                    drawPath(fwdPath, SwissRedPrimary, style = Stroke(width = 2f))

                    // Draw Points
                    curvePoints.forEachIndexed { idx, point ->
                        val pt = getPointOffset(idx, point.parMarketQuotePct)
                        drawCircle(SwissAccentBlue, radius = 5f, center = pt)
                    }

                    // Highlight selected point crosshair
                    selectedIndex?.let { idx ->
                        if (idx in curvePoints.indices) {
                            val pt = getPointOffset(idx, curvePoints[idx].parMarketQuotePct)
                            drawLine(SwissRedPrimary, start = Offset(pt.x, 0f), end = Offset(pt.x, h), strokeWidth = 1.5f)
                            drawCircle(SwissRedPrimary, radius = 8f, center = pt)
                        }
                    }
                }
            }

            // Tenor Labels Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                curvePoints.filterIndexed { index, _ -> index % 2 == 0 || index == curvePoints.lastIndex }.forEach { pt ->
                    Text(
                        text = pt.tenor,
                        color = SwissTextMuted,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Inspection Panel
            val activePoint = selectedIndex?.let { curvePoints.getOrNull(it) } ?: curvePoints.find { it.tenor == "5Y" } ?: curvePoints.first()
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SwissNavyBackground, RoundedCornerShape(2.dp))
                    .border(1.dp, SwissBorder, RoundedCornerShape(2.dp))
                    .padding(6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "TENOR: ${activePoint.tenor} (${activePoint.maturityDate})",
                    color = SwissTextLight,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "PAR: ${String.format("%.3f", activePoint.parMarketQuotePct)}% | ZERO: ${String.format("%.3f", activePoint.zeroRatePct)}% | FWD: ${String.format("%.3f", activePoint.forwardRatePct)}% | DF: ${String.format("%.5f", activePoint.discountFactor)} | DV01/10M: CHF ${String.format("%,d", activePoint.dv01Per10m.toInt())}",
                    color = SwissTextMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
fun LegendItem(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .background(color, RoundedCornerShape(1.dp))
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            color = SwissTextMuted,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}
