package com.example.saron.model

import java.time.LocalDate

/**
 * Data quality classification for Swiss market observations.
 */
enum class DataQuality {
    PRIME, STANDARD, DEGRADED, SIMULATED
}

/**
 * Publication status from SIX repo market platform.
 */
enum class PublicationStatus {
    INTRADAY_PROVISIONAL,
    FIXING_1200,
    FIXING_1600,
    FIXING_1800_OFFICIAL,
    CLOSED
}

/**
 * Single observation of SARON or repo rate tick.
 */
data class SaronObservation(
    val timestamp: String,
    val businessDate: LocalDate,
    val value: Double, // Percentage rate, e.g. 0.9545 (%)
    val tenor: String = "ON",
    val currency: String = "CHF",
    val source: String = "SIX Repo Market",
    val dataQuality: DataQuality = DataQuality.PRIME,
    val publicationStatus: PublicationStatus = PublicationStatus.FIXING_1800_OFFICIAL,
    val isOfficial: Boolean = true,
    val isDerived: Boolean = false,
    val isSimulated: Boolean = false
)

/**
 * Official SIX fixing record for a specific day.
 */
data class SaronFixing(
    val date: LocalDate,
    val fixing1200: Double,
    val fixing1600: Double,
    val fixing1800Official: Double,
    val intradayHigh: Double,
    val intradayLow: Double,
    val referencePrice: Double,
    val repoVolumeChfBn: Double, // Repo volume in CHF Billions
    val transactionCount: Int,
    val quoteCount: Int,
    val bidAskSpreadBp: Double,
    val intradayVolBp: Double,
    val prevFixingDiffBp: Double
)

/**
 * Audit entry for a single calendar day inside a compounding period.
 */
data class DailyObservationAudit(
    val date: LocalDate,
    val dayOfWeek: String,
    val isBusinessDay: Boolean,
    val saronRatePct: Double,
    val calendarDaysWeight: Int, // Number of days rate applies (e.g., 3 for Friday)
    val dailyMultiplier: Double, // 1 + (r * n / 360)
    val cumulativeCompoundedFactor: Double,
    val accruedInterestChf: Double
)

/**
 * Result of SARON compounding over an observation period.
 */
data class SaronCompoundedResult(
    val startDate: LocalDate,
    val endDate: LocalDate,
    val tenorLabel: String,
    val notionalChf: Double,
    val compoundedRatePct: Double, // Compounded rate in percent
    val annualizedRatePct: Double,
    val totalAccruedInterestChf: Double,
    val observationShiftDays: Int,
    val lookbackDays: Int,
    val paymentLagDays: Int,
    val totalCalendarDays: Int,
    val totalBusinessDays: Int,
    val dailyAudits: List<DailyObservationAudit>
)

/**
 * Single point on the CHF SARON OIS yield curve.
 */
data class SaronCurvePoint(
    val tenor: String, // e.g., ON, 1W, 1M, 3M, 6M, 1Y, 2Y, 5Y, 10Y, 30Y
    val maturityYears: Double,
    val maturityDate: LocalDate,
    val parMarketQuotePct: Double,
    val zeroRatePct: Double,
    val discountFactor: Double,
    val forwardRatePct: Double,
    val dv01Per10m: Double, // DV01 per CHF 10M Notional
    val convexity: Double
)

/**
 * OIS Swap instrument parameters and valuation outputs.
 */
data class OisSwapInstrument(
    val id: String,
    val name: String,
    val side: OisSwapSide, // PAY_FIXED or RECEIVE_FIXED
    val notionalChf: Double,
    val fixedRatePct: Double,
    val tenorYears: Int,
    val startDate: LocalDate,
    val maturityDate: LocalDate,
    val paymentFrequencyMonths: Int = 12,
    val presentValueChf: Double = 0.0,
    val npvChf: Double = 0.0,
    val parRatePct: Double = 0.0,
    val dv01Chf: Double = 0.0,
    val pv01Chf: Double = 0.0,
    val gammaChf: Double = 0.0,
    val thetaChf: Double = 0.0,
    val cashflows: List<OisCashflow> = emptyList()
)

enum class OisSwapSide {
    PAY_FIXED_RECEIVE_SARON,
    RECEIVE_FIXED_PAY_SARON
}

data class OisCashflow(
    val period: Int,
    val startDate: LocalDate,
    val endDate: LocalDate,
    val fixedLegAmountChf: Double,
    val floatingLegEstimatedAmountChf: Double,
    val netCashflowChf: Double,
    val discountFactor: Double,
    val presentValueChf: Double
)

/**
 * SARON Futures contract definition.
 */
data class SaronFutureContract(
    val code: String, // e.g. "F3M-Z26"
    val expiryDate: LocalDate,
    val priceQuote: Double, // e.g., 99.05 -> Implied SARON = 0.95%
    val impliedSaronRatePct: Double,
    val basisToSpotBp: Double,
    val volumeContracts: Int,
    val openInterestContracts: Int,
    val contractSizeChf: Double = 1_000_000.0
)

/**
 * Option contract model (SARON Caps, Floors, Swaptions).
 */
enum class OptionType { CAP, FLOOR, PAYER_SWAPTION, RECEIVER_SWAPTION }
enum class PricingModel { BLACK_76, BACHELIER_NORMAL }

data class SaronOptionContract(
    val id: String,
    val optionType: OptionType,
    val notionalChf: Double,
    val strikeRatePct: Double,
    val expiryDate: LocalDate,
    val tenorYears: Int,
    val pricingModel: PricingModel = PricingModel.BACHELIER_NORMAL,
    val impliedVolBpOrPct: Double, // Normal vol in bps or Black vol in %
    val premiumChf: Double,
    val delta: Double,
    val gamma: Double,
    val vegaChfPerBp: Double,
    val thetaChfPerDay: Double,
    val rhoChfPerBp: Double,
    val vanna: Double,
    val volga: Double
)

/**
 * Swiss Repo Market quote.
 */
data class RepoMarketQuote(
    val tenor: String, // ON, 1W, 2W, 1M, 3M
    val ratePct: Double,
    val collateralType: String, // GC (General Collateral), Special
    val haircutPct: Double,
    val volumeChfM: Double,
    val specialnessBp: Double,
    val gcSpreadBp: Double,
    val saronSpreadBp: Double
)

/**
 * Collateral security asset record.
 */
data class CollateralAsset(
    val isin: String,
    val issuer: String, // Swiss Confederation, Canton Zurich, Pfandbriefbank
    val maturityDate: LocalDate,
    val marketPricePct: Double,
    val yieldPct: Double,
    val haircutPct: Double,
    val isSnbEligible: Boolean = true,
    val nominalChf: Double,
    val marketValueChf: Double,
    val collateralValueChf: Double // marketValue * (1 - haircut)
)

/**
 * Swiss National Bank Policy state.
 */
data class SnbPolicyState(
    val policyRatePct: Double,
    val sightDepositRatePct: Double,
    val saronRatePct: Double,
    val policySpreadBp: Double, // SARON - Policy Rate
    val sightDepositSpreadBp: Double, // SARON - Sight Deposit Rate
    val snbBillsOutstandingChfBn: Double,
    val repoOpsVolumeChfBn: Double,
    val regimeName: String, // e.g. NORMALISATION, LOW-RATE, TIGHTENING
    val isAlertTriggered: Boolean,
    val alertMessage: String
)

/**
 * Swiss Floating SARON Mortgage Position.
 */
data class ChfMortgagePosition(
    val id: String,
    val clientName: String,
    val principalNotionalChf: Double,
    val marginBp: Double, // Margin added to SARON (e.g. +85 bps)
    val paymentFrequencyMonths: Int = 3, // Quarterly
    val currentCompoundedSaronPct: Double,
    val totalEffectiveRatePct: Double, // SARON + Margin
    val quarterlyPaymentChf: Double,
    val remainingBalanceChf: Double,
    val sensitivity100bpChf: Double // Annual interest change if SARON shifts +100bp
)

/**
 * Trade ticket & Portfolio Position.
 */
enum class InstrumentCategory { OIS_SWAP, FUTURE, CAP, FLOOR, SWAPTION, GOVT_BOND, REPO, MORTGAGE }

data class PortfolioPosition(
    val id: String,
    val category: InstrumentCategory,
    val name: String,
    val side: String, // BUY / SELL or PAY / RECEIVE
    val notionalChf: Double,
    val entryRatePct: Double,
    val currentMarkRatePct: Double,
    val presentValueChf: Double,
    val dv01Chf: Double,
    val vegaChf: Double,
    val pnlTodayChf: Double,
    val pnlMtdChf: Double,
    val pnlYtdChf: Double
)

/**
 * Risk Summary for the entire portfolio.
 */
data class RiskSummary(
    val totalNotionalChf: Double,
    val totalPvChf: Double,
    val totalDv01Chf: Double,
    val saronDv01Chf: Double,
    val govtDv01Chf: Double,
    val basisDv01Chf: Double,
    val totalVegaChf: Double,
    val totalGammaChf: Double,
    val keyRateDv01s: Map<String, Double>, // Tenor -> DV01
    val var95Chf: Double,
    val var99Chf: Double,
    val expectedShortfallChf: Double,
    val stressLossChf: Double
)

/**
 * Scenario definition for stress testing.
 */
data class StressScenario(
    val id: String,
    val name: String,
    val description: String,
    val snbShiftBp: Double = 0.0,
    val saronShiftBp: Double = 0.0,
    val curveShiftType: String = "Parallel", // Parallel, Steepener, Flattener, RepoStress
    val tenorShocksBp: Map<String, Double> = emptyMap()
)

/**
 * RQQL Quantitative Command result.
 */
data class RqqlCommandResult(
    val command: String,
    val executionTimeMs: Long,
    val summaryText: String,
    val resultType: String, // TEXT, TABLE, GRAPH, RISK
    val tableHeaders: List<String> = emptyList(),
    val tableRows: List<List<String>> = emptyList()
)
