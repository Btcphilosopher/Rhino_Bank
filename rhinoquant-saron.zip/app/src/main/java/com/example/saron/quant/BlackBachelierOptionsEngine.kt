package com.example.saron.quant

import com.example.saron.model.OptionType
import com.example.saron.model.PricingModel
import com.example.saron.model.SaronOptionContract
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.sqrt

/**
 * Quantitative Pricing Engine for SARON Options (Caps, Floors, Swaptions).
 * Supports both Black-76 (lognormal vol) and Bachelier (normal vol in basis points) models.
 * Calculates option premium and first/second order Greeks:
 * Delta, Gamma, Vega, Theta, Rho, Volga, Vanna.
 */
object BlackBachelierOptionsEngine {

    /**
     * Standard Normal Cumulative Distribution Function N(x).
     */
    fun cdf(x: Double): Double {
        val a1 = 0.254829592
        val a2 = -0.284496736
        val a3 = 1.421413741
        val a4 = -1.453152027
        val a5 = 1.061405429
        val p = 0.3275911

        val sign = if (x < 0) -1 else 1
        val absX = abs(x) / sqrt(2.0)

        val t = 1.0 / (1.0 + p * absX)
        val y = 1.0 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * exp(-absX * absX)

        return 0.5 * (1.0 + sign * y)
    }

    /**
     * Standard Normal Probability Density Function N'(x).
     */
    fun pdf(x: Double): Double {
        return (1.0 / sqrt(2.0 * Math.PI)) * exp(-0.5 * x * x)
    }

    /**
     * Prices a SARON option contract.
     *
     * @param option Option contract input
     * @param forwardRatePct Current forward SARON rate in percent (e.g. 0.985)
     * @param discountFactor Discount factor to expiry DF(T)
     */
    fun priceOption(
        option: SaronOptionContract,
        forwardRatePct: Double = 0.985,
        discountFactor: Double = 0.980
    ): SaronOptionContract {

        val F = forwardRatePct / 100.0 // Decimal rate
        val K = option.strikeRatePct / 100.0 // Decimal strike
        val T = option.tenorYears.toDouble() // Time to expiry in years
        val N = option.notionalChf
        val isCall = option.optionType == OptionType.CAP || option.optionType == OptionType.PAYER_SWAPTION

        val premium: Double
        val delta: Double
        val gamma: Double
        val vega: Double
        val theta: Double
        val rho: Double
        val vanna: Double
        val volga: Double

        if (option.pricingModel == PricingModel.BACHELIER_NORMAL) {
            // Normal Bachelier Model (vol in bps/year e.g. 25 bps = 0.0025)
            val sigma = option.impliedVolBpOrPct / 10000.0 // Convert bps to decimal
            val sqrtT = sqrt(T.coerceAtLeast(0.001))
            val d = (F - K) / (sigma * sqrtT)

            val nD = pdf(d)
            val cND = cdf(d)

            val intrinsic = if (isCall) (F - K) * cND + sigma * sqrtT * nD else (K - F) * cdf(-d) + sigma * sqrtT * nD

            premium = N * discountFactor * intrinsic * T

            delta = if (isCall) discountFactor * cND else -discountFactor * (1.0 - cND)
            gamma = discountFactor * nD / (sigma * sqrtT)
            vega = N * discountFactor * sqrtT * nD * 0.0001 // Vega per 1 bp vol
            theta = -N * discountFactor * (sigma * nD / (2.0 * sqrtT)) / 365.0
            rho = -T * premium * 0.0001
            vanna = -discountFactor * d * nD / sigma
            volga = vega * d * d
        } else {
            // Black-76 Lognormal Model (vol in % e.g. 15% = 0.15)
            val sigma = (option.impliedVolBpOrPct / 100.0).coerceAtLeast(0.0001)
            val sqrtT = sqrt(T.coerceAtLeast(0.001))

            val d1 = (ln(F / K) + 0.5 * sigma * sigma * T) / (sigma * sqrtT)
            val d2 = d1 - sigma * sqrtT

            val intrinsic = if (isCall) {
                F * cdf(d1) - K * cdf(d2)
            } else {
                K * cdf(-d2) - F * cdf(-d1)
            }

            premium = N * discountFactor * intrinsic * T

            delta = if (isCall) discountFactor * cdf(d1) else -discountFactor * cdf(-d1)
            gamma = discountFactor * pdf(d1) / (F * sigma * sqrtT)
            vega = N * discountFactor * F * sqrtT * pdf(d1) * 0.01 // Vega per 1% vol
            theta = -N * discountFactor * (F * sigma * pdf(d1) / (2.0 * sqrtT)) / 365.0
            rho = -T * premium * 0.0001
            vanna = -discountFactor * pdf(d1) * d2 / sigma
            volga = vega * d1 * d2 / sigma
        }

        return option.copy(
            premiumChf = premium,
            delta = delta,
            gamma = gamma,
            vegaChfPerBp = vega,
            thetaChfPerDay = theta,
            rhoChfPerBp = rho,
            vanna = vanna,
            volga = volga
        )
    }
}
