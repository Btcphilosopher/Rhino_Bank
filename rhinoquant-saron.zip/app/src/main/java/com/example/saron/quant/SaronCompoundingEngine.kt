package com.example.saron.quant

import com.example.saron.model.DailyObservationAudit
import com.example.saron.model.SaronCompoundedResult
import java.time.DayOfWeek
import java.time.LocalDate

/**
 * High-precision SARON Compounding Engine.
 * Implements the official SIX Swiss Exchange SARON Compound Rate mathematical conventions:
 * Day-count: ACT/360
 * Compounding Formula:
 * Compounded_Rate = [ ( \prod_{i=1}^{N_b} (1 + \frac{r_i \cdot n_i}{360}) ) - 1 ] \times \frac{360}{N_d}
 * where:
 * r_i = daily SARON fixing rate for observation day i
 * n_i = number of calendar days rate r_i applies (e.g. 3 for Friday to Monday)
 * N_b = number of business days in observation period
 * N_d = total calendar days in observation period
 */
object SaronCompoundingEngine {

    /**
     * Check if a given date is a Swiss Bank / SIX Repo market holiday (Zurich calendar).
     */
    fun isSwissBusinessDay(date: LocalDate): Boolean {
        val dayOfWeek = date.dayOfWeek
        if (dayOfWeek == DayOfWeek.SATURDAY || dayOfWeek == DayOfWeek.SUNDAY) {
            return false
        }
        val month = date.monthValue
        val day = date.dayOfMonth

        // Swiss fixed-date holidays
        if (month == 1 && (day == 1 || day == 2)) return false // New Year's Day & Berchtoldstag
        if (month == 5 && day == 1) return false               // May Day (Zurich)
        if (month == 8 && day == 1) return false               // Swiss National Day
        if (month == 12 && (day == 25 || day == 26)) return false // Christmas & St Stephen's Day

        // Easter-based approximate movable holidays (Good Friday, Easter Monday, Ascension, Whit Monday)
        val year = date.year
        val easterDate = calculateEaster(year)
        if (date == easterDate.minusDays(2)) return false // Good Friday
        if (date == easterDate.plusDays(1)) return false  // Easter Monday
        if (date == easterDate.plusDays(39)) return false // Ascension Day
        if (date == easterDate.plusDays(50)) return false // Whit Monday

        return true
    }

    /**
     * Calculate Easter Sunday for a given year using Anonymous Gregorian algorithm.
     */
    private fun calculateEaster(year: Int): LocalDate {
        val a = year % 19
        val b = year / 100
        val c = year % 100
        val d = b / 4
        val e = b % 4
        val f = (b + 8) / 25
        val g = (b - f + 1) / 3
        val h = (19 * a + b - d - g + 15) % 30
        val i = c / 4
        val k = c % 4
        val l = (32 + 2 * e + 2 * i - h - k) % 7
        val m = (a + 11 * h + 22 * l) / 451
        val month = (h + l - 7 * m + 114) / 31
        val day = ((h + l - 7 * m + 114) % 31) + 1
        return LocalDate.of(year, month, day)
    }

    /**
     * Roll date to next business day if it falls on a weekend or holiday (Following convention).
     */
    fun rollToBusinessDay(date: LocalDate): LocalDate {
        var current = date
        while (!isSwissBusinessDay(current)) {
            current = current.plusDays(1)
        }
        return current
    }

    /**
     * Get the previous business day.
     */
    fun getPreviousBusinessDay(date: LocalDate): LocalDate {
        var current = date.minusDays(1)
        while (!isSwissBusinessDay(current)) {
            current = current.minusDays(1)
        }
        return current
    }

    /**
     * Calculates the compounded SARON rate over an observation period with complete daily breakdown.
     *
     * @param startDate Start date of contract
     * @param endDate End date of contract
     * @param notionalChf Principal amount in CHF
     * @param observationShiftDays Days to shift observation window (e.g., 2)
     * @param lookbackDays Lookback window days (e.g. 0 or 2)
     * @param paymentLagDays Days between end of observation and payment
     * @param saronRates Map of LocalDate -> SARON Rate (%)
     * @param defaultRate Default SARON rate (%) if date missing from map
     */
    fun calculateCompoundedRate(
        startDate: LocalDate,
        endDate: LocalDate,
        notionalChf: Double = 100_000_000.0,
        tenorLabel: String = "CUSTOM",
        observationShiftDays: Int = 0,
        lookbackDays: Int = 0,
        paymentLagDays: Int = 0,
        saronRates: Map<LocalDate, Double> = emptyMap(),
        defaultRate: Double = 0.9545
    ): SaronCompoundedResult {

        // Adjust observation period for shift & lookback
        val obsStart = startDate.minusDays(lookbackDays.toLong()).minusDays(observationShiftDays.toLong())
        val obsEnd = endDate.minusDays(lookbackDays.toLong()).minusDays(observationShiftDays.toLong())

        val dailyAudits = mutableListOf<DailyObservationAudit>()

        var currDate = obsStart
        var cumulativeFactor = 1.0
        var totalBusinessDays = 0
        var totalCalendarDays = 0

        while (currDate.isBefore(obsEnd)) {
            val isBusDay = isSwissBusinessDay(currDate)
            
            // Find applicable fixing date (if weekend/holiday, prior fixing rate applies)
            val fixingDate = if (isBusDay) currDate else getPreviousBusinessDay(currDate)
            val dailyRatePct = saronRates[fixingDate] ?: defaultRate

            // Calculate number of calendar days this fixing applies to
            var nextDate = currDate.plusDays(1)
            var weightDays = 1
            if (isBusDay) {
                // Count calendar days until next business day
                while (!isSwissBusinessDay(nextDate) && nextDate.isBefore(obsEnd.plusDays(7))) {
                    weightDays++
                    nextDate = nextDate.plusDays(1)
                }
            } else {
                weightDays = 1
            }

            // ACT/360 daily compounding factor: 1 + (r_i * n_i / 36000)
            val dailyFactor = 1.0 + (dailyRatePct * weightDays / 36000.0)
            cumulativeFactor *= dailyFactor

            totalCalendarDays += weightDays
            if (isBusDay) totalBusinessDays++

            val accruedSoFar = notionalChf * (cumulativeFactor - 1.0)

            dailyAudits.add(
                DailyObservationAudit(
                    date = currDate,
                    dayOfWeek = currDate.dayOfWeek.name,
                    isBusinessDay = isBusDay,
                    saronRatePct = dailyRatePct,
                    calendarDaysWeight = weightDays,
                    dailyMultiplier = dailyFactor,
                    cumulativeCompoundedFactor = cumulativeFactor,
                    accruedInterestChf = accruedSoFar
                )
            )

            // Step forward by weightDays
            currDate = currDate.plusDays(weightDays.toLong())
        }

        val N_d = if (totalCalendarDays > 0) totalCalendarDays else 1
        
        // Annualized Compounded Rate in Percent: [ cumulativeFactor - 1 ] * (360 / N_d) * 100
        val compoundedRatePct = (cumulativeFactor - 1.0) * (360.0 / N_d) * 100.0
        val effectiveRatePct = compoundedRatePct
        val totalAccruedInterestChf = notionalChf * (cumulativeFactor - 1.0)

        return SaronCompoundedResult(
            startDate = startDate,
            endDate = endDate,
            tenorLabel = tenorLabel,
            notionalChf = notionalChf,
            compoundedRatePct = compoundedRatePct,
            annualizedRatePct = effectiveRatePct,
            totalAccruedInterestChf = totalAccruedInterestChf,
            observationShiftDays = observationShiftDays,
            lookbackDays = lookbackDays,
            paymentLagDays = paymentLagDays,
            totalCalendarDays = N_d,
            totalBusinessDays = totalBusinessDays,
            dailyAudits = dailyAudits
        )
    }
}
