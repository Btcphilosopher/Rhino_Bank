package com.example.saron.quant

import com.example.saron.model.CollateralAsset
import com.example.saron.model.RepoMarketQuote

/**
 * Swiss Repo & Collateral Analytics Engine.
 * Calculates collateral values:
 * Collateral_Value = Market_Value * (1 - Haircut)
 * Evaluates repo borrowing costs and GC vs Special spreads.
 */
object RepoCollateralEngine {

    /**
     * Calculates collateral value and maximum borrowing capacity.
     */
    fun evaluateCollateral(asset: CollateralAsset): CollateralAsset {
        val marketValue = asset.nominalChf * (asset.marketPricePct / 100.0)
        val collateralVal = marketValue * (1.0 - asset.haircutPct / 100.0)

        return asset.copy(
            marketValueChf = marketValue,
            collateralValueChf = collateralVal
        )
    }

    /**
     * Optimizes funding allocation across available collateral assets.
     */
    fun calculateTotalFundingCapacity(assets: List<CollateralAsset>): Pair<Double, Double> {
        var totalMarketValue = 0.0
        var totalCollateralValue = 0.0

        for (a in assets) {
            val evaluated = evaluateCollateral(a)
            totalMarketValue += evaluated.marketValueChf
            totalCollateralValue += evaluated.collateralValueChf
        }

        return Pair(totalMarketValue, totalCollateralValue)
    }

    /**
     * Compute GC vs Special spread for repo instruments.
     */
    fun calculateRepoSpreads(
        quote: RepoMarketQuote,
        saronRatePct: Double
    ): RepoMarketQuote {
        val gcSpread = (quote.ratePct - saronRatePct) * 100.0 // in bps
        val saronSpread = (quote.ratePct - saronRatePct) * 100.0
        val specialness = if (quote.collateralType == "Special") 15.0 else 0.0

        return quote.copy(
            gcSpreadBp = gcSpread,
            saronSpreadBp = saronSpread,
            specialnessBp = specialness
        )
    }
}
