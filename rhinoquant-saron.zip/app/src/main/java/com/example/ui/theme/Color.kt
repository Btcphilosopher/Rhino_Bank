package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Swiss Institutional Rates Color Palette
val SwissNavyBackground = Color(0xFF0B132B)
val SwissSurfaceDark = Color(0xFF151D33)
val SwissSurfaceVariant = Color(0xFF1E293B)
val SwissBorder = Color(0xFF334155)

val SwissSteelGrey = Color(0xFF64748B)
val SwissTextLight = Color(0xFFF8FAFC)
val SwissTextMuted = Color(0xFF94A3B8)

val SwissRedPrimary = Color(0xFFDC2626)
val SwissRedDark = Color(0xFFB91C1C)
val SwissRedMuted = Color(0xFF7F1D1D)

val SwissAccentBlue = Color(0xFF2563EB)
val SwissGreenPositive = Color(0xFF10B981)
val SwissAmberWarning = Color(0xFFF59E0B)
