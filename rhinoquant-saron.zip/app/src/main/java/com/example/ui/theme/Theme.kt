package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val SwissColorScheme = darkColorScheme(
    primary = SwissRedPrimary,
    onPrimary = Color.White,
    primaryContainer = SwissRedDark,
    onPrimaryContainer = SwissTextLight,
    secondary = SwissAccentBlue,
    onSecondary = Color.White,
    background = SwissNavyBackground,
    onBackground = SwissTextLight,
    surface = SwissSurfaceDark,
    onSurface = SwissTextLight,
    surfaceVariant = SwissSurfaceVariant,
    onSurfaceVariant = SwissTextMuted,
    outline = SwissBorder,
    error = SwissRedPrimary
)

@Composable
fun RhinoQuantSaronTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = SwissColorScheme,
        typography = Typography,
        content = content
    )
}
