package com.example

import com.example.saron.quant.*
import com.example.saron.model.*
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate

class SaronQuantEngineTest {

    @Test
    fun testSwissBusinessDayChecker() {
        val testDateSunday = LocalDate.of(2026, 7, 5) // Sunday
        val testDateMonday = LocalDate.of(2026, 7, 6) // Monday
        val nationalDay = LocalDate.of(2026, 8, 1)    // Swiss National Day

        assertFalse(SaronCompoundingEngine.isSwissBusinessDay(testDateSunday))
        assertTrue(SaronCompoundingEngine.isSwissBusinessDay(testDateMonday))
        assertFalse(SaronCompoundingEngine.isSwissBusinessDay(nationalDay))
    }

    @Test
    fun testSaronCompoundingMathAct360() {
        val start = LocalDate.of(2026, 1, 1)
        val end = LocalDate.of(2026, 4, 1)
        val notional = 100_000_000.0

        val result = SaronCompoundingEngine.calculateCompoundedRate(
            startDate = start,
            endDate = end,
            notionalChf = notional,
            tenorLabel = "3M",
            defaultRate = 1.0000 // 1.00% flat
        )

        assertTrue(result.compoundedRatePct > 0.99 && result.compoundedRatePct < 1.02)
        assertTrue(result.totalAccruedInterestChf > 0.0)
        assertEquals(90, result.totalCalendarDays)
    }

    @Test
    fun testOisCurveBootstrapper() {
        val valuationDate = LocalDate.of(2026, 10, 8)
        val curve = SaronCurveBootstrapper.bootstrapCurve(
            valuationDate = valuationDate,
            marketQuotes = mapOf("1Y" to 1.00, "5Y" to 1.20)
        )

        assertNotNull(curve)
        assertTrue(curve.isNotEmpty())
        assertTrue(curve.first().discountFactor < 1.0)
    }

    @Test
    fun testBlackBachelierOptionsEngine() {
        val option = SaronOptionContract(
            id = "TEST-CAP",
            optionType = OptionType.CAP,
            notionalChf = 10_000_000.0,
            strikeRatePct = 1.25,
            expiryDate = LocalDate.now().plusYears(1),
            tenorYears = 1,
            pricingModel = PricingModel.BACHELIER_NORMAL,
            impliedVolBpOrPct = 25.0,
            premiumChf = 0.0,
            delta = 0.0,
            gamma = 0.0,
            vegaChfPerBp = 0.0,
            thetaChfPerDay = 0.0,
            rhoChfPerBp = 0.0,
            vanna = 0.0,
            volga = 0.0
        )

        val priced = BlackBachelierOptionsEngine.priceOption(option, forwardRatePct = 1.00)
        assertTrue(priced.premiumChf > 0.0)
        assertTrue(priced.delta > 0.0)
    }

    @Test
    fun testRqqlParser() {
        val res = RqqlParser.executeQuery("GET SARON COMPOUND(3M)")
        assertNotNull(res)
        assertTrue(res.summaryText.contains("Compounded SARON"))
    }
}
