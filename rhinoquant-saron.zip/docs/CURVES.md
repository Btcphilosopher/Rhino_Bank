# CHF SARON OIS CURVE BOOTSTRAPPING

## Curve Construction

The CHF OIS curve is constructed from a sequence of benchmark instruments:
- Overnight (ON)
- Short tenors: 1W, 1M, 3M, 6M, 9M
- Long tenors: 1Y, 2Y, 3Y, 4Y, 5Y, 7Y, 10Y, 15Y, 20Y, 30Y

## Formulas

1. **Short-Term Discount Factor ($\le 1Y$)**:
   $$DF(t) = \frac{1}{1 + S_t \cdot \frac{t}{360}}$$

2. **Long-Term Discount Factor ($> 1Y$)**:
   $$DF(t) = e^{-R_{zero}(t) \cdot t}$$

3. **Forward Rate**:
   $$F(t_1, t_2) = \frac{360}{d} \cdot \left( \frac{DF(t_1)}{DF(t_2)} - 1 \right)$$

4. **DV01 (Dollar Value of a 1bp shift)**:
   $$DV01 = Notional \cdot t \cdot DF(t) \cdot 0.0001$$
