# SNB MONETARY POLICY TRANSMISSION

## Policy Mechanics

The Swiss National Bank (SNB) sets its policy interest rate to maintain price stability.
The policy transmission flow:
1. **SNB Policy Target Rate**
2. **SNB Repo & SNB Bills Liquidity Operations**
3. **SIX Repo Market Trading & SARON Fixing**
4. **CHF OIS Yield Curve & Swaps**
5. **CHF Mortgage & Credit Funding Rates**
