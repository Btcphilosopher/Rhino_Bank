# DATA MODEL & DOMAIN SCHEMAS

## Data Models Summary

- `SaronObservation`: Single rate observation record with timestamp, status, and provenance.
- `SaronFixing`: Official SIX fixing record (12:00, 16:00, 18:00) with repo volume.
- `DailyObservationAudit`: Day-by-day compounding audit entry.
- `SaronCompoundedResult`: Output of compounding engine with daily audits.
- `SaronCurvePoint`: Bootstrapped yield curve tenor point.
- `OisSwapInstrument`: OIS swap definition with cashflow breakdown.
- `SaronFutureContract`: Quarterly SARON futures contract.
- `SaronOptionContract`: Options pricer model with full Greeks.
- `ChfMortgagePosition`: Floating SARON mortgage position ($SARON + Margin$).
- `PortfolioPosition`: Mark-to-market position with DV01 & Vega exposures.
- `RiskSummary`: Portfolio level risk aggregation and Monte Carlo VaR.
- `StressScenario`: Macro stress testing scenario parameters.
- `RqqlCommandResult`: Parsed RQQL console query result.
