# DEPLOYMENT & BUILD GUIDE

## Build System

RHINOQUANT SARON is built using Gradle Kotlin DSL (.gradle.kts).

### Command-line Commands

- **Build APK**:
  ```sh
  gradle assembleDebug
  ```
- **Run Unit Tests**:
  ```sh
  gradle :app:testDebugUnitTest
  ```
