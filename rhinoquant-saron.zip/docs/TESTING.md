# QUANTITATIVE TESTING SUITE

## Test Coverage

Quantitative unit tests in `app/src/test/java/com/example/SaronQuantEngineTest.kt` verify:
1. `testSwissBusinessDayChecker`: Zurich bank holiday & weekend roll rules.
2. `testSaronCompoundingMathAct360`: ACT/360 daily compounding calculations.
3. `testOisCurveBootstrapper`: Curve bootstrapping, discount factors, and zero rates.
4. `testBlackBachelierOptionsEngine`: Bachelier normal option pricing and Greeks.
5. `testRqqlParser`: RQQL query parsing and structured table outputs.

To execute tests:
```sh
gradle :app:testDebugUnitTest
```
