# PORTFOLIO RISK & MONTE CARLO VaR

## Risk Measures

1. **DV01**: Present value impact of a 1 basis point (+0.01%) parallel shift in the yield curve.
2. **Key-Rate DV01**: Rate sensitivity decomposed by maturity bucket (1M, 3M, 1Y, 2Y, 5Y, 10Y, 30Y).
3. **Vega**: Sensitivity of options portfolio to a 1 bp shift in implied volatility.
4. **Monte Carlo Value-at-Risk (VaR)**:
   - 1000-draw deterministic normal simulation.
   - Calculates 1D 95% VaR, 1D 99% VaR, and Expected Shortfall (CVaR).
