# COLLATERAL VALUATION & HAIRCUTS

## Valuation Formula

$$Market\_Value = Nominal \times \frac{Clean\_Price}{100} + Accrued\_Interest$$

$$Collateral\_Value = Market\_Value \times \left(1 - \frac{Haircut\_Pct}{100}\right)$$

SNB-eligible collateral includes Swiss Confederation bonds (Eidgenossen), Cantonal bonds, and Pfandbriefbank covered bonds.
