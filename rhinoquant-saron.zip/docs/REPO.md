# SWISS REPO MARKET & SPREADS

## Market Architecture

SARON is derived directly from transactions and binding quotes on the SIX Repo trading platform.

## GC vs Special Spreads

- **General Collateral (GC)**: High-quality basket of eligible Swiss government and cantonal bonds where specific ISINs are interchangeable.
- **Special Repo**: Repo operations where a specific ISIN is demanded, giving rise to a "Specialness Premium" ($Rate_{Special} < Rate_{GC}$).
- **Spreads**:
  $$GC\_Spread = Rate_{Repo} - Rate_{SARON}$$
