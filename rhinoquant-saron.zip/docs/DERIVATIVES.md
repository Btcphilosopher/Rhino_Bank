# SARON FUTURES & OPTIONS PRICING

## 3M SARON Futures
Quarterly IMM contracts (March, June, September, December).
- Quoted Price: $P = 100 - Implied\_SARON\_Rate$
- Implied SARON Rate: $100 - P$

## Options Models
1. **Normal Bachelier Model** (Volatility in basis points per year):
   $$d = \frac{F - K}{\sigma_{normal} \sqrt{T}}$$
   $$Call = N \cdot DF(T) \cdot \left[ (F - K) \Phi(d) + \sigma_{normal} \sqrt{T} \phi(d) \right] \cdot T$$
2. **Greeks**:
   - $\Delta$: Delta $\frac{\partial V}{\partial F}$
   - $Vega$: Sensitivity to 1bp vol shift
   - $Theta$: 1-day time decay
