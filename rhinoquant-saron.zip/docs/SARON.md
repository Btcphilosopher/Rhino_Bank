# SIX SWISS EXCHANGE SARON METHODOLOGY

## Overview

**SARON (Swiss Average Rate Overnight)** is the primary Swiss franc overnight secured money-market benchmark rate. It is administered and published by SIX Financial Information AG.

Unlike unsecured interbank rates (such as historical LIBOR), SARON is backed by actual transactions and binding quotes in the Swiss Franc Repo market.

## Key Characteristics

- **Underlying Market**: Swiss Repo Market (Swiss Franc GC & Special repo).
- **Day-Count Convention**: **ACT/360** (Actual calendar days / 360 days per year).
- **Fixings Schedule**:
  - **12:00 Fixing**: Provisional intraday fixing published at 12:00 CET.
  - **16:00 Fixing**: Provisional intraday fixing published at 16:00 CET.
  - **18:00 Fixing**: Official benchmark fixing published at 18:00 CET, serving as the official reference for derivatives, OIS swaps, floating-rate notes, and mortgages.

## Continuous Calculation & Filtering

SIX calculates SARON continuously during the trading day using a trimmed volume-weighted average rate algorithm. Outliers and non-representative quotes are filtered to prevent manipulation.
