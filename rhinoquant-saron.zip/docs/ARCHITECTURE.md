# SYSTEM ARCHITECTURE - RHINOQUANT SARON

## Overview

RHINOQUANT SARON is structured according to Clean Architecture principles, ensuring strict separation between financial quantitative calculation logic, data repository management, state presentation, and Jetpack Compose user interfaces.

```
┌─────────────────────────────────────────────────────────────┐
│                    JETPACK COMPOSE UI                       │
│  (Overview, Fixings, Compounding, Curves, Risk, RQQL, etc.) │
└──────────────────────────────┬──────────────────────────────┘
                               │ StateFlow
┌──────────────────────────────▼──────────────────────────────┐
│                  SARON TERMINAL VIEWMODEL                   │
└──────────────────────────────┬──────────────────────────────┘
                               │ Repository / Quant Engine Call
┌──────────────────────────────┼──────────────────────────────┐
│                              │                              │
┌───────────────▼──────────────┐┌──────────────▼──────────────┐
│   SARON MARKET REPOSITORY    ││    QUANTITATIVE ENGINES     │
│ (Simulated / Live Market Data)││ - Compounding Engine        │
└──────────────────────────────┘│ - Curve Bootstrapper        │
                                │ - OIS Swap Pricer           │
                                │ - Black/Bachelier Options   │
                                │ - Risk & Monte Carlo VaR    │
                                │ - RQQL Parser               │
                                └─────────────────────────────┘
```

## Module Boundaries

1. **`com.example.saron.model`**: Strongly typed domain data classes (`SaronObservation`, `SaronFixing`, `SaronCompoundedResult`, `SaronCurvePoint`, `OisSwapInstrument`, `SaronOptionContract`, `RiskSummary`, `StressScenario`, `RqqlCommandResult`).
2. **`com.example.saron.quant`**: Pure mathematical and quantitative algorithms with zero UI dependencies (`SaronCompoundingEngine`, `SaronCurveBootstrapper`, `OisPricingEngine`, `BlackBachelierOptionsEngine`, `RepoCollateralEngine`, `RiskAndScenarioEngine`, `SnbTransmissionEngine`, `RqqlParser`).
3. **`com.example.saron.data`**: Market repository managing StateFlow streams for ticks, fixings, curves, repo, futures, options, and trades (`SaronMarketRepository`).
4. **`com.example.saron.viewmodel`**: Coordinates active workspace state, parameter updates, RQQL executions, scenario shocks, and portfolio risk calculations (`SaronTerminalViewModel`).
5. **`com.example.saron.ui`**: Swiss institutional Jetpack Compose interface with custom Canvas charts, high-density data tables, and tabbed workspace components (`TerminalHeader`, `WorkspaceSelector`, `OisCurveChart`, Workspaces).
