# SARON COMPOUNDING MATHEMATICS

## Mathematical Formula

Because SARON is an overnight rate, longer contractual tenors (e.g., 1M, 3M, 6M, 12M) are calculated using daily compounding over the observation period:

$$R_{comp} = \left[ \prod_{i=1}^{N_b} \left(1 + \frac{r_i \cdot n_i}{36000}\right) - 1 \right] \times \frac{360}{N_d} \times 100$$

Where:
- $r_i$: Daily SARON fixing rate in percent (%) on business day $i$.
- $n_i$: Number of calendar days for which rate $r_i$ applies (e.g., 3 days for Friday fixings covering Friday, Saturday, Sunday).
- $N_b$: Total number of Swiss business days in the observation period.
- $N_d$: Total calendar days in the observation period ($\sum n_i$).

## Conventions & Conventions Supported

1. **Observation Shift**: Shifts the observation period back by $S$ business days relative to the interest payment period.
2. **Lookback Window**: Applies a backward shift of $L$ days without shifting weight factors.
3. **Payment Lag**: Introduces a $P$-day delay between the observation end date and actual cash settlement.
4. **Swiss Zurich Holiday Calendar**: Accounts for Swiss National Day (Aug 1), Berchtoldstag (Jan 2), New Year's Day, Christmas, St. Stephen's Day, Good Friday, Easter Monday, Ascension, and Whit Monday.
