# SARON OIS SWAP PRICING

## Valuation Logic

A SARON Overnight Index Swap (OIS) exchanges a fixed interest payment for a compounded SARON floating payment:

$$NPV = PV_{Fixed} - PV_{Floating}$$

For a Receive Fixed OIS:
- $PV_{Fixed} = N \cdot R_{fixed} \cdot \sum \Delta t_i \cdot DF(t_i)$
- $PV_{Floating} = N \cdot \sum F(t_{i-1}, t_i) \cdot \Delta t_i \cdot DF(t_i)$
- **Par Fixed Rate**:
  $$R_{par} = \frac{\sum F(t_{i-1}, t_i) \cdot \Delta t_i \cdot DF(t_i)}{\sum \Delta t_i \cdot DF(t_i)}$$
