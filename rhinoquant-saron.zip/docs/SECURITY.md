# SECURITY & GOVERNANCE CONTROLS

## Governance Features

1. **Immutable Audit Trail**: Day-by-day compounding calculation breakdown is preserved without loss of precision.
2. **Data Provenance**: Every tick is tagged as `PRIME`, `DERIVED`, or `SIMULATED`.
3. **Secrets Management**: No API keys or credentials hardcoded; managed via `.env` / `.env.example` and injected via `BuildConfig`.
