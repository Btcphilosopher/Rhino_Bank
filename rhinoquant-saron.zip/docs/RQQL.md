# RHINOQUANT QUERY LANGUAGE (RQQL) SPECIFICATION

## Overview

**RQQL (RhinoQuant Query Language)** is a domain-specific query language for executing quantitative analytics, pricing, and risk commands directly from the terminal console.

## Supported Commands

| Query Command | Description | Output Type |
|---|---|---|
| `GET SARON` | Retrieves current official SARON fixings and intraday statistics | Text / Table |
| `GET SARON(18:00)` | Official 18:00 SIX benchmark fixing details and trade volume | Text |
| `GET SARON COMPOUND(3M)` | 3M SARON Compounding calculation audit breakdown | Table |
| `GET CHF OIS CURVE` | Bootstrapped SARON OIS yield curve table (ON to 30Y) | Table |
| `GET SARON VS SNB` | SNB Policy rate transmission & policy spread analytics | Summary |
| `PRICE SARON OIS 5Y` | Prices a 5Y SARON OIS swap with NPV and DV01 | Table |
| `DV01 PORTFOLIO` | Portfolio risk decomposition and Monte Carlo VaR | Risk Report |
| `STRESS SARON +50BP` | Reprices portfolio under a +50bp rate shock scenario | Table |
| `FORECAST SARON 12M` | Multi-horizon quantitative SARON forecast model | Table |
