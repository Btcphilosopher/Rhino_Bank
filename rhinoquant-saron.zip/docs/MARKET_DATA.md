# MARKET DATA & PROVENANCE ARCHITECTURE

## Data Quality & Provenance Flags

Every observation in RHINOQUANT SARON is tagged with provenance metadata:
- `PRIME`: Validated SIX repo market fixing.
- `DERIVED`: Computed compound rate, zero curve, or swap par rate.
- `SIMULATED`: Synthetic demo market environment tick.

## SIX Market Connectivity Interface

The platform provides abstract market data adapter interfaces for SIX Swiss Exchange, Bloomberg, Refinitiv, FIX, and REST feeds.
