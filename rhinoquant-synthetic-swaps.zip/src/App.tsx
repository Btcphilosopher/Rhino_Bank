import React, { useState, useEffect } from 'react';
import { Header, ActiveTab } from './components/Header';
import { FlagshipShowcase } from './components/FlagshipShowcase';
import { SwapFactory } from './components/SwapFactory';
import { SwapDetail } from './components/SwapDetail';
import { TradingBlotter } from './components/TradingBlotter';
import { RFQDesk } from './components/RFQDesk';
import { PortfolioView } from './components/PortfolioView';
import { RiskWaterfallView } from './components/RiskWaterfallView';
import { CurveViewer } from './components/CurveViewer';
import { CollateralNettingView } from './components/CollateralNettingView';
import { CompressionDesk } from './components/CompressionDesk';
import { ScenarioLab } from './components/ScenarioLab';
import { DisputeCenter } from './components/DisputeCenter';
import { ModelGovernanceView } from './components/ModelGovernanceView';
import { AIQuantAssistant } from './components/AIQuantAssistant';
import { APIDocsModal } from './components/APIDocsModal';

import { CanonicalSwap, YieldCurve, VolatilitySurface, NettingSet, DisputeRecord, ModelGovernance } from './types/swap';
import { INITIAL_SWAPS, INITIAL_YIELD_CURVES, INITIAL_VOLATILITY_SURFACES, INITIAL_NETTING_SETS, INITIAL_DISPUTES, INITIAL_MODEL_GOVERNANCE } from './data/seedData';
import { priceSwap } from './engine/pricing';
import { calculateSwapRisk } from './engine/risk';
import { applyCurveShock } from './engine/curves';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('FACTORY');
  const [selectedSwapId, setSelectedSwapId] = useState<string | null>(null);

  const [swaps, setSwaps] = useState<CanonicalSwap[]>([]);
  const [curves, setCurves] = useState<YieldCurve[]>(INITIAL_YIELD_CURVES);
  const [volSurfaces] = useState<VolatilitySurface[]>(INITIAL_VOLATILITY_SURFACES);
  const [nettingSets] = useState<NettingSet[]>(INITIAL_NETTING_SETS);
  const [disputes] = useState<DisputeRecord[]>(INITIAL_DISPUTES);
  const [models] = useState<ModelGovernance[]>(INITIAL_MODEL_GOVERNANCE);

  const [showApiDocs, setShowApiDocs] = useState<boolean>(false);

  // Fetch initial swaps from API or seed
  useEffect(() => {
    const fetchSwaps = async () => {
      try {
        const res = await fetch('/v1/swaps');
        if (res.ok) {
          const data = await res.json();
          if (data.swaps && data.swaps.length > 0) {
            setSwaps(data.swaps);
            return;
          }
        }
      } catch (err) {
        console.warn('API fetch fell back to local state:', err);
      }
      // Fallback local init
      const primaryCurve = curves[0];
      const initialPriced = INITIAL_SWAPS.map((s) => {
        const priced = priceSwap(s, primaryCurve);
        priced.swap.risk = calculateSwapRisk(priced.swap, primaryCurve);
        return priced.swap;
      });
      setSwaps(initialPriced);
    };

    fetchSwaps();
  }, []);

  // Total Portfolio PV
  const totalPv = swaps.reduce((acc, s) => acc + s.valuation.cleanPv, 0);

  // Handlers
  const handleSwapCreated = (newSwap: CanonicalSwap) => {
    const primaryCurve = curves[0];
    const priced = priceSwap(newSwap, primaryCurve);
    priced.swap.risk = calculateSwapRisk(priced.swap, primaryCurve);

    setSwaps([priced.swap, ...swaps]);
    setSelectedSwapId(priced.swap.swapId);
  };

  const handleAmendSwap = (swapId: string, updates: Partial<CanonicalSwap>) => {
    const primaryCurve = curves[0];
    setSwaps(
      swaps.map((s) => {
        if (s.swapId === swapId) {
          const updated = {
            ...s,
            ...updates,
            version: s.version + 1,
            contractStatus: 'AMENDED' as const,
            updatedAt: new Date().toISOString(),
          };
          const priced = priceSwap(updated, primaryCurve);
          priced.swap.risk = calculateSwapRisk(priced.swap, primaryCurve);
          return priced.swap;
        }
        return s;
      })
    );
  };

  const handleTerminateSwap = (swapId: string) => {
    setSwaps(
      swaps.map((s) => {
        if (s.swapId === swapId) {
          return {
            ...s,
            contractStatus: 'TERMINATED' as const,
            updatedAt: new Date().toISOString(),
          };
        }
        return s;
      })
    );
  };

  const handleRunCurveShock = async (shiftBp: number) => {
    const shocked = applyCurveShock(curves[0], 'PARALLEL_BP', shiftBp);
    setCurves([shocked, ...curves.slice(1)]);

    // Re-value all swaps with shocked curve
    const updatedSwaps = swaps.map((s) => {
      const priced = priceSwap(s, shocked);
      priced.swap.risk = calculateSwapRisk(priced.swap, shocked);
      return priced.swap;
    });

    setSwaps(updatedSwaps);

    // Call API shock if available
    try {
      await fetch('/v1/curves/shock', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ shiftBp, shockType: 'PARALLEL_BP' }),
      });
    } catch (e) {
      // Local fallback handled
    }
  };

  const selectedSwap = swaps.find((s) => s.swapId === selectedSwapId);

  return (
    <div className="min-h-screen bg-[#0B0E14] text-slate-100 font-sans flex flex-col">
      {/* Top Bar Header Contract */}
      <Header
        activeTab={activeTab}
        setActiveTab={(tab) => {
          setActiveTab(tab);
          setSelectedSwapId(null);
        }}
        onOpenApiDocs={() => setShowApiDocs(true)}
        swapsCount={swaps.length}
        totalPv={totalPv}
      />

      <main className="flex-1 max-w-[1600px] w-full mx-auto p-4 space-y-6">
        {/* Flagship Demonstration Banner */}
        {!selectedSwapId && (
          <FlagshipShowcase
            onSelectSwap={(id) => setSelectedSwapId(id)}
            onRunCurveShock={handleRunCurveShock}
            swaps={swaps}
          />
        )}

        {/* Selected Swap Deep View */}
        {selectedSwapId && selectedSwap ? (
          <SwapDetail
            swap={selectedSwap}
            onBack={() => setSelectedSwapId(null)}
            onAmendSwap={handleAmendSwap}
            onTerminateSwap={handleTerminateSwap}
          />
        ) : (
          <>
            {activeTab === 'FACTORY' && (
              <SwapFactory onSwapCreated={handleSwapCreated} yieldCurve={curves[0]} />
            )}

            {activeTab === 'BLOTTER' && (
              <TradingBlotter
                swaps={swaps}
                onSelectSwap={(id) => setSelectedSwapId(id)}
                onTerminateSwap={handleTerminateSwap}
              />
            )}

            {activeTab === 'RFQ' && (
              <RFQDesk onExecuteQuote={handleSwapCreated} />
            )}

            {activeTab === 'PORTFOLIO' && (
              <PortfolioView swaps={swaps} />
            )}

            {activeTab === 'RISK_WATERFALL' && (
              <RiskWaterfallView swaps={swaps} />
            )}

            {activeTab === 'CURVES' && (
              <CurveViewer
                curves={curves}
                volSurfaces={volSurfaces}
                onShockCurve={handleRunCurveShock}
              />
            )}

            {activeTab === 'COLLATERAL' && (
              <CollateralNettingView nettingSets={nettingSets} swaps={swaps} />
            )}

            {activeTab === 'COMPRESSION' && (
              <CompressionDesk swaps={swaps} />
            )}

            {activeTab === 'SCENARIO' && (
              <ScenarioLab swaps={swaps} yieldCurve={curves[0]} />
            )}

            {activeTab === 'DISPUTE' && (
              <DisputeCenter disputes={disputes} />
            )}

            {activeTab === 'GOVERNANCE' && (
              <ModelGovernanceView models={models} />
            )}

            {activeTab === 'AI_ASSISTANT' && (
              <AIQuantAssistant />
            )}
          </>
        )}
      </main>

      {/* OpenAPI Specs Modal */}
      {showApiDocs && <APIDocsModal onClose={() => setShowApiDocs(false)} />}
    </div>
  );
}
