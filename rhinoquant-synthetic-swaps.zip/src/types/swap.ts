/**
 * RHINOQUANT SYNTHETIC SWAPS - CANONICAL TYPES
 */

export type SwapFamily =
  | 'IRS'
  | 'FX'
  | 'EQUITY'
  | 'COMMODITY'
  | 'CREDIT'
  | 'DIGITAL_ASSET'
  | 'INFRASTRUCTURE';

export type ProductType =
  // Interest Rate Swaps
  | 'Fixed-for-Floating'
  | 'OIS (SONIA/SOFR/€STR)'
  | 'Basis Swap'
  | 'Inflation Swap'
  | 'Cross-Currency Swap'
  | 'Zero-Coupon Swap'
  | 'Forward-Starting Swap'
  | 'Amortising Swap'
  // FX Swaps
  | 'FX Swap'
  | 'NDF Synthetic Swap'
  | 'Quanto Swap'
  | 'Currency Basis Swap'
  // Equity Swaps
  | 'Equity Total Return Swap'
  | 'Index Swap'
  | 'Basket Swap'
  | 'Dividend Swap'
  | 'Volatility Swap'
  | 'Variance Swap'
  // Commodity Swaps
  | 'Oil Forward Swap'
  | 'Gas Swap'
  | 'Power Electricity Swap'
  | 'Hydrogen Swap'
  | 'Metals Swap'
  | 'Freight Swap'
  // Credit Swaps
  | 'Single-Name CDS'
  | 'Index CDS (iTraxx/CDX)'
  | 'Basket CDS / FTD'
  | 'Credit Spread Swap'
  | 'Total Return Credit Swap'
  // Digital Asset Swaps
  | 'BTC Total Return Swap'
  | 'ETH Total Return Swap'
  | 'Crypto Basis Swap'
  | 'Digital Asset Volatility Swap'
  | 'Stablecoin Rate Swap'
  | 'Crypto/GBP Synthetic Swap'
  // Infrastructure Swaps
  | 'Rail Revenue Swap'
  | 'Port Throughput Swap'
  | 'Electricity Generation Swap'
  | 'Hydrogen Production Swap'
  | 'Fibre Capacity Swap'
  | 'Water Demand Swap';

export type ContractStatus =
  | 'DRAFT'
  | 'RFQ_QUOTED'
  | 'EXECUTED'
  | 'CONFIRMED'
  | 'COLLATERALISED'
  | 'ACTIVE'
  | 'AMENDED'
  | 'NOVATED'
  | 'COMPRESSED'
  | 'TERMINATED'
  | 'MATURED';

export type LegDirection = 'PAY' | 'RECEIVE';

export type LegType =
  | 'Fixed'
  | 'Floating'
  | 'EquityReturn'
  | 'CommodityPrice'
  | 'Credit'
  | 'FX'
  | 'Index'
  | 'Inflation'
  | 'DigitalAsset'
  | 'InfrastructureRevenue';

export type DayCountConvention = 'ACT/360' | 'ACT/365' | '30/360' | 'ACT/ACT';
export type BusinessDayConvention = 'MODIFIED_FOLLOWING' | 'FOLLOWING' | 'PRECEDING';
export type PaymentFrequency = 'MONTHLY' | 'QUARTERLY' | 'SEMI_ANNUAL' | 'ANNUAL' | 'AT_MATURITY';

export interface SwapLeg {
  id: string;
  legType: LegType;
  direction: LegDirection;
  currency: string;
  notional: number;
  referenceIndexOrAsset: string;
  calculationMethod: string;
  resetFrequency: PaymentFrequency;
  paymentFrequency: PaymentFrequency;
  fixedRate?: number; // e.g., 0.04125 = 4.125%
  spreadBp?: number;  // e.g. +15 = 15 bps
  multiplier?: number;
  leverage?: number;
  cap?: number;
  floor?: number;
  dayCount: DayCountConvention;
  businessDay: BusinessDayConvention;
  calendar: string;
  settlementConvention: 'PHYSICAL' | 'CASH' | 'SYNTHETIC_NET';
}

export interface Cashflow {
  periodNumber: number;
  startDate: string;
  endDate: string;
  resetDate: string;
  paymentDate: string;
  accrualFraction: number; // e.g. 0.25 for quarterly
  payLegAmount: number;
  receiveLegAmount: number;
  netCashflow: number; // Receive - Pay
  discountFactor: number;
  presentValue: number;
  fixingRateOrPrice: number;
  status: 'UPCOMING' | 'FIXED' | 'SETTLED';
}

export interface SensitivityProfile {
  dv01: number;          // Change in PV for 1bp shift in yield curve (£/bp)
  pv01: number;          // PV of 1bp annuity
  keyRateDv01: {
    '1M'?: number;
    '3M'?: number;
    '6M'?: number;
    '1Y'?: number;
    '2Y'?: number;
    '5Y'?: number;
    '10Y'?: number;
    '30Y'?: number;
  };
  delta?: number;        // Asset/Spot/Equity Delta
  gamma?: number;        // Gamma
  vega?: number;         // Vega (£ / 1% vol)
  theta?: number;        // Daily time decay (£ / day)
  rho?: number;          // Sensitivity to funding rate
  cs01?: number;         // Credit Spread 01 (£ / 1bp spread shift)
  commodityDelta?: number; // £ per unit commodity price shift
  digitalAssetDelta?: number; // £ per 1% crypto price shift
  convexity?: number;
}

export interface ValuationOutput {
  cleanPv: number;
  dirtyPv: number;
  fairSwapRate: number; // e.g., 0.04125
  parSpreadBp: number;
  forwardValue: number;
  discountCurveUsed: string;
  forecastCurveUsed: string;
  pricingModelUsed: string;
  modelVersion: string;
  calibrationTimestamp: string;
  expectedCashflowTotal: number;
}

export interface CollateralTerms {
  agreementType: 'ISDA_2016_VM_IM' | 'SYNTHETIC_CSA_PROPRIETARY';
  variationMarginCurrency: string;
  initialMarginReq: number;
  independentAmount: number;
  threshold: number;
  minimumTransferAmount: number;
  eligibleCollateral: string[]; // ['GBP Cash', 'UK Gilts', 'US Treasuries', 'USDC']
  haircuts: Record<string, number>; // e.g., {'UK Gilts': 0.02, 'USDC': 0.01}
}

export interface CanonicalSwap {
  swapId: string;
  tradeId: string;
  version: number;
  productType: ProductType;
  swapFamily: SwapFamily;
  counterpartyA: string; // Party A (User Desk)
  counterpartyB: string; // Party B (Dealer/Client)
  notional: number;
  currency: string;
  effectiveDate: string;
  maturityDate: string;
  businessDayConvention: BusinessDayConvention;
  dayCountConvention: DayCountConvention;
  paymentCalendar: string;
  legs: SwapLeg[];
  cashflows: Cashflow[];
  valuation: ValuationOutput;
  risk: SensitivityProfile;
  collateralTerms: CollateralTerms;
  currentMarginCall: number; // positive = call to B, negative = pay to B
  nettingSetId: string;
  valuationModel: string;
  modelVersion: string;
  marketDataDependencies: string[];
  contractStatus: ContractStatus;
  lifecycleHistory: LifecycleEvent[];
  auditHash: string;
  createdAt: string;
  updatedAt: string;
  tags?: string[];
}

export interface LifecycleEvent {
  eventId: string;
  timestamp: string;
  eventType:
    | 'TRADE_EXECUTION'
    | 'CONFIRMATION'
    | 'COLLATERAL_POSTED'
    | 'RATE_RESET'
    | 'VALUATION_UPDATE'
    | 'MARGIN_CALL'
    | 'CASHFLOW_SETTLEMENT'
    | 'AMENDMENT'
    | 'NOVATION'
    | 'COMPRESSION'
    | 'TERMINATION'
    | 'MATURITY';
  description: string;
  performedBy: string;
  previousVersion?: number;
  newVersion?: number;
  hash: string;
  financialImpactPvChange?: number;
}

export interface CurvePoint {
  tenor: string; // '1M', '3M', '6M', '1Y', '2Y', '5Y', '10Y', '30Y'
  years: number;
  parRate: number;
  zeroRate: number;
  discountFactor: number;
  forwardRate: number;
}

export interface YieldCurve {
  curveId: string;
  name: string;
  currency: string;
  referenceIndex: string; // e.g., 'SONIA', 'SOFR', '€STR'
  source: 'BOE_LIVE_SYNTHETIC' | 'FED_OIS' | 'ECB_ESTR' | 'RHINO_QUANT_MODEL';
  timestamp: string;
  status: 'LIVE' | 'SIMULATED' | 'HISTORICAL' | 'SCENARIO' | 'MANUAL';
  calibrationStatus: 'CALIBRATED' | 'DEGRADED';
  version: string;
  points: CurvePoint[];
}

export interface VolatilityPoint {
  strike: number;
  expiryMonths: number;
  impliedVol: number; // e.g. 0.22 = 22%
  sabrAlpha?: number;
  sabrBeta?: number;
  sabrRho?: number;
  sabrNu?: number;
}

export interface VolatilitySurface {
  surfaceId: string;
  assetOrIndex: string;
  timestamp: string;
  atmVol: number;
  skewBp: number;
  curvatureBp: number;
  points: VolatilityPoint[];
}

export interface NettingSet {
  nettingSetId: string;
  counterparty: string;
  agreements: string;
  swapsCount: number;
  grossExposure: number;
  netExposure: number;
  collateralPosted: number;
  netUncollateralisedExposure: number;
}

export interface RFQ {
  rfqId: string;
  createdAt: string;
  swapFamily: SwapFamily;
  productType: ProductType;
  notional: number;
  currency: string;
  tenorYears: number;
  payOrReceiveFixed: LegDirection;
  status: 'CREATED' | 'SENT' | 'QUOTED' | 'ACCEPTED' | 'EXECUTED' | 'EXPIRED';
  quotes: Quote[];
}

export interface Quote {
  quoteId: string;
  dealerName: string;
  dealerRating: string;
  fixedRateOffered: number;
  spreadBpOffered: number;
  pvToUser: number;
  creditValuationAdjustment: number;
  validUntil: string;
}

export interface DisputeRecord {
  disputeId: string;
  swapId: string;
  counterparty: string;
  rhinoQuantPv: number;
  counterpartyPv: number;
  variancePv: number;
  attribution: {
    marketDataDiff: number;
    curveDiff: number;
    modelDiff: number;
    termDiff: number;
    timingDiff: number;
  };
  status: 'OPEN' | 'UNDER_REVIEW' | 'RESOLVED';
}

export interface ModelGovernance {
  modelId: string;
  name: string;
  version: string;
  author: string;
  calibrationDate: string;
  parameters: Record<string, number | string>;
  dataDependencies: string[];
  validationStatus: 'PRODUCTION_VALIDATED' | 'CHALLENGER' | 'RESEARCH';
  challengerModelName?: string;
  productionVsChallengerPvDeltaPercent?: number;
}

export interface PnLAttribution {
  date: string;
  openingPv: number;
  curveShiftPnL: number;
  volatilityPnL: number;
  fxPnL: number;
  creditPnL: number;
  thetaTimeDecayPnL: number;
  newTradesPnL: number;
  terminationsPnL: number;
  cashflowsPnL: number;
  closingPv: number;
}
