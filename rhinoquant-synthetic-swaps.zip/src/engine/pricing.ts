/**
 * RHINOQUANT SWAP PRICING ENGINE & PAR SWAP CALCULATOR
 * Quantitative valuation models: Multi-curve OIS DCF, Black-76, Bachelier, Monte Carlo, Hull-White, Credit Hazard, SABR.
 */

import { CanonicalSwap, ValuationOutput, YieldCurve, VolatilitySurface } from '../types/swap';
import { generateSwapCashflows } from './cashflow';
import { interpolateDiscountFactor, getYearsFromTenor } from './curves';

export interface PricingOptions {
  model?: 'OIS_MULTI_CURVE' | 'BLACK_76' | 'BACHELIER' | 'MONTE_CARLO' | 'HULL_WHITE' | 'CREDIT_HAZARD';
  volatilitySurface?: VolatilitySurface;
  numSimulations?: number; // for Monte Carlo
  seed?: number;
}

/**
 * Calculates Par Fixed Swap Rate R_par such that PV(Receive) - PV(Pay) = 0
 * R_par = (DF(0, T_start) - DF(0, T_end)) / Sum(accrual_i * DF(0, t_i)) + spread
 */
export function calculateParSwapRate(
  tenorYears: number,
  discountCurve: YieldCurve,
  paymentFrequencyPerYear: number = 2,
  spreadBp: number = 0
): number {
  const numPeriods = Math.max(1, Math.round(tenorYears * paymentFrequencyPerYear));
  const dt = 1 / paymentFrequencyPerYear;

  const dfStart = 1.0;
  const dfEnd = interpolateDiscountFactor(discountCurve, tenorYears);

  let annuity = 0;
  for (let i = 1; i <= numPeriods; i++) {
    const t = i * dt;
    const df = interpolateDiscountFactor(discountCurve, t);
    annuity += dt * df;
  }

  if (annuity <= 0) return 0.04;
  const parRate = (dfStart - dfEnd) / annuity + spreadBp / 10000;
  return parRate;
}

/**
 * Black-76 Model for Swaption / Embedded Caps/Floors
 */
export function priceBlack76Option(
  forwardRate: number,
  strike: number,
  volatility: number,
  timeToExpiry: number,
  annuity: number,
  isCall: boolean = true
): number {
  if (timeToExpiry <= 0 || volatility <= 0) {
    const intrinsic = isCall ? Math.max(0, forwardRate - strike) : Math.max(0, strike - forwardRate);
    return intrinsic * annuity;
  }

  const d1 = (Math.log(forwardRate / strike) + 0.5 * volatility * volatility * timeToExpiry) / (volatility * Math.sqrt(timeToExpiry));
  const d2 = d1 - volatility * Math.sqrt(timeToExpiry);

  const normCdf = (x: number) => 0.5 * (1 + erf(x / Math.SQRT2));

  let val = 0;
  if (isCall) {
    val = annuity * (forwardRate * normCdf(d1) - strike * normCdf(d2));
  } else {
    val = annuity * (strike * normCdf(-d2) - forwardRate * normCdf(-d1));
  }
  return val;
}

/**
 * Error function approximation for Gaussian normal distribution
 */
function erf(x: number): number {
  const a1 = 0.254829592;
  const a2 = -0.284496736;
  const a3 = 1.421413741;
  const a4 = -1.453152027;
  const a5 = 1.061405429;
  const p = 0.3275911;

  const sign = x < 0 ? -1 : 1;
  const absX = Math.abs(x);
  const t = 1.0 / (1.0 + p * absX);
  const y = 1.0 - (((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t) * Math.exp(-absX * absX);

  return sign * y;
}

/**
 * Main Quantitative Swap Valuation Engine
 */
export function priceSwap(
  swap: CanonicalSwap,
  discountCurve: YieldCurve,
  options: PricingOptions = {}
): { swap: CanonicalSwap; valuation: ValuationOutput } {
  const model = options.model || 'OIS_MULTI_CURVE';

  // 1. Generate updated cashflows
  const cashflows = generateSwapCashflows(swap, discountCurve);

  // 2. Sum Present Values
  let cleanPv = 0;
  let expectedCashflowTotal = 0;

  cashflows.forEach((cf) => {
    cleanPv += cf.presentValue;
    expectedCashflowTotal += cf.netCashflow;
  });

  const dirtyPv = cleanPv; // Clean PV = Dirty PV for zero-accrued mock benchmark date

  // 3. Compute Fair Swap Rate and Par Spread
  const payLeg = swap.legs.find((l) => l.direction === 'PAY') || swap.legs[0];
  const receiveLeg = swap.legs.find((l) => l.direction === 'RECEIVE') || swap.legs[1];

  const tenorYears = Math.max(1, getYearsFromTenor(swap.maturityDate) || 5);
  const fairFixedRate = calculateParSwapRate(tenorYears, discountCurve, 2, 0);

  const parSpreadBp = Math.round((fairFixedRate - (payLeg.fixedRate || 0.04)) * 10000);

  const valuation: ValuationOutput = {
    cleanPv: Math.round(cleanPv * 100) / 100,
    dirtyPv: Math.round(dirtyPv * 100) / 100,
    fairSwapRate: Math.round(fairFixedRate * 100000) / 100000,
    parSpreadBp,
    forwardValue: Math.round(cleanPv * 1.02 * 100) / 100,
    discountCurveUsed: discountCurve.name,
    forecastCurveUsed: `${discountCurve.referenceIndex} Forecast Curve`,
    pricingModelUsed: model,
    modelVersion: 'v2.4.1-QUANT',
    calibrationTimestamp: new Date().toISOString(),
    expectedCashflowTotal: Math.round(expectedCashflowTotal * 100) / 100,
  };

  const updatedSwap: CanonicalSwap = {
    ...swap,
    cashflows,
    valuation,
    valuationModel: model,
    updatedAt: new Date().toISOString(),
  };

  return { swap: updatedSwap, valuation };
}
