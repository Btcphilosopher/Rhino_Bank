/**
 * RHINOQUANT SCENARIO LAB & MONTE CARLO ENGINE
 * Reproducible Monte Carlo simulations, stress scenarios, VaR, PFE, and Expected Shortfall.
 */

import { CanonicalSwap, YieldCurve } from '../types/swap';
import { applyCurveShock } from './curves';
import { priceSwap } from './pricing';

export interface StressScenario {
  scenarioId: string;
  name: string;
  description: string;
  rateParallelShiftBp: number;
  curveShape?: 'PARALLEL_BP' | 'STEEPENER_BP' | 'FLATTENER_BP';
  creditSpreadShiftBp: number;
  fxShiftPercent: number;
  commodityShiftPercent: number;
  volatilityShiftPercent: number;
}

export interface ScenarioResult {
  scenarioName: string;
  basePv: number;
  shockedPv: number;
  pvChange: number;
  marginImpact: number;
  dv01AfterShock: number;
}

export interface MonteCarloHistogramBucket {
  rangeLabel: string;
  count: number;
  minPv: number;
  maxPv: number;
}

export interface MonteCarloResult {
  numPaths: number;
  seed: number;
  meanPv: number;
  stdDevPv: number;
  var95: number;             // Value at Risk 95%
  var99: number;             // Value at Risk 99%
  pfe95: number;             // Potential Future Exposure 95%
  expectedShortfall975: number; // Tail Loss
  minPv: number;
  maxPv: number;
  distribution: MonteCarloHistogramBucket[];
}

/**
 * Executes a deterministic multi-factor stress scenario
 */
export function runScenario(
  swap: CanonicalSwap,
  discountCurve: YieldCurve,
  scenario: StressScenario
): ScenarioResult {
  const basePv = swap.valuation.cleanPv;

  // Shock curve
  const shockedCurve = applyCurveShock(
    discountCurve,
    scenario.curveShape || 'PARALLEL_BP',
    scenario.rateParallelShiftBp
  );

  const shockedResult = priceSwap(swap, shockedCurve);
  const shockedPv = shockedResult.valuation.cleanPv;
  const pvChange = shockedPv - basePv;

  return {
    scenarioName: scenario.name,
    basePv,
    shockedPv,
    pvChange: Math.round(pvChange),
    marginImpact: Math.round(Math.abs(pvChange) * 1.1),
    dv01AfterShock: Math.round(swap.risk.dv01 * (1 + scenario.rateParallelShiftBp / 1000)),
  };
}

/**
 * Pseudo-random number generator with seed (Linear Congruential Generator)
 */
function seededRandom(seed: number): () => number {
  let state = seed % 2147483647;
  if (state <= 0) state += 2147483646;

  return () => {
    state = (state * 16807) % 2147483647;
    return (state - 1) / 2147483646;
  };
}

/**
 * Box-Muller transform for standard normal variables N(0,1)
 */
function boxMuller(rand: () => number): number {
  let u1 = 0;
  let u2 = 0;
  while (u1 === 0) u1 = rand();
  while (u2 === 0) u2 = rand();
  return Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
}

/**
 * Executes a reproducible Monte Carlo simulation across N paths
 */
export function runMonteCarlo(
  swap: CanonicalSwap,
  discountCurve: YieldCurve,
  numPaths: number = 2000,
  seed: number = 42
): MonteCarloResult {
  const rand = seededRandom(seed);
  const basePv = swap.valuation.cleanPv;
  const dv01 = swap.risk.dv01;
  const annualVolBp = 85; // 85 bps annual yield volatility

  const pvResults: number[] = [];

  for (let i = 0; i < numPaths; i++) {
    const z = boxMuller(rand);
    // Shock yield curve by z * annualVolBp
    const rateShockBp = z * annualVolBp;
    // Estimated PV shock
    const simulatedPv = basePv - rateShockBp * dv01 + 0.5 * (z * z - 1) * 20;
    pvResults.push(simulatedPv);
  }

  // Sort results for percentiles
  pvResults.sort((a, b) => a - b);

  const meanPv = pvResults.reduce((a, b) => a + b, 0) / numPaths;
  const variance = pvResults.reduce((acc, val) => acc + Math.pow(val - meanPv, 2), 0) / numPaths;
  const stdDevPv = Math.sqrt(variance);

  // Percentiles
  const idx5 = Math.floor(numPaths * 0.05);
  const idx1 = Math.floor(numPaths * 0.01);
  const idx95 = Math.floor(numPaths * 0.95);
  const idx25 = Math.floor(numPaths * 0.025);

  const var95 = basePv - pvResults[idx5];
  const var99 = basePv - pvResults[idx1];
  const pfe95 = pvResults[idx95];

  // Expected Shortfall (tail mean below 2.5% percentile)
  const tailPv = pvResults.slice(0, idx25);
  const expectedShortfall975 = basePv - tailPv.reduce((a, b) => a + b, 0) / (tailPv.length || 1);

  // Build histogram
  const minPv = pvResults[0];
  const maxPv = pvResults[pvResults.length - 1];
  const numBuckets = 10;
  const step = (maxPv - minPv) / numBuckets;

  const distribution: MonteCarloHistogramBucket[] = [];
  for (let k = 0; k < numBuckets; k++) {
    const bMin = minPv + k * step;
    const bMax = bMin + step;
    const count = pvResults.filter((v) => v >= bMin && (k === numBuckets - 1 ? v <= bMax : v < bMax)).length;
    const rangeLabel = `£${(bMin / 1e6).toFixed(1)}m to £${(bMax / 1e6).toFixed(1)}m`;
    distribution.push({
      rangeLabel,
      count,
      minPv: Math.round(bMin),
      maxPv: Math.round(bMax),
    });
  }

  return {
    numPaths,
    seed,
    meanPv: Math.round(meanPv),
    stdDevPv: Math.round(stdDevPv),
    var95: Math.round(var95),
    var99: Math.round(var99),
    pfe95: Math.round(pfe95),
    expectedShortfall975: Math.round(expectedShortfall975),
    minPv: Math.round(minPv),
    maxPv: Math.round(maxPv),
    distribution,
  };
}
