/**
 * RHINOQUANT CURVE ENGINE
 * Institutional yield curve bootstrapping, interpolation, forward rates, and discount factors.
 */

import { CurvePoint, YieldCurve } from '../types/swap';

export function getYearsFromTenor(tenor: string): number {
  const match = tenor.match(/^(\d+)([DMY])$/);
  if (!match) return 1;
  const val = parseInt(match[1], 10);
  const unit = match[2];
  if (unit === 'D') return val / 365;
  if (unit === 'M') return val / 12;
  if (unit === 'Y') return val;
  return val;
}

/**
 * Calculates discount factor DF(t) given zero rate r and time t
 * DF(t) = exp(-r * t)
 */
export function calculateDiscountFactor(zeroRate: number, years: number): number {
  if (years <= 0) return 1.0;
  return Math.exp(-zeroRate * years);
}

/**
 * Linear/Log-linear Interpolation of Discount Factors
 */
export function interpolateDiscountFactor(curve: YieldCurve, years: number): number {
  if (years <= 0) return 1.0;
  const points = curve.points;
  if (points.length === 0) return 1.0;

  // Extrapolation low
  if (years <= points[0].years) {
    const rate = points[0].zeroRate;
    return Math.exp(-rate * years);
  }

  // Extrapolation high
  if (years >= points[points.length - 1].years) {
    const lastPoint = points[points.length - 1];
    return Math.exp(-lastPoint.zeroRate * years);
  }

  // Bracket points
  for (let i = 0; i < points.length - 1; i++) {
    const p1 = points[i];
    const p2 = points[i + 1];
    if (years >= p1.years && years <= p2.years) {
      const weight = (years - p1.years) / (p2.years - p1.years);
      // Log-linear interpolation on discount factors
      const logDf1 = Math.log(p1.discountFactor);
      const logDf2 = Math.log(p2.discountFactor);
      const logDf = logDf1 + weight * (logDf2 - logDf1);
      return Math.exp(logDf);
    }
  }

  return 1.0;
}

/**
 * Derives Zero Rate from Discount Factor DF(t)
 * r(t) = -ln(DF(t)) / t
 */
export function getZeroRateFromDf(df: number, years: number): number {
  if (years <= 0 || df <= 0) return 0;
  return -Math.log(df) / years;
}

/**
 * Calculates Forward Rate between t1 and t2
 * f(t1, t2) = (ln(DF(t1)) - ln(DF(t2))) / (t2 - t1)
 */
export function getForwardRate(curve: YieldCurve, t1: number, t2: number): number {
  if (t2 <= t1) return 0;
  const df1 = interpolateDiscountFactor(curve, t1);
  const df2 = interpolateDiscountFactor(curve, t2);
  if (df2 <= 0 || df1 <= 0) return 0;
  return (Math.log(df1) - Math.log(df2)) / (t2 - t1);
}

/**
 * Apply Curve Shocks (Parallel Shift, Steepener, Flattener)
 */
export function applyCurveShock(
  curve: YieldCurve,
  shockType: 'PARALLEL_BP' | 'STEEPENER_BP' | 'FLATTENER_BP',
  shiftBp: number
): YieldCurve {
  const shiftDecimal = shiftBp / 10000;
  const newPoints = curve.points.map((pt) => {
    let pointShift = 0;
    if (shockType === 'PARALLEL_BP') {
      pointShift = shiftDecimal;
    } else if (shockType === 'STEEPENER_BP') {
      // Short rates drop/stay, long rates rise
      pointShift = (pt.years / 30) * shiftDecimal;
    } else if (shockType === 'FLATTENER_BP') {
      // Short rates rise, long rates drop
      pointShift = (1 - pt.years / 30) * shiftDecimal;
    }

    const newZeroRate = Math.max(0.0001, pt.zeroRate + pointShift);
    const newDf = calculateDiscountFactor(newZeroRate, pt.years);
    const newParRate = pt.parRate + pointShift;
    const newForward = pt.forwardRate + pointShift;

    return {
      ...pt,
      zeroRate: newZeroRate,
      discountFactor: newDf,
      parRate: newParRate,
      forwardRate: newForward,
    };
  });

  return {
    ...curve,
    status: 'SCENARIO',
    version: `${curve.version}-SHOCKED`,
    points: newPoints,
  };
}
