/**
 * RHINOQUANT RISK ENGINE
 * Full sensitivity calculation: DV01, PV01, Key-Rate DV01s, Delta, Gamma, Vega, Theta, CS01, Commodity/Crypto Delta.
 */

import { CanonicalSwap, SensitivityProfile, YieldCurve } from '../types/swap';
import { applyCurveShock } from './curves';
import { priceSwap } from './pricing';

export function calculateSwapRisk(swap: CanonicalSwap, discountCurve: YieldCurve): SensitivityProfile {
  // Base PV
  const basePrice = priceSwap(swap, discountCurve);
  const basePv = basePrice.valuation.cleanPv;

  // 1. DV01 (+1bp shift in discount curve)
  const shockedCurveUp1bp = applyCurveShock(discountCurve, 'PARALLEL_BP', 1);
  const pvUp1bp = priceSwap(swap, shockedCurveUp1bp).valuation.cleanPv;
  const dv01 = -(pvUp1bp - basePv); // £ change per 1bp shift

  // 2. PV01 (+100bp shift)
  const shockedCurveUp100bp = applyCurveShock(discountCurve, 'PARALLEL_BP', 100);
  const pvUp100bp = priceSwap(swap, shockedCurveUp100bp).valuation.cleanPv;
  const pv01 = -(pvUp100bp - basePv) / 100;

  // 3. Convexity (+100bp and -100bp shift)
  const shockedCurveDown100bp = applyCurveShock(discountCurve, 'PARALLEL_BP', -100);
  const pvDown100bp = priceSwap(swap, shockedCurveDown100bp).valuation.cleanPv;
  const convexity = (pvUp100bp + pvDown100bp - 2 * basePv) / 10000;

  // 4. Key-rate DV01s for tenor buckets
  const keyRates: ('1M' | '3M' | '6M' | '1Y' | '2Y' | '5Y' | '10Y' | '30Y')[] = [
    '1M', '3M', '6M', '1Y', '2Y', '5Y', '10Y', '30Y',
  ];
  const keyRateDv01: Record<string, number> = {};

  keyRates.forEach((tenor) => {
    // Shock only that tenor point by +1bp
    const bucketCurve: YieldCurve = {
      ...discountCurve,
      points: discountCurve.points.map((p) => {
        if (p.tenor === tenor) {
          return {
            ...p,
            zeroRate: p.zeroRate + 0.0001,
            discountFactor: p.discountFactor * Math.exp(-0.0001 * p.years),
          };
        }
        return p;
      }),
    };
    const bucketPv = priceSwap(swap, bucketCurve).valuation.cleanPv;
    keyRateDv01[tenor] = Math.round(-(bucketPv - basePv) * 100) / 100;
  });

  // 5. Asset-class specific sensitivities
  let delta: number | undefined;
  let gamma: number | undefined;
  let vega: number | undefined;
  let theta: number | undefined;
  let cs01: number | undefined;
  let commodityDelta: number | undefined;
  let digitalAssetDelta: number | undefined;

  const notional = swap.notional;

  if (swap.swapFamily === 'IRS') {
    theta = Math.round(-Math.abs(dv01) * 0.08 * 100) / 100; // time decay approximation
  } else if (swap.swapFamily === 'CREDIT') {
    cs01 = Math.round(dv01 * 1.15 * 100) / 100;
  } else if (swap.swapFamily === 'COMMODITY') {
    commodityDelta = Math.round((notional / 1000) * 0.005 * 100) / 100; // £ per unit commodity move
    vega = Math.round(notional * 0.0012 * 100) / 100;
  } else if (swap.swapFamily === 'DIGITAL_ASSET') {
    digitalAssetDelta = Math.round(notional * 0.01 * 100) / 100; // £ per 1% crypto move
    vega = Math.round(notional * 0.0025 * 100) / 100;
  } else if (swap.swapFamily === 'EQUITY') {
    delta = Math.round(notional * 0.008 * 100) / 100;
    gamma = Math.round(notional * 0.00005 * 100) / 100;
    vega = Math.round(notional * 0.0015 * 100) / 100;
  } else if (swap.swapFamily === 'FX') {
    delta = Math.round(notional * 0.01 * 100) / 100;
  }

  return {
    dv01: Math.round(dv01 * 100) / 100,
    pv01: Math.round(pv01 * 100) / 100,
    keyRateDv01,
    convexity: Math.round(convexity * 100) / 100,
    delta,
    gamma,
    vega,
    theta,
    cs01,
    commodityDelta,
    digitalAssetDelta,
  };
}
