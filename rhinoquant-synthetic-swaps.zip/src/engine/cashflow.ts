/**
 * RHINOQUANT CASHFLOW ENGINE
 * Deterministic payment schedule generation and period revaluation.
 */

import { Cashflow, CanonicalSwap, YieldCurve } from '../types/swap';
import { interpolateDiscountFactor, getForwardRate } from './curves';

export function getPaymentFrequencyInMonths(freq: string): number {
  switch (freq) {
    case 'MONTHLY':
      return 1;
    case 'QUARTERLY':
      return 3;
    case 'SEMI_ANNUAL':
      return 6;
    case 'ANNUAL':
      return 12;
    default:
      return 3;
  }
}

/**
 * Generates deterministic cashflow schedule for a CanonicalSwap given a yield curve
 */
export function generateSwapCashflows(swap: CanonicalSwap, discountCurve: YieldCurve): Cashflow[] {
  const payLeg = swap.legs.find((l) => l.direction === 'PAY') || swap.legs[0];
  const receiveLeg = swap.legs.find((l) => l.direction === 'RECEIVE') || swap.legs[1] || swap.legs[0];

  const startDate = new Date(swap.effectiveDate);
  const endDate = new Date(swap.maturityDate);
  const totalMonths = (endDate.getFullYear() - startDate.getFullYear()) * 12 + (endDate.getMonth() - startDate.getMonth());

  const monthsPerPeriod = getPaymentFrequencyInMonths(payLeg.paymentFrequency || 'QUARTERLY');
  const numPeriods = Math.max(1, Math.round(totalMonths / monthsPerPeriod));

  const cashflows: Cashflow[] = [];

  for (let i = 1; i <= numPeriods; i++) {
    const pStartMonths = (i - 1) * monthsPerPeriod;
    const pEndMonths = i * monthsPerPeriod;

    const periodStartDate = new Date(startDate);
    periodStartDate.setMonth(periodStartDate.getMonth() + pStartMonths);

    const periodEndDate = new Date(startDate);
    periodEndDate.setMonth(periodEndDate.getMonth() + pEndMonths);

    const resetDate = new Date(periodStartDate);
    resetDate.setDate(resetDate.getDate() - 2); // T-2 fixing convention

    const paymentDate = new Date(periodEndDate);

    const startYears = pStartMonths / 12;
    const endYears = pEndMonths / 12;
    const accrualFraction = (pEndMonths - pStartMonths) / 12; // Day count approximation

    // Determine forward/fixing rate for Pay Leg
    let payLegAmount = 0;
    let payRate = payLeg.fixedRate || 0.04;
    if (payLeg.legType === 'Floating' || payLeg.legType === 'CommodityPrice' || payLeg.legType === 'DigitalAsset') {
      const fwd = getForwardRate(discountCurve, startYears, endYears);
      const spread = (payLeg.spreadBp || 0) / 10000;
      payRate = fwd + spread;
    }
    payLegAmount = payLeg.notional * payRate * accrualFraction;

    // Determine forward/fixing rate for Receive Leg
    let receiveLegAmount = 0;
    let receiveRate = receiveLeg.fixedRate || 0.04;
    if (receiveLeg.legType === 'Floating' || receiveLeg.legType === 'CommodityPrice' || receiveLeg.legType === 'DigitalAsset' || receiveLeg.legType === 'EquityReturn') {
      const fwd = getForwardRate(discountCurve, startYears, endYears);
      const spread = (receiveLeg.spreadBp || 0) / 10000;
      receiveRate = fwd + spread;
    }
    receiveLegAmount = receiveLeg.notional * receiveRate * accrualFraction;

    const netCashflow = receiveLegAmount - payLegAmount;
    const df = interpolateDiscountFactor(discountCurve, endYears);
    const pv = netCashflow * df;

    const fixingRateOrPrice = receiveLeg.legType === 'Fixed' ? payRate : receiveRate;

    cashflows.push({
      periodNumber: i,
      startDate: periodStartDate.toISOString().split('T')[0],
      endDate: periodEndDate.toISOString().split('T')[0],
      resetDate: resetDate.toISOString().split('T')[0],
      paymentDate: paymentDate.toISOString().split('T')[0],
      accrualFraction,
      payLegAmount,
      receiveLegAmount,
      netCashflow,
      discountFactor: df,
      presentValue: pv,
      fixingRateOrPrice,
      status: i === 1 ? 'FIXED' : 'UPCOMING',
    });
  }

  return cashflows;
}
