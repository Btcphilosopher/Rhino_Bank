/**
 * RHINOQUANT PORTFOLIO COMPRESSION ENGINE
 * Identifies offsetting swaps, simulates tear-up, and calculates notional and risk reduction.
 */

import { CanonicalSwap } from '../types/swap';

export interface CompressionOpportunity {
  swapAId: string;
  swapBId: string;
  counterparty: string;
  productType: string;
  notionalA: number;
  notionalB: number;
  compressibleNotional: number;
  pvA: number;
  pvB: number;
  netPvImpact: number;
  dv01Reduction: number;
  status: 'IDENTIFIED' | 'SIMULATED' | 'EXECUTED';
}

/**
 * Scans portfolio to find pairs of offsetting swaps for compression
 */
export function identifyCompressionOpportunities(swaps: CanonicalSwap[]): CompressionOpportunity[] {
  const opportunities: CompressionOpportunity[] = [];

  for (let i = 0; i < swaps.length; i++) {
    for (let j = i + 1; j < swaps.length; j++) {
      const s1 = swaps[i];
      const s2 = swaps[j];

      if (
        s1.counterpartyB === s2.counterpartyB &&
        s1.productType === s2.productType &&
        s1.currency === s2.currency &&
        s1.contractStatus === 'ACTIVE' &&
        s2.contractStatus === 'ACTIVE'
      ) {
        // Check if legs are opposite direction
        const s1PayLeg = s1.legs.find((l) => l.direction === 'PAY');
        const s2PayLeg = s2.legs.find((l) => l.direction === 'PAY');

        // If one pays fixed and other receives fixed, or opposite directions
        if (s1PayLeg && s2PayLeg && s1PayLeg.legType !== s2PayLeg.legType) {
          const compressibleNotional = Math.min(s1.notional, s2.notional);
          const netPvImpact = s1.valuation.cleanPv + s2.valuation.cleanPv;
          const dv01Reduction = Math.abs(s1.risk.dv01) + Math.abs(s2.risk.dv01) - Math.abs(s1.risk.dv01 + s2.risk.dv01);

          opportunities.push({
            swapAId: s1.swapId,
            swapBId: s2.swapId,
            counterparty: s1.counterpartyB,
            productType: s1.productType,
            notionalA: s1.notional,
            notionalB: s2.notional,
            compressibleNotional,
            pvA: s1.valuation.cleanPv,
            pvB: s2.valuation.cleanPv,
            netPvImpact: Math.round(netPvImpact),
            dv01Reduction: Math.round(dv01Reduction * 100) / 100,
            status: 'IDENTIFIED',
          });
        }
      }
    }
  }

  return opportunities;
}
