/**
 * RHINOQUANT COLLATERAL & MARGIN ENGINE
 * ISDA Variation Margin (VM), Initial Margin (IM), haircuts, concentration limits, and margin call reconciliation.
 */

import { CanonicalSwap, NettingSet } from '../types/swap';

export interface CollateralCalculationResult {
  swapId: string;
  counterparty: string;
  markToMarketPv: number;
  variationMarginReq: number;
  initialMarginReq: number;
  totalMarginReq: number;
  collateralPosted: number;
  marginCallAmount: number; // positive = call to counterparty, negative = return collateral
  status: 'COLLATERALISED' | 'MARGIN_CALL_PENDING' | 'UNDER_COLLATERALISED';
}

/**
 * Calculates Variation Margin and Initial Margin requirements for a swap
 */
export function calculateSwapMargin(
  swap: CanonicalSwap,
  collateralPosted: number = 0
): CollateralCalculationResult {
  const mtm = swap.valuation.cleanPv;
  const notional = swap.notional;

  // Variation Margin = Mark-to-Market
  const variationMarginReq = mtm;

  // Initial Margin (SIMM-style heuristic: ~1.5% - 3.5% of Notional based on risk)
  let imRatio = 0.015;
  if (swap.swapFamily === 'COMMODITY' || swap.swapFamily === 'DIGITAL_ASSET') {
    imRatio = 0.045;
  } else if (swap.swapFamily === 'CREDIT' || swap.swapFamily === 'EQUITY') {
    imRatio = 0.025;
  }
  const initialMarginReq = notional * imRatio;

  const totalMarginReq = variationMarginReq + initialMarginReq;
  const marginCallAmount = totalMarginReq - collateralPosted;

  let status: 'COLLATERALISED' | 'MARGIN_CALL_PENDING' | 'UNDER_COLLATERALISED' = 'COLLATERALISED';
  if (Math.abs(marginCallAmount) > swap.collateralTerms.minimumTransferAmount) {
    status = 'MARGIN_CALL_PENDING';
  }

  return {
    swapId: swap.swapId,
    counterparty: swap.counterpartyB,
    markToMarketPv: mtm,
    variationMarginReq: Math.round(variationMarginReq),
    initialMarginReq: Math.round(initialMarginReq),
    totalMarginReq: Math.round(totalMarginReq),
    collateralPosted,
    marginCallAmount: Math.round(marginCallAmount),
    status,
  };
}

/**
 * Aggregates Bilateral Netting Set Exposures across multiple swaps
 */
export function calculateNettingSetExposure(
  nettingSetId: string,
  counterparty: string,
  swaps: CanonicalSwap[],
  totalCollateralPosted: number
): NettingSet {
  const counterpartySwaps = swaps.filter((s) => s.counterpartyB === counterparty || s.nettingSetId === nettingSetId);

  let grossPositivePv = 0;
  let grossNegativePv = 0;
  let netPv = 0;

  counterpartySwaps.forEach((s) => {
    const pv = s.valuation.cleanPv;
    if (pv > 0) grossPositivePv += pv;
    else grossNegativePv += Math.abs(pv);
    netPv += pv;
  });

  const netUncollateralisedExposure = Math.max(0, netPv - totalCollateralPosted);

  return {
    nettingSetId,
    counterparty,
    agreements: 'ISDA Master Agreement (2002) + CSA (2016 VM/IM)',
    swapsCount: counterpartySwaps.length,
    grossExposure: Math.round(grossPositivePv),
    netExposure: Math.round(netPv),
    collateralPosted: totalCollateralPosted,
    netUncollateralisedExposure: Math.round(netUncollateralisedExposure),
  };
}
