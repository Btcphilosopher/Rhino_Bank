import React, { useState } from 'react';
import { Zap, Send, CheckCircle2, Clock, ShieldAlert, Award } from 'lucide-react';
import { Quote, RFQ, SwapFamily, ProductType, CanonicalSwap } from '../types/swap';

interface RFQDeskProps {
  onExecuteQuote: (newSwap: CanonicalSwap) => void;
}

export const RFQDesk: React.FC<RFQDeskProps> = ({ onExecuteQuote }) => {
  const [selectedFamily, setSelectedFamily] = useState<SwapFamily>('IRS');
  const [selectedProduct, setSelectedProduct] = useState<ProductType>('Fixed-for-Floating');
  const [notional, setNotional] = useState<number>(250000000); // £250M
  const [tenorYears, setTenorYears] = useState<number>(5);
  const [direction, setDirection] = useState<'PAY' | 'RECEIVE'>('RECEIVE');

  const [rfqStatus, setRfqStatus] = useState<'IDLE' | 'QUOTING' | 'QUOTED' | 'EXECUTED'>('IDLE');
  const [quotes, setQuotes] = useState<Quote[]>([]);

  const handleRequestQuotes = () => {
    setRfqStatus('QUOTING');
    setQuotes([]);

    setTimeout(() => {
      const baseRate = direction === 'RECEIVE' ? 0.04125 : 0.0415;
      const generatedQuotes: Quote[] = [
        {
          quoteId: 'Q-BARCLAYS-01',
          dealerName: 'Barclays Capital Synthetic Desk',
          dealerRating: 'AA',
          fixedRateOffered: baseRate,
          spreadBpOffered: 0,
          pvToUser: 1250000,
          creditValuationAdjustment: -12000,
          validUntil: '120s',
        },
        {
          quoteId: 'Q-GOLDMAN-02',
          dealerName: 'Goldman Sachs International',
          dealerRating: 'A+',
          fixedRateOffered: baseRate + 0.0002,
          spreadBpOffered: +2,
          pvToUser: 1380000,
          creditValuationAdjustment: -15000,
          validUntil: '120s',
        },
        {
          quoteId: 'Q-MORGAN-03',
          dealerName: 'Morgan Stanley Synthetic Trading',
          dealerRating: 'A+',
          fixedRateOffered: baseRate - 0.0001,
          spreadBpOffered: -1,
          pvToUser: 1120000,
          creditValuationAdjustment: -9000,
          validUntil: '120s',
        },
      ];
      setQuotes(generatedQuotes);
      setRfqStatus('QUOTED');
    }, 1200);
  };

  const handleAcceptQuote = (q: Quote) => {
    const swapId = `SWAP-RFQ-${Math.random().toString(36).substring(2, 7).toUpperCase()}`;
    const tradeId = `TRD-RFQ-${Date.now().toString().slice(-4)}`;

    const newSwap: CanonicalSwap = {
      swapId,
      tradeId,
      version: 1,
      productType: selectedProduct,
      swapFamily: selectedFamily,
      counterpartyA: 'RhinoQuant Principal Desk',
      counterpartyB: q.dealerName,
      notional,
      currency: 'GBP',
      effectiveDate: '2026-10-01',
      maturityDate: `${2026 + tenorYears}-10-01`,
      businessDayConvention: 'MODIFIED_FOLLOWING',
      dayCountConvention: 'ACT/365',
      paymentCalendar: 'GBLO',
      legs: [
        {
          id: `LEG-${swapId}-PAY`,
          legType: 'Fixed',
          direction: direction === 'RECEIVE' ? 'PAY' : 'RECEIVE',
          currency: 'GBP',
          notional,
          referenceIndexOrAsset: `FIXED_${(q.fixedRateOffered * 100).toFixed(3)}%`,
          calculationMethod: 'Fixed Coupon',
          resetFrequency: 'SEMI_ANNUAL',
          paymentFrequency: 'SEMI_ANNUAL',
          fixedRate: q.fixedRateOffered,
          dayCount: 'ACT/365',
          businessDay: 'MODIFIED_FOLLOWING',
          calendar: 'GBLO',
          settlementConvention: 'CASH',
        },
        {
          id: `LEG-${swapId}-REC`,
          legType: 'Floating',
          direction: direction,
          currency: 'GBP',
          notional,
          referenceIndexOrAsset: 'SONIA',
          calculationMethod: 'SONIA Compounded',
          resetFrequency: 'QUARTERLY',
          paymentFrequency: 'QUARTERLY',
          spreadBp: q.spreadBpOffered,
          dayCount: 'ACT/365',
          businessDay: 'MODIFIED_FOLLOWING',
          calendar: 'GBLO',
          settlementConvention: 'CASH',
        },
      ],
      cashflows: [],
      valuation: {
        cleanPv: q.pvToUser,
        dirtyPv: q.pvToUser,
        fairSwapRate: q.fixedRateOffered,
        parSpreadBp: q.spreadBpOffered,
        forwardValue: q.pvToUser * 1.02,
        discountCurveUsed: 'GBP SONIA OIS Yield Curve',
        forecastCurveUsed: 'SONIA Forecast Curve',
        pricingModelUsed: 'OIS_MULTI_CURVE',
        modelVersion: 'v2.4.1-QUANT',
        calibrationTimestamp: new Date().toISOString(),
        expectedCashflowTotal: q.pvToUser * 1.1,
      },
      risk: {
        dv01: Math.round(-(notional / 10000) * tenorYears * 0.85),
        pv01: 0,
        keyRateDv01: {},
      },
      collateralTerms: {
        agreementType: 'ISDA_2016_VM_IM',
        variationMarginCurrency: 'GBP',
        initialMarginReq: Math.round(notional * 0.02),
        independentAmount: 0,
        threshold: 0,
        minimumTransferAmount: 100000,
        eligibleCollateral: ['GBP Cash', 'UK Gilts'],
        haircuts: {},
      },
      currentMarginCall: q.pvToUser,
      nettingSetId: 'NET-BARCLAYS-001',
      valuationModel: 'OIS_MULTI_CURVE',
      modelVersion: 'v2.4.1-QUANT',
      marketDataDependencies: ['CURVE-GBP-SONIA-OIS'],
      contractStatus: 'ACTIVE',
      lifecycleHistory: [
        {
          eventId: `EVT-${swapId}-RFQ`,
          timestamp: new Date().toISOString(),
          eventType: 'TRADE_EXECUTION',
          description: `Executed via RFQ Terminal with ${q.dealerName}. Offered Rate: ${(q.fixedRateOffered * 100).toFixed(3)}%.`,
          performedBy: 'Rhino RFQ Trader',
          hash: `0x${Math.random().toString(16).substring(2, 10)}`,
        },
      ],
      auditHash: `0x${Math.random().toString(16).substring(2, 10)}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    onExecuteQuote(newSwap);
    setRfqStatus('EXECUTED');
  };

  return (
    <div className="bg-[#121824] border border-slate-800 rounded-lg p-4 space-y-6">
      <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Zap className="w-4 h-4 text-amber-400" />
          <h2 className="text-sm font-bold text-white tracking-tight uppercase font-mono">
            Multi-Dealer Institutional RFQ Terminal
          </h2>
        </div>
        <span className="text-xs font-mono text-emerald-400 flex items-center gap-1">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          5 Live Dealer Stream Feeds Connected
        </span>
      </div>

      {/* RFQ Order Form */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 bg-[#0B0E14] border border-slate-800 p-4 rounded text-xs font-mono">
        <div>
          <label className="text-slate-400 block mb-1">Swap Family</label>
          <select
            value={selectedFamily}
            onChange={(e) => setSelectedFamily(e.target.value as SwapFamily)}
            className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-white"
          >
            <option value="IRS">IRS</option>
            <option value="COMMODITY">Commodity</option>
            <option value="DIGITAL_ASSET">Digital Asset</option>
            <option value="INFRASTRUCTURE">Infrastructure</option>
            <option value="FX">FX</option>
          </select>
        </div>

        <div>
          <label className="text-slate-400 block mb-1">Gross Notional (£)</label>
          <input
            type="number"
            value={notional}
            onChange={(e) => setNotional(Number(e.target.value))}
            className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-white font-bold"
          />
        </div>

        <div>
          <label className="text-slate-400 block mb-1">Tenor (Years)</label>
          <input
            type="number"
            value={tenorYears}
            onChange={(e) => setTenorYears(Number(e.target.value))}
            className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-white font-bold"
          />
        </div>

        <div className="flex items-end">
          <button
            onClick={handleRequestQuotes}
            disabled={rfqStatus === 'QUOTING'}
            className="w-full py-2 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-slate-950 font-bold rounded transition-all shadow-md flex items-center justify-center gap-2"
          >
            <Send className="w-4 h-4" />
            {rfqStatus === 'QUOTING' ? 'Streaming Quotes...' : 'Request Multi-Dealer Quotes'}
          </button>
        </div>
      </div>

      {/* Dealer Stream Results */}
      {quotes.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-xs font-mono uppercase font-bold text-slate-400">
            Live Dealer Streams ({quotes.length} Responses Received)
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {quotes.map((q) => (
              <div
                key={q.quoteId}
                className="bg-[#0B0E14] border border-amber-500/30 p-4 rounded space-y-3 relative hover:border-amber-400 transition-colors"
              >
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <div>
                    <span className="font-bold text-slate-100 font-mono text-xs">{q.dealerName}</span>
                    <span className="ml-2 text-[10px] px-1.5 py-0.5 bg-slate-800 text-amber-400 rounded font-mono">
                      Rating: {q.dealerRating}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                  <div>
                    <span className="text-slate-500 block text-[10px]">Offered Fixed Rate</span>
                    <span className="text-sm font-bold text-amber-300">
                      {(q.fixedRateOffered * 100).toFixed(3)}%
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">PV Impact</span>
                    <span className="text-sm font-bold text-emerald-400">
                      +£{(q.pvToUser / 1e6).toFixed(3)}M
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 border-t border-slate-800/80 pt-2">
                  <span>CVA: £{Math.abs(q.creditValuationAdjustment).toLocaleString()}</span>
                  <span className="text-amber-400 flex items-center gap-1">
                    <Clock className="w-3 h-3" /> {q.validUntil}
                  </span>
                </div>

                <button
                  onClick={() => handleAcceptQuote(q)}
                  className="w-full py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded transition-colors flex items-center justify-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  Accept & Execute
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
