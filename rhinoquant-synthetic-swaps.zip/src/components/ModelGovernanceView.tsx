import React from 'react';
import { Shield, Cpu, CheckCircle2 } from 'lucide-react';
import { ModelGovernance } from '../types/swap';

interface ModelGovernanceViewProps {
  models: ModelGovernance[];
}

export const ModelGovernanceView: React.FC<ModelGovernanceViewProps> = ({ models }) => {
  return (
    <div className="bg-[#121824] border border-slate-800 rounded-lg p-4 space-y-6">
      <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Shield className="w-4 h-4 text-amber-400" />
          <h2 className="text-sm font-bold text-white tracking-tight uppercase font-mono">
            Model Governance & Challenger Model Centre
          </h2>
        </div>
        <span className="text-xs font-mono text-emerald-400">
          {models.length} Validated Production Pricing Models
        </span>
      </div>

      <div className="space-y-4 font-mono text-xs">
        {models.map((m) => (
          <div key={m.modelId} className="bg-[#0B0E14] border border-slate-800 p-4 rounded space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
              <div>
                <span className="font-bold text-slate-100 text-sm">{m.name}</span>
                <span className="ml-2 text-[10px] text-amber-400">({m.version})</span>
              </div>
              <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 rounded text-[10px] font-bold">
                {m.validationStatus}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-slate-300 text-xs">
              <div>
                <span className="text-slate-500 block text-[10px]">Author & Calibrated Date</span>
                <span>{m.author} · {m.calibrationDate}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">Challenger Model Comparison</span>
                <span>
                  {m.challengerModelName} (Delta: {m.productionVsChallengerPvDeltaPercent}%)
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
