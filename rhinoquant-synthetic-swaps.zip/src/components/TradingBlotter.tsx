import React, { useState } from 'react';
import {
  Layers,
  Search,
  Filter,
  CheckSquare,
  Square,
  XCircle,
  Eye,
  Zap,
} from 'lucide-react';
import { CanonicalSwap, SwapFamily, ContractStatus } from '../types/swap';

interface TradingBlotterProps {
  swaps: CanonicalSwap[];
  onSelectSwap: (swapId: string) => void;
  onTerminateSwap: (swapId: string) => void;
}

export const TradingBlotter: React.FC<TradingBlotterProps> = ({
  swaps,
  onSelectSwap,
  onTerminateSwap,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [familyFilter, setFamilyFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [selectedSwapIds, setSelectedSwapIds] = useState<string[]>([]);

  const filteredSwaps = swaps.filter((s) => {
    const matchesSearch =
      s.swapId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.tradeId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.counterpartyB.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.productType.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesFamily = familyFilter === 'ALL' || s.swapFamily === familyFilter;
    const matchesStatus = statusFilter === 'ALL' || s.contractStatus === statusFilter;

    return matchesSearch && matchesFamily && matchesStatus;
  });

  const toggleSelectSwap = (id: string) => {
    if (selectedSwapIds.includes(id)) {
      setSelectedSwapIds(selectedSwapIds.filter((item) => item !== id));
    } else {
      setSelectedSwapIds([...selectedSwapIds, id]);
    }
  };

  const toggleSelectAll = () => {
    if (selectedSwapIds.length === filteredSwaps.length) {
      setSelectedSwapIds([]);
    } else {
      setSelectedSwapIds(filteredSwaps.map((s) => s.swapId));
    }
  };

  return (
    <div className="bg-[#121824] border border-slate-800 rounded-lg p-4 space-y-4">
      {/* Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-amber-400" />
          <h2 className="text-sm font-bold text-white tracking-tight uppercase font-mono">
            Institutional Derivatives Trading Blotter
          </h2>
          <span className="px-2 py-0.5 bg-slate-900 text-slate-400 border border-slate-800 rounded text-xs font-mono">
            {filteredSwaps.length} Active Lines
          </span>
        </div>

        {/* Filters & Search */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-2.5" />
            <input
              type="text"
              placeholder="Filter by ID, counterparty, product..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-[#0B0E14] border border-slate-800 rounded pl-8 pr-3 py-1.5 text-xs font-mono text-slate-200 focus:outline-none focus:border-amber-500 w-64"
            />
          </div>

          <select
            value={familyFilter}
            onChange={(e) => setFamilyFilter(e.target.value)}
            className="bg-[#0B0E14] border border-slate-800 rounded px-2.5 py-1.5 text-xs font-mono text-slate-300"
          >
            <option value="ALL">All Families</option>
            <option value="IRS">IRS</option>
            <option value="COMMODITY">Commodity</option>
            <option value="DIGITAL_ASSET">Digital Asset</option>
            <option value="INFRASTRUCTURE">Infrastructure</option>
            <option value="FX">FX</option>
            <option value="EQUITY">Equity</option>
            <option value="CREDIT">Credit</option>
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-[#0B0E14] border border-slate-800 rounded px-2.5 py-1.5 text-xs font-mono text-slate-300"
          >
            <option value="ALL">All Statuses</option>
            <option value="ACTIVE">Active</option>
            <option value="AMENDED">Amended</option>
            <option value="TERMINATED">Terminated</option>
          </select>
        </div>
      </div>

      {/* Main Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs font-mono border-collapse">
          <thead>
            <tr className="border-b border-slate-800 text-slate-400 bg-slate-900/60">
              <th className="py-2.5 px-3">
                <button onClick={toggleSelectAll}>
                  {selectedSwapIds.length === filteredSwaps.length && filteredSwaps.length > 0 ? (
                    <CheckSquare className="w-4 h-4 text-amber-400" />
                  ) : (
                    <Square className="w-4 h-4 text-slate-600" />
                  )}
                </button>
              </th>
              <th className="py-2.5 px-3">Swap ID</th>
              <th className="py-2.5 px-3">Family / Product</th>
              <th className="py-2.5 px-3">Counterparty Desk</th>
              <th className="py-2.5 px-3 text-right">Notional</th>
              <th className="py-2.5 px-3">Maturity</th>
              <th className="py-2.5 px-3 text-right">Clean PV</th>
              <th className="py-2.5 px-3 text-right">DV01</th>
              <th className="py-2.5 px-3 text-center">Status</th>
              <th className="py-2.5 px-3 text-right">Action</th>
            </tr>
          </thead>
          <tbody>
            {filteredSwaps.map((s) => (
              <tr
                key={s.swapId}
                className="border-b border-slate-800/60 hover:bg-slate-800/40 transition-colors"
              >
                <td className="py-2.5 px-3">
                  <button onClick={() => toggleSelectSwap(s.swapId)}>
                    {selectedSwapIds.includes(s.swapId) ? (
                      <CheckSquare className="w-4 h-4 text-amber-400" />
                    ) : (
                      <Square className="w-4 h-4 text-slate-700" />
                    )}
                  </button>
                </td>
                <td className="py-2.5 px-3 font-bold text-amber-400">{s.swapId}</td>
                <td className="py-2.5 px-3 text-slate-200">
                  <div>{s.productType}</div>
                  <div className="text-[10px] text-slate-500">{s.swapFamily}</div>
                </td>
                <td className="py-2.5 px-3 text-slate-300">{s.counterpartyB}</td>
                <td className="py-2.5 px-3 text-right font-bold text-slate-100">
                  {s.currency} {(s.notional / 1e6).toFixed(1)}M
                </td>
                <td className="py-2.5 px-3 text-slate-400">{s.maturityDate}</td>
                <td className={`py-2.5 px-3 text-right font-bold ${s.valuation.cleanPv >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  £{(s.valuation.cleanPv / 1e6).toFixed(3)}M
                </td>
                <td className="py-2.5 px-3 text-right text-rose-400 font-bold">
                  -£{Math.abs(s.risk.dv01).toLocaleString()}
                </td>
                <td className="py-2.5 px-3 text-center">
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                      s.contractStatus === 'ACTIVE'
                        ? 'bg-emerald-500/20 text-emerald-300'
                        : s.contractStatus === 'AMENDED'
                        ? 'bg-amber-500/20 text-amber-300'
                        : 'bg-rose-500/20 text-rose-400'
                    }`}
                  >
                    {s.contractStatus}
                  </span>
                </td>
                <td className="py-2.5 px-3 text-right">
                  <button
                    onClick={() => onSelectSwap(s.swapId)}
                    className="p-1 text-slate-400 hover:text-amber-400 hover:bg-slate-800 rounded transition-colors"
                    title="View Machine-Readable Chain"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
