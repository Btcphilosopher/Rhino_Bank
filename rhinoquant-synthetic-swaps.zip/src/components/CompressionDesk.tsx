import React, { useState, useEffect } from 'react';
import { GitCommit, Zap, CheckCircle2 } from 'lucide-react';
import { CanonicalSwap } from '../types/swap';
import { identifyCompressionOpportunities, CompressionOpportunity } from '../engine/compression';

interface CompressionDeskProps {
  swaps: CanonicalSwap[];
}

export const CompressionDesk: React.FC<CompressionDeskProps> = ({ swaps }) => {
  const [opportunities, setOpportunities] = useState<CompressionOpportunity[]>([]);
  const [executedIds, setExecutedIds] = useState<string[]>([]);

  useEffect(() => {
    const opps = identifyCompressionOpportunities(swaps);
    setOpportunities(opps);
  }, [swaps]);

  const handleExecuteTearUp = (opp: CompressionOpportunity) => {
    setExecutedIds([...executedIds, opp.swapAId, opp.swapBId]);
  };

  return (
    <div className="bg-[#121824] border border-slate-800 rounded-lg p-4 space-y-6">
      <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <GitCommit className="w-4 h-4 text-amber-400" />
          <h2 className="text-sm font-bold text-white tracking-tight uppercase font-mono">
            RhinoQuant Portfolio Compression & Tear-Up Engine
          </h2>
        </div>
        <span className="text-xs font-mono text-emerald-400">
          {opportunities.length} Offsetting Swap Pairs Identified
        </span>
      </div>

      {/* Opportunities List */}
      <div className="space-y-3">
        {opportunities.map((opp, idx) => {
          const isExecuted = executedIds.includes(opp.swapAId);
          return (
            <div
              key={idx}
              className="bg-[#0B0E14] border border-slate-800 p-4 rounded flex flex-wrap items-center justify-between gap-4 font-mono text-xs"
            >
              <div>
                <div className="flex items-center gap-2 font-bold text-amber-400">
                  <span>{opp.counterparty}</span>
                  <span>·</span>
                  <span>{opp.productType}</span>
                </div>
                <div className="text-slate-400 text-[11px] mt-1">
                  Swap A ({opp.swapAId}): £{(opp.notionalA / 1e6).toFixed(1)}M vs Swap B ({opp.swapBId}): £{(opp.notionalB / 1e6).toFixed(1)}M
                </div>
              </div>

              <div className="flex items-center gap-6">
                <div>
                  <span className="text-slate-500 block text-[10px]">Compressible Notional</span>
                  <span className="text-white font-bold">£{(opp.compressibleNotional / 1e6).toFixed(1)}M</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px]">DV01 Reduction</span>
                  <span className="text-emerald-400 font-bold">-£{opp.dv01Reduction}/bp</span>
                </div>

                {isExecuted ? (
                  <span className="px-3 py-1 bg-emerald-500/20 text-emerald-300 rounded font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-4 h-4" /> Compressed
                  </span>
                ) : (
                  <button
                    onClick={() => handleExecuteTearUp(opp)}
                    className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded transition-colors"
                  >
                    Simulate Tear-Up
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
