import React from 'react';
import { Shield, Lock, FileText, CheckCircle2 } from 'lucide-react';
import { NettingSet, CanonicalSwap } from '../types/swap';

interface CollateralNettingViewProps {
  nettingSets: NettingSet[];
  swaps: CanonicalSwap[];
}

export const CollateralNettingView: React.FC<CollateralNettingViewProps> = ({
  nettingSets,
  swaps,
}) => {
  return (
    <div className="bg-[#121824] border border-slate-800 rounded-lg p-4 space-y-6">
      <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Shield className="w-4 h-4 text-amber-400" />
          <h2 className="text-sm font-bold text-white tracking-tight uppercase font-mono">
            Bilateral Netting Sets & ISDA Collateral Engine
          </h2>
        </div>
        <span className="text-xs font-mono text-emerald-400">
          ISDA 2016 Variation & Initial Margin Compliant
        </span>
      </div>

      {/* Netting Sets Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs font-mono border-collapse">
          <thead>
            <tr className="border-b border-slate-800 text-slate-400 bg-slate-900/60">
              <th className="py-2.5 px-3">Netting Set ID</th>
              <th className="py-2.5 px-3">Counterparty Desk</th>
              <th className="py-2.5 px-3">Master Agreement</th>
              <th className="py-2.5 px-3 text-center">Swaps</th>
              <th className="py-2.5 px-3 text-right">Gross Exposure</th>
              <th className="py-2.5 px-3 text-right">Net Exposure</th>
              <th className="py-2.5 px-3 text-right">Collateral Posted</th>
              <th className="py-2.5 px-3 text-right">Uncollateralised</th>
            </tr>
          </thead>
          <tbody>
            {nettingSets.map((ns) => (
              <tr key={ns.nettingSetId} className="border-b border-slate-800/60 hover:bg-slate-800/40">
                <td className="py-2.5 px-3 font-bold text-amber-400">{ns.nettingSetId}</td>
                <td className="py-2.5 px-3 text-slate-200">{ns.counterparty}</td>
                <td className="py-2.5 px-3 text-slate-400">{ns.agreements}</td>
                <td className="py-2.5 px-3 text-center text-slate-300">{ns.swapsCount}</td>
                <td className="py-2.5 px-3 text-right text-slate-300">
                  £{(ns.grossExposure / 1e6).toFixed(2)}M
                </td>
                <td className="py-2.5 px-3 text-right font-bold text-emerald-400">
                  £{(ns.netExposure / 1e6).toFixed(2)}M
                </td>
                <td className="py-2.5 px-3 text-right text-slate-200">
                  £{(ns.collateralPosted / 1e6).toFixed(2)}M
                </td>
                <td className="py-2.5 px-3 text-right font-bold text-amber-300">
                  £{(ns.netUncollateralisedExposure / 1e6).toFixed(2)}M
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
