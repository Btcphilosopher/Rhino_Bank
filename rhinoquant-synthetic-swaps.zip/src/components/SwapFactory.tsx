import React, { useState, useEffect } from 'react';
import {
  Boxes,
  Plus,
  ArrowRight,
  Calculator,
  ShieldAlert,
  Sliders,
  CheckCircle,
} from 'lucide-react';
import {
  SwapFamily,
  ProductType,
  CanonicalSwap,
  SwapLeg,
  YieldCurve,
} from '../types/swap';
import { calculateParSwapRate } from '../engine/pricing';

interface SwapFactoryProps {
  onSwapCreated: (swap: CanonicalSwap) => void;
  yieldCurve: YieldCurve;
}

export const SwapFactory: React.FC<SwapFactoryProps> = ({
  onSwapCreated,
  yieldCurve,
}) => {
  const [selectedFamily, setSelectedFamily] = useState<SwapFamily>('IRS');
  const [selectedProduct, setSelectedProduct] = useState<ProductType>('Fixed-for-Floating');

  // Swap Contract Parameters
  const [notional, setNotional] = useState<number>(100000000); // £100M default
  const [currency, setCurrency] = useState<string>('GBP');
  const [counterpartyB, setCounterpartyB] = useState<string>('Barclays Capital Synthetic Desk');
  const [tenorYears, setTenorYears] = useState<number>(5);
  const [paymentFrequency, setPaymentFrequency] = useState<string>('SEMI_ANNUAL');
  const [dayCount, setDayCount] = useState<string>('ACT/365');

  // Leg Parameters
  const [payLegFixedRate, setPayLegFixedRate] = useState<number>(0.04125);
  const [payLegSpreadBp, setPayLegSpreadBp] = useState<number>(0);
  const [receiveLegIndex, setReceiveLegIndex] = useState<string>('SONIA');
  const [receiveLegSpreadBp, setReceiveLegSpreadBp] = useState<number>(0);

  // Par Fixed Rate Calculation
  const [fairFixedRate, setFairFixedRate] = useState<number>(0.04125);

  useEffect(() => {
    // Recalculate par rate
    const par = calculateParSwapRate(tenorYears, yieldCurve);
    setFairFixedRate(par);
    if (selectedFamily === 'IRS' && selectedProduct === 'Fixed-for-Floating') {
      setPayLegFixedRate(Math.round(par * 100000) / 100000);
    }
  }, [tenorYears, yieldCurve, selectedFamily, selectedProduct]);

  const productOptions: Record<SwapFamily, ProductType[]> = {
    IRS: [
      'Fixed-for-Floating',
      'OIS (SONIA/SOFR/€STR)',
      'Basis Swap',
      'Inflation Swap',
      'Cross-Currency Swap',
      'Zero-Coupon Swap',
      'Forward-Starting Swap',
      'Amortising Swap',
    ],
    FX: [
      'FX Swap',
      'NDF Synthetic Swap',
      'Quanto Swap',
      'Currency Basis Swap',
    ],
    EQUITY: [
      'Equity Total Return Swap',
      'Index Swap',
      'Basket Swap',
      'Dividend Swap',
      'Volatility Swap',
      'Variance Swap',
    ],
    COMMODITY: [
      'Oil Forward Swap',
      'Gas Swap',
      'Power Electricity Swap',
      'Hydrogen Swap',
      'Metals Swap',
      'Freight Swap',
    ],
    CREDIT: [
      'Single-Name CDS',
      'Index CDS (iTraxx/CDX)',
      'Basket CDS / FTD',
      'Credit Spread Swap',
      'Total Return Credit Swap',
    ],
    DIGITAL_ASSET: [
      'BTC Total Return Swap',
      'ETH Total Return Swap',
      'Crypto Basis Swap',
      'Digital Asset Volatility Swap',
      'Stablecoin Rate Swap',
      'Crypto/GBP Synthetic Swap',
    ],
    INFRASTRUCTURE: [
      'Rail Revenue Swap',
      'Port Throughput Swap',
      'Electricity Generation Swap',
      'Hydrogen Production Swap',
      'Fibre Capacity Swap',
      'Water Demand Swap',
    ],
  };

  const handleFamilySelect = (family: SwapFamily) => {
    setSelectedFamily(family);
    setSelectedProduct(productOptions[family][0]);
    if (family === 'DIGITAL_ASSET') {
      setReceiveLegIndex('BTC/GBP Index Spot Return');
    } else if (family === 'COMMODITY') {
      setReceiveLegIndex('UK_POWER_BASELOAD_INDEX');
    } else if (family === 'INFRASTRUCTURE') {
      setReceiveLegIndex('UK_RAIL_PASSENGER_KM_INDEX');
    } else {
      setReceiveLegIndex('SONIA');
    }
  };

  const handleStructureSwap = async () => {
    const swapId = `SWAP-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
    const tradeId = `TRD-RHINO-${selectedFamily}-${Date.now().toString().slice(-4)}`;

    const today = new Date();
    const effectiveDate = today.toISOString().split('T')[0];
    const maturityDateObj = new Date(today);
    maturityDateObj.setFullYear(today.getFullYear() + tenorYears);
    const maturityDate = maturityDateObj.toISOString().split('T')[0];

    const payLeg: SwapLeg = {
      id: `LEG-${swapId}-PAY`,
      legType: 'Fixed',
      direction: 'PAY',
      currency,
      notional,
      referenceIndexOrAsset: `FIXED_${(payLegFixedRate * 100).toFixed(3)}%`,
      calculationMethod: 'Fixed Rate Day Count Fraction',
      resetFrequency: paymentFrequency as any,
      paymentFrequency: paymentFrequency as any,
      fixedRate: payLegFixedRate,
      spreadBp: payLegSpreadBp,
      dayCount: dayCount as any,
      businessDay: 'MODIFIED_FOLLOWING',
      calendar: 'GBLO',
      settlementConvention: 'CASH',
    };

    const receiveLeg: SwapLeg = {
      id: `LEG-${swapId}-REC`,
      legType: selectedFamily === 'COMMODITY' ? 'CommodityPrice' : selectedFamily === 'DIGITAL_ASSET' ? 'DigitalAsset' : 'Floating',
      direction: 'RECEIVE',
      currency,
      notional,
      referenceIndexOrAsset: receiveLegIndex,
      calculationMethod: 'Floating Rate Index Reset',
      resetFrequency: 'QUARTERLY',
      paymentFrequency: paymentFrequency as any,
      spreadBp: receiveLegSpreadBp,
      dayCount: dayCount as any,
      businessDay: 'MODIFIED_FOLLOWING',
      calendar: 'GBLO',
      settlementConvention: 'CASH',
    };

    const newSwap: CanonicalSwap = {
      swapId,
      tradeId,
      version: 1,
      productType: selectedProduct,
      swapFamily: selectedFamily,
      counterpartyA: 'RhinoQuant Principal Desk',
      counterpartyB,
      notional,
      currency,
      effectiveDate,
      maturityDate,
      businessDayConvention: 'MODIFIED_FOLLOWING',
      dayCountConvention: dayCount as any,
      paymentCalendar: 'GBLO',
      legs: [payLeg, receiveLeg],
      cashflows: [],
      valuation: {
        cleanPv: 0,
        dirtyPv: 0,
        fairSwapRate: fairFixedRate,
        parSpreadBp: receiveLegSpreadBp,
        forwardValue: 0,
        discountCurveUsed: yieldCurve.name,
        forecastCurveUsed: `${receiveLegIndex} Forecast Curve`,
        pricingModelUsed: 'OIS_MULTI_CURVE',
        modelVersion: 'v2.4.1-QUANT',
        calibrationTimestamp: new Date().toISOString(),
        expectedCashflowTotal: 0,
      },
      risk: {
        dv01: Math.round(-(notional / 10000) * tenorYears * 0.85),
        pv01: 0,
        keyRateDv01: {},
      },
      collateralTerms: {
        agreementType: 'ISDA_2016_VM_IM',
        variationMarginCurrency: currency,
        initialMarginReq: Math.round(notional * 0.02),
        independentAmount: 0,
        threshold: 0,
        minimumTransferAmount: 100000,
        eligibleCollateral: ['GBP Cash', 'UK Gilts'],
        haircuts: {},
      },
      currentMarginCall: 0,
      nettingSetId: 'NET-BARCLAYS-001',
      valuationModel: 'OIS_MULTI_CURVE',
      modelVersion: 'v2.4.1-QUANT',
      marketDataDependencies: [yieldCurve.curveId],
      contractStatus: 'ACTIVE',
      lifecycleHistory: [
        {
          eventId: `EVT-${swapId}-EXEC`,
          timestamp: new Date().toISOString(),
          eventType: 'TRADE_EXECUTION',
          description: `Swap structured and executed via RhinoQuant Swap Factory. Product: ${selectedProduct}. Notional: ${currency} ${(notional / 1e6).toFixed(1)}M.`,
          performedBy: 'RhinoQuant Derivatives Structurer',
          hash: `0x${Math.random().toString(16).substring(2, 10)}`,
        },
      ],
      auditHash: `0x${Math.random().toString(16).substring(2, 10)}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    onSwapCreated(newSwap);
  };

  return (
    <div className="space-y-6">
      {/* Step 1: Select Swap Family */}
      <div className="bg-[#121824] border border-slate-800 rounded-lg p-4">
        <div className="flex items-center gap-2 mb-3">
          <Boxes className="w-4 h-4 text-amber-400" />
          <h2 className="text-sm font-bold text-white tracking-tight uppercase font-mono">
            Step 1: Select Synthetic Swap Family & Product Taxonomy
          </h2>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2 mb-4">
          {(['IRS', 'FX', 'EQUITY', 'COMMODITY', 'CREDIT', 'DIGITAL_ASSET', 'INFRASTRUCTURE'] as SwapFamily[]).map(
            (family) => (
              <button
                key={family}
                onClick={() => handleFamilySelect(family)}
                className={`px-3 py-2 rounded text-xs font-mono font-semibold transition-all text-center border ${
                  selectedFamily === family
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/50 shadow-sm shadow-amber-500/10'
                    : 'bg-[#0B0E14] text-slate-400 border-slate-800 hover:text-slate-200 hover:border-slate-700'
                }`}
              >
                {family.replace('_', ' ')}
              </button>
            )
          )}
        </div>

        {/* Product Type Selector */}
        <div className="flex flex-wrap items-center gap-2 bg-[#0B0E14] p-3 rounded border border-slate-800">
          <span className="text-xs font-mono text-slate-400 mr-2">Products:</span>
          {productOptions[selectedFamily].map((prod) => (
            <button
              key={prod}
              onClick={() => setSelectedProduct(prod)}
              className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                selectedProduct === prod
                  ? 'bg-amber-500 text-slate-950 font-bold'
                  : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
              }`}
            >
              {prod}
            </button>
          ))}
        </div>
      </div>

      {/* Step 2: Contract Terms & Leg Builder */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Contract Parameters */}
        <div className="bg-[#121824] border border-slate-800 rounded-lg p-4 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 className="text-xs font-bold text-slate-200 uppercase font-mono flex items-center gap-2">
              <Sliders className="w-4 h-4 text-amber-400" />
              Contractual Terms
            </h3>
            <span className="text-[10px] font-mono text-slate-400">ISDA STANDARD</span>
          </div>

          <div>
            <label className="text-[11px] font-mono text-slate-400 block mb-1">
              Gross Notional
            </label>
            <div className="flex items-center gap-2">
              <input
                type="number"
                value={notional}
                onChange={(e) => setNotional(Number(e.target.value))}
                className="w-full bg-[#0B0E14] border border-slate-800 rounded px-3 py-1.5 text-xs font-mono text-white focus:outline-none focus:border-amber-500"
              />
              <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value)}
                className="bg-[#0B0E14] border border-slate-800 rounded px-2 py-1.5 text-xs font-mono text-amber-400"
              >
                <option value="GBP">GBP</option>
                <option value="USD">USD</option>
                <option value="EUR">EUR</option>
                <option value="JPY">JPY</option>
              </select>
            </div>
            <span className="text-[10px] font-mono text-emerald-400 mt-1 block">
              = £{(notional / 1e6).toFixed(1)} Million
            </span>
          </div>

          <div>
            <label className="text-[11px] font-mono text-slate-400 block mb-1">
              Counterparty Desk B
            </label>
            <select
              value={counterpartyB}
              onChange={(e) => setCounterpartyB(e.target.value)}
              className="w-full bg-[#0B0E14] border border-slate-800 rounded px-3 py-1.5 text-xs font-mono text-slate-200 focus:outline-none focus:border-amber-500"
            >
              <option value="Barclays Capital Synthetic Desk">Barclays Capital Synthetic Desk</option>
              <option value="Goldman Sachs International">Goldman Sachs International</option>
              <option value="Morgan Stanley Synthetic Trading">Morgan Stanley Synthetic Trading</option>
              <option value="HSBC Global Banking & Markets">HSBC Global Banking & Markets</option>
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] font-mono text-slate-400 block mb-1">
                Tenor (Years)
              </label>
              <input
                type="number"
                min={1}
                max={30}
                value={tenorYears}
                onChange={(e) => setTenorYears(Number(e.target.value))}
                className="w-full bg-[#0B0E14] border border-slate-800 rounded px-3 py-1.5 text-xs font-mono text-white focus:outline-none focus:border-amber-500"
              />
            </div>
            <div>
              <label className="text-[11px] font-mono text-slate-400 block mb-1">
                Payment Freq
              </label>
              <select
                value={paymentFrequency}
                onChange={(e) => setPaymentFrequency(e.target.value)}
                className="w-full bg-[#0B0E14] border border-slate-800 rounded px-2 py-1.5 text-xs font-mono text-slate-200"
              >
                <option value="SEMI_ANNUAL">Semi-Annual</option>
                <option value="QUARTERLY">Quarterly</option>
                <option value="ANNUAL">Annual</option>
                <option value="MONTHLY">Monthly</option>
              </select>
            </div>
          </div>
        </div>

        {/* Visual Leg Builder */}
        <div className="lg:col-span-2 bg-[#121824] border border-slate-800 rounded-lg p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-4">
              <h3 className="text-xs font-bold text-slate-200 uppercase font-mono flex items-center gap-2">
                <Calculator className="w-4 h-4 text-amber-400" />
                Visual Swap Leg Builder
              </h3>

              {/* Real-Time Par Rate Badge */}
              <div className="flex items-center gap-2 bg-amber-500/10 border border-amber-500/30 px-3 py-1 rounded text-xs font-mono">
                <span className="text-slate-400">Par Fixed Rate R_par:</span>
                <span className="text-amber-400 font-bold">
                  {(fairFixedRate * 100).toFixed(3)}%
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* LEG 1: PAY LEG */}
              <div className="bg-[#0B0E14] border border-rose-500/30 p-3 rounded space-y-3">
                <div className="flex items-center justify-between border-b border-rose-500/20 pb-1.5">
                  <span className="text-xs font-bold font-mono text-rose-400 flex items-center gap-1">
                    LEG 1: PAY LEG (PARTY A)
                  </span>
                  <span className="text-[10px] font-mono text-slate-500">Fixed Rate</span>
                </div>

                <div>
                  <label className="text-[10px] font-mono text-slate-400 block mb-1">
                    Fixed Coupon Rate (%)
                  </label>
                  <input
                    type="number"
                    step="0.001"
                    value={payLegFixedRate * 100}
                    onChange={(e) => setPayLegFixedRate(Number(e.target.value) / 100)}
                    className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1 text-xs font-mono text-rose-300 font-bold"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-mono text-slate-400 block mb-1">
                    Leg Spread (bps)
                  </label>
                  <input
                    type="number"
                    value={payLegSpreadBp}
                    onChange={(e) => setPayLegSpreadBp(Number(e.target.value))}
                    className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1 text-xs font-mono text-slate-300"
                  />
                </div>
              </div>

              {/* LEG 2: RECEIVE LEG */}
              <div className="bg-[#0B0E14] border border-emerald-500/30 p-3 rounded space-y-3">
                <div className="flex items-center justify-between border-b border-emerald-500/20 pb-1.5">
                  <span className="text-xs font-bold font-mono text-emerald-400 flex items-center gap-1">
                    LEG 2: RECEIVE LEG (PARTY A)
                  </span>
                  <span className="text-[10px] font-mono text-slate-500">Floating / Asset</span>
                </div>

                <div>
                  <label className="text-[10px] font-mono text-slate-400 block mb-1">
                    Reference Index / Asset
                  </label>
                  <input
                    type="text"
                    value={receiveLegIndex}
                    onChange={(e) => setReceiveLegIndex(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1 text-xs font-mono text-emerald-300 font-bold"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-mono text-slate-400 block mb-1">
                    Spread over Index (bps)
                  </label>
                  <input
                    type="number"
                    value={receiveLegSpreadBp}
                    onChange={(e) => setReceiveLegSpreadBp(Number(e.target.value))}
                    className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1 text-xs font-mono text-slate-300"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Execution Button */}
          <div className="mt-6 flex justify-end">
            <button
              onClick={handleStructureSwap}
              className="px-6 py-2.5 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-slate-950 font-bold text-xs rounded transition-all shadow-lg shadow-amber-500/20 flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              Structure & Execute Machine-Readable Swap
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
