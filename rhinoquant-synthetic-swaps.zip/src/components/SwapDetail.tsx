import React, { useState } from 'react';
import {
  ArrowLeft,
  GitCommit,
  Edit,
  UserCheck,
  XCircle,
  Play,
  FileCheck,
  Layers,
  Activity,
  Shield,
  HelpCircle,
  Hash,
  CheckCircle2,
} from 'lucide-react';
import { CanonicalSwap, Cashflow } from '../types/swap';

interface SwapDetailProps {
  swap: CanonicalSwap;
  onBack: () => void;
  onAmendSwap: (swapId: string, updates: Partial<CanonicalSwap>) => void;
  onTerminateSwap: (swapId: string) => void;
}

export const SwapDetail: React.FC<SwapDetailProps> = ({
  swap,
  onBack,
  onAmendSwap,
  onTerminateSwap,
}) => {
  const [activeTab, setActiveTab] = useState<'CHAIN' | 'CASHFLOWS' | 'RISK' | 'LIFECYCLE' | 'AMEND'>('CHAIN');
  const [newFixedRate, setNewFixedRate] = useState<number>((swap.legs[0]?.fixedRate || 0.04125) * 100);
  const [selectedCashflow, setSelectedCashflow] = useState<Cashflow | null>(null);

  const handleAmendSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const updatedRate = newFixedRate / 100;
    onAmendSwap(swap.swapId, {
      legs: swap.legs.map((l) => (l.legType === 'Fixed' ? { ...l, fixedRate: updatedRate } : l)),
    });
    setActiveTab('CHAIN');
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#121824] border border-slate-800 p-4 rounded-lg">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-1.5 bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 rounded transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono text-amber-400 font-bold text-sm">
                {swap.swapId}
              </span>
              <span className="text-slate-600">·</span>
              <span className="font-mono text-xs text-slate-400">{swap.tradeId}</span>
              <span className="px-2 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded text-[10px] font-mono font-semibold">
                v{swap.version} {swap.contractStatus}
              </span>
            </div>
            <h1 className="text-base font-bold text-white tracking-tight mt-0.5">
              {swap.productType} ({swap.swapFamily})
            </h1>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('AMEND')}
            disabled={swap.contractStatus === 'TERMINATED'}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded text-xs font-mono transition-colors flex items-center gap-1.5 disabled:opacity-50"
          >
            <Edit className="w-3.5 h-3.5 text-amber-400" />
            Amend Terms
          </button>

          <button
            onClick={() => onTerminateSwap(swap.swapId)}
            disabled={swap.contractStatus === 'TERMINATED'}
            className="px-3 py-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 rounded text-xs font-mono transition-colors flex items-center gap-1.5 disabled:opacity-50"
          >
            <XCircle className="w-3.5 h-3.5" />
            Terminate Swap
          </button>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2 text-xs font-mono">
        <button
          onClick={() => setActiveTab('CHAIN')}
          className={`px-3 py-1.5 rounded transition-colors ${
            activeTab === 'CHAIN'
              ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Valuation Chain
        </button>
        <button
          onClick={() => setActiveTab('CASHFLOWS')}
          className={`px-3 py-1.5 rounded transition-colors ${
            activeTab === 'CASHFLOWS'
              ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Cashflow Engine ({swap.cashflows.length})
        </button>
        <button
          onClick={() => setActiveTab('RISK')}
          className={`px-3 py-1.5 rounded transition-colors ${
            activeTab === 'RISK'
              ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Sensitivities & Risk
        </button>
        <button
          onClick={() => setActiveTab('LIFECYCLE')}
          className={`px-3 py-1.5 rounded transition-colors ${
            activeTab === 'LIFECYCLE'
              ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Lifecycle Audit Trail ({swap.lifecycleHistory.length})
        </button>
      </div>

      {/* Tab Content: Canonical Valuation Chain */}
      {activeTab === 'CHAIN' && (
        <div className="space-y-6">
          {/* Canonical Sequence Diagram */}
          <div className="bg-[#121824] border border-slate-800 p-4 rounded-lg overflow-x-auto">
            <h2 className="text-xs font-mono uppercase font-bold text-slate-400 mb-3">
              Machine-Readable Valuation Chain
            </h2>
            <div className="flex items-center gap-2 min-w-[700px] text-xs font-mono">
              <span className="px-2.5 py-1.5 bg-slate-900 border border-slate-700 text-amber-400 rounded">
                REFERENCE
              </span>
              <span>→</span>
              <span className="px-2.5 py-1.5 bg-slate-900 border border-slate-700 text-slate-200 rounded">
                LEGS ({swap.legs.length})
              </span>
              <span>→</span>
              <span className="px-2.5 py-1.5 bg-slate-900 border border-slate-700 text-slate-200 rounded">
                CASHFLOWS
              </span>
              <span>→</span>
              <span className="px-2.5 py-1.5 bg-slate-900 border border-slate-700 text-slate-200 rounded">
                VALUATION
              </span>
              <span>→</span>
              <span className="px-2.5 py-1.5 bg-slate-900 border border-slate-700 text-rose-400 rounded">
                RISK (DV01)
              </span>
              <span>→</span>
              <span className="px-2.5 py-1.5 bg-slate-900 border border-slate-700 text-emerald-400 rounded">
                COLLATERAL
              </span>
              <span>→</span>
              <span className="px-2.5 py-1.5 bg-slate-900 border border-slate-700 text-slate-300 rounded">
                SETTLEMENT
              </span>
            </div>
          </div>

          {/* Key Metrics Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-[#121824] border border-slate-800 p-3.5 rounded">
              <div className="text-xs font-mono text-slate-500">Clean Present Value (PV)</div>
              <div className="text-lg font-bold font-mono text-emerald-400 mt-1">
                £{(swap.valuation.cleanPv / 1e6).toFixed(3)}M
              </div>
              <div className="text-[10px] font-mono text-slate-400 mt-1">
                Model: {swap.valuationModel}
              </div>
            </div>

            <div className="bg-[#121824] border border-slate-800 p-3.5 rounded">
              <div className="text-xs font-mono text-slate-500">DV01 Sensitivity</div>
              <div className="text-lg font-bold font-mono text-rose-400 mt-1">
                -£{Math.abs(swap.risk.dv01).toLocaleString()}/bp
              </div>
              <div className="text-[10px] font-mono text-slate-400 mt-1">
                Yield Curve +1bp Shift
              </div>
            </div>

            <div className="bg-[#121824] border border-slate-800 p-3.5 rounded">
              <div className="text-xs font-mono text-slate-500">Fair Swap Rate R_par</div>
              <div className="text-lg font-bold font-mono text-amber-300 mt-1">
                {(swap.valuation.fairSwapRate * 100).toFixed(3)}%
              </div>
              <div className="text-[10px] font-mono text-slate-400 mt-1">
                Par Spread: +{swap.valuation.parSpreadBp} bps
              </div>
            </div>

            <div className="bg-[#121824] border border-slate-800 p-3.5 rounded">
              <div className="text-xs font-mono text-slate-500">Variation Margin Call</div>
              <div className="text-lg font-bold font-mono text-slate-100 mt-1">
                £{(swap.currentMarginCall / 1e6).toFixed(3)}M
              </div>
              <div className="text-[10px] font-mono text-emerald-400 mt-1">
                ISDA 2016 VM/IM Compliant
              </div>
            </div>
          </div>

          {/* Legs Detail Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {swap.legs.map((leg, idx) => (
              <div
                key={leg.id}
                className={`bg-[#121824] border p-4 rounded-lg space-y-2 ${
                  leg.direction === 'PAY' ? 'border-rose-500/30' : 'border-emerald-500/30'
                }`}
              >
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <span
                    className={`text-xs font-bold font-mono ${
                      leg.direction === 'PAY' ? 'text-rose-400' : 'text-emerald-400'
                    }`}
                  >
                    LEG {idx + 1}: {leg.direction} ({leg.legType})
                  </span>
                  <span className="text-xs font-mono text-slate-400">
                    {leg.currency} {(leg.notional / 1e6).toFixed(1)}M
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs font-mono text-slate-300 pt-1">
                  <div>
                    <span className="text-slate-500 block text-[10px]">Reference</span>
                    <span className="font-bold text-white">{leg.referenceIndexOrAsset}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">Rate / Spread</span>
                    <span>
                      {leg.fixedRate !== undefined
                        ? `${(leg.fixedRate * 100).toFixed(3)}%`
                        : `+${leg.spreadBp || 0} bps`}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">Day Count</span>
                    <span>{leg.dayCount}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">Frequency</span>
                    <span>{leg.paymentFrequency}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab Content: Cashflow Engine */}
      {activeTab === 'CASHFLOWS' && (
        <div className="space-y-4">
          <div className="bg-[#121824] border border-slate-800 p-4 rounded-lg">
            <h3 className="text-xs font-mono uppercase font-bold text-slate-300 mb-2">
              Deterministic Cashflow Schedule ({swap.cashflows.length} Periods)
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              Formula: <code className="font-mono text-amber-300">Net Payment = (Receive Leg Cashflow) − (Pay Leg Cashflow)</code> where each leg cashflow derives from <code className="font-mono text-emerald-300">Rate × Notional × Accrual Fraction</code>.
            </p>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 bg-slate-900/60">
                    <th className="py-2 px-2">#</th>
                    <th className="py-2 px-2">Reset Date</th>
                    <th className="py-2 px-2">Pay Date</th>
                    <th className="py-2 px-2">Accrual</th>
                    <th className="py-2 px-2 text-right">Pay Amount</th>
                    <th className="py-2 px-2 text-right">Receive Amount</th>
                    <th className="py-2 px-2 text-right">Net Cashflow</th>
                    <th className="py-2 px-2 text-right">Discount Factor</th>
                    <th className="py-2 px-2 text-right">Present Value</th>
                    <th className="py-2 px-2 text-center">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {swap.cashflows.map((cf) => (
                    <tr
                      key={cf.periodNumber}
                      onClick={() => setSelectedCashflow(cf)}
                      className="border-b border-slate-800/60 hover:bg-slate-800/40 cursor-pointer transition-colors"
                    >
                      <td className="py-2 px-2 text-slate-400">{cf.periodNumber}</td>
                      <td className="py-2 px-2 text-slate-300">{cf.resetDate}</td>
                      <td className="py-2 px-2 text-slate-300">{cf.paymentDate}</td>
                      <td className="py-2 px-2 text-slate-400">{cf.accrualFraction.toFixed(2)}</td>
                      <td className="py-2 px-2 text-right text-rose-400">
                        £{Math.round(cf.payLegAmount).toLocaleString()}
                      </td>
                      <td className="py-2 px-2 text-right text-emerald-400">
                        £{Math.round(cf.receiveLegAmount).toLocaleString()}
                      </td>
                      <td className={`py-2 px-2 text-right font-bold ${cf.netCashflow >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                        £{Math.round(cf.netCashflow).toLocaleString()}
                      </td>
                      <td className="py-2 px-2 text-right text-slate-400">{cf.discountFactor.toFixed(4)}</td>
                      <td className="py-2 px-2 text-right font-bold text-slate-200">
                        £{Math.round(cf.presentValue).toLocaleString()}
                      </td>
                      <td className="py-2 px-2 text-center">
                        <span className={`px-2 py-0.5 rounded text-[10px] ${cf.status === 'FIXED' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800 text-slate-400'}`}>
                          {cf.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Tab Content: Lifecycle Audit Trail */}
      {activeTab === 'LIFECYCLE' && (
        <div className="bg-[#121824] border border-slate-800 p-4 rounded-lg space-y-4">
          <h3 className="text-xs font-mono uppercase font-bold text-slate-300 mb-3">
            Immutable Machine-Readable Lifecycle Event Ledger
          </h3>

          <div className="space-y-3 font-mono text-xs">
            {swap.lifecycleHistory.map((evt) => (
              <div key={evt.eventId} className="bg-[#0B0E14] border border-slate-800 p-3 rounded flex items-start gap-3">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-amber-400">{evt.eventType}</span>
                    <span className="text-[10px] text-slate-500">{evt.timestamp}</span>
                  </div>
                  <p className="text-slate-300 mt-1">{evt.description}</p>
                  <div className="flex items-center gap-4 mt-2 text-[10px] text-slate-500 border-t border-slate-800/80 pt-1.5">
                    <span>Performed By: {evt.performedBy}</span>
                    <span>Audit Hash: {evt.hash}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab Content: Amend Terms */}
      {activeTab === 'AMEND' && (
        <div className="bg-[#121824] border border-slate-800 p-4 rounded-lg max-w-lg space-y-4">
          <h3 className="text-xs font-mono uppercase font-bold text-amber-400">
            Amend Contractual Terms (Generates Version {swap.version + 1})
          </h3>

          <form onSubmit={handleAmendSubmit} className="space-y-4 text-xs font-mono">
            <div>
              <label className="text-slate-400 block mb-1">New Fixed Leg Rate (%)</label>
              <input
                type="number"
                step="0.001"
                value={newFixedRate}
                onChange={(e) => setNewFixedRate(Number(e.target.value))}
                className="w-full bg-[#0B0E14] border border-slate-800 rounded px-3 py-2 text-white font-bold"
              />
            </div>

            <button
              type="submit"
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded transition-colors"
            >
              Execute Amendment
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
