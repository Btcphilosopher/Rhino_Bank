import React from 'react';
import { X, Code2, Globe, Server, Check } from 'lucide-react';

interface APIDocsModalProps {
  onClose: () => void;
}

export const APIDocsModal: React.FC<APIDocsModalProps> = ({ onClose }) => {
  const endpoints = [
    { method: 'GET', path: '/v1/swaps', desc: 'Retrieve all machine-readable canonical swap objects' },
    { method: 'POST', path: '/v1/swaps', desc: 'Structure and execute a new canonical synthetic swap' },
    { method: 'GET', path: '/v1/swaps/{id}', desc: 'Get full machine-readable chain for a specific swap' },
    { method: 'GET', path: '/v1/swaps/{id}/cashflows', desc: 'Get period cashflow schedule and fixing status' },
    { method: 'GET', path: '/v1/swaps/{id}/price', desc: 'Re-price swap using multi-curve OIS model' },
    { method: 'GET', path: '/v1/swaps/{id}/risk', desc: 'Get DV01, PV01, key-rate DV01s, and sensitivities' },
    { method: 'POST', path: '/v1/swaps/{id}/amend', desc: 'Amend contract terms (creates new version with hash)' },
    { method: 'POST', path: '/v1/swaps/{id}/terminate', desc: 'Execute early termination with close-out settlement' },
    { method: 'GET', path: '/v1/curves', desc: 'Retrieve calibrated yield curves and forward curves' },
    { method: 'POST', path: '/v1/curves/shock', desc: 'Apply curve shock (+/- bp, steepener) across portfolio' },
    { method: 'GET', path: '/v1/portfolios', desc: 'Get portfolio decomposition and netting set exposures' },
    { method: 'POST', path: '/v1/scenarios/run', desc: 'Execute multi-factor stress scenario revaluation' },
    { method: 'POST', path: '/v1/scenarios/monte-carlo', desc: 'Execute seed-reproducible Monte Carlo simulation' },
    { method: 'POST', path: '/v1/ai/query', desc: 'Query RHINOQUANT SWAP INTELLIGENCE AI assistant' },
  ];

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#121824] border border-slate-800 rounded-lg max-w-3xl w-full max-h-[85vh] flex flex-col font-mono text-xs">
        <div className="flex items-center justify-between p-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Code2 className="w-5 h-5 text-amber-400" />
            <h2 className="text-sm font-bold text-white uppercase">
              RhinoQuant Institutional REST & WebSocket API Specification
            </h2>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-slate-800 text-slate-400 rounded">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-4 overflow-y-auto space-y-3">
          {endpoints.map((e, idx) => (
            <div key={idx} className="bg-[#0B0E14] border border-slate-800 p-2.5 rounded flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    e.method === 'GET' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400'
                  }`}
                >
                  {e.method}
                </span>
                <span className="font-bold text-slate-200">{e.path}</span>
              </div>
              <span className="text-slate-400 text-[11px]">{e.desc}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
