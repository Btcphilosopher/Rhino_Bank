import React, { useState } from 'react';
import { Activity, Sliders, RefreshCw, BarChart2 } from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';
import { YieldCurve, VolatilitySurface } from '../types/swap';

interface CurveViewerProps {
  curves: YieldCurve[];
  volSurfaces: VolatilitySurface[];
  onShockCurve: (shiftBp: number) => void;
}

export const CurveViewer: React.FC<CurveViewerProps> = ({
  curves,
  volSurfaces,
  onShockCurve,
}) => {
  const [selectedCurveId, setSelectedCurveId] = useState<string>(curves[0]?.curveId || '');
  const [shockBp, setShockBp] = useState<number>(25);

  const activeCurve = curves.find((c) => c.curveId === selectedCurveId) || curves[0];

  const chartData = activeCurve?.points.map((pt) => ({
    tenor: pt.tenor,
    zeroRatePercent: (pt.zeroRate * 100).toFixed(3),
    parRatePercent: (pt.parRate * 100).toFixed(3),
    discountFactor: pt.discountFactor.toFixed(4),
  }));

  return (
    <div className="space-y-6">
      {/* Curve Selector & Controls */}
      <div className="bg-[#121824] border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <Activity className="w-5 h-5 text-amber-400" />
          <div>
            <h2 className="text-sm font-bold text-white tracking-tight uppercase font-mono">
              Institutional Curve Construction & Volatility Surface Engine
            </h2>
            <span className="text-xs text-slate-400 font-mono">
              Bootstrapping · Discount Factors · Forward Curves · SABR Volatility
            </span>
          </div>
        </div>

        {/* Curve Shock Tool */}
        <div className="flex items-center gap-2 bg-[#0B0E14] border border-slate-800 p-2 rounded text-xs font-mono">
          <span className="text-slate-400">Curve Shock:</span>
          <button
            onClick={() => onShockCurve(25)}
            className="px-2 py-1 bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 border border-amber-500/40 rounded"
          >
            +25bp
          </button>
          <button
            onClick={() => onShockCurve(50)}
            className="px-2 py-1 bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 border border-amber-500/40 rounded"
          >
            +50bp
          </button>
          <button
            onClick={() => onShockCurve(-25)}
            className="px-2 py-1 bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700 rounded"
          >
            -25bp
          </button>
        </div>
      </div>

      {/* Yield Curve Line Chart */}
      <div className="bg-[#121824] border border-slate-800 rounded-lg p-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <BarChart2 className="w-4 h-4 text-amber-400" />
            <h3 className="text-xs font-bold text-slate-200 uppercase font-mono">
              {activeCurve.name} ({activeCurve.currency})
            </h3>
          </div>
          <span className="text-xs font-mono text-emerald-400">
            {activeCurve.status} · {activeCurve.version}
          </span>
        </div>

        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
              <XAxis dataKey="tenor" stroke="#64748B" tick={{ fontSize: 11, fill: '#94A3B8' }} />
              <YAxis stroke="#64748B" tick={{ fontSize: 11, fill: '#94A3B8' }} domain={['auto', 'auto']} />
              <Tooltip
                contentStyle={{ backgroundColor: '#0B0E14', borderColor: '#334155', color: '#F1F5F9', fontSize: 12 }}
              />
              <Line type="monotone" dataKey="zeroRatePercent" name="Zero Rate (%)" stroke="#F59E0B" strokeWidth={2} dot={{ r: 4 }} />
              <Line type="monotone" dataKey="parRatePercent" name="Par Rate (%)" stroke="#10B981" strokeWidth={2} dot={{ r: 4 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
