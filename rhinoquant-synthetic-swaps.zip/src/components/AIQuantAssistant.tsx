import React, { useState } from 'react';
import { Bot, Send, Sparkles, AlertCircle, HelpCircle, CornerDownLeft } from 'lucide-react';

interface AIQuantAssistantProps {
  onClose?: () => void;
}

export const AIQuantAssistant: React.FC<AIQuantAssistantProps> = () => {
  const [prompt, setPrompt] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [response, setResponse] = useState<string | null>(null);
  const [history, setHistory] = useState<{ query: string; answer: string }[]>([]);

  const samplePrompts = [
    'Why did the value of my portfolio change today?',
    'What is my largest DV01 exposure across counterparties?',
    'What happens to portfolio PV if SONIA rises 50bp?',
    'Which swaps offset my 5Y GBP IRS position?',
    'Summarize cashflows due for settlement in the next 12 months.',
  ];

  const handleAsk = async (queryToAsk?: string) => {
    const query = queryToAsk || prompt;
    if (!query.trim()) return;

    setLoading(true);
    setResponse(null);

    try {
      const res = await fetch('/v1/ai/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: query }),
      });

      const data = await res.json();
      const answerText = data.answer || data.error || 'No response returned.';
      setResponse(answerText);
      setHistory([{ query, answer: answerText }, ...history]);
      setPrompt('');
    } catch (err: any) {
      setResponse(`Error communicating with RhinoQuant AI: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-[#121824] border border-slate-800 rounded-lg p-4 space-y-6">
      <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Bot className="w-5 h-5 text-emerald-400" />
          <h2 className="text-sm font-bold text-white tracking-tight uppercase font-mono">
            RHINOQUANT SWAP INTELLIGENCE (AI QUANT ASSISTANT)
          </h2>
        </div>
        <span className="text-xs font-mono text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded bg-emerald-500/10">
          Server-Side Gemini 3.8-Flash
        </span>
      </div>

      {/* Sample Prompt Chips */}
      <div className="space-y-1.5 font-mono text-xs">
        <span className="text-slate-400 text-[10px] uppercase font-bold block mb-1">
          Quantitative Quick Queries:
        </span>
        <div className="flex flex-wrap gap-2">
          {samplePrompts.map((p, idx) => (
            <button
              key={idx}
              onClick={() => handleAsk(p)}
              className="px-2.5 py-1 bg-[#0B0E14] hover:bg-slate-800 text-slate-300 border border-slate-800 rounded transition-colors text-left"
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      {/* Input Box */}
      <div className="relative">
        <textarea
          rows={3}
          placeholder="Ask RHINOQUANT SWAP INTELLIGENCE about your trades, valuations, curves, or risk exposures..."
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          className="w-full bg-[#0B0E14] border border-slate-800 rounded p-3 text-xs font-mono text-slate-100 focus:outline-none focus:border-emerald-500 resize-none"
        />
        <button
          onClick={() => handleAsk()}
          disabled={loading || !prompt.trim()}
          className="absolute right-3 bottom-3 px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded font-mono transition-colors flex items-center gap-1.5 disabled:opacity-50"
        >
          <Send className="w-3.5 h-3.5" />
          {loading ? 'Analyzing...' : 'Ask AI'}
        </button>
      </div>

      {/* Response View */}
      {response && (
        <div className="bg-[#0B0E14] border border-emerald-500/40 p-4 rounded space-y-2 font-mono text-xs">
          <div className="flex items-center gap-2 text-emerald-400 font-bold border-b border-slate-800 pb-2">
            <Sparkles className="w-4 h-4" /> RHINOQUANT AI QUANT RESPONSE
          </div>
          <div className="text-slate-200 whitespace-pre-wrap leading-relaxed pt-1">
            {response}
          </div>
        </div>
      )}
    </div>
  );
};
