import React from 'react';
import { BarChart3, TrendingUp, ShieldAlert, PieChart as PieIcon, Layers } from 'lucide-react';
import { CanonicalSwap } from '../types/swap';

interface PortfolioViewProps {
  swaps: CanonicalSwap[];
}

export const PortfolioView: React.FC<PortfolioViewProps> = ({ swaps }) => {
  const grossNotional = swaps.reduce((acc, s) => acc + s.notional, 0);
  const totalPv = swaps.reduce((acc, s) => acc + s.valuation.cleanPv, 0);
  const totalDv01 = swaps.reduce((acc, s) => acc + s.risk.dv01, 0);
  const totalCs01 = swaps.reduce((acc, s) => acc + (s.risk.cs01 || 0), 0);

  // Group by Swap Family
  const familyBreakdown: Record<string, { count: number; notional: number; pv: number }> = {};
  swaps.forEach((s) => {
    if (!familyBreakdown[s.swapFamily]) {
      familyBreakdown[s.swapFamily] = { count: 0, notional: 0, pv: 0 };
    }
    familyBreakdown[s.swapFamily].count += 1;
    familyBreakdown[s.swapFamily].notional += s.notional;
    familyBreakdown[s.swapFamily].pv += s.valuation.cleanPv;
  });

  return (
    <div className="space-y-6">
      {/* High Level Portfolio Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-[#121824] border border-slate-800 p-4 rounded-lg">
          <span className="text-xs font-mono text-slate-500 block">Gross Portfolio Notional</span>
          <span className="text-xl font-bold font-mono text-amber-400 mt-1 block">
            £{(grossNotional / 1e9).toFixed(2)} Billion
          </span>
          <span className="text-[10px] font-mono text-slate-400 mt-1 block">
            {swaps.length} Active Synthetic Swap Contracts
          </span>
        </div>

        <div className="bg-[#121824] border border-slate-800 p-4 rounded-lg">
          <span className="text-xs font-mono text-slate-500 block">Total Mark-to-Market PV</span>
          <span className={`text-xl font-bold font-mono mt-1 block ${totalPv >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            £{(totalPv / 1e6).toFixed(3)} Million
          </span>
          <span className="text-[10px] font-mono text-slate-400 mt-1 block">
            Discounted via OIS & Forward Curves
          </span>
        </div>

        <div className="bg-[#121824] border border-slate-800 p-4 rounded-lg">
          <span className="text-xs font-mono text-slate-500 block">Net Portfolio DV01</span>
          <span className="text-xl font-bold font-mono text-rose-400 mt-1 block">
            -£{Math.abs(totalDv01).toLocaleString()}/bp
          </span>
          <span className="text-[10px] font-mono text-slate-400 mt-1 block">
            Rate Curve Sensitivity
          </span>
        </div>

        <div className="bg-[#121824] border border-slate-800 p-4 rounded-lg">
          <span className="text-xs font-mono text-slate-500 block">Net Credit CS01</span>
          <span className="text-xl font-bold font-mono text-amber-300 mt-1 block">
            -£{Math.abs(totalCs01).toLocaleString()}/bp
          </span>
          <span className="text-[10px] font-mono text-slate-400 mt-1 block">
            Credit Spread Sensitivity
          </span>
        </div>
      </div>

      {/* Asset Class Breakdown */}
      <div className="bg-[#121824] border border-slate-800 p-4 rounded-lg space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <h2 className="text-xs font-bold text-white uppercase font-mono flex items-center gap-2">
            <PieIcon className="w-4 h-4 text-amber-400" />
            Asset Class Portfolio Decomposition
          </h2>
          <span className="text-xs font-mono text-slate-400">TOTAL P&L → ASSET CLASS → SWAP → LEG</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {Object.entries(familyBreakdown).map(([family, data]) => (
            <div key={family} className="bg-[#0B0E14] border border-slate-800 p-3.5 rounded space-y-2 font-mono">
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                <span className="font-bold text-amber-400 text-xs">{family}</span>
                <span className="text-[10px] text-slate-500">{data.count} Swaps</span>
              </div>

              <div className="text-xs space-y-1 pt-1">
                <div className="flex justify-between text-slate-400">
                  <span>Gross Notional:</span>
                  <span className="text-slate-200 font-bold">£{(data.notional / 1e6).toFixed(1)}M</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Clean PV:</span>
                  <span className={`font-bold ${data.pv >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    £{(data.pv / 1e6).toFixed(3)}M
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
