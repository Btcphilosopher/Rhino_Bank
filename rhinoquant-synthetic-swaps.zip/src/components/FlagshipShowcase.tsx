import React, { useState } from 'react';
import { Zap, Activity, ArrowUpRight, CheckCircle2, TrendingUp, Cpu } from 'lucide-react';
import { CanonicalSwap } from '../types/swap';

interface FlagshipShowcaseProps {
  onSelectSwap: (swapId: string) => void;
  onRunCurveShock: (shiftBp: number) => Promise<void>;
  swaps: CanonicalSwap[];
}

export const FlagshipShowcase: React.FC<FlagshipShowcaseProps> = ({
  onSelectSwap,
  onRunCurveShock,
  swaps,
}) => {
  const [isShocking, setIsShocking] = useState(false);
  const [lastShock, setLastShock] = useState<string | null>(null);

  const flagship1 = swaps.find((s) => s.swapId === 'SWAP-FLAGSHIP-001') || swaps[0];
  const flagship2 = swaps.find((s) => s.swapId === 'SWAP-FLAGSHIP-002') || swaps[1];
  const flagship3 = swaps.find((s) => s.swapId === 'SWAP-FLAGSHIP-003') || swaps[2];

  const handleShock = async (bp: number) => {
    setIsShocking(true);
    await onRunCurveShock(bp);
    setIsShocking(false);
    setLastShock(`SONIA Curve Shifted +${bp}bp at ${new Date().toLocaleTimeString()}`);
  };

  return (
    <section className="bg-[#121824] border border-slate-800 rounded-lg p-4 mb-6">
      <div className="flex flex-wrap items-center justify-between gap-4 mb-3 border-b border-slate-800/80 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 text-[10px] font-mono uppercase bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded">
              INSTITUTIONAL DEMONSTRATION SUITE
            </span>
            <h2 className="text-base font-bold text-white tracking-tight">
              RhinoQuant Flagship Synthetic Swaps
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Pre-structured machine-readable financial objects with active cashflow schedules, multi-curve OIS discounting, and real-time sensitivity waterfalls.
          </p>
        </div>

        {/* 1-Click SONIA +50bp Shock Simulation */}
        <div className="flex items-center gap-3">
          {lastShock && (
            <span className="text-xs font-mono text-emerald-400 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              {lastShock}
            </span>
          )}

          <button
            onClick={() => handleShock(50)}
            disabled={isShocking}
            className="px-3 py-2 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-slate-950 font-bold text-xs rounded transition-all shadow-md shadow-amber-500/10 flex items-center gap-2 disabled:opacity-50"
          >
            <Activity className="w-4 h-4 animate-pulse" />
            {isShocking ? 'Re-calculating Curves & Risk...' : 'Simulate SONIA +50bp Shock'}
          </button>
        </div>
      </div>

      {/* 3 Flagship Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* FLAGSHIP 1 */}
        {flagship1 && (
          <div
            onClick={() => onSelectSwap(flagship1.swapId)}
            className="bg-[#0B0E14] border border-slate-800 hover:border-amber-500/50 p-3.5 rounded transition-all cursor-pointer group hover:bg-slate-900/60"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5 text-xs text-slate-400">
                <span className="font-mono text-amber-400 font-semibold">FLAGSHIP 01</span>
                <span>·</span>
                <span>GBP IRS</span>
              </div>
              <ArrowUpRight className="w-4 h-4 text-slate-500 group-hover:text-amber-400 transition-colors" />
            </div>

            <h3 className="text-sm font-bold text-slate-100 mb-1 group-hover:text-amber-300 transition-colors">
              RHINOQUANT SONIA SWAP 01
            </h3>
            <p className="text-xs text-slate-400 mb-3">
              £1.0B 5-Year Fixed-for-Floating GBP Interest Rate Swap. Rec SONIA vs Pay Fixed 4.125%.
            </p>

            <div className="grid grid-cols-2 gap-2 text-xs font-mono bg-slate-900/80 p-2 rounded border border-slate-800/80 mb-2">
              <div>
                <div className="text-slate-500 text-[10px]">Clean PV</div>
                <div className="font-bold text-emerald-400">
                  £{(flagship1.valuation.cleanPv / 1e6).toFixed(3)}M
                </div>
              </div>
              <div>
                <div className="text-slate-500 text-[10px]">DV01 Sensitivity</div>
                <div className="font-bold text-rose-400">
                  -£{Math.abs(flagship1.risk.dv01).toLocaleString()}/bp
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
              <span>Counterparty: Barclays Synth</span>
              <span className="text-amber-400 font-semibold">OIS Discounting</span>
            </div>
          </div>
        )}

        {/* FLAGSHIP 2 */}
        {flagship2 && (
          <div
            onClick={() => onSelectSwap(flagship2.swapId)}
            className="bg-[#0B0E14] border border-slate-800 hover:border-amber-500/50 p-3.5 rounded transition-all cursor-pointer group hover:bg-slate-900/60"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5 text-xs text-slate-400">
                <span className="font-mono text-amber-400 font-semibold">FLAGSHIP 02</span>
                <span>·</span>
                <span>COMMODITY</span>
              </div>
              <ArrowUpRight className="w-4 h-4 text-slate-500 group-hover:text-amber-400 transition-colors" />
            </div>

            <h3 className="text-sm font-bold text-slate-100 mb-1 group-hover:text-amber-300 transition-colors">
              NORTH SEA POWER SWAP 01
            </h3>
            <p className="text-xs text-slate-400 mb-3">
              £250M Electricity Swap referencing UK Baseload Power Index (£82.50/MWh fixed).
            </p>

            <div className="grid grid-cols-2 gap-2 text-xs font-mono bg-slate-900/80 p-2 rounded border border-slate-800/80 mb-2">
              <div>
                <div className="text-slate-500 text-[10px]">Clean PV</div>
                <div className="font-bold text-emerald-400">
                  £{(flagship2.valuation.cleanPv / 1e6).toFixed(3)}M
                </div>
              </div>
              <div>
                <div className="text-slate-500 text-[10px]">Commodity Delta</div>
                <div className="font-bold text-amber-300">
                  +£{flagship2.risk.commodityDelta?.toLocaleString()}/MWh
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
              <span>Counterparty: Morgan Stanley</span>
              <span className="text-amber-400 font-semibold">Power Forward Curve</span>
            </div>
          </div>
        )}

        {/* FLAGSHIP 3 */}
        {flagship3 && (
          <div
            onClick={() => onSelectSwap(flagship3.swapId)}
            className="bg-[#0B0E14] border border-slate-800 hover:border-amber-500/50 p-3.5 rounded transition-all cursor-pointer group hover:bg-slate-900/60"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5 text-xs text-slate-400">
                <span className="font-mono text-amber-400 font-semibold">FLAGSHIP 03</span>
                <span>·</span>
                <span>DIGITAL ASSET</span>
              </div>
              <ArrowUpRight className="w-4 h-4 text-slate-500 group-hover:text-amber-400 transition-colors" />
            </div>

            <h3 className="text-sm font-bold text-slate-100 mb-1 group-hover:text-amber-300 transition-colors">
              BTC TOTAL RETURN SWAP 01
            </h3>
            <p className="text-xs text-slate-400 mb-3">
              £100M Synthetic BTC Total Return Swap referencing BTC/GBP Index Spot vs SONIA+120bp.
            </p>

            <div className="grid grid-cols-2 gap-2 text-xs font-mono bg-slate-900/80 p-2 rounded border border-slate-800/80 mb-2">
              <div>
                <div className="text-slate-500 text-[10px]">Clean PV</div>
                <div className="font-bold text-emerald-400">
                  £{(flagship3.valuation.cleanPv / 1e6).toFixed(3)}M
                </div>
              </div>
              <div>
                <div className="text-slate-500 text-[10px]">Spot Delta (1%)</div>
                <div className="font-bold text-emerald-400">
                  +£{( (flagship3.risk.digitalAssetDelta || 0) / 1e6).toFixed(2)}M
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
              <span>Counterparty: Goldman Sachs</span>
              <span className="text-amber-400 font-semibold">Monte Carlo TR Model</span>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
