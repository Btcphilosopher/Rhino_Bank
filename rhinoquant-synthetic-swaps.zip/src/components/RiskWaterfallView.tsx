import React from 'react';
import { TrendingUp, ArrowDown, Activity, Shield, DollarSign } from 'lucide-react';
import { CanonicalSwap } from '../types/swap';

interface RiskWaterfallViewProps {
  swaps: CanonicalSwap[];
}

export const RiskWaterfallView: React.FC<RiskWaterfallViewProps> = ({ swaps }) => {
  const totalPv = swaps.reduce((acc, s) => acc + s.valuation.cleanPv, 0);
  const totalDv01 = swaps.reduce((acc, s) => acc + s.risk.dv01, 0);
  const totalMarginCall = swaps.reduce((acc, s) => acc + s.currentMarginCall, 0);

  return (
    <div className="bg-[#121824] border border-slate-800 rounded-lg p-4 space-y-6">
      <div className="border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-amber-400" />
          <h2 className="text-sm font-bold text-white tracking-tight uppercase font-mono">
            RhinoQuant Synthetic Swap Risk Waterfall
          </h2>
        </div>
        <p className="text-xs text-slate-400 mt-0.5">
          Step-by-step causal chain mapping market factor shocks through forward curves, cashflow revaluation, PV delta, DV01, margin requirements, and portfolio P&L.
        </p>
      </div>

      {/* Visual Risk Waterfall Flow */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-3 text-xs font-mono overflow-x-auto py-2">
        <div className="bg-[#0B0E14] border border-amber-500/40 p-3 rounded w-full md:w-auto text-center space-y-1">
          <span className="text-[10px] text-amber-400 font-bold block">1. MARKET FACTOR</span>
          <span className="text-slate-100 font-bold">SONIA +25bp Shift</span>
        </div>

        <ArrowDown className="w-4 h-4 text-amber-400 shrink-0 md:-rotate-90" />

        <div className="bg-[#0B0E14] border border-slate-800 p-3 rounded w-full md:w-auto text-center space-y-1">
          <span className="text-[10px] text-slate-500 font-bold block">2. CURVE SHIFT</span>
          <span className="text-slate-200 font-bold">Forward Rates Shift</span>
        </div>

        <ArrowDown className="w-4 h-4 text-slate-600 shrink-0 md:-rotate-90" />

        <div className="bg-[#0B0E14] border border-slate-800 p-3 rounded w-full md:w-auto text-center space-y-1">
          <span className="text-[10px] text-slate-500 font-bold block">3. CASHFLOW REVAL</span>
          <span className="text-slate-200 font-bold">Discount Factors Adj</span>
        </div>

        <ArrowDown className="w-4 h-4 text-slate-600 shrink-0 md:-rotate-90" />

        <div className="bg-[#0B0E14] border border-rose-500/40 p-3 rounded w-full md:w-auto text-center space-y-1">
          <span className="text-[10px] text-rose-400 font-bold block">4. PV CHANGE (DV01)</span>
          <span className="text-rose-300 font-bold">£{Math.round(totalDv01 * 25).toLocaleString()}</span>
        </div>

        <ArrowDown className="w-4 h-4 text-rose-400 shrink-0 md:-rotate-90" />

        <div className="bg-[#0B0E14] border border-emerald-500/40 p-3 rounded w-full md:w-auto text-center space-y-1">
          <span className="text-[10px] text-emerald-400 font-bold block">5. MARGIN REQUIREMENT</span>
          <span className="text-emerald-300 font-bold">£{(totalMarginCall / 1e6).toFixed(2)}M VM/IM</span>
        </div>
      </div>
    </div>
  );
};
