import React from 'react';
import { FileText, AlertTriangle, ShieldCheck } from 'lucide-react';
import { DisputeRecord } from '../types/swap';

interface DisputeCenterProps {
  disputes: DisputeRecord[];
}

export const DisputeCenter: React.FC<DisputeCenterProps> = ({ disputes }) => {
  return (
    <div className="bg-[#121824] border border-slate-800 rounded-lg p-4 space-y-6">
      <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <FileText className="w-4 h-4 text-amber-400" />
          <h2 className="text-sm font-bold text-white tracking-tight uppercase font-mono">
            Institutional Valuation Dispute Centre
          </h2>
        </div>
        <span className="text-xs font-mono text-amber-400">
          {disputes.length} Active Valuation Dispute Claims
        </span>
      </div>

      <div className="space-y-4 font-mono text-xs">
        {disputes.map((d) => (
          <div key={d.disputeId} className="bg-[#0B0E14] border border-slate-800 p-4 rounded space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-400" />
                <span className="font-bold text-slate-100">{d.disputeId}</span>
                <span>·</span>
                <span className="text-slate-400">{d.swapId}</span>
                <span>·</span>
                <span className="text-amber-400">{d.counterparty}</span>
              </div>
              <span className="px-2 py-0.5 bg-amber-500/20 text-amber-300 rounded text-[10px] font-bold">
                {d.status}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 bg-slate-900/60 p-2.5 rounded">
              <div>
                <span className="text-slate-500 block text-[10px]">RhinoQuant PV</span>
                <span className="font-bold text-emerald-400">£{d.rhinoQuantPv.toLocaleString()}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">Counterparty PV</span>
                <span className="font-bold text-slate-200">£{d.counterpartyPv.toLocaleString()}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">Variance Delta</span>
                <span className="font-bold text-rose-400">£{d.variancePv.toLocaleString()}</span>
              </div>
            </div>

            {/* Attribution Breakdown */}
            <div>
              <span className="text-slate-500 text-[10px] block mb-1">Valuation Difference Attribution</span>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-[11px] text-slate-300 bg-slate-950 p-2 rounded">
                <div>Market Data: +£{d.attribution.marketDataDiff.toLocaleString()}</div>
                <div>Curve Diff: +£{d.attribution.curveDiff.toLocaleString()}</div>
                <div>Model Diff: +£{d.attribution.modelDiff.toLocaleString()}</div>
                <div>Term Diff: +£{d.attribution.termDiff.toLocaleString()}</div>
                <div>Timing Diff: +£{d.attribution.timingDiff.toLocaleString()}</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
