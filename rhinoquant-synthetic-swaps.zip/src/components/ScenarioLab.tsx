import React, { useState } from 'react';
import { Cpu, Play, BarChart2, ShieldAlert } from 'lucide-react';
import { CanonicalSwap, YieldCurve } from '../types/swap';
import { runScenario, runMonteCarlo, MonteCarloResult, StressScenario } from '../engine/scenario';

interface ScenarioLabProps {
  swaps: CanonicalSwap[];
  yieldCurve: YieldCurve;
}

export const ScenarioLab: React.FC<ScenarioLabProps> = ({ swaps, yieldCurve }) => {
  const [numPaths, setNumPaths] = useState<number>(2000);
  const [seed, setSeed] = useState<number>(42);
  const [mcResult, setMcResult] = useState<MonteCarloResult | null>(null);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);

  const [shiftBp, setShiftBp] = useState<number>(50);
  const [scenarioOutput, setScenarioOutput] = useState<any>(null);

  const handleRunMonteCarlo = () => {
    setIsSimulating(true);
    setTimeout(() => {
      const res = runMonteCarlo(swaps[0], yieldCurve, numPaths, seed);
      setMcResult(res);
      setIsSimulating(false);
    }, 400);
  };

  const handleRunStressScenario = () => {
    const sc: StressScenario = {
      scenarioId: 'SCEN-01',
      name: `Parallel Curve Shift +${shiftBp}bp`,
      description: `Shocking SONIA curve by +${shiftBp}bp across all tenors`,
      rateParallelShiftBp: shiftBp,
      creditSpreadShiftBp: 15,
      fxShiftPercent: 2,
      commodityShiftPercent: 5,
      volatilityShiftPercent: 10,
    };
    const res = runScenario(swaps[0], yieldCurve, sc);
    setScenarioOutput(res);
  };

  return (
    <div className="space-y-6">
      <div className="bg-[#121824] border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <Cpu className="w-5 h-5 text-amber-400" />
          <div>
            <h2 className="text-sm font-bold text-white tracking-tight uppercase font-mono">
              RhinoQuant Quantitative Scenario Lab & Reproducible Monte Carlo Engine
            </h2>
            <span className="text-xs text-slate-400 font-mono">
              Multi-Factor Stress Testing · Potential Future Exposure (PFE 95%) · VaR 99% · Expected Shortfall
            </span>
          </div>
        </div>
      </div>

      {/* Grid: Scenario Lab & Monte Carlo */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Multi-Factor Stress Lab */}
        <div className="bg-[#121824] border border-slate-800 rounded-lg p-4 space-y-4 font-mono text-xs">
          <h3 className="font-bold text-slate-200 uppercase border-b border-slate-800 pb-2">
            1. Multi-Factor Stress Scenario Lab
          </h3>

          <div className="space-y-3">
            <div>
              <label className="text-slate-400 block mb-1">Rate Shift (+/- bp)</label>
              <input
                type="number"
                value={shiftBp}
                onChange={(e) => setShiftBp(Number(e.target.value))}
                className="w-full bg-[#0B0E14] border border-slate-800 rounded px-3 py-1.5 text-amber-400 font-bold"
              />
            </div>

            <button
              onClick={handleRunStressScenario}
              className="w-full py-2 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-slate-950 font-bold rounded transition-colors flex items-center justify-center gap-2"
            >
              <Play className="w-4 h-4" /> Run Stress Test Re-valuation
            </button>
          </div>

          {scenarioOutput && (
            <div className="bg-[#0B0E14] border border-slate-800 p-3 rounded space-y-2 text-xs pt-3">
              <div className="text-amber-400 font-bold">{scenarioOutput.scenarioName}</div>
              <div className="flex justify-between text-slate-400">
                <span>Base PV:</span>
                <span className="text-slate-200">£{(scenarioOutput.basePv / 1e6).toFixed(3)}M</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Shocked PV:</span>
                <span className="text-emerald-400 font-bold">£{(scenarioOutput.shockedPv / 1e6).toFixed(3)}M</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>PV Delta:</span>
                <span className={`font-bold ${scenarioOutput.pvChange >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  £{scenarioOutput.pvChange.toLocaleString()}
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Monte Carlo Simulator */}
        <div className="bg-[#121824] border border-slate-800 rounded-lg p-4 space-y-4 font-mono text-xs">
          <h3 className="font-bold text-slate-200 uppercase border-b border-slate-800 pb-2">
            2. Reproducible Monte Carlo Simulation Engine
          </h3>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-slate-400 block mb-1">Number of Paths</label>
              <input
                type="number"
                value={numPaths}
                onChange={(e) => setNumPaths(Number(e.target.value))}
                className="w-full bg-[#0B0E14] border border-slate-800 rounded px-3 py-1.5 text-white"
              />
            </div>
            <div>
              <label className="text-slate-400 block mb-1">Random Seed</label>
              <input
                type="number"
                value={seed}
                onChange={(e) => setSeed(Number(e.target.value))}
                className="w-full bg-[#0B0E14] border border-slate-800 rounded px-3 py-1.5 text-amber-400 font-bold"
              />
            </div>
          </div>

          <button
            onClick={handleRunMonteCarlo}
            disabled={isSimulating}
            className="w-full py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
          >
            <Play className="w-4 h-4" />
            {isSimulating ? 'Simulating Paths...' : 'Execute Monte Carlo Simulation'}
          </button>

          {mcResult && (
            <div className="bg-[#0B0E14] border border-slate-800 p-3 rounded space-y-2">
              <div className="flex justify-between text-slate-400">
                <span>Value at Risk (VaR 95%):</span>
                <span className="text-rose-400 font-bold">£{mcResult.var95.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Potential Future Exposure (PFE 95%):</span>
                <span className="text-emerald-400 font-bold">£{(mcResult.pfe95 / 1e6).toFixed(3)}M</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Expected Shortfall (ES 97.5%):</span>
                <span className="text-rose-400 font-bold">£{mcResult.expectedShortfall975.toLocaleString()}</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
