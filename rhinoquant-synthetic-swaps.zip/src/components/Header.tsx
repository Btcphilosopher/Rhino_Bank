import React from 'react';
import {
  Activity,
  Layers,
  BarChart3,
  GitCommit,
  Shield,
  Zap,
  TrendingUp,
  Cpu,
  Bot,
  Code2,
  FileText,
  Boxes,
} from 'lucide-react';

export type ActiveTab =
  | 'FACTORY'
  | 'BLOTTER'
  | 'RFQ'
  | 'PORTFOLIO'
  | 'RISK_WATERFALL'
  | 'CURVES'
  | 'COLLATERAL'
  | 'COMPRESSION'
  | 'SCENARIO'
  | 'DISPUTE'
  | 'GOVERNANCE'
  | 'AI_ASSISTANT';

interface HeaderProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  onOpenApiDocs: () => void;
  swapsCount: number;
  totalPv: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onOpenApiDocs,
  swapsCount,
  totalPv,
}) => {
  return (
    <header className="border-b border-slate-800 bg-[#0E131F] px-4 py-2.5 text-slate-200 sticky top-0 z-40">
      <div className="flex flex-wrap items-center justify-between gap-3">
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="flex items-center gap-2 bg-gradient-to-r from-amber-600/20 to-amber-500/10 border border-amber-500/30 px-2.5 py-1 rounded">
            <Zap className="w-4 h-4 text-amber-400" />
            <span className="font-bold tracking-tight text-white text-base font-mono">
              RHINOQUANT<span className="text-amber-400">.SWAPS</span>
            </span>
          </div>
          <span className="hidden xl:inline-block text-xs font-mono text-slate-400 border-l border-slate-700 pl-3">
            SYNTHETIC DERIVATIVES OS
          </span>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="flex items-center gap-1 overflow-x-auto py-1 scrollbar-none text-xs font-medium">
          <button
            onClick={() => setActiveTab('FACTORY')}
            className={`px-2.5 py-1.5 rounded transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'FACTORY'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Boxes className="w-3.5 h-3.5" />
            Swap Factory
          </button>

          <button
            onClick={() => setActiveTab('BLOTTER')}
            className={`px-2.5 py-1.5 rounded transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'BLOTTER'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            Trading Blotter ({swapsCount})
          </button>

          <button
            onClick={() => setActiveTab('RFQ')}
            className={`px-2.5 py-1.5 rounded transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'RFQ'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            RFQ Terminal
          </button>

          <button
            onClick={() => setActiveTab('PORTFOLIO')}
            className={`px-2.5 py-1.5 rounded transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'PORTFOLIO'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            Portfolio
          </button>

          <button
            onClick={() => setActiveTab('RISK_WATERFALL')}
            className={`px-2.5 py-1.5 rounded transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'RISK_WATERFALL'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5" />
            Risk Waterfall
          </button>

          <button
            onClick={() => setActiveTab('CURVES')}
            className={`px-2.5 py-1.5 rounded transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'CURVES'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            Curves & Vol
          </button>

          <button
            onClick={() => setActiveTab('COLLATERAL')}
            className={`px-2.5 py-1.5 rounded transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'COLLATERAL'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            Collateral
          </button>

          <button
            onClick={() => setActiveTab('COMPRESSION')}
            className={`px-2.5 py-1.5 rounded transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'COMPRESSION'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <GitCommit className="w-3.5 h-3.5" />
            Compression
          </button>

          <button
            onClick={() => setActiveTab('SCENARIO')}
            className={`px-2.5 py-1.5 rounded transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'SCENARIO'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Cpu className="w-3.5 h-3.5" />
            Scenario Lab
          </button>

          <button
            onClick={() => setActiveTab('DISPUTE')}
            className={`px-2.5 py-1.5 rounded transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'DISPUTE'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            Disputes
          </button>

          <button
            onClick={() => setActiveTab('GOVERNANCE')}
            className={`px-2.5 py-1.5 rounded transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'GOVERNANCE'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            Governance
          </button>
        </nav>

        {/* Zone 3: Live Status & Primary Actions */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Portfolio PV Badge */}
          <div className="hidden sm:flex items-center gap-2 bg-slate-900 border border-slate-800 px-3 py-1 rounded text-xs">
            <span className="text-slate-400">Total PV:</span>
            <span className={`font-mono font-bold ${totalPv >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              £{(totalPv / 1e6).toFixed(2)}M
            </span>
          </div>

          {/* AI Assistant Button */}
          <button
            onClick={() => setActiveTab('AI_ASSISTANT')}
            className={`px-3 py-1.5 rounded text-xs font-medium transition-all flex items-center gap-1.5 ${
              activeTab === 'AI_ASSISTANT'
                ? 'bg-emerald-500 text-slate-950 font-bold shadow-lg shadow-emerald-500/20'
                : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/20'
            }`}
          >
            <Bot className="w-3.5 h-3.5" />
            Quant AI
          </button>

          {/* REST/WS API Docs */}
          <button
            onClick={onOpenApiDocs}
            className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 rounded text-xs font-mono transition-colors flex items-center gap-1"
            title="REST & WebSocket OpenAPI Specifications"
          >
            <Code2 className="w-3.5 h-3.5 text-amber-400" />
            API
          </button>
        </div>
      </div>
    </header>
  );
};
