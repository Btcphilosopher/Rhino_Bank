import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';
import {
  INITIAL_YIELD_CURVES,
  INITIAL_VOLATILITY_SURFACES,
  INITIAL_NETTING_SETS,
  INITIAL_SWAPS,
  INITIAL_MODEL_GOVERNANCE,
  INITIAL_DISPUTES,
  INITIAL_PNL_ATTRIBUTION,
} from './src/data/seedData';
import { CanonicalSwap, YieldCurve, ContractStatus, RFQ, Quote } from './src/types/swap';
import { priceSwap } from './src/engine/pricing';
import { calculateSwapRisk } from './src/engine/risk';
import { calculateSwapMargin, calculateNettingSetExposure } from './src/engine/collateral';
import { identifyCompressionOpportunities } from './src/engine/compression';
import { runScenario, runMonteCarlo } from './src/engine/scenario';
import { applyCurveShock } from './src/engine/curves';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json());

// In-Memory State Database
let yieldCurves: YieldCurve[] = [...INITIAL_YIELD_CURVES];
let swapsState: CanonicalSwap[] = [...INITIAL_SWAPS];
let nettingSets = [...INITIAL_NETTING_SETS];
let modelGovernance = [...INITIAL_MODEL_GOVERNANCE];
let disputes = [...INITIAL_DISPUTES];
let pnlHistory = [...INITIAL_PNL_ATTRIBUTION];
let rfqs: RFQ[] = [];

// Initialize swap cashflows, valuation and risk upon launch
function initializeState() {
  const primaryCurve = yieldCurves[0];
  swapsState = swapsState.map((swap) => {
    const priced = priceSwap(swap, primaryCurve);
    const risk = calculateSwapRisk(priced.swap, primaryCurve);
    return {
      ...priced.swap,
      risk,
    };
  });
}
initializeState();

// Initialize Gemini Client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || 'PLACEHOLDER_KEY',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// REST API ENDPOINTS

// Get all Swaps
app.get('/v1/swaps', (req: Request, res: Response) => {
  res.json({ count: swapsState.length, swaps: swapsState });
});

// Create new Swap
app.post('/v1/swaps', (req: Request, res: Response) => {
  const newSwapData: CanonicalSwap = req.body;
  const primaryCurve = yieldCurves[0];
  const priced = priceSwap(newSwapData, primaryCurve);
  const risk = calculateSwapRisk(priced.swap, primaryCurve);

  const completeSwap: CanonicalSwap = {
    ...priced.swap,
    risk,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  swapsState.push(completeSwap);
  res.status(201).json({ message: 'Swap created successfully', swap: completeSwap });
});

// Get Swap by ID
app.get('/v1/swaps/:id', (req: Request, res: Response) => {
  const swap = swapsState.find((s) => s.swapId === req.params.id || s.tradeId === req.params.id);
  if (!swap) {
    return res.status(404).json({ error: 'Swap not found' });
  }
  res.json(swap);
});

// Get Swap Cashflows
app.get('/v1/swaps/:id/cashflows', (req: Request, res: Response) => {
  const swap = swapsState.find((s) => s.swapId === req.params.id);
  if (!swap) return res.status(404).json({ error: 'Swap not found' });
  res.json({ swapId: swap.swapId, cashflows: swap.cashflows });
});

// Re-price Swap
app.get('/v1/swaps/:id/price', (req: Request, res: Response) => {
  const swap = swapsState.find((s) => s.swapId === req.params.id);
  if (!swap) return res.status(404).json({ error: 'Swap not found' });
  const primaryCurve = yieldCurves[0];
  const priced = priceSwap(swap, primaryCurve);
  res.json(priced.valuation);
});

// Get Swap Risk
app.get('/v1/swaps/:id/risk', (req: Request, res: Response) => {
  const swap = swapsState.find((s) => s.swapId === req.params.id);
  if (!swap) return res.status(404).json({ error: 'Swap not found' });
  res.json(swap.risk);
});

// Get Swap Margin & Collateral
app.get('/v1/swaps/:id/margin', (req: Request, res: Response) => {
  const swap = swapsState.find((s) => s.swapId === req.params.id);
  if (!swap) return res.status(404).json({ error: 'Swap not found' });
  const marginResult = calculateSwapMargin(swap, swap.valuation.cleanPv);
  res.json(marginResult);
});

// Amend Swap
app.post('/v1/swaps/:id/amend', (req: Request, res: Response) => {
  const index = swapsState.findIndex((s) => s.swapId === req.params.id);
  if (index === -1) return res.status(404).json({ error: 'Swap not found' });

  const currentSwap = swapsState[index];
  const updates = req.body;

  const amendedSwap: CanonicalSwap = {
    ...currentSwap,
    ...updates,
    version: currentSwap.version + 1,
    contractStatus: 'AMENDED' as ContractStatus,
    updatedAt: new Date().toISOString(),
    lifecycleHistory: [
      ...currentSwap.lifecycleHistory,
      {
        eventId: `EVT-AMEND-${Date.now()}`,
        timestamp: new Date().toISOString(),
        eventType: 'AMENDMENT',
        description: `Swap terms amended (Version ${currentSwap.version + 1})`,
        performedBy: 'Rhino Desk Trader',
        previousVersion: currentSwap.version,
        newVersion: currentSwap.version + 1,
        hash: `0x${Math.random().toString(16).substring(2, 10)}`,
      },
    ],
  };

  const primaryCurve = yieldCurves[0];
  const priced = priceSwap(amendedSwap, primaryCurve);
  priced.swap.risk = calculateSwapRisk(priced.swap, primaryCurve);

  swapsState[index] = priced.swap;
  res.json({ message: 'Swap amended', swap: priced.swap });
});

// Terminate Swap
app.post('/v1/swaps/:id/terminate', (req: Request, res: Response) => {
  const index = swapsState.findIndex((s) => s.swapId === req.params.id);
  if (index === -1) return res.status(404).json({ error: 'Swap not found' });

  const currentSwap = swapsState[index];
  const closeOutAmount = currentSwap.valuation.cleanPv;

  const terminatedSwap: CanonicalSwap = {
    ...currentSwap,
    contractStatus: 'TERMINATED' as ContractStatus,
    updatedAt: new Date().toISOString(),
    lifecycleHistory: [
      ...currentSwap.lifecycleHistory,
      {
        eventId: `EVT-TERM-${Date.now()}`,
        timestamp: new Date().toISOString(),
        eventType: 'TERMINATION',
        description: `Early termination executed. Close-out settlement amount: £${closeOutAmount.toLocaleString()}`,
        performedBy: 'Rhino Head of Risk',
        hash: `0x${Math.random().toString(16).substring(2, 10)}`,
      },
    ],
  };

  swapsState[index] = terminatedSwap;
  res.json({ message: 'Swap terminated', closeOutAmount, swap: terminatedSwap });
});

// Get Yield Curves
app.get('/v1/curves', (req: Request, res: Response) => {
  res.json(yieldCurves);
});

// Shock Curve
app.post('/v1/curves/shock', (req: Request, res: Response) => {
  const { shiftBp, shockType } = req.body;
  const shockedCurve = applyCurveShock(yieldCurves[0], shockType || 'PARALLEL_BP', shiftBp || 25);
  yieldCurves[0] = shockedCurve;

  // Re-price all swaps with shocked curve
  swapsState = swapsState.map((swap) => {
    const priced = priceSwap(swap, shockedCurve);
    priced.swap.risk = calculateSwapRisk(priced.swap, shockedCurve);
    return priced.swap;
  });

  res.json({ message: `Curve shocked by ${shiftBp}bp`, curve: shockedCurve, updatedSwapsCount: swapsState.length });
});

// Portfolio Summary & Decomposition
app.get('/v1/portfolios', (req: Request, res: Response) => {
  let grossNotional = 0;
  let totalPv = 0;
  let totalDv01 = 0;
  let totalCs01 = 0;

  swapsState.forEach((s) => {
    grossNotional += s.notional;
    totalPv += s.valuation.cleanPv;
    totalDv01 += s.risk.dv01;
    if (s.risk.cs01) totalCs01 += s.risk.cs01;
  });

  const nettingExposures = nettingSets.map((ns) => calculateNettingSetExposure(ns.nettingSetId, ns.counterparty, swapsState, ns.collateralPosted));

  res.json({
    grossNotional,
    totalPv: Math.round(totalPv),
    totalDv01: Math.round(totalDv01),
    totalCs01: Math.round(totalCs01),
    swapsCount: swapsState.length,
    nettingExposures,
  });
});

// Compression Engine Endpoint
app.get('/v1/compression/opportunities', (req: Request, res: Response) => {
  const opps = identifyCompressionOpportunities(swapsState);
  res.json({ opportunitiesCount: opps.length, opportunities: opps });
});

// Scenario Lab Endpoint
app.post('/v1/scenarios/run', (req: Request, res: Response) => {
  const { scenario, swapId } = req.body;
  const primaryCurve = yieldCurves[0];

  if (swapId) {
    const swap = swapsState.find((s) => s.swapId === swapId);
    if (!swap) return res.status(404).json({ error: 'Swap not found' });
    const result = runScenario(swap, primaryCurve, scenario);
    return res.json(result);
  }

  // Run across all swaps in portfolio
  const results = swapsState.map((s) => runScenario(s, primaryCurve, scenario));
  res.json({ scenarioName: scenario.name, results });
});

// Monte Carlo Endpoint
app.post('/v1/scenarios/monte-carlo', (req: Request, res: Response) => {
  const { swapId, numPaths, seed } = req.body;
  const swap = swapsState.find((s) => s.swapId === swapId) || swapsState[0];
  const primaryCurve = yieldCurves[0];

  const mcResult = runMonteCarlo(swap, primaryCurve, numPaths || 2000, seed || 42);
  res.json(mcResult);
});

// AI Quant Assistant Query
app.post('/v1/ai/query', async (req: Request, res: Response) => {
  try {
    const { prompt } = req.body;

    const portfolioContext = {
      activeSwapsCount: swapsState.length,
      grossNotional: swapsState.reduce((acc, s) => acc + s.notional, 0),
      totalPv: swapsState.reduce((acc, s) => acc + s.valuation.cleanPv, 0),
      totalDv01: swapsState.reduce((acc, s) => acc + s.risk.dv01, 0),
      swapsSummary: swapsState.map((s) => ({
        id: s.swapId,
        family: s.swapFamily,
        type: s.productType,
        counterparty: s.counterpartyB,
        notional: s.notional,
        pv: s.valuation.cleanPv,
        dv01: s.risk.dv01,
      })),
      curveRateSONIA5Y: yieldCurves[0].points.find((p) => p.tenor === '5Y')?.parRate,
    };

    const systemInstruction = `You are RHINOQUANT SWAP INTELLIGENCE, an elite quantitative derivatives specialist at a top-tier London investment bank.
Answer questions grounded strictly in the provided live portfolio data.
You MUST tag every key claim or metric using one of these strict labels in bracketed uppercase:
- [OBSERVED]: For factual current state or trade facts.
- [CALCULATED]: For exact arithmetic outputs derived from data.
- [MODEL OUTPUT]: For model valuations or pricing outputs.
- [SCENARIO]: For simulated shock outputs or hypotheticals.
- [ASSUMPTION]: For theoretical parameters or market assumptions.

Be concise, precise, quantitative, and professional. Avoid filler, marketing jargon, or conversational text.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `Portfolio Data Context: ${JSON.stringify(portfolioContext)}\n\nUser Question: ${prompt}`,
      config: {
        systemInstruction,
        temperature: 0.2,
      },
    });

    res.json({ answer: response.text || 'Unable to generate response.' });
  } catch (error: any) {
    console.error('AI Assistant Error:', error);
    res.status(500).json({ error: error.message || 'Error processing AI query' });
  }
});

// Mount Vite middleware in development
if (process.env.NODE_ENV !== 'production') {
  const { createServer: createViteServer } = await import('vite');
  const vite = await createViteServer({
    server: { middlewareMode: true },
    appType: 'custom',
  });
  app.use(vite.middlewares);
  app.use('*', async (req, res, next) => {
    try {
      const url = req.originalUrl;
      let template = (await import('fs')).readFileSync(path.resolve(__dirname, 'index.html'), 'utf-8');
      template = await vite.transformIndexHtml(url, template);
      res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
    } catch (e) {
      vite.ssrFixStacktrace(e as Error);
      next(e);
    }
  });
} else {
  // Production static file serving
  app.use(express.static(path.resolve(__dirname, 'dist')));
  app.get('*', (req, res) => {
    res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
  });
}

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`[RhinoQuant Server] Running on http://localhost:${PORT}`);
});
