import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
const angularApp = new AngularNodeAppEngine();

app.use(express.json());

/**
 * REST API v1 Endpoints for Aire Cement Systems Ltd Digital Twin
 */
app.get('/api/v1/plant/status', (req, res) => {
  res.json({
    facility: 'Aire Cement Works',
    location: 'Bradford, West Yorkshire, UK',
    operator: 'AIRE CEMENT SYSTEMS LTD.',
    kilnStatus: 'RUNNING',
    clinkerProductionTph: 114.0,
    thermalSpecificGjT: 3.12,
    electricalSpecificKwhT: 88.5,
    co2IntensityKgT: 685,
    timestamp: new Date().toISOString()
  });
});

app.get('/api/v1/assets', (req, res) => {
  res.json([
    { id: 'QUARRY-01', name: 'Quarry Primary Jaw Crusher', status: 'NORMAL', healthScore: 94 },
    { id: 'RMILL-01', name: 'Raw Mill VRM System', status: 'NORMAL', healthScore: 91 },
    { id: 'PREHEATER-01', name: '5-Stage Preheater Tower', status: 'NORMAL', healthScore: 88 },
    { id: 'KILN-01', name: 'Rotary Kiln Main Drive', status: 'NORMAL', healthScore: 86 },
    { id: 'COOLER-01', name: 'Clinker Cooler Grate Drive', status: 'NORMAL', healthScore: 82 },
    { id: 'CMILL-01', name: 'Cement Mill 1 VRM', status: 'NORMAL', healthScore: 92 },
    { id: 'CMILL-02', name: 'Cement Mill 2 Ball Mill', status: 'DEGRADED', healthScore: 68, vibrationMmS: 6.85 }
  ]);
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
