import { Injectable, signal, computed } from '@angular/core';
import {
  ChemicalComposition,
  CementRatios,
  ClinkerPhases,
  RawMillState,
  PreheaterStage,
  PrecalcinerState,
  RotaryKilnState,
  ClinkerCoolerState,
  CementMillState,
  CementProduct,
  QualitySample,
  EnergyMetrics,
  EmissionsMetrics,
  PlantAsset,
  AlarmItem,
  TimelineEvent
} from '../models/cement-process.models';

@Injectable({
  providedIn: 'root'
})
export class CementTwinService {
  // --- Simulation Control Signals ---
  readonly isSimulating = signal<boolean>(true);
  readonly simSpeedMultiplier = signal<number>(1); // 1x, 10x, 100x, 1000x
  readonly currentTimestamp = signal<Date>(new Date('2026-09-30T06:00:00'));
  readonly activeViewMode = signal<'3D' | 'PID' | 'PYROPROCESS' | 'LAB' | 'ENERGY' | 'ASSETS' | 'SCENARIOS' | 'HISTORIAN' | 'CONTROL_ROOM'>('3D');
  readonly selectedAssetId = signal<string | null>('KILN-01');

  // --- Sensor Noise / Anomaly Controls ---
  readonly sensorNoiseEnabled = signal<boolean>(true);
  readonly injectedFault = signal<'NONE' | 'RAW_MOISTURE_SPIKE' | 'MILL2_VIBRATION' | 'COOLER_AIR_DROP' | 'KILN_HOTSPOT'>('NONE');

  // --- Core Chemistry State Signals ---
  readonly limestoneComposition = signal<ChemicalComposition>({
    CaO: 51.8, SiO2: 2.9, Al2O3: 0.8, Fe2O3: 0.4, MgO: 1.1, SO3: 0.2, K2O: 0.1, Na2O: 0.05, Cl: 0.01, LOI: 41.5, moisture: 3.2
  });

  readonly clayShaleComposition = signal<ChemicalComposition>({
    CaO: 3.2, SiO2: 58.4, Al2O3: 18.2, Fe2O3: 6.8, MgO: 2.1, SO3: 0.5, K2O: 2.4, Na2O: 0.8, Cl: 0.02, LOI: 6.5, moisture: 6.8
  });

  readonly ironOreComposition = signal<ChemicalComposition>({
    CaO: 2.1, SiO2: 12.0, Al2O3: 4.5, Fe2O3: 72.0, MgO: 1.2, SO3: 0.1, K2O: 0.2, Na2O: 0.1, Cl: 0.0, LOI: 6.5, moisture: 4.0
  });

  // Raw Mix Recipe (Proportions %)
  readonly rawMixProportions = signal<{ limestone: number; clayShale: number; ironOre: number }>({
    limestone: 80.5,
    clayShale: 18.0,
    ironOre: 1.5
  });

  // Derived Raw Meal Chemistry
  readonly rawMealComposition = computed<ChemicalComposition>(() => {
    const props = this.rawMixProportions();
    const ls = this.limestoneComposition();
    const cs = this.clayShaleComposition();
    const io = this.ironOreComposition();

    const wLs = props.limestone / 100;
    const wCs = props.clayShale / 100;
    const wIo = props.ironOre / 100;

    const calcField = (field: keyof ChemicalComposition) =>
      Number((ls[field] * wLs + cs[field] * wCs + io[field] * wIo).toFixed(2));

    return {
      CaO: calcField('CaO'),
      SiO2: calcField('SiO2'),
      Al2O3: calcField('Al2O3'),
      Fe2O3: calcField('Fe2O3'),
      MgO: calcField('MgO'),
      SO3: calcField('SO3'),
      K2O: calcField('K2O'),
      Na2O: calcField('Na2O'),
      Cl: calcField('Cl'),
      LOI: calcField('LOI'),
      moisture: calcField('moisture')
    };
  });

  // Derived Cement Ratios (LSF, SM, AM)
  readonly rawMealRatios = computed<CementRatios>(() => {
    const rm = this.rawMealComposition();
    // LSF = CaO / (2.8*SiO2 + 1.2*Al2O3 + 0.65*Fe2O3) * 100
    const denomLSF = 2.8 * rm.SiO2 + 1.2 * rm.Al2O3 + 0.65 * rm.Fe2O3;
    const LSF = denomLSF > 0 ? (rm.CaO / denomLSF) * 100 : 0;

    const denomSM = rm.Al2O3 + rm.Fe2O3;
    const SM = denomSM > 0 ? rm.SiO2 / denomSM : 0;

    const AM = rm.Fe2O3 > 0 ? rm.Al2O3 / rm.Fe2O3 : 0;

    return {
      LSF: Number(LSF.toFixed(1)),
      SM: Number(SM.toFixed(2)),
      AM: Number(AM.toFixed(2))
    };
  });

  // Predicted Clinker Composition & Bogue Phases
  readonly clinkerPhases = computed<ClinkerPhases>(() => {
    const rm = this.rawMealComposition();
    // LOI loss factor during calcination
    const factor = 100 / (100 - rm.LOI);
    const cao = rm.CaO * factor;
    const sio2 = rm.SiO2 * factor;
    const al2o3 = rm.Al2O3 * factor;
    const fe2o3 = rm.Fe2O3 * factor;
    const so3 = rm.SO3 * factor;

    // Bogue Equations
    const c3s = 4.071 * cao - 7.600 * sio2 - 6.718 * al2o3 - 1.430 * fe2o3 - 2.852 * so3;
    const c2s = 2.867 * sio2 - 0.7544 * c3s;
    const c3a = 2.650 * al2o3 - 1.692 * fe2o3;
    const c4af = 3.043 * fe2o3;
    const freeLime = Math.max(0.4, Number((1.2 - (c3s / 100) * 0.5).toFixed(2)));

    return {
      C3S: Math.max(0, Number(c3s.toFixed(1))),
      C2S: Math.max(0, Number(c2s.toFixed(1))),
      C3A: Math.max(0, Number(c3a.toFixed(1))),
      C4AF: Math.max(0, Number(c4af.toFixed(1))),
      freeLime
    };
  });

  // --- Process Equipment Signals ---
  readonly rawMillState = signal<RawMillState>({
    id: 'RMILL-01',
    name: 'Raw Mill 1 (Vertical Roller Mill)',
    feedRateTph: 195.0,
    moistureInPercent: 3.8,
    grindingPressureBar: 115.0,
    differentialPressureMbar: 34.5,
    motorPowerKw: 3120,
    specificEnergyKwhT: 16.0,
    separatorSpeedRpm: 840,
    airFlowM3h: 285000,
    outletTempC: 88,
    productFinenessR90Micron: 11.2,
    vibrationMmS: 2.1,
    circulatingLoadPercent: 180,
    status: 'RUNNING'
  });

  readonly preheaterStages = signal<PreheaterStage[]>([
    { stageNumber: 1, gasTempC: 325, solidsTempC: 280, pressureMbar: -42.0, cycloneEfficiencyPercent: 96.2 },
    { stageNumber: 2, gasTempC: 485, solidsTempC: 420, pressureMbar: -31.5, cycloneEfficiencyPercent: 95.8 },
    { stageNumber: 3, gasTempC: 640, solidsTempC: 580, pressureMbar: -22.0, cycloneEfficiencyPercent: 95.1 },
    { stageNumber: 4, gasTempC: 785, solidsTempC: 720, pressureMbar: -14.5, cycloneEfficiencyPercent: 94.8 },
    { stageNumber: 5, gasTempC: 890, solidsTempC: 845, pressureMbar: -8.0, cycloneEfficiencyPercent: 94.0 }
  ]);

  readonly precalcinerState = signal<PrecalcinerState>({
    fuelInputTph: 4.8,
    alternativeFuelPercent: 35.0,
    combustionTempC: 960,
    calcinationDegreePercent: 91.5,
    co2FlowTph: 58.4,
    o2Percent: 2.4
  });

  readonly rotaryKilnState = signal<RotaryKilnState>({
    id: 'KILN-01',
    name: 'Rotary Kiln 1 (68m x 4.4m)',
    feedRateTph: 182.4,
    rotationSpeedRpm: 3.4,
    inclinationDegree: 3.5,
    secondaryAirTempC: 1015,
    tertiaryAirTempC: 865,
    burningZoneTempC: 1438,
    flameTempC: 1850,
    primaryFuelTph: 7.8,
    alternativeFuelTph: 2.4,
    fillingDegreePercent: 12.2,
    residenceTimeMin: 24.5,
    clinkerProductionTph: 114.0,
    drivePowerKw: 480,
    shellMaxTempC: 287,
    o2Percent: 3.1,
    co2Percent: 22.4,
    noxPpm: 420,
    thermalConsumptionGjT: 3.12,
    zones: [
      { name: 'Inlet Zone', startMeter: 0, endMeter: 10, gasTempC: 1050, materialTempC: 880, shellTempC: 210, coatingThicknessMm: 10 },
      { name: 'Calcination Extension', startMeter: 10, endMeter: 24, gasTempC: 1180, materialTempC: 1020, shellTempC: 245, coatingThicknessMm: 25 },
      { name: 'Transition Zone', startMeter: 24, endMeter: 42, gasTempC: 1320, materialTempC: 1210, shellTempC: 260, coatingThicknessMm: 120 },
      { name: 'Burning Zone', startMeter: 42, endMeter: 58, gasTempC: 1850, materialTempC: 1438, shellTempC: 287, coatingThicknessMm: 210 },
      { name: 'Cooling Discharge Zone', startMeter: 58, endMeter: 68, gasTempC: 1250, materialTempC: 1280, shellTempC: 230, coatingThicknessMm: 45 }
    ],
    status: 'RUNNING'
  });

  readonly clinkerCoolerState = signal<ClinkerCoolerState>({
    id: 'COOLER-01',
    name: 'Clinker Cooler (Grate Cooler)',
    grateSpeedSpm: 18.5,
    coolingAirM3h: 185000,
    clinkerInTempC: 1280,
    clinkerOutTempC: 88,
    secondaryAirTempC: 1015,
    tertiaryAirTempC: 865,
    heatRecoveredGjH: 142.5,
    coolingEfficiencyPercent: 74.8
  });

  readonly cementMill1State = signal<CementMillState>({
    id: 'CMILL-01',
    name: 'Cement Mill 1 (Vertical Roller Mill)',
    millType: 'VERTICAL_ROLLER_MILL',
    clinkerFeedTph: 85.0,
    gypsumFeedTph: 4.5,
    scmFeedTph: 10.5,
    additiveFeedTph: 0.5,
    totalFeedTph: 100.5,
    motorPowerKw: 3850,
    specificEnergyKwhT: 38.3,
    separatorSpeedRpm: 920,
    productBlaineCm2G: 3850,
    outletTempC: 92,
    vibrationMmS: 2.4,
    circulatingLoadPercent: 145,
    status: 'RUNNING'
  });

  readonly cementMill2State = signal<CementMillState>({
    id: 'CMILL-02',
    name: 'Cement Mill 2 (Ball Mill with High-Efficiency Separator)',
    millType: 'BALL_MILL',
    clinkerFeedTph: 68.0,
    gypsumFeedTph: 3.8,
    scmFeedTph: 8.2,
    additiveFeedTph: 0.4,
    totalFeedTph: 80.4,
    motorPowerKw: 3400,
    specificEnergyKwhT: 42.2,
    separatorSpeedRpm: 880,
    productBlaineCm2G: 3920,
    outletTempC: 108,
    vibrationMmS: 4.8, // Normal baseline, rises during simulation event
    circulatingLoadPercent: 210,
    status: 'RUNNING'
  });

  // Products
  readonly cementProducts = signal<CementProduct[]>([
    {
      id: 'PROD-01',
      code: 'Aire CEM I 52.5N',
      name: 'Aire CEM I High Strength Portland',
      description: 'Pure Portland cement for rapid strength development & civil structures.',
      clinkerPercent: 95.0,
      gypsumPercent: 5.0,
      scmType: 'NONE',
      scmPercent: 0,
      targetBlaineCm2G: 4200,
      target28DayStrengthMpa: 58.5,
      embodiedCarbonKgCo2T: 785,
      unitCostGbpT: 88.50
    },
    {
      id: 'PROD-02',
      code: 'Aire CEM II/A-LL 42.5R',
      name: 'Aire CEM II Limestone Portland',
      description: 'General purpose low-carbon building cement with 12% limestone filler.',
      clinkerPercent: 83.0,
      gypsumPercent: 5.0,
      scmType: 'LIMESTONE',
      scmPercent: 12.0,
      targetBlaineCm2G: 3850,
      target28DayStrengthMpa: 48.0,
      embodiedCarbonKgCo2T: 680,
      unitCostGbpT: 79.00
    },
    {
      id: 'PROD-03',
      code: 'Aire CEM III/A 42.5N',
      name: 'Aire Eco-Cement (GGBS Slag)',
      description: 'Ultra-low carbon cement containing 50% Ground Granulated Blast-furnace Slag.',
      clinkerPercent: 46.0,
      gypsumPercent: 4.0,
      scmType: 'SLAG',
      scmPercent: 50.0,
      targetBlaineCm2G: 4500,
      target28DayStrengthMpa: 46.5,
      embodiedCarbonKgCo2T: 395,
      unitCostGbpT: 74.20
    }
  ]);

  // Assets Hierarchy
  readonly assetsList = signal<PlantAsset[]>([
    {
      id: 'QUARRY-01',
      name: 'Quarry Primary Jaw Crusher',
      category: 'QUARRY',
      manufacturer: 'Metso Outotec',
      model: 'C160 Jaw Crusher',
      commissioningYear: 2018,
      ratedCapacityTph: 450,
      operatingHours: 28400,
      vibrationMmS: 2.8,
      bearingTempC: 54,
      motorCurrentAmps: 310,
      condition: 'NORMAL',
      healthScorePercent: 94,
      lastMaintenanceDate: '2026-08-12',
      nextScheduledMaintenance: '2026-11-15'
    },
    {
      id: 'RMILL-01',
      name: 'Raw Mill VRM System',
      category: 'RAW_MILL',
      manufacturer: 'Loesche',
      model: 'LM 56.4',
      commissioningYear: 2020,
      ratedCapacityTph: 220,
      operatingHours: 21500,
      vibrationMmS: 2.1,
      bearingTempC: 62,
      motorCurrentAmps: 340,
      condition: 'NORMAL',
      healthScorePercent: 91,
      lastMaintenanceDate: '2026-07-20',
      nextScheduledMaintenance: '2026-10-25'
    },
    {
      id: 'PREHEATER-01',
      name: '5-Stage Suspension Preheater & Calciner',
      category: 'PYROPROCESS',
      manufacturer: 'FLSmidth',
      model: 'ILC 5-Stage',
      commissioningYear: 2019,
      ratedCapacityTph: 200,
      operatingHours: 26100,
      vibrationMmS: 1.2,
      bearingTempC: 45,
      motorCurrentAmps: 180,
      condition: 'NORMAL',
      healthScorePercent: 88,
      lastMaintenanceDate: '2026-06-10',
      nextScheduledMaintenance: '2026-12-01'
    },
    {
      id: 'KILN-01',
      name: 'Rotary Kiln Main Drive & Shell',
      category: 'PYROPROCESS',
      manufacturer: 'Polysius / Thyssenkrupp',
      model: '3-Pier Rotary Kiln',
      commissioningYear: 2019,
      ratedCapacityTph: 125,
      operatingHours: 27900,
      vibrationMmS: 2.4,
      bearingTempC: 68,
      motorCurrentAmps: 420,
      condition: 'NORMAL',
      healthScorePercent: 86,
      lastMaintenanceDate: '2026-05-18',
      nextScheduledMaintenance: '2026-11-20'
    },
    {
      id: 'COOLER-01',
      name: 'Clinker Cooler Grate Drive',
      category: 'COOLER',
      manufacturer: 'IKN',
      model: 'Pendulum Cooler',
      commissioningYear: 2019,
      ratedCapacityTph: 125,
      operatingHours: 27200,
      vibrationMmS: 3.1,
      bearingTempC: 72,
      motorCurrentAmps: 145,
      condition: 'NORMAL',
      healthScorePercent: 82,
      lastMaintenanceDate: '2026-04-30',
      nextScheduledMaintenance: '2026-10-15'
    },
    {
      id: 'CMILL-01',
      name: 'Cement Mill 1 VRM',
      category: 'CEMENT_MILL',
      manufacturer: 'Pfeiffer',
      model: 'MPS 4500 C',
      commissioningYear: 2021,
      ratedCapacityTph: 110,
      operatingHours: 18300,
      vibrationMmS: 2.4,
      bearingTempC: 58,
      motorCurrentAmps: 390,
      condition: 'NORMAL',
      healthScorePercent: 92,
      lastMaintenanceDate: '2026-08-01',
      nextScheduledMaintenance: '2026-11-01'
    },
    {
      id: 'CMILL-02',
      name: 'Cement Mill 2 Ball Mill Drive & Gearbox',
      category: 'CEMENT_MILL',
      manufacturer: 'FLSmidth',
      model: 'Unidan 4.6 x 14.0m',
      commissioningYear: 2015,
      ratedCapacityTph: 85,
      operatingHours: 42100,
      vibrationMmS: 4.8,
      bearingTempC: 79,
      motorCurrentAmps: 360,
      condition: 'DEGRADED',
      healthScorePercent: 68,
      lastMaintenanceDate: '2026-03-10',
      nextScheduledMaintenance: '2026-10-05',
      activeWorkOrder: 'WO-2026-0894'
    }
  ]);

  // Active Alarms list
  readonly activeAlarms = signal<AlarmItem[]>([
    {
      alarmId: 'ALM-8041',
      timestamp: '08:45:12',
      assetId: 'CMILL-02',
      assetName: 'Cement Mill 2 Ball Mill',
      variable: 'Drive Pinion Vibration',
      currentValue: 6.85,
      unit: 'mm/s',
      threshold: 6.0,
      severity: 'HIGH',
      causeDiagnostic: 'Trunnion bearing roller pitting & gear coupling misalignment',
      acknowledged: false
    },
    {
      alarmId: 'ALM-8038',
      timestamp: '08:20:05',
      assetId: 'COOLER-01',
      assetName: 'Clinker Cooler',
      variable: 'Secondary Air Temperature Drop',
      currentValue: 978,
      unit: '°C',
      threshold: 1000,
      severity: 'ADVISORY',
      causeDiagnostic: 'Grate clinker bed channeling causing secondary heat exchange loss',
      acknowledged: true,
      acknowledgedBy: 'J. Hargreaves (Shift Supervisor)'
    }
  ]);

  // Quality Samples
  readonly qualitySamples = signal<QualitySample[]>([
    {
      sampleId: 'SMP-20260930-01',
      materialName: 'Raw Meal Composite',
      sourceLocation: 'Raw Meal Silo 2 Outlet',
      timestamp: '2026-09-30 06:15',
      operator: 'D. Firth (Lab Tech)',
      composition: { CaO: 42.1, SiO2: 13.8, Al2O3: 3.4, Fe2O3: 2.1, MgO: 1.4, SO3: 0.4, K2O: 0.6, Na2O: 0.2, Cl: 0.01, LOI: 35.8, moisture: 0.3 },
      ratios: { LSF: 97.8, SM: 2.51, AM: 1.62 },
      status: 'APPROVED',
      provenance: 'MEASURED'
    },
    {
      sampleId: 'SMP-20260930-02',
      materialName: 'Clinker Hot Sample',
      sourceLocation: 'Cooler Discharge Conveyor',
      timestamp: '2026-09-30 08:00',
      operator: 'D. Firth (Lab Tech)',
      composition: { CaO: 65.2, SiO2: 21.4, Al2O3: 5.3, Fe2O3: 3.2, MgO: 2.1, SO3: 0.6, K2O: 0.9, Na2O: 0.3, Cl: 0.01, LOI: 0.4, moisture: 0.0 },
      phases: { C3S: 62.4, C2S: 15.1, C3A: 8.6, C4AF: 9.7, freeLime: 0.8 },
      status: 'APPROVED',
      provenance: 'MEASURED'
    }
  ]);

  // Demo Timeline Events ("BRADFORD MORNING PRODUCTION")
  readonly demoEvents = signal<TimelineEvent[]>([
    {
      timeStr: '06:00',
      timestampMs: new Date('2026-09-30T06:00:00').getTime(),
      headline: 'Bradford Works Shift Handover & Nominal Startup',
      description: 'Morning shift begins. Kiln 1 running at 182.4 t/h feed. Raw Mill 1 operating smoothly.',
      affectedAssetId: 'KILN-01',
      type: 'OPERATIONAL'
    },
    {
      timeStr: '06:30',
      headline: 'Quarry Raw Limestone Moisture Elevation',
      description: 'Inbound raw limestone moisture increases from 3.2% to 5.4% following rainfall in the quarry stockpile.',
      affectedAssetId: 'RMILL-01',
      type: 'PROCESS_CHANGE',
      parameterDiffs: { 'Moisture In': '3.2% → 5.4%', 'Drying Air Demand': '+18%' }
    },
    {
      timeStr: '07:00',
      headline: 'Raw Mill Thermal Energy Increase',
      description: 'Raw mill mill fan consumes more hot kiln gas for drying. Specific energy rises from 16.0 to 18.2 kWh/t.',
      affectedAssetId: 'RMILL-01',
      type: 'PROCESS_CHANGE',
      parameterDiffs: { 'Specific Energy': '16.0 → 18.2 kWh/t', 'Differential Pressure': '34.5 → 38.2 mbar' }
    },
    {
      timeStr: '07:30',
      headline: 'Pyroprocess Production Ramp (+5% Kiln Feed)',
      description: 'Control room increases kiln feed to 191.5 t/h to meet high weekend dispatch demand for CEM II.',
      affectedAssetId: 'KILN-01',
      type: 'OPERATIONAL',
      parameterDiffs: { 'Kiln Feed': '182.4 → 191.5 t/h', 'Petcoke Fuel': '7.8 → 8.2 t/h' }
    },
    {
      timeStr: '08:00',
      headline: 'Clinker Production Rises to 119.5 t/h',
      description: 'Burning zone temperature stabilizes at 1442°C. Calciner calcination degree at 92.1%.',
      affectedAssetId: 'KILN-01',
      type: 'OPERATIONAL'
    },
    {
      timeStr: '08:20',
      headline: 'Clinker Cooler Efficiency Drop',
      description: 'Clinker bed channeling causes cooler heat recovery to fall. Secondary air temperature drops from 1015°C to 978°C.',
      affectedAssetId: 'COOLER-01',
      type: 'DEGRADATION',
      parameterDiffs: { 'Cooler Efficiency': '74.8% → 69.2%', 'Secondary Air': '1015°C → 978°C' }
    },
    {
      timeStr: '08:45',
      headline: 'Cement Mill 2 Drive Vibration Warning',
      description: 'Ball Mill 2 drive pinion vibration spikes to 6.85 mm/s (Threshold: 6.0 mm/s). Alarm ALM-8041 raised.',
      affectedAssetId: 'CMILL-02',
      type: 'DEGRADATION',
      parameterDiffs: { 'Vibration': '4.8 → 6.85 mm/s', 'Bearing Temp': '79°C → 86°C' }
    },
    {
      timeStr: '09:15',
      headline: 'Virtual Predictive Maintenance Scenario Executed',
      description: 'Reliability Engineer runs What-If Scenario to evaluate reducing Ball Mill load vs immediate trip vs delayed maintenance.',
      affectedAssetId: 'CMILL-02',
      type: 'DECISION'
    },
    {
      timeStr: '09:30',
      headline: 'Scenario Comparison & Load Derating Strategy',
      description: 'Mill 2 feed derated by 20% (80.4 → 64.3 t/h) to suppress vibration while scheduling maintenance for 14:00.',
      affectedAssetId: 'CMILL-02',
      type: 'MAINTENANCE'
    },
    {
      timeStr: '10:00',
      headline: 'Bradford Morning Executive Review Complete',
      description: 'Plant Manager reviews energy, CO2 intensity (678 kg/t cement), quality compliance, and maintenance work order WO-2026-0894.',
      affectedAssetId: 'KILN-01',
      type: 'OPERATIONAL'
    }
  ]);

  // Derived Energy Metrics
  readonly energyMetrics = computed<EnergyMetrics>(() => {
    const rmill = this.rawMillState();
    const kiln = this.rotaryKilnState();
    const cm1 = this.cementMill1State();
    const cm2 = this.cementMill2State();

    const totalElec = rmill.motorPowerKw + kiln.drivePowerKw + cm1.motorPowerKw + cm2.motorPowerKw + 2450; // auxiliaries
    const totalCementTph = cm1.totalFeedTph + cm2.totalFeedTph;

    const specificKwhT = totalCementTph > 0 ? totalElec / totalCementTph : 88.5;

    return {
      totalElectricityKw: Math.round(totalElec),
      specificElectricityKwhTCement: Number(specificKwhT.toFixed(1)),
      thermalConsumptionGjTClinker: kiln.thermalConsumptionGjT,
      alternativeFuelThermalSubPercent: Number(((kiln.alternativeFuelTph * 24) / (kiln.primaryFuelTph * 32 + kiln.alternativeFuelTph * 24) * 100).toFixed(1)),
      gridPowerImportKw: Math.round(totalElec - 1200), // 1.2MW Waste Heat Recovery
      wasteHeatRecoveryKw: 1200
    };
  });

  // Derived Emissions Metrics
  readonly emissionsMetrics = computed<EmissionsMetrics>(() => {
    const kiln = this.rotaryKilnState();
    const totalCementTph = this.cementMill1State().totalFeedTph + this.cementMill2State().totalFeedTph;

    // Process CO2 from limestone calcination (CaCO3 -> CaO + CO2 ~ 0.525 t CO2 / t clinker)
    const processCo2Tph = kiln.clinkerProductionTph * 0.525;

    // Fuel CO2 from combustion (Petcoke ~ 3.1 tCO2/t, Alt fuel ~ 1.2 tCO2/t)
    const fuelCo2Tph = kiln.primaryFuelTph * 3.1 + kiln.alternativeFuelTph * 1.2;

    // Scope 2 Electricity CO2 (UK Grid factor ~0.21 kg CO2/kWh)
    const elecKw = this.energyMetrics().totalElectricityKw;
    const scope2Co2Tph = (elecKw * 0.21) / 1000;

    const totalScope1And2 = processCo2Tph + fuelCo2Tph + scope2Co2Tph;
    const specificCo2Clinker = kiln.clinkerProductionTph > 0 ? (totalScope1And2 * 1000) / kiln.clinkerProductionTph : 810;
    const specificCo2Cement = totalCementTph > 0 ? (totalScope1And2 * 1000) / totalCementTph : 685;

    return {
      processCo2Tph: Number(processCo2Tph.toFixed(2)),
      fuelCo2Tph: Number(fuelCo2Tph.toFixed(2)),
      electricityScope2Co2Tph: Number(scope2Co2Tph.toFixed(2)),
      totalScope1And2Co2Tph: Number(totalScope1And2.toFixed(2)),
      specificEmissionsKgCo2TClinker: Math.round(specificCo2Clinker),
      specificEmissionsKgCo2TCement: Math.round(specificCo2Cement),
      annualCo2TonneEstimate: Math.round(totalScope1And2 * 24 * 330) // 330 operating days
    };
  });

  // Historian Time Series Buffer
  readonly historianData = signal<{
    timestamp: string;
    kilnFeedTph: number;
    burningZoneTempC: number;
    mill2VibrationMmS: number;
    specificKwhT: number;
    co2Tph: number;
  }[]>([]);

  constructor() {
    this.initHistorianBuffer();
    this.startSimulationLoop();
  }

  private initHistorianBuffer() {
    const initial: {
      timestamp: string;
      kilnFeedTph: number;
      burningZoneTempC: number;
      mill2VibrationMmS: number;
      specificKwhT: number;
      co2Tph: number;
    }[] = [];

    const baseTime = new Date('2026-09-30T05:00:00');
    for (let i = 0; i < 60; i++) {
      const t = new Date(baseTime.getTime() + i * 60000);
      const timeStr = t.toTimeString().substring(0, 5);
      initial.push({
        timestamp: timeStr,
        kilnFeedTph: 182 + Math.sin(i / 5) * 2,
        burningZoneTempC: 1435 + Math.cos(i / 4) * 4,
        mill2VibrationMmS: 4.5 + (i > 45 ? (i - 45) * 0.12 : Math.random() * 0.2),
        specificKwhT: 87 + Math.sin(i / 10) * 1.5,
        co2Tph: 118 + Math.cos(i / 8) * 3
      });
    }
    this.historianData.set(initial);
  }

  private startSimulationLoop() {
    setInterval(() => {
      if (!this.isSimulating()) return;

      const speed = this.simSpeedMultiplier();
      const current = this.currentTimestamp();
      const nextTime = new Date(current.getTime() + 1000 * speed);
      this.currentTimestamp.set(nextTime);

      // Process micro-fluctuations & sensor noise
      this.tickPhysicsEngine();
    }, 1000);
  }

  private tickPhysicsEngine() {
    const hasNoise = this.sensorNoiseEnabled();
    const noise = (scale: number) => (hasNoise ? (Math.random() - 0.5) * scale : 0);

    // Update Kiln
    this.rotaryKilnState.update(k => ({
      ...k,
      burningZoneTempC: Math.min(1520, Math.max(1380, Math.round(k.burningZoneTempC + noise(1.5)))),
      shellMaxTempC: Math.round(285 + noise(3)),
      drivePowerKw: Math.round(480 + noise(10))
    }));

    // Update CM2 Vibration
    this.cementMill2State.update(m => {
      const isEventActive = this.currentTimestamp().getHours() >= 8 && this.currentTimestamp().getMinutes() >= 45;
      const targetVib = isEventActive ? 6.85 : 4.8;
      const currentVib = m.vibrationMmS;
      const nextVib = Number((currentVib + (targetVib - currentVib) * 0.05 + noise(0.08)).toFixed(2));
      return {
        ...m,
        vibrationMmS: nextVib
      };
    });

    // Append to Historian every 10 seconds
    const timeStr = this.currentTimestamp().toTimeString().substring(0, 5);
    const data = this.historianData();
    if (data.length === 0 || data[data.length - 1].timestamp !== timeStr) {
      const newPoint = {
        timestamp: timeStr,
        kilnFeedTph: Number(this.rotaryKilnState().feedRateTph.toFixed(1)),
        burningZoneTempC: this.rotaryKilnState().burningZoneTempC,
        mill2VibrationMmS: this.cementMill2State().vibrationMmS,
        specificKwhT: this.energyMetrics().specificElectricityKwhTCement,
        co2Tph: this.emissionsMetrics().totalScope1And2Co2Tph
      };
      this.historianData.set([...data.slice(-120), newPoint]); // Keep last 120 points
    }
  }

  // Parameter Setters
  setSimSpeed(multiplier: number) {
    this.simSpeedMultiplier.set(multiplier);
  }

  toggleSimulation() {
    this.isSimulating.update(v => !v);
  }

  setKilnFeedRate(tph: number) {
    this.rotaryKilnState.update(k => ({
      ...k,
      feedRateTph: tph,
      clinkerProductionTph: Number((tph * 0.625).toFixed(1))
    }));
  }

  setRawMixProportions(props: { limestone: number; clayShale: number; ironOre: number }) {
    this.rawMixProportions.set(props);
  }

  setAlternativeFuelPercent(percent: number) {
    this.precalcinerState.update(p => ({
      ...p,
      alternativeFuelPercent: percent
    }));
    this.rotaryKilnState.update(k => {
      const altTph = Number(((percent / 100) * 6.5).toFixed(1));
      const primTph = Number((8.5 - altTph * 0.8).toFixed(1));
      return {
        ...k,
        alternativeFuelTph: altTph,
        primaryFuelTph: primTph
      };
    });
  }

  acknowledgeAlarm(alarmId: string, operatorName: string) {
    this.activeAlarms.update(alarms =>
      alarms.map(a => a.alarmId === alarmId ? { ...a, acknowledged: true, acknowledgedBy: `${operatorName} (${new Date().toLocaleTimeString()})` } : a)
    );
  }

  seekTimeMachine(timeStr: string) {
    const today = '2026-09-30T';
    const target = new Date(`${today}${timeStr}:00`);
    if (!isNaN(target.getTime())) {
      this.currentTimestamp.set(target);
    }
  }
}
