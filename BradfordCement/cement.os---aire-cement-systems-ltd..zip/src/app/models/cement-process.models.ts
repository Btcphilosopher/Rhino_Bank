export type ProvenanceType = 'MEASURED' | 'CALCULATED' | 'SIMULATED' | 'ESTIMATED' | 'PREDICTED';

export type AlarmSeverity = 'INFO' | 'ADVISORY' | 'WARNING' | 'HIGH' | 'CRITICAL';

export type AssetCondition = 'NORMAL' | 'WATCH' | 'DEGRADED' | 'HIGH RISK' | 'CRITICAL';

export interface ChemicalComposition {
  CaO: number;      // % Calcium Oxide
  SiO2: number;     // % Silicon Dioxide
  Al2O3: number;    // % Aluminium Oxide
  Fe2O3: number;    // % Iron Oxide
  MgO: number;      // % Magnesium Oxide
  SO3: number;      // % Sulfur Trioxide
  K2O: number;      // % Potassium Oxide
  Na2O: number;     // % Sodium Oxide
  Cl: number;       // % Chloride
  LOI: number;      // % Loss on Ignition (primarily CO2)
  moisture: number; // % Water content
}

export interface CementRatios {
  LSF: number; // Lime Saturation Factor
  SM: number;  // Silica Modulus
  AM: number;  // Alumina Modulus
}

export interface ClinkerPhases {
  C3S: number;  // Alite % (3CaO·SiO2)
  C2S: number;  // Belite % (2CaO·SiO2)
  C3A: number;  // Aluminite % (3CaO·Al2O3)
  C4AF: number; // Ferrite % (4CaO·Al2O3·Fe2O3)
  freeLime: number; // % Free CaO
}

export interface MaterialStream {
  id: string;
  name: string;
  materialType: 'limestone' | 'clay' | 'shale' | 'sand' | 'iron_ore' | 'raw_meal' | 'clinker' | 'gypsum' | 'slag' | 'fly_ash' | 'alternative_fuel' | 'coal' | 'petcoke' | 'cement';
  massFlowTph: number;
  temperatureC: number;
  moisturePercent: number;
  composition: ChemicalComposition;
  particleSizeMicronsD50: number;
  densityKgM3: number;
  sourceUnitId: string;
  destinationUnitId: string;
  provenance: ProvenanceType;
}

export interface RawMillState {
  id: string;
  name: string;
  feedRateTph: number;
  moistureInPercent: number;
  grindingPressureBar: number;
  differentialPressureMbar: number;
  motorPowerKw: number;
  specificEnergyKwhT: number;
  separatorSpeedRpm: number;
  airFlowM3h: number;
  outletTempC: number;
  productFinenessR90Micron: number; // % retained on 90µm sieve
  vibrationMmS: number;
  circulatingLoadPercent: number;
  status: 'RUNNING' | 'STANDBY' | 'TRIPPED' | 'MAINTENANCE';
}

export interface PreheaterStage {
  stageNumber: number; // 1 to 5
  gasTempC: number;
  solidsTempC: number;
  pressureMbar: number;
  cycloneEfficiencyPercent: number;
}

export interface PrecalcinerState {
  fuelInputTph: number;
  alternativeFuelPercent: number;
  combustionTempC: number;
  calcinationDegreePercent: number; // CaCO3 -> CaO conversion %
  co2FlowTph: number;
  o2Percent: number;
}

export interface KilnZone {
  name: string;
  startMeter: number;
  endMeter: number;
  gasTempC: number;
  materialTempC: number;
  shellTempC: number;
  coatingThicknessMm: number;
}

export interface RotaryKilnState {
  id: string;
  name: string;
  feedRateTph: number;
  rotationSpeedRpm: number;
  inclinationDegree: number;
  secondaryAirTempC: number;
  tertiaryAirTempC: number;
  burningZoneTempC: number;
  flameTempC: number;
  primaryFuelTph: number; // Petcoke / Coal
  alternativeFuelTph: number;
  fillingDegreePercent: number;
  residenceTimeMin: number;
  clinkerProductionTph: number;
  drivePowerKw: number;
  shellMaxTempC: number;
  o2Percent: number;
  co2Percent: number;
  noxPpm: number;
  thermalConsumptionGjT: number;
  zones: KilnZone[];
  status: 'RUNNING' | 'STANDBY' | 'TRIPPED' | 'STARTUP';
}

export interface ClinkerCoolerState {
  id: string;
  name: string;
  grateSpeedSpm: number;
  coolingAirM3h: number;
  clinkerInTempC: number;
  clinkerOutTempC: number;
  secondaryAirTempC: number;
  tertiaryAirTempC: number;
  heatRecoveredGjH: number;
  coolingEfficiencyPercent: number;
}

export interface CementMillState {
  id: string;
  name: string;
  millType: 'BALL_MILL' | 'VERTICAL_ROLLER_MILL';
  clinkerFeedTph: number;
  gypsumFeedTph: number;
  scmFeedTph: number; // Slag/Fly ash
  additiveFeedTph: number;
  totalFeedTph: number;
  motorPowerKw: number;
  specificEnergyKwhT: number;
  separatorSpeedRpm: number;
  productBlaineCm2G: number;
  outletTempC: number;
  vibrationMmS: number;
  circulatingLoadPercent: number;
  status: 'RUNNING' | 'STANDBY' | 'TRIPPED' | 'MAINTENANCE';
}

export interface CementProduct {
  id: string;
  code: string; // e.g. 'Aire CEM I 52.5N'
  name: string;
  description: string;
  clinkerPercent: number;
  gypsumPercent: number;
  scmType: 'NONE' | 'SLAG' | 'LIMESTONE' | 'FLY_ASH';
  scmPercent: number;
  targetBlaineCm2G: number;
  target28DayStrengthMpa: number;
  embodiedCarbonKgCo2T: number;
  unitCostGbpT: number;
}

export interface QualitySample {
  sampleId: string;
  materialName: string;
  sourceLocation: string;
  timestamp: string;
  operator: string;
  composition: ChemicalComposition;
  ratios?: CementRatios;
  phases?: ClinkerPhases;
  blaineCm2G?: number;
  residue90MicronPercent?: number;
  initialSettingTimeMin?: number;
  compressiveStrength2DayMpa?: number;
  compressiveStrength28DayMpa?: number;
  status: 'APPROVED' | 'PENDING' | 'REJECTED';
  provenance: ProvenanceType;
}

export interface EnergyMetrics {
  totalElectricityKw: number;
  specificElectricityKwhTCement: number;
  thermalConsumptionGjTClinker: number;
  alternativeFuelThermalSubPercent: number;
  gridPowerImportKw: number;
  wasteHeatRecoveryKw: number;
}

export interface EmissionsMetrics {
  processCo2Tph: number; // From calcination CaCO3 -> CaO + CO2
  fuelCo2Tph: number;    // From combustion
  electricityScope2Co2Tph: number;
  totalScope1And2Co2Tph: number;
  specificEmissionsKgCo2TClinker: number;
  specificEmissionsKgCo2TCement: number;
  annualCo2TonneEstimate: number;
}

export interface PlantAsset {
  id: string;
  name: string;
  category: 'QUARRY' | 'RAW_MILL' | 'PYROPROCESS' | 'COOLER' | 'CEMENT_MILL' | 'STORAGE' | 'DISPATCH' | 'UTILITIES';
  manufacturer: string;
  model: string;
  commissioningYear: number;
  ratedCapacityTph: number;
  operatingHours: number;
  vibrationMmS: number;
  bearingTempC: number;
  motorCurrentAmps: number;
  condition: AssetCondition;
  healthScorePercent: number; // 0 - 100
  lastMaintenanceDate: string;
  nextScheduledMaintenance: string;
  activeWorkOrder?: string;
}

export interface AlarmItem {
  alarmId: string;
  timestamp: string;
  assetId: string;
  assetName: string;
  variable: string;
  currentValue: number;
  unit: string;
  threshold: number;
  severity: AlarmSeverity;
  causeDiagnostic: string;
  acknowledged: boolean;
  acknowledgedBy?: string;
}

export interface WhatIfScenario {
  id: string;
  title: string;
  description: string;
  parameterChanges: {
    kilnFeedPercentChange?: number;
    rawMaterialMoisturePercentChange?: number;
    alternativeFuelSubPercent?: number;
    scmAdditionPercent?: number;
    coolerEfficiencyLossPercent?: number;
    millSpeedRpmDelta?: number;
  };
  results?: {
    clinkerProductionTph: number;
    cementProductionTph: number;
    thermalGjT: number;
    electricalKwhT: number;
    co2KgTCement: number;
    costGbpTCement: number;
    predicted28dStrengthMpa: number;
    equipmentRiskLevel: AssetCondition;
  };
}

export interface TimelineEvent {
  timeStr: string;
  timestampMs?: number;
  headline: string;
  description: string;
  affectedAssetId: string;
  type: 'OPERATIONAL' | 'PROCESS_CHANGE' | 'DEGRADATION' | 'MAINTENANCE' | 'DECISION';
  parameterDiffs?: Record<string, string>;
}
