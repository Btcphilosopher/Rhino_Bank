import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CementTwinService } from '../../services/cement-twin.service';

@Component({
  selector: 'app-pyroprocess-kiln-view',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="w-full h-full bg-[#111317] p-6 overflow-y-auto text-slate-200">
      <!-- Section Header -->
      <div class="flex items-center justify-between pb-4 border-b border-white/10 mb-6">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono px-2 py-0.5 bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded">PYROPROCESS SYSTEM</span>
            <h1 class="text-xl font-bold text-white tracking-tight">KILN-01 COMPUTATIONAL DIGITAL TWIN</h1>
          </div>
          <p class="text-xs text-slate-400 mt-1 font-mono">68m x 4.4m Rotary Kiln · 5-Stage Preheater & Calciner · Grate Cooler</p>
        </div>

        <div class="flex items-center gap-6">
          <div class="text-right">
            <div class="text-xs text-slate-400 uppercase font-mono">Clinker Output</div>
            <div class="text-lg font-bold text-emerald-400 font-mono tabular-nums">{{ kiln().clinkerProductionTph }} t/h</div>
          </div>
          <div class="text-right">
            <div class="text-xs text-slate-400 uppercase font-mono">Thermal Specific</div>
            <div class="text-lg font-bold text-amber-400 font-mono tabular-nums">{{ kiln().thermalConsumptionGjT }} GJ/t</div>
          </div>
        </div>
      </div>

      <!-- Main Grid Layout -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <!-- Column 1: Kiln Thermal & Zone Profile -->
        <div class="lg:col-span-2 bg-[#181b22] border border-white/10 rounded-2xl p-5 shadow-xl">
          <div class="flex items-center justify-between mb-4">
            <h3 class="text-sm font-bold text-slate-100 flex items-center gap-2">
              <span class="material-icons text-orange-400 text-base">thermostat</span>
              KILN THERMAL PROFILE & SHELL SURFACE SCANNER (0 to 68m)
            </h3>
            <span class="text-xs text-slate-400 font-mono">Data Source: Infrared Scanner + Model</span>
          </div>

          <!-- Thermal Profile SVG Chart -->
          <div class="relative w-full h-56 bg-[#111317] rounded-xl border border-white/5 p-4 mb-4">
            <svg class="w-full h-full" viewBox="0 0 600 180" preserveAspectRatio="none">
              <!-- Grid lines -->
              <line x1="0" y1="40" x2="600" y2="40" stroke="#ffffff10" stroke-width="1"/>
              <line x1="0" y1="80" x2="600" y2="80" stroke="#ffffff10" stroke-width="1"/>
              <line x1="0" y1="120" x2="600" y2="120" stroke="#ffffff10" stroke-width="1"/>

              <!-- Temp scale labels -->
              <text x="5" y="15" fill="#ef4444" font-size="9" font-mono>1800°C (Gas Flame)</text>
              <text x="5" y="75" fill="#f59e0b" font-size="9" font-mono>1400°C (Material Bed)</text>
              <text x="5" y="135" fill="#3b82f6" font-size="9" font-mono>300°C (Shell Outer)</text>

              <!-- Gas Temp Curve (Flame peak at 50m) -->
              <path d="M 0,110 C 150,90 300,70 450,15 C 500,10 550,60 600,100" fill="none" stroke="#ef4444" stroke-width="2.5"/>

              <!-- Material Temp Curve -->
              <path d="M 0,130 C 120,115 250,95 450,45 C 520,40 560,70 600,85" fill="none" stroke="#f59e0b" stroke-width="2.5"/>

              <!-- Shell Temp Profile -->
              <path d="M 0,165 C 150,155 350,150 450,138 C 500,140 550,155 600,160" fill="none" stroke="#3b82f6" stroke-width="2"/>
            </svg>
          </div>

          <!-- Zone Breakdown Cards -->
          <div class="grid grid-cols-5 gap-2">
            @for (zone of kiln().zones; track zone.name) {
              <div class="bg-[#202530] p-2.5 rounded-xl border border-white/5 text-xs">
                <div class="text-[11px] font-semibold text-slate-300 truncate">{{ zone.name }}</div>
                <div class="text-[10px] text-slate-400 font-mono">{{ zone.startMeter }}-{{ zone.endMeter }}m</div>
                <div class="mt-2 text-amber-400 font-bold font-mono">{{ zone.materialTempC }}°C</div>
                <div class="text-[10px] text-slate-400 font-mono">Shell: {{ zone.shellTempC }}°C</div>
              </div>
            }
          </div>
        </div>

        <!-- Column 2: Clinker Phase Mineralogy (Bogue Calculations) -->
        <div class="bg-[#181b22] border border-white/10 rounded-2xl p-5 shadow-xl flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between mb-3">
              <h3 class="text-sm font-bold text-slate-100 flex items-center gap-2">
                <span class="material-icons text-emerald-400 text-base">science</span>
                CLINKER PHASE MINERALOGY
              </h3>
              <span class="text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded font-mono">CALCULATED</span>
            </div>

            <!-- Mineral Phase Progress Bars -->
            <div class="space-y-4 my-4">
              <div>
                <div class="flex justify-between text-xs font-mono mb-1">
                  <span class="text-slate-300">C3S Alite (3CaO·SiO2)</span>
                  <span class="text-emerald-400 font-bold">{{ phases().C3S }} %</span>
                </div>
                <div class="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div class="bg-emerald-500 h-full rounded-full" [style.width.%]="phases().C3S"></div>
                </div>
              </div>

              <div>
                <div class="flex justify-between text-xs font-mono mb-1">
                  <span class="text-slate-300">C2S Belite (2CaO·SiO2)</span>
                  <span class="text-blue-400 font-bold">{{ phases().C2S }} %</span>
                </div>
                <div class="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div class="bg-blue-500 h-full rounded-full" [style.width.%]="phases().C2S"></div>
                </div>
              </div>

              <div>
                <div class="flex justify-between text-xs font-mono mb-1">
                  <span class="text-slate-300">C3A Aluminite (3CaO·Al2O3)</span>
                  <span class="text-amber-400 font-bold">{{ phases().C3A }} %</span>
                </div>
                <div class="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div class="bg-amber-500 h-full rounded-full" [style.width.%]="phases().C3A * 3"></div>
                </div>
              </div>

              <div>
                <div class="flex justify-between text-xs font-mono mb-1">
                  <span class="text-slate-300">C4AF Ferrite (4CaO·Al2O3·Fe2O3)</span>
                  <span class="text-purple-400 font-bold">{{ phases().C4AF }} %</span>
                </div>
                <div class="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div class="bg-purple-500 h-full rounded-full" [style.width.%]="phases().C4AF * 3"></div>
                </div>
              </div>

              <div>
                <div class="flex justify-between text-xs font-mono mb-1">
                  <span class="text-slate-300">Free Lime (CaO) Target &lt; 1.5%</span>
                  <span class="text-red-400 font-bold">{{ phases().freeLime }} %</span>
                </div>
                <div class="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div class="bg-red-500 h-full rounded-full" [style.width.%]="phases().freeLime * 20"></div>
                </div>
              </div>
            </div>
          </div>

          <!-- Controls: Adjust Kiln Feed Rate -->
          <div class="pt-4 border-t border-white/10">
            <div class="flex items-center justify-between text-xs font-mono mb-2">
              <span class="text-slate-300">Kiln Feed Rate Adjustment:</span>
              <span class="text-amber-400 font-bold">{{ kiln().feedRateTph }} t/h</span>
            </div>
            <input
              type="range"
              min="140"
              max="220"
              step="1"
              [value]="kiln().feedRateTph"
              (input)="onKilnFeedChange($event)"
              class="w-full accent-amber-500 cursor-pointer"
            />
          </div>
        </div>
      </div>

      <!-- Preheater Cyclones & Cooler Overview -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <!-- Preheater 5-stage Breakdown -->
        <div class="bg-[#181b22] border border-white/10 rounded-2xl p-5 shadow-xl">
          <h3 class="text-sm font-bold text-slate-100 mb-4 flex items-center gap-2">
            <span class="material-icons text-amber-400 text-base">compress</span>
            PREHEATER TOWER 5-STAGE DRAFT & TEMPERATURES
          </h3>

          <div class="space-y-2">
            @for (stage of preheater(); track stage.stageNumber) {
              <div class="flex items-center justify-between p-2.5 bg-[#202530] rounded-xl text-xs font-mono border border-white/5">
                <span class="text-slate-300 font-bold">Cyclone Stage {{ stage.stageNumber }}</span>
                <span class="text-amber-400">Gas: {{ stage.gasTempC }}°C</span>
                <span class="text-blue-400">Pressure: {{ stage.pressureMbar }} mbar</span>
                <span class="text-emerald-400">Eff: {{ stage.cycloneEfficiencyPercent }}%</span>
              </div>
            }
          </div>
        </div>

        <!-- Clinker Cooler Parameters -->
        <div class="bg-[#181b22] border border-white/10 rounded-2xl p-5 shadow-xl">
          <h3 class="text-sm font-bold text-slate-100 mb-4 flex items-center gap-2">
            <span class="material-icons text-cyan-400 text-base">ac_unit</span>
            CLINKER COOLER RECOVERY & EFFICIENCY
          </h3>

          <div class="grid grid-cols-2 gap-3 text-xs font-mono">
            <div class="p-3 bg-[#202530] rounded-xl border border-white/5">
              <div class="text-slate-400 text-[11px]">Secondary Air Temp</div>
              <div class="text-base font-bold text-amber-400 mt-1">{{ cooler().secondaryAirTempC }} °C</div>
            </div>

            <div class="p-3 bg-[#202530] rounded-xl border border-white/5">
              <div class="text-slate-400 text-[11px]">Tertiary Air Temp</div>
              <div class="text-base font-bold text-amber-400 mt-1">{{ cooler().tertiaryAirTempC }} °C</div>
            </div>

            <div class="p-3 bg-[#202530] rounded-xl border border-white/5">
              <div class="text-slate-400 text-[11px]">Clinker Discharge Temp</div>
              <div class="text-base font-bold text-cyan-400 mt-1">{{ cooler().clinkerOutTempC }} °C</div>
            </div>

            <div class="p-3 bg-[#202530] rounded-xl border border-white/5">
              <div class="text-slate-400 text-[11px]">Cooler Heat Recovery</div>
              <div class="text-base font-bold text-emerald-400 mt-1">{{ cooler().heatRecoveredGjH }} GJ/h</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class PyroprocessKilnViewComponent {
  private twin = inject(CementTwinService);

  readonly kiln = this.twin.rotaryKilnState;
  readonly phases = this.twin.clinkerPhases;
  readonly preheater = this.twin.preheaterStages;
  readonly cooler = this.twin.clinkerCoolerState;

  onKilnFeedChange(event: Event) {
    const val = Number((event.target as HTMLInputElement).value);
    this.twin.setKilnFeedRate(val);
  }
}
