import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CementTwinService } from '../../services/cement-twin.service';

@Component({
  selector: 'app-control-room-dashboard-view',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="w-full h-full bg-[#111317] p-6 overflow-y-auto text-slate-200">
      <!-- Control Room Banner -->
      <div class="flex items-center justify-between pb-4 border-b border-white/10 mb-6">
        <div class="flex items-center gap-3">
          <div class="w-3 h-3 rounded-full bg-emerald-500 animate-pulse"></div>
          <div>
            <h1 class="text-xl font-bold text-white tracking-tight font-display">AIRE CEMENT SYSTEMS — BRADFORD CENTRAL CONTROL ROOM</h1>
            <p class="text-xs text-slate-400 font-mono">SCADA SC-408 · Shift Leader: J. Hargreaves · System Status: NOMINAL OPERATIONAL</p>
          </div>
        </div>

        <div class="flex items-center gap-4 font-mono text-xs">
          <button (click)="toggleSim()" class="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-black font-bold rounded-xl transition-all shadow-md">
            {{ isSimulating() ? 'PAUSE SIMULATION' : 'RESUME SIMULATION' }}
          </button>
        </div>
      </div>

      <!-- High-Density Equipment SCADA Status Cards -->
      <div class="grid grid-cols-2 md:grid-cols-6 gap-3 mb-6 font-mono">
        <div class="p-3 bg-[#181b22] border border-white/10 rounded-xl">
          <div class="text-[10px] text-slate-400">ROTARY KILN</div>
          <div class="text-sm font-bold text-emerald-400 mt-1 flex items-center gap-1">
            <span class="w-2 h-2 rounded-full bg-emerald-500"></span> RUNNING
          </div>
          <div class="text-xs text-slate-300 mt-1 font-bold">{{ kiln().clinkerProductionTph }} t/h</div>
        </div>

        <div class="p-3 bg-[#181b22] border border-white/10 rounded-xl">
          <div class="text-[10px] text-slate-400">RAW MILL 1</div>
          <div class="text-sm font-bold text-emerald-400 mt-1 flex items-center gap-1">
            <span class="w-2 h-2 rounded-full bg-emerald-500"></span> RUNNING
          </div>
          <div class="text-xs text-slate-300 mt-1 font-bold">{{ rawMill().feedRateTph }} t/h</div>
        </div>

        <div class="p-3 bg-[#181b22] border border-white/10 rounded-xl">
          <div class="text-[10px] text-slate-400">CEMENT MILL 1</div>
          <div class="text-sm font-bold text-emerald-400 mt-1 flex items-center gap-1">
            <span class="w-2 h-2 rounded-full bg-emerald-500"></span> RUNNING
          </div>
          <div class="text-xs text-slate-300 mt-1 font-bold">{{ cmill1().totalFeedTph }} t/h</div>
        </div>

        <div class="p-3 bg-[#181b22] border border-white/10 rounded-xl">
          <div class="text-[10px] text-slate-400">CEMENT MILL 2</div>
          <div class="text-sm font-bold text-amber-400 mt-1 flex items-center gap-1">
            <span class="w-2 h-2 rounded-full bg-amber-500"></span> ADVISORY
          </div>
          <div class="text-xs text-slate-300 mt-1 font-bold">{{ cmill2().totalFeedTph }} t/h</div>
        </div>

        <div class="p-3 bg-[#181b22] border border-white/10 rounded-xl">
          <div class="text-[10px] text-slate-400">CLINKER COOLER</div>
          <div class="text-sm font-bold text-emerald-400 mt-1 flex items-center gap-1">
            <span class="w-2 h-2 rounded-full bg-emerald-500"></span> RUNNING
          </div>
          <div class="text-xs text-slate-300 mt-1 font-bold">{{ cooler().coolingEfficiencyPercent }}% Eff</div>
        </div>

        <div class="p-3 bg-[#181b22] border border-white/10 rounded-xl">
          <div class="text-[10px] text-slate-400">PACKING & DISPATCH</div>
          <div class="text-sm font-bold text-emerald-400 mt-1 flex items-center gap-1">
            <span class="w-2 h-2 rounded-full bg-emerald-500"></span> RUNNING
          </div>
          <div class="text-xs text-slate-300 mt-1 font-bold">180 t/h</div>
        </div>
      </div>

      <!-- ALARMS & OPERATIONAL EVENTS -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Active Alarms -->
        <div class="bg-[#181b22] border border-white/10 rounded-2xl p-5 shadow-xl">
          <div class="flex items-center justify-between mb-4">
            <h3 class="text-sm font-bold text-slate-100 flex items-center gap-2">
              <span class="material-icons text-red-400 text-base">notifications_active</span>
              ACTIVE ENGINEERING ALARMS ({{ alarms().length }})
            </h3>
            <span class="text-[10px] text-slate-400 font-mono">IEC 62682 Severity Compliance</span>
          </div>

          <div class="space-y-3 font-mono text-xs">
            @for (alm of alarms(); track alm.alarmId) {
              <div class="p-3 bg-[#202530] border border-white/5 rounded-xl space-y-2">
                <div class="flex items-center justify-between">
                  <div class="flex items-center gap-2">
                    <span [class]="alm.severity === 'HIGH' ? 'bg-red-500/20 text-red-400 border-red-500/30' : 'bg-amber-500/20 text-amber-400 border-amber-500/30'" class="px-2 py-0.5 rounded text-[10px] font-bold border">
                      {{ alm.severity }}
                    </span>
                    <span class="font-bold text-white">{{ alm.assetName }}</span>
                  </div>

                  <span class="text-slate-400 text-[11px]">{{ alm.timestamp }}</span>
                </div>

                <div class="text-slate-300">
                  {{ alm.variable }}: <span class="text-amber-400 font-bold">{{ alm.currentValue }} {{ alm.unit }}</span> (Limit: {{ alm.threshold }})
                </div>

                <p class="text-[11px] text-slate-400 leading-relaxed font-sans">{{ alm.causeDiagnostic }}</p>

                <div class="pt-2 border-t border-white/5 flex items-center justify-between">
                  @if (alm.acknowledged) {
                    <span class="text-emerald-400 text-[10px]">ACK: {{ alm.acknowledgedBy }}</span>
                  } @else {
                    <button (click)="ackAlarm(alm.alarmId)" class="px-3 py-1 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 rounded text-[10px] font-bold">
                      ACKNOWLEDGE ALARM
                    </button>
                  }
                </div>
              </div>
            }
          </div>
        </div>

        <!-- SCADA Live Process Telemetry Feed -->
        <div class="bg-[#181b22] border border-white/10 rounded-2xl p-5 shadow-xl">
          <h3 class="text-sm font-bold text-slate-100 mb-4 flex items-center gap-2">
            <span class="material-icons text-blue-400 text-base">monitor_heart</span>
            PLANT CRITICAL PROCESS PARAMETERS
          </h3>

          <div class="space-y-3 font-mono text-xs">
            <div class="p-3 bg-[#202530] rounded-xl border border-white/5 flex justify-between items-center">
              <span class="text-slate-300">Kiln Burning Zone Temperature</span>
              <span class="text-base font-bold text-amber-400">{{ kiln().burningZoneTempC }} °C</span>
            </div>

            <div class="p-3 bg-[#202530] rounded-xl border border-white/5 flex justify-between items-center">
              <span class="text-slate-300">Calciner Calcination Degree</span>
              <span class="text-base font-bold text-emerald-400">{{ precalciner().calcinationDegreePercent }} %</span>
            </div>

            <div class="p-3 bg-[#202530] rounded-xl border border-white/5 flex justify-between items-center">
              <span class="text-slate-300">Raw Mill Specific Energy</span>
              <span class="text-base font-bold text-blue-400">{{ rawMill().specificEnergyKwhT }} kWh/t</span>
            </div>

            <div class="p-3 bg-[#202530] rounded-xl border border-white/5 flex justify-between items-center">
              <span class="text-slate-300">Cement Mill 2 Pinion Vibration</span>
              <span [class]="cmill2().vibrationMmS > 6.0 ? 'text-red-400 font-bold animate-pulse' : 'text-slate-200'" class="text-base font-bold">
                {{ cmill2().vibrationMmS }} mm/s
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class ControlRoomDashboardViewComponent {
  private twin = inject(CementTwinService);

  readonly isSimulating = this.twin.isSimulating;
  readonly alarms = this.twin.activeAlarms;

  readonly kiln = this.twin.rotaryKilnState;
  readonly rawMill = this.twin.rawMillState;
  readonly precalciner = this.twin.precalcinerState;
  readonly cmill1 = this.twin.cementMill1State;
  readonly cmill2 = this.twin.cementMill2State;
  readonly cooler = this.twin.clinkerCoolerState;

  toggleSim() {
    this.twin.toggleSimulation();
  }

  ackAlarm(id: string) {
    this.twin.acknowledgeAlarm(id, 'J. Hargreaves');
  }
}
