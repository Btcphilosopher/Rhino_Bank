import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CementTwinService } from '../../services/cement-twin.service';
import { TimelineEvent } from '../../models/cement-process.models';

@Component({
  selector: 'app-scenario-engine-view',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="w-full h-full bg-[#111317] p-6 overflow-y-auto text-slate-200">
      <!-- Header -->
      <div class="flex items-center justify-between pb-4 border-b border-white/10 mb-6">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono px-2 py-0.5 bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded">SIMULATION MATRIX</span>
            <h1 class="text-xl font-bold text-white tracking-tight">WHAT-IF SCENARIO ENGINE & DEMO REPLAY</h1>
          </div>
          <p class="text-xs text-slate-400 mt-1 font-mono">Process Monte Carlo Analysis · Multi-Variable Tradeoff Matrix · Bradford Morning Scenario</p>
        </div>

        <div class="flex items-center gap-2">
          <button (click)="runScenario('BASELINE')" [class]="activeScenario() === 'BASELINE' ? 'bg-amber-500 text-black font-bold' : 'bg-[#181b22] text-slate-300 border border-white/10'" class="px-3.5 py-1.5 rounded-xl text-xs font-mono transition-all">
            BASELINE
          </button>

          <button (click)="runScenario('FEED_RAMP')" [class]="activeScenario() === 'FEED_RAMP' ? 'bg-amber-500 text-black font-bold' : 'bg-[#181b22] text-slate-300 border border-white/10'" class="px-3.5 py-1.5 rounded-xl text-xs font-mono transition-all">
            KILN FEED +10%
          </button>

          <button (click)="runScenario('MOISTURE_HIGH')" [class]="activeScenario() === 'MOISTURE_HIGH' ? 'bg-amber-500 text-black font-bold' : 'bg-[#181b22] text-slate-300 border border-white/10'" class="px-3.5 py-1.5 rounded-xl text-xs font-mono transition-all">
            RAW MOISTURE +3%
          </button>

          <button (click)="runScenario('FUEL_SWITCH')" [class]="activeScenario() === 'FUEL_SWITCH' ? 'bg-amber-500 text-black font-bold' : 'bg-[#181b22] text-slate-300 border border-white/10'" class="px-3.5 py-1.5 rounded-xl text-xs font-mono transition-all">
            FUEL SWITCH (50% ALT)
          </button>
        </div>
      </div>

      <!-- Comparison Matrix Table -->
      <div class="bg-[#181b22] border border-white/10 rounded-2xl p-5 shadow-xl mb-6">
        <h3 class="text-sm font-bold text-slate-100 mb-4 flex items-center gap-2">
          <span class="material-icons text-amber-400 text-base">table_chart</span>
          SCENARIO TRADEOFF COMPARISON MATRIX
        </h3>

        <div class="overflow-x-auto">
          <table class="w-full text-xs font-mono text-left">
            <thead class="bg-[#202530] text-slate-400 uppercase text-[10px]">
              <tr>
                <th class="p-3">Performance Metric</th>
                <th class="p-3 text-amber-400">BASELINE</th>
                <th class="p-3 text-blue-400">KILN FEED +10%</th>
                <th class="p-3 text-cyan-400">MOISTURE +3%</th>
                <th class="p-3 text-emerald-400">FUEL SWITCH</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-white/5 text-slate-300">
              <tr class="hover:bg-white/5">
                <td class="p-3 font-semibold text-white">Clinker Production Rate</td>
                <td class="p-3 font-bold text-amber-400">114.0 t/h</td>
                <td class="p-3 font-bold text-blue-400">125.4 t/h (+10%)</td>
                <td class="p-3 text-slate-400">112.1 t/h (-1.7%)</td>
                <td class="p-3 text-emerald-400">113.8 t/h</td>
              </tr>

              <tr class="hover:bg-white/5">
                <td class="p-3 font-semibold text-white">Specific Electrical Energy</td>
                <td class="p-3 font-bold text-amber-400">88.5 kWh/t</td>
                <td class="p-3 text-slate-400">86.2 kWh/t (-2.6%)</td>
                <td class="p-3 font-bold text-cyan-400">94.8 kWh/t (+7.1%)</td>
                <td class="p-3 text-slate-400">89.1 kWh/t</td>
              </tr>

              <tr class="hover:bg-white/5">
                <td class="p-3 font-semibold text-white">Specific Thermal Consumption</td>
                <td class="p-3 font-bold text-amber-400">3.12 GJ/t</td>
                <td class="p-3 text-slate-400">3.18 GJ/t</td>
                <td class="p-3 text-slate-400">3.32 GJ/t</td>
                <td class="p-3 font-bold text-emerald-400">3.08 GJ/t (-1.3%)</td>
              </tr>

              <tr class="hover:bg-white/5">
                <td class="p-3 font-semibold text-white">Emissions Intensity (Cement)</td>
                <td class="p-3 font-bold text-amber-400">685 kg CO2/t</td>
                <td class="p-3 text-slate-400">682 kg CO2/t</td>
                <td class="p-3 text-slate-400">705 kg CO2/t</td>
                <td class="p-3 font-bold text-emerald-400">620 kg CO2/t (-9.5%)</td>
              </tr>

              <tr class="hover:bg-white/5">
                <td class="p-3 font-semibold text-white">Cement Cost of Production</td>
                <td class="p-3 font-bold text-amber-400">£42.50 / t</td>
                <td class="p-3 font-bold text-blue-400">£39.80 / t</td>
                <td class="p-3 font-bold text-red-400">£46.20 / t</td>
                <td class="p-3 font-bold text-emerald-400">£37.90 / t</td>
              </tr>

              <tr class="hover:bg-white/5">
                <td class="p-3 font-semibold text-white">Equipment Risk Status</td>
                <td class="p-3"><span class="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-400 font-bold border border-emerald-500/30">NORMAL</span></td>
                <td class="p-3"><span class="px-2 py-0.5 rounded text-[10px] bg-amber-500/20 text-amber-400 font-bold border border-amber-500/30">HIGH LOAD</span></td>
                <td class="p-3"><span class="px-2 py-0.5 rounded text-[10px] bg-blue-500/20 text-blue-400 font-bold border border-blue-500/30">FAN DRAFT</span></td>
                <td class="p-3"><span class="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-400 font-bold border border-emerald-500/30">NORMAL</span></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Demo Replay: "BRADFORD MORNING PRODUCTION" Timeline -->
      <div class="bg-[#181b22] border border-white/10 rounded-2xl p-5 shadow-xl">
        <h3 class="text-sm font-bold text-slate-100 mb-4 flex items-center gap-2">
          <span class="material-icons text-purple-400 text-base">history</span>
          DEMO SCENARIO: BRADFORD MORNING PRODUCTION (06:00 - 10:00 REPLAY)
        </h3>

        <div class="space-y-3 font-mono text-xs">
              @for (evt of demoEvents(); track evt.headline) {
                <div
                  tabindex="0"
                  (click)="jumpToEvent(evt)"
                  (keyup.enter)="jumpToEvent(evt)"
                  class="p-3.5 bg-[#202530] hover:bg-[#282f3e] rounded-xl border border-white/5 cursor-pointer transition-all flex items-start justify-between focus:outline-none focus:ring-1 focus:ring-amber-500"
                >
              <div class="space-y-1">
                <div class="flex items-center gap-2">
                  <span class="px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 font-bold text-[10px] border border-amber-500/30">{{ evt.timeStr }}</span>
                  <h4 class="font-bold text-white text-xs">{{ evt.headline }}</h4>
                </div>
                <p class="text-slate-300 text-[11px] font-sans">{{ evt.description }}</p>

                @if (evt.parameterDiffs) {
                  <div class="flex flex-wrap gap-2 pt-1 text-[10px]">
                    @for (entry of getDiffEntries(evt.parameterDiffs); track entry.key) {
                      <span class="px-2 py-0.5 bg-black/40 text-amber-300 rounded border border-white/5 font-mono">
                        {{ entry.key }}: {{ entry.value }}
                      </span>
                    }
                  </div>
                }
              </div>

              <span class="text-[10px] text-slate-400 uppercase bg-slate-800 px-2 py-1 rounded">
                {{ evt.type }}
              </span>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class ScenarioEngineViewComponent {
  private twin = inject(CementTwinService);

  readonly activeScenario = signal<'BASELINE' | 'FEED_RAMP' | 'MOISTURE_HIGH' | 'FUEL_SWITCH'>('BASELINE');
  readonly demoEvents = this.twin.demoEvents;

  runScenario(scen: 'BASELINE' | 'FEED_RAMP' | 'MOISTURE_HIGH' | 'FUEL_SWITCH') {
    this.activeScenario.set(scen);
    if (scen === 'FEED_RAMP') {
      this.twin.setKilnFeedRate(200.6);
    } else if (scen === 'FUEL_SWITCH') {
      this.twin.setAlternativeFuelPercent(50);
    } else {
      this.twin.setKilnFeedRate(182.4);
    }
  }

  jumpToEvent(evt: TimelineEvent) {
    this.twin.seekTimeMachine(evt.timeStr);
    alert(`Replaying Plant Digital Twin state at ${evt.timeStr}: ${evt.headline}`);
  }

  getDiffEntries(diffs: Record<string, string>): { key: string; value: string }[] {
    return Object.entries(diffs).map(([key, value]) => ({ key, value }));
  }
}
