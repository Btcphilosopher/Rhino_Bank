import { Component, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CementTwinService } from '../../services/cement-twin.service';

@Component({
  selector: 'app-energy-emissions-view',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="w-full h-full bg-[#111317] p-6 overflow-y-auto text-slate-200">
      <!-- Header -->
      <div class="flex items-center justify-between pb-4 border-b border-white/10 mb-6">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono px-2 py-0.5 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded">NET ZERO ROADMAP</span>
            <h1 class="text-xl font-bold text-white tracking-tight">PLANT ENERGY ACCOUNTING & DECARBONISATION LAB</h1>
          </div>
          <p class="text-xs text-slate-400 mt-1 font-mono">Scope 1, 2 & 3 Emissions Engine · Waste Heat Recovery · Alternative Fuel Substitution</p>
        </div>

        <div class="flex items-center gap-6">
          <div class="text-right">
            <div class="text-xs text-slate-400 uppercase font-mono">Scope 1 & 2 CO2</div>
            <div class="text-lg font-bold text-amber-400 font-mono tabular-nums">{{ emissions().totalScope1And2Co2Tph }} t CO2/h</div>
          </div>
          <div class="text-right">
            <div class="text-xs text-slate-400 uppercase font-mono">Intensity</div>
            <div class="text-lg font-bold text-emerald-400 font-mono tabular-nums">{{ emissions().specificEmissionsKgCo2TCement }} kg CO2/t</div>
          </div>
        </div>
      </div>

      <!-- KPI Summary Cards -->
      <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div class="bg-[#181b22] border border-white/10 p-4 rounded-2xl">
          <div class="text-xs text-slate-400 uppercase font-mono">Thermal Energy</div>
          <div class="text-xl font-bold text-amber-400 font-mono mt-1 tabular-nums">{{ energy().thermalConsumptionGjTClinker }} GJ/t clinker</div>
          <p class="text-[10px] text-slate-500 mt-1 font-mono">Target: &lt; 3.10 GJ/t</p>
        </div>

        <div class="bg-[#181b22] border border-white/10 p-4 rounded-2xl">
          <div class="text-xs text-slate-400 uppercase font-mono">Electrical Specific</div>
          <div class="text-xl font-bold text-blue-400 font-mono mt-1 tabular-nums">{{ energy().specificElectricityKwhTCement }} kWh/t cement</div>
          <p class="text-[10px] text-slate-500 mt-1 font-mono">Total Import: {{ energy().totalElectricityKw }} kW</p>
        </div>

        <div class="bg-[#181b22] border border-white/10 p-4 rounded-2xl">
          <div class="text-xs text-slate-400 uppercase font-mono">Alt Fuel Substitution</div>
          <div class="text-xl font-bold text-emerald-400 font-mono mt-1 tabular-nums">{{ energy().alternativeFuelThermalSubPercent }} %</div>
          <p class="text-[10px] text-slate-500 mt-1 font-mono">RDF, Tires, Biomass</p>
        </div>

        <div class="bg-[#181b22] border border-white/10 p-4 rounded-2xl">
          <div class="text-xs text-slate-400 uppercase font-mono">Waste Heat Recovery</div>
          <div class="text-xl font-bold text-cyan-400 font-mono mt-1 tabular-nums">{{ energy().wasteHeatRecoveryKw }} kW</div>
          <p class="text-[10px] text-slate-500 mt-1 font-mono">Preheater + Cooler Boilers</p>
        </div>
      </div>

      <!-- DECARBONISATION LAB & WHAT-IF SIMULATOR -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <!-- Controls Panel -->
        <div class="bg-[#181b22] border border-white/10 p-5 rounded-2xl shadow-xl">
          <h3 class="text-sm font-bold text-slate-100 mb-4 flex items-center gap-2">
            <span class="material-icons text-emerald-400 text-base">sliders</span>
            DECARBONISATION SCENARIO CONTROLS
          </h3>

          <div class="space-y-4 text-xs font-mono">
            <!-- Alt Fuel % -->
            <div>
              <div class="flex justify-between mb-1">
                <span class="text-slate-300">Alternative Fuel Substitution (RDF/Biomass)</span>
                <span class="text-amber-400 font-bold">{{ altFuelSub() }} %</span>
              </div>
              <input type="range" min="10" max="85" step="5" [value]="altFuelSub()" (input)="altFuelSub.set(+($any($event.target).value))" class="w-full accent-amber-500 cursor-pointer"/>
            </div>

            <!-- SCM Clinker Substitution % -->
            <div>
              <div class="flex justify-between mb-1">
                <span class="text-slate-300">SCM Addition Ratio (GGBS Slag / Calcined Clay)</span>
                <span class="text-blue-400 font-bold">{{ scmSub() }} %</span>
              </div>
              <input type="range" min="5" max="60" step="5" [value]="scmSub()" (input)="scmSub.set(+($any($event.target).value))" class="w-full accent-blue-500 cursor-pointer"/>
            </div>

            <!-- Carbon Capture % -->
            <div>
              <div class="flex justify-between mb-1">
                <span class="text-slate-300">Aethelgard CCUS Amine Carbon Capture</span>
                <span class="text-purple-400 font-bold">{{ ccusRate() }} %</span>
              </div>
              <input type="range" min="0" max="90" step="10" [value]="ccusRate()" (input)="ccusRate.set(+($any($event.target).value))" class="w-full accent-purple-500 cursor-pointer"/>
            </div>
          </div>
        </div>

        <!-- Calculated Decarbonisation Results -->
        <div class="bg-[#181b22] border border-white/10 p-5 rounded-2xl shadow-xl flex flex-col justify-between">
          <div>
            <h3 class="text-sm font-bold text-slate-100 mb-4 flex items-center gap-2">
              <span class="material-icons text-purple-400 text-base">insights</span>
              PROJECTED DECARBONISATION IMPACT
            </h3>

            <div class="space-y-3 font-mono text-xs">
              <div class="p-3 bg-[#202530] rounded-xl border border-white/5 flex justify-between items-center">
                <span class="text-slate-300">Projected Cement CO2 Intensity:</span>
                <span class="text-base font-bold text-emerald-400">{{ simulatedIntensity() }} kg CO2/t</span>
              </div>

              <div class="p-3 bg-[#202530] rounded-xl border border-white/5 flex justify-between items-center">
                <span class="text-slate-300">Annual CO2 Reduction vs Baseline:</span>
                <span class="text-base font-bold text-purple-400">{{ annualSavingsTonne().toLocaleString() }} t CO2/yr</span>
              </div>

              <div class="p-3 bg-[#202530] rounded-xl border border-white/5 flex justify-between items-center">
                <span class="text-slate-300">UK ETS Carbon Tax Cost Impact:</span>
                <span class="text-base font-bold text-blue-400">- £{{ carbonTaxSavingsGbp().toLocaleString() }} / yr</span>
              </div>
            </div>
          </div>

          <div class="pt-4 border-t border-white/10 text-[11px] text-slate-400 font-mono">
            *Assumes UK ETS allowance price of £78/t CO2 and 330 operational days/year.
          </div>
        </div>
      </div>
    </div>
  `
})
export class EnergyEmissionsViewComponent {
  private twin = inject(CementTwinService);

  readonly energy = this.twin.energyMetrics;
  readonly emissions = this.twin.emissionsMetrics;

  // Interactive Scenario Sliders
  readonly altFuelSub = signal<number>(35);
  readonly scmSub = signal<number>(15);
  readonly ccusRate = signal<number>(0);

  readonly simulatedIntensity = computed(() => {
    const base = 685;
    const altReduction = (this.altFuelSub() - 35) * 1.8;
    const scmReduction = (this.scmSub() - 15) * 4.2;
    const ccusReduction = (this.ccusRate() / 100) * 400;

    return Math.max(80, Math.round(base - altReduction - scmReduction - ccusReduction));
  });

  readonly annualSavingsTonne = computed(() => {
    const deltaKgT = 685 - this.simulatedIntensity();
    const annualTonnage = 850000; // 850k tonnes cement/yr
    return Math.max(0, Math.round((deltaKgT * annualTonnage) / 1000));
  });

  readonly carbonTaxSavingsGbp = computed(() => {
    return this.annualSavingsTonne() * 78; // £78/t CO2
  });
}
