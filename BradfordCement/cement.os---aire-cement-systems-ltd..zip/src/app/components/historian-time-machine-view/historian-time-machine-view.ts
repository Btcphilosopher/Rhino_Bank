import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CementTwinService } from '../../services/cement-twin.service';

@Component({
  selector: 'app-historian-time-machine-view',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="w-full h-full bg-[#111317] p-6 overflow-y-auto text-slate-200">
      <!-- Header -->
      <div class="flex items-center justify-between pb-4 border-b border-white/10 mb-6">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono px-2 py-0.5 bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded">HISTORIAN & TIME MACHINE</span>
            <h1 class="text-xl font-bold text-white tracking-tight">PLANT HISTORIAN TIME-SERIES & REPLAY</h1>
          </div>
          <p class="text-xs text-slate-400 mt-1 font-mono">100,000+ Operational Telemetry Records · Fault Injection · Time Machine Replay</p>
        </div>

        <!-- Simulation Speed Multiplier Buttons -->
        <div class="flex items-center gap-2 font-mono text-xs">
          <span class="text-slate-400">SPEED:</span>
          <button (click)="setSpeed(1)" [class]="simSpeed() === 1 ? 'bg-amber-500 text-black font-bold' : 'bg-[#181b22] text-slate-300 border border-white/10'" class="px-2.5 py-1 rounded-lg">1x</button>
          <button (click)="setSpeed(10)" [class]="simSpeed() === 10 ? 'bg-amber-500 text-black font-bold' : 'bg-[#181b22] text-slate-300 border border-white/10'" class="px-2.5 py-1 rounded-lg">10x</button>
          <button (click)="setSpeed(100)" [class]="simSpeed() === 100 ? 'bg-amber-500 text-black font-bold' : 'bg-[#181b22] text-slate-300 border border-white/10'" class="px-2.5 py-1 rounded-lg">100x</button>
          <button (click)="setSpeed(1000)" [class]="simSpeed() === 1000 ? 'bg-amber-500 text-black font-bold' : 'bg-[#181b22] text-slate-300 border border-white/10'" class="px-2.5 py-1 rounded-lg">1000x</button>
        </div>
      </div>

      <!-- TIME MACHINE SCRUBBER BAR -->
      <div class="bg-[#181b22] border border-white/10 rounded-2xl p-4 mb-6 shadow-xl">
        <div class="flex items-center justify-between mb-2 text-xs font-mono">
          <span class="text-amber-400 font-bold flex items-center gap-1.5">
            <span class="material-icons text-sm">schedule</span>
            CURRENT REPLAY TIMESTAMP: {{ currentTimestampStr() }}
          </span>
          <span class="text-slate-400">06:00:00 — 10:00:00</span>
        </div>

        <input
          type="range"
          min="0"
          max="240"
          [value]="getTimeMinutesOffset()"
          (input)="onScrubberChange($event)"
          class="w-full accent-amber-500 cursor-pointer"
        />
      </div>

      <!-- MULTI-SENSOR HISTORIAN TREND CHARTS -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <!-- Chart 1: Burning Zone Temp -->
        <div class="bg-[#181b22] border border-white/10 p-5 rounded-2xl shadow-xl">
          <div class="flex justify-between items-center mb-3">
            <span class="text-xs font-bold text-slate-200 font-mono">KILN-01 BURNING ZONE TEMP (°C)</span>
            <span class="text-amber-400 font-mono text-xs font-bold">{{ kiln().burningZoneTempC }} °C</span>
          </div>

          <div class="h-44 bg-[#111317] rounded-xl border border-white/5 p-2 flex items-end gap-1">
            @for (p of historianData(); track p.timestamp) {
              <div
                class="flex-1 bg-amber-500/80 hover:bg-amber-400 rounded-t transition-all"
                [style.height.%]="((p.burningZoneTempC - 1350) / 150) * 100"
                [title]="p.timestamp + ': ' + p.burningZoneTempC + ' °C'"
              ></div>
            }
          </div>
        </div>

        <!-- Chart 2: CMILL-02 Vibration -->
        <div class="bg-[#181b22] border border-white/10 p-5 rounded-2xl shadow-xl">
          <div class="flex justify-between items-center mb-3">
            <span class="text-xs font-bold text-slate-200 font-mono">CMILL-02 DRIVE VIBRATION (mm/s)</span>
            <span [class]="cmill2().vibrationMmS > 6.0 ? 'text-red-400 font-bold' : 'text-emerald-400'" class="font-mono text-xs">
              {{ cmill2().vibrationMmS }} mm/s
            </span>
          </div>

          <div class="h-44 bg-[#111317] rounded-xl border border-white/5 p-2 flex items-end gap-1">
            @for (p of historianData(); track p.timestamp) {
              <div
                class="flex-1 transition-all rounded-t"
                [class]="p.mill2VibrationMmS > 6.0 ? 'bg-red-500' : 'bg-emerald-500/80'"
                [style.height.%]="(p.mill2VibrationMmS / 8.0) * 100"
                [title]="p.timestamp + ': ' + p.mill2VibrationMmS + ' mm/s'"
              ></div>
            }
          </div>
        </div>
      </div>
    </div>
  `
})
export class HistorianTimeMachineViewComponent {
  private twin = inject(CementTwinService);

  readonly simSpeed = this.twin.simSpeedMultiplier;
  readonly historianData = this.twin.historianData;
  readonly kiln = this.twin.rotaryKilnState;
  readonly cmill2 = this.twin.cementMill2State;

  readonly currentTimestampStr = () => this.twin.currentTimestamp().toTimeString().substring(0, 8);

  setSpeed(mult: number) {
    this.twin.setSimSpeed(mult);
  }

  getTimeMinutesOffset(): number {
    const start = new Date('2026-09-30T06:00:00').getTime();
    const curr = this.twin.currentTimestamp().getTime();
    return Math.max(0, Math.min(240, Math.floor((curr - start) / 60000)));
  }

  onScrubberChange(e: Event) {
    const mins = Number((e.target as HTMLInputElement).value);
    const start = new Date('2026-09-30T06:00:00').getTime();
    const target = new Date(start + mins * 60000);
    this.twin.currentTimestamp.set(target);
  }
}
