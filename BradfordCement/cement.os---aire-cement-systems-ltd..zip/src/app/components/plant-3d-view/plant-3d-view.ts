import { Component, ElementRef, ViewChild, AfterViewInit, OnDestroy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CementTwinService } from '../../services/cement-twin.service';
import * as THREE from 'three';

@Component({
  selector: 'app-plant-3d-view',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="relative w-full h-full bg-[#0d0f12] overflow-hidden flex flex-col select-none">
      <!-- 3D Canvas Area -->
      <div #canvasContainer class="relative w-full flex-1 cursor-grab active:cursor-grabbing">
        <!-- Overlay Camera Controls & Mode Selector -->
        <div class="absolute top-4 left-4 z-10 flex flex-wrap gap-2 bg-[#181b22]/90 backdrop-blur border border-white/10 p-2 rounded-xl text-xs shadow-xl">
          <span class="text-slate-400 font-mono self-center px-2 font-semibold">CAMERA PRESETS:</span>
          <button (click)="setCameraPreset('OVERVIEW')" [class]="activeCameraPreset() === 'OVERVIEW' ? 'bg-amber-500 text-black font-semibold' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'" class="px-3 py-1.5 rounded-lg transition-colors">
            Plant Overview
          </button>

          <button (click)="setCameraPreset('PYROPROCESS')" [class]="activeCameraPreset() === 'PYROPROCESS' ? 'bg-amber-500 text-black font-semibold' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'" class="px-3 py-1.5 rounded-lg transition-colors">
            Kiln & Preheater
          </button>

          <button (click)="setCameraPreset('RAW_MILL')" [class]="activeCameraPreset() === 'RAW_MILL' ? 'bg-amber-500 text-black font-semibold' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'" class="px-3 py-1.5 rounded-lg transition-colors">
            Raw Mill
          </button>

          <button (click)="setCameraPreset('CEMENT_MILLS')" [class]="activeCameraPreset() === 'CEMENT_MILLS' ? 'bg-amber-500 text-black font-semibold' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'" class="px-3 py-1.5 rounded-lg transition-colors">
            Cement Mills
          </button>

          <button (click)="setCameraPreset('DISPATCH')" [class]="activeCameraPreset() === 'DISPATCH' ? 'bg-amber-500 text-black font-semibold' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'" class="px-3 py-1.5 rounded-lg transition-colors">
            Silos & Dispatch
          </button>
        </div>

        <!-- Render Modes Overlay -->
        <div class="absolute top-4 right-4 z-10 flex gap-2 bg-[#181b22]/90 backdrop-blur border border-white/10 p-2 rounded-xl text-xs shadow-xl">
          <button (click)="setRenderMode('REALISTIC')" [class]="activeRenderMode() === 'REALISTIC' ? 'bg-emerald-500 text-black font-semibold' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'" class="px-3 py-1.5 rounded-lg transition-colors">
            Standard 3D
          </button>

          <button (click)="setRenderMode('THERMAL')" [class]="activeRenderMode() === 'THERMAL' ? 'bg-orange-500 text-white font-semibold' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'" class="px-3 py-1.5 rounded-lg transition-colors">
            Thermal Heatmap
          </button>

          <button (click)="setRenderMode('MECHANICAL')" [class]="activeRenderMode() === 'MECHANICAL' ? 'bg-blue-500 text-white font-semibold' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'" class="px-3 py-1.5 rounded-lg transition-colors">
            Vibration Health
          </button>
        </div>

        <!-- Selected Object Interactive Badge -->
        @if (hoveredAssetName()) {
          <div class="absolute bottom-6 left-6 z-10 bg-[#181b22]/95 border border-amber-500/50 p-3 rounded-xl text-xs shadow-2xl backdrop-blur max-w-sm pointer-events-none animate-fadeIn">
            <div class="flex items-center gap-2 text-amber-400 font-semibold mb-1">
              <span class="material-icons text-sm">precision_manufacturing</span>
              <span>{{ hoveredAssetName() }}</span>
            </div>
            <p class="text-slate-300 font-mono text-[11px]">Click to inspect computational engineering state in detail panel.</p>
          </div>
        }

        <!-- 3D Hint -->
        <div class="absolute bottom-6 right-6 z-10 text-[11px] text-slate-400 font-mono bg-black/60 px-3 py-1.5 rounded-lg border border-white/10 backdrop-blur">
          <span>Click + Drag to rotate | Scroll to zoom | Click asset to inspect</span>
        </div>
      </div>
    </div>
  `
})
export class Plant3dViewComponent implements AfterViewInit, OnDestroy {
  @ViewChild('canvasContainer', { static: true }) canvasContainer!: ElementRef<HTMLDivElement>;

  private twinService = inject(CementTwinService);

  readonly activeCameraPreset = signal<'OVERVIEW' | 'PYROPROCESS' | 'RAW_MILL' | 'CEMENT_MILLS' | 'DISPATCH'>('OVERVIEW');
  readonly activeRenderMode = signal<'REALISTIC' | 'THERMAL' | 'MECHANICAL'>('REALISTIC');
  readonly hoveredAssetName = signal<string | null>(null);

  // Three.js instances
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private animFrameId!: number;

  // Key mesh objects for dynamic animation
  private kilnMesh!: THREE.Mesh;
  private preheaterTowerGroup!: THREE.Group;
  private materialParticles!: THREE.Points;

  // Mouse Orbit controls state
  private isMouseDown = false;
  private mousePrevX = 0;
  private mousePrevY = 0;
  private cameraSpherical = { radius: 180, theta: Math.PI / 4, phi: Math.PI / 3 };
  private cameraTarget = new THREE.Vector3(0, 15, 0);

  ngAfterViewInit() {
    this.initThree();
    this.buildBradfordPlant3D();
    this.animate();
    this.setupEventListeners();
  }

  ngOnDestroy() {
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
  }

  private initThree() {
    const container = this.canvasContainer.nativeElement;
    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || 600;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0d0f12);
    this.scene.fog = new THREE.FogExp2(0x0d0f12, 0.0035);

    this.camera = new THREE.PerspectiveCamera(45, width / height, 1, 1000);
    this.updateCameraPosition();

    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.appendChild(this.renderer.domElement);

    // Industrial Lighting Setup
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    this.scene.add(ambientLight);

    const sunLight = new THREE.DirectionalLight(0xfff5ea, 1.2);
    sunLight.position.set(120, 180, 80);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.width = 2048;
    sunLight.shadow.mapSize.height = 2048;
    sunLight.shadow.camera.near = 10;
    sunLight.shadow.camera.far = 400;
    const d = 150;
    sunLight.shadow.camera.left = -d;
    sunLight.shadow.camera.right = d;
    sunLight.shadow.camera.top = d;
    sunLight.shadow.camera.bottom = -d;
    this.scene.add(sunLight);

    // Subtle blue fill light
    const fillLight = new THREE.DirectionalLight(0x8090b0, 0.4);
    fillLight.position.set(-100, 80, -100);
    this.scene.add(fillLight);
  }

  private buildBradfordPlant3D() {
    // 1. Site Ground Slab & Yorkshire Wall Frame
    const groundGeo = new THREE.PlaneGeometry(320, 240);
    const groundMat = new THREE.MeshStandardMaterial({ color: 0x1f242d, roughness: 0.9, metalness: 0.1 });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    this.scene.add(ground);

    // Grid helper for industrial engineering feel
    const grid = new THREE.GridHelper(320, 32, 0x3a4252, 0x222733);
    grid.position.y = 0.1;
    this.scene.add(grid);

    // Yorkshire Stone Perimeter Walls
    const wallMat = new THREE.MeshStandardMaterial({ color: 0x4a4640, roughness: 0.95 });
    const wallNorth = new THREE.Mesh(new THREE.BoxGeometry(320, 4, 3), wallMat);
    wallNorth.position.set(0, 2, -120);
    this.scene.add(wallNorth);

    // 2. PREHEATER TOWER (Massive 5-stage cyclone tower - Signature Structure)
    this.preheaterTowerGroup = new THREE.Group();
    const towerSteelMat = new THREE.MeshStandardMaterial({ color: 0x2e3542, metalness: 0.7, roughness: 0.4 });
    const cycloneMat = new THREE.MeshStandardMaterial({ color: 0x5a6270, metalness: 0.6, roughness: 0.3 });

    // 4 Corner Steel Columns
    const colGeo = new THREE.BoxGeometry(2, 65, 2);
    [
      [-12, -12], [12, -12], [-12, 12], [12, 12]
    ].forEach(([x, z]) => {
      const col = new THREE.Mesh(colGeo, towerSteelMat);
      col.position.set(x, 32.5, z);
      col.castShadow = true;
      this.preheaterTowerGroup.add(col);
    });

    // 5 Stages of Cyclones
    for (let stage = 1; stage <= 5; stage++) {
      const y = stage * 11 + 5;
      const cycloneGeo = new THREE.CylinderGeometry(4.5, 1.5, 7, 16);
      const cyclone = new THREE.Mesh(cycloneGeo, cycloneMat);
      cyclone.position.set(0, y, 0);
      cyclone.castShadow = true;
      this.preheaterTowerGroup.add(cyclone);

      // Floor platform
      const platGeo = new THREE.BoxGeometry(26, 0.8, 26);
      const plat = new THREE.Mesh(platGeo, towerSteelMat);
      plat.position.set(0, y - 4, 0);
      this.preheaterTowerGroup.add(plat);
    }
    this.preheaterTowerGroup.position.set(-60, 0, 0);
    this.scene.add(this.preheaterTowerGroup);

    // 3. ROTARY KILN (68m long cylinder, inclined 3.5°)
    const kilnGroup = new THREE.Group();

    // Kiln Shell Mesh with emissive hot burning zone
    const kilnGeo = new THREE.CylinderGeometry(3.2, 3.2, 70, 32);
    const kilnMat = new THREE.MeshStandardMaterial({
      color: 0x383e4a,
      metalness: 0.8,
      roughness: 0.3,
      emissive: 0xff3d00,
      emissiveIntensity: 0.25
    });
    this.kilnMesh = new THREE.Mesh(kilnGeo, kilnMat);
    this.kilnMesh.rotation.z = Math.PI / 2 - 0.06; // inclined
    this.kilnMesh.position.set(0, 14, 0);
    this.kilnMesh.castShadow = true;
    kilnGroup.add(this.kilnMesh);

    // 3 Support Piers (Concrete foundations)
    const pierMat = new THREE.MeshStandardMaterial({ color: 0x6b7280, roughness: 0.8 });
    [-25, 0, 25].forEach(x => {
      const pier = new THREE.Mesh(new THREE.BoxGeometry(6, 12, 8), pierMat);
      pier.position.set(x, 6, 0);
      pier.castShadow = true;
      kilnGroup.add(pier);

      // Riding Ring (Riding tyre)
      const ringGeo = new THREE.TorusGeometry(3.6, 0.8, 16, 32);
      const ringMat = new THREE.MeshStandardMaterial({ color: 0x1a1a1a, metalness: 0.9, roughness: 0.1 });
      const ring = new THREE.Mesh(ringGeo, ringMat);
      ring.position.set(x, 14 - x * 0.06, 0);
      ring.rotation.y = Math.PI / 2;
      kilnGroup.add(ring);
    });

    this.scene.add(kilnGroup);

    // 4. CLINKER COOLER BUILDING
    const coolerBuildingGeo = new THREE.BoxGeometry(28, 12, 18);
    const coolerBuildingMat = new THREE.MeshStandardMaterial({ color: 0x2b313d, roughness: 0.6 });
    const coolerBuilding = new THREE.Mesh(coolerBuildingGeo, coolerBuildingMat);
    coolerBuilding.position.set(45, 6, 0);
    coolerBuilding.castShadow = true;
    this.scene.add(coolerBuilding);

    // 5. RAW MEAL SILOS & CLINKER SILOS (Cylindrical Concrete Towers)
    const siloMat = new THREE.MeshStandardMaterial({ color: 0x828a99, roughness: 0.7 });

    // Raw Meal Silos (2 towers near preheater)
    [-75, -75].forEach((x, idx) => {
      const z = idx === 0 ? -25 : 25;
      const silo = new THREE.Mesh(new THREE.CylinderGeometry(7, 7, 38, 24), siloMat);
      silo.position.set(x, 19, z);
      silo.castShadow = true;
      this.scene.add(silo);
    });

    // Clinker Silos (2 large towers after cooler)
    [70, 70].forEach((x, idx) => {
      const z = idx === 0 ? -25 : 25;
      const silo = new THREE.Mesh(new THREE.CylinderGeometry(9, 9, 45, 24), siloMat);
      silo.position.set(x, 22.5, z);
      silo.castShadow = true;
      this.scene.add(silo);
    });

    // 6. RAW MILL & CEMENT MILLS BUILDINGS
    const millBuildingMat = new THREE.MeshStandardMaterial({ color: 0x3d4452, roughness: 0.5, metalness: 0.3 });

    // Raw Mill Building
    const rawMillBldg = new THREE.Mesh(new THREE.BoxGeometry(30, 20, 24), millBuildingMat);
    rawMillBldg.position.set(-60, 10, -50);
    rawMillBldg.castShadow = true;
    this.scene.add(rawMillBldg);

    // Cement Mills Building (Housing VRM & Ball Mill)
    const cementMillBldg = new THREE.Mesh(new THREE.BoxGeometry(45, 22, 28), millBuildingMat);
    cementMillBldg.position.set(100, 11, -30);
    cementMillBldg.castShadow = true;
    this.scene.add(cementMillBldg);

    // 7. EXHAUST STACK (Tall thin chimney with plume)
    const stackGeo = new THREE.CylinderGeometry(2, 3.5, 75, 20);
    const stackMat = new THREE.MeshStandardMaterial({ color: 0x22262e, metalness: 0.8 });
    const stack = new THREE.Mesh(stackGeo, stackMat);
    stack.position.set(-85, 37.5, 50);
    stack.castShadow = true;
    this.scene.add(stack);

    // 8. MATERIAL FLOW PARTICLES
    const particleCount = 120;
    const particleGeo = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount; i++) {
      positions[i * 3] = -90 + (i / particleCount) * 190;
      positions[i * 3 + 1] = 14 + Math.sin(i) * 2;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 4;
    }

    particleGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const particleMat = new THREE.PointsMaterial({
      color: 0xf59e0b,
      size: 1.8,
      transparent: true,
      opacity: 0.8
    });
    this.materialParticles = new THREE.Points(particleGeo, particleMat);
    this.scene.add(this.materialParticles);
  }

  private animate() {
    this.animFrameId = requestAnimationFrame(() => this.animate());

    // Rotate Rotary Kiln
    if (this.kilnMesh && this.twinService.isSimulating()) {
      this.kilnMesh.rotation.x += 0.015 * this.twinService.simSpeedMultiplier();
    }

    // Animate particles along material stream
    if (this.materialParticles) {
      const positions = this.materialParticles.geometry.attributes['position'].array as Float32Array;
      for (let i = 0; i < positions.length / 3; i++) {
        positions[i * 3] += 0.25 * this.twinService.simSpeedMultiplier();
        if (positions[i * 3] > 100) {
          positions[i * 3] = -90;
        }
      }
      this.materialParticles.geometry.attributes['position'].needsUpdate = true;
    }

    this.renderer.render(this.scene, this.camera);
  }

  private setupEventListeners() {
    const container = this.canvasContainer.nativeElement;

    window.addEventListener('resize', () => {
      const w = container.clientWidth;
      const h = container.clientHeight;
      if (w && h) {
        this.camera.aspect = w / h;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(w, h);
      }
    });

    container.addEventListener('mousedown', (e) => {
      this.isMouseDown = true;
      this.mousePrevX = e.clientX;
      this.mousePrevY = e.clientY;
    });

    window.addEventListener('mouseup', () => {
      this.isMouseDown = false;
    });

    container.addEventListener('mousemove', (e) => {
      if (!this.isMouseDown) return;

      const deltaX = e.clientX - this.mousePrevX;
      const deltaY = e.clientY - this.mousePrevY;
      this.mousePrevX = e.clientX;
      this.mousePrevY = e.clientY;

      this.cameraSpherical.theta -= deltaX * 0.005;
      this.cameraSpherical.phi = Math.max(0.1, Math.min(Math.PI / 2 - 0.05, this.cameraSpherical.phi - deltaY * 0.005));

      this.updateCameraPosition();
    });

    container.addEventListener('wheel', (e) => {
      e.preventDefault();
      this.cameraSpherical.radius = Math.max(30, Math.min(300, this.cameraSpherical.radius + e.deltaY * 0.1));
      this.updateCameraPosition();
    });
  }

  private updateCameraPosition() {
    const { radius, theta, phi } = this.cameraSpherical;
    this.camera.position.x = this.cameraTarget.x + radius * Math.sin(phi) * Math.cos(theta);
    this.camera.position.y = this.cameraTarget.y + radius * Math.cos(phi);
    this.camera.position.z = this.cameraTarget.z + radius * Math.sin(phi) * Math.sin(theta);
    this.camera.lookAt(this.cameraTarget);
  }

  setCameraPreset(preset: 'OVERVIEW' | 'PYROPROCESS' | 'RAW_MILL' | 'CEMENT_MILLS' | 'DISPATCH') {
    this.activeCameraPreset.set(preset);
    switch (preset) {
      case 'OVERVIEW':
        this.cameraTarget.set(0, 15, 0);
        this.cameraSpherical = { radius: 180, theta: Math.PI / 4, phi: Math.PI / 3 };
        break;
      case 'PYROPROCESS':
        this.cameraTarget.set(-20, 20, 0);
        this.cameraSpherical = { radius: 90, theta: Math.PI / 3, phi: Math.PI / 3.5 };
        this.twinService.selectedAssetId.set('KILN-01');
        break;
      case 'RAW_MILL':
        this.cameraTarget.set(-60, 12, -40);
        this.cameraSpherical = { radius: 65, theta: Math.PI / 5, phi: Math.PI / 3 };
        this.twinService.selectedAssetId.set('RMILL-01');
        break;
      case 'CEMENT_MILLS':
        this.cameraTarget.set(100, 12, -25);
        this.cameraSpherical = { radius: 70, theta: Math.PI / 3, phi: Math.PI / 3.2 };
        this.twinService.selectedAssetId.set('CMILL-02');
        break;
      case 'DISPATCH':
        this.cameraTarget.set(70, 20, 20);
        this.cameraSpherical = { radius: 85, theta: Math.PI / 2.5, phi: Math.PI / 3.5 };
        break;
    }
    this.updateCameraPosition();
  }

  setRenderMode(mode: 'REALISTIC' | 'THERMAL' | 'MECHANICAL') {
    this.activeRenderMode.set(mode);
    if (!this.kilnMesh) return;

    const mat = this.kilnMesh.material as THREE.MeshStandardMaterial;
    if (mode === 'THERMAL') {
      mat.color.setHex(0xd97706);
      mat.emissive.setHex(0xef4444);
      mat.emissiveIntensity = 0.8;
    } else if (mode === 'MECHANICAL') {
      mat.color.setHex(0x3b82f6);
      mat.emissive.setHex(0x1d4ed8);
      mat.emissiveIntensity = 0.4;
    } else {
      mat.color.setHex(0x383e4a);
      mat.emissive.setHex(0xff3d00);
      mat.emissiveIntensity = 0.25;
    }
  }
}
