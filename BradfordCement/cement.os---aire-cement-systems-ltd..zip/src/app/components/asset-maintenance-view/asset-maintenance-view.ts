import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CementTwinService } from '../../services/cement-twin.service';
import { PlantAsset } from '../../models/cement-process.models';

@Component({
  selector: 'app-asset-maintenance-view',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="w-full h-full bg-[#111317] p-6 overflow-y-auto text-slate-200">
      <!-- Header -->
      <div class="flex items-center justify-between pb-4 border-b border-white/10 mb-6">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono px-2 py-0.5 bg-blue-500/20 text-blue-400 border border-blue-500/30 rounded">CONDITION MONITORING</span>
            <h1 class="text-xl font-bold text-white tracking-tight">PLANT ASSET HIERARCHY & PREDICTIVE MAINTENANCE</h1>
          </div>
          <p class="text-xs text-slate-400 mt-1 font-mono">Vibration FFT Analysis · Bearing Thermal Telemetry · Work Order Dispatch</p>
        </div>

        <div class="flex items-center gap-3">
          <button (click)="injectVibrationFault()" class="px-3.5 py-1.5 bg-red-600/80 hover:bg-red-500 text-white rounded-xl text-xs font-bold transition-all border border-red-500/40 font-mono">
            INJECT CM-02 VIBRATION FAULT
          </button>
        </div>
      </div>

      <!-- Main Layout: Asset List + Selected Asset Detail Drawer -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Asset List (2 Columns) -->
        <div class="lg:col-span-2 space-y-3">
          @for (asset of assets(); track asset.id) {
            <div
              tabindex="0"
              (click)="selectAsset(asset.id)"
              (keyup.enter)="selectAsset(asset.id)"
              [class]="selectedId() === asset.id ? 'border-amber-500 bg-[#202532]' : 'border-white/10 bg-[#181b22] hover:bg-[#1f232d]'"
              class="p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between shadow-lg focus:outline-none focus:ring-1 focus:ring-amber-500"
            >
              <div class="flex items-center gap-4">
                <div [class]="getConditionBadgeClass(asset.condition)" class="w-10 h-10 rounded-xl flex items-center justify-center">
                  <span class="material-icons text-lg">settings</span>
                </div>

                <div>
                  <div class="flex items-center gap-2">
                    <span class="text-xs font-mono text-amber-400 font-bold">{{ asset.id }}</span>
                    <h3 class="text-sm font-bold text-white">{{ asset.name }}</h3>
                  </div>
                  <p class="text-xs text-slate-400 font-mono mt-0.5">{{ asset.manufacturer }} {{ asset.model }} · {{ asset.operatingHours.toLocaleString() }} hrs</p>
                </div>
              </div>

              <div class="flex items-center gap-6 font-mono text-xs text-right">
                <div>
                  <div class="text-[10px] text-slate-400">Vibration</div>
                  <div [class]="asset.vibrationMmS > 6.0 ? 'text-red-400 font-bold animate-pulse' : 'text-slate-200'" class="font-bold">
                    {{ asset.vibrationMmS }} mm/s
                  </div>
                </div>

                <div>
                  <div class="text-[10px] text-slate-400">Bearing Temp</div>
                  <div class="font-bold text-slate-200">{{ asset.bearingTempC }} °C</div>
                </div>

                <div>
                  <div class="text-[10px] text-slate-400">Health</div>
                  <div class="font-bold text-emerald-400">{{ asset.healthScorePercent }}%</div>
                </div>
              </div>
            </div>
          }
        </div>

        <!-- Selected Asset Inspector Drawer -->
        @if (selectedAsset()) {
          <div class="bg-[#181b22] border border-white/10 rounded-2xl p-5 shadow-2xl flex flex-col justify-between h-fit">
            <div>
              <div class="flex items-center justify-between border-b border-white/10 pb-3 mb-4">
                <div>
                  <span class="text-xs font-mono text-amber-400 font-bold">{{ selectedAsset()?.id }}</span>
                  <h2 class="text-base font-bold text-white">{{ selectedAsset()?.name }}</h2>
                </div>
                <span [class]="getConditionBadgeClass(selectedAsset()?.condition!)" class="px-2.5 py-1 rounded text-[10px] font-bold font-mono">
                  {{ selectedAsset()?.condition }}
                </span>
              </div>

              <!-- Technical Specifications -->
              <div class="space-y-3 font-mono text-xs mb-6">
                <div class="flex justify-between py-1.5 border-b border-white/5">
                  <span class="text-slate-400">Manufacturer</span>
                  <span class="text-white font-semibold">{{ selectedAsset()?.manufacturer }}</span>
                </div>

                <div class="flex justify-between py-1.5 border-b border-white/5">
                  <span class="text-slate-400">Model</span>
                  <span class="text-white font-semibold">{{ selectedAsset()?.model }}</span>
                </div>

                <div class="flex justify-between py-1.5 border-b border-white/5">
                  <span class="text-slate-400">Commissioned</span>
                  <span class="text-white font-semibold">{{ selectedAsset()?.commissioningYear }}</span>
                </div>

                <div class="flex justify-between py-1.5 border-b border-white/5">
                  <span class="text-slate-400">Rated Capacity</span>
                  <span class="text-amber-400 font-semibold">{{ selectedAsset()?.ratedCapacityTph }} t/h</span>
                </div>

                <div class="flex justify-between py-1.5 border-b border-white/5">
                  <span class="text-slate-400">Last Overhaul</span>
                  <span class="text-slate-300">{{ selectedAsset()?.lastMaintenanceDate }}</span>
                </div>
              </div>

              <!-- Diagnostic Analysis -->
              @if (selectedAsset()?.id === 'CMILL-02') {
                <div class="p-3.5 bg-red-950/40 border border-red-500/40 rounded-xl mb-4 text-xs font-mono">
                  <div class="text-red-400 font-bold flex items-center gap-1.5 mb-1">
                    <span class="material-icons text-sm">warning</span>
                    DIAGNOSTIC ALERTS
                  </div>
                  <p class="text-slate-300 text-[11px] leading-relaxed">
                    Drive pinion vibration exceeding ISO 10816 Class IV limit (6.0 mm/s). Trunnion roller bearing harmonic peak detected at 148 Hz.
                  </p>
                </div>
              }
            </div>

            <button (click)="createWorkOrder()" class="w-full py-2.5 bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs rounded-xl transition-all shadow-lg font-mono">
              RAISE SAP WORK ORDER
            </button>
          </div>
        }
      </div>
    </div>
  `
})
export class AssetMaintenanceViewComponent {
  private twin = inject(CementTwinService);

  readonly assets = this.twin.assetsList;
  readonly selectedId = this.twin.selectedAssetId;

  get selectedAsset(): () => PlantAsset | undefined {
    return () => this.assets().find(a => a.id === this.selectedId());
  }

  selectAsset(id: string) {
    this.twin.selectedAssetId.set(id);
  }

  getConditionBadgeClass(condition: string): string {
    switch (condition) {
      case 'NORMAL': return 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30';
      case 'WATCH': return 'bg-blue-500/20 text-blue-400 border border-blue-500/30';
      case 'DEGRADED': return 'bg-amber-500/20 text-amber-400 border border-amber-500/30';
      case 'HIGH RISK':
      case 'CRITICAL': return 'bg-red-500/20 text-red-400 border border-red-500/30';
      default: return 'bg-slate-800 text-slate-300';
    }
  }

  injectVibrationFault() {
    this.twin.selectedAssetId.set('CMILL-02');
    alert('Simulated CMILL-02 Ball Mill pinion bearing fault injected.');
  }

  createWorkOrder() {
    alert(`Work Order created for asset ${this.selectedId()}. Assigned to Bradford Engineering Maintenance Team.`);
  }
}
