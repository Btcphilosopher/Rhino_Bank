import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CementTwinService } from '../../services/cement-twin.service';

@Component({
  selector: 'app-pid-diagram-view',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="w-full h-full bg-[#111317] p-4 flex flex-col text-slate-200 overflow-auto select-none">
      <!-- P&ID Header -->
      <div class="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
        <div>
          <h2 class="text-base font-bold text-white flex items-center gap-2">
            <span class="material-icons text-amber-400">schema</span>
            AIRE CEMENT WORKS — PROCESS & INSTRUMENTATION DIAGRAM (P&ID)
          </h2>
          <p class="text-xs text-slate-400 font-mono">Drawing Ref: ACW-PID-2026-REV4 · Live Mass Balance & Process Telemetry</p>
        </div>
        <div class="flex items-center gap-4 text-xs font-mono">
          <div class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span> RUNNING</div>
          <div class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-full bg-amber-500"></span> ADVISORY</div>
          <div class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping"></span> ALARM HIGH</div>
        </div>
      </div>

      <!-- SVG Process Flow Diagram Container -->
      <div class="relative flex-1 bg-[#161922] border border-white/10 rounded-2xl p-6 overflow-x-auto min-w-[1100px]">
        <svg class="w-full h-[580px]" viewBox="0 0 1150 560">
          <defs>
            <linearGradient id="lineGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stop-color="#3b82f6"/>
              <stop offset="50%" stop-color="#f59e0b"/>
              <stop offset="100%" stop-color="#10b981"/>
            </linearGradient>
            <marker id="arrow" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
              <path d="M 0 0 L 10 5 L 0 10 z" fill="#f59e0b"/>
            </marker>
          </defs>

          <!-- CONNECTING PIPELINES -->
          <!-- Quarry -> Raw Mill -->
          <path d="M 110 120 L 220 120" stroke="#3b82f6" stroke-width="4" stroke-dasharray="6,4" class="animate-flow-dash" marker-end="url(#arrow)"/>
          
          <!-- Raw Mill -> Blending Silo -->
          <path d="M 330 120 L 420 120" stroke="#60a5fa" stroke-width="4" stroke-dasharray="6,4" class="animate-flow-dash" marker-end="url(#arrow)"/>

          <!-- Blending Silo -> Preheater Tower -->
          <path d="M 470 170 L 470 230 L 520 230" stroke="#fbbf24" stroke-width="4" stroke-dasharray="6,4" class="animate-flow-dash" marker-end="url(#arrow)"/>

          <!-- Preheater -> Kiln -->
          <path d="M 580 280 L 610 320" stroke="#f97316" stroke-width="5" stroke-dasharray="6,4" class="animate-flow-dash" marker-end="url(#arrow)"/>

          <!-- Kiln -> Cooler -->
          <path d="M 750 345 L 820 345" stroke="#ef4444" stroke-width="5" stroke-dasharray="6,4" class="animate-flow-dash" marker-end="url(#arrow)"/>

          <!-- Cooler -> Clinker Silo -->
          <path d="M 910 345 L 980 345" stroke="#10b981" stroke-width="4" stroke-dasharray="6,4" class="animate-flow-dash" marker-end="url(#arrow)"/>

          <!-- Clinker Silo -> Cement Mills -->
          <path d="M 1020 395 L 1020 480 L 760 480" stroke="#10b981" stroke-width="4" stroke-dasharray="6,4" class="animate-flow-dash" marker-end="url(#arrow)"/>

          <!-- Cement Mills -> Dispatch -->
          <path d="M 640 480 L 450 480" stroke="#34d399" stroke-width="4" stroke-dasharray="6,4" class="animate-flow-dash" marker-end="url(#arrow)"/>

          <!-- NODE 1: QUARRY & CRUSHER -->
          <g transform="translate(30, 70)" class="cursor-pointer group" (click)="selectAsset('QUARRY-01')">
            <rect width="80" height="100" rx="8" fill="#1f2430" stroke="#3b82f6" stroke-width="2" class="group-hover:stroke-amber-400 transition-colors"/>
            <text x="40" y="30" fill="#93c5fd" font-size="11" font-weight="bold" text-anchor="middle" font-family="monospace">QUARRY</text>
            <text x="40" y="48" fill="#e2e8f0" font-size="10" text-anchor="middle" font-family="monospace">Primary Jaw</text>
            <text x="40" y="70" fill="#fbbf24" font-size="12" font-weight="bold" text-anchor="middle" font-family="monospace">280 t/h</text>
            <text x="40" y="86" fill="#94a3b8" font-size="9" text-anchor="middle" font-family="monospace">Moisture 3.8%</text>
          </g>

          <!-- NODE 2: RAW MILL (RMILL-01) -->
          <g transform="translate(220, 60)" class="cursor-pointer group" (click)="selectAsset('RMILL-01')">
            <rect width="110" height="120" rx="10" fill="#1f2430" stroke="#60a5fa" stroke-width="2" class="group-hover:stroke-amber-400 transition-colors"/>
            <text x="55" y="25" fill="#60a5fa" font-size="11" font-weight="bold" text-anchor="middle" font-family="monospace">RMILL-01 (VRM)</text>
            <text x="55" y="50" fill="#38bdf8" font-size="13" font-weight="bold" text-anchor="middle" font-family="monospace">{{ rawMill().feedRateTph }} t/h</text>
            <text x="55" y="70" fill="#e2e8f0" font-size="10" text-anchor="middle" font-family="monospace">Power: {{ rawMill().motorPowerKw }} kW</text>
            <text x="55" y="86" fill="#e2e8f0" font-size="10" text-anchor="middle" font-family="monospace">DP: {{ rawMill().differentialPressureMbar }} mbar</text>
            <text x="55" y="102" fill="#a7f3d0" font-size="10" text-anchor="middle" font-family="monospace">{{ rawMill().specificEnergyKwhT }} kWh/t</text>
          </g>

          <!-- NODE 3: RAW MEAL SILO -->
          <g transform="translate(420, 80)" class="cursor-pointer group">
            <path d="M 10 0 L 50 0 L 60 70 L 30 90 L 0 70 Z" fill="#1f2430" stroke="#94a3b8" stroke-width="2"/>
            <text x="30" y="30" fill="#cbd5e1" font-size="10" font-weight="bold" text-anchor="middle" font-family="monospace">RAW MEAL</text>
            <text x="30" y="45" fill="#cbd5e1" font-size="10" text-anchor="middle" font-family="monospace">SILO 1-2</text>
            <text x="30" y="65" fill="#38bdf8" font-size="11" font-weight="bold" text-anchor="middle" font-family="monospace">8,450 t</text>
          </g>

          <!-- NODE 4: PREHEATER TOWER & PRECALCINER -->
          <g transform="translate(520, 160)" class="cursor-pointer group" (click)="selectAsset('PREHEATER-01')">
            <rect width="90" height="130" rx="8" fill="#1f2430" stroke="#fbbf24" stroke-width="2" class="group-hover:stroke-amber-400 transition-colors"/>
            <text x="45" y="25" fill="#fbbf24" font-size="11" font-weight="bold" text-anchor="middle" font-family="monospace">PREHEATER</text>
            <text x="45" y="42" fill="#e2e8f0" font-size="9" text-anchor="middle" font-family="monospace">5-Stage Cyclones</text>
            <text x="45" y="65" fill="#f97316" font-size="12" font-weight="bold" text-anchor="middle" font-family="monospace">Top: 325°C</text>
            <text x="45" y="82" fill="#ef4444" font-size="12" font-weight="bold" text-anchor="middle" font-family="monospace">Calciner: 960°C</text>
            <text x="45" y="102" fill="#a7f3d0" font-size="10" text-anchor="middle" font-family="monospace">Calc: {{ precalciner().calcinationDegreePercent }}%</text>
          </g>

          <!-- NODE 5: ROTARY KILN (KILN-01) -->
          <g transform="translate(610, 300)" class="cursor-pointer group" (click)="selectAsset('KILN-01')">
            <polygon points="0,10 140,25 140,65 0,50" fill="#291e1d" stroke="#f97316" stroke-width="3" class="group-hover:stroke-amber-400 transition-colors"/>
            <text x="70" y="32" fill="#f97316" font-size="12" font-weight="bold" text-anchor="middle" font-family="monospace">ROTARY KILN-01</text>
            <text x="70" y="48" fill="#fca5a5" font-size="11" font-weight="bold" text-anchor="middle" font-family="monospace">BZ: {{ kiln().burningZoneTempC }}°C</text>
            <text x="70" y="62" fill="#fed7aa" font-size="10" text-anchor="middle" font-family="monospace">Feed: {{ kiln().feedRateTph }} t/h | {{ kiln().rotationSpeedRpm }} RPM</text>
          </g>

          <!-- NODE 6: CLINKER COOLER (COOLER-01) -->
          <g transform="translate(820, 300)" class="cursor-pointer group" (click)="selectAsset('COOLER-01')">
            <rect width="90" height="90" rx="8" fill="#1f2430" stroke="#10b981" stroke-width="2" class="group-hover:stroke-amber-400 transition-colors"/>
            <text x="45" y="22" fill="#10b981" font-size="11" font-weight="bold" text-anchor="middle" font-family="monospace">COOLER-01</text>
            <text x="45" y="40" fill="#e2e8f0" font-size="10" text-anchor="middle" font-family="monospace">Sec Air: {{ cooler().secondaryAirTempC }}°C</text>
            <text x="45" y="58" fill="#e2e8f0" font-size="10" text-anchor="middle" font-family="monospace">Out: {{ cooler().clinkerOutTempC }}°C</text>
            <text x="45" y="76" fill="#a7f3d0" font-size="10" text-anchor="middle" font-family="monospace">Eff: {{ cooler().coolingEfficiencyPercent }}%</text>
          </g>

          <!-- NODE 7: CLINKER SILO -->
          <g transform="translate(980, 290)" class="cursor-pointer group">
            <path d="M 10 0 L 50 0 L 60 90 L 30 110 L 0 90 Z" fill="#1f2430" stroke="#10b981" stroke-width="2"/>
            <text x="30" y="30" fill="#a7f3d0" font-size="10" font-weight="bold" text-anchor="middle" font-family="monospace">CLINKER</text>
            <text x="30" y="45" fill="#a7f3d0" font-size="10" font-weight="bold" text-anchor="middle" font-family="monospace">SILO 1-2</text>
            <text x="30" y="70" fill="#34d399" font-size="11" font-weight="bold" text-anchor="middle" font-family="monospace">14,200 t</text>
          </g>

          <!-- NODE 8: CEMENT MILLS (CMILL-01 & CMILL-02) -->
          <g transform="translate(640, 440)" class="cursor-pointer group" (click)="selectAsset('CMILL-02')">
            <rect width="120" height="90" rx="8" fill="#1f2430" [attr.stroke]="cmill2().vibrationMmS > 6.0 ? '#ef4444' : '#34d399'" stroke-width="2.5" class="group-hover:stroke-amber-400 transition-colors"/>
            <text x="60" y="20" fill="#34d399" font-size="11" font-weight="bold" text-anchor="middle" font-family="monospace">CEMENT MILLS</text>
            <text x="60" y="38" fill="#e2e8f0" font-size="10" text-anchor="middle" font-family="monospace">CM-01 VRM: {{ cmill1().totalFeedTph }} t/h</text>
            <text x="60" y="54" fill="#e2e8f0" font-size="10" text-anchor="middle" font-family="monospace">CM-02 Ball: {{ cmill2().totalFeedTph }} t/h</text>

            @if (cmill2().vibrationMmS > 6.0) {
              <text x="60" y="74" fill="#ef4444" font-size="11" font-weight="bold" text-anchor="middle" font-family="monospace" class="animate-pulse">VIB: {{ cmill2().vibrationMmS }} mm/s!</text>
            } @else {
              <text x="60" y="74" fill="#a7f3d0" font-size="10" text-anchor="middle" font-family="monospace">Blaine: {{ cmill1().productBlaineCm2G }} cm²/g</text>
            }
          </g>

          <!-- NODE 9: PACKING & BULK DISPATCH -->
          <g transform="translate(330, 440)" class="cursor-pointer group">
            <rect width="120" height="90" rx="8" fill="#1f2430" stroke="#38bdf8" stroke-width="2"/>
            <text x="60" y="25" fill="#38bdf8" font-size="11" font-weight="bold" text-anchor="middle" font-family="monospace">DISPATCH & SILOS</text>
            <text x="60" y="45" fill="#e2e8f0" font-size="10" text-anchor="middle" font-family="monospace">Bulk Loading Bays</text>
            <text x="60" y="62" fill="#38bdf8" font-size="11" font-weight="bold" text-anchor="middle" font-family="monospace">180 t/h Truck Load</text>
          </g>
        </svg>
      </div>
    </div>
  `
})
export class PidDiagramViewComponent {
  private twin = inject(CementTwinService);

  readonly rawMill = this.twin.rawMillState;
  readonly precalciner = this.twin.precalcinerState;
  readonly kiln = this.twin.rotaryKilnState;
  readonly cooler = this.twin.clinkerCoolerState;
  readonly cmill1 = this.twin.cementMill1State;
  readonly cmill2 = this.twin.cementMill2State;

  selectAsset(id: string) {
    this.twin.selectedAssetId.set(id);
  }
}
