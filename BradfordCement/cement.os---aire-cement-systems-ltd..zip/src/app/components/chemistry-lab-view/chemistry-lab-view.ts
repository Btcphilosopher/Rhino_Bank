import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CementTwinService } from '../../services/cement-twin.service';

@Component({
  selector: 'app-chemistry-lab-view',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="w-full h-full bg-[#111317] p-6 overflow-y-auto text-slate-200">
      <!-- Header -->
      <div class="flex items-center justify-between pb-4 border-b border-white/10 mb-6">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono px-2 py-0.5 bg-blue-500/20 text-blue-400 border border-blue-500/30 rounded">LABORATORY ENGINE</span>
            <h1 class="text-xl font-bold text-white tracking-tight">CEMENT CHEMISTRY & QUALITY CONTROL</h1>
          </div>
          <p class="text-xs text-slate-400 mt-1 font-mono">XRF Oxide Spectrometry · Moduli Calculations · Clinker Phase Kinetics</p>
        </div>

        <button (click)="calibrateTwinWithLabData()" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-2 shadow-lg shadow-emerald-900/30">
          <span class="material-icons text-sm">sync</span>
          CALIBRATE TWIN WITH LAB DATA
        </button>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <!-- Raw Mix Proportions & Oxide Analysis -->
        <div class="bg-[#181b22] border border-white/10 rounded-2xl p-5 shadow-xl">
          <h3 class="text-sm font-bold text-slate-100 mb-4 flex items-center gap-2">
            <span class="material-icons text-blue-400 text-base">tune</span>
            RAW MATERIAL PROPORTIONING RECIPE
          </h3>

          <div class="space-y-4 text-xs font-mono">
            <div>
              <div class="flex justify-between mb-1">
                <span class="text-slate-300">Bradford Limestone</span>
                <span class="text-amber-400 font-bold">{{ props().limestone }} %</span>
              </div>
              <input type="range" min="70" max="88" step="0.5" [value]="props().limestone" (input)="updateLimestone($event)" class="w-full accent-amber-500 cursor-pointer"/>
            </div>

            <div>
              <div class="flex justify-between mb-1">
                <span class="text-slate-300">Yorkshire Clay / Shale</span>
                <span class="text-blue-400 font-bold">{{ props().clayShale }} %</span>
              </div>
              <input type="range" min="10" max="28" step="0.5" [value]="props().clayShale" (input)="updateClayShale($event)" class="w-full accent-blue-500 cursor-pointer"/>
            </div>

            <div>
              <div class="flex justify-between mb-1">
                <span class="text-slate-300">Iron Corrective Ore</span>
                <span class="text-red-400 font-bold">{{ props().ironOre }} %</span>
              </div>
              <input type="range" min="0.5" max="4.0" step="0.1" [value]="props().ironOre" (input)="updateIronOre($event)" class="w-full accent-red-500 cursor-pointer"/>
            </div>
          </div>

          <!-- Calculated Raw Meal Oxides -->
          <div class="mt-6 pt-4 border-t border-white/10">
            <div class="text-xs font-bold text-slate-300 mb-2">CALCULATED RAW MEAL OXIDES (%)</div>
            <div class="grid grid-cols-3 gap-2 text-xs font-mono">
              <div class="p-2 bg-[#202530] rounded-lg border border-white/5">
                <span class="text-slate-400">CaO: </span><span class="text-white font-bold">{{ rawMeal().CaO }}%</span>
              </div>
              <div class="p-2 bg-[#202530] rounded-lg border border-white/5">
                <span class="text-slate-400">SiO2: </span><span class="text-white font-bold">{{ rawMeal().SiO2 }}%</span>
              </div>
              <div class="p-2 bg-[#202530] rounded-lg border border-white/5">
                <span class="text-slate-400">Al2O3: </span><span class="text-white font-bold">{{ rawMeal().Al2O3 }}%</span>
              </div>
              <div class="p-2 bg-[#202530] rounded-lg border border-white/5">
                <span class="text-slate-400">Fe2O3: </span><span class="text-white font-bold">{{ rawMeal().Fe2O3 }}%</span>
              </div>
              <div class="p-2 bg-[#202530] rounded-lg border border-white/5">
                <span class="text-slate-400">MgO: </span><span class="text-white font-bold">{{ rawMeal().MgO }}%</span>
              </div>
              <div class="p-2 bg-[#202530] rounded-lg border border-white/5">
                <span class="text-slate-400">LOI: </span><span class="text-white font-bold">{{ rawMeal().LOI }}%</span>
              </div>
            </div>
          </div>
        </div>

        <!-- CEMENT RATIOS & TARGETS -->
        <div class="bg-[#181b22] border border-white/10 rounded-2xl p-5 shadow-xl">
          <h3 class="text-sm font-bold text-slate-100 mb-4 flex items-center gap-2">
            <span class="material-icons text-amber-400 text-base">functions</span>
            CEMENT INDUSTRY RATIOS & MODULI
          </h3>

          <div class="space-y-4 font-mono text-xs">
            <!-- LSF -->
            <div class="p-3.5 bg-[#202530] rounded-xl border border-white/5">
              <div class="flex justify-between items-center mb-1">
                <span class="text-slate-300 font-bold">Lime Saturation Factor (LSF)</span>
                <span class="text-lg font-bold text-amber-400">{{ ratios().LSF }} %</span>
              </div>
              <p class="text-[11px] text-slate-400">Target: 95.0 - 98.5%. Controls combinability & burnability.</p>
            </div>

            <!-- SM -->
            <div class="p-3.5 bg-[#202530] rounded-xl border border-white/5">
              <div class="flex justify-between items-center mb-1">
                <span class="text-slate-300 font-bold">Silica Modulus (SM)</span>
                <span class="text-lg font-bold text-blue-400">{{ ratios().SM }}</span>
              </div>
              <p class="text-[11px] text-slate-400">Target: 2.30 - 2.70. High SM reduces liquid phase & coating.</p>
            </div>

            <!-- AM -->
            <div class="p-3.5 bg-[#202530] rounded-xl border border-white/5">
              <div class="flex justify-between items-center mb-1">
                <span class="text-slate-300 font-bold">Alumina Modulus (AM)</span>
                <span class="text-lg font-bold text-emerald-400">{{ ratios().AM }}</span>
              </div>
              <p class="text-[11px] text-slate-400">Target: 1.30 - 1.80. Ratio of Al2O3 to Fe2O3 fluxing oxide.</p>
            </div>
          </div>
        </div>

        <!-- CEMENT PRODUCTS SPECIFICATION -->
        <div class="bg-[#181b22] border border-white/10 rounded-2xl p-5 shadow-xl">
          <h3 class="text-sm font-bold text-slate-100 mb-4 flex items-center gap-2">
            <span class="material-icons text-purple-400 text-base">inventory_2</span>
            AIRE CEMENT PRODUCT PORTFOLIO
          </h3>

          <div class="space-y-3">
            @for (prod of products(); track prod.id) {
              <div class="p-3 bg-[#202530] rounded-xl border border-white/5 text-xs font-mono">
                <div class="flex justify-between items-center font-bold text-white mb-1">
                  <span>{{ prod.code }}</span>
                  <span class="text-emerald-400">£{{ prod.unitCostGbpT }}/t</span>
                </div>
                <p class="text-[11px] text-slate-400 mb-2">{{ prod.description }}</p>
                <div class="flex justify-between text-[10px] text-slate-300">
                  <span>Clinker: {{ prod.clinkerPercent }}%</span>
                  <span>Target 28d: {{ prod.target28DayStrengthMpa }} MPa</span>
                  <span class="text-amber-400">{{ prod.embodiedCarbonKgCo2T }} kg CO2/t</span>
                </div>
              </div>
            }
          </div>
        </div>
      </div>

      <!-- Laboratory Test Samples Table -->
      <div class="bg-[#181b22] border border-white/10 rounded-2xl p-5 shadow-xl">
        <h3 class="text-sm font-bold text-slate-100 mb-4 flex items-center gap-2">
          <span class="material-icons text-teal-400 text-base">biotech</span>
          LABORATORY QUALITY SAMPLES LOG
        </h3>

        <div class="overflow-x-auto">
          <table class="w-full text-xs font-mono text-left text-slate-300">
            <thead class="bg-[#202530] text-slate-400 uppercase text-[10px]">
              <tr>
                <th class="p-3">Sample ID</th>
                <th class="p-3">Material</th>
                <th class="p-3">Location</th>
                <th class="p-3">Timestamp</th>
                <th class="p-3">Operator</th>
                <th class="p-3">CaO %</th>
                <th class="p-3">SiO2 %</th>
                <th class="p-3">LSF</th>
                <th class="p-3">Status</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-white/5">
              @for (smp of samples(); track smp.sampleId) {
                <tr class="hover:bg-white/5">
                  <td class="p-3 text-amber-400 font-bold">{{ smp.sampleId }}</td>
                  <td class="p-3 font-semibold text-white">{{ smp.materialName }}</td>
                  <td class="p-3 text-slate-400">{{ smp.sourceLocation }}</td>
                  <td class="p-3 text-slate-400">{{ smp.timestamp }}</td>
                  <td class="p-3 text-slate-400">{{ smp.operator }}</td>
                  <td class="p-3 font-bold">{{ smp.composition.CaO }}%</td>
                  <td class="p-3 font-bold">{{ smp.composition.SiO2 }}%</td>
                  <td class="p-3 text-emerald-400 font-bold">{{ smp.ratios?.LSF || '-' }}</td>
                  <td class="p-3">
                    <span class="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-400 font-bold border border-emerald-500/30">
                      {{ smp.status }}
                    </span>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class ChemistryLabViewComponent {
  private twin = inject(CementTwinService);

  readonly props = this.twin.rawMixProportions;
  readonly rawMeal = this.twin.rawMealComposition;
  readonly ratios = this.twin.rawMealRatios;
  readonly products = this.twin.cementProducts;
  readonly samples = this.twin.qualitySamples;

  updateLimestone(e: Event) {
    const val = Number((e.target as HTMLInputElement).value);
    const rem = 100 - val - this.props().ironOre;
    this.twin.setRawMixProportions({
      limestone: val,
      clayShale: Number(rem.toFixed(1)),
      ironOre: this.props().ironOre
    });
  }

  updateClayShale(e: Event) {
    const val = Number((e.target as HTMLInputElement).value);
    const rem = 100 - val - this.props().ironOre;
    this.twin.setRawMixProportions({
      limestone: Number(rem.toFixed(1)),
      clayShale: val,
      ironOre: this.props().ironOre
    });
  }

  updateIronOre(e: Event) {
    const val = Number((e.target as HTMLInputElement).value);
    const rem = 100 - val - this.props().clayShale;
    this.twin.setRawMixProportions({
      limestone: Number(rem.toFixed(1)),
      clayShale: this.props().clayShale,
      ironOre: val
    });
  }

  calibrateTwinWithLabData() {
    alert('Digital Twin calibrated with XRF Laboratory Data. Mass-balance and chemistry kinetic parameters updated successfully.');
  }
}
