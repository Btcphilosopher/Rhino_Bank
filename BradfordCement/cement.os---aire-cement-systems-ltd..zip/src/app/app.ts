import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CementTwinService } from './services/cement-twin.service';
import { Plant3dViewComponent } from './components/plant-3d-view/plant-3d-view';
import { PidDiagramViewComponent } from './components/pid-diagram-view/pid-diagram-view';
import { PyroprocessKilnViewComponent } from './components/pyroprocess-kiln-view/pyroprocess-kiln-view';
import { ChemistryLabViewComponent } from './components/chemistry-lab-view/chemistry-lab-view';
import { EnergyEmissionsViewComponent } from './components/energy-emissions-view/energy-emissions-view';
import { AssetMaintenanceViewComponent } from './components/asset-maintenance-view/asset-maintenance-view';
import { ScenarioEngineViewComponent } from './components/scenario-engine-view/scenario-engine-view';
import { HistorianTimeMachineViewComponent } from './components/historian-time-machine-view/historian-time-machine-view';
import { ControlRoomDashboardViewComponent } from './components/control-room-dashboard-view/control-room-dashboard-view';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    Plant3dViewComponent,
    PidDiagramViewComponent,
    PyroprocessKilnViewComponent,
    ChemistryLabViewComponent,
    EnergyEmissionsViewComponent,
    AssetMaintenanceViewComponent,
    ScenarioEngineViewComponent,
    HistorianTimeMachineViewComponent,
    ControlRoomDashboardViewComponent
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  readonly twin = inject(CementTwinService);

  readonly activeView = this.twin.activeViewMode;
  readonly isSimulating = this.twin.isSimulating;
  readonly simSpeed = this.twin.simSpeedMultiplier;
  readonly currentTimestamp = this.twin.currentTimestamp;

  readonly activeAlarmsCount = () => this.twin.activeAlarms().filter(a => !a.acknowledged).length;

  setView(view: '3D' | 'PID' | 'PYROPROCESS' | 'LAB' | 'ENERGY' | 'ASSETS' | 'SCENARIOS' | 'HISTORIAN' | 'CONTROL_ROOM') {
    this.twin.activeViewMode.set(view);
  }

  toggleSimulation() {
    this.twin.toggleSimulation();
  }

  setSpeed(mult: number) {
    this.twin.setSimSpeed(mult);
  }
}
