import { GoogleGenAI, Type } from "@google/genai";
import { NextRequest, NextResponse } from "next/server";

// Initialize Gemini SDK with telemetry header
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

export async function POST(req: NextRequest) {
  try {
    const { application, carbonBudget, exposureClass } = await req.json();

    if (!application || !carbonBudget || !exposureClass) {
      return NextResponse.json(
        { error: "Missing required spec parameters." },
        { status: 400 }
      );
    }

    const prompt = `
      You are the Principal Materials Scientist at Bradford Cement Works in West Yorkshire.
      We need to formulate a premium, high-integrity architectural concrete mix design compliant with BS 8500 and BS EN 206 for a luxury project.

      Parameters requested by the specifier:
      - Structural Application: ${application}
      - Carbon Mitigation level: ${carbonBudget}
      - Environmental Exposure Class (BS EN 206): ${exposureClass}

      Please design a concrete specification using local West Yorkshire aggregates (such as Millstone Grit coarse aggregate and local Pennine gritstone sands) that combines Bradford's legendary industrial longevity with sleek contemporary aesthetic finishes.

      Structure your response exactly according to the schema provided.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are an elite UK-based concrete materials engineer. Provide exact BS 8500 metrics, local Yorkshire geological references, precise water/cement ratios, and professional engineering descriptions.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            strengthClass: {
              type: Type.STRING,
              description: "The concrete compressive strength class, e.g. C32/40 or C40/50"
            },
            wcRatio: {
              type: Type.STRING,
              description: "The maximum water-to-cement ratio, e.g. 0.40"
            },
            cementType: {
              type: Type.STRING,
              description: "The BS 8500 cement combination code, e.g. CEM III/A + S (GGBS slag or limestone)"
            },
            localAggregates: {
              type: Type.STRING,
              description: "Details of the chosen locally sourced West Yorkshire aggregates"
            },
            carbonStats: {
              type: Type.STRING,
              description: "Estimated embodied CO2 emission reduction, e.g. '58% CO2 saving (140 kg CO2e/m3)'"
            },
            placementAdvice: {
              type: Type.STRING,
              description: "Specific placement and curing advice tailored for the damp and cold northern climate of Bradford"
            },
            description: {
              type: Type.STRING,
              description: "A 2-paragraph professional engineering explanation of the rational and aesthetic qualities of this mix"
            },
            specifications: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  parameter: { type: Type.STRING },
                  value: { type: Type.STRING }
                },
                required: ["parameter", "value"]
              },
              description: "An array of technical design metrics (e.g. Slump Class, Minimum Cement Content, Chloride Class)"
            }
          },
          required: [
            "strengthClass",
            "wcRatio",
            "cementType",
            "localAggregates",
            "carbonStats",
            "placementAdvice",
            "description",
            "specifications"
          ]
        }
      }
    });

    const textOutput = response.text;
    if (!textOutput) {
      throw new Error("No text returned from Gemini");
    }

    const parsedData = JSON.parse(textOutput.trim());
    return NextResponse.json(parsedData);

  } catch (error: any) {
    console.error("Gemini Spec Advisor Error:", error);
    return NextResponse.json(
      { error: error.message || "Failed to generate specification." },
      { status: 500 }
    );
  }
}
