'use client';

import { useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { motion } from 'motion/react';
import { 
  FileText, 
  Layers, 
  ArrowRight, 
  Percent, 
  CheckCircle, 
  Flame, 
  Hammer,
  Info
} from 'lucide-react';

const products = [
  {
    id: 'eco-35',
    name: 'BCW-EcoMix 35',
    tagline: 'Standard Low-Carbon Structural Foundation Mix',
    strength: 'C32/40',
    slump: 'S3 (100–150 mm)',
    slag: '35% GGBS Slag Replacement',
    hydration: 'Low Hydration Heat (Safe for Mass Pours)',
    aggregate: '20mm West Yorkshire Millstone Grit',
    embodiedCO2: '190 kg CO2e/m³ (35% Saving)',
    applications: 'Heavy load structural foundations, retaining walls, slab works, and high-density cores.',
    technicalData: [
      { name: 'Compressive Strength (7 Day)', value: '≥ 24 N/mm²' },
      { name: 'Compressive Strength (28 Day)', value: '≥ 40 N/mm²' },
      { name: 'Chloride Class', value: 'Cl 0.20 (Reinforced)' },
      { name: 'Target W/C Ratio', value: '0.45' },
      { name: 'Exposure Suitability', value: 'XC1, XC2, XC3, XF1' }
    ]
  },
  {
    id: 'ultra-65',
    name: 'BCW-Novacem 65',
    tagline: 'Ultimate Eco-Conscious Calcined Clay Binder',
    strength: 'C28/35',
    slump: 'S4 (160–210 mm)',
    slag: '65% Calcined Clay & Limestone Flour',
    hydration: 'Very Low Heat development',
    aggregate: '10mm Local Pennine River Sand & Grit',
    embodiedCO2: '98 kg CO2e/m³ (65% Saving)',
    applications: 'Architectural facades, light residential casting, cladding, and eco-certified developments.',
    technicalData: [
      { name: 'Compressive Strength (7 Day)', value: '≥ 15 N/mm²' },
      { name: 'Compressive Strength (28 Day)', value: '≥ 35 N/mm²' },
      { name: 'Chloride Class', value: 'Cl 0.10 (Ultimate)' },
      { name: 'Target W/C Ratio', value: '0.40' },
      { name: 'Exposure Suitability', value: 'XC1, XC2, C1' }
    ]
  },
  {
    id: 'facade-polished',
    name: 'BCW-Precast Terrazzo',
    tagline: 'Premium Highly Polishable Architectural Concrete',
    strength: 'C40/50',
    slump: 'SF1 (Flowing Self-Consolidating)',
    slag: '20% Fine Fly-Ash Binder',
    hydration: 'Moderate Heat Release',
    aggregate: '6mm Dark Yorkshire Ironstone & Spar',
    embodiedCO2: '240 kg CO2e/m³ (20% Saving)',
    applications: 'Bespoke polished flooring panels, structural countertops, architectural exhibition columns, and precast steps.',
    technicalData: [
      { name: 'Compressive Strength (7 Day)', value: '≥ 32 N/mm²' },
      { name: 'Compressive Strength (28 Day)', value: '≥ 50 N/mm²' },
      { name: 'Chloride Class', value: 'Cl 0.20' },
      { name: 'Target W/C Ratio', value: '0.36 (High-density)' },
      { name: 'Exposure Suitability', value: 'XC1, C1 (Indoor focus)' }
    ]
  },
  {
    id: 'marine-xf',
    name: 'BCW-Sulphate Shield 60',
    tagline: 'High-Density Marine & Chemical Shield Mixture',
    strength: 'C50/60',
    slump: 'S3 (100–150 mm)',
    slag: '60% Slag and Microsilica Blockers',
    hydration: 'Slow strength build / Low mass heat',
    aggregate: '20mm Double-Washed Pennine Flint Gravel',
    embodiedCO2: '160 kg CO2e/m³ (48% Saving)',
    applications: 'Marine infrastructure, bridges, retaining sea walls, chemical factories, and aggressive sulphate farm soils.',
    technicalData: [
      { name: 'Compressive Strength (7 Day)', value: '≥ 28 N/mm²' },
      { name: 'Compressive Strength (28 Day)', value: '≥ 60 N/mm²' },
      { name: 'Chloride Class', value: 'Cl 0.05 (Maximum resistance)' },
      { name: 'Target W/C Ratio', value: '0.34 (Ultra-dense)' },
      { name: 'Exposure Suitability', value: 'XS1, XS2, XF3, XA2' }
    ]
  }
];

export default function BespokeCementPage() {
  const [downloadedId, setDownloadedId] = useState<string | null>(null);

  const handleDownload = (id: string, name: string) => {
    setDownloadedId(id);
    // Mimic real datasheet download
    setTimeout(() => {
      setDownloadedId(null);
      alert(`Technical specification PDF generated for ${name}. Compilation matches UK BS 8500-1 Annex B.`);
    }, 1200);
  };

  return (
    <div className="bg-charcoal min-h-screen text-white pt-32 pb-24">
      
      {/* Page Header */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 mb-16">
        <div className="border-b border-stone-900 pb-12">
          <span className="text-xs tracking-[0.3em] text-brass font-bold block mb-4">
            MATERIALS CATALOGUE
          </span>
          <h1 className="font-serif text-4xl md:text-5xl lg:text-7xl leading-none text-white tracking-tight">
            Our Bespoke Mixes
          </h1>
          <p className="text-stone-400 text-xs sm:text-sm max-w-2xl mt-6 leading-relaxed">
            We operate a wet-mix batching facility and architectural casting yard. Explore our standard performance formulations, designed to conform with UK BS 8500 and customizable down to exact color, curing heat, and aggregate geology.
          </p>
        </div>
      </section>

      {/* Materials List */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="flex flex-col gap-12 lg:gap-16">
          {products.map((item, idx) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-100px' }}
              transition={{ duration: 0.8, delay: idx * 0.1 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 bg-stone-950/20 hover:bg-stone-950/40 border border-stone-900 hover:border-stone-850 p-6 sm:p-8 lg:p-10 rounded-sm transition-all duration-500 concrete-grain"
            >
              
              {/* Product Info Block: Left/Center */}
              <div className="lg:col-span-7 flex flex-col justify-between">
                <div>
                  <div className="flex flex-wrap items-center gap-x-4 gap-y-2 mb-4">
                    <span className="font-serif text-3xl font-bold text-brass tracking-tight">
                      {item.name}
                    </span>
                    <span className="text-[10px] bg-stone-900 border border-stone-800 text-stone-400 px-3 py-1 rounded-sm uppercase tracking-widest font-mono font-bold shrink-0">
                      STRENGTH: {item.strength}
                    </span>
                  </div>

                  <h3 className="text-sm text-stone-300 font-semibold mb-4 tracking-wide font-sans">
                    {item.tagline}
                  </h3>

                  <p className="text-xs sm:text-sm text-stone-400 leading-relaxed font-sans mb-8">
                    {item.applications}
                  </p>

                  {/* Highlights Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pb-6 border-b border-stone-900">
                    <div className="flex items-start gap-3">
                      <Percent className="w-4 h-4 text-brass mt-0.5 shrink-0" />
                      <div>
                        <span className="text-[9px] text-stone-500 tracking-wider uppercase font-bold block mb-0.5">BINDER COMPOSITE</span>
                        <span className="text-xs text-stone-300 font-medium">{item.slag}</span>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Flame className="w-4 h-4 text-brass mt-0.5 shrink-0" />
                      <div>
                        <span className="text-[9px] text-stone-500 tracking-wider uppercase font-bold block mb-0.5">HYDRATION RATE</span>
                        <span className="text-xs text-stone-300 font-medium">{item.hydration}</span>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Hammer className="w-4 h-4 text-brass mt-0.5 shrink-0" />
                      <div>
                        <span className="text-[9px] text-stone-500 tracking-wider uppercase font-bold block mb-0.5">GEOLOGICAL AGGREGATE</span>
                        <span className="text-xs text-stone-300 font-medium">{item.aggregate}</span>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-4 h-4 text-emerald-500 mt-0.5 shrink-0" />
                      <div>
                        <span className="text-[9px] text-stone-500 tracking-wider uppercase font-bold block mb-0.5">CARBON PERFORMANCE</span>
                        <span className="text-xs text-emerald-400 font-bold">{item.embodiedCO2}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Download call-to-action */}
                <div className="pt-6 flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
                  <button
                    onClick={() => handleDownload(item.id, item.name)}
                    disabled={downloadedId === item.id}
                    className="flex items-center justify-center gap-3 py-3 px-6 bg-stone-900 border border-stone-800 hover:border-brass hover:text-brass text-[10px] tracking-widest text-white font-bold uppercase transition-all duration-300 rounded-sm"
                  >
                    <FileText className={`w-3.5 h-3.5 ${downloadedId === item.id ? 'animate-bounce text-brass' : 'text-stone-400'}`} />
                    <span>
                      {downloadedId === item.id ? 'COMPILING DATASHEET...' : 'DOWNLOAD TECHNICAL DATASHEET'}
                    </span>
                  </button>
                  <Link
                    href="/contact"
                    className="flex items-center justify-center gap-2 py-3 px-6 text-[10px] tracking-widest text-stone-400 hover:text-white transition-colors uppercase font-bold"
                  >
                    <span>Request Mix Adjustment</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </Link>
                </div>

              </div>

              {/* Technical Specifications: Right */}
              <div className="lg:col-span-5 bg-stone-950/60 p-6 border border-stone-900 rounded-sm flex flex-col justify-between">
                <div>
                  <div className="border-b border-stone-900 pb-3 mb-4">
                    <span className="text-[8px] tracking-widest text-stone-500 uppercase font-mono">SPECIFICATION DATA MATRIX</span>
                    <h4 className="font-serif text-sm font-semibold text-stone-300 mt-0.5">Physical Performance Limits</h4>
                  </div>

                  <dl className="flex flex-col gap-3 text-xs">
                    <div className="flex justify-between items-center py-1 border-b border-stone-900">
                      <dt className="text-stone-500">Slump/Workability Class</dt>
                      <dd className="text-white font-medium">{item.slump}</dd>
                    </div>
                    {item.technicalData.map((tech, i) => (
                      <div key={i} className="flex justify-between items-center py-1 border-b border-stone-900">
                        <dt className="text-stone-500">{tech.name}</dt>
                        <dd className="text-white font-medium">{tech.value}</dd>
                      </div>
                    ))}
                  </dl>
                </div>

                <div className="mt-6 pt-4 border-t border-stone-900 flex items-center gap-2 text-[10px] text-stone-500 italic">
                  <Info className="w-3.5 h-3.5 text-stone-600 shrink-0" />
                  <span>Complies with British Standard BS 8500 and BS EN 206 for ready-mix batching.</span>
                </div>

              </div>

            </motion.div>
          ))}
        </div>
      </section>

    </div>
  );
}
