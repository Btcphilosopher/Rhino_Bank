'use client';

import Image from 'next/image';
import Link from 'next/link';
import { motion } from 'motion/react';
import { Landmark, Compass, Award, Building2, ArrowRight } from 'lucide-react';

export default function AboutPage() {
  return (
    <div className="bg-charcoal min-h-screen text-white pt-32 pb-24">
      
      {/* Page Header */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 mb-16">
        <div className="border-b border-stone-900 pb-12">
          <span className="text-xs tracking-[0.3em] text-brass font-bold block mb-4">
            HISTORY, MISSION & GEOLOGY
          </span>
          <h1 className="font-serif text-4xl md:text-5xl lg:text-7xl leading-none text-white tracking-tight animate-fade-in">
            About Bradford Cement
          </h1>
          <p className="text-stone-400 text-xs sm:text-sm max-w-2xl mt-6 leading-relaxed">
            Formed in the crucible of West Yorkshire&apos;s industrial expansion, we have evolved from regional plaster suppliers into a leading producer of precast architectural concrete panels and low-carbon cement binders.
          </p>
        </div>
      </section>

      {/* Asymmetric Editorial History Section */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 mb-24">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Main Narrative: Left (70%) */}
          <div className="lg:col-span-8 flex flex-col gap-8 text-sm sm:text-base text-stone-300 leading-relaxed font-serif">
            
            <p className="first-letter:text-5xl first-letter:font-serif first-letter:font-bold first-letter:float-left first-letter:mr-3 first-letter:mt-1 first-letter:text-brass text-stone-200">
              Bradford&apos;s architectural identity is rooted in its rugged geological surroundings. During the 19th century, the city became the wool capital of the world, building massive Victorian mills and civic masterpieces like the City Hall out of hard, soot-resistant West Yorkshire Millstone Grit. 
            </p>

            <p>
              It is this exact spirit of monumental durability and geological honesty that guides Bradford Cement Works today. Founded in 1918 on the banks of the Bradford Canal, we spent our early decades supporting local industrial masonry. As the construction industry transitioned toward modernism in the mid-20th century, we pioneered on-site batching and custom precast aggregates, combining traditional Yorkshire durability with contemporary architectural precision.
            </p>

            {/* In-text Editorial Callout */}
            <div className="border-y border-stone-900 py-6 my-4">
              <p className="font-serif italic text-lg sm:text-xl text-brass text-center">
                &ldquo;We do not merely mix aggregates; we formulate the physical foundations of tomorrow&apos;s British architecture.&rdquo;
              </p>
            </div>

            <p>
              Today, from our fully upgraded batching yard and laboratory on Canal Road, we produce highly specified concrete mixtures for tier-one contractors across Great Britain. Our partners range from high-density infrastructure developers to legendary architectural studios like Foster + Partners and David Chipperfield, seeking custom-finished facades with bespoke acid-etched, sandblasted, or diamond-polished textures.
            </p>

            <p>
              As we navigate the climate transition, our focus remains on decoupling structural strength from carbon volume. By integrating calcined clays and blast-furnace slag into our binders, we are preserving Bradford&apos;s industrial legacy of permanence while safeguarding the West Yorkshire environment for generations to come.
            </p>

          </div>

          {/* Sidebar / Captions: Right (30%) */}
          <div className="lg:col-span-4 bg-stone-950 p-6 border border-stone-900 rounded-sm flex flex-col gap-6">
            
            <div className="border-b border-stone-900 pb-4">
              <span className="text-[8px] tracking-widest text-stone-500 uppercase font-mono">LAB DETAILS</span>
              <h4 className="font-serif text-sm font-semibold text-white mt-1">Our Bradford Premises</h4>
            </div>

            <div className="relative aspect-[4/3] bg-stone-900 overflow-hidden rounded-sm border border-stone-850">
              <Image
                src="/images/material_concrete_texture.jpg"
                alt="Bespoke concrete slab specimen details"
                fill
                className="object-cover"
                referrerPolicy="no-referrer"
              />
              <span className="absolute bottom-2 left-2 bg-charcoal/80 backdrop-blur-sm py-1 px-2 text-[8px] font-bold text-brass tracking-widest uppercase">
                FORMULATED BATCH SPECIMEN
              </span>
            </div>

            <ul className="flex flex-col gap-4 text-xs text-stone-400">
              <li className="flex items-start gap-3">
                <Landmark className="w-4 h-4 text-brass shrink-0 mt-0.5" />
                <span><strong>Victorian Heritage:</strong> Inspired by local gritstone buildings.</span>
              </li>
              <li className="flex items-start gap-3">
                <Compass className="w-4 h-4 text-brass shrink-0 mt-0.5" />
                <span><strong>Aggregates Sourced:</strong> 95% of sand and gravel from regional Yorkshire valleys.</span>
              </li>
              <li className="flex items-start gap-3">
                <Building2 className="w-4 h-4 text-brass shrink-0 mt-0.5" />
                <span><strong>Premises:</strong> Canal Road, Bradford BD2 (Operating continuously since 1918).</span>
              </li>
            </ul>

          </div>

        </div>
      </section>

      {/* Corporate Values Strip */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 grid grid-cols-1 md:grid-cols-3 gap-8 pt-16 border-t border-stone-900">
        
        <div className="p-4 bg-stone-950/20 border border-stone-900 rounded-sm">
          <Award className="w-6 h-6 text-brass mb-4" />
          <h4 className="font-serif text-lg text-white mb-2">Uncompromising QA</h4>
          <p className="text-xs text-stone-400 leading-relaxed font-sans">
            Every cubic meter of concrete mixed is cataloged and tested in our accredited lab. We supply full cube crusher test data sheets to project engineers, providing complete structural liability protection.
          </p>
        </div>

        <div className="p-4 bg-stone-950/20 border border-stone-900 rounded-sm">
          <Landmark className="w-6 h-6 text-brass mb-4" />
          <h4 className="font-serif text-lg text-white mb-2">Architectural Publishing</h4>
          <p className="text-xs text-stone-400 leading-relaxed font-sans">
            We collaborate with architectural journals and universities, organizing materials exhibitions and testing novel decorative cement surfaces for civic monographs.
          </p>
        </div>

        <div className="p-4 bg-stone-950/20 border border-stone-900 rounded-sm flex flex-col justify-between">
          <div>
            <Compass className="w-6 h-6 text-brass mb-4" />
            <h4 className="font-serif text-lg text-white mb-2">Custom Aggregates</h4>
            <p className="text-xs text-stone-400 leading-relaxed font-sans">
              Architects can visit our yard to select exact stone geologies—limestone, dark gritstone, granite spar—and pigment tints to match neighboring heritage structures.
            </p>
          </div>
          <Link
            href="/contact"
            className="text-[10px] tracking-widest font-bold text-brass hover:text-white transition-colors uppercase flex items-center gap-2 mt-4"
          >
            <span>Request Yard Visit</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

      </section>

    </div>
  );
}
