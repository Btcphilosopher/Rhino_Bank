import type {Metadata} from 'next';
import { Cormorant_Garamond, Plus_Jakarta_Sans } from 'next/font/google';
import './globals.css';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

const cormorant = Cormorant_Garamond({
  subsets: ['latin'],
  variable: '--font-serif',
  weight: ['400', '500', '600', '700'],
  display: 'swap',
});

const jakarta = Plus_Jakarta_Sans({
  subsets: ['latin'],
  variable: '--font-sans',
  weight: ['400', '500', '600', '700'],
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'Bradford Cement Works | Bespoke Architectural Concrete & Premium Mixes',
  description: 'Premium bespoke cement and architectural-concrete manufacturer based in Bradford, West Yorkshire. Combining historic industrial craftsmanship with supermodernist engineering.',
  openGraph: {
    title: 'Bradford Cement Works | Bespoke Architectural Concrete & Premium Mixes',
    description: 'Premium bespoke cement and architectural-concrete manufacturer based in Bradford, West Yorkshire. Combining historic industrial craftsmanship with supermodernist engineering.',
    type: 'website',
    images: [
      {
        url: '/images/hero_bradford_cement.jpg',
        width: 1200,
        height: 630,
        alt: 'Bradford Cement Works Architectural Project',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Bradford Cement Works | Bespoke Architectural Concrete & Premium Mixes',
    description: 'Premium bespoke cement and architectural-concrete manufacturer based in Bradford, West Yorkshire. Combining historic industrial craftsmanship with supermodernist engineering.',
    images: ['/images/hero_bradford_cement.jpg'],
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className={`${cormorant.variable} ${jakarta.variable} scroll-smooth`}>
      <body suppressHydrationWarning className="bg-charcoal text-white font-sans antialiased flex flex-col min-h-screen">
        <Navbar />
        <main className="flex-grow">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
