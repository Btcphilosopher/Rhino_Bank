'use client';

import { useState } from 'react';
import Image from 'next/image';
import { motion, AnimatePresence } from 'motion/react';
import { MapPin, ArrowUpRight, Scale, Info, CheckCircle2 } from 'lucide-react';

const categories = [
  { id: 'all', label: 'ALL PROJECTS' },
  { id: 'civic', label: 'CIVIC & PUBLIC' },
  { id: 'residential', label: 'RESIDENTIAL' },
  { id: 'infrastructure', label: 'INFRASTRUCTURE' },
];

const projectsData = [
  {
    title: 'THE MILLENNIUM APARTMENTS',
    category: 'residential',
    location: 'Bradford, West Yorkshire',
    img: '/images/project_millennium_apartments.jpg',
    architect: 'SimpsonHaugh & Partners',
    contractor: 'BAM Nuttall',
    mixType: 'BCW precast limestone C40/50 panels',
    volume: '14,200 m³',
    co2Reduced: '35% (EcoMix binder)',
    desc: 'Clad entirely in high-finish structural panels using local millstone sand aggregates, achieving a timeless, soot-resistant facade in keeping with Bradford heritage.',
  },
  {
    title: 'CITY CENTRE DEVELOPMENT',
    category: 'civic',
    location: 'Bradford Civic Quarter',
    img: '/images/project_city_centre.jpg',
    architect: 'Foster + Partners',
    contractor: 'Sir Robert McAlpine',
    mixType: 'Acid-etched structural ribbed concrete',
    volume: '28,900 m³',
    co2Reduced: '65% (Novacem limestone-clay)',
    desc: 'A stunning modern public square flanking the gothic City Hall, using deep ribbed textured concrete that reflects light similarly to Yorkshire ashlar stone.',
  },
  {
    title: 'RIVERFRONT INFRASTRUCTURE',
    category: 'infrastructure',
    location: 'Shipley Viaduct Bridge',
    img: '/images/project_riverfront_infrastructure.jpg',
    architect: 'Arup Engineers',
    contractor: 'Balfour Beatty',
    mixType: 'Sulphate-resistant marine C50/60 concrete',
    volume: '41,500 m³',
    co2Reduced: '45% (GGBS mix blend)',
    desc: 'An extreme-longevity river bridge matching classic Victorian brickwork arches with contemporary high-density steel-blue concrete piers.',
  },
  {
    title: 'THE BRADFORD MONOLITH MUSEUM',
    category: 'civic',
    location: 'Little Germany Archive',
    img: '/images/hero_bradford_cement.jpg',
    architect: 'David Chipperfield Architects',
    contractor: 'Laing O&apos;Rourke',
    mixType: 'Polished charcoal terrazzo concrete',
    volume: '9,400 m³',
    co2Reduced: '55% (EcoMix GGBS)',
    desc: 'A supermodernist exhibition hub utilizing massive exposed columns of raw polished structural concrete mixed with local dark ironstone aggregates.',
  },
];

export default function OurWorkPage() {
  const [activeFilter, setActiveFilter] = useState('all');
  const [selectedProject, setSelectedProject] = useState<typeof projectsData[0] | null>(null);

  const filteredProjects = activeFilter === 'all' 
    ? projectsData 
    : projectsData.filter(p => p.category === activeFilter);

  return (
    <div className="bg-charcoal min-h-screen text-white pt-32 pb-24">
      
      {/* Editorial Page Header */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 mb-16">
        <div className="border-b border-stone-900 pb-12">
          <span className="text-xs tracking-[0.3em] text-brass font-bold block mb-4">
            CHRONOLOGY & PORTFOLIO
          </span>
          <h1 className="font-serif text-4xl md:text-5xl lg:text-7xl leading-none text-white tracking-tight">
            Our Architectural Work
          </h1>
          <p className="text-stone-400 text-xs sm:text-sm max-w-2xl mt-6 leading-relaxed">
            From heavy civil infrastructure spanning rivers to micro-polished terrazzo gallery surfaces, we work with leading architects and engineers to deliver customized structural concrete and cement specifications.
          </p>
        </div>
      </section>

      {/* Gallery & Interactive Filters */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12">
        
        {/* Interactive Segmented Filter Controls */}
        <div className="flex flex-wrap items-center gap-2 mb-12 pb-6 border-b border-stone-900">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveFilter(cat.id)}
              className={`px-4 py-2 text-[10px] tracking-widest font-bold transition-all duration-300 rounded-sm ${
                activeFilter === cat.id
                  ? 'bg-brass text-charcoal shadow-lg font-extrabold'
                  : 'text-stone-400 hover:text-white bg-transparent hover:bg-stone-900/30'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Dynamic Project Grid */}
        <motion.div 
          layout
          className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12"
        >
          <AnimatePresence mode="popLayout">
            {filteredProjects.map((project, idx) => (
              <motion.div
                layout
                key={project.title}
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                transition={{ duration: 0.5, ease: 'easeInOut' }}
                className="group flex flex-col cursor-pointer border border-stone-900/40 hover:border-stone-850 p-4 rounded-sm bg-stone-950/20 hover:bg-stone-950/40 transition-all duration-300"
                onClick={() => setSelectedProject(project)}
              >
                {/* Image Reveal */}
                <div className="relative aspect-[16:10] bg-stone-900 overflow-hidden rounded-sm">
                  <Image
                    src={project.img}
                    alt={project.title}
                    fill
                    className="object-cover group-hover:scale-[1.02] transition-all duration-500 brightness-90"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-4 right-4 bg-charcoal/80 backdrop-blur-sm border border-stone-850 py-1 px-2.5 text-[9px] font-bold tracking-widest text-brass">
                    {project.volume} USED
                  </div>
                </div>

                {/* Info block */}
                <div className="mt-6 flex items-start justify-between">
                  <div>
                    <span className="text-[9px] tracking-widest text-stone-500 font-bold block uppercase mb-1">
                      {project.category.toUpperCase()}
                    </span>
                    <h3 className="font-serif text-xl text-white group-hover:text-brass transition-colors font-semibold">
                      {project.title}
                    </h3>
                    <div className="flex items-center gap-2 mt-2">
                      <MapPin className="w-3.5 h-3.5 text-brass shrink-0" />
                      <span className="text-xs text-stone-400">
                        {project.location}
                      </span>
                    </div>
                  </div>

                  <div className="w-9 h-9 rounded-full border border-stone-800 flex items-center justify-center text-stone-500 group-hover:border-brass group-hover:text-brass transition-all">
                    <ArrowUpRight className="w-4 h-4" />
                  </div>
                </div>

                <p className="text-xs text-stone-500 mt-4 leading-relaxed font-sans line-clamp-2">
                  {project.desc}
                </p>

                {/* High-end unboxed metadata */}
                <div className="mt-4 pt-4 border-t border-stone-900/80 flex items-center gap-4 text-[10px] tracking-wider text-stone-500">
                  <span>{project.architect}</span>
                  <span aria-hidden="true" className="text-brass">·</span>
                  <span className="text-emerald-500">{project.co2Reduced} CO2e</span>
                </div>

              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

      </section>

      {/* Project Detail Dialog / Modal */}
      <AnimatePresence>
        {selectedProject && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-charcoal/90 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="bg-stone-950 border border-stone-850 rounded-sm max-w-4xl w-full max-h-[90vh] overflow-y-auto relative concrete-grain"
            >
              {/* Close handle */}
              <button
                onClick={() => setSelectedProject(null)}
                className="absolute top-6 right-6 z-10 py-1.5 px-3 bg-stone-900 border border-stone-800 hover:border-brass text-[10px] tracking-widest text-stone-400 hover:text-brass font-bold transition-all uppercase rounded-sm"
              >
                CLOSE [X]
              </button>

              <div className="grid grid-cols-1 md:grid-cols-12">
                {/* Media frame: Left */}
                <div className="md:col-span-6 relative aspect-video md:aspect-auto min-h-[300px] md:min-h-full">
                  <Image
                    src={selectedProject.img}
                    alt={selectedProject.title}
                    fill
                    className="object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>

                {/* Meta list: Right */}
                <div className="md:col-span-6 p-8 md:p-12 flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] tracking-[0.2em] text-brass font-bold uppercase block mb-2">
                      SPECIFICATION OVERVIEW
                    </span>
                    <h2 className="font-serif text-3xl text-white mb-2 font-bold leading-none">
                      {selectedProject.title}
                    </h2>
                    <p className="text-xs text-stone-400 flex items-center gap-1.5 mb-6">
                      <MapPin className="w-3.5 h-3.5 text-stone-500" />
                      <span>{selectedProject.location}</span>
                    </p>

                    <p className="text-xs text-stone-300 leading-relaxed font-serif mb-8">
                      {selectedProject.desc}
                    </p>

                    {/* Specifications List */}
                    <dl className="flex flex-col gap-3 text-xs border-t border-stone-900 pt-6">
                      <div className="flex justify-between py-1.5 border-b border-stone-900">
                        <dt className="text-stone-500 font-bold uppercase tracking-wider text-[9px]">LEAD ARCHITECT</dt>
                        <dd className="text-white font-medium">{selectedProject.architect}</dd>
                      </div>
                      <div className="flex justify-between py-1.5 border-b border-stone-900">
                        <dt className="text-stone-500 font-bold uppercase tracking-wider text-[9px]">CONTRACTOR</dt>
                        <dd className="text-white font-medium">{selectedProject.contractor}</dd>
                      </div>
                      <div className="flex justify-between py-1.5 border-b border-stone-900">
                        <dt className="text-stone-500 font-bold uppercase tracking-wider text-[9px]">MATERIAL RECIPE</dt>
                        <dd className="text-brass font-medium">{selectedProject.mixType}</dd>
                      </div>
                      <div className="flex justify-between py-1.5 border-b border-stone-900">
                        <dt className="text-stone-500 font-bold uppercase tracking-wider text-[9px]">CONCRETE VOLUME</dt>
                        <dd className="text-white font-medium">{selectedProject.volume}</dd>
                      </div>
                      <div className="flex justify-between py-1.5 border-b border-stone-900">
                        <dt className="text-stone-500 font-bold uppercase tracking-wider text-[9px]">CO2 SAVINGS</dt>
                        <dd className="text-emerald-500 font-bold flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>{selectedProject.co2Reduced}</span>
                        </dd>
                      </div>
                    </dl>
                  </div>

                  <div className="mt-8 pt-6 border-t border-stone-900">
                    <button
                      onClick={() => setSelectedProject(null)}
                      className="w-full py-3.5 bg-brass text-charcoal text-xs tracking-widest font-bold uppercase hover:bg-brass-dark transition-all rounded-sm"
                    >
                      Return to Gallery
                    </button>
                  </div>
                </div>

              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
