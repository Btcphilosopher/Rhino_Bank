'use client';

import Image from 'next/image';
import Link from 'next/link';
import { motion } from 'motion/react';
import { 
  ArrowRight, 
  Layers, 
  Leaf, 
  Award, 
  SlidersHorizontal, 
  MapPin, 
  Building2, 
  ArrowUpRight 
} from 'lucide-react';

const capabilities = [
  {
    icon: Layers,
    title: 'BESPOKE MIXES',
    desc: 'Tailored to your vision.',
  },
  {
    icon: Leaf,
    title: 'SUSTAINABLE PRACTICES',
    desc: 'Lower carbon. Lasting value.',
  },
  {
    icon: Award,
    title: 'LOCAL HERITAGE',
    desc: "Bradford's industrial legacy.",
  },
  {
    icon: SlidersHorizontal,
    title: 'PRECISION CRAFTSMANSHIP',
    desc: 'Engineered for excellence.',
  },
];

const featuredProjects = [
  {
    title: 'THE MILLENNIUM APARTMENTS',
    location: 'BRADFORD',
    img: '/images/project_millennium_apartments.jpg',
    href: '/our-work',
  },
  {
    title: 'CITY CENTRE DEVELOPMENT',
    location: 'BRADFORD',
    img: '/images/project_city_centre.jpg',
    href: '/our-work',
  },
  {
    title: 'RIVERFRONT INFRASTRUCTURE',
    location: 'BRADFORD',
    img: '/images/project_riverfront_infrastructure.jpg',
    href: '/our-work',
  },
];

export default function HomePage() {
  return (
    <div className="bg-charcoal min-h-screen text-white pt-24 overflow-hidden">
      
      {/* 1. Dramatic Architectural Hero Section */}
      <section className="relative min-h-[90vh] flex items-center justify-center py-12 lg:py-24 border-b border-stone-900">
        <div className="absolute inset-0 z-0">
          <Image
            src="/images/hero_bradford_cement.jpg"
            alt="Bradford Cement Works Architectural Project and Skyline"
            fill
            className="object-cover object-center opacity-85 brightness-[0.4]"
            priority
            referrerPolicy="no-referrer"
          />
          {/* Subtle vignette/contrast scrim for readability */}
          <div className="absolute inset-0 bg-gradient-to-t from-charcoal via-transparent to-black/30"></div>
        </div>

        <div className="max-w-7xl mx-auto px-6 lg:px-12 w-full z-10 relative grid grid-cols-1 lg:grid-cols-12 gap-12 items-end">
          
          {/* Hero Text Box */}
          <div className="lg:col-span-7 flex flex-col items-start text-left">
            
            {/* Subtle vintage header indicator */}
            <motion.div 
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="flex items-center gap-2 mb-6"
            >
              <span className="w-1.5 h-1.5 bg-brass"></span>
              <span className="text-[10px] tracking-[0.4em] text-brass uppercase font-bold">
                TRADITIONAL CRAFT. MODERN PRECISION.
              </span>
            </motion.div>

            {/* Giant Architectural Headline */}
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.15 }}
              className="font-serif text-5xl md:text-6xl lg:text-7xl leading-[1.05] text-white tracking-tight text-wrap balance max-w-2xl"
            >
              Bespoke<br />
              Cement Works<br />
              in Bradford
            </motion.h1>

            {/* Subheading */}
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="text-stone-300 font-sans font-medium text-xs tracking-widest uppercase mt-6 mb-4"
            >
              BUILT FOR WHAT&apos;S NEXT.
            </motion.p>

            {/* Editorial Paragraph */}
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="text-stone-400 text-xs sm:text-sm leading-relaxed max-w-lg mb-8 font-sans"
            >
              We are a specialist, bespoke cement works based in Bradford, West Yorkshire, producing high-performance cement, architectural concrete and custom mixes for residential, commercial and infrastructure projects across the UK and beyond.
            </motion.p>

            {/* CTA Button */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.5 }}
              className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 w-full sm:w-auto"
            >
              <Link
                href="/our-work"
                className="group py-3.5 px-6 border border-white hover:border-brass hover:text-brass text-xs tracking-widest font-bold uppercase transition-all duration-300 flex items-center justify-center gap-4 rounded-sm"
              >
                <span>EXPLORE OUR WORK</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1.5 transition-transform" />
              </Link>
              <Link
                href="/technical"
                className="group py-3.5 px-6 bg-brass hover:bg-brass-dark text-charcoal text-xs tracking-widest font-bold uppercase transition-all duration-300 flex items-center justify-center gap-2 rounded-sm"
              >
                <span>SPECIFY MIX RECIPE</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </Link>
            </motion.div>

          </div>

          {/* Location/Heritage Block - Bottom Right Alignment */}
          <div className="lg:col-span-5 flex justify-end lg:pb-6">
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 1, delay: 0.6 }}
              className="text-right border-r border-brass/50 pr-6 hidden md:block"
            >
              <span className="text-[9px] tracking-[0.3em] text-stone-500 font-bold block mb-1">
                BRADFORD
              </span>
              <p className="text-[11px] tracking-widest text-white leading-relaxed max-w-xs font-serif italic text-stone-300">
                &ldquo;Our home, our craft. Shaped by Yorkshire grit and millstone longevity.&rdquo;
              </p>
            </motion.div>
          </div>

        </div>
      </section>

      {/* 2. Horizontal Premium Capability Strip */}
      <section className="bg-stone-950 border-b border-stone-900 relative">
        <div className="max-w-7xl mx-auto px-6 lg:px-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 items-stretch">
          
          {/* Main capabilities */}
          <div className="lg:col-span-9 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 border-r border-stone-900 divide-y sm:divide-y-0 sm:divide-x divide-stone-900">
            {capabilities.map((cap, i) => {
              const Icon = cap.icon;
              return (
                <div key={i} className="py-8 px-6 flex flex-col justify-between gap-4 group">
                  <div className="w-8 h-8 flex items-center justify-center border border-stone-800 group-hover:border-brass transition-colors">
                    <Icon className="w-4 h-4 text-stone-500 group-hover:text-brass transition-colors" />
                  </div>
                  <div>
                    <h3 className="text-[10px] tracking-widest text-white font-bold mb-1">
                      {cap.title}
                    </h3>
                    <p className="text-xs text-stone-500">
                      {cap.desc}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Static Action Card */}
          <div className="lg:col-span-3 py-8 px-6 bg-stone-900/40 flex flex-col justify-between items-start gap-6 group relative overflow-hidden">
            <div className="absolute inset-0 opacity-15 mix-blend-overlay z-0 pointer-events-none">
              <Image 
                src="/images/material_concrete_texture.jpg" 
                alt="Material Texture" 
                fill 
                className="object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            
            <div className="z-10">
              <span className="text-[8px] tracking-widest text-brass font-bold uppercase block mb-1">
                OUR CEMENT
              </span>
              <h4 className="font-serif text-lg text-white group-hover:text-brass transition-colors duration-300">
                Strength. Aesthetics.<br />Endurance.
              </h4>
            </div>

            <Link
              href="/bespoke-cement"
              className="z-10 text-[10px] font-bold tracking-widest text-white hover:text-brass transition-colors uppercase flex items-center gap-2 mt-2 group"
            >
              <span>DISCOVER OUR RANGE</span>
              <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>

        </div>
      </section>

      {/* 3. Editorial Featured Projects Section */}
      <section className="py-16 lg:py-28 bg-[#F5F4EE] text-charcoal concrete-grain relative">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          
          {/* Header Row */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-16 items-end">
            <div className="lg:col-span-5">
              <span className="text-xs tracking-[0.3em] text-stone-500 font-bold block mb-4">
                FEATURED PROJECTS
              </span>
              <h2 className="font-serif text-4xl md:text-5xl lg:text-6xl text-stone-900 leading-[1.1] tracking-tight text-wrap balance">
                From contemporary homes to landmark developments.
              </h2>
            </div>
            <div className="lg:col-span-5 lg:col-start-8">
              <p className="text-sm text-stone-600 leading-relaxed font-sans mb-6">
                Our bespoke cement mixtures and architectural concretes bring structural designs to life, combining the physical performance of high-density aggregates with highly customized aesthetic surface qualities.
              </p>
              <Link
                href="/our-work"
                className="inline-flex items-center gap-3 text-xs tracking-widest font-bold uppercase text-stone-900 hover:text-brass transition-colors group"
              >
                <span>VIEW OUR PROJECTS</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1.5 transition-transform" />
              </Link>
            </div>
          </div>

          {/* Projects Column/Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {featuredProjects.map((project, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.8, delay: idx * 0.15 }}
                className="group flex flex-col"
              >
                {/* Image Container with Zoom Reveal */}
                <div className="relative aspect-[4/3] bg-stone-300 overflow-hidden rounded-sm border border-stone-200">
                  <Image
                    src={project.img}
                    alt={project.title}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-700 brightness-[0.9]"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </div>

                {/* Meta details */}
                <div className="mt-5 flex items-center justify-between border-b border-stone-200 pb-4">
                  <div>
                    <h4 className="font-serif text-base text-stone-900 group-hover:text-brass transition-colors font-semibold">
                      {project.title}
                    </h4>
                    <div className="flex items-center gap-2 mt-1">
                      <MapPin className="w-3 h-3 text-stone-500" />
                      <span className="text-[9px] tracking-widest text-stone-500 uppercase font-bold">
                        {project.location}
                      </span>
                    </div>
                  </div>
                  
                  <Link
                    href={project.href}
                    className="w-8 h-8 rounded-full border border-stone-300 flex items-center justify-center text-stone-700 hover:border-stone-900 hover:text-stone-900 transition-all group"
                  >
                    <ArrowUpRight className="w-4 h-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>

        </div>
      </section>

      {/* 4. Mini Promotional Teaser: Spec Advisor */}
      <section className="py-20 lg:py-32 bg-charcoal relative">
        <div className="max-w-7xl mx-auto px-6 lg:px-12 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          <div className="lg:col-span-5">
            <span className="text-xs tracking-[0.3em] text-brass font-bold block mb-4">
              TECHNICAL DEVELOPMENT
            </span>
            <h2 className="font-serif text-3xl md:text-4xl lg:text-5xl text-white leading-tight mb-6">
              Neural material design, customized instantly for your project load bounds.
            </h2>
            <p className="text-xs sm:text-sm text-stone-400 leading-relaxed font-sans mb-8">
              We operate an on-site testing facility in Bradford where our engineers customize aggregates and binder matrices. Use our digital Materials Spec Advisor to compile a tailored specification based on BS 8500 parameters.
            </p>
            <Link
              href="/technical"
              className="inline-flex items-center gap-3 py-3.5 px-6 bg-stone-900 hover:bg-stone-850 border border-stone-800 hover:border-brass text-xs tracking-widest font-bold uppercase transition-all duration-300 rounded-sm"
            >
              <span>ACCESS MIX LAB</span>
              <ArrowRight className="w-4 h-4 text-brass" />
            </Link>
          </div>

          <div className="lg:col-span-6 lg:col-start-7 bg-charcoal-light p-6 rounded-sm border border-stone-900 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-[2px] bg-brass"></div>
            
            <div className="flex items-center justify-between border-b border-stone-800 pb-4 mb-6">
              <div className="flex items-center gap-2">
                <Building2 className="w-4 h-4 text-brass" />
                <span className="text-[10px] tracking-widest text-stone-400 uppercase font-mono">SPECIFIER TERMINAL</span>
              </div>
              <span className="text-[9px] text-stone-500 font-mono">LAB ONLINE</span>
            </div>

            <div className="space-y-4 text-xs">
              <div className="p-4 bg-stone-900/60 rounded-sm border border-stone-850">
                <p className="text-[9px] text-stone-500 tracking-wider uppercase mb-1">SELECTED APP</p>
                <p className="text-white font-medium">Precast Architectural Facades (High Finish)</p>
              </div>
              <div className="p-4 bg-stone-900/60 rounded-sm border border-stone-850">
                <p className="text-[9px] text-stone-500 tracking-wider uppercase mb-1">CARBON LIMIT</p>
                <p className="text-emerald-500 font-medium font-serif">EcoMix 35% Slag Carbon Saving (GGBS)</p>
              </div>
              <div className="p-4 bg-stone-900/60 rounded-sm border border-stone-850">
                <p className="text-[9px] text-stone-500 tracking-wider uppercase mb-1">STRENGTH ESTIMATED</p>
                <p className="text-brass font-serif font-bold text-base">C40/50 COMPRESSIVE RATING</p>
              </div>
            </div>

            <p className="text-[10px] text-stone-500 italic mt-6 text-center">
              *Full BS 8500 compilation and chemical breakdown available in the Technical Mix Lab.
            </p>
          </div>

        </div>
      </section>

      {/* 5. Clean Trust Banner / Quote */}
      <section className="py-16 bg-[#16181F] text-center border-t border-b border-stone-900">
        <div className="max-w-4xl mx-auto px-6">
          <span className="text-[10px] tracking-[0.3em] text-brass uppercase font-bold block mb-6">
            ESTABLISHED IN THE HEART OF WEST YORKSHIRE
          </span>
          <p className="font-serif text-2xl md:text-3xl lg:text-4xl text-stone-100 italic leading-snug">
            &ldquo;From the dark soot-faced mills of the Industrial Revolution to the brilliant precast facades of contemporary London, Bradford cement is built to outlast generations.&rdquo;
          </p>
          <div className="flex items-center justify-center gap-3 mt-8">
            <span className="w-8 h-[1px] bg-stone-700"></span>
            <span className="text-xs tracking-widest text-stone-500 font-bold uppercase">
              BRADFORD CEMENT ARCHITECTURAL PRESS, 1968
            </span>
            <span className="w-8 h-[1px] bg-stone-700"></span>
          </div>
        </div>
      </section>

    </div>
  );
}
