'use client';

import { motion } from 'motion/react';
import SpecAdvisor from '@/components/SpecAdvisor';
import { 
  Building, 
  FlaskConical, 
  ShieldAlert, 
  LineChart, 
  HelpCircle, 
  ArrowRight 
} from 'lucide-react';

const certifications = [
  { label: 'UKAS Quality Testing', value: 'Lab Reference No. 9410' },
  { label: 'BS 8500 Ready-Mix Compliant', value: 'BSI Certificate KM 50293' },
  { label: 'ISO 9001 Quality System', value: 'FM 81923 Certificate' },
  { label: 'BS EN 197-1 Binder Quality', value: 'CE Marking 0086-CPR' }
];

export default function TechnicalPage() {
  return (
    <div className="bg-charcoal min-h-screen text-white pt-32 pb-24">
      
      {/* Editorial Header */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 mb-16">
        <div className="border-b border-stone-900 pb-12">
          <span className="text-xs tracking-[0.3em] text-brass font-bold block mb-4">
            MATERIALS LABORATORY & TESTING
          </span>
          <h1 className="font-serif text-4xl md:text-5xl lg:text-7xl leading-none text-white tracking-tight">
            Technical Specification
          </h1>
          <p className="text-stone-400 text-xs sm:text-sm max-w-2xl mt-6 leading-relaxed">
            We maintain an in-house testing laboratory at our Bradford facility. Here, we conduct aggregate mineral grading, moisture checks, and cube crush trials to guarantee structural compliance with UK Building Regulations and British Standards.
          </p>
        </div>
      </section>

      {/* Main Spec Tool Segment */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 mb-20">
        <div className="mb-8">
          <h2 className="text-xs font-bold tracking-widest text-stone-500 uppercase mb-2">
            NEURAL SPECIFICATION ENGINE
          </h2>
          <p className="font-serif text-2xl text-white">
            Formulate Custom Mix Designs Instantly
          </p>
        </div>
        
        {/* Hosted SpecAdvisor component */}
        <SpecAdvisor />
      </section>

      {/* Laboratory Specs & Certifications Grid */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 grid grid-cols-1 lg:grid-cols-12 gap-12 border-t border-stone-900 pt-16">
        
        {/* Testing Info: Left */}
        <div className="lg:col-span-7 flex flex-col gap-8">
          <div>
            <span className="text-[10px] tracking-widest text-brass font-bold block uppercase mb-3">
              QUALITY CONTROL PROTOCOLS
            </span>
            <h3 className="font-serif text-2xl text-white mb-4">
              Structural Concrete Integrity Trials
            </h3>
            <p className="text-xs sm:text-sm text-stone-400 leading-relaxed font-sans">
              To support architects and structural engineers, our quality control team performs comprehensive cube testing on every batch. Specimens are cured in climate-controlled water tanks at 20°C and crushed at 7, 28, and 56 days to verify structural compressive strength ratings.
            </p>
          </div>

          {/* Interactive Strength curve mock */}
          <div className="bg-stone-950 p-6 border border-stone-900 rounded-sm">
            <div className="flex items-center justify-between pb-4 mb-4 border-b border-stone-900">
              <div className="flex items-center gap-2">
                <LineChart className="w-4 h-4 text-brass" />
                <span className="text-[9px] tracking-widest text-stone-400 uppercase font-mono">STRENGTH GAIN MATRIX (C40/50 EXAMPLE)</span>
              </div>
              <span className="text-[9px] text-emerald-500 font-mono">GGBS SLOW HYDRATION EFFECT</span>
            </div>

            {/* Custom chart using styled tailwind divs */}
            <div className="h-44 flex items-end justify-between gap-2 pt-6 pb-2 relative">
              <div className="absolute top-0 left-0 w-full text-[8px] text-stone-600 border-t border-stone-900 pt-1">
                TARGET DESIGN COMPRESSIVE STRENGTH (50 N/mm²)
              </div>
              <div className="absolute top-1/2 left-0 w-full text-[8px] text-stone-600 border-t border-stone-900/40">
                28-DAY RATING POINT (40 N/mm²)
              </div>

              {/* Day 1 Bar */}
              <div className="flex flex-col items-center gap-2 w-1/5">
                <div className="w-full bg-stone-900 h-8 rounded-sm relative">
                  <div className="absolute bottom-0 left-0 w-full bg-stone-750 h-full transition-all"></div>
                </div>
                <span className="text-[9px] text-stone-500 font-mono">Day 3 (12N)</span>
              </div>

              {/* Day 7 Bar */}
              <div className="flex flex-col items-center gap-2 w-1/5">
                <div className="w-full bg-stone-900 h-20 rounded-sm relative">
                  <div className="absolute bottom-0 left-0 w-full bg-stone-600 h-full transition-all"></div>
                </div>
                <span className="text-[9px] text-stone-500 font-mono">Day 7 (28N)</span>
              </div>

              {/* Day 28 Bar */}
              <div className="flex flex-col items-center gap-2 w-1/5">
                <div className="w-full bg-stone-900 h-32 rounded-sm relative">
                  <div className="absolute bottom-0 left-0 w-full bg-brass h-full transition-all animate-pulse"></div>
                </div>
                <span className="text-[9px] text-brass font-bold font-mono">Day 28 (42N)</span>
              </div>

              {/* Day 56 Bar */}
              <div className="flex flex-col items-center gap-2 w-1/5">
                <div className="w-full bg-stone-900 h-36 rounded-sm relative">
                  <div className="absolute bottom-0 left-0 w-full bg-emerald-600 h-full transition-all"></div>
                </div>
                <span className="text-[9px] text-emerald-400 font-mono">Day 56 (52N)</span>
              </div>
            </div>

            <p className="text-[10px] text-stone-500 italic mt-4 leading-relaxed">
              *EcoMix mixtures with GGBS slag cure slower during the initial 7 days but achieve higher density, lower permeability, and superior ultimate strength at 56 days.
            </p>
          </div>
        </div>

        {/* Certifications: Right */}
        <div className="lg:col-span-5 flex flex-col justify-between">
          <div className="bg-stone-950 p-6 border border-stone-900 rounded-sm">
            <span className="text-[9px] tracking-widest text-stone-500 font-bold block uppercase mb-4">
              REGULATORY CERTIFICATIONS
            </span>
            <h4 className="font-serif text-lg text-white mb-6">
              National Compliance & Traceability
            </h4>

            <ul className="flex flex-col gap-6 text-xs">
              {certifications.map((cert, index) => (
                <li key={index} className="flex items-start gap-3.5 pb-4 border-b border-stone-900 last:border-b-0">
                  <FlaskConical className="w-4 h-4 text-brass shrink-0 mt-0.5" />
                  <div>
                    <p className="text-white font-medium">{cert.label}</p>
                    <p className="text-[10px] text-stone-500 mt-1 font-mono">{cert.value}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>

          <div className="bg-stone-900/20 p-6 border border-stone-900 rounded-sm mt-6">
            <div className="flex items-center gap-2 text-rose-400 text-[10px] font-bold uppercase tracking-widest mb-2">
              <ShieldAlert className="w-4 h-4" />
              <span>Chloride Limitation Standard</span>
            </div>
            <p className="text-xs text-stone-400 leading-relaxed font-sans">
              For reinforced structures, chloride class <code className="text-white bg-stone-900 px-1 py-0.5 rounded">Cl 0.20</code> is enforced across all mixes to prevent corrosion of steel reinforcement rebar, complying fully with BS 8500-1 requirements.
            </p>
          </div>
        </div>

      </section>

    </div>
  );
}
