'use client';

import { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Leaf, 
  HelpCircle, 
  TrendingDown, 
  Trees, 
  Car, 
  ChevronRight, 
  Building 
} from 'lucide-react';

export default function SustainabilityPage() {
  const [volume, setVolume] = useState(250); // Default concrete volume in cubic meters
  const [phase, setPhase] = useState('foundations');

  // Carbon metrics (kg CO2e per cubic meter)
  const opcEmissions = 320; // Ordinary Portland Cement
  const ecoMixEmissions = 190; // EcoMix (GGBS 35%)
  const novacemEmissions = 98; // Novacem (Clay 65%)

  // Total calculations (in kilograms)
  const totalOPC = volume * opcEmissions;
  const totalEco = volume * ecoMixEmissions;
  const totalNova = volume * novacemEmissions;

  // Savings
  const ecoSavings = totalOPC - totalEco;
  const novaSavings = totalOPC - totalNova;

  // Equivalent offsets
  // Trees planted offset: 1 tree absorbs ~22kg of CO2 per year
  const treesEco = Math.round(ecoSavings / 22);
  const treesNova = Math.round(novaSavings / 22);

  // Car miles offset: Average passenger car emits ~0.2kg CO2 per km
  const carMilesEco = Math.round(ecoSavings / 0.2);
  const carMilesNova = Math.round(novaSavings / 0.2);

  return (
    <div className="bg-charcoal min-h-screen text-white pt-32 pb-24">
      
      {/* Page Header */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 mb-16">
        <div className="border-b border-stone-900 pb-12">
          <span className="text-xs tracking-[0.3em] text-brass font-bold block mb-4">
            ENVIRONMENTAL RESPONSIBILITY
          </span>
          <h1 className="font-serif text-4xl md:text-5xl lg:text-7xl leading-none text-white tracking-tight animate-fade-in">
            Sustainable Practices
          </h1>
          <p className="text-stone-400 text-xs sm:text-sm max-w-2xl mt-6 leading-relaxed">
            The British construction industry is targeting Net Zero by 2050. Bradford Cement Works is at the forefront of this transition, replacing clinker with industrial slag and calcined clays to slash carbon footprints without sacrificing compressive integrity.
          </p>
        </div>
      </section>

      {/* Carbon Mitigation Calculator Simulator */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 mb-20">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 bg-charcoal-light border border-stone-900 rounded-sm overflow-hidden concrete-grain">
          
          {/* Calculator inputs: Left */}
          <div className="lg:col-span-5 p-8 lg:p-12 border-b lg:border-b-0 lg:border-r border-stone-900">
            <div className="flex items-center gap-2 text-brass text-xs font-semibold tracking-widest uppercase mb-6">
              <Leaf className="w-4 h-4" />
              <span>Carbon Mitigation Calculator</span>
            </div>

            <h3 className="font-serif text-2xl text-white mb-6">
              Estimate Your Embodied Carbon Footprint
            </h3>

            {/* Volume Input slider */}
            <div className="flex flex-col gap-3 mb-8">
              <div className="flex justify-between items-end">
                <label className="text-[10px] text-stone-500 font-bold tracking-widest uppercase">
                  CONCRETE VOLUME (m³)
                </label>
                <span className="text-xl font-serif text-brass font-bold">
                  {volume.toLocaleString()} m³
                </span>
              </div>
              <input
                type="range"
                min="10"
                max="5000"
                step="10"
                value={volume}
                onChange={(e) => setVolume(Number(e.target.value))}
                className="w-full h-1 bg-stone-800 accent-brass rounded-lg cursor-pointer outline-none"
              />
              <div className="flex justify-between text-[9px] text-stone-600 font-mono">
                <span>10 m³</span>
                <span>2,500 m³</span>
                <span>5,000 m³</span>
              </div>
            </div>

            {/* Project Phase Selector */}
            <div className="flex flex-col gap-3 mb-8">
              <label className="text-[10px] text-stone-500 font-bold tracking-widest uppercase">
                CONSTRUCTION PROJECT SECTOR
              </label>
              <div className="flex flex-col gap-2">
                {[
                  { id: 'foundations', label: 'Underground Foundations (High-Density Pours)' },
                  { id: 'frame', label: 'Structural Columns & Frames' },
                  { id: 'facades', label: 'Architectural Cladding & Facades' }
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setPhase(item.id)}
                    className={`text-left text-xs py-3.5 px-4 rounded-sm border transition-all duration-300 ${
                      phase === item.id
                        ? 'border-brass bg-stone-900/60 text-white font-semibold'
                        : 'border-stone-800 text-stone-400 hover:border-stone-700 bg-transparent'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            <p className="text-[11px] text-stone-500 leading-relaxed italic">
              *Calculations are based on verified Environmental Product Declarations (EPD) and benchmarked against standard UK baseline concrete mixes.
            </p>
          </div>

          {/* Calculator outputs / graphs: Right */}
          <div className="lg:col-span-7 p-8 lg:p-12 flex flex-col justify-between">
            
            {/* Visual Bars Comparison */}
            <div className="flex flex-col gap-6">
              <h4 className="text-[10px] tracking-widest text-stone-400 font-bold uppercase mb-2">
                EMBODIED CO2 COMPARISON (TONNES)
              </h4>

              {/* Bar 1: OPC */}
              <div className="flex flex-col gap-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-stone-500">Standard Portland (CEM I) Baseline</span>
                  <span className="text-white font-semibold">{(totalOPC / 1000).toFixed(1)} t CO2e</span>
                </div>
                <div className="w-full bg-stone-900 h-3 rounded-full overflow-hidden">
                  <div className="bg-stone-600 h-full w-full"></div>
                </div>
              </div>

              {/* Bar 2: EcoMix */}
              <div className="flex flex-col gap-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-brass font-medium">Bradford EcoMix (35% GGBS)</span>
                  <span className="text-brass font-bold">{(totalEco / 1000).toFixed(1)} t CO2e</span>
                </div>
                <div className="w-full bg-stone-900 h-3 rounded-full overflow-hidden">
                  <div 
                    className="bg-brass h-full transition-all duration-500"
                    style={{ width: `${(totalEco / totalOPC) * 100}%` }}
                  ></div>
                </div>
              </div>

              {/* Bar 3: Novacem */}
              <div className="flex flex-col gap-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-emerald-500 font-medium">Bradford Novacem (65% clay)</span>
                  <span className="text-emerald-400 font-bold">{(totalNova / 1000).toFixed(1)} t CO2e</span>
                </div>
                <div className="w-full bg-stone-900 h-3 rounded-full overflow-hidden">
                  <div 
                    className="bg-emerald-600 h-full transition-all duration-500"
                    style={{ width: `${(totalNova / totalOPC) * 100}%` }}
                  ></div>
                </div>
              </div>
            </div>

            {/* Saving Indices Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-8 border-t border-stone-900 mt-8">
              
              {/* Eco Savings Summary */}
              <div className="bg-stone-950 p-5 border border-stone-900 rounded-sm flex flex-col justify-between">
                <div>
                  <span className="text-[8px] tracking-widest text-brass font-bold uppercase block mb-1">
                    ECO-MIX SAVINGS INDEX
                  </span>
                  <span className="font-serif text-xl font-bold text-white block mb-3">
                    {((totalOPC - totalEco) / 1000).toFixed(1)} Tonnes Offset
                  </span>
                </div>
                
                <div className="flex flex-col gap-2.5 text-xs text-stone-500">
                  <div className="flex items-center gap-2">
                    <Trees className="w-4 h-4 text-emerald-500 shrink-0" />
                    <span>Absorbed by <strong className="text-white">{treesEco.toLocaleString()}</strong> trees yearly</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Car className="w-4 h-4 text-brass shrink-0" />
                    <span>Or offsetting <strong className="text-white">{carMilesEco.toLocaleString()}</strong> km car exhaust</span>
                  </div>
                </div>
              </div>

              {/* Novacem Savings Summary */}
              <div className="bg-stone-950 p-5 border border-stone-900 rounded-sm flex flex-col justify-between">
                <div>
                  <span className="text-[8px] tracking-widest text-emerald-500 font-bold uppercase block mb-1">
                    NOVACEM IMPACT INDEX
                  </span>
                  <span className="font-serif text-xl font-bold text-emerald-400 block mb-3">
                    {((totalOPC - totalNova) / 1000).toFixed(1)} Tonnes Offset
                  </span>
                </div>

                <div className="flex flex-col gap-2.5 text-xs text-stone-500">
                  <div className="flex items-center gap-2">
                    <Trees className="w-4 h-4 text-emerald-500 shrink-0" />
                    <span>Absorbed by <strong className="text-white">{treesNova.toLocaleString()}</strong> trees yearly</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Car className="w-4 h-4 text-brass shrink-0" />
                    <span>Or offsetting <strong className="text-white">{carMilesNova.toLocaleString()}</strong> km car exhaust</span>
                  </div>
                </div>
              </div>

            </div>

          </div>

        </div>

      </section>

      {/* Sustainable Core Actions list */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 grid grid-cols-1 md:grid-cols-3 gap-8 pt-16 border-t border-stone-900">
        
        <div className="p-4">
          <TrendingDown className="w-6 h-6 text-brass mb-4" />
          <h4 className="font-serif text-lg text-white mb-2">Clinker Substitution</h4>
          <p className="text-xs text-stone-400 leading-relaxed font-sans">
            By substituting Portland cement clinker with Ground Granulated Blast-furnace Slag (GGBS) and pulverized fuel ash, we divert waste from industrial metals smelting while reinforcing concrete against acids and sulphates.
          </p>
        </div>

        <div className="p-4">
          <Trees className="w-6 h-6 text-brass mb-4" />
          <h4 className="font-serif text-lg text-white mb-2">Local Aggregates Focus</h4>
          <p className="text-xs text-stone-400 leading-relaxed font-sans">
            Over 95% of our sand, water, and coarse stone aggregates are sourced from quarries within a 35-mile radius of Bradford. This minimizes heavy haulage emissions, supporting the local Yorkshire economy.
          </p>
        </div>

        <div className="p-4">
          <Building className="w-6 h-6 text-brass mb-4" />
          <h4 className="font-serif text-lg text-white mb-2">Eco-Paving & Reclaim</h4>
          <p className="text-xs text-stone-400 leading-relaxed font-sans">
            All wash water at our Canal Road batching yard is collected, filtered, and recirculated back into new mixtures. Over-poured concrete is cast into structural retaining interlocking blocks to prevent material waste.
          </p>
        </div>

      </section>

    </div>
  );
}
