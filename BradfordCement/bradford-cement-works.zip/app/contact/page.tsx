'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Mail, 
  Phone, 
  MapPin, 
  Building2, 
  Send, 
  CheckCircle2, 
  ShieldCheck, 
  Briefcase 
} from 'lucide-react';

export default function ContactPage() {
  // Form State
  const [formData, setFormData] = useState({
    name: '',
    organisation: '',
    role: 'architect',
    email: '',
    phone: '',
    location: '',
    volume: '',
    message: ''
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // Validate form fields
  const validateForm = () => {
    const tempErrors: Record<string, string> = {};
    if (!formData.name.trim()) tempErrors.name = 'Specifier name is required.';
    if (!formData.organisation.trim()) tempErrors.organisation = 'Organisation or practice is required.';
    if (!formData.email.trim()) {
      tempErrors.email = 'Email address is required.';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      tempErrors.email = 'Please enter a valid email address.';
    }
    if (!formData.phone.trim()) tempErrors.phone = 'Direct telephone line is required.';
    if (!formData.message.trim()) tempErrors.message = 'Please provide brief details about your concrete spec needs.';

    setErrors(tempErrors);
    return Object.keys(tempErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    setSubmitting(true);
    // Simulate real database or email submission
    setTimeout(() => {
      setSubmitting(false);
      setSubmitted(true);
    }, 1500);
  };

  return (
    <div className="bg-charcoal min-h-screen text-white pt-32 pb-24">
      
      {/* Page Header */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 mb-16">
        <div className="border-b border-stone-900 pb-12">
          <span className="text-xs tracking-[0.3em] text-brass font-bold block mb-4">
            COMMERCIAL ENQUIRIES & ADVISORY
          </span>
          <h1 className="font-serif text-4xl md:text-5xl lg:text-7xl leading-none text-white tracking-tight">
            Work With Us
          </h1>
          <p className="text-stone-400 text-xs sm:text-sm max-w-2xl mt-6 leading-relaxed">
            Ready to specify a custom structural mix, request aggregate panel samples, or book a consulting session in our Bradford laboratory? Complete our technical spec request below, and our engineering desk will respond within 24 hours.
          </p>
        </div>
      </section>

      {/* Main split grid: Form Left, Contact Details Right */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-stretch">
          
          {/* Enquiry Form: Left (7 Cols) */}
          <div className="lg:col-span-7 bg-charcoal-light p-6 sm:p-10 border border-stone-900 rounded-sm relative concrete-grain">
            <div className="absolute top-0 left-0 w-full h-[2px] bg-brass"></div>

            <AnimatePresence mode="wait">
              {!submitted ? (
                <motion.form
                  key="contact-form"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  onSubmit={handleSubmit}
                  className="space-y-6"
                >
                  <div className="border-b border-stone-850 pb-4 mb-2">
                    <h3 className="font-serif text-lg text-white">Technical Specifier Desk</h3>
                    <p className="text-[10px] text-stone-500 mt-1 uppercase tracking-wider">Please provide concrete parameters below</p>
                  </div>

                  {/* 1. Name & Organisation row */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div className="flex flex-col gap-2">
                      <label htmlFor="name" className="text-[9px] text-stone-400 font-bold tracking-widest uppercase">
                        Specifier Name *
                      </label>
                      <input
                        id="name"
                        type="text"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="py-3 px-4 bg-stone-950 border border-stone-900 focus:border-brass outline-none text-xs text-white rounded-sm transition-all"
                        placeholder="e.g. Rachel Foster"
                      />
                      {errors.name && <span className="text-[10px] text-rose-500">{errors.name}</span>}
                    </div>

                    <div className="flex flex-col gap-2">
                      <label htmlFor="organisation" className="text-[9px] text-stone-400 font-bold tracking-widest uppercase">
                        Organisation / Practice *
                      </label>
                      <input
                        id="organisation"
                        type="text"
                        value={formData.organisation}
                        onChange={(e) => setFormData({ ...formData, organisation: e.target.value })}
                        className="py-3 px-4 bg-stone-950 border border-stone-900 focus:border-brass outline-none text-xs text-white rounded-sm transition-all"
                        placeholder="e.g. Foster + Partners"
                      />
                      {errors.organisation && <span className="text-[10px] text-rose-500">{errors.organisation}</span>}
                    </div>
                  </div>

                  {/* 2. Professional Role Selector */}
                  <div className="flex flex-col gap-2">
                    <label htmlFor="role" className="text-[9px] text-stone-400 font-bold tracking-widest uppercase">
                      Professional Practice Role
                    </label>
                    <select
                      id="role"
                      value={formData.role}
                      onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                      className="py-3 px-4 bg-stone-950 border border-stone-900 focus:border-brass outline-none text-xs text-stone-300 rounded-sm cursor-pointer transition-all"
                    >
                      <option value="architect">Architect & Urban Designer</option>
                      <option value="engineer">Structural / Materials Engineer</option>
                      <option value="developer">Real Estate Developer / Client Representative</option>
                      <option value="contractor">Main Contractor / Estimator</option>
                      <option value="other">Other / Self-Builder</option>
                    </select>
                  </div>

                  {/* 3. Contact Coordinates row */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div className="flex flex-col gap-2">
                      <label htmlFor="email" className="text-[9px] text-stone-400 font-bold tracking-widest uppercase">
                        Direct Email Address *
                      </label>
                      <input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="py-3 px-4 bg-stone-950 border border-stone-900 focus:border-brass outline-none text-xs text-white rounded-sm transition-all"
                        placeholder="specifications@yourpractice.com"
                      />
                      {errors.email && <span className="text-[10px] text-rose-500">{errors.email}</span>}
                    </div>

                    <div className="flex flex-col gap-2">
                      <label htmlFor="phone" className="text-[9px] text-stone-400 font-bold tracking-widest uppercase">
                        Telephone Number *
                      </label>
                      <input
                        id="phone"
                        type="text"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        className="py-3 px-4 bg-stone-950 border border-stone-900 focus:border-brass outline-none text-xs text-white rounded-sm transition-all"
                        placeholder="+44 (0) 20 7000 0000"
                      />
                      {errors.phone && <span className="text-[10px] text-rose-500">{errors.phone}</span>}
                    </div>
                  </div>

                  {/* 4. Project specifics row */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div className="flex flex-col gap-2">
                      <label htmlFor="location" className="text-[9px] text-stone-400 font-bold tracking-widest uppercase">
                        Project Site Location
                      </label>
                      <input
                        id="location"
                        type="text"
                        value={formData.location}
                        onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                        className="py-3 px-4 bg-stone-950 border border-stone-900 focus:border-brass outline-none text-xs text-white rounded-sm transition-all"
                        placeholder="e.g. Shipley, West Yorkshire"
                      />
                    </div>

                    <div className="flex flex-col gap-2">
                      <label htmlFor="volume" className="text-[9px] text-stone-400 font-bold tracking-widest uppercase">
                        Est. Volume Target (m³)
                      </label>
                      <input
                        id="volume"
                        type="text"
                        value={formData.volume}
                        onChange={(e) => setFormData({ ...formData, volume: e.target.value })}
                        className="py-3 px-4 bg-stone-950 border border-stone-900 focus:border-brass outline-none text-xs text-white rounded-sm transition-all"
                        placeholder="e.g. 1,400 m³"
                      />
                    </div>
                  </div>

                  {/* 5. Message Vision paragraph */}
                  <div className="flex flex-col gap-2">
                    <label htmlFor="message" className="text-[9px] text-stone-400 font-bold tracking-widest uppercase">
                      Architectural Vision & Mixture Requirements *
                    </label>
                    <textarea
                      id="message"
                      rows={5}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="py-3 px-4 bg-stone-950 border border-stone-900 focus:border-brass outline-none text-xs text-white rounded-sm resize-none transition-all"
                      placeholder="Please outline your structural strength target, environmental exposure risk (XC3, marine), and desired aesthetic finish (e.g. acid-etched texture, warm alabaster tone)..."
                    />
                    {errors.message && <span className="text-[10px] text-rose-500">{errors.message}</span>}
                  </div>

                  {/* Action submission button */}
                  <button
                    type="submit"
                    disabled={submitting}
                    className="w-full py-4 bg-brass hover:bg-brass-dark disabled:bg-stone-850 disabled:text-stone-500 text-charcoal font-bold text-xs tracking-widest uppercase transition-all flex items-center justify-center gap-3 rounded-sm cursor-pointer active:scale-[0.99]"
                  >
                    {submitting ? (
                      <span>TRANSMITTING ENQUIRY TO EST. DESK...</span>
                    ) : (
                      <>
                        <Send className="w-4 h-4 text-charcoal" />
                        <span>Submit Project Specification Request</span>
                      </>
                    )}
                  </button>

                </motion.form>
              ) : (
                <motion.div
                  key="success-card"
                  initial={{ opacity: 0, scale: 0.98 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="flex flex-col items-center justify-center text-center py-16 px-4"
                >
                  <CheckCircle2 className="w-16 h-16 text-brass mb-6 animate-pulse" />
                  <h3 className="font-serif text-3xl text-white mb-2">
                    Enquiry Logged Securely
                  </h3>
                  <p className="text-xs text-stone-400 tracking-widest uppercase font-mono mb-4">
                    TRANSMISSION ID: BCW-{Math.floor(Math.random() * 900000) + 100000}
                  </p>
                  <p className="text-sm text-stone-300 leading-relaxed max-w-md mb-8">
                    Thank you, <strong className="text-white">{formData.name}</strong> of <strong className="text-white">{formData.organisation}</strong>. Our specification estimators have received your project details for <strong className="text-white">{formData.location || 'your UK site'}</strong> and will compile our BS 8500 quotation profile.
                  </p>
                  <button
                    onClick={() => {
                      setSubmitted(false);
                      setFormData({
                        name: '',
                        organisation: '',
                        role: 'architect',
                        email: '',
                        phone: '',
                        location: '',
                        volume: '',
                        message: ''
                      });
                    }}
                    className="py-3 px-6 bg-stone-900 hover:bg-stone-850 border border-stone-800 hover:border-brass text-xs tracking-widest text-white font-bold uppercase transition-all rounded-sm"
                  >
                    Submit Another Enquiry
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Location details & Map placeholder: Right (5 Cols) */}
          <div className="lg:col-span-5 flex flex-col justify-between gap-12">
            
            {/* Contact details Card */}
            <div className="bg-stone-950 p-8 border border-stone-900 rounded-sm">
              <span className="text-[9px] tracking-widest text-stone-500 font-bold block uppercase mb-6">
                HEADQUARTERS & BATCHING PLANT
              </span>

              <h3 className="font-serif text-2xl text-white mb-6">
                Bradford Cement Works Ltd.
              </h3>

              <ul className="flex flex-col gap-6 text-xs text-stone-400">
                <li className="flex items-start gap-3.5 pb-4 border-b border-stone-900">
                  <MapPin className="w-5 h-5 text-brass shrink-0 mt-0.5" />
                  <div>
                    <span className="text-[8px] text-stone-500 tracking-widest block uppercase font-bold mb-1">PLANT LOCATION</span>
                    <span className="text-white">
                      Canal Road Industrial Sector,<br />
                      Bradford, West Yorkshire, BD2 1AL
                    </span>
                  </div>
                </li>
                <li className="flex items-start gap-3.5 pb-4 border-b border-stone-900">
                  <Phone className="w-5 h-5 text-brass shrink-0 mt-0.5" />
                  <div>
                    <span className="text-[8px] text-stone-500 tracking-widest block uppercase font-bold mb-1">TELEPHONE DESK</span>
                    <a href="tel:+441274555191" className="text-white hover:text-brass transition-colors font-medium">
                      +44 (0) 1274 555 191
                    </a>
                  </div>
                </li>
                <li className="flex items-start gap-3.5">
                  <Mail className="w-5 h-5 text-brass shrink-0 mt-0.5" />
                  <div>
                    <span className="text-[8px] text-stone-500 tracking-widest block uppercase font-bold mb-1">SPECIFIER DIRECT EMAIL</span>
                    <a href="mailto:specifications@bradfordcement.co.uk" className="text-white hover:text-brass transition-colors font-medium">
                      specifications@bradfordcement.co.uk
                    </a>
                  </div>
                </li>
              </ul>
            </div>

            {/* Geological Map / Location visual */}
            <div className="bg-stone-950 p-6 border border-stone-900 rounded-sm relative overflow-hidden flex-grow flex flex-col justify-between min-h-[250px]">
              {/* Subtle map coordinates grid */}
              <div className="absolute inset-0 pointer-events-none opacity-10">
                <div className="w-full h-full border-r border-stone-700 absolute left-1/3"></div>
                <div className="w-full h-full border-r border-stone-700 absolute left-2/3"></div>
                <div className="w-full h-full border-b border-stone-700 absolute top-1/2"></div>
              </div>

              <div className="z-10">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-2.5 h-2.5 rounded-full bg-brass animate-ping"></div>
                  <span className="text-[8px] tracking-widest text-brass font-mono uppercase font-bold">BATCHING PLOT BD2</span>
                </div>
                <h4 className="font-serif text-sm font-semibold text-stone-300">
                  Bradford Canal Transit Hub
                </h4>
                <p className="text-[10px] text-stone-500 mt-1 leading-relaxed max-w-xs font-sans">
                  Sited immediately adjacent to the historical Bradford canal shipping routes, providing deep-density industrial loading access.
                </p>
              </div>

              <div className="z-10 flex items-center justify-between border-t border-stone-900 pt-4 mt-6">
                <span className="text-[8px] text-stone-500 font-mono">LAT: 53.8052° N · LONG: -1.7483° W</span>
                <span className="text-[8px] text-emerald-500 font-mono font-bold flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>ISO 9001 PLOT ACCREDITATION</span>
                </span>
              </div>
            </div>

          </div>

        </div>
      </section>

    </div>
  );
}
