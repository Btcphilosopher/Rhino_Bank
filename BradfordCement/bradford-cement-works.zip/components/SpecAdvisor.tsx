'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Cpu, 
  Settings2, 
  Leaf, 
  ShieldCheck, 
  CornerDownRight, 
  Loader2, 
  Sparkles, 
  Download, 
  RefreshCw 
} from 'lucide-react';

const applications = [
  { id: 'foundation', label: 'Underground Structural Foundations (Heavy Load)', desc: 'Engineered for high compressive resistance, soil sulphates, and zero moisture ingress.' },
  { id: 'precast', label: 'Precast Architectural Facades (High Finish)', desc: 'Optimized for visual perfection, smooth formwork release, and sharp edge casting.' },
  { id: 'interior', label: 'Bespoke Polished Terrazzo Floors & Walls', desc: 'Crafted with fine aggregates and pigments for diamond-polishing and interior aesthetics.' },
  { id: 'infrastructure', label: 'Civic Bridges & Marine Environments', desc: 'Saturated water resistance, high chloride blocking, and extreme lifespan (120+ years).' },
  { id: 'paving', label: 'High-Traffic Pedestrian Paving & Plazas', desc: 'Abrasion-resistant aggregates with micro-texture for safety and slip prevention.' },
];

const carbonBudgets = [
  { id: 'standard', label: 'Standard Portland Mix', desc: 'Traditional CEM I mix, optimized for strength but with standard CO2 profile (320kg CO2/m³).', saving: '0% CO2 Reduction' },
  { id: 'ecomix', label: 'Bradford EcoMix (GGBS)', desc: 'Substitutes 35% cement with ground granulated blast-furnace slag, lowering embodied carbon.', saving: '35% CO2 Reduction' },
  { id: 'zero', label: 'Bradford Novacem (Limestone-Clay)', desc: 'Ultra-low carbon breakthrough using calcined clay and limestone flour for ultimate mitigation.', saving: '65% CO2 Reduction' },
];

const exposureClasses = [
  { id: 'xc3', label: 'XC3 - Moderate Carbonation (General Outdoor)', desc: 'Reinforced concrete exposed to outdoor air and fluctuating moisture levels.' },
  { id: 'xs1', label: 'XS1 - Salt Aerosols (De-icing / Marine Aerosols)', desc: 'Concrete exposed to airborne salt, bridges near seawater, or highways.' },
  { id: 'xf3', label: 'XF3 - Severe Freeze-Thaw Saturation', desc: 'High moisture environments exposed to freezing temperatures (Yorkshire Moors conditions).' },
  { id: 'xa2', label: 'XA2 - Moderate Chemical Soil Sulphate Attack', desc: 'Concrete in contact with aggressive natural soil or aggressive groundwater.' },
  { id: 'c1', label: 'C1 - Low-Risk Interior Climate', desc: 'Concrete inside buildings with low relative humidity, zero corrosion risk.' },
];

interface SpecResult {
  strengthClass: string;
  wcRatio: string;
  cementType: string;
  localAggregates: string;
  carbonStats: string;
  placementAdvice: string;
  description: string;
  specifications: Array<{ parameter: string; value: string }>;
}

export default function SpecAdvisor() {
  const [app, setApp] = useState(applications[0].id);
  const [carbon, setCarbon] = useState(carbonBudgets[1].id);
  const [exposure, setExposure] = useState(exposureClasses[0].id);
  
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<SpecResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleGenerateSpec = async () => {
    setLoading(true);
    setError(null);
    try {
      const selectedApp = applications.find(a => a.id === app)?.label;
      const selectedCarbon = carbonBudgets.find(c => c.id === carbon)?.label;
      const selectedExposure = exposureClasses.find(e => e.id === exposure)?.label;

      const response = await fetch('/api/spec-advisor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          application: selectedApp,
          carbonBudget: selectedCarbon,
          exposureClass: selectedExposure,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to compute technical spec. Please verify server connection.');
      }

      const data = await response.json();
      setResult(data);
    } catch (err: any) {
      setError(err.message || 'An unexpected server error occurred.');
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setResult(null);
    setError(null);
  };

  return (
    <div className="w-full bg-charcoal-light border border-stone-900 rounded-sm overflow-hidden concrete-grain">
      <div className="p-6 md:p-8 lg:p-12">
        
        {/* Component Header */}
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 pb-8 border-b border-stone-800">
          <div>
            <div className="flex items-center gap-2 text-brass text-xs font-semibold tracking-widest uppercase mb-1">
              <Cpu className="w-4 h-4" />
              <span>AI Materials Laboratory</span>
            </div>
            <h3 className="font-serif text-2xl md:text-3xl text-white">
              Bespoke Mixture Specification Advisor
            </h3>
            <p className="text-xs text-stone-400 mt-2 max-w-2xl leading-relaxed">
              Define your physical structural boundaries and environmental exposures. Our server-side neural materials model will formulate a compliant UK BS 8500 specification matching Yorkshire geological aggregates.
            </p>
          </div>
          {result && (
            <button
              onClick={handleReset}
              className="flex items-center gap-2 text-xs font-bold tracking-widest text-brass hover:text-white transition-colors uppercase py-2 px-4 border border-brass/40 hover:border-white shrink-0"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Reconfigure Mix</span>
            </button>
          )}
        </div>

        <AnimatePresence mode="wait">
          {!result ? (
            <motion.div
              key="selector-form"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-8 pt-8"
            >
              {/* Form Selectors: Left/Center */}
              <div className="lg:col-span-8 flex flex-col gap-8">
                
                {/* 1. Application Selection */}
                <div>
                  <label className="flex items-center gap-2 text-xs font-bold tracking-widest text-stone-400 uppercase mb-3">
                    <Settings2 className="w-4 h-4 text-brass" />
                    <span>01 / Structural Application</span>
                  </label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {applications.map((item) => (
                      <button
                        key={item.id}
                        onClick={() => setApp(item.id)}
                        className={`text-left p-4 border transition-all duration-300 rounded-sm relative flex flex-col justify-between h-full ${
                          app === item.id
                            ? 'border-brass bg-stone-900/60 shadow-lg'
                            : 'border-stone-800 hover:border-stone-700 bg-transparent'
                        }`}
                      >
                        <div className="font-serif text-sm font-semibold text-white mb-1.5 flex items-start gap-2">
                          <CornerDownRight className={`w-3.5 h-3.5 shrink-0 mt-0.5 ${app === item.id ? 'text-brass' : 'text-stone-600'}`} />
                          <span>{item.label}</span>
                        </div>
                        <span className="text-[10px] text-stone-500 leading-relaxed">
                          {item.desc}
                        </span>
                        {app === item.id && (
                          <div className="absolute top-2 right-2 w-1.5 h-1.5 bg-brass"></div>
                        )}
                      </button>
                    ))}
                  </div>
                </div>

                {/* 2. Carbon Mitigation Level */}
                <div>
                  <label className="flex items-center gap-2 text-xs font-bold tracking-widest text-stone-400 uppercase mb-3">
                    <Leaf className="w-4 h-4 text-brass" />
                    <span>02 / Embodied Carbon Level</span>
                  </label>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    {carbonBudgets.map((item) => (
                      <button
                        key={item.id}
                        onClick={() => setCarbon(item.id)}
                        className={`text-left p-4 border transition-all duration-300 rounded-sm relative flex flex-col justify-between h-full ${
                          carbon === item.id
                            ? 'border-brass bg-stone-900/60 shadow-lg'
                            : 'border-stone-800 hover:border-stone-700 bg-transparent'
                        }`}
                      >
                        <div>
                          <div className="font-serif text-sm font-semibold text-white mb-1">
                            {item.label}
                          </div>
                          <span className="text-[9px] text-brass font-bold tracking-widest uppercase block mb-2">
                            {item.saving}
                          </span>
                        </div>
                        <span className="text-[10px] text-stone-500 leading-relaxed">
                          {item.desc}
                        </span>
                        {carbon === item.id && (
                          <div className="absolute top-2 right-2 w-1.5 h-1.5 bg-brass"></div>
                        )}
                      </button>
                    ))}
                  </div>
                </div>

                {/* 3. Exposure Classes */}
                <div>
                  <label className="flex items-center gap-2 text-xs font-bold tracking-widest text-stone-400 uppercase mb-3">
                    <ShieldCheck className="w-4 h-4 text-brass" />
                    <span>03 / Environmental Exposure Class (BS EN 206)</span>
                  </label>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                    {exposureClasses.map((item) => (
                      <button
                        key={item.id}
                        onClick={() => setExposure(item.id)}
                        className={`text-left p-4 border transition-all duration-300 rounded-sm relative flex flex-col justify-between h-full ${
                          exposure === item.id
                            ? 'border-brass bg-stone-900/60 shadow-lg'
                            : 'border-stone-800 hover:border-stone-700 bg-transparent'
                        }`}
                      >
                        <div className="font-serif text-sm font-semibold text-white mb-1.5">
                          {item.label}
                        </div>
                        <span className="text-[10px] text-stone-500 leading-relaxed">
                          {item.desc}
                        </span>
                        {exposure === item.id && (
                          <div className="absolute top-2 right-2 w-1.5 h-1.5 bg-brass"></div>
                        )}
                      </button>
                    ))}
                  </div>
                </div>

              </div>

              {/* Advisory Trigger Sidebar: Right */}
              <div className="lg:col-span-4 flex flex-col justify-between border-l border-stone-800 lg:pl-8">
                <div className="flex flex-col gap-6">
                  <div className="bg-stone-900/40 p-6 border border-stone-800/80 rounded-sm">
                    <h4 className="text-[10px] tracking-widest text-stone-400 font-bold uppercase mb-4">
                      CURRENT ADVISORY STATE
                    </h4>
                    
                    <ul className="flex flex-col gap-4 text-xs">
                      <li className="flex flex-col gap-1">
                        <span className="text-[9px] text-stone-500 tracking-wider uppercase">APPLICATION</span>
                        <span className="text-white font-medium">
                          {applications.find(a => a.id === app)?.label.split(' (')[0]}
                        </span>
                      </li>
                      <li className="flex flex-col gap-1">
                        <span className="text-[9px] text-stone-500 tracking-wider uppercase">CARBON BUDGET</span>
                        <span className="text-brass font-semibold">
                          {carbonBudgets.find(c => c.id === carbon)?.label}
                        </span>
                      </li>
                      <li className="flex flex-col gap-1">
                        <span className="text-[9px] text-stone-500 tracking-wider uppercase">EXPOSURE RATING</span>
                        <span className="text-white font-medium">
                          {exposureClasses.find(e => e.id === exposure)?.label.split(' - ')[0]}
                        </span>
                      </li>
                    </ul>
                  </div>

                  <p className="text-[11px] text-stone-500 leading-relaxed">
                    By submitting these engineering limits, our custom materials platform queries the Bradford neural formulation system, compiling exact chemical compositions and aggregate bounds to optimize tensile resistance, aesthetics, and carbon footprint.
                  </p>
                </div>

                <div className="pt-6 lg:pt-0">
                  <button
                    onClick={handleGenerateSpec}
                    disabled={loading}
                    className="w-full py-4 px-6 bg-brass text-charcoal text-xs tracking-widest font-bold uppercase hover:bg-brass-dark disabled:bg-stone-800 disabled:text-stone-500 transition-all duration-300 flex items-center justify-center gap-3 rounded-sm active:scale-[0.98]"
                  >
                    {loading ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin text-charcoal" />
                        <span>Formulating Mix Recipe...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4 text-charcoal" />
                        <span>Compile Technical Specification</span>
                      </>
                    )}
                  </button>
                  {error && (
                    <p className="text-xs text-rose-500 mt-3 text-center">
                      {error}
                    </p>
                  )}
                </div>
              </div>

            </motion.div>
          ) : (
            <motion.div
              key="spec-result"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="pt-8"
            >
              {/* Output Presentation */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                
                {/* Left/Center: Recipe details & explanation */}
                <div className="lg:col-span-8 flex flex-col gap-6">
                  
                  {/* Headline & Strength Indicators */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="bg-stone-900 p-4 border border-stone-800 rounded-sm">
                      <span className="text-[9px] text-stone-500 tracking-wider uppercase block mb-1">
                        BS COMPRESSIVE STRENGTH
                      </span>
                      <span className="font-serif text-2xl font-bold text-brass">
                        {result.strengthClass}
                      </span>
                    </div>
                    <div className="bg-stone-900 p-4 border border-stone-800 rounded-sm">
                      <span className="text-[9px] text-stone-500 tracking-wider uppercase block mb-1">
                        WATER/CEMENT RATIO
                      </span>
                      <span className="font-serif text-2xl font-bold text-white">
                        {result.wcRatio}
                      </span>
                    </div>
                    <div className="bg-stone-900 p-4 border border-stone-800 rounded-sm">
                      <span className="text-[9px] text-stone-500 tracking-wider uppercase block mb-1">
                        CARBON OFFSET METRIC
                      </span>
                      <span className="font-serif text-xl font-bold text-emerald-500 leading-none mt-1 block">
                        {result.carbonStats}
                      </span>
                    </div>
                  </div>

                  {/* General Engineering Rationale */}
                  <div className="border-l-2 border-brass pl-6 py-2 my-2">
                    <h4 className="text-xs font-bold tracking-widest text-stone-400 uppercase mb-2">
                      ENGINEERING COMPOSITION ANALYSIS
                    </h4>
                    <div className="text-sm text-stone-300 leading-relaxed space-y-4 font-serif">
                      {result.description.split('\n\n').map((para, index) => (
                        <p key={index}>{para}</p>
                      ))}
                    </div>
                  </div>

                  {/* Secondary Details: local agg, placement */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-4 border-t border-stone-850">
                    <div>
                      <h5 className="text-[10px] tracking-widest font-bold text-brass uppercase mb-2">
                        YORKSHIRE AGGREGATE BOUND
                      </h5>
                      <p className="text-xs text-stone-400 leading-relaxed">
                        {result.localAggregates}
                      </p>
                    </div>
                    <div>
                      <h5 className="text-[10px] tracking-widest font-bold text-brass uppercase mb-2">
                        NORTHERN CLIMATE PLACEMENT ADVICE
                      </h5>
                      <p className="text-xs text-stone-400 leading-relaxed">
                        {result.placementAdvice}
                      </p>
                    </div>
                  </div>

                </div>

                {/* Right: Technical Datasheet Card */}
                <div className="lg:col-span-4">
                  <div className="bg-stone-950 p-6 border-2 border-stone-800/80 rounded-sm relative">
                    <div className="absolute top-4 right-4 w-2 h-2 bg-brass animate-pulse"></div>
                    
                    <div className="border-b border-stone-850 pb-4 mb-4">
                      <span className="text-[8px] tracking-widest text-stone-500 uppercase font-mono">
                        BRADFORD MATERIAL LAB // NO. {Math.floor(Math.random() * 900000) + 100000}
                      </span>
                      <h4 className="font-serif text-lg text-white mt-1">
                        FORMULATED MIX SHEET
                      </h4>
                      <p className="text-[10px] text-stone-500 mt-1">
                        Target design bounds conform to BS 8500-1 structural requirements.
                      </p>
                    </div>

                    {/* Specifications List */}
                    <dl className="flex flex-col gap-3 text-xs mb-6">
                      <div className="flex justify-between items-center py-1.5 border-b border-stone-900">
                        <dt className="text-stone-500">Cement Combination</dt>
                        <dd className="text-white font-medium text-right">{result.cementType}</dd>
                      </div>
                      {result.specifications.map((spec, i) => (
                        <div key={i} className="flex justify-between items-start py-1.5 border-b border-stone-900 gap-4">
                          <dt className="text-stone-500 shrink-0">{spec.parameter}</dt>
                          <dd className="text-white font-medium text-right">{spec.value}</dd>
                        </div>
                      ))}
                    </dl>

                    {/* PDF/Print Action Button */}
                    <button
                      onClick={() => window.print()}
                      className="w-full py-3 px-4 bg-stone-900 border border-stone-800 hover:border-brass text-[10px] tracking-widest text-white hover:text-brass font-bold uppercase transition-all duration-300 flex items-center justify-center gap-2 rounded-sm"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Print / Download Datasheet</span>
                    </button>
                  </div>
                </div>

              </div>
            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </div>
  );
}
