'use client';

import Link from 'next/link';
import { Mail, Phone, MapPin, ArrowUpRight } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  const handleScrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-charcoal border-t border-stone-900 pt-16 pb-8 text-stone-400 font-sans relative overflow-hidden">
      {/* Subtle concrete grid background divider lines */}
      <div className="absolute inset-0 pointer-events-none opacity-5">
        <div className="w-full h-full border-r border-stone-800 absolute left-1/4"></div>
        <div className="w-full h-full border-r border-stone-800 absolute left-1/2"></div>
        <div className="w-full h-full border-r border-stone-800 absolute left-3/4"></div>
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-12 relative z-10">
        
        {/* Main Footer Sections */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-8 pb-12 border-b border-stone-900">
          
          {/* Brand Column */}
          <div className="flex flex-col gap-6">
            <Link href="/" className="flex items-center gap-3 group">
              <div className="w-7 h-7 flex items-center justify-center border border-brass/40">
                <span className="font-serif font-bold text-sm text-brass">B</span>
              </div>
              <div className="flex flex-col">
                <span className="font-serif text-xs tracking-widest text-white font-bold">
                  BRADFORD
                </span>
                <span className="font-sans text-[8px] tracking-[0.3em] text-stone-500 mt-0.5">
                  CEMENT WORKS
                </span>
              </div>
            </Link>
            <p className="text-xs text-stone-500 leading-relaxed max-w-xs">
              Pioneering architectural concrete engineering since 1918. Formed in Bradford, delivering structural and aesthetic mixtures across Great Britain.
            </p>
            <div className="flex flex-wrap gap-x-4 gap-y-1 text-[10px] tracking-wider text-stone-500">
              <span>ISO 9001:2015</span>
              <span>·</span>
              <span>ISO 14001:2015</span>
              <span>·</span>
              <span>UKAS Quality</span>
            </div>
          </div>

          {/* Navigation Links Column */}
          <div className="flex flex-col gap-4">
            <h4 className="text-xs font-bold tracking-widest text-white uppercase">
              CAPABILITIES
            </h4>
            <ul className="flex flex-col gap-2.5 text-xs">
              <li>
                <Link href="/bespoke-cement" className="hover:text-brass transition-colors duration-200">
                  Bespoke Cement Mixes
                </Link>
              </li>
              <li>
                <Link href="/bespoke-cement" className="hover:text-brass transition-colors duration-200">
                  Architectural Concrete Panels
                </Link>
              </li>
              <li>
                <Link href="/technical" className="hover:text-brass transition-colors duration-200">
                  Structural Technical Spec
                </Link>
              </li>
              <li>
                <Link href="/sustainability" className="hover:text-brass transition-colors duration-200">
                  Eco-Conscious Limestone
                </Link>
              </li>
            </ul>
          </div>

          {/* Directory Column */}
          <div className="flex flex-col gap-4">
            <h4 className="text-xs font-bold tracking-widest text-white uppercase">
              RESOURCES
            </h4>
            <ul className="flex flex-col gap-2.5 text-xs">
              <li>
                <Link href="/our-work" className="hover:text-brass transition-colors duration-200">
                  Featured Projects
                </Link>
              </li>
              <li>
                <Link href="/about" className="hover:text-brass transition-colors duration-200">
                  Victorian Industrial Heritage
                </Link>
              </li>
              <li>
                <Link href="/technical" className="hover:text-brass transition-colors duration-200">
                  Datasheets & Downloads
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-brass transition-colors duration-200">
                  Request Mixture Advisory
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Details Column */}
          <div className="flex flex-col gap-4">
            <h4 className="text-xs font-bold tracking-widest text-white uppercase">
              HEAD OFFICE & LABS
            </h4>
            <ul className="flex flex-col gap-3 text-xs text-stone-400">
              <li className="flex items-start gap-2.5">
                <MapPin className="w-3.5 h-3.5 text-brass shrink-0 mt-0.5" />
                <span>
                  Canal Road Industrial Sector,<br />
                  Bradford, West Yorkshire, BD2 1AL
                </span>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="w-3.5 h-3.5 text-brass shrink-0" />
                <a href="tel:+441274555191" className="hover:text-brass transition-colors">
                  +44 (0) 1274 555 191
                </a>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="w-3.5 h-3.5 text-brass shrink-0" />
                <a href="mailto:specifications@bradfordcement.co.uk" className="hover:text-brass transition-colors">
                  specifications@bradfordcement.co.uk
                </a>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar: Copyright & Top-Scroll */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex flex-col md:flex-row items-center gap-2 md:gap-6 text-[10px] tracking-widest text-stone-500">
            <span>© {currentYear} BRADFORD CEMENT WORKS LIMITED.</span>
            <div className="flex items-center gap-4 mt-2 md:mt-0">
              <Link href="/contact" className="hover:text-white transition-colors">PRIVACY POLICY</Link>
              <span>·</span>
              <Link href="/contact" className="hover:text-white transition-colors">TERMS OF SALE</Link>
              <span>·</span>
              <Link href="/contact" className="hover:text-white transition-colors">SITEMAP</Link>
            </div>
          </div>

          <button
            onClick={handleScrollToTop}
            className="flex items-center gap-2 text-[10px] tracking-widest text-stone-400 hover:text-brass font-bold transition-colors duration-300 group"
          >
            <span>RETURN TO TOP</span>
            <ArrowUpRight className="w-3.5 h-3.5 text-stone-500 group-hover:text-brass transition-colors duration-300" />
          </button>
        </div>

      </div>
    </footer>
  );
}
