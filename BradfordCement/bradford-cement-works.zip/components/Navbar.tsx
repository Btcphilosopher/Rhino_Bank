'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { MapPin, Menu, X, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const navLinks = [
  { label: 'HOME', href: '/' },
  { label: 'OUR WORK', href: '/our-work' },
  { label: 'BESPOKE CEMENT', href: '/bespoke-cement' },
  { label: 'TECHNICAL', href: '/technical' },
  { label: 'SUSTAINABILITY', href: '/sustainability' },
  { label: 'ABOUT', href: '/about' },
  { label: 'CONTACT', href: '/contact' },
];

export default function Navbar() {
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu on path change
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [pathname]);

  return (
    <>
      <header
        className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 border-b ${
          scrolled
            ? 'bg-charcoal/95 backdrop-blur-md py-4 border-stone-800 shadow-xl'
            : 'bg-transparent py-6 border-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 lg:px-12 flex items-center justify-between">
          
          {/* Zone 1: Logo Wordmark */}
          <Link href="/" className="flex items-center gap-3 group shrink-0">
            <div className="relative w-8 h-8 flex items-center justify-center border border-brass/40 group-hover:border-brass transition-all duration-300">
              <span className="font-serif font-bold text-lg text-brass tracking-tight">B</span>
              <div className="absolute top-0 left-0 w-1.5 h-1.5 border-t border-l border-brass/60"></div>
              <div className="absolute bottom-0 right-0 w-1.5 h-1.5 border-b border-r border-brass/60"></div>
            </div>
            <div className="flex flex-col">
              <span className="font-serif text-sm tracking-widest text-white leading-none font-bold group-hover:text-brass transition-colors duration-300">
                BRADFORD
              </span>
              <span className="font-sans text-[9px] tracking-[0.3em] text-concrete leading-none mt-1">
                CEMENT WORKS
              </span>
            </div>
          </Link>

          {/* Zone 2: Navigation Links */}
          <nav className="hidden lg:flex items-center gap-6 xl:gap-8">
            {navLinks.map((link) => {
              const isActive = pathname === link.href;
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`text-xs font-semibold tracking-widest relative py-1.5 transition-colors duration-300 ${
                    isActive ? 'text-brass' : 'text-stone-300 hover:text-white'
                  }`}
                >
                  {link.label}
                  {isActive && (
                    <motion.div
                      layoutId="activeNavBorder"
                      className="absolute bottom-0 left-0 w-full h-[1px] bg-brass"
                      transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                    />
                  )}
                </Link>
              );
            })}
          </nav>

          {/* Zone 3: Location & Secondary Detail Block (Desktop only) */}
          <div className="hidden xl:flex items-center gap-6 border-l border-stone-800 pl-6 shrink-0">
            <div className="flex items-center gap-2">
              <MapPin className="w-3.5 h-3.5 text-brass" />
              <div className="flex flex-col text-left">
                <span className="text-[10px] tracking-widest text-white font-semibold leading-none">
                  BRADFORD
                </span>
                <span className="text-[8px] tracking-widest text-stone-500 leading-none mt-1">
                  WEST YORKSHIRE
                </span>
              </div>
            </div>
            <div className="flex flex-col text-right">
              <span className="text-[9px] tracking-widest text-stone-400 font-medium">
                BESPOKE MIXES
              </span>
              <span className="text-[8px] tracking-widest text-brass font-semibold mt-1">
                FOR A HIGHER TOMORROW
              </span>
            </div>
          </div>

          {/* Mobile Actions: CTA + Menu Toggle */}
          <div className="flex lg:hidden items-center gap-4">
            <Link
              href="/contact"
              className="px-3 py-1.5 text-[10px] tracking-widest bg-brass hover:bg-brass-dark text-charcoal font-bold transition-all duration-300 rounded-sm"
            >
              ENQUIRE
            </Link>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-1 text-stone-300 hover:text-white transition-colors"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </header>

      {/* Mobile Menu Slideout */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            className="fixed top-0 left-0 w-full h-screen bg-charcoal/98 z-40 pt-28 px-8 flex flex-col justify-between pb-12 overflow-y-auto"
          >
            <div className="flex flex-col gap-6">
              {navLinks.map((link, idx) => {
                const isActive = pathname === link.href;
                return (
                  <motion.div
                    key={link.href}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.05 }}
                  >
                    <Link
                      href={link.href}
                      className={`text-xl font-serif tracking-widest flex items-center justify-between group ${
                        isActive ? 'text-brass font-semibold' : 'text-stone-300'
                      }`}
                    >
                      <span>{link.label}</span>
                      <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-100 group-hover:translate-x-1 transition-all text-brass" />
                    </Link>
                  </motion.div>
                );
              })}
            </div>

            <div className="border-t border-stone-800 pt-8 flex flex-col gap-4">
              <div className="flex items-center gap-3">
                <MapPin className="w-4 h-4 text-brass" />
                <span className="text-xs tracking-widest text-stone-400">
                  BRADFORD, WEST YORKSHIRE
                </span>
              </div>
              <p className="text-[10px] tracking-wider text-stone-500 max-w-xs">
                Premium architectural cement and concrete engineering for premier developers & contractors.
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
