package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.Persona
import com.example.ui.viewmodel.YorkCemViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            YorkCemTheme {
                val viewModel: YorkCemViewModel = viewModel()
                val currentPersona by viewModel.currentPersona.collectAsState()

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = {
                        YorkCemTopBar()
                    },
                    bottomBar = {
                        YorkCemBottomNavigation(
                            currentPersona = currentPersona,
                            onPersonaSelected = { viewModel.setPersona(it) }
                        )
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (currentPersona) {
                            Persona.DISPATCHER -> DispatcherScreen(viewModel = viewModel)
                            Persona.CUSTOMER -> CustomerScreen(viewModel = viewModel)
                            Persona.DRIVER -> DriverScreen(viewModel = viewModel)
                            Persona.DEPOT -> DepotScreen(viewModel = viewModel)
                            Persona.MANAGEMENT -> ManagementScreen(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun YorkCemTopBar() {
    CenterAlignedTopAppBar(
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PrecisionManufacturing,
                    contentDescription = null,
                    tint = YorkCemOrange,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "YORKCEM",
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.sp,
                    fontSize = 20.sp,
                    color = Color.White
                )
            }
        },
        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
            containerColor = YorkCemNavy
        )
    )
}

@Composable
fun YorkCemBottomNavigation(
    currentPersona: Persona,
    onPersonaSelected: (Persona) -> Unit
) {
    NavigationBar(
        containerColor = YorkCemNavy,
        tonalElevation = 8.dp,
        modifier = Modifier.testTag("persona_nav_bar")
    ) {
        val navItems = listOf(
            Triple(Persona.DISPATCHER, Icons.Default.Dashboard, "DISPATCH"),
            Triple(Persona.CUSTOMER, Icons.Default.Business, "CUSTOMER"),
            Triple(Persona.DRIVER, Icons.Default.LocalShipping, "DRIVER"),
            Triple(Persona.DEPOT, Icons.Default.Factory, "DEPOT"),
            Triple(Persona.MANAGEMENT, Icons.Default.BarChart, "ANALYTICS")
        )

        navItems.forEach { (persona, icon, label) ->
            NavigationBarItem(
                selected = currentPersona == persona,
                onClick = { onPersonaSelected(persona) },
                icon = {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = if (currentPersona == persona) YorkCemNavy else Color.White
                    )
                },
                label = {
                    Text(
                        text = label,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (currentPersona == persona) YorkCemStone else Color.White.copy(alpha = 0.7f)
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = YorkCemStone
                ),
                modifier = Modifier.testTag("nav_item_${label.lowercase()}")
            )
        }
    }
}
