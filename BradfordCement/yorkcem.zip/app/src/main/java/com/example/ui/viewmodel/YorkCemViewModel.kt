package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.YorkCemDatabase
import com.example.data.model.*
import com.example.data.repository.YorkCemRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

enum class Persona {
    DISPATCHER, CUSTOMER, DRIVER, DEPOT, MANAGEMENT
}

class YorkCemViewModel(application: Application) : AndroidViewModel(application) {

    private val database = YorkCemDatabase.getDatabase(application, viewModelScope)
    private val repository = YorkCemRepository(database.yorkCemDao())

    // UI Active Persona
    private val _currentPersona = MutableStateFlow(Persona.DISPATCHER)
    val currentPersona: StateFlow<Persona> = _currentPersona.asStateFlow()

    // Screen navigation parameters inside personas
    private val _currentCustomerScreen = MutableStateFlow("DASHBOARD") // "DASHBOARD", "ORDER_FORM", "TRACKING", "INVOICES"
    val currentCustomerScreen: StateFlow<String> = _currentCustomerScreen.asStateFlow()

    private val _currentDriverScreen = MutableStateFlow("SELECT_VEHICLE") // "SELECT_VEHICLE", "PRE_START", "WORKFLOW", "SITE_SAFETY", "DISCHARGE", "SIGNATURE"
    val currentDriverScreen: StateFlow<String> = _currentDriverScreen.asStateFlow()

    private val _selectedOrderIdForTracking = MutableStateFlow<Long?>(null)
    val selectedOrderIdForTracking: StateFlow<Long?> = _selectedOrderIdForTracking.asStateFlow()

    // State flows from database
    val products = repository.products.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val sites = repository.sites.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val vehicles = repository.vehicles.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val silos = repository.silos.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val orders = repository.orders.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val preStartChecks = repository.preStartChecks.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val loads = repository.loads.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val pods = repository.pods.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val auditLogs = repository.auditLogs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Driver workflow active states
    private val _selectedDriverVehicleReg = MutableStateFlow<String?>(null)
    val selectedDriverVehicleReg: StateFlow<String?> = _selectedDriverVehicleReg.asStateFlow()

    private val _activeDriverOrder = MutableStateFlow<Order?>(null)
    val activeDriverOrder: StateFlow<Order?> = _activeDriverOrder.asStateFlow()

    // Real-time active alerts
    private val _activeAlerts = MutableStateFlow<List<String>>(
        listOf(
            "ALERT: Silo 03 is running low (120 tonnes remaining). Refill scheduled.",
            "ALERT: YC-219 has maintenance flagged (REPAIR_REQUIRED) - brakes check overdue."
        )
    )
    val activeAlerts: StateFlow<List<String>> = _activeAlerts.asStateFlow()

    // In-memory support tickets
    private val _supportTickets = MutableStateFlow<List<Map<String, String>>>(
        listOf(
            mapOf("id" to "TKT-101", "orderId" to "#1", "type" to "Quantity Discrepancy", "text" to "Requested 24t, received 23.8t on site.", "status" to "RESOLVED"),
            mapOf("id" to "TKT-102", "orderId" to "#2", "type" to "Late Delivery", "text" to "Slight traffic delay on A650 Bradford approach.", "status" to "INVESTIGATING")
        )
    )
    val supportTickets: StateFlow<List<Map<String, String>>> = _supportTickets.asStateFlow()

    fun setPersona(persona: Persona) {
        _currentPersona.value = persona
    }

    fun setCustomerScreen(screen: String) {
        _currentCustomerScreen.value = screen
    }

    fun setDriverScreen(screen: String) {
        _currentDriverScreen.value = screen
    }

    fun setTrackingOrderId(id: Long?) {
        _selectedOrderIdForTracking.value = id
        if (id != null) {
            _currentCustomerScreen.value = "TRACKING"
        }
    }

    fun setDriverVehicle(reg: String?) {
        _selectedDriverVehicleReg.value = reg
        if (reg != null) {
            _currentDriverScreen.value = "PRE_START"
        } else {
            _currentDriverScreen.value = "SELECT_VEHICLE"
        }
    }

    fun selectActiveDriverOrder(order: Order) {
        _activeDriverOrder.value = order
        _currentDriverScreen.value = "WORKFLOW"
    }

    // --- OPERATIONAL TRANSACTIONS ---

    fun createOrder(
        customerName: String,
        siteId: String,
        productId: String,
        quantity: Double,
        deliveryWindow: String,
        vehicleType: String,
        phone: String,
        instructions: String,
        poNumber: String,
        specialReqs: String,
        isRecurring: Boolean = false,
        schedule: String? = null,
        projectId: String? = null
    ) {
        viewModelScope.launch {
            val product = products.value.find { it.productId == productId }
            val unitPrice = product?.price ?: 120.0
            val totalPrice = (unitPrice * quantity) + 150.0 // Unit price * quantity + base delivery charge

            val newOrder = Order(
                customerName = customerName,
                siteId = siteId,
                productId = productId,
                quantity = quantity,
                deliveryDate = SimpleDateFormat("yyyy-MM-dd", Locale.UK).format(Date()),
                deliveryWindow = deliveryWindow,
                vehicleTypeRequested = vehicleType,
                contactPhone = phone,
                siteInstructions = instructions,
                poNumber = poNumber,
                specialRequirements = specialReqs,
                status = "PLANNED",
                priceTotal = totalPrice,
                isRecurring = isRecurring,
                recurrenceSchedule = schedule,
                projectId = projectId
            )

            val orderId = repository.createOrder(newOrder)

            // Insert audit log
            repository.insertAuditLog(
                AuditLog(
                    orderId = orderId,
                    action = "ORDER_CREATED",
                    username = customerName,
                    timestamp = System.currentTimeMillis(),
                    details = "Order #$orderId created for $quantity tonnes of ${product?.productName ?: productId}.",
                    previousState = null,
                    newState = "PLANNED"
                )
            )

            // Silo inventory check triggers automated system alerts
            val targetSilo = silos.value.find { it.siloId == product?.siloId }
            if (targetSilo != null && targetSilo.availableQuantity < quantity) {
                _activeAlerts.value = _activeAlerts.value + "ALERT: Order #$orderId quantity ($quantity t) exceeds normal available silo stock in ${targetSilo.name}."
            }
        }
    }

    fun assignVehicleAndDriver(orderId: Long, vehicleReg: String, driverName: String) {
        viewModelScope.launch {
            val order = repository.getOrderById(orderId)
            val vehicle = repository.getVehicleByReg(vehicleReg)
            if (order != null && vehicle != null) {
                // Update vehicle state to active
                val updatedVehicle = vehicle.copy(
                    driverName = driverName,
                    availability = "ACTIVE"
                )
                repository.insertVehicle(updatedVehicle)

                // Update order state
                val updatedOrder = order.copy(
                    status = "APPROVED",
                    assignedVehicle = vehicleReg,
                    assignedDriver = driverName,
                    eta = calculateSimulatedEta(vehicleReg, order.siteId)
                )
                repository.updateOrder(updatedOrder)

                repository.insertAuditLog(
                    AuditLog(
                        orderId = orderId,
                        action = "VEHICLE_ASSIGNED",
                        username = "Dispatcher (System)",
                        timestamp = System.currentTimeMillis(),
                        details = "Assigned truck $vehicleReg to driver $driverName for order #$orderId.",
                        previousState = order.status,
                        newState = "APPROVED"
                    )
                )
            }
        }
    }

    fun submitDriverPreStart(
        reg: String,
        driver: String,
        tyres: Boolean,
        lights: Boolean,
        brakes: Boolean,
        hoses: Boolean,
        pressure: Boolean,
        emergency: Boolean,
        comment: String
    ) {
        viewModelScope.launch {
            val isPassed = tyres && lights && brakes && hoses && pressure && emergency
            val check = PreStartCheck(
                vehicleReg = reg,
                timestamp = System.currentTimeMillis(),
                driverName = driver,
                tyresPassed = tyres,
                lightsPassed = lights,
                brakesPassed = brakes,
                hosesPassed = hoses,
                pressurePassed = pressure,
                emergencyEquipmentPassed = emergency,
                comment = comment,
                isOverallPassed = isPassed
            )
            repository.insertPreStartCheck(check)

            // Update vehicle status based on pre-start
            val vehicle = repository.getVehicleByReg(reg)
            if (vehicle != null) {
                val updatedVehicle = vehicle.copy(
                    availability = if (isPassed) "AVAILABLE" else "MAINTENANCE",
                    maintenanceStatus = if (isPassed) "GOOD" else "REPAIR_REQUIRED"
                )
                repository.insertVehicle(updatedVehicle)
            }

            if (!isPassed) {
                _activeAlerts.value = _activeAlerts.value + "ALERT: Vehicle $reg failed pre-start check under driver $driver! Flagged for immediate maintenance."
            }

            // Progress Driver Screen to Workflow if passed
            if (isPassed) {
                _currentDriverScreen.value = "WORKFLOW"
            } else {
                _selectedDriverVehicleReg.value = null
                _currentDriverScreen.value = "SELECT_VEHICLE"
            }
        }
    }

    fun startLoadingProcess(orderId: Long) {
        viewModelScope.launch {
            val order = repository.getOrderById(orderId)
            if (order != null) {
                val updatedOrder = order.copy(status = "LOADING")
                repository.updateOrder(updatedOrder)

                val vehicle = order.assignedVehicle?.let { repository.getVehicleByReg(it) }
                if (vehicle != null) {
                    repository.insertVehicle(vehicle.copy(availability = "ACTIVE"))
                }

                repository.insertAuditLog(
                    AuditLog(
                        orderId = orderId,
                        action = "LOAD_STARTED",
                        username = order.assignedDriver ?: "Silo Operator",
                        timestamp = System.currentTimeMillis(),
                        details = "Truck loading sequence initiated at Yorkshire depot.",
                        previousState = order.status,
                        newState = "LOADING"
                    )
                )
            }
        }
    }

    fun completeLoadingProcess(orderId: Long, actualQuantity: Double, operatorName: String) {
        viewModelScope.launch {
            val order = repository.getOrderById(orderId)
            if (order != null) {
                val product = products.value.find { it.productId == order.productId }
                val silo = product?.siloId?.let { repository.getSiloById(it) }

                // Record load management record
                val loadRecord = LoadManagement(
                    orderId = orderId,
                    truckReg = order.assignedVehicle ?: "MOCK-TRK",
                    productName = product?.productName ?: order.productId,
                    siloId = product?.siloId ?: "SILO-01",
                    batchCode = product?.batch ?: "BATCH-MOCK",
                    targetQuantity = order.quantity,
                    actualQuantity = actualQuantity,
                    operatorName = operatorName,
                    timestamp = System.currentTimeMillis()
                )
                repository.insertLoad(loadRecord)

                // Decrease Silo stock
                if (silo != null) {
                    val updatedSilo = silo.copy(
                        currentQuantity = (silo.currentQuantity - actualQuantity).coerceAtLeast(0.0),
                        availableQuantity = (silo.availableQuantity - actualQuantity).coerceAtLeast(0.0),
                        status = if (silo.currentQuantity - actualQuantity < 300.0) "LOW" else "NORMAL"
                    )
                    repository.insertSilo(updatedSilo)

                    if (updatedSilo.status == "LOW") {
                        _activeAlerts.value = _activeAlerts.value + "ALERT: Inventory low in ${updatedSilo.name}! Level down to ${updatedSilo.currentQuantity.toInt()} tonnes."
                    }
                }

                val updatedOrder = order.copy(status = "LOADED")
                repository.updateOrder(updatedOrder)

                repository.insertAuditLog(
                    AuditLog(
                        orderId = orderId,
                        action = "LOAD_COMPLETED",
                        username = operatorName,
                        timestamp = System.currentTimeMillis(),
                        details = "Truck loaded: target ${order.quantity}t, actual ${actualQuantity}t from Silo ${silo?.siloId ?: "SILO-01"}.",
                        previousState = "LOADING",
                        newState = "LOADED"
                    )
                )

                // If active in driver portal, update active order
                if (_activeDriverOrder.value?.orderId == orderId) {
                    _activeDriverOrder.value = updatedOrder
                }
            }
        }
    }

    fun departDepot(orderId: Long) {
        viewModelScope.launch {
            val order = repository.getOrderById(orderId)
            if (order != null) {
                val updatedOrder = order.copy(status = "EN_ROUTE")
                repository.updateOrder(updatedOrder)

                repository.insertAuditLog(
                    AuditLog(
                        orderId = orderId,
                        action = "DELIVERY_DEPARTED",
                        username = order.assignedDriver ?: "Driver",
                        timestamp = System.currentTimeMillis(),
                        details = "Driver departed depot. En route to Yorkshire site with batch ${order.productId}.",
                        previousState = "LOADED",
                        newState = "EN_ROUTE"
                    )
                )

                if (_activeDriverOrder.value?.orderId == orderId) {
                    _activeDriverOrder.value = updatedOrder
                }
            }
        }
    }

    fun arriveAtSite(orderId: Long) {
        viewModelScope.launch {
            val order = repository.getOrderById(orderId)
            if (order != null) {
                val updatedOrder = order.copy(status = "ARRIVED")
                repository.updateOrder(updatedOrder)

                repository.insertAuditLog(
                    AuditLog(
                        orderId = orderId,
                        action = "ARRIVED",
                        username = order.assignedDriver ?: "Driver",
                        timestamp = System.currentTimeMillis(),
                        details = "Vehicle entered geofence boundary of ${order.siteId}.",
                        previousState = "EN_ROUTE",
                        newState = "ARRIVED"
                    )
                )

                if (_activeDriverOrder.value?.orderId == orderId) {
                    _activeDriverOrder.value = updatedOrder
                    _currentDriverScreen.value = "SITE_SAFETY"
                }
            }
        }
    }

    fun confirmSiteSafety(orderId: Long) {
        _currentDriverScreen.value = "DISCHARGE"
    }

    fun completeDischarge(
        orderId: Long,
        deliveredQty: Double,
        signatureName: String,
        pointsData: String,
        exceptions: String,
        notes: String
    ) {
        viewModelScope.launch {
            val order = repository.getOrderById(orderId)
            if (order != null) {
                val variance = deliveredQty - order.quantity
                val product = products.value.find { it.productId == order.productId }

                // Insert Proof of Delivery (POD)
                val pod = ProofOfDelivery(
                    orderId = orderId,
                    customerName = order.customerName,
                    siteName = order.siteId,
                    productName = product?.productName ?: order.productId,
                    quantityDelivered = deliveredQty,
                    batchCode = product?.batch ?: "BATCH-MOCK",
                    vehicleReg = order.assignedVehicle ?: "YC-MOCK",
                    driverName = order.assignedDriver ?: "Driver",
                    arrivalTime = "10:15",
                    completionTime = SimpleDateFormat("HH:mm", Locale.UK).format(Date()),
                    signatureName = signatureName,
                    signaturePointsData = pointsData,
                    hasPhoto = exceptions.isNotEmpty(),
                    photoUri = if (exceptions.isNotEmpty()) "mock_photo_evidence.png" else null,
                    exceptions = exceptions,
                    notes = notes
                )
                repository.insertPod(pod)

                // Update Order status to COMPLETED
                val updatedOrder = order.copy(
                    status = "COMPLETED",
                    variance = variance
                )
                repository.updateOrder(updatedOrder)

                // Reset Vehicle state to AVAILABLE
                val vehicle = order.assignedVehicle?.let { repository.getVehicleByReg(it) }
                if (vehicle != null) {
                    val updatedVehicle = vehicle.copy(
                        availability = "AVAILABLE",
                        odometer = vehicle.odometer + 45 // Add simulated trip mileage
                    )
                    repository.insertVehicle(updatedVehicle)
                }

                repository.insertAuditLog(
                    AuditLog(
                        orderId = orderId,
                        action = "DISCHARGE_COMPLETED",
                        username = order.assignedDriver ?: "Driver",
                        timestamp = System.currentTimeMillis(),
                        details = "Discharge finished. Net delivered: ${deliveredQty}t. Variance: ${variance}t. POD recorded.",
                        previousState = "ARRIVED",
                        newState = "COMPLETED"
                    )
                )

                // If variance is outside a 10% threshold, trigger system warning flag
                if (Math.abs(variance) > (order.quantity * 0.1)) {
                    _activeAlerts.value = _activeAlerts.value + "ALERT: Delivery discrepancy on Order #$orderId. Ordered: ${order.quantity}t, Delivered: ${deliveredQty}t."
                }

                // Complete driver flow
                _activeDriverOrder.value = null
                _currentDriverScreen.value = "SELECT_VEHICLE"
            }
        }
    }

    fun submitSupportTicket(orderId: String, issueType: String, text: String) {
        val newTicket = mapOf(
            "id" to "TKT-${100 + _supportTickets.value.size + 1}",
            "orderId" to orderId,
            "type" to issueType,
            "text" to text,
            "status" to "SUBMITTED"
        )
        _supportTickets.value = _supportTickets.value + newTicket
    }

    // Helper to calculate a simulated UK ETA (e.g. 10:12 + or - variance)
    private fun calculateSimulatedEta(vehicleReg: String, siteId: String): String {
        val cal = Calendar.getInstance()
        cal.add(Calendar.MINUTE, 45) // Simulated travel time is 45 mins
        val format = SimpleDateFormat("HH:mm", Locale.UK)
        return format.format(cal.time)
    }

    // Simulation tool to manually inject mechanical breakdown event
    fun simulateBreakdown(reg: String) {
        viewModelScope.launch {
            val vehicle = repository.getVehicleByReg(reg)
            if (vehicle != null) {
                repository.insertVehicle(vehicle.copy(availability = "MAINTENANCE", maintenanceStatus = "REPAIR_REQUIRED"))
                _activeAlerts.value = _activeAlerts.value + "ALERT: YC-BREAKDOWN! Vehicle $reg reports critical compressor failure en route. Reallocation required."

                // Find active en_route order assigned to this vehicle
                val activeOrder = orders.value.find { it.assignedVehicle == reg && it.status == "EN_ROUTE" }
                if (activeOrder != null) {
                    val updated = activeOrder.copy(status = "APPROVED", assignedVehicle = null, assignedDriver = null)
                    repository.updateOrder(updated)
                    repository.insertAuditLog(
                        AuditLog(
                            orderId = activeOrder.orderId,
                            action = "VEHICLE_BREAKDOWN",
                            username = "System Telemetry",
                            timestamp = System.currentTimeMillis(),
                            details = "Vehicle $reg breakdown occurred. Delivery of ${activeOrder.quantity}t to ${activeOrder.siteId} rolled back to PLANNED for reallocation.",
                            previousState = "EN_ROUTE",
                            newState = "APPROVED"
                        )
                    )
                }
            }
        }
    }
}
