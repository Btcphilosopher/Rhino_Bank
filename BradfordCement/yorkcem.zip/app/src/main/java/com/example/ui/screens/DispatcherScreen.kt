package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Order
import com.example.data.model.Vehicle
import com.example.ui.theme.*
import com.example.ui.viewmodel.YorkCemViewModel
import kotlinx.coroutines.launch

// Yorkshire city node coords for custom canvas map
data class YorkshireNode(val name: String, val x: Float, val y: Float, val isDepot: Boolean = false)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DispatcherScreen(
    viewModel: YorkCemViewModel,
    modifier: Modifier = Modifier
) {
    val orders by viewModel.orders.collectAsState()
    val vehicles by viewModel.vehicles.collectAsState()
    val silos by viewModel.silos.collectAsState()
    val activeAlerts by viewModel.activeAlerts.collectAsState()

    var showAssignDialog by remember { mutableStateOf<Order?>(null) }
    var selectedVehicleRegForAssignment by remember { mutableStateOf("") }
    var driverNameInput by remember { mutableStateOf("") }

    val scope = rememberCoroutineScope()

    val yorkshireNodes = listOf(
        YorkshireNode("Leeds Depot", 0.5f, 0.45f, isDepot = true),
        YorkshireNode("Bradford", 0.3f, 0.40f),
        YorkshireNode("Wakefield", 0.55f, 0.65f),
        YorkshireNode("Huddersfield", 0.25f, 0.70f),
        YorkshireNode("Halifax", 0.20f, 0.55f),
        YorkshireNode("York", 0.85f, 0.25f),
        YorkshireNode("Harrogate", 0.60f, 0.20f),
        YorkshireNode("Sheffield", 0.65f, 0.90f),
        YorkshireNode("Skipton", 0.15f, 0.25f),
        YorkshireNode("Keighley", 0.18f, 0.35f)
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(YorkCemLightGrey)
            .padding(12.dp)
    ) {
        // Active System Alerts Ticker
        if (activeAlerts.isNotEmpty()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = YorkCemRed.copy(alpha = 0.1f)),
                border = BorderStroke(1.dp, YorkCemRed),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Alert Warning",
                        tint = YorkCemRed,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = activeAlerts.first(),
                        color = YorkCemRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                }
            }
        }

        // Split view: Left = Delivery Board / Controls, Right = Live Map & Telemetry
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // LEFT PANEL: TODAY'S ACTIVE DELIVERIES
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(2.dp),
                modifier = Modifier
                    .weight(1.2f)
                    .fillMaxHeight()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "TODAY'S OPERATIONAL BOARD",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = YorkCemNavy
                        )
                        Badge(containerColor = YorkCemNavy) {
                            Text(
                                text = "${orders.size} JOBS",
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    if (orders.isEmpty()) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.List, contentDescription = null, tint = YorkCemGrey, modifier = Modifier.size(48.dp))
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("No active orders found.", color = YorkCemGrey, fontSize = 14.sp)
                            }
                        }
                    } else {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(orders) { order ->
                                Card(
                                    colors = CardDefaults.cardColors(
                                        containerColor = when (order.status) {
                                            "COMPLETED" -> YorkCemLightGrey.copy(alpha = 0.5f)
                                            "EN_ROUTE" -> YorkCemNavy.copy(alpha = 0.05f)
                                            else -> Color.White
                                        }
                                    ),
                                    border = BorderStroke(
                                        width = 1.dp,
                                        color = when (order.status) {
                                            "COMPLETED" -> YorkCemGrey.copy(alpha = 0.3f)
                                            "EN_ROUTE" -> YorkCemNavy
                                            "ARRIVED", "DISCHARGING" -> YorkCemGreen
                                            "LOADING" -> YorkCemOrange
                                            else -> YorkCemGrey.copy(alpha = 0.5f)
                                        }
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("order_item_${order.orderId}")
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text(
                                                    text = "ORDER #${order.orderId} - ${order.customerName}",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 14.sp,
                                                    color = YorkCemNavy
                                                )
                                                Text(
                                                    text = "${order.siteId} | ${order.deliveryWindow}",
                                                    fontSize = 12.sp,
                                                    color = YorkCemGrey
                                                )
                                            }

                                            // Status Badge
                                            Surface(
                                                color = when (order.status) {
                                                    "PLANNED" -> YorkCemGrey.copy(alpha = 0.2f)
                                                    "APPROVED" -> YorkCemNavy
                                                    "LOADING" -> YorkCemOrange
                                                    "LOADED" -> YorkCemBlue
                                                    "EN_ROUTE" -> YorkCemNavy
                                                    "ARRIVED" -> YorkCemGreen
                                                    "DISCHARGING" -> YorkCemGreen
                                                    "COMPLETED" -> YorkCemGrey
                                                    else -> YorkCemGrey
                                                },
                                                shape = RoundedCornerShape(4.dp)
                                            ) {
                                                Text(
                                                    text = order.status,
                                                    color = if (order.status == "PLANNED") YorkCemNavy else Color.White,
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(6.dp))

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "Product: ${order.productId} (${order.quantity} tonnes)",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Medium,
                                                color = YorkCemNavy
                                            )
                                            if (order.assignedVehicle != null) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Icon(Icons.Default.LocalShipping, contentDescription = null, modifier = Modifier.size(14.dp), tint = YorkCemNavy)
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text(
                                                        text = "${order.assignedVehicle} (${order.assignedDriver})",
                                                        fontSize = 11.sp,
                                                        color = YorkCemNavy,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                            } else {
                                                Button(
                                                    onClick = { showAssignDialog = order },
                                                    colors = ButtonDefaults.buttonColors(containerColor = YorkCemOrange),
                                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                                    modifier = Modifier
                                                        .height(28.dp)
                                                        .testTag("assign_truck_btn_${order.orderId}")
                                                ) {
                                                    Text("ALLOCATE TRUCK", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                        }

                                        // Actions inside dispatch control for demo purposes
                                        if (order.status == "APPROVED" || order.status == "LOADING" || order.status == "LOADED") {
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.End,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                if (order.status == "APPROVED") {
                                                    TextButton(
                                                        onClick = { viewModel.startLoadingProcess(order.orderId) },
                                                        modifier = Modifier.height(28.dp)
                                                    ) {
                                                        Text("LOAD", color = YorkCemOrange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                                    }
                                                } else if (order.status == "LOADING") {
                                                    TextButton(
                                                        onClick = { viewModel.completeLoadingProcess(order.orderId, order.quantity, "Silo Op Pete") },
                                                        modifier = Modifier.height(28.dp)
                                                    ) {
                                                        Text("COMPLETE LOAD", color = YorkCemBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                                    }
                                                } else if (order.status == "LOADED") {
                                                    TextButton(
                                                        onClick = { viewModel.departDepot(order.orderId) },
                                                        modifier = Modifier.height(28.dp)
                                                    ) {
                                                        Text("DEPART TRUCK", color = YorkCemGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // RIGHT PANEL: LIVE YORKSHIRE MAP & FLEET STATUS
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Interactive Yorkshire Canvas Map
                Card(
                    colors = CardDefaults.cardColors(containerColor = YorkCemNavy),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1.2f)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "YORKSHIRE FLIGHT CONTROL",
                                color = YorkCemStone,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .background(YorkCemGreen, RoundedCornerShape(4.dp))
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("SYSTEMS OK", color = YorkCemGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        // Custom Map Drawing
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)
                                .background(YorkCemDarkPlate, RoundedCornerShape(8.dp))
                                .border(1.dp, YorkCemStone.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                val w = size.width
                                val h = size.height

                                // Draw County boundaries/grid
                                for (i in 1..4) {
                                    val gridX = w * (i / 5f)
                                    val gridY = h * (i / 5f)
                                    drawLine(
                                        color = YorkCemStone.copy(alpha = 0.05f),
                                        start = Offset(gridX, 0f),
                                        end = Offset(gridX, h),
                                        strokeWidth = 1f
                                    )
                                    drawLine(
                                        color = YorkCemStone.copy(alpha = 0.05f),
                                        start = Offset(0f, gridY),
                                        end = Offset(w, gridY),
                                        strokeWidth = 1f
                                    )
                                }

                                // Draw road links
                                val depotCoords = Offset(w * 0.5f, h * 0.45f) // Leeds Depot
                                yorkshireNodes.forEach { node ->
                                    if (!node.isDepot) {
                                        drawLine(
                                            color = YorkCemStone.copy(alpha = 0.25f),
                                            start = depotCoords,
                                            end = Offset(w * node.x, h * node.y),
                                            strokeWidth = 2f
                                        )
                                    }
                                }

                                // Draw Nodes
                                yorkshireNodes.forEach { node ->
                                    val center = Offset(w * node.x, h * node.y)
                                    drawCircle(
                                        color = if (node.isDepot) YorkCemOrange else YorkCemGrey,
                                        radius = if (node.isDepot) 12f else 8f,
                                        center = center
                                    )
                                    drawCircle(
                                        color = Color.White,
                                        radius = if (node.isDepot) 6f else 4f,
                                        center = center
                                    )
                                }

                                // Draw active vehicles on map
                                vehicles.forEachIndexed { index, vehicle ->
                                    // Map vehicles along road vectors depending on their state for mock animation
                                    val targetNode = yorkshireNodes.getOrNull((index + 1) % yorkshireNodes.size) ?: yorkshireNodes[0]
                                    val isMoving = vehicle.availability == "ACTIVE"
                                    val posRatio = if (isMoving) 0.6f else 0f
                                    val startX = w * 0.5f
                                    val startY = h * 0.45f
                                    val endX = w * targetNode.x
                                    val endY = h * targetNode.y

                                    val curX = startX + (endX - startX) * posRatio
                                    val curY = startY + (endY - startY) * posRatio

                                    // Draw truck locator glow
                                    drawCircle(
                                        color = if (vehicle.availability == "MAINTENANCE") YorkCemRed.copy(alpha = 0.4f) else YorkCemOrange.copy(alpha = 0.4f),
                                        radius = 20f,
                                        center = Offset(curX, curY)
                                    )
                                    drawCircle(
                                        color = if (vehicle.availability == "MAINTENANCE") YorkCemRed else YorkCemStone,
                                        radius = 7f,
                                        center = Offset(curX, curY)
                                    )
                                }
                            }

                            // Overlay labels for depots
                            yorkshireNodes.forEach { node ->
                                Box(
                                    modifier = Modifier
                                        .offset(
                                            x = (node.x * 240).coerceAtLeast(10f).dp,
                                            y = (node.y * 180).coerceAtLeast(10f).dp
                                        )
                                        .background(YorkCemNavy.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = node.name.uppercase(),
                                        color = Color.White,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                // FLEET MONITORS & MAINTENANCE REPORT
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "YORKCEM HEAVY-HAULAGE FLEET",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = YorkCemNavy
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(vehicles) { vehicle ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(YorkCemLightGrey, RoundedCornerShape(6.dp))
                                        .padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = vehicle.registration,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp,
                                                color = YorkCemNavy
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Surface(
                                                color = YorkCemNavy,
                                                shape = RoundedCornerShape(4.dp)
                                            ) {
                                                Text(
                                                    text = vehicle.fuelType,
                                                    color = Color.White,
                                                    fontSize = 9.sp,
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                )
                                            }
                                        }
                                        Text(
                                            text = "${vehicle.vehicleType} | Odo: ${vehicle.odometer} mi",
                                            fontSize = 11.sp,
                                            color = YorkCemGrey
                                        )
                                    }

                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        // Status Dot
                                        Surface(
                                            color = when (vehicle.availability) {
                                                "AVAILABLE" -> YorkCemGreen.copy(alpha = 0.2f)
                                                "ACTIVE" -> YorkCemOrange.copy(alpha = 0.2f)
                                                else -> YorkCemRed.copy(alpha = 0.2f)
                                            },
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Text(
                                                text = vehicle.availability,
                                                color = when (vehicle.availability) {
                                                    "AVAILABLE" -> YorkCemGreen
                                                    "ACTIVE" -> YorkCemOrange
                                                    else -> YorkCemRed
                                                },
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }

                                        // Simulated breakdown trigger for demo safety sequence
                                        if (vehicle.availability == "ACTIVE") {
                                            IconButton(
                                                onClick = { viewModel.simulateBreakdown(vehicle.registration) },
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.ReportProblem,
                                                    contentDescription = "Simulate breakdown",
                                                    tint = YorkCemRed,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // DIALOG FOR TRUCK ALLOCATION / DISPATCH
    if (showAssignDialog != null) {
        val targetOrder = showAssignDialog!!
        val availableTrucks = vehicles.filter { it.availability == "AVAILABLE" && it.maintenanceStatus == "GOOD" }

        AlertDialog(
            onDismissRequest = { showAssignDialog = null },
            title = { Text("ALLOCATE TRUCK & DRIVER", fontWeight = FontWeight.Bold, color = YorkCemNavy) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Select an available vehicle to fulfill Order #${targetOrder.orderId} (${targetOrder.quantity}t of CEM cement).", fontSize = 12.sp)

                    if (availableTrucks.isEmpty()) {
                        Text("No eligible vehicles available. Clear maintenance or complete existing jobs first.", color = YorkCemRed, fontWeight = FontWeight.Bold)
                    } else {
                        // Dropdown simulation/Selection
                        Text("Available Yorkshire Fleet Vehicles:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        LazyColumn(modifier = Modifier.height(140.dp)) {
                            items(availableTrucks) { truck ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { selectedVehicleRegForAssignment = truck.registration }
                                        .background(
                                            if (selectedVehicleRegForAssignment == truck.registration) YorkCemStone.copy(alpha = 0.3f)
                                            else Color.Transparent
                                        )
                                        .border(
                                            1.dp,
                                            if (selectedVehicleRegForAssignment == truck.registration) YorkCemNavy
                                            else YorkCemLightGrey
                                        )
                                        .padding(8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(truck.registration, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text("${truck.vehicleType} | Cap: ${truck.capacityTonnes}t", fontSize = 11.sp, color = YorkCemGrey)
                                    }
                                    if (selectedVehicleRegForAssignment == truck.registration) {
                                        Icon(Icons.Default.Check, contentDescription = null, tint = YorkCemNavy)
                                    }
                                }
                            }
                        }

                        OutlinedTextField(
                            value = driverNameInput,
                            onValueChange = { driverNameInput = it },
                            label = { Text("Driver Name") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("driver_name_input")
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (selectedVehicleRegForAssignment.isNotEmpty() && driverNameInput.isNotEmpty()) {
                            viewModel.assignVehicleAndDriver(targetOrder.orderId, selectedVehicleRegForAssignment, driverNameInput)
                            showAssignDialog = null
                            selectedVehicleRegForAssignment = ""
                            driverNameInput = ""
                        }
                    },
                    enabled = selectedVehicleRegForAssignment.isNotEmpty() && driverNameInput.isNotEmpty(),
                    colors = ButtonDefaults.buttonColors(containerColor = YorkCemNavy)
                ) {
                    Text("CONFIRM DISPATCH DISK")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAssignDialog = null }) {
                    Text("CANCEL")
                }
            }
        )
    }
}
