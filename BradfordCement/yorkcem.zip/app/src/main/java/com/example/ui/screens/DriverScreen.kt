package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Order
import com.example.data.model.Vehicle
import com.example.ui.theme.*
import com.example.ui.viewmodel.YorkCemViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun DriverScreen(
    viewModel: YorkCemViewModel,
    modifier: Modifier = Modifier
) {
    val currentScreen by viewModel.currentDriverScreen.collectAsState()
    val vehicles by viewModel.vehicles.collectAsState()
    val orders by viewModel.orders.collectAsState()
    val selectedReg by viewModel.selectedDriverVehicleReg.collectAsState()
    val activeOrder by viewModel.activeDriverOrder.collectAsState()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(YorkCemDarkPlate) // High contrast dark theme for easy outdoor reading
            .padding(16.dp)
    ) {
        when (currentScreen) {
            "SELECT_VEHICLE" -> DriverSelectVehicle(viewModel, vehicles)
            "PRE_START" -> DriverPreStartScreen(viewModel, selectedReg ?: "")
            "WORKFLOW" -> DriverWorkflowHub(viewModel, selectedReg ?: "", activeOrder, orders)
            "SITE_SAFETY" -> DriverSiteSafetyScreen(viewModel, activeOrder)
            "DISCHARGE" -> DriverDischargeScreen(viewModel, activeOrder)
            "SIGNATURE" -> DriverSignatureScreen(viewModel, activeOrder)
        }
    }
}

@Composable
fun DriverSelectVehicle(
    viewModel: YorkCemViewModel,
    vehicles: List<Vehicle>
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("YORKCEM DRIVER PORTAL", color = YorkCemStone, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("SELECT YOUR HAULER", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            }
            Icon(Icons.Default.LocalShipping, contentDescription = null, tint = YorkCemStone, modifier = Modifier.size(36.dp))
        }

        Text("Select vehicle to initiate mandatory pre-start inspection sequence:", color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp)

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(vehicles) { vehicle ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = YorkCemNavy),
                    border = BorderStroke(1.dp, YorkCemStone.copy(alpha = 0.3f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.setDriverVehicle(vehicle.registration) }
                        .testTag("driver_vehicle_${vehicle.registration}")
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(vehicle.registration, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color.White)
                            Text(vehicle.vehicleType, fontSize = 12.sp, color = YorkCemStone)
                            Text("Cap: ${vehicle.capacityTonnes}t | ${vehicle.fuelType}", fontSize = 11.sp, color = YorkCemGrey)
                        }
                        Icon(Icons.Default.ArrowForwardIos, contentDescription = null, tint = YorkCemStone, modifier = Modifier.size(20.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun DriverPreStartScreen(
    viewModel: YorkCemViewModel,
    vehicleReg: String
) {
    var tyres by remember { mutableStateOf(true) }
    var lights by remember { mutableStateOf(true) }
    var brakes by remember { mutableStateOf(true) }
    var hoses by remember { mutableStateOf(true) }
    var pressure by remember { mutableStateOf(true) }
    var emergency by remember { mutableStateOf(true) }
    var comments by remember { mutableStateOf("") }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Text("VEHICLE PRE-START INSPECTION", color = YorkCemStone, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text("CHECKLIST: $vehicleReg", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Confirm heavy vehicle condition prior to depot dispatch loading.", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
        }

        // Checklist Items
        val itemsList = listOf(
            Triple("Tyre Condition & Nut Torque", tyres, { tyres = !tyres }),
            Triple("Lights, Markers & Indicators", lights, { lights = !lights }),
            Triple("Air Brakes & Retarder System", brakes, { brakes = !brakes }),
            Triple("Pneumatic Delivery Hoses & Couplers", hoses, { hoses = !hoses }),
            Triple("Tank Pressure Relief Valves", pressure, { pressure = !pressure }),
            Triple("Safety PPE, Fire Extinguisher, Spill Kit", emergency, { emergency = !emergency })
        )

        items(itemsList) { (title, checked, toggle) ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(YorkCemNavy, RoundedCornerShape(8.dp))
                    .clickable { toggle() }
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Switch(
                    checked = checked,
                    onCheckedChange = { toggle() },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = YorkCemGreen,
                        checkedTrackColor = YorkCemGreen.copy(alpha = 0.4f),
                        uncheckedThumbColor = YorkCemRed,
                        uncheckedTrackColor = YorkCemRed.copy(alpha = 0.4f)
                    )
                )
            }
        }

        item {
            OutlinedTextField(
                value = comments,
                onValueChange = { comments = it },
                label = { Text("Defect details or comments", color = Color.White) },
                colors = TextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedContainerColor = YorkCemNavy,
                    unfocusedContainerColor = YorkCemNavy
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            Button(
                onClick = {
                    viewModel.submitDriverPreStart(
                        reg = vehicleReg,
                        driver = "Mick Fitzpatrick",
                        tyres = tyres,
                        lights = lights,
                        brakes = brakes,
                        hoses = hoses,
                        pressure = pressure,
                        emergency = emergency,
                        comment = comments
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = YorkCemOrange),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("submit_pre_start_btn")
            ) {
                Text("SUBMIT VEHICLE SIGN-OFF", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }
    }
}

@Composable
fun DriverWorkflowHub(
    viewModel: YorkCemViewModel,
    vehicleReg: String,
    activeOrder: Order?,
    allOrders: List<Order>
) {
    // Filter orders allocated to this vehicle that are not completed yet
    val myOrders = allOrders.filter { it.assignedVehicle == vehicleReg && it.status != "COMPLETED" }

    Column(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("ACTIVE TANKER: $vehicleReg", color = YorkCemStone, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("DRIVER OPERATIONS", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            }
            // Quick logoff
            IconButton(onClick = { viewModel.setDriverVehicle(null) }) {
                Icon(Icons.Default.ExitToApp, contentDescription = "Log out of truck", tint = YorkCemRed)
            }
        }

        if (activeOrder == null) {
            Text("ALLOCATED DELIVERY RUNS", color = YorkCemStone, fontWeight = FontWeight.Bold, fontSize = 13.sp)

            if (myOrders.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .background(YorkCemNavy, RoundedCornerShape(8.dp))
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.ListAlt, contentDescription = null, tint = YorkCemGrey, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("No active job assignments for $vehicleReg.", color = Color.White, fontSize = 15.sp)
                    }
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(myOrders) { order ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = YorkCemNavy),
                            border = BorderStroke(1.dp, YorkCemStone.copy(alpha = 0.3f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.selectActiveDriverOrder(order) }
                                .testTag("select_order_btn_${order.orderId}")
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("ORDER #${order.orderId}", fontWeight = FontWeight.Bold, color = YorkCemOrange, fontSize = 14.sp)
                                    Surface(color = YorkCemOrange, shape = RoundedCornerShape(4.dp)) {
                                        Text(order.status, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                    }
                                }
                                Text(order.customerName, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 18.sp)
                                Text(order.siteId, fontSize = 14.sp, color = YorkCemStone)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("Quantity: ${order.quantity} t | Window: ${order.deliveryWindow}", fontSize = 12.sp, color = YorkCemGrey)

                                Spacer(modifier = Modifier.height(12.dp))

                                Button(
                                    onClick = { viewModel.selectActiveDriverOrder(order) },
                                    colors = ButtonDefaults.buttonColors(containerColor = YorkCemOrange),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("INITIATE TRIP FLOW", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // ACTIVE JOB SCREEN
            Card(
                colors = CardDefaults.cardColors(containerColor = YorkCemNavy),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("CURRENT LIVE ASSIGNMENT", color = YorkCemStone, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(activeOrder.customerName, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text(activeOrder.siteId, color = YorkCemStone, fontSize = 16.sp)

                    Spacer(modifier = Modifier.height(16.dp))

                    Card(colors = CardDefaults.cardColors(containerColor = YorkCemDarkPlate)) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Product:", color = YorkCemStone)
                                Text("Bulk Cement", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Volume:", color = YorkCemStone)
                                Text("${activeOrder.quantity} Tonnes", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Required by:", color = YorkCemStone)
                                Text(activeOrder.deliveryWindow, color = YorkCemOrange, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text("SPECIAL SITE ACCESS DIRECTIVES:", color = YorkCemStone, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = activeOrder.siteInstructions,
                        color = Color.White,
                        fontSize = 13.sp,
                        modifier = Modifier.background(YorkCemDarkPlate, RoundedCornerShape(4.dp)).padding(8.dp)
                    )

                    Spacer(modifier = Modifier.weight(1f))

                    // ACTION TRIGGER DEPENDING ON STATE
                    when (activeOrder.status) {
                        "APPROVED" -> {
                            Button(
                                onClick = { viewModel.startLoadingProcess(activeOrder.orderId) },
                                colors = ButtonDefaults.buttonColors(containerColor = YorkCemOrange),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(56.dp)
                                    .testTag("driver_start_loading")
                            ) {
                                Text("BEGIN DEPOT LOADING SEQUENCE", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                        }
                        "LOADING" -> {
                            Button(
                                onClick = { viewModel.completeLoadingProcess(activeOrder.orderId, activeOrder.quantity, "Depot Operator Pete") },
                                colors = ButtonDefaults.buttonColors(containerColor = YorkCemBlue),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(56.dp)
                                    .testTag("driver_complete_loading")
                            ) {
                                Text("CONFIRM LOAD COMPLETED", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                        }
                        "LOADED" -> {
                            Button(
                                onClick = { viewModel.departDepot(activeOrder.orderId) },
                                colors = ButtonDefaults.buttonColors(containerColor = YorkCemGreen),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(56.dp)
                                    .testTag("driver_depart_depot")
                            ) {
                                Text("DEPART DEPOT (START TRANSIT)", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                        }
                        "EN_ROUTE" -> {
                            Button(
                                onClick = { viewModel.arriveAtSite(activeOrder.orderId) },
                                colors = ButtonDefaults.buttonColors(containerColor = YorkCemOrange),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(56.dp)
                                    .testTag("driver_arrive_site")
                            ) {
                                Text("CONFIRM ARRIVAL AT SITE GEOFENCE", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DriverSiteSafetyScreen(
    viewModel: YorkCemViewModel,
    order: Order?
) {
    var confirmedGps by remember { mutableStateOf(false) }
    var safePosition by remember { mutableStateOf(false) }
    var contactPresent by remember { mutableStateOf(false) }
    var unloadingConfirmed by remember { mutableStateOf(false) }
    var hosesConnected by remember { mutableStateOf(false) }

    Column(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        Text("CRITICAL PHYSICAL SAFETY CLEARANCE", color = YorkCemRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Text("SITE UNLOAD CHECKLIST", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Safety protocol mandates physical site visual check before tank compression.", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)

        val checklist = listOf(
            Triple("Site address matches GPS geofence marker", confirmedGps, { confirmedGps = !confirmedGps }),
            Triple("Vehicle parked on solid ground, brakes engaged", safePosition, { safePosition = !safePosition }),
            Triple("Customer contact/receiver is present at silo", contactPresent, { contactPresent = !contactPresent }),
            Triple("Correct silo coupling matched & locked", unloadingConfirmed, { unloadingConfirmed = !unloadingConfirmed }),
            Triple("Unload hoses inspected, connected, and pinned", hosesConnected, { hosesConnected = !hosesConnected })
        )

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(1f)) {
            items(checklist) { (label, value, toggle) ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(YorkCemNavy, RoundedCornerShape(8.dp))
                        .clickable { toggle() }
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(label, color = Color.White, fontSize = 13.sp)
                    Icon(
                        imageVector = if (value) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                        contentDescription = null,
                        tint = if (value) YorkCemGreen else YorkCemGrey
                    )
                }
            }
        }

        val allChecked = confirmedGps && safePosition && contactPresent && unloadingConfirmed && hosesConnected

        Button(
            onClick = { if (allChecked && order != null) viewModel.confirmSiteSafety(order.orderId) },
            enabled = allChecked,
            colors = ButtonDefaults.buttonColors(containerColor = YorkCemGreen, disabledContainerColor = YorkCemNavy),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("driver_safety_clear_btn")
        ) {
            Text("PROCEED TO PRESSURE DISCHARGE", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}

@Composable
fun DriverDischargeScreen(
    viewModel: YorkCemViewModel,
    order: Order?
) {
    var step by remember { mutableStateOf("CONNECT") } // CONNECT, PRESSURIZE, DISCHARGING, DEPRESSURIZE, COMPLETE
    var pressurePsi by remember { mutableStateOf(0.0) }
    var dischargedTonnes by remember { mutableStateOf(0.0) }

    val scope = rememberCoroutineScope()

    Column(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        Text("BULK TANK DISCHARGE PANEL", color = YorkCemStone, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Text("UNLOADING CONTROLLER", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)

        // Telemetry Gauge
        Card(
            colors = CardDefaults.cardColors(containerColor = YorkCemNavy),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("SYSTEM PRESSURE", color = YorkCemStone, fontSize = 11.sp)
                        Text("${pressurePsi.toInt()} PSI", color = if (pressurePsi > 25) YorkCemRed else YorkCemOrange, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("DISCHARGED QUANTITY", color = YorkCemStone, fontSize = 11.sp)
                        Text("${String.format("%.1f", dischargedTonnes)} t", color = YorkCemGreen, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            contentAlignment = Alignment.Center
        ) {
            when (step) {
                "CONNECT" -> {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("COMPRESSOR LINE READY", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("Confirm auxiliary pneumatic compressor lines engaged.", color = YorkCemStone, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(onClick = {
                            step = "PRESSURIZE"
                            pressurePsi = 18.0
                        }, colors = ButtonDefaults.buttonColors(containerColor = YorkCemOrange)) {
                            Text("ENGAGE COMPRESSOR & PRESSURIZE")
                        }
                    }
                }
                "PRESSURIZE" -> {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("TANK PRESSURIZING...", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("Target operating envelope: 15-22 PSI.", color = YorkCemStone, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(onClick = {
                            step = "DISCHARGING"
                            pressurePsi = 21.0
                            dischargedTonnes = 1.2
                        }, colors = ButtonDefaults.buttonColors(containerColor = YorkCemGreen)) {
                            Text("OPEN SUPPLY FLANGE (START DISCHARGE)")
                        }
                    }
                }
                "DISCHARGING" -> {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("DISCHARGE IN PROGRESS", color = YorkCemGreen, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("Cement fluidizing under pneumatic pressure.", color = YorkCemStone, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(16.dp))

                        // Trigger flow increments
                        Button(onClick = {
                            val max = order?.quantity ?: 24.0
                            if (dischargedTonnes < max) {
                                dischargedTonnes = (dischargedTonnes + 6.0).coerceAtMost(max)
                            } else {
                                step = "DEPRESSURIZE"
                                pressurePsi = 4.0
                            }
                        }, colors = ButtonDefaults.buttonColors(containerColor = YorkCemOrange)) {
                            Text(if (dischargedTonnes < (order?.quantity ?: 24.0)) "INCREASE UNLOAD" else "PROCEED TO DEPRESSURIZE")
                        }
                    }
                }
                "DEPRESSURIZE" -> {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("BLOW-DOWN ENVELOPE ACTIVE", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("Depressurizing main delivery chamber safely.", color = YorkCemStone, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(onClick = {
                            step = "COMPLETE"
                            pressurePsi = 0.0
                        }, colors = ButtonDefaults.buttonColors(containerColor = YorkCemOrange)) {
                            Text("CONFIRM DEPRESSURIZED (0 PSI)")
                        }
                    }
                }
                "COMPLETE" -> {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("DISCHARGE OPERATION COMPLETED", color = YorkCemGreen, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("Disconnect hoses and inspect couplers for residue.", color = YorkCemStone, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(onClick = {
                            viewModel.setDriverScreen("SIGNATURE")
                        }, colors = ButtonDefaults.buttonColors(containerColor = YorkCemGreen)) {
                            Text("PROCEED TO e-POD SIGNATURE")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DriverSignatureScreen(
    viewModel: YorkCemViewModel,
    order: Order?
) {
    var signatureName by remember { mutableStateOf("") }
    var notesInput by remember { mutableStateOf("") }
    var exceptionsInput by remember { mutableStateOf("") }

    // Path representing user drawing points
    val path = remember { Path() }
    var pointsCount by remember { mutableStateOf(0) }

    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        Text("ELECTRONIC PROOF OF DELIVERY", color = YorkCemStone, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Text("CUSTOMER SIGN-OFF & e-POD", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)

        OutlinedTextField(
            value = signatureName,
            onValueChange = { signatureName = it },
            label = { Text("Receiver's Printed Name", color = Color.White) },
            colors = TextFieldDefaults.colors(
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedContainerColor = YorkCemNavy,
                unfocusedContainerColor = YorkCemNavy
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("signature_name_input")
        )

        // DRAWABLE CANVAS FOR SIGNATURE
        Text("DRAW SIGNATURE:", color = YorkCemStone, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp)
                .background(Color.White, RoundedCornerShape(8.dp))
                .border(2.dp, YorkCemStone, RoundedCornerShape(8.dp))
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            path.moveTo(offset.x, offset.y)
                        },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            path.lineTo(change.position.x, change.position.y)
                            pointsCount++
                        }
                    )
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawPath(
                    path = path,
                    color = YorkCemNavy,
                    style = Stroke(width = 6f)
                )
            }
            if (pointsCount == 0) {
                Text(
                    text = "Sign here with finger",
                    color = YorkCemGrey,
                    fontSize = 13.sp,
                    modifier = Modifier.align(Alignment.Center)
                )
            }
        }

        OutlinedTextField(
            value = exceptionsInput,
            onValueChange = { exceptionsInput = it },
            label = { Text("Record Discrepancy or Exceptions (Leave empty if none)", color = Color.White) },
            colors = TextFieldDefaults.colors(
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedContainerColor = YorkCemNavy,
                unfocusedContainerColor = YorkCemNavy
            ),
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = notesInput,
            onValueChange = { notesInput = it },
            label = { Text("Driver comments", color = Color.White) },
            colors = TextFieldDefaults.colors(
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedContainerColor = YorkCemNavy,
                unfocusedContainerColor = YorkCemNavy
            ),
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = {
                if (order != null && signatureName.isNotEmpty()) {
                    viewModel.completeDischarge(
                        orderId = order.orderId,
                        deliveredQty = order.quantity, // Default to full target
                        signatureName = signatureName,
                        pointsData = "SIG_POINTS_${pointsCount}",
                        exceptions = exceptionsInput,
                        notes = notesInput
                    )
                }
            },
            enabled = signatureName.isNotEmpty() && pointsCount > 5,
            colors = ButtonDefaults.buttonColors(containerColor = YorkCemGreen),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("driver_submit_pod")
        ) {
            Text("SUBMIT PROOF OF DELIVERY", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}
