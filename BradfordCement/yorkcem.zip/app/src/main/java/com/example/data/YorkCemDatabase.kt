package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.YorkCemDao
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        Product::class,
        CustomerSite::class,
        Vehicle::class,
        Silo::class,
        Order::class,
        PreStartCheck::class,
        LoadManagement::class,
        ProofOfDelivery::class,
        AuditLog::class
    ],
    version = 1,
    exportSchema = false
)
abstract class YorkCemDatabase : RoomDatabase() {

    abstract fun yorkCemDao(): YorkCemDao

    companion object {
        @Volatile
        private var INSTANCE: YorkCemDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): YorkCemDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    YorkCemDatabase::class.java,
                    "yorkcem_database"
                )
                .addCallback(YorkCemDatabaseCallback(scope))
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class YorkCemDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateDatabase(database.yorkCemDao())
                }
            }
        }

        private suspend fun populateDatabase(dao: YorkCemDao) {
            // Seed Silos
            val silos = listOf(
                Silo("SILO-01", "Silo 01 (Bulk CEM I)", "YorkCem Bulk CEM I", 2000.0, 1428.0, 1362.0, "NORMAL", 21.4, false),
                Silo("SILO-02", "Silo 02 (Low Carbon CEM II)", "EcoCem Low-Carbon", 2500.0, 1980.0, 1920.0, "NORMAL", 18.5, false),
                Silo("SILO-03", "Silo 03 (Specialist Rapid-Set)", "Rapid-Setting Grout", 1000.0, 120.0, 100.0, "LOW", 23.2, true),
                Silo("SILO-04", "Silo 04 (Bagged Storage B)", "Portland Premium Pallet", 500.0, 410.0, 410.0, "NORMAL", 15.0, false)
            )
            dao.insertSilos(silos)

            // Seed Products
            val products = listOf(
                Product("PROD-001", "YorkCem Bulk CEM I", "CEM I", "Grade 52.5N", "BULK", 1250.0, "SILO-01", 1362.0, "BATCH-26A", "APPROVED", 115.0),
                Product("PROD-002", "EcoCem Low-Carbon", "CEM II / B-V", "Grade 42.5N", "BULK", 1180.0, "SILO-02", 1920.0, "BATCH-26B", "APPROVED", 125.0),
                Product("PROD-003", "Rapid-Setting Grout", "CEM IV", "Specialist Grade", "BULK", 1300.0, "SILO-03", 100.0, "BATCH-R9", "APPROVED", 165.0),
                Product("PROD-004", "Portland Premium Pallet", "Bagged Portland", "Grade 42.5R", "BAGGED", 1400.0, "SILO-04", 410.0, "BATCH-P4", "APPROVED", 150.0)
            )
            dao.insertProducts(products)

            // Seed Customer Sites
            val sites = listOf(
                CustomerSite(
                    siteId = "BRADFORD-0421",
                    customerName = "Aire Construction",
                    address = "Bradford Ring Road Development, Bradford, BD4 7AH",
                    siteContact = "Nigel Henderson",
                    contactPhone = "+44 7700 900077",
                    accessRestrictions = "Articulated bulk tankers permitted.",
                    openingHours = "06:30 - 17:00",
                    siloCount = 2,
                    siloCapacityTonnes = 120.0,
                    deliveryType = "BULK",
                    specialInstructions = "Reverse to central silos, watch for overhead cable gantry.",
                    ppeRequirements = "Hard Hat, Hi-Vis, Safety Boots, Safety Glasses",
                    reversingRequirements = "Banksman required for reversing near Silo A",
                    maxVehicleWeight = 44.0
                ),
                CustomerSite(
                    siteId = "LEEDS-1102",
                    customerName = "City Plaza Devs Ltd",
                    address = "Wellington Street Commercial Hub, Leeds, LS1 4AP",
                    siteContact = "Sarah Jenkins",
                    contactPhone = "+44 7700 900143",
                    accessRestrictions = "Rigid vehicles only due to tight city center turnings.",
                    openingHours = "07:30 - 18:00",
                    siloCount = 1,
                    siloCapacityTonnes = 40.0,
                    deliveryType = "BULK",
                    specialInstructions = "Contact gatekeeper 30 mins before arrival. High pedestrian zone.",
                    ppeRequirements = "Full PPE + Dust Mask during discharge hookup",
                    reversingRequirements = "Reverse directly from street entrance with traffic marshal",
                    maxVehicleWeight = 32.0
                ),
                CustomerSite(
                    siteId = "YORK-0309",
                    customerName = "Minster Heritage & Masonry",
                    address = "Lord Mayor's Walk Historic Archway, York, YO31 7HB",
                    siteContact = "David Fletcher",
                    contactPhone = "+44 7700 900228",
                    accessRestrictions = "Rigid Flatbed crane only. Bagged pallets only. Low archways.",
                    openingHours = "08:30 - 16:30",
                    siloCount = 0,
                    siloCapacityTonnes = 0.0,
                    deliveryType = "BAGGED",
                    specialInstructions = "Park in designated loading area outside wall, offload via truck-mounted crane.",
                    ppeRequirements = "Hard Hat, Safety Boots, Hi-Vis Vest",
                    reversingRequirements = "Straight offloading point",
                    maxVehicleWeight = 18.0
                ),
                CustomerSite(
                    siteId = "WAKEFIELD-0144",
                    customerName = "Pennine Civil Engineering",
                    address = "Wakefield Bypass Overbridge Project, Wakefield, WF2 9UY",
                    siteContact = "Marcus Vance",
                    contactPhone = "+44 7700 900355",
                    accessRestrictions = "Full heavy road vehicles permitted. Dedicated site track.",
                    openingHours = "24 Hours (Contractual)",
                    siloCount = 3,
                    siloCapacityTonnes = 180.0,
                    deliveryType = "BULK",
                    specialInstructions = "Follow temporary construction markers. Discharge to Silo 3 directly.",
                    ppeRequirements = "Hard Hat, Steel-Toe Boots, Hi-Vis Orange, Protective Gloves",
                    reversingRequirements = "Reverse up soil ramp to silo gantry",
                    maxVehicleWeight = 44.0
                )
            )
            dao.insertSites(sites)

            // Seed Fleet Vehicles
            val vehicles = listOf(
                Vehicle("YC-201", "Bulk Tanker (Artic)", 30.0, "Diesel", 248900, 53.7997, -1.5478, "Dave Ramsden", "AVAILABLE", "GOOD", "VALID", "2026-08-10", 45.0, 3, true, "Pneumatic Pressure", 15.0),
                Vehicle("YC-214", "Bulk Tanker (Artic)", 24.0, "HVO Tanker", 124500, 53.7940, -1.7520, "Mick Fitzpatrick", "AVAILABLE", "GOOD", "VALID", "2026-09-01", 38.0, 2, true, "Pneumatic Pressure", 12.0),
                Vehicle("YC-118", "Rigid Flatbed + Crane", 14.0, "Electric Rigid", 18200, 53.6800, -1.4900, "Alan Stubbs", "AVAILABLE", "SERVICE_DUE", "VALID", "2025-11-20", 0.0, 0, false, "Gravity/Crane", 0.0),
                Vehicle("YC-207", "Bulk Tanker (Rigid)", 18.0, "Hydrogen Heavy", 45600, 53.9590, -1.0810, "Jack Thompson", "AVAILABLE", "GOOD", "VALID", "2026-07-15", 28.0, 2, true, "Pneumatic Pressure", 10.0),
                Vehicle("YC-219", "Bulk Tanker (Artic)", 24.0, "Diesel", 321800, 53.9900, -1.5400, "Paul Greenwood", "AVAILABLE", "REPAIR_REQUIRED", "VALID", "2026-04-12", 38.0, 2, true, "Pneumatic Pressure", 12.0)
            )
            dao.insertVehicles(vehicles)

            // Seed Some initial Orders to showcase the Dispatch Control Room immediately
            val initialOrders = listOf(
                Order(
                    customerName = "Aire Construction",
                    siteId = "BRADFORD-0421",
                    productId = "PROD-001",
                    quantity = 24.0,
                    deliveryDate = "2026-09-30",
                    deliveryWindow = "09:30 - 11:00",
                    vehicleTypeRequested = "Bulk Tanker (Artic)",
                    contactPhone = "+44 7700 900077",
                    siteInstructions = "Reverse to central silos, watch for overhead cables.",
                    poNumber = "PO-88192",
                    specialRequirements = "Fast-discharge compressor required.",
                    status = "EN_ROUTE",
                    assignedVehicle = "YC-214",
                    assignedDriver = "Mick Fitzpatrick",
                    eta = "10:12",
                    priceTotal = 2760.0,
                    projectId = "MANCHESTER-ROAD-DEV"
                ),
                Order(
                    customerName = "City Plaza Devs Ltd",
                    siteId = "LEEDS-1102",
                    productId = "PROD-002",
                    quantity = 18.0,
                    deliveryDate = "2026-09-30",
                    deliveryWindow = "08:30 - 10:00",
                    vehicleTypeRequested = "Bulk Tanker (Rigid)",
                    contactPhone = "+44 7700 900143",
                    siteInstructions = "Rigid only. Reverse from street entrance.",
                    poNumber = "PO-77291",
                    specialRequirements = "Low height rigid vehicle",
                    status = "LOADING",
                    assignedVehicle = "YC-207",
                    assignedDriver = "Jack Thompson",
                    eta = "09:40",
                    priceTotal = 2250.0,
                    projectId = "LEEDS-PLAZA-CENTRE"
                ),
                Order(
                    customerName = "Pennine Civil Engineering",
                    siteId = "WAKEFIELD-0144",
                    productId = "PROD-001",
                    quantity = 28.0,
                    deliveryDate = "2026-09-30",
                    deliveryWindow = "11:00 - 13:00",
                    vehicleTypeRequested = "Bulk Tanker (Artic)",
                    contactPhone = "+44 7700 900355",
                    siteInstructions = "Reverse up ramp to silo gantry.",
                    poNumber = "PO-99120",
                    specialRequirements = "Full PPE required.",
                    status = "APPROVED",
                    assignedVehicle = "YC-201",
                    assignedDriver = "Dave Ramsden",
                    eta = "11:15",
                    priceTotal = 3220.0
                ),
                Order(
                    customerName = "Minster Heritage & Masonry",
                    siteId = "YORK-0309",
                    productId = "PROD-004",
                    quantity = 10.0,
                    deliveryDate = "2026-09-30",
                    deliveryWindow = "14:00 - 16:00",
                    vehicleTypeRequested = "Rigid Flatbed + Crane",
                    contactPhone = "+44 7700 900228",
                    siteInstructions = "Offload with truck crane outside wall.",
                    poNumber = "PO-1004",
                    specialRequirements = "Ensure pallet wrap intact.",
                    status = "PLANNED",
                    priceTotal = 1500.0
                )
            )

            for (order in initialOrders) {
                dao.insertOrder(order)
            }

            // Seed Some Audit Log items
            val logs = listOf(
                AuditLog(orderId = 1, action = "ORDER_CREATED", username = "Dispatch Admin", timestamp = System.currentTimeMillis() - 7200000, details = "Bulk Order created for Aire Construction", previousState = null, newState = "PLANNED"),
                AuditLog(orderId = 1, action = "VEHICLE_ASSIGNED", username = "Dispatch Admin", timestamp = System.currentTimeMillis() - 3600000, details = "Vehicle YC-214 assigned to Order #1", previousState = "PLANNED", newState = "APPROVED"),
                AuditLog(orderId = 1, action = "DELIVERY_STARTED", username = "Mick Fitzpatrick", timestamp = System.currentTimeMillis() - 1200000, details = "Driver Mick Fitzpatrick departed West West Yorkshire Depot with 24 tonnes", previousState = "LOADED", newState = "EN_ROUTE")
            )
            for (log in logs) {
                dao.insertAuditLog(log)
            }
        }
    }
}
