package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = YorkCemOrange,
    secondary = YorkCemStone,
    tertiary = YorkCemGrey,
    background = YorkCemDarkPlate,
    surface = YorkCemNavy,
    onPrimary = androidx.compose.ui.graphics.Color.White,
    onSecondary = YorkCemNavy,
    onBackground = YorkCemLightGrey,
    onSurface = YorkCemLightGrey
)

private val LightColorScheme = lightColorScheme(
    primary = YorkCemNavy,
    secondary = YorkCemStone,
    tertiary = YorkCemOrange,
    background = YorkCemLightGrey,
    surface = androidx.compose.ui.graphics.Color.White,
    onPrimary = androidx.compose.ui.graphics.Color.White,
    onSecondary = YorkCemNavy,
    onBackground = YorkCemNavy,
    onSurface = YorkCemNavy
)

@Composable
fun YorkCemTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

// Keep a backward compatible wrapper just in case
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    YorkCemTheme(darkTheme = darkTheme, content = content)
}
