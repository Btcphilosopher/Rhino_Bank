package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// YORKCEM Palette
val YorkCemNavy = Color(0xFF1E2A38) // Dark Navy/Steel
val YorkCemStone = Color(0xFFD6C5B3) // Yorkshire Stone Sand
val YorkCemOrange = Color(0xFFE65F2B) // Restrained Industrial Orange
val YorkCemGrey = Color(0xFF7F8C8D) // Cement Grey
val YorkCemLightGrey = Color(0xFFF2F4F4) // Light Industrial Plate
val YorkCemDarkPlate = Color(0xFF111822) // High contrast dark surface
val YorkCemGreen = Color(0xFF27AE60) // Safety Status OK
val YorkCemRed = Color(0xFFC0392B) // Safety Status Stop
val YorkCemBlue = Color(0xFF2980B9) // Flow/Pneumatics

