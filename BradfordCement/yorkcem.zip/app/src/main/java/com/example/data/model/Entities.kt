package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
    @PrimaryKey val productId: String,
    val productName: String,
    val cementType: String,
    val grade: String,
    val bulkOrBagged: String, // "BULK" or "BAGGED"
    val density: Double, // kg/m3
    val siloId: String,
    val availableQuantity: Double, // tonnes
    val batch: String,
    val qualityStatus: String, // "APPROVED", "PENDING_TEST"
    val price: Double // GBP per tonne or pallet
)

@Entity(tableName = "customer_sites")
data class CustomerSite(
    @PrimaryKey val siteId: String,
    val customerName: String,
    val address: String,
    val siteContact: String,
    val contactPhone: String,
    val accessRestrictions: String, // "Articulated vehicle permitted", "Rigids only"
    val openingHours: String,
    val siloCount: Int,
    val siloCapacityTonnes: Double,
    val deliveryType: String, // "BULK" or "BAGGED"
    val specialInstructions: String,
    val ppeRequirements: String, // "Hi-Vis, Steel Toes, Hard Hat, Safety Glasses"
    val reversingRequirements: String, // "Banksman required", "Reverse to unloading point"
    val maxVehicleWeight: Double // tonnes
)

@Entity(tableName = "vehicles")
data class Vehicle(
    @PrimaryKey val registration: String,
    val vehicleType: String, // "Bulk Tanker", "Rigid Flatbed", "Articulated Flatbed"
    val capacityTonnes: Double,
    val fuelType: String, // "Diesel", "HVO", "Electric", "Hydrogen"
    val odometer: Long,
    val latitude: Double,
    val longitude: Double,
    val driverName: String,
    val availability: String, // "AVAILABLE", "MAINTENANCE", "ACTIVE"
    val maintenanceStatus: String, // "GOOD", "SERVICE_DUE", "REPAIR_REQUIRED"
    val motStatus: String, // "VALID", "EXPIRING"
    val lastServiceDate: String,
    // Bulk Tanker specific details
    val tankCapacity: Double, // m3
    val compartments: Int,
    val compressor: Boolean,
    val dischargeSystem: String, // "Pneumatic Pressure", "Gravity"
    val hoseLength: Double // meters
)

@Entity(tableName = "silos")
data class Silo(
    @PrimaryKey val siloId: String,
    val name: String,
    val productName: String,
    val capacityTonnes: Double,
    val currentQuantity: Double,
    val availableQuantity: Double,
    val status: String, // "NORMAL", "LOW", "CRITICAL", "OFFLINE"
    val temperatureC: Double,
    val alarmsActive: Boolean
)

@Entity(tableName = "orders")
data class Order(
    @PrimaryKey(autoGenerate = true) val orderId: Long = 0,
    val customerName: String,
    val siteId: String,
    val productId: String,
    val quantity: Double,
    val deliveryDate: String,
    val deliveryWindow: String,
    val vehicleTypeRequested: String,
    val contactPhone: String,
    val siteInstructions: String,
    val poNumber: String,
    val specialRequirements: String,
    val status: String, // "PLANNED", "APPROVED", "LOADING", "LOADED", "EN_ROUTE", "ARRIVED", "DISCHARGING", "COMPLETED", "CANCELLED"
    val assignedVehicle: String? = null,
    val assignedDriver: String? = null,
    val eta: String? = null,
    val variance: Double? = null,
    val priceTotal: Double,
    val isRecurring: Boolean = false,
    val recurrenceSchedule: String? = null, // "Weekly", "Fortnightly"
    val projectId: String? = null // For project delivery mode
)

@Entity(tableName = "pre_start_checks")
data class PreStartCheck(
    @PrimaryKey(autoGenerate = true) val checkId: Long = 0,
    val vehicleReg: String,
    val timestamp: Long,
    val driverName: String,
    val tyresPassed: Boolean,
    val lightsPassed: Boolean,
    val brakesPassed: Boolean,
    val hosesPassed: Boolean,
    val pressurePassed: Boolean,
    val emergencyEquipmentPassed: Boolean,
    val comment: String,
    val isOverallPassed: Boolean
)

@Entity(tableName = "load_management")
data class LoadManagement(
    @PrimaryKey(autoGenerate = true) val loadId: Long = 0,
    val orderId: Long,
    val truckReg: String,
    val productName: String,
    val siloId: String,
    val batchCode: String,
    val targetQuantity: Double,
    val actualQuantity: Double,
    val operatorName: String,
    val timestamp: Long
)

@Entity(tableName = "proof_of_delivery")
data class ProofOfDelivery(
    @PrimaryKey(autoGenerate = true) val podId: Long = 0,
    val orderId: Long,
    val customerName: String,
    val siteName: String,
    val productName: String,
    val quantityDelivered: Double,
    val batchCode: String,
    val vehicleReg: String,
    val driverName: String,
    val arrivalTime: String,
    val completionTime: String,
    val signatureName: String,
    val signaturePointsData: String, // Encoded SVG/String representation of touch points
    val hasPhoto: Boolean,
    val photoUri: String?,
    val exceptions: String,
    val notes: String
)

@Entity(tableName = "audit_logs")
data class AuditLog(
    @PrimaryKey(autoGenerate = true) val logId: Long = 0,
    val orderId: Long?,
    val action: String, // "ORDER_CREATED", "LOAD_COMPLETED", etc.
    val username: String,
    val timestamp: Long,
    val details: String,
    val previousState: String?,
    val newState: String?
)
