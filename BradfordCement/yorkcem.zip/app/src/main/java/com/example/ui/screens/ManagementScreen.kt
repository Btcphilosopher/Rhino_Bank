package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AuditLog
import com.example.ui.theme.*
import com.example.ui.viewmodel.YorkCemViewModel
import java.text.SimpleDateFormat
import java.util.*

data class FleetScenario(
    val name: String,
    val rangeKm: Int,
    val payloadTonnes: Int,
    val chargingTime: String,
    val energyCostPer100km: Double,
    val co2Savings: String,
    val suitabilityRating: String
)

@Composable
fun ManagementScreen(
    viewModel: YorkCemViewModel,
    modifier: Modifier = Modifier
) {
    val auditLogs by viewModel.auditLogs.collectAsState()
    var selectedScenarioIndex by remember { mutableStateOf(0) }

    val fleetScenarios = listOf(
        FleetScenario("Diesel Heavy Tanker", 900, 30, "15 Mins", 65.0, "Baseline (0%)", "Excellent (Long Range)"),
        FleetScenario("HVO Biodiesel Tanker", 850, 30, "15 Mins", 78.0, "90% CO2 Reduction", "Excellent (Direct Drop-in)"),
        FleetScenario("Battery-Electric Rigid", 250, 18, "4 Hours (DC Fast)", 22.0, "100% Zero-Emissions", "Moderate (Short Hauls Only)"),
        FleetScenario("Hydrogen Heavy Vehicle", 550, 24, "20 Mins", 95.0, "100% Zero-Emissions", "Good (Silo Supply Viable)")
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(YorkCemLightGrey)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // MANAGEMENT KPI PANEL
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = YorkCemNavy),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("YORKSHIRE CEMENT & MATERIALS", color = YorkCemStone, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text("OPERATIONAL MANAGEMENT & ESG", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // DAILY KPI METRICS
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                listOf(
                    Pair("DELIVERIES", "126"),
                    Pair("COMPLETED", "91"),
                    Pair("TONNES SHIPPED", "2,842 t"),
                    Pair("ON-TIME", "94.7%")
                ).forEach { (title, count) ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("kpi_${title.lowercase().replace(" ", "_")}")
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(title, color = YorkCemGrey, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(count, color = YorkCemNavy, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // FUTURE FLEET LAB
        item {
            Text("FUTURE FLEET ESG SIMULATION LAB", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = YorkCemNavy)
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Select powertrain configuration to audit logistics & payload trade-offs:", fontSize = 12.sp, color = YorkCemGrey)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        fleetScenarios.forEachIndexed { index, scenario ->
                            Surface(
                                color = if (selectedScenarioIndex == index) YorkCemOrange else YorkCemLightGrey,
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { selectedScenarioIndex = index }
                            ) {
                                Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(8.dp)) {
                                    Text(
                                        text = scenario.name.split(" ")[0] + " " + (scenario.name.split().getOrNull(1) ?: ""),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (selectedScenarioIndex == index) Color.White else YorkCemNavy
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    val activeScenario = fleetScenarios[selectedScenarioIndex]

                    Card(colors = CardDefaults.cardColors(containerColor = YorkCemLightGrey)) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Maximum Fleet Range:", fontSize = 12.sp)
                                Text("${activeScenario.rangeKm} km", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Payload (Net tonnes):", fontSize = 12.sp)
                                Text("${activeScenario.payloadTonnes} t", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Depot Refuel/Recharge Time:", fontSize = 12.sp)
                                Text(activeScenario.chargingTime, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Running Cost (GBP/100km):", fontSize = 12.sp)
                                Text("£${activeScenario.energyCostPer100km.toInt()}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = YorkCemOrange)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("CO2 emissions saving:", fontSize = 12.sp)
                                Text(activeScenario.co2Savings, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = YorkCemGreen)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Yorkshire Hills Suitability:", fontSize = 12.sp)
                                Text(activeScenario.suitabilityRating, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = YorkCemNavy)
                            }
                        }
                    }
                }
            }
        }

        // REAL-TIME AUDIT LOG
        item {
            Text("YORKCEM BLOCKCHAIN AUDIT TRAIL LOGS", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = YorkCemNavy)
        }

        if (auditLogs.isEmpty()) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Text("No audit log events recorded in local ledger.", fontSize = 11.sp, color = YorkCemGrey, modifier = Modifier.padding(16.dp))
                }
            }
        } else {
            items(auditLogs) { log ->
                val timeStr = SimpleDateFormat("HH:mm:ss", Locale.UK).format(Date(log.timestamp))

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, YorkCemStone.copy(alpha = 0.2f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = when (log.action) {
                                        "ORDER_CREATED" -> Icons.Default.AddBox
                                        "VEHICLE_ASSIGNED" -> Icons.Default.AssignmentInd
                                        "LOAD_COMPLETED" -> Icons.Default.CloudDone
                                        "DISCHARGE_COMPLETED" -> Icons.Default.Draw
                                        "VEHICLE_BREAKDOWN" -> Icons.Default.Dangerous
                                        else -> Icons.Default.History
                                    },
                                    contentDescription = null,
                                    tint = YorkCemNavy,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = log.action,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = YorkCemOrange
                                )
                            }
                            Text(
                                text = timeStr,
                                fontSize = 10.sp,
                                color = YorkCemGrey
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = log.details,
                            fontSize = 12.sp,
                            color = YorkCemNavy
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Actor: ${log.username}",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = YorkCemGrey
                        )
                    }
                }
            }
        }
    }
}

// Simple extension helper
fun String.split() = this.split(" ")
