package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CustomerSite
import com.example.data.model.Order
import com.example.data.model.Product
import com.example.ui.theme.*
import com.example.ui.viewmodel.YorkCemViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerScreen(
    viewModel: YorkCemViewModel,
    modifier: Modifier = Modifier
) {
    val currentScreen by viewModel.currentCustomerScreen.collectAsState()
    val orders by viewModel.orders.collectAsState()
    val sites by viewModel.sites.collectAsState()
    val products by viewModel.products.collectAsState()
    val pods by viewModel.pods.collectAsState()
    val tickets by viewModel.supportTickets.collectAsState()

    // Sub-screen navigation layout
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(YorkCemLightGrey)
    ) {
        // Customer App Local Sub-Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(YorkCemNavy)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "YORKCEM CUSTOMER PORTAL",
                    color = YorkCemStone,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Aire Construction Ltd.",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Quick navigation row
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(
                    onClick = { viewModel.setCustomerScreen("DASHBOARD") },
                    colors = ButtonDefaults.textButtonColors(
                        contentColor = if (currentScreen == "DASHBOARD") YorkCemStone else Color.White.copy(alpha = 0.7f)
                    )
                ) {
                    Text("DASHBOARD", fontSize = 11.sp)
                }
                TextButton(
                    onClick = { viewModel.setCustomerScreen("ORDER_FORM") },
                    colors = ButtonDefaults.textButtonColors(
                        contentColor = if (currentScreen == "ORDER_FORM") YorkCemStone else Color.White.copy(alpha = 0.7f)
                    ),
                    modifier = Modifier.testTag("nav_order_cement")
                ) {
                    Text("ORDER CEMENT", fontSize = 11.sp)
                }
                TextButton(
                    onClick = { viewModel.setCustomerScreen("DOCUMENTS") },
                    colors = ButtonDefaults.textButtonColors(
                        contentColor = if (currentScreen == "DOCUMENTS") YorkCemStone else Color.White.copy(alpha = 0.7f)
                    )
                ) {
                    Text("INVOICES & POD", fontSize = 11.sp)
                }
            }
        }

        // Body Switcher
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(16.dp)
        ) {
            when (currentScreen) {
                "DASHBOARD" -> CustomerDashboard(viewModel, orders)
                "ORDER_FORM" -> CustomerOrderForm(viewModel, sites, products)
                "TRACKING" -> CustomerTrackingScreen(viewModel)
                "DOCUMENTS" -> CustomerDocumentHub(viewModel, orders, pods)
                "SUPPORT" -> CustomerSupportHub(viewModel, orders, tickets)
            }
        }
    }
}

@Composable
fun CustomerDashboard(
    viewModel: YorkCemViewModel,
    orders: List<Order>
) {
    // Find active or next en-route/approved delivery for the primary display
    val nextDelivery = orders.find { it.status != "COMPLETED" && it.status != "CANCELLED" }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // NEXT DELIVERY BANNER
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = YorkCemNavy),
                elevation = CardDefaults.cardElevation(4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "NEXT CEMENT DELIVERY",
                        color = YorkCemStone,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    if (nextDelivery != null) {
                        Text(
                            text = if (nextDelivery.productId == "PROD-001") "Yorkshire Stock Cement (Bulk CEM I)" else "EcoCem Low-Carbon (CEM II)",
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${nextDelivery.quantity} Tonnes",
                            color = YorkCemStone,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("TIMING WINDOW", color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp)
                                Text("Today, ${nextDelivery.deliveryWindow}", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                            Column {
                                Text("ASSIGNED TANKER", color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp)
                                Text(nextDelivery.assignedVehicle ?: "QUEUE ALLOCATION", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("ESTIMATED ETA", color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp)
                                Text(nextDelivery.eta ?: "COMPUTING...", color = YorkCemOrange, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Status tag
                            Surface(
                                color = YorkCemOrange,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = nextDelivery.status,
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }

                            Button(
                                onClick = { viewModel.setTrackingOrderId(nextDelivery.orderId) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                                modifier = Modifier
                                    .height(34.dp)
                                    .testTag("track_delivery_btn")
                            ) {
                                Text("TRACK VEHICLE", color = YorkCemNavy, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    } else {
                        // Empty next delivery
                        Text("No upcoming scheduled deliveries.", color = Color.White, fontSize = 15.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = { viewModel.setCustomerScreen("ORDER_FORM") },
                            colors = ButtonDefaults.buttonColors(containerColor = YorkCemOrange)
                        ) {
                            Text("BOOK BULK SUPPLY")
                        }
                    }
                }
            }
        }

        // QUICK ACTIONS PORTAL GRID
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { viewModel.setCustomerScreen("ORDER_FORM") }
                        .testTag("order_cement_card")
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Icon(Icons.Default.AddBox, contentDescription = null, tint = YorkCemOrange, modifier = Modifier.size(28.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("ORDER CEMENT", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = YorkCemNavy)
                        Text("Place real-time bulk bookings", fontSize = 10.sp, color = YorkCemGrey)
                    }
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { viewModel.setCustomerScreen("DOCUMENTS") }
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Icon(Icons.Default.ReceiptLong, contentDescription = null, tint = YorkCemNavy, modifier = Modifier.size(28.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("VIEW INVOICES & POD", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = YorkCemNavy)
                        Text("Download sign-offs & bills", fontSize = 10.sp, color = YorkCemGrey)
                    }
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { viewModel.setCustomerScreen("SUPPORT") }
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Icon(Icons.Default.SupportAgent, contentDescription = null, tint = YorkCemBlue, modifier = Modifier.size(28.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("CUSTOMER CARE", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = YorkCemNavy)
                        Text("Report variance or late trucks", fontSize = 10.sp, color = YorkCemGrey)
                    }
                }
            }
        }

        // HISTORICAL LIST
        item {
            Text(
                text = "YOUR CEMENT REQUISITIONS HISTORY",
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = YorkCemNavy
            )
        }

        items(orders) { order ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White, RoundedCornerShape(8.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Requisition #${order.orderId}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = YorkCemNavy)
                    Text("Silo Delivery | PO: ${order.poNumber}", fontSize = 11.sp, color = YorkCemGrey)
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("${order.quantity} Tonnes", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = YorkCemNavy)
                    Text(order.status, fontSize = 11.sp, color = if (order.status == "COMPLETED") YorkCemGreen else YorkCemOrange, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerOrderForm(
    viewModel: YorkCemViewModel,
    sites: List<CustomerSite>,
    products: List<Product>
) {
    var selectedSiteId by remember { mutableStateOf(sites.firstOrNull()?.siteId ?: "") }
    var selectedProductId by remember { mutableStateOf(products.firstOrNull()?.productId ?: "") }
    var quantityString by remember { mutableStateOf("24.0") }
    var deliveryWindow by remember { mutableStateOf("09:30 - 11:00") }
    var vehicleTypeRequested by remember { mutableStateOf("Bulk Tanker (Artic)") }
    var poNumber by remember { mutableStateOf("PO-") }
    var specialInstructions by remember { mutableStateOf("") }
    var contactPhone by remember { mutableStateOf("+44 ") }

    var formError by remember { mutableStateOf("") }
    var formSuccess by remember { mutableStateOf(false) }

    val windows = listOf("06:30 - 08:00", "08:30 - 10:00", "09:30 - 11:00", "11:30 - 13:00", "14:00 - 15:30", "16:00 - 17:30")
    val vehicleTypes = listOf("Bulk Tanker (Artic)", "Bulk Tanker (Rigid)", "Rigid Flatbed + Crane")

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White, RoundedCornerShape(8.dp))
            .padding(16.dp)
    ) {
        item {
            Text(
                text = "SUBMIT BULK REQUISITION TICKET",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = YorkCemNavy
            )
            Text(
                text = "Validate volume against operational parameters and site silo constraints.",
                fontSize = 11.sp,
                color = YorkCemGrey
            )
            Spacer(modifier = Modifier.height(8.dp))
        }

        // Error message banner
        if (formError.isNotEmpty()) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = YorkCemRed.copy(alpha = 0.1f))) {
                    Text(formError, color = YorkCemRed, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(8.dp))
                }
            }
        }

        // Success message banner
        if (formSuccess) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = YorkCemGreen.copy(alpha = 0.1f))) {
                    Text("Requisition logged successfully! Transmitting to YORKCEM Dispatch Control Room.", color = YorkCemGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(8.dp))
                }
            }
        }

        // SITE SELECT
        item {
            Text("TARGET UNLOADING SITE & STORAGE", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                sites.forEach { site ->
                    Surface(
                        color = if (selectedSiteId == site.siteId) YorkCemNavy else YorkCemLightGrey,
                        border = BorderStroke(1.dp, YorkCemNavy),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedSiteId = site.siteId }
                    ) {
                        Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(site.siteId, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = if (selectedSiteId == site.siteId) Color.White else YorkCemNavy)
                            Text("Cap: ${site.siloCapacityTonnes}t", fontSize = 10.sp, color = if (selectedSiteId == site.siteId) YorkCemStone else YorkCemGrey)
                        }
                    }
                }
            }
        }

        // PRODUCT SELECT
        item {
            Text("PRODUCT SPECIFICATION", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                products.forEach { prod ->
                    Surface(
                        color = if (selectedProductId == prod.productId) YorkCemOrange else YorkCemLightGrey,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedProductId = prod.productId }
                    ) {
                        Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(prod.productName, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = if (selectedProductId == prod.productId) Color.White else YorkCemNavy)
                            Text("${prod.cementType} | £${prod.price.toInt()}/t", fontSize = 9.sp, color = if (selectedProductId == prod.productId) Color.White.copy(alpha = 0.8f) else YorkCemGrey)
                        }
                    }
                }
            }
        }

        // QUANTITY INPUT (TONNES)
        item {
            OutlinedTextField(
                value = quantityString,
                onValueChange = { quantityString = it },
                label = { Text("Required Quantity (Tonnes)") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("quantity_input")
            )
        }

        // DELIVERY WINDOW SELECT
        item {
            Text("DELIVERY TIME SLOT", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                windows.take(3).forEach { slot ->
                    Surface(
                        color = if (deliveryWindow == slot) YorkCemNavy else YorkCemLightGrey,
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { deliveryWindow = slot }
                    ) {
                        Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(6.dp)) {
                            Text(slot, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = if (deliveryWindow == slot) Color.White else YorkCemNavy)
                        }
                    }
                }
            }
        }

        // VEHICLE SELECT
        item {
            Text("VEHICLE REQUISITION METRICS", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                vehicleTypes.forEach { vt ->
                    Surface(
                        color = if (vehicleTypeRequested == vt) YorkCemNavy else YorkCemLightGrey,
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { vehicleTypeRequested = vt }
                    ) {
                        Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(6.dp)) {
                            Text(vt, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = if (vehicleTypeRequested == vt) Color.White else YorkCemNavy)
                        }
                    }
                }
            }
        }

        // PO NUMBER & PHONE
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = poNumber,
                    onValueChange = { poNumber = it },
                    label = { Text("PO Reference") },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("po_input")
                )
                OutlinedTextField(
                    value = contactPhone,
                    onValueChange = { contactPhone = it },
                    label = { Text("Site Contact Phone") },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("phone_input")
                )
            }
        }

        // SITE DIRECTIONS / EXTRA DETAILS
        item {
            OutlinedTextField(
                value = specialInstructions,
                onValueChange = { specialInstructions = it },
                label = { Text("Special Site Unloading Instructions") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        // SUBMIT ACTIONS
        item {
            Button(
                onClick = {
                    formError = ""
                    val qty = quantityString.toDoubleOrNull()
                    val targetSite = sites.find { it.siteId == selectedSiteId }

                    if (qty == null || qty <= 0) {
                        formError = "CRITICAL: Enter a positive numeric value for cement quantity."
                        return@Button
                    }
                    if (targetSite != null && targetSite.siloCapacityTonnes > 0 && qty > targetSite.siloCapacityTonnes) {
                        formError = "CRITICAL: Ordered volume ($qty t) exceeds target site silo capacity bounds (${targetSite.siloCapacityTonnes} t)."
                        return@Button
                    }
                    if (poNumber.length < 4) {
                        formError = "CRITICAL: Valid Purchase Order (PO) reference required for automated invoicing audits."
                        return@Button
                    }

                    // Submit Order
                    viewModel.createOrder(
                        customerName = "Aire Construction",
                        siteId = selectedSiteId,
                        productId = selectedProductId,
                        quantity = qty,
                        deliveryWindow = deliveryWindow,
                        vehicleType = vehicleTypeRequested,
                        phone = contactPhone,
                        instructions = specialInstructions,
                        poNumber = poNumber,
                        specialReqs = "PPE: hard hat, high vis, protective footwear"
                    )

                    formSuccess = true
                    // Reset
                    quantityString = "24.0"
                    poNumber = "PO-"
                    specialInstructions = ""
                },
                colors = ButtonDefaults.buttonColors(containerColor = YorkCemOrange),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("submit_order_btn")
            ) {
                Text("DISPATCH CEMENT BOOKING", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }
    }
}

@Composable
fun CustomerTrackingScreen(viewModel: YorkCemViewModel) {
    val trackingOrderId by viewModel.selectedOrderIdForTracking.collectAsState()
    val orders by viewModel.orders.collectAsState()
    val order = orders.find { it.orderId == trackingOrderId }

    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        modifier = Modifier
            .fillMaxSize()
            .padding(8.dp)
    ) {
        if (order == null) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Select a delivery from your dashboard to track it live.")
            }
        } else {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "REAL-TIME LOGISTICS TRACKING",
                    color = YorkCemNavy,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
                Text(
                    text = "ORDER ID: #${order.orderId} | SITE: ${order.siteId}",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = YorkCemNavy
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Track Progress steps
                val steps = listOf("APPROVED", "LOADING", "LOADED", "EN_ROUTE", "ARRIVED", "DISCHARGING", "COMPLETED")
                val activeIndex = steps.indexOf(order.status)

                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    steps.forEachIndexed { index, step ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (index <= activeIndex) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                contentDescription = null,
                                tint = if (index <= activeIndex) YorkCemGreen else YorkCemGrey,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = step,
                                fontWeight = if (index == activeIndex) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 14.sp,
                                color = if (index == activeIndex) YorkCemNavy else YorkCemGrey
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Card(colors = CardDefaults.cardColors(containerColor = YorkCemLightGrey)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Carrier Tanker:", fontSize = 12.sp)
                            Text(order.assignedVehicle ?: "PENDING", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Assigned Driver:", fontSize = 12.sp)
                            Text(order.assignedDriver ?: "PENDING", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Current ETA:", fontSize = 12.sp)
                            Text(order.eta ?: "COMPUTING", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = YorkCemOrange)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = { viewModel.setCustomerScreen("DASHBOARD") },
                    colors = ButtonDefaults.buttonColors(containerColor = YorkCemNavy),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("RETURN TO HOME")
                }
            }
        }
    }
}

@Composable
fun CustomerDocumentHub(
    viewModel: YorkCemViewModel,
    orders: List<Order>,
    pods: List<com.example.data.model.ProofOfDelivery>
) {
    var selectedOrderForInvoice by remember { mutableStateOf<Order?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("ELECTRONIC DELIVERY TICKETS & INVOICING", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = YorkCemNavy)

        Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("Your Digital Invoices", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(6.dp))

                val completed = orders.filter { it.status == "COMPLETED" }
                if (completed.isEmpty()) {
                    Text("No invoices generated yet. Invoices are dispatched on successful unloading completion.", fontSize = 11.sp, color = YorkCemGrey)
                } else {
                    LazyColumn(modifier = Modifier.height(140.dp)) {
                        items(completed) { order ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .background(YorkCemLightGrey, RoundedCornerShape(4.dp))
                                    .clickable { selectedOrderForInvoice = order }
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("Invoice INV-${1280 + order.orderId}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Text("Order #${order.orderId} | PO: ${order.poNumber}", fontSize = 10.sp, color = YorkCemGrey)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("£${order.priceTotal.toInt()}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = YorkCemNavy)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Icon(Icons.Default.Download, contentDescription = "Download invoice", tint = YorkCemOrange, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("Electronic Proof of Delivery (ePOD)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(6.dp))

                if (pods.isEmpty()) {
                    Text("No delivery tickets recorded.", fontSize = 11.sp, color = YorkCemGrey)
                } else {
                    LazyColumn(modifier = Modifier.height(140.dp)) {
                        items(pods) { pod ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .background(YorkCemLightGrey, RoundedCornerShape(4.dp))
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("POD Ticket #${pod.podId}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Text("Site: ${pod.siteName} | Carrier: ${pod.vehicleReg}", fontSize = 10.sp, color = YorkCemGrey)
                                    Text("Signee: ${pod.signatureName}", fontSize = 9.sp, color = YorkCemNavy)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("${pod.quantityDelivered}t", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = YorkCemGreen)
                                    Text("Arrived: ${pod.arrivalTime} | Finish: ${pod.completionTime}", fontSize = 9.sp, color = YorkCemGrey)
                                }
                            }
                        }
                    }
                }
            }
        }

        // INVOICE PREVIEW DRAWER
        AnimatedVisibility(visible = selectedOrderForInvoice != null) {
            val order = selectedOrderForInvoice!!
            Card(
                colors = CardDefaults.cardColors(containerColor = YorkCemNavy),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("YORKSHIRE CEMENT & MATERIALS LTD", color = YorkCemStone, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        IconButton(onClick = { selectedOrderForInvoice = null }) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                        }
                    }
                    Text("TAX INVOICE INV-${1280 + order.orderId}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("Billed to: Aire Construction Ltd.", color = YorkCemStone, fontSize = 12.sp)
                    Text("PO Number: ${order.poNumber}", color = YorkCemStone, fontSize = 12.sp)

                    Divider(modifier = Modifier.padding(vertical = 8.dp), color = YorkCemStone.copy(alpha = 0.3f))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Bulk Cement Supply (${order.quantity} t)", color = Color.White, fontSize = 12.sp)
                        Text("£${(order.priceTotal - 150.0).toInt()}.00", color = Color.White, fontSize = 12.sp)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Heavy Transport Charge & Silo Hookup", color = Color.White, fontSize = 12.sp)
                        Text("£150.00", color = Color.White, fontSize = 12.sp)
                    }

                    Divider(modifier = Modifier.padding(vertical = 8.dp), color = YorkCemStone.copy(alpha = 0.3f))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("TOTAL DUE (Inc. VAT)", color = YorkCemStone, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("£${order.priceTotal.toInt()}.00", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun CustomerSupportHub(
    viewModel: YorkCemViewModel,
    orders: List<Order>,
    tickets: List<Map<String, String>>
) {
    var issueType by remember { mutableStateOf("Late Delivery") }
    var orderIdForTicket by remember { mutableStateOf("") }
    var ticketDetails by remember { mutableStateOf("") }
    var supportFormSuccess by remember { mutableStateOf(false) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("CUSTOMER SERVICE & DISCREPANCY REGISTER", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = YorkCemNavy)

        Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("Log an Incident / Ticket", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(8.dp))

                if (supportFormSuccess) {
                    Text("Ticket logged. Our Yorkshire operations manager will contact you within 30 minutes.", color = YorkCemGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Late Delivery", "Wrong Product", "Quantity Variance").forEach { type ->
                        Surface(
                            color = if (issueType == type) YorkCemNavy else YorkCemLightGrey,
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { issueType = type }
                        ) {
                            Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(8.dp)) {
                                Text(type, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (issueType == type) Color.White else YorkCemNavy)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = orderIdForTicket,
                    onValueChange = { orderIdForTicket = it },
                    label = { Text("Associated Order ID (#)") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = ticketDetails,
                    onValueChange = { ticketDetails = it },
                    label = { Text("Describe the delivery anomaly...") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = {
                        if (orderIdForTicket.isNotEmpty() && ticketDetails.isNotEmpty()) {
                            viewModel.submitSupportTicket(orderIdForTicket, issueType, ticketDetails)
                            supportFormSuccess = true
                            orderIdForTicket = ""
                            ticketDetails = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = YorkCemOrange),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("TRANSMIT INCIDENT TICKET")
                }
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("Active Support Tickets", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(6.dp))

                LazyColumn(modifier = Modifier.height(140.dp)) {
                    items(tickets) { ticket ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .background(YorkCemLightGrey, RoundedCornerShape(4.dp))
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("${ticket["id"]} | ${ticket["type"]}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text("Order Reference: ${ticket["orderId"]}", fontSize = 10.sp, color = YorkCemGrey)
                                Text(ticket["text"] ?: "", fontSize = 10.sp, color = YorkCemNavy)
                            }
                            Surface(
                                color = if (ticket["status"] == "RESOLVED") YorkCemGreen.copy(alpha = 0.2f) else YorkCemOrange.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = ticket["status"] ?: "",
                                    color = if (ticket["status"] == "RESOLVED") YorkCemGreen else YorkCemOrange,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
