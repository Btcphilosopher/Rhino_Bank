package com.example.data.dao

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface YorkCemDao {

    // Products
    @Query("SELECT * FROM products")
    fun getProductsFlow(): Flow<List<Product>>

    @Query("SELECT * FROM products")
    suspend fun getProducts(): List<Product>

    @Query("SELECT * FROM products WHERE productId = :id")
    suspend fun getProductById(id: String): Product?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: Product)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProducts(products: List<Product>)

    // Customer Sites
    @Query("SELECT * FROM customer_sites")
    fun getCustomerSitesFlow(): Flow<List<CustomerSite>>

    @Query("SELECT * FROM customer_sites")
    suspend fun getCustomerSites(): List<CustomerSite>

    @Query("SELECT * FROM customer_sites WHERE siteId = :id")
    suspend fun getSiteById(id: String): CustomerSite?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSite(site: CustomerSite)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSites(sites: List<CustomerSite>)

    // Vehicles
    @Query("SELECT * FROM vehicles")
    fun getVehiclesFlow(): Flow<List<Vehicle>>

    @Query("SELECT * FROM vehicles")
    suspend fun getVehicles(): List<Vehicle>

    @Query("SELECT * FROM vehicles WHERE registration = :reg")
    suspend fun getVehicleByReg(reg: String): Vehicle?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVehicle(vehicle: Vehicle)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVehicles(vehicles: List<Vehicle>)

    // Silos
    @Query("SELECT * FROM silos")
    fun getSilosFlow(): Flow<List<Silo>>

    @Query("SELECT * FROM silos")
    suspend fun getSilos(): List<Silo>

    @Query("SELECT * FROM silos WHERE siloId = :id")
    suspend fun getSiloById(id: String): Silo?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSilo(silo: Silo)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSilos(silos: List<Silo>)

    // Orders
    @Query("SELECT * FROM orders ORDER BY orderId DESC")
    fun getOrdersFlow(): Flow<List<Order>>

    @Query("SELECT * FROM orders ORDER BY orderId DESC")
    suspend fun getOrders(): List<Order>

    @Query("SELECT * FROM orders WHERE orderId = :id")
    suspend fun getOrderById(id: Long): Order?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: Order): Long

    @Update
    suspend fun updateOrder(order: Order)

    // Pre-start Checks
    @Query("SELECT * FROM pre_start_checks ORDER BY timestamp DESC")
    fun getPreStartChecksFlow(): Flow<List<PreStartCheck>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPreStartCheck(check: PreStartCheck)

    // Load Management
    @Query("SELECT * FROM load_management ORDER BY timestamp DESC")
    fun getLoadsFlow(): Flow<List<LoadManagement>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLoad(load: LoadManagement)

    // Proof Of Delivery
    @Query("SELECT * FROM proof_of_delivery ORDER BY podId DESC")
    fun getPodsFlow(): Flow<List<ProofOfDelivery>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPod(pod: ProofOfDelivery)

    // Audit Logs
    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC")
    fun getAuditLogsFlow(): Flow<List<AuditLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: AuditLog)
}
