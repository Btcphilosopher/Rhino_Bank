package com.example.data.repository

import com.example.data.dao.YorkCemDao
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

class YorkCemRepository(private val dao: YorkCemDao) {

    val products: Flow<List<Product>> = dao.getProductsFlow()
    val sites: Flow<List<CustomerSite>> = dao.getCustomerSitesFlow()
    val vehicles: Flow<List<Vehicle>> = dao.getVehiclesFlow()
    val silos: Flow<List<Silo>> = dao.getSilosFlow()
    val orders: Flow<List<Order>> = dao.getOrdersFlow()
    val preStartChecks: Flow<List<PreStartCheck>> = dao.getPreStartChecksFlow()
    val loads: Flow<List<LoadManagement>> = dao.getLoadsFlow()
    val pods: Flow<List<ProofOfDelivery>> = dao.getPodsFlow()
    val auditLogs: Flow<List<AuditLog>> = dao.getAuditLogsFlow()

    suspend fun getProductById(id: String) = dao.getProductById(id)
    suspend fun insertProduct(product: Product) = dao.insertProduct(product)

    suspend fun getSiteById(id: String) = dao.getSiteById(id)
    suspend fun insertSite(site: CustomerSite) = dao.insertSite(site)

    suspend fun getVehicleByReg(reg: String) = dao.getVehicleByReg(reg)
    suspend fun insertVehicle(vehicle: Vehicle) = dao.insertVehicle(vehicle)

    suspend fun getSiloById(id: String) = dao.getSiloById(id)
    suspend fun insertSilo(silo: Silo) = dao.insertSilo(silo)

    suspend fun getOrderById(id: Long) = dao.getOrderById(id)
    suspend fun createOrder(order: Order): Long = dao.insertOrder(order)
    suspend fun updateOrder(order: Order) = dao.updateOrder(order)

    suspend fun insertPreStartCheck(check: PreStartCheck) = dao.insertPreStartCheck(check)
    suspend fun insertLoad(load: LoadManagement) = dao.insertLoad(load)
    suspend fun insertPod(pod: ProofOfDelivery) = dao.insertPod(pod)
    suspend fun insertAuditLog(log: AuditLog) = dao.insertAuditLog(log)
}
