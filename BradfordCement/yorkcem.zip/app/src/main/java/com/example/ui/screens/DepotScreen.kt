package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Silo
import com.example.ui.theme.*
import com.example.ui.viewmodel.YorkCemViewModel

@Composable
fun DepotScreen(
    viewModel: YorkCemViewModel,
    modifier: Modifier = Modifier
) {
    val silos by viewModel.silos.collectAsState()
    val orders by viewModel.orders.collectAsState()

    // Filter loading queue
    val loadingOrders = orders.filter { it.status == "LOADING" || it.status == "APPROVED" }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(YorkCemLightGrey)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // DEPOT OVERVIEW BANNER
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = YorkCemNavy),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("YORKSHIRE BASE DEPOT", color = YorkCemStone, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("SILO & LOADING OPERATIONS", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                    Icon(Icons.Default.SettingsInputComponent, contentDescription = null, tint = YorkCemStone, modifier = Modifier.size(36.dp))
                }
            }
        }

        // SILO TELEMETRY MONITOR
        item {
            Text("LIVE SILO INVENTORY & TELEMETRY", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = YorkCemNavy)
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                silos.forEach { silo ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(2.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("silo_monitor_${silo.siloId}")
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(silo.siloId, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = YorkCemNavy)
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .background(
                                            if (silo.alarmsActive) YorkCemRed else YorkCemGreen,
                                            RoundedCornerShape(4.dp)
                                        )
                                )
                            }
                            Text(silo.name, fontSize = 10.sp, color = YorkCemGrey, maxLines = 1)

                            Spacer(modifier = Modifier.height(12.dp))

                            // Silo Level Indicator (Vertical progress simulation)
                            val fillPercentage = (silo.currentQuantity / silo.capacityTonnes).toFloat()

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(100.dp)
                                    .background(YorkCemLightGrey, RoundedCornerShape(4.dp))
                                    .clip(RoundedCornerShape(4.dp))
                                    .border(1.dp, YorkCemStone.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .fillMaxHeight(fillPercentage)
                                        .background(
                                            if (fillPercentage < 0.2f) YorkCemRed else YorkCemNavy
                                        )
                                        .align(Alignment.BottomCenter)
                                )
                                Text(
                                    text = "${(fillPercentage * 100).toInt()}%",
                                    color = if (fillPercentage > 0.5f) Color.White else YorkCemNavy,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    modifier = Modifier.align(Alignment.Center)
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text("Qty: ${silo.currentQuantity.toInt()} t", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("Temp: ${silo.temperatureC}°C", fontSize = 10.sp, color = YorkCemGrey)
                            Text(
                                text = silo.status,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (silo.status == "LOW") YorkCemRed else YorkCemGreen
                            )
                        }
                    }
                }
            }
        }

        // LOADING BAY QUEUE
        item {
            Text("AUTOMATED LOADING BAY QUEUE (WEST BAY)", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = YorkCemNavy)
        }

        if (loadingOrders.isEmpty()) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Text("No tankers currently in loading queue or bays.", fontSize = 12.sp, color = YorkCemGrey, modifier = Modifier.padding(16.dp))
                }
            }
        } else {
            items(loadingOrders) { order ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, YorkCemStone.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "BAY 0${(order.orderId % 3) + 1}",
                                    fontWeight = FontWeight.Bold,
                                    color = YorkCemOrange,
                                    fontSize = 14.sp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Truck: ${order.assignedVehicle ?: "UNASSIGNED"}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                            Text("Product: CEM Bulk Portland | Target: ${order.quantity} t", fontSize = 11.sp, color = YorkCemGrey)
                            Text("Driver: ${order.assignedDriver ?: "PENDING"}", fontSize = 11.sp, color = YorkCemNavy)
                        }

                        // Operator Trigger Action
                        if (order.status == "APPROVED") {
                            Button(
                                onClick = { viewModel.startLoadingProcess(order.orderId) },
                                colors = ButtonDefaults.buttonColors(containerColor = YorkCemOrange)
                            ) {
                                Text("START FILL", fontSize = 11.sp)
                            }
                        } else if (order.status == "LOADING") {
                            Button(
                                onClick = { viewModel.completeLoadingProcess(order.orderId, order.quantity, "Operator Pete") },
                                colors = ButtonDefaults.buttonColors(containerColor = YorkCemGreen)
                            ) {
                                Text("COMPLETE LOAD", fontSize = 11.sp)
                            }
                        } else {
                            Surface(color = YorkCemGreen, shape = RoundedCornerShape(4.dp)) {
                                Text("LOADED", color = Color.White, fontSize = 10.sp, modifier = Modifier.padding(6.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}
