export interface InstrumentData {
  id: string; // e.g., 'USDSTBL', 'GBPSTBL', 'EURSTBL', 'JPYSTBL', 'CHFSTBL', 'USD/GBP', 'USD/EUR', 'EUR/GBP'
  name: string;
  baseCurrency: string;
  quoteCurrency: string;
  targetPeg: number;
  currentPrice: number;
  bestBid: number;
  bestAsk: number;
  spreadBps: number;
  vwap24h: number;
  twap24h: number;
  high24h: number;
  low24h: number;
  volume24hUsd: number;
  volatilityBps: number;
  depthBidUsd: number;
  depthAskUsd: number;
  deviationBps: number;
  redemptionFlow: 'NORMAL' | 'ELEVATED' | 'HIGH_REDEMPTION' | 'CRITICAL_OUTFLOW';
  riskState: 'GREEN' | 'AMBER' | 'RED' | 'CRITICAL';
}

export interface VenueQuote {
  venueId: string;
  venueName: string;
  bid: number;
  ask: number;
  bidSize: number;
  askSize: number;
  latencyMs: number;
  feeBps: number;
  status: 'ONLINE' | 'DEGRADED' | 'DISCONNECTED';
}

export interface OrderRecord {
  orderId: string;
  timestamp: string;
  account: string;
  trader: string;
  instrument: string;
  side: 'BUY' | 'SELL';
  quantity: number;
  price: number;
  orderType: 'MARKET' | 'LIMIT' | 'STOP' | 'STOP_LIMIT' | 'IOC' | 'FOK' | 'GTC' | 'RFQ';
  timeInForce: string;
  venue: string;
  riskStatus: 'PASSED' | 'REJECTED' | 'WARNING';
  executionStatus: 'NEW' | 'PARTIALLY_FILLED' | 'FILLED' | 'CANCELLED' | 'REJECTED';
  rejectionReason?: string;
}

export interface ExecutionRecord {
  executionId: string;
  orderId: string;
  timestamp: string;
  instrument: string;
  side: 'BUY' | 'SELL';
  filledQuantity: number;
  filledPrice: number;
  feeUsd: number;
  slippageBps: number;
  venue: string;
  settlementStatus: 'MATCHED' | 'DVP_PENDING' | 'SETTLED_ATOMIC';
}

export interface PositionRecord {
  currency: string;
  instrument: string;
  netPosition: number;
  avgPrice: number;
  currentPrice: number;
  unrealizedPnl: number;
  realizedPnl: number;
  exposureUsd: number;
}

export interface TreasuryState {
  totalLiquidityUsd: number;
  cashFiatUsd: number;
  stablecoinInventoryUsd: number;
  govSecuritiesUsd: number;
  collateralAllocatedUsd: number;
  runway30dDays: number;
  runway90dDays: number;
  redemptionCoveragePct: number;
  reserves: {
    currency: string;
    fiatBalance: number;
    stablecoinBalance: number;
    backingRatioPct: number;
  }[];
}

export interface RiskState {
  overallState: 'GREEN' | 'AMBER' | 'RED' | 'CRITICAL';
  marketRiskLevel: number; // 0-100
  liquidityRiskLevel: number; // 0-100
  counterpartyRiskLevel: number; // 0-100
  depegRiskLevel: number; // 0-100
  var99Usd: number;
  expectedShortfallUsd: number;
  pPegBreachPct: number;
  pLiquidityShortfallPct: number;
  limits: {
    level: string;
    notionalUsedUsd: number;
    notionalLimitUsd: number;
    pctUsed: number;
  }[];
}

export interface SystemHealth {
  apiGateway: 'ONLINE' | 'DEGRADED' | 'OFFLINE';
  database: 'ONLINE' | 'DEGRADED' | 'OFFLINE';
  marketData: 'ONLINE' | 'DEGRADED' | 'STALE' | 'OFFLINE';
  riskEngine: 'ONLINE' | 'DEGRADED' | 'OFFLINE';
  execution: 'ONLINE' | 'DEGRADED' | 'OFFLINE';
  settlement: 'ONLINE' | 'DEGRADED' | 'OFFLINE';
  reconciliation: 'BALANCED' | 'MISMATCH_DETECTED';
  incidentState: 'NORMAL' | 'DEGRADED' | 'PARTIAL_OUTAGE' | 'EMERGENCY';
}

export interface ScenarioType {
  id: 'NORMAL' | 'HIGH_VOLATILITY' | 'LIQUIDITY_SHOCK' | 'REDEMPTION_EVENT' | 'DEPEG' | 'VENUE_FAILURE' | 'COUNTERPARTY_FAILURE' | 'MARKET_DATA_FAILURE' | 'COMBINED_CRISIS';
  name: string;
  description: string;
}

// Global In-Memory Store for Synthetic Institutional State
let currentScenario: ScenarioType['id'] = 'NORMAL';

export function getScenario(): ScenarioType['id'] {
  return currentScenario;
}

export function setScenario(scenario: ScenarioType['id']) {
  currentScenario = scenario;
}

// Initial Instruments Baseline
export function getInitialInstruments(scenario: ScenarioType['id']): InstrumentData[] {
  let depegOffset = 0;
  let spreadMult = 1;
  let volatilityMult = 1;
  let redemptionState: InstrumentData['redemptionFlow'] = 'NORMAL';
  let riskState: InstrumentData['riskState'] = 'GREEN';

  if (scenario === 'DEPEG') {
    depegOffset = -0.0050; // -50 bps depeg on USDSTBL
    spreadMult = 3.5;
    volatilityMult = 4.0;
    redemptionState = 'CRITICAL_OUTFLOW';
    riskState = 'CRITICAL';
  } else if (scenario === 'LIQUIDITY_SHOCK') {
    spreadMult = 5.0;
    volatilityMult = 2.5;
    redemptionState = 'HIGH_REDEMPTION';
    riskState = 'RED';
  } else if (scenario === 'REDEMPTION_EVENT') {
    redemptionState = 'HIGH_REDEMPTION';
    riskState = 'AMBER';
  } else if (scenario === 'HIGH_VOLATILITY') {
    volatilityMult = 3.0;
    spreadMult = 2.0;
    riskState = 'AMBER';
  } else if (scenario === 'COMBINED_CRISIS') {
    depegOffset = -0.0090; // -90 bps depeg
    spreadMult = 8.0;
    volatilityMult = 6.0;
    redemptionState = 'CRITICAL_OUTFLOW';
    riskState = 'CRITICAL';
  }

  const usdPrice = 1.0000 + depegOffset;
  
  return [
    {
      id: 'USDSTBL',
      name: 'Rhino USD Institutional Stablecoin',
      baseCurrency: 'USDSTBL',
      quoteCurrency: 'USD',
      targetPeg: 1.000000,
      currentPrice: usdPrice,
      bestBid: Number((usdPrice - 0.0001 * spreadMult).toFixed(6)),
      bestAsk: Number((usdPrice + 0.0001 * spreadMult).toFixed(6)),
      spreadBps: Number((0.2 * spreadMult).toFixed(2)),
      vwap24h: 0.99992,
      twap24h: 0.99995,
      high24h: 1.00012,
      low24h: Number((usdPrice - 0.0005).toFixed(5)),
      volume24hUsd: 1450000000,
      volatilityBps: Number((1.8 * volatilityMult).toFixed(1)),
      depthBidUsd: scenario === 'LIQUIDITY_SHOCK' ? 8500000 : 85000000,
      depthAskUsd: scenario === 'LIQUIDITY_SHOCK' ? 9200000 : 92000000,
      deviationBps: Number(((usdPrice - 1.0) * 10000).toFixed(1)),
      redemptionFlow: redemptionState,
      riskState,
    },
    {
      id: 'GBPSTBL',
      name: 'Rhino GBP Institutional Stablecoin',
      baseCurrency: 'GBPSTBL',
      quoteCurrency: 'GBP',
      targetPeg: 1.000000,
      currentPrice: 1.00002,
      bestBid: 0.99995,
      bestAsk: 1.00008,
      spreadBps: 1.3,
      vwap24h: 1.00001,
      twap24h: 1.00000,
      high24h: 1.00025,
      low24h: 0.99980,
      volume24hUsd: 480000000,
      volatilityBps: 2.1,
      depthBidUsd: 35000000,
      depthAskUsd: 38000000,
      deviationBps: 0.2,
      redemptionFlow: 'NORMAL',
      riskState: 'GREEN',
    },
    {
      id: 'EURSTBL',
      name: 'Rhino EUR Institutional Stablecoin',
      baseCurrency: 'EURSTBL',
      quoteCurrency: 'EUR',
      targetPeg: 1.000000,
      currentPrice: 0.99998,
      bestBid: 0.99991,
      bestAsk: 1.00005,
      spreadBps: 1.4,
      vwap24h: 0.99997,
      twap24h: 0.99998,
      high24h: 1.00018,
      low24h: 0.99975,
      volume24hUsd: 620000000,
      volatilityBps: 2.3,
      depthBidUsd: 42000000,
      depthAskUsd: 45000000,
      deviationBps: -0.2,
      redemptionFlow: 'NORMAL',
      riskState: 'GREEN',
    },
    {
      id: 'JPYSTBL',
      name: 'Rhino JPY Institutional Stablecoin',
      baseCurrency: 'JPYSTBL',
      quoteCurrency: 'JPY',
      targetPeg: 1.000000,
      currentPrice: 1.00005,
      bestBid: 0.99996,
      bestAsk: 1.00014,
      spreadBps: 1.8,
      vwap24h: 1.00003,
      twap24h: 1.00002,
      high24h: 1.00030,
      low24h: 0.99970,
      volume24hUsd: 210000000,
      volatilityBps: 3.1,
      depthBidUsd: 18000000,
      depthAskUsd: 20000000,
      deviationBps: 0.5,
      redemptionFlow: 'NORMAL',
      riskState: 'GREEN',
    },
    {
      id: 'CHFSTBL',
      name: 'Rhino CHF Institutional Stablecoin',
      baseCurrency: 'CHFSTBL',
      quoteCurrency: 'CHF',
      targetPeg: 1.000000,
      currentPrice: 1.00001,
      bestBid: 0.99994,
      bestAsk: 1.00007,
      spreadBps: 1.3,
      vwap24h: 1.00000,
      twap24h: 1.00001,
      high24h: 1.00015,
      low24h: 0.99985,
      volume24hUsd: 190000000,
      volatilityBps: 1.9,
      depthBidUsd: 16000000,
      depthAskUsd: 17500000,
      deviationBps: 0.1,
      redemptionFlow: 'NORMAL',
      riskState: 'GREEN',
    },
    {
      id: 'USD/GBP',
      name: 'USDSTBL / GBPSTBL Cross Pair',
      baseCurrency: 'USDSTBL',
      quoteCurrency: 'GBPSTBL',
      targetPeg: 0.782000,
      currentPrice: 0.78195,
      bestBid: 0.78188,
      bestAsk: 0.78202,
      spreadBps: 1.8,
      vwap24h: 0.78198,
      twap24h: 0.78194,
      high24h: 0.78310,
      low24h: 0.78080,
      volume24hUsd: 340000000,
      volatilityBps: 12.4,
      depthBidUsd: 25000000,
      depthAskUsd: 27000000,
      deviationBps: -0.6,
      redemptionFlow: 'NORMAL',
      riskState: 'GREEN',
    },
    {
      id: 'USD/EUR',
      name: 'USDSTBL / EURSTBL Cross Pair',
      baseCurrency: 'USDSTBL',
      quoteCurrency: 'EURSTBL',
      targetPeg: 0.921500,
      currentPrice: 0.92148,
      bestBid: 0.92140,
      bestAsk: 0.92156,
      spreadBps: 1.7,
      vwap24h: 0.92152,
      twap24h: 0.92146,
      high24h: 0.92280,
      low24h: 0.92010,
      volume24hUsd: 410000000,
      volatilityBps: 11.8,
      depthBidUsd: 31000000,
      depthAskUsd: 33000000,
      deviationBps: -0.2,
      redemptionFlow: 'NORMAL',
      riskState: 'GREEN',
    },
    {
      id: 'EUR/GBP',
      name: 'EURSTBL / GBPSTBL Cross Pair',
      baseCurrency: 'EURSTBL',
      quoteCurrency: 'GBPSTBL',
      targetPeg: 0.848500,
      currentPrice: 0.84846,
      bestBid: 0.84838,
      bestAsk: 0.84854,
      spreadBps: 1.9,
      vwap24h: 0.84849,
      twap24h: 0.84844,
      high24h: 0.84960,
      low24h: 0.84720,
      volume24hUsd: 290000000,
      volatilityBps: 14.1,
      depthBidUsd: 22000000,
      depthAskUsd: 24000000,
      deviationBps: -0.5,
      redemptionFlow: 'NORMAL',
      riskState: 'GREEN',
    },
  ];
}
