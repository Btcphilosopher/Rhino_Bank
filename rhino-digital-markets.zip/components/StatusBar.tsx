"use client";

import React from "react";
import { ShieldCheck, Activity, AlertOctagon, TrendingUp, Lock } from "lucide-react";

interface StatusBarProps {
  riskState: 'GREEN' | 'AMBER' | 'RED' | 'CRITICAL';
  liquidityState: string;
  limitPct: number;
  todayPnlUsd: number;
  pegPrice: number;
  pegDeviationBps: number;
  activeScenario: string;
}

export function StatusBar({
  riskState,
  liquidityState,
  limitPct,
  todayPnlUsd,
  pegPrice,
  pegDeviationBps,
  activeScenario,
}: StatusBarProps) {
  const getRiskBadge = () => {
    switch (riskState) {
      case 'GREEN':
        return <span className="bg-emerald-950/80 text-emerald-400 border border-emerald-800/60 px-2 py-0.5 rounded font-mono font-bold">Risk: GREEN</span>;
      case 'AMBER':
        return <span className="bg-amber-950/80 text-amber-400 border border-amber-800/60 px-2 py-0.5 rounded font-mono font-bold">Risk: AMBER (ELEVATED)</span>;
      case 'RED':
        return <span className="bg-rose-950/80 text-rose-400 border border-rose-800/60 px-2 py-0.5 rounded font-mono font-bold animate-pulse">Risk: RED (HIGH)</span>;
      case 'CRITICAL':
        return <span className="bg-rose-600 text-white px-2 py-0.5 rounded font-mono font-bold animate-pulse">Risk: CRITICAL (DEPEG ESCALATION)</span>;
    }
  };

  return (
    <footer className="bg-[#090c10] border-t border-[#1e293b] px-4 py-1.5 text-xs text-slate-300 font-mono flex items-center justify-between select-none">
      <div className="flex items-center space-x-4">
        {getRiskBadge()}

        <span className="flex items-center space-x-1">
          <span className="text-slate-500">Liquidity:</span>
          <span className={liquidityState === 'HIGH' ? 'text-emerald-400 font-bold' : 'text-amber-400 font-bold'}>
            {liquidityState}
          </span>
        </span>

        <span className="flex items-center space-x-1">
          <span className="text-slate-500">Notional Limits:</span>
          <span className={limitPct > 80 ? 'text-amber-400 font-bold' : 'text-slate-200'}>
            {limitPct.toFixed(1)}% Used
          </span>
        </span>

        <span className="flex items-center space-x-1">
          <span className="text-slate-500">Today P&L:</span>
          <span className={todayPnlUsd >= 0 ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
            {todayPnlUsd >= 0 ? `+$${todayPnlUsd.toLocaleString()}` : `-$${Math.abs(todayPnlUsd).toLocaleString()}`}
          </span>
        </span>

        <span className="flex items-center space-x-1 border-l border-[#1e293b] pl-3">
          <span className="text-slate-500">USDSTBL Peg:</span>
          <span className="font-bold text-slate-100">{pegPrice.toFixed(5)}</span>
          <span className={pegDeviationBps < -5 ? 'text-rose-400 font-bold' : 'text-slate-400 text-[11px]'}>
            ({pegDeviationBps >= 0 ? `+${pegDeviationBps}` : pegDeviationBps} bps)
          </span>
        </span>
      </div>

      <div className="flex items-center space-x-4 text-[11px] text-slate-400">
        <span className="flex items-center space-x-1">
          <Lock className="w-3 h-3 text-slate-500" />
          <span>AES-256 ENCRYPTED</span>
        </span>
        <span>•</span>
        <span>RUST ENGINE v3.6.0</span>
        <span>•</span>
        <span className="text-blue-400">RHINO BANK DIGITAL MARKETS</span>
      </div>
    </footer>
  );
}
