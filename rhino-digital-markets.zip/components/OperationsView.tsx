"use client";

import React from "react";
import { Server, Database, ShieldCheck, Activity, CheckCircle, FileText } from "lucide-react";

interface OperationsViewProps {
  reconciliationData: any;
  systemHealth: string;
}

export function OperationsView({ reconciliationData, systemHealth }: OperationsViewProps) {
  const summary = reconciliationData?.summary || {
    tradingLedgerUsd: 2450000000,
    bankLedgerUsd: 2450000000,
    blockchainNetworkUsd: 2450000000,
    custodyUsd: 2450000000,
    varianceUsd: 0,
    status: "BALANCED",
  };

  const auditLogs = [
    {
      id: "LOG-9921",
      timestamp: "2026-09-02T11:42:00.000Z",
      actor: "TRADER_EVANCE",
      role: "SENIOR_TRADER",
      action: "ORDER_SUBMITTED",
      details: "BUY 10,000,000 USDSTBL @ 0.99980 via RHINO_INTERNAL",
      hash: "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    },
    {
      id: "LOG-9920",
      timestamp: "2026-09-02T11:37:00.000Z",
      actor: "SYSTEM_RISK_ENGINE",
      role: "RISK_AUTOMATION",
      action: "PRE_TRADE_CHECK_PASSED",
      details: "Notional & Sanctions checks verified green",
      hash: "8f434346648f6b96df89dda901c5176b10a6d83961dd3c1ac88b59b2dc327aa4",
    },
    {
      id: "LOG-9919",
      timestamp: "2026-09-02T11:32:00.000Z",
      actor: "TREASURY_OFFICER",
      role: "TREASURY_MANAGER",
      action: "RESERVE_REBALANCED",
      details: "Transferred $50,000,000 T-Bills to Primary Escrow",
      hash: "a591a6d40bf420404a011733cfb7b190d62c65bf0bcda32b57b277d9ad9f146e",
    },
  ];

  return (
    <div className="flex-1 p-4 bg-[#07090e] text-slate-200 font-mono overflow-y-auto">
      <div className="max-w-7xl mx-auto space-y-4">
        {/* Title */}
        <div className="flex items-center justify-between bg-[#0b0e14] border border-[#1e293b] p-4 rounded">
          <div>
            <h1 className="text-lg font-extrabold text-white">RHINO OPERATIONS & RECONCILIATION COCKPIT</h1>
            <p className="text-xs text-slate-400">
              Automated 4-way ledger reconciliation, real-time subsystem state health, and cryptographic audit logging.
            </p>
          </div>
          <div className="flex items-center space-x-2 bg-emerald-950/40 text-emerald-400 border border-emerald-800/60 px-3 py-1.5 rounded text-xs font-bold">
            <CheckCircle className="w-4 h-4" />
            <span>RECONCILIATION: BALANCED (0 VARIANCE)</span>
          </div>
        </div>

        {/* System Subsystems Health Matrix */}
        <div className="bg-[#0b0e14] border border-[#1e293b] p-4 rounded space-y-3">
          <h2 className="text-sm font-bold text-slate-200 border-b border-[#1e293b] pb-2">
            SUBSYSTEM SERVICE HEALTH MATRIX
          </h2>

          <div className="grid grid-cols-4 gap-3 text-xs">
            <div className="bg-[#090d14] p-3 rounded border border-[#1e293b] flex items-center justify-between">
              <span>API Gateway Layer</span>
              <span className="text-emerald-400 font-bold">ONLINE (1.2ms)</span>
            </div>
            <div className="bg-[#090d14] p-3 rounded border border-[#1e293b] flex items-center justify-between">
              <span>PostgreSQL Cluster</span>
              <span className="text-emerald-400 font-bold">ONLINE (0.6ms)</span>
            </div>
            <div className="bg-[#090d14] p-3 rounded border border-[#1e293b] flex items-center justify-between">
              <span>Market Data Aggregator</span>
              <span className="text-emerald-400 font-bold">ONLINE (0.4ms)</span>
            </div>
            <div className="bg-[#090d14] p-3 rounded border border-[#1e293b] flex items-center justify-between">
              <span>Pre-Trade Risk Engine</span>
              <span className="text-emerald-400 font-bold">ONLINE (&lt;100µs)</span>
            </div>
            <div className="bg-[#090d14] p-3 rounded border border-[#1e293b] flex items-center justify-between">
              <span>Smart Order Router</span>
              <span className="text-emerald-400 font-bold">ONLINE (0.8ms)</span>
            </div>
            <div className="bg-[#090d14] p-3 rounded border border-[#1e293b] flex items-center justify-between">
              <span>Atomic Settlement Engine</span>
              <span className="text-emerald-400 font-bold">ONLINE (2.1ms)</span>
            </div>
            <div className="bg-[#090d14] p-3 rounded border border-[#1e293b] flex items-center justify-between">
              <span>R Quant Analytics Server</span>
              <span className="text-emerald-400 font-bold">ONLINE (READY)</span>
            </div>
            <div className="bg-[#090d14] p-3 rounded border border-[#1e293b] flex items-center justify-between">
              <span>Audit Cryptographic Logger</span>
              <span className="text-emerald-400 font-bold">ACTIVE (SHA-256)</span>
            </div>
          </div>
        </div>

        {/* 4-Way Reconciliation Grid */}
        <div className="bg-[#0b0e14] border border-[#1e293b] p-4 rounded space-y-3">
          <h2 className="text-sm font-bold text-slate-200 border-b border-[#1e293b] pb-2">
            AUTOMATED 4-WAY LEDGER RECONCILIATION GRID
          </h2>

          <div className="grid grid-cols-4 gap-3 text-xs">
            <div className="bg-[#090d14] p-3.5 rounded border border-[#1e293b] space-y-1">
              <div className="text-slate-500 text-[10px]">1. TRADING LEDGER</div>
              <div className="text-base font-extrabold text-white">${(summary.tradingLedgerUsd / 1000000000).toFixed(2)}B</div>
              <div className="text-[10px] text-emerald-400">STATUS: MATCHED</div>
            </div>

            <div className="bg-[#090d14] p-3.5 rounded border border-[#1e293b] space-y-1">
              <div className="text-slate-500 text-[10px]">2. BANK CORE LEDGER</div>
              <div className="text-base font-extrabold text-white">${(summary.bankLedgerUsd / 1000000000).toFixed(2)}B</div>
              <div className="text-[10px] text-emerald-400">STATUS: MATCHED</div>
            </div>

            <div className="bg-[#090d14] p-3.5 rounded border border-[#1e293b] space-y-1">
              <div className="text-slate-500 text-[10px]">3. BLOCKCHAIN NETWORK</div>
              <div className="text-base font-extrabold text-white">${(summary.blockchainNetworkUsd / 1000000000).toFixed(2)}B</div>
              <div className="text-[10px] text-emerald-400">STATUS: MATCHED</div>
            </div>

            <div className="bg-[#090d14] p-3.5 rounded border border-[#1e293b] space-y-1">
              <div className="text-slate-500 text-[10px]">4. CUSTODY ESCROW</div>
              <div className="text-base font-extrabold text-white">${(summary.custodyUsd / 1000000000).toFixed(2)}B</div>
              <div className="text-[10px] text-emerald-400">STATUS: MATCHED</div>
            </div>
          </div>
        </div>

        {/* Cryptographic Audit Log Explorer */}
        <div className="bg-[#0b0e14] border border-[#1e293b] p-4 rounded space-y-3">
          <h2 className="text-sm font-bold text-slate-200 border-b border-[#1e293b] pb-2">
            IMMUTABLE CRYPTOGRAPHIC AUDIT TRAIL LOG
          </h2>

          <div className="space-y-2 text-xs">
            {auditLogs.map((log) => (
              <div key={log.id} className="p-3 bg-[#090d14] border border-[#1e293b] rounded space-y-1">
                <div className="flex items-center justify-between font-bold">
                  <span className="text-blue-400">{log.id} • {log.action}</span>
                  <span className="text-slate-500 text-[10px]">{log.timestamp}</span>
                </div>
                <div className="text-slate-300 text-[11px]">{log.details}</div>
                <div className="text-[10px] text-slate-500 font-mono truncate">
                  SHA-256 State Hash: {log.hash}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
