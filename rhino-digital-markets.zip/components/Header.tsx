"use client";

import React, { useState, useEffect } from "react";
import { Shield, Activity, Cpu, Database, UserCheck, AlertTriangle } from "lucide-react";

interface HeaderProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  userRole: string;
  setUserRole: (role: string) => void;
  activeScenario: string;
  setScenario: (scen: string) => void;
  systemHealth: string;
}

const ROLES = [
  "TRADER",
  "SENIOR_TRADER",
  "TREASURY_MANAGER",
  "RISK_OFFICER",
  "COMPLIANCE_OFFICER",
  "OPERATIONS",
  "SETTLEMENT",
  "AUDITOR",
  "EXECUTIVE",
];

const TABS = [
  { id: "trading", label: "Trading Terminal" },
  { id: "rfq", label: "OTC / RFQ Desk" },
  { id: "treasury", label: "Treasury Management" },
  { id: "risk", label: "Risk Cockpit" },
  { id: "portfolio", label: "Portfolio & P&L" },
  { id: "operations", label: "Operations & Audit" },
  { id: "executive", label: "Executive View" },
  { id: "quant", label: "R Quant Lab" },
  { id: "ai", label: "Rhino Intelligence" },
];

export function Header({
  currentTab,
  setCurrentTab,
  userRole,
  setUserRole,
  activeScenario,
  setScenario,
  systemHealth,
}: HeaderProps) {
  const [time, setTime] = useState("");

  useEffect(() => {
    const update = () => {
      const now = new Date();
      setTime(now.toISOString().replace("T", " ").slice(0, 19) + " UTC");
    };
    update();
    const interval = setInterval(update, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <header className="bg-[#0b0e14] border-b border-[#1e293b] text-[#e2e8f0] select-none">
      {/* Top Brand Bar */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-[#161f2e]">
        <div className="flex items-center space-x-3">
          {/* Institutional Rhino Logo */}
          <div className="flex items-center space-x-2 bg-[#162032] border border-[#2b3b55] px-2.5 py-1 rounded">
            <div className="w-5 h-5 bg-[#0055ff] flex items-center justify-center font-bold text-xs text-white rounded-sm">
              🦏
            </div>
            <span className="font-extrabold tracking-wider text-sm text-white">
              RHINO BANK
            </span>
            <span className="text-[10px] bg-[#0055ff]/20 text-[#60a5fa] px-1.5 py-0.5 rounded font-mono uppercase tracking-widest border border-[#0055ff]/30">
              DIGITAL MARKETS
            </span>
          </div>

          <div className="h-4 w-[1px] bg-[#1e293b]" />

          <div className="flex items-center space-x-2 text-xs font-mono text-slate-400">
            <span className="flex items-center space-x-1">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse-slow" />
              <span className="text-slate-200">GLOBAL | USD</span>
            </span>
            <span>•</span>
            <span className="text-slate-400">{time}</span>
          </div>
        </div>

        {/* Right Status & Role Switchers */}
        <div className="flex items-center space-x-3 text-xs">
          {/* Scenario Trigger Badge */}
          <div className="flex items-center space-x-1.5 bg-[#111827] border border-[#1f2937] px-2 py-1 rounded">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-slate-400 text-[11px]">SCENARIO:</span>
            <select
              value={activeScenario}
              onChange={(e) => setScenario(e.target.value)}
              className="bg-transparent text-amber-300 font-mono font-bold text-xs focus:outline-none cursor-pointer"
            >
              <option value="NORMAL" className="bg-[#0b0e14] text-emerald-400">NORMAL MARKET</option>
              <option value="HIGH_VOLATILITY" className="bg-[#0b0e14] text-amber-400">HIGH VOLATILITY</option>
              <option value="LIQUIDITY_SHOCK" className="bg-[#0b0e14] text-rose-400">LIQUIDITY SHOCK</option>
              <option value="REDEMPTION_EVENT" className="bg-[#0b0e14] text-amber-400">REDEMPTION EVENT ($470M)</option>
              <option value="DEPEG" className="bg-[#0b0e14] text-rose-500">DEPEG EVENT (-50 BPS)</option>
              <option value="VENUE_FAILURE" className="bg-[#0b0e14] text-amber-400">VENUE A FAILURE</option>
              <option value="COUNTERPARTY_FAILURE" className="bg-[#0b0e14] text-amber-400">COUNTERPARTY B DEGRADED</option>
              <option value="MARKET_DATA_FAILURE" className="bg-[#0b0e14] text-rose-400">MARKET DATA STALE</option>
              <option value="COMBINED_CRISIS" className="bg-[#0b0e14] text-rose-600">COMBINED CRISIS (CRITICAL)</option>
            </select>
          </div>

          {/* User Role Selector */}
          <div className="flex items-center space-x-1.5 bg-[#111827] border border-[#1f2937] px-2 py-1 rounded">
            <UserCheck className="w-3.5 h-3.5 text-blue-400" />
            <span className="text-slate-400 text-[11px]">ROLE:</span>
            <select
              value={userRole}
              onChange={(e) => setUserRole(e.target.value)}
              className="bg-transparent text-blue-300 font-mono font-bold text-xs focus:outline-none cursor-pointer"
            >
              {ROLES.map((role) => (
                <option key={role} value={role} className="bg-[#0b0e14] text-slate-200">
                  {role.replace("_", " ")}
                </option>
              ))}
            </select>
          </div>

          {/* System Health Status Badge */}
          <div className="flex items-center space-x-1 bg-emerald-950/40 text-emerald-400 border border-emerald-800/40 px-2 py-1 rounded font-mono text-[11px]">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span>CORE: {systemHealth}</span>
          </div>
        </div>
      </div>

      {/* Primary Workspace Navigation Tabs */}
      <nav className="flex items-center space-x-1 px-3 pt-1 bg-[#090c10] overflow-x-auto text-xs border-b border-[#161f2e]">
        {TABS.map((tab) => {
          const isActive = currentTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setCurrentTab(tab.id)}
              className={`px-3 py-1.5 font-medium border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
                isActive
                  ? "border-[#0055ff] text-white bg-[#111827]/80 rounded-t"
                  : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-[#111827]/40"
              }`}
            >
              {tab.label}
            </button>
          );
        })}
      </nav>
    </header>
  );
}
