"use client";

import React, { useState } from "react";
import { Bot, Send, ShieldAlert, Sparkles, RefreshCw } from "lucide-react";

interface RhinoIntelligenceProps {
  platformState: any;
}

export function RhinoIntelligence({ platformState }: RhinoIntelligenceProps) {
  const [messages, setMessages] = useState<Array<{ sender: "USER" | "AI"; text: string; disclaimer?: string; time: string }>>([
    {
      sender: "AI",
      text: "Greetings. I am RHINO INTELLIGENCE, your authorized read-only Quantitative & Risk Co-pilot powered by Gemini 3.7 Flash. How may I assist your analysis of current portfolio risk, peg stability, or stress scenario outputs today?",
      time: new Date().toLocaleTimeString(),
    },
  ]);
  const [prompt, setPrompt] = useState("");
  const [loading, setLoading] = useState(false);

  const presets = [
    "What is our current USDSTBL exposure?",
    "Why has liquidity deteriorated?",
    "Run a 20% redemption stress test analysis",
    "What are our largest counterparty exposures?",
  ];

  const handleSend = async (queryText?: string) => {
    const textToSend = queryText || prompt;
    if (!textToSend.trim()) return;

    const userMsg = {
      sender: "USER" as const,
      text: textToSend,
      time: new Date().toLocaleTimeString(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setPrompt("");
    setLoading(true);

    try {
      const res = await fetch("/api/gemini/assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: textToSend,
          contextState: platformState,
        }),
      });

      const data = await res.json();
      setLoading(false);

      if (data.error) {
        setMessages((prev) => [
          ...prev,
          {
            sender: "AI",
            text: `System Warning: ${data.error}`,
            time: new Date().toLocaleTimeString(),
          },
        ]);
      } else {
        setMessages((prev) => [
          ...prev,
          {
            sender: "AI",
            text: data.text,
            disclaimer: data.disclaimer,
            time: new Date().toLocaleTimeString(),
          },
        ]);
      }
    } catch (err: any) {
      setLoading(false);
      setMessages((prev) => [
        ...prev,
        {
          sender: "AI",
          text: `Error contacting Rhino Intelligence: ${err.message}`,
          time: new Date().toLocaleTimeString(),
        },
      ]);
    }
  };

  return (
    <div className="flex-1 p-4 bg-[#07090e] text-slate-200 font-mono flex flex-col justify-between overflow-hidden">
      <div className="max-w-5xl mx-auto w-full flex-1 flex flex-col overflow-hidden space-y-3">
        {/* Title */}
        <div className="bg-[#0b0e14] border border-[#1e293b] p-4 rounded flex items-center justify-between flex-shrink-0">
          <div>
            <h1 className="text-lg font-extrabold text-white flex items-center space-x-2">
              <Sparkles className="w-5 h-5 text-blue-400" />
              <span>RHINO INTELLIGENCE (GEMINI 3.7 FLASH CO-PILOT)</span>
            </h1>
            <p className="text-xs text-slate-400">
              Read-only AI quantitative co-pilot for risk interpretation, scenario analysis, and liquidity reporting.
            </p>
          </div>
          <div className="text-right text-[10px] bg-blue-950/40 text-blue-300 border border-blue-800/40 px-2.5 py-1 rounded font-mono">
            READ-ONLY ADVISORY ENGINE
          </div>
        </div>

        {/* Preset Prompt Shortcuts */}
        <div className="flex items-center space-x-2 overflow-x-auto flex-shrink-0">
          {presets.map((preset, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(preset)}
              className="px-2.5 py-1 bg-[#111827] hover:bg-[#1f2937] border border-[#1f2937] text-slate-300 text-[11px] rounded font-mono whitespace-nowrap cursor-pointer transition-colors"
            >
              {preset}
            </button>
          ))}
        </div>

        {/* Message Thread */}
        <div className="flex-1 bg-[#0b0e14] border border-[#1e293b] p-4 rounded overflow-y-auto space-y-4">
          {messages.map((msg, idx) => (
            <div
              key={idx}
              className={`flex flex-col ${msg.sender === "USER" ? "items-end" : "items-start"}`}
            >
              <div
                className={`max-w-3xl p-3.5 rounded text-xs leading-relaxed ${
                  msg.sender === "USER"
                    ? "bg-[#0055ff] text-white rounded-br-none"
                    : "bg-[#090d14] border border-[#1e293b] text-slate-200 rounded-bl-none"
                }`}
              >
                <div className="font-bold text-[10px] text-slate-400 mb-1 flex items-center justify-between">
                  <span>{msg.sender === "USER" ? "TRADER QUERY" : "RHINO INTELLIGENCE"}</span>
                  <span className="ml-2">{msg.time}</span>
                </div>

                <div className="whitespace-pre-wrap">{msg.text}</div>

                {msg.disclaimer && (
                  <div className="mt-2 text-[10px] text-amber-400/90 border-t border-[#1e293b] pt-1.5 font-bold">
                    ⚠️ {msg.disclaimer}
                  </div>
                )}
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex items-center space-x-2 text-xs text-blue-400 font-mono animate-pulse p-2">
              <RefreshCw className="w-4 h-4 animate-spin" />
              <span>RHINO INTELLIGENCE IS PROCESSING QUANTITATIVE CONTEXT...</span>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="flex items-center space-x-2 flex-shrink-0 pt-2"
        >
          <input
            type="text"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Ask Rhino Intelligence about portfolio risk, VaR 99%, peg stability, or liquidity stress..."
            className="flex-1 bg-[#0b0e14] border border-[#1e293b] rounded px-4 py-2 text-xs font-mono text-white focus:border-blue-500 focus:outline-none"
          />
          <button
            type="submit"
            disabled={loading}
            className="px-4 py-2 bg-[#0055ff] hover:bg-blue-600 text-white font-bold text-xs rounded flex items-center space-x-1 cursor-pointer disabled:opacity-50"
          >
            <Send className="w-3.5 h-3.5" />
            <span>SUBMIT</span>
          </button>
        </form>
      </div>
    </div>
  );
}
