"use client";

import React, { useState, useEffect } from "react";
import { Send, Clock, CheckCircle2, ShieldAlert } from "lucide-react";

export function RfqDesk() {
  const [side, setSide] = useState<"BUY" | "SELL">("BUY");
  const [asset, setAsset] = useState("USDSTBL");
  const [amountUsd, setAmountUsd] = useState("25000000");
  const [rfqActive, setRfqActive] = useState(false);
  const [timer, setTimer] = useState(30);
  const [selectedQuoteId, setSelectedQuoteId] = useState<string | null>(null);
  const [executionResult, setExecutionResult] = useState<any>(null);

  const quotes = [
    { id: "Q-LPA-01", lp: "Liquidity Provider A (Tier 1)", price: 1.00012, venue: "ECN Direct", spreadBps: 1.2 },
    { id: "Q-LPB-02", lp: "Liquidity Provider B (Prime Broker)", price: 1.00009, venue: "Over-the-Counter", spreadBps: 0.9 },
    { id: "Q-LPC-03", lp: "Liquidity Provider C (Global Bank)", price: 1.00015, venue: "Direct Desk", spreadBps: 1.5 },
    { id: "Q-RHINO-04", lp: "Rhino Bank Internal Treasury Desk", price: 1.00011, venue: "Internal Reserve", spreadBps: 1.1 },
  ];

  useEffect(() => {
    let interval: any;
    if (rfqActive && timer > 0) {
      interval = setInterval(() => {
        setTimer((t) => {
          if (t <= 1) {
            setRfqActive(false);
            return 0;
          }
          return t - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [rfqActive, timer]);

  const handleSendRfq = (e: React.FormEvent) => {
    e.preventDefault();
    setRfqActive(true);
    setTimer(30);
    setSelectedQuoteId("Q-LPB-02"); // Auto-select best execution
    setExecutionResult(null);
  };

  const handleExecuteRfq = (quote: any) => {
    const code = "CONF-882194";
    setExecutionResult({
      quoteId: quote.id,
      lp: quote.lp,
      executedPrice: quote.price,
      notional: parseFloat(amountUsd),
      settlementMode: "ATOMIC_DVP",
      timestamp: "2026-09-02T11:45:00.000Z",
      confirmationCode: code,
    });
    setRfqActive(false);
  };

  return (
    <div className="flex-1 p-4 bg-[#07090e] text-slate-200 font-mono overflow-y-auto">
      <div className="max-w-6xl mx-auto space-y-4">
        {/* Header Title */}
        <div className="bg-[#0b0e14] border border-[#1e293b] p-4 rounded flex items-center justify-between">
          <div>
            <h1 className="text-lg font-extrabold text-white tracking-wide">
              INSTITUTIONAL OTC / RFQ DESK
            </h1>
            <p className="text-xs text-slate-400">
              Request-for-Quote workflow connecting institutional clients with Tier-1 liquidity providers and Rhino Treasury.
            </p>
          </div>
          <div className="text-right text-xs">
            <span className="text-slate-400">COUNTERPARTY CREDIT:</span>
            <span className="text-emerald-400 font-bold ml-1.5">$250,000,000 APPROVED</span>
          </div>
        </div>

        <div className="grid grid-cols-12 gap-4">
          {/* RFQ Submission Panel (Cols 1-5) */}
          <div className="col-span-5 bg-[#0b0e14] border border-[#1e293b] p-4 rounded flex flex-col justify-between">
            <div>
              <h2 className="text-sm font-bold text-slate-200 border-b border-[#1e293b] pb-2 mb-3">
                1. CLIENT RFQ PARAMETERS
              </h2>

              <form onSubmit={handleSendRfq} className="space-y-3">
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setSide("BUY")}
                    className={`py-2 rounded font-bold text-xs cursor-pointer ${
                      side === "BUY" ? "bg-emerald-600 text-white" : "bg-[#111827] text-slate-400"
                    }`}
                  >
                    BUY STABLECOIN
                  </button>
                  <button
                    type="button"
                    onClick={() => setSide("SELL")}
                    className={`py-2 rounded font-bold text-xs cursor-pointer ${
                      side === "SELL" ? "bg-rose-600 text-white" : "bg-[#111827] text-slate-400"
                    }`}
                  >
                    SELL STABLECOIN
                  </button>
                </div>

                <div>
                  <label className="text-xs text-slate-400 block mb-1">Select Asset:</label>
                  <select
                    value={asset}
                    onChange={(e) => setAsset(e.target.value)}
                    className="w-full bg-[#111827] border border-[#1f2937] rounded px-3 py-1.5 text-white text-xs font-mono"
                  >
                    <option value="USDSTBL">USDSTBL - Rhino USD Stablecoin</option>
                    <option value="GBPSTBL">GBPSTBL - Rhino GBP Stablecoin</option>
                    <option value="EURSTBL">EURSTBL - Rhino EUR Stablecoin</option>
                    <option value="JPYSTBL">JPYSTBL - Rhino JPY Stablecoin</option>
                    <option value="CHFSTBL">CHFSTBL - Rhino CHF Stablecoin</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs text-slate-400 block mb-1">Notional Quantity (USD Equivalent):</label>
                  <input
                    type="number"
                    value={amountUsd}
                    onChange={(e) => setAmountUsd(e.target.value)}
                    className="w-full bg-[#111827] border border-[#1f2937] rounded px-3 py-1.5 text-white text-xs font-mono"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 bg-[#0055ff] hover:bg-blue-600 text-white rounded font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer flex items-center justify-center space-x-2"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>DISPATCH RFQ TO LIQUIDITY PROVIDERS</span>
                </button>
              </form>
            </div>

            <div className="mt-4 p-2.5 bg-[#090d14] border border-[#1e293b] rounded text-[11px] text-slate-400">
              <span className="text-emerald-400 font-bold">BEST EXECUTION GUARANTEE:</span> Quotes are aggregated across 4 independent market-maker streams with smart slippage protection.
            </div>
          </div>

          {/* Live Multi-LP Quotes Panel (Cols 6-12) */}
          <div className="col-span-7 bg-[#0b0e14] border border-[#1e293b] p-4 rounded flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between border-b border-[#1e293b] pb-2 mb-3">
                <h2 className="text-sm font-bold text-slate-200">
                  2. LIVE MULTI-LP STREAMING QUOTES
                </h2>

                {rfqActive && (
                  <div className="flex items-center space-x-1.5 bg-amber-950/60 text-amber-300 border border-amber-800 px-2.5 py-1 rounded text-xs font-bold animate-pulse">
                    <Clock className="w-3.5 h-3.5" />
                    <span>QUOTE EXPIRY: {timer}s</span>
                  </div>
                )}
              </div>

              {!rfqActive && !executionResult && (
                <div className="h-48 flex items-center justify-center text-slate-500 text-xs border border-dashed border-[#1e293b] rounded">
                  Dispatch RFQ parameters to generate real-time institutional quote ladder.
                </div>
              )}

              {rfqActive && (
                <div className="space-y-2">
                  {quotes.map((q) => {
                    const isBest = q.id === "Q-LPB-02";
                    const isSelected = selectedQuoteId === q.id;
                    return (
                      <div
                        key={q.id}
                        onClick={() => setSelectedQuoteId(q.id)}
                        className={`p-3 rounded border flex items-center justify-between cursor-pointer transition-colors ${
                          isSelected
                            ? "bg-[#0f1d33] border-[#0055ff]"
                            : "bg-[#0c1017] border-[#1e293b] hover:bg-[#111827]"
                        }`}
                      >
                        <div>
                          <div className="font-bold text-white text-xs flex items-center space-x-2">
                            <span>{q.lp}</span>
                            {isBest && (
                              <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[9px] px-1.5 py-0.5 rounded">
                                BEST EXECUTION
                              </span>
                            )}
                          </div>
                          <div className="text-[10px] text-slate-400 mt-0.5">
                            Venue: {q.venue} | Spread: {q.spreadBps} bps
                          </div>
                        </div>

                        <div className="text-right">
                          <div className="font-bold text-emerald-400 text-sm">{q.price.toFixed(5)}</div>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleExecuteRfq(q);
                            }}
                            className="mt-1 px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-bold rounded"
                          >
                            ACCEPT & EXECUTE
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              {executionResult && (
                <div className="bg-emerald-950/40 border border-emerald-800 p-4 rounded space-y-2">
                  <div className="flex items-center space-x-2 text-emerald-400 font-bold text-sm">
                    <CheckCircle2 className="w-5 h-5" />
                    <span>RFQ TRADE CONFIRMED & ATOMICALLY SETTLED</span>
                  </div>
                  <div className="text-xs text-slate-300 space-y-1 font-mono pt-2 border-t border-emerald-800/40">
                    <div>Confirmation Code: <span className="text-white font-bold">{executionResult.confirmationCode}</span></div>
                    <div>Counterparty: <span className="text-white font-bold">{executionResult.lp}</span></div>
                    <div>Executed Price: <span className="text-white font-bold">{executionResult.executedPrice.toFixed(5)}</span></div>
                    <div>Notional Amount: <span className="text-white font-bold">${executionResult.notional.toLocaleString()}</span></div>
                    <div>Settlement Mechanism: <span className="text-emerald-400 font-bold">Atomic Delivery vs Payment (DVP)</span></div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
