"use client";

import React, { useState } from "react";
import { Code2, Terminal, Play, LineChart, FileCode } from "lucide-react";

export function QuantLab() {
  const [selectedScript, setSelectedScript] = useState("monte_carlo.R");

  const scripts: Record<string, string> = {
    "pricing.R": `# Rhino Bank Digital Markets - Peg Stability & Smart Pricing Engine
library(stats)

calculate_smart_price <- function(venue_prices, venue_weights) {
  weighted_mid <- sum(venue_prices * venue_weights) / sum(venue_weights)
  return(weighted_mid)
}

# Run pricing test
venues <- c(0.99982, 0.99978, 0.99985)
weights <- c(0.40, 0.35, 0.25)
smart_mid <- calculate_smart_price(venues, weights)
cat("Calculated Rhino Smart Price:", sprintf("%.6f", smart_mid), "\\n")`,

    "monte_carlo.R": `# Rhino Bank Quantitative Research - Monte Carlo Peg Breach Simulator
set.seed(2026)
n_simulations <- 10000
time_horizon_days <- 30
initial_peg <- 1.0000
daily_volatility <- 0.00015
drift <- -0.00001

simulated_paths <- matrix(0, nrow = n_simulations, ncol = time_horizon_days)

for (i in 1:n_simulations) {
  shocks <- rnorm(time_horizon_days, mean = drift, sd = daily_volatility)
  simulated_paths[i, ] <- cumprod(c(initial_peg, 1 + shocks))[-1]
}

final_prices <- simulated_paths[, time_horizon_days]
var_99 <- quantile(final_prices, 0.01)
peg_breaches <- sum(final_prices < 0.9950) / n_simulations

cat("Monte Carlo Simulation Completed: 10,000 runs\\n")
cat("VaR (99%):", sprintf("%.6f", var_99), "\\n")
cat("Probability of Peg Breach (-50 bps):", sprintf("%.2f%%", peg_breaches * 100), "\\n")`,

    "stress.R": `# Rhino Bank Liquidity Stress Testing Engine
run_redemption_stress <- function(available_cash, gov_bonds, total_inventory, shock_pct) {
  outflow <- total_inventory * shock_pct
  cash_after <- available_cash - outflow
  total_liquid_after <- (available_cash + gov_bonds) - outflow
  return(list(outflow = outflow, cash_after = cash_after, total_liquid_after = total_liquid_after))
}

res <- run_redemption_stress(850000000, 680000000, 920000000, 0.30)
cat("30% Stress Scenario Result:\\n")
cat("Outflow:", res$outflow / 1e6, "M USD\\n")
cat("Remaining Liquid Assets:", res$total_liquid_after / 1e6, "M USD\\n")`,
  };

  return (
    <div className="flex-1 p-4 bg-[#07090e] text-slate-200 font-mono overflow-y-auto">
      <div className="max-w-7xl mx-auto space-y-4">
        {/* Title */}
        <div className="flex items-center justify-between bg-[#0b0e14] border border-[#1e293b] p-4 rounded">
          <div>
            <h1 className="text-lg font-extrabold text-white flex items-center space-x-2">
              <Code2 className="w-5 h-5 text-purple-400" />
              <span>RHINO QUANTITATIVE RESEARCH LAB (R ENGINE)</span>
            </h1>
            <p className="text-xs text-slate-400">
              Quantitative modeling environment for peg stability analytics, Monte Carlo risk simulations, and stress testing.
            </p>
          </div>
          <div className="flex items-center space-x-2 bg-purple-950/40 text-purple-300 border border-purple-800/60 px-3 py-1.5 rounded text-xs font-bold">
            <Terminal className="w-4 h-4" />
            <span>R ENVIRONMENT: ACTIVE (10,000 RUNS)</span>
          </div>
        </div>

        {/* Workspace Layout */}
        <div className="grid grid-cols-12 gap-4">
          {/* Script Explorer & Code View (Cols 1-7) */}
          <div className="col-span-7 bg-[#0b0e14] border border-[#1e293b] p-4 rounded flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between border-b border-[#1e293b] pb-2 mb-3">
                <div className="flex items-center space-x-2">
                  <FileCode className="w-4 h-4 text-[#60a5fa]" />
                  <span className="font-bold text-slate-200 text-xs">R MODULE BROWSER</span>
                </div>
                <div className="flex items-center space-x-1">
                  {Object.keys(scripts).map((scriptName) => (
                    <button
                      key={scriptName}
                      onClick={() => setSelectedScript(scriptName)}
                      className={`px-2 py-0.5 text-[10px] font-mono rounded cursor-pointer ${
                        selectedScript === scriptName ? "bg-[#0055ff] text-white font-bold" : "text-slate-400 hover:text-white"
                      }`}
                    >
                      {scriptName}
                    </button>
                  ))}
                </div>
              </div>

              <pre className="p-3 bg-[#080b10] border border-[#161f2e] rounded text-xs font-mono text-emerald-400 overflow-x-auto h-72">
                <code>{scripts[selectedScript]}</code>
              </pre>
            </div>

            <div className="mt-4 flex items-center justify-between">
              <button className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs rounded uppercase flex items-center space-x-2 cursor-pointer">
                <Play className="w-3.5 h-3.5" />
                <span>EXECUTE R MODULE</span>
              </button>
              <span className="text-[10px] text-slate-500 font-mono">
                R-Script Compiler Version 4.3.2
              </span>
            </div>
          </div>

          {/* Execution Output Console (Cols 8-12) */}
          <div className="col-span-5 bg-[#0b0e14] border border-[#1e293b] p-4 rounded flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between border-b border-[#1e293b] pb-2 mb-3">
                <span className="font-bold text-slate-200 text-xs">R STDOUT OUTPUT CONSOLE</span>
                <span className="text-[10px] text-emerald-400 font-mono">STATUS: SUCCESS</span>
              </div>

              <div className="p-3 bg-[#080b10] border border-[#161f2e] rounded text-xs font-mono text-slate-200 space-y-2 h-72 overflow-y-auto">
                <div className="text-slate-500">&gt; Rscript /quant/R/{selectedScript}</div>
                <div className="text-emerald-400">[1] &quot;R engine initialized successfully.&quot;</div>
                <div className="text-white font-bold">Executing 10,000 Monte Carlo paths...</div>
                <div className="text-slate-300">
                  ----------------------------------------<br />
                  VaR (99% Confidence): 0.995750 USD<br />
                  Expected Shortfall (CVaR): 0.993200 USD<br />
                  P(Peg Breach -50 bps): 0.20%<br />
                  P(Liquidity Deficit): 0.10%<br />
                  ----------------------------------------
                </div>
                <div className="text-emerald-400">[COMPLETE] All metrics written to Risk Subsystem.</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
