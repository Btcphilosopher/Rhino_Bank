"use client";

import React from "react";
import { ShieldAlert, Activity, AlertOctagon, Lock, Cpu, BarChart3 } from "lucide-react";

interface RiskCockpitProps {
  riskData: any;
  activeScenario: string;
}

export function RiskCockpit({ riskData, activeScenario }: RiskCockpitProps) {
  const summary = riskData?.summary || {
    overallState: "GREEN",
    marketRiskScore: 18,
    liquidityRiskScore: 12,
    counterpartyRiskScore: 14,
    depegRiskScore: 8,
  };

  const quantMetrics = riskData?.quantMetrics || {
    var99Usd: 4250000,
    expectedShortfallUsd: 6800000,
    pPegBreachPct: 0.2,
    pLiquidityShortfallPct: 0.1,
  };

  const limits = riskData?.limits || [];
  const depegEscalation = riskData?.depegEscalation || [];

  const getBadgeStyle = (state: string) => {
    switch (state) {
      case "GREEN":
        return "bg-emerald-950/80 text-emerald-400 border-emerald-800/60";
      case "AMBER":
        return "bg-amber-950/80 text-amber-400 border-amber-800/60";
      case "RED":
        return "bg-rose-950/80 text-rose-400 border-rose-800/60 animate-pulse";
      case "CRITICAL":
        return "bg-rose-600 text-white font-extrabold animate-pulse";
      default:
        return "bg-slate-800 text-slate-300 border-slate-700";
    }
  };

  return (
    <div className="flex-1 p-4 bg-[#07090e] text-slate-200 font-mono overflow-y-auto">
      <div className="max-w-7xl mx-auto space-y-4">
        {/* Header Title */}
        <div className="flex items-center justify-between bg-[#0b0e14] border border-[#1e293b] p-4 rounded">
          <div>
            <h1 className="text-lg font-extrabold text-white flex items-center space-x-2">
              <ShieldAlert className="w-5 h-5 text-blue-400" />
              <span>RHINO RISK & QUANTITATIVE COCKPIT</span>
            </h1>
            <p className="text-xs text-slate-400">
              Real-time market risk, counterparty exposure limits, Monte Carlo simulations, and Depeg Response Protocol.
            </p>
          </div>
          <div className={`px-4 py-1.5 rounded border text-xs font-bold uppercase tracking-wider ${getBadgeStyle(summary.overallState)}`}>
            SYSTEM RISK STATE: {summary.overallState}
          </div>
        </div>

        {/* Traffic Light Risk Categories Grid */}
        <div className="grid grid-cols-4 gap-3">
          <div className="bg-[#0b0e14] border border-[#1e293b] p-3 rounded flex items-center justify-between">
            <div>
              <div className="text-[10px] text-slate-500 uppercase">MARKET RISK</div>
              <div className="text-lg font-extrabold text-white mt-0.5">{summary.marketRiskScore} / 100</div>
            </div>
            <div className={`w-3 h-3 rounded-full ${summary.marketRiskScore > 50 ? "bg-rose-500" : "bg-emerald-400"}`} />
          </div>

          <div className="bg-[#0b0e14] border border-[#1e293b] p-3 rounded flex items-center justify-between">
            <div>
              <div className="text-[10px] text-slate-500 uppercase">LIQUIDITY RISK</div>
              <div className="text-lg font-extrabold text-white mt-0.5">{summary.liquidityRiskScore} / 100</div>
            </div>
            <div className={`w-3 h-3 rounded-full ${summary.liquidityRiskScore > 50 ? "bg-rose-500" : "bg-emerald-400"}`} />
          </div>

          <div className="bg-[#0b0e14] border border-[#1e293b] p-3 rounded flex items-center justify-between">
            <div>
              <div className="text-[10px] text-slate-500 uppercase">COUNTERPARTY RISK</div>
              <div className="text-lg font-extrabold text-white mt-0.5">{summary.counterpartyRiskScore} / 100</div>
            </div>
            <div className={`w-3 h-3 rounded-full ${summary.counterpartyRiskScore > 50 ? "bg-amber-400" : "bg-emerald-400"}`} />
          </div>

          <div className="bg-[#0b0e14] border border-[#1e293b] p-3 rounded flex items-center justify-between">
            <div>
              <div className="text-[10px] text-slate-500 uppercase">STABLECOIN PEG RISK</div>
              <div className="text-lg font-extrabold text-white mt-0.5">{summary.depegRiskScore} / 100</div>
            </div>
            <div className={`w-3 h-3 rounded-full ${summary.depegRiskScore > 50 ? "bg-rose-600 animate-pulse" : "bg-emerald-400"}`} />
          </div>
        </div>

        {/* Main Section Grid */}
        <div className="grid grid-cols-12 gap-4">
          {/* Depeg Response Protocol Escalation Matrix (Cols 1-7) */}
          <div className="col-span-7 bg-[#0b0e14] border border-[#1e293b] p-4 rounded flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between border-b border-[#1e293b] pb-2 mb-3">
                <h2 className="text-sm font-bold text-slate-200 flex items-center space-x-2">
                  <AlertOctagon className="w-4 h-4 text-rose-400" />
                  <span>DEPEG RESPONSE MODE & ESCALATION POLICY</span>
                </h2>
                <span className="text-[10px] text-slate-400">DETERMINISTIC GOVERNANCE</span>
              </div>

              <div className="space-y-2 text-xs">
                {depegEscalation.map((tier: any) => {
                  const isActive = tier.status.includes("ACTIVE");
                  return (
                    <div
                      key={tier.threshold}
                      className={`p-3 rounded border transition-colors ${
                        isActive
                          ? "bg-rose-950/40 border-rose-600/80 text-white"
                          : "bg-[#090d14] border-[#1e293b] text-slate-400"
                      }`}
                    >
                      <div className="flex items-center justify-between font-bold">
                        <span className={isActive ? "text-rose-400" : "text-slate-300"}>
                          {tier.threshold} (PEG = {tier.targetPeg.toFixed(5)})
                        </span>
                        <span
                          className={`text-[10px] px-2 py-0.5 rounded font-mono ${
                            isActive ? "bg-rose-600 text-white animate-pulse" : "bg-[#111827] text-slate-500"
                          }`}
                        >
                          {tier.status}
                        </span>
                      </div>
                      <div className="text-[11px] mt-1 text-slate-300 font-mono">
                        {tier.action}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="mt-4 p-2.5 bg-[#090d14] border border-[#1e293b] rounded text-[11px] text-slate-400">
              <span className="text-blue-400 font-bold">AUTOMATED DEFENSE RULE:</span> Secondary trading is restricted automatically when peg deviation exceeds -50.0 bps to preserve bank liquidity.
            </div>
          </div>

          {/* Monte Carlo & Hierarchical Risk Limits (Cols 8-12) */}
          <div className="col-span-5 bg-[#0b0e14] border border-[#1e293b] p-4 rounded flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between border-b border-[#1e293b] pb-2 mb-3">
                <h2 className="text-sm font-bold text-slate-200">
                  MONTE CARLO RISK OUTPUTS (10,000 SIMS)
                </h2>
                <span className="text-[10px] text-emerald-400 font-mono">R ENGINE VERIFIED</span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs mb-4">
                <div className="bg-[#090d14] border border-[#1e293b] p-2.5 rounded">
                  <div className="text-[10px] text-slate-500">Value at Risk (VaR 99%):</div>
                  <div className="text-sm font-extrabold text-rose-400 mt-1">
                    ${(quantMetrics.var99Usd / 1000000).toFixed(2)}M USD
                  </div>
                </div>

                <div className="bg-[#090d14] border border-[#1e293b] p-2.5 rounded">
                  <div className="text-[10px] text-slate-500">Expected Shortfall (CVaR):</div>
                  <div className="text-sm font-extrabold text-rose-500 mt-1">
                    ${(quantMetrics.expectedShortfallUsd / 1000000).toFixed(2)}M USD
                  </div>
                </div>

                <div className="bg-[#090d14] border border-[#1e293b] p-2.5 rounded">
                  <div className="text-[10px] text-slate-500">P(PEG BREACH 30D):</div>
                  <div className="text-sm font-extrabold text-amber-400 mt-1">
                    {quantMetrics.pPegBreachPct}%
                  </div>
                </div>

                <div className="bg-[#090d14] border border-[#1e293b] p-2.5 rounded">
                  <div className="text-[10px] text-slate-500">P(LIQUIDITY DEFICIT):</div>
                  <div className="text-sm font-extrabold text-slate-200 mt-1">
                    {quantMetrics.pLiquidityShortfallPct}%
                  </div>
                </div>
              </div>

              {/* Hierarchical Limits Table */}
              <div className="border-t border-[#1e293b] pt-3">
                <div className="text-xs text-slate-400 font-bold mb-2">HIERARCHICAL RISK LIMITS MATRIX</div>
                <div className="space-y-1.5 text-[11px]">
                  {limits.map((lim: any) => (
                    <div key={lim.level} className="flex items-center justify-between bg-[#090d14] p-2 rounded">
                      <span className="text-slate-300 font-bold">{lim.level}</span>
                      <div className="text-right">
                        <span className="text-slate-400 font-mono">${(lim.usedUsd / 1000000).toFixed(0)}M / ${(lim.limitUsd / 1000000).toFixed(0)}M</span>
                        <span className={`ml-2 font-bold ${lim.pctUsed > 80 ? "text-amber-400" : "text-emerald-400"}`}>
                          ({lim.pctUsed}%)
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
