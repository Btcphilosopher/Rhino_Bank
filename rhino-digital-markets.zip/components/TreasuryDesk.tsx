"use client";

import React, { useState } from "react";
import { Landmark, Shield, AlertTriangle, Layers, Play } from "lucide-react";

interface TreasuryDeskProps {
  treasuryData: any;
  userRole: string;
}

export function TreasuryDesk({ treasuryData, userRole }: TreasuryDeskProps) {
  const metrics = treasuryData?.metrics || {
    totalLiquidityUsd: 2450000000,
    availableCashUsd: 850000000,
    stablecoinInventoryUsd: 920000000,
    governmentSecuritiesUsd: 680000000,
    collateralBufferUsd: 450000000,
    liquidityRunway30dDays: 94,
    liquidityRunway90dDays: 280,
    redemptionCoverageRatioPct: 166.3,
  };

  const reserves = treasuryData?.reserves || [];
  const redemptionScenarios = treasuryData?.redemptionScenarios || [];

  const [selectedShockPct, setSelectedShockPct] = useState("30%");
  const [mintAmount, setMintAmount] = useState("10000000");
  const [mintAsset, setMintAsset] = useState("USDSTBL");
  const [actionMessage, setActionMessage] = useState<string | null>(null);

  const activeShock = redemptionScenarios.find((s: any) => s.percentage === selectedShockPct) || redemptionScenarios[3] || {};

  const canMintBurn = ["TREASURY_MANAGER", "EXECUTIVE", "ADMINISTRATOR"].includes(userRole);

  const handleMintAction = (action: "MINT" | "BURN") => {
    if (!canMintBurn) {
      setActionMessage(`AUTHORIZATION DENIED: Role ${userRole} lacks Treasury Mint/Burn authority.`);
      return;
    }
    setActionMessage(`AUTHORIZATION GRANTED: ${action} request for $${parseInt(mintAmount).toLocaleString()} ${mintAsset} dispatched to Rhino Authorized Issuance Service.`);
  };

  return (
    <div className="flex-1 p-4 bg-[#07090e] text-slate-200 font-mono overflow-y-auto">
      <div className="max-w-7xl mx-auto space-y-4">
        {/* Title & Key KPI Summary Cards */}
        <div className="flex items-center justify-between bg-[#0b0e14] border border-[#1e293b] p-4 rounded">
          <div>
            <h1 className="text-lg font-extrabold text-white">RHINO BANK TREASURY DESK</h1>
            <p className="text-xs text-slate-400">
              Institutional reserve management, liquidity buffers, 30/90-day cash runway, and stablecoin mint/burn gateway.
            </p>
          </div>
          <div className="flex items-center space-x-2 bg-emerald-950/40 text-emerald-400 border border-emerald-800/60 px-3 py-1.5 rounded text-xs font-bold">
            <Landmark className="w-4 h-4" />
            <span>COVERAGE RATIO: {metrics.redemptionCoverageRatioPct}%</span>
          </div>
        </div>

        {/* Top Metric Cards Grid */}
        <div className="grid grid-cols-6 gap-3">
          <div className="bg-[#0b0e14] border border-[#1e293b] p-3 rounded">
            <div className="text-[10px] text-slate-500 uppercase">TOTAL LIQUIDITY</div>
            <div className="text-base font-extrabold text-white mt-1">
              ${(metrics.totalLiquidityUsd / 1000000000).toFixed(2)}B
            </div>
          </div>

          <div className="bg-[#0b0e14] border border-[#1e293b] p-3 rounded">
            <div className="text-[10px] text-slate-500 uppercase">AVAILABLE CASH</div>
            <div className="text-base font-extrabold text-emerald-400 mt-1">
              ${(metrics.availableCashUsd / 1000000).toFixed(0)}M
            </div>
          </div>

          <div className="bg-[#0b0e14] border border-[#1e293b] p-3 rounded">
            <div className="text-[10px] text-slate-500 uppercase">STABLECOIN INVENTORY</div>
            <div className="text-base font-extrabold text-blue-400 mt-1">
              ${(metrics.stablecoinInventoryUsd / 1000000).toFixed(0)}M
            </div>
          </div>

          <div className="bg-[#0b0e14] border border-[#1e293b] p-3 rounded">
            <div className="text-[10px] text-slate-500 uppercase">GOV SECURITIES (T-BILLS)</div>
            <div className="text-base font-extrabold text-slate-200 mt-1">
              ${(metrics.governmentSecuritiesUsd / 1000000).toFixed(0)}M
            </div>
          </div>

          <div className="bg-[#0b0e14] border border-[#1e293b] p-3 rounded">
            <div className="text-[10px] text-slate-500 uppercase">COLLATERAL BUFFER</div>
            <div className="text-base font-extrabold text-amber-400 mt-1">
              ${(metrics.collateralBufferUsd / 1000000).toFixed(0)}M
            </div>
          </div>

          <div className="bg-[#0b0e14] border border-[#1e293b] p-3 rounded">
            <div className="text-[10px] text-slate-500 uppercase">30D / 90D RUNWAY</div>
            <div className="text-base font-extrabold text-emerald-400 mt-1">
              {metrics.liquidityRunway30dDays}d / {metrics.liquidityRunway90dDays}d
            </div>
          </div>
        </div>

        {/* Middle Main Content Grid */}
        <div className="grid grid-cols-12 gap-4">
          {/* Liquidity Cockpit & Stress Simulator (Cols 1-7) */}
          <div className="col-span-7 bg-[#0b0e14] border border-[#1e293b] p-4 rounded flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between border-b border-[#1e293b] pb-2 mb-3">
                <h2 className="text-sm font-bold text-slate-200">
                  LIQUIDITY COCKPIT & REDEMPTION SHOCK SIMULATOR
                </h2>
                <span className="text-xs text-amber-400 font-bold">STRESS TESTING ENGINE</span>
              </div>

              <p className="text-xs text-slate-400 mb-3">
                Select a simulated redemption wave percentage to evaluate immediate reserve coverage and cash runway depletion:
              </p>

              {/* Scenario Selector Buttons */}
              <div className="flex items-center space-x-1.5 mb-4 overflow-x-auto">
                {redemptionScenarios.map((scen: any) => (
                  <button
                    key={scen.percentage}
                    onClick={() => setSelectedShockPct(scen.percentage)}
                    className={`px-2.5 py-1 text-xs rounded font-bold cursor-pointer transition-colors ${
                      selectedShockPct === scen.percentage
                        ? "bg-[#0055ff] text-white"
                        : "bg-[#111827] text-slate-400 hover:text-white"
                    }`}
                  >
                    {scen.percentage}
                  </button>
                ))}
              </div>

              {/* Shock Output Details */}
              <div className="bg-[#090d14] border border-[#1e293b] p-3.5 rounded space-y-2 text-xs">
                <div className="flex items-center justify-between border-b border-[#161f2e] pb-1.5">
                  <span className="text-slate-400">Simulated Redemption Wave:</span>
                  <span className="text-rose-400 font-bold">{selectedShockPct} of Total Inventory</span>
                </div>
                <div className="flex items-center justify-between border-b border-[#161f2e] pb-1.5">
                  <span className="text-slate-400">Redemption Demand (Outflow):</span>
                  <span className="text-white font-bold">${(activeShock.redemptionDemandUsd / 1000000)?.toFixed(1)}M USD</span>
                </div>
                <div className="flex items-center justify-between border-b border-[#161f2e] pb-1.5">
                  <span className="text-slate-400">Available Cash Remaining Post-Shock:</span>
                  <span className={activeShock.cashRemainingUsd > 0 ? "text-emerald-400 font-bold" : "text-amber-400 font-bold"}>
                    ${(activeShock.cashRemainingUsd / 1000000)?.toFixed(1)}M USD
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Total Liquid Buffer Post-Shock:</span>
                  <span className="text-emerald-400 font-bold">
                    ${(activeShock.totalLiquidRemainingUsd / 1000000)?.toFixed(1)}M USD ({activeShock.status})
                  </span>
                </div>
              </div>
            </div>

            <div className="mt-4 p-2.5 bg-emerald-950/30 border border-emerald-800/40 rounded text-[11px] text-emerald-300">
              ✓ RHINO TREASURY IS RATED <span className="font-bold text-white">100%+ FULLY BACKED</span> WITH LIQUID T-BILLS & DIRECT BANK RESERVES.
            </div>
          </div>

          {/* Mint / Burn Issuance Gateway & Reserve Breakdown (Cols 8-12) */}
          <div className="col-span-5 bg-[#0b0e14] border border-[#1e293b] p-4 rounded flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between border-b border-[#1e293b] pb-2 mb-3">
                <h2 className="text-sm font-bold text-slate-200">
                  ISSUANCE & REDEMPTION GATEWAY
                </h2>
                <span className="text-[10px] text-blue-400">AUTHORIZATION TIER 3</span>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="text-xs text-slate-400 block mb-1">Asset Universe:</label>
                  <select
                    value={mintAsset}
                    onChange={(e) => setMintAsset(e.target.value)}
                    className="w-full bg-[#111827] border border-[#1f2937] rounded px-3 py-1.5 text-white text-xs font-mono"
                  >
                    <option value="USDSTBL">USDSTBL - Rhino USD Stablecoin</option>
                    <option value="GBPSTBL">GBPSTBL - Rhino GBP Stablecoin</option>
                    <option value="EURSTBL">EURSTBL - Rhino EUR Stablecoin</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs text-slate-400 block mb-1">Requested Volume:</label>
                  <input
                    type="number"
                    value={mintAmount}
                    onChange={(e) => setMintAmount(e.target.value)}
                    className="w-full bg-[#111827] border border-[#1f2937] rounded px-3 py-1.5 text-white text-xs font-mono"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2 pt-1">
                  <button
                    onClick={() => handleMintAction("MINT")}
                    className="py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded uppercase cursor-pointer"
                  >
                    AUTHORIZE MINT
                  </button>
                  <button
                    onClick={() => handleMintAction("BURN")}
                    className="py-2 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs rounded uppercase cursor-pointer"
                  >
                    AUTHORIZE REDEEM
                  </button>
                </div>
              </div>

              {actionMessage && (
                <div className="mt-3 p-2.5 rounded text-[11px] bg-[#111827] border border-[#1f2937] text-slate-200">
                  {actionMessage}
                </div>
              )}
            </div>

            {/* Reserves Breakdown Table */}
            <div className="mt-4 border-t border-[#1e293b] pt-3">
              <div className="text-xs text-slate-400 font-bold mb-2">CURRENCY RESERVES BACKING</div>
              <table className="w-full text-left text-[11px]">
                <thead>
                  <tr className="text-slate-500 border-b border-[#161f2e]">
                    <th className="pb-1">CURRENCY</th>
                    <th className="pb-1 text-right">FIAT CASH</th>
                    <th className="pb-1 text-right">INVENTORY</th>
                    <th className="pb-1 text-right">BACKING</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#161f2e]">
                  {reserves.map((res: any) => (
                    <tr key={res.currency}>
                      <td className="py-1 font-bold text-white">{res.currency}</td>
                      <td className="py-1 text-right">${(res.fiatBalance / 1000000).toFixed(0)}M</td>
                      <td className="py-1 text-right text-slate-400">${(res.stablecoinBalance / 1000000).toFixed(0)}M</td>
                      <td className="py-1 text-right text-emerald-400 font-bold">{res.backingRatioPct}%</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
