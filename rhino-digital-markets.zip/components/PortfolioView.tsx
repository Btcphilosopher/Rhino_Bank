"use client";

import React from "react";
import { PieChart, TrendingUp, Layers, DollarSign } from "lucide-react";

interface PortfolioViewProps {
  positions: any[];
}

export function PortfolioView({ positions }: PortfolioViewProps) {
  const totalNav = 4850000000;
  const cashFiat = 850000000;
  const stablecoins = 920000000;
  const collateral = 450000000;
  const todayPnl = 276000;
  const mtdPnl = 4150000;
  const ytdPnl = 28400000;

  return (
    <div className="flex-1 p-4 bg-[#07090e] text-slate-200 font-mono overflow-y-auto">
      <div className="max-w-7xl mx-auto space-y-4">
        {/* Title */}
        <div className="flex items-center justify-between bg-[#0b0e14] border border-[#1e293b] p-4 rounded">
          <div>
            <h1 className="text-lg font-extrabold text-white">PORTFOLIO ACCOUNTS & P&L ENGINE</h1>
            <p className="text-xs text-slate-400">
              Multi-asset portfolio drill-down hierarchy: Portfolio → Currency → Instrument → Position → Transaction.
            </p>
          </div>
          <div className="text-right">
            <div className="text-[10px] text-slate-400">TOTAL INSTITUTIONAL NAV</div>
            <div className="text-lg font-extrabold text-emerald-400">${(totalNav / 1000000000).toFixed(3)}B USD</div>
          </div>
        </div>

        {/* Top P&L KPI Cards */}
        <div className="grid grid-cols-4 gap-3">
          <div className="bg-[#0b0e14] border border-[#1e293b] p-3 rounded">
            <div className="text-[10px] text-slate-500 uppercase">TODAY REALIZED & UNREALIZED P&L</div>
            <div className="text-base font-extrabold text-emerald-400 mt-1">+${todayPnl.toLocaleString()} USD</div>
          </div>

          <div className="bg-[#0b0e14] border border-[#1e293b] p-3 rounded">
            <div className="text-[10px] text-slate-500 uppercase">MTD ACCUMULATED P&L</div>
            <div className="text-base font-extrabold text-emerald-400 mt-1">+${(mtdPnl / 1000000).toFixed(2)}M USD</div>
          </div>

          <div className="bg-[#0b0e14] border border-[#1e293b] p-3 rounded">
            <div className="text-[10px] text-slate-500 uppercase">YTD TOTAL P&L</div>
            <div className="text-base font-extrabold text-emerald-400 mt-1">+${(ytdPnl / 1000000).toFixed(2)}M USD</div>
          </div>

          <div className="bg-[#0b0e14] border border-[#1e293b] p-3 rounded">
            <div className="text-[10px] text-slate-500 uppercase">TOTAL GROSS NOTIONAL EXPOSURE</div>
            <div className="text-base font-extrabold text-blue-400 mt-1">$1.42B USD</div>
          </div>
        </div>

        {/* Detailed Positions Table */}
        <div className="bg-[#0b0e14] border border-[#1e293b] p-4 rounded space-y-3">
          <h2 className="text-sm font-bold text-slate-200 border-b border-[#1e293b] pb-2">
            DETAILED POSITION BREAKDOWN & MTM VALUATION
          </h2>

          <table className="w-full text-left text-xs">
            <thead>
              <tr className="text-slate-500 border-b border-[#161f2e] text-[10px]">
                <th className="pb-2">INSTRUMENT</th>
                <th className="pb-2">CURRENCY</th>
                <th className="pb-2 text-right">NET POSITION</th>
                <th className="pb-2 text-right">AVG ENTRY PRICE</th>
                <th className="pb-2 text-right">CURRENT MTM</th>
                <th className="pb-2 text-right">UNREALIZED P&L</th>
                <th className="pb-2 text-right">REALIZED P&L</th>
                <th className="pb-2 text-right">EXPOSURE (USD)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#161f2e]">
              {positions.map((pos: any) => (
                <tr key={pos.currency} className="hover:bg-[#0e1420]">
                  <td className="py-2.5 font-bold text-white">{pos.instrument}</td>
                  <td className="py-2.5 text-slate-400">{pos.currency}</td>
                  <td className="py-2.5 text-right font-bold text-slate-200">${(pos.netPosition / 1000000).toFixed(1)}M</td>
                  <td className="py-2.5 text-right text-slate-400">{pos.avgPrice?.toFixed(5)}</td>
                  <td className="py-2.5 text-right text-slate-200">{pos.currentPrice?.toFixed(5)}</td>
                  <td className={`py-2.5 text-right font-bold ${pos.unrealizedPnl >= 0 ? "text-emerald-400" : "text-rose-400"}`}>
                    {pos.unrealizedPnl >= 0 ? `+$${pos.unrealizedPnl.toLocaleString()}` : `-$${Math.abs(pos.unrealizedPnl).toLocaleString()}`}
                  </td>
                  <td className="py-2.5 text-right text-emerald-400">+${pos.realizedPnl.toLocaleString()}</td>
                  <td className="py-2.5 text-right font-bold text-slate-200">${(pos.exposureUsd / 1000000).toFixed(1)}M</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
