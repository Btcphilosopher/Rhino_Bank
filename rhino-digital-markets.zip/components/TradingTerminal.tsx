"use client";

import React, { useState } from "react";
import { ArrowUpRight, ArrowDownRight, ShieldCheck, AlertCircle, RefreshCw, ChevronRight } from "lucide-react";

interface TradingTerminalProps {
  marketData: any;
  orders: any[];
  executions: any[];
  positions: any[];
  onPlaceOrder: (orderData: any) => Promise<any>;
  userRole: string;
}

export function TradingTerminal({
  marketData,
  orders,
  executions,
  positions,
  onPlaceOrder,
  userRole,
}: TradingTerminalProps) {
  const instruments = marketData?.instruments || [];
  const selectedInstrument = marketData?.selectedInstrument || instruments[0] || {};
  const orderBook = marketData?.orderBook || { bids: [], asks: [] };
  const smartPrice = marketData?.smartPrice || {};

  const [selectedInstId, setSelectedInstId] = useState(selectedInstrument.id || "USDSTBL");
  const [side, setSide] = useState<"BUY" | "SELL">("BUY");
  const [quantity, setQuantity] = useState("5000000");
  const [price, setPrice] = useState(selectedInstrument.currentPrice?.toString() || "0.99982");
  const [orderType, setOrderType] = useState("LIMIT");
  const [tif, setTif] = useState("IOC");
  const [venue, setVenue] = useState("RHINO_INTERNAL");
  const [chartMode, setChartMode] = useState<"PRICE" | "SPREAD" | "DEPTH" | "VWAP">("PRICE");
  const [timeframe, setTimeframe] = useState("1D");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [orderFeedback, setOrderFeedback] = useState<{ success: boolean; message: string } | null>(null);

  const currentInst = instruments.find((i: any) => i.id === selectedInstId) || selectedInstrument;

  const handleOrderSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setOrderFeedback(null);

    const res = await onPlaceOrder({
      instrument: selectedInstId,
      side,
      quantity: parseFloat(quantity),
      price: parseFloat(price),
      orderType,
      timeInForce: tif,
      venue,
      userRole,
    });

    setIsSubmitting(false);
    if (res) {
      setOrderFeedback({
        success: res.success,
        message: res.message || (res.success ? "Order executed successfully" : "Order rejected"),
      });
    }
  };

  const notional = (parseFloat(quantity) || 0) * (parseFloat(price) || 1);
  const isOverNotionalLimit = notional > 50000000;

  return (
    <div className="flex-1 grid grid-cols-12 grid-rows-12 gap-1.5 p-1.5 bg-[#07090e] overflow-hidden text-slate-200">
      {/* 1. MARKET WATCH PANEL (Cols 1-3, Rows 1-6) */}
      <div className="col-span-3 row-span-6 bg-[#0b0e14] border border-[#1e293b] rounded flex flex-col overflow-hidden">
        <div className="px-3 py-1.5 bg-[#0f1522] border-b border-[#1e293b] flex items-center justify-between font-mono text-xs font-semibold text-slate-300">
          <span>MARKET WATCH</span>
          <span className="text-[10px] text-slate-500 font-normal">INSTITUTIONAL UNIVERSE</span>
        </div>
        <div className="flex-1 overflow-y-auto divide-y divide-[#161f2e]">
          {instruments.map((inst: any) => {
            const isSelected = inst.id === selectedInstId;
            return (
              <button
                key={inst.id}
                onClick={() => {
                  setSelectedInstId(inst.id);
                  setPrice(inst.currentPrice.toString());
                }}
                className={`w-full px-3 py-2 text-left flex items-center justify-between transition-colors cursor-pointer ${
                  isSelected ? "bg-[#111c2e] border-l-2 border-[#0055ff]" : "hover:bg-[#0e1420]"
                }`}
              >
                <div>
                  <div className="font-mono font-bold text-xs text-white flex items-center space-x-1">
                    <span>{inst.id}</span>
                    {inst.riskState === "CRITICAL" && (
                      <span className="text-[9px] bg-rose-500/20 text-rose-400 px-1 rounded">DEPEG</span>
                    )}
                  </div>
                  <div className="text-[10px] text-slate-400 font-mono truncate max-w-[120px]">
                    Spread: {inst.spreadBps} bps
                  </div>
                </div>
                <div className="text-right font-mono text-xs">
                  <div className="font-bold text-slate-100">{inst.currentPrice?.toFixed(5)}</div>
                  <div className={inst.deviationBps < 0 ? "text-rose-400 text-[10px]" : "text-emerald-400 text-[10px]"}>
                    {inst.deviationBps >= 0 ? `+${inst.deviationBps}` : inst.deviationBps} bps
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. FINANCIAL CHART PANEL (Cols 4-8, Rows 1-6) */}
      <div className="col-span-5 row-span-6 bg-[#0b0e14] border border-[#1e293b] rounded flex flex-col overflow-hidden">
        <div className="px-3 py-1.5 bg-[#0f1522] border-b border-[#1e293b] flex items-center justify-between font-mono text-xs">
          <div className="flex items-center space-x-2">
            <span className="font-bold text-white">{currentInst.id}</span>
            <span className="text-slate-400 text-[11px] font-normal">{currentInst.name}</span>
          </div>

          <div className="flex items-center space-x-1">
            {(["PRICE", "SPREAD", "DEPTH", "VWAP"] as const).map((mode) => (
              <button
                key={mode}
                onClick={() => setChartMode(mode)}
                className={`px-1.5 py-0.5 text-[10px] font-mono rounded ${
                  chartMode === mode ? "bg-[#0055ff] text-white font-bold" : "text-slate-400 hover:text-white"
                }`}
              >
                {mode}
              </button>
            ))}
          </div>
        </div>

        {/* Real-time Interactive SVG Financial Chart */}
        <div className="flex-1 p-2 flex flex-col justify-between bg-[#080b10] relative">
          <div className="flex items-center justify-between text-xs font-mono text-slate-400 px-1">
            <span>TARGET: {currentInst.targetPeg?.toFixed(6)}</span>
            <span>24H VWAP: {currentInst.vwap24h?.toFixed(5)}</span>
            <span>VOLATILITY: {currentInst.volatilityBps} bps</span>
          </div>

          {/* SVG Canvas Rendering */}
          <div className="w-full h-44 relative my-1">
            <svg className="w-full h-full overflow-visible" viewBox="0 0 500 160">
              <defs>
                <linearGradient id="chartGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#0055ff" stopOpacity="0.3" />
                  <stop offset="100%" stopColor="#0055ff" stopOpacity="0.0" />
                </linearGradient>
              </defs>

              {/* Grid Lines */}
              <line x1="0" y1="20" x2="500" y2="20" stroke="#1e293b" strokeDasharray="3 3" />
              <line x1="0" y1="80" x2="500" y2="80" stroke="#334155" strokeWidth="1" /> {/* Target peg line */}
              <line x1="0" y1="140" x2="500" y2="140" stroke="#1e293b" strokeDasharray="3 3" />

              {/* Peg Target Line Label */}
              <text x="5" y="75" fill="#64748b" fontSize="10" fontFamily="monospace">Target 1.00000</text>

              {/* Price Line Simulation Path */}
              <path
                d={
                  currentInst.id === "USDSTBL" && marketData?.activeScenario === "DEPEG"
                    ? "M 0 80 Q 100 78, 200 95 T 350 135 T 500 145"
                    : "M 0 82 Q 80 75, 160 81 T 320 78 T 500 80"
                }
                fill="none"
                stroke={currentInst.riskState === "CRITICAL" ? "#f43f5e" : "#3b82f6"}
                strokeWidth="2"
              />

              {/* Area Fill */}
              <path
                d={
                  currentInst.id === "USDSTBL" && marketData?.activeScenario === "DEPEG"
                    ? "M 0 80 Q 100 78, 200 95 T 350 135 T 500 145 L 500 160 L 0 160 Z"
                    : "M 0 82 Q 80 75, 160 81 T 320 78 T 500 80 L 500 160 L 0 160 Z"
                }
                fill="url(#chartGrad)"
              />
            </svg>
          </div>

          <div className="flex items-center justify-between text-[10px] font-mono text-slate-500 border-t border-[#1e293b] pt-1">
            <span>00:00</span>
            <span>06:00</span>
            <span>12:00</span>
            <span>18:00</span>
            <span>NOW</span>
          </div>
        </div>
      </div>

      {/* 3. ORDER TICKET (Cols 9-12, Rows 1-6) */}
      <div className="col-span-4 row-span-6 bg-[#0b0e14] border border-[#1e293b] rounded flex flex-col overflow-hidden">
        <div className="px-3 py-1.5 bg-[#0f1522] border-b border-[#1e293b] flex items-center justify-between font-mono text-xs font-semibold text-slate-300">
          <span>INSTITUTIONAL ORDER TICKET</span>
          <span className="text-[10px] text-blue-400 font-mono">PRE-TRADE RISK ACTIVE</span>
        </div>

        <form onSubmit={handleOrderSubmit} className="p-3 flex-1 flex flex-col justify-between text-xs font-mono">
          {/* BUY / SELL Switcher */}
          <div className="grid grid-cols-2 gap-2 mb-2">
            <button
              type="button"
              onClick={() => setSide("BUY")}
              className={`py-1.5 rounded font-bold cursor-pointer text-xs ${
                side === "BUY"
                  ? "bg-emerald-600 text-white shadow-sm"
                  : "bg-[#111827] text-slate-400 hover:text-white"
              }`}
            >
              BUY {selectedInstId}
            </button>
            <button
              type="button"
              onClick={() => setSide("SELL")}
              className={`py-1.5 rounded font-bold cursor-pointer text-xs ${
                side === "SELL"
                  ? "bg-rose-600 text-white shadow-sm"
                  : "bg-[#111827] text-slate-400 hover:text-white"
              }`}
            >
              SELL {selectedInstId}
            </button>
          </div>

          <div className="space-y-2">
            <div>
              <label className="text-[11px] text-slate-400 block mb-0.5">Quantity (Units):</label>
              <input
                type="number"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                className="w-full bg-[#111827] border border-[#1f2937] rounded px-2.5 py-1 text-white text-xs font-mono focus:border-blue-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-[11px] text-slate-400 block mb-0.5">Price ({currentInst.quoteCurrency}):</label>
              <input
                type="number"
                step="0.00001"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                className="w-full bg-[#111827] border border-[#1f2937] rounded px-2.5 py-1 text-white text-xs font-mono focus:border-blue-500 focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] text-slate-400 block mb-0.5">Order Type:</label>
                <select
                  value={orderType}
                  onChange={(e) => setOrderType(e.target.value)}
                  className="w-full bg-[#111827] border border-[#1f2937] rounded px-2 py-1 text-white text-xs font-mono"
                >
                  <option value="MARKET">MARKET</option>
                  <option value="LIMIT">LIMIT</option>
                  <option value="STOP">STOP</option>
                  <option value="IOC">IOC</option>
                  <option value="FOK">FOK</option>
                  <option value="GTC">GTC</option>
                </select>
              </div>
              <div>
                <label className="text-[10px] text-slate-400 block mb-0.5">Execution Venue:</label>
                <select
                  value={venue}
                  onChange={(e) => setVenue(e.target.value)}
                  className="w-full bg-[#111827] border border-[#1f2937] rounded px-2 py-1 text-white text-xs font-mono"
                >
                  <option value="RHINO_INTERNAL">RHINO INTERNAL</option>
                  <option value="VENUE_A">VENUE A (ECN)</option>
                  <option value="VENUE_B">VENUE B (DIRECT)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Pre-Trade Risk Gate Validation Checklist */}
          <div className="my-2 p-2 bg-[#090d14] border border-[#1e293b] rounded text-[10px] space-y-1">
            <div className="text-slate-400 font-bold mb-1 flex items-center justify-between">
              <span>PRE-TRADE RISK EVALUATION:</span>
              <span className="text-emerald-400 font-normal">GATEKEEPER ONLINE</span>
            </div>
            <div className="flex items-center justify-between">
              <span>Notional Value:</span>
              <span className={isOverNotionalLimit ? "text-rose-400 font-bold" : "text-emerald-400 font-mono"}>
                ${notional.toLocaleString()} {isOverNotionalLimit ? "(EXCEEDS $50M)" : "✓"}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span>Sanctions & AML Check:</span>
              <span className="text-emerald-400">PASSED ✓</span>
            </div>
          </div>

          {orderFeedback && (
            <div
              className={`p-2 rounded text-[11px] mb-2 font-mono ${
                orderFeedback.success ? "bg-emerald-950/80 text-emerald-300 border border-emerald-800" : "bg-rose-950/80 text-rose-300 border border-rose-800"
              }`}
            >
              {orderFeedback.message}
            </div>
          )}

          <button
            type="submit"
            disabled={isSubmitting || isOverNotionalLimit}
            className={`w-full py-2 rounded font-bold text-xs uppercase tracking-wider transition-all cursor-pointer ${
              side === "BUY"
                ? "bg-emerald-600 hover:bg-emerald-500 text-white disabled:opacity-50"
                : "bg-rose-600 hover:bg-rose-500 text-white disabled:opacity-50"
            }`}
          >
            {isSubmitting ? "EVALUATING RISK & EXECUTING..." : `TRANSACT ${side} ${selectedInstId}`}
          </button>
        </form>
      </div>

      {/* 4. ORDER BOOK PANEL (Cols 1-4, Rows 7-12) */}
      <div className="col-span-4 row-span-6 bg-[#0b0e14] border border-[#1e293b] rounded flex flex-col overflow-hidden">
        <div className="px-3 py-1.5 bg-[#0f1522] border-b border-[#1e293b] flex items-center justify-between font-mono text-xs font-semibold text-slate-300">
          <span>CONSOLIDATED ORDER BOOK</span>
          <span className="text-[10px] text-slate-400 font-normal">
            SPREAD: {smartPrice.effectiveSpreadBps} BPS
          </span>
        </div>

        <div className="flex-1 p-2 flex flex-col justify-between font-mono text-[11px]">
          {/* Header */}
          <div className="grid grid-cols-4 text-slate-500 pb-1 border-b border-[#161f2e] text-[10px]">
            <span>PRICE</span>
            <span className="text-right">SIZE (USD)</span>
            <span className="text-right">ORDERS</span>
            <span className="text-right">CUMULATIVE</span>
          </div>

          {/* Asks (Red) */}
          <div className="space-y-0.5 py-1">
            {orderBook.asks.slice().reverse().map((ask: any, idx: number) => (
              <div key={idx} className="grid grid-cols-4 hover:bg-[#1a1015] text-rose-400">
                <span className="font-bold">{ask.price.toFixed(5)}</span>
                <span className="text-right">{ask.size.toLocaleString()}</span>
                <span className="text-right text-slate-400">{ask.orders}</span>
                <span className="text-right text-slate-500">{ask.cumulative.toLocaleString()}</span>
              </div>
            ))}
          </div>

          {/* Mid Price Ticker */}
          <div className="py-1 px-2 my-1 bg-[#09101d] border-y border-[#1e293b] flex items-center justify-between text-xs font-bold text-blue-400">
            <span>MID: {smartPrice.consolidatedMid?.toFixed(5)}</span>
            <span className="text-[10px] text-slate-400 font-normal">
              MICRO: {orderBook.microprice?.toFixed(5)} | IMB: {orderBook.imbalancePct}%
            </span>
          </div>

          {/* Bids (Green) */}
          <div className="space-y-0.5 py-1">
            {orderBook.bids.map((bid: any, idx: number) => (
              <div key={idx} className="grid grid-cols-4 hover:bg-[#0b1a14] text-emerald-400">
                <span className="font-bold">{bid.price.toFixed(5)}</span>
                <span className="text-right">{bid.size.toLocaleString()}</span>
                <span className="text-right text-slate-400">{bid.orders}</span>
                <span className="text-right text-slate-500">{bid.cumulative.toLocaleString()}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 5. EXECUTIONS TABLE (Cols 5-8, Rows 7-12) */}
      <div className="col-span-4 row-span-6 bg-[#0b0e14] border border-[#1e293b] rounded flex flex-col overflow-hidden">
        <div className="px-3 py-1.5 bg-[#0f1522] border-b border-[#1e293b] flex items-center justify-between font-mono text-xs font-semibold text-slate-300">
          <span>LIVE EXECUTIONS</span>
          <span className="text-[10px] text-emerald-400 font-normal">ATOMIC SETTLED</span>
        </div>
        <div className="flex-1 overflow-y-auto p-2">
          <table className="w-full text-left font-mono text-[11px]">
            <thead>
              <tr className="text-slate-500 border-b border-[#161f2e] text-[10px]">
                <th className="pb-1">TIME</th>
                <th className="pb-1">INST</th>
                <th className="pb-1">SIDE</th>
                <th className="pb-1 text-right">PRICE</th>
                <th className="pb-1 text-right">QTY</th>
                <th className="pb-1 text-right">SETTLEMENT</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#161f2e]">
              {executions.map((exec: any) => (
                <tr key={exec.executionId} className="hover:bg-[#0e1420]">
                  <td className="py-1 text-slate-400 text-[10px]">{exec.timestamp?.slice(11, 19)}</td>
                  <td className="py-1 font-bold text-white">{exec.instrument}</td>
                  <td className={`py-1 font-bold ${exec.side === "BUY" ? "text-emerald-400" : "text-rose-400"}`}>
                    {exec.side}
                  </td>
                  <td className="py-1 text-right font-mono text-slate-200">{exec.filledPrice?.toFixed(5)}</td>
                  <td className="py-1 text-right text-slate-300">${(exec.filledQuantity / 1000000).toFixed(1)}M</td>
                  <td className="py-1 text-right text-emerald-400 text-[10px]">SETTLED_ATOMIC</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* 6. POSITIONS PANEL (Cols 9-12, Rows 7-12) */}
      <div className="col-span-4 row-span-6 bg-[#0b0e14] border border-[#1e293b] rounded flex flex-col overflow-hidden">
        <div className="px-3 py-1.5 bg-[#0f1522] border-b border-[#1e293b] flex items-center justify-between font-mono text-xs font-semibold text-slate-300">
          <span>PORTFOLIO POSITIONS</span>
          <span className="text-[10px] text-slate-400 font-normal">REALIZED P&L</span>
        </div>
        <div className="flex-1 overflow-y-auto p-2">
          <table className="w-full text-left font-mono text-[11px]">
            <thead>
              <tr className="text-slate-500 border-b border-[#161f2e] text-[10px]">
                <th className="pb-1">CURRENCY</th>
                <th className="pb-1 text-right">NET POSITION</th>
                <th className="pb-1 text-right">AVG ENTRY</th>
                <th className="pb-1 text-right">UNREALIZED P&L</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#161f2e]">
              {positions.map((pos: any) => (
                <tr key={pos.currency} className="hover:bg-[#0e1420]">
                  <td className="py-1.5 font-bold text-white">{pos.instrument}</td>
                  <td className="py-1.5 text-right font-bold text-slate-200">${(pos.netPosition / 1000000).toFixed(1)}M</td>
                  <td className="py-1.5 text-right text-slate-400">{pos.avgPrice?.toFixed(5)}</td>
                  <td className={`py-1.5 text-right font-bold ${pos.unrealizedPnl >= 0 ? "text-emerald-400" : "text-rose-400"}`}>
                    {pos.unrealizedPnl >= 0 ? `+$${pos.unrealizedPnl.toLocaleString()}` : `-$${Math.abs(pos.unrealizedPnl).toLocaleString()}`}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
