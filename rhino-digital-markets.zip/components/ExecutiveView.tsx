"use client";

import React from "react";
import { Landmark, TrendingUp, ShieldCheck, Activity, Award, AlertTriangle } from "lucide-react";

interface ExecutiveViewProps {
  treasuryData: any;
  riskData: any;
  marketData: any;
  onSetScenario: (scen: string) => void;
}

export function ExecutiveView({ treasuryData, riskData, marketData, onSetScenario }: ExecutiveViewProps) {
  const pegDev = marketData?.pegMonitor?.deviationBps || -1.8;
  const riskState = riskData?.summary?.overallState || "GREEN";

  return (
    <div className="flex-1 p-6 bg-[#07090e] text-slate-200 font-mono overflow-y-auto">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Banner */}
        <div className="bg-[#0b0e14] border-2 border-[#0055ff] p-6 rounded shadow-lg flex items-center justify-between">
          <div>
            <div className="flex items-center space-x-2 text-xs text-[#60a5fa] font-bold uppercase tracking-widest mb-1">
              <span>RHINO BANK DIGITAL MARKETS</span>
              <span>•</span>
              <span>EXECUTIVE BOARD BRIEFING</span>
            </div>
            <h1 className="text-2xl font-extrabold text-white">
              INSTITUTIONAL STABLECOIN EXECUTIVE SUMMARY
            </h1>
            <p className="text-xs text-slate-400 mt-1">
              Real-time 30-second operational snapshot for Chief Risk Officer, Treasurer, and Board of Directors.
            </p>
          </div>

          <div className="text-right">
            <div className="text-xs text-slate-400">PEG HEALTH STATUS</div>
            <div className="text-xl font-extrabold text-emerald-400 mt-0.5">0.99982 USD ({pegDev} bps)</div>
            <div className="text-[10px] text-slate-400 mt-0.5">TARGET: 1.00000 USD</div>
          </div>
        </div>

        {/* 6 Executive KIP Cards */}
        <div className="grid grid-cols-3 gap-4">
          <div className="bg-[#0b0e14] border border-[#1e293b] p-4 rounded space-y-1">
            <div className="text-xs text-slate-500 font-bold uppercase">TOTAL DIGITAL ASSET BALANCE</div>
            <div className="text-2xl font-extrabold text-white">$2.450 BILLION</div>
            <div className="text-xs text-emerald-400">100%+ Fully Backed by Cash & T-Bills</div>
          </div>

          <div className="bg-[#0b0e14] border border-[#1e293b] p-4 rounded space-y-1">
            <div className="text-xs text-slate-500 font-bold uppercase">24H INSTITUTIONAL VOLUME</div>
            <div className="text-2xl font-extrabold text-blue-400">$1.450 BILLION</div>
            <div className="text-xs text-slate-400">Across 3 ECN Venues & RFQ Desk</div>
          </div>

          <div className="bg-[#0b0e14] border border-[#1e293b] p-4 rounded space-y-1">
            <div className="text-xs text-slate-500 font-bold uppercase">NET UNHEDGED EXPOSURE</div>
            <div className="text-2xl font-extrabold text-slate-200">$480 MILLION</div>
            <div className="text-xs text-slate-400">Within $800M Bank Limits</div>
          </div>

          <div className="bg-[#0b0e14] border border-[#1e293b] p-4 rounded space-y-1">
            <div className="text-xs text-slate-500 font-bold uppercase">LIQUIDITY CASH RUNWAY</div>
            <div className="text-2xl font-extrabold text-emerald-400">94 DAYS</div>
            <div className="text-xs text-slate-400">30-Day Stress Buffer Duration</div>
          </div>

          <div className="bg-[#0b0e14] border border-[#1e293b] p-4 rounded space-y-1">
            <div className="text-xs text-slate-500 font-bold uppercase">QUANT VALUE AT RISK (VaR 99%)</div>
            <div className="text-2xl font-extrabold text-amber-400">$4.25 MILLION</div>
            <div className="text-xs text-slate-400">10,000 Monte Carlo Simulations</div>
          </div>

          <div className="bg-[#0b0e14] border border-[#1e293b] p-4 rounded space-y-1">
            <div className="text-xs text-slate-500 font-bold uppercase">SUBSYSTEM HEALTH STATE</div>
            <div className="text-2xl font-extrabold text-emerald-400">100% OPERATIONAL</div>
            <div className="text-xs text-emerald-400">Zero Audit Variances Detected</div>
          </div>
        </div>

        {/* Executive Crisis Trigger Shortcuts */}
        <div className="bg-[#0b0e14] border border-[#1e293b] p-5 rounded space-y-3">
          <h2 className="text-sm font-bold text-slate-200 border-b border-[#1e293b] pb-2 flex items-center justify-between">
            <span>EXECUTIVE DEMO CRISIS SCENARIO CONTROLLER</span>
            <span className="text-xs text-amber-400">BOARD TESTING PROTOCOL</span>
          </h2>

          <p className="text-xs text-slate-400">
            Select a financial crisis scenario to test system-wide automated risk response, depeg escalation, and liquidity preservation:
          </p>

          <div className="grid grid-cols-4 gap-2 text-xs">
            <button
              onClick={() => onSetScenario("NORMAL")}
              className="p-2.5 bg-[#090d14] hover:bg-[#111827] border border-[#1e293b] rounded text-emerald-400 font-bold text-left cursor-pointer"
            >
              1. NORMAL MARKET
            </button>
            <button
              onClick={() => onSetScenario("DEPEG")}
              className="p-2.5 bg-[#090d14] hover:bg-rose-950/60 border border-rose-800/80 rounded text-rose-400 font-bold text-left cursor-pointer"
            >
              2. DEPEG EVENT (-50 BPS)
            </button>
            <button
              onClick={() => onSetScenario("LIQUIDITY_SHOCK")}
              className="p-2.5 bg-[#090d14] hover:bg-amber-950/60 border border-amber-800/80 rounded text-amber-400 font-bold text-left cursor-pointer"
            >
              3. LIQUIDITY SHOCK
            </button>
            <button
              onClick={() => onSetScenario("REDEMPTION_EVENT")}
              className="p-2.5 bg-[#090d14] hover:bg-amber-950/60 border border-amber-800/80 rounded text-amber-400 font-bold text-left cursor-pointer"
            >
              4. REDEMPTION WAVE ($470M)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
