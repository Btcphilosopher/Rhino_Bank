import { NextRequest, NextResponse } from "next/server";
import { OrderRecord, ExecutionRecord, PositionRecord, getScenario } from "@/lib/rhino-state";

// In-Memory active orders and execution history
const orderHistory: OrderRecord[] = [
  {
    orderId: "ORD-98214-US",
    timestamp: new Date(Date.now() - 120000).toISOString(),
    account: "RHINO-INST-TREASURY-01",
    trader: "Senior Trader (E. Vance)",
    instrument: "USDSTBL",
    side: "BUY",
    quantity: 10000000,
    price: 0.99980,
    orderType: "LIMIT",
    timeInForce: "GTC",
    venue: "RHINO_INTERNAL",
    riskStatus: "PASSED",
    executionStatus: "FILLED",
  },
  {
    orderId: "ORD-98215-US",
    timestamp: new Date(Date.now() - 60000).toISOString(),
    account: "BARCLAYS-DESK-ALGO",
    trader: "Algo Gateway",
    instrument: "USDSTBL",
    side: "SELL",
    quantity: 5000000,
    price: 0.99990,
    orderType: "IOC",
    timeInForce: "IOC",
    venue: "VENUE_A",
    riskStatus: "PASSED",
    executionStatus: "FILLED",
  },
];

const executionHistory: ExecutionRecord[] = [
  {
    executionId: "EXEC-7721-01",
    orderId: "ORD-98214-US",
    timestamp: new Date(Date.now() - 120000).toISOString(),
    instrument: "USDSTBL",
    side: "BUY",
    filledQuantity: 10000000,
    filledPrice: 0.99980,
    feeUsd: 150.00,
    slippageBps: 0.1,
    venue: "RHINO_INTERNAL",
    settlementStatus: "SETTLED_ATOMIC",
  },
  {
    executionId: "EXEC-7721-02",
    orderId: "ORD-98215-US",
    timestamp: new Date(Date.now() - 60000).toISOString(),
    instrument: "USDSTBL",
    side: "SELL",
    filledQuantity: 5000000,
    filledPrice: 0.99990,
    feeUsd: 85.00,
    slippageBps: 0.2,
    venue: "VENUE_A",
    settlementStatus: "SETTLED_ATOMIC",
  },
];

const positions: PositionRecord[] = [
  {
    currency: "USD",
    instrument: "USDSTBL",
    netPosition: 450000000,
    avgPrice: 0.99992,
    currentPrice: 0.99982,
    unrealizedPnl: -45000,
    realizedPnl: 182000,
    exposureUsd: 449919000,
  },
  {
    currency: "GBP",
    instrument: "GBPSTBL",
    netPosition: 180000000,
    avgPrice: 1.00000,
    currentPrice: 1.00002,
    unrealizedPnl: 3600,
    realizedPnl: 94000,
    exposureUsd: 180003600,
  },
  {
    currency: "EUR",
    instrument: "EURSTBL",
    netPosition: 220000000,
    avgPrice: 0.99995,
    currentPrice: 0.99998,
    unrealizedPnl: 6600,
    realizedPnl: 121000,
    exposureUsd: 219995600,
  },
];

export async function GET() {
  return NextResponse.json({
    orders: orderHistory,
    executions: executionHistory,
    positions,
  });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { action, instrument, side, quantity, price, orderType, timeInForce, venue, account, userRole } = body;

    const notional = Number(quantity) * (Number(price) || 1);
    const maxLimit = 50000000; // $50M limit
    const scenario = getScenario();

    // 1. PRE-TRADE RISK EVALUATION PIPELINE
    let riskStatus: OrderRecord['riskStatus'] = 'PASSED';
    let rejectionReason: string | undefined = undefined;

    if (notional > maxLimit) {
      riskStatus = 'REJECTED';
      rejectionReason = `PRE-TRADE RISK VIOLATION: Notional $${notional.toLocaleString()} exceeds single order limit ($50,000,000).`;
    } else if (scenario === 'DEPEG' && side === 'BUY' && notional > 10000000) {
      riskStatus = 'REJECTED';
      rejectionReason = `DEPEG ESCALATION POLICY: Buy orders restricted during active Depeg state unless authorized by Chief Risk Officer.`;
    } else if (scenario === 'MARKET_DATA_FAILURE') {
      riskStatus = 'REJECTED';
      rejectionReason = `SAFETY HALT: Primary market data feeds marked stale. Executions blocked.`;
    }

    const orderId = `ORD-${Math.floor(100000 + Math.random() * 900000)}-US`;
    const newOrder: OrderRecord = {
      orderId,
      timestamp: new Date().toISOString(),
      account: account || "RHINO-PRIMARY-TRADING",
      trader: userRole || "Senior Trader",
      instrument: instrument || "USDSTBL",
      side: side || "BUY",
      quantity: Number(quantity),
      price: Number(price) || 1.0000,
      orderType: orderType || "LIMIT",
      timeInForce: timeInForce || "IOC",
      venue: venue || "RHINO_INTERNAL",
      riskStatus,
      executionStatus: riskStatus === 'PASSED' ? 'FILLED' : 'REJECTED',
      rejectionReason,
    };

    orderHistory.unshift(newOrder);

    if (riskStatus === 'PASSED') {
      const execId = `EXEC-${Math.floor(1000 + Math.random() * 9000)}-01`;
      const execution: ExecutionRecord = {
        executionId: execId,
        orderId,
        timestamp: new Date().toISOString(),
        instrument: instrument || "USDSTBL",
        side: side || "BUY",
        filledQuantity: Number(quantity),
        filledPrice: Number(price) || 1.0000,
        feeUsd: Number((notional * 0.00005).toFixed(2)),
        slippageBps: 0.1,
        venue: venue || "RHINO_INTERNAL",
        settlementStatus: 'SETTLED_ATOMIC',
      };
      executionHistory.unshift(execution);
    }

    return NextResponse.json({
      success: riskStatus === 'PASSED',
      order: newOrder,
      message: riskStatus === 'PASSED' ? 'Order validated by Pre-Trade Risk Engine and executed atomically.' : rejectionReason,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
