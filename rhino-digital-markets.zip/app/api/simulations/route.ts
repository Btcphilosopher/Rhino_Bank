import { NextRequest, NextResponse } from "next/server";
import { setScenario, ScenarioType, getScenario } from "@/lib/rhino-state";

const scenarioList: ScenarioType[] = [
  { id: 'NORMAL', name: 'NORMAL MARKET', description: 'Standard spreads, high depth, baseline liquidity and zero peg deviation.' },
  { id: 'HIGH_VOLATILITY', name: 'HIGH VOLATILITY', description: 'Rapid price fluctuations, widened spreads (2.0x), increased intraday range.' },
  { id: 'LIQUIDITY_SHOCK', name: 'LIQUIDITY SHOCK', description: 'Order book depth drops by 90%, spreads widen (5.0x), high slippage impact.' },
  { id: 'REDEMPTION_EVENT', name: 'REDEMPTION EVENT', description: 'Large stablecoin redemption wave ($470M outflow). Elevated reserve drawdown.' },
  { id: 'DEPEG', name: 'DEPEG EVENT (-50 bps)', description: 'USDSTBL moves away from target peg to $0.9950. Triggers Depeg Crisis Escalation Policy.' },
  { id: 'VENUE_FAILURE', name: 'VENUE FAILURE', description: 'Primary ECN Venue A disconnects. Smart Order Router automatically re-routes traffic.' },
  { id: 'COUNTERPARTY_FAILURE', name: 'COUNTERPARTY FAILURE', description: 'Liquidity Provider B marked degraded. Counterparty credit limit alerts triggered.' },
  { id: 'MARKET_DATA_FAILURE', name: 'MARKET-DATA STALE', description: 'Primary tick stream marked stale. Safety pre-trade risk engine blocks new risky orders.' },
  { id: 'COMBINED_CRISIS', name: 'COMBINED CRISIS', description: 'Multi-factor emergency: -90 bps depeg, liquidity shock, venue outage & redemption wave.' },
];

export async function GET() {
  return NextResponse.json({
    currentScenario: getScenario(),
    availableScenarios: scenarioList,
  });
}

export async function POST(req: NextRequest) {
  try {
    const { scenarioId } = await req.json();
    if (!scenarioId || !scenarioList.find(s => s.id === scenarioId)) {
      return NextResponse.json({ error: 'Invalid scenario ID' }, { status: 400 });
    }
    setScenario(scenarioId as ScenarioType['id']);
    return NextResponse.json({
      success: true,
      currentScenario: getScenario(),
      message: `Switched institutional simulation mode to ${scenarioId}. System risk meters and engines updated.`,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
