import { NextRequest, NextResponse } from "next/server";
import { getScenario } from "@/lib/rhino-state";

export async function GET(req: NextRequest) {
  const scenario = getScenario();

  let overallState: 'GREEN' | 'AMBER' | 'RED' | 'CRITICAL' = 'GREEN';
  let marketRisk = 18;
  let liquidityRisk = 12;
  let counterpartyRisk = 14;
  let depegRisk = 8;
  let pPegBreach = 0.002;
  let pLiquidityShortfall = 0.001;
  let var99 = 4250000;
  let expectedShortfall = 6800000;

  if (scenario === 'DEPEG') {
    overallState = 'CRITICAL';
    marketRisk = 92;
    liquidityRisk = 85;
    depegRisk = 98;
    pPegBreach = 0.884;
    pLiquidityShortfall = 0.342;
    var99 = 48500000;
    expectedShortfall = 72000000;
  } else if (scenario === 'LIQUIDITY_SHOCK') {
    overallState = 'RED';
    liquidityRisk = 91;
    marketRisk = 65;
    pLiquidityShortfall = 0.421;
    var99 = 22100000;
    expectedShortfall = 34000000;
  } else if (scenario === 'REDEMPTION_EVENT') {
    overallState = 'AMBER';
    liquidityRisk = 62;
    pLiquidityShortfall = 0.115;
    var99 = 11200000;
  } else if (scenario === 'HIGH_VOLATILITY') {
    overallState = 'AMBER';
    marketRisk = 74;
    var99 = 18400000;
  } else if (scenario === 'VENUE_FAILURE' || scenario === 'COUNTERPARTY_FAILURE') {
    overallState = 'AMBER';
    counterpartyRisk = 82;
  } else if (scenario === 'COMBINED_CRISIS') {
    overallState = 'CRITICAL';
    marketRisk = 98;
    liquidityRisk = 96;
    counterpartyRisk = 94;
    depegRisk = 99;
    pPegBreach = 0.942;
    pLiquidityShortfall = 0.618;
    var99 = 89000000;
    expectedShortfall = 135000000;
  }

  const limits = [
    { level: "BANK_GROSS_EXPOSURE", usedUsd: 1420000000, limitUsd: 2000000000, pctUsed: 71.0 },
    { level: "BANK_NET_EXPOSURE", usedUsd: 480000000, limitUsd: 800000000, pctUsed: 60.0 },
    { level: "DIGITAL_MARKETS_DESK", usedUsd: 380000000, limitUsd: 500000000, pctUsed: 76.0 },
    { level: "SENIOR_TRADER_EVANCE", usedUsd: 41000000, limitUsd: 50000000, pctUsed: 82.0 },
    { level: "COUNTERPARTY_BARCLAYS", usedUsd: 180000000, limitUsd: 250000000, pctUsed: 72.0 },
    { level: "DAILY_LOSS_CAP", usedUsd: 840000, limitUsd: 5000000, pctUsed: 16.8 },
  ];

  const depegEscalation = [
    { targetPeg: 1.00000, threshold: "NORMAL (0.0 bps)", action: "Standard inventory limits & automated market making", status: scenario === 'NORMAL' ? "ACTIVE" : "PASSED" },
    { targetPeg: 0.99950, threshold: "AMBER (-5.0 bps)", action: "Increase monitoring to 100ms. Widen MM spreads by 2.5 bps", status: ['HIGH_VOLATILITY', 'REDEMPTION_EVENT', 'AMBER'].includes(overallState) ? "ACTIVE" : "MONITORING" },
    { targetPeg: 0.99800, threshold: "RED (-20.0 bps)", action: "Reduce max order size by 50%. Require Senior Trader co-signing", status: ['RED', 'CRITICAL'].includes(overallState) ? "ACTIVE" : "STANDBY" },
    { targetPeg: 0.99500, threshold: "CRITICAL (-50.0 bps)", action: "Depeg Crisis Mode. Restrict buy/sell to redemption desk only", status: scenario === 'DEPEG' ? "TRIGGERED_ACTIVE" : "STANDBY" },
    { targetPeg: 0.99000, threshold: "EMERGENCY (-100.0 bps)", action: "Halt secondary trading on affected stablecoin. Initiate Treasury reserve redemption protocol", status: scenario === 'COMBINED_CRISIS' ? "TRIGGERED_ACTIVE" : "STANDBY" },
  ];

  return NextResponse.json({
    summary: {
      overallState,
      marketRiskScore: marketRisk,
      liquidityRiskScore: liquidityRisk,
      counterpartyRiskScore: counterpartyRisk,
      depegRiskScore: depegRisk,
    },
    quantMetrics: {
      var99Usd: var99,
      expectedShortfallUsd: expectedShortfall,
      pPegBreachPct: Number((pPegBreach * 100).toFixed(2)),
      pLiquidityShortfallPct: Number((pLiquidityShortfall * 100).toFixed(2)),
      monteCarloSimulationsCount: 10000,
      confidenceIntervalPct: 99.0,
    },
    limits,
    depegEscalation,
    timestamp: new Date().toISOString(),
  });
}
