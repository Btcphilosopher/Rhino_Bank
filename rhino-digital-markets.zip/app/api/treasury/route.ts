import { NextRequest, NextResponse } from "next/server";
import { getScenario } from "@/lib/rhino-state";

export async function GET(req: NextRequest) {
  const scenario = getScenario();

  let totalLiquidity = 2450000000;
  let cashFiat = 850000000;
  let stablecoinInv = 920000000;
  let govSecurities = 680000000;
  let collateralAllocated = 450000000;
  let runway30 = 94;
  let runway90 = 280;

  if (scenario === 'REDEMPTION_EVENT') {
    stablecoinInv = 450000000;
    cashFiat = 420000000;
    totalLiquidity = 1550000000;
    runway30 = 38;
    runway90 = 110;
  } else if (scenario === 'LIQUIDITY_SHOCK') {
    totalLiquidity = 1100000000;
    cashFiat = 210000000;
    runway30 = 18;
    runway90 = 45;
  }

  // Reserves composition
  const reserves = [
    { currency: "USD", fiatBalance: cashFiat, stablecoinBalance: stablecoinInv, backingRatioPct: 104.2 },
    { currency: "GBP", fiatBalance: 240000000, stablecoinBalance: 220000000, backingRatioPct: 109.1 },
    { currency: "EUR", fiatBalance: 310000000, stablecoinBalance: 295000000, backingRatioPct: 105.1 },
    { currency: "JPY", fiatBalance: 120000000, stablecoinBalance: 115000000, backingRatioPct: 104.3 },
    { currency: "CHF", fiatBalance: 95000000, stablecoinBalance: 90000000, backingRatioPct: 105.5 },
  ];

  // Stress test scenarios: 5%, 10%, 20%, 30%, 50%, 75%, 90%
  const redemptionScenarios = [0.05, 0.10, 0.20, 0.30, 0.50, 0.75, 0.90].map(pct => {
    const redemptionDemand = stablecoinInv * pct;
    const cashRemaining = cashFiat - redemptionDemand;
    const totalLiquidRemaining = (cashFiat + govSecurities) - redemptionDemand;
    return {
      percentage: `${pct * 100}%`,
      redemptionDemandUsd: redemptionDemand,
      cashRemainingUsd: cashRemaining,
      totalLiquidRemainingUsd: totalLiquidRemaining,
      status: totalLiquidRemaining > 0 ? (cashRemaining > 0 ? "FULLY_COVERED" : "SECONDAY_BUFFER_USED") : "DEFICIT",
    };
  });

  return NextResponse.json({
    metrics: {
      totalLiquidityUsd: totalLiquidity,
      availableCashUsd: cashFiat,
      stablecoinInventoryUsd: stablecoinInv,
      governmentSecuritiesUsd: govSecurities,
      collateralBufferUsd: collateralAllocated,
      liquidityRunway30dDays: runway30,
      liquidityRunway90dDays: runway90,
      redemptionCoverageRatioPct: Number(((cashFiat + govSecurities) / stablecoinInv * 100).toFixed(1)),
    },
    reserves,
    redemptionScenarios,
    timestamp: new Date().toISOString(),
  });
}
