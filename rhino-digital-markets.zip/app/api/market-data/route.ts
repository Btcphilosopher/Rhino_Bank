import { NextRequest, NextResponse } from "next/server";
import { getInitialInstruments, getScenario, VenueQuote } from "@/lib/rhino-state";

export async function GET(req: NextRequest) {
  const scenario = getScenario();
  const instruments = getInitialInstruments(scenario);

  // Simulated venue Quotes for USDSTBL
  const usdInst = instruments.find(i => i.id === 'USDSTBL') || instruments[0];
  const mid = usdInst.currentPrice;

  const venueAStatus = scenario === 'VENUE_FAILURE' ? 'DISCONNECTED' : 'ONLINE';
  const venueBStatus = scenario === 'COUNTERPARTY_FAILURE' ? 'DEGRADED' : 'ONLINE';
  const isMarketDataStale = scenario === 'MARKET_DATA_FAILURE';

  const venues: VenueQuote[] = [
    {
      venueId: 'VENUE_A',
      venueName: 'Institutional ECN Alpha',
      bid: Number((mid - 0.00008).toFixed(6)),
      ask: Number((mid + 0.00010).toFixed(6)),
      bidSize: venueAStatus === 'ONLINE' ? 25000000 : 0,
      askSize: venueAStatus === 'ONLINE' ? 28000000 : 0,
      latencyMs: 1.4,
      feeBps: 0.35,
      status: venueAStatus,
    },
    {
      venueId: 'VENUE_B',
      venueName: 'Global Direct Liquidity Desk',
      bid: Number((mid - 0.00012).toFixed(6)),
      ask: Number((mid + 0.00006).toFixed(6)),
      bidSize: venueBStatus === 'ONLINE' ? 32000000 : 5000000,
      askSize: venueBStatus === 'ONLINE' ? 35000000 : 6000000,
      latencyMs: 2.8,
      feeBps: 0.50,
      status: venueBStatus,
    },
    {
      venueId: 'VENUE_C',
      venueName: 'Rhino Primary Market Pool',
      bid: Number((mid - 0.00005).toFixed(6)),
      ask: Number((mid + 0.00005).toFixed(6)),
      bidSize: 45000000,
      askSize: 45000000,
      latencyMs: 0.6,
      feeBps: 0.10,
      status: 'ONLINE',
    },
  ];

  // Detailed Order Book depth for USDSTBL
  const bids = [
    { price: Number((mid - 0.00005).toFixed(6)), size: 12500000, orders: 14, cumulative: 12500000 },
    { price: Number((mid - 0.00010).toFixed(6)), size: 18400000, orders: 22, cumulative: 30900000 },
    { price: Number((mid - 0.00015).toFixed(6)), size: 24100000, orders: 31, cumulative: 55000000 },
    { price: Number((mid - 0.00020).toFixed(6)), size: 30000000, orders: 45, cumulative: 85000000 },
  ];

  const asks = [
    { price: Number((mid + 0.00005).toFixed(6)), size: 14200000, orders: 18, cumulative: 14200000 },
    { price: Number((mid + 0.00010).toFixed(6)), size: 19800000, orders: 27, cumulative: 34000000 },
    { price: Number((mid + 0.00015).toFixed(6)), size: 26000000, orders: 38, cumulative: 60000000 },
    { price: Number((mid + 0.00020).toFixed(6)), size: 32000000, orders: 50, cumulative: 92000000 },
  ];

  return NextResponse.json({
    activeScenario: scenario,
    instruments,
    selectedInstrument: usdInst,
    smartPrice: {
      instrument: usdInst.id,
      bestBid: usdInst.bestBid,
      bestAsk: usdInst.bestAsk,
      consolidatedMid: usdInst.currentPrice,
      effectiveSpreadBps: usdInst.spreadBps,
      totalBidDepthUsd: usdInst.depthBidUsd,
      totalAskDepthUsd: usdInst.depthAskUsd,
      venueCount: venues.filter(v => v.status === 'ONLINE').length,
      anomalyFlag: isMarketDataStale ? 'STALE_PRICE_WARNING' : (usdInst.riskState === 'CRITICAL' ? 'DEPEG_ALERT' : null),
    },
    venues,
    orderBook: {
      bids,
      asks,
      microprice: Number((mid + (usdInst.depthBidUsd - usdInst.depthAskUsd) * 0.000000001).toFixed(6)),
      imbalancePct: Number((((usdInst.depthBidUsd - usdInst.depthAskUsd) / (usdInst.depthBidUsd + usdInst.depthAskUsd)) * 100).toFixed(2)),
    },
    pegMonitor: {
      instrument: 'USDSTBL',
      target: 1.000000,
      current: usdInst.currentPrice,
      deviationBps: usdInst.deviationBps,
      range24h: `${usdInst.low24h.toFixed(5)}–${usdInst.high24h.toFixed(5)}`,
      liquidity: scenario === 'LIQUIDITY_SHOCK' ? 'LOW' : 'HIGH',
      redemptionFlow: usdInst.redemptionFlow,
      riskState: usdInst.riskState,
    },
    timestamp: new Date().toISOString(),
  });
}
