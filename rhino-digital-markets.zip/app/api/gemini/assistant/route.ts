import { NextRequest, NextResponse } from "next/server";
import { getGeminiClient } from "@/lib/gemini";

export async function POST(req: NextRequest) {
  try {
    const { prompt, contextState } = await req.json();

    if (!prompt) {
      return NextResponse.json({ error: "Prompt is required" }, { status: 400 });
    }

    const ai = getGeminiClient();

    const systemInstruction = `
You are RHINO INTELLIGENCE, the authorized AI Quantitative & Risk Co-pilot for Rhino Bank Digital Markets.
Your role is to assist human traders, risk officers, and treasury managers with real-time portfolio analysis, stress testing interpretations, and market risk diagnoses.

CRITICAL INSTITUTIONAL CONSTRAINTS:
1. You are STRICTLY READ-ONLY. You MAY NOT execute trades, modify risk limits, burn/mint stablecoins, or alter bank reserves.
2. Any recommended action MUST include a note that it requires dual-authorization via the Risk & Treasury Gateways.
3. Use formal, precise institutional financial terminology (e.g. bps, VWAP, TWAP, VaR 99%, Expected Shortfall, DVP, RTGS).
4. Never use retail crypto jargon or speculative promises.
5. Provide quantitative numerical breakdowns whenever possible.

Current Platform Context:
${JSON.stringify(contextState || {}, null, 2)}
`;

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: prompt,
      config: {
        systemInstruction,
        temperature: 0.2,
      },
    });

    return NextResponse.json({
      text: response.text || "No analytical response generated.",
      timestamp: new Date().toISOString(),
      disclaimer: "RHINO INTELLIGENCE IS A READ-ONLY ADVISORY ENGINE. ALL ACTIONS REQUIRE DUAL HUMAN AUTHORIZATION.",
    });
  } catch (error: any) {
    console.error("Rhino Intelligence Error:", error);
    return NextResponse.json(
      { error: error.message || "Failed to process Rhino Intelligence query." },
      { status: 500 }
    );
  }
}
