import { NextRequest, NextResponse } from "next/server";

export async function GET(req: NextRequest) {
  const tradingLedgerUsd = 2450000000;
  const bankLedgerUsd = 2450000000;
  const blockchainNetworkUsd = 2450000000;
  const custodyUsd = 2450000000;

  const reconciliationRecords = [
    {
      id: "REC-2026-0902-01",
      timestamp: new Date().toISOString(),
      ledgerA: "TRADING_LEDGER",
      ledgerB: "BANK_INTERNAL_CORE",
      sumAUsd: tradingLedgerUsd,
      sumBUsd: bankLedgerUsd,
      varianceUsd: 0,
      status: "BALANCED",
    },
    {
      id: "REC-2026-0902-02",
      timestamp: new Date().toISOString(),
      ledgerA: "STABLECOIN_NETWORK_STATE",
      ledgerB: "CUSTODY_RESERVE_ESCROW",
      sumAUsd: blockchainNetworkUsd,
      sumBUsd: custodyUsd,
      varianceUsd: 0,
      status: "BALANCED",
    },
  ];

  return NextResponse.json({
    summary: {
      tradingLedgerUsd,
      bankLedgerUsd,
      blockchainNetworkUsd,
      custodyUsd,
      varianceUsd: 0,
      status: "BALANCED",
      lastRunAt: new Date().toISOString(),
    },
    records: reconciliationRecords,
  });
}
