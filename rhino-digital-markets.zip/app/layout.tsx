import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Rhino Bank Digital Markets | Institutional Trading & Treasury Platform',
  description: 'Institutional stablecoin trading, treasury liquidity management, FX conversion, and quantitative risk engine.',
  openGraph: {
    title: 'Rhino Bank Digital Markets',
    description: 'Institutional Stablecoin Trading, Treasury & Quantitative Risk Platform',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Rhino Bank Digital Markets',
    description: 'Institutional Stablecoin Trading, Treasury & Quantitative Risk Platform',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
