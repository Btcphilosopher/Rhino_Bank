"use client";

import React, { useState, useEffect } from "react";
import { Header } from "@/components/Header";
import { StatusBar } from "@/components/StatusBar";
import { TradingTerminal } from "@/components/TradingTerminal";
import { RfqDesk } from "@/components/RfqDesk";
import { TreasuryDesk } from "@/components/TreasuryDesk";
import { RiskCockpit } from "@/components/RiskCockpit";
import { PortfolioView } from "@/components/PortfolioView";
import { OperationsView } from "@/components/OperationsView";
import { ExecutiveView } from "@/components/ExecutiveView";
import { QuantLab } from "@/components/QuantLab";
import { RhinoIntelligence } from "@/components/RhinoIntelligence";

export default function Home() {
  const [currentTab, setCurrentTab] = useState("trading");
  const [userRole, setUserRole] = useState("SENIOR_TRADER");
  const [activeScenario, setActiveScenario] = useState("NORMAL");

  const [marketData, setMarketData] = useState<any>(null);
  const [tradingData, setTradingData] = useState<any>({ orders: [], executions: [], positions: [] });
  const [treasuryData, setTreasuryData] = useState<any>(null);
  const [riskData, setRiskData] = useState<any>(null);
  const [reconciliationData, setReconciliationData] = useState<any>(null);

  const fetchAllState = async () => {
    try {
      const [mRes, tRes, trRes, rRes, recRes] = await Promise.all([
        fetch("/api/market-data"),
        fetch("/api/trading"),
        fetch("/api/treasury"),
        fetch("/api/risk"),
        fetch("/api/reconciliation"),
      ]);

      const mVal = await mRes.json();
      const tVal = await tRes.json();
      const trVal = await trRes.json();
      const rVal = await rRes.json();
      const recVal = await recRes.json();

      setMarketData(mVal);
      setTradingData(tVal);
      setTreasuryData(trVal);
      setRiskData(rVal);
      setReconciliationData(recVal);
      if (mVal.activeScenario) {
        setActiveScenario(mVal.activeScenario);
      }
    } catch (err) {
      console.error("Failed to fetch platform state:", err);
    }
  };

  useEffect(() => {
    let isMounted = true;
    const load = async () => {
      try {
        const [mRes, tRes, trRes, rRes, recRes] = await Promise.all([
          fetch("/api/market-data"),
          fetch("/api/trading"),
          fetch("/api/treasury"),
          fetch("/api/risk"),
          fetch("/api/reconciliation"),
        ]);

        const mVal = await mRes.json();
        const tVal = await tRes.json();
        const trVal = await trRes.json();
        const rVal = await rRes.json();
        const recVal = await recRes.json();

        if (isMounted) {
          setMarketData(mVal);
          setTradingData(tVal);
          setTreasuryData(trVal);
          setRiskData(rVal);
          setReconciliationData(recVal);
          if (mVal.activeScenario) {
            setActiveScenario(mVal.activeScenario);
          }
        }
      } catch (err) {
        console.error("Failed to fetch platform state:", err);
      }
    };

    load();
    const interval = setInterval(load, 2000);
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, []);

  const handleScenarioChange = async (newScenario: string) => {
    setActiveScenario(newScenario);
    await fetch("/api/simulations", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ scenarioId: newScenario }),
    });
    fetchAllState();
  };

  const handlePlaceOrder = async (orderPayload: any) => {
    const res = await fetch("/api/trading", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(orderPayload),
    });
    const result = await res.json();
    fetchAllState();
    return result;
  };

  const pegPrice = marketData?.pegMonitor?.current || 0.99982;
  const pegDev = marketData?.pegMonitor?.deviationBps || -1.8;
  const riskState = riskData?.summary?.overallState || "GREEN";

  return (
    <div className="flex flex-col h-screen w-screen bg-[#07090e] font-sans overflow-hidden">
      {/* Institutional Top Header */}
      <Header
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        userRole={userRole}
        setUserRole={setUserRole}
        activeScenario={activeScenario}
        setScenario={handleScenarioChange}
        systemHealth="100% OPERATIONAL"
      />

      {/* Main Workspace Display */}
      <main className="flex-1 flex flex-col overflow-hidden relative">
        {currentTab === "trading" && (
          <TradingTerminal
            marketData={marketData}
            orders={tradingData.orders}
            executions={tradingData.executions}
            positions={tradingData.positions}
            onPlaceOrder={handlePlaceOrder}
            userRole={userRole}
          />
        )}

        {currentTab === "rfq" && <RfqDesk />}

        {currentTab === "treasury" && (
          <TreasuryDesk treasuryData={treasuryData} userRole={userRole} />
        )}

        {currentTab === "risk" && (
          <RiskCockpit riskData={riskData} activeScenario={activeScenario} />
        )}

        {currentTab === "portfolio" && (
          <PortfolioView positions={tradingData.positions || []} />
        )}

        {currentTab === "operations" && (
          <OperationsView
            reconciliationData={reconciliationData}
            systemHealth="OPERATIONAL"
          />
        )}

        {currentTab === "executive" && (
          <ExecutiveView
            treasuryData={treasuryData}
            riskData={riskData}
            marketData={marketData}
            onSetScenario={handleScenarioChange}
          />
        )}

        {currentTab === "quant" && <QuantLab />}

        {currentTab === "ai" && (
          <RhinoIntelligence
            platformState={{ marketData, riskData, treasuryData, activeScenario }}
          />
        )}
      </main>

      {/* Persistent Bottom Status Bar */}
      <StatusBar
        riskState={riskState}
        liquidityState={marketData?.pegMonitor?.liquidity || "HIGH"}
        limitPct={82.0}
        todayPnlUsd={276000}
        pegPrice={pegPrice}
        pegDeviationBps={pegDev}
        activeScenario={activeScenario}
      />
    </div>
  );
}
