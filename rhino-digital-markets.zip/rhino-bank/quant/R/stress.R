# RHINO BANK QUANT RESEARCH LAB - STRESS TESTING & LIQUIDITY AT RISK
# Language: R

run_liquidity_stress_test <- function(inventory_usd, cash_usd, gov_secs_usd, scenarios = c(0.05, 0.10, 0.20, 0.30, 0.50, 0.75, 0.90)) {
  total_liquid_assets <- cash_usd + gov_secs_usd
  results <- data.frame(
    Scenario_Redemption_Pct = paste0(scenarios * 100, "%"),
    Redemption_Demand_USD = inventory_usd * scenarios,
    Available_Cash_Remaining = cash_usd - (inventory_usd * scenarios),
    Total_Liquidity_Post_Shock = total_liquid_assets - (inventory_usd * scenarios),
    Coverage_Status = ifelse((total_liquid_assets - (inventory_usd * scenarios)) > 0, "SOLVENT", "DEFICIT")
  )
  return(results)
}
