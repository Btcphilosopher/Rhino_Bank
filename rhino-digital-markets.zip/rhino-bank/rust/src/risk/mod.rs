use crate::oms::{Order, RiskStatus};
use rust_decimal::Decimal;
use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RiskLimits {
    pub max_notional_per_order: Decimal,
    pub max_net_position: Decimal,
    pub max_daily_loss: Decimal,
    pub max_var_bps: Decimal,
    pub max_concentration_pct: Decimal,
    pub sanctions_blocked: bool,
}

impl Default for RiskLimits {
    fn default() -> Self {
        Self {
            max_notional_per_order: Decimal::from(50_000_000), // $50M limit
            max_net_position: Decimal::from(200_000_000), // $200M position limit
            max_daily_loss: Decimal::from(5_000_000), // $5M loss cap
            max_var_bps: Decimal::from(150),
            max_concentration_pct: Decimal::from(35),
            sanctions_blocked: false,
        }
    }
}

pub struct PreTradeRiskEngine {
    pub limits: RiskLimits,
}

impl PreTradeRiskEngine {
    pub fn new(limits: RiskLimits) -> Self {
        Self { limits }
    }

    pub fn evaluate(&self, order: &mut Order, current_position: Decimal) -> RiskStatus {
        // 1. Sanctions / Compliance Check
        if self.limits.sanctions_blocked {
            let status = RiskStatus::Rejected("SANCTIONS_VIOLATION: Account flagged".to_string());
            order.risk_status = status.clone();
            return status;
        }

        // 2. Notional Limit Check
        let price = order.price.unwrap_or(Decimal::from(1));
        let notional = order.quantity * price;
        if notional > self.limits.max_notional_per_order {
            let status = RiskStatus::Rejected(format!(
                "NOTIONAL_LIMIT_EXCEEDED: Notional {} > Limit {}",
                notional, self.limits.max_notional_per_order
            ));
            order.risk_status = status.clone();
            return status;
        }

        // 3. Position Limit Check
        let future_position = match order.side {
            crate::oms::OrderSide::Buy => current_position + order.quantity,
            crate::oms::OrderSide::Sell => current_position - order.quantity,
        };
        if future_position.abs() > self.limits.max_net_position {
            let status = RiskStatus::Rejected(format!(
                "POSITION_LIMIT_EXCEEDED: Projected position {} > Limit {}",
                future_position.abs(), self.limits.max_net_position
            ));
            order.risk_status = status.clone();
            return status;
        }

        order.risk_status = RiskStatus::Passed;
        RiskStatus::Passed
    }
}
