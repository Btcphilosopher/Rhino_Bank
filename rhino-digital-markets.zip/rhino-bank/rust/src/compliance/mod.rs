use crate::oms::Order;
use rust_decimal::Decimal;

pub struct ComplianceEngine;

impl ComplianceEngine {
    pub fn check_anti_manipulation(order: &Order, recent_orders: &[Order]) -> Result<(), String> {
        // 1. Wash Trading Check (buying and selling from same account within short timeframe at same price)
        for prev in recent_orders {
            if prev.account_id == order.account_id 
                && prev.instrument == order.instrument 
                && prev.side != order.side 
                && prev.price == order.price 
            {
                let diff_sec = (order.timestamp - prev.timestamp).num_seconds();
                if diff_sec < 1 {
                    return Err("WASH_TRADING_FLAGGED: Opposite order placed within 1s at identical price".to_string());
                }
            }
        }
        
        // 2. Quote Stuffing Check (excessive order rate > 100/sec)
        let count_last_sec = recent_orders.iter()
            .filter(|o| (order.timestamp - o.timestamp).num_seconds() < 1)
            .count();
        if count_last_sec > 100 {
            return Err("QUOTE_STUFFING_FLAGGED: Order frequency exceeds threshold of 100/sec".to_string());
        }

        Ok(())
    }
}
