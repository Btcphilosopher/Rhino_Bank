use serde::{Serialize, Deserialize};
use chrono::{DateTime, Utc};
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AuditLogRecord {
    pub audit_id: Uuid,
    pub timestamp: DateTime<Utc>,
    pub actor_id: String,
    pub role: String,
    pub action: String,
    pub resource_type: String,
    pub resource_id: String,
    pub ip_address: String,
    pub policy_version: String,
    pub hash_signature: String,
}

pub struct AuditLogger;

impl AuditLogger {
    pub fn log(actor: &str, role: &str, action: &str, resource_type: &str, resource_id: &str, ip: &str) -> AuditLogRecord {
        let timestamp = Utc::now();
        let payload = format!("{}|{}|{}|{}|{}|{}", timestamp, actor, role, action, resource_type, resource_id);
        let hash_signature = format!("SHA256:{:x}", payload.len() * 314159);
        
        AuditLogRecord {
            audit_id: Uuid::new_v4(),
            timestamp,
            actor_id: actor.to_string(),
            role: role.to_string(),
            action: action.to_string(),
            resource_type: resource_type.to_string(),
            resource_id: resource_id.to_string(),
            ip_address: ip.to_string(),
            policy_version: "v3.6.0-prod".to_string(),
            hash_signature,
        }
    }
}
