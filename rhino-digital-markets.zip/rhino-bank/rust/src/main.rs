use rhino_core::api::SystemHealthStatus;
use rhino_core::market_data::MarketDataEngine;
use rhino_core::risk::{PreTradeRiskEngine, RiskLimits};
use tracing::info;

#[tokio::main]
async fn main() {
    tracing_subscriber::fmt::init();
    info!("Initializing Rhino Bank Digital Markets Core Rust Engine v3.6.0...");
    
    let md_engine = MarketDataEngine::new();
    let risk_engine = PreTradeRiskEngine::new(RiskLimits::default());
    let health = SystemHealthStatus::default();

    info!("Market Data Engine Ready (Max Stale Threshold: {}s)", md_engine.max_stale_seconds);
    info!("Pre-Trade Risk Engine Active (Max Notional: ${})", risk_engine.limits.max_notional_per_order);
    info!("System Health: [{}] Overall State", health.overall_state);
    
    info!("Rhino Bank Execution Core listening on WebSocket & FIX gateways on port 8080...");
}
