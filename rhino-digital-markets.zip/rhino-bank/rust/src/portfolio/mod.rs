use serde::{Serialize, Deserialize};
use rust_decimal::Decimal;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PortfolioState {
    pub total_nav_usd: Decimal,
    pub cash_fiat_usd: Decimal,
    pub stablecoin_inventory_usd: Decimal,
    pub collateral_allocated_usd: Decimal,
    pub gross_exposure_usd: Decimal,
    pub net_exposure_usd: Decimal,
    pub realized_pnl_today: Decimal,
    pub unrealized_pnl_today: Decimal,
    pub var_99_1d_usd: Decimal,
    pub expected_shortfall_usd: Decimal,
}

impl PortfolioState {
    pub fn calculate_nav(&mut self) {
        self.total_nav_usd = self.cash_fiat_usd + self.stablecoin_inventory_usd + self.collateral_allocated_usd;
    }
}
