use serde::{Serialize, Deserialize};
use rust_decimal::Decimal;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ReconciliationReport {
    pub trading_ledger_usd: Decimal,
    pub bank_ledger_usd: Decimal,
    pub stablecoin_network_usd: Decimal,
    pub custody_usd: Decimal,
    pub variance_usd: Decimal,
    pub is_balanced: bool,
}

pub struct ReconciliationEngine;

impl ReconciliationEngine {
    pub fn reconcile(trading: Decimal, bank: Decimal, chain: Decimal, custody: Decimal) -> ReconciliationReport {
        let variance = (trading - bank).abs() + (trading - chain).abs() + (trading - custody).abs();
        ReconciliationReport {
            trading_ledger_usd: trading,
            bank_ledger_usd: bank,
            stablecoin_network_usd: chain,
            custody_usd: custody,
            variance_usd: variance,
            is_balanced: variance == Decimal::from(0),
        }
    }
}
