use serde::{Serialize, Deserialize};
use rust_decimal::Decimal;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum ExecutionStrategy {
    BestPrice,
    MinimumSlippage,
    VWAP,
    TWAP,
    Iceberg { display_size: Decimal },
    Participation { rate_pct: Decimal },
    SmartRoute,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RouteVenueQuote {
    pub venue_id: String,
    pub price: Decimal,
    pub available_liquidity: Decimal,
    pub fee_bps: Decimal,
    pub latency_ms: u32,
    pub estimated_slippage_bps: Decimal,
}

pub struct SmartOrderRouter;

impl SmartOrderRouter {
    pub fn find_optimal_route(quotes: &[RouteVenueQuote], requested_size: Decimal) -> Option<&RouteVenueQuote> {
        // Filter venues with sufficient liquidity
        quotes.iter()
            .filter(|q| q.available_liquidity >= requested_size)
            .min_by(|a, b| {
                // Effective price = raw price + fees + slippage impact
                let eff_a = a.price * (Decimal::from(1) + (a.fee_bps + a.estimated_slippage_bps) / Decimal::from(10000));
                let eff_b = b.price * (Decimal::from(1) + (b.fee_bps + b.estimated_slippage_bps) / Decimal::from(10000));
                eff_a.partial_cmp(&eff_b).unwrap_or(std::cmp::Ordering::Equal)
            })
    }
}
