use serde::{Serialize, Deserialize};
use rust_decimal::Decimal;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TreasuryMetrics {
    pub total_liquidity: Decimal,
    pub available_cash: Decimal,
    pub stablecoin_inventory: Decimal,
    pub government_securities: Decimal,
    pub collateral_buffer: Decimal,
    pub liquidity_runway_30d_days: u32,
    pub liquidity_runway_90d_days: u32,
    pub redemption_coverage_ratio: Decimal,
}

pub struct TreasuryDesk;

impl TreasuryDesk {
    pub fn evaluate_redemption_shock(&self, metrics: &TreasuryMetrics, shock_pct: Decimal) -> Decimal {
        let redemption_demand = metrics.stablecoin_inventory * (shock_pct / Decimal::from(100));
        let remaining_liquidity = metrics.available_cash + metrics.government_securities - redemption_demand;
        remaining_liquidity
    }
}
