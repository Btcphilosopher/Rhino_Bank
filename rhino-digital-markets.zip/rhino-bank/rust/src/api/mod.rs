use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SystemHealthStatus {
    pub api_gateway: String,
    pub database: String,
    pub market_data: String,
    pub risk_engine: String,
    pub execution: String,
    pub settlement: String,
    pub reconciliation: String,
    pub overall_state: String,
}

impl Default for SystemHealthStatus {
    fn default() -> Self {
        Self {
            api_gateway: "ONLINE".to_string(),
            database: "ONLINE".to_string(),
            market_data: "ONLINE".to_string(),
            risk_engine: "ONLINE".to_string(),
            execution: "ONLINE".to_string(),
            settlement: "ONLINE".to_string(),
            reconciliation: "ONLINE".to_string(),
            overall_state: "HEALTHY".to_string(),
        }
    }
}
