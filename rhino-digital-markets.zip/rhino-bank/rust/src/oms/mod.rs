use serde::{Serialize, Deserialize};
use rust_decimal::Decimal;
use chrono::{DateTime, Utc};
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum OrderSide {
    Buy,
    Sell,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum OrderType {
    Market,
    Limit,
    Stop,
    StopLimit,
    IOC,
    FOK,
    GTC,
    Day,
    PostOnly,
    RFQ,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum RiskStatus {
    Pending,
    Passed,
    Rejected(String),
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum ExecutionStatus {
    New,
    PartiallyFilled,
    Filled,
    Cancelled,
    Rejected,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Order {
    pub order_id: Uuid,
    pub client_id: Uuid,
    pub account_id: Uuid,
    pub instrument: String,
    pub side: OrderSide,
    pub quantity: Decimal,
    pub price: Option<Decimal>,
    pub order_type: OrderType,
    pub time_in_force: String,
    pub venue: String,
    pub timestamp: DateTime<Utc>,
    pub risk_status: RiskStatus,
    pub execution_status: ExecutionStatus,
}

pub struct OrderManagementSystem;

impl OrderManagementSystem {
    pub fn new_order(
        client_id: Uuid,
        account_id: Uuid,
        instrument: String,
        side: OrderSide,
        quantity: Decimal,
        price: Option<Decimal>,
        order_type: OrderType,
        time_in_force: String,
        venue: String,
    ) -> Order {
        Order {
            order_id: Uuid::new_v4(),
            client_id,
            account_id,
            instrument,
            side,
            quantity,
            price,
            order_type,
            time_in_force,
            venue,
            timestamp: Utc::now(),
            risk_status: RiskStatus::Pending,
            execution_status: ExecutionStatus::New,
        }
    }
}
