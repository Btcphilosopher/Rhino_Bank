use serde::{Serialize, Deserialize};
use rust_decimal::Decimal;
use chrono::{DateTime, Utc};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MarketTick {
    pub timestamp: DateTime<Utc>,
    pub venue: String,
    pub instrument: String,
    pub sequence: u64,
    pub bid: Decimal,
    pub ask: Decimal,
    pub bid_size: Decimal,
    pub ask_size: Decimal,
    pub source: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SmartPrice {
    pub instrument: String,
    pub best_bid: Decimal,
    pub best_ask: Decimal,
    pub consolidated_mid: Decimal,
    pub effective_spread_bps: Decimal,
    pub total_bid_depth: Decimal,
    pub total_ask_depth: Decimal,
    pub venue_count: usize,
    pub anomaly_flag: Option<String>,
}

pub struct MarketDataEngine {
    pub max_stale_seconds: i64,
}

impl MarketDataEngine {
    pub fn new() -> Self {
        Self { max_stale_seconds: 3 }
    }

    pub fn validate_tick(&self, tick: &MarketTick, current_time: DateTime<Utc>) -> Result<(), String> {
        // Stale Price Check
        let age = (current_time - tick.timestamp).num_seconds();
        if age > self.max_stale_seconds {
            return Err(format!("STALE_PRICE: Tick age {}s exceeds threshold", age));
        }
        // Crossed / Locked Market Check
        if tick.bid >= tick.ask {
            return Err(format!("CROSSED_MARKET: Bid {} >= Ask {}", tick.bid, tick.ask));
        }
        // Abnormal Spread Check (> 500 bps)
        let mid = (tick.bid + tick.ask) / Decimal::from(2);
        let spread_bps = ((tick.ask - tick.bid) / mid) * Decimal::from(10000);
        if spread_bps > Decimal::from(500) {
            return Err(format!("ABNORMAL_SPREAD: Spread {} bps exceeds 500bps threshold", spread_bps));
        }
        Ok(())
    }

    pub fn aggregate_smart_price(&self, instrument: &str, ticks: &[MarketTick]) -> Option<SmartPrice> {
        if ticks.is_empty() {
            return None;
        }

        let best_bid = ticks.iter().map(|t| t.bid).max()?;
        let best_ask = ticks.iter().map(|t| t.ask).min()?;
        let mid = (best_bid + best_ask) / Decimal::from(2);
        let spread_bps = ((best_ask - best_bid) / mid) * Decimal::from(10000);
        let total_bid_depth: Decimal = ticks.iter().map(|t| t.bid_size).sum();
        let total_ask_depth: Decimal = ticks.iter().map(|t| t.ask_size).sum();

        let anomaly = if best_bid >= best_ask {
            Some("CROSSED_BOOK_DETECTED".to_string())
        } else {
            None
        };

        Some(SmartPrice {
            instrument: instrument.to_string(),
            best_bid,
            best_ask,
            consolidated_mid: mid,
            effective_spread_bps: spread_bps,
            total_bid_depth,
            total_ask_depth,
            venue_count: ticks.len(),
            anomaly_flag: anomaly,
        })
    }
}
