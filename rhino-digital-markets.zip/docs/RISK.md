# RHINO BANK DIGITAL MARKETS - QUANTITATIVE RISK & DEPEG RESPONSE MANUAL

## 1. Hierarchical Risk Limits
Limits are evaluated in cascade:
`BANK` -> `BUSINESS_UNIT` -> `DESK` -> `TRADER` -> `CLIENT` -> `ORDER`

## 2. Deterministic Depeg Escalation Policy
When a stablecoin moves away from target ($1.000000), the system transitions through policy-driven risk levels:
- **PEG = 1.00000 (NORMAL)**: Green state. Standard inventory limits and market making.
- **PEG = 0.99950 (-5.0 bps / AMBER)**: Alert triggered. Increase monitoring frequency to 100ms. Widen market-making spreads by 2.5 bps.
- **PEG = 0.99800 (-20.0 bps / RED)**: Reduce max notional order size by 50%. Pause automated arbitrage strategies. Require Senior Trader co-signing.
- **PEG = 0.99500 (-50.0 bps / CRITICAL)**: Activate Depeg Crisis Mode. Restrict buy/sell to redemption desk only. Lock speculative algorithmic routes.
- **PEG = 0.99000 (-100.0 bps / EMERGENCY)**: Halts secondary trading on affected stablecoin. Initiate automated Treasury reserve redemption protocol.

## 3. Monte Carlo Risk Metrics
- **P(PEG BREACH)**: 30-day simulated probability of price breaching [0.9950, 1.0050].
- **P(LIQUIDITY SHORTFALL)**: Probability of redemption requests exceeding immediate cash buffers.
- **VaR 99% & Expected Shortfall (CVaR)**: Quantifies tail risk loss under severe market stress.
