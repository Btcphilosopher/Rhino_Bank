# RHINO BANK DIGITAL MARKETS - ARCHITECTURE SPECIFICATION

## 1. Overview & Separation of Concerns
Rhino Bank Digital Markets decouples the **Stablecoin Monetary System** (issuance, reserve backing, burn/mint authority) from the **Stablecoin Trading System** (order routing, pricing, market making, clearing). The trading system does NOT mint or alter money independently; it interacts exclusively via authorized RFQ / API issuance gateways.

## 2. Component Pipeline
```
                    RHINO BANK
                         │
              ┌──────────▼──────────┐
              │ DIGITAL MARKETS UI   │ (React + TypeScript Desktop UI)
              └──────────┬──────────┘
                         │
              ┌──────────▼──────────┐
              │ API / SESSION LAYER │ (Next.js 15 API & Auth Gateway)
              └──────────┬──────────┘
                         │
          ┌──────────────┼───────────────┐
          │              │               │
      ORDER MGMT      TREASURY        RISK
          │              │               │
          └──────────────┼───────────────┘
                         │
                 EXECUTION ENGINE (Rust High-Performance Core)
                         │
        ┌────────────────┼─────────────────┐
        │                │                 │
      VENUES          OTC/RFQ         INTERNAL
        │                │             LIQUIDITY
        └────────────────┼─────────────────┘
                         │
                  SETTLEMENT ENGINE
                         │
              STABLECOIN NETWORK (Atomic DVP / RTGS)
```

## 3. Key Subsystems
- **Market Data Engine**: Normalizes quotes from Venue A, Venue B, Venue C, and Internal Desk. Calculates Smart Price, best bid/ask, VWAP, TWAP, and detects stale/crossed markets.
- **Pre-Trade Risk Engine**: Evaluates limits (Notional, Position, Daily Loss, Sanctions) before order submission.
- **Smart Order Router (SOR)**: Executes orders against optimal liquidity pools considering fees, latency, and slippage.
- **R Quant Lab**: Asynchronous quantitative research lab calculating VaR (99%), Expected Shortfall, Monte Carlo peg breach probabilities, and stress scenario matrices.
