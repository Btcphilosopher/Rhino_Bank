-- RHINO BANK DIGITAL MARKETS - INSTITUTIONAL POSTGRESQL DDL SCHEMA
-- Schema Version: 3.6.0
-- Isolation Level: Serializable / Read Committed

CREATE SCHEMA IF NOT EXISTS rhino_markets;

-- 1. USERS & ACCESS CONTROL (RBAC)
CREATE TABLE IF NOT EXISTS rhino_markets.users (
    user_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    username VARCHAR(64) UNIQUE NOT NULL,
    email VARCHAR(128) UNIQUE NOT NULL,
    role VARCHAR(32) NOT NULL, -- TRADER, SENIOR_TRADER, TREASURY_MANAGER, RISK_OFFICER, COMPLIANCE_OFFICER, OPERATIONS, SETTLEMENT, ADMINISTRATOR, AUDITOR, EXECUTIVE
    mfa_enabled BOOLEAN DEFAULT TRUE,
    session_ip_allowlist TEXT[],
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(16) DEFAULT 'ACTIVE'
);

-- 2. ACCOUNTS & COUNTERPARTIES
CREATE TABLE IF NOT EXISTS rhino_markets.accounts (
    account_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    account_name VARCHAR(128) NOT NULL,
    account_type VARCHAR(32) NOT NULL, -- INTERNAL_TREASURY, CLIENT_INSTITUTIONAL, LP_DESK, SETTLEMENT_ESCROW
    currency VARCHAR(8) NOT NULL,
    credit_limit DECIMAL(20, 4) DEFAULT 100000000.0000,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS rhino_markets.counterparties (
    counterparty_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(128) NOT NULL,
    lei_code VARCHAR(20) UNIQUE, -- Legal Entity Identifier
    tier VARCHAR(16) NOT NULL, -- TIER_1_BANK, PRIME_BROKER, LIQUIDITY_PROVIDER, ISSUER
    rating VARCHAR(8) DEFAULT 'AA',
    settlement_network VARCHAR(32) NOT NULL,
    status VARCHAR(16) DEFAULT 'APPROVED'
);

-- 3. INSTRUMENTS (STABLECOINS & FX PAIRS)
CREATE TABLE IF NOT EXISTS rhino_markets.instruments (
    instrument_id VARCHAR(16) PRIMARY KEY, -- USDSTBL, GBPSTBL, EURSTBL, JPYSTBL, CHFSTBL, USD/GBP, USD/EUR
    base_currency VARCHAR(8) NOT NULL,
    quote_currency VARCHAR(8) NOT NULL,
    peg_target DECIMAL(12, 6) DEFAULT 1.000000,
    tick_size DECIMAL(12, 6) DEFAULT 0.000100,
    lot_size DECIMAL(16, 4) DEFAULT 1000.0000,
    min_order_notional DECIMAL(16, 4) DEFAULT 10000.0000,
    max_order_notional DECIMAL(16, 4) DEFAULT 50000000.0000,
    status VARCHAR(16) DEFAULT 'ACTIVE'
);

-- 4. MARKET DATA & VENUES
CREATE TABLE IF NOT EXISTS rhino_markets.venues (
    venue_id VARCHAR(16) PRIMARY KEY, -- VENUE_A, VENUE_B, VENUE_C, RHINO_INTERNAL
    name VARCHAR(64) NOT NULL,
    venue_type VARCHAR(32) NOT NULL, -- ECN, DIRECT_DEALER, INTERNAL_DESK
    latency_ms INT DEFAULT 2,
    fee_bps DECIMAL(6, 2) DEFAULT 0.50,
    status VARCHAR(16) DEFAULT 'ONLINE'
);

CREATE TABLE IF NOT EXISTS rhino_markets.market_data (
    tick_id BIGSERIAL PRIMARY KEY,
    timestamp TIMESTAMPTZ NOT NULL,
    venue_id VARCHAR(16) REFERENCES rhino_markets.venues(venue_id),
    instrument_id VARCHAR(16) REFERENCES rhino_markets.instruments(instrument_id),
    sequence_id BIGINT NOT NULL,
    bid_price DECIMAL(12, 6) NOT NULL,
    ask_price DECIMAL(12, 6) NOT NULL,
    bid_size DECIMAL(16, 4) NOT NULL,
    ask_size DECIMAL(16, 4) NOT NULL,
    vwap DECIMAL(12, 6),
    is_stale BOOLEAN DEFAULT FALSE,
    is_crossed BOOLEAN DEFAULT FALSE
);

CREATE INDEX idx_market_data_inst_ts ON rhino_markets.market_data (instrument_id, timestamp DESC);

-- 5. ORDERS & EXECUTIONS (OMS)
CREATE TABLE IF NOT EXISTS rhino_markets.orders (
    order_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id UUID REFERENCES rhino_markets.users(user_id),
    account_id UUID REFERENCES rhino_markets.accounts(account_id),
    instrument_id VARCHAR(16) REFERENCES rhino_markets.instruments(instrument_id),
    side VARCHAR(4) NOT NULL, -- BUY, SELL
    quantity DECIMAL(16, 4) NOT NULL,
    price DECIMAL(12, 6),
    order_type VARCHAR(16) NOT NULL, -- MARKET, LIMIT, STOP, STOP_LIMIT, IOC, FOK, GTC, DAY, POST_ONLY, RFQ
    time_in_force VARCHAR(8) NOT NULL, -- IOC, FOK, GTC, DAY
    venue_id VARCHAR(16) REFERENCES rhino_markets.venues(venue_id),
    risk_status VARCHAR(16) NOT NULL, -- PASSED, REJECTED, PENDING_APPROVAL
    execution_status VARCHAR(16) NOT NULL, -- NEW, PARTIALLY_FILLED, FILLED, CANCELLED, REJECTED
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS rhino_markets.executions (
    execution_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID REFERENCES rhino_markets.orders(order_id),
    instrument_id VARCHAR(16) REFERENCES rhino_markets.instruments(instrument_id),
    side VARCHAR(4) NOT NULL,
    filled_quantity DECIMAL(16, 4) NOT NULL,
    filled_price DECIMAL(12, 6) NOT NULL,
    fee_amount DECIMAL(16, 4) NOT NULL,
    slippage_bps DECIMAL(8, 2) NOT NULL,
    executed_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 6. POSITIONS & BALANCES
CREATE TABLE IF NOT EXISTS rhino_markets.positions (
    position_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    account_id UUID REFERENCES rhino_markets.accounts(account_id),
    instrument_id VARCHAR(16) REFERENCES rhino_markets.instruments(instrument_id),
    net_position DECIMAL(16, 4) DEFAULT 0.0000,
    average_entry_price DECIMAL(12, 6) DEFAULT 0.000000,
    realized_pnl DECIMAL(16, 4) DEFAULT 0.0000,
    unrealized_pnl DECIMAL(16, 4) DEFAULT 0.0000,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS rhino_markets.balances (
    balance_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    account_id UUID REFERENCES rhino_markets.accounts(account_id),
    currency VARCHAR(8) NOT NULL,
    cash_amount DECIMAL(20, 4) DEFAULT 0.0000,
    stablecoin_inventory DECIMAL(20, 4) DEFAULT 0.0000,
    collateral_allocated DECIMAL(20, 4) DEFAULT 0.0000,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 7. RISK LIMITS & EVENTS
CREATE TABLE IF NOT EXISTS rhino_markets.risk_limits (
    limit_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    level VARCHAR(32) NOT NULL, -- BANK, BUSINESS_UNIT, DESK, TRADER, CLIENT, ORDER
    entity_id VARCHAR(64) NOT NULL,
    max_notional DECIMAL(20, 4) NOT NULL,
    max_net_exposure DECIMAL(20, 4) NOT NULL,
    max_daily_loss DECIMAL(20, 4) NOT NULL,
    max_var DECIMAL(20, 4) NOT NULL,
    status VARCHAR(16) DEFAULT 'ACTIVE'
);

CREATE TABLE IF NOT EXISTS rhino_markets.risk_events (
    event_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    timestamp TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    severity VARCHAR(16) NOT NULL, -- INFO, AMBER, RED, CRITICAL
    category VARCHAR(32) NOT NULL, -- PEG_BREACH, LIMIT_VIOLATION, LIQUIDITY_SHOCK, VENUE_OUTAGE
    description TEXT NOT NULL,
    resolved BOOLEAN DEFAULT FALSE
);

-- 8. SETTLEMENT & RECONCILIATION
CREATE TABLE IF NOT EXISTS rhino_markets.settlements (
    settlement_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    execution_id UUID REFERENCES rhino_markets.executions(execution_id),
    counterparty_id UUID REFERENCES rhino_markets.counterparties(counterparty_id),
    delivery_asset VARCHAR(16) NOT NULL,
    settlement_amount DECIMAL(20, 4) NOT NULL,
    settlement_mode VARCHAR(32) NOT NULL, -- ATOMIC_ON_CHAIN, NET_END_OF_DAY, RTGS
    status VARCHAR(16) DEFAULT 'PENDING'
);

CREATE TABLE IF NOT EXISTS rhino_markets.reconciliations (
    reconciliation_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    timestamp TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    trading_ledger_sum DECIMAL(20, 4) NOT NULL,
    bank_ledger_sum DECIMAL(20, 4) NOT NULL,
    blockchain_ledger_sum DECIMAL(20, 4) NOT NULL,
    mismatch_detected BOOLEAN DEFAULT FALSE,
    variance DECIMAL(16, 4) DEFAULT 0.0000,
    status VARCHAR(16) DEFAULT 'BALANCED'
);

-- 9. IMMUTABLE AUDIT TRAIL
CREATE TABLE IF NOT EXISTS rhino_markets.audit_events (
    audit_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    timestamp TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    actor_id VARCHAR(64) NOT NULL,
    role VARCHAR(32) NOT NULL,
    action VARCHAR(64) NOT NULL,
    resource_type VARCHAR(32) NOT NULL,
    resource_id VARCHAR(64) NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    policy_version VARCHAR(16) NOT NULL,
    hash_signature VARCHAR(128) NOT NULL
);
