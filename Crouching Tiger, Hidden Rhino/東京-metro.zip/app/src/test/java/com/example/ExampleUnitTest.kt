package com.example

import com.example.engine.*
import com.example.model.*
import org.junit.Assert.*
import org.junit.Test
import java.util.*

class ExampleUnitTest {

    // ==========================================
    // 1. TICKET LIFECYCLE & ENGINE TESTS
    // ==========================================
    @Test
    fun testTicketPurchaseAndActivation() {
        val productId = TicketProductEngine.SUBWAY_72H.id
        
        // Purchase
        val ticket = TicketLifecycleEngine.purchaseTicket(
            productId = productId,
            passengerType = PassengerType.ADULT,
            quantity = 1,
            isDemo = true
        )

        assertEquals(TicketStatus.PURCHASED, ticket.status)
        assertEquals(productId, ticket.productId)
        assertEquals(2000, ticket.pricePaid)
        assertTrue(ticket.isDemo)
        assertTrue(ticket.ticketId.contains("DEMO"))

        // Activate
        val activatedTicket = TicketLifecycleEngine.activateTicket(ticket)
        assertEquals(TicketStatus.ACTIVATED, activatedTicket.status)
        assertNotNull(activatedTicket.validFrom)
        assertNotNull(activatedTicket.validUntil)
        
        // Exact 72 hours check: 72 * 3600 * 1000
        val expectedDuration = 72 * 3600 * 1000L
        assertEquals(expectedDuration, activatedTicket.validUntil!! - activatedTicket.validFrom!!)
        
        // Display QR (contains verification mode)
        assertTrue(activatedTicket.qrPayload.contains("ticket_id"))
        assertTrue(activatedTicket.qrPayload.contains(ticket.ticketId))
        assertTrue(activatedTicket.qrPayload.contains("signature"))
    }

    @Test
    fun testTicketStatusTransitionsAndExpiration() {
        val productId = TicketProductEngine.METRO_24H.id
        val ticket = TicketLifecycleEngine.purchaseTicket(
            productId = productId,
            passengerType = PassengerType.CHILD,
            quantity = 2,
            isDemo = false
        )

        assertEquals(TicketStatus.PURCHASED, ticket.status)
        // Child 24h Metro ticket is ¥350. Total for 2 = ¥700
        assertEquals(700, ticket.pricePaid)

        val activated = TicketLifecycleEngine.activateTicket(ticket)
        
        // Verify expiration calculation in status check
        val statusInitially = TicketLifecycleEngine.getTicketStatus(activated)
        assertEquals(TicketStatus.VALID, statusInitially)

        // Mock a future ticket that is past expiration
        val expiredMockTicket = activated.copy(
            validUntil = System.currentTimeMillis() - 1000L // 1 second ago
        )
        val statusExpired = TicketLifecycleEngine.getTicketStatus(expiredMockTicket)
        assertEquals(TicketStatus.EXPIRED, statusExpired)
    }

    @Test
    fun testTicketRefundAndCancel() {
        val ticket = TicketLifecycleEngine.purchaseTicket(
            productId = TicketProductEngine.COMMON_1DAY.id,
            passengerType = PassengerType.ADULT,
            quantity = 1,
            isDemo = true
        )

        // Initial purchased tickets are fully refundable
        assertEquals(TicketStatus.PURCHASED, ticket.status)
        val refunded = ticket.copy(status = TicketStatus.REFUNDED)
        assertEquals(TicketStatus.REFUNDED, refunded.status)
    }

    // ==========================================
    // 2. PASS COVERAGE & MULTI-HOURS VALIDITY
    // ==========================================
    @Test
    fun testPassValidityHours() {
        // 24h Pass
        val p24 = TicketProductEngine.SUBWAY_24H
        assertEquals(24, p24.validityHours)
        assertEquals(1000, p24.priceAdult)

        // 48h Pass
        val p48 = TicketProductEngine.SUBWAY_48H
        assertEquals(48, p48.validityHours)
        assertEquals(1500, p48.priceAdult)

        // 72h Pass
        val p72 = TicketProductEngine.SUBWAY_72H
        assertEquals(72, p72.validityHours)
        assertEquals(2000, p72.priceAdult)
    }

    // ==========================================
    // 3. ROUTE COMPILATION & OPERATOR COGNIZANCE
    // ==========================================
    @Test
    fun testSubwayRoutingEngine() {
        // Ginza (G09) -> Shibuya (G01) (Direct Metro Ginza Line)
        val routesDirect = RouteEngine.planRoutes("GINZA", "SHIBUYA")
        assertFalse(routesDirect.isEmpty())
        
        val fastestDirect = routesDirect.first()
        assertEquals(0, fastestDirect.transferCount)
        assertEquals("G", fastestDirect.legs.first().lineCode)
        assertEquals(Operator.TOKYO_METRO, fastestDirect.legs.first().operator)

        // Asakusa (Toei A) -> Roppongi (Toei E)
        val routesToei = RouteEngine.planRoutes("ASAKUSA", "ROPPONGI")
        assertFalse(routesToei.isEmpty())
        val toeiJourney = routesToei.find { j -> j.legs.any { it.operator == Operator.TOEI_SUBWAY } }
        assertNotNull(toeiJourney)
    }

    @Test
    fun testMultiOperatorAndJRInteroperability() {
        // Tokyo -> Shinjuku via JR East
        val routesJR = RouteEngine.planRoutes("TOKYO", "SHINJUKU")
        assertFalse(routesJR.isEmpty())
        
        val jrJourney = routesJR.find { j -> j.legs.any { it.operator == Operator.JR_EAST } }
        assertNotNull(jrJourney)
        assertEquals(Operator.JR_EAST, jrJourney?.legs?.first()?.operator)
    }

    // ==========================================
    // 4. FARE ENGINE COMPARISONS & PASS ADVISORY
    // ==========================================
    @Test
    fun testFareCalculationRules() {
        // Tokyo Metro 5km trip Adult = ¥180
        val metroFare = FareEngine.calculateSingleFare(listOf(Operator.TOKYO_METRO), 5.0, PassengerType.ADULT)
        assertEquals(180, metroFare)

        // Toei Subway 5km trip Child = ¥115 (230 / 2)
        val toeiChildFare = FareEngine.calculateSingleFare(listOf(Operator.TOEI_SUBWAY), 5.0, PassengerType.CHILD)
        assertEquals(115, toeiChildFare)

        // Inter-operator transfer (Metro + Toei 10km total): sum of half distance fares minus ¥70 discount
        // 5km Metro = 180, 5km Toei = 230. Total = 180 + 230 - 70 = 340
        val transferFare = FareEngine.calculateSingleFare(listOf(Operator.TOKYO_METRO, Operator.TOEI_SUBWAY), 10.0, PassengerType.ADULT)
        assertEquals(340, transferFare)
    }

    @Test
    fun testPassRecommendationLogic() {
        // Single fare trips today: 3 trips costing ¥340 each. Total = ¥1020
        val faresToday = listOf(340, 340, 340)
        val recommendation = FareEngine.recommendPass(faresToday)
        
        // Since ¥1020 is >= ¥1000, Subway 24h (¥1000) should be recommended!
        assertNotNull(recommendation)
        assertEquals(TicketProductEngine.SUBWAY_24H.id, recommendation?.id)
    }

    // ==========================================
    // 5. MIDNIGHT BOUNDARIES & TIME ENGINE
    // ==========================================
    @Test
    fun testMidnightAndTimeBoundaries() {
        // Simulate activation at 23:59 on the Common One-Day Ticket
        val product = TicketProductEngine.COMMON_1DAY
        val ticket = TicketLifecycleEngine.purchaseTicket(product.id, PassengerType.ADULT, 1, true)
        
        val baseTime = System.currentTimeMillis()
        val calendar = Calendar.getInstance(TimeZone.getTimeZone("Asia/Tokyo")).apply {
            timeInMillis = baseTime
            set(Calendar.HOUR_OF_DAY, 23)
            set(Calendar.MINUTE, 59)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val activationTime = calendar.timeInMillis
        
        val calendarUntil = Calendar.getInstance(TimeZone.getTimeZone("Asia/Tokyo")).apply {
            timeInMillis = baseTime
            set(Calendar.HOUR_OF_DAY, 23)
            set(Calendar.MINUTE, 59)
            set(Calendar.SECOND, 59)
            set(Calendar.MILLISECOND, 999)
        }
        val expectedUntil = calendarUntil.timeInMillis
        
        // Custom activation to simulate time bounds precisely
        val activated = ticket.copy(
            status = TicketStatus.ACTIVATED,
            activationTime = activationTime,
            validFrom = activationTime,
            validUntil = expectedUntil
        )

        assertEquals(expectedUntil, activated.validUntil)
        // Duration should be exactly 59 seconds and 999 milliseconds
        assertEquals(59999L, activated.validUntil!! - activated.validFrom!!)
    }
}
