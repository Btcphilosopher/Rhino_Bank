package com.example.engine

import com.example.model.*
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.*

// ==========================================
// 1. TICKET PRODUCT ENGINE
// ==========================================
object TicketProductEngine {
    val METRO_24H = TicketProduct(
        id = "METRO_24H",
        nameJa = "東京メトロ 24時間券",
        nameEn = "Tokyo Metro 24-hour Ticket",
        priceAdult = 700,
        priceChild = 350,
        validityHours = 24,
        operators = listOf(Operator.TOKYO_METRO)
    )

    val SUBWAY_24H = TicketProduct(
        id = "SUBWAY_24H",
        nameJa = "Tokyo Subway Ticket 24時間",
        nameEn = "Tokyo Subway Ticket 24-hour",
        priceAdult = 1000,
        priceChild = 500,
        validityHours = 24,
        operators = listOf(Operator.TOKYO_METRO, Operator.TOEI_SUBWAY)
    )

    val SUBWAY_48H = TicketProduct(
        id = "SUBWAY_48H",
        nameJa = "Tokyo Subway Ticket 48時間",
        nameEn = "Tokyo Subway Ticket 48-hour",
        priceAdult = 1500,
        priceChild = 750,
        validityHours = 48,
        operators = listOf(Operator.TOKYO_METRO, Operator.TOEI_SUBWAY)
    )

    val SUBWAY_72H = TicketProduct(
        id = "SUBWAY_72H",
        nameJa = "Tokyo Subway Ticket 72時間",
        nameEn = "Tokyo Subway Ticket 72-hour",
        priceAdult = 2000,
        priceChild = 1000,
        validityHours = 72,
        operators = listOf(Operator.TOKYO_METRO, Operator.TOEI_SUBWAY)
    )

    val COMMON_1DAY = TicketProduct(
        id = "COMMON_1DAY",
        nameJa = "東京メトロ・都営地下鉄共通一日乗車券",
        nameEn = "Common One-Day Ticket",
        priceAdult = 1100,
        priceChild = 550,
        validityHours = 24, // Reset at 23:59:59 but represented as 24
        operators = listOf(Operator.TOKYO_METRO, Operator.TOEI_SUBWAY)
    )

    val BUNDLE_SKYTREE = TicketProduct(
        id = "BUNDLE_SKYTREE",
        nameJa = "Subway 24h + 東京スカイツリー展望台",
        nameEn = "Subway 24h + Tokyo Skytree Combo",
        priceAdult = 3100,
        priceChild = 1550,
        validityHours = 24,
        operators = listOf(Operator.TOKYO_METRO, Operator.TOEI_SUBWAY),
        isBundle = true,
        bundleDescription = "Tokyo Subway 24-hour Ticket + Tokyo Skytree Tembo Deck (350m) entry ticket."
    )

    val BUNDLE_TOWER = TicketProduct(
        id = "BUNDLE_TOWER",
        nameJa = "Subway 24h + 東京タワー展望台",
        nameEn = "Subway 24h + Tokyo Tower Combo",
        priceAdult = 2200,
        priceChild = 1100,
        validityHours = 24,
        operators = listOf(Operator.TOKYO_METRO, Operator.TOEI_SUBWAY),
        isBundle = true,
        bundleDescription = "Tokyo Subway 24-hour Ticket + Tokyo Tower Main Deck (150m) entry ticket."
    )

    val ALL_PRODUCTS = listOf(
        METRO_24H,
        SUBWAY_24H,
        SUBWAY_48H,
        SUBWAY_72H,
        COMMON_1DAY,
        BUNDLE_SKYTREE,
        BUNDLE_TOWER
    )

    fun getProductById(id: String): TicketProduct? {
        return ALL_PRODUCTS.find { it.id == id }
    }
}

// ==========================================
// 2. FARE ENGINE
// ==========================================
object FareEngine {
    fun calculateSingleFare(
        operators: List<Operator>,
        distanceKm: Double,
        passengerType: PassengerType
    ): Int {
        var fare = 0
        val hasMetro = operators.contains(Operator.TOKYO_METRO)
        val hasToei = operators.contains(Operator.TOEI_SUBWAY)

        if (hasMetro && hasToei) {
            // Tokyo Metro + Toei transfer: sum with ¥70 discount
            val metroFare = calculateMetroFare(distanceKm / 2.0)
            val toeiFare = calculateToeiFare(distanceKm / 2.0)
            fare = metroFare + toeiFare - 70
        } else if (hasMetro) {
            fare = calculateMetroFare(distanceKm)
        } else if (hasToei) {
            fare = calculateToeiFare(distanceKm)
        } else {
            // Non-subway operators (JR, Keikyu, Keisei, etc.)
            fare = when {
                operators.contains(Operator.JR_EAST) -> {
                    // JR base distance fare
                    if (distanceKm <= 5) 150 else if (distanceKm <= 10) 170 else 220
                }
                operators.contains(Operator.KEIKYU) -> 250
                operators.contains(Operator.KEISEI) -> 320
                else -> 200
            }
        }

        return if (passengerType == PassengerType.CHILD) (fare / 2) else fare
    }

    private fun calculateMetroFare(distance: Double): Int {
        return when {
            distance <= 6.0 -> 180
            distance <= 11.0 -> 210
            distance <= 19.0 -> 260
            distance <= 27.0 -> 300
            else -> 340
        }
    }

    private fun calculateToeiFare(distance: Double): Int {
        return when {
            distance <= 4.0 -> 180
            distance <= 9.0 -> 230
            distance <= 15.0 -> 280
            distance <= 21.0 -> 330
            else -> 380
        }
    }

    // Pass Recommendation Logic
    fun recommendPass(itineraryFares: List<Int>): TicketProduct? {
        val totalSingleCost = itineraryFares.sum()
        if (totalSingleCost >= 2000) {
            return TicketProductEngine.SUBWAY_72H
        } else if (totalSingleCost >= 1500) {
            return TicketProductEngine.SUBWAY_48H
        } else if (totalSingleCost >= 1000) {
            return TicketProductEngine.SUBWAY_24H
        } else if (totalSingleCost >= 700) {
            return TicketProductEngine.METRO_24H
        }
        return null
    }
}

// ==========================================
// 3. QR TICKET ENGINE
// ==========================================
object QRTicketEngine {
    private const val SECRET_HMAC_KEY = "TOKYO_METRO_PASSENGER_OS_SECURE_HMAC_TOKEN"

    fun generateQR(
        ticketId: String,
        productId: String,
        passengerType: PassengerType,
        validFrom: Long?,
        validUntil: Long?,
        isDemo: Boolean
    ): String {
        val canonicalPayload = "ticket_id:$ticketId|product:$productId|passenger:${passengerType.name}|from:${validFrom ?: 0}|until:${validUntil ?: 0}|demo:$isDemo"
        val signature = hmacSha256(canonicalPayload, SECRET_HMAC_KEY)
        
        // Return structured canonical payload
        return """
            {
              "ticket_id": "$ticketId",
              "issuer": "Tokyo Metro Co., Ltd.",
              "product": "$productId",
              "valid_from": ${validFrom ?: 0},
              "valid_until": ${validUntil ?: 0},
              "is_demo": $isDemo,
              "signature": "$signature"
            }
        """.trimIndent()
    }

    private fun hmacSha256(data: String, key: String): String {
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val hash = digest.digest((data + key).toByteArray(Charsets.UTF_8))
            hash.joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            "MOCK_SIGNATURE_VERIFIED_7c402abf"
        }
    }
}

// ==========================================
// 4. TICKET LIFECYCLE ENGINE
// ==========================================
object TicketLifecycleEngine {
    fun purchaseTicket(
        productId: String,
        passengerType: PassengerType,
        quantity: Int,
        isDemo: Boolean = true
    ): DigitalTicket {
        val product = TicketProductEngine.getProductById(productId)
            ?: throw IllegalArgumentException("Invalid product id: $productId")
        
        val ticketId = "METRO-${if (isDemo) "DEMO" else "PROD"}-${UUID.randomUUID().toString().take(8).uppercase()}"
        val pricePaid = if (passengerType == PassengerType.ADULT) product.priceAdult * quantity else product.priceChild * quantity
        val purchaseTime = System.currentTimeMillis()

        return DigitalTicket(
            ticketId = ticketId,
            productId = productId,
            productNameEn = product.nameEn,
            productNameJa = product.nameJa,
            issuer = "Tokyo Metro Co., Ltd.",
            passengerType = passengerType,
            quantity = quantity,
            pricePaid = pricePaid,
            purchaseTime = purchaseTime,
            activationTime = null,
            validFrom = null,
            validUntil = null,
            status = TicketStatus.PURCHASED,
            qrPayload = "",
            signature = "",
            isDemo = isDemo
        )
    }

    fun activateTicket(ticket: DigitalTicket): DigitalTicket {
        if (ticket.status != TicketStatus.PURCHASED) {
            return ticket // Cannot re-activate
        }
        val product = TicketProductEngine.getProductById(ticket.productId)
            ?: return ticket

        val activationTime = System.currentTimeMillis()
        val validFrom = activationTime
        
        // Calculate exact validity expiration
        val validUntil = if (ticket.productId == TicketProductEngine.COMMON_1DAY.id) {
            // Common One-Day Ticket: ends at 23:59:59 of activation day (Tokyo Time)
            val cal = Calendar.getInstance(TimeZone.getTimeZone("Asia/Tokyo"))
            cal.timeInMillis = activationTime
            cal.set(Calendar.HOUR_OF_DAY, 23)
            cal.set(Calendar.MINUTE, 59)
            cal.set(Calendar.SECOND, 59)
            cal.set(Calendar.MILLISECOND, 999)
            cal.timeInMillis
        } else {
            // 24h, 48h, 72h ticket
            activationTime + (product.validityHours * 3600 * 1000L)
        }

        val qr = QRTicketEngine.generateQR(
            ticketId = ticket.ticketId,
            productId = ticket.productId,
            passengerType = ticket.passengerType,
            validFrom = validFrom,
            validUntil = validUntil,
            isDemo = ticket.isDemo
        )

        return ticket.copy(
            status = TicketStatus.ACTIVATED,
            activationTime = activationTime,
            validFrom = validFrom,
            validUntil = validUntil,
            qrPayload = qr,
            signature = "VERIFIED-HMAC-256"
        )
    }

    fun getTicketStatus(ticket: DigitalTicket): TicketStatus {
        if (ticket.status != TicketStatus.ACTIVATED && ticket.status != TicketStatus.VALID) {
            return ticket.status
        }
        val current = System.currentTimeMillis()
        val until = ticket.validUntil ?: return ticket.status
        return if (current > until) {
            TicketStatus.EXPIRED
        } else {
            TicketStatus.VALID
        }
    }
}

// ==========================================
// 5. ROUTE & JOURNEY & STATION ENGINE
// ==========================================
object RouteEngine {
    val STATIONS = listOf(
        Station("TOKYO", "東京", "Tokyo", listOf(Operator.TOKYO_METRO, Operator.JR_EAST), listOf("M"), 35.681167, 139.767052, listOf("M17", "Marunouchi Exit", "Yaesu Exit")),
        Station("GINZA", "銀座", "Ginza", listOf(Operator.TOKYO_METRO), listOf("G", "M", "H"), 35.671914, 139.763953, listOf("A1", "A2", "B1", "C2", "C4")),
        Station("SHINJUKU", "新宿", "Shinjuku", listOf(Operator.TOKYO_METRO, Operator.TOEI_SUBWAY, Operator.JR_EAST), listOf("M", "E"), 35.689622, 139.700346, listOf("A10", "B12", "E27 Exit")),
        Station("SHIBUYA", "渋谷", "Shibuya", listOf(Operator.TOKYO_METRO, Operator.JR_EAST, Operator.TOKYU), listOf("G", "Z", "F"), 35.658034, 139.701636, listOf("A1", "A6", "Hachiko Exit")),
        Station("ASAKUSA", "浅草", "Asakusa", listOf(Operator.TOKYO_METRO, Operator.TOEI_SUBWAY), listOf("G", "A"), 35.711516, 139.796555, listOf("A4", "A5", "Kaminarimon Exit")),
        Station("UENO", "上野", "Ueno", listOf(Operator.TOKYO_METRO, Operator.JR_EAST), listOf("G", "H"), 35.713768, 139.777254, listOf("A1", "A2", "Central Exit")),
        Station("ROPPONGI", "六本木", "Roppongi", listOf(Operator.TOKYO_METRO, Operator.TOEI_SUBWAY), listOf("H", "E"), 35.662758, 139.731211, listOf("1A", "1B", "3", "4A")),
        Station("HANEDA", "羽田空港", "Haneda Airport", listOf(Operator.KEIKYU), listOf("KK"), 35.548480, 139.784115, listOf("Terminal 1 & 2 Exit")),
        Station("NARITA", "成田空港", "Narita Airport", listOf(Operator.KEISEI, Operator.JR_EAST), listOf("KS"), 35.765620, 140.386220, listOf("Skyliner Terminal Exit"))
    )

    data class Edge(
        val fromId: String,
        val toId: String,
        val lineCode: String,
        val lineNameEn: String,
        val operator: Operator,
        val durationMinutes: Int,
        val distanceKm: Double
    )

    val EDGES = listOf(
        Edge("TOKYO", "GINZA", "M", "Marunouchi Line", Operator.TOKYO_METRO, 2, 1.2),
        Edge("GINZA", "SHINJUKU", "M", "Marunouchi Line", Operator.TOKYO_METRO, 15, 7.5),
        Edge("GINZA", "UENO", "G", "Ginza Line", Operator.TOKYO_METRO, 11, 5.3),
        Edge("UENO", "ASAKUSA", "G", "Ginza Line", Operator.TOKYO_METRO, 5, 2.2),
        Edge("GINZA", "SHIBUYA", "G", "Ginza Line", Operator.TOKYO_METRO, 16, 7.0),
        Edge("GINZA", "ROPPONGI", "H", "Hibiya Line", Operator.TOKYO_METRO, 9, 3.8),
        Edge("SHINJUKU", "ROPPONGI", "E", "Oedo Line", Operator.TOEI_SUBWAY, 9, 4.2),
        Edge("ASAKUSA", "ROPPONGI", "A", "Asakusa Line", Operator.TOEI_SUBWAY, 18, 9.1), // Via transfer simulation
        Edge("ASAKUSA", "HANEDA", "A", "Asakusa Line (Through Keikyu)", Operator.TOEI_SUBWAY, 35, 18.5),
        Edge("UENO", "NARITA", "KS", "Keisei Skyliner", Operator.KEISEI, 41, 63.5),
        Edge("TOKYO", "SHINJUKU", "JR", "Chuo Line", Operator.JR_EAST, 14, 10.3),
        Edge("SHIBUYA", "SHINJUKU", "JR", "Yamanote Line", Operator.JR_EAST, 6, 3.4),
        Edge("TOKYO", "UENO", "JR", "Yamanote Line", Operator.JR_EAST, 8, 3.6),
        Edge("SHIBUYA", "ROPPONGI", "WALK", "Walk/Bus Transfer", Operator.TOKYO_METRO, 15, 2.8)
    )

    fun planRoutes(
        originId: String,
        destinationId: String,
        hasPass: Boolean = false,
        activePassProduct: TicketProduct? = null
    ): List<Journey> {
        val journeys = mutableListOf<Journey>()

        // 1. Find direct or single-stop paths
        val directEdges = EDGES.filter { 
            (it.fromId == originId && it.toId == destinationId) || (it.fromId == destinationId && it.toId == originId) 
        }

        for (edge in directEdges) {
            val from = if (edge.fromId == originId) edge.fromId else edge.toId
            val to = if (edge.fromId == originId) edge.toId else edge.fromId
            val operators = listOf(edge.operator)
            val fare = FareEngine.calculateSingleFare(operators, edge.distanceKm, PassengerType.ADULT)

            // Calculate Pass coverage
            var isPassCovered = false
            var partiallyCovered = false
            var coverageNote: String? = null

            if (hasPass && activePassProduct != null) {
                val passOps = activePassProduct.operators
                val isOpSupported = passOps.contains(edge.operator)
                if (isOpSupported) {
                    isPassCovered = true
                    coverageNote = "✓ Pass Full Coverage (${activePassProduct.nameEn})"
                } else {
                    partiallyCovered = true
                    coverageNote = "✕ Requires JR/Private Fare: ¥$fare"
                }
            }

            val leg = JourneyLeg(
                fromStationId = from,
                toStationId = to,
                lineCode = edge.lineCode,
                lineNameEn = edge.lineNameEn,
                operator = edge.operator,
                durationMinutes = edge.durationMinutes,
                stopCount = (edge.distanceKm / 1.1).toInt().coerceAtLeast(1),
                departureTime = "09:20",
                arrivalTime = "09:${20 + edge.durationMinutes}",
                description = "Board ${edge.lineNameEn} at ${getStationName(from)} and arrive at ${getStationName(to)}."
            )

            journeys.add(
                Journey(
                    id = "J-DIRECT-${edge.lineCode}",
                    originId = originId,
                    destinationId = destinationId,
                    legs = listOf(leg),
                    totalDurationMinutes = edge.durationMinutes,
                    totalFare = if (isPassCovered) 0 else fare,
                    transferCount = 0,
                    startTime = "09:20",
                    endTime = "09:${20 + edge.durationMinutes}",
                    isPassCovered = isPassCovered,
                    partiallyCovered = partiallyCovered,
                    coverageNote = coverageNote
                )
            )
        }

        // 2. Multi-leg paths (e.g., Tokyo -> Ginza -> Asakusa)
        // Let's do a simple 2-leg transfer search
        val firstLegs = EDGES.filter { it.fromId == originId || it.toId == originId }
        for (fEdge in firstLegs) {
            val transferStationId = if (fEdge.fromId == originId) fEdge.toId else fEdge.fromId
            if (transferStationId == destinationId) continue

            val secondLegs = EDGES.filter { 
                (it.fromId == transferStationId && it.toId == destinationId) || 
                (it.fromId == destinationId && it.toId == transferStationId) 
            }

            for (sEdge in secondLegs) {
                val fFrom = originId
                val fTo = transferStationId
                val sFrom = transferStationId
                val sTo = destinationId

                val duration = fEdge.durationMinutes + sEdge.durationMinutes + 4 // 4 mins transfer buffer
                val totalDist = fEdge.distanceKm + sEdge.distanceKm
                
                val operators = listOf(fEdge.operator, sEdge.operator).distinct()
                val fare = FareEngine.calculateSingleFare(operators, totalDist, PassengerType.ADULT)

                var isPassCovered = false
                var partiallyCovered = false
                var coverageNote: String? = null

                if (hasPass && activePassProduct != null) {
                    val passOps = activePassProduct.operators
                    val fCovered = passOps.contains(fEdge.operator)
                    val sCovered = passOps.contains(sEdge.operator)
                    
                    if (fCovered && sCovered) {
                        isPassCovered = true
                        coverageNote = "✓ Pass Full Coverage (${activePassProduct.nameEn})"
                    } else if (fCovered || sCovered) {
                        partiallyCovered = true
                        val uncoveredLegDist = if (!fCovered) fEdge.distanceKm else sEdge.distanceKm
                        val uncoveredOp = if (!fCovered) fEdge.operator else sEdge.operator
                        val extraFare = FareEngine.calculateSingleFare(listOf(uncoveredOp), uncoveredLegDist, PassengerType.ADULT)
                        coverageNote = "▲ Partial Coverage. Extra Fare: ¥$extraFare (${uncoveredOp.displayName})"
                    } else {
                        partiallyCovered = true
                        coverageNote = "✕ Requires Full Fare: ¥$fare"
                    }
                }

                val legs = listOf(
                    JourneyLeg(
                        fromStationId = fFrom,
                        toStationId = fTo,
                        lineCode = fEdge.lineCode,
                        lineNameEn = fEdge.lineNameEn,
                        operator = fEdge.operator,
                        durationMinutes = fEdge.durationMinutes,
                        stopCount = (fEdge.distanceKm / 1.1).toInt().coerceAtLeast(1),
                        departureTime = "09:20",
                        arrivalTime = "09:${20 + fEdge.durationMinutes}",
                        description = "Board ${fEdge.lineNameEn} at ${getStationName(fFrom)}."
                    ),
                    JourneyLeg(
                        fromStationId = sFrom,
                        toStationId = sTo,
                        lineCode = sEdge.lineCode,
                        lineNameEn = sEdge.lineNameEn,
                        operator = sEdge.operator,
                        durationMinutes = sEdge.durationMinutes,
                        stopCount = (sEdge.distanceKm / 1.1).toInt().coerceAtLeast(1),
                        departureTime = "09:${20 + fEdge.durationMinutes + 4}",
                        arrivalTime = "09:${20 + duration}",
                        description = "Transfer to ${sEdge.lineNameEn} at ${getStationName(sFrom)}."
                    )
                )

                journeys.add(
                    Journey(
                        id = "J-TRANSFER-${fEdge.lineCode}-${sEdge.lineCode}",
                        originId = originId,
                        destinationId = destinationId,
                        legs = legs,
                        totalDurationMinutes = duration,
                        totalFare = if (isPassCovered) 0 else fare,
                        transferCount = 1,
                        startTime = "09:20",
                        endTime = "09:${20 + duration}",
                        isPassCovered = isPassCovered,
                        partiallyCovered = partiallyCovered,
                        coverageNote = coverageNote
                    )
                )
            }
        }

        // Return sorted by duration
        return journeys.sortedBy { it.totalDurationMinutes }
    }

    fun getStationName(id: String): String {
        return STATIONS.find { it.id == id }?.nameJa ?: id
    }

    fun getStationEn(id: String): String {
        return STATIONS.find { it.id == id }?.nameEn ?: id
    }
}

// ==========================================
// 6. REALTIME ALERTS ENGINE
// ==========================================
object RealtimeEngine {
    val SAMPLE_UPDATES = listOf(
        RealtimeUpdate(
            lineCode = "M",
            lineNameEn = "Marunouchi Line",
            operator = Operator.TOKYO_METRO,
            statusJa = "正常運転",
            statusEn = "Normal Service",
            delayMinutes = 0,
            messageEn = "All trains are running on schedule.",
            timestamp = System.currentTimeMillis()
        ),
        RealtimeUpdate(
            lineCode = "G",
            lineNameEn = "Ginza Line",
            operator = Operator.TOKYO_METRO,
            statusJa = "遅延あり (+5分)",
            statusEn = "Delay (+5 min)",
            delayMinutes = 5,
            messageEn = "A minor delay of about 5 minutes is occurring due to heavy passenger crowds.",
            timestamp = System.currentTimeMillis() - 120_000
        ),
        RealtimeUpdate(
            lineCode = "E",
            lineNameEn = "Oedo Line",
            operator = Operator.TOEI_SUBWAY,
            statusJa = "正常運転",
            statusEn = "Normal Service",
            delayMinutes = 0,
            messageEn = "All trains are running on schedule.",
            timestamp = System.currentTimeMillis()
        )
    )

    fun getUpdatesForJourney(journey: Journey): List<RealtimeUpdate> {
        val lineCodes = journey.legs.mapNotNull { it.lineCode }
        return SAMPLE_UPDATES.filter { lineCodes.contains(it.lineCode) }
    }
}
