package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Tokyo Precision Palette
val MetroBlue = Color(0xFF00ACD1) // Tokyo Metro Blue Logo Color
val ToeiGreen = Color(0xFF009B4F) // Toei Green Logo Color

val MetroDarkBg = Color(0xFF121212)
val MetroCardBg = Color(0xFF1E1E1E)
val MetroLightBg = Color(0xFFF5F5F7)
val MetroBorder = Color(0xFFE2E2E5)
val MetroTextPrimary = Color(0xFF1C1C1E)
val MetroTextSecondary = Color(0xFF8E8E93)

// Subway Line Colors
val MarunouchiRed = Color(0xFFE60012)
val GinzaOrange = Color(0xFFF39700)
val HibiyaSilver = Color(0xFF9CAEB7)
val ChiyodaGreen = Color(0xFF009944)
val TozaiSkyBlue = Color(0xFF009EAF)
val YurakuchoGold = Color(0xFFC1A173)
val HanzomonPurple = Color(0xFF8F76D6)
val NambokuEmerald = Color(0xFF00AC97)
val FukutoshinBrown = Color(0xFF9C5E31)

// Toei Line Colors
val AsakusaRose = Color(0xFFE85294)
val MitaBlue = Color(0xFF0079C2)
val ShinjukuLeaf = Color(0xFF6CBB5A)
val OedoMagenta = Color(0xFFB6007A)

// Alert Red
val AlertCritical = Color(0xFFD9381E)
val SuccessGreen = Color(0xFF2E7D32)
val PremiumGold = Color(0xFFC5A059)

