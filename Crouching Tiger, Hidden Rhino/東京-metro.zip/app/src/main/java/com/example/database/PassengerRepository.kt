package com.example.database

import com.example.model.DigitalTicket
import com.example.model.Order
import kotlinx.coroutines.flow.Flow

class PassengerRepository(private val db: AppDatabase) {
    private val ticketDao = db.ticketDao()
    private val orderDao = db.orderDao()

    val allTickets: Flow<List<DigitalTicket>> = ticketDao.getAllTicketsFlow()
    val allOrders: Flow<List<Order>> = orderDao.getAllOrdersFlow()

    suspend fun insertTicket(ticket: DigitalTicket) {
        ticketDao.insertTicket(ticket)
    }

    suspend fun updateTicket(ticket: DigitalTicket) {
        ticketDao.updateTicket(ticket)
    }

    suspend fun getTicketById(ticketId: String): DigitalTicket? {
        return ticketDao.getTicketById(ticketId)
    }

    suspend fun insertOrder(order: Order) {
        orderDao.insertOrder(order)
    }

    suspend fun updateOrder(order: Order) {
        orderDao.updateOrder(order)
    }

    suspend fun clearAllData() {
        ticketDao.clearAllTickets()
        orderDao.clearAllOrders()
    }
}
