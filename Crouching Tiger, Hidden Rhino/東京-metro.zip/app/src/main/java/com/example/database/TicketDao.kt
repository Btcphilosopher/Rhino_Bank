package com.example.database

import androidx.room.*
import com.example.model.DigitalTicket
import kotlinx.coroutines.flow.Flow

@Dao
interface TicketDao {
    @Query("SELECT * FROM digital_tickets ORDER BY purchaseTime DESC")
    fun getAllTicketsFlow(): Flow<List<DigitalTicket>>

    @Query("SELECT * FROM digital_tickets WHERE ticketId = :ticketId")
    suspend fun getTicketById(ticketId: String): DigitalTicket?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicket(ticket: DigitalTicket)

    @Update
    suspend fun updateTicket(ticket: DigitalTicket)

    @Query("DELETE FROM digital_tickets")
    suspend fun clearAllTickets()
}
