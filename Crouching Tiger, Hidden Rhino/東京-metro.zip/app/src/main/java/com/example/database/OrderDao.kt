package com.example.database

import androidx.room.*
import com.example.model.Order
import kotlinx.coroutines.flow.Flow

@Dao
interface OrderDao {
    @Query("SELECT * FROM passenger_orders ORDER BY createdAt DESC")
    fun getAllOrdersFlow(): Flow<List<Order>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: Order)

    @Update
    suspend fun updateOrder(order: Order)

    @Query("DELETE FROM passenger_orders")
    suspend fun clearAllOrders()
}
