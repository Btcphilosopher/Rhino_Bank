package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.database.AppDatabase
import com.example.database.PassengerRepository
import com.example.engine.*
import com.example.model.*
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

class PassengerViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getDatabase(application)
    private val repository = PassengerRepository(db)

    // General Passenger State
    val allTickets: StateFlow<List<DigitalTicket>> = repository.allTickets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allOrders: StateFlow<List<Order>> = repository.allOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // UI Tab Navigation
    private val _currentTab = MutableStateFlow("home")
    val currentTab: StateFlow<String> = _currentTab.asStateFlow()

    // Station Search and Routing
    private val _originStationId = MutableStateFlow("ASAKUSA")
    val originStationId: StateFlow<String> = _originStationId.asStateFlow()

    private val _destinationStationId = MutableStateFlow("SHIBUYA")
    val destinationStationId: StateFlow<String> = _destinationStationId.asStateFlow()

    private val _searchResults = MutableStateFlow<List<Journey>>(emptyList())
    val searchResults: StateFlow<List<Journey>> = _searchResults.asStateFlow()

    private val _selectedJourney = MutableStateFlow<Journey?>(null)
    val selectedJourney: StateFlow<Journey?> = _selectedJourney.asStateFlow()

    // Real-time updates / delays
    private val _alerts = MutableStateFlow<List<RealtimeUpdate>>(RealtimeEngine.SAMPLE_UPDATES)
    val alerts: StateFlow<List<RealtimeUpdate>> = _alerts.asStateFlow()

    // Ticketing Mode (Demo or Production)
    private val _isProductionMode = MutableStateFlow(false)
    val isProductionMode: StateFlow<Boolean> = _isProductionMode.asStateFlow()

    // Purchase Dialog / BottomSheet
    private val _selectedProduct = MutableStateFlow<TicketProduct?>(null)
    val selectedProduct: StateFlow<TicketProduct?> = _selectedProduct.asStateFlow()

    private val _passengerType = MutableStateFlow(PassengerType.ADULT)
    val passengerType: StateFlow<PassengerType> = _passengerType.asStateFlow()

    private val _purchaseQuantity = MutableStateFlow(1)
    val purchaseQuantity: StateFlow<Int> = _purchaseQuantity.asStateFlow()

    // Suica/PASMO IC Card Pay-As-You-Go Simulator
    private val _icBalance = MutableStateFlow(2500)
    val icBalance: StateFlow<Int> = _icBalance.asStateFlow()

    // Active digital ticket in QR wallet
    private val _activeTicketId = MutableStateFlow<String?>(null)
    val activeTicketId: StateFlow<String?> = _activeTicketId.asStateFlow()

    val activeTicket: StateFlow<DigitalTicket?> = combine(allTickets, _activeTicketId) { tickets, activeId ->
        tickets.find { it.ticketId == activeId }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Recommendation State
    private val _passRecommendation = MutableStateFlow<TicketProduct?>(null)
    val passRecommendation: StateFlow<TicketProduct?> = _passRecommendation.asStateFlow()

    init {
        // Trigger initial route planning and recommendations
        planRoute()
        updateRecommendations()
    }

    fun switchTab(tab: String) {
        _currentTab.value = tab
    }

    fun setOrigin(id: String) {
        _originStationId.value = id
        planRoute()
        updateRecommendations()
    }

    fun setDestination(id: String) {
        _destinationStationId.value = id
        planRoute()
        updateRecommendations()
    }

    fun swapStations() {
        val temp = _originStationId.value
        _originStationId.value = _destinationStationId.value
        _destinationStationId.value = temp
        planRoute()
        updateRecommendations()
    }

    fun toggleTicketingMode(isProd: Boolean) {
        _isProductionMode.value = isProd
    }

    fun setSelectedProduct(product: TicketProduct?) {
        _selectedProduct.value = product
        _purchaseQuantity.value = 1
        _passengerType.value = PassengerType.ADULT
    }

    fun setPassengerType(type: PassengerType) {
        _passengerType.value = type
    }

    fun updateQuantity(delta: Int) {
        _purchaseQuantity.value = (_purchaseQuantity.value + delta).coerceAtLeast(1)
    }

    fun planRoute() {
        viewModelScope.launch {
            // Check if there is an active valid pass in database to cover fares
            val activePass = allTickets.value.firstOrNull { 
                TicketLifecycleEngine.getTicketStatus(it) == TicketStatus.VALID || 
                TicketLifecycleEngine.getTicketStatus(it) == TicketStatus.ACTIVATED
            }
            val hasPass = activePass != null
            val activePassProduct = activePass?.let { TicketProductEngine.getProductById(it.productId) }

            val planned = RouteEngine.planRoutes(
                originId = _originStationId.value,
                destinationId = _destinationStationId.value,
                hasPass = hasPass,
                activePassProduct = activePassProduct
            )
            _searchResults.value = planned
            if (planned.isNotEmpty() && _selectedJourney.value == null) {
                _selectedJourney.value = planned.first()
            } else if (planned.isNotEmpty()) {
                _selectedJourney.value = planned.find { it.id == _selectedJourney.value?.id } ?: planned.first()
            }
        }
    }

    fun selectJourney(journey: Journey) {
        _selectedJourney.value = journey
    }

    private fun updateRecommendations() {
        // Look at the journeys today and calculate recommendations
        val currentFares = _searchResults.value.map { it.totalFare }
        _passRecommendation.value = FareEngine.recommendPass(currentFares)
    }

    fun buyTicket(productId: String) {
        viewModelScope.launch {
            val product = TicketProductEngine.getProductById(productId) ?: return@launch
            val qty = _purchaseQuantity.value
            val passType = _passengerType.value
            val pricePerUnit = if (passType == PassengerType.ADULT) product.priceAdult else product.priceChild
            val totalCost = pricePerUnit * qty

            // Simulate credit card tokenization / secure transaction
            val orderId = "ORD-${UUID.randomUUID().toString().take(12).uppercase()}"
            val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
            val type = Types.newParameterizedType(List::class.java, OrderItem::class.java)
            val adapter = moshi.adapter<List<OrderItem>>(type)
            val itemsJson = adapter.toJson(listOf(OrderItem(productId, product.nameEn, passType, qty, totalCost)))

            val order = Order(
                orderId = orderId,
                itemsJson = itemsJson,
                subtotal = (totalCost * 0.9).toInt(),
                tax = (totalCost * 0.1).toInt(),
                total = totalCost,
                paymentStatus = "PAID",
                createdAt = System.currentTimeMillis()
            )

            // Insert Order
            repository.insertOrder(order)

            // Generate Ticket under proper life cycle
            val ticket = TicketLifecycleEngine.purchaseTicket(
                productId = productId,
                passengerType = passType,
                quantity = qty,
                isDemo = !_isProductionMode.value
            )
            repository.insertTicket(ticket)

            // Auto display in Ticket list / tab
            _currentTab.value = "ticket"
            _selectedProduct.value = null // close sheet
        }
    }

    fun activateTicket(ticketId: String) {
        viewModelScope.launch {
            val ticket = repository.getTicketById(ticketId) ?: return@launch
            val activated = TicketLifecycleEngine.activateTicket(ticket)
            repository.updateTicket(activated)
            _activeTicketId.value = activated.ticketId
        }
    }

    fun refundTicket(ticketId: String) {
        viewModelScope.launch {
            val ticket = repository.getTicketById(ticketId) ?: return@launch
            if (ticket.status == TicketStatus.PURCHASED) {
                val refunded = ticket.copy(status = TicketStatus.REFUNDED)
                repository.updateTicket(refunded)
            }
        }
    }

    fun selectActiveTicket(ticketId: String?) {
        _activeTicketId.value = ticketId
    }

    fun addIcCardBalance(amount: Int) {
        _icBalance.value = _icBalance.value + amount
    }

    fun clearAllUserData() {
        viewModelScope.launch {
            repository.clearAllData()
            _activeTicketId.value = null
            _icBalance.value = 2500
        }
    }
}
