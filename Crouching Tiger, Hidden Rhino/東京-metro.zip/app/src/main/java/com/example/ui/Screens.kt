package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.*
import com.example.model.*
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs

// ==========================================
// CENTRAL NAVIGATION TAB DISPATCHER
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PassengerOSApp(viewModel: PassengerViewModel) {
    val currentTab by viewModel.currentTab.collectAsState()
    val selectedProduct by viewModel.selectedProduct.collectAsState()

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = Color.White,
                tonalElevation = 0.dp,
                modifier = Modifier.border(width = 0.5.dp, color = MetroBorder)
            ) {
                val tabs = listOf(
                    Triple("home", "ホーム", Icons.Default.Subway),
                    Triple("route", "経路", Icons.Default.AltRoute),
                    Triple("map", "地図", Icons.Default.Map),
                    Triple("ticket", "チケット", Icons.Default.QrCode),
                    Triple("profile", "マイページ", Icons.Default.Person)
                )
                tabs.forEach { (route, label, icon) ->
                    NavigationBarItem(
                        selected = currentTab == route,
                        onClick = { viewModel.switchTab(route) },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MetroBlue,
                            selectedTextColor = MetroBlue,
                            unselectedIconColor = MetroTextSecondary,
                            unselectedTextColor = MetroTextSecondary,
                            indicatorColor = MetroBlue.copy(alpha = 0.1f)
                        ),
                        modifier = Modifier.testTag("nav_tab_$route")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MetroLightBg)
        ) {
            AnimatedContent(
                targetState = currentTab,
                transitionSpec = {
                    fadeIn(animationSpec = tween(150)) togetherWith fadeOut(animationSpec = tween(150))
                },
                label = "tab_transition"
            ) { targetTab ->
                when (targetTab) {
                    "home" -> HomeScreen(viewModel)
                    "route" -> RouteScreen(viewModel)
                    "map" -> MapScreen(viewModel)
                    "ticket" -> TicketScreen(viewModel)
                    "profile" -> ProfileScreen(viewModel)
                }
            }

            // Ticket Purchase Sheet / Dialog
            if (selectedProduct != null) {
                PurchaseConfirmationSheet(
                    product = selectedProduct!!,
                    viewModel = viewModel,
                    onDismiss = { viewModel.setSelectedProduct(null) }
                )
            }
        }
    }
}

// ==========================================
// 1. HOME SCREEN (ホーム)
// ==========================================
@Composable
fun HomeScreen(viewModel: PassengerViewModel) {
    val originId by viewModel.originStationId.collectAsState()
    val destId by viewModel.destinationStationId.collectAsState()
    val activeTicket by viewModel.activeTicket.collectAsState()
    val alerts by viewModel.alerts.collectAsState()
    val icBalance by viewModel.icBalance.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Brand Header
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(MetroBlue, CircleShape)
                        .wrapContentSize(Alignment.Center)
                ) {
                    Text("M", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        "東京 Metro",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = MetroTextPrimary
                    )
                    Text(
                        "Tokyo Metro Passenger OS",
                        fontSize = 11.sp,
                        color = MetroTextSecondary,
                        letterSpacing = 1.sp
                    )
                }
            }
        }

        // Travel Route Planning Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(0.5.dp, MetroBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "どこへ行きますか？",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MetroTextPrimary,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            // Origin Field
                            StationSelectorRow(
                                label = "出発地",
                                selectedId = originId,
                                onSelect = { viewModel.setOrigin(it) }
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            // Destination Field
                            StationSelectorRow(
                                label = "目的地",
                                selectedId = destId,
                                onSelect = { viewModel.setDestination(it) }
                            )
                        }

                        // Swap Button
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(
                            onClick = { viewModel.swapStations() },
                            modifier = Modifier
                                .size(40.dp)
                                .background(MetroLightBg, CircleShape)
                                .testTag("swap_stations_button")
                        ) {
                            Icon(Icons.Default.SwapVert, contentDescription = "Swap", tint = MetroBlue)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Quick access stations
                    Text("クイックアクセス", fontSize = 11.sp, color = MetroTextSecondary, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val quickStations = listOf(
                            "TOKYO" to "東京駅",
                            "SHINJUKU" to "新宿",
                            "SHIBUYA" to "渋谷",
                            "ASAKUSA" to "浅草",
                            "GINZA" to "銀座",
                            "HANEDA" to "羽田空港",
                            "NARITA" to "成田空港"
                        )
                        quickStations.forEach { (id, name) ->
                            Box(
                                modifier = Modifier
                                    .background(MetroLightBg, RoundedCornerShape(16.dp))
                                    .clickable {
                                        if (originId != id) {
                                            viewModel.setDestination(id)
                                        } else {
                                            viewModel.setDestination("SHIBUYA")
                                        }
                                    }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(name, fontSize = 12.sp, color = MetroTextPrimary)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = { viewModel.switchTab("route") },
                        colors = ButtonDefaults.buttonColors(containerColor = MetroBlue),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("plan_route_button")
                    ) {
                        Text("ルートを検索", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }

        // Active Ticket / Pass Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(0.5.dp, MetroBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "有効なチケット (Active Ticket)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MetroTextSecondary
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    if (activeTicket != null) {
                        val ticket = activeTicket!!
                        val timeRemaining = ticket.validUntil?.let { it - System.currentTimeMillis() } ?: 0L
                        val hours = (timeRemaining / (3600 * 1000L)).coerceAtLeast(0L)
                        val mins = ((timeRemaining % (3600 * 1000L)) / (60 * 1000L)).coerceAtLeast(0L)

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.Black, RoundedCornerShape(8.dp))
                                .padding(16.dp)
                        ) {
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        ticket.productNameJa,
                                        color = Color.White,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Box(
                                        modifier = Modifier
                                            .background(SuccessGreen, RoundedCornerShape(4.dp))
                                            .padding(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Text("VALID", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    ticket.productNameEn,
                                    color = Color.White.copy(alpha = 0.7f),
                                    fontSize = 12.sp
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("残り時間 (Remaining)", color = Color.White.copy(alpha = 0.5f), fontSize = 10.sp)
                                        Text("${hours}時間 ${mins}分", color = PremiumGold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Button(
                                        onClick = { viewModel.switchTab("ticket") },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                        shape = RoundedCornerShape(4.dp),
                                        modifier = Modifier.testTag("show_qr_button")
                                    ) {
                                        Icon(Icons.Default.QrCode, contentDescription = "QR", tint = Color.Black, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("QR表示", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    } else {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp)
                        ) {
                            Icon(
                                Icons.Outlined.ConfirmationNumber,
                                contentDescription = "No Ticket",
                                tint = MetroTextSecondary,
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                "有効な乗車券がありません",
                                fontSize = 13.sp,
                                color = MetroTextSecondary
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            OutlinedButton(
                                onClick = { viewModel.switchTab("ticket") },
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, MetroBlue),
                                modifier = Modifier.testTag("buy_pass_nav_button")
                            ) {
                                Text("お得な切符を購入", color = MetroBlue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // IC Card PASMO/Suica Simulation
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(0.5.dp, MetroBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(Color(0xFFE50012).copy(alpha = 0.1f), CircleShape)
                                .wrapContentSize(Alignment.Center)
                        ) {
                            Icon(Icons.Default.CreditCard, contentDescription = "IC Card", tint = Color(0xFFE50012))
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("PASMO / Suica (模擬)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MetroTextPrimary)
                            Text("IC PAY-AS-YOU-GO", fontSize = 11.sp, color = MetroTextSecondary)
                        }
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("¥${icBalance}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MetroTextPrimary)
                        Text(
                            "+¥1,000 チャージ",
                            fontSize = 11.sp,
                            color = MetroBlue,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .clickable { viewModel.addIcCardBalance(1000) }
                                .padding(top = 4.dp)
                                .testTag("charge_ic_button")
                        )
                    }
                }
            }
        }

        // Subway Service Alerts (運行情報)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(0.5.dp, MetroBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "運行情報 (Service Alerts)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MetroTextSecondary
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    alerts.forEach { alert ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(
                                        if (alert.delayMinutes > 0) AlertCritical else SuccessGreen,
                                        CircleShape
                                    )
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                alert.lineNameEn,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                if (alert.delayMinutes > 0) "遅延あり (+${alert.delayMinutes}分)" else "正常運転",
                                fontSize = 12.sp,
                                color = if (alert.delayMinutes > 0) AlertCritical else SuccessGreen,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
fun StationSelectorRow(label: String, selectedId: String, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .background(MetroLightBg, RoundedCornerShape(8.dp))
            .clickable { expanded = true }
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(label, fontSize = 9.sp, color = MetroTextSecondary, fontWeight = FontWeight.Bold)
            Text(
                "${RouteEngine.getStationName(selectedId)} (${RouteEngine.getStationEn(selectedId)})",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MetroTextPrimary
            )
        }
        Icon(Icons.Default.ArrowDropDown, contentDescription = "Dropdown", tint = MetroTextSecondary)

        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            RouteEngine.STATIONS.forEach { station ->
                DropdownMenuItem(
                    text = { Text("${station.nameJa} (${station.nameEn})") },
                    onClick = {
                        onSelect(station.id)
                        expanded = false
                    }
                )
            }
        }
    }
}

// ==========================================
// 2. ROUTE SCREEN (経路)
// ==========================================
@Composable
fun RouteScreen(viewModel: PassengerViewModel) {
    val originId by viewModel.originStationId.collectAsState()
    val destId by viewModel.destinationStationId.collectAsState()
    val searchResults by viewModel.searchResults.collectAsState()
    val selectedJourney by viewModel.selectedJourney.collectAsState()
    val recommendation by viewModel.passRecommendation.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Station Header Summary
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White, RoundedCornerShape(12.dp))
                .border(0.5.dp, MetroBorder)
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("乗車区間 (Itinerary)", fontSize = 11.sp, color = MetroTextSecondary)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        RouteEngine.getStationName(originId),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MetroTextPrimary
                    )
                    Icon(
                        Icons.Default.ArrowForward,
                        contentDescription = "to",
                        tint = MetroTextSecondary,
                        modifier = Modifier
                            .padding(horizontal = 8.dp)
                            .size(16.dp)
                    )
                    Text(
                        RouteEngine.getStationName(destId),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MetroTextPrimary
                    )
                }
            }
            OutlinedButton(
                onClick = { viewModel.swapStations() },
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(0.5.dp, MetroBorder)
            ) {
                Icon(Icons.Default.SwapHoriz, contentDescription = "Swap")
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Pass Recommendation Banner
        if (recommendation != null) {
            Card(
                colors = CardDefaults.cardColors(containerColor = PremiumGold.copy(alpha = 0.1f)),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(0.5.dp, PremiumGold),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.setSelectedProduct(recommendation) }
                    .testTag("recommendation_banner")
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Lightbulb, contentDescription = "Tip", tint = PremiumGold)
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "乗車券の賢い選択 (Pass Recommendation)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = PremiumGold
                        )
                        Text(
                            "${recommendation!!.nameJa} の方がお得になる可能性があります。",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MetroTextPrimary
                        )
                    }
                    Icon(Icons.Default.ChevronRight, contentDescription = "View", tint = PremiumGold)
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        // Available Routes
        Text("経路の候補 (Planned Journeys)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MetroTextSecondary)
        Spacer(modifier = Modifier.height(8.dp))

        if (searchResults.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text("該当する経路が見つかりませんでした。", color = MetroTextSecondary)
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(searchResults) { journey ->
                    val isSelected = selectedJourney?.id == journey.id
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) Color.White else Color.White.copy(alpha = 0.6f)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(
                            width = if (isSelected) 1.5.dp else 0.5.dp,
                            color = if (isSelected) MetroBlue else MetroBorder
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.selectJourney(journey) }
                            .testTag("journey_card_${journey.id}")
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .background(
                                                if (journey.legs.firstOrNull()?.operator?.isSubway == true) MetroBlue else Color.Gray,
                                                RoundedCornerShape(4.dp)
                                            )
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            if (journey.transferCount == 0) "直通" else "乗換 ${journey.transferCount}回",
                                            color = Color.White,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        "${journey.totalDurationMinutes}分",
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MetroTextPrimary
                                    )
                                }

                                Text(
                                    if (journey.totalFare == 0) "Pass Covered" else "¥${journey.totalFare}",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (journey.totalFare == 0) SuccessGreen else MetroTextPrimary
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Simplified Timeline display
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(journey.startTime, fontSize = 12.sp, color = MetroTextSecondary)
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .padding(horizontal = 8.dp)
                                        .height(2.dp)
                                        .background(MetroBorder)
                                )
                                Text(journey.endTime, fontSize = 12.sp, color = MetroTextSecondary)
                            }

                            if (isSelected) {
                                Spacer(modifier = Modifier.height(12.dp))
                                Divider(color = MetroBorder, thickness = 0.5.dp)
                                Spacer(modifier = Modifier.height(12.dp))

                                // Realtime Journey legs detail
                                journey.legs.forEachIndexed { index, leg ->
                                    Row(modifier = Modifier.fillMaxWidth()) {
                                        // Vertical timeline indicator
                                        Column(
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            modifier = Modifier.width(24.dp)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(8.dp)
                                                    .background(MetroBlue, CircleShape)
                                            )
                                            Box(
                                                modifier = Modifier
                                                    .width(2.dp)
                                                    .height(40.dp)
                                                    .background(MetroBorder)
                                            )
                                        }

                                        Spacer(modifier = Modifier.width(8.dp))

                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                "${leg.departureTime} ${RouteEngine.getStationName(leg.fromStationId)}",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp
                                            )
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.padding(vertical = 4.dp)
                                            ) {
                                                if (leg.lineCode != null) {
                                                    val lineCol = getLineColor(leg.lineCode)
                                                    Box(
                                                        modifier = Modifier
                                                            .background(lineCol, CircleShape)
                                                            .size(16.dp)
                                                            .wrapContentSize(Alignment.Center)
                                                    ) {
                                                        Text(leg.lineCode, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                    }
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text(
                                                        "${leg.lineNameEn} (${leg.stopCount}駅)",
                                                        fontSize = 12.sp,
                                                        color = MetroTextSecondary
                                                    )
                                                } else {
                                                    Text("徒歩 / Walk", fontSize = 12.sp, color = MetroTextSecondary)
                                                }
                                            }
                                        }
                                    }

                                    // Print Destination Station at the end
                                    if (index == journey.legs.size - 1) {
                                        Row(modifier = Modifier.fillMaxWidth()) {
                                            Column(
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                modifier = Modifier.width(24.dp)
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(8.dp)
                                                        .background(MetroBlue, CircleShape)
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                "${leg.arrivalTime} ${RouteEngine.getStationName(leg.toStationId)}",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp
                                            )
                                        }
                                    }
                                }

                                if (journey.coverageNote != null) {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(
                                        journey.coverageNote,
                                        fontSize = 12.sp,
                                        color = if (journey.isPassCovered) SuccessGreen else AlertCritical,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
    }
}

// Helper to resolve Line Colors
fun getLineColor(lineCode: String): Color {
    return when (lineCode) {
        "M" -> MarunouchiRed
        "G" -> GinzaOrange
        "H" -> HibiyaSilver
        "C" -> ChiyodaGreen
        "T" -> TozaiSkyBlue
        "Y" -> YurakuchoGold
        "Z" -> HanzomonPurple
        "N" -> NambokuEmerald
        "F" -> FukutoshinBrown
        "A" -> AsakusaRose
        "I" -> MitaBlue
        "S" -> ShinjukuLeaf
        "E" -> OedoMagenta
        else -> Color.Gray
    }
}

// ==========================================
// 3. MAP SCREEN (地図)
// ==========================================
@Composable
fun MapScreen(viewModel: PassengerViewModel) {
    val originId by viewModel.originStationId.collectAsState()
    val destId by viewModel.destinationStationId.collectAsState()

    var showLines by remember { mutableStateOf(true) }
    var showJR by remember { mutableStateOf(true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("東京交通路線図 (Tokyo Subway Network)", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MetroTextPrimary)
        Text("In-Memory Interactive GIS Map Canvas", fontSize = 11.sp, color = MetroTextSecondary)

        Spacer(modifier = Modifier.height(12.dp))

        // Map Control Toggles
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            FilterChip(
                selected = showLines,
                onClick = { showLines = !showLines },
                label = { Text("Subway Lines") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MetroBlue.copy(alpha = 0.1f),
                    selectedLabelColor = MetroBlue
                )
            )
            FilterChip(
                selected = showJR,
                onClick = { showJR = !showJR },
                label = { Text("JR Lines") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = Color.Gray.copy(alpha = 0.1f),
                    selectedLabelColor = Color.Black
                )
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Beautiful Interactive Map Canvas Drawing
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Color.White, RoundedCornerShape(12.dp))
                .border(0.5.dp, MetroBorder)
                .clip(RoundedCornerShape(12.dp))
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val canvasWidth = size.width
                val canvasHeight = size.height

                // GIS scale conversion parameters mapping coordinate bounding box of central Tokyo
                val minLat = 35.53
                val maxLat = 35.78
                val minLng = 139.68
                val maxLng = 139.82

                fun convertCoords(lat: Double, lng: Double): Offset {
                    val x = ((lng - minLng) / (maxLng - minLng)) * canvasWidth
                    val y = (1.0 - (lat - minLat) / (maxLat - minLat)) * canvasHeight
                    return Offset(x.toFloat(), y.toFloat())
                }

                // 1. Draw Network Connections
                if (showLines) {
                    RouteEngine.EDGES.forEach { edge ->
                        if (!showJR && edge.operator == Operator.JR_EAST) return@forEach

                        val fromStation = RouteEngine.STATIONS.find { it.id == edge.fromId }
                        val toStation = RouteEngine.STATIONS.find { it.id == edge.toId }
                        if (fromStation != null && toStation != null) {
                            val start = convertCoords(fromStation.latitude, fromStation.longitude)
                            val end = convertCoords(toStation.latitude, toStation.longitude)
                            val color = getLineColor(edge.lineCode)

                            drawLine(
                                color = color,
                                start = start,
                                end = end,
                                strokeWidth = 5f,
                                pathEffect = if (edge.operator == Operator.JR_EAST) {
                                    PathEffect.dashPathEffect(floatArrayOf(15f, 15f), 0f)
                                } else null
                            )
                        }
                    }
                }

                // 2. Draw Stations
                RouteEngine.STATIONS.forEach { station ->
                    val isOrigin = station.id == originId
                    val isDest = station.id == destId
                    val pos = convertCoords(station.latitude, station.longitude)

                    // Draw outer ring
                    drawCircle(
                        color = if (isOrigin) SuccessGreen else if (isDest) AlertCritical else Color.White,
                        radius = if (isOrigin || isDest) 18f else 12f,
                        center = pos
                    )

                    drawCircle(
                        color = if (isOrigin) SuccessGreen else if (isDest) AlertCritical else MetroBlue,
                        radius = if (isOrigin || isDest) 12f else 8f,
                        center = pos,
                        style = Stroke(width = if (isOrigin || isDest) 4f else 3f)
                    )

                    // Simple labels
                    // Keep text labels outside overlaps
                    val offsetText = Offset(pos.x + 18f, pos.y - 12f)
                    // We don't have native drawText easily without native Canvas in DrawScope, but we can draw dots cleanly!
                }
            }

            // Overlay Floating Station Markers inside Composable
            RouteEngine.STATIONS.forEach { station ->
                val isOrigin = station.id == originId
                val isDest = station.id == destId

                // Calculate positions using relative alignment
                val latWeight = (station.latitude - 35.53) / (35.78 - 35.53)
                val lngWeight = (station.longitude - 139.68) / (139.82 - 139.68)

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .align(
                                BiasAlignment(
                                    horizontalBias = ((lngWeight * 2) - 1.0).toFloat(),
                                    verticalBias = (1.0 - (latWeight * 2)).toFloat()
                                )
                            )
                            .background(
                                if (isOrigin) SuccessGreen else if (isDest) AlertCritical else Color.White.copy(alpha = 0.9f),
                                RoundedCornerShape(4.dp)
                            )
                            .border(
                                0.5.dp,
                                if (isOrigin) SuccessGreen else if (isDest) AlertCritical else MetroBorder,
                                RoundedCornerShape(4.dp)
                            )
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        Text(
                            station.nameJa,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isOrigin || isDest) Color.White else Color.Black
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// 4. TICKET WALLET SCREEN (チケット)
// ==========================================
@Composable
fun TicketScreen(viewModel: PassengerViewModel) {
    val allTickets by viewModel.allTickets.collectAsState()
    val isProdMode by viewModel.isProductionMode.collectAsState()

    var showWalletOnly by remember { mutableStateOf(true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("チケットウォレット (Digital Wallet)", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MetroTextPrimary)
                Text(
                    if (isProdMode) "TICKETING MODE: PRODUCTION (Real API Setup)" else "TICKETING MODE: DEMO (Simulation Provider)",
                    fontSize = 11.sp,
                    color = if (isProdMode) SuccessGreen else PremiumGold,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Wallet vs Purchase switcher
        TabRow(
            selectedTabIndex = if (showWalletOnly) 0 else 1,
            containerColor = Color.Transparent,
            contentColor = MetroBlue,
            divider = { Divider(color = MetroBorder) }
        ) {
            Tab(
                selected = showWalletOnly,
                onClick = { showWalletOnly = true },
                text = { Text("所持切符 (My Tickets)", fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("my_tickets_tab")
            )
            Tab(
                selected = !showWalletOnly,
                onClick = { showWalletOnly = false },
                text = { Text("乗車券購入 (Buy Pass)", fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("buy_pass_tab")
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (showWalletOnly) {
            // My tickets wallet list
            if (allTickets.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Outlined.ConfirmationNumber, contentDescription = "No Pass", tint = MetroTextSecondary, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("購入した切符はありません", fontSize = 14.sp, color = MetroTextSecondary)
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = { showWalletOnly = false },
                            colors = ButtonDefaults.buttonColors(containerColor = MetroBlue),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("チケットを購入する", color = Color.White)
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Filter ACTIVE vs PURCHASED vs EXPIRED
                    val activeList = allTickets.filter { 
                        it.status == TicketStatus.ACTIVATED || it.status == TicketStatus.VALID 
                    }
                    val purchasedList = allTickets.filter { it.status == TicketStatus.PURCHASED }
                    val pastList = allTickets.filter { 
                        it.status != TicketStatus.ACTIVATED && 
                        it.status != TicketStatus.VALID && 
                        it.status != TicketStatus.PURCHASED 
                    }

                    if (activeList.isNotEmpty()) {
                        item { Text("有効なチケット", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MetroTextSecondary) }
                        items(activeList) { ticket ->
                            ActiveTicketWalletCard(ticket, viewModel)
                        }
                    }

                    if (purchasedList.isNotEmpty()) {
                        item { Text("購入済み (未有効化)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MetroTextSecondary) }
                        items(purchasedList) { ticket ->
                            PurchasedTicketCard(ticket, viewModel)
                        }
                    }

                    if (pastList.isNotEmpty()) {
                        item { Text("過去のチケット / 履歴", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MetroTextSecondary) }
                        items(pastList) { ticket ->
                            PastTicketCard(ticket)
                        }
                    }
                }
            }
        } else {
            // Purchase Menu List
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text(
                        "東京観光とお得な切符一覧 (Official Passes)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MetroTextSecondary,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }

                items(TicketProductEngine.ALL_PRODUCTS) { product ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(0.5.dp, MetroBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.setSelectedProduct(product) }
                            .testTag("buy_product_card_${product.id}")
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Top
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        product.nameJa,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MetroTextPrimary
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        product.nameEn,
                                        fontSize = 12.sp,
                                        color = MetroTextSecondary
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        "¥${product.priceAdult}",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MetroBlue
                                    )
                                    Text("大人 / 1枚", fontSize = 10.sp, color = MetroTextSecondary)
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Operator coverages
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                product.operators.forEach { op ->
                                    val isMetro = op == Operator.TOKYO_METRO
                                    Box(
                                        modifier = Modifier
                                            .background(
                                                if (isMetro) MetroBlue else ToeiGreen,
                                                RoundedCornerShape(4.dp)
                                            )
                                            .padding(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            if (isMetro) "Tokyo Metro" else "Toei Subway",
                                            color = Color.White,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Text(
                                    "首次使用後 ${product.validityHours}時間有効",
                                    fontSize = 11.sp,
                                    color = MetroTextSecondary
                                )
                            }

                            if (product.isBundle && product.bundleDescription != null) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Box(
                                    modifier = Modifier
                                        .background(PremiumGold.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                                        .padding(8.dp)
                                ) {
                                    Text(
                                        product.bundleDescription,
                                        fontSize = 11.sp,
                                        color = MetroTextPrimary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// DETAILED DIGITAL QR WALLET CARD
// ==========================================
@Composable
fun ActiveTicketWalletCard(ticket: DigitalTicket, viewModel: PassengerViewModel) {
    val timeRemaining = ticket.validUntil?.let { it - System.currentTimeMillis() } ?: 0L
    val hours = (timeRemaining / (3600 * 1000L)).coerceAtLeast(0L)
    val mins = ((timeRemaining % (3600 * 1000L)) / (60 * 1000L)).coerceAtLeast(0L)

    var showQRDetails by remember { mutableStateOf(false) }

    Card(
        colors = CardDefaults.cardColors(containerColor = Color.Black),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { showQRDetails = !showQRDetails }
            .testTag("active_ticket_card")
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "東京 Metro",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Box(
                    modifier = Modifier
                        .background(SuccessGreen, RoundedCornerShape(4.dp))
                        .padding(horizontal = 10.dp, vertical = 2.dp)
                ) {
                    Text("VALID", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                ticket.productNameJa,
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Text(
                ticket.productNameEn,
                color = Color.White.copy(alpha = 0.6f),
                fontSize = 13.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            // THE QR CODE DISPLAY LAYER
            Box(
                modifier = Modifier
                    .size(200.dp)
                    .background(Color.White, RoundedCornerShape(12.dp))
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                // Generate and draw a fully stylized, realistic QR Grid block!
                QRGridDrawing(payload = ticket.qrPayload, isDemo = ticket.isDemo)
            }

            Spacer(modifier = Modifier.height(12.dp))
            Text("请将二维码对准检票机", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)

            Spacer(modifier = Modifier.height(20.dp))
            Divider(color = Color.White.copy(alpha = 0.2f), thickness = 0.5.dp)
            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("有効期限 (Validity Bounds)", color = Color.White.copy(alpha = 0.4f), fontSize = 10.sp)
                    val sdf = SimpleDateFormat("MM/dd HH:mm", Locale.getDefault())
                    val fromStr = ticket.validFrom?.let { sdf.format(Date(it)) } ?: ""
                    val untilStr = ticket.validUntil?.let { sdf.format(Date(it)) } ?: ""
                    Text("$fromStr → $untilStr", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("残り時間 (Remaining)", color = Color.White.copy(alpha = 0.4f), fontSize = 10.sp)
                    Text("${hours}時間 ${mins}分", color = PremiumGold, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
            }

            if (showQRDetails) {
                Spacer(modifier = Modifier.height(16.dp))
                Divider(color = Color.White.copy(alpha = 0.2f), thickness = 0.5.dp)
                Spacer(modifier = Modifier.height(12.dp))

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.Start
                ) {
                    Text("安全认证 (Security & Payload)", color = Color.White.copy(alpha = 0.5f), fontSize = 10.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        ticket.qrPayload,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        color = Color.LightGray
                    )
                }
            }
        }
    }
}

// Beautiful simulated pixelated QR Grid Drawing block!
@Composable
fun QRGridDrawing(payload: String, isDemo: Boolean) {
    // We can draw a highly convincing matrix QR code by using simple nested lines & boxes, or a canvas of 15x15 grids!
    Canvas(modifier = Modifier.fillMaxSize()) {
        val size = size.width
        val cellSize = size / 17f

        // Draw Corner Finder Patterns
        fun drawFinder(x: Float, y: Float) {
            // Outer block
            drawRect(
                color = Color.Black,
                topLeft = Offset(x * cellSize, y * cellSize),
                size = androidx.compose.ui.geometry.Size(7 * cellSize, 7 * cellSize)
            )
            // Inner white ring
            drawRect(
                color = Color.White,
                topLeft = Offset((x + 1) * cellSize, (y + 1) * cellSize),
                size = androidx.compose.ui.geometry.Size(5 * cellSize, 5 * cellSize)
            )
            // Center black core
            drawRect(
                color = Color.Black,
                topLeft = Offset((x + 2) * cellSize, (y + 2) * cellSize),
                size = androidx.compose.ui.geometry.Size(3 * cellSize, 3 * cellSize)
            )
        }

        // Clean Canvas
        drawRect(color = Color.White)

        // Draw standard finder patterns at top-left, top-right, and bottom-left corners!
        drawFinder(0f, 0f)
        drawFinder(10f, 0f)
        drawFinder(0f, 10f)

        // Generate pseudo-random matrix blocks depending on payload string hash to represent actual signature!
        val payloadHash = abs(payload.hashCode())
        val random = Random(payloadHash.toLong())

        for (i in 0 until 17) {
            for (j in 0 until 17) {
                // Skip corner areas where finder patterns are located
                if ((i < 8 && j < 8) || (i > 9 && j < 8) || (i < 8 && j > 9)) {
                    continue
                }
                // Randomly color cells black/white
                if (random.nextBoolean()) {
                    drawRect(
                        color = Color.Black,
                        topLeft = Offset(i * cellSize, j * cellSize),
                        size = androidx.compose.ui.geometry.Size(cellSize, cellSize)
                    )
                }
            }
        }

        // Overlay transparent "DEMO" stamp if it is a Demo ticket!
        if (isDemo) {
            // Draw a high contrast text block overlay visually or keep it pure and simple.
        }
    }

    if (isDemo) {
        Box(
            modifier = Modifier
                .background(AlertCritical, RoundedCornerShape(4.dp))
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            Text(
                "DEMO TICKET",
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp
            )
        }
    }
}

@Composable
fun PurchasedTicketCard(ticket: DigitalTicket, viewModel: PassengerViewModel) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(0.5.dp, MetroBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(ticket.productNameJa, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MetroTextPrimary)
                    Text(ticket.productNameEn, fontSize = 12.sp, color = MetroTextSecondary)
                }
                Box(
                    modifier = Modifier
                        .background(PremiumGold.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text("READY", color = PremiumGold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("購入日 (Purchased)", fontSize = 10.sp, color = MetroTextSecondary)
                    val sdf = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault())
                    Text(sdf.format(Date(ticket.purchaseTime)), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { viewModel.refundTicket(ticket.ticketId) },
                        border = BorderStroke(0.5.dp, AlertCritical),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text("退金 (Refund)", color = AlertCritical, fontSize = 12.sp)
                    }
                    Button(
                        onClick = { viewModel.activateTicket(ticket.ticketId) },
                        colors = ButtonDefaults.buttonColors(containerColor = MetroBlue),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.testTag("activate_ticket_btn_${ticket.ticketId}")
                    ) {
                        Text("使用開始 (Activate)", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun PastTicketCard(ticket: DigitalTicket) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.5f)),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(0.5.dp, MetroBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(ticket.productNameJa, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MetroTextSecondary)
                    Text(ticket.productNameEn, fontSize = 11.sp, color = MetroTextSecondary)
                }
                Box(
                    modifier = Modifier
                        .background(Color.LightGray, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(ticket.status.name, color = Color.DarkGray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ==========================================
// 5. PROFILE SCREEN (マイページ)
// ==========================================
@Composable
fun ProfileScreen(viewModel: PassengerViewModel) {
    val isProdMode by viewModel.isProductionMode.collectAsState()
    val allOrders by viewModel.allOrders.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // User Profile Info
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(0.5.dp, MetroBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .background(MetroBlue.copy(alpha = 0.1f), CircleShape)
                            .wrapContentSize(Alignment.Center)
                    ) {
                        Icon(Icons.Default.Person, contentDescription = "User", tint = MetroBlue, modifier = Modifier.size(30.dp))
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text("Tokyo Commuter", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MetroTextPrimary)
                        Text("DEMO USER ACCOUNT", fontSize = 11.sp, color = MetroTextSecondary)
                    }
                }
            }
        }

        // Ticketing Mode Selector (PRODUCTION vs DEMO)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(0.5.dp, MetroBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "切符発券システム設定 (Ticketing Mode Security)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MetroTextSecondary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "生产环境要求仅允许由官方API签发。此处可切换查看Demo发券和Prod真实防伪签发模式的表现差别。",
                        fontSize = 11.sp,
                        color = MetroTextSecondary
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            if (isProdMode) "PRODUCTION MODE" else "DEMO MODE",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isProdMode) SuccessGreen else PremiumGold
                        )
                        Switch(
                            checked = isProdMode,
                            onCheckedChange = { viewModel.toggleTicketingMode(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = SuccessGreen,
                                uncheckedThumbColor = Color.White,
                                uncheckedTrackColor = Color.LightGray
                            ),
                            modifier = Modifier.testTag("ticketing_mode_switch")
                        )
                    }
                }
            }
        }

        // Orders List history
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(0.5.dp, MetroBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "注文履歴 (Purchase Orders History)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MetroTextSecondary
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    if (allOrders.isEmpty()) {
                        Text("注文履歴がありません", fontSize = 12.sp, color = MetroTextSecondary)
                    } else {
                        allOrders.forEach { order ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(order.orderId, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MetroTextPrimary)
                                    val sdf = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault())
                                    Text(sdf.format(Date(order.createdAt)), fontSize = 10.sp, color = MetroTextSecondary)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("¥${order.total}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MetroBlue)
                                    Text(order.paymentStatus, fontSize = 9.sp, color = SuccessGreen, fontWeight = FontWeight.Bold)
                                }
                            }
                            Divider(color = MetroBorder, thickness = 0.5.dp)
                        }
                    }
                }
            }
        }

        // Clear Storage Action
        item {
            OutlinedButton(
                onClick = { viewModel.clearAllUserData() },
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(0.5.dp, AlertCritical),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("clear_data_button")
            ) {
                Text("キャッシュをクリア / 退会", color = AlertCritical, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

// ==========================================
// TICKET PURCHASE CONFIRMATION DIALOG SHEET
// ==========================================
@Composable
fun PurchaseConfirmationSheet(
    product: TicketProduct,
    viewModel: PassengerViewModel,
    onDismiss: () -> Unit
) {
    val quantity by viewModel.purchaseQuantity.collectAsState()
    val type by viewModel.passengerType.collectAsState()
    val isProdMode by viewModel.isProductionMode.collectAsState()

    val total = if (type == PassengerType.ADULT) product.priceAdult * quantity else product.priceChild * quantity

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(product.nameJa, fontWeight = FontWeight.Bold, fontSize = 18.sp) },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(product.nameEn, fontSize = 13.sp, color = MetroTextSecondary)
                Spacer(modifier = Modifier.height(16.dp))

                // Passenger type select
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FilterChip(
                        selected = type == PassengerType.ADULT,
                        onClick = { viewModel.setPassengerType(PassengerType.ADULT) },
                        label = { Text("大人 / Adult (¥${product.priceAdult})") }
                    )
                    FilterChip(
                        selected = type == PassengerType.CHILD,
                        onClick = { viewModel.setPassengerType(PassengerType.CHILD) },
                        label = { Text("小児 / Child (¥${product.priceChild})") }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Quantity selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("数量 (Quantity)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MetroTextPrimary)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { viewModel.updateQuantity(-1) }) {
                            Icon(Icons.Default.Remove, contentDescription = "Decrease")
                        }
                        Text("$quantity", fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 12.dp))
                        IconButton(onClick = { viewModel.updateQuantity(1) }) {
                            Icon(Icons.Default.Add, contentDescription = "Increase")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Divider(color = MetroBorder, thickness = 0.5.dp)
                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("合計金額 (Total Price)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MetroTextPrimary)
                    Text("¥${total}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MetroBlue)
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    if (isProdMode) "✓ PRODUCTION API AUTHORIZED ISSUER" else "▲ DEMO / SYNTHETIC TICKET GENERATION",
                    fontSize = 11.sp,
                    color = if (isProdMode) SuccessGreen else PremiumGold,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { viewModel.buyTicket(product.id) },
                colors = ButtonDefaults.buttonColors(containerColor = MetroBlue),
                modifier = Modifier.testTag("confirm_purchase_button")
            ) {
                Text("購入確認 (Pay ¥${total})", color = Color.White)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("キャンセル", color = MetroTextSecondary)
            }
        }
    )
}
