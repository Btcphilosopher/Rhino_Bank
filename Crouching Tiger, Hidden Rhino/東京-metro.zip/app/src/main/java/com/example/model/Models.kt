package com.example.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

enum class Operator(val displayName: String, val isSubway: Boolean) : Serializable {
    TOKYO_METRO("Tokyo Metro", true),
    TOEI_SUBWAY("Toei Subway", true),
    JR_EAST("JR East", false),
    KEIKYU("Keikyu Electric Railway", false),
    KEISEI("Keisei Electric Railway", false),
    TOKYU("Tokyu Railway", false),
    ODAKYU("Odakyu Electric Railway", false)
}

data class Station(
    val id: String,
    val nameJa: String,
    val nameEn: String,
    val operators: List<Operator>,
    val lines: List<String>,
    val latitude: Double,
    val longitude: Double,
    val exits: List<String> = emptyList()
) : Serializable

data class StationExit(
    val id: String,
    val stationId: String,
    val name: String,
    val nearbyAttractions: List<String>,
    val walkTimeMinutes: Int
) : Serializable

data class TransitLine(
    val code: String, // e.g., "M" for Marunouchi, "G" for Ginza
    val nameJa: String,
    val nameEn: String,
    val operator: Operator,
    val colorHex: String
) : Serializable

enum class TicketStatus : Serializable {
    PURCHASED,
    READY,
    ACTIVATED,
    VALID,
    EXPIRED,
    USED,
    CANCELLED,
    REFUNDED
}

enum class PassengerType : Serializable {
    ADULT,
    CHILD
}

data class TicketProduct(
    val id: String,
    val nameJa: String,
    val nameEn: String,
    val priceAdult: Int,
    val priceChild: Int,
    val validityHours: Int,
    val operators: List<Operator>,
    val isBundle: Boolean = false,
    val bundleDescription: String? = null
) : Serializable

@Entity(tableName = "digital_tickets")
data class DigitalTicket(
    @PrimaryKey val ticketId: String,
    val productId: String,
    val productNameEn: String,
    val productNameJa: String,
    val issuer: String,
    val passengerType: PassengerType,
    val quantity: Int,
    val pricePaid: Int,
    val purchaseTime: Long, // Epoch ms
    val activationTime: Long? = null, // Epoch ms
    val validFrom: Long? = null, // Epoch ms
    val validUntil: Long? = null, // Epoch ms
    val status: TicketStatus,
    val qrPayload: String,
    val signature: String,
    val isDemo: Boolean
) : Serializable

@Entity(tableName = "passenger_orders")
data class Order(
    @PrimaryKey val orderId: String,
    val itemsJson: String, // List of ordered items
    val subtotal: Int,
    val tax: Int,
    val total: Int,
    val paymentStatus: String, // "PAID", "REFUNDED", "FAILED"
    val createdAt: Long,
    val refundedAt: Long? = null
) : Serializable

data class OrderItem(
    val productId: String,
    val nameEn: String,
    val passengerType: PassengerType,
    val quantity: Int,
    val price: Int
) : Serializable

data class JourneyLeg(
    val fromStationId: String,
    val toStationId: String,
    val lineCode: String?, // Null means walking
    val lineNameEn: String?,
    val operator: Operator,
    val durationMinutes: Int,
    val stopCount: Int,
    val departureTime: String,
    val arrivalTime: String,
    val description: String
) : Serializable

data class Journey(
    val id: String,
    val originId: String,
    val destinationId: String,
    val legs: List<JourneyLeg>,
    val totalDurationMinutes: Int,
    val totalFare: Int,
    val transferCount: Int,
    val startTime: String,
    val endTime: String,
    val isPassCovered: Boolean = false,
    val partiallyCovered: Boolean = false,
    val coverageNote: String? = null
) : Serializable

data class RealtimeUpdate(
    val lineCode: String,
    val lineNameEn: String,
    val operator: Operator,
    val statusJa: String,
    val statusEn: String,
    val delayMinutes: Int,
    val messageEn: String,
    val timestamp: Long
) : Serializable
