package com.example.database

import androidx.room.TypeConverter
import com.example.model.Operator
import com.example.model.PassengerType
import com.example.model.TicketStatus
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

class Converters {
    private val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()

    @TypeConverter
    fun fromTicketStatus(value: TicketStatus): String = value.name

    @TypeConverter
    fun toTicketStatus(value: String): TicketStatus = TicketStatus.valueOf(value)

    @TypeConverter
    fun fromPassengerType(value: PassengerType): String = value.name

    @TypeConverter
    fun toPassengerType(value: String): PassengerType = PassengerType.valueOf(value)

    @TypeConverter
    fun fromOperatorList(operators: List<Operator>?): String? {
        if (operators == null) return null
        val type = Types.newParameterizedType(List::class.java, String::class.java)
        val adapter = moshi.adapter<List<String>>(type)
        return adapter.toJson(operators.map { it.name })
    }

    @TypeConverter
    fun toOperatorList(value: String?): List<Operator>? {
        if (value == null) return null
        val type = Types.newParameterizedType(List::class.java, String::class.java)
        val adapter = moshi.adapter<List<String>>(type)
        return adapter.fromJson(value)?.map { Operator.valueOf(it) }
    }
}
