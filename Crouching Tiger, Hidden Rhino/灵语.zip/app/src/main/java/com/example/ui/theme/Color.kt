package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val LingYuBackgroundDark = Color(0xFF0B0F17)
val LingYuSurfaceDark = Color(0xFF161F30)
val LingYuCardDark = Color(0xFF1E293B)
val LingYuPrimaryCyan = Color(0xFF38BDF8)
val LingYuSecondaryIndigo = Color(0xFF818CF8)
val LingYuAccentGreen = Color(0xFF10B981)
val LingYuTextWhite = Color(0xFFF8FAFC)
val LingYuTextMuted = Color(0xFF94A3B8)
val LingYuBorder = Color(0xFF334155)
val LingYuAlertRed = Color(0xFFEF4444)
