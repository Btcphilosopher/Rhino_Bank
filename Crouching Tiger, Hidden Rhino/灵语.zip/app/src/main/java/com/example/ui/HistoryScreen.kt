package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.database.ConversationDao
import com.example.data.database.ConversationEntity
import com.example.ui.theme.LingYuBackgroundDark
import com.example.ui.theme.LingYuBorder
import com.example.ui.theme.LingYuCardDark
import com.example.ui.theme.LingYuPrimaryCyan
import com.example.ui.theme.LingYuSurfaceDark
import com.example.ui.theme.LingYuTextMuted
import com.example.ui.theme.LingYuTextWhite
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoryScreen(
    conversationDao: ConversationDao,
    scope: CoroutineScope
) {
    val conversations by conversationDao.getRecentConversations().collectAsState(initial = emptyList())

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LingYuBackgroundDark)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "对话历史与执行链路",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = LingYuTextWhite
                )
            )

            if (conversations.isNotEmpty()) {
                IconButton(onClick = {
                    scope.launch(Dispatchers.IO) {
                        conversationDao.clearHistory()
                    }
                }) {
                    Icon(Icons.Default.Delete, contentDescription = "清空历史", tint = LingYuTextMuted)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (conversations.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "暂无对话历史记录",
                    style = MaterialTheme.typography.bodyLarge.copy(color = LingYuTextMuted)
                )
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(conversations) { conv ->
                    ConversationItemCard(conv)
                }
            }
        }
    }
}

@Composable
fun ConversationItemCard(conv: ConversationEntity) {
    val sdf = SimpleDateFormat("MM-dd HH:mm", Locale.CHINA)
    val dateStr = sdf.format(Date(conv.timestamp))

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = LingYuCardDark),
        border = androidx.compose.foundation.BorderStroke(1.dp, LingYuBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Surface(
                    color = LingYuSurfaceDark,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "意图: ${conv.intentName}",
                        style = MaterialTheme.typography.labelSmall.copy(color = LingYuPrimaryCyan),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Text(
                    text = "$dateStr | 延迟 ${conv.totalLatencyMs}ms",
                    style = MaterialTheme.typography.labelSmall.copy(color = LingYuTextMuted)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "语音: “${conv.userVoiceText}”",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = LingYuTextWhite,
                    fontWeight = FontWeight.SemiBold
                )
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "回答: ${conv.agentResponseText}",
                style = MaterialTheme.typography.bodySmall.copy(color = LingYuTextMuted)
            )

            if (conv.toolsUsed.isNotBlank() && conv.toolsUsed != "None") {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "调用的工具: ${conv.toolsUsed}",
                    style = MaterialTheme.typography.labelSmall.copy(color = LingYuPrimaryCyan)
                )
            }
        }
    }
}
