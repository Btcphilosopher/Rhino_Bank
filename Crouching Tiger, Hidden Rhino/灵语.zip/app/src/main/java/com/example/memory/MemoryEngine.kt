package com.example.memory

import com.example.data.database.MemoryDao
import com.example.data.database.MemoryEntity
import kotlinx.coroutines.flow.Flow

class MemoryEngine(private val memoryDao: MemoryDao) {

    val allMemories: Flow<List<MemoryEntity>> = memoryDao.getAllMemories()

    suspend fun remember(type: String, content: String, source: String = "对话分析"): Long {
        return memoryDao.insertMemory(
            MemoryEntity(
                type = type,
                content = content,
                source = source,
                confidence = 0.95f
            )
        )
    }

    suspend fun forgetByKeyword(keyword: String) {
        memoryDao.deleteMemoryByKeyword(keyword)
    }

    suspend fun deleteMemoryById(id: Long) {
        memoryDao.deleteMemory(id)
    }
}

class PersonalKnowledgeBase {
    fun queryKnowledge(keyword: String): List<String> {
        val mockKnowledge = listOf(
            "个人偏好：喜欢听轻音乐与古典爵士",
            "常用地址：公司位于张江高科技园区，家位于静安区",
            "工作习惯：每周五下午汇总周报，习惯早上8点阅读新闻",
            "健康事项：每日提醒早上8:00服药，每周二四跑步"
        )
        return mockKnowledge.filter { it.contains(keyword) }
    }
}
