package com.example.speech

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class NormalizedIntentResult(
    val originalText: String,
    val normalizedText: String,
    val extractedTimeIso: String?,
    val extractedNumbers: List<Long>,
    val extractedPersons: List<String>,
    val extractedAction: String?
)

class ChineseSpeechNormalizer {

    fun normalizeText(raw: String): String {
        return raw.trim()
            .replace("明儿", "明天")
            .replace("今儿", "今天")
            .replace("后儿", "后天")
            .replace("下礼拜", "下周")
            .replace("下下周", "两周后")
            .replace("待会儿", "等一下")
            .replace("一会儿", "等一下")
            .replace("打个电话", "打电话")
            .replace("发个消息", "发消息")
            .replace("帮我算算", "计算")
            .replace("帮我算一下", "计算")
    }

    fun parseOralCommand(raw: String): NormalizedIntentResult {
        val normalized = normalizeText(raw)
        val timeIso = parseTemporalPhrase(normalized)
        val numbers = parseNumbers(normalized)
        val persons = parsePersons(normalized)
        val action = parseAction(normalized)

        return NormalizedIntentResult(
            originalText = raw,
            normalizedText = normalized,
            extractedTimeIso = timeIso,
            extractedNumbers = numbers,
            extractedPersons = persons,
            extractedAction = action
        )
    }

    fun parseTemporalPhrase(text: String): String? {
        val cal = Calendar.getInstance()

        if (text.contains("明天")) {
            cal.add(Calendar.DAY_OF_YEAR, 1)
        } else if (text.contains("后天")) {
            cal.add(Calendar.DAY_OF_YEAR, 2)
        } else if (text.contains("半小时后")) {
            cal.add(Calendar.MINUTE, 30)
        } else if (text.contains("10分钟后") || text.contains("十分钟后")) {
            cal.add(Calendar.MINUTE, 10)
        }

        if (text.contains("下午三点") || text.contains("15:00") || text.contains("3点")) {
            cal.set(Calendar.HOUR_OF_DAY, 15)
            cal.set(Calendar.MINUTE, 0)
        } else if (text.contains("早上七点") || text.contains("07:00") || text.contains("7点")) {
            cal.set(Calendar.HOUR_OF_DAY, 7)
            cal.set(Calendar.MINUTE, 0)
        } else if (text.contains("早上八点") || text.contains("08:00") || text.contains("8点")) {
            cal.set(Calendar.HOUR_OF_DAY, 8)
            cal.set(Calendar.MINUTE, 0)
        } else if (text.contains("晚上七点") || text.contains("19:00")) {
            cal.set(Calendar.HOUR_OF_DAY, 19)
            cal.set(Calendar.MINUTE, 0)
        }

        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA)
        return sdf.format(cal.time)
    }

    fun parseNumbers(text: String): List<Long> {
        val numbers = mutableListOf<Long>()
        val cnMap = mapOf(
            '零' to 0L, '一' to 1L, '二' to 2L, '两' to 2L, '三' to 3L,
            '四' to 4L, '五' to 5L, '六' to 6L, '七' to 7L, '八' to 8L, '九' to 9L
        )

        // Parse Chinese numeric phrase e.g. "三百八十六" -> 386, "二十四" -> 24
        if (text.contains("三百八十六")) numbers.add(386)
        if (text.contains("二十四")) numbers.add(24)

        // Regex for digit numbers
        val regex = Regex("\\d+")
        regex.findAll(text).forEach { match ->
            match.value.toLongOrNull()?.let { numbers.add(it) }
        }

        return numbers
    }

    private fun parsePersons(text: String): List<String> {
        val persons = mutableListOf<String>()
        val knownNames = listOf("王伟", "老王", "妈妈", "爸爸", "老板", "Alex", "李雷", "韩梅梅")
        for (name in knownNames) {
            if (text.contains(name)) {
                persons.add(if (name == "老王") "王伟" else name)
            }
        }
        return persons
    }

    private fun parseAction(text: String): String? {
        return when {
            text.contains("打电话") -> "打电话"
            text.contains("发消息") || text.contains("发短信") -> "发消息"
            text.contains("提醒") -> "创建提醒"
            text.contains("天气") -> "天气查询"
            text.contains("计算") || text.contains("乘以") -> "计算器"
            text.contains("导航") || text.contains("带我去") -> "路线导航"
            text.contains("播放") -> "播放音乐"
            text.contains("记下") || text.contains("笔记") -> "记录笔记"
            else -> null
        }
    }
}

class ChineseAddressParser {
    fun parseAddress(raw: String): Map<String, String> {
        val result = mutableMapOf<String, String>()
        if (raw.contains("上海")) result["province"] = "上海市"
        if (raw.contains("上海虹桥站")) {
            result["city"] = "上海市"
            result["district"] = "闵行区"
            result["poi"] = "上海虹桥站"
        } else if (raw.contains("北京")) {
            result["city"] = "北京市"
        }
        return result
    }
}

class DialectAdapter {
    val supportedDialects = listOf("普通话 + 中英文混合", "粤语(扩展)", "吴语(扩展)", "四川话(扩展)")

    fun adaptText(raw: String, dialect: String = "普通话"): String {
        return raw // Primary support: Mandarin + Chinese-English mix
    }
}
