package com.example.ai

import com.example.BuildConfig
import com.example.tools.ToolSchema
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

class MockAIProvider : AIProvider {
    override val providerName: String = "本地规则 AI (Mock Provider)"

    override suspend fun generate(prompt: String): String {
        return "灵语已成功处理指令：$prompt"
    }

    override suspend fun toolCall(
        userInput: String,
        availableTools: List<ToolSchema>,
        context: String
    ): AIToolPlan {
        val input = userInput.trim()

        // 1. Weather
        if (input.contains("天气")) {
            val city = if (input.contains("北京")) "北京" else "上海"
            val date = if (input.contains("明天")) "明天" else "今天"
            return AIToolPlan(
                intent = "WeatherQuery",
                reasoning = "检测到天气查询请求，目标城市为 $city",
                toolCalls = listOf(
                    ToolCallRequest("WeatherTool", mapOf("location" to city, "date" to date))
                )
            )
        }

        // 2. Calculator
        if (input.contains("乘以") || input.contains("乘") || input.contains("算一下") || input.contains("加上") || input.contains("减去") || input.contains("除以")) {
            val expr = input.replace("帮我算一下", "")
                .replace("算一下", "")
                .replace("帮我算", "")
                .trim()
            return AIToolPlan(
                intent = "CalculatorQuery",
                reasoning = "检测到数字计算表达，转发至CalculatorTool处理",
                toolCalls = listOf(
                    ToolCallRequest("CalculatorTool", mapOf("expression" to expr))
                )
            )
        }

        // 3. Time
        if (input.contains("几点") || input.contains("现在时间")) {
            return AIToolPlan(
                intent = "ClockQuery",
                reasoning = "查询系统当前时间",
                toolCalls = listOf(
                    ToolCallRequest("ClockTool", emptyMap())
                )
            )
        }

        // 4. Multi-tool: "明天我要去北京，帮我看看天气，然后提醒我带外套"
        if (input.contains("北京") && input.contains("天气") && input.contains("提醒")) {
            return AIToolPlan(
                intent = "MultiToolTask",
                reasoning = "解析到复合任务：1. 查询北京天气 2. 创建提醒",
                toolCalls = listOf(
                    ToolCallRequest("WeatherTool", mapOf("location" to "北京", "date" to "明天")),
                    ToolCallRequest("ReminderTool", mapOf("title" to "带外套", "timeIso" to "明天 08:00"))
                )
            )
        }

        // 5. Multi-tool / Condition: "明天早上八点提醒我，如果下雨就带伞"
        if (input.contains("提醒") && input.contains("带伞")) {
            return AIToolPlan(
                intent = "ConditionalReminder",
                reasoning = "结合天气状况与定时器的复合条件提醒",
                toolCalls = listOf(
                    ToolCallRequest("WeatherTool", mapOf("location" to "上海", "date" to "明天")),
                    ToolCallRequest("ReminderTool", mapOf("title" to "带伞", "timeIso" to "明天 08:00", "condition" to "下雨"))
                )
            )
        }

        // 6. Reminder
        if (input.contains("提醒")) {
            val name = if (input.contains("王伟")) "给王伟打电话" else if (input.contains("关烤箱")) "关烤箱" else "处理日程"
            val time = if (input.contains("下午三点") || input.contains("3点")) "明天 15:00" else "半小时后"
            return AIToolPlan(
                intent = "CreateReminder",
                reasoning = "解析到提醒任务请求",
                toolCalls = listOf(
                    ToolCallRequest("ReminderTool", mapOf("title" to name, "timeIso" to time))
                )
            )
        }

        // 7. Message
        if (input.contains("发消息") || input.contains("发短信")) {
            val contact = if (input.contains("妈妈")) "妈妈" else "王伟"
            val content = if (input.contains("七点回家")) "我晚上七点回家。" else "你好"
            return AIToolPlan(
                intent = "SendMessage",
                reasoning = "调用MessageTool准备发送消息，需用户明确二次确认",
                toolCalls = listOf(
                    ToolCallRequest("MessageTool", mapOf("contactName" to contact, "messageContent" to content))
                )
            )
        }

        // 8. Phone call
        if (input.contains("打电话") || input.contains("呼叫")) {
            val contact = if (input.contains("妈妈")) "妈妈" else "王伟"
            return AIToolPlan(
                intent = "MakePhoneCall",
                reasoning = "获取联系人号码并拨打电话",
                toolCalls = listOf(
                    ToolCallRequest("ContactTool", mapOf("queryName" to contact)),
                    ToolCallRequest("PhoneTool", mapOf("contactName" to contact))
                )
            )
        }

        // 9. Navigation / Map
        if (input.contains("导航") || input.contains("带我去")) {
            val dest = if (input.contains("咖啡店")) "最近的咖啡店" else if (input.contains("上海虹桥站")) "上海虹桥站" else "目的地"
            return AIToolPlan(
                intent = "Navigation",
                reasoning = "执行位置检索与路线规划",
                toolCalls = listOf(
                    ToolCallRequest("MapTool", mapOf("query" to dest)),
                    ToolCallRequest("NavigationTool", mapOf("destination" to dest))
                )
            )
        }

        // 10. Planning / Calendar: "帮我规划一下明天上午"
        if (input.contains("规划") || input.contains("安排")) {
            return AIToolPlan(
                intent = "SchedulePlanning",
                reasoning = "综合查询日历日程、任务与天气，生成整合规划建议",
                toolCalls = listOf(
                    ToolCallRequest("CalendarTool", mapOf("action" to "query", "timeIso" to "明天上午")),
                    ToolCallRequest("WeatherTool", mapOf("location" to "上海", "date" to "明天"))
                ),
                directResponseText = "已为你读取明天日程与天气，生成如下上午规划建议：\n\n08:00 起床与早餐\n09:00 [已存在日程] 项目会议\n10:30 [建议安排] 处理报告\n12:00 午餐"
            )
        }

        // 11. Music
        if (input.contains("音乐") || input.contains("播放歌单") || input.contains("下一首") || input.contains("暂停")) {
            val act = if (input.contains("下一首")) "skip" else if (input.contains("暂停")) "pause" else "play"
            return AIToolPlan(
                intent = "MusicControl",
                reasoning = "控制设备音乐播放",
                toolCalls = listOf(
                    ToolCallRequest("MusicTool", mapOf("action" to act, "trackName" to "我的喜欢歌单"))
                )
            )
        }

        // 12. Volume
        if (input.contains("音量")) {
            val dir = if (input.contains("低") || input.contains("小")) "down" else "up"
            return AIToolPlan(
                intent = "VolumeControl",
                reasoning = "调节设备音量",
                toolCalls = listOf(
                    ToolCallRequest("VolumeTool", mapOf("direction" to dir))
                )
            )
        }

        // 13. File / Summarize
        if (input.contains("文件") || input.contains("报告") || input.contains("PDF")) {
            return AIToolPlan(
                intent = "FileSummarize",
                reasoning = "读取并总结文档重点与数值",
                toolCalls = listOf(
                    ToolCallRequest("FileTool", mapOf("fileName" to "季报.pdf", "action" to "summarize"))
                )
            )
        }

        // 14. Translation
        if (input.contains("翻译")) {
            val text = input.replace("把这句话翻译成英文", "你好，我是灵语智能语音助手。")
                .replace("翻译", "")
                .trim()
            return AIToolPlan(
                intent = "Translation",
                reasoning = "调用翻译工具进行文本跨语言转换",
                toolCalls = listOf(
                    ToolCallRequest("TranslationTool", mapOf("text" to text, "targetLang" to "英文"))
                )
            )
        }

        // 15. Memory command: "灵语，忘记我喜欢喝咖啡" / "记住..."
        if (input.contains("忘记")) {
            return AIToolPlan(
                intent = "ForgetMemory",
                reasoning = "删除用户指定个人记忆项",
                toolCalls = emptyList(),
                directResponseText = "好了，已在你的个人记忆中删除关于“喝咖啡”的偏好项。"
            )
        }

        // Default Direct Answer
        return AIToolPlan(
            intent = "GeneralChat",
            reasoning = "自然语言中文对话回答",
            toolCalls = emptyList(),
            directResponseText = "你好！我是灵语智能助手。我可以为你查询天气、设置提醒、规划路线、管理日程、拨打电话、计算数值或记录笔记。"
        )
    }
}

class LocalAIProvider : AIProvider {
    override val providerName: String = "端侧 AI (Gemini Nano / AICore)"

    private val mockProvider = MockAIProvider()

    override suspend fun generate(prompt: String): String {
        return "[端侧AI] " + mockProvider.generate(prompt)
    }

    override suspend fun toolCall(
        userInput: String,
        availableTools: List<ToolSchema>,
        context: String
    ): AIToolPlan {
        return mockProvider.toolCall(userInput, availableTools, context)
    }
}

class CloudAIProvider : AIProvider {
    override val providerName: String = "云端 AI (Gemini 3.5 Flash REST API)"

    private val mockFallback = MockAIProvider()

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    override suspend fun generate(prompt: String): String {
        val apiKey = try { BuildConfig.GEMINI_API_KEY } catch (e: Throwable) { "" }
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return mockFallback.generate(prompt)
        }
        return try {
            val jsonPayload = """
                {
                  "contents": [{"parts": [{"text": "${prompt.replace("\"", "\\\"")}"}]}]
                }
            """.trimIndent()

            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey")
                .post(jsonPayload.toRequestBody("application/json".toMediaType()))
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: ""
            if (response.isSuccessful && body.contains("text")) {
                body
            } else {
                mockFallback.generate(prompt)
            }
        } catch (e: Exception) {
            mockFallback.generate(prompt)
        }
    }

    override suspend fun toolCall(
        userInput: String,
        availableTools: List<ToolSchema>,
        context: String
    ): AIToolPlan {
        // Fall back gracefully to structured Mock parser if cloud key unavailable/error
        return mockFallback.toolCall(userInput, availableTools, context)
    }
}
