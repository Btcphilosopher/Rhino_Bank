package com.example.tools

enum class RiskLevel {
    LOW, MEDIUM, HIGH
}

data class ToolParameter(
    val name: String,
    val type: String, // String, Number, Boolean
    val description: String,
    val required: Boolean = true
)

data class ToolSchema(
    val name: String,
    val description: String,
    val parameters: List<ToolParameter>,
    val riskLevel: RiskLevel,
    val requiresConfirmation: Boolean = false,
    val permissionRequired: String? = null
)

data class ToolResult(
    val success: Boolean,
    val data: Map<String, Any?> = emptyMap(),
    val resultText: String,
    val error: String? = null,
    val confirmationPrompt: String? = null
)

data class ToolContext(
    val currentCity: String = "上海",
    val userLat: Double = 31.2304,
    val userLng: Double = 121.4737,
    val isNetworkAvailable: Boolean = true
)

interface Tool {
    val schema: ToolSchema
    suspend fun execute(args: Map<String, Any?>, context: ToolContext): ToolResult
}
