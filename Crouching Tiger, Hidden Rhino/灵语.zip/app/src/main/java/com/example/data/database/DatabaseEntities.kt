package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String, // PREFERENCE, FACT, TASK, DIALOGUE
    val content: String,
    val source: String,
    val confidence: Float = 1.0f,
    val createdAt: Long = System.currentTimeMillis(),
    val userControlled: Boolean = true
)

@Entity(tableName = "reminders")
data class ReminderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val timeIso: String,
    val isCompleted: Boolean = false,
    val recurrence: String? = null,
    val condition: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "automations")
data class AutomationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val trigger: String,
    val condition: String? = null,
    val action: String,
    val isEnabled: Boolean = true,
    val lastRunTime: Long = 0
)

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userVoiceText: String,
    val agentResponseText: String,
    val intentName: String,
    val toolsUsed: String,
    val totalLatencyMs: Long,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "agent_runs")
data class AgentRunEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userInput: String,
    val planJson: String,
    val executionResultJson: String,
    val status: String, // SUCCESS, FAILED, CONFIRMATION_REQUIRED
    val timestamp: Long = System.currentTimeMillis()
)
