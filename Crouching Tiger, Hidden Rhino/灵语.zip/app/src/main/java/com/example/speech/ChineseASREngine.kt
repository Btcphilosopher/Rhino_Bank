package com.example.speech

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.Locale

enum class ASRMode {
    ON_DEVICE,
    CLOUD,
    MOCK
}

class ChineseASREngine(private val context: Context) {

    private val _partialText = MutableStateFlow("")
    val partialText: StateFlow<String> = _partialText

    private val _finalText = MutableStateFlow("")
    val finalText: StateFlow<String> = _finalText

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening

    private val _activeMode = MutableStateFlow(ASRMode.MOCK)
    val activeMode: StateFlow<ASRMode> = _activeMode

    private var speechRecognizer: SpeechRecognizer? = null

    init {
        checkAndInitRecognizer()
    }

    fun checkAndInitRecognizer() {
        try {
            if (SpeechRecognizer.isRecognitionAvailable(context)) {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S &&
                    SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
                ) {
                    speechRecognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
                    _activeMode.value = ASRMode.ON_DEVICE
                } else {
                    speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)
                    _activeMode.value = ASRMode.CLOUD
                }
                setupRecognitionListener()
            } else {
                _activeMode.value = ASRMode.MOCK
            }
        } catch (e: Exception) {
            _activeMode.value = ASRMode.MOCK
        }
    }

    private fun setupRecognitionListener() {
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                _isListening.value = true
            }

            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                _isListening.value = false
            }

            override fun onError(error: Int) {
                _isListening.value = false
            }

            override fun onResults(results: Bundle?) {
                _isListening.value = false
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    val result = matches[0]
                    _partialText.value = result
                    _finalText.value = result
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    _partialText.value = matches[0]
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }

    fun startListening() {
        _partialText.value = ""
        _finalText.value = ""

        if (_activeMode.value == ASRMode.MOCK || speechRecognizer == null) {
            _isListening.value = true
            return
        }

        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.SIMPLIFIED_CHINESE.toString())
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            }
            speechRecognizer?.startListening(intent)
            _isListening.value = true
        } catch (e: Exception) {
            _activeMode.value = ASRMode.MOCK
            _isListening.value = true
        }
    }

    fun stopListening() {
        _isListening.value = false
        try {
            speechRecognizer?.stopListening()
        } catch (e: Exception) {
            // Ignore
        }
    }

    fun simulateSpokenText(simulatedText: String) {
        _partialText.value = simulatedText
        _finalText.value = simulatedText
        _isListening.value = false
    }

    fun destroy() {
        try {
            speechRecognizer?.destroy()
        } catch (e: Exception) {
            // Ignore
        }
    }
}

class WakeWordEngine {
    private val _isWakeWordDetected = MutableStateFlow(false)
    val isWakeWordDetected: StateFlow<Boolean> = _isWakeWordDetected

    fun triggerWakeWord() {
        _isWakeWordDetected.value = true
    }

    fun resetWakeWord() {
        _isWakeWordDetected.value = false
    }
}
