package com.example.security

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class PrivacyManager {
    private val _isPrivacyMode = MutableStateFlow(false)
    val isPrivacyMode: StateFlow<Boolean> = _isPrivacyMode

    private val _isOfflineMode = MutableStateFlow(false)
    val isOfflineMode: StateFlow<Boolean> = _isOfflineMode

    fun setPrivacyMode(enabled: Boolean) {
        _isPrivacyMode.value = enabled
    }

    fun setOfflineMode(enabled: Boolean) {
        _isOfflineMode.value = enabled
    }

    fun getProcessingBadgeText(): String {
        return if (_isPrivacyMode.value || _isOfflineMode.value) {
            "● 本地处理"
        } else {
            "☁ 云端处理"
        }
    }
}
