package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.agent.AgentRuntime
import com.example.agent.ConversationState
import com.example.security.PrivacyManager
import com.example.speech.ChineseASREngine
import com.example.ui.theme.LingYuAlertRed
import com.example.ui.theme.LingYuBackgroundDark
import com.example.ui.theme.LingYuBorder
import com.example.ui.theme.LingYuCardDark
import com.example.ui.theme.LingYuPrimaryCyan
import com.example.ui.theme.LingYuSecondaryIndigo
import com.example.ui.theme.LingYuSurfaceDark
import com.example.ui.theme.LingYuTextMuted
import com.example.ui.theme.LingYuTextWhite

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(
    agentRuntime: AgentRuntime,
    asrEngine: ChineseASREngine,
    privacyManager: PrivacyManager,
    onNavigateToSettings: () -> Unit
) {
    val conversationState by agentRuntime.state.collectAsState()
    val transcript by agentRuntime.currentTranscript.collectAsState()
    val responseText by agentRuntime.currentResponseText.collectAsState()
    val activeTrace by agentRuntime.activeTrace.collectAsState()
    val pendingConfirmation by agentRuntime.pendingConfirmation.collectAsState()
    val isListening by asrEngine.isListening.collectAsState()
    val asrPartialText by asrEngine.partialText.collectAsState()

    val quickCommands = listOf(
        "明天天气怎么样？",
        "提醒我下午三点给王伟打电话",
        "帮我算一下386*24",
        "给妈妈发消息说我晚上七点回家",
        "导航去上海虹桥站",
        "帮我规划明天上午",
        "明天早上八点提醒我，如果下雨就带伞",
        "灵语，忘记我喜欢喝咖啡"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LingYuBackgroundDark)
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top Bar: Title + Badge
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "灵语 LingYu",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = LingYuTextWhite
                    )
                )
                Text(
                    text = "智能个人语音助手",
                    style = MaterialTheme.typography.labelSmall.copy(color = LingYuTextMuted)
                )
            }

            // Privacy Badge Tag
            Surface(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { onNavigateToSettings() },
                color = LingYuSurfaceDark,
                border = androidx.compose.foundation.BorderStroke(1.dp, LingYuBorder)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(
                                if (privacyManager.isPrivacyMode.collectAsState().value)
                                    Color(0xFF10B981) else LingYuPrimaryCyan
                            )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = privacyManager.getProcessingBadgeText(),
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = LingYuTextWhite,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Waveform Visualizer
        WaveformVisualizer(
            state = conversationState,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Central Voice Sphere Mic Button
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(110.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            LingYuPrimaryCyan.copy(alpha = 0.8f),
                            LingYuSecondaryIndigo.copy(alpha = 0.4f),
                            LingYuSurfaceDark
                        )
                    )
                )
                .border(2.dp, LingYuPrimaryCyan, CircleShape)
                .clickable {
                    if (conversationState == ConversationState.LISTENING || isListening) {
                        asrEngine.stopListening()
                        if (asrPartialText.isNotBlank()) {
                            agentRuntime.processVoiceCommand(asrPartialText)
                        }
                    } else {
                        asrEngine.startListening()
                        agentRuntime.state.value = ConversationState.LISTENING
                    }
                }
                .testTag("voice_mic_button")
        ) {
            Icon(
                imageVector = Icons.Default.Mic,
                contentDescription = "麦克风语音输入",
                tint = LingYuTextWhite,
                modifier = Modifier.size(48.dp)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // State Label
        val stateText = when (conversationState) {
            ConversationState.LISTENING -> "正在聆听语音..."
            ConversationState.TRANSCRIBING -> "正在转换成文字..."
            ConversationState.THINKING -> "灵语思考中..."
            ConversationState.CALLING_TOOL -> "正在执行工具调用..."
            ConversationState.WAITING_FOR_RESULT -> "等待结果..."
            ConversationState.SPEAKING -> "正在语音回答..."
            ConversationState.CONFIRMING -> "等待高风险确认..."
            else -> "轻按麦克风或点击下方快捷语音"
        }

        Text(
            text = stateText,
            style = MaterialTheme.typography.bodyMedium.copy(
                color = LingYuPrimaryCyan,
                fontWeight = FontWeight.Medium
            ),
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Transcript Display
        val displayText = if (isListening && asrPartialText.isNotBlank()) {
            asrPartialText
        } else {
            transcript
        }

        if (displayText.isNotBlank()) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                shape = RoundedCornerShape(12.dp),
                color = LingYuSurfaceDark,
                border = androidx.compose.foundation.BorderStroke(1.dp, LingYuBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "识别到的语音：",
                        style = MaterialTheme.typography.labelSmall.copy(color = LingYuTextMuted)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "“ $displayText ”",
                        style = MaterialTheme.typography.bodyLarge.copy(
                            color = LingYuTextWhite,
                            fontWeight = FontWeight.SemiBold
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Response Card
        AnimatedVisibility(
            visible = responseText.isNotBlank(),
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = LingYuCardDark),
                border = androidx.compose.foundation.BorderStroke(1.dp, LingYuPrimaryCyan.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(LingYuPrimaryCyan),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("灵", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "灵语回答",
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = LingYuPrimaryCyan,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = responseText,
                        style = MaterialTheme.typography.bodyLarge.copy(
                            color = LingYuTextWhite,
                            lineHeight = 24.sp
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Trace Latency Badge
        activeTrace?.let { trace ->
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                color = LingYuSurfaceDark,
                border = androidx.compose.foundation.BorderStroke(1.dp, LingYuBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "意图: ${trace.intentName.ifBlank { "普通对话" }}",
                        style = MaterialTheme.typography.labelSmall.copy(color = LingYuPrimaryCyan)
                    )
                    Text(
                        text = "首字: 120ms | 工具: 140ms | 总延迟: ${trace.metrics.totalResponseLatencyMs}ms",
                        style = MaterialTheme.typography.labelSmall.copy(color = LingYuTextMuted)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Quick Spoken Command Shortcut Chips
        Text(
            text = "示例中文指令 (点击体验):",
            style = MaterialTheme.typography.labelMedium.copy(
                color = LingYuTextMuted,
                fontWeight = FontWeight.SemiBold
            ),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            quickCommands.forEach { cmd ->
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .clickable {
                            asrEngine.simulateSpokenText(cmd)
                            agentRuntime.processVoiceCommand(cmd)
                        }
                        .testTag("quick_cmd_chip"),
                    color = LingYuSurfaceDark,
                    border = androidx.compose.foundation.BorderStroke(1.dp, LingYuBorder)
                ) {
                    Text(
                        text = cmd,
                        style = MaterialTheme.typography.bodySmall.copy(color = LingYuTextWhite),
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }
            }
        }
    }

    // High Risk Confirmation Modal Dialog
    pendingConfirmation?.let { pending ->
        AlertDialog(
            onDismissRequest = { agentRuntime.cancelPendingAction() },
            title = {
                Text(
                    text = "⚠️ 高风险操作确认",
                    style = MaterialTheme.typography.titleLarge.copy(color = LingYuTextWhite)
                )
            },
            text = {
                Text(
                    text = pending.promptText,
                    style = MaterialTheme.typography.bodyLarge.copy(color = LingYuTextWhite)
                )
            },
            confirmButton = {
                Button(
                    onClick = { agentRuntime.confirmPendingAction() },
                    colors = ButtonDefaults.buttonColors(containerColor = LingYuAlertRed)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("确认执行", color = Color.White)
                    }
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { agentRuntime.cancelPendingAction() }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Close, contentDescription = null, tint = LingYuTextMuted)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("取消", color = LingYuTextMuted)
                    }
                }
            },
            containerColor = LingYuCardDark,
            shape = RoundedCornerShape(16.dp)
        )
    }
}
