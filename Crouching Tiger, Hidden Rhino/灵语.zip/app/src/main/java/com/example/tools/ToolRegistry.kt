package com.example.tools

class ToolRegistry {
    private val toolsMap: Map<String, Tool> = listOf(
        WeatherTool(),
        ClockTool(),
        CalculatorTool(),
        TimerTool(),
        ReminderTool(),
        CalendarTool(),
        ContactTool(),
        PhoneTool(),
        MessageTool(),
        MapTool(),
        NavigationTool(),
        SearchTool(),
        TranslationTool(),
        NotesTool(),
        FileTool(),
        MusicTool(),
        VolumeTool(),
        DeviceSettingsTool()
    ).associateBy { it.schema.name }

    fun getTool(name: String): Tool? = toolsMap[name]

    fun getAllTools(): List<Tool> = toolsMap.values.toList()

    fun getAllSchemas(): List<ToolSchema> = toolsMap.values.map { it.schema }

    suspend fun executeTool(
        name: String,
        args: Map<String, Any?>,
        context: ToolContext = ToolContext()
    ): ToolResult {
        val tool = toolsMap[name] ?: return ToolResult(
            success = false,
            resultText = "未找到名为 '$name' 的工具。",
            error = "Tool not found"
        )

        return try {
            tool.execute(args, context)
        } catch (e: Exception) {
            ToolResult(
                success = false,
                resultText = "工具执行出错：${e.message}",
                error = e.message
            )
        }
    }
}
