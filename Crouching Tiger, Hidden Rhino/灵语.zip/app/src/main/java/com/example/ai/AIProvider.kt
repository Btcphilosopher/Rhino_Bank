package com.example.ai

import com.example.tools.ToolSchema

data class ToolCallRequest(
    val toolName: String,
    val arguments: Map<String, Any?>
)

data class AIToolPlan(
    val intent: String,
    val reasoning: String,
    val toolCalls: List<ToolCallRequest>,
    val directResponseText: String? = null,
    val clarificationNeeded: String? = null
)

interface AIProvider {
    val providerName: String
    suspend fun generate(prompt: String): String
    suspend fun toolCall(userInput: String, availableTools: List<ToolSchema>, context: String): AIToolPlan
}
