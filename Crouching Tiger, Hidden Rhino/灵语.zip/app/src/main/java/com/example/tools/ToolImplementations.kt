package com.example.tools

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class WeatherTool : Tool {
    override val schema = ToolSchema(
        name = "WeatherTool",
        description = "查询实时及未来天气情况",
        parameters = listOf(
            ToolParameter("location", "String", "城市或地区名称，如'上海', '北京'", required = false),
            ToolParameter("date", "String", "日期，如'明天', '今天', '后天'", required = false)
        ),
        riskLevel = RiskLevel.LOW
    )

    override suspend fun execute(args: Map<String, Any?>, context: ToolContext): ToolResult {
        val city = (args["location"] as? String)?.takeIf { it.isNotBlank() } ?: context.currentCity
        val dateStr = (args["date"] as? String) ?: "明天"
        
        val temp = if (city.contains("北京")) 15 else 18
        val condition = if (dateStr.contains("明天")) "小雨" else "多云转晴"
        val prob = if (condition.contains("雨")) 0.72 else 0.10

        val text = "${dateStr}${city}气温 ${temp}°C，${condition}，降水概率 ${(prob * 100).toInt()}%。建议出门带伞。"
        return ToolResult(
            success = true,
            data = mapOf(
                "city" to city,
                "temperature" to temp,
                "condition" to condition,
                "precipitationProbability" to prob,
                "date" to dateStr
            ),
            resultText = text
        )
    }
}

class ClockTool : Tool {
    override val schema = ToolSchema(
        name = "ClockTool",
        description = "获取当前系统精确时间与系统时钟",
        parameters = listOf(
            ToolParameter("timezone", "String", "时区，默认本地时区", required = false)
        ),
        riskLevel = RiskLevel.LOW
    )

    override suspend fun execute(args: Map<String, Any?>, context: ToolContext): ToolResult {
        val sdf = SimpleDateFormat("yyyy年MM月dd日 EEEE HH:mm:ss", Locale.CHINA)
        val nowStr = sdf.format(Date())
        return ToolResult(
            success = true,
            data = mapOf("currentTime" to nowStr, "timestamp" to System.currentTimeMillis()),
            resultText = "现在时间是 $nowStr。"
        )
    }
}

class CalculatorTool : Tool {
    override val schema = ToolSchema(
        name = "CalculatorTool",
        description = "进行准确的数值计算与代数运算",
        parameters = listOf(
            ToolParameter("expression", "String", "数学表达式，如 '386 * 24' 或 '125 + 75'", required = true)
        ),
        riskLevel = RiskLevel.LOW
    )

    override suspend fun execute(args: Map<String, Any?>, context: ToolContext): ToolResult {
        val expr = args["expression"]?.toString() ?: ""
        val sanitized = expr.replace("乘以", "*")
            .replace("乘", "*")
            .replace("除以", "/")
            .replace("除", "/")
            .replace("加上", "+")
            .replace("加", "+")
            .replace("减去", "-")
            .replace("减", "-")
            .replace("x", "*")
            .replace("X", "*")
            .filter { it.isDigit() || it in "+-*/(). " }
            .trim()

        return try {
            val result = evaluateSimpleExpr(sanitized)
            ToolResult(
                success = true,
                data = mapOf("expression" to expr, "calculatedResult" to result),
                resultText = "$expr 计算结果为 $result。"
            )
        } catch (e: Exception) {
            ToolResult(
                success = false,
                resultText = "计算失败，请检查表达式：$expr",
                error = e.message
            )
        }
    }

    private fun evaluateSimpleExpr(expr: String): Double {
        if (expr.contains("*")) {
            val parts = expr.split("*")
            return parts[0].trim().toDouble() * parts[1].trim().toDouble()
        }
        if (expr.contains("/")) {
            val parts = expr.split("/")
            return parts[0].trim().toDouble() / parts[1].trim().toDouble()
        }
        if (expr.contains("+")) {
            val parts = expr.split("+")
            return parts[0].trim().toDouble() + parts[1].trim().toDouble()
        }
        if (expr.contains("-")) {
            val parts = expr.split("-")
            return parts[0].trim().toDouble() - parts[1].trim().toDouble()
        }
        return expr.trim().toDouble()
    }
}

class TimerTool : Tool {
    override val schema = ToolSchema(
        name = "TimerTool",
        description = "设置倒计时定时器",
        parameters = listOf(
            ToolParameter("durationSeconds", "Number", "倒计时时长（秒）", required = true),
            ToolParameter("label", "String", "定时器标签，如'关烤箱'", required = false)
        ),
        riskLevel = RiskLevel.LOW
    )

    override suspend fun execute(args: Map<String, Any?>, context: ToolContext): ToolResult {
        val secs = (args["durationSeconds"] as? Number)?.toInt() ?: 1800
        val label = (args["label"] as? String) ?: "定时器"
        val mins = secs / 60
        val displayStr = if (mins > 0) "${mins}分钟" else "${secs}秒"

        return ToolResult(
            success = true,
            data = mapOf("durationSeconds" to secs, "label" to label),
            resultText = "已成功为你开启 $displayStr 的【$label】倒计时。"
        )
    }
}

class ReminderTool : Tool {
    override val schema = ToolSchema(
        name = "ReminderTool",
        description = "创建个人日程或任务提醒",
        parameters = listOf(
            ToolParameter("title", "String", "提醒内容，如'给王伟打电话'", required = true),
            ToolParameter("timeIso", "String", "提醒时间，如'明天 15:00'", required = true),
            ToolParameter("condition", "String", "条件提醒（可选），如'下雨'", required = false)
        ),
        riskLevel = RiskLevel.LOW
    )

    override suspend fun execute(args: Map<String, Any?>, context: ToolContext): ToolResult {
        val title = (args["title"] as? String) ?: "未命名提醒"
        val timeIso = (args["timeIso"] as? String) ?: "明天 15:00"
        val cond = args["condition"] as? String

        val text = if (cond.isNull_or_empty_custom()) {
            "好的，已设置于 $timeIso 提醒你：$title。"
        } else {
            "好的，已设置条件提醒：$timeIso 如果 $cond 则提醒你：$title。"
        }

        return ToolResult(
            success = true,
            data = mapOf("title" to title, "timeIso" to timeIso, "condition" to (cond ?: "")),
            resultText = text
        )
    }
}

private fun String?.isNull_or_empty_custom(): Boolean = this.isNullOrEmpty() || this == "null"

class CalendarTool : Tool {
    override val schema = ToolSchema(
        name = "CalendarTool",
        description = "查询与安排系统日历日程",
        parameters = listOf(
            ToolParameter("action", "String", "动作：query/create", required = true),
            ToolParameter("title", "String", "日程标题，如'项目会议'", required = false),
            ToolParameter("timeIso", "String", "时间，如'明天 09:00'", required = false)
        ),
        riskLevel = RiskLevel.MEDIUM
    )

    override suspend fun execute(args: Map<String, Any?>, context: ToolContext): ToolResult {
        val action = (args["action"] as? String) ?: "query"
        val title = (args["title"] as? String) ?: "会议"
        val time = (args["timeIso"] as? String) ?: "明天 09:00"

        return if (action == "create") {
            ToolResult(
                success = true,
                data = mapOf("title" to title, "timeIso" to time),
                resultText = "已为你成功添加日历日程：$time $title。"
            )
        } else {
            ToolResult(
                success = true,
                data = mapOf("events" to listOf("$time $title")),
                resultText = "你明天的日程安排有：08:00 起床，09:00 $title，10:30 报告处理，12:00 午餐。"
            )
        }
    }
}

class ContactTool : Tool {
    override val schema = ToolSchema(
        name = "ContactTool",
        description = "查询通讯录联系人信息",
        parameters = listOf(
            ToolParameter("queryName", "String", "联系人姓名，如'妈妈', '王伟', 'Alex'", required = true)
        ),
        riskLevel = RiskLevel.LOW
    )

    override suspend fun execute(args: Map<String, Any?>, context: ToolContext): ToolResult {
        val name = (args["queryName"] as? String) ?: ""
        val mockContacts = mapOf(
            "妈妈" to "13800138000",
            "王伟" to "13912345678",
            "Alex" to "13598765432",
            "爸爸" to "13700137000",
            "老板" to "18611223344"
        )

        val phone = mockContacts[name]
        return if (phone != null) {
            ToolResult(
                success = true,
                data = mapOf("contactName" to name, "phoneNumber" to phone),
                resultText = "已找到联系人 $name，电话号码：$phone。"
            )
        } else {
            ToolResult(
                success = true,
                data = mapOf("contactName" to name, "matches" to listOf("${name}1 (138***)", "${name}2 (139***)")),
                resultText = "在通讯录中找到匹配的联系人：$name。"
            )
        }
    }
}

class PhoneTool : Tool {
    override val schema = ToolSchema(
        name = "PhoneTool",
        description = "发起电话拨打（高风险操作，需确认）",
        parameters = listOf(
            ToolParameter("contactName", "String", "联系人姓名", required = true),
            ToolParameter("phoneNumber", "String", "电话号码", required = false)
        ),
        riskLevel = RiskLevel.HIGH,
        requiresConfirmation = true,
        permissionRequired = "android.permission.CALL_PHONE"
    )

    override suspend fun execute(args: Map<String, Any?>, context: ToolContext): ToolResult {
        val name = (args["contactName"] as? String) ?: "联系人"
        val phone = (args["phoneNumber"] as? String) ?: "13800138000"

        return ToolResult(
            success = true,
            data = mapOf("contactName" to name, "phoneNumber" to phone),
            resultText = "正在呼叫 $name ($phone)...",
            confirmationPrompt = "确认要给 $name ($phone) 拨打电话吗？"
        )
    }
}

class MessageTool : Tool {
    override val schema = ToolSchema(
        name = "MessageTool",
        description = "发送短信或消息（高风险操作，需确认）",
        parameters = listOf(
            ToolParameter("contactName", "String", "接收人姓名", required = true),
            ToolParameter("messageContent", "String", "发送的消息内容", required = true)
        ),
        riskLevel = RiskLevel.HIGH,
        requiresConfirmation = true,
        permissionRequired = "android.permission.SEND_SMS"
    )

    override suspend fun execute(args: Map<String, Any?>, context: ToolContext): ToolResult {
        val name = (args["contactName"] as? String) ?: "联系人"
        val content = (args["messageContent"] as? String) ?: ""

        return ToolResult(
            success = true,
            data = mapOf("contactName" to name, "messageContent" to content),
            resultText = "已发送消息给 $name：“$content”",
            confirmationPrompt = "要发送给$name：\n\n“$content”\n\n确认发送吗？"
        )
    }
}

class MapTool : Tool {
    override val schema = ToolSchema(
        name = "MapTool",
        description = "查询附近地点、POI及地图位置信息",
        parameters = listOf(
            ToolParameter("query", "String", "查询关键词，如'咖啡店', '加油站', '上海虹桥站'", required = true)
        ),
        riskLevel = RiskLevel.LOW,
        permissionRequired = "android.permission.ACCESS_FINE_LOCATION"
    )

    override suspend fun execute(args: Map<String, Any?>, context: ToolContext): ToolResult {
        val query = (args["query"] as? String) ?: "咖啡店"
        val text = "在附近找到推荐地点：1. 星巴克咖啡（距离约450米） 2. 瑞幸咖啡（距离约600米）。"

        return ToolResult(
            success = true,
            data = mapOf(
                "query" to query,
                "places" to listOf(
                    mapOf("name" to "星巴克咖啡", "distance" to "450米"),
                    mapOf("name" to "瑞幸咖啡", "distance" to "600米")
                )
            ),
            resultText = text
        )
    }
}

class NavigationTool : Tool {
    override val schema = ToolSchema(
        name = "NavigationTool",
        description = "开启实时路线规划与地图导航",
        parameters = listOf(
            ToolParameter("destination", "String", "目的地，如'上海虹桥站'", required = true)
        ),
        riskLevel = RiskLevel.LOW
    )

    override suspend fun execute(args: Map<String, Any?>, context: ToolContext): ToolResult {
        val dest = (args["destination"] as? String) ?: "上海虹桥站"
        return ToolResult(
            success = true,
            data = mapOf("destination" to dest, "estimatedTimeMins" to 35, "distanceKm" to 21.5),
            resultText = "已为你规划去 $dest 的路线，全程约21.5公里，预计用时35分钟。要开始导航吗？"
        )
    }
}

class SearchTool : Tool {
    override val schema = ToolSchema(
        name = "SearchTool",
        description = "检索网络实时信息、新闻、百科事实",
        parameters = listOf(
            ToolParameter("query", "String", "搜索关键词", required = true)
        ),
        riskLevel = RiskLevel.LOW
    )

    override suspend fun execute(args: Map<String, Any?>, context: ToolContext): ToolResult {
        val query = (args["query"] as? String) ?: ""
        return ToolResult(
            success = true,
            data = mapOf("query" to query),
            resultText = "关于“$query”的最新结果：灵语已为你从网络获取最新资料并完成整理。"
        )
    }
}

class TranslationTool : Tool {
    override val schema = ToolSchema(
        name = "TranslationTool",
        description = "中文与英文等多语言实时互译",
        parameters = listOf(
            ToolParameter("text", "String", "待翻译文本", required = true),
            ToolParameter("targetLang", "String", "目标语言，如'英文', '中文'", required = false)
        ),
        riskLevel = RiskLevel.LOW
    )

    override suspend fun execute(args: Map<String, Any?>, context: ToolContext): ToolResult {
        val text = (args["text"] as? String) ?: ""
        val target = (args["targetLang"] as? String) ?: "英文"

        val translated = if (target.contains("英")) {
            "Translation: \"$text\" -> \"Hello, this is LingYu Intelligent Voice Assistant.\""
        } else {
            "翻译结果：“$text” -> “你好，我是灵语智能语音助手。”"
        }

        return ToolResult(
            success = true,
            data = mapOf("originalText" to text, "translatedText" to translated),
            resultText = translated
        )
    }
}

class NotesTool : Tool {
    override val schema = ToolSchema(
        name = "NotesTool",
        description = "记录与保存语音笔记或文本内容",
        parameters = listOf(
            ToolParameter("content", "String", "笔记内容", required = true)
        ),
        riskLevel = RiskLevel.LOW
    )

    override suspend fun execute(args: Map<String, Any?>, context: ToolContext): ToolResult {
        val content = (args["content"] as? String) ?: ""
        return ToolResult(
            success = true,
            data = mapOf("content" to content, "timestamp" to System.currentTimeMillis()),
            resultText = "好的，已将“$content”记入你的个人笔记库中。"
        )
    }
}

class FileTool : Tool {
    override val schema = ToolSchema(
        name = "FileTool",
        description = "读取、解析并总结本地文件或文档内容",
        parameters = listOf(
            ToolParameter("fileName", "String", "文件名或文档名称", required = true),
            ToolParameter("action", "String", "动作：summarize/extractNumbers/translate", required = false)
        ),
        riskLevel = RiskLevel.LOW
    )

    override suspend fun execute(args: Map<String, Any?>, context: ToolContext): ToolResult {
        val file = (args["fileName"] as? String) ?: "这份文件"
        val act = (args["action"] as? String) ?: "summarize"

        val text = when (act) {
            "extractNumbers" -> "文件《$file》中的关键财务数字：2026年Q2营收增长18.5%，净利润为3,860万元。"
            else -> "已解析《$file》：本文主要包含Q2季度总结、语音AI架构规划与下一步交付计划。"
        }

        return ToolResult(
            success = true,
            data = mapOf("fileName" to file, "action" to act),
            resultText = text
        )
    }
}

class MusicTool : Tool {
    override val schema = ToolSchema(
        name = "MusicTool",
        description = "控制音乐播放、歌单切换与暂停",
        parameters = listOf(
            ToolParameter("action", "String", "动作：play/pause/resume/skip/previous", required = true),
            ToolParameter("trackName", "String", "歌曲或歌单名称", required = false)
        ),
        riskLevel = RiskLevel.LOW
    )

    override suspend fun execute(args: Map<String, Any?>, context: ToolContext): ToolResult {
        val action = (args["action"] as? String) ?: "play"
        val track = (args["trackName"] as? String) ?: "我的喜欢歌单"

        val text = when (action) {
            "pause" -> "音乐已暂停。"
            "skip" -> "已为你切换到下一首歌曲。"
            "previous" -> "已切换到上一首歌曲。"
            else -> "已为你开始播放 $track。"
        }

        return ToolResult(
            success = true,
            data = mapOf("action" to action, "trackName" to track),
            resultText = text
        )
    }
}

class VolumeTool : Tool {
    override val schema = ToolSchema(
        name = "VolumeTool",
        description = "调节设备音量大小",
        parameters = listOf(
            ToolParameter("direction", "String", "调节方向：up/down/set", required = true),
            ToolParameter("level", "Number", "具体音量百分比（0-100）", required = false)
        ),
        riskLevel = RiskLevel.LOW
    )

    override suspend fun execute(args: Map<String, Any?>, context: ToolContext): ToolResult {
        val dir = (args["direction"] as? String) ?: "down"
        val text = if (dir == "down") "已将音量调低。" else "已调整设备音量。"

        return ToolResult(
            success = true,
            data = mapOf("direction" to dir),
            resultText = text
        )
    }
}

class DeviceSettingsTool : Tool {
    override val schema = ToolSchema(
        name = "DeviceSettingsTool",
        description = "控制系统设置（如WIFI、蓝牙、手电筒、勿扰模式）",
        parameters = listOf(
            ToolParameter("setting", "String", "设置项：wifi/bluetooth/flashlight/do_not_disturb", required = true),
            ToolParameter("action", "String", "动作：on/off/toggle", required = true)
        ),
        riskLevel = RiskLevel.LOW
    )

    override suspend fun execute(args: Map<String, Any?>, context: ToolContext): ToolResult {
        val setting = (args["setting"] as? String) ?: "flashlight"
        val action = (args["action"] as? String) ?: "toggle"

        val label = when (setting) {
            "wifi" -> "WLAN"
            "bluetooth" -> "蓝牙"
            "flashlight" -> "手电筒"
            else -> "系统设置"
        }

        return ToolResult(
            success = true,
            data = mapOf("setting" to setting, "action" to action),
            resultText = "已为你${if (action == "off") "关闭" else "开启"}$label。"
        )
    }
}
