package com.example.agent

class ClarificationEngine {

    fun checkAmbiguity(userInput: String): String? {
        if (userInput.contains("去见他") || userInput.contains("给他打电话")) {
            return "你是指联系人“王伟”还是“李雷”？"
        }
        if (userInput.contains("开会") && !userInput.contains("点") && !userInput.contains("时间")) {
            return "请问你希望安排在明天的什么时间开会？"
        }
        return null
    }
}
