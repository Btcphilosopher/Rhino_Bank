package com.example.context

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class RelevantContext(
    val currentTimeIso: String,
    val currentLocationCity: String,
    val activeApp: String = "灵语",
    val userMemoriesSummary: String = "偏好晨跑；喜欢轻音乐；常用地址静安区",
    val networkMode: String = "线上云端"
)

class ContextEngine {
    fun getCurrentContext(isPrivacyMode: Boolean = false): RelevantContext {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA)
        return RelevantContext(
            currentTimeIso = sdf.format(Date()),
            currentLocationCity = "上海",
            networkMode = if (isPrivacyMode) "离线/端侧" else "线上云端"
        )
    }
}
