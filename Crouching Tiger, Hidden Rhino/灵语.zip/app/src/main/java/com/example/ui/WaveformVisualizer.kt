package com.example.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.example.agent.ConversationState
import com.example.ui.theme.LingYuPrimaryCyan
import com.example.ui.theme.LingYuSecondaryIndigo
import kotlin.math.sin

@Composable
fun WaveformVisualizer(
    state: ConversationState,
    modifier: Modifier = Modifier
) {
    val phaseAnim = remember { Animatable(0f) }

    LaunchedEffect(state) {
        if (state == ConversationState.LISTENING ||
            state == ConversationState.THINKING ||
            state == ConversationState.SPEAKING
        ) {
            phaseAnim.animateTo(
                targetValue = (2 * Math.PI).toFloat(),
                animationSpec = infiniteRepeatable(
                    animation = tween(1200, easing = LinearEasing),
                    repeatMode = RepeatMode.Restart
                )
            )
        } else {
            phaseAnim.snapTo(0f)
        }
    }

    val amplitude = when (state) {
        ConversationState.LISTENING -> 35f
        ConversationState.THINKING -> 20f
        ConversationState.SPEAKING -> 40f
        else -> 6f
    }

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(70.dp)
    ) {
        val width = size.width
        val height = size.height
        val centerY = height / 2f

        if (width <= 0f) return@Canvas

        val path1 = Path()
        val path2 = Path()

        path1.moveTo(0f, centerY)
        path2.moveTo(0f, centerY)

        val step = 10f
        var x = 0f
        while (x <= width) {
            val progress = x / width
            // Windowing curve to taper wave edges smoothly
            val window = sin(progress * Math.PI).toFloat()

            val phase = phaseAnim.value
            val y1 = centerY + sin(x * 0.02f + phase).toFloat() * amplitude * window
            val y2 = centerY + sin(x * 0.03f - phase * 0.8f).toFloat() * (amplitude * 0.7f) * window

            path1.lineTo(x, y1)
            path2.lineTo(x, y2)
            x += step
        }

        drawPath(
            path = path1,
            color = LingYuPrimaryCyan,
            style = Stroke(width = 3.dp.toPx())
        )

        drawPath(
            path = path2,
            color = LingYuSecondaryIndigo.copy(alpha = 0.6f),
            style = Stroke(width = 2.dp.toPx())
        )
    }
}
