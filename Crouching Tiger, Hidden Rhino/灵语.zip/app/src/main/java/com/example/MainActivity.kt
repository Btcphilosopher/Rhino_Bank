package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.AutoMode
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.room.Room
import com.example.agent.AgentRuntime
import com.example.automation.AutomationEngine
import com.example.context.ContextEngine
import com.example.data.database.AppDatabase
import com.example.evaluation.EvaluationLab
import com.example.memory.MemoryEngine
import com.example.security.PrivacyManager
import com.example.speech.ChineseASREngine
import com.example.tools.ToolRegistry
import com.example.tts.ChineseTTSEngine
import com.example.ui.AutomationScreen
import com.example.ui.EvaluationScreen
import com.example.ui.HistoryScreen
import com.example.ui.HomeScreen
import com.example.ui.MemoryScreen
import com.example.ui.SettingsScreen
import com.example.ui.ToolsScreen
import com.example.ui.theme.LingYuBackgroundDark
import com.example.ui.theme.LingYuBorder
import com.example.ui.theme.LingYuPrimaryCyan
import com.example.ui.theme.LingYuSurfaceDark
import com.example.ui.theme.LingYuTextMuted
import com.example.ui.theme.LingYuTextWhite
import com.example.ui.theme.LingYuTheme

enum class AppNavDestination(val label: String, val icon: ImageVector) {
    HOME("灵语", Icons.Default.Mic),
    TOOLS("工具", Icons.Default.Widgets),
    MEMORY("记忆", Icons.Default.Psychology),
    AUTOMATION("自动化", Icons.Default.AutoMode),
    EVALUATION("评测", Icons.Default.Assessment),
    HISTORY("历史", Icons.Default.History),
    SETTINGS("设置", Icons.Default.Settings)
}

class MainActivity : ComponentActivity() {

    private lateinit var database: AppDatabase
    private lateinit var toolRegistry: ToolRegistry
    private lateinit var memoryEngine: MemoryEngine
    private lateinit var privacyManager: PrivacyManager
    private lateinit var contextEngine: ContextEngine
    private lateinit var ttsEngine: ChineseTTSEngine
    private lateinit var asrEngine: ChineseASREngine
    private lateinit var automationEngine: AutomationEngine
    private lateinit var evaluationLab: EvaluationLab

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        database = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "lingyu_voice_assistant.db"
        ).fallbackToDestructiveMigration().build()

        toolRegistry = ToolRegistry()
        memoryEngine = MemoryEngine(database.memoryDao())
        privacyManager = PrivacyManager()
        contextEngine = ContextEngine()
        ttsEngine = ChineseTTSEngine(this)
        asrEngine = ChineseASREngine(this)
        automationEngine = AutomationEngine(database.automationDao())
        evaluationLab = EvaluationLab()

        setContent {
            LingYuTheme {
                val scope = rememberCoroutineScope()
                val agentRuntime = remember {
                    AgentRuntime(
                        scope = scope,
                        toolRegistry = toolRegistry,
                        memoryEngine = memoryEngine,
                        privacyManager = privacyManager,
                        contextEngine = contextEngine,
                        conversationDao = database.conversationDao(),
                        reminderDao = database.reminderDao(),
                        ttsEngine = ttsEngine
                    )
                }

                var currentDestination by remember { mutableStateOf(AppNavDestination.HOME) }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        NavigationBar(
                            containerColor = LingYuSurfaceDark,
                            tonalElevation = 8.dp
                        ) {
                            AppNavDestination.values().forEach { dest ->
                                val selected = currentDestination == dest
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { currentDestination = dest },
                                    icon = {
                                        Icon(
                                            imageVector = dest.icon,
                                            contentDescription = dest.label
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = dest.label,
                                            color = if (selected) LingYuPrimaryCyan else LingYuTextMuted
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = LingYuPrimaryCyan,
                                        unselectedIconColor = LingYuTextMuted,
                                        indicatorColor = LingYuBackgroundDark
                                    )
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .background(LingYuBackgroundDark)
                    ) {
                        when (currentDestination) {
                            AppNavDestination.HOME -> HomeScreen(
                                agentRuntime = agentRuntime,
                                asrEngine = asrEngine,
                                privacyManager = privacyManager,
                                onNavigateToSettings = { currentDestination = AppNavDestination.SETTINGS }
                            )
                            AppNavDestination.TOOLS -> ToolsScreen(
                                toolRegistry = toolRegistry,
                                agentRuntime = agentRuntime
                            )
                            AppNavDestination.MEMORY -> MemoryScreen(
                                memoryEngine = memoryEngine,
                                scope = scope
                            )
                            AppNavDestination.AUTOMATION -> AutomationScreen(
                                automationEngine = automationEngine,
                                scope = scope
                            )
                            AppNavDestination.EVALUATION -> EvaluationScreen(
                                evaluationLab = evaluationLab
                            )
                            AppNavDestination.HISTORY -> HistoryScreen(
                                conversationDao = database.conversationDao(),
                                scope = scope
                            )
                            AppNavDestination.SETTINGS -> SettingsScreen(
                                privacyManager = privacyManager,
                                agentRuntime = agentRuntime
                            )
                        }
                    }
                }
            }
        }
    }
}
