package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.agent.AgentRuntime
import com.example.ai.CloudAIProvider
import com.example.ai.LocalAIProvider
import com.example.ai.MockAIProvider
import com.example.security.PrivacyManager
import com.example.ui.theme.LingYuBackgroundDark
import com.example.ui.theme.LingYuBorder
import com.example.ui.theme.LingYuCardDark
import com.example.ui.theme.LingYuPrimaryCyan
import com.example.ui.theme.LingYuSurfaceDark
import com.example.ui.theme.LingYuTextMuted
import com.example.ui.theme.LingYuTextWhite

@Composable
fun SettingsScreen(
    privacyManager: PrivacyManager,
    agentRuntime: AgentRuntime
) {
    val isPrivacyMode by privacyManager.isPrivacyMode.collectAsState()
    val isOfflineMode by privacyManager.isOfflineMode.collectAsState()

    var selectedProviderIndex by remember { mutableStateOf(0) } // 0: Mock, 1: Local, 2: Cloud
    var speechRate by remember { mutableFloatStateOf(1.0f) }
    var speechPitch by remember { mutableFloatStateOf(1.0f) }
    var apiKeyText by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LingYuBackgroundDark)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = "系统设置与隐私控制",
            style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Bold,
                color = LingYuTextWhite
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Privacy & Offline Section
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = LingYuCardDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, LingYuBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "隐私与脱机模式",
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = LingYuPrimaryCyan,
                        fontWeight = FontWeight.Bold
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("隐私模式 (强制端侧处理)", color = LingYuTextWhite, fontWeight = FontWeight.Medium)
                        Text("开启后语音与提示词均不离开设备", color = LingYuTextMuted, style = MaterialTheme.typography.bodySmall)
                    }

                    Switch(
                        checked = isPrivacyMode,
                        onCheckedChange = { privacyManager.setPrivacyMode(it) },
                        colors = SwitchDefaults.colors(checkedTrackColor = LingYuPrimaryCyan)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("离线离网模式", color = LingYuTextWhite, fontWeight = FontWeight.Medium)
                        Text("全本地离线工具与模拟语义解析", color = LingYuTextMuted, style = MaterialTheme.typography.bodySmall)
                    }

                    Switch(
                        checked = isOfflineMode,
                        onCheckedChange = { privacyManager.setOfflineMode(it) },
                        colors = SwitchDefaults.colors(checkedTrackColor = LingYuPrimaryCyan)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // AI Provider Section
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = LingYuCardDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, LingYuBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "AI 引擎选型",
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = LingYuPrimaryCyan,
                        fontWeight = FontWeight.Bold
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                val providers = listOf("本地规则 (Mock Provider - 纯离线无Key可完美运行)", "端侧 AI (Gemini Nano / AICore)", "云端 AI (Gemini 3.5 Flash REST API)")
                providers.forEachIndexed { index, name ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = selectedProviderIndex == index,
                            onClick = {
                                selectedProviderIndex = index
                                agentRuntime.activeAiProvider = when (index) {
                                    1 -> LocalAIProvider()
                                    2 -> CloudAIProvider()
                                    else -> MockAIProvider()
                                }
                            },
                            colors = RadioButtonDefaults.colors(selectedColor = LingYuPrimaryCyan)
                        )
                        Text(name, color = LingYuTextWhite, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // TTS Speech Rate
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = LingYuCardDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, LingYuBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "中文 TTS 语音合成调优",
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = LingYuPrimaryCyan,
                        fontWeight = FontWeight.Bold
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text("语速倍率: ${String.format("%.1f", speechRate)}x", color = LingYuTextWhite)
                Slider(
                    value = speechRate,
                    onValueChange = { speechRate = it },
                    valueRange = 0.5f..2.0f,
                    colors = SliderDefaults.colors(
                        thumbColor = LingYuPrimaryCyan,
                        activeTrackColor = LingYuPrimaryCyan,
                        inactiveTrackColor = LingYuSurfaceDark
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text("声调音高: ${String.format("%.1f", speechPitch)}x", color = LingYuTextWhite)
                Slider(
                    value = speechPitch,
                    onValueChange = { speechPitch = it },
                    valueRange = 0.5f..1.5f,
                    colors = SliderDefaults.colors(
                        thumbColor = LingYuPrimaryCyan,
                        activeTrackColor = LingYuPrimaryCyan,
                        inactiveTrackColor = LingYuSurfaceDark
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Key config notes
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = LingYuCardDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, LingYuBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "密钥管理安全配置",
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = LingYuPrimaryCyan,
                        fontWeight = FontWeight.Bold
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "默认无需配置任何商业 API Key 即可完整测试全部功能。如需在 AI Studio Secrets 中绑定云端 Gemini 密钥，请将 GEMINI_API_KEY 配置至 .env / Secrets 提词中。",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = LingYuTextMuted,
                        lineHeight = 18.sp
                    )
                )
            }
        }
    }
}
