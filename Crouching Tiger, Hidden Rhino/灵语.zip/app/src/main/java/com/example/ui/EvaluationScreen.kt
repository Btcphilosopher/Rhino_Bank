package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.evaluation.EvaluationLab
import com.example.evaluation.EvaluationResult
import com.example.ui.theme.LingYuBackgroundDark
import com.example.ui.theme.LingYuBorder
import com.example.ui.theme.LingYuCardDark
import com.example.ui.theme.LingYuPrimaryCyan
import com.example.ui.theme.LingYuSecondaryIndigo
import com.example.ui.theme.LingYuSurfaceDark
import com.example.ui.theme.LingYuTextMuted
import com.example.ui.theme.LingYuTextWhite

@Composable
fun EvaluationScreen(evaluationLab: EvaluationLab) {
    var evalResult by remember { mutableStateOf<EvaluationResult?>(null) }
    var isRunning by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LingYuBackgroundDark)
            .padding(16.dp)
    ) {
        Text(
            text = "评测实验室 (1,000条中文 Golden Dataset)",
            style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Bold,
                color = LingYuTextWhite
            )
        )
        Text(
            text = "包含天气、提醒、日历、通话、短信、地图、计算器、音乐、设备控制等全场景指令基准测试",
            style = MaterialTheme.typography.labelSmall.copy(color = LingYuTextMuted)
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                isRunning = true
                evalResult = evaluationLab.runEvaluation()
                isRunning = false
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = LingYuPrimaryCyan)
        ) {
            Text(
                text = if (isRunning) "基准测试运行中..." else "🚀 运行 Golden Dataset 自动化评测",
                color = Color.Black,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        evalResult?.let { result ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = LingYuCardDark),
                border = androidx.compose.foundation.BorderStroke(1.dp, LingYuPrimaryCyan)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "总体识别与动作准确率",
                                style = MaterialTheme.typography.labelSmall.copy(color = LingYuTextMuted)
                            )
                            Text(
                                text = "${result.accuracyPercentage}%",
                                style = MaterialTheme.typography.headlineLarge.copy(
                                    color = LingYuPrimaryCyan,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "平均全链路延迟",
                                style = MaterialTheme.typography.labelSmall.copy(color = LingYuTextMuted)
                            )
                            Text(
                                text = "${result.avgLatencyMs} ms",
                                style = MaterialTheme.typography.headlineMedium.copy(
                                    color = LingYuSecondaryIndigo,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "通过测试用例：${result.passedTests} / ${result.totalTests}",
                        style = MaterialTheme.typography.bodyMedium.copy(color = LingYuTextWhite)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    LinearProgressIndicator(
                        progress = { result.accuracyPercentage / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(CircleShape),
                        color = LingYuPrimaryCyan,
                        trackColor = LingYuSurfaceDark
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "分场景准确率明细：",
                style = MaterialTheme.typography.titleMedium.copy(
                    color = LingYuTextWhite,
                    fontWeight = FontWeight.Bold
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(result.categoryAccuracies.toList()) { (cat, acc) ->
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        color = LingYuSurfaceDark,
                        border = androidx.compose.foundation.BorderStroke(1.dp, LingYuBorder)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(cat, color = LingYuTextWhite)
                            Text("${acc.toInt()}%", color = LingYuPrimaryCyan, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        } ?: run {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .background(LingYuSurfaceDark, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "点击上方按钮开始评测 Golden Dataset",
                    color = LingYuTextMuted
                )
            }
        }
    }
}
