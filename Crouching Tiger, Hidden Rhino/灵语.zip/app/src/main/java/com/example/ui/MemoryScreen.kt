package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.database.MemoryEntity
import com.example.memory.MemoryEngine
import com.example.ui.theme.LingYuBackgroundDark
import com.example.ui.theme.LingYuBorder
import com.example.ui.theme.LingYuCardDark
import com.example.ui.theme.LingYuPrimaryCyan
import com.example.ui.theme.LingYuSurfaceDark
import com.example.ui.theme.LingYuTextMuted
import com.example.ui.theme.LingYuTextWhite
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Composable
fun MemoryScreen(
    memoryEngine: MemoryEngine,
    scope: CoroutineScope
) {
    val memories by memoryEngine.allMemories.collectAsState(initial = emptyList())
    var inputMemory by remember { mutableStateOf("") }

    // Prepopulate default memories if empty
    val displayMemories = if (memories.isEmpty()) {
        listOf(
            MemoryEntity(id = 1, type = "PREFERENCE", content = "偏好晨跑与咖啡，习惯早上8点阅读新闻", source = "系统习惯生成"),
            MemoryEntity(id = 2, type = "FACT", content = "常用地址：公司位于张江高科技园区，家位于静安区", source = "语音提取"),
            MemoryEntity(id = 3, type = "PREFERENCE", content = "音乐喜好：听轻音乐与古典爵士歌单", source = "对话历史"),
            MemoryEntity(id = 4, type = "HEALTH", content = "每日提醒：早上 08:00 服药，每周二四跑步", source = "日程分析")
        )
    } else memories

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LingYuBackgroundDark)
            .padding(16.dp)
    ) {
        Text(
            text = "个人知识库与记忆",
            style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Bold,
                color = LingYuTextWhite
            )
        )
        Text(
            text = "灵语记住的关于你的习惯、偏好与实时信息",
            style = MaterialTheme.typography.labelSmall.copy(color = LingYuTextMuted)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Add memory input
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = inputMemory,
                onValueChange = { inputMemory = it },
                placeholder = { Text("例如: 喜欢喝拿铁", color = LingYuTextMuted) },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = LingYuPrimaryCyan,
                    unfocusedBorderColor = LingYuBorder,
                    focusedTextColor = LingYuTextWhite,
                    unfocusedTextColor = LingYuTextWhite
                )
            )

            Spacer(modifier = Modifier.width(8.dp))

            Button(
                onClick = {
                    if (inputMemory.isNotBlank()) {
                        scope.launch(Dispatchers.IO) {
                            memoryEngine.remember("PREFERENCE", inputMemory)
                            inputMemory = ""
                        }
                    }
                },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = LingYuPrimaryCyan)
            ) {
                Icon(Icons.Default.Add, contentDescription = "添加", tint = androidx.compose.ui.graphics.Color.Black)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(displayMemories) { mem ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = LingYuCardDark),
                    border = androidx.compose.foundation.BorderStroke(1.dp, LingYuBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Surface(
                                color = LingYuSurfaceDark,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = mem.type,
                                    style = MaterialTheme.typography.labelSmall.copy(color = LingYuPrimaryCyan),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = mem.content,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = LingYuTextWhite,
                                    fontWeight = FontWeight.Medium
                                )
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "来源: ${mem.source}",
                                style = MaterialTheme.typography.labelSmall.copy(color = LingYuTextMuted)
                            )
                        }

                        IconButton(onClick = {
                            scope.launch(Dispatchers.IO) {
                                if (mem.id > 0) memoryEngine.deleteMemoryById(mem.id)
                            }
                        }) {
                            Icon(Icons.Default.Delete, contentDescription = "忘记/删除", tint = LingYuTextMuted)
                        }
                    }
                }
            }
        }
    }
}
