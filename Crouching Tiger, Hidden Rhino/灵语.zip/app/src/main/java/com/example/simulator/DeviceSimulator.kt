package com.example.simulator

enum class DeviceType {
    PHONE,
    EARBUDS,
    CAR,
    SMART_SPEAKER,
    WATCH
}

data class DeviceSession(
    val deviceType: DeviceType,
    val deviceName: String,
    val isAudioOutputConnected: Boolean = true,
    val isScreenAvailable: Boolean = true
)

class DeviceContextManager {
    private var activeDevice = DeviceSession(DeviceType.PHONE, "灵语手机端")

    fun switchDevice(type: DeviceType): DeviceSession {
        activeDevice = when (type) {
            DeviceType.PHONE -> DeviceSession(DeviceType.PHONE, "灵语旗舰手机")
            DeviceType.EARBUDS -> DeviceSession(DeviceType.EARBUDS, "灵语智能耳机", isScreenAvailable = false)
            DeviceType.CAR -> DeviceSession(DeviceType.CAR, "灵语车载系统")
            DeviceType.SMART_SPEAKER -> DeviceSession(DeviceType.SMART_SPEAKER, "灵语智能音箱")
            DeviceType.WATCH -> DeviceSession(DeviceType.WATCH, "灵语手表端")
        }
        return activeDevice
    }

    fun getActiveDevice(): DeviceSession = activeDevice
}
