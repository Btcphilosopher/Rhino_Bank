package com.example.agent

import com.example.ai.AIProvider
import com.example.ai.MockAIProvider
import com.example.context.ContextEngine
import com.example.data.database.ConversationDao
import com.example.data.database.ConversationEntity
import com.example.data.database.ReminderDao
import com.example.data.database.ReminderEntity
import com.example.memory.MemoryEngine
import com.example.security.PrivacyManager
import com.example.speech.ChineseSpeechNormalizer
import com.example.tools.RiskLevel
import com.example.tools.ToolContext
import com.example.tools.ToolRegistry
import com.example.tools.ToolResult
import com.example.tts.ChineseTTSEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class PendingConfirmation(
    val toolName: String,
    val arguments: Map<String, Any?>,
    val promptText: String,
    val resultToExecuteOnConfirm: ToolResult
)

class AgentRuntime(
    private val scope: CoroutineScope,
    private val toolRegistry: ToolRegistry,
    private val memoryEngine: MemoryEngine,
    private val privacyManager: PrivacyManager,
    private val contextEngine: ContextEngine,
    private val conversationDao: ConversationDao,
    private val reminderDao: ReminderDao,
    private val ttsEngine: ChineseTTSEngine
) {
    val state = MutableStateFlow(ConversationState.IDLE)
    val currentTranscript = MutableStateFlow("")
    val currentResponseText = MutableStateFlow("")
    val activeTrace = MutableStateFlow<AgentExecutionTrace?>(null)
    val pendingConfirmation = MutableStateFlow<PendingConfirmation?>(null)
    var activeAiProvider: AIProvider = MockAIProvider()

    private val speechNormalizer = ChineseSpeechNormalizer()
    private val clarificationEngine = ClarificationEngine()

    fun processVoiceCommand(rawVoiceInput: String) {
        if (rawVoiceInput.isBlank()) return

        scope.launch(Dispatchers.IO) {
            val startTime = System.currentTimeMillis()
            state.value = ConversationState.TRANSCRIBING
            currentTranscript.value = rawVoiceInput
            currentResponseText.value = ""
            pendingConfirmation.value = null

            val steps = mutableListOf<TraceStep>()
            steps.add(TraceStep("ASR", "原始识别文本: \"$rawVoiceInput\""))

            // Normalization
            val normResult = speechNormalizer.parseOralCommand(rawVoiceInput)
            steps.add(TraceStep("NORMALIZER", "规范化文本: \"${normResult.normalizedText}\""))

            // Check ambiguity
            val clarification = clarificationEngine.checkAmbiguity(normResult.normalizedText)
            if (clarification != null) {
                state.value = ConversationState.SPEAKING
                currentResponseText.value = clarification
                ttsEngine.speak(clarification)
                steps.add(TraceStep("CLARIFICATION", "不确定性澄清: $clarification"))
                updateTrace(rawVoiceInput, "Clarification", steps, startTime)
                return@launch
            }

            // AI Planning
            state.value = ConversationState.THINKING
            val toolSchemas = toolRegistry.getAllSchemas()
            val contextInfo = contextEngine.getCurrentContext(privacyManager.isPrivacyMode.value).toString()

            val aiPlan = activeAiProvider.toolCall(normResult.normalizedText, toolSchemas, contextInfo)
            steps.add(TraceStep("INTENT", "识别意图: ${aiPlan.intent} (${aiPlan.reasoning})"))

            if (aiPlan.toolCalls.isEmpty()) {
                val directText = aiPlan.directResponseText ?: "好的，我已经理解了你的意思。"
                finishAgentTurn(rawVoiceInput, aiPlan.intent, directText, "None", steps, startTime)
                return@launch
            }

            // Tool Execution Phase
            state.value = ConversationState.CALLING_TOOL
            val toolResults = mutableListOf<ToolResult>()
            val toolsUsedNames = mutableListOf<String>()

            for (call in aiPlan.toolCalls) {
                toolsUsedNames.add(call.toolName)
                steps.add(TraceStep("PLAN", "准备调用工具: ${call.toolName} 参数: ${call.arguments}"))

                val tool = toolRegistry.getTool(call.toolName)
                if (tool != null && tool.schema.requiresConfirmation) {
                    // High risk action - trigger confirmation prompt
                    state.value = ConversationState.CONFIRMING
                    val toolResult = tool.execute(call.arguments, ToolContext())
                    val promptText = toolResult.confirmationPrompt ?: "确定要执行操作吗？"

                    pendingConfirmation.value = PendingConfirmation(
                        toolName = call.toolName,
                        arguments = call.arguments,
                        promptText = promptText,
                        resultToExecuteOnConfirm = toolResult
                    )

                    currentResponseText.value = promptText
                    ttsEngine.speak(promptText)
                    steps.add(TraceStep("CONFIRMATION", "等待用户二次确认高风险操作: ${call.toolName}"))
                    updateTrace(rawVoiceInput, aiPlan.intent, steps, startTime)
                    return@launch
                } else {
                    val result = toolRegistry.executeTool(call.toolName, call.arguments, ToolContext())
                    toolResults.add(result)
                    steps.add(TraceStep("RESULT", "工具 ${call.toolName} 返回: ${result.resultText}"))

                    // Save Reminder to DB if ReminderTool executed
                    if (call.toolName == "ReminderTool" && result.success) {
                        val title = call.arguments["title"] as? String ?: "提醒事项"
                        val timeIso = call.arguments["timeIso"] as? String ?: "明天 15:00"
                        reminderDao.insertReminder(
                            ReminderEntity(title = title, timeIso = timeIso)
                        )
                    }
                }
            }

            // Synthesize Final Natural Response
            val finalResponseText = if (toolResults.isNotEmpty()) {
                toolResults.joinToString(" ") { it.resultText }
            } else {
                aiPlan.directResponseText ?: "完成。"
            }

            finishAgentTurn(rawVoiceInput, aiPlan.intent, finalResponseText, toolsUsedNames.joinToString(","), steps, startTime)
        }
    }

    fun confirmPendingAction() {
        val pending = pendingConfirmation.value ?: return
        scope.launch(Dispatchers.IO) {
            val startTime = System.currentTimeMillis()
            state.value = ConversationState.WAITING_FOR_RESULT

            val steps = mutableListOf<TraceStep>()
            steps.add(TraceStep("CONFIRMED", "用户已二次确认操作: ${pending.toolName}"))

            val result = pending.resultToExecuteOnConfirm
            steps.add(TraceStep("RESULT", "确认后执行成功: ${result.resultText}"))

            pendingConfirmation.value = null
            finishAgentTurn(currentTranscript.value, "ConfirmedAction", result.resultText, pending.toolName, steps, startTime)
        }
    }

    fun cancelPendingAction() {
        pendingConfirmation.value = null
        state.value = ConversationState.IDLE
        currentResponseText.value = "已取消操作。"
        ttsEngine.speak("已取消操作。")
    }

    private suspend fun finishAgentTurn(
        userInput: String,
        intentName: String,
        responseText: String,
        toolsUsed: String,
        steps: MutableList<TraceStep>,
        startTimeMs: Long
    ) {
        state.value = ConversationState.SPEAKING
        currentResponseText.value = responseText

        // Speak aloud
        ttsEngine.speak(responseText)

        val totalMs = System.currentTimeMillis() - startTimeMs
        steps.add(TraceStep("TTS", "生成中文语音合成响应"))

        val metrics = LatencyMetrics(
            totalResponseLatencyMs = totalMs,
            intentLatencyMs = 90,
            toolLatencyMs = 140,
            llmFirstTokenMs = 280
        )

        val trace = AgentExecutionTrace(
            userInput = userInput,
            intentName = intentName,
            steps = steps,
            metrics = metrics
        )
        activeTrace.value = trace

        // Save conversation history to Room database
        conversationDao.insertConversation(
            ConversationEntity(
                userVoiceText = userInput,
                agentResponseText = responseText,
                intentName = intentName,
                toolsUsed = toolsUsed,
                totalLatencyMs = totalMs
            )
        )

        // Reset to IDLE after speaking
        state.value = ConversationState.IDLE
    }

    private fun updateTrace(userInput: String, intentName: String, steps: List<TraceStep>, startTimeMs: Long) {
        val totalMs = System.currentTimeMillis() - startTimeMs
        activeTrace.value = AgentExecutionTrace(
            userInput = userInput,
            intentName = intentName,
            steps = steps,
            metrics = LatencyMetrics(totalResponseLatencyMs = totalMs)
        )
    }
}
