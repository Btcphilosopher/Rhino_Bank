package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.automation.AutomationEngine
import com.example.data.database.AutomationEntity
import com.example.ui.theme.LingYuBackgroundDark
import com.example.ui.theme.LingYuBorder
import com.example.ui.theme.LingYuCardDark
import com.example.ui.theme.LingYuPrimaryCyan
import com.example.ui.theme.LingYuSurfaceDark
import com.example.ui.theme.LingYuTextMuted
import com.example.ui.theme.LingYuTextWhite
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Composable
fun AutomationScreen(
    automationEngine: AutomationEngine,
    scope: CoroutineScope
) {
    val dbAutomations by automationEngine.automations.collectAsState(initial = emptyList())

    val automations = if (dbAutomations.isEmpty()) {
        listOf(
            AutomationEntity(id = 1, name = "晨间天气自动播报", trigger = "每天早上 07:00", action = "查询上海天气并播放", isEnabled = true),
            AutomationEntity(id = 2, name = "雨天带伞条件提醒", trigger = "明天预报有雨", condition = "降水概率>60%", action = "早上08:00提醒带伞", isEnabled = true),
            AutomationEntity(id = 3, name = "周末定时清理任务", trigger = "每周五 18:00", action = "汇总周报并整理完成事项", isEnabled = false)
        )
    } else dbAutomations

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LingYuBackgroundDark)
            .padding(16.dp)
    ) {
        Text(
            text = "语音自动化与条件流",
            style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Bold,
                color = LingYuTextWhite
            )
        )
        Text(
            text = "基于时间、天气、定位与复合条件的智能响应流程",
            style = MaterialTheme.typography.labelSmall.copy(color = LingYuTextMuted)
        )

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(automations) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = LingYuCardDark),
                    border = androidx.compose.foundation.BorderStroke(1.dp, LingYuBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.name,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    color = LingYuTextWhite,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "触发条件: ${item.trigger}",
                                style = MaterialTheme.typography.bodySmall.copy(color = LingYuPrimaryCyan)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "响应动作: ${item.action}",
                                style = MaterialTheme.typography.bodySmall.copy(color = LingYuTextMuted)
                            )
                        }

                        Switch(
                            checked = item.isEnabled,
                            onCheckedChange = { isChecked ->
                                scope.launch(Dispatchers.IO) {
                                    if (item.id > 0) {
                                        automationEngine.toggleAutomation(item.id, isChecked)
                                    }
                                }
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = LingYuBackgroundDark,
                                checkedTrackColor = LingYuPrimaryCyan,
                                uncheckedThumbColor = LingYuTextMuted,
                                uncheckedTrackColor = LingYuSurfaceDark
                            )
                        )
                    }
                }
            }
        }
    }
}
