package com.example.automation

import com.example.data.database.AutomationDao
import com.example.data.database.AutomationEntity
import kotlinx.coroutines.flow.Flow

class AutomationEngine(private val automationDao: AutomationDao) {

    val automations: Flow<List<AutomationEntity>> = automationDao.getAllAutomations()

    suspend fun addAutomation(name: String, trigger: String, condition: String?, action: String): Long {
        return automationDao.insertAutomation(
            AutomationEntity(
                name = name,
                trigger = trigger,
                condition = condition,
                action = action,
                isEnabled = true
            )
        )
    }

    suspend fun toggleAutomation(id: Long, isEnabled: Boolean) {
        automationDao.setAutomationEnabled(id, isEnabled)
    }

    suspend fun deleteAutomation(id: Long) {
        automationDao.deleteAutomation(id)
    }
}
