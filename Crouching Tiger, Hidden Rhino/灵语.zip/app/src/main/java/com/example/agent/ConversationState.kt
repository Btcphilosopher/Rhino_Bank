package com.example.agent

enum class ConversationState {
    IDLE,
    LISTENING,
    TRANSCRIBING,
    THINKING,
    CALLING_TOOL,
    WAITING_FOR_RESULT,
    SPEAKING,
    CONFIRMING,
    ERROR
}

data class LatencyMetrics(
    val asrFirstPartialMs: Long = 120,
    val asrFinalMs: Long = 280,
    val intentLatencyMs: Long = 90,
    val toolLatencyMs: Long = 140,
    val llmFirstTokenMs: Long = 320,
    val ttsFirstAudioMs: Long = 110,
    val totalResponseLatencyMs: Long = 1030
)

data class TraceStep(
    val stepName: String, // ASR, INTENT, PLAN, TOOL, RESULT, ANSWER, TTS
    val detail: String,
    val timestampMs: Long = System.currentTimeMillis()
)

data class AgentExecutionTrace(
    val conversationId: Long = System.currentTimeMillis(),
    val userInput: String = "",
    val intentName: String = "",
    val steps: List<TraceStep> = emptyList(),
    val metrics: LatencyMetrics = LatencyMetrics()
)
