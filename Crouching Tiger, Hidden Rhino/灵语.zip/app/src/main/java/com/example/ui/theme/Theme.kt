package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = LingYuPrimaryCyan,
    onPrimary = Color.Black,
    secondary = LingYuSecondaryIndigo,
    onSecondary = Color.White,
    tertiary = LingYuAccentGreen,
    background = LingYuBackgroundDark,
    onBackground = LingYuTextWhite,
    surface = LingYuSurfaceDark,
    onSurface = LingYuTextWhite,
    surfaceVariant = LingYuCardDark,
    onSurfaceVariant = LingYuTextMuted,
    outline = LingYuBorder,
    error = LingYuAlertRed
)

@Composable
fun LingYuTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    LingYuTheme(content = content)
}
