package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.agent.AgentRuntime
import com.example.tools.RiskLevel
import com.example.tools.ToolRegistry
import com.example.tools.ToolSchema
import com.example.ui.theme.LingYuAlertRed
import com.example.ui.theme.LingYuBackgroundDark
import com.example.ui.theme.LingYuBorder
import com.example.ui.theme.LingYuCardDark
import com.example.ui.theme.LingYuPrimaryCyan
import com.example.ui.theme.LingYuSurfaceDark
import com.example.ui.theme.LingYuTextMuted
import com.example.ui.theme.LingYuTextWhite

@Composable
fun ToolsScreen(
    toolRegistry: ToolRegistry,
    agentRuntime: AgentRuntime
) {
    val tools = toolRegistry.getAllSchemas()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LingYuBackgroundDark)
            .padding(16.dp)
    ) {
        Text(
            text = "系统工具注册表 (18项)",
            style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Bold,
                color = LingYuTextWhite
            )
        )
        Text(
            text = "天气/时钟/计算器/定时器/提醒/日历/通讯录/电话/短信/地图/导航/搜索/翻译/笔记/文件/音乐/音量/设置",
            style = MaterialTheme.typography.labelSmall.copy(color = LingYuTextMuted)
        )

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(tools) { schema ->
                ToolSchemaCard(schema, agentRuntime)
            }
        }
    }
}

@Composable
fun ToolSchemaCard(schema: ToolSchema, agentRuntime: AgentRuntime) {
    var lastOutput by remember { mutableStateOf("") }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = LingYuCardDark),
        border = androidx.compose.foundation.BorderStroke(1.dp, LingYuBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = schema.name,
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = LingYuPrimaryCyan,
                        fontWeight = FontWeight.Bold
                    )
                )

                Surface(
                    color = if (schema.riskLevel == RiskLevel.HIGH) LingYuAlertRed.copy(alpha = 0.2f) else LingYuSurfaceDark,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = if (schema.riskLevel == RiskLevel.HIGH) "高风险 (需二次确认)" else "低风险",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (schema.riskLevel == RiskLevel.HIGH) LingYuAlertRed else LingYuTextMuted
                        ),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = schema.description,
                style = MaterialTheme.typography.bodyMedium.copy(color = LingYuTextWhite)
            )

            Spacer(modifier = Modifier.height(6.dp))

            val paramsStr = schema.parameters.joinToString(", ") { "${it.name}:${it.type}" }
            Text(
                text = "参数: [$paramsStr]",
                style = MaterialTheme.typography.labelSmall.copy(color = LingYuTextMuted)
            )

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = {
                    val prompt = when (schema.name) {
                        "WeatherTool" -> "明天天气怎么样？"
                        "CalculatorTool" -> "帮我算一下386*24"
                        "ClockTool" -> "现在几点"
                        "MessageTool" -> "给妈妈发消息说我晚上七点回家"
                        "PhoneTool" -> "给妈妈打电话"
                        "NavigationTool" -> "导航去上海虹桥站"
                        "ReminderTool" -> "提醒我下午三点给王伟打电话"
                        else -> "测试 ${schema.name}"
                    }
                    agentRuntime.processVoiceCommand(prompt)
                },
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = LingYuSurfaceDark)
            ) {
                Text("直接测试执行", color = LingYuPrimaryCyan)
            }
        }
    }
}
