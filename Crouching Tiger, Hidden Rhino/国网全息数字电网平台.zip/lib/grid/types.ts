// STATE GRID DIGITAL GRID OS - Core Types & Object Models
// 国网全息数字电网平台 - 核心数据结构与数字孪生模型

export type VoltageLevel = '1000kV' | '±1100kV' | '±800kV' | '500kV' | '220kV' | '110kV' | '35kV' | '10kV';

export type AssetType =
  | 'Substation'
  | 'ConverterStation'
  | 'Transformer'
  | 'CircuitBreaker'
  | 'Disconnector'
  | 'Busbar'
  | 'TransmissionLine'
  | 'Tower'
  | 'Cable'
  | 'HVDCLink'
  | 'HVACLine'
  | 'PowerPlant'
  | 'WindFarm'
  | 'SolarFarm'
  | 'HydroPlant'
  | 'NuclearPlant'
  | 'BatteryEnergyStorage'
  | 'DataCenter'
  | 'IndustrialLoad'
  | 'EVChargingStation'
  | 'Microgrid'
  | 'VirtualPowerPlant';

export type GridRegion = '华北' | '华东' | '华中' | '西北' | '西南' | '东北';

export type OperationalStatus = 'normal' | 'warning' | 'critical' | 'maintenance' | 'outage';

export interface LatLngAlt {
  lat: number;
  lng: number;
  alt?: number;
}

export interface TelemetryData {
  timestamp: string;
  voltagekV: number;
  voltageAngleDeg?: number;
  currentA: number;
  activePowerMW: number;
  reactivePowerMvar: number;
  powerFactor: number;
  frequencyHz: number;
  temperatureC: number;
  oilTemperatureC?: number;
  tapPosition?: number;
  breakerState?: 'closed' | 'open' | 'tripped';
  batterySOCPercent?: number;
  windSpeedMs?: number;
  solarIrradianceWm2?: number;
  waterLevelM?: number;
  loadingPercent: number;
}

export interface DefectItem {
  id: string;
  category: 'insulator_damage' | 'corrosion' | 'missing_pin' | 'vegetation_encroachment' | 'tower_anomaly' | 'conductor_damage';
  severity: 'low' | 'medium' | 'high' | 'critical';
  confidence: number;
  description: string;
  detectedAt: string;
  imageUrl?: string;
}

export interface TowerObject {
  id: string;
  lineId: string;
  towerNumber: string;
  location: LatLngAlt;
  heightMeters: number;
  type: 'suspension' | 'tension' | 'uhv_gantry';
  icingRisk: 'low' | 'medium' | 'high' | 'severe';
  vegetationClearanceMeters: number;
  defects: DefectItem[];
}

export interface DigitalGridObject {
  id: string;
  name: string;
  nameEn: string;
  type: AssetType;
  region: GridRegion;
  province: string;
  city: string;
  voltageLevel: VoltageLevel;
  owner: string;
  status: OperationalStatus;
  location: LatLngAlt;
  connectedNodes: string[]; // Bus or node IDs connected
  capacityMW?: number;
  maxVoltagekV?: number;

  // BIM & GIS
  bimModelUrl?: string;
  gisCoordinates?: [number, number];

  // Live Telemetry
  telemetry: TelemetryData;

  // Health & Diagnostics
  healthIndex: number; // 0-100
  thermalStressScore: number;
  vibrationLevelG?: number;
  partialDischargepC?: number;
  oilLevelPercent?: number;

  // Maintenance History
  lastMaintenanceDate: string;
  nextScheduledMaintenance: string;
  failureRatePerYear: number;
  workOrderCount: number;
}

export interface TransmissionLineObject extends DigitalGridObject {
  fromSubstationId: string;
  toSubstationId: string;
  lengthKm: number;
  conductorType: string;
  resistancePU: number;
  reactancePU: number;
  susceptancePU: number;
  thermalRatingMW: number;
  towers: TowerObject[];
  wildfireRisk: 'low' | 'medium' | 'high' | 'critical';
  isUHV: boolean;
  isDC: boolean;
}

export interface SubstationObject extends DigitalGridObject {
  transformers: string[]; // Transformer IDs
  circuitBreakers: string[];
  buses: string[];
  substationType: '1000kV UHV' | '±800kV Converter' | '500kV Hub' | '220kV Distribution';
  gisEquipmentCount: number;
}

export interface PowerFlowResult {
  timestamp: string;
  converged: boolean;
  iterations: number;
  totalGenerationMW: number;
  totalLoadMW: number;
  totalLossesMW: number;
  systemFrequencyHz: number;
  busResults: {
    busId: string;
    busName: string;
    voltagekV: number;
    voltagePU: number;
    angleDeg: number;
    activePowerMW: number;
    reactivePowerMvar: number;
    status: OperationalStatus;
  }[];
  lineResults: {
    lineId: string;
    lineName: string;
    fromBusId: string;
    toBusId: string;
    pFlowMW: number;
    qFlowMvar: number;
    loadingPercent: number;
    lossMW: number;
    status: OperationalStatus;
  }[];
  overloadedLines: string[];
  voltageViolations: string[];
}

export interface AlarmItem {
  id: string;
  assetId: string;
  assetName: string;
  timestamp: string;
  severity: 'informational' | 'warning' | 'major' | 'critical';
  title: string;
  description: string;
  acknowledged: boolean;
  acknowledgedBy?: string;
  cause: string;
  recommendedAction: string;
}

export interface WeatherScenario {
  id: string;
  name: string;
  type: 'typhoon' | 'blizzard' | 'wildfire' | 'heatwave' | 'thunderstorm';
  centerLat: number;
  centerLng: number;
  radiusKm: number;
  windSpeedKmH: number;
  precipitationMmH: number;
  temperatureC: number;
  movingVector: { dLat: number; dLng: number };
  affectedAssetIds: string[];
}

export interface ContingencyAnalysisResult {
  outageAssetId: string;
  outageAssetName: string;
  islandsCount: number;
  overloadedLineIds: string[];
  maxOverloadPercent: number;
  unservedLoadMW: number;
  systemFrequencyImpactHz: number;
  mitigationActions: string[];
}

export interface ScenarioDefinition {
  id: string;
  name: string;
  description: string;
  loadDeltaPercent: number; // e.g. +10%
  renewableWindDeltaGW: number; // e.g. +10GW
  renewableSolarDeltaGW: number;
  dataCenterLoadAddMW: number; // e.g. 2000MW
  outageLineIds: string[];
  weatherEventId?: string;
}
