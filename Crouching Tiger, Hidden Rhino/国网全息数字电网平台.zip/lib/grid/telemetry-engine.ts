// STATE GRID DIGITAL GRID OS - SCADA Real-Time Telemetry Simulation Engine
// SCADA 实时遥测数据引擎 (Telemetry Publisher & Signal Generator)

import { DigitalGridObject, SubstationObject, TransmissionLineObject, TelemetryData } from './types';

type TelemetryCallback = (updatedAssets: Map<string, TelemetryData>) => void;

export class TelemetryEngine {
  private listeners: Set<TelemetryCallback> = new Set();
  private intervalId: NodeJS.Timeout | null = null;
  private timeOffsetMinutes = 0; // Simulated time offset from 08:00

  constructor() {
    // Engine ready
  }

  public subscribe(callback: TelemetryCallback): () => void {
    this.listeners.add(callback);
    return () => this.listeners.delete(callback);
  }

  public start(intervalMs: number = 2000) {
    if (this.intervalId) return;
    this.intervalId = setInterval(() => {
      this.tick();
    }, intervalMs);
  }

  public stop() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
  }

  public setTimeOffset(minutes: number) {
    this.timeOffsetMinutes = minutes;
  }

  private tick() {
    this.timeOffsetMinutes += 1;
    // Calculate diurnal factor (simulating 24h diurnal load curve)
    // 08:00 is minute 0, peak at 12:00 (min 240) and 20:00 (min 720)
    const hour = (8 + Math.floor(this.timeOffsetMinutes / 60)) % 24;
    const minute = this.timeOffsetMinutes % 60;

    const updatedMap = new Map<string, TelemetryData>();

    // Standard load shape
    const diurnalLoadFactor = 0.75 + 0.25 * Math.sin(((hour + minute / 60) - 6) * (Math.PI / 12));
    const solarFactor = Math.max(0, Math.sin(((hour + minute / 60) - 6) * (Math.PI / 12)));
    const windNoise = 1.0 + (Math.sin(this.timeOffsetMinutes / 15) * 0.12);

    // Random micro jitter
    const jitter = () => (Math.random() - 0.5) * 0.004;

    const timestamp = new Date().toISOString();

    // Broadcast updated telemetry payload
    const mockUpdates: Record<string, Partial<TelemetryData>> = {
      sub_changji: {
        activePowerMW: parseFloat((6000 * diurnalLoadFactor).toFixed(1)),
        voltagekV: parseFloat((1100 * (1 + jitter())).toFixed(1)),
        temperatureC: parseFloat((35 + solarFactor * 8).toFixed(1)),
        loadingPercent: parseFloat((50 * diurnalLoadFactor).toFixed(1)),
      },
      sub_shanghai: {
        activePowerMW: parseFloat((4100 * (0.8 + 0.3 * diurnalLoadFactor)).toFixed(1)),
        voltagekV: parseFloat((498.6 * (1 + jitter())).toFixed(1)),
        loadingPercent: parseFloat((75 * (0.8 + 0.35 * diurnalLoadFactor)).toFixed(1)),
        oilTemperatureC: parseFloat((55 + diurnalLoadFactor * 9).toFixed(1)),
      },
      gen_ningxia_solar: {
        activePowerMW: parseFloat((5200 * solarFactor).toFixed(1)),
        solarIrradianceWm2: Math.round(1000 * solarFactor),
        loadingPercent: parseFloat((65 * solarFactor).toFixed(1)),
      },
      gen_zhangjiakou_wind: {
        activePowerMW: parseFloat((3200 * windNoise).toFixed(1)),
        windSpeedMs: parseFloat((12.4 * windNoise).toFixed(1)),
        loadingPercent: parseFloat((64 * windNoise).toFixed(1)),
      },
    };

    Object.entries(mockUpdates).forEach(([id, data]) => {
      updatedMap.set(id, {
        timestamp,
        voltagekV: data.voltagekV ?? 500,
        currentA: data.currentA ?? 3000,
        activePowerMW: data.activePowerMW ?? 2000,
        reactivePowerMvar: data.reactivePowerMvar ?? 200,
        powerFactor: 0.99,
        frequencyHz: parseFloat((50.00 + jitter()).toFixed(3)),
        temperatureC: data.temperatureC ?? 28,
        loadingPercent: data.loadingPercent ?? 60,
        ...data,
      });
    });

    this.listeners.forEach((cb) => cb(updatedMap));
  }
}

export const globalTelemetryEngine = new TelemetryEngine();
