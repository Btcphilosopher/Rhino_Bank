'use client';

import React from 'react';
import { WeatherScenario, TransmissionLineObject } from '@/lib/grid/types';
import { CloudLightning, Flame, Wind, Thermometer, AlertTriangle, ShieldAlert, CheckCircle2 } from 'lucide-react';

interface WeatherRiskViewProps {
  weather: WeatherScenario | null;
  lines: TransmissionLineObject[];
}

export const WeatherRiskView: React.FC<WeatherRiskViewProps> = ({ weather, lines }) => {
  return (
    <div className="w-full h-full bg-slate-950 p-6 flex flex-col font-mono text-slate-200 overflow-y-auto">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-6">
        <div>
          <h2 className="text-lg font-bold text-amber-400 tracking-wide flex items-center space-x-2">
            <CloudLightning className="w-5 h-5" />
            <span>EXTREME WEATHER & WILDFIRE HAZARD ENGINE | 极端天气、覆冰与山火预警平台</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Real-time Typhoon Path Projection, Wildfire Infrared Monitoring & Line Thermal Capacity Derating Solver
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <span className="px-2.5 py-1 rounded bg-amber-950 text-amber-300 border border-amber-800 text-xs font-bold">
            HAZARD RISK LEVEL: ELEVATED (二级预警)
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1">
        {/* Active Weather System Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between text-xs border-b border-slate-800 pb-2">
            <span className="font-bold text-amber-400 flex items-center space-x-1.5">
              <Flame className="w-4 h-4 text-rose-500" />
              <span>当前气象灾害系统 (Active Disaster)</span>
            </span>
            <span className="text-rose-400 font-bold">STATUS: MONITORED</span>
          </div>

          <div className="space-y-3">
            <div className="text-sm font-bold text-slate-100">{weather?.name || '超强台风“海燕” (Typhoon Haiyan)'}</div>
            <div className="text-xs text-slate-400">
              Disaster Type: <span className="text-amber-300 font-bold">{weather?.type || 'Typhoon'}</span>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2">
              <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                <div className="text-slate-400 text-[10px]">Max Wind Speed</div>
                <div className="text-base font-bold text-emerald-400 mt-1">{weather?.windSpeedKmH || 150} km/h</div>
                <div className="text-[9px] text-slate-500">Category 14 Strong Typhoon</div>
              </div>

              <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                <div className="text-slate-400 text-[10px]">Impact Radius</div>
                <div className="text-base font-bold text-cyan-400 mt-1">{weather?.radiusKm || 280} km</div>
                <div className="text-[9px] text-slate-500">Affecting East China Corridor</div>
              </div>
            </div>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800 text-[11px] text-slate-300 space-y-1">
            <div className="font-bold text-amber-400">气象推演建议 (Meteorological Action):</div>
            <p className="text-slate-400 leading-relaxed">
              受高温强风影响，沿途输电线路载流容量下调 (Derating) 15%。建议启动抽水蓄能并调增华中跨区受电。
            </p>
          </div>
        </div>

        {/* Transmission Corridor Risk Matrix */}
        <div className="col-span-1 lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="text-xs font-bold text-slate-300 uppercase border-b border-slate-800 pb-2">
            受影响通道动态容量下调与杆塔机械应力评估 (Line Capacity Derating & Mechanical Stress)
          </div>

          <div className="space-y-3">
            {lines.map((line) => {
              const riskScore = line.isUHV ? 25 : 68;
              const cap = line.capacityMW || 6000;
              const deratedCapacityMW = Math.round(cap * 0.85);

              return (
                <div key={line.id} className="bg-slate-950 p-3.5 rounded border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-200">{line.name}</span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        riskScore > 50
                          ? 'bg-amber-950 text-amber-400 border border-amber-800'
                          : 'bg-emerald-950 text-emerald-400'
                      }`}
                    >
                      RISK SCORE: {riskScore}/100
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-[11px] pt-1">
                    <div>
                      <span className="text-slate-500">额定容量 (Rated):</span>{' '}
                      <span className="text-slate-300">{cap} MW</span>
                    </div>
                    <div>
                      <span className="text-slate-500">高温/强风下调容量:</span>{' '}
                      <span className="text-amber-300 font-bold">{deratedCapacityMW} MW</span>
                    </div>
                    <div>
                      <span className="text-slate-500">杆塔分布 count:</span>{' '}
                      <span className="text-cyan-400">{line.towers.length} Towers</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
