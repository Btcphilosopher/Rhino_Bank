'use client';

import React, { useState } from 'react';
import { SubstationObject, TransmissionLineObject, DigitalGridObject, PowerFlowResult } from '@/lib/grid/types';
import { runNewtonRaphsonPowerFlow } from '@/lib/grid/power-flow-solver';
import { FlaskConical, X, Play, RefreshCw, Zap, TrendingUp, AlertTriangle, CheckCircle2 } from 'lucide-react';

interface ScenarioLabModalProps {
  isOpen: boolean;
  onClose: () => void;
  substations: SubstationObject[];
  lines: TransmissionLineObject[];
  generators: DigitalGridObject[];
  basePowerFlow: PowerFlowResult;
}

export const ScenarioLabModal: React.FC<ScenarioLabModalProps> = ({
  isOpen,
  onClose,
  substations,
  lines,
  generators,
  basePowerFlow,
}) => {
  const [loadDelta, setLoadDelta] = useState<number>(10); // +10%
  const [solarDelta, setSolarDelta] = useState<number>(20); // +20GW
  const [windDelta, setWindDelta] = useState<number>(-5); // -5GW
  const [dataCenterMW, setDataCenterMW] = useState<number>(2000); // +2000MW
  const [tripUHV, setTripUHV] = useState<boolean>(false);

  const [simResult, setSimResult] = useState<PowerFlowResult | null>(null);

  if (!isOpen) return null;

  const handleRunSimulation = () => {
    const res = runNewtonRaphsonPowerFlow(substations, lines, generators, {
      loadMultiplier: 1 + loadDelta / 100,
      solarDeltaGW: solarDelta,
      windDeltaGW: windDelta,
      dataCenterLoadAddMW: dataCenterMW,
      outageLineIds: tripUHV ? ['line_changji_guzhou'] : [],
    });
    setSimResult(res);
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 font-mono text-xs text-slate-200">
      <div className="bg-slate-900 border border-slate-700 rounded-lg max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <FlaskConical className="w-5 h-5 text-emerald-400" />
            <div>
              <h2 className="text-sm font-bold text-slate-100">POWER SYSTEM SCENARIO LAB | 新型电力系统推演实验室</h2>
              <p className="text-[11px] text-slate-400">
                Sandbox Grid Matrix Experimentation (+10% Load, +20GW Solar, UHV Outage, Data-Center Surge)
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-200">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 flex-1 overflow-y-auto space-y-6">
          {/* Controls Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-slate-950 p-4 rounded border border-slate-800">
            <div>
              <label className="text-slate-400 text-[11px] font-semibold">全网负荷增幅 (Load Delta): +{loadDelta}%</label>
              <input
                type="range"
                min={-20}
                max={40}
                value={loadDelta}
                onChange={(e) => setLoadDelta(parseInt(e.target.value))}
                className="w-full mt-2 accent-cyan-400 cursor-pointer h-1.5 bg-slate-800 rounded"
              />
            </div>

            <div>
              <label className="text-slate-400 text-[11px] font-semibold">光伏装机增量 (Solar Expansion): +{solarDelta} GW</label>
              <input
                type="range"
                min={0}
                max={50}
                value={solarDelta}
                onChange={(e) => setSolarDelta(parseInt(e.target.value))}
                className="w-full mt-2 accent-amber-400 cursor-pointer h-1.5 bg-slate-800 rounded"
              />
            </div>

            <div>
              <label className="text-slate-400 text-[11px] font-semibold">风电出力波动 (Wind Fluctuations): {windDelta} GW</label>
              <input
                type="range"
                min={-20}
                max={20}
                value={windDelta}
                onChange={(e) => setWindDelta(parseInt(e.target.value))}
                className="w-full mt-2 accent-emerald-400 cursor-pointer h-1.5 bg-slate-800 rounded"
              />
            </div>

            <div>
              <label className="text-slate-400 text-[11px] font-semibold">新增数据中心负载 (Data-Center Surge): +{dataCenterMW} MW</label>
              <input
                type="range"
                min={0}
                max={5000}
                step={500}
                value={dataCenterMW}
                onChange={(e) => setDataCenterMW(parseInt(e.target.value))}
                className="w-full mt-2 accent-indigo-400 cursor-pointer h-1.5 bg-slate-800 rounded"
              />
            </div>

            <div className="col-span-1 md:col-span-2 flex items-center space-x-3 pt-2">
              <input
                type="checkbox"
                id="uhv_trip"
                checked={tripUHV}
                onChange={(e) => setTripUHV(e.target.checked)}
                className="w-4 h-4 accent-rose-500 rounded cursor-pointer"
              />
              <label htmlFor="uhv_trip" className="text-rose-300 font-bold cursor-pointer">
                模拟昌吉-古泉 ±1100kV 特高压直流通道 N-1 突发跳闸 Outage
              </label>
            </div>
          </div>

          <button
            onClick={handleRunSimulation}
            className="w-full py-3 bg-emerald-950 hover:bg-emerald-900 border border-emerald-700 rounded text-emerald-300 font-bold text-sm transition-all flex items-center justify-center space-x-2"
          >
            <Play className="w-4 h-4 text-emerald-400" />
            <span>执行 Newton-Raphson 潮流矩阵推演计算</span>
          </button>

          {/* Simulation Comparison Results */}
          {simResult && (
            <div className="space-y-4 pt-2 border-t border-slate-800">
              <h3 className="font-bold text-slate-200 text-sm flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>推演计算结果对比 (BEFORE vs SCENARIO AFTER)</span>
              </h3>

              <div className="grid grid-cols-3 gap-3">
                <div className="bg-slate-950 p-3 rounded border border-slate-800">
                  <div className="text-slate-400 text-[10px]">全网总负荷 Total Load</div>
                  <div className="text-base font-bold text-emerald-400 mt-1">
                    {simResult.totalLoadMW.toLocaleString()} MW
                  </div>
                  <div className="text-[10px] text-slate-500 mt-1">
                    Baseline: {basePowerFlow.totalLoadMW.toLocaleString()} MW (
                    <span className="text-emerald-400">
                      +{(simResult.totalLoadMW - basePowerFlow.totalLoadMW).toFixed(0)} MW
                    </span>
                    )
                  </div>
                </div>

                <div className="bg-slate-950 p-3 rounded border border-slate-800">
                  <div className="text-slate-400 text-[10px]">网损 (Losses)</div>
                  <div className="text-base font-bold text-amber-400 mt-1">
                    {simResult.totalLossesMW.toLocaleString()} MW
                  </div>
                  <div className="text-[10px] text-slate-500 mt-1">
                    Baseline: {basePowerFlow.totalLossesMW.toLocaleString()} MW
                  </div>
                </div>

                <div className="bg-slate-950 p-3 rounded border border-slate-800">
                  <div className="text-slate-400 text-[10px]">系统频率 Frequency</div>
                  <div className="text-base font-bold text-cyan-400 mt-1">
                    {simResult.systemFrequencyHz} Hz
                  </div>
                  <div className="text-[10px] text-slate-500 mt-1">Swing Equation Stability</div>
                </div>
              </div>

              {simResult.overloadedLines.length > 0 && (
                <div className="p-3 bg-rose-950/40 border border-rose-800 rounded space-y-1">
                  <div className="text-rose-400 font-bold flex items-center space-x-1.5">
                    <AlertTriangle className="w-4 h-4" />
                    <span>检测到过载线路 (Overloaded Corridors Detected):</span>
                  </div>
                  <div className="text-slate-300 text-[11px]">
                    {simResult.overloadedLines.join(', ')} (Overload &gt; 98%)
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
