'use client';

import React from 'react';
import {
  Zap,
  Activity,
  Layers,
  Cpu,
  CloudLightning,
  Eye,
  Bot,
  FlaskConical,
  ShieldAlert,
  Flame,
  Radio,
} from 'lucide-react';
import { PowerFlowResult } from '@/lib/grid/types';

export type ViewMode =
  | '3d_map'
  | 'substation_bim'
  | 'sld_diagram'
  | 'telemetry_powerflow'
  | 'weather_risk'
  | 'ai_inspection'
  | 'scenario_lab';

interface HeaderNavProps {
  currentView: ViewMode;
  onViewChange: (view: ViewMode) => void;
  powerFlow: PowerFlowResult;
  onOpenAIAssistant: () => void;
  onOpenScenarioLab: () => void;
  onOpenCascadingLab: () => void;
  alarmCount: number;
}

export const HeaderNav: React.FC<HeaderNavProps> = ({
  currentView,
  onViewChange,
  powerFlow,
  onOpenAIAssistant,
  onOpenScenarioLab,
  onOpenCascadingLab,
  alarmCount,
}) => {
  const renewableMW = 8400; // Solar + Wind + Hydro sample
  const renewablePercent = ((renewableMW / powerFlow.totalGenerationMW) * 100).toFixed(1);

  return (
    <header className="w-full bg-slate-950 border-b border-slate-800 flex flex-col font-mono text-slate-200 select-none z-30">
      {/* Top Banner - National Grid Operating Overview & Status Bar */}
      <div className="px-4 py-2 bg-slate-900/90 flex items-center justify-between border-b border-slate-800/80">
        {/* Branding & Logo */}
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded bg-gradient-to-br from-cyan-500 to-emerald-600 flex items-center justify-center shadow-[0_0_12px_rgba(6,182,212,0.5)]">
            <Zap className="w-5 h-5 text-slate-950 stroke-[2.5]" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-bold text-sm tracking-wider text-slate-100">
                国家电网新型电力系统全息数字电网
              </span>
              <span className="px-2 py-0.5 rounded text-[10px] bg-cyan-950 text-cyan-400 border border-cyan-800 font-semibold">
                STATE GRID DIGITAL GRID OS v4.2
              </span>
            </div>
            <div className="text-[10px] text-slate-400">
              国家级电力调度中心 | National Power Grid Operating & Digital Twin OS
            </div>
          </div>
        </div>

        {/* Real-time Telemetry Metrics Bar */}
        <div className="hidden lg:flex items-center space-x-6 text-xs">
          <div className="flex flex-col">
            <span className="text-[10px] text-slate-400">总负荷 (Total Load)</span>
            <span className="font-bold text-emerald-400 font-mono text-sm">{powerFlow.totalLoadMW.toLocaleString()} MW</span>
          </div>

          <div className="flex flex-col">
            <span className="text-[10px] text-slate-400">总发电 (Total Gen)</span>
            <span className="font-bold text-cyan-400 font-mono text-sm">{powerFlow.totalGenerationMW.toLocaleString()} MW</span>
          </div>

          <div className="flex flex-col">
            <span className="text-[10px] text-slate-400">新能源占比 (Renewable)</span>
            <span className="font-bold text-amber-400 font-mono text-sm">{renewablePercent}%</span>
          </div>

          <div className="flex flex-col">
            <span className="text-[10px] text-slate-400">特高压跨区 (UHV Flow)</span>
            <span className="font-bold text-indigo-400 font-mono text-sm">18,500 MW</span>
          </div>

          <div className="flex flex-col">
            <span className="text-[10px] text-slate-400">系统频率 (Frequency)</span>
            <div className="flex items-center space-x-1">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="font-bold text-slate-100 font-mono text-sm">{powerFlow.systemFrequencyHz} Hz</span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center space-x-2">
          <button
            onClick={onOpenAIAssistant}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded bg-cyan-950 hover:bg-cyan-900 border border-cyan-700 text-cyan-300 text-xs font-semibold transition-all shadow-sm"
          >
            <Bot className="w-4 h-4 text-cyan-400" />
            <span>AI 调度助手</span>
          </button>

          <button
            onClick={onOpenScenarioLab}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 border border-slate-600 text-slate-200 text-xs font-semibold transition-all"
          >
            <FlaskConical className="w-4 h-4 text-emerald-400" />
            <span>推演实验室</span>
          </button>

          <button
            onClick={onOpenCascadingLab}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded bg-rose-950 hover:bg-rose-900 border border-rose-800 text-rose-300 text-xs font-semibold transition-all"
          >
            <ShieldAlert className="w-4 h-4 text-rose-400" />
            <span>N-1 连锁故障</span>
          </button>
        </div>
      </div>

      {/* Navigation View Switcher Tabs */}
      <div className="px-4 py-1.5 bg-slate-950 flex items-center space-x-1 overflow-x-auto text-xs">
        <button
          onClick={() => onViewChange('3d_map')}
          className={`flex items-center space-x-1.5 px-3 py-1.5 rounded transition-all ${
            currentView === '3d_map'
              ? 'bg-cyan-950 text-cyan-300 border border-cyan-700 font-bold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>3D GIS 全景数字电网</span>
        </button>

        <button
          onClick={() => onViewChange('substation_bim')}
          className={`flex items-center space-x-1.5 px-3 py-1.5 rounded transition-all ${
            currentView === 'substation_bim'
              ? 'bg-cyan-950 text-cyan-300 border border-cyan-700 font-bold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Cpu className="w-3.5 h-3.5" />
          <span>变电站 3D BIM 数字孪生</span>
        </button>

        <button
          onClick={() => onViewChange('sld_diagram')}
          className={`flex items-center space-x-1.5 px-3 py-1.5 rounded transition-all ${
            currentView === 'sld_diagram'
              ? 'bg-cyan-950 text-cyan-300 border border-cyan-700 font-bold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Zap className="w-3.5 h-3.5" />
          <span>电气拓扑 & 单线图 (SLD)</span>
        </button>

        <button
          onClick={() => onViewChange('telemetry_powerflow')}
          className={`flex items-center space-x-1.5 px-3 py-1.5 rounded transition-all ${
            currentView === 'telemetry_powerflow'
              ? 'bg-cyan-950 text-cyan-300 border border-cyan-700 font-bold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Activity className="w-3.5 h-3.5" />
          <span>SCADA 遥测与潮流计算</span>
        </button>

        <button
          onClick={() => onViewChange('weather_risk')}
          className={`flex items-center space-x-1.5 px-3 py-1.5 rounded transition-all ${
            currentView === 'weather_risk'
              ? 'bg-cyan-950 text-cyan-300 border border-cyan-700 font-bold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <CloudLightning className="w-3.5 h-3.5 text-amber-400" />
          <span>极端天气与山火预警</span>
        </button>

        <button
          onClick={() => onViewChange('ai_inspection')}
          className={`flex items-center space-x-1.5 px-3 py-1.5 rounded transition-all ${
            currentView === 'ai_inspection'
              ? 'bg-cyan-950 text-cyan-300 border border-cyan-700 font-bold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Eye className="w-3.5 h-3.5 text-emerald-400" />
          <span>AI 无人机视觉巡检</span>
        </button>
      </div>
    </header>
  );
};
