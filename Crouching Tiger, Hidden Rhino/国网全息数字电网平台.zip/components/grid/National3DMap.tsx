'use client';

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { DigitalGridObject, SubstationObject, TransmissionLineObject, WeatherScenario } from '@/lib/grid/types';
import { ShieldAlert, Zap, Layers, Compass, Wind, Sun, Eye } from 'lucide-react';

interface National3DMapProps {
  substations: SubstationObject[];
  lines: TransmissionLineObject[];
  generators: DigitalGridObject[];
  selectedObjectId: string | null;
  onSelectObject: (id: string) => void;
  activeWeather?: WeatherScenario | null;
  overloadedLineIds?: string[];
  disabledLineIds?: string[];
}

export const National3DMap: React.FC<National3DMapProps> = ({
  substations,
  lines,
  generators,
  selectedObjectId,
  onSelectObject,
  activeWeather,
  overloadedLineIds = [],
  disabledLineIds = [],
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  const [hoveredObject, setHoveredObject] = useState<{ id: string; name: string; type: string } | null>(null);
  const [showTowers, setShowTowers] = useState(true);
  const [showFlowParticles, setShowFlowParticles] = useState(true);

  // Map 3D coordinate mapping helper
  // Latitude: 20°N to 50°N -> Z: 20 to -20
  // Longitude: 85°E to 125°E -> X: -30 to 30
  const latLngToVector3 = (lat: number, lng: number, alt: number = 0): THREE.Vector3 => {
    const x = ((lng - 105) / 20) * 35;
    const z = -((lat - 35) / 15) * 25;
    const y = (alt / 1000) * 2 + 0.5;
    return new THREE.Vector3(x, y, z);
  };

  useEffect(() => {
    if (!containerRef.current) return;
    const container = containerRef.current;
    const width = container.clientWidth;
    const height = container.clientHeight;

    // 1. Scene setup
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color(0x0a0f18); // Deep steel graphite blue
    scene.fog = new THREE.FogExp2(0x0a0f18, 0.008);

    // 2. Camera setup
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    cameraRef.current = camera;
    camera.position.set(0, 55, 45);
    camera.lookAt(0, 0, 0);

    // 3. Renderer setup
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    rendererRef.current = renderer;
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;

    // Clear previous canvas
    while (container.firstChild) {
      container.removeChild(container.firstChild);
    }
    container.appendChild(renderer.domElement);

    // 4. Lights
    const ambientLight = new THREE.AmbientLight(0x384c66, 1.8);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xaad5ff, 2.2);
    dirLight.position.set(30, 80, 40);
    dirLight.castShadow = true;
    scene.add(dirLight);

    // 5. China Map Base Plane (Grid Mesh & Relief)
    const mapWidth = 80;
    const mapHeight = 60;
    const mapGeo = new THREE.PlaneGeometry(mapWidth, mapHeight, 64, 64);
    
    // Create subtle terrain relief elevation
    const pos = mapGeo.attributes.position;
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const z = pos.getY(i);
      // Qinghai-Tibet plateau elevation on left (x < -10)
      let elev = 0;
      if (x < -5) {
        elev = Math.sin((x + 10) * 0.1) * 2.5 + Math.cos(z * 0.1) * 1.5;
      }
      pos.setZ(i, Math.max(0, elev));
    }
    mapGeo.computeVertexNormals();
    mapGeo.rotateX(-Math.PI / 2);

    const mapMat = new THREE.MeshStandardMaterial({
      color: 0x121b28,
      roughness: 0.8,
      metalness: 0.2,
      wireframe: false,
    });
    const mapMesh = new THREE.Mesh(mapGeo, mapMat);
    mapMesh.receiveShadow = true;
    scene.add(mapMesh);

    // Grid wireframe overlay
    const gridHelper = new THREE.GridHelper(90, 45, 0x1f344d, 0x152538);
    gridHelper.position.y = 0.05;
    scene.add(gridHelper);

    // 6. Regional Labels & Markers
    const regions = [
      { name: '华北 (North China)', lat: 39.9, lng: 116.4 },
      { name: '华东 (East China)', lat: 31.2, lng: 121.5 },
      { name: '华中 (Central China)', lat: 30.6, lng: 114.3 },
      { name: '西北 (Northwest China)', lat: 37.0, lng: 106.0 },
      { name: '西南 (Southwest China)', lat: 29.5, lng: 103.0 },
      { name: '南方/华南 (Southern Grid)', lat: 23.1, lng: 113.2 },
    ];

    regions.forEach((reg) => {
      const vec = latLngToVector3(reg.lat, reg.lng);
      const ringGeo = new THREE.RingGeometry(1.5, 1.8, 32);
      ringGeo.rotateX(-Math.PI / 2);
      const ringMat = new THREE.MeshBasicMaterial({
        color: 0x2e4b6e,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.5,
      });
      const ringMesh = new THREE.Mesh(ringGeo, ringMat);
      ringMesh.position.copy(vec);
      ringMesh.position.y = 0.1;
      scene.add(ringMesh);
    });

    // 7. Render Substations & Power Plants as 3D Interactive Nodes
    const nodeObjectsMap = new Map<string, THREE.Object3D>();

    substations.forEach((sub) => {
      const vec = latLngToVector3(sub.location.lat, sub.location.lng, sub.location.alt);
      
      const isUHV = sub.voltageLevel.includes('1000') || sub.voltageLevel.includes('1100') || sub.voltageLevel.includes('800');
      const nodeColor = isUHV ? 0x00e5ff : 0x00ff88; // UHV Cyan / 500kV Emerald Green
      
      const group = new THREE.Group();
      group.position.copy(vec);

      // Base pedestal
      const pedGeo = new THREE.CylinderGeometry(1.2, 1.5, 0.6, 8);
      const pedMat = new THREE.MeshStandardMaterial({ color: 0x1c2b3e, metalness: 0.8 });
      const pedMesh = new THREE.Mesh(pedGeo, pedMat);
      pedMesh.position.y = 0.3;
      group.add(pedMesh);

      // Main substation tower beacon
      const beaconGeo = new THREE.OctahedronGeometry(0.9, 0);
      const beaconMat = new THREE.MeshStandardMaterial({
        color: selectedObjectId === sub.id ? 0xffcc00 : nodeColor,
        emissive: selectedObjectId === sub.id ? 0xffaa00 : nodeColor,
        emissiveIntensity: selectedObjectId === sub.id ? 0.8 : 0.4,
        roughness: 0.2,
      });
      const beaconMesh = new THREE.Mesh(beaconGeo, beaconMat);
      beaconMesh.position.y = 1.8;
      group.add(beaconMesh);

      // Pulsing outer halo
      const haloGeo = new THREE.RingGeometry(1.8, 2.2, 32);
      haloGeo.rotateX(-Math.PI / 2);
      const haloMat = new THREE.MeshBasicMaterial({
        color: nodeColor,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.4,
      });
      const haloMesh = new THREE.Mesh(haloGeo, haloMat);
      haloMesh.position.y = 0.15;
      group.add(haloMesh);

      group.userData = { id: sub.id, name: sub.name, type: sub.type };
      scene.add(group);
      nodeObjectsMap.set(sub.id, group);
    });

    // Generators
    generators.forEach((gen) => {
      const vec = latLngToVector3(gen.location.lat, gen.location.lng, gen.location.alt);
      const group = new THREE.Group();
      group.position.copy(vec);

      let genColor = 0xffa500; // Orange default
      if (gen.type === 'HydroPlant') genColor = 0x00aaff;
      if (gen.type === 'WindFarm') genColor = 0x77ff00;
      if (gen.type === 'SolarFarm') genColor = 0xffe600;
      if (gen.type === 'BatteryEnergyStorage') genColor = 0xff00ff;

      const genGeo = new THREE.BoxGeometry(1.4, 1.4, 1.4);
      const genMat = new THREE.MeshStandardMaterial({
        color: genColor,
        emissive: genColor,
        emissiveIntensity: 0.3,
        roughness: 0.3,
      });
      const genMesh = new THREE.Mesh(genGeo, genMat);
      genMesh.position.y = 0.7;
      group.add(genMesh);

      group.userData = { id: gen.id, name: gen.name, type: gen.type };
      scene.add(group);
      nodeObjectsMap.set(gen.id, group);
    });

    // 8. Transmission Line Corridors & Power Flow Animation
    const flowParticles: { mesh: THREE.Mesh; startVec: THREE.Vector3; endVec: THREE.Vector3; progress: number; speed: number }[] = [];

    lines.forEach((line) => {
      const fromSub = substations.find((s) => s.id === line.fromSubstationId) || generators.find((g) => g.id === line.fromSubstationId);
      const toSub = substations.find((s) => s.id === line.toSubstationId) || generators.find((g) => g.id === line.toSubstationId);

      if (!fromSub || !toSub) return;

      const startVec = latLngToVector3(fromSub.location.lat, fromSub.location.lng, fromSub.location.alt);
      const endVec = latLngToVector3(toSub.location.lat, toSub.location.lng, toSub.location.alt);

      const isTripped = disabledLineIds.includes(line.id);
      const isOverloaded = overloadedLineIds.includes(line.id);

      let lineColor = line.isUHV ? 0x00e5ff : 0x00ff88;
      if (isOverloaded) lineColor = 0xff3300; // Red alert
      if (isTripped) lineColor = 0x445566; // Grey disabled

      // Catenary curve midpoint elevation
      const midVec = new THREE.Vector3().addVectors(startVec, endVec).multiplyScalar(0.5);
      midVec.y += 3.5;

      const curve = new THREE.QuadraticBezierCurve3(startVec, midVec, endVec);
      const points = curve.getPoints(40);
      const lineGeo = new THREE.BufferGeometry().setFromPoints(points);

      const lineMat = new THREE.LineDashedMaterial({
        color: lineColor,
        dashSize: isTripped ? 0.8 : 2,
        gapSize: isTripped ? 0.8 : 0,
        linewidth: line.isUHV ? 3 : 2,
      });

      const lineMesh = new THREE.Line(lineGeo, lineMat);
      lineMesh.computeLineDistances();
      scene.add(lineMesh);

      // Power flow particles moving along line
      if (!isTripped && showFlowParticles) {
        for (let p = 0; p < 3; p++) {
          const particleGeo = new THREE.SphereGeometry(0.35, 8, 8);
          const particleMat = new THREE.MeshBasicMaterial({ color: isOverloaded ? 0xff2200 : 0xffffff });
          const particleMesh = new THREE.Mesh(particleGeo, particleMat);
          scene.add(particleMesh);

          flowParticles.push({
            mesh: particleMesh,
            startVec,
            endVec,
            progress: p / 3,
            speed: 0.005 + (line.telemetry.loadingPercent / 100) * 0.008,
          });
        }
      }

      // Towers
      if (showTowers && line.towers.length > 0) {
        line.towers.forEach((tower) => {
          const tVec = latLngToVector3(tower.location.lat, tower.location.lng);
          const tGeo = new THREE.CylinderGeometry(0.1, 0.4, 1.8, 4);
          const tMat = new THREE.MeshBasicMaterial({ color: tower.defects.length > 0 ? 0xffaa00 : 0x557799 });
          const tMesh = new THREE.Mesh(tGeo, tMat);
          tMesh.position.copy(tVec);
          tMesh.position.y = 0.9;
          scene.add(tMesh);
        });
      }
    });

    // 9. Weather Storm Overlay
    if (activeWeather) {
      const stormVec = latLngToVector3(activeWeather.centerLat, activeWeather.centerLng);
      const stormGeo = new THREE.SphereGeometry(activeWeather.radiusKm * 0.15, 16, 16);
      const stormMat = new THREE.MeshStandardMaterial({
        color: 0xff3355,
        transparent: true,
        opacity: 0.35,
        wireframe: true,
      });
      const stormMesh = new THREE.Mesh(stormGeo, stormMat);
      stormMesh.position.copy(stormVec);
      stormMesh.position.y = 4.0;
      scene.add(stormMesh);
    }

    // 10. Mouse Interaction (Raycasting)
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();

    const handlePointerMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(mouse, camera);
      const intersects = raycaster.intersectObjects(scene.children, true);

      let found = false;
      for (const hit of intersects) {
        let curr: THREE.Object3D | null = hit.object;
        while (curr && !curr.userData?.id) {
          curr = curr.parent;
        }
        if (curr && curr.userData?.id) {
          setHoveredObject({ id: curr.userData.id, name: curr.userData.name, type: curr.userData.type });
          found = true;
          break;
        }
      }
      if (!found) setHoveredObject(null);
    };

    const handleClick = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(mouse, camera);
      const intersects = raycaster.intersectObjects(scene.children, true);

      for (const hit of intersects) {
        let curr: THREE.Object3D | null = hit.object;
        while (curr && !curr.userData?.id) {
          curr = curr.parent;
        }
        if (curr && curr.userData?.id) {
          onSelectObject(curr.userData.id);
          break;
        }
      }
    };

    container.addEventListener('mousemove', handlePointerMove);
    container.addEventListener('click', handleClick);

    // 11. Animation Loop
    let angle = 0;
    const animate = () => {
      animationFrameRef.current = requestAnimationFrame(animate);

      // Rotate nodes beacon slightly
      nodeObjectsMap.forEach((obj) => {
        const beacon = obj.children[1];
        if (beacon) beacon.rotation.y += 0.015;
      });

      // Animate flow particles
      flowParticles.forEach((p) => {
        p.progress += p.speed;
        if (p.progress >= 1) p.progress = 0;
        p.mesh.position.lerpVectors(p.startVec, p.endVec, p.progress);
        p.mesh.position.y += Math.sin(p.progress * Math.PI) * 2.0;
      });

      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!containerRef.current || !rendererRef.current || !cameraRef.current) return;
      const w = containerRef.current.clientWidth;
      const h = containerRef.current.clientHeight;
      cameraRef.current.aspect = w / h;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      container.removeEventListener('mousemove', handlePointerMove);
      container.removeEventListener('click', handleClick);
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
      if (rendererRef.current) rendererRef.current.dispose();
    };
  }, [substations, lines, generators, selectedObjectId, activeWeather, overloadedLineIds, disabledLineIds, showFlowParticles, showTowers]);

  return (
    <div className="relative w-full h-full overflow-hidden bg-slate-950">
      {/* 3D WebGL Canvas Container */}
      <div ref={containerRef} className="w-full h-full cursor-crosshair" />

      {/* Demonstration / Simulated Grid Badge */}
      <div className="absolute top-4 left-4 z-10 flex items-center space-x-2 bg-slate-900/90 border border-emerald-500/40 px-3 py-1.5 rounded-sm backdrop-blur shadow-lg">
        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
        <span className="text-xs font-mono tracking-wider text-emerald-300 font-semibold">
          DEMONSTRATION / SIMULATED GRID | 仿真/演示电网
        </span>
      </div>

      {/* Map Control Floating Toolbar */}
      <div className="absolute top-4 right-4 z-10 flex items-center space-x-2 bg-slate-900/80 border border-slate-700/60 p-1.5 rounded-md backdrop-blur">
        <button
          onClick={() => setShowFlowParticles(!showFlowParticles)}
          className={`flex items-center space-x-1 px-2.5 py-1 text-xs font-mono rounded transition-colors ${
            showFlowParticles ? 'bg-cyan-950 text-cyan-300 border border-cyan-700' : 'text-slate-400 hover:bg-slate-800'
          }`}
        >
          <Zap className="w-3.5 h-3.5" />
          <span>潮流粒子 (Power Flow)</span>
        </button>
        <button
          onClick={() => setShowTowers(!showTowers)}
          className={`flex items-center space-x-1 px-2.5 py-1 text-xs font-mono rounded transition-colors ${
            showTowers ? 'bg-emerald-950 text-emerald-300 border border-emerald-700' : 'text-slate-400 hover:bg-slate-800'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>输电铁塔 (Towers)</span>
        </button>
      </div>

      {/* Hover Information Tooltip */}
      {hoveredObject && (
        <div className="absolute bottom-6 left-6 z-20 bg-slate-900/95 border border-cyan-500/60 px-4 py-2.5 rounded shadow-xl backdrop-blur font-mono text-xs text-slate-200">
          <div className="text-cyan-400 font-bold tracking-wide">{hoveredObject.name}</div>
          <div className="text-slate-400 mt-0.5">
            类型 Type: <span className="text-slate-200">{hoveredObject.type}</span> | ID: <span className="text-slate-200">{hoveredObject.id}</span>
          </div>
          <div className="text-emerald-400 text-[11px] mt-1">点击进入 3D 详细数字孪生 / Click to inspect twin</div>
        </div>
      )}

      {/* Legend */}
      <div className="absolute bottom-6 right-6 z-10 bg-slate-900/80 border border-slate-800 p-3 rounded-md backdrop-blur text-xs font-mono text-slate-300 space-y-1.5">
        <div className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold mb-1">Grid Asset Legend</div>
        <div className="flex items-center space-x-2">
          <span className="w-3 h-3 rounded-full bg-cyan-400 shadow-[0_0_8px_rgba(6,182,212,0.8)]" />
          <span>1000kV / ±1100kV / ±800kV 特高压 (UHV)</span>
        </div>
        <div className="flex items-center space-x-2">
          <span className="w-3 h-3 rounded-full bg-emerald-400" />
          <span>500kV 主干网变电站 (500kV Hub)</span>
        </div>
        <div className="flex items-center space-x-2">
          <span className="w-3 h-3 rounded bg-amber-400" />
          <span>新能源发电机组 (Wind / Solar / Hydro)</span>
        </div>
        <div className="flex items-center space-x-2">
          <span className="w-3 h-3 rounded bg-fuchsia-400" />
          <span>储能电站 (BESS Storage)</span>
        </div>
      </div>
    </div>
  );
};
