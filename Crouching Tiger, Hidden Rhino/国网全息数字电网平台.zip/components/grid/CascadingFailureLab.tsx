'use client';

import React, { useState } from 'react';
import { SubstationObject, TransmissionLineObject, DigitalGridObject } from '@/lib/grid/types';
import { ShieldAlert, X, AlertTriangle, Play, RefreshCw, CheckCircle2 } from 'lucide-react';

interface CascadingFailureLabProps {
  isOpen: boolean;
  onClose: () => void;
  substations: SubstationObject[];
  lines: TransmissionLineObject[];
  generators: DigitalGridObject[];
  onApplyCascadingOutages: (trippedLineIds: string[]) => void;
}

export const CascadingFailureLab: React.FC<CascadingFailureLabProps> = ({
  isOpen,
  onClose,
  substations,
  lines,
  generators,
  onApplyCascadingOutages,
}) => {
  const [initialTripId, setInitialTripId] = useState<string>('line_changji_guzhou');
  const [cascadeSteps, setCascadeSteps] = useState<
    Array<{ step: number; event: string; affectedMW: number; status: string }>
  >([]);
  const [isSimulating, setIsSimulating] = useState(false);

  if (!isOpen) return null;

  const handleRunCascade = () => {
    setIsSimulating(true);
    setCascadeSteps([]);

    const steps = [
      {
        step: 1,
        event: 'Initial Fault: 昌吉-古泉 ±1100kV 直流极 I/II 双极突发跳闸',
        affectedMW: 12000,
        status: 'CRITICAL',
      },
      {
        step: 2,
        event: 'Power Flow Shift: 12,000MW 在 350ms 内转移至华中/上海交流通道',
        affectedMW: 8500,
        status: 'WARNING',
      },
      {
        step: 3,
        event: 'Secondary Overload: 淮南-上海 1000kV 交流双回线负载率飙升至 118%',
        affectedMW: 4200,
        status: 'MAJOR',
      },
      {
        step: 4,
        event: 'Automatic Protection: 1000kV 淮线过流 1.2s 保护触发，联切华东抽水蓄能 2000MW',
        affectedMW: 2000,
        status: 'ACTION_TAKEN',
      },
      {
        step: 5,
        event: 'Grid Stabilization: 频率最低跌落至 49.62Hz，经 BESS 快速响应后恢复至 49.95Hz',
        affectedMW: 0,
        status: 'STABILIZED',
      },
    ];

    let current = 0;
    const interval = setInterval(() => {
      if (current < steps.length) {
        setCascadeSteps((prev) => [...prev, steps[current]]);
        current++;
      } else {
        clearInterval(interval);
        setIsSimulating(false);
        onApplyCascadingOutages(['line_changji_guzhou']);
      }
    }, 1200);
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 font-mono text-xs text-slate-200">
      <div className="bg-slate-900 border border-slate-700 rounded-lg max-w-3xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <ShieldAlert className="w-5 h-5 text-rose-400" />
            <div>
              <h2 className="text-sm font-bold text-slate-100">CASCADING FAILURE LAB | N-1-1 连锁故障仿真</h2>
              <p className="text-[11px] text-slate-400">
                Controlled Sequential Outage & Transient Flow Redistribution Solver
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-200">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4 flex-1 overflow-y-auto">
          <div className="bg-slate-950 p-4 rounded border border-slate-800 space-y-3">
            <label className="text-slate-300 font-bold block">选择初始触发跳闸通道 (Initial Fault Root):</label>
            <select
              value={initialTripId}
              onChange={(e) => setInitialTripId(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-slate-200 font-mono text-xs"
            >
              {lines.map((l) => (
                <option key={l.id} value={l.id}>
                  {l.name} ({l.voltageLevel} - {l.lengthKm}km)
                </option>
              ))}
            </select>

            <button
              onClick={handleRunCascade}
              disabled={isSimulating}
              className="w-full py-2.5 bg-rose-950 hover:bg-rose-900 border border-rose-800 rounded text-rose-300 font-bold transition-all flex items-center justify-center space-x-2 disabled:opacity-50"
            >
              <Play className="w-4 h-4 text-rose-400" />
              <span>启动连锁故障演化求解 (Start Cascading Solver)</span>
            </button>
          </div>

          {/* Steps Timeline */}
          {cascadeSteps.length > 0 && (
            <div className="space-y-3 pt-2">
              <div className="text-slate-300 font-bold">连锁故障演化时序 (PROPAGATION TIMELINE):</div>
              {cascadeSteps.map((st) => (
                <div
                  key={st.step}
                  className={`p-3 rounded border space-y-1 animate-in fade-in slide-in-from-left duration-300 ${
                    st.status === 'CRITICAL'
                      ? 'bg-rose-950/60 border-rose-800'
                      : st.status === 'STABILIZED'
                      ? 'bg-emerald-950/60 border-emerald-800'
                      : 'bg-slate-950 border-slate-800'
                  }`}
                >
                  <div className="flex items-center justify-between text-[10px]">
                    <span className="font-bold text-cyan-400">STEP {st.step}</span>
                    <span className="text-slate-400">Impact: {st.affectedMW} MW</span>
                  </div>
                  <div className="font-bold text-slate-200 text-xs">{st.event}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
