'use client';

import React, { useState } from 'react';
import { TowerObject, DefectItem } from '@/lib/grid/types';
import { Eye, ShieldAlert, CheckCircle2, AlertTriangle, Camera, Layers, Wrench, RefreshCw } from 'lucide-react';

interface AIInspectionViewProps {
  towers: TowerObject[];
}

export const AIInspectionView: React.FC<AIInspectionViewProps> = ({ towers }) => {
  const [selectedTowerId, setSelectedTowerId] = useState<string>(towers[0]?.id || 'tower_n128');

  const selectedTower = towers.find((t) => t.id === selectedTowerId) || towers[0];

  return (
    <div className="w-full h-full bg-slate-950 p-6 flex flex-col font-mono text-slate-200 overflow-y-auto">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-6">
        <div>
          <h2 className="text-lg font-bold text-emerald-400 tracking-wide flex items-center space-x-2">
            <Eye className="w-5 h-5" />
            <span>AI DRONE INSPECTION & DEFECT ANALYZER | 输电线路无人机 AI 视觉巡检孪生</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Autonomous Drone LiDAR & High-Resolution Optical Inspection with On-Tower Computer Vision Defect Detection
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <span className="px-2.5 py-1 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 text-xs font-bold flex items-center space-x-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>DRONE #4 ACTIVE IN FLIGHT</span>
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1">
        {/* Left: Tower List */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4 space-y-3">
          <div className="text-xs font-bold text-slate-400 uppercase border-b border-slate-800 pb-2">
            特高压/主干网杆塔列表 (Towers)
          </div>

          <div className="space-y-2 max-h-[550px] overflow-y-auto">
            {towers.map((tower) => {
              const isSelected = tower.id === selectedTowerId;
              const hasCriticalDefect = tower.defects.some((d) => d.severity === 'critical' || d.severity === 'high');

              return (
                <div
                  key={tower.id}
                  onClick={() => setSelectedTowerId(tower.id)}
                  className={`p-3 rounded border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-cyan-950/80 border-cyan-400 shadow-md'
                      : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-200">{tower.towerNumber}</span>
                    <span
                      className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                        hasCriticalDefect
                          ? 'bg-rose-950 text-rose-400 border border-rose-800'
                          : 'bg-emerald-950 text-emerald-400'
                      }`}
                    >
                      {tower.defects.length > 0 ? `${tower.defects.length} DEFECTS` : 'NORMAL'}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1">Line: {tower.lineId}</div>
                  <div className="text-[10px] text-slate-500 mt-0.5">
                    Tower Type: {tower.type} | Height: {tower.heightMeters}m | Icing: {tower.icingRisk}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Center: Synthetic Optical Computer Vision Feed with Bounding Box Overlays */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col space-y-4">
          <div className="flex items-center justify-between text-xs border-b border-slate-800 pb-2">
            <span className="font-bold text-cyan-400 flex items-center space-x-1.5">
              <Camera className="w-4 h-4 text-cyan-400" />
              <span>DRONE CV OPTICAL FEED (4K HDR)</span>
            </span>
            <span className="text-slate-400 text-[10px]">FPS: 30 | Latency: 42ms</span>
          </div>

          {/* Synthetic Tower & Defect Bounding Box Graphic */}
          <div className="relative flex-1 bg-slate-950 border border-slate-800 rounded min-h-[360px] flex items-center justify-center overflow-hidden">
            {/* Background Grid Pattern */}
            <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:2rem_2rem] opacity-30" />

            {/* Simulated 2D Tower SVG Schematic */}
            <svg viewBox="0 0 400 300" className="w-full h-full p-4 relative z-10">
              {/* Tower Lattice Body */}
              <line x1="200" y1="40" x2="160" y2="280" stroke="#475569" strokeWidth="4" />
              <line x1="200" y1="40" x2="240" y2="280" stroke="#475569" strokeWidth="4" />
              <line x1="140" y1="100" x2="260" y2="100" stroke="#475569" strokeWidth="4" />
              <line x1="120" y1="160" x2="280" y2="160" stroke="#475569" strokeWidth="4" />
              
              {/* Cross arm diagonals */}
              <line x1="160" y1="100" x2="240" y2="160" stroke="#334155" strokeWidth="2" />
              <line x1="240" y1="100" x2="160" y2="160" stroke="#334155" strokeWidth="2" />

              {/* Insulator Strings */}
              <circle cx="140" cy="115" r="8" fill="#00e5ff" opacity="0.8" />
              <circle cx="260" cy="115" r="8" fill="#00e5ff" opacity="0.8" />

              {/* Bounding Box 1: Broken Insulator */}
              <rect
                x="120"
                y="95"
                width="45"
                height="40"
                fill="none"
                stroke="#f43f5e"
                strokeWidth="2"
                strokeDasharray="4 2"
                className="animate-pulse"
              />
              <text x="120" y="90" fill="#f43f5e" fontSize="10" fontFamily="monospace" fontWeight="bold">
                [AI: Broken Insulator 98.4%]
              </text>

              {/* Bounding Box 2: Vegetation Encroachment */}
              <rect
                x="220"
                y="220"
                width="70"
                height="50"
                fill="none"
                stroke="#fbbf24"
                strokeWidth="2"
                strokeDasharray="4 2"
              />
              <text x="220" y="215" fill="#fbbf24" fontSize="10" fontFamily="monospace" fontWeight="bold">
                [AI: Vegetation Clear &lt; 2.5m]
              </text>
            </svg>

            {/* Telemetry Overlay */}
            <div className="absolute bottom-3 left-3 z-20 bg-slate-900/90 border border-slate-800 px-3 py-1.5 rounded text-[10px] text-slate-300 font-mono">
              Tower: <span className="text-cyan-400 font-bold">{selectedTower.towerNumber}</span> | GPS:{' '}
              {selectedTower.location.lat.toFixed(4)}°N, {selectedTower.location.lng.toFixed(4)}°E
            </div>
          </div>
        </div>

        {/* Right: Detected Defect Inspector */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4 space-y-4">
          <div className="text-xs font-bold text-slate-300 uppercase border-b border-slate-800 pb-2 flex justify-between items-center">
            <span>AI 识别缺陷列表 (Defects)</span>
            <span className="text-rose-400 font-bold">{selectedTower.defects.length} DETECTED</span>
          </div>

          {selectedTower.defects.map((def) => (
            <div key={def.id} className="bg-slate-950 p-3 rounded border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span
                  className={`px-1.5 py-0.5 rounded text-[10px] font-bold uppercase ${
                    def.severity === 'critical'
                      ? 'bg-rose-950 text-rose-300 border border-rose-800'
                      : 'bg-amber-950 text-amber-300 border border-amber-800'
                  }`}
                >
                  {def.severity}
                </span>
                <span className="text-[10px] text-cyan-400 font-bold font-mono">
                  CONFIDENCE: {(def.confidence * 100).toFixed(1)}%
                </span>
              </div>

              <div className="font-bold text-slate-200 text-xs">{def.category}</div>
              <p className="text-[11px] text-slate-400 leading-relaxed">{def.description}</p>
              <div className="text-[10px] text-slate-500">Detected At: {def.detectedAt}</div>

              <button className="w-full mt-2 py-1.5 bg-slate-800 hover:bg-slate-700 text-cyan-300 rounded text-[11px] font-semibold transition-colors">
                生成无人机缺陷检修工单 (Create Workorder)
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
