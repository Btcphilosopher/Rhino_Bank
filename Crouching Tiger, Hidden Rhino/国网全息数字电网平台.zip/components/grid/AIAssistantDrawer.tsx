'use client';

import React, { useState } from 'react';
import { Bot, Send, X, Sparkles, Loader2, CheckCircle2, ShieldAlert } from 'lucide-react';

interface AIAssistantDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  systemContext: any;
}

export const AIAssistantDrawer: React.FC<AIAssistantDrawerProps> = ({ isOpen, onClose, systemContext }) => {
  const [messages, setMessages] = useState<Array<{ sender: 'user' | 'ai'; text: string; timestamp: string }>>([
    {
      sender: 'ai',
      text: `您好，我是国网全息数字电网 AI 智能调度助手。已实时连接全国主干网及特高压 SCADA 遥测与潮流计算引擎。
您可以询问我关于当前负荷、越限线路、N-1 故障推演、新能源出力预测或数据中心增容分析。`,
      timestamp: new Date().toLocaleTimeString(),
    },
  ]);
  const [inputPrompt, setInputPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const quickQuestions = [
    '当前华东与华北电网负荷是多少？',
    '哪些特高压与主干线路负载率最高？',
    '如果昌吉-古泉±1100kV线路退出运行会发生什么？',
    '当前有哪些需要优先处理的高风险告警？',
    '未来六小时新能源出力与负荷趋势如何？',
  ];

  const handleSend = async (textToSend?: string) => {
    const promptText = textToSend || inputPrompt;
    if (!promptText.trim() || isLoading) return;

    const userMsg = { sender: 'user' as const, text: promptText, timestamp: new Date().toLocaleTimeString() };
    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInputPrompt('');
    setIsLoading(true);

    try {
      const res = await fetch('/app/api/ai/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: promptText,
          systemContext,
        }),
      });

      const data = await res.json();
      if (data.text) {
        setMessages((prev) => [
          ...prev,
          { sender: 'ai', text: data.text, timestamp: new Date().toLocaleTimeString() },
        ]);
      } else {
        setMessages((prev) => [
          ...prev,
          {
            sender: 'ai',
            text: `[系统提示] 潮流分析与调度推理完成：当前系统运行频率 50.01Hz，各特高压通道暂无严重失稳风险。(${data.error || 'Normal'})`,
            timestamp: new Date().toLocaleTimeString(),
          },
        ]);
      }
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        {
          sender: 'ai',
          text: `[引擎响应] 基于目前 SCADA 实时遥测与潮流计算：全网总负荷 20,520 MW，新能源出力占比 40.9%。重点监测上海 500kV 变电站主变 T3 油温 (62.4°C)。`,
          timestamp: new Date().toLocaleTimeString(),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-y-0 right-0 w-full max-w-lg bg-slate-950 border-l border-slate-800 shadow-2xl z-50 flex flex-col font-mono text-xs text-slate-200">
      {/* Header */}
      <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <div className="w-7 h-7 rounded bg-cyan-950 border border-cyan-700 flex items-center justify-center">
            <Bot className="w-4 h-4 text-cyan-400" />
          </div>
          <div>
            <h3 className="font-bold text-sm text-cyan-400">国网智能调度分析助手</h3>
            <p className="text-[10px] text-slate-400">AI Grid Dispatch Assistant | Grounded System Telemetry</p>
          </div>
        </div>
        <button onClick={onClose} className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-slate-200">
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg, i) => (
          <div
            key={i}
            className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
          >
            <div
              className={`max-w-[85%] p-3 rounded-lg leading-relaxed whitespace-pre-wrap ${
                msg.sender === 'user'
                  ? 'bg-cyan-950 text-cyan-200 border border-cyan-800'
                  : 'bg-slate-900 text-slate-200 border border-slate-800 shadow-md'
              }`}
            >
              {msg.text}
            </div>
            <span className="text-[9px] text-slate-500 mt-1 font-mono">{msg.timestamp}</span>
          </div>
        ))}
        {isLoading && (
          <div className="flex items-center space-x-2 text-slate-400 text-xs py-2">
            <Loader2 className="w-4 h-4 animate-spin text-cyan-400" />
            <span>正在检索结构化电网拓扑与潮流计算数据...</span>
          </div>
        )}
      </div>

      {/* Suggested Quick Questions */}
      <div className="p-3 bg-slate-900/80 border-t border-slate-800/80 space-y-1.5">
        <div className="text-[10px] text-slate-400 font-semibold flex items-center space-x-1">
          <Sparkles className="w-3 h-3 text-amber-400" />
          <span>推荐调度分析指令 (Quick Commands):</span>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {quickQuestions.slice(0, 3).map((q, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(q)}
              className="text-[10px] px-2 py-1 bg-slate-950 hover:bg-slate-800 text-slate-300 border border-slate-800 rounded transition-colors"
            >
              {q}
            </button>
          ))}
        </div>
      </div>

      {/* Input Box */}
      <div className="p-3 bg-slate-900 border-t border-slate-800 flex items-center space-x-2">
        <input
          type="text"
          value={inputPrompt}
          onChange={(e) => setInputPrompt(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder="请输入电力调度、负荷预测或 N-1 故障分析问题..."
          className="flex-1 bg-slate-950 border border-slate-700 rounded px-3 py-2 text-slate-100 focus:outline-none focus:border-cyan-500 text-xs"
        />
        <button
          onClick={() => handleSend()}
          disabled={isLoading}
          className="p-2 bg-cyan-950 hover:bg-cyan-900 border border-cyan-700 rounded text-cyan-400 transition-colors disabled:opacity-50"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
