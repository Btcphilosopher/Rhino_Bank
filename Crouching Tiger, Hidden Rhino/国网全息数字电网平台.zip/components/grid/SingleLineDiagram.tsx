'use client';

import React from 'react';
import { SubstationObject, TransmissionLineObject, DigitalGridObject } from '@/lib/grid/types';
import { Zap, Activity, ShieldAlert, Cpu, CheckCircle2 } from 'lucide-react';

interface SingleLineDiagramProps {
  substations: SubstationObject[];
  lines: TransmissionLineObject[];
  generators: DigitalGridObject[];
  selectedObjectId: string | null;
  onSelectObject: (id: string) => void;
  disabledLineIds?: string[];
}

export const SingleLineDiagram: React.FC<SingleLineDiagramProps> = ({
  substations,
  lines,
  generators,
  selectedObjectId,
  onSelectObject,
  disabledLineIds = [],
}) => {
  return (
    <div className="w-full h-full bg-slate-950 p-6 flex flex-col font-mono text-slate-200 overflow-auto">
      {/* Header bar */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-6">
        <div>
          <h2 className="text-lg font-bold text-cyan-400 tracking-wide flex items-center space-x-2">
            <Zap className="w-5 h-5" />
            <span>NATIONAL GRID SINGLE-LINE DIAGRAM (SLD) | 电气拓扑单线图</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Real-time Nodal Connectivity Graph (Generator → Busbar → Transformer → UHV/HV Line → Substation → Load)
          </p>
        </div>

        <div className="flex items-center space-x-4 text-xs">
          <div className="flex items-center space-x-1.5">
            <span className="w-3 h-1.5 bg-cyan-400 rounded-sm" />
            <span>1000kV / ±1100kV UHV Bus</span>
          </div>
          <div className="flex items-center space-x-1.5">
            <span className="w-3 h-1.5 bg-emerald-400 rounded-sm" />
            <span>500kV Busbar</span>
          </div>
          <div className="flex items-center space-x-1.5">
            <span className="w-3.5 h-3.5 border border-amber-400 rounded-full flex items-center justify-center text-[9px] text-amber-400">
              G
            </span>
            <span>Generator Node</span>
          </div>
        </div>
      </div>

      {/* Topological Schematic Canvas */}
      <div className="relative flex-1 bg-slate-900/60 border border-slate-800 rounded-lg p-8 min-h-[500px] flex items-center justify-between space-x-6 overflow-x-auto">
        {/* Layer 1: Generation Fleet */}
        <div className="flex flex-col space-y-6 min-w-[200px]">
          <div className="text-xs font-bold text-slate-400 uppercase border-b border-slate-800 pb-1">
            发电端 (Generators)
          </div>

          {generators.map((gen) => {
            const isSelected = selectedObjectId === gen.id;
            return (
              <div
                key={gen.id}
                onClick={() => onSelectObject(gen.id)}
                className={`p-3 rounded border cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-amber-950/80 border-amber-400 shadow-[0_0_12px_rgba(251,191,36,0.4)]'
                    : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="w-6 h-6 rounded-full border-2 border-amber-400 text-amber-400 font-bold flex items-center justify-center text-xs">
                    G
                  </span>
                  <span className="text-[10px] text-emerald-400 font-bold">LIVE</span>
                </div>
                <div className="font-bold text-xs text-slate-100 mt-2 truncate">{gen.name}</div>
                <div className="text-[11px] text-amber-300 font-mono mt-1">
                  P: {gen.telemetry.activePowerMW} MW
                </div>
              </div>
            );
          })}
        </div>

        {/* Electrical Busbar 1 (West/North Sending Bus) */}
        <div className="w-2 bg-gradient-to-b from-cyan-500 via-emerald-400 to-cyan-500 h-80 rounded-full shadow-[0_0_15px_rgba(6,182,212,0.6)] relative flex items-center justify-center">
          <span className="absolute -top-6 text-[10px] text-cyan-400 font-bold whitespace-nowrap">
            BUSBAR 1000kV #1
          </span>
        </div>

        {/* Layer 2: Sending Substations & Converter Stations */}
        <div className="flex flex-col space-y-6 min-w-[220px]">
          <div className="text-xs font-bold text-slate-400 uppercase border-b border-slate-800 pb-1">
            送端变电站/换流站
          </div>

          {substations.slice(0, 3).map((sub) => {
            const isSelected = selectedObjectId === sub.id;
            return (
              <div
                key={sub.id}
                onClick={() => onSelectObject(sub.id)}
                className={`p-3.5 rounded border cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-cyan-950/80 border-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.4)]'
                    : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex justify-between items-center text-[10px] text-slate-400">
                  <span className="text-cyan-400 font-bold">{sub.voltageLevel}</span>
                  <span>{sub.substationType}</span>
                </div>
                <div className="font-bold text-xs text-slate-100 mt-1">{sub.name}</div>
                
                {/* Circuit Breaker Badge */}
                <div className="flex items-center space-x-2 mt-2 pt-2 border-t border-slate-800/80 text-[10px]">
                  <span className="w-2 h-2 rounded-full bg-emerald-400" />
                  <span className="text-slate-300">CB 5012: CLOSED</span>
                  <span className="text-slate-400 ml-auto">{sub.telemetry.voltagekV}kV</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Layer 3: UHV / HV Transmission Corridors */}
        <div className="flex flex-col space-y-4 min-w-[240px]">
          <div className="text-xs font-bold text-slate-400 uppercase border-b border-slate-800 pb-1">
            特高压输电通道 (UHV Lines)
          </div>

          {lines.map((line) => {
            const isTripped = disabledLineIds.includes(line.id);
            const isSelected = selectedObjectId === line.id;
            return (
              <div
                key={line.id}
                onClick={() => onSelectObject(line.id)}
                className={`p-3 rounded border cursor-pointer transition-all ${
                  isTripped
                    ? 'bg-rose-950/30 border-rose-800 opacity-60'
                    : isSelected
                    ? 'bg-emerald-950/80 border-emerald-400 shadow-[0_0_12px_rgba(52,211,153,0.4)]'
                    : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex justify-between items-center text-[10px]">
                  <span className={isTripped ? 'text-rose-400 font-bold' : 'text-emerald-400 font-bold'}>
                    {isTripped ? 'TRIPPED (已跳闸)' : 'ACTIVE (正常)'}
                  </span>
                  <span className="text-slate-400">{line.lengthKm} km</span>
                </div>
                <div className="font-bold text-xs text-slate-200 mt-1 truncate">{line.name}</div>
                
                <div className="w-full bg-slate-800 h-1.5 rounded-full mt-2 overflow-hidden">
                  <div
                    className={`h-full ${
                      isTripped ? 'bg-rose-600' : line.telemetry.loadingPercent > 80 ? 'bg-amber-400' : 'bg-emerald-400'
                    }`}
                    style={{ width: `${isTripped ? 0 : line.telemetry.loadingPercent}%` }}
                  />
                </div>
                <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                  <span>P: {isTripped ? 0 : line.telemetry.activePowerMW} MW</span>
                  <span>{line.telemetry.loadingPercent}% Load</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Electrical Busbar 2 (East/Central Receiving Bus) */}
        <div className="w-2 bg-gradient-to-b from-emerald-400 via-cyan-400 to-emerald-400 h-80 rounded-full shadow-[0_0_15px_rgba(52,211,153,0.6)] relative flex items-center justify-center">
          <span className="absolute -top-6 text-[10px] text-emerald-400 font-bold whitespace-nowrap">
            BUSBAR 500kV #2
          </span>
        </div>

        {/* Layer 4: Load Center Receiving Substations */}
        <div className="flex flex-col space-y-6 min-w-[220px]">
          <div className="text-xs font-bold text-slate-400 uppercase border-b border-slate-800 pb-1">
            受端负荷中心 (Load Substations)
          </div>

          {substations.slice(3).map((sub) => {
            const isSelected = selectedObjectId === sub.id;
            return (
              <div
                key={sub.id}
                onClick={() => onSelectObject(sub.id)}
                className={`p-3.5 rounded border cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-cyan-950/80 border-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.4)]'
                    : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex justify-between items-center text-[10px] text-slate-400">
                  <span className="text-emerald-400 font-bold">{sub.voltageLevel}</span>
                  <span>{sub.city}</span>
                </div>
                <div className="font-bold text-xs text-slate-100 mt-1">{sub.name}</div>
                <div className="text-[11px] text-emerald-300 font-mono mt-1">
                  Demand: {sub.telemetry.activePowerMW} MW
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
