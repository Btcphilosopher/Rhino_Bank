'use client';

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { SubstationObject } from '@/lib/grid/types';
import { Cpu, Zap, Activity, Thermometer, ShieldAlert, CheckCircle2, RefreshCw } from 'lucide-react';

interface SubstationBIM3DProps {
  substation: SubstationObject;
}

export const SubstationBIM3D: React.FC<SubstationBIM3DProps> = ({ substation }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const [selectedSubComponent, setSelectedSubComponent] = useState<string>('tf_t1');
  const [wireframeMode, setWireframeMode] = useState(false);

  useEffect(() => {
    if (!containerRef.current) return;
    const container = containerRef.current;
    const width = container.clientWidth;
    const height = container.clientHeight;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0f18);
    scene.fog = new THREE.FogExp2(0x0a0f18, 0.015);

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 500);
    camera.position.set(25, 20, 30);
    camera.lookAt(0, 3, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;

    while (container.firstChild) container.removeChild(container.firstChild);
    container.appendChild(renderer.domElement);

    // Lights
    const ambientLight = new THREE.AmbientLight(0x405570, 2.0);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffffff, 2.5);
    dirLight.position.set(20, 40, 20);
    dirLight.castShadow = true;
    scene.add(dirLight);

    // Substation Ground Yard Mat
    const yardGeo = new THREE.PlaneGeometry(60, 50);
    yardGeo.rotateX(-Math.PI / 2);
    const yardMat = new THREE.MeshStandardMaterial({
      color: 0x182433,
      roughness: 0.9,
    });
    const yardMesh = new THREE.Mesh(yardGeo, yardMat);
    yardMesh.receiveShadow = true;
    scene.add(yardMesh);

    const grid = new THREE.GridHelper(60, 30, 0x22364e, 0x162436);
    grid.position.y = 0.05;
    scene.add(grid);

    // Perimeter Security Fence
    const fenceMat = new THREE.MeshBasicMaterial({ color: 0x334455, wireframe: true });
    const fenceGeo = new THREE.BoxGeometry(58, 3, 48);
    const fenceMesh = new THREE.Mesh(fenceGeo, fenceMat);
    fenceMesh.position.y = 1.5;
    scene.add(fenceMesh);

    // 1. Control Building
    const bldgGeo = new THREE.BoxGeometry(12, 6, 8);
    const bldgMat = new THREE.MeshStandardMaterial({ color: 0x2d3e52, roughness: 0.5 });
    const bldg = new THREE.Mesh(bldgGeo, bldgMat);
    bldg.position.set(-18, 3, -15);
    scene.add(bldg);

    // Roof solar panels
    const roofGeo = new THREE.PlaneGeometry(11, 7);
    roofGeo.rotateX(-Math.PI / 2);
    const roofMat = new THREE.MeshStandardMaterial({ color: 0x0066cc });
    const roof = new THREE.Mesh(roofGeo, roofMat);
    roof.position.set(-18, 6.05, -15);
    scene.add(roof);

    // 2. Main Transformers (T1 & T2)
    const createTransformer = (x: number, z: number, id: string, label: string) => {
      const group = new THREE.Group();
      group.position.set(x, 0, z);

      // Tank Body
      const tankGeo = new THREE.BoxGeometry(6, 4.5, 4);
      const tankMat = new THREE.MeshStandardMaterial({
        color: selectedSubComponent === id ? 0x00e5ff : 0x2b425b,
        emissive: selectedSubComponent === id ? 0x006688 : 0x000000,
        wireframe: wireframeMode,
      });
      const tank = new THREE.Mesh(tankGeo, tankMat);
      tank.position.y = 2.25;
      group.add(tank);

      // Radiator Cooling Fins
      for (let f = -2.2; f <= 2.2; f += 0.8) {
        const finGeo = new THREE.BoxGeometry(0.3, 3.5, 4.4);
        const finMat = new THREE.MeshStandardMaterial({ color: 0x1f2e40 });
        const fin = new THREE.Mesh(finGeo, finMat);
        fin.position.set(f, 2.0, 0);
        group.add(fin);
      }

      // High Voltage Bushings (3 Top porcelain insulators)
      for (let b = -1.8; b <= 1.8; b += 1.8) {
        const bushGeo = new THREE.CylinderGeometry(0.2, 0.4, 3, 12);
        const bushMat = new THREE.MeshStandardMaterial({ color: 0xcc6600, roughness: 0.3 });
        const bush = new THREE.Mesh(bushGeo, bushMat);
        bush.position.set(b, 6, 0);
        group.add(bush);
      }

      group.userData = { id, name: label };
      scene.add(group);
      return group;
    };

    createTransformer(-8, 0, 'tf_t1', '主变压器 Main Transformer T1 (500kV/220kV)');
    createTransformer(8, 0, 'tf_t2', '主变压器 Main Transformer T2 (500kV/220kV)');

    // 3. GIS Switchgear Enclosure
    const gisGeo = new THREE.CylinderGeometry(1.0, 1.0, 24, 16);
    gisGeo.rotateZ(Math.PI / 2);
    const gisMat = new THREE.MeshStandardMaterial({ color: 0x4a6572, metalness: 0.8 });
    const gisMesh = new THREE.Mesh(gisGeo, gisMat);
    gisMesh.position.set(0, 4, 12);
    scene.add(gisMesh);

    // 4. Overhead Busbars & Gantry Towers
    for (let g = -18; g <= 18; g += 12) {
      const gantryGeo = new THREE.BoxGeometry(0.8, 12, 0.8);
      const gantryMat = new THREE.MeshStandardMaterial({ color: 0x3b5266 });
      const tower1 = new THREE.Mesh(gantryGeo, gantryMat);
      tower1.position.set(g, 6, -8);
      scene.add(tower1);
    }

    // Overhead Busbar Lines
    const busLineMat = new THREE.MeshBasicMaterial({ color: 0x00ff88 });
    for (let b = -2; b <= 2; b += 2) {
      const busGeo = new THREE.CylinderGeometry(0.08, 0.08, 40, 8);
      busGeo.rotateZ(Math.PI / 2);
      const bus = new THREE.Mesh(busGeo, busLineMat);
      bus.position.set(0, 11, -8 + b);
      scene.add(bus);
    }

    // Raycasting
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();

    const handleClick = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(mouse, camera);
      const intersects = raycaster.intersectObjects(scene.children, true);

      for (const hit of intersects) {
        let curr: THREE.Object3D | null = hit.object;
        while (curr && !curr.userData?.id) {
          curr = curr.parent;
        }
        if (curr && curr.userData?.id) {
          setSelectedSubComponent(curr.userData.id);
          break;
        }
      }
    };

    container.addEventListener('click', handleClick);

    let animId: number;
    const animate = () => {
      animId = requestAnimationFrame(animate);
      renderer.render(scene, camera);
    };
    animate();

    const handleResize = () => {
      if (!containerRef.current) return;
      const w = containerRef.current.clientWidth;
      const h = containerRef.current.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      container.removeEventListener('click', handleClick);
      cancelAnimationFrame(animId);
      renderer.dispose();
    };
  }, [substation, selectedSubComponent, wireframeMode]);

  return (
    <div className="relative w-full h-full bg-slate-950 flex flex-col md:flex-row">
      {/* 3D BIM View Canvas */}
      <div className="relative flex-1 h-full">
        <div ref={containerRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

        <div className="absolute top-4 left-4 z-10 bg-slate-900/90 border border-slate-700/80 p-3 rounded-md backdrop-blur shadow-xl font-mono text-xs">
          <div className="text-cyan-400 font-bold text-sm tracking-wide">{substation.name} - 3D BIM Twin</div>
          <div className="text-slate-400 mt-1">
            Voltage: <span className="text-emerald-400 font-bold">{substation.voltageLevel}</span> | GIS Units: <span className="text-slate-200">{substation.gisEquipmentCount}</span>
          </div>
          <div className="flex items-center space-x-2 mt-2">
            <button
              onClick={() => setWireframeMode(!wireframeMode)}
              className="px-2 py-1 bg-slate-800 hover:bg-slate-700 border border-slate-600 rounded text-[11px] text-slate-200 transition-colors"
            >
              {wireframeMode ? 'Solid Shader' : 'BIM Wireframe Structure'}
            </button>
          </div>
        </div>

        <div className="absolute bottom-4 left-4 z-10 bg-slate-900/80 border border-slate-800 px-3 py-1.5 rounded text-xs font-mono text-slate-400">
          💡 Click Transformer T1 or T2 in 3D to inspect detailed thermal stress & diagnostics
        </div>
      </div>

      {/* BIM Transformer Twin Telemetry Inspector Side Panel */}
      <div className="w-full md:w-80 bg-slate-900 border-l border-slate-800 p-4 font-mono text-xs overflow-y-auto space-y-4 text-slate-200">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="flex items-center space-x-2 text-cyan-400 font-bold">
            <Cpu className="w-4 h-4" />
            <span>TRANSFORMER TWIN T1</span>
          </div>
          <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 text-[10px] font-bold">
            HEALTH 96/100
          </span>
        </div>

        {/* Real-Time Diagnostic Telemetry Gauges */}
        <div className="grid grid-cols-2 gap-2">
          <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
            <div className="text-slate-400 text-[11px]">Loading (负载率)</div>
            <div className="text-base font-bold text-emerald-400 mt-1">{substation.telemetry.loadingPercent}%</div>
            <div className="text-[10px] text-slate-500">Nominal 63%</div>
          </div>
          <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
            <div className="text-slate-400 text-[11px]">Oil Temp (油温)</div>
            <div className="text-base font-bold text-amber-400 mt-1">{substation.telemetry.oilTemperatureC || 56.2}°C</div>
            <div className="text-[10px] text-slate-500">Max Threshold 85°C</div>
          </div>
          <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
            <div className="text-slate-400 text-[11px]">DGA Partial Dis.</div>
            <div className="text-base font-bold text-cyan-400 mt-1">12 pC</div>
            <div className="text-[10px] text-slate-500">Normal (&lt;50 pC)</div>
          </div>
          <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
            <div className="text-slate-400 text-[11px]">Tap Position</div>
            <div className="text-base font-bold text-slate-200 mt-1">+3 (105%)</div>
            <div className="text-[10px] text-slate-500">OLTC Auto Mode</div>
          </div>
        </div>

        {/* Thermal Stress Analysis */}
        <div className="bg-slate-950/60 p-3 rounded border border-slate-800 space-y-2">
          <div className="flex justify-between text-slate-300 font-semibold text-[11px]">
            <span>THERMAL STRESS SCORE</span>
            <span className="text-emerald-400">LOW (18/100)</span>
          </div>
          <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
            <div className="bg-emerald-400 h-full w-[18%]" />
          </div>
          <p className="text-[10px] text-slate-400 leading-relaxed">
            Winding hot-spot temperature calculated at 68.4°C. Insulation aging factor $V = 0.94$ (normal degradation).
          </p>
        </div>

        {/* Maintenance History */}
        <div className="space-y-1.5">
          <div className="text-slate-400 text-[11px] font-semibold">MAINTENANCE HISTORY & SCHEDULE</div>
          <div className="bg-slate-950 p-2 rounded border border-slate-800/80 text-[11px] space-y-1">
            <div className="flex justify-between text-slate-300">
              <span>Last Annual Inspection:</span>
              <span className="text-slate-400">{substation.lastMaintenanceDate}</span>
            </div>
            <div className="flex justify-between text-slate-300">
              <span>Next Scheduled Test:</span>
              <span className="text-cyan-400">{substation.nextScheduledMaintenance}</span>
            </div>
          </div>
        </div>

        <button className="w-full py-2 bg-slate-800 hover:bg-slate-700 border border-slate-600 rounded text-slate-200 font-bold transition-colors">
          Issue Inspection Work Order
        </button>
      </div>
    </div>
  );
};
