'use client';

import React, { useState, useEffect } from 'react';
import { PowerFlowResult } from '@/lib/grid/types';
import { Play, Pause, RotateCcw, FastForward, Clock, Zap, Activity, ShieldCheck } from 'lucide-react';

interface BottomTimelineProps {
  powerFlow: PowerFlowResult;
  onTimeChange: (hour: number, minute: number) => void;
}

export const BottomTimeline: React.FC<BottomTimelineProps> = ({ powerFlow, onTimeChange }) => {
  const [isPlaying, setIsPlaying] = useState(true);
  const [speedMultiplier, setSpeedMultiplier] = useState(1);
  const [simulatedMinutes, setSimulatedMinutes] = useState(0); // 0 = 08:00 AM

  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(() => {
      setSimulatedMinutes((prev) => {
        const next = (prev + 1 * speedMultiplier) % (12 * 60); // 12h simulation window (08:00 - 20:00)
        const hour = 8 + Math.floor(next / 60);
        const min = Math.floor(next % 60);
        onTimeChange(hour, min);
        return next;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isPlaying, speedMultiplier, onTimeChange]);

  const currentHour = 8 + Math.floor(simulatedMinutes / 60);
  const currentMin = Math.floor(simulatedMinutes % 60);
  const formattedTime = `${currentHour.toString().padStart(2, '0')}:${currentMin.toString().padStart(2, '0')}:00`;

  // Central Power Balance Calculation Equation
  const genMW = powerFlow.totalGenerationMW;
  const importMW = 18500; // UHV cross-region
  const bessMW = 450;
  const loadMW = powerFlow.totalLoadMW;
  const exportMW = 0;
  const lossesMW = powerFlow.totalLossesMW;

  const balanceMW = genMW + importMW + bessMW - loadMW - exportMW - lossesMW;

  return (
    <footer className="w-full bg-slate-950 border-t border-slate-800 p-3 flex flex-col md:flex-row items-center justify-between font-mono text-xs text-slate-200 z-30 select-none">
      {/* Time Machine Playback Controls */}
      <div className="flex items-center space-x-3 mb-2 md:mb-0">
        <div className="flex items-center space-x-1.5 px-3 py-1 bg-slate-900 border border-slate-700 rounded text-cyan-400 font-bold">
          <Clock className="w-4 h-4 text-cyan-400" />
          <span className="text-sm">2026-09-18 {formattedTime}</span>
        </div>

        <button
          onClick={() => setIsPlaying(!isPlaying)}
          className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-600 transition-colors"
        >
          {isPlaying ? <Pause className="w-4 h-4 text-amber-400" /> : <Play className="w-4 h-4 text-emerald-400" />}
        </button>

        <button
          onClick={() => {
            setSimulatedMinutes(0);
            onTimeChange(8, 0);
          }}
          className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-400 transition-colors"
        >
          <RotateCcw className="w-4 h-4" />
        </button>

        <button
          onClick={() => setSpeedMultiplier((prev) => (prev === 1 ? 5 : prev === 5 ? 10 : 1))}
          className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-[11px] font-bold text-cyan-300 border border-slate-700"
        >
          {speedMultiplier}x Speed
        </button>
      </div>

      {/* Scrubber Slider */}
      <div className="flex-1 max-w-xl mx-4 flex items-center space-x-3">
        <span className="text-[10px] text-slate-400">08:00</span>
        <input
          type="range"
          min={0}
          max={720}
          value={simulatedMinutes}
          onChange={(e) => {
            const val = parseInt(e.target.value);
            setSimulatedMinutes(val);
            const h = 8 + Math.floor(val / 60);
            const m = Math.floor(val % 60);
            onTimeChange(h, m);
          }}
          className="w-full accent-cyan-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
        />
        <span className="text-[10px] text-slate-400">20:00</span>
      </div>

      {/* Central Power Balance Equation Display */}
      <div className="flex items-center space-x-3 text-[11px] bg-slate-900 px-3 py-1.5 rounded border border-slate-800">
        <div className="flex items-center space-x-1 text-slate-300">
          <Zap className="w-3.5 h-3.5 text-amber-400" />
          <span>全网电量平衡方程:</span>
        </div>
        <div className="font-mono text-slate-200">
          <span className="text-cyan-400 font-bold">{genMW.toFixed(0)}</span>(发) +{' '}
          <span className="text-indigo-400">{importMW}</span>(受) -{' '}
          <span className="text-emerald-400 font-bold">{loadMW.toFixed(0)}</span>(用) -{' '}
          <span className="text-slate-400">{lossesMW.toFixed(0)}</span>(损) ={' '}
          <span className="text-emerald-400 font-bold">+{balanceMW.toFixed(0)} MW (平衡)</span>
        </div>
      </div>
    </footer>
  );
};
