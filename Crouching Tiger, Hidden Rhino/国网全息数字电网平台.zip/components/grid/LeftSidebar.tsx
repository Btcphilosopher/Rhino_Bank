'use client';

import React, { useState } from 'react';
import { SubstationObject, TransmissionLineObject, DigitalGridObject, AlarmItem } from '@/lib/grid/types';
import {
  ChevronRight,
  ChevronDown,
  Building2,
  Zap,
  Radio,
  Bell,
  CheckCircle2,
  AlertTriangle,
  Sun,
  Wind,
  Battery,
  Flame,
} from 'lucide-react';

interface LeftSidebarProps {
  substations: SubstationObject[];
  lines: TransmissionLineObject[];
  generators: DigitalGridObject[];
  alarms: AlarmItem[];
  selectedObjectId: string | null;
  onSelectObject: (id: string) => void;
  onAcknowledgeAlarm: (alarmId: string) => void;
  onTriggerScenario: (scenario: string) => void;
}

export const LeftSidebar: React.FC<LeftSidebarProps> = ({
  substations,
  lines,
  generators,
  alarms,
  selectedObjectId,
  onSelectObject,
  onAcknowledgeAlarm,
  onTriggerScenario,
}) => {
  const [activeTab, setActiveTab] = useState<'hierarchy' | 'alarms' | 'scenarios'>('hierarchy');
  const [expandedRegions, setExpandedRegions] = useState<Record<string, boolean>>({
    '华东': true,
    '西北': true,
    '华北': true,
    '华中': true,
    '西南': true,
  });

  const toggleRegion = (reg: string) => {
    setExpandedRegions((prev) => ({ ...prev, [reg]: !prev[reg] }));
  };

  const regionsList = ['华东', '西北', '华北', '华中', '西南', '东北'];

  return (
    <aside className="w-80 h-full bg-slate-950 border-r border-slate-800 flex flex-col font-mono text-xs text-slate-200 select-none z-20">
      {/* Tab Selectors */}
      <div className="flex border-b border-slate-800 bg-slate-900/60">
        <button
          onClick={() => setActiveTab('hierarchy')}
          className={`flex-1 py-2.5 text-center font-bold border-b-2 transition-all ${
            activeTab === 'hierarchy'
              ? 'border-cyan-400 text-cyan-400 bg-slate-900'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          层级电网树 (Grid)
        </button>
        <button
          onClick={() => setActiveTab('alarms')}
          className={`flex-1 py-2.5 text-center font-bold border-b-2 flex items-center justify-center space-x-1.5 transition-all ${
            activeTab === 'alarms'
              ? 'border-cyan-400 text-cyan-400 bg-slate-900'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Bell className="w-3.5 h-3.5 text-amber-400" />
          <span>告警中心 ({alarms.filter((a) => !a.acknowledged).length})</span>
        </button>
        <button
          onClick={() => setActiveTab('scenarios')}
          className={`flex-1 py-2.5 text-center font-bold border-b-2 transition-all ${
            activeTab === 'scenarios'
              ? 'border-cyan-400 text-cyan-400 bg-slate-900'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          场景推演
        </button>
      </div>

      {/* Tab 1: Hierarchy Tree */}
      {activeTab === 'hierarchy' && (
        <div className="flex-1 overflow-y-auto p-3 space-y-3">
          {/* Root Node */}
          <div className="flex items-center space-x-2 font-bold text-sm text-cyan-400 pb-2 border-b border-slate-800">
            <Building2 className="w-4 h-4" />
            <span>国家电网有限公司 (STATE GRID)</span>
          </div>

          {regionsList.map((regionName) => {
            const isExpanded = expandedRegions[regionName];
            const regSubs = substations.filter((s) => s.region === regionName);
            const regLines = lines.filter((l) => l.region === regionName);
            const regGens = generators.filter((g) => g.region === regionName);

            return (
              <div key={regionName} className="space-y-1">
                {/* Region Header */}
                <div
                  onClick={() => toggleRegion(regionName)}
                  className="flex items-center justify-between p-2 rounded bg-slate-900 hover:bg-slate-850 cursor-pointer text-slate-200 font-bold border border-slate-800/80"
                >
                  <div className="flex items-center space-x-2">
                    {isExpanded ? (
                      <ChevronDown className="w-4 h-4 text-slate-400" />
                    ) : (
                      <ChevronRight className="w-4 h-4 text-slate-400" />
                    )}
                    <span>{regionName}区域电网</span>
                  </div>
                  <span className="text-[10px] text-slate-400 font-normal">
                    {regSubs.length + regGens.length} assets
                  </span>
                </div>

                {/* Expanded Asset Children */}
                {isExpanded && (
                  <div className="pl-4 space-y-1 border-l border-slate-800 my-1">
                    {/* Substations */}
                    {regSubs.map((sub) => {
                      const isSelected = selectedObjectId === sub.id;
                      return (
                        <div
                          key={sub.id}
                          onClick={() => onSelectObject(sub.id)}
                          className={`p-1.5 rounded flex items-center justify-between cursor-pointer text-[11px] transition-all ${
                            isSelected
                              ? 'bg-cyan-950 text-cyan-300 font-bold border border-cyan-800'
                              : 'text-slate-300 hover:bg-slate-900'
                          }`}
                        >
                          <div className="flex items-center space-x-1.5 truncate">
                            <Zap className="w-3 h-3 text-cyan-400 shrink-0" />
                            <span className="truncate">{sub.name}</span>
                          </div>
                          <span className="text-[9px] px-1 py-0.2 rounded bg-slate-800 text-slate-400 font-mono shrink-0">
                            {sub.voltageLevel}
                          </span>
                        </div>
                      );
                    })}

                    {/* Generators */}
                    {regGens.map((gen) => {
                      const isSelected = selectedObjectId === gen.id;
                      return (
                        <div
                          key={gen.id}
                          onClick={() => onSelectObject(gen.id)}
                          className={`p-1.5 rounded flex items-center justify-between cursor-pointer text-[11px] transition-all ${
                            isSelected
                              ? 'bg-amber-950 text-amber-300 font-bold border border-amber-800'
                              : 'text-slate-300 hover:bg-slate-900'
                          }`}
                        >
                          <div className="flex items-center space-x-1.5 truncate">
                            {gen.type === 'WindFarm' && <Wind className="w-3 h-3 text-emerald-400 shrink-0" />}
                            {gen.type === 'SolarFarm' && <Sun className="w-3 h-3 text-amber-400 shrink-0" />}
                            {gen.type === 'BatteryEnergyStorage' && <Battery className="w-3 h-3 text-fuchsia-400 shrink-0" />}
                            {gen.type === 'HydroPlant' && <Radio className="w-3 h-3 text-cyan-400 shrink-0" />}
                            <span className="truncate">{gen.name}</span>
                          </div>
                        </div>
                      );
                    })}

                    {/* Lines */}
                    {regLines.map((line) => {
                      const isSelected = selectedObjectId === line.id;
                      return (
                        <div
                          key={line.id}
                          onClick={() => onSelectObject(line.id)}
                          className={`p-1.5 rounded flex items-center justify-between cursor-pointer text-[11px] transition-all ${
                            isSelected
                              ? 'bg-emerald-950 text-emerald-300 font-bold border border-emerald-800'
                              : 'text-slate-400 hover:bg-slate-900'
                          }`}
                        >
                          <span className="truncate">{line.name}</span>
                          <span className="text-[9px] text-slate-500 font-mono">{line.voltageLevel}</span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Tab 2: Alarm Center */}
      {activeTab === 'alarms' && (
        <div className="flex-1 overflow-y-auto p-3 space-y-3">
          <div className="flex items-center justify-between text-xs font-bold text-slate-300 pb-2 border-b border-slate-800">
            <span>故障与越限告警列表 (ALARMS)</span>
            <span className="text-amber-400 font-mono">{alarms.length} TOTAL</span>
          </div>

          {alarms.map((alm) => {
            const isCritical = alm.severity === 'critical' || alm.severity === 'major';
            return (
              <div
                key={alm.id}
                className={`p-3 rounded border space-y-2 transition-all ${
                  isCritical
                    ? 'bg-rose-950/40 border-rose-800/90'
                    : 'bg-slate-900 border-slate-800'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span
                    className={`px-1.5 py-0.5 rounded text-[10px] font-bold uppercase ${
                      isCritical ? 'bg-rose-900 text-rose-300' : 'bg-amber-950 text-amber-400'
                    }`}
                  >
                    {alm.severity}
                  </span>
                  <span className="text-[10px] text-slate-500 font-mono">{alm.timestamp}</span>
                </div>

                <div className="font-bold text-slate-200 text-xs">{alm.title}</div>
                <div className="text-[11px] text-slate-400 leading-relaxed">{alm.description}</div>

                <div className="bg-slate-950 p-2 rounded border border-slate-850 text-[10px] text-amber-300">
                  💡 {alm.recommendedAction}
                </div>

                <div className="flex items-center justify-between pt-1">
                  <span className="text-[10px] text-slate-400">{alm.assetName}</span>
                  {!alm.acknowledged ? (
                    <button
                      onClick={() => onAcknowledgeAlarm(alm.id)}
                      className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-600 rounded text-[10px] transition-colors"
                    >
                      确认告警 (ACK)
                    </button>
                  ) : (
                    <span className="text-[10px] text-emerald-400 flex items-center space-x-1">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>已确认 ({alm.acknowledgedBy})</span>
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Tab 3: Quick Scenarios */}
      {activeTab === 'scenarios' && (
        <div className="flex-1 overflow-y-auto p-3 space-y-3">
          <div className="text-xs font-bold text-slate-300 pb-2 border-b border-slate-800">
            预设电网推演场景 (PRESET SCENARIOS)
          </div>

          <button
            onClick={() => onTriggerScenario('line_outage')}
            className="w-full text-left p-3 rounded bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 space-y-1.5 transition-all"
          >
            <div className="flex items-center justify-between font-bold text-rose-400">
              <span>昌吉-古泉 ±1100kV 直流线路 N-1 故障</span>
              <AlertTriangle className="w-4 h-4" />
            </div>
            <p className="text-[11px] text-slate-400">
              Simulate 12,000MW UHVDC transmission line tripping; observe frequency drop & flow redistribution.
            </p>
          </button>

          <button
            onClick={() => onTriggerScenario('weather_typhoon')}
            className="w-full text-left p-3 rounded bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 space-y-1.5 transition-all"
          >
            <div className="flex items-center justify-between font-bold text-amber-400">
              <span>超强台风“海燕”袭击华东/上海网架</span>
              <Flame className="w-4 h-4" />
            </div>
            <p className="text-[11px] text-slate-400">
              Moving storm vector across Shanghai & Anhui transmission corridors; automatic tower risk scoring.
            </p>
          </button>

          <button
            onClick={() => onTriggerScenario('datacenter_surge')}
            className="w-full text-left p-3 rounded bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 space-y-1.5 transition-all"
          >
            <div className="flex items-center justify-between font-bold text-cyan-400">
              <span>华北/北京 2000MW 大型数据中心集中加载</span>
              <Zap className="w-4 h-4" />
            </div>
            <p className="text-[11px] text-slate-400">
              Simulate rapid IT cooling & UPS load spike; test 500kV transformer thermal stress tolerance.
            </p>
          </button>

          <button
            onClick={() => onTriggerScenario('renewable_surge')}
            className="w-full text-left p-3 rounded bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 space-y-1.5 transition-all"
          >
            <div className="flex items-center justify-between font-bold text-emerald-400">
              <span>西北/宁夏 +10GW 大风电/大光伏高出力冲顶</span>
              <Sun className="w-4 h-4" />
            </div>
            <p className="text-[11px] text-slate-400">
              High renewable penetration scenario; calculate curtailment rate and BESS storage absorption capacity.
            </p>
          </button>
        </div>
      )}
    </aside>
  );
};
