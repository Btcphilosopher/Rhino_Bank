'use client';

import React from 'react';
import { SubstationObject, TransmissionLineObject, DigitalGridObject } from '@/lib/grid/types';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
} from 'recharts';
import {
  Activity,
  Cpu,
  ShieldAlert,
  Thermometer,
  Wrench,
  CheckCircle2,
  AlertTriangle,
  Radio,
  Clock,
  Zap,
} from 'lucide-react';

interface RightInspectorProps {
  selectedObject: SubstationObject | TransmissionLineObject | DigitalGridObject | null;
  onRunNMinus1: (id: string) => void;
  onToggleOutage: (id: string) => void;
  onOpenInspection: (id: string) => void;
  isOutage: boolean;
}

export const RightInspector: React.FC<RightInspectorProps> = ({
  selectedObject,
  onRunNMinus1,
  onToggleOutage,
  onOpenInspection,
  isOutage,
}) => {
  if (!selectedObject) {
    return (
      <aside className="w-96 h-full bg-slate-950 border-l border-slate-800 p-6 flex flex-col items-center justify-center font-mono text-xs text-slate-400 z-20">
        <Activity className="w-10 h-10 text-slate-700 animate-pulse mb-3" />
        <p className="text-center">请在地图、三维全景或单线图中选择变电站、线路或发电设备以查看双向数字孪生遥测。</p>
        <p className="text-[11px] text-slate-600 mt-2 text-center">Select any digital grid object to inspect live SCADA telemetry.</p>
      </aside>
    );
  }

  // Generate simulated 24h historical telemetry data for charts
  const historyData = Array.from({ length: 12 }, (_, i) => {
    const hour = `${(8 + i).toString().padStart(2, '0')}:00`;
    const baseP = selectedObject.telemetry.activePowerMW || 2000;
    const loadPct = selectedObject.telemetry.loadingPercent || 50;
    return {
      time: hour,
      powerMW: Math.round(baseP * (0.8 + Math.sin(i / 2) * 0.25)),
      loadingPct: Math.round(loadPct * (0.85 + Math.sin(i / 3) * 0.2)),
      voltagekV: parseFloat((selectedObject.telemetry.voltagekV + Math.sin(i * 1.5) * 2).toFixed(1)),
    };
  });

  return (
    <aside className="w-96 h-full bg-slate-950 border-l border-slate-800 flex flex-col font-mono text-xs text-slate-200 overflow-y-auto z-20 select-none">
      {/* Object Title & Status Header */}
      <div className="p-4 bg-slate-900 border-b border-slate-800 space-y-2">
        <div className="flex items-center justify-between">
          <span className="px-2 py-0.5 rounded text-[10px] bg-cyan-950 text-cyan-400 border border-cyan-800 font-bold">
            {selectedObject.voltageLevel} {selectedObject.type}
          </span>
          <span
            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
              isOutage
                ? 'bg-rose-950 text-rose-300 border border-rose-800'
                : selectedObject.status === 'normal'
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                : 'bg-amber-950 text-amber-300 border border-amber-800'
            }`}
          >
            {isOutage ? 'OUTAGE (已停运)' : 'OPERATIONAL (正常)'}
          </span>
        </div>

        <h3 className="text-sm font-bold text-slate-100 tracking-wide">{selectedObject.name}</h3>
        <p className="text-[11px] text-slate-400">
          ID: {selectedObject.id} | 所属: {selectedObject.owner}
        </p>
      </div>

      {/* Main SCADA Telemetry Dashboard */}
      <div className="p-4 space-y-4 border-b border-slate-800">
        <div className="flex items-center justify-between text-slate-300 font-bold">
          <span>实时遥测参数 (SCADA Telemetry)</span>
          <span className="text-[10px] text-emerald-400 flex items-center space-x-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
            <span>LIVE 1s</span>
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
            <div className="text-slate-400 text-[10px]">母线电压 (Voltage)</div>
            <div className="text-sm font-bold text-cyan-400 mt-1">
              {isOutage ? 0 : selectedObject.telemetry.voltagekV} kV
            </div>
            <div className="text-[9px] text-slate-500">Nominal V = 1.00 p.u.</div>
          </div>

          <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
            <div className="text-slate-400 text-[10px]">有功功率 (Active Power)</div>
            <div className="text-sm font-bold text-emerald-400 mt-1">
              {isOutage ? 0 : selectedObject.telemetry.activePowerMW} MW
            </div>
            <div className="text-[9px] text-slate-500">Q = {selectedObject.telemetry.reactivePowerMvar} Mvar</div>
          </div>

          <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
            <div className="text-slate-400 text-[10px]">设备负载率 (Loading)</div>
            <div className="text-sm font-bold text-amber-400 mt-1">
              {isOutage ? 0 : selectedObject.telemetry.loadingPercent}%
            </div>
            <div className="text-[9px] text-slate-500">Thermal Rating Limit</div>
          </div>

          <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
            <div className="text-slate-400 text-[10px]">系统频率 (Frequency)</div>
            <div className="text-sm font-bold text-slate-200 mt-1">
              {selectedObject.telemetry.frequencyHz} Hz
            </div>
            <div className="text-[9px] text-slate-500">Target 50.00 Hz</div>
          </div>
        </div>

        {/* Telemetry Chart: Active Power & Loading 12h Trend */}
        <div className="bg-slate-900 p-3 rounded border border-slate-800 space-y-2">
          <div className="text-[11px] text-slate-300 font-semibold">12小时有功功率与负载率趋势</div>
          <div className="h-32 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={historyData}>
                <defs>
                  <linearGradient id="colorPower" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#06b6d4" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="time" stroke="#475569" fontSize={9} />
                <YAxis stroke="#475569" fontSize={9} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '11px' }}
                />
                <Area type="monotone" dataKey="powerMW" stroke="#06b6d4" fillOpacity={1} fill="url(#colorPower)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Asset Diagnostics & Health Index */}
      <div className="p-4 space-y-3 border-b border-slate-800">
        <div className="text-slate-300 font-bold flex items-center justify-between">
          <span>设备健康度与诊断 (AI Health)</span>
          <span className="text-emerald-400 font-bold">{selectedObject.healthIndex}/100</span>
        </div>

        <div className="bg-slate-900 p-3 rounded border border-slate-800 space-y-2">
          <div className="flex justify-between text-[11px]">
            <span className="text-slate-400">热应力得分 (Thermal Stress):</span>
            <span className="text-amber-400 font-bold">{selectedObject.thermalStressScore}/100</span>
          </div>
          <div className="flex justify-between text-[11px]">
            <span className="text-slate-400">年预计故障率 (Failure Rate):</span>
            <span className="text-slate-200">{(selectedObject.failureRatePerYear * 100).toFixed(1)}% / yr</span>
          </div>
          <div className="flex justify-between text-[11px]">
            <span className="text-slate-400">上次定检日期 (Last Test):</span>
            <span className="text-slate-300">{selectedObject.lastMaintenanceDate}</span>
          </div>
        </div>
      </div>

      {/* Dispatcher Actions */}
      <div className="p-4 space-y-2">
        <div className="text-slate-300 font-bold mb-2">调度与仿真控制 (Dispatch Actions)</div>

        <button
          onClick={() => onRunNMinus1(selectedObject.id)}
          className="w-full py-2 bg-slate-900 hover:bg-slate-850 border border-slate-700 hover:border-cyan-500 rounded text-cyan-300 font-bold transition-all flex items-center justify-center space-x-1.5"
        >
          <ShieldAlert className="w-4 h-4 text-cyan-400" />
          <span>运行 N-1 安全校正计算</span>
        </button>

        <button
          onClick={() => onToggleOutage(selectedObject.id)}
          className={`w-full py-2 rounded font-bold border transition-all flex items-center justify-center space-x-1.5 ${
            isOutage
              ? 'bg-emerald-950 hover:bg-emerald-900 border-emerald-700 text-emerald-300'
              : 'bg-rose-950 hover:bg-rose-900 border-rose-800 text-rose-300'
          }`}
        >
          <AlertTriangle className="w-4 h-4" />
          <span>{isOutage ? '恢复设备投入运行 (Re-close)' : '模拟设备断开/停运 (Open Circuit)'}</span>
        </button>

        <button
          onClick={() => onOpenInspection(selectedObject.id)}
          className="w-full py-2 bg-slate-900 hover:bg-slate-850 border border-slate-700 text-slate-200 font-bold rounded transition-all flex items-center justify-center space-x-1.5"
        >
          <Wrench className="w-4 h-4 text-emerald-400" />
          <span>调阅无人机 AI 巡检画像</span>
        </button>
      </div>
    </aside>
  );
};
