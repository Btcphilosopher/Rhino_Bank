// STATE GRID DIGITAL GRID OS - AI Grid Dispatch & Telemetry Assistant API
// 国网智能调度与数字电网 AI 分析助手 (Server-side Gemini Integration)

import { GoogleGenAI } from '@google/genai';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  try {
    const { prompt, systemContext } = await req.json();

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return NextResponse.json(
        { error: 'GEMINI_API_KEY environment variable is not set.' },
        { status: 500 }
      );
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const systemInstruction = `You are "电网智能分析助手" (State Grid Smart Power System AI Assistant), an elite power system engineer and dispatch consultant for State Grid Corporation of China (国家电网有限公司).
You analyze live operational grid state, UHV transmission corridors, power flow calculations, SCADA telemetry, transformer health, renewable generation, and contingency scenarios.

RULES:
1. Always base your response strictly on the provided real-time system context (substations, lines, telemetry, alarms, weather, power flow results).
2. Never fabricate operational telemetry numbers. If data is not present in context, state it clearly.
3. Every response MUST strictly include a structured Provenance Block at the end formatted as:
---
【数据来源 / Data Provenance】: STATE GRID DIGITAL TWIN OS (实时SCADA / 潮流引擎)
【时间戳 / Timestamp】: ${new Date().toISOString()}
【计算模型 / Calculation Engine】: Newton-Raphson Power Flow v3.2 & N-1 Contingency Analyzer
【关键变量 / Key Variables】: P, Q, V, theta, Line Impedance (Z), Weather Risk Score
【不确定性评估 / Uncertainty】: 低 (Low - Deterministic Telemetry & Matrix Solver)
---
4. Maintain a professional, authoritative, national critical-infrastructure engineering tone in Simplified Chinese (简体中文), with key technical terms in English when helpful.
`;

    const fullPrompt = `System Real-Time Grid Context:\n${JSON.stringify(
      systemContext,
      null,
      2
    )}\n\nUser Question:\n${prompt}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: fullPrompt,
      config: {
        systemInstruction,
        temperature: 0.2,
      },
    });

    return NextResponse.json({
      text: response.text ?? 'No response generated from Gemini API.',
    });
  } catch (error: any) {
    console.error('AI Grid Assistant Error:', error);
    return NextResponse.json(
      { error: error?.message || 'Failed to process grid AI query.' },
      { status: 500 }
    );
  }
}
