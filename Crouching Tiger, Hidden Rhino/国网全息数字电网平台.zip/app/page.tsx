'use client';

import React, { useState, useEffect, useMemo } from 'react';
import { INITIAL_SUBSTATIONS, INITIAL_TRANSMISSION_LINES, INITIAL_GENERATORS, INITIAL_ALARMS, INITIAL_WEATHER_SCENARIOS } from '@/lib/grid/data';
import { SubstationObject, TransmissionLineObject, DigitalGridObject, AlarmItem, PowerFlowResult } from '@/lib/grid/types';
import { runNewtonRaphsonPowerFlow } from '@/lib/grid/power-flow-solver';
import { globalTelemetryEngine } from '@/lib/grid/telemetry-engine';

import { HeaderNav, ViewMode } from '@/components/grid/HeaderNav';
import { LeftSidebar } from '@/components/grid/LeftSidebar';
import { RightInspector } from '@/components/grid/RightInspector';
import { BottomTimeline } from '@/components/grid/BottomTimeline';

import { National3DMap } from '@/components/grid/National3DMap';
import { SubstationBIM3D } from '@/components/grid/SubstationBIM3D';
import { SingleLineDiagram } from '@/components/grid/SingleLineDiagram';
import { AIAssistantDrawer } from '@/components/grid/AIAssistantDrawer';
import { ScenarioLabModal } from '@/components/grid/ScenarioLabModal';
import { CascadingFailureLab } from '@/components/grid/CascadingFailureLab';
import { AIInspectionView } from '@/components/grid/AIInspectionView';
import { WeatherRiskView } from '@/components/grid/WeatherRiskView';

export default function StateGridDigitalGridOSPage() {
  const [currentView, setCurrentView] = useState<ViewMode>('3d_map');
  const [substations, setSubstations] = useState<SubstationObject[]>(INITIAL_SUBSTATIONS);
  const [lines, setLines] = useState<TransmissionLineObject[]>(INITIAL_TRANSMISSION_LINES);
  const [generators, setGenerators] = useState<DigitalGridObject[]>(INITIAL_GENERATORS);
  const [alarms, setAlarms] = useState<AlarmItem[]>(INITIAL_ALARMS);
  const [selectedObjectId, setSelectedObjectId] = useState<string | null>('sub_shanghai');

  const [disabledLineIds, setDisabledLineIds] = useState<string[]>([]);

  // Compute power flow dynamically whenever topology or outages change
  const powerFlow = useMemo(
    () =>
      runNewtonRaphsonPowerFlow(substations, lines, generators, {
        outageLineIds: disabledLineIds,
      }),
    [substations, lines, generators, disabledLineIds]
  );

  // Modals & Drawers
  const [isAIAssistantOpen, setIsAIAssistantOpen] = useState(false);
  const [isScenarioLabOpen, setIsScenarioLabOpen] = useState(false);
  const [isCascadingLabOpen, setIsCascadingLabOpen] = useState(false);

  // Subscribe to real-time SCADA telemetry engine
  useEffect(() => {
    globalTelemetryEngine.start(2500);

    const unsubscribe = globalTelemetryEngine.subscribe((updatedMap) => {
      setSubstations((prev) =>
        prev.map((sub) => {
          const telemetryUpdate = updatedMap.get(sub.id);
          if (!telemetryUpdate) return sub;
          return {
            ...sub,
            telemetry: { ...sub.telemetry, ...telemetryUpdate },
          };
        })
      );

      setGenerators((prev) =>
        prev.map((gen) => {
          const telemetryUpdate = updatedMap.get(gen.id);
          if (!telemetryUpdate) return gen;
          return {
            ...gen,
            telemetry: { ...gen.telemetry, ...telemetryUpdate },
          };
        })
      );
    });

    return () => {
      unsubscribe();
      globalTelemetryEngine.stop();
    };
  }, []);

  // Object Selection Handler
  const handleSelectObject = (id: string) => {
    setSelectedObjectId(id);
  };

  const handleAcknowledgeAlarm = (alarmId: string) => {
    setAlarms((prev) =>
      prev.map((a) => (a.id === alarmId ? { ...a, acknowledged: true, acknowledgedBy: 'Dispatcher DISP-01' } : a))
    );
  };

  const handleToggleOutage = (id: string) => {
    if (disabledLineIds.includes(id)) {
      setDisabledLineIds((prev) => prev.filter((i) => i !== id));
    } else {
      setDisabledLineIds((prev) => [...prev, id]);
    }
  };

  const handleTriggerScenario = (scenarioKey: string) => {
    if (scenarioKey === 'line_outage') {
      setDisabledLineIds(['line_changji_guzhou']);
      setCurrentView('sld_diagram');
    } else if (scenarioKey === 'weather_typhoon') {
      setCurrentView('weather_risk');
    } else if (scenarioKey === 'datacenter_surge') {
      setIsScenarioLabOpen(true);
    } else if (scenarioKey === 'renewable_surge') {
      setIsScenarioLabOpen(true);
    }
  };

  // Selected Object Resolver
  const selectedObject =
    substations.find((s) => s.id === selectedObjectId) ||
    lines.find((l) => l.id === selectedObjectId) ||
    generators.find((g) => g.id === selectedObjectId) ||
    null;

  const selectedSubstation = substations.find((s) => s.id === selectedObjectId) || substations[1];

  // All towers list gathered from lines
  const allTowers = lines.flatMap((l) => l.towers);

  return (
    <div className="w-screen h-screen bg-slate-950 flex flex-col font-mono text-slate-100 overflow-hidden select-none">
      {/* Top Main Navigation & Status Header */}
      <HeaderNav
        currentView={currentView}
        onViewChange={setCurrentView}
        powerFlow={powerFlow}
        onOpenAIAssistant={() => setIsAIAssistantOpen(true)}
        onOpenScenarioLab={() => setIsScenarioLabOpen(true)}
        onOpenCascadingLab={() => setIsCascadingLabOpen(true)}
        alarmCount={alarms.filter((a) => !a.acknowledged).length}
      />

      {/* Main Workspace Area (Left Navigation Sidebar + Active View Workspace + Right Inspector) */}
      <div className="flex-1 flex flex-row overflow-hidden relative">
        {/* Left Hierarchy Tree & Alarm Panel */}
        <LeftSidebar
          substations={substations}
          lines={lines}
          generators={generators}
          alarms={alarms}
          selectedObjectId={selectedObjectId}
          onSelectObject={handleSelectObject}
          onAcknowledgeAlarm={handleAcknowledgeAlarm}
          onTriggerScenario={handleTriggerScenario}
        />

        {/* Center Workspace Content Area */}
        <main className="flex-1 h-full relative overflow-hidden bg-slate-950">
          {currentView === '3d_map' && (
            <National3DMap
              substations={substations}
              lines={lines}
              generators={generators}
              selectedObjectId={selectedObjectId}
              onSelectObject={handleSelectObject}
              activeWeather={INITIAL_WEATHER_SCENARIOS[0]}
              overloadedLineIds={powerFlow.overloadedLines}
              disabledLineIds={disabledLineIds}
            />
          )}

          {currentView === 'substation_bim' && <SubstationBIM3D substation={selectedSubstation} />}

          {currentView === 'sld_diagram' && (
            <SingleLineDiagram
              substations={substations}
              lines={lines}
              generators={generators}
              selectedObjectId={selectedObjectId}
              onSelectObject={handleSelectObject}
              disabledLineIds={disabledLineIds}
            />
          )}

          {currentView === 'telemetry_powerflow' && (
            <SingleLineDiagram
              substations={substations}
              lines={lines}
              generators={generators}
              selectedObjectId={selectedObjectId}
              onSelectObject={handleSelectObject}
              disabledLineIds={disabledLineIds}
            />
          )}

          {currentView === 'ai_inspection' && <AIInspectionView towers={allTowers} />}

          {currentView === 'weather_risk' && (
            <WeatherRiskView weather={INITIAL_WEATHER_SCENARIOS[0]} lines={lines} />
          )}
        </main>

        {/* Right Inspector Sidebar Panel */}
        <RightInspector
          selectedObject={selectedObject}
          onRunNMinus1={(id) => setIsCascadingLabOpen(true)}
          onToggleOutage={handleToggleOutage}
          onOpenInspection={(id) => setCurrentView('ai_inspection')}
          isOutage={disabledLineIds.includes(selectedObjectId || '')}
        />
      </div>

      {/* Bottom Timeline & Central Power Balance Equation Bar */}
      <BottomTimeline
        powerFlow={powerFlow}
        onTimeChange={(hour, min) => {
          globalTelemetryEngine.setTimeOffset((hour - 8) * 60 + min);
        }}
      />

      {/* AI Assistant Drawer */}
      <AIAssistantDrawer
        isOpen={isAIAssistantOpen}
        onClose={() => setIsAIAssistantOpen(false)}
        systemContext={{
          powerFlow,
          substationsCount: substations.length,
          linesCount: lines.length,
          alarms,
        }}
      />

      {/* Scenario Lab Modal */}
      <ScenarioLabModal
        isOpen={isScenarioLabOpen}
        onClose={() => setIsScenarioLabOpen(false)}
        substations={substations}
        lines={lines}
        generators={generators}
        basePowerFlow={powerFlow}
      />

      {/* Cascading Failure Lab Modal */}
      <CascadingFailureLab
        isOpen={isCascadingLabOpen}
        onClose={() => setIsCascadingLabOpen(false)}
        substations={substations}
        lines={lines}
        generators={generators}
        onApplyCascadingOutages={(trippedIds) => setDisabledLineIds(trippedIds)}
      />
    </div>
  );
}
