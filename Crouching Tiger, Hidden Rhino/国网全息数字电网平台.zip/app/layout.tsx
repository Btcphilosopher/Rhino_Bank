import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: '国网全息数字电网平台 | STATE GRID DIGITAL GRID OS',
  description: '国家电网新型电力系统三维数字孪生与智能调度平台 (National-scale 3D Power Grid Digital Twin, SCADA Telemetry, Electrical Topology & Power Flow Engine)',
  openGraph: {
    title: '国网全息数字电网平台 | STATE GRID DIGITAL GRID OS',
    description: '国家电网新型电力系统三维数字孪生与智能调度平台 (National-scale 3D Power Grid Digital Twin, SCADA Telemetry, Electrical Topology & Power Flow Engine)',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: '国网全息数字电网平台 | STATE GRID DIGITAL GRID OS',
    description: '国家电网新型电力系统三维数字孪生与智能调度平台',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
