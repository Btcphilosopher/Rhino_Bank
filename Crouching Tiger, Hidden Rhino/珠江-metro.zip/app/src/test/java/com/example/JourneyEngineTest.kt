package com.example

import com.example.engine.JourneyEngine
import com.example.model.RoutePreference
import org.junit.Assert.*
import org.junit.Test

class JourneyEngineTest {

    @Test
    fun testPlanJourneysFromGuangzhouToHongKong() {
        val plans = JourneyEngine.planJourneys("广州南站", "香港西九龙站", RoutePreference.FASTEST)

        assertNotNull(plans)
        assertTrue(plans.isNotEmpty())

        val fastest = plans.first { it.tag == "最快" }
        assertEquals("广州南站", fastest.originStationName)
        assertEquals("香港西九龙站", fastest.destinationStationName)
        assertTrue(fastest.isCrossBorder)
        assertTrue(fastest.legs.isNotEmpty())
        assertTrue(fastest.totalFareCNY > 0)
    }

    @Test
    fun testSimulatedDelayTriggersReplanning() {
        val delayMinutes = 8
        val plans = JourneyEngine.planJourneys("广州南站", "香港西九龙站", RoutePreference.FASTEST, delayMinutes)

        val delayedPlan = plans.first { it.tag == "最快" }
        assertEquals(delayMinutes, delayedPlan.delayMinutes)
        assertTrue(delayedPlan.isReplanned)
    }
}
