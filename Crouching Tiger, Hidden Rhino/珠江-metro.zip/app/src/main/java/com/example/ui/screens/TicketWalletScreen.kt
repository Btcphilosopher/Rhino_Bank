package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.TicketStatus
import com.example.ui.components.MetroHeaderBar
import com.example.ui.components.QrTicketCard
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.TransportBlue
import com.example.viewmodel.MainViewModel

@Composable
fun TicketWalletScreen(
    viewModel: MainViewModel,
    onNavigateToSearch: () -> Unit
) {
    val tickets by viewModel.tickets.collectAsState()
    var selectedTab by remember { mutableStateOf(0) } // 0: 待出行, 1: 历史订单

    val filteredTickets = when (selectedTab) {
        0 -> tickets.filter { it.status == TicketStatus.UPCOMING || it.status == TicketStatus.ACTIVE }
        else -> tickets.filter { it.status == TicketStatus.COMPLETED || it.status == TicketStatus.CANCELLED }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
    ) {
        MetroHeaderBar(subtitleText = "电子车票与乘车码钱包")

        // Wallet Tabs
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color.White,
            contentColor = TransportBlue
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("待出行 (${tickets.count { it.status == TicketStatus.UPCOMING || it.status == TicketStatus.ACTIVE }})", fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("历史订单", fontWeight = FontWeight.Bold) }
            )
        }

        if (filteredTickets.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.ConfirmationNumber,
                    contentDescription = null,
                    tint = Color(0xFF94A3B8),
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text("暂无此类车票", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = NavyDeep)
                Spacer(modifier = Modifier.height(8.dp))
                Text("你可以搜索路线并购买体验演示电子票", fontSize = 13.sp, color = Color(0xFF64748B))
                Spacer(modifier = Modifier.height(20.dp))
                Button(
                    onClick = onNavigateToSearch,
                    colors = ButtonDefaults.buttonColors(containerColor = TransportBlue),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("前往路线搜索")
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp)
            ) {
                item {
                    Surface(
                        color = Color(0xFFEFF6FF),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFF2563EB), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "提示：演示模式已严格标识【SIMULATED TICKET】。闸机过闸时请出示 QR 二维码",
                                fontSize = 11.sp,
                                color = Color(0xFF1E40AF)
                            )
                        }
                    }
                }

                items(filteredTickets) { ticket ->
                    QrTicketCard(
                        ticket = ticket,
                        onStatusAction = {
                            viewModel.updateTicketStatus(ticket.id, TicketStatus.COMPLETED)
                        }
                    )
                }
            }
        }
    }
}
