package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.JourneyPlan
import com.example.model.Ticket
import com.example.ui.components.MetroHeaderBar
import com.example.ui.components.QrTicketCard
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.TransportBlue
import com.example.viewmodel.AppNavTab
import com.example.viewmodel.MainViewModel

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onNavigateToRoute: () -> Unit,
    onNavigateToTimeline: () -> Unit,
    onNavigateToTicketWallet: () -> Unit
) {
    val originQuery by viewModel.originQuery.collectAsState()
    val destinationQuery by viewModel.destinationQuery.collectAsState()
    val routePlans by viewModel.routePlans.collectAsState()
    val tickets by viewModel.tickets.collectAsState()
    val alerts = viewModel.serviceAlerts

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
    ) {
        MetroHeaderBar(subtitleText = "大湾区 11 城统一出行 OS")

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            // Search Card Block (Section II & III)
            item {
                Spacer(modifier = Modifier.height(12.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("home_search_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "你要去哪里？",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyDeep
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Origin Box
                        OutlinedTextField(
                            value = originQuery,
                            onValueChange = { viewModel.setOrigin(it) },
                            label = { Text("从哪里出发 (默认: 当前位置)", fontSize = 12.sp) },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.MyLocation,
                                    contentDescription = null,
                                    tint = Color(0xFF059669)
                                )
                            },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("origin_input_field")
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Destination Box
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = destinationQuery,
                                onValueChange = { viewModel.setDestination(it) },
                                label = { Text("目的地 (如: 香港西九龙站 / 深圳北站)", fontSize = 12.sp) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Place,
                                        contentDescription = null,
                                        tint = Color(0xFFDC2626)
                                    )
                                },
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("destination_input_field")
                            )

                            Spacer(modifier = Modifier.width(8.dp))

                            IconButton(
                                onClick = { viewModel.swapOriginAndDestination() },
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFF1F5F9))
                                    .testTag("swap_stations_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.SwapVert,
                                    contentDescription = "互换",
                                    tint = NavyDeep
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                viewModel.searchJourneys()
                                onNavigateToRoute()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = TransportBlue),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("search_route_button")
                        ) {
                            Icon(Icons.Default.Directions, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("搜索全网路线 (包含高铁/地铁/城际)", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Quick Actions (Section III)
            item {
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "快捷出行",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyDeep
                )
                Spacer(modifier = Modifier.height(8.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val quickPills = listOf(
                        Triple("回家", "广州珠江新城", Icons.Default.Home),
                        Triple("去公司", "深圳福田 CBD", Icons.Default.Work),
                        Triple("香港西九龙", "香港西九龙站", Icons.Default.Train),
                        Triple("白云机场", "白云机场T2", Icons.Default.FlightTakeoff),
                        Triple("深圳北站", "深圳北站", Icons.Default.Subway),
                        Triple("澳门关闸", "澳门关闸", Icons.Default.DirectionsBus)
                    )

                    items(quickPills) { (label, target, icon) ->
                        Surface(
                            color = Color.White,
                            shape = RoundedCornerShape(12.dp),
                            shadowElevation = 1.dp,
                            modifier = Modifier.clickable {
                                viewModel.setDestination(target)
                                onNavigateToRoute()
                            }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(icon, contentDescription = null, tint = TransportBlue, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(label, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = NavyDeep)
                            }
                        }
                    }
                }
            }

            // Recent Journeys (Section III)
            item {
                Spacer(modifier = Modifier.height(20.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "常用与推荐行程",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyDeep
                    )
                    TextButton(onClick = onNavigateToRoute) {
                        Text("查看全部路线", fontSize = 12.sp, color = TransportBlue)
                    }
                }

                routePlans.take(2).forEach { plan ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(14.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable {
                                viewModel.selectJourneyPlan(plan)
                                onNavigateToTimeline()
                            }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(plan.originStationName, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = NavyDeep)
                                    Text(" → ", fontSize = 14.sp, color = Color(0xFF94A3B8))
                                    Text(plan.destinationStationName, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = NavyDeep)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("预计 ${plan.totalDurationMinutes} 分钟", fontSize = 12.sp, color = Color(0xFF64748B))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("换乘 ${plan.transferCount} 次", fontSize = 12.sp, color = Color(0xFF64748B))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("¥${plan.totalFareCNY}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFFDC2626))
                                }
                            }

                            Button(
                                onClick = {
                                    viewModel.selectJourneyPlan(plan)
                                    onNavigateToTimeline()
                                },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier.height(34.dp)
                            ) {
                                Text("看行程", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // Realtime Service Alerts (Section III & XXXI)
            item {
                Spacer(modifier = Modifier.height(20.dp))
                Text(
                    text = "湾区交通实时状态与提醒",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyDeep
                )
                Spacer(modifier = Modifier.height(8.dp))

                alerts.forEach { alert ->
                    Surface(
                        color = Color.White,
                        shape = RoundedCornerShape(12.dp),
                        shadowElevation = 1.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = Color(0xFF0284C7),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(alert.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = NavyDeep)
                                Text(alert.summary, fontSize = 11.sp, color = Color(0xFF64748B))
                            }
                        }
                    }
                }
            }

            // Upcoming Active Tickets Box
            if (tickets.isNotEmpty()) {
                item {
                    Spacer(modifier = Modifier.height(20.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "待出行电子车票",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyDeep
                        )
                        TextButton(onClick = onNavigateToTicketWallet) {
                            Text("我的票夹 (${tickets.size})", fontSize = 12.sp, color = TransportBlue)
                        }
                    }

                    QrTicketCard(ticket = tickets.first())
                }
            }
        }
    }
}
