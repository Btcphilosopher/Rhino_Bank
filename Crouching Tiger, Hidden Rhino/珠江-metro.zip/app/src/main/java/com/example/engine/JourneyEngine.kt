package com.example.engine

import com.example.dataset.GbaTransitDataset
import com.example.model.*

object JourneyEngine {

    fun planJourneys(
        originName: String,
        destinationName: String,
        preference: RoutePreference = RoutePreference.FASTEST,
        simulatedDelayMinutes: Int = 0
    ): List<JourneyPlan> {
        val origin = GbaTransitDataset.STATIONS.find { it.name.contains(originName) || originName.contains(it.name) }
            ?: GbaTransitDataset.STATIONS.first { it.id == "GZ_SOUTH" }
        val dest = GbaTransitDataset.STATIONS.find { it.name.contains(destinationName) || destinationName.contains(it.name) }
            ?: GbaTransitDataset.STATIONS.first { it.id == "HK_WEST_KOWLOON" }

        val plans = mutableListOf<JourneyPlan>()

        // 1. Plan A: "最快" (Fastest - High Speed Rail / Express)
        plans.add(buildFastestPlan(origin, dest, simulatedDelayMinutes))

        // 2. Plan B: "更省钱" (Cheaper - Metro / Intercity)
        plans.add(buildCheapestPlan(origin, dest))

        // 3. Plan C: "少换乘" (Fewest Transfers)
        plans.add(buildFewestTransfersPlan(origin, dest))

        // 4. Plan D: "少步行 / 无障碍" (Less Walking & Step-free)
        plans.add(buildLessWalkingPlan(origin, dest))

        return when (preference) {
            RoutePreference.CHEAPEST -> plans.sortedBy { it.totalFareCNY }
            RoutePreference.FEWEST_TRANSFERS -> plans.sortedBy { it.transferCount }
            RoutePreference.LESS_WALKING -> plans.sortedBy { it.totalWalkingMeters }
            else -> plans.sortedBy { it.totalDurationMinutes + (if (it.isReplanned) 10 else 0) }
        }
    }

    private fun buildFastestPlan(origin: Station, dest: Station, delayMinutes: Int): JourneyPlan {
        val isCrossBorder = origin.city != dest.city && (dest.city == "香港" || origin.city == "香港" || dest.city == "澳门" || origin.city == "澳门")
        val baseDuration = if (origin.id == "GZ_SOUTH" && dest.id == "HK_WEST_KOWLOON") 65 else 85
        val totalDuration = baseDuration + delayMinutes

        val status = if (delayMinutes > 0) RealtimeStatus.DELAYED else RealtimeStatus.NORMAL

        val legs = mutableListOf<JourneyLeg>()

        // Step 1: Walk to Station Entrance
        legs.add(
            JourneyLeg(
                id = "LEG_01",
                legType = LegType.WALK,
                mode = TransitMode.WALK,
                title = "前往车站入口",
                subtitle = "安检与实名制核验区",
                operatorName = "站内步行",
                departureStation = "你的当前位置",
                arrivalStation = origin.name,
                departureTime = "08:02",
                arrivalTime = "08:06",
                durationMinutes = 4,
                instructions = listOf("从 ${origin.exits.firstOrNull()?.exitCode ?: "A"} 出口附近凭身份证/通行证刷闸机进站", "安检通道人流平稳，预计耗时 4 分钟"),
                distanceMeters = 250
            )
        )

        // Step 2: Station Entry & Boarding
        legs.add(
            JourneyLeg(
                id = "LEG_02",
                legType = LegType.BOARDING,
                mode = TransitMode.HIGH_SPEED_RAIL,
                title = "进入候车厅并检票进站",
                subtitle = "检票口 A12-A13",
                operatorName = OperatorType.CHINA_RAILWAY.displayName,
                departureStation = origin.name,
                arrivalStation = origin.name,
                departureTime = "08:06",
                arrivalTime = "08:20",
                durationMinutes = 14,
                platform = "12站台",
                vehicleNumber = "G6501 次 (复兴号智能动车组)",
                instructions = listOf("前往 2F 候车大厅 A12 检票口", "刷二代身份证或回乡证/通行证过闸"),
                isAccessible = true
            )
        )

        // Step 3: High Speed Transit
        legs.add(
            JourneyLeg(
                id = "LEG_03",
                legType = LegType.TRANSIT,
                mode = TransitMode.HIGH_SPEED_RAIL,
                title = "${origin.name} → ${dest.name}",
                subtitle = "广深港高速铁路 (直达/停靠深圳北)",
                operatorName = OperatorType.CHINA_RAILWAY.displayName,
                lineName = "广深港高铁",
                lineColorHex = "#7C3AED",
                departureStation = origin.name,
                arrivalStation = dest.name,
                departureTime = "08:20",
                arrivalTime = if (delayMinutes > 0) "09:33 (延误 ${delayMinutes} 分钟)" else "09:25",
                durationMinutes = 65 + delayMinutes,
                stopsCount = 1,
                intermediateStops = listOf("深圳北站"),
                platform = "12站台",
                vehicleNumber = "G6501 次 (03车 08A)",
                instructions = listOf("列车运行速度 300 km/h", "即将抵达 ${dest.name}"),
                fareAmount = 215.0,
                currency = "CNY"
            )
        )

        // Step 4: Border Control if Cross-border
        if (isCrossBorder) {
            legs.add(
                JourneyLeg(
                    id = "LEG_04",
                    legType = LegType.BORDER_CONTROL,
                    mode = TransitMode.WALK,
                    title = "${dest.name} 一地两检口岸",
                    subtitle = "内地口岸区与香港口岸区通关",
                    operatorName = "出入境边防检查",
                    departureStation = dest.name,
                    arrivalStation = dest.name,
                    departureTime = "09:25",
                    arrivalTime = "09:35",
                    durationMinutes = 10,
                    instructions = listOf(
                        "出站后跟随【香港入境】指示牌前往 B2 层通关大堂",
                        "请准备好有效【港澳通行证/回乡证/护照】及有效签注"
                    ),
                    borderRequirement = "须持有效出港证件及签注"
                )
            )
        }

        // Step 5: Final Station Exit
        legs.add(
            JourneyLeg(
                id = "LEG_05",
                legType = LegType.STATION_EXIT,
                mode = TransitMode.WALK,
                title = "出站抵达目的地",
                subtitle = "${dest.name} M 出口 (圆方/柯士甸)",
                operatorName = "站内步行",
                departureStation = dest.name,
                arrivalStation = "目的地",
                departureTime = "09:35",
                arrivalTime = "09:40",
                durationMinutes = 5,
                instructions = listOf("顺乘电梯上升至地面/商场连廊", "旅程完成"),
                distanceMeters = 200
            )
        )

        return JourneyPlan(
            id = "PLAN_FASTEST_${System.currentTimeMillis()}",
            tag = "最快",
            originStationName = origin.name,
            originCity = origin.city,
            destinationStationName = dest.name,
            destinationCity = dest.city,
            departureTime = "08:02",
            arrivalTime = if (delayMinutes > 0) "09:48 (+${delayMinutes}m)" else "09:40",
            totalDurationMinutes = totalDuration + 18,
            transferCount = 0,
            totalWalkingMeters = 450,
            totalFareCNY = 215.0,
            legs = legs,
            isCrossBorder = isCrossBorder,
            realtimeStatus = status,
            delayMinutes = delayMinutes,
            isReplanned = delayMinutes > 0
        )
    }

    private fun buildCheapestPlan(origin: Station, dest: Station): JourneyPlan {
        val isCrossBorder = origin.city != dest.city && (dest.city == "香港" || origin.city == "香港")

        val legs = listOf(
            JourneyLeg(
                id = "LEG_C01",
                legType = LegType.TRANSIT,
                mode = TransitMode.METRO,
                title = "${origin.name} → 广州东站",
                subtitle = "广州地铁 3 号线 (北延段)",
                operatorName = OperatorType.GZ_METRO.displayName,
                lineName = "广州地铁3号线",
                lineColorHex = "#EAB308",
                departureStation = origin.name,
                arrivalStation = "广州东站",
                departureTime = "08:00",
                arrivalTime = "08:35",
                durationMinutes = 35,
                stopsCount = 9,
                fareAmount = 7.0
            ),
            JourneyLeg(
                id = "LEG_C02",
                legType = LegType.TRANSIT,
                mode = TransitMode.INTERCITY_RAIL,
                title = "广州东站 → 深圳罗湖",
                subtitle = "广深城际 C7003 次 (随到随走)",
                operatorName = OperatorType.GBA_INTERCITY.displayName,
                lineName = "广深城际",
                lineColorHex = "#2563EB",
                departureStation = "广州东站",
                arrivalStation = "深圳罗湖",
                departureTime = "08:45",
                arrivalTime = "10:05",
                durationMinutes = 80,
                stopsCount = 3,
                fareAmount = 79.5
            ),
            JourneyLeg(
                id = "LEG_C03",
                legType = LegType.BORDER_CONTROL,
                mode = TransitMode.WALK,
                title = "罗湖口岸过关",
                subtitle = "深圳罗湖 ⇆ 香港罗湖大楼",
                operatorName = "出入境边防检查",
                departureStation = "深圳罗湖",
                arrivalStation = "香港罗湖站",
                departureTime = "10:05",
                arrivalTime = "10:25",
                durationMinutes = 20,
                instructions = listOf("凭通行证/回乡证自助通道过关", "过关后直接进入港铁罗湖站闸机"),
                borderRequirement = "须持有效出港证件"
            ),
            JourneyLeg(
                id = "LEG_C04",
                legType = LegType.TRANSIT,
                mode = TransitMode.MTR,
                title = "香港罗湖站 → 金钟 / 九龙",
                subtitle = "港铁 MTR 东铁线",
                operatorName = OperatorType.HK_MTR.displayName,
                lineName = "MTR 东铁线",
                lineColorHex = "#00529B",
                departureStation = "香港罗湖站",
                arrivalStation = dest.name,
                departureTime = "10:30",
                arrivalTime = "11:15",
                durationMinutes = 45,
                stopsCount = 12,
                fareAmount = 43.5,
                currency = "HKD"
            )
        )

        return JourneyPlan(
            id = "PLAN_CHEAPEST_${System.currentTimeMillis()}",
            tag = "更省钱",
            originStationName = origin.name,
            originCity = origin.city,
            destinationStationName = dest.name,
            destinationCity = dest.city,
            departureTime = "08:00",
            arrivalTime = "11:15",
            totalDurationMinutes = 195,
            transferCount = 2,
            totalWalkingMeters = 850,
            totalFareCNY = 126.0,
            legs = legs,
            isCrossBorder = isCrossBorder,
            realtimeStatus = RealtimeStatus.NORMAL
        )
    }

    private fun buildFewestTransfersPlan(origin: Station, dest: Station): JourneyPlan {
        val isCrossBorder = origin.city != dest.city && (dest.city == "香港" || origin.city == "香港")

        val legs = listOf(
            JourneyLeg(
                id = "LEG_FT01",
                legType = LegType.TRANSIT,
                mode = TransitMode.HIGH_SPEED_RAIL,
                title = "${origin.name} → 深圳北站",
                subtitle = "广深港高铁 G6201 次",
                operatorName = OperatorType.CHINA_RAILWAY.displayName,
                lineName = "广深港高铁",
                lineColorHex = "#7C3AED",
                departureStation = origin.name,
                arrivalStation = "深圳北站",
                departureTime = "08:15",
                arrivalTime = "08:45",
                durationMinutes = 30,
                fareAmount = 74.5
            ),
            JourneyLeg(
                id = "LEG_FT02",
                legType = LegType.TRANSIT,
                mode = TransitMode.HIGH_SPEED_RAIL,
                title = "深圳北站 → ${dest.name}",
                subtitle = "广深港高铁 G5611 次",
                operatorName = OperatorType.CHINA_RAILWAY.displayName,
                lineName = "广深港高铁",
                lineColorHex = "#7C3AED",
                departureStation = "深圳北站",
                arrivalStation = dest.name,
                departureTime = "09:00",
                arrivalTime = "09:18",
                durationMinutes = 18,
                fareAmount = 75.0
            )
        )

        return JourneyPlan(
            id = "PLAN_FEWEST_${System.currentTimeMillis()}",
            tag = "少换乘",
            originStationName = origin.name,
            originCity = origin.city,
            destinationStationName = dest.name,
            destinationCity = dest.city,
            departureTime = "08:15",
            arrivalTime = "09:25",
            totalDurationMinutes = 70,
            transferCount = 1,
            totalWalkingMeters = 300,
            totalFareCNY = 149.5,
            legs = legs,
            isCrossBorder = isCrossBorder,
            realtimeStatus = RealtimeStatus.NORMAL
        )
    }

    private fun buildLessWalkingPlan(origin: Station, dest: Station): JourneyPlan {
        val isCrossBorder = origin.city != dest.city && (dest.city == "香港" || origin.city == "香港")

        val legs = listOf(
            JourneyLeg(
                id = "LEG_LW01",
                legType = LegType.TRANSIT,
                mode = TransitMode.HIGH_SPEED_RAIL,
                title = "${origin.name} → ${dest.name}",
                subtitle = "直达无障碍专线 (商务座/全程电梯优先)",
                operatorName = OperatorType.CHINA_RAILWAY.displayName,
                lineName = "广深港高铁直通列车",
                lineColorHex = "#0284C7",
                departureStation = origin.name,
                arrivalStation = dest.name,
                departureTime = "08:30",
                arrivalTime = "09:37",
                durationMinutes = 67,
                instructions = listOf("全程使用站内无障碍直梯接驳", "无需阶梯或长距离步行"),
                fareAmount = 215.0,
                isAccessible = true
            )
        )

        return JourneyPlan(
            id = "PLAN_WALK_${System.currentTimeMillis()}",
            tag = "少步行",
            originStationName = origin.name,
            originCity = origin.city,
            destinationStationName = dest.name,
            destinationCity = dest.city,
            departureTime = "08:30",
            arrivalTime = "09:42",
            totalDurationMinutes = 72,
            transferCount = 0,
            totalWalkingMeters = 180,
            totalFareCNY = 215.0,
            legs = legs,
            isCrossBorder = isCrossBorder,
            realtimeStatus = RealtimeStatus.NORMAL
        )
    }
}
