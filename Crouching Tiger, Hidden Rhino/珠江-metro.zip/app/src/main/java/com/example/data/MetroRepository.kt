package com.example.data

import com.example.dataset.GbaTransitDataset
import com.example.engine.JourneyEngine
import com.example.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class MetroRepository(private val db: AppDatabase) {

    fun getCities(): List<City> = GbaTransitDataset.CITIES

    fun getStations(): List<Station> = GbaTransitDataset.STATIONS

    fun searchStations(query: String): List<Station> {
        if (query.isBlank()) return GbaTransitDataset.STATIONS.take(6)
        return GbaTransitDataset.STATIONS.filter {
            it.name.contains(query, ignoreCase = true) ||
                    it.nameEn.contains(query, ignoreCase = true) ||
                    it.city.contains(query, ignoreCase = true) ||
                    it.lines.any { line -> line.contains(query, ignoreCase = true) }
        }
    }

    fun getServiceAlerts(): List<ServiceAlert> = GbaTransitDataset.REALTIME_ALERTS

    fun getLiveVehicles(): List<VehiclePosition> = GbaTransitDataset.LIVE_VEHICLES

    fun planJourneys(
        origin: String,
        destination: String,
        preference: RoutePreference = RoutePreference.FASTEST,
        simulatedDelayMinutes: Int = 0
    ): List<JourneyPlan> {
        return JourneyEngine.planJourneys(origin, destination, preference, simulatedDelayMinutes)
    }

    // Room Flow Streams
    val savedJourneys: Flow<List<SavedJourneyEntity>> = db.savedJourneyDao().getAllSavedJourneys()

    val ticketsFlow: Flow<List<Ticket>> = db.ticketDao().getAllTickets().map { entities ->
        entities.map { entity ->
            Ticket(
                id = entity.id,
                journeyPlanId = entity.journeyPlanId,
                productType = TicketProductType.entries.find { it.label == entity.productTypeLabel }
                    ?: TicketProductType.HIGH_SPEED_RAIL_12306,
                issuerName = entity.issuerName,
                originStation = entity.originStation,
                destinationStation = entity.destinationStation,
                departureTime = entity.departureTime,
                arrivalTime = entity.arrivalTime,
                trainOrVehicleNumber = entity.trainOrVehicleNumber,
                seatOrCarriage = entity.seatOrCarriage,
                passengerName = entity.passengerName,
                price = entity.price,
                currency = entity.currency,
                status = TicketStatus.entries.find { it.displayName == entity.statusName } ?: TicketStatus.UPCOMING,
                qrCodePayload = entity.qrCodePayload,
                validityText = entity.validityText,
                isSimulated = entity.isSimulated
            )
        }
    }

    suspend fun saveJourney(plan: JourneyPlan) {
        val entity = SavedJourneyEntity(
            id = plan.id,
            origin = plan.originStationName,
            destination = plan.destinationStationName,
            departureTime = plan.departureTime,
            durationMinutes = plan.totalDurationMinutes,
            totalFareCNY = plan.totalFareCNY,
            tag = plan.tag,
            isCrossBorder = plan.isCrossBorder
        )
        db.savedJourneyDao().insertJourney(entity)
    }

    suspend fun issueDemoTicket(plan: JourneyPlan): Ticket {
        val ticketId = "TKT_${System.currentTimeMillis()}"
        val productType = if (plan.isCrossBorder) {
            TicketProductType.HIGH_SPEED_RAIL_12306
        } else {
            TicketProductType.METRO_PASS
        }

        val ticket = Ticket(
            id = ticketId,
            journeyPlanId = plan.id,
            productType = productType,
            issuerName = if (plan.isCrossBorder) "中国铁路 12306 / MTR 跨境联程" else "大湾区轨道交通统一票务",
            originStation = plan.originStationName,
            destinationStation = plan.destinationStationName,
            departureTime = plan.departureTime,
            arrivalTime = plan.arrivalTime,
            trainOrVehicleNumber = if (plan.isCrossBorder) "G6501 次" else "大湾区乘车码",
            seatOrCarriage = if (plan.isCrossBorder) "03车 08A号 (二等座)" else "全线自由席",
            price = plan.totalFareCNY,
            currency = "CNY",
            status = TicketStatus.UPCOMING,
            qrCodePayload = "DEMO_QR_GBA_METRO_${ticketId}_${plan.originStationName}_${plan.destinationStationName}",
            validityText = "当日有效 (2026-09-18 23:59 截止)",
            isSimulated = true
        )

        db.ticketDao().insertTicket(
            TicketEntity(
                id = ticket.id,
                journeyPlanId = ticket.journeyPlanId,
                productTypeLabel = ticket.productType.label,
                issuerName = ticket.issuerName,
                originStation = ticket.originStation,
                destinationStation = ticket.destinationStation,
                departureTime = ticket.departureTime,
                arrivalTime = ticket.arrivalTime,
                trainOrVehicleNumber = ticket.trainOrVehicleNumber,
                seatOrCarriage = ticket.seatOrCarriage,
                passengerName = ticket.passengerName,
                price = ticket.price,
                currency = ticket.currency,
                statusName = ticket.status.displayName,
                qrCodePayload = ticket.qrCodePayload,
                validityText = ticket.validityText,
                isSimulated = true
            )
        )

        return ticket
    }

    suspend fun updateTicketStatus(ticketId: String, status: TicketStatus) {
        db.ticketDao().updateTicketStatus(ticketId, status.displayName)
    }

    suspend fun seedInitialFavorites() {
        val favorites = listOf(
            FavoritePlaceEntity("FAV_HOME", "家", "广州天河区珠江新城", "HOME", "广州", "home"),
            FavoritePlaceEntity("FAV_WORK", "公司", "深圳福田 CBD 腾讯大厦/网易大厦", "WORK", "深圳", "work"),
            FavoritePlaceEntity("FAV_HK", "香港西九龙", "香港特别行政区油尖旺区", "HSR_STATION", "香港", "train"),
            FavoritePlaceEntity("FAV_AIRPORT", "广州白云国际机场", "广州市花都区T2航站楼", "AIRPORT", "广州", "flight")
        )
        favorites.forEach { db.favoritePlaceDao().insertFavoritePlace(it) }
    }
}
