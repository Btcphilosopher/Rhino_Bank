package com.example.model

enum class LegType {
    WALK,
    STATION_ENTRY,
    BOARDING,
    TRANSIT,
    TRANSFER,
    BORDER_CONTROL,
    SECURITY_CHECK,
    STATION_EXIT
}

data class JourneyLeg(
    val id: String,
    val legType: LegType,
    val mode: TransitMode,
    val title: String,
    val subtitle: String,
    val operatorName: String,
    val lineName: String? = null,
    val lineColorHex: String? = null,
    val departureStation: String,
    val arrivalStation: String,
    val departureTime: String,
    val arrivalTime: String,
    val durationMinutes: Int,
    val stopsCount: Int = 0,
    val intermediateStops: List<String> = emptyList(),
    val platform: String? = null,
    val vehicleNumber: String? = null,
    val instructions: List<String> = emptyList(),
    val distanceMeters: Int = 0,
    val fareAmount: Double = 0.0,
    val currency: String = "CNY",
    val isAccessible: Boolean = true,
    val borderRequirement: String? = null
)

data class JourneyPlan(
    val id: String,
    val tag: String, // "最快", "更省钱", "少换乘", "少步行", "跨境便捷"
    val originStationName: String,
    val originCity: String,
    val destinationStationName: String,
    val destinationCity: String,
    val departureTime: String,
    val arrivalTime: String,
    val totalDurationMinutes: Int,
    val transferCount: Int,
    val totalWalkingMeters: Int,
    val totalFareCNY: Double,
    val legs: List<JourneyLeg>,
    val isCrossBorder: Boolean = false,
    val realtimeStatus: RealtimeStatus = RealtimeStatus.NORMAL,
    val delayMinutes: Int = 0,
    val isReplanned: Boolean = false
)

enum class JourneyState {
    PLANNED,
    TICKET_PURCHASED,
    READY_TO_DEPART,
    IN_PROGRESS,
    DELAYED_AWAITING_REPLAN,
    ARRIVED,
    COMPLETED
}
