package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.MetroHeaderBar
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.TransportBlue
import com.example.viewmodel.MainViewModel

@Composable
fun ProfileScreen(
    viewModel: MainViewModel
) {
    var selectedLanguage by remember { mutableStateOf("简体中文") }
    var isAccessibilityEnabled by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
    ) {
        MetroHeaderBar(subtitleText = "个人中心与出行偏好")

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 80.dp)
        ) {
            // User Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .clip(CircleShape)
                                .background(TransportBlue),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(32.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("大湾区出行用户", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = NavyDeep)
                                Spacer(modifier = Modifier.width(8.dp))
                                Surface(
                                    color = Color(0xFFECFDF5),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = "已实名认证",
                                        fontSize = 10.sp,
                                        color = Color(0xFF059669),
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text("证件类型：港网通 / 二代身份证", fontSize = 12.sp, color = Color(0xFF64748B))
                            Text("乘车码账户：广深佛东 / 港铁八达通已绑定", fontSize = 11.sp, color = Color(0xFF0284C7))
                        }
                    }
                }
            }

            // Saved Places
            item {
                Spacer(modifier = Modifier.height(20.dp))
                Text("常用地点设置", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = NavyDeep)
                Spacer(modifier = Modifier.height(8.dp))

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Home, contentDescription = null, tint = Color(0xFF059669))
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text("家", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = NavyDeep)
                                    Text("广州市天河区珠江新城", fontSize = 12.sp, color = Color(0xFF64748B))
                                }
                            }
                            Text("修改", fontSize = 12.sp, color = TransportBlue)
                        }

                        Divider(modifier = Modifier.padding(vertical = 10.dp), color = Color(0xFFF1F5F9))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Work, contentDescription = null, tint = Color(0xFF2563EB))
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text("公司", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = NavyDeep)
                                    Text("深圳市福田区 CBD", fontSize = 12.sp, color = Color(0xFF64748B))
                                }
                            }
                            Text("修改", fontSize = 12.sp, color = TransportBlue)
                        }
                    }
                }
            }

            // Accessibility & Preferences
            item {
                Spacer(modifier = Modifier.height(20.dp))
                Text("出行偏好与无障碍 (Accessibility)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = NavyDeep)
                Spacer(modifier = Modifier.height(8.dp))

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Accessible, contentDescription = null, tint = Color(0xFF7C3AED))
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text("全程无障碍优先", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = NavyDeep)
                                    Text("优先避开阶梯、自动匹配站内无障碍直梯", fontSize = 12.sp, color = Color(0xFF64748B))
                                }
                            }
                            Switch(
                                checked = isAccessibilityEnabled,
                                onCheckedChange = { isAccessibilityEnabled = it },
                                modifier = Modifier.testTag("accessibility_switch")
                            )
                        }
                    }
                }
            }

            // Language & System Options
            item {
                Spacer(modifier = Modifier.height(20.dp))
                Text("系统与多语言 (Language)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = NavyDeep)
                Spacer(modifier = Modifier.height(8.dp))

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Language, contentDescription = null, tint = Color(0xFF0284C7))
                                Spacer(modifier = Modifier.width(12.dp))
                                Text("显示语言", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = NavyDeep)
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                listOf("简体中文", "繁體中文", "English").forEach { lang ->
                                    FilterChip(
                                        selected = selectedLanguage == lang,
                                        onClick = { selectedLanguage = lang },
                                        label = { Text(lang, fontSize = 11.sp) },
                                        modifier = Modifier.height(28.dp)
                                    )
                                }
                            }
                        }

                        Divider(modifier = Modifier.padding(vertical = 10.dp), color = Color(0xFFF1F5F9))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CloudDone, contentDescription = null, tint = Color(0xFF059669))
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text("离线离线线网图缓存", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = NavyDeep)
                                    Text("大湾区 200+ 车站数据已离线加载", fontSize = 12.sp, color = Color(0xFF64748B))
                                }
                            }
                            Text("已最新", fontSize = 12.sp, color = Color(0xFF059669), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
