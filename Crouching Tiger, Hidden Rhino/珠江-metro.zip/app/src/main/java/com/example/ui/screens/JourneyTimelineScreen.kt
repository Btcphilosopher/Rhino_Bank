package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.RealtimeStatus
import com.example.ui.components.MetroHeaderBar
import com.example.ui.components.RealtimeAlertBanner
import com.example.ui.components.TimelineLegView
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.TransportBlue
import com.example.viewmodel.MainViewModel

@Composable
fun JourneyTimelineScreen(
    viewModel: MainViewModel,
    onNavigateToTickets: () -> Unit
) {
    val selectedPlan by viewModel.selectedJourneyPlan.collectAsState()
    val delayMinutes by viewModel.simulatedDelayMinutes.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
    ) {
        MetroHeaderBar(subtitleText = "可执行行程 Timeline 实时追踪")

        if (selectedPlan == null) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text("暂无选中的行程，请返回搜索路线", color = Color(0xFF64748B))
            }
            return
        }

        val plan = selectedPlan!!

        // Top Summary Header Card
        Surface(
            color = Color.White,
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = plan.originStationName,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = NavyDeep
                            )
                            Icon(
                                imageVector = Icons.Default.East,
                                contentDescription = null,
                                tint = Color(0xFF94A3B8),
                                modifier = Modifier.padding(horizontal = 8.dp)
                            )
                            Text(
                                text = plan.destinationStationName,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = NavyDeep
                            )
                        }

                        Text(
                            text = "全程预计 ${plan.totalDurationMinutes} 分钟 • 换乘 ${plan.transferCount} 次",
                            fontSize = 12.sp,
                            color = Color(0xFF64748B)
                        )
                    }

                    // Delay simulation test toggle button
                    OutlinedButton(
                        onClick = {
                            if (delayMinutes == 0) {
                                viewModel.triggerSimulatedDelay(8)
                            } else {
                                viewModel.triggerReplanning()
                            }
                        },
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = if (delayMinutes > 0) Color(0xFF059669) else Color(0xFFDC2626)
                        ),
                        modifier = Modifier.testTag("simulate_delay_button")
                    ) {
                        Icon(
                            imageVector = if (delayMinutes > 0) Icons.Default.Autorenew else Icons.Default.Timer,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (delayMinutes > 0) "恢复正常" else "模拟延误 +8m",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = if (delayMinutes > 0) Color(0xFFFEF2F2) else Color(0xFFECFDF5),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (delayMinutes > 0) Color(0xFFDC2626) else Color(0xFF059669))
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (delayMinutes > 0) "当前阶段延误 $delayMinutes 分钟" else "实时交通状况良好",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (delayMinutes > 0) Color(0xFF991B1B) else Color(0xFF065F46)
                                )
                            }
                        }
                    }

                    Button(
                        onClick = {
                            viewModel.buyDemoTicket(plan)
                            onNavigateToTickets()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = TransportBlue),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .height(36.dp)
                            .testTag("show_digital_ticket_button")
                    ) {
                        Icon(Icons.Default.ConfirmationNumber, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("出示/购买电子票", fontSize = 12.sp)
                    }
                }
            }
        }

        // Live Alert & Re-Planning Banner
        if (delayMinutes > 0) {
            RealtimeAlertBanner(
                title = "前面阶段发生延误，影响行程预估到达时间",
                message = "原预计到达时间 ${plan.arrivalTime}，现延误 ${delayMinutes} 分钟。系统已为你准备智能重新规划替代方案。",
                delayMinutes = delayMinutes,
                onReplanClick = { viewModel.triggerReplanning() }
            )
        }

        // Executable Step Timeline List (Section VII & VIII)
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 12.dp),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            itemsIndexed(plan.legs) { index, leg ->
                TimelineLegView(
                    leg = leg,
                    isFirst = index == 0,
                    isLast = index == plan.legs.size - 1
                )
            }
        }
    }
}
