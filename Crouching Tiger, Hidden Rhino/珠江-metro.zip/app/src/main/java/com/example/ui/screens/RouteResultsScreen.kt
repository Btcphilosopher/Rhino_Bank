package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.JourneyPlan
import com.example.model.RoutePreference
import com.example.ui.components.MetroHeaderBar
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.TransportBlue
import com.example.viewmodel.MainViewModel

@Composable
fun RouteResultsScreen(
    viewModel: MainViewModel,
    onSelectJourneyPlan: (JourneyPlan) -> Unit
) {
    val originQuery by viewModel.originQuery.collectAsState()
    val destinationQuery by viewModel.destinationQuery.collectAsState()
    val routePlans by viewModel.routePlans.collectAsState()
    val selectedPreference by viewModel.selectedPreference.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
    ) {
        MetroHeaderBar(subtitleText = "全网跨城/跨境路线规划")

        // Route Header
        Surface(
            color = Color.White,
            shadowElevation = 1.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = originQuery,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyDeep
                        )
                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = null,
                            tint = Color(0xFF64748B),
                            modifier = Modifier
                                .padding(horizontal = 8.dp)
                                .size(18.dp)
                        )
                        Text(
                            text = destinationQuery,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyDeep
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFFEFF6FF))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "共 ${routePlans.size} 个可行方案",
                            fontSize = 11.sp,
                            color = TransportBlue,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Preferences Tabs (Section XXVI & LXI)
                ScrollableTabRow(
                    selectedTabIndex = RoutePreference.entries.indexOf(selectedPreference),
                    edgePadding = 0.dp,
                    containerColor = Color.Transparent,
                    divider = {}
                ) {
                    RoutePreference.entries.forEach { pref ->
                        Tab(
                            selected = selectedPreference == pref,
                            onClick = { viewModel.setPreference(pref) },
                            text = {
                                Text(
                                    text = pref.title,
                                    fontWeight = if (selectedPreference == pref) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 13.sp
                                )
                            }
                        )
                    }
                }
            }
        }

        // Route Options List
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp)
        ) {
            items(routePlans) { plan ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                        .clickable { onSelectJourneyPlan(plan) }
                        .testTag("route_card_${plan.tag}")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = when (plan.tag) {
                                    "最快" -> Color(0xFFEFF6FF)
                                    "更省钱" -> Color(0xFFECFDF5)
                                    "少换乘" -> Color(0xFFF5F3FF)
                                    else -> Color(0xFFF1F5F9)
                                },
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = plan.tag,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = when (plan.tag) {
                                        "最快" -> Color(0xFF2563EB)
                                        "更省钱" -> Color(0xFF059669)
                                        "少换乘" -> Color(0xFF7C3AED)
                                        else -> Color(0xFF475569)
                                    },
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }

                            if (plan.isCrossBorder) {
                                Surface(
                                    color = Color(0xFFFEF2F2),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = "跨境行程 (含海关查验)",
                                        fontSize = 11.sp,
                                        color = Color(0xFFDC2626),
                                        fontWeight = FontWeight.Medium,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Time & Duration
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.Bottom) {
                                    Text(
                                        text = plan.departureTime,
                                        fontSize = 22.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = NavyDeep
                                    )
                                    Text(
                                        text = " → ",
                                        fontSize = 16.sp,
                                        color = Color(0xFF94A3B8)
                                    )
                                    Text(
                                        text = plan.arrivalTime,
                                        fontSize = 22.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = NavyDeep
                                    )
                                }
                                Text(
                                    text = "${plan.originStationName} 出发  •  抵达 ${plan.destinationStationName}",
                                    fontSize = 12.sp,
                                    color = Color(0xFF64748B)
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "${plan.totalDurationMinutes} 分钟",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF2563EB)
                                )
                                Text(
                                    text = "换乘 ${plan.transferCount} 次 • 步行 ${plan.totalWalkingMeters}m",
                                    fontSize = 11.sp,
                                    color = Color(0xFF64748B)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Divider(color = Color(0xFFF1F5F9))
                        Spacer(modifier = Modifier.height(10.dp))

                        // Footer: Mode Badges & Action Buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "预计票价",
                                    fontSize = 10.sp,
                                    color = Color(0xFF94A3B8)
                                )
                                Text(
                                    text = "¥${plan.totalFareCNY}",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFDC2626)
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    onClick = { onSelectJourneyPlan(plan) },
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.testTag("view_timeline_button")
                                ) {
                                    Text("看行程", fontSize = 12.sp)
                                }

                                Button(
                                    onClick = {
                                        viewModel.selectJourneyPlan(plan)
                                        viewModel.buyDemoTicket(plan)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = TransportBlue),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.testTag("buy_ticket_button")
                                ) {
                                    Text("电子车票", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
