package com.example.model

enum class TicketStatus(val displayName: String) {
    UPCOMING("待出行"),
    ACTIVE("行程中"),
    COMPLETED("已完成"),
    CANCELLED("已退票"),
    REFUNDED("已改签")
}

enum class TicketProductType(val label: String) {
    HIGH_SPEED_RAIL_12306("中国铁路 12306 高铁电子客票"),
    METRO_PASS("大湾区地铁乘车码 (广深佛东)"),
    HK_MTR_QR("港铁 MTR 电子单程票/QR"),
    MACAU_LRT_PASS("澳门轻轨电子票"),
    INTERCITY_RAIL_PASS("广东城际铁路随到随走通"),
    FERRY_TICKET("湾区水上客运船票")
}

data class Ticket(
    val id: String,
    val journeyPlanId: String,
    val productType: TicketProductType,
    val issuerName: String,
    val originStation: String,
    val destinationStation: String,
    val departureTime: String,
    val arrivalTime: String,
    val trainOrVehicleNumber: String,
    val seatOrCarriage: String,
    val passengerName: String = "张*华 (授权实名)",
    val passengerIdMasked: String = "4401**********1234",
    val price: Double,
    val currency: String = "CNY",
    val status: TicketStatus = TicketStatus.UPCOMING,
    val qrCodePayload: String, // String used to render QR code graphic
    val validityText: String,
    val isSimulated: Boolean = true, // MANDATORY requirement #14 & #22: SIMULATED / DEMO TICKET
    val simulationNotice: String = "【演示卡片 SIMULATED TICKET】此卡片为开发演示票据，真实出行请前往官方授权渠道 (12306 / 官方 App)"
)
