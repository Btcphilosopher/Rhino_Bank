package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Station
import com.example.ui.components.MetroHeaderBar
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.TransportBlue
import com.example.viewmodel.MainViewModel

@Composable
fun MapScreen(
    viewModel: MainViewModel,
    onStationSelect: (Station) -> Unit
) {
    var selectedLevel by remember { mutableStateOf(1) } // 1: GBA, 2: City, 3: Line Network, 4: Station Indoor
    var selectedCityFilter by remember { mutableStateOf("全部") }
    var activeStation by remember { mutableStateOf(viewModel.stations.first()) }

    val stations = viewModel.stations
    val liveVehicles = viewModel.liveVehicles

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
    ) {
        MetroHeaderBar(subtitleText = "大湾区 4 层级 GIS 交通网络图")

        // Map Level Switcher Bar (Section XI & XII)
        Surface(
            color = Color(0xFF1E293B),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "地图层级 (GIS Zoom)",
                        fontSize = 12.sp,
                        color = Color(0xFF94A3B8),
                        fontWeight = FontWeight.Medium
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf(
                            1 to "L1 湾区",
                            2 to "L2 城市",
                            3 to "L3 线路",
                            4 to "L4 车站"
                        ).forEach { (lvl, title) ->
                            FilterChip(
                                selected = selectedLevel == lvl,
                                onClick = { selectedLevel = lvl },
                                label = { Text(title, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = TransportBlue,
                                    selectedLabelColor = Color.White,
                                    containerColor = Color(0xFF334155),
                                    labelColor = Color(0xFFCBD5E1)
                                ),
                                modifier = Modifier
                                    .height(28.dp)
                                    .testTag("map_level_$lvl")
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // City Filter Chips
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    val cityOptions = listOf("全部", "广州", "深圳", "香港", "澳门", "佛山", "东莞", "珠海")
                    items(cityOptions) { city ->
                        SuggestionChip(
                            onClick = { selectedCityFilter = city },
                            label = { Text(city, fontSize = 11.sp) },
                            colors = SuggestionChipDefaults.suggestionChipColors(
                                containerColor = if (selectedCityFilter == city) Color(0xFF0284C7) else Color(0xFF0F172A),
                                labelColor = Color.White
                            ),
                            border = SuggestionChipDefaults.suggestionChipBorder(
                                enabled = true,
                                borderColor = Color(0xFF334155)
                            ),
                            modifier = Modifier.height(26.dp)
                        )
                    }
                }
            }
        }

        // Interactive Canvas Vector Transit Map Box
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Color(0xFF0F172A))
        ) {
            // High contrast map canvas drawing lines and station nodes
            Canvas(modifier = Modifier.fillMaxSize()) {
                val width = size.width
                val height = size.height

                // Draw regional railway trunk lines
                drawLine(
                    color = Color(0xFF7C3AED),
                    start = Offset(width * 0.2f, height * 0.2f),
                    end = Offset(width * 0.8f, height * 0.8f),
                    strokeWidth = 6f
                )
                drawLine(
                    color = Color(0xFF2563EB),
                    start = Offset(width * 0.3f, height * 0.15f),
                    end = Offset(width * 0.3f, height * 0.85f),
                    strokeWidth = 5f
                )
                drawLine(
                    color = Color(0xFF059669),
                    start = Offset(width * 0.15f, height * 0.5f),
                    end = Offset(width * 0.85f, height * 0.5f),
                    strokeWidth = 5f
                )
            }

            // Render Stations on Canvas
            val filteredStations = if (selectedCityFilter == "全部") stations else stations.filter { it.city == selectedCityFilter }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Live Train Indicators Badge
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF1E293B).copy(alpha = 0.9f))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF10B981))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "实时车辆位置追踪中 (${liveVehicles.size} 列在途)",
                        fontSize = 11.sp,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Station Node Quick Selector Cards List
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "选中枢纽: ${activeStation.name} (${activeStation.city})",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )

                            Button(
                                onClick = { onStationSelect(activeStation) },
                                colors = ButtonDefaults.buttonColors(containerColor = TransportBlue),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Text("以此设为目的地", fontSize = 11.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "经停线路: ${activeStation.lines.joinToString(" • ")}",
                            fontSize = 12.sp,
                            color = Color(0xFF38BDF8)
                        )

                        // Level 4 Indoor Details Preview if L4 selected (Section XXVIII)
                        if (selectedLevel == 4 || activeStation.exits.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Divider(color = Color(0xFF334155))
                            Spacer(modifier = Modifier.height(8.dp))

                            Text("车站内部与无障碍设施 (Indoor Facilities)", fontSize = 11.sp, color = Color(0xFF94A3B8), fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))

                            activeStation.exits.take(2).forEach { exit ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(vertical = 2.dp)
                                ) {
                                    Badge(containerColor = Color(0xFF0284C7)) {
                                        Text("${exit.exitCode} 出口", fontSize = 10.sp)
                                    }
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "${exit.description} (${exit.connectedTransport})",
                                        fontSize = 11.sp,
                                        color = Color(0xFFCBD5E1)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Station Node Selector Row
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(filteredStations) { st ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (activeStation.id == st.id) TransportBlue else Color(0xFF0F172A))
                                        .border(1.dp, Color(0xFF334155), RoundedCornerShape(8.dp))
                                        .clickable { activeStation = st }
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text(st.name, fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
