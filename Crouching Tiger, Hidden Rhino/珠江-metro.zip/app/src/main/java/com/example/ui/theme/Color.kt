package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Pearl River Metro Supermodern Transport Palette
val NavyDeep = Color(0xFF0F172A)
val NavyLight = Color(0xFF1E293B)
val TransportBlue = Color(0xFF1D4ED8)
val TransportBlueLight = Color(0xFF3B82F6)
val TransportCyan = Color(0xFF06B6D4)
val EmeraldSuccess = Color(0xFF059669)
val AmberWarning = Color(0xFFD97706)
val RedAlert = Color(0xFFDC2626)
val PurpleHsr = Color(0xFF7C3AED)
val SurfaceLight = Color(0xFFF8FAFC)
val CardBackground = Color(0xFFFFFFFF)
val TextPrimary = Color(0xFF0F172A)
val TextSecondary = Color(0xFF475569)
val TextMuted = Color(0xFF94A3B8)
val BorderDivider = Color(0xFFE2E8F0)
