package com.example.dataset

import com.example.model.*

object GbaTransitDataset {

    val CITIES = listOf(
        City("GZ", "广州", "Guangzhou"),
        City("SZ", "深圳", "Shenzhen"),
        City("HK", "香港", "Hong Kong"),
        City("MO", "澳门", "Macao"),
        City("FS", "佛山", "Foshan"),
        City("DG", "东莞", "Dongguan"),
        City("ZH", "珠海", "Zhuhai"),
        City("ZS", "中山", "Zhongshan"),
        City("JM", "江门", "Jiangmen"),
        City("HZ", "惠州", "Huizhou"),
        City("ZQ", "肇庆", "Zhaoqing")
    )

    val STATIONS = listOf(
        // Guangzhou Hubs
        Station(
            id = "GZ_SOUTH",
            name = "广州南站",
            nameEn = "Guangzhou South Railway Station",
            city = "广州",
            latitude = 22.9889,
            longitude = 113.2688,
            lines = listOf("高速铁路", "广深城际", "广州地铁2号线", "广州地铁7号线", "广州地铁22号线", "佛山地铁2号线"),
            isTransferHub = true,
            isHighSpeedRail = true,
            exits = listOf(
                StationExit("A", "西广场/出租车候客区", "公交总站、P1停车场", hasLift = true),
                StationExit("B", "东广场/长途客运站", "广珠城际候车厅、P3停车场", hasLift = true),
                StationExit("C", "地铁站厅/检票口", "地铁2号线/7号线/22号线换乘", hasLift = true)
            ),
            indoorFacilities = listOf(
                IndoorFacility("FAC_01", "CUSTOMS", "实名制安检口 1-4", "1F"),
                IndoorFacility("FAC_02", "GATE", "高铁候车大厅 检票口 A2-A23", "2F"),
                IndoorFacility("FAC_03", "LIFT", "直梯 (直达地铁站厅)", "B1-2F"),
                IndoorFacility("FAC_04", "PLATFORM", "1-28站台", "1F")
            )
        ),
        Station(
            id = "GZ_EAST",
            name = "广州东站",
            nameEn = "Guangzhou East Station",
            city = "广州",
            latitude = 23.1484,
            longitude = 113.3245,
            lines = listOf("广深城际", "广州地铁1号线", "广州地铁3号线"),
            isTransferHub = true,
            isHighSpeedRail = true
        ),
        Station(
            id = "GZ_TIYU_XILU",
            name = "体育西路",
            nameEn = "Tiyu Xilu Station",
            city = "广州",
            latitude = 23.1315,
            longitude = 113.3214,
            lines = listOf("广州地铁1号线", "广州地铁3号线"),
            isTransferHub = true
        ),
        Station(
            id = "GZ_ZHUJIANG_NEW_TOWN",
            name = "珠江新城",
            nameEn = "Zhujiang New Town",
            city = "广州",
            latitude = 23.1198,
            longitude = 113.3211,
            lines = listOf("广州地铁3号线", "广州地铁5号线"),
            isTransferHub = true
        ),
        Station(
            id = "GZ_AIRPORT_T2",
            name = "白云机场T2",
            nameEn = "Baiyun Airport Terminal 2",
            city = "广州",
            latitude = 23.3925,
            longitude = 113.3082,
            lines = listOf("广州地铁3号线", "广清城际", "广州东环城际"),
            isAirport = true,
            isTransferHub = true
        ),

        // Shenzhen Hubs
        Station(
            id = "SZ_NORTH",
            name = "深圳北站",
            nameEn = "Shenzhen North Station",
            city = "深圳",
            latitude = 22.6105,
            longitude = 114.0296,
            lines = listOf("高速铁路", "深江城际", "深圳地铁4号线", "深圳地铁5号线", "深圳地铁6号线"),
            isTransferHub = true,
            isHighSpeedRail = true,
            exits = listOf(
                StationExit("A", "东广场/长途客运站", "公交枢纽、打车通道", hasLift = true),
                StationExit("C", "西广场/致远中路", "P1停车库", hasLift = true)
            )
        ),
        Station(
            id = "SZ_FUTIAN",
            name = "福田站",
            nameEn = "Futian Railway Station",
            city = "深圳",
            latitude = 22.5398,
            longitude = 114.0553,
            lines = listOf("高速铁路 (广深港高铁)", "深圳地铁2号线", "深圳地铁3号线", "深圳地铁11号线"),
            isTransferHub = true,
            isHighSpeedRail = true,
            isBorderPort = true
        ),
        Station(
            id = "SZ_LUOHU",
            name = "罗湖口岸",
            nameEn = "Luohu Border Port",
            city = "深圳",
            latitude = 22.5322,
            longitude = 114.1179,
            lines = listOf("深圳地铁1号线", "深圳站 (广深铁路)", "香港东铁线 (联程)"),
            isTransferHub = true,
            isBorderPort = true,
            exits = listOf(
                StationExit("A1", "罗湖商业城/通关大厅", "往香港方向出入境联检大楼", hasLift = true)
            )
        ),
        Station(
            id = "SZ_GANGXIABEI",
            name = "岗厦北",
            nameEn = "Gangxiabei Super Hub",
            city = "深圳",
            latitude = 22.5408,
            longitude = 114.0682,
            lines = listOf("深圳地铁2号线", "深圳地铁10号线", "深圳地铁11号线", "深圳地铁14号线"),
            isTransferHub = true
        ),
        Station(
            id = "SZ_AIRPORT",
            name = "深圳宝安机场",
            nameEn = "Shenzhen Bao'an Airport",
            city = "深圳",
            latitude = 22.6312,
            longitude = 113.8123,
            lines = listOf("深圳地铁11号线", "穗深城际"),
            isAirport = true,
            isTransferHub = true
        ),

        // Hong Kong Hubs
        Station(
            id = "HK_WEST_KOWLOON",
            name = "香港西九龙站",
            nameEn = "Hong Kong West Kowloon Station",
            city = "香港",
            latitude = 22.3042,
            longitude = 114.1652,
            lines = listOf("高速铁路 (广深港高铁)", "MTR 柯士甸站 (屯马线)", "MTR 九龙站 (机场快线/东涌线)"),
            isTransferHub = true,
            isHighSpeedRail = true,
            isBorderPort = true,
            exits = listOf(
                StationExit("M", "圆方 Elements / 九龙站", "行人天桥/无障碍接驳通道", hasLift = true),
                StationExit("A", "柯士甸站人行天桥", "屯马线接驳", hasLift = true),
                StationExit("C", "一地两检通关大厅", "内地口岸区/香港口岸区", hasLift = true)
            ),
            indoorFacilities = listOf(
                IndoorFacility("HK_FAC_01", "CUSTOMS", "内地/香港一地两检海关联检大堂", "B2F/B3F"),
                IndoorFacility("HK_FAC_02", "GATE", "高铁离港候车区 Gate 1-15", "B3F"),
                IndoorFacility("HK_FAC_03", "PLATFORM", "高铁抵港/离港站台 1-15", "B4F")
            )
        ),
        Station(
            id = "HK_ADMIRALTY",
            name = "金钟站",
            nameEn = "Admiralty MTR Station",
            city = "香港",
            latitude = 22.2792,
            longitude = 114.1648,
            lines = listOf("MTR 港岛线", "MTR 荃湾线", "MTR 南港岛线", "MTR 东铁线"),
            isTransferHub = true
        ),
        Station(
            id = "HK_LO_WU",
            name = "罗湖站 (MTR)",
            nameEn = "Lo Wu MTR Station",
            city = "香港",
            latitude = 22.5289,
            longitude = 114.1132,
            lines = listOf("MTR 东铁线"),
            isTransferHub = true,
            isBorderPort = true
        ),
        Station(
            id = "HK_AIRPORT",
            name = "香港国际机场",
            nameEn = "Hong Kong International Airport",
            city = "香港",
            latitude = 22.3080,
            longitude = 113.9185,
            lines = listOf("MTR 机场快线", "机场海天客运码头 (渡轮)"),
            isAirport = true,
            isTransferHub = true,
            isFerryPort = true
        ),

        // Macao & Zhuhai Hubs
        Station(
            id = "MO_BORDER_GATE",
            name = "澳门关闸",
            nameEn = "Macao Border Gate",
            city = "澳门",
            latitude = 22.2155,
            longitude = 113.5492,
            lines = listOf("澳门公共巴士总站", "拱北口岸跨境接驳", "澳门轻轨 (规划延长线)"),
            isTransferHub = true,
            isBorderPort = true
        ),
        Station(
            id = "MO_TAIPA_FERRY",
            name = "氹仔码头/澳门机场",
            nameEn = "Taipa Ferry Terminal / Macao Airport",
            city = "澳门",
            latitude = 22.1610,
            longitude = 113.5788,
            lines = listOf("澳门轻轨氹仔线", "氹仔客运码头", "澳门国际机场"),
            isAirport = true,
            isFerryPort = true,
            isTransferHub = true
        ),
        Station(
            id = "ZH_ZHUHAI_STATION",
            name = "珠海站",
            nameEn = "Zhuhai Railway Station",
            city = "珠海",
            latitude = 22.2168,
            longitude = 113.5488,
            lines = listOf("广珠城际", "珠机城际", "拱北口岸 (步行可达)"),
            isTransferHub = true,
            isHighSpeedRail = true,
            isBorderPort = true
        ),
        Station(
            id = "ZH_HENGQIN",
            name = "横琴口岸",
            nameEn = "Hengqin Border Port",
            city = "珠海",
            latitude = 22.1388,
            longitude = 113.5432,
            lines = listOf("珠机城际", "澳门轻轨横琴线 (一地两检)"),
            isTransferHub = true,
            isBorderPort = true
        ),

        // Foshan & Dongguan Hubs
        Station(
            id = "FS_FOSHANWEST",
            name = "佛山西站",
            nameEn = "Foshan West Railway Station",
            city = "佛山",
            latitude = 23.0825,
            longitude = 113.0089,
            lines = listOf("高速铁路", "广佛南环城际", "佛山地铁3号线"),
            isTransferHub = true,
            isHighSpeedRail = true
        ),
        Station(
            id = "FS_ZUMIAO",
            name = "祖庙",
            nameEn = "Zumiao Station",
            city = "佛山",
            latitude = 23.0289,
            longitude = 113.1118,
            lines = listOf("广佛地铁线"),
            isTransferHub = false
        ),
        Station(
            id = "DG_HUMEN",
            name = "虎门站",
            nameEn = "Humen Station",
            city = "东莞",
            latitude = 22.8621,
            longitude = 113.6738,
            lines = listOf("广深港高铁", "穗深城际", "东莞轨道交通2号线"),
            isTransferHub = true,
            isHighSpeedRail = true
        )
    )

    val REALTIME_ALERTS = listOf(
        ServiceAlert(
            id = "ALT_01",
            title = "香港 MTR 东铁线运行平稳",
            summary = "因跨境客流增加，罗湖/落马洲口岸人流适中，过关时间约 10-15 分钟。",
            affectedLineOrStation = "MTR 东铁线",
            severity = RealtimeStatus.NORMAL,
            publishTime = "10 分钟前"
        ),
        ServiceAlert(
            id = "ALT_02",
            title = "广州地铁 3 号线高峰客流管控",
            summary = "体育西路及珠江新城站实施常态化客流管控，请预留换乘时间。",
            affectedLineOrStation = "广州地铁3号线",
            severity = RealtimeStatus.MINOR_DELAY,
            publishTime = "25 分钟前"
        ),
        ServiceAlert(
            id = "ALT_03",
            title = "广深城际列车运行正常",
            summary = "广深城际“随到随走”系统正常，广州东-深圳间班次间隔 10-15 分钟。",
            affectedLineOrStation = "广深城际",
            severity = RealtimeStatus.NORMAL,
            publishTime = "1 小时前"
        )
    )

    val LIVE_VEHICLES = listOf(
        VehiclePosition("G6501", "HSR_GZ_HK", "广深港高铁 G6501", "广州南站", "深圳北站", RealtimeStatus.NORMAL, 0, 22.8, 113.8),
        VehiclePosition("G6503", "HSR_GZ_HK", "广深港高铁 G6503", "深圳北站", "香港西九龙站", RealtimeStatus.NORMAL, 0, 22.4, 114.1),
        VehiclePosition("MTR_E01", "MTR_EAST_RAIL", "港铁东铁线 E01", "罗湖站 (MTR)", "上水站", RealtimeStatus.NORMAL, 0, 22.5, 114.1),
        VehiclePosition("GZ_LINE3_12", "GZ_M3", "广州地铁3号线 0312", "广州南站", "大石", RealtimeStatus.MINOR_DELAY, 2, 23.0, 113.3)
    )
}
