package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.MetroRepository
import com.example.model.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class AppNavTab(val title: String, val iconName: String) {
    HOME("首页", "home"),
    MAP("地图", "map"),
    ROUTE("路线", "directions"),
    TICKETS("车票", "confirmation_number"),
    PROFILE("我的", "person")
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: MetroRepository = MetroRepository(AppDatabase.getDatabase(application))

    val currentTab = MutableStateFlow(AppNavTab.HOME)

    val originQuery = MutableStateFlow("广州南站")
    val destinationQuery = MutableStateFlow("香港西九龙站")
    val selectedPreference = MutableStateFlow(RoutePreference.FASTEST)

    val simulatedDelayMinutes = MutableStateFlow(0)

    private val _routePlans = MutableStateFlow<List<JourneyPlan>>(emptyList())
    val routePlans: StateFlow<List<JourneyPlan>> = _routePlans.asStateFlow()

    private val _selectedJourneyPlan = MutableStateFlow<JourneyPlan?>(null)
    val selectedJourneyPlan: StateFlow<JourneyPlan?> = _selectedJourneyPlan.asStateFlow()

    val tickets: StateFlow<List<Ticket>> = repository.ticketsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val savedJourneys = repository.savedJourneys
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val serviceAlerts = repository.getServiceAlerts()
    val stations = repository.getStations()
    val liveVehicles = repository.getLiveVehicles()

    init {
        viewModelScope.launch {
            repository.seedInitialFavorites()
            searchJourneys()
        }
    }

    fun searchJourneys() {
        val origin = originQuery.value.ifBlank { "广州南站" }
        val dest = destinationQuery.value.ifBlank { "香港西九龙站" }
        val delay = simulatedDelayMinutes.value

        val plans = repository.planJourneys(origin, dest, selectedPreference.value, delay)
        _routePlans.value = plans
        if (plans.isNotEmpty() && _selectedJourneyPlan.value == null) {
            _selectedJourneyPlan.value = plans.first()
        }
    }

    fun selectJourneyPlan(plan: JourneyPlan) {
        _selectedJourneyPlan.value = plan
    }

    fun setOrigin(origin: String) {
        originQuery.value = origin
        searchJourneys()
    }

    fun setDestination(dest: String) {
        destinationQuery.value = dest
        searchJourneys()
    }

    fun swapOriginAndDestination() {
        val temp = originQuery.value
        originQuery.value = destinationQuery.value
        destinationQuery.value = temp
        searchJourneys()
    }

    fun setPreference(preference: RoutePreference) {
        selectedPreference.value = preference
        searchJourneys()
    }

    fun triggerSimulatedDelay(delayMins: Int) {
        simulatedDelayMinutes.value = delayMins
        searchJourneys()
        val currentPlan = _selectedJourneyPlan.value
        if (currentPlan != null) {
            val updated = _routePlans.value.firstOrNull { it.tag == currentPlan.tag } ?: _routePlans.value.firstOrNull()
            _selectedJourneyPlan.value = updated
        }
    }

    fun triggerReplanning() {
        simulatedDelayMinutes.value = 0
        searchJourneys()
        _selectedJourneyPlan.value = _routePlans.value.firstOrNull()
    }

    fun buyDemoTicket(plan: JourneyPlan) {
        viewModelScope.launch {
            repository.issueDemoTicket(plan)
            currentTab.value = AppNavTab.TICKETS
        }
    }

    fun saveCurrentJourney(plan: JourneyPlan) {
        viewModelScope.launch {
            repository.saveJourney(plan)
        }
    }

    fun updateTicketStatus(ticketId: String, status: TicketStatus) {
        viewModelScope.launch {
            repository.updateTicketStatus(ticketId, status)
        }
    }
}
