package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SavedJourneyDao {
    @Query("SELECT * FROM saved_journeys ORDER BY timestamp DESC")
    fun getAllSavedJourneys(): Flow<List<SavedJourneyEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJourney(journey: SavedJourneyEntity)

    @Query("DELETE FROM saved_journeys WHERE id = :id")
    suspend fun deleteJourney(id: String)
}

@Dao
interface TicketDao {
    @Query("SELECT * FROM tickets ORDER BY timestamp DESC")
    fun getAllTickets(): Flow<List<TicketEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicket(ticket: TicketEntity)

    @Query("UPDATE tickets SET statusName = :newStatus WHERE id = :ticketId")
    suspend fun updateTicketStatus(ticketId: String, newStatus: String)

    @Query("DELETE FROM tickets WHERE id = :ticketId")
    suspend fun deleteTicket(ticketId: String)
}

@Dao
interface FavoritePlaceDao {
    @Query("SELECT * FROM favorite_places")
    fun getAllFavoritePlaces(): Flow<List<FavoritePlaceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavoritePlace(place: FavoritePlaceEntity)
}
