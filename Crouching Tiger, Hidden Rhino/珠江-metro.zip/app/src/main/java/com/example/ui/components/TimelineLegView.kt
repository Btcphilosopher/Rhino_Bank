package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.JourneyLeg
import com.example.model.LegType
import com.example.model.TransitMode

@Composable
fun TimelineLegView(
    leg: JourneyLeg,
    isFirst: Boolean,
    isLast: Boolean
) {
    var isExpanded by remember { mutableStateOf(true) }

    val lineColor = when {
        leg.lineColorHex != null -> parseColorHex(leg.lineColorHex)
        leg.legType == LegType.BORDER_CONTROL -> Color(0xFFDC2626)
        leg.mode == TransitMode.HIGH_SPEED_RAIL -> Color(0xFF7C3AED)
        leg.mode == TransitMode.INTERCITY_RAIL -> Color(0xFF2563EB)
        leg.mode == TransitMode.METRO -> Color(0xFF059669)
        leg.mode == TransitMode.MTR -> Color(0xFF00529B)
        else -> Color(0xFF64748B)
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 2.dp)
            .testTag("timeline_leg_${leg.id}")
    ) {
        // Left Column: Departure Time
        Column(
            modifier = Modifier.width(52.dp),
            horizontalAlignment = Alignment.End
        ) {
            Text(
                text = leg.departureTime,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0F172A)
            )
            Text(
                text = "${leg.durationMinutes}m",
                fontSize = 11.sp,
                color = Color(0xFF64748B)
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        // Center Column: Timeline Node & Connecting Line
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.width(28.dp)
        ) {
            // Station Node Bullet
            Box(
                modifier = Modifier
                    .size(18.dp)
                    .clip(CircleShape)
                    .background(if (isFirst || isLast) lineColor else Color.White)
                    .padding(3.dp),
                contentAlignment = Alignment.Center
            ) {
                if (!isFirst && !isLast) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                            .background(lineColor)
                    )
                }
            }

            // Connecting Vertical Line
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height(if (isExpanded) 120.dp else 40.dp)
                    .background(lineColor)
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        // Right Column: Step Content Card
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .weight(1f)
                .clickable { isExpanded = !isExpanded }
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = leg.title,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(lineColor.copy(alpha = 0.12f))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = leg.mode.label,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = lineColor
                        )
                    }
                }

                Text(
                    text = leg.subtitle,
                    fontSize = 12.sp,
                    color = Color(0xFF64748B),
                    modifier = Modifier.padding(top = 2.dp)
                )

                // Extra details pills
                Row(
                    modifier = Modifier.padding(top = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    leg.platform?.let {
                        AssistChip(
                            onClick = {},
                            label = { Text("站台: $it", fontSize = 10.sp) },
                            leadingIcon = { Icon(Icons.Default.Place, contentDescription = null, modifier = Modifier.size(12.dp)) },
                            modifier = Modifier.height(24.dp)
                        )
                    }
                    leg.vehicleNumber?.let {
                        AssistChip(
                            onClick = {},
                            label = { Text(it, fontSize = 10.sp) },
                            leadingIcon = { Icon(Icons.Default.Train, contentDescription = null, modifier = Modifier.size(12.dp)) },
                            modifier = Modifier.height(24.dp)
                        )
                    }
                }

                // Cross-border ID requirement alert pill
                leg.borderRequirement?.let { borderReq ->
                    Surface(
                        color = Color(0xFFFEF2F2),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Gavel,
                                contentDescription = "跨境证件提醒",
                                tint = Color(0xFFDC2626),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = borderReq,
                                fontSize = 11.sp,
                                color = Color(0xFF991B1B),
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                // Expandable step instructions
                AnimatedVisibility(visible = isExpanded) {
                    Column(modifier = Modifier.padding(top = 8.dp)) {
                        Divider(color = Color(0xFFF1F5F9))
                        Spacer(modifier = Modifier.height(6.dp))
                        leg.instructions.forEach { stepText ->
                            Row(
                                modifier = Modifier.padding(vertical = 2.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Text("• ", fontSize = 12.sp, color = Color(0xFF2563EB))
                                Text(
                                    text = stepText,
                                    fontSize = 12.sp,
                                    color = Color(0xFF334155),
                                    lineHeight = 16.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun parseColorHex(hex: String): Color {
    return try {
        Color(android.graphics.Color.parseColor(hex))
    } catch (e: Exception) {
        Color(0xFF2563EB)
    }
}
