package com.example.model

import androidx.compose.ui.graphics.Color

enum class TransitMode(val label: String, val iconName: String) {
    HIGH_SPEED_RAIL("高速铁路", "train"),
    INTERCITY_RAIL("城际铁路", "subway"),
    METRO("城市地铁", "directions_subway"),
    MTR("香港港铁", "directions_railway"),
    MACAU_LRT("澳门轻轨", "tram"),
    BUS("城市公交", "directions_bus"),
    FERRY("水上客运", "directions_boat"),
    AIRPORT_EXPRESS("机场快线", "flight_takeoff"),
    WALK("步行", "directions_walk")
}

enum class OperatorType(val displayName: String) {
    CHINA_RAILWAY("中国国家铁路 (12306)"),
    GZ_METRO("广州地铁"),
    SZ_METRO("深圳地铁"),
    FS_METRO("佛山地铁"),
    DG_METRO("东莞轨道交通"),
    GBA_INTERCITY("广东城际"),
    HK_MTR("香港铁路 (MTR)"),
    MACAU_LRT("澳门轻轨股份有限公司"),
    FERRY_OPERATOR("湾区客轮航运")
}

enum class RealtimeStatus(val label: String, val colorHex: String) {
    NORMAL("运行正常", "#10B981"),
    MINOR_DELAY("轻微延误", "#F59E0B"),
    DELAYED("严重延误", "#EF4444"),
    SUSPENDED("暂停运营", "#6B7280"),
    SIMULATED("演示实时", "#3B82F6")
}

data class City(
    val id: String,
    val name: String,
    val nameEn: String,
    val isMainHub: Boolean = true
)

data class Station(
    val id: String,
    val name: String,
    val nameEn: String,
    val city: String,
    val latitude: Double,
    val longitude: Double,
    val lines: List<String>,
    val isTransferHub: Boolean = false,
    val isHighSpeedRail: Boolean = false,
    val isAirport: Boolean = false,
    val isBorderPort: Boolean = false,
    val isFerryPort: Boolean = false,
    val exits: List<StationExit> = emptyList(),
    val indoorFacilities: List<IndoorFacility> = emptyList()
)

data class StationExit(
    val exitCode: String,
    val description: String,
    val connectedTransport: String,
    val hasLift: Boolean = true,
    val hasEscalator: Boolean = true
)

data class IndoorFacility(
    val id: String,
    val type: String, // GATE, PLATFORM, LIFT, ESCALATOR, RESTROOM, CUSTOMS
    val label: String,
    val floor: String,
    val isAccessible: Boolean = true
)

data class TransitLine(
    val id: String,
    val name: String,
    val colorHex: String,
    val mode: TransitMode,
    val operatorType: OperatorType,
    val city: String,
    val stations: List<String>
)

data class VehiclePosition(
    val vehicleId: String,
    val lineId: String,
    val lineName: String,
    val currentStationName: String,
    val nextStationName: String,
    val status: RealtimeStatus,
    val delayMinutes: Int = 0,
    val latitude: Double,
    val longitude: Double
)

data class ServiceAlert(
    val id: String,
    val title: String,
    val summary: String,
    val affectedLineOrStation: String,
    val severity: RealtimeStatus,
    val publishTime: String
)

enum class RoutePreference(val title: String, val desc: String) {
    FASTEST("最快到达", "优先选择高铁/城际"),
    CHEAPEST("更省钱", "优先选择普通地铁/公交"),
    FEWEST_TRANSFERS("少换乘", "尽量直达或单次换乘"),
    LESS_WALKING("少步行", "减少站内与同站换乘步行"),
    ACCESSIBLE("无障碍优先", "全程全程电梯与无障碍通道"),
    CROSS_BORDER_FAST("跨境快速通关", "优先高铁/直通口岸")
}
