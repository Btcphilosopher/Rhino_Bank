package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.*
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.PearlRiverMetroTheme
import com.example.ui.theme.TransportBlue
import com.example.viewmodel.AppNavTab
import com.example.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            PearlRiverMetroTheme {
                val currentTab by viewModel.currentTab.collectAsState()

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        NavigationBar(
                            containerColor = Color.White,
                            tonalElevation = 8.dp,
                            windowInsets = WindowInsets.navigationBars
                        ) {
                            AppNavTab.entries.forEach { tab ->
                                val selected = currentTab == tab
                                val icon = when (tab) {
                                    AppNavTab.HOME -> Icons.Default.Home
                                    AppNavTab.MAP -> Icons.Default.Map
                                    AppNavTab.ROUTE -> Icons.Default.Directions
                                    AppNavTab.TICKETS -> Icons.Default.ConfirmationNumber
                                    AppNavTab.PROFILE -> Icons.Default.Person
                                }

                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { viewModel.currentTab.value = tab },
                                    icon = { Icon(icon, contentDescription = tab.title) },
                                    label = {
                                        Text(
                                            text = tab.title,
                                            fontSize = 11.sp,
                                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = TransportBlue,
                                        selectedTextColor = TransportBlue,
                                        indicatorColor = Color(0xFFDBEAFE),
                                        unselectedIconColor = Color(0xFF64748B),
                                        unselectedTextColor = Color(0xFF64748B)
                                    ),
                                    modifier = Modifier.testTag("nav_item_${tab.name}")
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (currentTab) {
                            AppNavTab.HOME -> HomeScreen(
                                viewModel = viewModel,
                                onNavigateToRoute = { viewModel.currentTab.value = AppNavTab.ROUTE },
                                onNavigateToTimeline = { viewModel.currentTab.value = AppNavTab.ROUTE },
                                onNavigateToTicketWallet = { viewModel.currentTab.value = AppNavTab.TICKETS }
                            )

                            AppNavTab.ROUTE -> RouteResultsScreen(
                                viewModel = viewModel,
                                onSelectJourneyPlan = { plan ->
                                    viewModel.selectJourneyPlan(plan)
                                    // Remain on Route or view Timeline
                                }
                            )

                            AppNavTab.MAP -> MapScreen(
                                viewModel = viewModel,
                                onStationSelect = { station ->
                                    viewModel.setDestination(station.name)
                                    viewModel.currentTab.value = AppNavTab.ROUTE
                                }
                            )

                            AppNavTab.TICKETS -> TicketWalletScreen(
                                viewModel = viewModel,
                                onNavigateToSearch = { viewModel.currentTab.value = AppNavTab.HOME }
                            )

                            AppNavTab.PROFILE -> ProfileScreen(
                                viewModel = viewModel
                            )
                        }
                    }
                }
            }
        }
    }
}
