package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_journeys")
data class SavedJourneyEntity(
    @PrimaryKey val id: String,
    val origin: String,
    val destination: String,
    val departureTime: String,
    val durationMinutes: Int,
    val totalFareCNY: Double,
    val tag: String,
    val isCrossBorder: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "tickets")
data class TicketEntity(
    @PrimaryKey val id: String,
    val journeyPlanId: String,
    val productTypeLabel: String,
    val issuerName: String,
    val originStation: String,
    val destinationStation: String,
    val departureTime: String,
    val arrivalTime: String,
    val trainOrVehicleNumber: String,
    val seatOrCarriage: String,
    val passengerName: String,
    val price: Double,
    val currency: String,
    val statusName: String,
    val qrCodePayload: String,
    val validityText: String,
    val isSimulated: Boolean = true,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "favorite_places")
data class FavoritePlaceEntity(
    @PrimaryKey val id: String,
    val name: String,
    val address: String,
    val category: String, // HOME, WORK, AIRPORT, HSR_STATION, PORT, FAVORITE
    val cityName: String,
    val iconName: String
)
