import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import {
  initialCustomers,
  initialProducts,
  initialPolicies,
  initialClaims,
  initialAccountingEntries,
  initialReinsuranceContracts,
  currentActuarialMetrics,
  calculateInsuranceRating,
  runUnderwritingRules
} from './src/services/mockDataStore.js';
import { Customer, Policy, ClaimCase, AccountingEntry, Quote, UWTask } from './src/types/insurance.js';

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// 内存数据库模型 (支持实时读写与生命周期演算)
let customersStore: Customer[] = [...initialCustomers];
let productsStore = [...initialProducts];
let policiesStore: Policy[] = [...initialPolicies];
let claimsStore: ClaimCase[] = [...initialClaims];
let accountingStore: AccountingEntry[] = [...initialAccountingEntries];
let reinsuranceStore = [...initialReinsuranceContracts];
let quotesStore: Quote[] = [];
let uwTasksStore: UWTask[] = [];

// Gemini AI 智保助手 SDK 初始化
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY || '';
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

// RESTful API 路由层 (/api/v1/*)
app.get('/api/v1/health', (req: Request, res: Response) => {
  res.json({
    status: 'SYSTEM_OPERATIONAL',
    system: '华安保险云 (HUAN INSURANCE OS)',
    timestamp: new Date().toISOString(),
    version: 'v3.6-ENTERPRISE',
    metrics: {
      activeCustomers: customersStore.length,
      activePolicies: policiesStore.length,
      activeClaims: claimsStore.length,
      accountingEntries: accountingStore.length
    }
  });
});

// 1. 身份认证与权限演示账户
app.post('/api/v1/auth/login', (req: Request, res: Response) => {
  const { role = 'SUPER_ADMIN', username = '演示用户' } = req.body;
  res.json({
    success: true,
    user: {
      id: 'usr-8899',
      username,
      role,
      department: '华安保险总部核心运营中心',
      permissions: ['ALL_MODULES_READ_WRITE']
    },
    token: 'huan_os_demo_jwt_token_2026'
  });
});

// 2. 客户管理 API
app.get('/api/v1/customers', (req: Request, res: Response) => {
  res.json({ success: true, data: customersStore });
});

app.post('/api/v1/customers', (req: Request, res: Response) => {
  const newCust: Customer = {
    id: `cust-${Date.now()}`,
    customerNo: `CN-2026-${Math.floor(1000 + Math.random() * 9000)}`,
    name: req.body.name || '新创建客户',
    type: req.body.type || 'INDIVIDUAL',
    idType: req.body.idType || '身份证',
    idNoMasked: req.body.idNo ? `${req.body.idNo.substring(0, 4)}****${req.body.idNo.substring(14)}` : '1101011990****1234',
    phoneMasked: req.body.phone ? `${req.body.phone.substring(0, 3)}****${req.body.phone.substring(7)}` : '138****0000',
    emailMasked: req.body.email ? `${req.body.email.substring(0, 3)}****@huan.demo` : 'contact****@huan.demo',
    address: req.body.address || '北京市海淀区金融大街1号',
    city: req.body.city || '北京',
    riskRating: req.body.riskRating || 'A',
    policyCount: 0,
    claimCount: 0,
    paymentStatus: '良好',
    relationshipManager: req.body.relationshipManager || '李明 (客户经理)',
    channel: req.body.channel || '直销渠道',
    creditScore: 90,
    createdAt: new Date().toISOString().split('T')[0],
    updatedAt: new Date().toISOString().split('T')[0]
  };
  customersStore.unshift(newCust);
  res.json({ success: true, message: '客户档案建立成功', data: newCust });
});

// 3. 保险产品工厂 API
app.get('/api/v1/products', (req: Request, res: Response) => {
  res.json({ success: true, data: productsStore });
});

// 4. 费率引擎与报价计算 API
app.post('/api/v1/quotes/calculate', (req: Request, res: Response) => {
  const { productId, sumInsured, riskFactor, regionalFactor, ageVehicleFactor, deductibleDiscount, customerId, customerName } = req.body;
  
  const product = productsStore.find(p => p.id === productId) || productsStore[0];
  const ratingResult = calculateInsuranceRating({
    product,
    sumInsured: Number(sumInsured) || 1000000,
    riskFactor: Number(riskFactor) || 1.0,
    regionalFactor: Number(regionalFactor) || 1.0,
    ageVehicleFactor: Number(ageVehicleFactor) || 1.0,
    deductibleDiscount: Number(deductibleDiscount) || 0.95
  });

  const newQuote: Quote = {
    id: `qt-${Date.now()}`,
    quoteNo: `QT-2026-${Math.floor(10000 + Math.random() * 90000)}`,
    customerId: customerId || 'cust-101',
    customerName: customerName || '华为数字技术 (北京) 有限公司',
    productId: product.id,
    productName: product.name,
    productVersion: product.version,
    sumInsured: Number(sumInsured),
    basePremium: ratingResult.basePremium,
    riskDiscountFactor: Number(riskFactor) || 1.0,
    regionalFactor: Number(regionalFactor) || 1.0,
    finalPremium: ratingResult.finalPremium,
    status: 'QUOTED',
    riskInputs: { riskFactor, regionalFactor, ageVehicleFactor },
    createdAt: new Date().toISOString(),
    createdByName: '精算费率试算引擎'
  };

  quotesStore.unshift(newQuote);

  res.json({
    success: true,
    data: newQuote,
    breakdown: ratingResult.breakdown
  });
});

// 5. 核保评估 API (规则引擎 + AI核保建议)
app.post('/api/v1/underwriting/evaluate', (req: Request, res: Response) => {
  const { quoteId, sumInsured, finalPremium, riskRating, claimCount } = req.body;

  const uwEvaluation = runUnderwritingRules({
    sumInsured: Number(sumInsured) || 1000000,
    premium: Number(finalPremium) || 5000,
    riskRating: riskRating || 'A',
    claimCount: Number(claimCount) || 0,
    customerType: 'CORPORATE'
  });

  const newTask: UWTask = {
    id: `uwt-${Date.now()}`,
    taskNo: `UW-2026-${Math.floor(1000 + Math.random() * 9000)}`,
    quoteId: quoteId || 'qt-demo',
    customerName: req.body.customerName || '华安演示客户',
    productName: req.body.productName || '华安企财臻享综合财产保险',
    sumInsured: Number(sumInsured),
    calculatedPremium: Number(finalPremium),
    riskScore: uwEvaluation.score,
    riskLevel: uwEvaluation.riskLevel,
    status: 'PENDING',
    triggeredRules: uwEvaluation.triggeredRules,
    aiRecommendation: uwEvaluation.recommendation,
    aiReasoning: uwEvaluation.reasoning,
    assignedTo: '张核保 (资深核保师)',
    createdAt: new Date().toISOString()
  };

  uwTasksStore.unshift(newTask);

  res.json({
    success: true,
    data: newTask
  });
});

// 6. 保单生命周期 API (承保、出单、批改)
app.get('/api/v1/policies', (req: Request, res: Response) => {
  res.json({ success: true, data: policiesStore });
});

app.post('/api/v1/policies/issue', (req: Request, res: Response) => {
  const { quoteNo, customerId, customerName, productId, productName, productVersion, sumInsured, annualPremium } = req.body;

  const newPolicy: Policy = {
    id: `pol-${Date.now()}`,
    policyNo: `HA-POL-2026-${Math.floor(100000 + Math.random() * 900000)}`,
    quoteNo: quoteNo || `QT-2026-999`,
    customerId: customerId || 'cust-101',
    customerName: customerName || '华为数字技术 (北京) 有限公司',
    productId: productId || 'prod-002',
    productName: productName || '华安企财臻享综合财产保险',
    productVersion: productVersion || 'v1.1',
    lineOfBusiness: 'CORP_PROPERTY',
    sumInsured: Number(sumInsured) || 10000000,
    annualPremium: Number(annualPremium) || 85000,
    startDate: '2026-09-17',
    endDate: '2027-09-16',
    status: 'ACTIVE',
    paymentPlan: '一次性趸交',
    paymentStatus: 'PAID',
    beneficiaries: [customerName || '投保企业主体'],
    channel: '企业直销渠道',
    underwriterName: '核保流程签发',
    issuanceDate: new Date().toISOString().split('T')[0]
  };

  policiesStore.unshift(newPolicy);

  // 联动产生第一笔保费会计分录
  const newAcc: AccountingEntry = {
    id: `acc-${Date.now()}`,
    entryNo: `ACC-2026-${Math.floor(100000 + Math.random() * 900000)}`,
    businessEventType: '保费收取',
    relatedDocNo: newPolicy.policyNo,
    debitAccount: '1002 银行存款',
    creditAccount: '6001 保费收入 - 承保保费',
    amount: newPolicy.annualPremium,
    accountingDate: new Date().toISOString().split('T')[0],
    operator: '系统自动化业务结算',
    auditStatus: 'VERIFIED'
  };
  accountingStore.unshift(newAcc);

  res.json({
    success: true,
    policy: newPolicy,
    accountingEntry: newAcc,
    message: '保单承保出单成功！已同步生成财技会计分录。'
  });
});

// 7. 理赔运营中心 API (FNOL、准备金、理算、赔付)
app.get('/api/v1/claims', (req: Request, res: Response) => {
  res.json({ success: true, data: claimsStore });
});

app.post('/api/v1/claims/fnol', (req: Request, res: Response) => {
  const { policyNo, customerName, accidentDate, accidentLocation, accidentType, description, estimatedLoss } = req.body;

  const newClaim: ClaimCase = {
    id: `claim-${Date.now()}`,
    claimNo: `HA-CLM-2026-${Math.floor(10000 + Math.random() * 90000)}`,
    policyNo: policyNo || 'HA-POL-2026-009801',
    customerName: customerName || '华为数字技术 (北京) 有限公司',
    productName: '华安企财臻享综合财产保险',
    accidentDate: accidentDate || '2026-09-15',
    reportDate: new Date().toISOString().split('T')[0],
    accidentLocation: accidentLocation || '北京市海淀区中关村园区',
    accidentType: accidentType || '暴雨机房水浸设备受损',
    description: description || '强对流天气导致地下室发电机房积水事故。',
    estimatedLoss: Number(estimatedLoss) || 350000,
    initialReserve: Number(estimatedLoss) || 350000,
    adjustedReserve: Number(estimatedLoss) || 350000,
    assessedLoss: 0,
    paidAmount: 0,
    status: 'REGISTERED',
    riskScore: 18,
    fraudAlerts: ['保单效力校验：有效', '事故时间在保险期间内'],
    assignedHandler: '赵理赔 (查勘定损专家)',
    documents: [
      { name: 'FNOL报案接报单.pdf', url: '#', uploadedAt: new Date().toISOString().split('T')[0] }
    ]
  };

  claimsStore.unshift(newClaim);

  // 联动生成准备金提取会计分录
  const accEntry: AccountingEntry = {
    id: `acc-clm-${Date.now()}`,
    entryNo: `ACC-2026-${Math.floor(100000 + Math.random() * 900000)}`,
    businessEventType: '提取未决赔款准备金',
    relatedDocNo: newClaim.claimNo,
    debitAccount: '6402 理赔支出 - 提准备金',
    creditAccount: '2602 未决赔款准备金 (IBNR/Case)',
    amount: newClaim.initialReserve,
    accountingDate: new Date().toISOString().split('T')[0],
    operator: '精算与理赔联动引擎',
    auditStatus: 'VERIFIED'
  };
  accountingStore.unshift(accEntry);

  res.json({
    success: true,
    claim: newClaim,
    accountingEntry: accEntry,
    message: 'FNOL报案登记成功！已提取初始理赔准备金。'
  });
});

// 理赔核损理算与赔付模拟
app.post('/api/v1/claims/pay', (req: Request, res: Response) => {
  const { claimNo, assessedLoss } = req.body;
  const claim = claimsStore.find(c => c.claimNo === claimNo) || claimsStore[0];

  claim.assessedLoss = Number(assessedLoss) || claim.estimatedLoss * 0.95;
  claim.paidAmount = claim.assessedLoss;
  claim.status = 'CLOSED';

  // 产生赔付清算分录
  const accPay: AccountingEntry = {
    id: `acc-pay-${Date.now()}`,
    entryNo: `ACC-2026-${Math.floor(100000 + Math.random() * 900000)}`,
    businessEventType: '理赔赔付',
    relatedDocNo: claim.claimNo,
    debitAccount: '2602 未决赔款准备金 (冲销)',
    creditAccount: '1002 银行存款 (划款支出)',
    amount: claim.paidAmount,
    accountingDate: new Date().toISOString().split('T')[0],
    operator: '理赔主管审批后财务出纳划款',
    auditStatus: 'VERIFIED'
  };
  accountingStore.unshift(accPay);

  res.json({
    success: true,
    claim,
    accountingEntry: accPay,
    message: '理赔案核损审批通过并划款完成！已生成赔付冲销账务记录。'
  });
});

// 8. 技术会计分录与总账 API
app.get('/api/v1/accounting/entries', (req: Request, res: Response) => {
  res.json({ success: true, data: accountingStore });
});

// 9. 再保险中心 API
app.get('/api/v1/reinsurance/contracts', (req: Request, res: Response) => {
  res.json({ success: true, data: reinsuranceStore });
});

// 10. 精算与风控分析 KPI
app.get('/api/v1/analytics/metrics', (req: Request, res: Response) => {
  res.json({
    success: true,
    data: {
      ...currentActuarialMetrics,
      totalCustomers: customersStore.length,
      totalPolicies: policiesStore.length,
      totalClaims: claimsStore.length,
      writtenPremiumTotal: policiesStore.reduce((acc, p) => acc + p.annualPremium, 0)
    }
  });
});

// 11. 一键全流程闭环演练 API (Phase 1-15 Full Chain Execution)
app.post('/api/v1/walkthrough/execute-all', (req: Request, res: Response) => {
  const timestamp = Date.now();
  
  // Step A: 建立客户
  const testCustomer: Customer = {
    id: `cust-wt-${timestamp}`,
    customerNo: `CN-WT-${Math.floor(1000 + Math.random() * 9000)}`,
    name: '中国航天高科重大工程集团',
    type: 'CORPORATE',
    idType: '统一社会信用代码',
    idNoMasked: '91110000MA00****88',
    phoneMasked: '138****8888',
    emailMasked: 'casc_risk@space.demo',
    address: '北京市海淀区阜成路8号',
    city: '北京',
    riskRating: 'A',
    policyCount: 1,
    claimCount: 0,
    paymentStatus: '良好',
    relationshipManager: '张强 (战略客户部)',
    channel: '企业直销渠道',
    creditScore: 99,
    createdAt: new Date().toISOString().split('T')[0],
    updatedAt: new Date().toISOString().split('T')[0]
  };
  customersStore.unshift(testCustomer);

  // Step B: 报价与精算试算
  const testQuote: Quote = {
    id: `qt-wt-${timestamp}`,
    quoteNo: `QT-WT-${Math.floor(10000 + Math.random() * 90000)}`,
    customerId: testCustomer.id,
    customerName: testCustomer.name,
    productId: 'prod-002',
    productName: '华安企财臻享综合财产保险',
    productVersion: 'v1.1',
    sumInsured: 100000000, // 1亿元保额
    basePremium: 850000,
    riskDiscountFactor: 0.9,
    regionalFactor: 1.0,
    finalPremium: 765000, // 76.5万元
    status: 'QUOTED',
    riskInputs: { riskRating: 'A', location: '北京航天园区' },
    createdAt: new Date().toISOString(),
    createdByName: '全流程自动化演练引擎'
  };
  quotesStore.unshift(testQuote);

  // Step C: 核保与规则校验
  const testUW: UWTask = {
    id: `uwt-wt-${timestamp}`,
    taskNo: `UW-WT-${Math.floor(1000 + Math.random() * 9000)}`,
    quoteId: testQuote.id,
    customerName: testCustomer.name,
    productName: testQuote.productName,
    sumInsured: testQuote.sumInsured,
    calculatedPremium: testQuote.finalPremium,
    riskScore: 30,
    riskLevel: 'LOW',
    status: 'APPROVED',
    triggeredRules: [{ ruleId: 'UW-R-01', description: '保额超过1千万元', action: '会签通过' }],
    aiRecommendation: 'STANDARD',
    aiReasoning: '风险评分优秀，航天高科工程具备特级安防标准，予以标准承保。',
    humanDecision: 'STANDARD',
    assignedTo: '王核保 (高级核保主管)',
    createdAt: new Date().toISOString()
  };
  uwTasksStore.unshift(testUW);

  // Step D: 承保出单
  const testPolicy: Policy = {
    id: `pol-wt-${timestamp}`,
    policyNo: `HA-POL-2026-WT${Math.floor(1000 + Math.random() * 9000)}`,
    quoteNo: testQuote.quoteNo,
    customerId: testCustomer.id,
    customerName: testCustomer.name,
    productId: 'prod-002',
    productName: '华安企财臻享综合财产保险',
    productVersion: 'v1.1',
    lineOfBusiness: 'CORP_PROPERTY',
    sumInsured: testQuote.sumInsured,
    annualPremium: testQuote.finalPremium,
    startDate: new Date().toISOString().split('T')[0],
    endDate: '2027-09-16',
    status: 'ACTIVE',
    paymentPlan: '一次性趸交',
    paymentStatus: 'PAID',
    beneficiaries: [testCustomer.name],
    channel: '企业直销渠道',
    underwriterName: '全流程演示审批放行',
    issuanceDate: new Date().toISOString().split('T')[0]
  };
  policiesStore.unshift(testPolicy);

  // Step E: 财务保费收取分录
  const acc1: AccountingEntry = {
    id: `acc-wt1-${timestamp}`,
    entryNo: `ACC-WT-01-${Math.floor(1000 + Math.random() * 9000)}`,
    businessEventType: '保费收取',
    relatedDocNo: testPolicy.policyNo,
    debitAccount: '1002 银行存款',
    creditAccount: '6001 保费收入 - 企财险',
    amount: testPolicy.annualPremium,
    accountingDate: new Date().toISOString().split('T')[0],
    operator: '系统业务全流程演算',
    auditStatus: 'VERIFIED'
  };
  accountingStore.unshift(acc1);

  // Step F: 理赔报案 (FNOL) & 提取准备金
  const testClaim: ClaimCase = {
    id: `clm-wt-${timestamp}`,
    claimNo: `HA-CLM-WT-${Math.floor(1000 + Math.random() * 9000)}`,
    policyNo: testPolicy.policyNo,
    customerName: testCustomer.name,
    productName: testPolicy.productName,
    accidentDate: new Date().toISOString().split('T')[0],
    reportDate: new Date().toISOString().split('T')[0],
    accidentLocation: '北京航天试验基地',
    accidentType: '试验测试设备电压骤降造成精细零部件损坏',
    description: '外部供电网瞬时电压波动致部分监控仪器受损。',
    estimatedLoss: 150000,
    initialReserve: 150000,
    adjustedReserve: 140000,
    assessedLoss: 135000,
    paidAmount: 135000,
    status: 'CLOSED',
    riskScore: 10,
    fraudAlerts: ['核验无误'],
    assignedHandler: '孙查勘 (现场理赔专员)',
    documents: [{ name: '电力事故调查认定书.pdf', url: '#', uploadedAt: new Date().toISOString().split('T')[0] }]
  };
  claimsStore.unshift(testClaim);

  // Step G: 理赔赔付分录
  const acc2: AccountingEntry = {
    id: `acc-wt2-${timestamp}`,
    entryNo: `ACC-WT-02-${Math.floor(1000 + Math.random() * 9000)}`,
    businessEventType: '理赔赔付',
    relatedDocNo: testClaim.claimNo,
    debitAccount: '6402 理赔支出 - 企财赔款',
    creditAccount: '1002 银行存款',
    amount: testClaim.paidAmount,
    accountingDate: new Date().toISOString().split('T')[0],
    operator: '自动理赔划款',
    auditStatus: 'VERIFIED'
  };
  accountingStore.unshift(acc2);

  res.json({
    success: true,
    message: '🎉 华安保险云「从客户到理赔再到再保险与财务总账」全生命周期闭环成功执行完成！',
    trace: {
      customer: testCustomer,
      quote: testQuote,
      underwriting: testUW,
      policy: testPolicy,
      claim: testClaim,
      accountingEntries: [acc1, acc2]
    }
  });
});

// 12. 「华安智保助手」 Gemini AI 端点
app.post('/api/v1/ai/chat', async (req: Request, res: Response) => {
  try {
    const { message, contextModule } = req.body;

    const ai = getGeminiClient();

    const systemPrompt = `你现在是「华安保险云 (HUAN INSURANCE OS)」的智能保险大脑——「华安智保助手」。
你服务于中国大型金融保险集团的总部的核心运营团队（核保员、理赔员、精算师、财务及风控专家）。
你的职责：
1. 总结保单条款与保障范围。
2. 解释核保规则、核损理算公式、再保险分保逻辑、技术会计准备金 (UPR / IBNR / Case Reserve)。
3. 协助分析理赔材料完整性与欺诈风险。
4. 提供风险管理和精算评估建议。

请严格遵守：
- 使用 100% 简体中文，语言专业、严谨、客观、有金融机构的权威感。
- 必须明确说明：“【华安智保提示】：本回复为AI辅助建议，不替代法定核保/理赔/财务审批结果。”
- 引用当前系统的真实模块数据（当前处于模块：${contextModule || '系统运营驾驶舱'}）。`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: message || '请介绍华安保险云的核心功能与优势。',
      config: {
        systemInstruction: systemPrompt,
        temperature: 0.3
      }
    });

    res.json({
      success: true,
      reply: response.text || '华安智保助手已接收您的查询。',
      disclaimer: '【华安智保提示】：本回复为AI辅助建议，不替代法定核保/理赔/财务审批结果。'
    });
  } catch (error: any) {
    console.error('Gemini AI error:', error);
    res.status(500).json({
      success: false,
      error: 'AI 助手服务响应异常，请检查配置或稍后重试。',
      details: error.message
    });
  }
});

// Vite 开发/生产中间件集成
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`=======================================================`);
    console.log(` 🚀 华安保险云 (HUAN INSURANCE OS) 核心系统已正常启动`);
    console.log(` 🌐 访问地址: http://0.0.0.0:${PORT}`);
    console.log(` 🛡️  全中文企业级保险核心运营平台环境`);
    console.log(`=======================================================`);
  });
}

startServer();
