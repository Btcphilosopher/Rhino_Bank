/**
 * 华安保险云 (HUAN INSURANCE OS)
 * 核心数据模型与类型定义
 */

// 用户角色与RBAC
export type UserRole =
  | 'SUPER_ADMIN'      // 超级管理员
  | 'SYS_ADMIN'        // 系统管理员
  | 'PRODUCT_MANAGER'  // 产品经理
  | 'ACTUARY'          // 精算师
  | 'UNDERWRITER'      // 核保员
  | 'SR_UNDERWRITER'   // 高级核保员
  | 'CLAIM_HANDLER'    // 理赔员
  | 'CLAIM_MANAGER'    // 理赔主管
  | 'FINANCE_OFFICER'  // 财务人员
  | 'REINSURANCE_MGR'  // 再保险人员
  | 'RISK_OFFICER'     // 风险人员
  | 'AUDITOR'          // 审计人员
  | 'DATA_ANALYST'     // 数据分析师
  | 'AGENT'            // 代理人
  | 'BROKER'           // 经纪人
  | 'CORP_CUSTOMER'    // 企业客户
  | 'IND_CUSTOMER';    // 个人客户

// 客户类型
export type CustomerType = 'INDIVIDUAL' | 'CORPORATE' | 'INSTITUTION' | 'AGENT' | 'BROKER' | 'PARTNER';

// 客户档案
export interface Customer {
  id: string;
  customerNo: string;
  name: string;
  type: CustomerType;
  idType: '身份证' | '统一社会信用代码' | '护照' | '营业执照';
  idNoMasked: string;
  phoneMasked: string;
  emailMasked: string;
  address: string;
  city: string;
  riskRating: 'A' | 'B' | 'C' | 'D';
  policyCount: number;
  claimCount: number;
  paymentStatus: '良好' | '有逾期' | '正常';
  relationshipManager: string;
  channel: string;
  creditScore: number;
  createdAt: string;
  updatedAt: string;
}

// 险种大类
export type InsuranceLine =
  | 'VEHICLE'          // 车险
  | 'HOME_PROPERTY'    // 家庭财产险
  | 'CORP_PROPERTY'    // 企业财产险
  | 'ENGINEERING'      // 工程险
  | 'LIABILITY'        // 责任险
  | 'CARGO'            // 货运险
  | 'TRAVEL'           // 旅行保险
  | 'ACCIDENT'         // 意外险
  | 'MEDICAL'          // 医疗险
  | 'TERM_LIFE'        // 定期寿险
  | 'WHOLE_LIFE'       // 终身寿险
  | 'CRITICAL_ILLNESS' // 重疾险
  | 'CYBER'            // 网络安全险
  | 'AGRICULTURE';     // 农业保险

// 保障项目
export interface CoverageItem {
  id: string;
  code: string;
  name: string;
  limitAmount: number;
  deductible: number;
  isMandatory: boolean;
  premiumRate: number; // 费率 (‰ 或 %)
}

// 保险产品定义
export interface InsuranceProduct {
  id: string;
  productNo: string;
  name: string;
  lineOfBusiness: InsuranceLine;
  version: string; // e.g. "v1.0", "v2.0"
  targetCustomer: '个人' | '企业' | '不限';
  status: 'DRAFT' | 'TESTING' | 'PENDING_APPROVAL' | 'PUBLISHED' | 'SUSPENDED' | 'RETIRED';
  minSumInsured: number;
  maxSumInsured: number;
  coverages: CoverageItem[];
  exclusions: string[];
  waitingPeriodDays: number;
  paymentMethods: ('趸交' | '年交' | '月交')[];
  baseRate: number;
  commissionRate: number; // %
  createdAt: string;
}

// 报价单
export interface Quote {
  id: string;
  quoteNo: string;
  customerId: string;
  customerName: string;
  productId: string;
  productName: string;
  productVersion: string;
  sumInsured: number;
  basePremium: number;
  riskDiscountFactor: number;
  regionalFactor: number;
  finalPremium: number;
  status: 'DRAFT' | 'CALCULATING' | 'PENDING_UW' | 'QUOTED' | 'ACCEPTED' | 'REJECTED' | 'EXPIRED';
  riskInputs: Record<string, any>;
  createdAt: string;
  createdByName: string;
}

// 核保判定与结果
export type UWResult =
  | 'STANDARD'       // 标准承保
  | 'CONDITIONAL'    // 附条件承保
  | 'RATE_LOADING'   // 提高保费
  | 'SUM_REDUCTION'  // 降低保额
  | 'EXTRA_DOCS'     // 补充材料
  | 'MANUAL_AUDIT'   // 转人工审核
  | 'DECLINED';      // 拒绝承保

// 核保案件
export interface UWTask {
  id: string;
  taskNo: string;
  quoteId: string;
  customerName: string;
  productName: string;
  sumInsured: number;
  calculatedPremium: number;
  riskScore: number; // 1-100
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  status: 'PENDING' | 'IN_REVIEW' | 'APPROVED' | 'REJECTED' | 'DOCS_REQ';
  triggeredRules: { ruleId: string; description: string; action: string }[];
  aiRecommendation: UWResult;
  aiReasoning: string;
  humanDecision?: UWResult;
  assignedTo: string;
  createdAt: string;
}

// 保单状态
export type PolicyStatus =
  | 'DRAFT'          // 草稿
  | 'PENDING_EFFECT' // 待生效
  | 'ACTIVE'         // 有效
  | 'SUSPENDED'      // 暂停
  | 'SURRENDERED'    // 已退保
  | 'TERMINATED'     // 已终止
  | 'EXPIRED';       // 已到期

// 保单实体
export interface Policy {
  id: string;
  policyNo: string;
  quoteNo: string;
  customerId: string;
  customerName: string;
  productId: string;
  productName: string;
  productVersion: string;
  lineOfBusiness: InsuranceLine;
  sumInsured: number;
  annualPremium: number;
  startDate: string;
  endDate: string;
  status: PolicyStatus;
  paymentPlan: '一次性趸交' | '按年分期' | '按月分期';
  paymentStatus: 'UNPAID' | 'PARTIAL' | 'PAID' | 'OVERDUE';
  beneficiaries: string[];
  channel: string;
  underwriterName: string;
  issuanceDate: string;
}

// 保单批改 (Endorsement)
export interface Endorsement {
  id: string;
  endorsementNo: string;
  policyNo: string;
  type: '增加被保险人' | '调整保额' | '变更地址' | '变更车辆' | '调整保障范围' | '退保暂停';
  originalValue: string;
  newValue: string;
  reason: string;
  premiumDifference: number; // +/- 金额
  effectiveDate: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  createdAt: string;
}

// 计费与账单
export interface Invoice {
  id: string;
  invoiceNo: string;
  policyNo: string;
  customerName: string;
  amount: number;
  dueDate: string;
  paidAmount: number;
  status: 'UNPAID' | 'PARTIAL' | 'PAID' | 'OVERDUE' | 'CANCELLED';
  installmentIndex: number;
  totalInstallments: number;
}

// 理赔报案与案件 (Claims)
export interface ClaimCase {
  id: string;
  claimNo: string;
  policyNo: string;
  customerName: string;
  productName: string;
  accidentDate: string;
  reportDate: string;
  accidentLocation: string;
  accidentType: string;
  description: string;
  estimatedLoss: number;      // 预估损失
  initialReserve: number;     // 初始准备金
  adjustedReserve: number;    // 调整后准备金
  assessedLoss: number;       // 核定赔偿金
  paidAmount: number;         // 已支付金额
  status: 'FNOL' | 'REGISTERED' | 'INVESTIGATING' | 'ASSESSING' | 'APPROVING' | 'PAYING' | 'CLOSED';
  riskScore: number;
  fraudAlerts: string[];
  assignedHandler: string;
  documents: { name: string; url: string; uploadedAt: string }[];
}

// 再保险分保合同
export interface ReinsuranceContract {
  id: string;
  contractNo: string;
  reinsurerName: string; // 再保险人 (e.g. 中国再保险集团, 慕尼黑再保险)
  type: '比例再保险(Quota Share)' | '溢额再保险(Surplus)' | '超额赔款再保险(Excess of Loss)';
  cessionRate: number;   // 分出比例 %
  retentionLimit: number;// 自留额 (¥)
  signedAmount: number;
  cededPremium: number;  // 分保费
  cededClaims: number;   // 分保赔款回收
  effectiveDate: string;
}

// 财务技术会计分录
export interface AccountingEntry {
  id: string;
  entryNo: string;
  businessEventType: '保费收取' | '提取未赚保费准备金' | '理赔赔付' | '提取未决赔款准备金' | '支付渠道佣金' | '再保险结算';
  relatedDocNo: string; // 保单号/理赔号/账单号
  debitAccount: string; // 借方科目
  creditAccount: string;// 贷方科目
  amount: number;
  accountingDate: string;
  operator: string;
  auditStatus: 'VERIFIED' | 'PENDING';
}

// 精算与风控指标
export interface ActuarialMetrics {
  earnedPremium: number;    // 已赚保费
  incurredClaims: number;   // 已发生赔款
  lossRatio: number;        // 赔付率 %
  expenseRatio: number;     // 费用率 %
  combinedRatio: number;    // 综合成本率 %
  solvencyMargin: number;   // 偿付率 %
  ibnrReserve: number;      // IBNR 未决赔款准备金
}

// 系统日志与审计
export interface AuditLog {
  id: string;
  timestamp: string;
  operatorName: string;
  operatorRole: string;
  action: string;
  module: string;
  targetId: string;
  details: string;
  ipAddress: string;
}
