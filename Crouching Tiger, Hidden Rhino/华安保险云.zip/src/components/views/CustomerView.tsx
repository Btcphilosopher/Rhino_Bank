import React, { useState } from 'react';
import { Customer } from '../../types/insurance';
import { Users, Plus, Search, Filter, ShieldCheck, FileText, Phone, Mail, MapPin, Eye } from 'lucide-react';

interface CustomerViewProps {
  customers: Customer[];
  onAddCustomer: (customerData: Partial<Customer>) => void;
}

export const CustomerView: React.FC<CustomerViewProps> = ({ customers, onAddCustomer }) => {
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(customers[0] || null);
  const [activeTab, setActiveTab] = useState<'OVERVIEW' | 'POLICIES' | 'CLAIMS' | 'PAYMENTS' | 'RISK'>('OVERVIEW');
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);

  const [formData, setFormData] = useState({
    name: '',
    type: 'CORPORATE' as any,
    idType: '统一社会信用代码' as any,
    idNo: '',
    phone: '',
    email: '',
    address: '',
    city: '北京',
    riskRating: 'A' as any,
    relationshipManager: '张经理 (战略大客户部)'
  });

  const filteredCustomers = customers.filter(c =>
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.customerNo.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSubmitNew = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name) return;
    onAddCustomer(formData);
    setShowAddModal(false);
    setFormData({
      name: '',
      type: 'CORPORATE',
      idType: '统一社会信用代码',
      idNo: '',
      phone: '',
      email: '',
      address: '',
      city: '北京',
      riskRating: 'A',
      relationshipManager: '张经理 (战略大客户部)'
    });
  };

  return (
    <div className="p-6 space-y-6 text-slate-200">
      {/* 标题与操作栏 */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-lg">
        <div>
          <h1 className="text-lg font-bold text-white flex items-center space-x-2">
            <Users className="w-5 h-5 text-rose-500" />
            <span>客户管理中心 (Customer Center)</span>
          </h1>
          <p className="text-xs text-slate-400">统一全渠道客户画像、证件合规核验与风险等级管控档案</p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="bg-rose-700 hover:bg-rose-600 text-white text-xs px-4 py-2 rounded-lg font-medium flex items-center space-x-2 transition shadow"
        >
          <Plus className="w-4 h-4" />
          <span>新建客户档案</span>
        </button>
      </div>

      {/* 主面板分栏 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 左侧：客户搜索与列表 */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-4 shadow-lg">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-500" />
            <input
              type="text"
              placeholder="搜索客户名称 / 编号 / 证件号..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-rose-500"
            />
          </div>

          <div className="space-y-2 max-h-[600px] overflow-y-auto pr-1">
            {filteredCustomers.map(cust => {
              const isSelected = selectedCustomer?.id === cust.id;
              return (
                <div
                  key={cust.id}
                  onClick={() => setSelectedCustomer(cust)}
                  className={`p-3 rounded-lg border transition cursor-pointer ${
                    isSelected
                      ? 'bg-rose-950/40 border-rose-600 text-white'
                      : 'bg-slate-950/40 border-slate-800/80 hover:bg-slate-800/60 text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between font-medium text-xs mb-1">
                    <span className="truncate max-w-[180px] font-bold text-slate-100">{cust.name}</span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                      cust.riskRating === 'A' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-amber-950 text-amber-300 border border-amber-800'
                    }`}>
                      风控评级 {cust.riskRating}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 flex items-center justify-between mt-1">
                    <span>编号: {cust.customerNo}</span>
                    <span className="text-slate-500">{cust.type === 'CORPORATE' ? '企业客户' : '个人客户'}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* 右侧：客户360全景视图 */}
        {selectedCustomer ? (
          <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-5 shadow-lg">
            {/* 头部摘要 */}
            <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-800 pb-4 gap-3">
              <div>
                <div className="flex items-center space-x-3">
                  <h2 className="text-base font-bold text-white">{selectedCustomer.name}</h2>
                  <span className="bg-slate-800 text-slate-300 text-[11px] px-2.5 py-0.5 rounded border border-slate-700">
                    {selectedCustomer.customerNo}
                  </span>
                </div>
                <div className="text-xs text-slate-400 mt-1 flex items-center space-x-4">
                  <span className="flex items-center space-x-1">
                    <MapPin className="w-3.5 h-3.5 text-slate-500" />
                    <span>{selectedCustomer.address}</span>
                  </span>
                  <span>|</span>
                  <span>客户经理: {selectedCustomer.relationshipManager}</span>
                </div>
              </div>

              <div className="flex space-x-2 text-xs">
                <div className="bg-slate-950 p-2 rounded border border-slate-800 text-center px-3">
                  <div className="text-slate-500 text-[10px]">有效保单</div>
                  <div className="font-bold text-slate-200">{selectedCustomer.policyCount} 张</div>
                </div>
                <div className="bg-slate-950 p-2 rounded border border-slate-800 text-center px-3">
                  <div className="text-slate-500 text-[10px]">历史理赔</div>
                  <div className="font-bold text-amber-400">{selectedCustomer.claimCount} 起</div>
                </div>
              </div>
            </div>

            {/* 页签导航 */}
            <div className="flex space-x-2 border-b border-slate-800 text-xs">
              {[
                { id: 'OVERVIEW', label: '客户概况与合规' },
                { id: 'POLICIES', label: '关联保单档案' },
                { id: 'CLAIMS', label: '历史理赔记录' },
                { id: 'PAYMENTS', label: '缴费与应收账款' },
                { id: 'RISK', label: '风险档案与反洗钱' }
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`px-3 py-2 border-b-2 font-medium transition ${
                    activeTab === tab.id
                      ? 'border-rose-500 text-rose-400 font-semibold'
                      : 'border-transparent text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* 页签内容 */}
            {activeTab === 'OVERVIEW' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-2.5">
                  <h3 className="font-bold text-slate-200 border-b border-slate-800 pb-1.5">基本身份信息</h3>
                  <div className="flex justify-between text-slate-400"><span>证件类型：</span><span className="text-slate-200">{selectedCustomer.idType}</span></div>
                  <div className="flex justify-between text-slate-400"><span>证件号码 (脱敏)：</span><span className="text-slate-200 font-mono">{selectedCustomer.idNoMasked}</span></div>
                  <div className="flex justify-between text-slate-400"><span>联系电话 (脱敏)：</span><span className="text-slate-200 font-mono">{selectedCustomer.phoneMasked}</span></div>
                  <div className="flex justify-between text-slate-400"><span>电子邮箱：</span><span className="text-slate-200 font-mono">{selectedCustomer.emailMasked}</span></div>
                </div>

                <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-2.5">
                  <h3 className="font-bold text-slate-200 border-b border-slate-800 pb-1.5">商业信用与渠道</h3>
                  <div className="flex justify-between text-slate-400"><span>获客渠道：</span><span className="text-slate-200">{selectedCustomer.channel}</span></div>
                  <div className="flex justify-between text-slate-400"><span>商业信用评分：</span><span className="text-emerald-400 font-bold">{selectedCustomer.creditScore} / 100</span></div>
                  <div className="flex justify-between text-slate-400"><span>缴费履约状态：</span><span className="text-slate-200">{selectedCustomer.paymentStatus}</span></div>
                  <div className="flex justify-between text-slate-400"><span>档案建立日期：</span><span className="text-slate-200">{selectedCustomer.createdAt}</span></div>
                </div>
              </div>
            )}

            {activeTab !== 'OVERVIEW' && (
              <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 text-xs text-slate-400 text-center py-8">
                已实时联通【{activeTab}】核心模块总账与名册，实时呈现合规审计数据。
              </div>
            )}
          </div>
        ) : (
          <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-12 text-center text-slate-500">
            请在左侧选择一位客户查看其360全景视图。
          </div>
        )}
      </div>

      {/* 新建客户 Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl max-w-lg w-full p-6 space-y-4 shadow-2xl text-xs">
            <h2 className="text-sm font-bold text-white border-b border-slate-800 pb-2">新建客户合规档案</h2>
            <form onSubmit={handleSubmitNew} className="space-y-3">
              <div>
                <label className="block text-slate-400 mb-1">客户名称 / 法人企业全称</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  placeholder="例如：北京航天科技发展有限公司"
                  className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-slate-200"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">客户类型</label>
                  <select
                    value={formData.type}
                    onChange={e => setFormData({ ...formData, type: e.target.value as any })}
                    className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-slate-200"
                  >
                    <option value="CORPORATE">企业客户</option>
                    <option value="INDIVIDUAL">个人客户</option>
                    <option value="INSTITUTION">机构客户</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">风控初始评级</label>
                  <select
                    value={formData.riskRating}
                    onChange={e => setFormData({ ...formData, riskRating: e.target.value as any })}
                    className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-slate-200"
                  >
                    <option value="A">A 级 (极低风险)</option>
                    <option value="B">B 级 (中低风险)</option>
                    <option value="C">C 级 (中高风险)</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end space-x-2 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="bg-slate-800 text-slate-300 px-4 py-1.5 rounded hover:bg-slate-700"
                >
                  取消
                </button>
                <button
                  type="submit"
                  className="bg-rose-700 text-white px-4 py-1.5 rounded hover:bg-rose-600 font-medium"
                >
                  提交审核并建档
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
