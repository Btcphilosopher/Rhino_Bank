import React from 'react';
import { AlertTriangle, ShieldCheck, TrendingDown, DollarSign } from 'lucide-react';

export const RiskALMView: React.FC = () => {
  return (
    <div className="p-6 space-y-6 text-slate-200">
      <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-lg flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold text-white flex items-center space-x-2">
            <AlertTriangle className="w-5 h-5 text-rose-500" />
            <span>全面风险管理与资产负债管理 (Risk Management & ALM Cockpit)</span>
          </h1>
          <p className="text-xs text-slate-400">久期匹配 (Duration Matching)、流动性风险控制与 C-ROSS 偿付能力风控图谱</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-2">
          <div className="text-slate-400 font-bold">久期缺口分析 (Duration Gap)</div>
          <div className="text-xl font-extrabold text-white font-mono">+0.82 年</div>
          <div className="text-emerald-400">资产久期与负债久期高度匹配</div>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-2">
          <div className="text-slate-400 font-bold">综合偿付能力充足率</div>
          <div className="text-xl font-extrabold text-emerald-400 font-mono">248.5%</div>
          <div className="text-slate-400">监管法定底线: 100%</div>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-2">
          <div className="text-slate-400 font-bold">流动性覆盖率 (LCR)</div>
          <div className="text-xl font-extrabold text-sky-400 font-mono">182.0%</div>
          <div className="text-slate-400">具备强劲赔付资金保障</div>
        </div>
      </div>
    </div>
  );
};
