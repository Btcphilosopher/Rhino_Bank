import React, { useState } from 'react';
import { Globe2, Building2, ShieldCheck, Activity, MapPin } from 'lucide-react';

interface CityNode {
  id: string;
  name: string;
  role: string;
  writtenPremium: string;
  lossRatio: string;
  activePolicies: string;
  riskStatus: 'NORMAL' | 'ELEVATED' | 'HIGH';
  coords: { x: number; y: number };
}

const citiesData: CityNode[] = [
  { id: 'bj', name: '北京总部核心', role: '集团总控与大客户部', writtenPremium: '¥4.2亿元', lossRatio: '51.2%', activePolicies: '8,420 张', riskStatus: 'NORMAL', coords: { x: 68, y: 32 } },
  { id: 'sh', name: '上海陆家嘴分公司', role: '华东金融与航运保险中心', writtenPremium: '¥3.8亿元', lossRatio: '54.6%', activePolicies: '7,150 张', riskStatus: 'NORMAL', coords: { x: 78, y: 55 } },
  { id: 'sz', name: '深圳湾前海分公司', role: '大湾区网络安全与高科技险', writtenPremium: '¥2.6亿元', lossRatio: '42.8%', activePolicies: '5,300 张', riskStatus: 'NORMAL', coords: { x: 71, y: 76 } },
  { id: 'cd', name: '成都天府分公司', role: '西南区域核保与理赔基地', writtenPremium: '¥1.5亿元', lossRatio: '61.0%', activePolicies: '3,200 张', riskStatus: 'ELEVATED', coords: { x: 45, y: 62 } },
  { id: 'hz', name: '杭州钱江分公司', role: '数字经济与普惠金融', writtenPremium: '¥1.9亿元', lossRatio: '48.5%', activePolicies: '4,100 张', riskStatus: 'NORMAL', coords: { x: 76, y: 60 } }
];

export const DigitalTwinView: React.FC = () => {
  const [selectedCity, setSelectedCity] = useState<CityNode>(citiesData[0]);

  return (
    <div className="p-6 space-y-6 text-slate-200">
      <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-lg flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold text-white flex items-center space-x-2">
            <Globe2 className="w-5 h-5 text-rose-500" />
            <span>数字孪生保险公司 (Digital Twin Insurance OS)</span>
          </h1>
          <p className="text-xs text-slate-400">全国分支机构实时承保、理赔与自然灾害暴雨/台风巨灾风险地理孪生监控</p>
        </div>

        <span className="bg-emerald-950 text-emerald-300 border border-emerald-800 px-3 py-1 rounded text-xs font-bold">
          🟢 全国节点实时全双工点对点同步中
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 交互地图容器 */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-6 relative min-h-[420px] shadow-lg overflow-hidden flex flex-col justify-between">
          <div className="text-xs font-bold text-slate-300 mb-2">中国区机构风险地图 (点击节点切入大局)</div>

          {/* 仿真矢量简易地图画布 */}
          <div className="relative w-full h-[320px] bg-slate-950 rounded-lg border border-slate-800/80 p-4 overflow-hidden">
            <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:16px_16px] opacity-40"></div>

            {/* 节点绘制 */}
            {citiesData.map(c => {
              const isSelected = selectedCity.id === c.id;
              return (
                <button
                  key={c.id}
                  onClick={() => setSelectedCity(c)}
                  style={{ left: `${c.coords.x}%`, top: `${c.coords.y}%` }}
                  className="absolute transform -translate-x-1/2 -translate-y-1/2 group focus:outline-none"
                >
                  <span className={`relative flex h-5 w-5 items-center justify-center`}>
                    <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                      isSelected ? 'bg-rose-500' : 'bg-sky-400'
                    }`}></span>
                    <span className={`relative inline-flex rounded-full h-3.5 w-3.5 border border-slate-900 ${
                      isSelected ? 'bg-rose-600' : 'bg-sky-500'
                    }`}></span>
                  </span>
                  <span className={`mt-1 block text-[10px] font-bold px-2 py-0.5 rounded shadow border whitespace-nowrap ${
                    isSelected ? 'bg-rose-950 text-white border-rose-600' : 'bg-slate-900 text-slate-300 border-slate-700'
                  }`}>
                    {c.name}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* 节点详情 Panel */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4 shadow-lg text-xs">
          <div className="border-b border-slate-800 pb-3">
            <div className="flex items-center space-x-2">
              <MapPin className="w-4 h-4 text-rose-500" />
              <h2 className="text-base font-bold text-white">{selectedCity.name}</h2>
            </div>
            <p className="text-slate-400 mt-0.5">{selectedCity.role}</p>
          </div>

          <div className="space-y-3 bg-slate-950 p-4 rounded-lg border border-slate-800">
            <div className="flex justify-between">
              <span className="text-slate-400">已开出原保费：</span>
              <span className="font-bold text-emerald-400 text-sm font-mono">{selectedCity.writtenPremium}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">区域综合赔付率：</span>
              <span className="font-bold text-sky-400 font-mono">{selectedCity.lossRatio}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">在保有效保单：</span>
              <span className="font-bold text-white">{selectedCity.activePolicies}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">风控预警状态：</span>
              <span className="bg-emerald-950 text-emerald-300 px-2 py-0.5 rounded border border-emerald-800 text-[10px]">
                {selectedCity.riskStatus === 'NORMAL' ? '正常 (安全额度内)' : '重点关注'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
