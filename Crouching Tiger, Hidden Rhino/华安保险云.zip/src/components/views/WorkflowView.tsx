import React from 'react';
import { GitBranch, CheckCircle2, Clock, Play } from 'lucide-react';

export const WorkflowView: React.FC = () => {
  return (
    <div className="p-6 space-y-6 text-slate-200">
      <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-lg flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold text-white flex items-center space-x-2">
            <GitBranch className="w-5 h-5 text-rose-500" />
            <span>保险工作流与会签引擎 (BPMN Workflow Orchestrator)</span>
          </h1>
          <p className="text-xs text-slate-400">核保会签、理赔多级终审、保单退保退费审签流程编排与状态机</p>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl space-y-4 shadow-lg text-xs">
        <h2 className="font-bold text-white text-sm border-b border-slate-800 pb-2">大额企财险会签审批流 (Live State Machine)</h2>

        <div className="flex flex-col md:flex-row items-center justify-between gap-3 bg-slate-950 p-4 rounded-lg border border-slate-800">
          <div className="p-3 bg-slate-900 rounded border border-slate-700 text-center w-full md:w-auto">
            <div className="font-bold text-slate-200">1. 提交报价</div>
            <div className="text-[10px] text-emerald-400 mt-1">已通过 (自动)</div>
          </div>
          <span className="text-slate-600 font-bold">➔</span>
          <div className="p-3 bg-slate-900 rounded border border-slate-700 text-center w-full md:w-auto">
            <div className="font-bold text-slate-200">2. 规则引擎校验</div>
            <div className="text-[10px] text-amber-400 mt-1">触发多项拦截</div>
          </div>
          <span className="text-slate-600 font-bold">➔</span>
          <div className="p-3 bg-rose-950/80 rounded border border-rose-600 text-center w-full md:w-auto">
            <div className="font-bold text-rose-200">3. 资深核保师人工会签</div>
            <div className="text-[10px] text-rose-300 mt-1">正在会签中</div>
          </div>
          <span className="text-slate-600 font-bold">➔</span>
          <div className="p-3 bg-slate-900 rounded border border-slate-800 text-center w-full md:w-auto text-slate-500">
            <div className="font-bold">4. 财务收款出单</div>
            <div className="text-[10px]">等待前序节点</div>
          </div>
        </div>
      </div>
    </div>
  );
};
