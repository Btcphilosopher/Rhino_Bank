import React from 'react';
import { Layers, ShieldAlert, CheckCircle2, Building, DollarSign } from 'lucide-react';

export const ReinsuranceView: React.FC = () => {
  return (
    <div className="p-6 space-y-6 text-slate-200">
      <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-lg flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold text-white flex items-center space-x-2">
            <Layers className="w-5 h-5 text-rose-500" />
            <span>再保险运营中心 (Reinsurance Engine & Treaty Cessions)</span>
          </h1>
          <p className="text-xs text-slate-400">比例再保险 (Quota Share)、溢额再保险 (Surplus) 与 超额赔款 (XOL) 自动分保跟保</p>
        </div>

        <div className="bg-slate-950 px-3 py-1.5 rounded border border-slate-800 text-xs">
          <span className="text-slate-400">自留额上限：</span>
          <span className="text-rose-400 font-bold font-mono">¥20,000,000.00 / 案</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-2">
          <div className="text-slate-400 font-bold">中国再保险 (集团) 股份有限公司</div>
          <div className="text-slate-300">合约类型: 企财险成数分保合约 (30% Quota Share)</div>
          <div className="text-emerald-400 font-bold text-sm">已分保保费: ¥25,500,000</div>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-2">
          <div className="text-slate-400 font-bold">慕尼黑再保险公司 (Munich Re)</div>
          <div className="text-slate-300">合约类型: 巨灾超赔再保险 (Catastrophe XOL)</div>
          <div className="text-sky-400 font-bold text-sm">起赔点: ¥50,000,000</div>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-2">
          <div className="text-slate-400 font-bold">瑞士再保险公司 (Swiss Re)</div>
          <div className="text-slate-300">合约类型: 网络安全险溢额分保 (Surplus)</div>
          <div className="text-amber-400 font-bold text-sm">最高容量: ¥200,000,000</div>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl space-y-3 text-xs">
        <div className="font-bold text-slate-100 border-b border-slate-800 pb-2">再保险摊回理赔款明细 (Reinsurance Recoveries)</div>
        <div className="bg-slate-950 p-3 rounded border border-slate-800 flex justify-between items-center">
          <div>
            <div className="font-bold text-slate-200">理赔案号: HA-CLM-2026-009801 (发电机浸水)</div>
            <div className="text-[11px] text-slate-400">总赔付: ¥135,000.00 | 中再分摊 30% = ¥40,500.00</div>
          </div>
          <span className="bg-emerald-950 text-emerald-300 border border-emerald-800 px-3 py-1 rounded font-bold">
            已发摊回通知单
          </span>
        </div>
      </div>
    </div>
  );
};
