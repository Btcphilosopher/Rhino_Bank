import React, { useState } from 'react';
import { InsuranceProduct } from '../../types/insurance';
import { Package, Layers, CheckCircle2, Shield, AlertCircle, Plus, Sliders } from 'lucide-react';

interface ProductViewProps {
  products: InsuranceProduct[];
}

export const ProductView: React.FC<ProductViewProps> = ({ products }) => {
  const [selectedProduct, setSelectedProduct] = useState<InsuranceProduct>(products[0] || null);

  return (
    <div className="p-6 space-y-6 text-slate-200">
      {/* 标题 */}
      <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-lg flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold text-white flex items-center space-x-2">
            <Package className="w-5 h-5 text-rose-500" />
            <span>保险产品工厂 (Product Factory & Configurator)</span>
          </h1>
          <p className="text-xs text-slate-400">
            支持财产险、人身险、网络安全险等多险种条款配置与版本管理 (旧保单自动锁定原版本条款)
          </p>
        </div>

        <button className="bg-rose-700 hover:bg-rose-600 text-white text-xs px-4 py-2 rounded-lg font-medium flex items-center space-x-2 transition shadow">
          <Plus className="w-4 h-4" />
          <span>创建新产品版本</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 产品目录 */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3 shadow-lg">
          <div className="text-xs font-bold text-slate-300 mb-2 border-b border-slate-800 pb-2">
            已发布产品列表 ({products.length})
          </div>

          <div className="space-y-2">
            {products.map(p => {
              const isSelected = selectedProduct?.id === p.id;
              return (
                <div
                  key={p.id}
                  onClick={() => setSelectedProduct(p)}
                  className={`p-3 rounded-lg border transition cursor-pointer ${
                    isSelected
                      ? 'bg-rose-950/40 border-rose-600 text-white'
                      : 'bg-slate-950/40 border-slate-800 hover:bg-slate-800/60 text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between font-bold text-xs mb-1">
                    <span>{p.name}</span>
                    <span className="bg-slate-800 text-rose-400 px-2 py-0.5 rounded text-[10px] font-mono border border-slate-700">
                      {p.version}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-400 mt-1">
                    <span>代码: {p.productNo}</span>
                    <span>基础费率: {p.baseRate}%</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* 产品详情配置板 */}
        {selectedProduct && (
          <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-5 shadow-lg">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <div className="flex items-center space-x-2">
                  <h2 className="text-base font-bold text-white">{selectedProduct.name}</h2>
                  <span className="bg-emerald-950 text-emerald-300 text-[10px] px-2 py-0.5 rounded border border-emerald-800 font-bold">
                    {selectedProduct.status}
                  </span>
                </div>
                <div className="text-xs text-slate-400 mt-1">
                  产品编码：{selectedProduct.productNo} | 绑定版本：{selectedProduct.version} | 适用：{selectedProduct.targetCustomer}
                </div>
              </div>

              <div className="text-right">
                <div className="text-xs text-slate-400">渠道基础佣金率</div>
                <div className="text-sm font-bold text-amber-400">{selectedProduct.commissionRate}%</div>
              </div>
            </div>

            {/* 保障责任清单 */}
            <div className="space-y-3">
              <h3 className="text-xs font-bold text-slate-200 flex items-center space-x-1.5">
                <Shield className="w-4 h-4 text-sky-400" />
                <span>保障责任项与赔偿限额条款 (Coverages)</span>
              </h3>

              <div className="bg-slate-950 border border-slate-800 rounded-lg overflow-hidden text-xs">
                <table className="w-full text-left">
                  <thead className="bg-slate-900 text-slate-400 border-b border-slate-800">
                    <tr>
                      <th className="p-2.5">代码</th>
                      <th className="p-2.5">责任名称</th>
                      <th className="p-2.5">保额限额 (¥)</th>
                      <th className="p-2.5">免赔额 (¥)</th>
                      <th className="p-2.5">性质</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 text-slate-300">
                    {selectedProduct.coverages.map(cov => (
                      <tr key={cov.id}>
                        <td className="p-2.5 font-mono text-slate-400">{cov.code}</td>
                        <td className="p-2.5 font-medium text-slate-100">{cov.name}</td>
                        <td className="p-2.5 font-bold text-emerald-400">¥{cov.limitAmount.toLocaleString()}</td>
                        <td className="p-2.5 text-slate-400">¥{cov.deductible.toLocaleString()}</td>
                        <td className="p-2.5">
                          {cov.isMandatory ? (
                            <span className="text-rose-400 bg-rose-950/60 px-2 py-0.5 rounded border border-rose-900 text-[10px]">主险必选</span>
                          ) : (
                            <span className="text-sky-400 bg-sky-950/60 px-2 py-0.5 rounded border border-sky-900 text-[10px]">可选附加</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* 除外责任 */}
            <div className="space-y-2">
              <h3 className="text-xs font-bold text-slate-200 flex items-center space-x-1.5">
                <AlertCircle className="w-4 h-4 text-amber-400" />
                <span>法定除外责任与免责声明 (Exclusions)</span>
              </h3>
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 flex flex-wrap gap-2 text-xs">
                {selectedProduct.exclusions.map((ex, i) => (
                  <span key={i} className="bg-slate-900 text-slate-300 border border-slate-700 px-2.5 py-1 rounded">
                    🚫 {ex}
                  </span>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
