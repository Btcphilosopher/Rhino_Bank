import React, { useState } from 'react';
import { InsuranceProduct, Customer, Quote } from '../../types/insurance';
import { Calculator, Play, CheckCircle2, ArrowRight, ShieldCheck, FileSpreadsheet } from 'lucide-react';

interface QuoteViewProps {
  products: InsuranceProduct[];
  customers: Customer[];
  onNavigateToUW: (quoteData: any) => void;
}

export const QuoteView: React.FC<QuoteViewProps> = ({ products, customers, onNavigateToUW }) => {
  const [selectedProductId, setSelectedProductId] = useState(products[0]?.id || '');
  const [selectedCustomerId, setSelectedCustomerId] = useState(customers[0]?.id || '');
  const [sumInsured, setSumInsured] = useState(10000000);
  const [riskFactor, setRiskFactor] = useState(1.0);
  const [regionalFactor, setRegionalFactor] = useState(1.0);
  const [ageVehicleFactor, setAgeVehicleFactor] = useState(1.0);
  const [deductibleDiscount, setDeductibleDiscount] = useState(0.95);

  const [calculationResult, setCalculationResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const product = products.find(p => p.id === selectedProductId) || products[0];
  const customer = customers.find(c => c.id === selectedCustomerId) || customers[0];

  const handleCalculate = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/v1/quotes/calculate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productId: selectedProductId,
          customerId: selectedCustomerId,
          customerName: customer?.name,
          sumInsured,
          riskFactor,
          regionalFactor,
          ageVehicleFactor,
          deductibleDiscount
        })
      });
      const data = await res.json();
      if (data.success) {
        setCalculationResult(data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 space-y-6 text-slate-200">
      {/* 标题 */}
      <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-lg">
        <h1 className="text-lg font-bold text-white flex items-center space-x-2">
          <Calculator className="w-5 h-5 text-rose-500" />
          <span>保险定价与报价中心 (Rating & Pricing Engine)</span>
        </h1>
        <p className="text-xs text-slate-400">精确多因子精算定价公式：基础费率 x 风险因子 x 区域因子 x 车辆/行业因子 x 免赔额折扣 = 最终保费</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 输入试算表单 */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4 shadow-lg text-xs">
          <h2 className="font-bold text-slate-100 text-sm border-b border-slate-800 pb-2">报价入参配置</h2>

          <div>
            <label className="block text-slate-400 mb-1">选择投保客户主体</label>
            <select
              value={selectedCustomerId}
              onChange={(e) => setSelectedCustomerId(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-slate-200"
            >
              {customers.map(c => (
                <option key={c.id} value={c.id}>{c.name} ({c.customerNo})</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-slate-400 mb-1">选择目标保险产品 (含版本控制)</label>
            <select
              value={selectedProductId}
              onChange={(e) => setSelectedProductId(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-slate-200"
            >
              {products.map(p => (
                <option key={p.id} value={p.id}>{p.name} [{p.version}] - 基础费率 {p.baseRate}%</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-slate-400 mb-1">申请保障保额 (¥)</label>
            <input
              type="number"
              value={sumInsured}
              onChange={(e) => setSumInsured(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-slate-200 font-mono text-sm"
            />
          </div>

          {/* 多因子滑动调节 */}
          <div className="space-y-3 bg-slate-950 p-3 rounded border border-slate-800">
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>行业/安防风险调整因子:</span>
                <span className="font-bold text-rose-400">{riskFactor}</span>
              </div>
              <input
                type="range" min="0.5" max="2.0" step="0.05"
                value={riskFactor}
                onChange={(e) => setRiskFactor(Number(e.target.value))}
                className="w-full accent-rose-500"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>地域风暴/自然灾害因子:</span>
                <span className="font-bold text-sky-400">{regionalFactor}</span>
              </div>
              <input
                type="range" min="0.8" max="1.5" step="0.05"
                value={regionalFactor}
                onChange={(e) => setRegionalFactor(Number(e.target.value))}
                className="w-full accent-sky-500"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>免赔额折扣系数:</span>
                <span className="font-bold text-emerald-400">{deductibleDiscount}</span>
              </div>
              <input
                type="range" min="0.80" max="1.0" step="0.01"
                value={deductibleDiscount}
                onChange={(e) => setDeductibleDiscount(Number(e.target.value))}
                className="w-full accent-emerald-500"
              />
            </div>
          </div>

          <button
            onClick={handleCalculate}
            disabled={loading}
            className="w-full bg-rose-700 hover:bg-rose-600 text-white font-bold py-2.5 rounded-lg flex items-center justify-center space-x-2 text-xs transition shadow"
          >
            <Play className="w-4 h-4 fill-white" />
            <span>{loading ? '精算引擎算力计算中...' : '运行定价引擎计算最终保费'}</span>
          </button>
        </div>

        {/* 算力公式与输出单据 */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4 shadow-lg text-xs">
          <h2 className="font-bold text-slate-100 text-sm border-b border-slate-800 pb-2">精算定价明细与报价单 (Quote Document)</h2>

          {calculationResult ? (
            <div className="space-y-4">
              <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-2">
                <div className="text-slate-400">单据编号: <span className="text-slate-200 font-mono font-bold">{calculationResult.data.quoteNo}</span></div>
                <div className="text-slate-400">投保主体: <span className="text-slate-200 font-bold">{calculationResult.data.customerName}</span></div>
                <div className="text-slate-400">保障产品: <span className="text-slate-200 font-bold">{calculationResult.data.productName} ({calculationResult.data.productVersion})</span></div>
              </div>

              {/* 拆解步骤 */}
              <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-1.5 font-mono">
                <div className="text-xs font-bold text-slate-300 border-b border-slate-800 pb-1 mb-2">算力轨迹 (Auditable Lineage):</div>
                {calculationResult.breakdown.map((item: string, i: number) => (
                  <div key={i} className="text-slate-400 text-[11px] flex items-center space-x-2">
                    <span className="text-rose-500">•</span>
                    <span>{item}</span>
                  </div>
                ))}
              </div>

              {/* 应缴金额总结 */}
              <div className="bg-gradient-to-r from-rose-950/80 to-slate-950 p-4 rounded-lg border border-rose-800/80 flex items-center justify-between">
                <div>
                  <div className="text-xs text-rose-300 font-bold">最终计算应缴保费</div>
                  <div className="text-xl font-extrabold text-white">
                    ¥{calculationResult.data.finalPremium.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}
                  </div>
                </div>

                <button
                  onClick={() => onNavigateToUW(calculationResult.data)}
                  className="bg-emerald-700 hover:bg-emerald-600 text-white font-bold px-4 py-2 rounded-lg flex items-center space-x-2 transition shadow"
                >
                  <span>提交核保审查</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          ) : (
            <div className="bg-slate-950 p-12 rounded-lg border border-slate-800 text-center text-slate-500">
              请在左侧调整参数并点击「运行定价引擎计算最终保费」。
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
