import React, { useState } from 'react';
import { ClaimCase } from '../../types/insurance';
import { FileSpreadsheet, Plus, AlertOctagon, CheckCircle2, ShieldAlert, DollarSign, Search, FileCheck } from 'lucide-react';

interface ClaimsViewProps {
  claims: ClaimCase[];
  onRegisterFNOL: (fnolData: any) => void;
  onPayClaim: (claimNo: string, assessedLoss: number) => void;
}

export const ClaimsView: React.FC<ClaimsViewProps> = ({ claims, onRegisterFNOL, onPayClaim }) => {
  const [selectedClaim, setSelectedClaim] = useState<ClaimCase | null>(claims[0] || null);
  const [showFnolModal, setShowFnolModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  // FNOL 表单
  const [fnolPolicyNo, setFnolPolicyNo] = useState('HA-POL-2026-009801');
  const [fnolCustomerName, setFnolCustomerName] = useState('华为数字技术 (北京) 有限公司');
  const [fnolLocation, setFnolLocation] = useState('北京市海淀区中关村软件园');
  const [fnolAccidentType, setFnolAccidentType] = useState('暴雨浸水致地下发电机机房受损');
  const [fnolLossEstimate, setFnolLossEstimate] = useState(350000);

  // 核损变动
  const [assessedLossInput, setAssessedLossInput] = useState(330000);

  const filteredClaims = claims.filter(c =>
    c.claimNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.customerName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleFnolSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onRegisterFNOL({
      policyNo: fnolPolicyNo,
      customerName: fnolCustomerName,
      accidentLocation: fnolLocation,
      accidentType: fnolAccidentType,
      description: '现场受损情况严重，已派员前往勘查。',
      estimatedLoss: fnolLossEstimate
    });
    setShowFnolModal(false);
  };

  return (
    <div className="p-6 space-y-6 text-slate-200">
      {/* 标题 */}
      <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-lg flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold text-white flex items-center space-x-2">
            <FileSpreadsheet className="w-5 h-5 text-rose-500" />
            <span>理赔运营中心 (Claims Management Operating Center)</span>
          </h1>
          <p className="text-xs text-slate-400">
            FNOL首报案、反欺诈规则扫描、理赔未决准备金 (Case/IBNR) 自动提存与财务结算划扣
          </p>
        </div>

        <button
          onClick={() => setShowFnolModal(true)}
          className="bg-rose-700 hover:bg-rose-600 text-white text-xs px-4 py-2 rounded-lg font-medium flex items-center space-x-2 transition shadow"
        >
          <Plus className="w-4 h-4" />
          <span>FNOL 出险首报案</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 左侧理赔案列表 */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3 shadow-lg">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-500" />
            <input
              type="text"
              placeholder="搜索理赔案号 / 报案客户..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-200 focus:outline-none"
            />
          </div>

          <div className="space-y-2 max-h-[550px] overflow-y-auto">
            {filteredClaims.map(c => {
              const isSelected = selectedClaim?.id === c.id;
              return (
                <div
                  key={c.id}
                  onClick={() => setSelectedClaim(c)}
                  className={`p-3 rounded-lg border transition cursor-pointer ${
                    isSelected
                      ? 'bg-rose-950/40 border-rose-600 text-white'
                      : 'bg-slate-950/40 border-slate-800 hover:bg-slate-800/60 text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between font-bold text-xs mb-1">
                    <span className="font-mono text-rose-400">{c.claimNo}</span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      c.status === 'CLOSED' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-amber-950 text-amber-300 border border-amber-800'
                    }`}>
                      {c.status === 'CLOSED' ? '已结案划款' : '理算查勘中'}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-200 font-medium truncate">{c.customerName}</div>
                  <div className="text-[10px] text-slate-400 mt-1 flex justify-between">
                    <span>估损: ¥{c.estimatedLoss.toLocaleString()}</span>
                    <span className="text-amber-400">已提取准备金: ¥{c.initialReserve.toLocaleString()}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* 右侧案件理算核损详情 */}
        {selectedClaim ? (
          <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-5 shadow-lg text-xs">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <div className="flex items-center space-x-2">
                  <h2 className="text-base font-bold text-white font-mono">{selectedClaim.claimNo}</h2>
                  <span className="bg-slate-800 text-slate-300 text-[10px] px-2 py-0.5 rounded border border-slate-700">
                    保单: {selectedClaim.policyNo}
                  </span>
                </div>
                <p className="text-slate-400 mt-0.5">报案人: {selectedClaim.customerName} | 出险类型: {selectedClaim.accidentType}</p>
              </div>

              <div className="text-right">
                <div className="text-slate-400">查勘主管</div>
                <div className="font-bold text-slate-200">{selectedClaim.assignedHandler}</div>
              </div>
            </div>

            {/* 反欺诈识别条 */}
            <div className="bg-slate-950 p-3.5 rounded-lg border border-slate-800 space-y-2">
              <div className="flex items-center space-x-2 font-bold text-amber-300">
                <ShieldAlert className="w-4 h-4 text-amber-400" />
                <span>AI 反欺诈风控规则扫描结果 (Risk Score: {selectedClaim.riskScore})</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {selectedClaim.fraudAlerts.map((fa, i) => (
                  <span key={i} className="bg-slate-900 text-slate-300 px-2.5 py-1 rounded border border-slate-700">
                    ✅ {fa}
                  </span>
                ))}
              </div>
            </div>

            {/* 金额理算 */}
            <div className="grid grid-cols-3 gap-3 text-center">
              <div className="bg-slate-950 p-3 rounded border border-slate-800">
                <div className="text-slate-500 text-[10px]">初步报案估损</div>
                <div className="font-bold text-slate-300 text-sm mt-0.5">¥{selectedClaim.estimatedLoss.toLocaleString()}</div>
              </div>
              <div className="bg-slate-950 p-3 rounded border border-slate-800">
                <div className="text-slate-500 text-[10px]">已入账理赔未决准备金</div>
                <div className="font-bold text-amber-400 text-sm mt-0.5">¥{selectedClaim.initialReserve.toLocaleString()}</div>
              </div>
              <div className="bg-slate-950 p-3 rounded border border-slate-800">
                <div className="text-slate-500 text-[10px]">最终定损理算赔付额</div>
                <div className="font-bold text-emerald-400 text-sm mt-0.5">
                  ¥{(selectedClaim.paidAmount || selectedClaim.assessedLoss || selectedClaim.estimatedLoss * 0.95).toLocaleString()}
                </div>
              </div>
            </div>

            {/* 核损与赔付划扣按钮 */}
            {selectedClaim.status !== 'CLOSED' && (
              <div className="bg-slate-950 p-4 rounded-lg border border-rose-900/60 space-y-3">
                <div className="font-bold text-slate-200">理赔核损审批与财务划款</div>
                <div className="flex space-x-3 items-center">
                  <span className="text-slate-400">核定损失赔偿金额 (¥):</span>
                  <input
                    type="number"
                    value={assessedLossInput}
                    onChange={e => setAssessedLossInput(Number(e.target.value))}
                    className="bg-slate-900 border border-slate-700 rounded px-3 py-1.5 text-white font-mono"
                  />
                  <button
                    onClick={() => onPayClaim(selectedClaim.claimNo, assessedLossInput)}
                    className="bg-emerald-700 hover:bg-emerald-600 text-white font-bold px-4 py-1.5 rounded flex items-center space-x-1.5 transition"
                  >
                    <DollarSign className="w-4 h-4" />
                    <span>核准定损并直接划款结案</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-12 text-center text-slate-500">
            请在左侧选择一件理赔案进行核损与查勘。
          </div>
        )}
      </div>

      {/* FNOL Modal */}
      {showFnolModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl max-w-lg w-full p-6 space-y-4 shadow-2xl text-xs text-slate-200">
            <h2 className="text-sm font-bold text-white border-b border-slate-800 pb-2">出险首报案登记 (FNOL)</h2>
            <form onSubmit={handleFnolSubmit} className="space-y-3">
              <div>
                <label className="block text-slate-400 mb-1">关联保险单号</label>
                <input
                  type="text"
                  required
                  value={fnolPolicyNo}
                  onChange={e => setFnolPolicyNo(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">报案客户全称</label>
                <input
                  type="text"
                  required
                  value={fnolCustomerName}
                  onChange={e => setFnolCustomerName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">出险地点与原因</label>
                <input
                  type="text"
                  required
                  value={fnolAccidentType}
                  onChange={e => setFnolAccidentType(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">初步估损金额 (¥)</label>
                <input
                  type="number"
                  required
                  value={fnolLossEstimate}
                  onChange={e => setFnolLossEstimate(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 font-mono"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-3">
                <button
                  type="button"
                  onClick={() => setShowFnolModal(false)}
                  className="bg-slate-800 text-slate-300 px-4 py-1.5 rounded"
                >
                  取消
                </button>
                <button
                  type="submit"
                  className="bg-rose-700 text-white px-4 py-1.5 rounded font-medium"
                >
                  登记并提存准备金
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
