import React from 'react';
import { Building2, Smartphone, Users, Briefcase } from 'lucide-react';

export const PortalsView: React.FC = () => {
  return (
    <div className="p-6 space-y-6 text-slate-200">
      <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-lg flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold text-white flex items-center space-x-2">
            <Building2 className="w-5 h-5 text-rose-500" />
            <span>多端门户架构 (Omni-channel Portal Suite)</span>
          </h1>
          <p className="text-xs text-slate-400">支持保险代理人 App、经纪人 Portal、企业客户自助服务与个人客户微端</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-3">
          <div className="flex items-center space-x-2 font-bold text-white">
            <Smartphone className="w-4 h-4 text-rose-400" />
            <span>保险代理人 APP 移动端</span>
          </div>
          <p className="text-slate-400">现场出单、展业二维码、移动端费率试算、佣金秒级提现</p>
          <span className="bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded text-[10px]">
            当前活跃代理人: 1,850 人
          </span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-3">
          <div className="flex items-center space-x-2 font-bold text-white">
            <Briefcase className="w-4 h-4 text-sky-400" />
            <span>合作经纪渠道 Portal</span>
          </div>
          <p className="text-slate-400">批量 API 招投标报价对接、大型工程团险在线投保与对账系统</p>
          <span className="bg-sky-950 text-sky-300 border border-sky-800 px-2 py-0.5 rounded text-[10px]">
            已接入经纪公司: 42 家
          </span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-3">
          <div className="flex items-center space-x-2 font-bold text-white">
            <Building2 className="w-4 h-4 text-amber-400" />
            <span>企业客户自助 Portal</span>
          </div>
          <p className="text-slate-400">企业电子保单下载、保单在线批改加保、在线 FNOL 报案与进度跟踪</p>
          <span className="bg-amber-950 text-amber-300 border border-amber-800 px-2 py-0.5 rounded text-[10px]">
            在保企业用户: 3,420 家
          </span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-3">
          <div className="flex items-center space-x-2 font-bold text-white">
            <Users className="w-4 h-4 text-purple-400" />
            <span>个人 C 端小程序/微端</span>
          </div>
          <p className="text-slate-400">家财险与车险一键续保、拍照定损理赔、电子发票与批条查询</p>
          <span className="bg-purple-950 text-purple-300 border border-purple-800 px-2 py-0.5 rounded text-[10px]">
            月活终端: 12.8 万
          </span>
        </div>
      </div>
    </div>
  );
};
