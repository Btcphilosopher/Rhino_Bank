import React, { useState } from 'react';
import { UWTask, UWResult } from '../../types/insurance';
import { ShieldCheck, AlertTriangle, CheckCircle2, XCircle, FileText, Bot, UserCheck, FlaskConical, Play } from 'lucide-react';

interface UnderwritingViewProps {
  tasks: UWTask[];
  onIssuePolicy: (quoteData: any) => void;
}

export const UnderwritingView: React.FC<UnderwritingViewProps> = ({ tasks, onIssuePolicy }) => {
  const [activeTab, setActiveTab] = useState<'WORKBENCH' | 'RULE_LAB'>('WORKBENCH');
  const [selectedTask, setSelectedTask] = useState<UWTask | null>(tasks[0] || null);

  // 规则实验室输入
  const [labSumInsured, setLabSumInsured] = useState(15000000);
  const [labRiskRating, setLabRiskRating] = useState<'A' | 'B' | 'C' | 'D'>('C');
  const [labClaimCount, setLabClaimCount] = useState(3);
  const [labResult, setLabResult] = useState<any>(null);

  const handleRunRuleLab = () => {
    let triggered = [];
    let score = 20;

    if (labSumInsured > 10000000) {
      triggered.push({ ruleId: 'UW-R-01', description: '保额超过 ¥10,000,000 大额阈值', action: '要求转高级核保专家并过会' });
      score += 35;
    }
    if (labRiskRating === 'C' || labRiskRating === 'D') {
      triggered.push({ ruleId: 'UW-R-02', description: `客户风险评级为 ${labRiskRating} 级`, action: '要求补充前3年财务审计报告与现场安评文件' });
      score += 30;
    }
    if (labClaimCount >= 2) {
      triggered.push({ ruleId: 'UW-R-03', description: `历史出险件数超过 ${labClaimCount} 起`, action: '建议费率加费 15% 并提升免赔额' });
      score += 25;
    }

    setLabResult({
      score,
      riskLevel: score >= 70 ? 'CRITICAL' : score >= 45 ? 'HIGH' : 'MEDIUM',
      triggeredRules: triggered,
      recommendation: score >= 70 ? 'MANUAL_AUDIT' : 'RATE_LOADING'
    });
  };

  const handleApprove = (task: UWTask) => {
    onIssuePolicy({
      quoteNo: task.quoteId,
      customerName: task.customerName,
      productName: task.productName,
      sumInsured: task.sumInsured,
      annualPremium: task.calculatedPremium
    });
  };

  return (
    <div className="p-6 space-y-6 text-slate-200">
      {/* 标题栏 */}
      <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-lg flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold text-white flex items-center space-x-2">
            <ShieldCheck className="w-5 h-5 text-rose-500" />
            <span>核保工作台与规则实验室 (Underwriting Workbench & Rule Lab)</span>
          </h1>
          <p className="text-xs text-slate-400">
            AI/规则系统仅提供风险评级与裁决建议；高影响核保决议必须由授权核保专家人工确认。
          </p>
        </div>

        <div className="flex space-x-2">
          <button
            onClick={() => setActiveTab('WORKBENCH')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${
              activeTab === 'WORKBENCH' ? 'bg-rose-700 text-white' : 'bg-slate-800 text-slate-300'
            }`}
          >
            核保审查工作台
          </button>
          <button
            onClick={() => setActiveTab('RULE_LAB')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition flex items-center space-x-1.5 ${
              activeTab === 'RULE_LAB' ? 'bg-rose-700 text-white' : 'bg-slate-800 text-slate-300'
            }`}
          >
            <FlaskConical className="w-3.5 h-3.5" />
            <span>核保规则测试实验室</span>
          </button>
        </div>
      </div>

      {activeTab === 'WORKBENCH' ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* 任务列表 */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3 shadow-lg">
            <div className="text-xs font-bold text-slate-300 border-b border-slate-800 pb-2 flex justify-between items-center">
              <span>待核保审查任务 ({tasks.length})</span>
              <span className="text-amber-400 font-normal">须人工授权确认</span>
            </div>

            <div className="space-y-2">
              {tasks.map(t => {
                const isSelected = selectedTask?.id === t.id;
                return (
                  <div
                    key={t.id}
                    onClick={() => setSelectedTask(t)}
                    className={`p-3 rounded-lg border transition cursor-pointer ${
                      isSelected
                        ? 'bg-rose-950/40 border-rose-600 text-white'
                        : 'bg-slate-950/40 border-slate-800 hover:bg-slate-800/60 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between font-bold text-xs mb-1">
                      <span>{t.customerName}</span>
                      <span className={`px-2 py-0.5 rounded text-[10px] ${
                        t.riskLevel === 'CRITICAL' ? 'bg-rose-950 text-rose-300 border border-rose-800' : 'bg-amber-950 text-amber-300 border border-amber-800'
                      }`}>
                        风险分: {t.riskScore}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-400 mt-1 flex justify-between">
                      <span>{t.productName}</span>
                      <span className="text-emerald-400 font-bold">¥{t.calculatedPremium.toLocaleString()}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 核保评估详情区 */}
          {selectedTask ? (
            <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-5 shadow-lg text-xs">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div>
                  <h2 className="text-base font-bold text-white">{selectedTask.customerName} - 承保核保审查</h2>
                  <p className="text-slate-400 mt-0.5">任务编号: {selectedTask.taskNo} | 申请保额: ¥{selectedTask.sumInsured.toLocaleString()}</p>
                </div>

                <div className="text-right">
                  <div className="text-slate-400">系统裁决推荐</div>
                  <div className="font-bold text-amber-300 text-sm">{selectedTask.aiRecommendation}</div>
                </div>
              </div>

              {/* 命中规则列表 */}
              <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-2">
                <div className="font-bold text-slate-200 mb-1 flex items-center space-x-1.5">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  <span>核保规则引擎触发记录 ({selectedTask.triggeredRules.length} 条)</span>
                </div>
                {selectedTask.triggeredRules.map((rule, idx) => (
                  <div key={idx} className="p-2.5 bg-slate-900 rounded border border-slate-800/80 flex items-center justify-between">
                    <div>
                      <span className="font-mono text-rose-400 font-bold mr-2">[{rule.ruleId}]</span>
                      <span className="text-slate-300">{rule.description}</span>
                    </div>
                    <span className="text-amber-400 text-[11px]">{rule.action}</span>
                  </div>
                ))}
              </div>

              {/* AI 助手风险推理 */}
              <div className="bg-slate-950 p-4 rounded-lg border border-sky-900/60 space-y-2">
                <div className="font-bold text-sky-300 flex items-center space-x-1.5">
                  <Bot className="w-4 h-4 text-sky-400" />
                  <span>华安智保助手 · 风险推演与建议分析</span>
                </div>
                <div className="text-slate-300 leading-relaxed bg-slate-900 p-3 rounded border border-slate-800">
                  {selectedTask.aiReasoning}
                </div>
                <div className="text-[10px] text-amber-400 font-semibold mt-1">
                  【合规与授权提示】：AI与规则仅供风险决策辅助参考，高额承保决议须由授权核保员人工盖章放行。
                </div>
              </div>

              {/* 人工决定操作 */}
              <div className="pt-2 flex justify-end space-x-3 border-t border-slate-800">
                <button className="bg-slate-800 text-rose-400 hover:bg-rose-950/80 px-4 py-2 rounded-lg font-medium border border-rose-900 transition">
                  拒绝承保 (Decline)
                </button>
                <button
                  onClick={() => handleApprove(selectedTask)}
                  className="bg-emerald-700 hover:bg-emerald-600 text-white font-bold px-5 py-2 rounded-lg flex items-center space-x-2 transition shadow"
                >
                  <UserCheck className="w-4 h-4" />
                  <span>人工核准授权并放行出单</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-12 text-center text-slate-500">
              请选择待核保任务进行审查。
            </div>
          )}
        </div>
      ) : (
        /* 规则实验室 (Rule Test Lab) */
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-5 shadow-lg text-xs">
          <h2 className="text-sm font-bold text-white border-b border-slate-800 pb-2">核保规则模拟沙盒测试</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-slate-400 mb-1">试算保额 (¥)</label>
              <input
                type="number"
                value={labSumInsured}
                onChange={e => setLabSumInsured(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-slate-200 font-mono"
              />
            </div>
            <div>
              <label className="block text-slate-400 mb-1">客户风险评级</label>
              <select
                value={labRiskRating}
                onChange={e => setLabRiskRating(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-slate-200"
              >
                <option value="A">A 级 (优良)</option>
                <option value="B">B 级 (正常)</option>
                <option value="C">C 级 (高风险)</option>
                <option value="D">D 级 (极高风险)</option>
              </select>
            </div>
            <div>
              <label className="block text-slate-400 mb-1">历史理赔件数</label>
              <input
                type="number"
                value={labClaimCount}
                onChange={e => setLabClaimCount(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-slate-200 font-mono"
              />
            </div>
          </div>

          <button
            onClick={handleRunRuleLab}
            className="bg-rose-700 hover:bg-rose-600 text-white font-bold px-5 py-2.5 rounded-lg flex items-center space-x-2 transition"
          >
            <Play className="w-4 h-4 fill-white" />
            <span>执行规则沙盒演算</span>
          </button>

          {labResult && (
            <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-3 font-mono">
              <div className="text-slate-200 font-bold text-sm">沙盒演算输出结果：</div>
              <div className="text-slate-300">综合风险得分: <span className="text-rose-400 font-bold">{labResult.score}</span> | 评级: <span className="text-amber-400 font-bold">{labResult.riskLevel}</span></div>
              <div className="text-slate-400">建议裁决: <span className="text-emerald-400 font-bold">{labResult.recommendation}</span></div>
              <div className="space-y-1 pt-2 border-t border-slate-800">
                <div className="text-slate-400 text-[11px] mb-1">命中规则列表：</div>
                {labResult.triggeredRules.map((r: any, idx: number) => (
                  <div key={idx} className="text-slate-300 text-[11px]">
                    • [{r.ruleId}] {r.description} → {r.action}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
