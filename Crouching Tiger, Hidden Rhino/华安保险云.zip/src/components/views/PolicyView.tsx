import React, { useState } from 'react';
import { Policy } from '../../types/insurance';
import { FileText, FileEdit, RotateCw, Search, ShieldCheck, Download, ExternalLink, Calendar } from 'lucide-react';

interface PolicyViewProps {
  policies: Policy[];
}

export const PolicyView: React.FC<PolicyViewProps> = ({ policies }) => {
  const [selectedPolicy, setSelectedPolicy] = useState<Policy | null>(policies[0] || null);
  const [activeTab, setActiveTab] = useState<'LIST' | 'ENDORSEMENT' | 'RENEWAL'>('LIST');
  const [searchTerm, setSearchTerm] = useState('');

  // 批改申请表单
  const [endorsementType, setEndorsementType] = useState('保额调整与加保');
  const [endorsementNote, setEndorsementNote] = useState('企业新增一期服务器机房，申请将保额提升 20%');

  const filteredPolicies = policies.filter(p =>
    p.policyNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.customerName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-6 space-y-6 text-slate-200">
      {/* 标题 */}
      <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-lg flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold text-white flex items-center space-x-2">
            <FileText className="w-5 h-5 text-rose-500" />
            <span>保单管理与全生命周期中心 (Policy Lifecycle Administration)</span>
          </h1>
          <p className="text-xs text-slate-400">电子保单签发、财务/非财务批改 (Endorsements) 与 30/60/90 天续保管理</p>
        </div>

        <div className="flex space-x-2">
          <button
            onClick={() => setActiveTab('LIST')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${
              activeTab === 'LIST' ? 'bg-rose-700 text-white' : 'bg-slate-800 text-slate-300'
            }`}
          >
            有效保单总览
          </button>
          <button
            onClick={() => setActiveTab('ENDORSEMENT')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition flex items-center space-x-1 ${
              activeTab === 'ENDORSEMENT' ? 'bg-rose-700 text-white' : 'bg-slate-800 text-slate-300'
            }`}
          >
            <FileEdit className="w-3.5 h-3.5" />
            <span>保单批改 (Endorsements)</span>
          </button>
          <button
            onClick={() => setActiveTab('RENEWAL')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition flex items-center space-x-1 ${
              activeTab === 'RENEWAL' ? 'bg-rose-700 text-white' : 'bg-slate-800 text-slate-300'
            }`}
          >
            <RotateCw className="w-3.5 h-3.5" />
            <span>续保管理</span>
          </button>
        </div>
      </div>

      {activeTab === 'LIST' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* 左侧列表 */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3 shadow-lg">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-500" />
              <input
                type="text"
                placeholder="搜索保单号 / 投保企业..."
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-200 focus:outline-none"
              />
            </div>

            <div className="space-y-2 max-h-[550px] overflow-y-auto">
              {filteredPolicies.map(pol => {
                const isSelected = selectedPolicy?.id === pol.id;
                return (
                  <div
                    key={pol.id}
                    onClick={() => setSelectedPolicy(pol)}
                    className={`p-3 rounded-lg border transition cursor-pointer ${
                      isSelected
                        ? 'bg-rose-950/40 border-rose-600 text-white'
                        : 'bg-slate-950/40 border-slate-800 hover:bg-slate-800/60 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between font-bold text-xs mb-1">
                      <span className="font-mono text-rose-400">{pol.policyNo}</span>
                      <span className="bg-emerald-950 text-emerald-300 px-2 py-0.5 rounded text-[10px] border border-emerald-800 font-bold">
                        {pol.status}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-300 truncate font-medium">{pol.customerName}</div>
                    <div className="text-[10px] text-slate-400 mt-1 flex justify-between">
                      <span>{pol.productName}</span>
                      <span className="text-white font-bold">¥{pol.annualPremium.toLocaleString()}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 详情卡 */}
          {selectedPolicy ? (
            <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-5 shadow-lg text-xs">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div>
                  <div className="flex items-center space-x-2">
                    <h2 className="text-base font-bold text-white font-mono">{selectedPolicy.policyNo}</h2>
                    <span className="bg-sky-950 text-sky-300 text-[10px] px-2 py-0.5 rounded border border-sky-800">
                      电子保单已签发
                    </span>
                  </div>
                  <p className="text-slate-400 mt-0.5">关联报价单: {selectedPolicy.quoteNo} | 投保客户: {selectedPolicy.customerName}</p>
                </div>

                <button className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded font-medium flex items-center space-x-1.5 border border-slate-700">
                  <Download className="w-3.5 h-3.5" />
                  <span>下载加密PDF保单凭证</span>
                </button>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div className="bg-slate-950 p-3 rounded border border-slate-800">
                  <div className="text-slate-500 text-[10px]">保障总金额 (Sum Insured)</div>
                  <div className="font-bold text-emerald-400 text-sm mt-0.5">¥{selectedPolicy.sumInsured.toLocaleString()}</div>
                </div>
                <div className="bg-slate-950 p-3 rounded border border-slate-800">
                  <div className="text-slate-500 text-[10px]">年度承保保费</div>
                  <div className="font-bold text-rose-400 text-sm mt-0.5">¥{selectedPolicy.annualPremium.toLocaleString()}</div>
                </div>
                <div className="bg-slate-950 p-3 rounded border border-slate-800">
                  <div className="text-slate-500 text-[10px]">保险期间</div>
                  <div className="font-medium text-slate-300 text-[11px] mt-0.5">{selectedPolicy.startDate} 至 {selectedPolicy.endDate}</div>
                </div>
                <div className="bg-slate-950 p-3 rounded border border-slate-800">
                  <div className="text-slate-500 text-[10px]">缴费状态 / 方式</div>
                  <div className="font-bold text-sky-400 text-sm mt-0.5">{selectedPolicy.paymentStatus} ({selectedPolicy.paymentPlan})</div>
                </div>
              </div>

              <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-2">
                <div className="font-bold text-slate-200">受益人与签发信息</div>
                <div className="text-slate-400">第一法定受益人: {selectedPolicy.beneficiaries.join(', ')}</div>
                <div className="text-slate-400">签约销售渠道: {selectedPolicy.channel}</div>
                <div className="text-slate-400">签发核保人: {selectedPolicy.underwriterName} ({selectedPolicy.issuanceDate})</div>
              </div>
            </div>
          ) : (
            <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-12 text-center text-slate-500">
              请在左侧选择一张保单查看详细属性。
            </div>
          )}
        </div>
      )}

      {activeTab === 'ENDORSEMENT' && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-4 shadow-lg text-xs">
          <h2 className="text-sm font-bold text-white border-b border-slate-800 pb-2">保单批改中心 (Endorsements)</h2>
          <p className="text-slate-400">支持财务批改（保额增加/退费）与非财务批改（受益人更名/地址变更）。批改将同步生成补充财技分录。</p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-slate-400 mb-1">选择目标保单</label>
              <select className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-slate-200">
                {policies.map(p => (
                  <option key={p.id} value={p.id}>{p.policyNo} - {p.customerName}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-slate-400 mb-1">批改类型</label>
              <select value={endorsementType} onChange={e => setEndorsementType(e.target.value)} className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-slate-200">
                <option value="保额调整与加保">财务类：保额调整与追加保费</option>
                <option value="特别约定增补">条款类：增补特约风险保护条款</option>
                <option value="更换受益人与地址">非财务类：更新受益人与办公地址</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-slate-400 mb-1">批改批条说明 (Endorsement Statement)</label>
            <textarea
              rows={3}
              value={endorsementNote}
              onChange={e => setEndorsementNote(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-slate-200"
            />
          </div>

          <button className="bg-rose-700 hover:bg-rose-600 text-white font-bold px-5 py-2 rounded-lg">
            提交批改批条申请并过账
          </button>
        </div>
      )}

      {activeTab === 'RENEWAL' && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-4 shadow-lg text-xs">
          <h2 className="text-sm font-bold text-white border-b border-slate-800 pb-2">续保任务队列 (30/60/90 天提醒)</h2>
          <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 text-slate-400 space-y-2">
            <div className="flex justify-between items-center bg-slate-900 p-3 rounded border border-slate-800">
              <div>
                <div className="font-bold text-slate-200">HA-POL-2026-009801 (华为数字技术)</div>
                <div className="text-[11px] text-slate-400">距离到期还剩 28 天 · 建议无赔款优待折扣 (NCD) 85 折续保</div>
              </div>
              <button className="bg-rose-700 hover:bg-rose-600 text-white px-3 py-1.5 rounded font-medium">
                一键生成续保报价单
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
