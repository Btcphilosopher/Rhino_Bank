import React from 'react';
import { Lock, ShieldCheck, FileText, CheckCircle2 } from 'lucide-react';

export const SystemAuditView: React.FC = () => {
  return (
    <div className="p-6 space-y-6 text-slate-200">
      <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-lg flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold text-white flex items-center space-x-2">
            <Lock className="w-5 h-5 text-rose-500" />
            <span>系统权限与合规审计日志 (RBAC & Compliance Audit)</span>
          </h1>
          <p className="text-xs text-slate-400">满足国家等保三级与金融数据安全标准，不可篡改的操作流水审计链</p>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl space-y-3 shadow-lg text-xs">
        <div className="font-bold text-slate-200 border-b border-slate-800 pb-2">不可篡改审计操作日志 (Audit Trail)</div>
        <div className="space-y-2 font-mono">
          <div className="bg-slate-950 p-2.5 rounded border border-slate-800 flex justify-between">
            <span className="text-slate-300">[2026-09-17 09:30:12] 用户【张核保】核准批出保单 HA-POL-2026-009801</span>
            <span className="text-emerald-400">操作结果: SUCCESS</span>
          </div>
          <div className="bg-slate-950 p-2.5 rounded border border-slate-800 flex justify-between">
            <span className="text-slate-300">[2026-09-17 09:28:05] 系统定价引擎触发试算 报价单 QT-2026-88091</span>
            <span className="text-emerald-400">操作结果: SUCCESS</span>
          </div>
          <div className="bg-slate-950 p-2.5 rounded border border-slate-800 flex justify-between">
            <span className="text-slate-300">[2026-09-17 09:15:40] 用户【赵理赔】审核理赔案 HA-CLM-2026-009801 并划款</span>
            <span className="text-emerald-400">操作结果: SUCCESS</span>
          </div>
        </div>
      </div>
    </div>
  );
};
