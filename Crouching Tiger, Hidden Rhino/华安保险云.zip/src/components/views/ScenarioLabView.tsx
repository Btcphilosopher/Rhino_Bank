import React, { useState } from 'react';
import { FlaskConical, AlertTriangle, Play, CheckCircle2, TrendingDown, RefreshCw } from 'lucide-react';

export const ScenarioLabView: React.FC = () => {
  const [typhoonSeverity, setTyphoonSeverity] = useState('CAT3_TYPHOON');
  const [rateShift, setRateShift] = useState(-50); // bps
  const [simulationRan, setSimulationRan] = useState(false);

  return (
    <div className="p-6 space-y-6 text-slate-200">
      <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-lg flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold text-white flex items-center space-x-2">
            <FlaskConical className="w-5 h-5 text-rose-500" />
            <span>情景压力测试实验室 (Scenario Stress Testing Lab)</span>
          </h1>
          <p className="text-xs text-slate-400">
            模拟台风巨灾、极端暴雨、利率下行与通胀对偿付能力充足率 (Solvency II / C-ROSS) 的冲击
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl space-y-4 shadow-lg text-xs">
          <h2 className="font-bold text-slate-100 text-sm border-b border-slate-800 pb-2">压力测试宏观参数设定</h2>

          <div>
            <label className="block text-slate-400 mb-1">沿海巨灾台风/暴雨冲击情景</label>
            <select
              value={typhoonSeverity}
              onChange={e => setTyphoonSeverity(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-slate-200"
            >
              <option value="CAT2_TYPHOON">2级台风 - 沿海厂房水浸 (预计总赔款 ¥80,000,000)</option>
              <option value="CAT3_TYPHOON">3级强台风 - 东南沿海连带遮蔽 (预计总赔款 ¥220,000,000)</option>
              <option value="CAT5_SUPER">5级超强台风 - 极端50年一遇 (预计总赔款 ¥650,000,000)</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-400 mb-1">无风险利率与国债收益率变动 (bps)</label>
            <input
              type="number"
              value={rateShift}
              onChange={e => setRateShift(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-slate-200 font-mono"
            />
          </div>

          <button
            onClick={() => setSimulationRan(true)}
            className="w-full bg-rose-700 hover:bg-rose-600 text-white font-bold py-2.5 rounded-lg flex items-center justify-center space-x-2 transition shadow"
          >
            <Play className="w-4 h-4 fill-white" />
            <span>运行偿付能力压力测试矩阵</span>
          </button>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl space-y-4 shadow-lg text-xs">
          <h2 className="font-bold text-slate-100 text-sm border-b border-slate-800 pb-2">压力测试输出对照 (Benchmark vs Stress)</h2>

          <div className="space-y-3">
            <div className="bg-slate-950 p-3 rounded border border-slate-800 flex justify-between items-center">
              <div>
                <div className="text-slate-400">基准核心偿付能力充足率</div>
                <div className="text-lg font-bold text-emerald-400 font-mono">248.5%</div>
              </div>
              <div className="text-right">
                <div className="text-slate-400">压力测试后估计充足率</div>
                <div className={`text-lg font-bold font-mono ${simulationRan ? 'text-amber-400' : 'text-slate-500'}`}>
                  {simulationRan ? '182.4% (满足合规底线 100%)' : '待测算'}
                </div>
              </div>
            </div>

            {simulationRan && (
              <div className="bg-slate-950 p-3.5 rounded border border-amber-900/60 text-slate-300 space-y-2">
                <div className="font-bold text-amber-300 flex items-center space-x-1.5">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  <span>风险应对策略建议：</span>
                </div>
                <div>1. 触发超额赔款再保险 (XOL Cat Treaty) 追偿机制，转嫁 ¥150,000,000 赔款限额。</div>
                <div>2. 提升固定收益类高评级国债配比以降低利差损风险。</div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
