import React from 'react';
import { TrendingUp, Activity, BarChart2, DollarSign } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const actuarialLossRatioData = [
  { lob: '企财险', 赔付率: 52.4, 费用率: 35.1, 综合成本率: 87.5 },
  { lob: '车险', 赔付率: 68.2, 费用率: 26.5, 综合成本率: 94.7 },
  { lob: '责任险', 赔付率: 45.0, 费用率: 38.0, 综合成本率: 83.0 },
  { lob: '重疾险', 赔付率: 61.5, 费用率: 30.2, 综合成本率: 91.7 },
  { lob: '网络险', 赔付率: 22.0, 费用率: 42.0, 综合成本率: 64.0 }
];

export const ActuarialView: React.FC = () => {
  return (
    <div className="p-6 space-y-6 text-slate-200">
      <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-lg flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold text-white flex items-center space-x-2">
            <TrendingUp className="w-5 h-5 text-rose-500" />
            <span>精算评估与组合分析 (Actuarial & Portfolio Analytics)</span>
          </h1>
          <p className="text-xs text-slate-400">大数法则测算、赔付率 (Loss Ratio)、费用率 (Expense Ratio) 与 IBNR 三角网测算</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-lg">
          <h2 className="text-sm font-bold text-white mb-3">各险种综合成本率 (Combined Ratio) 拆解</h2>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={actuarialLossRatioData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="lob" stroke="#94A3B8" fontSize={11} />
                <YAxis stroke="#94A3B8" fontSize={11} />
                <Tooltip contentStyle={{ backgroundColor: '#0F172A', borderColor: '#334155', color: '#F8FAFC', fontSize: '11px' }} />
                <Bar dataKey="赔付率" stackId="a" fill="#BE123C" />
                <Bar dataKey="费用率" stackId="a" fill="#0284C7" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-lg text-xs space-y-3">
          <h2 className="font-bold text-white border-b border-slate-800 pb-2">IBNR 三角网评估 (Chain Ladder)</h2>
          <div className="bg-slate-950 p-3 rounded border border-slate-800 font-mono space-y-1">
            <div className="text-slate-400">事故年 2024: ¥12,500,000 (已终结 98%)</div>
            <div className="text-slate-400">事故年 2025: ¥18,200,000 (已终结 85%)</div>
            <div className="text-emerald-400 font-bold">事故年 2026: 估计最终赔款 ¥24,000,000</div>
          </div>
        </div>
      </div>
    </div>
  );
};
