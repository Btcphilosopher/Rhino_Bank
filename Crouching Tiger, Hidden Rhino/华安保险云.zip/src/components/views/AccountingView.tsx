import React from 'react';
import { AccountingEntry } from '../../types/insurance';
import { BookOpenCheck, CheckCircle2, ArrowDownUp, FileSpreadsheet, Layers } from 'lucide-react';

interface AccountingViewProps {
  entries: AccountingEntry[];
}

export const AccountingView: React.FC<AccountingViewProps> = ({ entries }) => {
  const totalDebits = entries.reduce((acc, e) => acc + e.amount, 0);

  return (
    <div className="p-6 space-y-6 text-slate-200">
      {/* 标题 */}
      <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-lg flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold text-white flex items-center space-x-2">
            <BookOpenCheck className="w-5 h-5 text-rose-500" />
            <span>财务与技术会计分录总账 (Insurance Technical Accounting Ledger)</span>
          </h1>
          <p className="text-xs text-slate-400">
            完全遵循 CAS 25 (中国保险会计准则) 与 IFRS 17 国际财务报告准则，借贷平衡自动过账
          </p>
        </div>

        <div className="bg-slate-950 px-4 py-2 rounded-lg border border-slate-800 text-right">
          <div className="text-[10px] text-slate-400">会计过账总流水 (借贷平衡)</div>
          <div className="text-sm font-extrabold text-emerald-400 font-mono">¥{totalDebits.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}</div>
        </div>
      </div>

      {/* 会计科目摘要板 */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-xl">
          <div className="text-slate-400 text-[11px]">1002 银行存款账户</div>
          <div className="text-base font-bold text-white mt-1">¥1,280,500,000.00</div>
          <div className="text-[10px] text-emerald-400 mt-0.5">流转资金安全覆盖</div>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-xl">
          <div className="text-slate-400 text-[11px]">2601 未赚保费准备金 (UPR)</div>
          <div className="text-base font-bold text-sky-400 mt-1">¥452,000,000.00</div>
          <div className="text-[10px] text-slate-400 mt-0.5">1/365 逐日递延计提</div>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-xl">
          <div className="text-slate-400 text-[11px]">2602 未决赔款准备金 (IBNR/Case)</div>
          <div className="text-base font-bold text-amber-400 mt-1">¥182,000,000.00</div>
          <div className="text-[10px] text-slate-400 mt-0.5">精算评估提存</div>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-xl">
          <div className="text-slate-400 text-[11px]">6001 保费收入 - 企财险/车险</div>
          <div className="text-base font-bold text-rose-400 mt-1">¥890,200,000.00</div>
          <div className="text-[10px] text-emerald-400 mt-0.5">实现原保费收入</div>
        </div>
      </div>

      {/* 分录流水列表 */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-lg text-xs space-y-3">
        <div className="font-bold text-slate-200 border-b border-slate-800 pb-2 flex justify-between items-center">
          <span>技术会计复式过账凭证列表</span>
          <span className="text-emerald-400 flex items-center space-x-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>自动审计试算平衡通过</span>
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-950 text-slate-400 font-semibold border-b border-slate-800">
              <tr>
                <th className="p-3">凭证编号</th>
                <th className="p-3">业务事件类型</th>
                <th className="p-3">关联保单/理赔单号</th>
                <th className="p-3">借方科目 (Debit)</th>
                <th className="p-3">贷方科目 (Credit)</th>
                <th className="p-3">发生金额 (¥)</th>
                <th className="p-3">记账日期</th>
                <th className="p-3">过账引擎</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {entries.map(entry => (
                <tr key={entry.id} className="hover:bg-slate-800/40 font-mono text-[11px]">
                  <td className="p-3 font-bold text-rose-400">{entry.entryNo}</td>
                  <td className="p-3 font-sans text-slate-200">{entry.businessEventType}</td>
                  <td className="p-3 text-sky-400">{entry.relatedDocNo}</td>
                  <td className="p-3 text-emerald-400 font-sans">{entry.debitAccount}</td>
                  <td className="p-3 text-amber-400 font-sans">{entry.creditAccount}</td>
                  <td className="p-3 font-bold text-white">¥{entry.amount.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}</td>
                  <td className="p-3 text-slate-400">{entry.accountingDate}</td>
                  <td className="p-3 text-slate-500 font-sans">{entry.operator}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
