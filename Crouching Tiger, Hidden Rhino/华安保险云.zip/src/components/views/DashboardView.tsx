import React from 'react';
import {
  TrendingUp,
  FileCheck,
  ShieldAlert,
  Clock,
  Coins,
  Building2,
  Users,
  Activity,
  ArrowUpRight,
  ArrowDownRight,
  AlertTriangle
} from 'lucide-react';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';

interface DashboardViewProps {
  onNavigate: (tab: any) => void;
  onOpenWalkthrough: () => void;
}

const premiumTrendData = [
  { month: '1月',保费收入: 980, 赔付支出: 520, 准备金: 1200 },
  { month: '2月',保费收入: 1050, 赔付支出: 480, 准备金: 1250 },
  { month: '3月',保费收入: 1200, 赔付支出: 610, 准备金: 1300 },
  { month: '4月',保费收入: 1150, 赔付支出: 590, 准备金: 1320 },
  { month: '5月',保费收入: 1380, 赔付支出: 640, 准备金: 1400 },
  { month: '6月',保费收入: 1420, 赔付支出: 710, 准备金: 1520 },
  { month: '7月',保费收入: 1560, 赔付支出: 890, 准备金: 1680 },
  { month: '8月',保费收入: 1680, 赔付支出: 750, 准备金: 1750 },
  { month: '9月',保费收入: 1280, 赔付支出: 452, 准备金: 1820 }
];

const lobDistributionData = [
  { name: '企财险', value: 38, color: '#0284C7' },
  { name: '车险', value: 28, color: '#BE123C' },
  { name: '责任与工程险', value: 16, color: '#D97706' },
  { name: '人身险与重疾', value: 12, color: '#059669' },
  { name: '网络安全险', value: 6, color: '#7C3AED' }
];

export const DashboardView: React.FC<DashboardViewProps> = ({ onNavigate, onOpenWalkthrough }) => {
  return (
    <div className="p-6 space-y-6 text-slate-200">
      {/* 顶部简报与大盘通告 */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 mb-1">
            <h1 className="text-xl font-bold text-white tracking-tight">华安保险云 · 运营驾驶舱</h1>
            <span className="bg-rose-950 text-rose-300 text-xs px-2.5 py-0.5 rounded border border-rose-800 font-medium">
              HQ Core Operational Control
            </span>
          </div>
          <p className="text-xs text-slate-400">
            集团实时承保、核保、计费、理赔、再保险与财技技术会计监控中心 (基于中国保险会计准则 CAS 25 / IFRS 17)
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={onOpenWalkthrough}
            className="bg-rose-700 hover:bg-rose-600 text-white font-medium text-xs px-4 py-2 rounded-lg transition shadow-md flex items-center space-x-2"
          >
            <Activity className="w-4 h-4 text-rose-200" />
            <span>执行 Phase 1-15 闭环演练</span>
          </button>
        </div>
      </div>

      {/* 第七节核心 13 大 KPI 指标矩阵 */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-xl shadow">
          <div className="text-[11px] text-slate-400 mb-1 flex items-center justify-between">
            <span>今日保费收入</span>
            <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="text-base font-bold text-white">¥1,280.5万</div>
          <div className="text-[10px] text-emerald-400 mt-1 flex items-center">
            <ArrowUpRight className="w-3 h-3 mr-0.5" />
            <span>较昨日 +14.2%</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-xl shadow">
          <div className="text-[11px] text-slate-400 mb-1 flex items-center justify-between">
            <span>今日新单</span>
            <FileCheck className="w-3.5 h-3.5 text-sky-400" />
          </div>
          <div className="text-base font-bold text-white">342 笔</div>
          <div className="text-[10px] text-sky-400 mt-1">自动核保率 82.5%</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-xl shadow cursor-pointer hover:border-amber-600 transition" onClick={() => onNavigate('UNDERWRITING')}>
          <div className="text-[11px] text-slate-400 mb-1 flex items-center justify-between">
            <span>待核保任务</span>
            <Clock className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="text-base font-bold text-amber-300">48 件</div>
          <div className="text-[10px] text-amber-400/80 mt-1">含高风险会签 6 件</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-xl shadow cursor-pointer hover:border-rose-600 transition" onClick={() => onNavigate('CLAIMS')}>
          <div className="text-[11px] text-slate-400 mb-1 flex items-center justify-between">
            <span>待处理理赔</span>
            <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
          </div>
          <div className="text-base font-bold text-rose-300">29 件</div>
          <div className="text-[10px] text-rose-400/80 mt-1">FNOL 待查勘 8 件</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-xl shadow">
          <div className="text-[11px] text-slate-400 mb-1 flex items-center justify-between">
            <span>待续保保单</span>
            <Clock className="w-3.5 h-3.5 text-purple-400" />
          </div>
          <div className="text-base font-bold text-white">156 件</div>
          <div className="text-[10px] text-purple-400 mt-1">提前30天提醒队列</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-xl shadow">
          <div className="text-[11px] text-slate-400 mb-1 flex items-center justify-between">
            <span>逾期应收保费</span>
            <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
          </div>
          <div className="text-base font-bold text-rose-400">¥32.4万</div>
          <div className="text-[10px] text-slate-400 mt-1">逾期账期 &gt; 15天</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-xl shadow">
          <div className="text-[11px] text-slate-400 mb-1 flex items-center justify-between">
            <span>理赔未决准备金</span>
            <Coins className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="text-base font-bold text-emerald-300">¥1.82亿元</div>
          <div className="text-[10px] text-slate-400 mt-1">IBNR + Case Reserve</div>
        </div>
      </div>

      {/* 第二排次级 6 大关键经营指标 */}
      <div className="grid grid-cols-2 md:grid-cols-6 gap-3">
        <div className="bg-slate-950/80 border border-slate-800 p-3 rounded-lg text-center">
          <div className="text-[10px] text-slate-400">已付赔付金额</div>
          <div className="text-sm font-bold text-slate-200 mt-0.5">¥4,520万元</div>
        </div>
        <div className="bg-slate-950/80 border border-slate-800 p-3 rounded-lg text-center">
          <div className="text-[10px] text-slate-400">综合成本率 (Combined Ratio)</div>
          <div className="text-sm font-bold text-emerald-400 mt-0.5">93.8% (承保盈利)</div>
        </div>
        <div className="bg-slate-950/80 border border-slate-800 p-3 rounded-lg text-center">
          <div className="text-[10px] text-slate-400">综合赔付率 (Loss Ratio)</div>
          <div className="text-sm font-bold text-sky-400 mt-0.5">58.2%</div>
        </div>
        <div className="bg-slate-950/80 border border-slate-800 p-3 rounded-lg text-center">
          <div className="text-[10px] text-slate-400">有效保单总数</div>
          <div className="text-sm font-bold text-slate-200 mt-0.5">24,580 张</div>
        </div>
        <div className="bg-slate-950/80 border border-slate-800 p-3 rounded-lg text-center">
          <div className="text-[10px] text-slate-400">客户总数</div>
          <div className="text-sm font-bold text-slate-200 mt-0.5">12,350 位</div>
        </div>
        <div className="bg-slate-950/80 border border-slate-800 p-3 rounded-lg text-center">
          <div className="text-[10px] text-slate-400">合作渠道数量</div>
          <div className="text-sm font-bold text-slate-200 mt-0.5">185 个</div>
        </div>
      </div>

      {/* 图表可视化区域 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 保费与赔付走势 */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-bold text-white">保费收入与赔付支出走势 (2026年度)</h2>
              <p className="text-[11px] text-slate-400">含未赚保费准备金 (UPR) 演进轨迹</p>
            </div>
            <span className="text-xs text-slate-400">单位：万元人民币</span>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={premiumTrendData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="month" stroke="#94A3B8" fontSize={11} />
                <YAxis stroke="#94A3B8" fontSize={11} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0F172A', borderColor: '#334155', color: '#F8FAFC', fontSize: '12px' }}
                />
                <Area type="monotone" dataKey="保费收入" stroke="#0284C7" fill="#0284C7" fillOpacity={0.2} />
                <Area type="monotone" dataKey="赔付支出" stroke="#BE123C" fill="#BE123C" fillOpacity={0.2} />
                <Area type="monotone" dataKey="准备金" stroke="#059669" fill="#059669" fillOpacity={0.1} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* 险种保费结构 */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-lg flex flex-col justify-between">
          <div>
            <h2 className="text-sm font-bold text-white mb-1">各险种保费占比</h2>
            <p className="text-[11px] text-slate-400 mb-4">财产险与人身险结构配置</p>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={lobDistributionData}
                    cx="50%"
                    cy="50%"
                    innerRadius={45}
                    outerRadius={75}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {lobDistributionData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ backgroundColor: '#0F172A', borderColor: '#334155', color: '#F8FAFC', fontSize: '11px' }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 text-[11px] border-t border-slate-800 pt-3">
            {lobDistributionData.map((item, idx) => (
              <div key={idx} className="flex items-center space-x-1.5">
                <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: item.color }}></span>
                <span className="text-slate-300 truncate">{item.name}: {item.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
