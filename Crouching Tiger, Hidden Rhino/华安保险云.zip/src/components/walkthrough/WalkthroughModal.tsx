import React, { useState } from 'react';
import { X, Play, CheckCircle2, ArrowRight, ShieldCheck, FileCheck, Layers, FileSpreadsheet, Building } from 'lucide-react';

interface WalkthroughModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRefreshData: () => void;
}

export const WalkthroughModal: React.FC<WalkthroughModalProps> = ({
  isOpen,
  onClose,
  onRefreshData
}) => {
  const [isRunning, setIsRunning] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [executionResult, setExecutionResult] = useState<any>(null);

  if (!isOpen) return null;

  const pipelineSteps = [
    { title: '1. 客户建档与风险画像', desc: '建立大型国有企业「中国航天高科重大工程集团」信用与风控档案' },
    { title: '2. 选择产品与精准精算定价', desc: '加载【华安企财臻享综合财产保险 v1.1】，运行多因子费率引擎试算保费' },
    { title: '3. 触发核保规则与专家会签', desc: '核保规则引擎拦截1亿元超大保额，经高级核保主管会签过会' },
    { title: '4. 承保出单与电子合同签发', desc: '生成正式保单【HA-POL-2026-WT8899】，同步构建未赚保费准备金 (UPR)' },
    { title: '5. 资金计费与实收保费进账', desc: '生成¥76.5万元应收保费账单，模拟银行到账冲销并记入财技总账' },
    { title: '6. FNOL报案与理赔案立案', desc: '基地试验设备遭遇供电骤降事故，进行出险报案与保单有效性校验' },
    { title: '7. 提取未决理赔准备金 (Case Reserve)', desc: '精算与查勘团队提取初始理赔准备金 ¥150,000.00' },
    { title: '8. 现场核损查勘与理赔金划扣', desc: '查勘定损 ¥135,000.00，完成最终审额、理算审批与资金实时划拨' },
    { title: '9. 财技双式记账与再保险分保结算', desc: '触发再保险 (Quota Share 30%) 追偿，同步记入借贷平衡技术会计总账' },
    { title: '10. 数据大盘与全流程血缘追溯', desc: '实时刷新综合成本率 (Combined Ratio) 与损益指标，全数据链保持一致' }
  ];

  const handleRunAll = async () => {
    setIsRunning(true);
    setExecutionResult(null);

    for (let i = 0; i < pipelineSteps.length; i++) {
      setCurrentStep(i + 1);
      await new Promise(r => setTimeout(r, 300));
    }

    try {
      const res = await fetch('/api/v1/walkthrough/execute-all', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      const data = await res.json();
      setExecutionResult(data);
      onRefreshData();
    } catch (err) {
      console.error(err);
    } finally {
      setIsRunning(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 select-none">
      <div className="bg-slate-900 border border-slate-800 rounded-xl max-w-4xl w-full shadow-2xl flex flex-col max-h-[90vh] text-slate-200">
        {/* Modal Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between rounded-t-xl">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-rose-950 border border-rose-800 rounded-lg">
              <ShieldCheck className="w-6 h-6 text-rose-400" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center space-x-2">
                <span>第一阶段全流程自动化演练引擎</span>
                <span className="bg-amber-950 text-amber-300 text-xs px-2 py-0.5 rounded border border-amber-800">
                  Section 55 闭环验证
                </span>
              </h2>
              <p className="text-xs text-slate-400">从【客户】一路穿透至【报价→核保→保单→扣款→理赔→准备金→再保险→财务总账】</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-800">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 flex-1 overflow-y-auto space-y-6 text-xs">
          {/* Action Bar */}
          <div className="bg-slate-950/80 p-4 rounded-lg border border-slate-800 flex items-center justify-between">
            <div>
              <div className="font-semibold text-slate-100 text-sm mb-1">华安核心链路连贯性测试说明</div>
              <div className="text-slate-400 leading-relaxed">
                点击一键演练将自动创建客户、试算费率、触发核保、签发保单、记账到账、FNOL报案、核定损额、完成赔付并过账至技术会计双式总账。
              </div>
            </div>
            <button
              onClick={handleRunAll}
              disabled={isRunning}
              className="bg-gradient-to-r from-rose-700 to-amber-600 hover:from-rose-600 hover:to-amber-500 text-white font-semibold px-5 py-2.5 rounded-lg flex items-center space-x-2 text-xs shadow-md shadow-rose-950 shrink-0 disabled:opacity-50 transition"
            >
              <Play className="w-4 h-4 fill-white" />
              <span>{isRunning ? `执行中 (${currentStep}/10)...` : '启动一键全流程演算'}</span>
            </button>
          </div>

          {/* Execution Pipeline Steps */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {pipelineSteps.map((s, idx) => {
              const isCompleted = currentStep > idx || executionResult;
              const isCurrent = currentStep === idx + 1 && isRunning;
              return (
                <div
                  key={idx}
                  className={`p-3 rounded-lg border transition ${
                    isCompleted
                      ? 'bg-emerald-950/20 border-emerald-800/80 text-emerald-200'
                      : isCurrent
                      ? 'bg-rose-950/40 border-rose-600 text-rose-100 animate-pulse'
                      : 'bg-slate-950/40 border-slate-800 text-slate-400'
                  }`}
                >
                  <div className="flex items-center justify-between font-semibold text-xs mb-1">
                    <span>{s.title}</span>
                    {isCompleted ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <span className="text-[10px] text-slate-500">Phase {idx + 1}</span>
                    )}
                  </div>
                  <div className="text-[11px] text-slate-400">{s.desc}</div>
                </div>
              );
            })}
          </div>

          {/* Execution Result Log */}
          {executionResult && (
            <div className="bg-slate-950 p-4 rounded-lg border border-emerald-800/80 space-y-3">
              <div className="flex items-center space-x-2 text-emerald-400 font-bold text-sm">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                <span>{executionResult.message}</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-[11px] font-mono">
                <div className="p-2.5 bg-slate-900 rounded border border-slate-800">
                  <div className="text-slate-400 mb-1">客户与保单号</div>
                  <div className="text-white font-bold">{executionResult.trace.policy.policyNo}</div>
                  <div className="text-slate-400 text-[10px] mt-0.5">{executionResult.trace.customer.name}</div>
                </div>
                <div className="p-2.5 bg-slate-900 rounded border border-slate-800">
                  <div className="text-slate-400 mb-1">承保保费与理赔赔款</div>
                  <div className="text-rose-400 font-bold">保费: ¥{executionResult.trace.policy.annualPremium.toLocaleString()}</div>
                  <div className="text-amber-400 font-bold">赔款: ¥{executionResult.trace.claim.paidAmount.toLocaleString()}</div>
                </div>
                <div className="p-2.5 bg-slate-900 rounded border border-slate-800">
                  <div className="text-slate-400 mb-1">产生技术会计分录</div>
                  <div className="text-emerald-400 font-bold">{executionResult.trace.accountingEntries.length} 笔借贷分录过账</div>
                  <div className="text-slate-400 text-[10px] mt-0.5">借: 1002 银行存款 / 贷: 6001 保费收入</div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex justify-end rounded-b-xl">
          <button
            onClick={onClose}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-4 py-2 rounded font-medium text-xs transition"
          >
            完成并关闭窗口
          </button>
        </div>
      </div>
    </div>
  );
};
