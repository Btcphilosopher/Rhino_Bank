import React from 'react';
import {
  LayoutDashboard,
  Users,
  Package,
  Calculator,
  ShieldCheck,
  FileText,
  FileEdit,
  RotateCw,
  CreditCard,
  Coins,
  FileSpreadsheet,
  Layers,
  BookOpenCheck,
  TrendingUp,
  AlertTriangle,
  Globe2,
  FlaskConical,
  Building2,
  GitBranch,
  Lock
} from 'lucide-react';

export type NavTab =
  | 'DASHBOARD'
  | 'CUSTOMERS'
  | 'PRODUCTS'
  | 'QUOTES'
  | 'UNDERWRITING'
  | 'POLICIES'
  | 'ENDORSEMENTS'
  | 'RENEWALS'
  | 'BILLING'
  | 'COMMISSIONS'
  | 'CLAIMS'
  | 'REINSURANCE'
  | 'ACCOUNTING'
  | 'ACTUARIAL'
  | 'RISK_ALM'
  | 'DIGITAL_TWIN'
  | 'SCENARIO_LAB'
  | 'PORTALS'
  | 'WORKFLOW'
  | 'SYSTEM_AUDIT';

interface SidebarProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
}

interface NavGroup {
  groupName: string;
  items: { id: NavTab; label: string; icon: React.FC<{ className?: string }> }[];
}

const navGroups: NavGroup[] = [
  {
    groupName: '运营驾驶',
    items: [
      { id: 'DASHBOARD', label: '运营驾驶舱', icon: LayoutDashboard },
      { id: 'DIGITAL_TWIN', label: '数字孪生保险公司', icon: Globe2 }
    ]
  },
  {
    groupName: '承保与契约',
    items: [
      { id: 'CUSTOMERS', label: '客户中心', icon: Users },
      { id: 'PRODUCTS', label: '产品工厂', icon: Package },
      { id: 'QUOTES', label: '报价与费率引擎', icon: Calculator },
      { id: 'UNDERWRITING', label: '核保工作台与规则', icon: ShieldCheck },
      { id: 'POLICIES', label: '保单中心', icon: FileText },
      { id: 'ENDORSEMENTS', label: '保单批改', icon: FileEdit },
      { id: 'RENEWALS', label: '续保管理', icon: RotateCw }
    ]
  },
  {
    groupName: '理赔与资金',
    items: [
      { id: 'CLAIMS', label: '理赔运营中心', icon: FileSpreadsheet },
      { id: 'BILLING', label: '计费与应收账款', icon: CreditCard },
      { id: 'COMMISSIONS', label: '渠道与佣金', icon: Coins },
      { id: 'REINSURANCE', label: '再保险中心', icon: Layers }
    ]
  },
  {
    groupName: '财技与精算',
    items: [
      { id: 'ACCOUNTING', label: '财务与技术会计', icon: BookOpenCheck },
      { id: 'ACTUARIAL', label: '精算与组合分析', icon: TrendingUp },
      { id: 'RISK_ALM', label: '风险与资产负债', icon: AlertTriangle },
      { id: 'SCENARIO_LAB', label: '情景压力测试实验室', icon: FlaskConical }
    ]
  },
  {
    groupName: '门户与工作流',
    items: [
      { id: 'PORTALS', label: '多端门户 (代理/经纪/企业)', icon: Building2 },
      { id: 'WORKFLOW', label: '工作流引擎', icon: GitBranch },
      { id: 'SYSTEM_AUDIT', label: '系统设置与合规审计', icon: Lock }
    ]
  }
];

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, onSelectTab }) => {
  return (
    <aside className="w-64 bg-slate-900 border-r border-slate-800 flex flex-col h-[calc(100vh-4rem)] overflow-y-auto text-slate-300 text-xs shrink-0 select-none">
      <div className="p-3 space-y-5">
        {navGroups.map((group, idx) => (
          <div key={idx}>
            <div className="px-3 text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
              {group.groupName}
            </div>
            <div className="space-y-0.5">
              {group.items.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => onSelectTab(item.id)}
                    className={`w-full flex items-center space-x-2.5 px-3 py-2 rounded-md transition font-medium ${
                      isActive
                        ? 'bg-rose-900/60 text-white border-l-2 border-rose-500 font-semibold'
                        : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                    }`}
                  >
                    <Icon className={`w-4 h-4 ${isActive ? 'text-rose-400' : 'text-slate-400'}`} />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-auto p-3 bg-slate-950/60 border-t border-slate-800/80 text-[11px] text-slate-400">
        <div className="font-medium text-slate-300 mb-0.5">华安财产保险股份有限公司</div>
        <div>核算版本：IFRS 17 / CAS 25</div>
        <div className="text-slate-500 mt-1">演示模式：全仿真企业级数据</div>
      </div>
    </aside>
  );
};
