import React from 'react';
import { Shield, Activity, Zap, Bot, User, CheckCircle2, Clock } from 'lucide-react';
import { UserRole } from '../../types/insurance';

interface HeaderProps {
  currentRole: UserRole;
  onRoleChange: (role: UserRole) => void;
  onOpenAI: () => void;
  onOpenWalkthrough: () => void;
  isWalkthroughRunning: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  currentRole,
  onRoleChange,
  onOpenAI,
  onOpenWalkthrough,
  isWalkthroughRunning
}) => {
  return (
    <header className="bg-slate-900 border-b border-slate-800 text-white h-16 px-4 flex items-center justify-between sticky top-0 z-40 shadow-lg">
      {/* 品牌标识 */}
      <div className="flex items-center space-x-3">
        <div className="bg-rose-700 p-2 rounded-lg flex items-center justify-center shadow-md shadow-rose-900/30">
          <Shield className="w-6 h-6 text-white" />
        </div>
        <div>
          <div className="flex items-center space-x-2">
            <h1 className="font-bold text-lg text-white tracking-wide">华安保险云</h1>
            <span className="bg-rose-950 text-rose-300 text-xs px-2 py-0.5 rounded border border-rose-800/60 font-mono">
              HUAN OS v3.6
            </span>
          </div>
          <p className="text-xs text-slate-400">全中文企业级保险核心运营平台</p>
        </div>
      </div>

      {/* 实时状态指示 */}
      <div className="hidden lg:flex items-center space-x-6 text-xs text-slate-300">
        <div className="flex items-center space-x-2 bg-slate-800/80 px-3 py-1.5 rounded-full border border-slate-700/60">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span className="font-medium text-emerald-400">核心引擎正常运作</span>
          <span className="text-slate-500">|</span>
          <span className="text-slate-400">实时点对点总账与准则同步</span>
        </div>

        <div className="flex items-center space-x-2 text-slate-400">
          <Clock className="w-3.5 h-3.5 text-slate-400" />
          <span>2026年9月17日 星期四</span>
        </div>
      </div>

      {/* 右侧交互区 */}
      <div className="flex items-center space-x-3">
        {/* 一键全流程闭环演练按钮 */}
        <button
          onClick={onOpenWalkthrough}
          disabled={isWalkthroughRunning}
          className="bg-gradient-to-r from-amber-600 to-rose-700 hover:from-amber-500 hover:to-rose-600 text-white text-xs px-3.5 py-1.5 rounded-md font-medium flex items-center space-x-1.5 transition shadow-sm border border-amber-500/30 disabled:opacity-50"
        >
          <Zap className="w-3.5 h-3.5 text-amber-200 fill-amber-200" />
          <span>{isWalkthroughRunning ? '全流程演算中...' : '全流程闭环演练'}</span>
        </button>

        {/* 角色切换 RBAC */}
        <div className="flex items-center space-x-1.5 bg-slate-800/80 px-2.5 py-1 rounded-md border border-slate-700 text-xs">
          <User className="w-3.5 h-3.5 text-slate-400" />
          <select
            value={currentRole}
            onChange={(e) => onRoleChange(e.target.value as UserRole)}
            className="bg-transparent text-slate-200 focus:outline-none cursor-pointer py-0.5 text-xs font-medium"
          >
            <option value="SUPER_ADMIN" className="bg-slate-800">超级管理员 (总部)</option>
            <option value="SR_UNDERWRITER" className="bg-slate-800">资深核保专家</option>
            <option value="CLAIM_MANAGER" className="bg-slate-800">理赔运营主管</option>
            <option value="ACTUARY" className="bg-slate-800">精算及风控官</option>
            <option value="FINANCE_OFFICER" className="bg-slate-800">技术会计及出纳</option>
            <option value="AGENT" className="bg-slate-800">保险代理人</option>
            <option value="BROKER" className="bg-slate-800">合作经纪渠道</option>
            <option value="CORP_CUSTOMER" className="bg-slate-800">企业客户代表</option>
          </select>
        </div>

        {/* AI 助手触发 */}
        <button
          onClick={onOpenAI}
          className="bg-sky-950 hover:bg-sky-900 text-sky-200 text-xs px-3 py-1.5 rounded-md border border-sky-800 flex items-center space-x-1.5 transition"
        >
          <Bot className="w-4 h-4 text-sky-400" />
          <span>华安智保助手</span>
        </button>
      </div>
    </header>
  );
};
