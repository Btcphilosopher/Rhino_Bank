import React, { useState } from 'react';
import { Bot, X, Send, Sparkles, ShieldAlert, FileText, CheckCircle } from 'lucide-react';

interface AIAssistantDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  activeModule: string;
}

interface ChatMessage {
  sender: 'user' | 'ai';
  text: string;
  disclaimer?: string;
  timestamp: string;
}

export const AIAssistantDrawer: React.FC<AIAssistantDrawerProps> = ({
  isOpen,
  onClose,
  activeModule
}) => {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      sender: 'ai',
      text: `您好！我是「华安智保助手」，华安保险云的核心智能大脑。\n\n我能协助您：\n1. 总结与提炼复杂理赔案情与风险隐患\n2. 解析核保规则触发条件与风险裁决逻辑\n3. 试算与解释技术会计准备金（UPR/IBNR/未决赔款）\n4. 生成监管合规呈报草案与对客沟通公文\n\n请问当前在【${activeModule}】模块中有什么我可以协助您的？`,
      disclaimer: '【华安智保提示】：本回复为AI辅助建议，不替代法定核保/理赔/财务审批结果。',
      timestamp: '09:30'
    }
  ]);

  if (!isOpen) return null;

  const quickPrompts = [
    '总结当前理赔案情与潜在欺诈预警点',
    '解释企财险特大保额核保会签规则与超限处理',
    '计算并对比未赚保费准备金(UPR)与未决赔款准备金(IBNR)',
    '拟定一份针对高风险企财险客户的附条件承保通知书草稿'
  ];

  const handleSend = async (customText?: string) => {
    const promptText = customText || input;
    if (!promptText.trim() || loading) return;

    const userMsg: ChatMessage = {
      sender: 'user',
      text: promptText,
      timestamp: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    if (!customText) setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/v1/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: promptText,
          contextModule: activeModule
        })
      });

      const data = await res.json();
      if (data.success) {
        setMessages(prev => [
          ...prev,
          {
            sender: 'ai',
            text: data.reply,
            disclaimer: data.disclaimer,
            timestamp: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })
          }
        ]);
      } else {
        setMessages(prev => [
          ...prev,
          {
            sender: 'ai',
            text: '华安智保助手暂时无法回应请求：' + (data.error || '通信异常'),
            timestamp: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })
          }
        ]);
      }
    } catch (err) {
      setMessages(prev => [
        ...prev,
        {
          sender: 'ai',
          text: '系统网络或服务器连接受阻，请稍后重试。',
          timestamp: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-y-0 right-0 w-96 bg-slate-900 border-l border-slate-800 shadow-2xl z-50 flex flex-col text-xs">
      {/* 标题栏 */}
      <div className="p-3 bg-slate-950 border-b border-slate-800 flex items-center justify-between text-white">
        <div className="flex items-center space-x-2">
          <div className="p-1.5 bg-sky-950 border border-sky-800 rounded-md">
            <Bot className="w-5 h-5 text-sky-400" />
          </div>
          <div>
            <h2 className="font-bold text-sm text-slate-100">华安智保助手</h2>
            <p className="text-[10px] text-slate-400">Gemini 驱动 · 当前上下文: {activeModule}</p>
          </div>
        </div>
        <button onClick={onClose} className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800">
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* 快捷指令 */}
      <div className="p-2.5 bg-slate-900/90 border-b border-slate-800/80 space-y-1.5">
        <div className="flex items-center space-x-1 text-[11px] font-medium text-sky-300">
          <Sparkles className="w-3.5 h-3.5 text-sky-400" />
          <span>常用高频保险指令：</span>
        </div>
        <div className="flex flex-col space-y-1">
          {quickPrompts.map((qp, i) => (
            <button
              key={i}
              onClick={() => handleSend(qp)}
              className="text-left bg-slate-800/60 hover:bg-slate-800 text-slate-300 hover:text-white px-2.5 py-1.5 rounded border border-slate-700/60 text-[11px] truncate transition"
            >
              • {qp}
            </button>
          ))}
        </div>
      </div>

      {/* 消息历史区 */}
      <div className="flex-1 p-3 overflow-y-auto space-y-3 bg-slate-950/40">
        {messages.map((m, idx) => (
          <div
            key={idx}
            className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}
          >
            <div
              className={`max-w-[88%] p-3 rounded-lg leading-relaxed whitespace-pre-wrap ${
                m.sender === 'user'
                  ? 'bg-rose-900/80 text-rose-50 border border-rose-700/60'
                  : 'bg-slate-800/90 text-slate-200 border border-slate-700/80'
              }`}
            >
              {m.text}
              {m.disclaimer && (
                <div className="mt-2 pt-2 border-t border-slate-700/60 text-[10px] text-amber-400 font-medium flex items-center space-x-1">
                  <ShieldAlert className="w-3 h-3 text-amber-400 shrink-0" />
                  <span>{m.disclaimer}</span>
                </div>
              )}
            </div>
            <span className="text-[10px] text-slate-500 mt-1 px-1">{m.timestamp}</span>
          </div>
        ))}

        {loading && (
          <div className="flex items-center space-x-2 text-sky-400 bg-slate-800/60 p-2.5 rounded border border-slate-700 w-fit">
            <Bot className="w-4 h-4 animate-bounce" />
            <span className="text-xs">华安智保助手正在深度研判中...</span>
          </div>
        )}
      </div>

      {/* 输入发送框 */}
      <div className="p-3 bg-slate-900 border-t border-slate-800">
        <div className="flex space-x-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="输入保险业务咨询、条款解释或决策协助..."
            className="flex-1 bg-slate-950 border border-slate-700 rounded px-3 py-2 text-slate-200 text-xs focus:outline-none focus:border-sky-500"
          />
          <button
            onClick={() => handleSend()}
            disabled={loading}
            className="bg-sky-600 hover:bg-sky-500 text-white px-3 py-2 rounded font-medium flex items-center justify-center transition disabled:opacity-50"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
