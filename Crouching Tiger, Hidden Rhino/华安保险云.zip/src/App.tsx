import React, { useState, useEffect } from 'react';
import { Header } from './components/layout/Header';
import { Sidebar, NavTab } from './components/layout/Sidebar';
import { AIAssistantDrawer } from './components/layout/AIAssistantDrawer';
import { WalkthroughModal } from './components/walkthrough/WalkthroughModal';

import { DashboardView } from './components/views/DashboardView';
import { CustomerView } from './components/views/CustomerView';
import { ProductView } from './components/views/ProductView';
import { QuoteView } from './components/views/QuoteView';
import { UnderwritingView } from './components/views/UnderwritingView';
import { PolicyView } from './components/views/PolicyView';
import { ClaimsView } from './components/views/ClaimsView';
import { AccountingView } from './components/views/AccountingView';
import { ReinsuranceView } from './components/views/ReinsuranceView';
import { ActuarialView } from './components/views/ActuarialView';
import { RiskALMView } from './components/views/RiskALMView';
import { DigitalTwinView } from './components/views/DigitalTwinView';
import { ScenarioLabView } from './components/views/ScenarioLabView';
import { PortalsView } from './components/views/PortalsView';
import { WorkflowView } from './components/views/WorkflowView';
import { SystemAuditView } from './components/views/SystemAuditView';

import { UserRole, Customer, InsuranceProduct, Policy, ClaimCase, AccountingEntry, UWTask } from './types/insurance';
import {
  initialCustomers,
  initialProducts,
  initialPolicies,
  initialClaims,
  initialAccountingEntries,
  initialUWTasks
} from './services/mockDataStore';

export function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('DASHBOARD');
  const [currentRole, setCurrentRole] = useState<UserRole>('SUPER_ADMIN');

  const [isAIOpen, setIsAIOpen] = useState(false);
  const [isWalkthroughOpen, setIsWalkthroughOpen] = useState(false);
  const [isWalkthroughRunning, setIsWalkthroughRunning] = useState(false);

  // 状态与数据源
  const [customers, setCustomers] = useState<Customer[]>(initialCustomers);
  const [products, setProducts] = useState<InsuranceProduct[]>(initialProducts);
  const [policies, setPolicies] = useState<Policy[]>(initialPolicies);
  const [claims, setClaims] = useState<ClaimCase[]>(initialClaims);
  const [accountingEntries, setAccountingEntries] = useState<AccountingEntry[]>(initialAccountingEntries);
  const [uwTasks, setUwTasks] = useState<UWTask[]>(initialUWTasks);

  // 首次加载拉取后端接口同步最新数据
  const refreshAllData = async () => {
    try {
      const [cRes, pRes, clRes, accRes] = await Promise.all([
        fetch('/api/v1/customers').then(r => r.json()).catch(() => null),
        fetch('/api/v1/policies').then(r => r.json()).catch(() => null),
        fetch('/api/v1/claims').then(r => r.json()).catch(() => null),
        fetch('/api/v1/accounting/entries').then(r => r.json()).catch(() => null)
      ]);

      if (cRes?.success) setCustomers(cRes.data);
      if (pRes?.success) setPolicies(pRes.data);
      if (clRes?.success) setClaims(clRes.data);
      if (accRes?.success) setAccountingEntries(accRes.data);
    } catch (e) {
      console.warn('Backend connection falling back to local memory store', e);
    }
  };

  useEffect(() => {
    refreshAllData();
  }, []);

  // 业务处理逻辑：新建客户
  const handleAddCustomer = async (custData: Partial<Customer>) => {
    try {
      const res = await fetch('/api/v1/customers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(custData)
      });
      const data = await res.json();
      if (data.success) {
        setCustomers(prev => [data.data, ...prev]);
      }
    } catch (err) {
      // 降级本地内存
      const newCust: Customer = {
        id: `cust-${Date.now()}`,
        customerNo: `CN-2026-${Math.floor(1000 + Math.random() * 9000)}`,
        name: custData.name || '新客户',
        type: custData.type || 'CORPORATE',
        idType: custData.idType || '统一社会信用代码',
        idNoMasked: '91110000****1234',
        phoneMasked: '138****0000',
        emailMasked: 'contact****@huan.demo',
        address: custData.address || '北京市海淀区',
        city: '北京',
        riskRating: custData.riskRating || 'A',
        policyCount: 0,
        claimCount: 0,
        paymentStatus: '良好',
        relationshipManager: custData.relationshipManager || '李经理',
        channel: '直销',
        creditScore: 90,
        createdAt: new Date().toISOString().split('T')[0],
        updatedAt: new Date().toISOString().split('T')[0]
      };
      setCustomers(prev => [newCust, ...prev]);
    }
  };

  // 提交核保
  const handleNavigateToUW = async (quoteData: any) => {
    try {
      const res = await fetch('/api/v1/underwriting/evaluate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(quoteData)
      });
      const data = await res.json();
      if (data.success) {
        setUwTasks(prev => [data.data, ...prev]);
      }
    } catch (err) {
      console.error(err);
    }
    setActiveTab('UNDERWRITING');
  };

  // 签发保单
  const handleIssuePolicy = async (policyData: any) => {
    try {
      const res = await fetch('/api/v1/policies/issue', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(policyData)
      });
      const data = await res.json();
      if (data.success) {
        setPolicies(prev => [data.policy, ...prev]);
        setAccountingEntries(prev => [data.accountingEntry, ...prev]);
      }
    } catch (e) {
      console.error(e);
    }
    setActiveTab('POLICIES');
  };

  // 理赔报案 FNOL
  const handleRegisterFNOL = async (fnolData: any) => {
    try {
      const res = await fetch('/api/v1/claims/fnol', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(fnolData)
      });
      const data = await res.json();
      if (data.success) {
        setClaims(prev => [data.claim, ...prev]);
        setAccountingEntries(prev => [data.accountingEntry, ...prev]);
      }
    } catch (e) {
      console.error(e);
    }
  };

  // 理赔支付
  const handlePayClaim = async (claimNo: string, assessedLoss: number) => {
    try {
      const res = await fetch('/api/v1/claims/pay', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ claimNo, assessedLoss })
      });
      const data = await res.json();
      if (data.success) {
        setClaims(prev => prev.map(c => c.claimNo === claimNo ? data.claim : c));
        setAccountingEntries(prev => [data.accountingEntry, ...prev]);
      }
    } catch (e) {
      console.error(e);
    }
  };

  // 根据当前 activeTab 渲染视图
  const renderActiveView = () => {
    switch (activeTab) {
      case 'DASHBOARD':
        return <DashboardView onNavigate={(tab) => setActiveTab(tab)} onOpenWalkthrough={() => setIsWalkthroughOpen(true)} />;
      case 'CUSTOMERS':
        return <CustomerView customers={customers} onAddCustomer={handleAddCustomer} />;
      case 'PRODUCTS':
        return <ProductView products={products} />;
      case 'QUOTES':
        return <QuoteView products={products} customers={customers} onNavigateToUW={handleNavigateToUW} />;
      case 'UNDERWRITING':
        return <UnderwritingView tasks={uwTasks} onIssuePolicy={handleIssuePolicy} />;
      case 'POLICIES':
      case 'ENDORSEMENTS':
      case 'RENEWALS':
        return <PolicyView policies={policies} />;
      case 'CLAIMS':
        return <ClaimsView claims={claims} onRegisterFNOL={handleRegisterFNOL} onPayClaim={handlePayClaim} />;
      case 'ACCOUNTING':
      case 'BILLING':
      case 'COMMISSIONS':
        return <AccountingView entries={accountingEntries} />;
      case 'REINSURANCE':
        return <ReinsuranceView />;
      case 'ACTUARIAL':
        return <ActuarialView />;
      case 'RISK_ALM':
        return <RiskALMView />;
      case 'DIGITAL_TWIN':
        return <DigitalTwinView />;
      case 'SCENARIO_LAB':
        return <ScenarioLabView />;
      case 'PORTALS':
        return <PortalsView />;
      case 'WORKFLOW':
        return <WorkflowView />;
      case 'SYSTEM_AUDIT':
        return <SystemAuditView />;
      default:
        return <DashboardView onNavigate={(tab) => setActiveTab(tab)} onOpenWalkthrough={() => setIsWalkthroughOpen(true)} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans antialiased selection:bg-rose-900 selection:text-white">
      {/* 全局顶部 Navigation Bar */}
      <Header
        currentRole={currentRole}
        onRoleChange={setCurrentRole}
        onOpenAI={() => setIsAIOpen(true)}
        onOpenWalkthrough={() => setIsWalkthroughOpen(true)}
        isWalkthroughRunning={isWalkthroughRunning}
      />

      {/* 主工作区 (Left Sidebar + Main View) */}
      <div className="flex-1 flex overflow-hidden">
        <Sidebar activeTab={activeTab} onSelectTab={setActiveTab} />

        <main className="flex-1 overflow-y-auto bg-slate-950">
          {renderActiveView()}
        </main>
      </div>

      {/* Slide-out Gemini AI 华安智保助手 Drawer */}
      <AIAssistantDrawer
        isOpen={isAIOpen}
        onClose={() => setIsAIOpen(false)}
        activeModule={activeTab}
      />

      {/* Phase 1-15 全流程演练 Modal */}
      <WalkthroughModal
        isOpen={isWalkthroughOpen}
        onClose={() => setIsWalkthroughOpen(false)}
        onRefreshData={refreshAllData}
      />
    </div>
  );
}

export default App;
