/**
 * 华安保险云 (HUAN INSURANCE OS)
 * 核心模拟数据仓与实时计算引擎 (Mock Data Store & Calculation Engines)
 */

import {
  Customer,
  InsuranceProduct,
  Quote,
  UWTask,
  Policy,
  Endorsement,
  Invoice,
  ClaimCase,
  ReinsuranceContract,
  AccountingEntry,
  ActuarialMetrics,
  AuditLog
} from '../types/insurance';

// 初始产品定义 (包含财产险、人身险、网络安全险等多险种工厂)
export const initialProducts: InsuranceProduct[] = [
  {
    id: 'prod-001',
    productNo: 'HA-P-VEH-2026',
    name: '华安极速车险综合保障计划',
    lineOfBusiness: 'VEHICLE',
    version: 'v2.0',
    targetCustomer: '个人',
    status: 'PUBLISHED',
    minSumInsured: 50000,
    maxSumInsured: 2000000,
    coverages: [
      { id: 'cov-1', code: 'MOD', name: '机动车损失保险', limitAmount: 300000, deductible: 500, isMandatory: true, premiumRate: 12.5 },
      { id: 'cov-2', code: 'TPL', name: '第三者责任保险', limitAmount: 1000000, deductible: 0, isMandatory: true, premiumRate: 8.2 },
      { id: 'cov-3', code: 'DVR', name: '车上人员责任险', limitAmount: 50000, deductible: 0, isMandatory: false, premiumRate: 2.1 }
    ],
    exclusions: ['违法驾驶', '无证驾驶', '未检车', '故意损坏'],
    waitingPeriodDays: 0,
    paymentMethods: ['趸交', '年交'],
    baseRate: 1.2,
    commissionRate: 15.0,
    createdAt: '2026-01-10'
  },
  {
    id: 'prod-002',
    productNo: 'HA-P-CORP-PROP',
    name: '华安企财臻享综合财产保险',
    lineOfBusiness: 'CORP_PROPERTY',
    version: 'v1.1',
    targetCustomer: '企业',
    status: 'PUBLISHED',
    minSumInsured: 1000000,
    maxSumInsured: 500000000,
    coverages: [
      { id: 'cov-4', code: 'FIRE', name: '火灾及爆炸风险保障', limitAmount: 50000000, deductible: 10000, isMandatory: true, premiumRate: 0.85 },
      { id: 'cov-5', code: 'NAT', name: '自然灾害附加险 (台风/暴雨)', limitAmount: 30000000, deductible: 20000, isMandatory: false, premiumRate: 0.45 },
      { id: 'cov-6', code: 'BI', name: '营业中断损失险', limitAmount: 10000000, deductible: 50000, isMandatory: false, premiumRate: 0.65 }
    ],
    exclusions: ['战争', '核辐射', '重大安全隐患整改不力', '自然磨损'],
    waitingPeriodDays: 3,
    paymentMethods: ['趸交', '年交'],
    baseRate: 0.85,
    commissionRate: 10.0,
    createdAt: '2025-11-15'
  },
  {
    id: 'prod-003',
    productNo: 'HA-P-CRIT-LIFE',
    name: '华安安康无忧重疾保障计划',
    lineOfBusiness: 'CRITICAL_ILLNESS',
    version: 'v2.1',
    targetCustomer: '个人',
    status: 'PUBLISHED',
    minSumInsured: 100000,
    maxSumInsured: 1000000,
    coverages: [
      { id: 'cov-7', code: 'CI120', name: '120种重度疾病保险金', limitAmount: 500000, deductible: 0, isMandatory: true, premiumRate: 18.0 },
      { id: 'cov-8', code: 'MI40', name: '40种轻症关爱保险金', limitAmount: 150000, deductible: 0, isMandatory: false, premiumRate: 3.5 }
    ],
    exclusions: ['先天性疾病', '投保前已患病', '自伤或犯罪', '毒品'],
    waitingPeriodDays: 90,
    paymentMethods: ['年交', '月交'],
    baseRate: 1.8,
    commissionRate: 25.0,
    createdAt: '2026-02-01'
  },
  {
    id: 'prod-004',
    productNo: 'HA-P-CYBER-SEC',
    name: '华安云盾企业网络安全与数据泄露保险',
    lineOfBusiness: 'CYBER',
    version: 'v1.0',
    targetCustomer: '企业',
    status: 'PUBLISHED',
    minSumInsured: 2000000,
    maxSumInsured: 100000000,
    coverages: [
      { id: 'cov-9', code: 'DATA_RANSOM', name: '勒索软件赎金及恢复费用', limitAmount: 10000000, deductible: 50000, isMandatory: true, premiumRate: 1.15 },
      { id: 'cov-10', code: 'THIRD_LIAB', name: '数据隐私泄露第三方赔偿责任', limitAmount: 20000000, deductible: 100000, isMandatory: true, premiumRate: 1.45 }
    ],
    exclusions: ['内部员工故意破坏', '未按期更新高危补丁', '国家级网络战'],
    waitingPeriodDays: 7,
    paymentMethods: ['趸交', '年交'],
    baseRate: 1.3,
    commissionRate: 12.0,
    createdAt: '2026-03-01'
  }
];

// 初始模拟客户
export const initialCustomers: Customer[] = [
  {
    id: 'cust-101',
    customerNo: 'CN-2026-8801',
    name: '华为数字技术 (北京) 有限公司',
    type: 'CORPORATE',
    idType: '统一社会信用代码',
    idNoMasked: '91110108MA01****98',
    phoneMasked: '138****9988',
    emailMasked: 'corp_risk@huawei-tech.demo',
    address: '北京市海淀区中关村软件园二期6号楼',
    city: '北京',
    riskRating: 'A',
    policyCount: 3,
    claimCount: 1,
    paymentStatus: '良好',
    relationshipManager: '张伟 (大客户部)',
    channel: '企业直销渠道',
    creditScore: 98,
    createdAt: '2025-06-12',
    updatedAt: '2026-09-01'
  },
  {
    id: 'cust-102',
    customerNo: 'CN-2026-8802',
    name: '上海张江高科物流服务有限公司',
    type: 'CORPORATE',
    idType: '统一社会信用代码',
    idNoMasked: '91310000MA1F****21',
    phoneMasked: '139****1234',
    emailMasked: 'admin@zhangjiang-logistics.demo',
    address: '上海市浦东新区张江高科技园区科苑路88号',
    city: '上海',
    riskRating: 'B',
    policyCount: 2,
    claimCount: 0,
    paymentStatus: '良好',
    relationshipManager: '李娜 (东区经纪部)',
    channel: '中信保险经纪',
    creditScore: 92,
    createdAt: '2025-08-20',
    updatedAt: '2026-08-15'
  },
  {
    id: 'cust-103',
    customerNo: 'CN-2026-3001',
    name: '林志远',
    type: 'INDIVIDUAL',
    idType: '身份证',
    idNoMasked: '1101051988****1234',
    phoneMasked: '186****5678',
    emailMasked: 'linzy****@gmail.demo',
    address: '北京市朝阳区建国门外大街1号国贸公寓',
    city: '北京',
    riskRating: 'A',
    policyCount: 2,
    claimCount: 0,
    paymentStatus: '良好',
    relationshipManager: '王芳 (个人营销中心)',
    channel: '个人代理人渠道',
    creditScore: 95,
    createdAt: '2026-01-15',
    updatedAt: '2026-09-10'
  },
  {
    id: 'cust-104',
    customerNo: 'CN-2026-3002',
    name: '陈静雅',
    type: 'INDIVIDUAL',
    idType: '身份证',
    idNoMasked: '4403011992****882X',
    phoneMasked: '137****9012',
    emailMasked: 'chenjy****@163.demo',
    address: '深圳市南山区科技园粤海街道1001号',
    city: '深圳',
    riskRating: 'B',
    policyCount: 1,
    claimCount: 1,
    paymentStatus: '良好',
    relationshipManager: '周明 (华南分公司)',
    channel: '华安官微线上网销',
    creditScore: 89,
    createdAt: '2026-03-22',
    updatedAt: '2026-09-14'
  }
];

// 初始保单列表
export const initialPolicies: Policy[] = [
  {
    id: 'pol-5001',
    policyNo: 'HA-POL-2026-009801',
    quoteNo: 'QT-2026-0911-01',
    customerId: 'cust-101',
    customerName: '华为数字技术 (北京) 有限公司',
    productId: 'prod-002',
    productName: '华安企财臻享综合财产保险',
    productVersion: 'v1.1',
    lineOfBusiness: 'CORP_PROPERTY',
    sumInsured: 50000000,
    annualPremium: 425000,
    startDate: '2026-01-01',
    endDate: '2026-12-31',
    status: 'ACTIVE',
    paymentPlan: '一次性趸交',
    paymentStatus: 'PAID',
    beneficiaries: ['华为数字技术 (北京) 有限公司'],
    channel: '企业直销渠道',
    underwriterName: '赵国强 (资深核保专家)',
    issuanceDate: '2025-12-28'
  },
  {
    id: 'pol-5002',
    policyNo: 'HA-POL-2026-009802',
    quoteNo: 'QT-2026-0912-05',
    customerId: 'cust-103',
    customerName: '林志远',
    productId: 'prod-001',
    productName: '华安极速车险综合保障计划',
    productVersion: 'v2.0',
    lineOfBusiness: 'VEHICLE',
    sumInsured: 1350000,
    annualPremium: 8650,
    startDate: '2026-02-15',
    endDate: '2027-02-14',
    status: 'ACTIVE',
    paymentPlan: '一次性趸交',
    paymentStatus: 'PAID',
    beneficiaries: ['林志远'],
    channel: '个人代理人渠道',
    underwriterName: '自动核保引擎 v3.6',
    issuanceDate: '2026-02-14'
  },
  {
    id: 'pol-5003',
    policyNo: 'HA-POL-2026-009803',
    quoteNo: 'QT-2026-0915-12',
    customerId: 'cust-102',
    customerName: '上海张江高科物流服务有限公司',
    productId: 'prod-004',
    productName: '华安云盾企业网络安全与数据泄露保险',
    productVersion: 'v1.0',
    lineOfBusiness: 'CYBER',
    sumInsured: 30000000,
    annualPremium: 390000,
    startDate: '2026-04-01',
    endDate: '2027-03-31',
    status: 'ACTIVE',
    paymentPlan: '按年分期',
    paymentStatus: 'PAID',
    beneficiaries: ['上海张江高科物流服务有限公司'],
    channel: '中信保险经纪',
    underwriterName: '钱敏 (网络风险核保员)',
    issuanceDate: '2026-03-29'
  }
];

// 初始理赔案件
export const initialClaims: ClaimCase[] = [
  {
    id: 'claim-901',
    claimNo: 'HA-CLM-2026-00412',
    policyNo: 'HA-POL-2026-009801',
    customerName: '华为数字技术 (北京) 有限公司',
    productName: '华安企财臻享综合财产保险',
    accidentDate: '2026-07-20',
    reportDate: '2026-07-21',
    accidentLocation: '北京海淀研发园区B3栋地下发电机房',
    accidentType: '暴雨积水导致水浸设备损坏',
    description: '特大暴雨造成园区地管倒灌，B3栋地下室机房部分高压柜及备用发电机浸水短路。',
    estimatedLoss: 1200000,
    initialReserve: 1200000,
    adjustedReserve: 1100000,
    assessedLoss: 1050000,
    paidAmount: 1050000,
    status: 'CLOSED',
    riskScore: 12,
    fraudAlerts: [],
    assignedHandler: '孙理理 (财产险理赔主管)',
    documents: [
      { name: '公估公司现场查勘报告.pdf', url: '#', uploadedAt: '2026-07-23' },
      { name: '气象局暴雨证明文件.pdf', url: '#', uploadedAt: '2026-07-22' },
      { name: '设备维修与替换发票清单.xlsx', url: '#', uploadedAt: '2026-07-28' }
    ]
  },
  {
    id: 'claim-902',
    claimNo: 'HA-CLM-2026-00418',
    policyNo: 'HA-POL-2026-009802',
    customerName: '林志远',
    productName: '华安极速车险综合保障计划',
    accidentDate: '2026-09-02',
    reportDate: '2026-09-02',
    accidentLocation: '北京市朝阳区京通快速辅路',
    accidentType: '机动车轻微刮蹭事故',
    description: '在早高峰变道过程中与三方车辆发生轻微追尾刮蹭，现场已快速理赔扣留照片。',
    estimatedLoss: 4500,
    initialReserve: 5000,
    adjustedReserve: 4500,
    assessedLoss: 4200,
    paidAmount: 0,
    status: 'APPROVING',
    riskScore: 25,
    fraudAlerts: ['现场照片EXIF时间与报案时间偏差约15分钟 (正常)'],
    assignedHandler: '刘可 (车险快速理赔员)',
    documents: [
      { name: '交警快速处理协议书.jpg', url: '#', uploadedAt: '2026-09-02' },
      { name: '4S店损毁定损单.pdf', url: '#', uploadedAt: '2026-09-03' }
    ]
  }
];

// 初始会计分录 (Insurance Technical Accounting Entries)
export const initialAccountingEntries: AccountingEntry[] = [
  {
    id: 'acc-1',
    entryNo: 'ACC-2026-000101',
    businessEventType: '保费收取',
    relatedDocNo: 'HA-POL-2026-009801',
    debitAccount: '1002 银行存款',
    creditAccount: '6001 保费收入 - 企财险',
    amount: 425000,
    accountingDate: '2026-01-01',
    operator: '系统自动转记',
    auditStatus: 'VERIFIED'
  },
  {
    id: 'acc-2',
    entryNo: 'ACC-2026-000102',
    businessEventType: '提取未赚保费准备金',
    relatedDocNo: 'HA-POL-2026-009801',
    debitAccount: '6401 提取未赚保费准备金',
    creditAccount: '2601 未赚保费准备金',
    amount: 212500,
    accountingDate: '2026-01-01',
    operator: '精算与财务接口',
    auditStatus: 'VERIFIED'
  },
  {
    id: 'acc-3',
    entryNo: 'ACC-2026-000801',
    businessEventType: '理赔赔付',
    relatedDocNo: 'HA-CLM-2026-00412',
    debitAccount: '6402 赔付支出 - 企财险',
    creditAccount: '1002 银行存款',
    amount: 1050000,
    accountingDate: '2026-08-05',
    operator: '财务出纳 - 宋洁',
    auditStatus: 'VERIFIED'
  }
];

// 初始再保险合同
export const initialReinsuranceContracts: ReinsuranceContract[] = [
  {
    id: 'reins-01',
    contractNo: 'RI-TRE-2026-PROP',
    reinsurerName: '中国财产再保险有限责任公司 (China Re)',
    type: '比例再保险(Quota Share)',
    cessionRate: 30.0,
    retentionLimit: 20000000,
    signedAmount: 150000000,
    cededPremium: 127500,
    cededClaims: 315000,
    effectiveDate: '2026-01-01'
  },
  {
    id: 'reins-02',
    contractNo: 'RI-TRE-2026-XOL',
    reinsurerName: '慕尼黑再保险公司 (Munich Re)',
    type: '超额赔款再保险(Excess of Loss)',
    cessionRate: 50.0,
    retentionLimit: 10000000,
    signedAmount: 300000000,
    cededPremium: 850000,
    cededClaims: 0,
    effectiveDate: '2026-01-01'
  }
];

// 精算与风控大盘模拟指标
export const currentActuarialMetrics: ActuarialMetrics = {
  earnedPremium: 185400000,
  incurredClaims: 107902800,
  lossRatio: 58.2,
  expenseRatio: 35.6,
  combinedRatio: 93.8,
  solvencyMargin: 248.5,
  ibnrReserve: 38500000
};

// 费率引擎与算力函数 (Rating Calculation Engine)
export function calculateInsuranceRating(params: {
  product: InsuranceProduct;
  sumInsured: number;
  riskFactor?: number;      // 风险因子 (e.g. 0.8 ~ 1.8)
  regionalFactor?: number;  // 区域因子 (e.g. 北京1.0, 沿海台风区1.2)
  ageVehicleFactor?: number;// 年龄/车龄/职业因子
  deductibleDiscount?: number;// 免赔额折扣
}): {
  basePremium: number;
  adjustedPremium: number;
  discountAmount: number;
  finalPremium: number;
  breakdown: string[];
} {
  const { product, sumInsured, riskFactor = 1.0, regionalFactor = 1.0, ageVehicleFactor = 1.0, deductibleDiscount = 0.95 } = params;
  
  // 基础保费 = 保额 * (基础费率 / 100)
  const basePremium = Math.round(sumInsured * (product.baseRate / 100));
  
  // 风险调整保费 = 基础保费 * 风险因子 * 区域因子 * 行业/车辆/年龄因子
  const adjustedPremium = Math.round(basePremium * riskFactor * regionalFactor * ageVehicleFactor);
  
  // 优惠与调整折扣
  const finalPremium = Math.round(adjustedPremium * deductibleDiscount);
  const discountAmount = Math.max(0, adjustedPremium - finalPremium);

  const breakdown = [
    `基础保额: ¥${sumInsured.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}`,
    `基础费率: ${product.baseRate}% -> 基础保费 ¥${basePremium.toLocaleString()}`,
    `综合风险调整因子: ${riskFactor} (风险) x ${regionalFactor} (区域) x ${ageVehicleFactor} (职业/车型)`,
    `免赔额优惠折扣率: ${(deductibleDiscount * 100).toFixed(1)}%`,
    `应缴最终保费: ¥${finalPremium.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}`
  ];

  return {
    basePremium,
    adjustedPremium,
    discountAmount,
    finalPremium,
    breakdown
  };
}

// 核保规则引擎测试函数 (Underwriting Rules Engine)
export function runUnderwritingRules(params: {
  sumInsured: number;
  premium: number;
  riskRating: 'A' | 'B' | 'C' | 'D';
  claimCount: number;
  customerType: string;
}): {
  score: number;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  triggeredRules: { ruleId: string; description: string; action: string }[];
  recommendation: 'STANDARD' | 'CONDITIONAL' | 'RATE_LOADING' | 'EXTRA_DOCS' | 'MANUAL_AUDIT' | 'DECLINED';
  reasoning: string;
} {
  const triggeredRules = [];
  let score = 20; // 基础基准分数

  if (params.sumInsured > 10000000) {
    triggeredRules.push({
      ruleId: 'UW-R-01',
      description: '保额超过 ¥10,000,000.00 超大保额限制阈值',
      action: '触发高级核保主管人工复核及再保险查勘'
    });
    score += 35;
  }

  if (params.riskRating === 'C' || params.riskRating === 'D') {
    triggeredRules.push({
      ruleId: 'UW-R-02',
      description: '客户风险评级为高风险级别 (C/D级)',
      action: '强制要求上传企业近三年财务审计报告与安评文件'
    });
    score += 30;
  }

  if (params.claimCount >= 2) {
    triggeredRules.push({
      ruleId: 'UW-R-03',
      description: '历史理赔记录超过2起 (出险率偏高)',
      action: '建议费率上浮15%~25%并提高免赔额'
    });
    score += 25;
  }

  let riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' = 'LOW';
  let recommendation: 'STANDARD' | 'CONDITIONAL' | 'RATE_LOADING' | 'EXTRA_DOCS' | 'MANUAL_AUDIT' | 'DECLINED' = 'STANDARD';
  let reasoning = '客户风险状况良好，各项指标均符合标准承保要求。';

  if (score >= 75) {
    riskLevel = 'CRITICAL';
    recommendation = 'MANUAL_AUDIT';
    reasoning = '系统检测到多项高风险因子（高保额/高出险率），需授权高级核保专家人工会签决议。';
  } else if (score >= 50) {
    riskLevel = 'HIGH';
    recommendation = 'RATE_LOADING';
    reasoning = '风险评分中偏高，建议应用10%~15%加费规则后附条件承保。';
  } else if (score >= 35) {
    riskLevel = 'MEDIUM';
    recommendation = 'EXTRA_DOCS';
    reasoning = '需补充相关查勘报告及免赔额协议后放行出单。';
  }

  return {
    score,
    riskLevel,
    triggeredRules,
    recommendation,
    reasoning
  };
}

export const initialUWTasks: UWTask[] = [
  {
    id: 'uwt-8001',
    taskNo: 'UW-2026-001',
    quoteId: 'QT-2026-0911-01',
    customerName: '华为数字技术 (北京) 有限公司',
    productName: '华安企财臻享综合财产保险',
    sumInsured: 50000000,
    calculatedPremium: 425000,
    riskScore: 78,
    riskLevel: 'CRITICAL',
    status: 'PENDING',
    triggeredRules: [
      { ruleId: 'UW-R-01', description: '企财险保额超过 1,000 万元大额拦截阈值', action: '转高级核保主管会签过会' },
      { ruleId: 'UW-R-04', description: '机房水浸风险评估需提交现场安防查勘报告', action: '要求补充防汛设施证明' }
    ],
    aiRecommendation: 'MANUAL_AUDIT',
    aiReasoning: '该投保主体为大型高科技企业，资产规模大，发电机房及服务器机房价值极高，建议附带防汛免赔额特约后人工核准承保。',
    assignedTo: '张国强 (资深核保专家)',
    createdAt: '2026-09-16 14:20:00'
  },
  {
    id: 'uwt-8002',
    taskNo: 'UW-2026-002',
    quoteId: 'QT-2026-0915-08',
    customerName: '上海张江高科物流服务有限公司',
    productName: '华安网络安全防范与损失补偿保险',
    sumInsured: 15000000,
    calculatedPremium: 185000,
    riskScore: 42,
    riskLevel: 'MEDIUM',
    status: 'PENDING',
    triggeredRules: [
      { ruleId: 'UW-R-02', description: '首次投保网络安全险且无等保三级认证', action: '要求补充网络安全渗透测试报告' }
    ],
    aiRecommendation: 'EXTRA_DOCS',
    aiReasoning: '企业具备基础防火墙，但缺少第三方攻防演练报告，建议补充证明材料后标准放行。',
    assignedTo: '李核保 (网络险专项团队)',
    createdAt: '2026-09-17 08:45:00'
  }
];
