package com.example.ui.driver

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.MainViewModel
import com.example.ui.components.CustomMapCanvas

@Composable
fun DriverPortal(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val drivers by viewModel.simulator.drivers.collectAsState()
    val activeDriverId by viewModel.activeDriverId.collectAsState()
    val driver = drivers.find { it.driverId == activeDriverId } ?: return
    val vehicle = viewModel.simulator.vehicles[driver.activeVehicleId] ?: return

    val offer by viewModel.driverOffer.collectAsState()
    val countdown by viewModel.driverOfferCountdown.collectAsState()
    val safetyInput by viewModel.safetyCodeInput.collectAsState()
    val navSteps by viewModel.driverNavSteps.collectAsState()

    val rides by viewModel.simulator.rides.collectAsState()
    // Current active ride for this driver
    val activeRide = rides.find { r -> 
        r.driverId == activeDriverId && r.status != RideStatus.COMPLETED && r.status != RideStatus.CANCELLED 
    }
    val trip = activeRide?.let { viewModel.simulator.trips.value[it.rideId] }

    Box(modifier = modifier.fillMaxSize()) {
        // 1. Full Bleed Map Layer showing H3 Cells Heatmap for demand hotspots
        CustomMapCanvas(
            modifier = Modifier.fillMaxSize(),
            riderLocation = activeRide?.let { LocationPoint(it.currentLat, it.currentLng) },
            destinationLocation = activeRide?.let { Pair(it.currentLat, it.currentLng) },
            drivers = drivers,
            activeRoute = trip?.route,
            h3Cells = viewModel.h3SpatialIndex.cells.values.toList(),
            showH3Heatmap = true,
            supplyDemandMultiplier = { cellId -> 
                viewModel.simulator.demandSupply.getSnapshotForCell(cellId)?.supplyDemandRatio?.let { ratio ->
                    // Return inverse ratio to represent scarcity (scarcity = high multiplier)
                    if (ratio > 0) 1.5 / ratio else 1.0
                } ?: 1.0
            }
        )

        // 2. Navigation turn-by-turn Guidance Card at TOP of the screen (active navigation HUD)
        if (activeRide != null && (activeRide.status == RideStatus.DRIVER_EN_ROUTE || activeRide.status == RideStatus.IN_TRIP) && navSteps.isNotEmpty()) {
            val stepIndex = trip?.currentPointIndex?.coerceAtMost(navSteps.size - 1) ?: 0
            val currentStep = navSteps[stepIndex]

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 40.dp)
                    .align(Alignment.TopCenter)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = when (currentStep.actionType) {
                            "TURN_LEFT" -> Icons.Default.ArrowBack
                            "TURN_RIGHT" -> Icons.Default.ArrowForward
                            "ARRIVED" -> Icons.Default.Flag
                            else -> Icons.Default.Navigation
                        },
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = currentStep.instruction,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "前方 ${currentStep.distanceMeters} 米 · 约 ${currentStep.durationSeconds} 秒",
                            color = Color.White.copy(alpha = 0.8f),
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // 3. Driver Control Hub (Bottom Section)
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(16.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (activeRide == null) {
                // Online/Offline Dashboard
                DriverHomeDashboard(
                    driver = driver,
                    vehicle = vehicle,
                    onOnlineToggle = { viewModel.toggleDriverOnlineState(it) }
                )
            } else {
                // Active Ride Order Tracking Panel
                DriverActiveRideControls(
                    ride = activeRide,
                    driver = driver,
                    vehicle = vehicle,
                    safetyInput = safetyInput,
                    onSafetyChange = { viewModel.updateSafetyCode(it) },
                    onVerifyCode = { viewModel.verifyCodeAndStartTrip() },
                    onNotifyArrived = { viewModel.driverNotifyArrived() }
                )
            }
        }

        // 4. Dispatch Order Proposal Overlay Dialog (Modal-like card)
        offer?.let { order ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.5f))
                    .clickable { /* Block clicks */ },
                contentAlignment = Alignment.Center
            ) {
                DriverOfferOverlay(
                    order = order,
                    countdown = countdown,
                    onAccept = { viewModel.acceptOffer() },
                    onReject = { viewModel.rejectOffer() }
                )
            }
        }
    }
}

// 司机端：主在线状态面板
@Composable
fun DriverHomeDashboard(
    driver: Driver,
    vehicle: Vehicle,
    onOnlineToggle: (Boolean) -> Unit
) {
    val isOnline = driver.status != DriverStatus.OFFLINE

    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text(
                        text = "云行司机平台",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold)
                    )
                    Text(
                        text = "${vehicle.plate} · ${vehicle.brand}${vehicle.model} (${vehicle.type})",
                        fontSize = 12.sp,
                        color = Color(0xFF64748B)
                    )
                }
                Spacer(modifier = Modifier.weight(1f))
                
                // On-Off status switch button
                Button(
                    onClick = { onOnlineToggle(!isOnline) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isOnline) Color(0xFFEF4444) else Color(0xFF10B981)
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("online_toggle_button")
                ) {
                    Text(
                        text = if (isOnline) "收工下线" else "上线接单",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }

            HorizontalDivider(color = Color(0xFFF1F5F9))

            // 收入指标展示段 (今日, 本周, 本月)
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                EarningIndicator("今日总收入", "¥${driver.todayEarnings.toString().substringBefore(".")}", modifier = Modifier.weight(1f))
                EarningIndicator("本周收入", "¥${driver.weeklyEarnings.toString().substringBefore(".")}", modifier = Modifier.weight(1f))
                EarningIndicator("本月总入账", "¥${driver.monthlyEarnings.toString().substringBefore(".")}", modifier = Modifier.weight(1f))
            }

            HorizontalDivider(color = Color(0xFFF1F5F9))

            // 在线时长、今日完成订单等详情表格
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                DetailColumn("今日订单数", "${driver.completedOrders} 单", Icons.Default.DoneAll)
                DetailColumn("在线时长", "${(driver.onlineTimeMinutes / 60)}小时${(driver.onlineTimeMinutes % 60)}分", Icons.Default.QueryBuilder)
                DetailColumn("司机评分", "${driver.rating}", Icons.Default.Star)
            }
        }
    }
}

@Composable
fun EarningIndicator(label: String, valStr: String, modifier: Modifier = Modifier) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
    ) {
        Text(text = label, fontSize = 11.sp, color = Color(0xFF64748B))
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = valStr, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF1E293B))
    }
}

@Composable
fun DetailColumn(label: String, valStr: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = icon, contentDescription = null, tint = Color(0xFF64748B), modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(text = label, fontSize = 11.sp, color = Color(0xFF64748B))
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = valStr, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E293B))
    }
}

// 司机端：订单派发请求弹出对话框 (带有15s倒计时)
@Composable
fun DriverOfferOverlay(
    order: RideRequest,
    countdown: Int,
    onAccept: () -> Unit,
    onReject: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 16.dp),
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.NotificationImportant,
                    contentDescription = null,
                    tint = Color(0xFFEA580C),
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "收到新订单推送！",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 16.sp,
                    color = Color(0xFFEA580C)
                )
                Spacer(modifier = Modifier.weight(1f))
                
                // Circular Countdown Timer Progress Indicator
                Box(contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(
                        progress = { countdown.toFloat() / 15f },
                        color = Color(0xFFEA580C),
                        trackColor = Color(0xFFFED7AA),
                        modifier = Modifier.size(36.dp)
                    )
                    Text(text = "$countdown", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFFEA580C))
                }
            }

            HorizontalDivider(color = Color(0xFFF1F5F9))

            // 派发订单明细 (上车点、下车点、里程价格、预估时间)
            Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                AddressSummaryLine(Icons.Default.PinDrop, "上车点", order.startAddress, Color(0xFF2563EB))
                AddressSummaryLine(Icons.Default.Place, "下车点", order.endAddress, Color(0xFFEA580C))
            }

            HorizontalDivider(color = Color(0xFFF1F5F9))

            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                EarningIndicator("行程距离", "约 12.4 km", modifier = Modifier.weight(1f))
                EarningIndicator("预计耗时", "28 分钟", modifier = Modifier.weight(1f))
                EarningIndicator("预计收益", "¥42.00", modifier = Modifier.weight(1f))
            }

            // 同意、拒绝按钮组
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedButton(
                    onClick = onReject,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFEF4444)),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(text = "拒绝", fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onAccept,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                    modifier = Modifier
                        .weight(1.5f)
                        .testTag("accept_offer_button")
                ) {
                    Text(text = "立即接受", fontWeight = FontWeight.ExtraBold)
                }
            }
        }
    }
}

@Composable
fun AddressSummaryLine(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, addr: String, iconColor: Color) {
    Row(verticalAlignment = Alignment.Top) {
        Icon(imageVector = icon, contentDescription = null, tint = iconColor, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Column {
            Text(text = label, fontSize = 11.sp, color = Color(0xFF64748B))
            Text(text = addr, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF1E293B))
        }
    }
}

// 司机端：进行中行程的操作面板 (接客、到场、核对、送客)
@Composable
fun DriverActiveRideControls(
    ride: Ride,
    driver: Driver,
    vehicle: Vehicle,
    safetyInput: String,
    onSafetyChange: (String) -> Unit,
    onVerifyCode: () -> Unit,
    onNotifyArrived: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "当前执行订单中",
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            )

            when (ride.status) {
                RideStatus.DRIVER_EN_ROUTE -> {
                    // Pre-arrival panel: Button "I have arrived"
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "请前往上车地点接乘客",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color(0xFF1E293B)
                        )
                        Text(
                            text = "上车点: 上海市浦东新区张江科学城",
                            fontSize = 12.sp,
                            color = Color(0xFF64748B)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        
                        Button(
                            onClick = onNotifyArrived,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("driver_arrived_button")
                        ) {
                            Text(text = "我已到达上车点", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                RideStatus.DRIVER_ARRIVED -> {
                    // Safety Code check screen to start trip
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "核对行程安全码",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color(0xFF1E293B)
                        )
                        Text(
                            text = "为了保障双方出行安全，请向乘客核对并输入其App中显示的【4位行程安全码】以开启行程：",
                            fontSize = 12.sp,
                            color = Color(0xFF64748B)
                        )
                        
                        OutlinedTextField(
                            value = safetyInput,
                            onValueChange = onSafetyChange,
                            placeholder = { Text("请输入4位数字安全码") },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("safety_code_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MaterialTheme.colorScheme.secondary,
                                unfocusedBorderColor = Color(0xFFE2E8F0)
                            )
                        )

                        Button(
                            onClick = onVerifyCode,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("verify_code_button")
                        ) {
                            Text(text = "验证并开始行程", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                RideStatus.IN_TRIP -> {
                    // In-transit navigation indicator
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "正在护送乘客前往目的地...",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = Color(0xFF10B981)
                            )
                        }
                        Text(
                            text = "实时计价、行程安全盾和防偏航报警器正在后台平稳运行中...",
                            fontSize = 11.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                }

                else -> {}
            }
        }
    }
}
