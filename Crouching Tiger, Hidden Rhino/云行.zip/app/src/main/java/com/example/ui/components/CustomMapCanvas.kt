package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.H3Hexagon
import com.example.data.Driver
import com.example.data.LocationPoint
import com.example.data.Route
import kotlin.math.cos
import kotlin.math.sin

@OptIn(ExperimentalTextApi::class)
@Composable
fun CustomMapCanvas(
    modifier: Modifier = Modifier,
    riderLocation: LocationPoint?,
    destinationLocation: Pair<Double, Double>?,
    drivers: List<Driver>,
    activeRoute: Route?,
    h3Cells: List<H3Hexagon> = emptyList(),
    selectedCellId: String? = null,
    showH3Heatmap: Boolean = false,
    supplyDemandMultiplier: (String) -> Double = { 1.0 }
) {
    // Coordinate bounds of central-eastern Shanghai
    val minLat = 31.08
    val maxLat = 31.28
    val minLng = 121.28
    val maxLng = 121.68

    // For smooth route animation (pulsing dashes)
    val infiniteTransition = rememberInfiniteTransition(label = "route_pulse")
    val dashOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 60f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "dash_offset"
    )

    val textMeasurer = rememberTextMeasurer()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF1F5F9)) // Warm neutral light canvas
            .testTag("custom_map_canvas")
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            // Coordinate conversion helpers
            fun toScreenX(lng: Double): Float {
                val fraction = (lng - minLng) / (maxLng - minLng)
                return (fraction * width).toFloat()
            }

            fun toScreenY(lat: Double): Float {
                // Latitudes increase going upwards, so we subtract fraction from 1
                val fraction = (lat - minLat) / (maxLat - minLat)
                return ((1.0 - fraction) * height).toFloat()
            }

            // 1. Draw the beautiful flowing Huangpu River (上海母亲河 - 黄浦江)
            // A smooth cubic bezier curve reflecting real river layout in Shanghai
            val riverPath = Path().apply {
                val p1 = Offset(toScreenX(121.43), toScreenY(31.09))
                val p2 = Offset(toScreenX(121.47), toScreenY(31.18))
                val p3 = Offset(toScreenX(121.50), toScreenY(31.24)) // Lujiazui bend
                val p4 = Offset(toScreenX(121.58), toScreenY(31.27))

                moveTo(p1.x, p1.y)
                cubicTo(p2.x, p2.y, p3.x, p3.y, p4.x, p4.y)
            }
            drawPath(
                path = riverPath,
                color = Color(0xFF93C5FD).copy(alpha = 0.5f), // Soft river blue
                style = Stroke(width = 30f, cap = StrokeCap.Round)
            )

            // 2. Draw Major Shanghai Highroads & Expressways (延安高架、中环、外环)
            // East-West highway (Yan'an Elevated road)
            drawLine(
                color = Color.White,
                start = Offset(toScreenX(121.28), toScreenY(31.22)),
                end = Offset(toScreenX(121.68), toScreenY(31.22)),
                strokeWidth = 12f,
                cap = StrokeCap.Round
            )
            drawLine(
                color = Color(0xFFCBD5E1), // inner road stroke
                start = Offset(toScreenX(121.28), toScreenY(31.22)),
                end = Offset(toScreenX(121.68), toScreenY(31.22)),
                strokeWidth = 6f
            )

            // North-South Highway (Century Avenue & Inner Ring link)
            drawLine(
                color = Color.White,
                start = Offset(toScreenX(121.48), toScreenY(31.08)),
                end = Offset(toScreenX(121.48), toScreenY(31.28)),
                strokeWidth = 10f
            )
            drawLine(
                color = Color(0xFFCBD5E1),
                start = Offset(toScreenX(121.48), toScreenY(31.08)),
                end = Offset(toScreenX(121.48), toScreenY(31.28)),
                strokeWidth = 5f
            )

            // 3. Draw Simulated H3 Hexagonal Grids / Hotspots
            if (showH3Heatmap && h3Cells.isNotEmpty()) {
                h3Cells.forEach { cell ->
                    val multiplier = supplyDemandMultiplier(cell.id)
                    // High multiplier = high demand = hot orange-red
                    val cellColor = when {
                        multiplier > 1.5 -> Color(0xFFEA580C).copy(alpha = 0.35f) // Hot
                        multiplier > 1.1 -> Color(0xFFF97316).copy(alpha = 0.2f)  // Warm
                        else -> Color(0xFF10B981).copy(alpha = 0.12f)            // Balanced green
                    }

                    val borderColor = when {
                        cell.id == selectedCellId -> Color(0xFF2563EB).copy(alpha = 0.9f)
                        multiplier > 1.5 -> Color(0xFFEA580C).copy(alpha = 0.7f)
                        else -> Color(0xFF94A3B8).copy(alpha = 0.4f)
                    }

                    val polyPath = Path().apply {
                        cell.vertices.forEachIndexed { idx, vertex ->
                            val sx = toScreenX(vertex.second)
                            val sy = toScreenY(vertex.first)
                            if (idx == 0) moveTo(sx, sy) else lineTo(sx, sy)
                        }
                        close()
                    }

                    // Fill cell
                    drawPath(path = polyPath, color = cellColor)
                    // Stroke border
                    drawPath(
                        path = polyPath,
                        color = borderColor,
                        style = Stroke(width = if (cell.id == selectedCellId) 6f else 3f)
                    )

                    // Draw tiny label
                    val textLayout = textMeasurer.measure(
                        text = cell.name.take(3),
                        style = TextStyle(color = Color(0xFF475569), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    )
                    drawText(
                        textLayout,
                        topLeft = Offset(toScreenX(cell.centerLng) - 25f, toScreenY(cell.centerLat) - 10f)
                    )
                }
            }

            // 4. Draw Landmark Indicators
            drawLandmark(textMeasurer, "上海虹桥站", 121.3204, 31.1944, ::toScreenX, ::toScreenY)
            drawLandmark(textMeasurer, "陆家嘴金融中心", 121.4998, 31.2397, ::toScreenX, ::toScreenY)
            drawLandmark(textMeasurer, "浦东国际机场", 121.8083, 31.1443, ::toScreenX, ::toScreenY)
            drawLandmark(textMeasurer, "张江高科技园", 121.5937, 31.2064, ::toScreenX, ::toScreenY)

            // 5. Draw Active Route Line (推荐路线)
            if (activeRoute != null && activeRoute.points.isNotEmpty()) {
                val routePath = Path().apply {
                    val first = activeRoute.points.first()
                    moveTo(toScreenX(first.longitude), toScreenY(first.latitude))
                    activeRoute.points.forEach { pt ->
                        lineTo(toScreenX(pt.longitude), toScreenY(pt.latitude))
                    }
                }

                // Draw outer glowing shadow line
                drawPath(
                    path = routePath,
                    color = Color(0xFF3B82F6).copy(alpha = 0.3f),
                    style = Stroke(width = 16f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                )

                // Draw main solid route line with animated dash effect
                drawPath(
                    path = routePath,
                    color = Color(0xFF2563EB), // Rich transit blue
                    style = Stroke(
                        width = 8f,
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round,
                        pathEffect = PathEffect.dashPathEffect(
                            intervals = floatArrayOf(30f, 25f),
                            phase = dashOffset
                        )
                    )
                )
            }

            // 6. Draw Moving Drivers (云行在线车辆)
            drivers.forEach { driver ->
                val drvX = toScreenX(driver.currentLng)
                val drvY = toScreenY(driver.currentLat)

                val carColor = when (driver.status) {
                    com.example.data.DriverStatus.ONLINE -> Color(0xFF10B981) // Green for empty/online
                    com.example.data.DriverStatus.TRIP -> Color(0xFF2563EB)   // Blue for occupied/on-trip
                    else -> Color(0xFFF97316)                                 // Orange for busy/assigned
                }

                // Draw a sleek triangular vehicle marker reflecting direction and bearing
                val size = 28f
                val headingRad = Math.toRadians(driver.bearing.toDouble())
                
                val p1 = Offset(
                    (drvX + size * sin(headingRad)).toFloat(),
                    (drvY - size * cos(headingRad)).toFloat()
                )
                val p2 = Offset(
                    (drvX + size * 0.6 * sin(headingRad + 2.5)).toFloat(),
                    (drvY - size * 0.6 * cos(headingRad + 2.5)).toFloat()
                )
                val p3 = Offset(
                    (drvX + size * 0.6 * sin(headingRad - 2.5)).toFloat(),
                    (drvY - size * 0.6 * cos(headingRad - 2.5)).toFloat()
                )

                val carPath = Path().apply {
                    moveTo(p1.x, p1.y)
                    lineTo(p2.x, p2.y)
                    lineTo(p3.x, p3.y)
                    close()
                }

                // Car glow shadow
                drawCircle(
                    color = carColor.copy(alpha = 0.35f),
                    radius = 24f,
                    center = Offset(drvX, drvY)
                )

                // Draw car body
                drawPath(path = carPath, color = carColor)
                drawPath(path = carPath, color = Color.White, style = Stroke(width = 3f))
            }

            // 7. Draw Rider Origin Pin (上车点)
            if (riderLocation != null) {
                val rx = toScreenX(riderLocation.longitude)
                val ry = toScreenY(riderLocation.latitude)

                // Pulse effect under passenger
                val pulseRadius = 14f + (dashOffset % 20f)
                drawCircle(
                    color = Color(0xFF2563EB).copy(alpha = (1.0f - (dashOffset / 60f)).coerceIn(0f, 0.4f)),
                    radius = pulseRadius,
                    center = Offset(rx, ry)
                )

                // Pin Base
                drawCircle(color = Color(0xFF2563EB), radius = 10f, center = Offset(rx, ry))
                drawCircle(color = Color.White, radius = 5f, center = Offset(rx, ry))
            }

            // 8. Draw Selected Destination Pin (下车点)
            if (destinationLocation != null) {
                val dx = toScreenX(destinationLocation.second)
                val dy = toScreenY(destinationLocation.first)

                // Dynamic pin drop drawing
                val path = Path().apply {
                    moveTo(dx, dy)
                    cubicTo(dx - 12, dy - 24, dx + 12, dy - 24, dx, dy)
                }
                drawCircle(color = Color(0xFFEA580C), radius = 11f, center = Offset(dx, dy - 24f))
                drawCircle(color = Color.White, radius = 4f, center = Offset(dx, dy - 24f))
                
                drawLine(
                    color = Color(0xFFEA580C),
                    start = Offset(dx, dy),
                    end = Offset(dx, dy - 15f),
                    strokeWidth = 5f,
                    cap = StrokeCap.Round
                )
            }
        }
    }
}

@OptIn(ExperimentalTextApi::class)
private fun DrawScope.drawLandmark(
    textMeasurer: TextMeasurer,
    name: String,
    lng: Double,
    lat: Double,
    toX: (Double) -> Float,
    toY: (Double) -> Float
) {
    val x = toX(lng)
    val y = toY(lat)

    // Landmark Dot
    drawCircle(color = Color(0xFF475569).copy(alpha = 0.25f), radius = 12f, center = Offset(x, y))
    drawCircle(color = Color(0xFF475569), radius = 5f, center = Offset(x, y))

    // Text Label
    val textLayout = textMeasurer.measure(
        text = name,
        style = TextStyle(
            color = Color(0xFF1E293B),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            background = Color.White.copy(alpha = 0.75f)
        )
    )
    drawText(
        textLayout,
        topLeft = Offset(x + 15f, y - 18f)
    )
}
