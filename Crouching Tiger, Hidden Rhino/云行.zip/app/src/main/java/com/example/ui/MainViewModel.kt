package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.CityMobilitySimulator
import com.example.core.EventBus
import com.example.core.H3SpatialIndex
import com.example.core.PlatformEvent
import com.example.data.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class PortalRole {
    RIDER,
    DRIVER,
    ADMIN
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    // 1. Core Engine Simulation reference
    val h3SpatialIndex = H3SpatialIndex()
    val routingProvider = MockRoutingProvider()
    val geocodingProvider = MockGeocodingProvider()
    val navProvider = MockNavigationProvider()
    
    val simulator = CityMobilitySimulator(h3SpatialIndex, routingProvider)

    // 2. Active Portal Selection
    private val _currentRole = MutableStateFlow(PortalRole.RIDER)
    val currentRole: StateFlow<PortalRole> = _currentRole.asStateFlow()

    fun switchRole(role: PortalRole) {
        _currentRole.value = role
    }

    // -------------------------------------------------------------------------
    // RIDER STATES & ACTIONS
    // -------------------------------------------------------------------------
    private val _riderSearchQuery = MutableStateFlow("")
    val riderSearchQuery: StateFlow<String> = _riderSearchQuery.asStateFlow()

    private val _searchResults = MutableStateFlow<List<SearchPlace>>(emptyList())
    val searchResults: StateFlow<List<SearchPlace>> = _searchResults.asStateFlow()

    private val _selectedDestination = MutableStateFlow<SearchPlace?>(null)
    val selectedDestination: StateFlow<SearchPlace?> = _selectedDestination.asStateFlow()

    private val _riderCurrentLocation = MutableStateFlow(LocationPoint(31.1154, 121.4337, provider = "GPS")) // Home
    val riderCurrentLocation: StateFlow<LocationPoint> = _riderCurrentLocation.asStateFlow()

    // Routes
    private val _recommendedRoute = MutableStateFlow<Route?>(null)
    val recommendedRoute: StateFlow<Route?> = _recommendedRoute.asStateFlow()

    private val _alternativeRoute = MutableStateFlow<Route?>(null)
    val alternativeRoute: StateFlow<Route?> = _alternativeRoute.asStateFlow()

    private val _selectedRouteIndex = MutableStateFlow(0) // 0 for recommended, 1 for alternative
    val selectedRouteIndex: StateFlow<Int> = _selectedRouteIndex.asStateFlow()

    // Pricing Options
    private val _estimatedFares = MutableStateFlow<Map<String, Fare>>(emptyMap())
    val estimatedFares: StateFlow<Map<String, Fare>> = _estimatedFares.asStateFlow()

    private val _selectedVehicleType = MutableStateFlow("舒适型")
    val selectedVehicleType: StateFlow<String> = _selectedVehicleType.asStateFlow()

    // Active Ride Request State
    private val _activeRide = MutableStateFlow<Ride?>(null)
    val activeRide: StateFlow<Ride?> = _activeRide.asStateFlow()

    private val _activeRideRoute = MutableStateFlow<Trip?>(null)
    val activeRideRoute: StateFlow<Trip?> = _activeRideRoute.asStateFlow()

    private val _currentRiderStep = MutableStateFlow("HOME") // HOME, SEARCH, SELECT_ROUTE, MATCHING, TRIP, PAYMENT, RATING

    // Selected Coupon
    private val _selectedCoupon = MutableStateFlow<Coupon?>(null)
    val selectedCoupon: StateFlow<Coupon?> = _selectedCoupon.asStateFlow()

    val availableCoupons = listOf(
        Coupon("cp_1", "新客立减券", 10.0, 15.0, System.currentTimeMillis() + 86400000),
        Coupon("cp_2", "晚高峰无门槛", 5.0, 0.0, System.currentTimeMillis() + 86400000),
        Coupon("cp_3", "豪华车型特惠", 20.0, 50.0, System.currentTimeMillis() + 86400000, "豪华型")
    )

    fun updateRiderStep(step: String) {
        _currentRiderStep.value = step
    }
    fun getRiderStep(): String = _currentRiderStep.value

    fun searchDestination(query: String) {
        _riderSearchQuery.value = query
        _searchResults.value = geocodingProvider.searchPlaces(query)
    }

    fun selectDestination(place: SearchPlace) {
        _selectedDestination.value = place
        _riderSearchQuery.value = place.name
        _searchResults.value = emptyList()

        // Calculate routes
        val routeRec = routingProvider.calculateRoute(
            _riderCurrentLocation.value.latitude, _riderCurrentLocation.value.longitude,
            place.latitude, place.longitude, "RECOMMENDED"
        )
        val routeAlt = routingProvider.calculateRoute(
            _riderCurrentLocation.value.latitude, _riderCurrentLocation.value.longitude,
            place.latitude, place.longitude, "ALTERNATIVE"
        )

        _recommendedRoute.value = routeRec
        _alternativeRoute.value = routeAlt
        _selectedRouteIndex.value = 0

        // Calculate prices
        val fares = mutableMapOf<String, Fare>()
        listOf("经济型", "舒适型", "商务型", "豪华型", "六座车").forEach { type ->
            fares[type] = simulator.pricing.calculateEstimate(
                _riderCurrentLocation.value.latitude, _riderCurrentLocation.value.longitude,
                routeRec.distanceKm, routeRec.durationMinutes, type
            )
        }
        _estimatedFares.value = fares
        _currentRiderStep.value = "SELECT_ROUTE"
    }

    fun selectRoute(index: Int) {
        _selectedRouteIndex.value = index
    }

    fun selectVehicleType(type: String) {
        _selectedVehicleType.value = type
        // Reset coupon if inapplicable
        _selectedCoupon.value?.let { cp ->
            if (cp.applicableVehicleType != "全部" && cp.applicableVehicleType != type) {
                _selectedCoupon.value = null
            }
        }
    }

    fun selectCoupon(coupon: Coupon?) {
        _selectedCoupon.value = coupon
    }

    fun callYunXingRide() {
        val dest = _selectedDestination.value ?: return
        val vehicleType = _selectedVehicleType.value
        
        _currentRiderStep.value = "MATCHING"
        
        viewModelScope.launch {
            simulator.requestRide(
                riderId = "rider_tom",
                startLat = _riderCurrentLocation.value.latitude,
                startLng = _riderCurrentLocation.value.longitude,
                startAddr = "我的当前位置",
                endLat = dest.latitude,
                endLng = dest.longitude,
                endAddr = dest.name,
                preferredType = vehicleType
            )
        }
    }

    fun cancelActiveRide() {
        val rideId = _activeRide.value?.rideId ?: return
        simulator.cancelRide(rideId, "乘客行程取消")
        resetRiderWorkflow()
    }

    fun resetRiderWorkflow() {
        _selectedDestination.value = null
        _recommendedRoute.value = null
        _alternativeRoute.value = null
        _estimatedFares.value = emptyMap()
        _activeRide.value = null
        _activeRideRoute.value = null
        _currentRiderStep.value = "HOME"
        _selectedCoupon.value = null
    }

    // -------------------------------------------------------------------------
    // DRIVER STATES & ACTIONS
    // -------------------------------------------------------------------------
    private val _activeDriverId = MutableStateFlow("driver_1") //王师傅
    val activeDriverId: StateFlow<String> = _activeDriverId.asStateFlow()

    private val _driverOffer = MutableStateFlow<RideRequest?>(null)
    val driverOffer: StateFlow<RideRequest?> = _driverOffer.asStateFlow()

    private val _driverOfferCountdown = MutableStateFlow(15)
    val driverOfferCountdown: StateFlow<Int> = _driverOfferCountdown.asStateFlow()

    private val _safetyCodeInput = MutableStateFlow("")
    val safetyCodeInput: StateFlow<String> = _safetyCodeInput.asStateFlow()

    private val _driverNavSteps = MutableStateFlow<List<NavStep>>(emptyList())
    val driverNavSteps: StateFlow<List<NavStep>> = _driverNavSteps.asStateFlow()

    fun updateSafetyCode(code: String) {
        _safetyCodeInput.value = code
    }

    fun getActiveDriver(): Driver? {
        return simulator.drivers.value.find { it.driverId == _activeDriverId.value }
    }

    fun getActiveVehicle(): Vehicle? {
        val drv = getActiveDriver() ?: return null
        return simulator.vehicles[drv.activeVehicleId]
    }

    fun toggleDriverOnlineState(online: Boolean) {
        simulator.toggleDriverOnline(_activeDriverId.value, online)
    }

    fun acceptOffer() {
        val offer = _driverOffer.value ?: return
        // Matching is handled directly by dispatch loop. Let's find the ride
        val ride = simulator.rides.value.find { it.requestId == offer.requestId } ?: return
        _driverOffer.value = null
        // Route steps generate
        val trip = simulator.trips.value[ride.rideId]
        if (trip != null) {
            _driverNavSteps.value = navProvider.generateNavigationSteps(trip.route)
        }
    }

    fun rejectOffer() {
        val offer = _driverOffer.value ?: return
        _driverOffer.value = null
        val ride = simulator.rides.value.find { it.requestId == offer.requestId }
        if (ride != null) {
            simulator.cancelRide(ride.rideId, "司机拒绝接单")
        }
    }

    fun driverNotifyArrived() {
        val ride = simulator.rides.value.find { it.driverId == _activeDriverId.value && it.status == RideStatus.DRIVER_EN_ROUTE } ?: return
        // Simulator update
        arriveDriverManual(ride.rideId)
    }

    private fun arriveDriverManual(rideId: String) {
        // Simple manual trigger if required
    }

    fun verifyCodeAndStartTrip() {
        val code = _safetyCodeInput.value
        val ride = simulator.rides.value.find { it.driverId == _activeDriverId.value && it.status == RideStatus.DRIVER_ARRIVED } ?: return
        val success = simulator.startRideWithCode(ride.rideId, code)
        if (success) {
            _safetyCodeInput.value = ""
            // Regenerate navigation steps for the destination transit
            val trip = simulator.trips.value[ride.rideId]
            if (trip != null) {
                _driverNavSteps.value = navProvider.generateNavigationSteps(trip.route)
            }
        }
    }

    // -------------------------------------------------------------------------
    // WEBSOCKET FLOW SYNC & REALTIME BINDING
    // -------------------------------------------------------------------------
    init {
        viewModelScope.launch {
            EventBus.events.collect { event ->
                when (event) {
                    is PlatformEvent.RideRequested -> {
                        // If driver is online and matching is targeted, trigger dispatch alert
                        val targetDriver = getActiveDriver()
                        // Check if optimal driver assigned is driver_1
                        val ride = simulator.rides.value.find { it.requestId == event.request.requestId }
                        if (ride != null && ride.driverId == _activeDriverId.value) {
                            _driverOffer.value = event.request
                            startOfferCountdown()
                        }
                    }
                    is PlatformEvent.DriverMatched -> {
                        val ride = simulator.rides.value.find { it.rideId == event.rideId }
                        if (ride?.riderId == "rider_tom") {
                            _activeRide.value = ride
                            _currentRiderStep.value = "DRIVER_EN_ROUTE"
                        }
                    }
                    is PlatformEvent.DriverLocationUpdated -> {
                        // Updates of moving markers
                    }
                    is PlatformEvent.TripUpdated -> {
                        val ride = _activeRide.value
                        if (ride != null && ride.rideId == event.rideId) {
                            val activeTrip = simulator.trips.value[event.rideId]
                            _activeRideRoute.value = activeTrip
                            _activeRide.value = ride.copy(
                                currentLat = event.currentLat,
                                currentLng = event.currentLng
                            )
                        }
                    }
                    is PlatformEvent.TripCompleted -> {
                        val ride = _activeRide.value
                        if (ride != null && ride.rideId == event.rideId) {
                            _activeRide.value = ride.copy(status = RideStatus.COMPLETED)
                            _currentRiderStep.value = "PAYMENT"
                        }
                    }
                    is PlatformEvent.PaymentCompleted -> {
                        val ride = _activeRide.value
                        if (ride != null && ride.rideId == event.rideId) {
                            _activeRide.value = ride.copy(status = RideStatus.COMPLETED)
                            _currentRiderStep.value = "RATING"
                        }
                    }
                    is PlatformEvent.RideCancelled -> {
                        val ride = _activeRide.value
                        if (ride != null && ride.rideId == event.rideId) {
                            resetRiderWorkflow()
                        }
                    }
                    else -> {}
                }
            }
        }
    }

    private fun startOfferCountdown() {
        _driverOfferCountdown.value = 15
        viewModelScope.launch {
            while (_driverOffer.value != null && _driverOfferCountdown.value > 0) {
                delay(1000)
                _driverOfferCountdown.value -= 1
            }
            if (_driverOfferCountdown.value == 0 && _driverOffer.value != null) {
                // Expire order offer
                rejectOffer()
            }
        }
    }

    // Ratings feedback submission
    fun submitRiderRating(score: Int, cleanliness: Int, service: Int, comment: String) {
        val ride = _activeRide.value ?: return
        val r = Rating(
            ratingId = "rat_${System.currentTimeMillis() % 100000}",
            rideId = ride.rideId,
            raterId = "rider_tom",
            rateeId = ride.driverId ?: "",
            score = score,
            serviceScore = service,
            cleanlinessScore = cleanliness,
            comment = comment
        )
        // Back to normal
        resetRiderWorkflow()
    }
}
