package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.PortalRole
import com.example.ui.admin.AdminPortal
import com.example.ui.driver.DriverPortal
import com.example.ui.rider.RiderPortal
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        RoleSwitcherBar(
                            currentRole = viewModel.currentRole.collectAsState().value,
                            onRoleSelected = { viewModel.switchRole(it) }
                        )
                    }
                ) { innerPadding ->
                    val activeRole by viewModel.currentRole.collectAsState()
                    
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(bottom = innerPadding.calculateBottomPadding()) // Leave space for role switcher, top is full-bleed map
                    ) {
                        Crossfade(targetState = activeRole, label = "portal_transition") { role ->
                            when (role) {
                                PortalRole.RIDER -> {
                                    RiderPortal(
                                        viewModel = viewModel,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                                PortalRole.DRIVER -> {
                                    DriverPortal(
                                        viewModel = viewModel,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                                PortalRole.ADMIN -> {
                                    AdminPortal(
                                        viewModel = viewModel,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RoleSwitcherBar(
    currentRole: PortalRole,
    onRoleSelected: (PortalRole) -> Unit
) {
    Surface(
        color = Color(0xFF0F172A), // Dark slate theme footer
        tonalElevation = 12.dp,
        modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars) // Ensure safe area at the bottom
            .border(width = 1.dp, color = Color(0xFF1E293B))
    ) {
        Row(
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp, horizontal = 16.dp)
        ) {
            RoleTabItem(
                label = "乘客端",
                icon = Icons.Default.Person,
                isSelected = currentRole == PortalRole.RIDER,
                tag = "rider_portal_tab",
                onClick = { onRoleSelected(PortalRole.RIDER) }
            )

            RoleTabItem(
                label = "司机端",
                icon = Icons.Default.DirectionsCar,
                isSelected = currentRole == PortalRole.DRIVER,
                tag = "driver_portal_tab",
                onClick = { onRoleSelected(PortalRole.DRIVER) }
            )

            RoleTabItem(
                label = "云行大脑",
                icon = Icons.Default.AdminPanelSettings,
                isSelected = currentRole == PortalRole.ADMIN,
                tag = "admin_portal_tab",
                onClick = { onRoleSelected(PortalRole.ADMIN) }
            )
        }
    }
}

@Composable
fun RowScope.RoleTabItem(
    label: String,
    icon: ImageVector,
    isSelected: Boolean,
    tag: String,
    onClick: () -> Unit
) {
    val activeBgColor = Color(0xFF1E293B)
    val activeTextColor = Color(0xFF38BDF8) // High visibility cyan text
    val inactiveTextColor = Color(0xFF94A3B8)

    Box(
        modifier = Modifier
            .weight(1f)
            .height(52.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSelected) activeBgColor else Color.Transparent)
            .clickable { onClick() }
            .testTag(tag),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isSelected) activeTextColor else inactiveTextColor,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = label,
                color = if (isSelected) activeTextColor else inactiveTextColor,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium
            )
        }
    }
}

