package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// 品牌核心调色板：高级低饱和、现代都市、高安全感
val YunXingPrimary = Color(0xFF1E293B) // 深板岩灰
val YunXingSecondary = Color(0xFF2563EB) // 都市低饱和蓝
val YunXingTertiary = Color(0xFFEA580C) // 警示与价格橙

val YunXingDark = Color(0xFF0F172A)
val YunXingLight = Color(0xFFF8FAFC)
val YunXingAccent = Color(0xFF10B981) // 绿色状态标识

val SafetyRed = Color(0xFFEF4444) // 紧急报警红
val NeutralLight = Color(0xFFF1F5F9)
val NeutralMedium = Color(0xFF64748B)
val NeutralDark = Color(0xFF1E293B)

