package com.example.ui.rider

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.MainViewModel
import com.example.ui.components.CustomMapCanvas

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RiderPortal(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val currentStep by viewModel.riderCurrentLocation.collectAsState() // trigger reload
    val riderStep = viewModel.getRiderStep()
    
    val selectedDest by viewModel.selectedDestination.collectAsState()
    val searchQuery by viewModel.riderSearchQuery.collectAsState()
    val searchResults by viewModel.searchResults.collectAsState()
    val recRoute by viewModel.recommendedRoute.collectAsState()
    val altRoute by viewModel.alternativeRoute.collectAsState()
    val selectedRouteIdx by viewModel.selectedRouteIndex.collectAsState()
    val fares by viewModel.estimatedFares.collectAsState()
    val selectedType by viewModel.selectedVehicleType.collectAsState()
    val activeRide by viewModel.activeRide.collectAsState()
    val activeTripRoute by viewModel.activeRideRoute.collectAsState()
    val selectedCoupon by viewModel.selectedCoupon.collectAsState()

    val drivers by viewModel.simulator.drivers.collectAsState()

    // Base coordinates
    val riderPos = viewModel.riderCurrentLocation.collectAsState().value
    val destPos = selectedDest?.let { Pair(it.latitude, it.longitude) }
    val activeRouteLine = if (selectedRouteIdx == 0) recRoute else altRoute

    Box(modifier = modifier.fillMaxSize()) {
        // 1. Full Bleed Map Layer
        CustomMapCanvas(
            modifier = Modifier.fillMaxSize(),
            riderLocation = riderPos,
            destinationLocation = destPos,
            drivers = drivers,
            activeRoute = activeRouteLine ?: activeTripRoute?.route
        )

        // 2. Rider Floating UI Sheet Container
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(16.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when (riderStep) {
                "HOME" -> {
                    RiderHomeCard(
                        searchQuery = searchQuery,
                        onQueryChange = { viewModel.searchDestination(it) },
                        onSearchTrigger = { viewModel.updateRiderStep("SEARCH") },
                        presetPlaces = viewModel.geocodingProvider.presetPlaces,
                        onSelectPlace = { viewModel.selectDestination(it) }
                    )
                }

                "SEARCH" -> {
                    RiderSearchCard(
                        query = searchQuery,
                        onQueryChange = { viewModel.searchDestination(it) },
                        results = searchResults,
                        onSelect = { viewModel.selectDestination(it) },
                        onBack = { viewModel.resetRiderWorkflow() }
                    )
                }

                "SELECT_ROUTE" -> {
                    RiderSelectRouteCard(
                        startAddr = "我的当前位置",
                        destAddr = selectedDest?.name ?: "目的地",
                        recRoute = recRoute,
                        altRoute = altRoute,
                        selectedRouteIdx = selectedRouteIdx,
                        onSelectRoute = { viewModel.selectRoute(it) },
                        fares = fares,
                        selectedType = selectedType,
                        onSelectType = { viewModel.selectVehicleType(it) },
                        coupons = viewModel.availableCoupons,
                        selectedCoupon = selectedCoupon,
                        onSelectCoupon = { viewModel.selectCoupon(it) },
                        onConfirm = { viewModel.callYunXingRide() },
                        onBack = { viewModel.resetRiderWorkflow() }
                    )
                }

                "MATCHING" -> {
                    RiderMatchingCard(
                        onCancel = { viewModel.cancelActiveRide() }
                    )
                }

                "DRIVER_EN_ROUTE" -> {
                    activeRide?.let { ride ->
                        RiderDriverArrivingCard(
                            ride = ride,
                            vehicle = viewModel.simulator.vehicles[ride.vehicleId]!!,
                            driver = viewModel.simulator.drivers.value.find { it.driverId == ride.driverId }!!,
                            trip = viewModel.simulator.trips.value[ride.rideId],
                            onCancel = { viewModel.cancelActiveRide() }
                        )
                    }
                }

                "PAYMENT" -> {
                    activeRide?.let { ride ->
                        val trip = viewModel.simulator.trips.value[ride.rideId]
                        val finalFare = fares[selectedType] ?: Fare(ride.rideId, 15.0, 20.0, 10.0, 3.0, 1.0, 0.0, 0.0, 48.0)
                        RiderPaymentCard(
                            amount = finalFare.totalFare,
                            fare = finalFare,
                            onPay = { method -> viewModel.simulator.submitPayment(ride.rideId, method) }
                        )
                    }
                }

                "RATING" -> {
                    RiderRatingCard(
                        onSubmit = { score, cleanliness, service, comment ->
                            viewModel.submitRiderRating(score, cleanliness, service, comment)
                        }
                    )
                }
            }
        }
    }
}

// 乘客端：首页叫车卡片
@Composable
fun RiderHomeCard(
    searchQuery: String,
    onQueryChange: (String) -> Unit,
    onSearchTrigger: () -> Unit,
    presetPlaces: List<SearchPlace>,
    onSelectPlace: (SearchPlace) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.DirectionsCar,
                    contentDescription = "云行出行",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "云行出行",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold)
                )
                Spacer(modifier = Modifier.weight(1f))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFE2E8F0))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "附近可用 12 辆车",
                        style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFF475569))
                    )
                }
            }

            // 您要去哪里？搜索框触发器
            Surface(
                onClick = onSearchTrigger,
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFFF1F5F9),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("search_trigger")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(16.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "搜索",
                        tint = Color(0xFF64748B)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "您要去哪里？ 输入目的地",
                        style = MaterialTheme.typography.bodyLarge.copy(color = Color(0xFF64748B))
                    )
                }
            }

            // 常用推荐目的地快捷入口
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "常用目的地",
                    style = MaterialTheme.typography.labelMedium.copy(color = Color(0xFF64748B))
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    presetPlaces.take(3).forEach { place ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFFF8FAFC))
                                .clickable { onSelectPlace(place) }
                                .padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = when (place.type) {
                                        "机场" -> Icons.Default.Flight
                                        "火车站" -> Icons.Default.Train
                                        "家" -> Icons.Default.Home
                                        else -> Icons.Default.Work
                                    },
                                    contentDescription = place.type,
                                    tint = Color(0xFF64748B),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = place.name,
                                    maxLines = 1,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center,
                                    color = Color(0xFF334155)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// 乘客端：搜索输入卡片
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RiderSearchCard(
    query: String,
    onQueryChange: (String) -> Unit,
    results: List<SearchPlace>,
    onSelect: (SearchPlace) -> Unit,
    onBack: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "返回")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "输入目的地",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            }

            OutlinedTextField(
                value = query,
                onValueChange = onQueryChange,
                placeholder = { Text("搜索地址、地标或机场") },
                leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("destination_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.secondary,
                    unfocusedBorderColor = Color(0xFFE2E8F0)
                )
            )

            LazyColumn(
                modifier = Modifier.heightIn(max = 240.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                if (results.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "无匹配地点，请输入关键字如「虹桥」",
                                color = Color(0xFF94A3B8),
                                fontSize = 13.sp
                            )
                        }
                    }
                } else {
                    items(results) { place ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelect(place) }
                                .padding(vertical = 12.dp, horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = when (place.type) {
                                    "机场" -> Icons.Default.Flight
                                    "火车站" -> Icons.Default.Train
                                    "家" -> Icons.Default.Home
                                    else -> Icons.Default.Place
                                },
                                contentDescription = null,
                                tint = Color(0xFF64748B),
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = place.name,
                                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                                    color = Color(0xFF1E293B)
                                )
                                Text(
                                    text = place.description,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF64748B)
                                )
                            }
                        }
                        HorizontalDivider(color = Color(0xFFF1F5F9))
                    }
                }
            }
        }
    }
}

// 乘客端：路线与车型选择卡片
@Composable
fun RiderSelectRouteCard(
    startAddr: String,
    destAddr: String,
    recRoute: Route?,
    altRoute: Route?,
    selectedRouteIdx: Int,
    onSelectRoute: (Int) -> Unit,
    fares: Map<String, Fare>,
    selectedType: String,
    onSelectType: (String) -> Unit,
    coupons: List<Coupon>,
    selectedCoupon: Coupon?,
    onSelectCoupon: (Coupon?) -> Unit,
    onConfirm: () -> Unit,
    onBack: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // 上下车地址展示
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "返回")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "出发地: $startAddr",
                        fontSize = 12.sp,
                        color = Color(0xFF64748B)
                    )
                    Text(
                        text = "目的地: $destAddr",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color(0xFF1E293B)
                    )
                }
            }

            HorizontalDivider(color = Color(0xFFF1F5F9))

            // 1. 路线对比方案展示
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                recRoute?.let { r ->
                    RoutePlanTab(
                        title = "推荐路线",
                        route = r,
                        isSelected = selectedRouteIdx == 0,
                        onClick = { onSelectRoute(0) },
                        modifier = Modifier.weight(1f)
                    )
                }
                altRoute?.let { r ->
                    RoutePlanTab(
                        title = "备用路线",
                        route = r,
                        isSelected = selectedRouteIdx == 1,
                        onClick = { onSelectRoute(1) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // 2. 车型选择列表 (水平滚动)
            Text(
                text = "选择车型",
                style = MaterialTheme.typography.labelMedium.copy(color = Color(0xFF64748B))
            )

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                val typesList = listOf(
                    Triple("经济型", "大众 比亚迪等", "约 4 分钟"),
                    Triple("舒适型", "帕萨特 丰田等", "约 2 分钟"),
                    Triple("商务型", "别克GL8 丰田等", "约 6 分钟"),
                    Triple("豪华型", "奔驰E级 宝马5系", "约 8 分钟"),
                    Triple("六座车", "丰田赛那 六座SUV", "约 5 分钟")
                )

                items(typesList) { item ->
                    val type = item.first
                    val desc = item.second
                    val eta = item.third
                    val fare = fares[type]

                    val isSelected = selectedType == type
                    
                    val displayPrice = fare?.let { f ->
                        val discounted = if (selectedCoupon != null && 
                            (selectedCoupon.applicableVehicleType == "全部" || selectedCoupon.applicableVehicleType == type)) {
                            (f.totalFare - selectedCoupon.value).coerceAtLeast(0.01)
                        } else f.totalFare
                        "¥${discounted.toString().substringBefore(".")}"
                    } ?: "计算中"

                    Box(
                        modifier = Modifier
                            .width(120.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else Color(0xFFF8FAFC))
                            .clickable { onSelectType(type) }
                            .padding(12.dp)
                            .testTag("vehicle_type_$type")
                    ) {
                        Column {
                            Text(
                                text = type,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) MaterialTheme.colorScheme.primary else Color(0xFF1E293B)
                            )
                            Text(text = desc, fontSize = 10.sp, color = Color(0xFF64748B))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = displayPrice,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (isSelected) MaterialTheme.colorScheme.primary else Color(0xFFEA580C),
                                fontSize = 18.sp
                            )
                            Text(text = eta, fontSize = 10.sp, color = Color(0xFF10B981))
                        }
                    }
                }
            }

            // 3. 优惠券选择器
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFFFEF2F2))
                    .clickable {
                        // Toggle through coupon sequence
                        val nextCp = if (selectedCoupon == null) coupons.first() else null
                        onSelectCoupon(nextCp)
                    }
                    .padding(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ConfirmationNumber,
                    contentDescription = null,
                    tint = Color(0xFFEF4444)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = selectedCoupon?.name ?: "点击选择或使用卡券",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Color(0xFF991B1B)
                    )
                    Text(
                        text = selectedCoupon?.let { "已减抵 ¥${it.value}" } ?: "最高可抵扣 ¥20",
                        fontSize = 11.sp,
                        color = Color(0xFF991B1B)
                    )
                }
                Spacer(modifier = Modifier.weight(1f))
                Text(
                    text = if (selectedCoupon != null) "已应用" else "选择优惠",
                    fontSize = 12.sp,
                    color = Color(0xFFB91C1C),
                    fontWeight = FontWeight.Bold
                )
            }

            // 4. 最终确认叫车按钮
            Button(
                onClick = onConfirm,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("confirm_call_button")
            ) {
                val currentFare = fares[selectedType]
                val priceLabel = currentFare?.let { f ->
                    val finalVal = if (selectedCoupon != null && 
                        (selectedCoupon.applicableVehicleType == "全部" || selectedCoupon.applicableVehicleType == selectedType)) {
                        (f.totalFare - selectedCoupon.value).coerceAtLeast(0.01)
                    } else f.totalFare
                    " ¥${finalVal.toString().substringBefore(".")}"
                } ?: ""
                
                Text(
                    text = "确认叫车 ($selectedType $priceLabel)",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 16.sp
                )
            }
        }
    }
}

@Composable
fun RoutePlanTab(
    title: String,
    route: Route,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (isSelected) MaterialTheme.colorScheme.secondary.copy(alpha = 0.1f) else Color(0xFFF1F5F9))
            .clickable { onClick() }
            .padding(12.dp)
    ) {
        Column {
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = if (isSelected) MaterialTheme.colorScheme.secondary else Color(0xFF475569)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "${route.distanceKm.toString().take(4)} km  |  ${route.durationMinutes} 分钟",
                fontSize = 11.sp,
                color = Color(0xFF64748B)
            )
        }
    }
}

// 乘客端：等待司机呼叫/匹配卡片
@Composable
fun RiderMatchingCard(
    onCancel: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            CircularProgressIndicator(
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.size(48.dp)
            )
            Text(
                text = "正在为您匹配附近最优质司机...",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = Color(0xFF1E293B)
            )
            Text(
                text = "正在匹配高分车队，实时路网ETA估算中，请耐心等候...",
                fontSize = 12.sp,
                color = Color(0xFF64748B),
                textAlign = TextAlign.Center
            )
            
            OutlinedButton(
                onClick = onCancel,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFEF4444)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(text = "取消叫车", fontWeight = FontWeight.Bold)
            }
        }
    }
}

// 乘客端：司机接单，前往乘客/行中监控卡片
@Composable
fun RiderDriverArrivingCard(
    ride: Ride,
    vehicle: Vehicle,
    driver: Driver,
    trip: Trip?,
    onCancel: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // 司机车牌、车型核心信息
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text(
                        text = vehicle.plate,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF1E293B)
                    )
                    Text(
                        text = "${vehicle.color} · ${vehicle.brand}${vehicle.model} (${vehicle.type})",
                        fontSize = 13.sp,
                        color = Color(0xFF64748B)
                    )
                }
                Spacer(modifier = Modifier.weight(1f))
                
                // 行程安全码
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFFEF3C7))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "安全码", fontSize = 10.sp, color = Color(0xFFD97706))
                        Text(text = ride.safetyCode, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFFB45309))
                    }
                }
            }

            HorizontalDivider(color = Color(0xFFF1F5F9))

            // 状态指示
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = when (ride.status) {
                        RideStatus.DRIVER_EN_ROUTE -> Icons.Default.DirectionsCar
                        RideStatus.DRIVER_ARRIVED -> Icons.Default.EmojiPeople
                        else -> Icons.Default.Navigation
                    },
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    val statusText = when (ride.status) {
                        RideStatus.DRIVER_EN_ROUTE -> "司机正火速赶往您的出发地..."
                        RideStatus.DRIVER_ARRIVED -> "【王师傅】已到达！请核对车牌上车"
                        RideStatus.RIDER_ONBOARD -> "验证成功，祝您一路顺风"
                        RideStatus.IN_TRIP -> "行程进行中，安全盾全天候守护您的旅途..."
                        else -> "订单处理中"
                    }
                    Text(
                        text = statusText,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color(0xFF1E293B)
                    )
                    
                    trip?.let { t ->
                        val remainingSecs = (t.route.points.size - 1 - t.currentPointIndex).coerceAtLeast(0)
                        val pct = if (t.route.points.isNotEmpty()) remainingSecs.toDouble() / t.route.points.size else 0.0
                        Text(
                            text = "剩余约 ${(t.route.distanceKm * pct).toString().take(4)} km · 约 ${(t.route.durationMinutes * pct).toInt().coerceAtLeast(1)} 分钟",
                            fontSize = 12.sp,
                            color = Color(0xFF10B981)
                        )
                    }
                }
            }

            // 安全快捷功能条
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Button(
                    onClick = { /* Emergency Help trigger */ },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(imageVector = Icons.Default.Shield, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "紧急求助", fontSize = 13.sp)
                }

                OutlinedButton(
                    onClick = onCancel,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF475569)),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(text = "取消行程", fontSize = 13.sp)
                }
            }
        }
    }
}

// 乘客端：微信支付/支付宝支付卡片
@Composable
fun RiderPaymentCard(
    amount: Double,
    fare: Fare,
    onPay: (String) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "行程顺利到达",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = Color(0xFF10B981)
            )
            
            Text(
                text = "¥${amount.toString()}",
                style = MaterialTheme.typography.displayMedium.copy(fontWeight = FontWeight.ExtraBold),
                color = Color(0xFF1E293B)
            )

            HorizontalDivider(color = Color(0xFFF1F5F9))

            // 费用明细展示
            Column(
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                FareRow("起步基础费用", "¥${fare.baseFare}")
                FareRow("里程行驶费用 (${fare.distanceFare.toString().take(4)} km)", "¥${fare.distanceFare.toString().take(4)}")
                FareRow("时间耗费费用 (${fare.timeFare.toString().take(4)} min)", "¥${fare.timeFare.toString().take(4)}")
                FareRow("平台代收服务费", "¥${fare.bookingFee}")
                if (fare.dynamicSurgeMultiplier > 1.0) {
                    FareRow("供需激增系数", "${fare.dynamicSurgeMultiplier}x", Color(0xFFEA580C))
                }
            }

            HorizontalDivider(color = Color(0xFFF1F5F9))

            Text(
                text = "请选择安全支付通道进行对账结算：",
                fontSize = 11.sp,
                color = Color(0xFF64748B),
                modifier = Modifier.align(Alignment.Start)
            )

            // 支付渠道选择与触发
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Button(
                    onClick = { onPay("微信支付") },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF22C55E)),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "微信支付", fontSize = 13.sp)
                }

                Button(
                    onClick = { onPay("支付宝") },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(imageVector = Icons.Default.Payment, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "支付宝", fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun FareRow(label: String, valStr: String, color: Color = Color(0xFF475569)) {
    Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(text = label, fontSize = 12.sp, color = Color(0xFF64748B))
        Text(text = valStr, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = color)
    }
}

// 乘客端：司机五星好评与评语卡片
@Composable
fun RiderRatingCard(
    onSubmit: (Int, Int, Int, String) -> Unit
) {
    var score by remember { mutableStateOf(5) }
    var serviceScore by remember { mutableStateOf(5) }
    var cleanlinessScore by remember { mutableStateOf(5) }
    var comment by remember { mutableStateOf("") }

    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "本次行程体验如何？",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = Color(0xFF1E293B)
            )

            // 五星好评点击交互
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                (1..5).forEach { star ->
                    val active = star <= score
                    IconButton(
                        onClick = { score = star },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = if (active) Color(0xFFFBBF24) else Color(0xFFE2E8F0),
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }
            }

            HorizontalDivider(color = Color(0xFFF1F5F9))

            // 精细维度：车辆整洁度、驾驶体验
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(text = "车辆干净整洁", fontSize = 13.sp, color = Color(0xFF475569))
                StarSelectorRow(cleanlinessScore) { cleanlinessScore = it }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(text = "司机准时服务好", fontSize = 13.sp, color = Color(0xFF475569))
                StarSelectorRow(serviceScore) { serviceScore = it }
            }

            OutlinedTextField(
                value = comment,
                onValueChange = { comment = it },
                placeholder = { Text("写下您对本次行程的评价吧...", fontSize = 13.sp) },
                shape = RoundedCornerShape(10.dp),
                maxLines = 3,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.secondary,
                    unfocusedBorderColor = Color(0xFFE2E8F0)
                )
            )

            Button(
                onClick = { onSubmit(score, cleanlinessScore, serviceScore, comment) },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("submit_rating_button")
            ) {
                Text(text = "提交评价", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun StarSelectorRow(score: Int, onScoreChange: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        (1..5).forEach { star ->
            val active = star <= score
            Icon(
                imageVector = Icons.Default.Star,
                contentDescription = null,
                tint = if (active) Color(0xFFFBBF24) else Color(0xFFE2E8F0),
                modifier = Modifier
                    .size(20.dp)
                    .clickable { onScoreChange(star) }
            )
        }
    }
}
