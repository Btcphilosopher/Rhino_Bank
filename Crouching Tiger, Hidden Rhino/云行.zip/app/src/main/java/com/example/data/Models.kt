package com.example.data

enum class Role {
    RIDER, DRIVER, SUPPORT, DISPATCHER, OPERATIONS, FINANCE, SAFETY, ADMIN, AUDITOR
}

enum class RideStatus {
    CREATED,
    SEARCHING,
    MATCHED,
    DRIVER_EN_ROUTE,
    DRIVER_ARRIVED,
    RIDER_ONBOARD,
    IN_TRIP,
    COMPLETED,
    CANCELLED,
    EXPIRED
}

enum class DriverStatus {
    OFFLINE,
    GOING_ONLINE,
    ONLINE,
    BUSY,
    TRIP,
    GOING_OFFLINE
}

data class User(
    val userId: String,
    val phone: String, // Kept masked or minimal to respect privacy rules
    val name: String,
    val role: Role,
    val avatarUrl: String = ""
)

data class Rider(
    val riderId: String,
    val userId: String,
    val rating: Float = 4.9f,
    val membershipLevel: String = "普通用户" // 普通用户, 银卡, 金卡
)

data class Driver(
    val driverId: String,
    val userId: String,
    val rating: Float = 4.85f,
    val status: DriverStatus = DriverStatus.OFFLINE,
    val activeVehicleId: String? = null,
    val isVerified: Boolean = false,
    val todayEarnings: Double = 0.0,
    val weeklyEarnings: Double = 0.0,
    val monthlyEarnings: Double = 0.0,
    val onlineTimeMinutes: Int = 0,
    val acceptedOrders: Int = 0,
    val completedOrders: Int = 0,
    val currentLat: Double = 31.2304, // Default Shanghai city center (Lujiazui)
    val currentLng: Double = 121.4737,
    val bearing: Float = 0f
)

data class Vehicle(
    val vehicleId: String,
    val driverId: String,
    val type: String, // 经济型, 舒适型, 商务型, 豪华型, 六座车
    val brand: String,
    val model: String,
    val color: String,
    val plate: String,
    val inspectionStatus: String = "已检验合格"
)

data class LocationPoint(
    val latitude: Double,
    val longitude: Double,
    val timestamp: Long = System.currentTimeMillis(),
    val speed: Float = 0f,
    val heading: Float = 0f,
    val accuracy: Float = 5f,
    val provider: String = "Mock"
)

data class Route(
    val routeId: String,
    val points: List<LocationPoint>,
    val distanceKm: Double,
    val durationMinutes: Int,
    val encodedPath: String = "",
    val name: String = "推荐路线"
)

data class RideRequest(
    val requestId: String,
    val riderId: String,
    val startLat: Double,
    val startLng: Double,
    val startAddress: String,
    val endLat: Double,
    val endLng: Double,
    val endAddress: String,
    val preferredVehicleType: String,
    val status: RideStatus = RideStatus.CREATED,
    val timestamp: Long = System.currentTimeMillis()
)

data class Ride(
    val rideId: String,
    val requestId: String,
    val riderId: String,
    val driverId: String?,
    val vehicleId: String?,
    val status: RideStatus,
    val currentLat: Double,
    val currentLng: Double,
    val safetyCode: String = "",
    val startTime: Long? = null,
    val endTime: Long? = null
)

data class Trip(
    val tripId: String,
    val rideId: String,
    val route: Route,
    val currentPointIndex: Int = 0,
    val pointsSampled: List<LocationPoint> = emptyList(),
    val startTimestamp: Long = System.currentTimeMillis()
)

data class Fare(
    val rideId: String,
    val baseFare: Double,
    val distanceFare: Double,
    val timeFare: Double,
    val bookingFee: Double,
    val dynamicSurgeMultiplier: Double = 1.0,
    val tolls: Double = 0.0,
    val discount: Double = 0.0,
    val totalFare: Double
)

data class Payment(
    val paymentId: String,
    val rideId: String,
    val amount: Double,
    val method: String, // 微信支付, 支付宝, 银行卡, 模拟支付
    val transactionId: String = "",
    val isSuccess: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

data class Receipt(
    val receiptId: String,
    val rideId: String,
    val riderId: String,
    val title: String = "电子发票",
    val amount: Double,
    val taxId: String = "91310115MA1H7UR88Y",
    val email: String = "",
    val status: String = "已开具", // 未开具, 处理中, 已开具
    val timestamp: Long = System.currentTimeMillis()
)

data class Rating(
    val ratingId: String,
    val rideId: String,
    val raterId: String, // User ID of rater
    val rateeId: String, // User ID of ratee
    val score: Int, // 1 - 5 stars
    val serviceScore: Int = 5,
    val cleanlinessScore: Int = 5,
    val driveScore: Int = 5,
    val comment: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

data class Coupon(
    val couponId: String,
    val name: String,
    val value: Double,
    val minSpend: Double,
    val expiryTimestamp: Long,
    val applicableVehicleType: String = "全部",
    val applicableRegion: String = "全部",
    val isUsed: Boolean = false
)

data class DriverEarning(
    val earningId: String,
    val driverId: String,
    val rideId: String,
    val grossFare: Double,
    val platformFee: Double,
    val incentiveBonus: Double = 0.0,
    val subsidies: Double = 0.0,
    val netEarnings: Double,
    val timestamp: Long = System.currentTimeMillis()
)

data class SupportTicket(
    val ticketId: String,
    val userId: String,
    val category: String, // 费用问题, 司机问题, 车辆问题, 订单问题, 支付问题, 安全问题, 其他
    val description: String,
    val status: String = "待处理", // 待处理, 处理中, 已解决
    val reply: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

data class Notification(
    val notificationId: String,
    val userId: String,
    val title: String,
    val message: String,
    val isRead: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

data class SafetyEvent(
    val eventId: String,
    val rideId: String,
    val category: String, // 紧急求助, 碰撞告警, 偏航告警, 离线告警, 疑似模拟定位
    val severity: String, // LOW, MEDIUM, HIGH, CRITICAL
    val description: String,
    val details: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

data class H3Cell(
    val h3Index: String, // H3 simulation index (hex grid ID)
    val name: String,
    val centerLat: Double,
    val centerLng: Double,
    val radiusKm: Double = 0.8
)

data class DemandSnapshot(
    val cellId: String,
    val requestsCount: Int,
    val availableDriversCount: Int,
    val activeTripsCount: Int,
    val supplyDemandRatio: Double, // supply / demand
    val averageEtaMinutes: Double,
    val timestamp: Long = System.currentTimeMillis()
)
