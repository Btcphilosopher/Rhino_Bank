package com.example.data

import android.os.Handler
import android.os.Looper
import kotlin.math.*

// -------------------------------------------------------------------------
// 1. 地图与定位服务抽象接口
// -------------------------------------------------------------------------

interface MapProvider {
    val providerName: String
    fun getLabel(): String
}

class MockMapProvider : MapProvider {
    override val providerName = "MockMapProvider"
    override fun getLabel() = "云行模拟地图服务 (演示模式)"
}

class AMapProvider : MapProvider {
    override val providerName = "AMapProvider"
    override fun getLabel() = "高德地图"
}

class BaiduMapProvider : MapProvider {
    override val providerName = "BaiduMapProvider"
    override fun getLabel() = "百度地图"
}

class GoogleMapsProvider : MapProvider {
    override val providerName = "GoogleMapsProvider"
    override fun getLabel() = "谷歌地图"
}

// -------------------------------------------------------------------------
// 2. 路径规划服务接口
// -------------------------------------------------------------------------

interface RoutingProvider {
    fun calculateRoute(
        startLat: Double, startLng: Double,
        endLat: Double, endLng: Double,
        mode: String = "RECOMMENDED"
    ): Route
}

class MockRoutingProvider : RoutingProvider {
    override fun calculateRoute(
        startLat: Double, startLng: Double,
        endLat: Double, endLng: Double,
        mode: String
    ): Route {
        // Calculate direct bearing and distance
        val dLat = endLat - startLat
        val dLng = endLng - startLng
        
        // Haversine formula for distance
        val r = 6371.0 // Earth radius in km
        val latDistance = Math.toRadians(dLat)
        val lngDistance = Math.toRadians(dLng)
        val a = sin(latDistance / 2) * sin(latDistance / 2) +
                cos(Math.toRadians(startLat)) * cos(Math.toRadians(endLat)) *
                sin(lngDistance / 2) * sin(lngDistance / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        val distanceKm = r * c
        
        // Speed estimate (averages around 45 km/h)
        val durationMinutes = max(2, (distanceKm / 45.0 * 60).toInt())
        
        // Generate a grid-aligned city road path (not a straight line!)
        // Grid road route: goes along coordinates simulating turn blocks
        val points = mutableListOf<LocationPoint>()
        val segments = 12
        val now = System.currentTimeMillis()
        
        points.add(LocationPoint(startLat, startLng, now, 0f, 0f, 5f, "Mock"))
        
        // Let's alternate going latitude then longitude to simulate a grid road network
        var currentLat = startLat
        var currentLng = startLng
        
        for (i in 1 until segments) {
            val fraction = i.toDouble() / segments
            
            // Add grid turn logic: first segment moves mostly in lat, second mostly in lng...
            if (i % 2 == 1) {
                // Move mostly lat
                currentLat = startLat + dLat * fraction + (sin(fraction * Math.PI) * 0.0015)
            } else {
                // Move mostly lng
                currentLng = startLng + dLng * fraction + (cos(fraction * Math.PI) * 0.0015)
            }
            
            val bearing = Math.toDegrees(atan2(dLng, dLat)).toFloat()
            val speedKmh = 40f + (sin(fraction * 10).toFloat() * 10f)
            points.add(
                LocationPoint(
                    currentLat,
                    currentLng,
                    now + (fraction * durationMinutes * 60000).toLong(),
                    speedKmh / 3.6f, // convert to m/s
                    bearing,
                    5f,
                    "Mock"
                )
            )
        }
        
        // Final point
        points.add(LocationPoint(endLat, endLng, now + durationMinutes * 60000, 0f, 0f, 5f, "Mock"))
        
        val name = if (mode == "RECOMMENDED") "推荐路线" else "备用路线 (${(distanceKm * 1.15).toString().take(4)} km)"
        val actualDistance = if (mode == "RECOMMENDED") distanceKm else distanceKm * 1.12
        val actualDuration = if (mode == "RECOMMENDED") durationMinutes else (durationMinutes * 1.15).toInt()
        
        return Route(
            routeId = "route_${(now % 100000)}",
            points = points,
            distanceKm = actualDistance,
            durationMinutes = actualDuration,
            name = name
        )
    }
}

// -------------------------------------------------------------------------
// 3. 地理编码服务接口
// -------------------------------------------------------------------------

data class SearchPlace(
    val name: String,
    val description: String,
    val latitude: Double,
    val longitude: Double,
    val type: String // 家, 公司, 机场, 火车站, 商场, 医院, 酒店, 地标
)

interface GeocodingProvider {
    fun searchPlaces(query: String): List<SearchPlace>
    fun reverseGeocode(lat: Double, lng: Double): String
    val presetPlaces: List<SearchPlace>
}

class MockGeocodingProvider : GeocodingProvider {
    override val presetPlaces = listOf(
        SearchPlace("上海虹桥站", "上海市闵行区申贵路1500号", 31.1944, 121.3204, "火车站"),
        SearchPlace("上海浦东国际机场", "上海市浦东新区迎宾大道6000号", 31.1443, 121.8083, "机场"),
        SearchPlace("陆家嘴金融中心", "上海市浦东新区世纪大道8号", 31.2397, 121.4998, "地标"),
        SearchPlace("上海火车站", "上海市静安区秣陵路303号", 31.2520, 121.4554, "火车站"),
        SearchPlace("我的家 (汇贤雅苑)", "上海市闵行区莲花南路路口", 31.1154, 121.4337, "家"),
        SearchPlace("公司 (张江高科园区)", "上海市浦东新区科苑路88号", 31.2064, 121.5937, "公司"),
        SearchPlace("静安寺商圈", "上海市静安区南京西路1686号", 31.2245, 121.4468, "商场"),
        SearchPlace("华山医院", "上海市静安区乌鲁木齐中路12号", 31.2201, 121.4385, "医院"),
        SearchPlace("和平饭店", "上海市黄浦区南京东路20号", 31.2408, 121.4891, "酒店"),
        SearchPlace("新天地时尚", "上海市黄浦区马当路245号", 31.2212, 121.4758, "商场")
    )

    override fun searchPlaces(query: String): List<SearchPlace> {
        if (query.isEmpty()) return presetPlaces
        return presetPlaces.filter { 
            it.name.contains(query, ignoreCase = true) || 
            it.description.contains(query, ignoreCase = true) ||
            it.type.contains(query, ignoreCase = true)
        }
    }

    override fun reverseGeocode(lat: Double, lng: Double): String {
        // Find nearest preset place
        var minDistance = Double.MAX_VALUE
        var nearest = "上海市黄浦区人民广场"
        
        for (place in presetPlaces) {
            val dist = sqrt((place.latitude - lat).pow(2) + (place.longitude - lng).pow(2))
            if (dist < minDistance) {
                minDistance = dist
                nearest = place.name + "附近"
            }
        }
        
        return nearest
    }
}

// -------------------------------------------------------------------------
// 4. 导航服务接口
// -------------------------------------------------------------------------

data class NavStep(
    val instruction: String,
    val distanceMeters: Int,
    val durationSeconds: Int,
    val actionType: String // STRAIGHT, TURN_LEFT, TURN_RIGHT, ARRIVED
)

interface NavigationProvider {
    fun generateNavigationSteps(route: Route): List<NavStep>
}

class MockNavigationProvider : NavigationProvider {
    override fun generateNavigationSteps(route: Route): List<NavStep> {
        val steps = mutableListOf<NavStep>()
        if (route.points.isEmpty()) return steps
        
        val totalDistance = (route.distanceKm * 1000).toInt()
        val totalTime = route.durationMinutes * 60
        
        // Segment steps
        steps.add(NavStep("向正北方向出发，驶入城市主干道", (totalDistance * 0.1).toInt(), (totalTime * 0.1).toInt(), "STRAIGHT"))
        steps.add(NavStep("前方 500 米左转进入高架快速路", 500, 45, "TURN_LEFT"))
        steps.add(NavStep("沿高架路直行，驶向目的地片区", (totalDistance * 0.6).toInt(), (totalTime * 0.6).toInt(), "STRAIGHT"))
        steps.add(NavStep("从高架出口驶出，进入辅路", (totalDistance * 0.15).toInt(), (totalTime * 0.15).toInt(), "TURN_RIGHT"))
        steps.add(NavStep("前方右转，即将到达目的地", 200, 30, "TURN_RIGHT"))
        steps.add(NavStep("已到达目的地：${route.name.substringBefore(" (")}", 0, 0, "ARRIVED"))
        
        return steps
    }
}

// -------------------------------------------------------------------------
// 5. 设备定位接口
// -------------------------------------------------------------------------

interface LocationProvider {
    fun getCurrentLocation(callback: (LocationPoint) -> Unit)
    fun startLocationUpdates(intervalMs: Long, callback: (LocationPoint) -> Unit)
    fun stopLocationUpdates()
}

class MockLocationProvider : LocationProvider {
    private var handler: Handler? = null
    private var runnable: Runnable? = null
    // Central Shanghai base coordinates
    private var lat = 31.2304
    private var lng = 121.4737

    override fun getCurrentLocation(callback: (LocationPoint) -> Unit) {
        callback(LocationPoint(lat, lng, System.currentTimeMillis()))
    }

    override fun startLocationUpdates(intervalMs: Long, callback: (LocationPoint) -> Unit) {
        handler = Handler(Looper.getMainLooper())
        runnable = object : Runnable {
            override fun run() {
                // Add tiny realistic drift
                lat += (randomDrift())
                lng += (randomDrift())
                callback(LocationPoint(lat, lng, System.currentTimeMillis()))
                handler?.postDelayed(this, intervalMs)
            }
        }
        handler?.post(runnable!!)
    }

    override fun stopLocationUpdates() {
        runnable?.let { handler?.removeCallbacks(it) }
        handler = null
        runnable = null
    }

    private fun randomDrift(): Double {
        return (Math.random() - 0.5) * 0.0001
    }
}

// -------------------------------------------------------------------------
// 6. 支付服务抽象接口
// -------------------------------------------------------------------------

interface PaymentProvider {
    val providerName: String
    fun processPayment(rideId: String, amount: Double, method: String, callback: (Payment) -> Unit)
}

class MockPaymentProvider : PaymentProvider {
    override val providerName = "MockPaymentProvider"
    override fun processPayment(rideId: String, amount: Double, method: String, callback: (Payment) -> Unit) {
        // Simulate background payment gateway validation
        Handler(Looper.getMainLooper()).postDelayed({
            val success = true // Demo is always successful
            val p = Payment(
                paymentId = "pay_${System.currentTimeMillis() % 1000000}",
                rideId = rideId,
                amount = amount,
                method = method,
                transactionId = "TXN_MOCK_${System.currentTimeMillis()}",
                isSuccess = success
            )
            callback(p)
        }, 1500) // Simulate network delay
    }
}
