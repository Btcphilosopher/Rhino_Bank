package com.example.core

import com.example.data.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.*

// -------------------------------------------------------------------------
// 1. 实时 WebSocket 消息/事件总线
// -------------------------------------------------------------------------

sealed class PlatformEvent {
    data class RideRequested(val request: RideRequest) : PlatformEvent()
    data class DriverMatched(val rideId: String, val driverId: String) : PlatformEvent()
    data class DriverAccepted(val rideId: String, val driverId: String) : PlatformEvent()
    data class DriverArrived(val rideId: String, val driverId: String) : PlatformEvent()
    data class TripStarted(val rideId: String) : PlatformEvent()
    data class DriverLocationUpdated(val driverId: String, val lat: Double, val lng: Double, val bearing: Float) : PlatformEvent()
    data class TripUpdated(val rideId: String, val currentLat: Double, val currentLng: Double, val remainingDistanceKm: Double, val remainingMinutes: Int) : PlatformEvent()
    data class TripCompleted(val rideId: String, val receipt: TripReceipt) : PlatformEvent()
    data class PaymentCompleted(val rideId: String, val payment: Payment) : PlatformEvent()
    data class RideCancelled(val rideId: String, val reason: String) : PlatformEvent()
    data class SystemAlert(val message: String, val level: String) : PlatformEvent()
}

object EventBus {
    private val _events = MutableSharedFlow<PlatformEvent>(replay = 5)
    val events = _events.asSharedFlow()

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    fun publish(event: PlatformEvent) {
        scope.launch {
            _events.emit(event)
        }
    }
}

// -------------------------------------------------------------------------
// 2. 空间索引 (H3 六边形网格仿真)
// -------------------------------------------------------------------------

data class H3Hexagon(
    val id: String,
    val name: String,
    val centerLat: Double,
    val centerLng: Double,
    val vertices: List<Pair<Double, Double>> // Coordinates of the 6 vertices
)

class H3SpatialIndex {
    val cells = mutableMapOf<String, H3Hexagon>()

    init {
        // Define an 8-cell simplified hexagonal mesh covering core Shanghai locations
        createCell("H3_LHZ", "陆家嘴商圈", 31.2397, 121.4998)
        createCell("H3_HQZ", "虹桥枢纽区", 31.1944, 121.3204)
        createCell("H3_PDC", "浦东机场区", 31.1443, 121.8083)
        createCell("H3_SHZ", "上海火车站", 31.2520, 121.4554)
        createCell("H3_XTD", "新天地商业区", 31.2212, 121.4758)
        createCell("H3_JAS", "静安寺街区", 31.2245, 121.4468)
        createCell("H3_ZJG", "张江高科技园", 31.2064, 121.5937)
        createCell("H3_MHL", "闵行南部住区", 31.1154, 121.4337)
    }

    private fun createCell(id: String, name: String, lat: Double, lng: Double) {
        // Compute 6 hexagon coordinates
        val r = 0.015 // roughly 1.5km spacing
        val vertices = (0..5).map { i ->
            val angle = i * Math.PI / 3
            Pair(lat + r * sin(angle), lng + r * cos(angle))
        }
        cells[id] = H3Hexagon(id, name, lat, lng, vertices)
    }

    fun findCell(lat: Double, lng: Double): H3Hexagon {
        // Return nearest hexagon cell
        var minDistance = Double.MAX_VALUE
        var nearest = cells.values.first()
        for (cell in cells.values) {
            val dist = sqrt((cell.centerLat - lat).pow(2) + (cell.centerLng - lng).pow(2))
            if (dist < minDistance) {
                minDistance = dist
                nearest = cell
            }
        }
        return nearest
    }
}

// -------------------------------------------------------------------------
// 3. 动态供需引擎
// -------------------------------------------------------------------------

class DemandSupplyEngine(private val spatialIndex: H3SpatialIndex) {
    // Keeps track of virtual demand logs
    private val supplyDemandCache = mutableMapOf<String, DemandSnapshot>()

    init {
        // Pre-populate with realistic demand levels
        updateSnapshots(emptyList(), emptyList())
    }

    fun updateSnapshots(activeRides: List<Ride>, activeDrivers: List<Driver>) {
        spatialIndex.cells.forEach { (id, cell) ->
            // Count drivers in this cell
            val driversInCell = activeDrivers.filter {
                spatialIndex.findCell(it.currentLat, it.currentLng).id == id
            }
            val availableDrivers = driversInCell.filter { it.status == DriverStatus.ONLINE }.size
            
            // Generate mock or real requests
            val requestsInCell = activeRides.filter {
                spatialIndex.findCell(it.currentLat, it.currentLng).id == id
            }.size
            
            // Random fluctuations based on typical city hotspots
            val baseDemand = when (id) {
                "H3_HQZ" -> 14 // High demand (Railway Station)
                "H3_PDC" -> 18 // High demand (Airport)
                "H3_LHZ" -> 12 // High demand (Lujiazui)
                else -> 4
            }
            
            val simulatedDemand = baseDemand + requestsInCell
            val simulatedSupply = max(1, availableDrivers + (driversInCell.size / 2))
            
            // Ratio = supply / demand (smaller ratio = more scarcity = surge pricing)
            val ratio = simulatedSupply.toDouble() / max(1, simulatedDemand)
            
            // Average ETA simulation based on supply
            val avgEta = when {
                ratio < 0.3 -> 12.0
                ratio < 0.7 -> 6.5
                else -> 3.2
            }
            
            supplyDemandCache[id] = DemandSnapshot(
                cellId = id,
                requestsCount = simulatedDemand,
                availableDriversCount = simulatedSupply,
                activeTripsCount = activeRides.filter { it.status == RideStatus.IN_TRIP }.size,
                supplyDemandRatio = ratio,
                averageEtaMinutes = avgEta
            )
        }
    }

    fun getSurgeMultiplier(lat: Double, lng: Double): Double {
        val cell = spatialIndex.findCell(lat, lng)
        val snapshot = supplyDemandCache[cell.id] ?: return 1.0
        
        // Scarcity threshold: if supply-demand ratio is under 0.8, start dynamic surge multiplier
        return when {
            snapshot.supplyDemandRatio < 0.2 -> 1.8 // Heavy demand / sparse cars
            snapshot.supplyDemandRatio < 0.5 -> 1.5
            snapshot.supplyDemandRatio < 0.8 -> 1.2
            else -> 1.0
        }
    }

    fun getSnapshotForCell(cellId: String): DemandSnapshot? = supplyDemandCache[cellId]
}

// -------------------------------------------------------------------------
// 4. 动态计价引擎
// -------------------------------------------------------------------------

data class PricingConfig(
    val vehicleType: String,
    val baseFare: Double,       // 起步价
    val distanceRate: Double,   // 每公里价格
    val timeRate: Double,       // 每分钟价格
    val bookingFee: Double      // 平台服务费
)

class PricingEngine(private val demandSupplyEngine: DemandSupplyEngine) {
    val configs = mapOf(
        "经济型" to PricingConfig("经济型", 11.0, 2.30, 0.40, 2.0),
        "舒适型" to PricingConfig("舒适型", 15.0, 2.90, 0.55, 3.0),
        "商务型" to PricingConfig("商务型", 22.0, 3.80, 0.80, 5.0),
        "豪华型" to PricingConfig("豪华型", 35.0, 5.20, 1.20, 8.0),
        "六座车" to PricingConfig("六座车", 20.0, 3.50, 0.70, 4.0)
    )

    fun calculateEstimate(
        startLat: Double, startLng: Double,
        distanceKm: Double, durationMinutes: Int,
        vehicleType: String
    ): Fare {
        val config = configs[vehicleType] ?: configs["舒适型"]!!
        
        val base = config.baseFare
        val distFare = config.distanceRate * distanceKm
        val timeFare = config.timeRate * durationMinutes
        val booking = config.bookingFee
        
        // Dynamic surge multiplier from demand supply engine
        val multiplier = demandSupplyEngine.getSurgeMultiplier(startLat, startLng)
        
        val total = (base + distFare + timeFare + booking) * multiplier
        
        return Fare(
            rideId = "",
            baseFare = base,
            distanceFare = distFare,
            timeFare = timeFare,
            bookingFee = booking,
            dynamicSurgeMultiplier = multiplier,
            totalFare = total.roundTo(2)
        )
    }

    private fun Double.roundTo(decimals: Int): Double {
        var multiplier = 1.0
        repeat(decimals) { multiplier *= 10 }
        return kotlin.math.round(this * multiplier) / multiplier
    }
}

// -------------------------------------------------------------------------
// 5. 实时调度引擎
// -------------------------------------------------------------------------

data class MatchWeights(
    val etaWeight: Double = 0.5,
    val waitingTimeWeight: Double = 0.3,
    val typeMatchingWeight: Double = 0.2
)

class DispatchEngine(
    private val spatialIndex: H3SpatialIndex,
    private val routingProvider: RoutingProvider
) {
    var weights = MatchWeights()

    fun findCandidateDrivers(
        rideRequest: RideRequest,
        drivers: List<Driver>,
        vehicles: Map<String, Vehicle>
    ): List<Driver> {
        val cell = spatialIndex.findCell(rideRequest.startLat, rideRequest.startLng)
        
        // Find offline/online status check
        val candidates = drivers.filter { driver ->
            driver.status == DriverStatus.ONLINE && driver.activeVehicleId != null
        }.filter { driver ->
            // Match preferred vehicle type
            val vehicle = vehicles[driver.activeVehicleId]
            vehicle?.type == rideRequest.preferredVehicleType
        }
        
        return candidates
    }

    fun selectOptimalDriver(
        rideRequest: RideRequest,
        candidates: List<Driver>,
        riderRating: Float = 5.0f
    ): Driver? {
        if (candidates.isEmpty()) return null
        
        // Calculate Match Score for each driver candidate
        // Score = etaWeight * (100 - ETA_Seconds) + typeMatchWeight * Vehicle_Match + waitingTimeWeight * Waiting_Delay
        // High score wins
        var bestDriver: Driver? = null
        var maxScore = -Double.MAX_VALUE
        
        for (driver in candidates) {
            // Compute direct grid distance for fast eta estimation
            val distance = sqrt(
                (driver.currentLat - rideRequest.startLat).pow(2) + 
                (driver.currentLng - rideRequest.startLng).pow(2)
            ) * 111.0 // Degrees to km approx
            
            val estimatedEtaMinutes = (distance / 35.0 * 60).coerceIn(1.0, 25.0)
            
            // Candidate score formula (the closer the driver, the higher the score)
            val etaScore = (30.0 - estimatedEtaMinutes) * 3.33 * weights.etaWeight // Normalized 0-100 scale
            val driverRatingBonus = (driver.rating - 4.0) * 20.0 * weights.typeMatchingWeight // Score premium for high ratings
            val waitingMultiplier = weights.waitingTimeWeight * 15.0 // Buffer weight
            
            val finalScore = etaScore + driverRatingBonus + waitingMultiplier
            
            if (finalScore > maxScore) {
                maxScore = finalScore
                bestDriver = driver
            }
        }
        
        return bestDriver
    }
}

// -------------------------------------------------------------------------
// 6. 欺诈与安全风控系统
// -------------------------------------------------------------------------

data class FraudReport(
    val isRisk: Boolean,
    val score: Int, // 0 - 100
    val reasons: List<String>,
    val action: String // ALLOW, AUDIT, BLOCK
)

class FraudDetectionEngine {
    private val safetyEvents = mutableListOf<SafetyEvent>()

    fun detectGpsAnomaly(
        driverId: String,
        lastLat: Double, lastLng: Double, lastTime: Long,
        newLat: Double, newLng: Double, newTime: Long
    ): FraudReport {
        val reasons = mutableListOf<String>()
        var score = 0
        
        val dLat = newLat - lastLat
        val dLng = newLng - lastLng
        val distKm = sqrt(dLat.pow(2) + dLng.pow(2)) * 111.0
        val timeSec = (newTime - lastTime) / 1000.0
        
        if (timeSec > 0.5) {
            val speedKmh = (distKm / (timeSec / 3600.0))
            
            // Check impossible speed
            if (speedKmh > 180.0) {
                score += 45
                reasons.add("超常规行驶速度 (计算时速 ${speedKmh.toInt()} km/h): GPS信号存在跳跃异常")
                safetyEvents.add(
                    SafetyEvent(
                        eventId = "evt_${System.currentTimeMillis() % 100000}",
                        rideId = "unknown",
                        category = "疑似模拟定位",
                        severity = "HIGH",
                        description = "司机(ID: $driverId)在短短 ${timeSec.toInt()} 秒内移动了 ${distKm.toString().take(4)} 公里，计算时速 ${speedKmh.toInt()} km/h，怀疑使用虚拟定位或外挂。"
                    )
                )
            }
            
            // Check location silence
            if (timeSec > 180.0) {
                score += 15
                reasons.add("定位沉默超时 (${(timeSec/60).toInt()} 分钟未更新位置)")
            }
        }
        
        val action = when {
            score >= 40 -> "BLOCK"
            score >= 15 -> "AUDIT"
            else -> "ALLOW"
        }
        
        return FraudReport(score > 0, score, reasons, action)
    }

    fun getSafetyLogs() = safetyEvents.toList()
    fun clearSafetyLogs() = safetyEvents.clear()
}

// -------------------------------------------------------------------------
// 7. 城市级出行仿真器 (数字孪生背景循环)
// -------------------------------------------------------------------------

data class TripReceipt(
    val rideId: String,
    val distanceKm: Double,
    val durationMinutes: Int,
    val totalFare: Double,
    val breakdown: Fare
)

class CityMobilitySimulator(
    private val h3Index: H3SpatialIndex,
    private val routingProvider: RoutingProvider
) {
    private val _drivers = MutableStateFlow<List<Driver>>(emptyList())
    val drivers = _drivers.asStateFlow()

    private val _rides = MutableStateFlow<List<Ride>>(emptyList())
    val rides = _rides.asStateFlow()

    private val _trips = MutableStateFlow<Map<String, Trip>>(emptyMap())
    val trips = _trips.asStateFlow()

    private val _logs = MutableStateFlow<List<String>>(emptyList())
    val logs = _logs.asStateFlow()

    val vehicles = mutableMapOf<String, Vehicle>()
    
    // Core engine parameters
    val demandSupply = DemandSupplyEngine(h3Index)
    val pricing = PricingEngine(demandSupply)
    val dispatch = DispatchEngine(h3Index, routingProvider)
    val fraud = FraudDetectionEngine()

    private val job = SupervisorJob()
    private val simulatorScope = CoroutineScope(Dispatchers.Default + job)

    init {
        // Build mock fleets (20 active drivers scattered around Shanghai hubs)
        val initialDrivers = mutableListOf<Driver>()
        val defaultModels = listOf(
            Triple("舒适型", "大众", "帕萨特"),
            Triple("经济型", "比亚迪", "秦PLUS"),
            Triple("商务型", "别克", "GL8"),
            Triple("豪华型", "奔驰", "E级"),
            Triple("六座车", "丰田", "赛那")
        )
        
        val locations = listOf(
            Pair(31.2397, 121.4998), // Lujiazui
            Pair(31.1944, 121.3204), // Hongqiao
            Pair(31.1443, 121.8083), // Pudong Airport
            Pair(31.2520, 121.4554), // Shanghai Station
            Pair(31.2212, 121.4758), // Xintiandi
            Pair(31.2245, 121.4468), // Jing'an Temple
            Pair(31.2064, 121.5937), // Zhangjiang
            Pair(31.1154, 121.4337)  // Minhang
        )

        for (i in 1..24) {
            val drvId = "driver_$i"
            val vehId = "veh_$i"
            
            val modelIndex = i % defaultModels.size
            val m = defaultModels[modelIndex]
            
            // Scatter around Shanghai landmarks
            val loc = locations[i % locations.size]
            val jitterLat = (Math.random() - 0.5) * 0.02
            val jitterLng = (Math.random() - 0.5) * 0.02
            
            vehicles[vehId] = Vehicle(
                vehicleId = vehId,
                driverId = drvId,
                type = m.first,
                brand = m.second,
                model = m.third,
                color = if (i % 2 == 0) "黑色" else "白色",
                plate = "沪A·D${(10000 + i * 217)}"
            )

            val rating = 4.7f + (Math.random() * 0.3).toFloat()
            initialDrivers.add(
                Driver(
                    driverId = drvId,
                    userId = "user_d_$i",
                    rating = rating.roundTo(2),
                    status = if (i <= 18) DriverStatus.ONLINE else DriverStatus.OFFLINE,
                    activeVehicleId = vehId,
                    isVerified = true,
                    todayEarnings = (50..600).random().toDouble(),
                    onlineTimeMinutes = (60..480).random(),
                    completedOrders = (3..18).random(),
                    currentLat = loc.first + jitterLat,
                    currentLng = loc.second + jitterLng
                )
            )
        }

        _drivers.value = initialDrivers
        log("云行城市出行模拟引擎初始化：已部署上海市 24 名首批在线司机与运营车辆车队")
        startSimulationLoop()
    }

    fun startSimulationLoop() {
        simulatorScope.launch {
            while (isActive) {
                delay(2000) // update step every 2 seconds
                
                // 1. Move vehicles currently executing orders
                val updatedDrivers = _drivers.value.map { driver ->
                    val activeTrip = _trips.value.values.find { t -> 
                        val ride = _rides.value.find { r -> r.rideId == t.rideId }
                        ride?.driverId == driver.driverId && ride.status == RideStatus.IN_TRIP
                    }
                    val enRouteTrip = _trips.value.values.find { t ->
                        val ride = _rides.value.find { r -> r.rideId == t.rideId }
                        ride?.driverId == driver.driverId && ride.status == RideStatus.DRIVER_EN_ROUTE
                    }

                    when {
                        activeTrip != null -> {
                            val routePoints = activeTrip.route.points
                            val nextIndex = (activeTrip.currentPointIndex + 1).coerceAtMost(routePoints.size - 1)
                            val nextPoint = routePoints[nextIndex]
                            
                            // Check GPS anomalies for security simulation
                            if (Math.random() > 0.99) {
                                // Simulate single location spike to trigger the Fraud engine!
                                val fakeLat = nextPoint.latitude + 0.15
                                fraud.detectGpsAnomaly(
                                    driver.driverId,
                                    nextPoint.latitude, nextPoint.longitude, System.currentTimeMillis() - 2000,
                                    fakeLat, nextPoint.longitude, System.currentTimeMillis()
                                )
                                log("【风控系统】检测到司机 ${driver.driverId} 定位突变异常，疑似模拟GPS定位")
                            }

                            // Update trip state
                            val updatedTrips = _trips.value.toMutableMap()
                            updatedTrips[activeTrip.tripId] = activeTrip.copy(currentPointIndex = nextIndex)
                            _trips.value = updatedTrips

                            // WebSocket message
                            val remaining = routePoints.size - 1 - nextIndex
                            val remainingDist = activeTrip.route.distanceKm * (remaining.toDouble() / routePoints.size)
                            val remainingMins = (activeTrip.route.durationMinutes * (remaining.toDouble() / routePoints.size)).toInt()
                            
                            EventBus.publish(
                                PlatformEvent.TripUpdated(
                                    activeTrip.rideId,
                                    nextPoint.latitude,
                                    nextPoint.longitude,
                                    remainingDist.roundTo(2),
                                    max(1, remainingMins)
                                )
                            )

                            // Check arrival
                            if (nextIndex == routePoints.size - 1) {
                                completeRideSimulation(activeTrip.rideId)
                            }

                            driver.copy(
                                currentLat = nextPoint.latitude,
                                currentLng = nextPoint.longitude,
                                bearing = nextPoint.heading,
                                status = DriverStatus.TRIP
                            )
                        }
                        enRouteTrip != null -> {
                            val routePoints = enRouteTrip.route.points
                            val nextIndex = (enRouteTrip.currentPointIndex + 2).coerceAtMost(routePoints.size - 1) // Move faster to pick up
                            val nextPoint = routePoints[nextIndex]

                            val updatedTrips = _trips.value.toMutableMap()
                            updatedTrips[enRouteTrip.tripId] = enRouteTrip.copy(currentPointIndex = nextIndex)
                            _trips.value = updatedTrips

                            if (nextIndex == routePoints.size - 1) {
                                arriveAtRiderSimulation(enRouteTrip.rideId)
                            }

                            driver.copy(
                                currentLat = nextPoint.latitude,
                                currentLng = nextPoint.longitude,
                                bearing = nextPoint.heading,
                                status = DriverStatus.BUSY
                            )
                        }
                        else -> {
                            // Free driver wandering around slightly
                            if (driver.status == DriverStatus.ONLINE) {
                                val driftLat = (Math.random() - 0.5) * 0.0006
                                val driftLng = (Math.random() - 0.5) * 0.0006
                                driver.copy(
                                    currentLat = driver.currentLat + driftLat,
                                    currentLng = driver.currentLng + driftLng,
                                    bearing = (0..359).random().toFloat()
                                )
                            } else {
                                driver
                            }
                        }
                    }
                }

                _drivers.value = updatedDrivers
                
                // Refresh supply/demand snapshot index mapping
                demandSupply.updateSnapshots(_rides.value, _drivers.value)
            }
        }
    }

    // 乘客叫车
    fun requestRide(riderId: String, startLat: Double, startLng: Double, startAddr: String, endLat: Double, endLng: Double, endAddr: String, preferredType: String): RideRequest {
        val reqId = "req_${System.currentTimeMillis() % 1000000}"
        val request = RideRequest(
            requestId = reqId,
            riderId = riderId,
            startLat = startLat,
            startLng = startLng,
            startAddress = startAddr,
            endLat = endLat,
            endLng = endLng,
            endAddress = endAddr,
            preferredVehicleType = preferredType,
            status = RideStatus.SEARCHING
        )
        
        log("【乘客叫车】创建乘车订单: $startAddr ➔ $endAddr, 车型: $preferredType")
        EventBus.publish(PlatformEvent.RideRequested(request))
        
        // Match driver
        val candidates = dispatch.findCandidateDrivers(request, _drivers.value, vehicles)
        val selected = dispatch.selectOptimalDriver(request, candidates)

        if (selected != null) {
            val rideId = "ride_${System.currentTimeMillis() % 1000000}"
            val ride = Ride(
                rideId = rideId,
                requestId = reqId,
                riderId = riderId,
                driverId = selected.driverId,
                vehicleId = selected.activeVehicleId,
                status = RideStatus.MATCHED,
                currentLat = selected.currentLat,
                currentLng = selected.currentLng,
                safetyCode = (1000..9999).random().toString()
            )
            
            val updatedRides = _rides.value.toMutableList()
            updatedRides.add(ride)
            _rides.value = updatedRides

            // Set dispatch route from driver to passenger
            val dispatchRoute = routingProvider.calculateRoute(
                selected.currentLat, selected.currentLng,
                startLat, startLng,
                "RECOMMENDED"
            )

            val updatedTrips = _trips.value.toMutableMap()
            updatedTrips[rideId] = Trip(
                tripId = "trip_${rideId}",
                rideId = rideId,
                route = dispatchRoute
            )
            _trips.value = updatedTrips

            // Update driver status to busy
            _drivers.value = _drivers.value.map { d ->
                if (d.driverId == selected.driverId) {
                    d.copy(status = DriverStatus.BUSY)
                } else d
            }

            log("【智能调度】匹配完成! 司机 ${vehicles[selected.activeVehicleId]?.brand ?: ""} ${vehicles[selected.activeVehicleId]?.plate ?: ""} (距离上车点 ${dispatchRoute.distanceKm.toString().take(4)} km) 已接单")
            EventBus.publish(PlatformEvent.DriverMatched(rideId, selected.driverId))
            EventBus.publish(PlatformEvent.DriverAccepted(rideId, selected.driverId))
        } else {
            log("【智能调度】空间匹配重试中...未找到在线 $preferredType 车型空闲司机")
            EventBus.publish(PlatformEvent.SystemAlert("叫车排队中：未找到合适的空闲司机，请稍候", "WARNING"))
        }

        return request
    }

    private fun arriveAtRiderSimulation(rideId: String) {
        _rides.value = _rides.value.map { ride ->
            if (ride.rideId == rideId) {
                log("【行中监控】司机已到达乘客上车点 (安全验证码: ${ride.safetyCode})")
                EventBus.publish(PlatformEvent.DriverArrived(rideId, ride.driverId!!))
                ride.copy(status = RideStatus.DRIVER_ARRIVED)
            } else ride
        }
    }

    // 验证安全码，开始行程
    fun startRideWithCode(rideId: String, code: String): Boolean {
        var success = false
        _rides.value = _rides.value.map { ride ->
            if (ride.rideId == rideId) {
                if (ride.safetyCode == code) {
                    success = true
                    
                    // Create real customer ride route from start address to destination
                    val req = _rides.value.find { it.rideId == rideId }?.requestId
                    val rideRequest = _trips.value[rideId]?.route // Fetch coordinates of the initial setup
                    // We generate a proper path for the actual trip transit
                    val riderReq = _rides.value.find { it.rideId == rideId }
                    val currentDriver = _drivers.value.find { d -> d.driverId == ride.driverId }
                    
                    val startLat = ride.currentLat
                    val startLng = ride.currentLng
                    
                    // Destination coordinates from simulated search indices
                    val defaultRoute = routingProvider.calculateRoute(
                        31.1154, 121.4337, 31.1944, 121.3204 // default
                    )

                    // Retrieve real search location parameters from the ride
                    val realRoute = routingProvider.calculateRoute(
                        ride.currentLat, ride.currentLng,
                        31.1944, 121.3204, // default to Shanghai Hongqiao
                        "RECOMMENDED"
                    )

                    val updatedTrips = _trips.value.toMutableMap()
                    updatedTrips[rideId] = Trip(
                        tripId = "trip_${rideId}",
                        rideId = rideId,
                        route = realRoute,
                        currentPointIndex = 0
                    )
                    _trips.value = updatedTrips

                    log("【订单系统】安全码验证通过！行程开启。乘客上车。")
                    EventBus.publish(PlatformEvent.TripStarted(rideId))
                    ride.copy(status = RideStatus.IN_TRIP, startTime = System.currentTimeMillis())
                } else {
                    log("【安全中心】安全验证码 $code 不匹配！拒绝开始行程。")
                    ride
                }
            } else ride
        }
        return success
    }

    private fun completeRideSimulation(rideId: String) {
        _rides.value = _rides.value.map { ride ->
            if (ride.rideId == rideId && ride.status == RideStatus.IN_TRIP) {
                val trip = _trips.value[rideId]!!
                
                val fare = pricing.calculateEstimate(
                    ride.currentLat, ride.currentLng,
                    trip.route.distanceKm, trip.route.durationMinutes,
                    vehicles[ride.vehicleId]?.type ?: "舒适型"
                )

                val receipt = TripReceipt(
                    rideId = rideId,
                    distanceKm = trip.route.distanceKm,
                    durationMinutes = trip.route.durationMinutes,
                    totalFare = fare.totalFare,
                    breakdown = fare
                )

                // Give driver some earnings credit
                _drivers.value = _drivers.value.map { d ->
                    if (d.driverId == ride.driverId) {
                        val newNet = fare.totalFare * 0.82 // Platform takes 18% service fee
                        d.copy(
                            status = DriverStatus.ONLINE,
                            todayEarnings = (d.todayEarnings + newNet).roundTo(2),
                            weeklyEarnings = (d.weeklyEarnings + newNet).roundTo(2),
                            monthlyEarnings = (d.monthlyEarnings + newNet).roundTo(2),
                            completedOrders = d.completedOrders + 1
                        )
                    } else d
                }

                log("【计价系统】乘客顺利抵达。实际距离 ${trip.route.distanceKm.toString().take(4)} km，时间 ${trip.route.durationMinutes} 分钟。应收账单: ¥${fare.totalFare}")
                EventBus.publish(PlatformEvent.TripCompleted(rideId, receipt))
                ride.copy(status = RideStatus.COMPLETED, endTime = System.currentTimeMillis())
            } else ride
        }
    }

    fun submitPayment(rideId: String, method: String) {
        log("【支付中心】正在发起第三方 $method 安全清算...")
        val paymentProvider = MockPaymentProvider()
        val ride = _rides.value.find { it.rideId == rideId } ?: return
        val trip = _trips.value[rideId] ?: return
        val fare = pricing.calculateEstimate(
            ride.currentLat, ride.currentLng,
            trip.route.distanceKm, trip.route.durationMinutes,
            vehicles[ride.vehicleId]?.type ?: "舒适型"
        )

        paymentProvider.processPayment(rideId, fare.totalFare, method) { payment ->
            log("【支付中心】支付对账成功！流水分水岭：交易号 ${payment.transactionId}")
            EventBus.publish(PlatformEvent.PaymentCompleted(rideId, payment))
        }
    }

    fun cancelRide(rideId: String, reason: String) {
        _rides.value = _rides.value.map { r ->
            if (r.rideId == rideId) {
                // Return driver to online state
                _drivers.value = _drivers.value.map { d ->
                    if (d.driverId == r.driverId) d.copy(status = DriverStatus.ONLINE) else d
                }
                log("【订单系统】订单已被取消，取消原因: $reason")
                EventBus.publish(PlatformEvent.RideCancelled(rideId, reason))
                r.copy(status = RideStatus.CANCELLED)
            } else r
        }
    }

    fun toggleDriverOnline(driverId: String, online: Boolean) {
        _drivers.value = _drivers.value.map { d ->
            if (d.driverId == driverId) {
                val newStatus = if (online) DriverStatus.ONLINE else DriverStatus.OFFLINE
                log("【系统状态】司机 ${vehicles[d.activeVehicleId]?.plate} ${if (online) "上线接单" else "下线休息"}")
                d.copy(status = newStatus)
            } else d
        }
    }

    fun log(message: String) {
        val timestamp = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.CHINA).format(java.util.Date())
        val formatted = "[$timestamp] $message"
        val currentLogs = _logs.value.toMutableList()
        currentLogs.add(0, formatted) // Prepend to see latest on top
        if (currentLogs.size > 100) currentLogs.removeAt(currentLogs.size - 1)
        _logs.value = currentLogs
    }

    private fun Float.roundTo(decimals: Int): Float {
        var multiplier = 1f
        repeat(decimals) { multiplier *= 10 }
        return kotlin.math.round(this * multiplier) / multiplier
    }

    private fun Double.roundTo(decimals: Int): Double {
        var multiplier = 1.0
        repeat(decimals) { multiplier *= 10 }
        return kotlin.math.round(this * multiplier) / multiplier
    }
}
