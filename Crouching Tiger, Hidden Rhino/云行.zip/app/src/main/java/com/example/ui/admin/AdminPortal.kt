package com.example.ui.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.MainViewModel
import com.example.ui.components.CustomMapCanvas

@Composable
fun AdminPortal(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val drivers by viewModel.simulator.drivers.collectAsState()
    val rides by viewModel.simulator.rides.collectAsState()
    val logs by viewModel.simulator.logs.collectAsState()

    // Aggregate statistics
    val onlineDriversCount = drivers.filter { it.status == DriverStatus.ONLINE }.size
    val activeTripsCount = rides.filter { it.status == RideStatus.IN_TRIP }.size
    val totalOrdersCount = rides.size
    val completedCount = rides.filter { it.status == RideStatus.COMPLETED }.size
    
    // Dispatch engine sliders parameters
    var etaWeight by remember { mutableStateOf(0.5f) }
    var waitWeight by remember { mutableStateOf(0.3f) }
    var typeWeight by remember { mutableStateOf(0.2f) }

    // Simulation rush hour toggle
    var isRushHour by remember { mutableStateOf(false) }

    Box(modifier = modifier.fillMaxSize()) {
        // 1. Digital Twin City Map Layer
        CustomMapCanvas(
            modifier = Modifier.fillMaxSize(),
            riderLocation = null,
            destinationLocation = null,
            drivers = drivers,
            activeRoute = null,
            h3Cells = viewModel.h3SpatialIndex.cells.values.toList(),
            showH3Heatmap = true,
            supplyDemandMultiplier = { cellId ->
                val base = if (isRushHour) 2.5 else 1.0
                viewModel.simulator.demandSupply.getSnapshotForCell(cellId)?.supplyDemandRatio?.let { ratio ->
                    if (ratio > 0) (base * 1.5) / ratio else base
                } ?: base
            }
        )

        // 2. Translucent Control Hub Overlays
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Left Panel: High level Counters & Sliders
            Column(
                modifier = Modifier
                    .weight(1.1f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Title Panel
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.95f)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Analytics, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "云行运营中心 Dashboard",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 15.sp,
                                color = Color(0xFF1E293B)
                            )
                        }
                    }
                }

                // Stats Dashboard Grid
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.95f)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(text = "平台实时状态监控", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF64748B))
                        
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            StatMiniBox("在线司机", "$onlineDriversCount 人", Color(0xFF10B981), Modifier.weight(1f))
                            StatMiniBox("进行中行程", "$activeTripsCount 单", Color(0xFF2563EB), Modifier.weight(1f))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            StatMiniBox("累计订单", "$totalOrdersCount 件", Color(0xFF475569), Modifier.weight(1f))
                            val pct = if (totalOrdersCount > 0) (completedCount * 100 / totalOrdersCount) else 96
                            StatMiniBox("派单完成率", "$pct %", Color(0xFFEA580C), Modifier.weight(1f))
                        }
                    }
                }

                // Dispatch Weight Controller Slider Panel
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.95f)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(text = "调度分配决策引擎 (DispatchWeights)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF64748B))
                        
                        // Rush Hour simulator
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(text = "模拟晚高峰拥堵", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Switch(
                                checked = isRushHour,
                                onCheckedChange = { 
                                    isRushHour = it
                                    if (it) {
                                        viewModel.simulator.log("【调度模拟】管理员开启了上海晚高峰仿真，空间热区拥堵系数大幅攀升，价格动态倍率自动开启。")
                                    } else {
                                        viewModel.simulator.log("【调度模拟】晚高峰流量消退，城市交通状况恢复正常。")
                                    }
                                },
                                modifier = Modifier.testTag("rush_hour_switch")
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        WeightSlider("路网 ETA 距离权重", etaWeight) { 
                            etaWeight = it
                            viewModel.simulator.dispatch.weights = viewModel.simulator.dispatch.weights.copy(etaWeight = it.toDouble())
                        }
                        WeightSlider("乘客等待时长权重", waitWeight) { 
                            waitWeight = it
                            viewModel.simulator.dispatch.weights = viewModel.simulator.dispatch.weights.copy(waitingTimeWeight = it.toDouble())
                        }
                        WeightSlider("高分车队匹配权重", typeWeight) { 
                            typeWeight = it
                            viewModel.simulator.dispatch.weights = viewModel.simulator.dispatch.weights.copy(typeMatchingWeight = it.toDouble())
                        }
                    }
                }
            }

            // Right Panel: Structured Diagnostic Audit Logs
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A).copy(alpha = 0.95f)), // Solid slate black background for terminal logs
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .weight(0.9f)
                    .fillMaxHeight()
                    .border(1.dp, Color(0xFF334155), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Dns, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "平台系统对账审计日志 (Realtime Logs)",
                            color = Color(0xFF38BDF8),
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(10.dp))

                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(logs) { log ->
                            Text(
                                text = log,
                                color = when {
                                    log.contains("风控") || log.contains("不匹配") -> Color(0xFFF87171) // Red alert
                                    log.contains("智能调度") || log.contains("匹配完成") -> Color(0xFF6EE7B7) // Green success
                                    else -> Color(0xFFE2E8F0) // White debug
                                },
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                lineHeight = 13.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatMiniBox(label: String, valStr: String, indicatorColor: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFFF8FAFC))
            .padding(10.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(indicatorColor)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = label, fontSize = 10.sp, color = Color(0xFF64748B))
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = valStr, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF1E293B))
        }
    }
}

@Composable
fun WeightSlider(label: String, value: Float, onValueChange: (Float) -> Unit) {
    Column {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(text = label, fontSize = 10.sp, color = Color(0xFF475569))
            Text(text = "${(value * 100).toInt()}%", fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            colors = SliderDefaults.colors(
                thumbColor = MaterialTheme.colorScheme.primary,
                activeTrackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
            ),
            modifier = Modifier.height(24.dp)
        )
    }
}
