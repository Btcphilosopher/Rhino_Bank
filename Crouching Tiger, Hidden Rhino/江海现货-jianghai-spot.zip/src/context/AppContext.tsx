/**
 * 中国内河现货航运交易平台 — 全局应用状态上下文 (App Context)
 * JIANGHAI SPOT State Management & Event Dispatcher
 */

import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  RoleType, 
  CargoListing, 
  Vessel, 
  FreightQuote, 
  TransportOrder, 
  Invoice, 
  Document, 
  Port, 
  ServiceAlert, 
  AuditEvent, 
  SimulationState, 
  MatchCandidate,
  Organisation
} from '../types';

import { 
  SEED_ORGANISATIONS, 
  SEED_PORTS, 
  SEED_CARGO_LISTINGS, 
  SEED_VESSELS, 
  SEED_QUOTES, 
  SEED_ORDERS, 
  SEED_INVOICES, 
  SEED_DOCUMENTS, 
  SEED_ALERTS, 
  SEED_AUDITS 
} from '../data/seedData';

import { generateMatchCandidates } from '../simulation/matchingEngine';

export type WorkspaceView = 
  | 'market_overview'    // 市场总览
  | 'cargo_market'       // 货源市场
  | 'cargo_detail'       // 货源详情
  | 'create_cargo'       // 发布货源
  | 'vessel_market'      // 运力市场
  | 'vessel_detail'      // 船舶详情
  | 'create_vessel'      // 发布运力
  | 'spot_quotation'     // 现货报价
  | 'rfq_detail'         // RFQ详情
  | 'matching_engine'    // 撮合引擎
  | 'waterway_network'   // 航线与水网
  | 'port_operations'    // 港口与码头
  | 'berth_planning'     // 泊位计划
  | 'orders_list'        // 订单列表
  | 'voyage_detail'      // 航次监控与跟踪
  | 'settlement_ledger'  // 中国式结算与发票
  | 'document_centre'    // 合同与单证中心
  | 'analytics'          // 市场数据与分析
  | 'operations_control' // 运营控制台
  | 'alerts'             // 预警与异常
  | 'organisation'       // 企业机构档案
  | 'settings'           // 平台设置
  | 'simulation_console';// 开发者与模拟控制台

export interface ToastMessage {
  id: string;
  type: 'info' | 'success' | 'warning' | 'error';
  title: string;
  message: string;
}

interface AppContextType {
  // 角色与全局视角
  currentRole: RoleType;
  setCurrentRole: (role: RoleType) => void;
  activeView: WorkspaceView;
  setActiveView: (view: WorkspaceView) => void;
  
  // 搜索与弹窗
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  isCommandBarOpen: boolean;
  setIsCommandBarOpen: (open: boolean) => void;
  isScenarioModalOpen: boolean;
  setIsScenarioModalOpen: (open: boolean) => void;
  isProvenanceModalOpen: boolean;
  setIsProvenanceModalOpen: (open: boolean) => void;
  selectedDrawerItem: { type: string; data: any } | null;
  setSelectedDrawerItem: (item: { type: string; data: any } | null) => void;
  
  // 核心数据集
  organisations: Organisation[];
  ports: Port[];
  cargoListings: CargoListing[];
  vessels: Vessel[];
  quotes: FreightQuote[];
  matchCandidates: MatchCandidate[];
  orders: TransportOrder[];
  invoices: Invoice[];
  documents: Document[];
  alerts: ServiceAlert[];
  audits: AuditEvent[];
  
  // 选中的对象 ID
  selectedCargoId: string | null;
  setSelectedCargoId: (id: string | null) => void;
  selectedVesselId: string | null;
  setSelectedVesselId: (id: string | null) => void;
  selectedOrderId: string | null;
  setSelectedOrderId: (id: string | null) => void;
  selectedPortId: string | null;
  setSelectedPortId: (id: string | null) => void;
  
  // 模拟引擎状态
  simulation: SimulationState;
  setSimulation: React.Dispatch<React.SetStateAction<SimulationState>>;
  advanceSimulationClock: (hours: number) => void;
  triggerSimulatedEvent: (eventType: 'lock_congestion' | 'severe_weather' | 'fuel_hike' | 'payment_hold') => void;
  
  // 业务动作
  addCargoListing: (cargo: Omit<CargoListing, 'id' | 'createdAt' | 'status'>) => void;
  addVesselListing: (vessel: Omit<Vessel, 'id' | 'status'>) => void;
  submitQuote: (quote: Omit<FreightQuote, 'id' | 'quoteNo' | 'createdAt' | 'status' | 'auditTrail'>) => void;
  acceptQuote: (quoteId: string) => void;
  createOrderFromMatch: (matchId: string) => void;
  signDocument: (docId: string, role: 'shipper' | 'carrier') => void;
  releaseSettlementPayment: (invoiceId: string) => void;
  runScenario: (scenarioId: number) => void;
  
  // 通知系统
  toasts: ToastMessage[];
  addToast: (toast: Omit<ToastMessage, 'id'>) => void;
  removeToast: (id: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentRole, setCurrentRole] = useState<RoleType>('cargo_owner');
  const [activeView, setActiveView] = useState<WorkspaceView>('market_overview');
  
  const [searchQuery, setSearchQuery] = useState('');
  const [isCommandBarOpen, setIsCommandBarOpen] = useState(false);
  const [isScenarioModalOpen, setIsScenarioModalOpen] = useState(false);
  const [isProvenanceModalOpen, setIsProvenanceModalOpen] = useState(false);
  const [selectedDrawerItem, setSelectedDrawerItem] = useState<{ type: string; data: any } | null>(null);

  const [organisations] = useState<Organisation[]>(SEED_ORGANISATIONS);
  const [ports, setPorts] = useState<Port[]>(SEED_PORTS);
  const [cargoListings, setCargoListings] = useState<CargoListing[]>(SEED_CARGO_LISTINGS);
  const [vessels, setVessels] = useState<Vessel[]>(SEED_VESSELS);
  const [quotes, setQuotes] = useState<FreightQuote[]>(SEED_QUOTES);
  const [orders, setOrders] = useState<TransportOrder[]>(SEED_ORDERS);
  const [invoices, setInvoices] = useState<Invoice[]>(SEED_INVOICES);
  const [documents, setDocuments] = useState<Document[]>(SEED_DOCUMENTS);
  const [alerts, setAlerts] = useState<ServiceAlert[]>(SEED_ALERTS);
  const [audits, setAudits] = useState<AuditEvent[]>(SEED_AUDITS);
  
  const [selectedCargoId, setSelectedCargoId] = useState<string | null>('cargo-101');
  const [selectedVesselId, setSelectedVesselId] = useState<string | null>('vsl-01');
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>('ord-801');
  const [selectedPortId, setSelectedPortId] = useState<string | null>('port-nanjing');

  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // 撮合候选集 (根据最新货源与运力实时算法刷新)
  const [matchCandidates, setMatchCandidates] = useState<MatchCandidate[]>([]);

  useEffect(() => {
    const computed = generateMatchCandidates(cargoListings, vessels);
    setMatchCandidates(computed);
  }, [cargoListings, vessels]);

  // 模拟器状态
  const [simulation, setSimulation] = useState<SimulationState>({
    isRunning: true,
    timeSpeedMultiplier: 1,
    simulatedTime: new Date().toISOString(),
    demandMultiplier: 1.0,
    capacityMultiplier: 1.0,
    simulatedFuelPriceRmbPerTon: 7200,
    weatherAlertActive: false,
    lockCongestionActive: true,
    logs: [
      `[${new Date().toLocaleTimeString()}] 平台引擎启动：已载入长江、京杭运河、珠江水系 24 个枢纽港口及航道节点`,
      `[${new Date().toLocaleTimeString()}] 确定性算法引擎就绪，正在监控 42 个在途航次与 8 个挂牌竞价单`
    ]
  });

  const addToast = (toast: Omit<ToastMessage, 'id'>) => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`;
    setToasts((prev) => [...prev, { ...toast, id }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const recordAudit = (action: string, module: string, operator: string, details: string) => {
    const newAudit: AuditEvent = {
      id: `aud-${Date.now()}`,
      timestamp: new Date().toISOString(),
      action,
      module,
      operator,
      details
    };
    setAudits((prev) => [newAudit, ...prev]);
  };

  // 推动模拟器时间
  const advanceSimulationClock = (hours: number) => {
    setSimulation((prev) => {
      const current = new Date(prev.simulatedTime);
      current.setHours(current.getHours() + hours);
      const newTime = current.toISOString();
      
      return {
        ...prev,
        simulatedTime: newTime,
        logs: [
          `[系统时钟快进 +${hours}小时] 模拟当前时间: ${new Date(newTime).toLocaleString('zh-CN')}`,
          ...prev.logs.slice(0, 30)
        ]
      };
    });

    // 在途航次进度更新
    setOrders((prevOrders) =>
      prevOrders.map((ord) => {
        if (ord.status === 'sailing') {
          const newProgress = Math.min(100, ord.progressPercent + hours * 4);
          const isArrived = newProgress >= 100;
          return {
            ...ord,
            progressPercent: newProgress,
            status: isArrived ? 'awaiting_berth' : 'sailing',
            events: isArrived
              ? [
                  ...ord.events,
                  {
                    id: `ev-${Date.now()}`,
                    timestamp: new Date().toISOString(),
                    eventType: 'arrived',
                    location: ord.destinationPortName,
                    description: `船只抵港，进入 ${ord.destinationPortName} 等待靠泊卸货阶段`,
                    operator: '模拟航运调度'
                  }
                ]
              : ord.events
          };
        }
        return ord;
      })
    );

    addToast({
      type: 'info',
      title: '模拟器推进',
      message: `时钟快进 ${hours} 小时，航次与港口排队动态已更新`
    });
  };

  // 触发模拟事件
  const triggerSimulatedEvent = (eventType: 'lock_congestion' | 'severe_weather' | 'fuel_hike' | 'payment_hold') => {
    if (eventType === 'lock_congestion') {
      setSimulation((prev) => ({
        ...prev,
        lockCongestionActive: true,
        logs: [`[异常触发] 三峡五级船闸与葛洲坝二号船闸发生限速拥堵，过闸延误增加 12 小时`, ...prev.logs]
      }));
      setPorts((prev) =>
        prev.map((p) => (p.id === 'port-chongqing' ? { ...p, status: 'congested', avgWaitHours: 18 } : p))
      );
      addToast({
        type: 'warning',
        title: '航道预警',
        message: '长江三峡段船闸已触发严重拥堵模式'
      });
    } else if (eventType === 'severe_weather') {
      setSimulation((prev) => ({
        ...prev,
        weatherAlertActive: true,
        logs: [`[气象预警] 长江中下游出现强浓雾天气，全线渡运与重载航次临时禁航`, ...prev.logs]
      }));
      addToast({
        type: 'error',
        title: '能见度预警',
        message: '气象局发布强浓雾预警，航道实施临时封航管制'
      });
    } else if (eventType === 'fuel_hike') {
      setSimulation((prev) => ({
        ...prev,
        simulatedFuelPriceRmbPerTon: 8100,
        logs: [`[市场变动] 船用柴油/LNG价格调增 +12.5%，即期燃油附加费标准相应上浮`, ...prev.logs]
      }));
      addToast({
        type: 'warning',
        title: '油价波动',
        message: '船用燃油价格上调至 8100 元/吨，燃油附加费已联动自动计算'
      });
    } else if (eventType === 'payment_hold') {
      addToast({
        type: 'error',
        title: '结算冻结预警',
        message: '检测到交接单缺少完好卸货盖章，托管资金已自动进入争议争议冻结状态'
      });
    }
  };

  // 业务动作：新增货源
  const addCargoListing = (cargoData: Omit<CargoListing, 'id' | 'createdAt' | 'status'>) => {
    const id = `cargo-${Date.now()}`;
    const newCargo: CargoListing = {
      ...cargoData,
      id,
      status: 'published',
      createdAt: new Date().toISOString()
    };
    setCargoListings((prev) => [newCargo, ...prev]);
    recordAudit('发布货源', '货源市场', `${currentRole} 用户`, `新建货源: ${newCargo.title}`);
    addToast({
      type: 'success',
      title: '货源发布成功',
      message: `货源 [${newCargo.title}] 已成功挂牌至现货市场`
    });
    setActiveView('cargo_market');
  };

  // 业务动作：新增运力
  const addVesselListing = (vesselData: Omit<Vessel, 'id' | 'status'>) => {
    const id = `vsl-${Date.now()}`;
    const newVessel: Vessel = {
      ...vesselData,
      id,
      status: 'idle'
    };
    setVessels((prev) => [newVessel, ...prev]);
    recordAudit('发布运力', '运力市场', `${currentRole} 用户`, `发布空船运力: ${newVessel.name}`);
    addToast({
      type: 'success',
      title: '运力挂牌成功',
      message: `船舶 [${newVessel.name}] 已成功录入可交易运力池`
    });
    setActiveView('vessel_market');
  };

  // 提交报价
  const submitQuote = (quoteData: Omit<FreightQuote, 'id' | 'quoteNo' | 'createdAt' | 'status' | 'auditTrail'>) => {
    const id = `quote-${Date.now()}`;
    const quoteNo = `QT${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(100 + Math.random() * 900)}`;
    const newQuote: FreightQuote = {
      ...quoteData,
      id,
      quoteNo,
      status: 'submitted',
      createdAt: new Date().toISOString(),
      auditTrail: [
        {
          timestamp: new Date().toISOString(),
          action: '提交报价',
          actor: quoteData.carrierOrgName
        }
      ]
    };
    setQuotes((prev) => [newQuote, ...prev]);
    recordAudit('提交报价', '现货报价引擎', quoteData.carrierOrgName, `针对货源提交运费报价单 ${quoteNo}`);
    addToast({
      type: 'success',
      title: '运费报价已提交',
      message: `报价单 ${quoteNo} 已发往货主审核谈判`
    });
    setActiveView('spot_quotation');
  };

  // 接受报价 -> 自动生成订单与合同
  const acceptQuote = (quoteId: string) => {
    const targetQuote = quotes.find((q) => q.id === quoteId);
    if (!targetQuote) return;

    setQuotes((prev) =>
      prev.map((q) => (q.id === quoteId ? { ...q, status: 'accepted' } : q))
    );

    // 更新货源状态
    setCargoListings((prev) =>
      prev.map((c) => (c.id === targetQuote.cargoId ? { ...c, status: 'matched' } : c))
    );

    // 生成运输订单
    const orderNo = `ORD${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(1000 + Math.random() * 9000)}`;
    const newOrder: TransportOrder = {
      id: `ord-${Date.now()}`,
      orderNo,
      cargoId: targetQuote.cargoId,
      cargoTitle: targetQuote.cargoTitle,
      cargoOwnerName: targetQuote.shipperOrgName,
      carrierName: targetQuote.carrierOrgName,
      vesselId: targetQuote.vesselId,
      vesselName: targetQuote.vesselName,
      mmsi: '413889101',
      originPortName: targetQuote.originPortName,
      destinationPortName: targetQuote.destinationPortName,
      weightTons: targetQuote.quantityTons,
      agreedPricePerTon: targetQuote.unitPriceRmb,
      totalAgreedCostRmb: targetQuote.totalEstimatedFreightRmb,
      loadingAppointment: new Date(Date.now() + 86400000).toISOString(),
      unloadingAppointment: new Date(Date.now() + 86400000 * (targetQuote.estimatedTransitDays + 1)).toISOString(),
      estimatedArrival: new Date(Date.now() + 86400000 * targetQuote.estimatedTransitDays).toISOString(),
      currentLat: 31.35,
      currentLng: 121.58,
      progressPercent: 0,
      status: 'created',
      paymentStatus: 'escrow_locked',
      insuranceStatus: 'covered',
      hasException: false,
      events: [
        {
          id: `ev-${Date.now()}`,
          timestamp: new Date().toISOString(),
          eventType: 'contract_signed',
          location: '江海现货交易平台',
          description: `双方达成运价协议 (单价: ¥${targetQuote.unitPriceRmb}/吨, 总运费: ¥${targetQuote.totalEstimatedFreightRmb.toLocaleString()})，自动生成运输订单`,
          operator: '智能撮合与交易引擎'
        }
      ],
      createdAt: new Date().toISOString()
    };

    setOrders((prev) => [newOrder, ...prev]);
    setSelectedOrderId(newOrder.id);

    // 生成电子水路运输合同
    const newDoc: Document = {
      id: `doc-${Date.now()}`,
      docNo: `HT${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(100 + Math.random() * 900)}`,
      title: `电子水路货物运输合同（${targetQuote.cargoTitle}）`,
      type: 'freight_contract',
      orderId: newOrder.id,
      orderNo: newOrder.orderNo,
      issuerOrgName: '江海现货交易平台存证中心',
      recipientOrgName: `${targetQuote.shipperOrgName} / ${targetQuote.carrierOrgName}`,
      createdDate: new Date().toISOString(),
      version: 'v1.0',
      status: 'pending_signature',
      signatureState: 'unsigned',
      hashVerification: `0x${Math.random().toString(16).substr(2, 40)}`
    };

    setDocuments((prev) => [newDoc, ...prev]);

    recordAudit('确认报价与生成订单', '撮合交易', targetQuote.shipperOrgName, `接受报价 ${targetQuote.quoteNo}，生成订单 ${orderNo}`);

    addToast({
      type: 'success',
      title: '交易撮合成功',
      message: `订单 ${orderNo} 已生成，合同存证已进入待盖章流程`
    });

    setActiveView('orders_list');
  };

  // 从撮合候选直接创建订单
  const createOrderFromMatch = (matchId: string) => {
    const candidate = matchCandidates.find((m) => m.id === matchId);
    if (!candidate) return;

    // 自动构造对应的模拟 quote 并接受
    const dummyQuote: FreightQuote = {
      id: `quote-${Date.now()}`,
      quoteNo: `QT${Date.now().toString().slice(-6)}`,
      cargoId: candidate.cargoId,
      cargoTitle: candidate.cargo.title,
      vesselId: candidate.vesselId,
      vesselName: candidate.vessel.name,
      carrierOrgId: candidate.vessel.operatorOrgId,
      carrierOrgName: candidate.vessel.operatorOrgName,
      shipperOrgId: candidate.cargo.ownerOrgId,
      shipperOrgName: candidate.cargo.ownerOrgName,
      originPortName: candidate.cargo.originPortName,
      destinationPortName: candidate.cargo.destinationPortName,
      quantityTons: candidate.cargo.weightTons,
      freightBasis: 'per_ton',
      unitPriceRmb: candidate.suggestedFreightRmbPerTon,
      baseFreightRmb: candidate.suggestedFreightRmbPerTon * candidate.cargo.weightTons,
      fuelSurchargeRmb: 2000,
      lockFeeRmb: 1500,
      portFeeRmb: 1000,
      loadingFeeRmb: 1000,
      unloadingFeeRmb: 1000,
      insuranceCostRmb: 500,
      taxRmb: Math.round(candidate.suggestedFreightRmbPerTon * candidate.cargo.weightTons * 0.09),
      totalEstimatedFreightRmb: Math.round(candidate.suggestedFreightRmbPerTon * candidate.cargo.weightTons * 1.09 + 5500),
      validityExpiry: candidate.cargo.expiresAt,
      estimatedTransitDays: 3,
      demurrageRatePerDayRmb: 2500,
      paymentTerms: '托管结算（按阶段放款）',
      status: 'submitted',
      createdAt: new Date().toISOString(),
      auditTrail: []
    };

    setQuotes((prev) => [dummyQuote, ...prev]);
    acceptQuote(dummyQuote.id);
  };

  // 签署电子单证
  const signDocument = (docId: string, role: 'shipper' | 'carrier') => {
    setDocuments((prev) =>
      prev.map((doc) => {
        if (doc.id === docId) {
          const now = new Date().toISOString();
          let newState: Document['signatureState'] = doc.signatureState;
          if (role === 'shipper') {
            newState = doc.signatureState === 'carrier_signed' ? 'both_signed' : 'shipper_signed';
          } else {
            newState = doc.signatureState === 'shipper_signed' ? 'both_signed' : 'carrier_signed';
          }

          const isFullySigned = newState === 'both_signed';
          return {
            ...doc,
            signatureState: newState,
            status: isFullySigned ? 'signed' : 'pending_signature',
            shipperSignedAt: role === 'shipper' ? now : doc.shipperSignedAt,
            carrierSignedAt: role === 'carrier' ? now : doc.carrierSignedAt
          };
        }
        return doc;
      })
    );

    addToast({
      type: 'success',
      title: '电子签章成功',
      message: `单证区块链存证哈希校验完成`
    });
  };

  // 解冻放款与结算
  const releaseSettlementPayment = (invoiceId: string) => {
    setInvoices((prev) =>
      prev.map((inv) => (inv.id === invoiceId ? { ...inv, status: 'settled', paidDate: new Date().toISOString() } : inv))
    );
    addToast({
      type: 'success',
      title: '资金结算完成',
      message: '托管账户已成功划转运费至承运人企业账户'
    });
  };

  // 演示预设场景加载器 (Scenarios 1-5)
  const runScenario = (scenarioId: number) => {
    if (scenarioId === 1) {
      // 场景 1: 安徽水泥发往南京
      setActiveView('cargo_market');
      setSelectedCargoId('cargo-101');
      addToast({
        type: 'info',
        title: '演示场景 1：水泥运量竞价',
        message: '载入安徽长运建材 3500吨 散装水泥至南京港配载流程'
      });
    } else if (scenarioId === 2) {
      // 场景 2: 梧州外贸集装箱驳运广州
      setActiveView('cargo_market');
      setSelectedCargoId('cargo-104');
      addToast({
        type: 'info',
        title: '演示场景 2：珠江内河集装箱多式联运',
        message: '载入 200 TEU 外贸电子零部件驳运至广州黄埔港流程'
      });
    } else if (scenarioId === 3) {
      // 场景 3: 京杭运河与三峡船闸拥堵预警
      triggerSimulatedEvent('lock_congestion');
      setActiveView('alerts');
    } else if (scenarioId === 4) {
      // 场景 4: 货主反向竞价拍卖
      setActiveView('spot_quotation');
      addToast({
        type: 'info',
        title: '演示场景 4：反向拍卖竞价',
        message: '展示武钢 5000吨 钢卷运费多船东实时阶梯竞价'
      });
    } else if (scenarioId === 5) {
      // 场景 5: 单证缺失结算争议异常
      triggerSimulatedEvent('payment_hold');
      setActiveView('settlement_ledger');
    }
    setIsScenarioModalOpen(false);
  };

  return (
    <AppContext.Provider
      value={{
        currentRole,
        setCurrentRole,
        activeView,
        setActiveView,
        searchQuery,
        setSearchQuery,
        isCommandBarOpen,
        setIsCommandBarOpen,
        isScenarioModalOpen,
        setIsScenarioModalOpen,
        isProvenanceModalOpen,
        setIsProvenanceModalOpen,
        selectedDrawerItem,
        setSelectedDrawerItem,
        organisations,
        ports,
        cargoListings,
        vessels,
        quotes,
        matchCandidates,
        orders,
        invoices,
        documents,
        alerts,
        audits,
        selectedCargoId,
        setSelectedCargoId,
        selectedVesselId,
        setSelectedVesselId,
        selectedOrderId,
        setSelectedOrderId,
        selectedPortId,
        setSelectedPortId,
        simulation,
        setSimulation,
        advanceSimulationClock,
        triggerSimulatedEvent,
        addCargoListing,
        addVesselListing,
        submitQuote,
        acceptQuote,
        createOrderFromMatch,
        signDocument,
        releaseSettlementPayment,
        runScenario,
        toasts,
        addToast,
        removeToast
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
