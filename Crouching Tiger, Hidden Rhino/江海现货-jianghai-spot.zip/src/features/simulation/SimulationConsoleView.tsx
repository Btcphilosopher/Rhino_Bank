/**
 * 中国内河现货航运交易平台 — 模拟控制台 (Simulation Console Workspace)
 * JIANGHAI SPOT Developer & Simulation Control Desk
 */

import React from 'react';
import { useApp } from '../../context/AppContext';
import { 
  SlidersHorizontal, 
  Clock, 
  Play, 
  FastForward, 
  RotateCcw, 
  AlertTriangle, 
  Fuel, 
  TrendingUp, 
  Lock, 
  Sparkles,
  Radio
} from 'lucide-react';

export const SimulationConsoleView: React.FC = () => {
  const { 
    simulation, 
    advanceSimulationClock, 
    triggerSimulatedEvent, 
    addToast
  } = useApp();

  return (
    <div className="h-full flex flex-col bg-slate-950 text-slate-100 font-sans overflow-hidden">
      <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between shrink-0">
        <div className="flex items-center space-x-2">
          <SlidersHorizontal className="w-5 h-5 text-cyan-400" />
          <h2 className="text-base font-bold text-slate-100">确定性领域引擎与开发者模拟控制台</h2>
        </div>
      </div>

      <div className="flex-1 p-5 overflow-y-auto space-y-5 text-xs">
        {/* 1. 时钟推进控制 */}
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-3">
          <div className="flex items-center space-x-2 font-bold text-slate-100">
            <Clock className="w-4 h-4 text-cyan-400" />
            <span>模拟时钟快进推演 (Clock Acceleration)</span>
          </div>

          <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-between">
            <span className="text-slate-400">当前系统模拟时间:</span>
            <span className="font-mono text-cyan-300 font-bold text-sm">
              {new Date(simulation.simulatedTime).toLocaleString('zh-CN')}
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <button
              onClick={() => advanceSimulationClock(1)}
              className="py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-100 font-bold rounded-lg border border-slate-700 transition"
            >
              +1 小时
            </button>
            <button
              onClick={() => advanceSimulationClock(6)}
              className="py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-100 font-bold rounded-lg border border-slate-700 transition"
            >
              +6 小时
            </button>
            <button
              onClick={() => advanceSimulationClock(24)}
              className="py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg transition"
            >
              +1 天 (推进履约)
            </button>
            <button
              onClick={() => advanceSimulationClock(168)}
              className="py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-lg transition"
            >
              +7 天 (推进结算)
            </button>
          </div>
        </div>

        {/* 2. 动态业务事件触发器 */}
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-3">
          <div className="flex items-center space-x-2 font-bold text-slate-100">
            <AlertTriangle className="w-4 h-4 text-amber-400" />
            <span>实时业务冲击模拟演练 (Business Disruption Events)</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <button
              onClick={() => triggerSimulatedEvent('lock_congestion')}
              className="p-3 bg-amber-950/40 hover:bg-amber-950/70 border border-amber-500/40 rounded-lg text-left space-y-1 transition"
            >
              <div className="font-bold text-amber-300">1. 触发三峡/京杭船闸严重拥堵预警</div>
              <p className="text-[11px] text-amber-200/70">自动更新过闸排队耗时，重算在途订单抵港 ETA。</p>
            </button>

            <button
              onClick={() => triggerSimulatedEvent('fuel_hike')}
              className="p-3 bg-orange-950/40 hover:bg-orange-950/70 border border-orange-500/40 rounded-lg text-left space-y-1 transition"
            >
              <div className="font-bold text-orange-300">2. 模拟船用柴油暴涨 (+15%)</div>
              <p className="text-[11px] text-orange-200/70">触发撮合算法更新，提升现货建议运价底价。</p>
            </button>

            <button
              onClick={() => triggerSimulatedEvent('severe_weather')}
              className="p-3 bg-cyan-950/40 hover:bg-cyan-950/70 border border-cyan-500/40 rounded-lg text-left space-y-1 transition"
            >
              <div className="font-bold text-cyan-300">3. 模拟恶劣天气大雾封航指令</div>
              <p className="text-[11px] text-cyan-200/70">发布全网航警，在途船舶降速停航封港。</p>
            </button>

            <button
              onClick={() => triggerSimulatedEvent('payment_hold')}
              className="p-3 bg-rose-950/40 hover:bg-rose-950/70 border border-rose-500/40 rounded-lg text-left space-y-1 transition"
            >
              <div className="font-bold text-rose-300">4. 模拟交接水运单未盖公章争议冻结</div>
              <p className="text-[11px] text-rose-200/70">冻结特定订单托管资金，需要人工存证核对解冻。</p>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
