/**
 * 中国内河现货航运交易平台 — 中国式结算与资金托管 (Settlement Workspace)
 * JIANGHAI SPOT Escrow, Bank Adapter, Digital RMB & Invoices
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  CreditCard, 
  Lock, 
  CheckCircle2, 
  DollarSign, 
  UserCheck,
  ShieldCheck, 
  FileText, 
  Building2, 
  AlertTriangle, 
  Download,
  ArrowUpRight,
  Sparkles
} from 'lucide-react';

export const SettlementView: React.FC = () => {
  const { orders, addToast, releaseSettlementPayment } = useApp();

  const [activeTab, setActiveTab] = useState<'escrow' | 'milestones' | 'invoices'>('escrow');

  // Hardcoded or dynamic derived wallet values
  const mockEscrowAccount = {
    availableBalanceRmb: 4850000,
    lockedEscrowRmb: 125000,
    digitalRmbBalance: 800000
  };

  const releaseEscrowPayment = (orderId: string) => {
    addToast({
      type: 'success',
      title: '运费解冻划转成功',
      message: `订单 #${orderId} 的托管尾款已安全划转给承运船东账户`
    });
  };

  return (
    <div className="h-full flex flex-col bg-slate-950 text-slate-100 font-sans overflow-hidden">
      {/* 顶部标签 */}
      <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between shrink-0">
        <div className="flex items-center space-x-2">
          <CreditCard className="w-5 h-5 text-emerald-400" />
          <h2 className="text-base font-bold text-slate-100">中国式现货水运资金托管与电子发票结算中心</h2>
        </div>

        <div className="flex bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
          <button
            onClick={() => setActiveTab('escrow')}
            className={`px-3 py-1.5 rounded-md font-medium transition ${
              activeTab === 'escrow' ? 'bg-emerald-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            托管账户概览 (Escrow)
          </button>
          <button
            onClick={() => setActiveTab('milestones')}
            className={`px-3 py-1.5 rounded-md font-medium transition ${
              activeTab === 'milestones' ? 'bg-emerald-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            阶段式划款 (Milestones)
          </button>
        </div>
      </div>

      {/* 主体 */}
      <div className="flex-1 p-5 overflow-y-auto space-y-5">
        {/* 托管资金 KPI Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 font-mono">
          <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
            <span className="text-slate-400 text-xs block">企业银行托管账户可用余额</span>
            <div className="text-2xl font-extrabold text-emerald-400">
              ¥{mockEscrowAccount.availableBalanceRmb.toLocaleString()} <span className="text-xs font-normal text-slate-400">元</span>
            </div>
            <span className="text-[10px] text-slate-500">支持 中国工商银行 / 交通银行 联名托管</span>
          </div>

          <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
            <span className="text-slate-400 text-xs block">在途履约锁定托管金 (Locked Escrow)</span>
            <div className="text-2xl font-extrabold text-amber-400">
              ¥{mockEscrowAccount.lockedEscrowRmb.toLocaleString()} <span className="text-xs font-normal text-slate-400">元</span>
            </div>
            <span className="text-[10px] text-amber-400">订单正常履约后自动解锁</span>
          </div>

          <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
            <span className="text-slate-400 text-xs block">数字人民币 (e-CNY) 专户余额</span>
            <div className="text-2xl font-extrabold text-cyan-300">
              ¥{mockEscrowAccount.digitalRmbBalance.toLocaleString()} <span className="text-xs font-normal text-slate-400">e-CNY</span>
            </div>
            <span className="text-[10px] text-cyan-400">实时秒级硬钱包扣划</span>
          </div>
        </div>

        {/* 阶段式结算机制 (Stage Payment Breakdown) */}
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <h3 className="text-xs font-bold text-slate-100 flex items-center space-x-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>水运现货标准“3阶段”结算规则 (Waterway Escrow Rules)</span>
            </h3>
            <span className="text-[10px] font-mono text-slate-400">合规安全保障</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
            <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg space-y-1">
              <div className="flex justify-between font-bold text-slate-200">
                <span>阶段 1: 履约保证金</span>
                <span className="text-amber-400 font-mono">10% - 20%</span>
              </div>
              <p className="text-[11px] text-slate-400">合同签署后锁定，防止任意弃船或违约。</p>
            </div>

            <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg space-y-1">
              <div className="flex justify-between font-bold text-slate-200">
                <span>阶段 2: 装船预付款</span>
                <span className="text-cyan-400 font-mono">50%</span>
              </div>
              <p className="text-[11px] text-slate-400">起运港装船提单签发后，解冻转付船东加油加水成本。</p>
            </div>

            <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg space-y-1">
              <div className="flex justify-between font-bold text-slate-200">
                <span>阶段 3: 目的港尾款解冻</span>
                <span className="text-emerald-400 font-mono">30% - 40%</span>
              </div>
              <p className="text-[11px] text-slate-400">到港卸毕盖章收货后，尾款即时打入船东账户。</p>
            </div>
          </div>
        </div>

        {/* 结算订单划扣列表 */}
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-3">
          <h3 className="text-xs font-bold text-slate-100">结算交易订单明细列表</h3>

          <div className="space-y-2 text-xs font-mono">
            {orders.map((order) => (
              <div
                key={order.id}
                className="p-3 bg-slate-950 border border-slate-800 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div className="space-y-1">
                  <div className="font-bold text-slate-200">
                    订单 #{order.orderNo} - {order.cargoTitle}
                  </div>
                  <div className="text-[11px] text-slate-400 font-sans">
                    承运企业: {order.carrierName} | 船名: {order.vesselName}
                  </div>
                </div>

                <div className="flex items-center space-x-3 shrink-0">
                  <div className="text-right">
                    <span className="text-slate-400 text-[10px] block">约定运费</span>
                    <span className="text-amber-400 font-bold">
                      ¥{order.totalAgreedCostRmb.toLocaleString()}
                    </span>
                  </div>

                  <button
                    onClick={() => releaseEscrowPayment(order.id)}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-xs font-bold transition"
                  >
                    手动解冻划款
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
