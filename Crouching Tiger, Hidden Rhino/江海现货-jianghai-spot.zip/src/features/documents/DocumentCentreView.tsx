/**
 * 中国内河现货航运交易平台 — 合同与单证中心 (Document Centre Workspace)
 * JIANGHAI SPOT Contracts, Bills of Lading & e-Signatures
 */

import React from 'react';
import { useApp } from '../../context/AppContext';
import { 
  FileText, 
  ShieldCheck, 
  CheckCircle2, 
  Download, 
  FileCheck2, 
  Lock, 
  Building2,
  Printer
} from 'lucide-react';

export const DocumentCentreView: React.FC = () => {
  const { orders, addToast } = useApp();

  const handlePrintContract = (orderNo: string) => {
    addToast({
      type: 'info',
      title: '生成电子单证 PDF',
      message: `已导出订单 #${orderNo} 的《水路货物运输合同》与区块链存证哈希`
    });
  };

  return (
    <div className="h-full flex flex-col bg-slate-950 text-slate-100 font-sans overflow-hidden">
      {/* 顶部标题 */}
      <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between shrink-0">
        <div className="flex items-center space-x-2">
          <FileText className="w-5 h-5 text-blue-400" />
          <h2 className="text-base font-bold text-slate-100">内河水路货物运输电子合同与提单存证中心</h2>
        </div>

        <span className="text-xs font-mono text-emerald-400 bg-emerald-950 px-2.5 py-1 rounded border border-emerald-800 flex items-center space-x-1">
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>信办/交通部电子签章认证标准</span>
        </span>
      </div>

      {/* 主体 */}
      <div className="flex-1 p-5 overflow-y-auto space-y-5">
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-3">
          <h3 className="text-xs font-bold text-slate-100">近期已生效电子水路运输合同与提单</h3>

          <div className="space-y-3 text-xs">
            {orders.map((order) => (
              <div
                key={order.id}
                className="p-4 bg-slate-950 border border-slate-800 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div className="space-y-1.5">
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-mono font-bold text-blue-400 bg-blue-950 px-2 py-0.5 rounded border border-blue-800">
                      中华人民共和国水路货物运输合同
                    </span>
                    <span className="text-xs font-bold text-slate-100">#{order.orderNo}</span>
                  </div>

                  <p className="text-slate-300 font-medium">{order.cargoTitle}</p>

                  <div className="text-[11px] text-slate-400 space-x-3 font-mono">
                    <span>托运方: {order.cargoOwnerName}</span>
                    <span className="text-slate-600">|</span>
                    <span>承运方: {order.carrierName}</span>
                    <span className="text-slate-600">|</span>
                    <span>船舶: {order.vesselName}</span>
                  </div>

                  <div className="text-[10px] text-emerald-400 font-mono">
                    区块链防篡改哈希: 0x8f3a...b2c9e7 (全流程存证)
                  </div>
                </div>

                <div className="flex items-center space-x-2 shrink-0">
                  <button
                    onClick={() => handlePrintContract(order.orderNo)}
                    className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold flex items-center space-x-1 border border-slate-700 transition"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>导出电子合同 PDF</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
