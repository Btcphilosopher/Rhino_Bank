/**
 * 中国内河现货航运交易平台 — 运力市场 (Vessel Market Workspace)
 * JIANGHAI SPOT Vessel Capacity & Search
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Vessel, VesselCategory } from '../../types';
import { CreateVesselModal } from './CreateVesselModal';
import { 
  Ship, 
  Search, 
  Plus, 
  MapPin, 
  ShieldCheck, 
  CheckCircle2, 
  Radio, 
  Compass, 
  Fuel, 
  Scale, 
  FileText,
  ChevronRight,
  Sliders
} from 'lucide-react';

const VESSEL_CATEGORIES: { key: VesselCategory | 'all'; label: string }[] = [
  { key: 'all', label: '全部船舶类型' },
  { key: 'dry_bulk_barge', label: '普通干散货驳船' },
  { key: 'container_barge', label: '集装箱驳船' },
  { key: 'tanker', label: '液体化学品船' },
  { key: 'multipurpose', label: '多用途自航船' }
];

export const VesselMarketView: React.FC = () => {
  const { vessels, selectedVesselId, setSelectedVesselId, setActiveView } = useApp();

  const [selectedCategory, setSelectedCategory] = useState<VesselCategory | 'all'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  const filteredVessels = vessels.filter((vessel) => {
    const matchesCategory = selectedCategory === 'all' || vessel.category === selectedCategory;
    const matchesSearch =
      vessel.name.includes(searchTerm) ||
      vessel.mmsi.includes(searchTerm) ||
      vessel.currentLocationPortName.includes(searchTerm) ||
      vessel.operatorOrgName.includes(searchTerm);
    return matchesCategory && matchesSearch;
  });

  const activeVessel = vessels.find((v) => v.id === selectedVesselId) || vessels[0];

  return (
    <div className="h-full flex flex-col bg-slate-950 text-slate-100 font-sans overflow-hidden">
      {/* 顶部过滤与动作 */}
      <div className="p-4 bg-slate-900 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 shrink-0">
        <div className="flex items-center space-x-3 flex-1 min-w-[280px]">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="搜索船名、MMSI九位码、停靠港口、船东企业..."
              className="w-full bg-slate-950 text-slate-200 text-xs rounded-lg pl-9 pr-3 py-2 border border-slate-700 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="flex items-center space-x-1 overflow-x-auto text-xs pb-1 sm:pb-0">
            {VESSEL_CATEGORIES.map((cat) => (
              <button
                key={cat.key}
                onClick={() => setSelectedCategory(cat.key)}
                className={`px-3 py-1.5 rounded-lg whitespace-nowrap font-medium transition ${
                  selectedCategory === cat.key
                    ? 'bg-blue-600 text-white font-bold'
                    : 'bg-slate-900 hover:bg-slate-800 text-slate-400'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="px-3 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg text-xs flex items-center space-x-1.5 shadow-lg transition transform active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>发布空船运力 (Publish Vessel)</span>
        </button>
      </div>

      {/* 主面板 */}
      <div className="flex-1 flex overflow-hidden">
        {/* 左侧：船舶运力列表 */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3.5 bg-slate-950">
          <div className="text-xs font-mono text-slate-400 flex justify-between">
            <span>在线可用空船运力 ({filteredVessels.length} 艘)</span>
            <span>更新时间: 实时 AIS 跟踪中</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {filteredVessels.map((vessel) => {
              const isSelected = vessel.id === activeVessel?.id;

              return (
                <div
                  key={vessel.id}
                  onClick={() => setSelectedVesselId(vessel.id)}
                  className={`p-4 rounded-xl border transition cursor-pointer flex flex-col justify-between space-y-3 ${
                    isSelected
                      ? 'bg-slate-900 border-blue-500 shadow-lg ring-1 ring-blue-500'
                      : 'bg-slate-900/70 hover:bg-slate-900 border-slate-800'
                  }`}
                >
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-semibold font-mono bg-blue-950 text-blue-400 border border-blue-800 px-2 py-0.5 rounded">
                        {vessel.categoryName}
                      </span>
                      <span className="text-[10px] font-mono text-emerald-400 flex items-center space-x-1">
                        <Radio className="w-3 h-3 animate-pulse" />
                        <span>{vessel.status === 'idle' ? '空运力可定' : '在途履约中'}</span>
                      </span>
                    </div>

                    <div className="flex items-center space-x-2">
                      <h3 className="text-sm font-bold text-slate-100">{vessel.name}</h3>
                      <span className="text-[11px] font-mono text-slate-400">MMSI: {vessel.mmsi}</span>
                    </div>

                    <div className="flex items-center space-x-2 text-xs text-slate-300">
                      <MapPin className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                      <span>停靠港: <strong className="text-slate-100">{vessel.currentLocationPortName}</strong></span>
                      <span className="text-slate-600">|</span>
                      <span>空船窗口: <strong className="text-emerald-400">{new Date(vessel.nextAvailableDate).toLocaleDateString('zh-CN')}</strong></span>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs font-mono">
                    <div className="space-x-2 text-slate-400">
                      <span>载重: <strong className="text-slate-200">{vessel.capacityTons}吨</strong></span>
                      {vessel.capacityTeu && <span>({vessel.capacityTeu} TEU)</span>}
                    </div>

                    <div className="text-slate-400">
                      吃水: <span className="text-cyan-400 font-bold">{vessel.maxDraftMeters}m</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* 右侧：船舶参数详情抽屉 */}
        {activeVessel && (
          <div className="w-96 bg-slate-900 border-l border-slate-800 p-5 flex flex-col justify-between overflow-y-auto shrink-0 shadow-2xl">
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <span className="text-xs font-mono text-blue-400 bg-blue-950 px-2 py-0.5 rounded border border-blue-800">
                  船舶档案 #{activeVessel.mmsi}
                </span>
                <span className="text-xs text-emerald-400 flex items-center space-x-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>五星合规船只</span>
                </span>
              </div>

              <div>
                <h2 className="text-base font-bold text-slate-100">{activeVessel.name}</h2>
                <p className="text-xs text-slate-400 mt-1">所属企业: {activeVessel.operatorOrgName}</p>
              </div>

              {/* 关键物理尺寸参数 */}
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800">
                  <span className="text-slate-400 block text-[11px]">载重吨 (DWT):</span>
                  <span className="text-sm font-bold font-mono text-slate-200">
                    {activeVessel.capacityTons} 吨
                  </span>
                </div>

                <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800">
                  <span className="text-slate-400 block text-[11px]">满载吃水 (Draft):</span>
                  <span className="text-sm font-bold font-mono text-cyan-400">
                    {activeVessel.maxDraftMeters} 米 (m)
                  </span>
                </div>

                <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800">
                  <span className="text-slate-400 block text-[11px]">船长 / 船宽:</span>
                  <span className="text-xs font-mono font-semibold text-slate-200">
                    {activeVessel.lengthMeters}m × {activeVessel.beamMeters}m
                  </span>
                </div>

                <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800">
                  <span className="text-slate-400 block text-[11px]">自卸配置:</span>
                  <span className="text-xs font-mono font-semibold text-slate-200">
                    {activeVessel.hasCrane ? '配备自卸吊' : '无自卸'}
                  </span>
                </div>
              </div>

              {/* 实时 AIS 与航迹 */}
              <div className="p-3 bg-blue-950/30 border border-blue-500/30 rounded-lg space-y-1 text-xs">
                <div className="flex justify-between text-slate-300">
                  <span>当前所在停靠港:</span>
                  <span className="font-bold text-slate-100">{activeVessel.currentLocationPortName}</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>空船预定离港日:</span>
                  <span className="font-mono text-emerald-400 font-bold">
                    {new Date(activeVessel.nextAvailableDate).toLocaleDateString('zh-CN')}
                  </span>
                </div>
              </div>
            </div>

            {/* 底部 Action */}
            <div className="pt-4 border-t border-slate-800 space-y-2">
              <button
                onClick={() => setActiveView('matching_engine')}
                className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg text-xs flex items-center justify-center space-x-1 shadow-md transition"
              >
                <span>为此船进行智能货源撮合 (Match Cargoes)</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>

      {isCreateModalOpen && (
        <CreateVesselModal onClose={() => setIsCreateModalOpen(false)} />
      )}
    </div>
  );
};
