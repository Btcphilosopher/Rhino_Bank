/**
 * 中国内河现货航运交易平台 — 发布空船运力 Modal (Create Vessel Modal)
 * JIANGHAI SPOT Vessel Capacity Form
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { VesselCategory } from '../../types';
import { Ship, X, AlertCircle } from 'lucide-react';

interface CreateVesselModalProps {
  onClose: () => void;
}

export const CreateVesselModal: React.FC<CreateVesselModalProps> = ({ onClose }) => {
  const { addVesselListing, ports, addToast } = useApp();

  const [name, setName] = useState('长航货889');
  const [mmsi, setMmsi] = useState('413892019');
  const [category, setCategory] = useState<VesselCategory>('dry_bulk_barge');
  const [capacityTons, setCapacityTons] = useState<number>(3500);
  const [lengthMeters, setLengthMeters] = useState<number>(88);
  const [beamMeters, setBeamMeters] = useState<number>(14.5);
  const [maxDraftMeters, setMaxDraftMeters] = useState<number>(4.2);
  const [currentPortId, setCurrentPortId] = useState<string>(ports[0]?.id || '');
  const [hasCrane, setHasCrane] = useState<boolean>(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const selectedPort = ports.find((p) => p.id === currentPortId) || ports[0];

    const categoryNames: Record<VesselCategory, string> = {
      dry_bulk_barge: '普通干散货驳船',
      self_propelled: '自航货船',
      container_barge: '集装箱驳船',
      multipurpose: '多用途自航船',
      tanker: '液体化学品船',
      heavy_lift: '大件重吊船',
      tug_barge: '内河拖驳组合',
      sand_carrier: '自卸砂石船',
      grain_carrier: '散粮船'
    };

    addVesselListing({
      name,
      mmsi,
      category,
      categoryName: categoryNames[category],
      capacityTons: Number(capacityTons),
      lengthMeters: Number(lengthMeters),
      beamMeters: Number(beamMeters),
      maxDraftMeters: Number(maxDraftMeters),
      emptyDraftMeters: 1.2,
      currentLocationPortId: selectedPort.id,
      currentLocationPortName: selectedPort.name,
      currentLat: 31.2,
      currentLng: 121.5,
      nextAvailablePortId: selectedPort.id,
      nextAvailablePortName: selectedPort.name,
      nextAvailableDate: new Date(Date.now() + 86400000 * 2).toISOString().slice(0, 10),
      fuelType: 'Diesel',
      fuelConsumptionEstTonsPerDay: 2.1,
      hasCrane,
      hasPumpingSystem: false,
      insuranceStatus: 'active',
      safetyCertStatus: 'verified',
      verified: true,
      minVoyageRateRmb: 5000,
      availabilityExpiry: new Date(Date.now() + 86400000 * 10).toISOString(),
      operatorOrgId: 'org_002',
      operatorOrgName: '长航水路运输有限公司'
    });

    addToast({
      type: 'success',
      title: '空船运力挂牌发布成功',
      message: `【${name}】 (${capacityTons}吨) 已进入现货运力池`
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-xl w-full max-w-lg overflow-hidden shadow-2xl font-sans text-xs">
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Ship className="w-4 h-4 text-blue-400" />
            <h3 className="font-bold text-slate-100 text-sm">发布现货空船运力</h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-200">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-slate-400 block mb-1">船名 (Vessel Name):</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-slate-950 text-slate-200 rounded p-2 border border-slate-700"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">MMSI 九位码:</label>
              <input
                type="text"
                required
                value={mmsi}
                onChange={(e) => setMmsi(e.target.value)}
                className="w-full bg-slate-950 text-slate-200 font-mono rounded p-2 border border-slate-700"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-slate-400 block mb-1">船舶类型:</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as VesselCategory)}
                className="w-full bg-slate-950 text-slate-200 rounded p-2 border border-slate-700"
              >
                <option value="dry_bulk_barge">普通干散货驳船</option>
                <option value="self_propelled">自航货船</option>
                <option value="container_barge">集装箱驳船</option>
                <option value="multipurpose">多用途自航船</option>
                <option value="tanker">液体化学品船</option>
              </select>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">载重吨 (DWT):</label>
              <input
                type="number"
                required
                value={capacityTons}
                onChange={(e) => setCapacityTons(Number(e.target.value))}
                className="w-full bg-slate-950 text-slate-200 font-mono rounded p-2 border border-slate-700"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="text-slate-400 block mb-1">船长 (m):</label>
              <input
                type="number"
                value={lengthMeters}
                onChange={(e) => setLengthMeters(Number(e.target.value))}
                className="w-full bg-slate-950 text-slate-200 font-mono rounded p-2 border border-slate-700"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">船宽 (m):</label>
              <input
                type="number"
                value={beamMeters}
                onChange={(e) => setBeamMeters(Number(e.target.value))}
                className="w-full bg-slate-950 text-slate-200 font-mono rounded p-2 border border-slate-700"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">满载吃水 (m):</label>
              <input
                type="number"
                step="0.1"
                value={maxDraftMeters}
                onChange={(e) => setMaxDraftMeters(Number(e.target.value))}
                className="w-full bg-slate-950 text-slate-200 font-mono rounded p-2 border border-slate-700"
              />
            </div>
          </div>

          <div>
            <label className="text-slate-400 block mb-1">当前停靠/待命港口:</label>
            <select
              value={currentPortId}
              onChange={(e) => setCurrentPortId(e.target.value)}
              className="w-full bg-slate-950 text-slate-200 rounded p-2 border border-slate-700"
            >
              {ports.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.regionName})
                </option>
              ))}
            </select>
          </div>

          <div className="pt-3 border-t border-slate-800 flex justify-end space-x-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-lg"
            >
              取消
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg shadow-md"
            >
              发布空船挂牌
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
