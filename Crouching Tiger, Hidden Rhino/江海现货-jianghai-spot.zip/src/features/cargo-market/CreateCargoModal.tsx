/**
 * 中国内河现货航运交易平台 — 发布新货源挂牌 (Create Cargo Modal)
 * JIANGHAI SPOT New Cargo Publishing Form
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { CargoCategory } from '../../types';
import { Package, X, Check, DollarSign, MapPin } from 'lucide-react';

export const CreateCargoModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const { ports, addCargoListing, addToast } = useApp();

  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<CargoCategory>('coal');
  const [weightTons, setWeightTons] = useState(3000);
  const [askingPrice, setAskingPrice] = useState(35);
  const [originPortId, setOriginPortId] = useState(ports[1]?.id || 'port-nanjing');
  const [destPortId, setDestPortId] = useState(ports[2]?.id || 'port-wuhu');
  const [maxDraft, setMaxDraft] = useState(4.2);
  const [description, setDescription] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      addToast({ type: 'warning', title: '表单不完整', message: '请填写货源标题名称' });
      return;
    }

    const originPort = ports.find((p) => p.id === originPortId);
    const destPort = ports.find((p) => p.id === destPortId);

    addCargoListing({
      title,
      category,
      categoryName: category === 'coal' ? '煤炭/电煤' : category === 'cement' ? '水泥/熟料' : '散货建材',
      weightTons: Number(weightTons),
      askingPricePerTon: Number(askingPrice),
      totalAskingFreight: Number(weightTons) * Number(askingPrice),
      pricingMechanism: 'fixed',
      originPortId,
      originPortName: originPort?.name || '南京港',
      destinationPortId: destPortId,
      destinationPortName: destPort?.name || '芜湖港',
      loadingWindowStart: new Date().toISOString(),
      loadingWindowEnd: new Date(Date.now() + 86400000 * 5).toISOString(),
      ownerOrgId: 'org-shipper-01',
      ownerOrgName: '安徽海螺水泥股份有限公司',
      loadingMethod: '抓斗快速装船',
      unloadingMethod: '皮带机输送卸船',
      maxDraftMeters: Number(maxDraft),
      description: description || '标准内河散货运输，需要船舶持有限深证书。',
      deliveryWindowStart: new Date(Date.now() + 86400000 * 6).toISOString(),
      deliveryWindowEnd: new Date(Date.now() + 86400000 * 10).toISOString(),
      requiredVesselType: 'dry_bulk_barge',
      packaging: '散装',
      isDangerous: false,
      insuranceRequired: true,
      currency: 'RMB',
      readiness: 'ready',
      docStatus: 'complete',
      expiresAt: new Date(Date.now() + 86400000 * 5).toISOString(),
      verified: true
    });

    addToast({
      type: 'success',
      title: '货源发布成功',
      message: `已向大厅挂牌 [${title}] (${weightTons}吨)`
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-xl bg-slate-900 border border-slate-700 rounded-xl shadow-2xl overflow-hidden font-sans text-slate-200">
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Package className="w-5 h-5 text-amber-400" />
            <h2 className="text-base font-bold text-slate-100">发布现货货源挂牌需求</h2>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-slate-200">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4 text-xs">
          <div>
            <label className="text-slate-400 block mb-1 font-semibold">货源标题名称 (Cargo Title):</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="例如: 宁国熟料厂 3500吨 散装水泥发南京港"
              className="w-full bg-slate-950 text-slate-100 rounded-lg p-2.5 border border-slate-700 focus:border-amber-500 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-slate-400 block mb-1">货物种类 (Category):</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as CargoCategory)}
                className="w-full bg-slate-950 text-slate-100 rounded-lg p-2 border border-slate-700"
              >
                <option value="coal">煤炭/电煤</option>
                <option value="cement">水泥/熟料</option>
                <option value="steel">钢材/卷板</option>
                <option value="sand_gravel">砂石建材</option>
                <option value="grain">粮食/原粮</option>
                <option value="containers">集装箱(TEU)</option>
              </select>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">货物总量 (吨 Tons):</label>
              <input
                type="number"
                value={weightTons}
                onChange={(e) => setWeightTons(Number(e.target.value))}
                className="w-full bg-slate-950 text-slate-100 font-mono rounded-lg p-2 border border-slate-700"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-slate-400 block mb-1">起运港口 (Origin Port):</label>
              <select
                value={originPortId}
                onChange={(e) => setOriginPortId(e.target.value)}
                className="w-full bg-slate-950 text-slate-100 rounded-lg p-2 border border-slate-700"
              >
                {ports.map((p) => (
                  <option key={p.id} value={p.id}>{p.name} ({p.regionName})</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">目的卸货港 (Destination):</label>
              <select
                value={destPortId}
                onChange={(e) => setDestPortId(e.target.value)}
                className="w-full bg-slate-950 text-slate-100 rounded-lg p-2 border border-slate-700"
              >
                {ports.map((p) => (
                  <option key={p.id} value={p.id}>{p.name} ({p.regionName})</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-slate-400 block mb-1">意向一口价运费 (RMB/吨):</label>
              <input
                type="number"
                value={askingPrice}
                onChange={(e) => setAskingPrice(Number(e.target.value))}
                className="w-full bg-slate-950 text-amber-400 font-mono font-bold rounded-lg p-2 border border-slate-700"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">船只限制吃水 (米 Draft):</label>
              <input
                type="number"
                step="0.1"
                value={maxDraft}
                onChange={(e) => setMaxDraft(Number(e.target.value))}
                className="w-full bg-slate-950 text-slate-100 font-mono rounded-lg p-2 border border-slate-700"
              />
            </div>
          </div>

          <div>
            <label className="text-slate-400 block mb-1">装卸与航次特殊要求:</label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="请输入水运特殊要求，如雨天停装、皮带输送速卸等..."
              className="w-full bg-slate-950 text-slate-100 rounded-lg p-2 border border-slate-700 focus:outline-none"
            />
          </div>

          <div className="pt-3 border-t border-slate-800 flex items-center justify-end space-x-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg font-medium transition"
            >
              取消
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg transition shadow-md"
            >
              一键挂牌发布
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
