/**
 * 中国内河现货航运交易平台 — 货源市场 (Cargo Market Workspace)
 * JIANGHAI SPOT Cargo Listings & Search
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { CargoListing, CargoCategory } from '../../types';
import { CreateCargoModal } from './CreateCargoModal';
import { 
  Package, 
  Search, 
  Plus, 
  Filter, 
  MapPin, 
  Calendar, 
  ShieldCheck, 
  ArrowRight, 
  DollarSign, 
  Scale, 
  FileText,
  X,
  ChevronRight
} from 'lucide-react';

const CARGO_CATEGORIES: { key: CargoCategory | 'all'; label: string }[] = [
  { key: 'all', label: '全部货种' },
  { key: 'coal', label: '煤炭/电煤' },
  { key: 'cement', label: '水泥/熟料' },
  { key: 'steel', label: '钢材/卷板' },
  { key: 'sand_gravel', label: '砂石建材' },
  { key: 'grain', label: '粮食/原粮' },
  { key: 'containers', label: '集装箱(TEU)' },
  { key: 'fertiliser', label: '化肥' },
  { key: 'chemicals', label: '化工液体' }
];

export const CargoMarketView: React.FC = () => {
  const { cargoListings, selectedCargoId, setSelectedCargoId, setActiveView, currentRole } = useApp();

  const [selectedCategory, setSelectedCategory] = useState<CargoCategory | 'all'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  // 过滤货源
  const filteredListings = cargoListings.filter((cargo) => {
    const matchesCategory = selectedCategory === 'all' || cargo.category === selectedCategory;
    const matchesSearch =
      cargo.title.includes(searchTerm) ||
      cargo.originPortName.includes(searchTerm) ||
      cargo.destinationPortName.includes(searchTerm) ||
      cargo.ownerOrgName.includes(searchTerm);
    return matchesCategory && matchesSearch;
  });

  const activeCargo = cargoListings.find((c) => c.id === selectedCargoId) || cargoListings[0];

  return (
    <div className="h-full flex flex-col bg-slate-950 text-slate-100 font-sans overflow-hidden">
      {/* 顶部过滤与动作栏 */}
      <div className="p-4 bg-slate-900 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 shrink-0">
        <div className="flex items-center space-x-3 flex-1 min-w-[280px]">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="搜索货源名称、港口、货主企业..."
              className="w-full bg-slate-950 text-slate-200 text-xs rounded-lg pl-9 pr-3 py-2 border border-slate-700 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="flex items-center space-x-1 overflow-x-auto text-xs pb-1 sm:pb-0">
            {CARGO_CATEGORIES.map((cat) => (
              <button
                key={cat.key}
                onClick={() => setSelectedCategory(cat.key)}
                className={`px-2.5 py-1.5 rounded-md font-medium whitespace-nowrap transition ${
                  selectedCategory === cat.key
                    ? 'bg-amber-500 text-slate-950 font-bold'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="px-3.5 py-2 bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold rounded-lg text-xs flex items-center space-x-1.5 shadow-md transition"
        >
          <Plus className="w-4 h-4" />
          <span>发布新货源需求</span>
        </button>
      </div>

      {/* 主体：货源列表与详情右侧抽屉 */}
      <div className="flex-1 flex overflow-hidden">
        {/* 左侧货源卡片网格/列表 */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
            <span>找到 {filteredListings.length} 项符合条件的挂牌货源</span>
            <span>货币单位: 人民币 (RMB / 元)</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {filteredListings.map((cargo) => {
              const isSelected = cargo.id === activeCargo?.id;
              return (
                <div
                  key={cargo.id}
                  onClick={() => setSelectedCargoId(cargo.id)}
                  className={`p-4 rounded-xl border transition cursor-pointer flex flex-col justify-between space-y-3 ${
                    isSelected
                      ? 'bg-slate-900 border-amber-500 shadow-lg shadow-amber-500/10 ring-1 ring-amber-500'
                      : 'bg-slate-900/70 hover:bg-slate-900 border-slate-800'
                  }`}
                >
                  <div className="space-y-2">
                    <div className="flex items-start justify-between">
                      <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">
                        {cargo.categoryName}
                      </span>
                      <span className="text-[11px] text-slate-400 font-mono">
                        {cargo.pricingMechanism === 'fixed' ? '一口价现货' : '竞价招标'}
                      </span>
                    </div>

                    <h3 className="text-sm font-bold text-slate-100 line-clamp-1">{cargo.title}</h3>

                    <div className="flex items-center space-x-2 text-xs text-slate-300">
                      <MapPin className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                      <span className="truncate">{cargo.originPortName}</span>
                      <ArrowRight className="w-3 h-3 text-slate-500 shrink-0" />
                      <span className="truncate">{cargo.destinationPortName}</span>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs">
                    <div className="space-x-2">
                      <span className="text-slate-400 font-mono">{cargo.weightTons} 吨</span>
                      <span className="text-slate-600">|</span>
                      <span className="text-slate-400 font-mono">限深: {cargo.maxDraftMeters}m</span>
                    </div>

                    <div className="text-right font-mono">
                      <span className="text-xs text-slate-400">意向运价: </span>
                      <span className="text-base font-extrabold text-amber-400">
                        ¥{cargo.askingPricePerTon}
                      </span>
                      <span className="text-[10px] text-slate-400">/吨</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* 右侧：选中货源详情抽屉 (Context Drawer) */}
        {activeCargo && (
          <div className="w-96 bg-slate-900 border-l border-slate-800 p-5 flex flex-col justify-between overflow-y-auto shrink-0 shadow-2xl">
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <span className="text-xs font-mono text-amber-400 bg-amber-950 px-2 py-0.5 rounded border border-amber-800">
                  货源详情 #{activeCargo.id}
                </span>
                <span className="text-xs text-emerald-400 flex items-center space-x-1">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>合规真凭</span>
                </span>
              </div>

              <div>
                <h2 className="text-base font-bold text-slate-100">{activeCargo.title}</h2>
                <p className="text-xs text-slate-400 mt-1">发布企业: {activeCargo.ownerOrgName}</p>
              </div>

              {/* 货源关键指标 Grid */}
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800">
                  <span className="text-slate-400 block text-[11px]">货物总量:</span>
                  <span className="text-sm font-bold font-mono text-slate-200">
                    {activeCargo.weightTons} 吨
                  </span>
                </div>

                <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800">
                  <span className="text-slate-400 block text-[11px]">限制吃水:</span>
                  <span className="text-sm font-bold font-mono text-cyan-400">
                    {activeCargo.maxDraftMeters} 米 (m)
                  </span>
                </div>

                <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800">
                  <span className="text-slate-400 block text-[11px]">起运港:</span>
                  <span className="text-xs font-semibold text-slate-200 truncate block">
                    {activeCargo.originPortName}
                  </span>
                </div>

                <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800">
                  <span className="text-slate-400 block text-[11px]">卸货港:</span>
                  <span className="text-xs font-semibold text-slate-200 truncate block">
                    {activeCargo.destinationPortName}
                  </span>
                </div>
              </div>

              {/* 描述与装卸要求 */}
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg space-y-2 text-xs">
                <span className="font-bold text-slate-200 block">装卸与设备条款:</span>
                <p className="text-slate-400 leading-relaxed text-[11px]">{activeCargo.description}</p>
                <div className="pt-2 border-t border-slate-800/80 space-y-1 text-[11px] text-slate-300">
                  <p>• 装船方式: {activeCargo.loadingMethod}</p>
                  <p>• 卸船方式: {activeCargo.unloadingMethod}</p>
                  <p>• 受载窗口: {new Date(activeCargo.loadingWindowStart).toLocaleDateString('zh-CN')} 至 {new Date(activeCargo.loadingWindowEnd).toLocaleDateString('zh-CN')}</p>
                </div>
              </div>

              {/* 运费与核算 */}
              <div className="p-3 bg-amber-950/30 border border-amber-500/30 rounded-lg space-y-1.5 text-xs">
                <div className="flex justify-between text-slate-300">
                  <span>预期单价:</span>
                  <span className="font-mono text-amber-400 font-bold">¥{activeCargo.askingPricePerTon} / 吨</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>估算基础总运费:</span>
                  <span className="font-mono text-amber-300 font-extrabold text-sm">
                    ¥{activeCargo.totalAskingFreight.toLocaleString()} 元
                  </span>
                </div>
              </div>
            </div>

            {/* 底部交互 Action */}
            <div className="pt-4 border-t border-slate-800 space-y-2">
              <button
                onClick={() => setActiveView('spot_quotation')}
                className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg text-xs flex items-center justify-center space-x-1 shadow-md transition"
              >
                <span>为此货源发起运费报价 (Submit Freight Quote)</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* 创建货源 Modal */}
      {isCreateModalOpen && (
        <CreateCargoModal onClose={() => setIsCreateModalOpen(false)} />
      )}
    </div>
  );
};
