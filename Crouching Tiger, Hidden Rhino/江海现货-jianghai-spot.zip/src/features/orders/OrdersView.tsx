/**
 * 中国内河现货航运交易平台 — 订单履约管理 (Orders Management Workspace)
 * JIANGHAI SPOT Order Management & Milestones
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TransportOrder, OrderStatus } from '../../types';
import { 
  FileCheck2, 
  MapPin, 
  Ship, 
  Package, 
  Clock, 
  ArrowRight, 
  CheckCircle2, 
  AlertTriangle, 
  Navigation,
  FileText,
  DollarSign
} from 'lucide-react';

const STATUS_MAP: Record<OrderStatus, { label: string; bg: string; text: string }> = {
  created: { label: '订单已创建', bg: 'bg-slate-800', text: 'text-slate-300' },
  pending_confirm: { label: '待双方确认', bg: 'bg-slate-800', text: 'text-slate-300' },
  awaiting_load: { label: '在港待装货', bg: 'bg-blue-950', text: 'text-blue-400' },
  loading: { label: '起运港装船中', bg: 'bg-amber-950', text: 'text-amber-400' },
  departed: { label: '已离港开航', bg: 'bg-cyan-950', text: 'text-cyan-400' },
  sailing: { label: '在途航行中', bg: 'bg-cyan-950', text: 'text-cyan-400' },
  awaiting_berth: { label: '抵港等靠泊', bg: 'bg-purple-950', text: 'text-purple-400' },
  unloading: { label: '目的港卸船中', bg: 'bg-indigo-950', text: 'text-indigo-400' },
  delivered: { label: '货物已安全交付', bg: 'bg-emerald-950', text: 'text-emerald-400' },
  settled: { label: '运费已划拨结算', bg: 'bg-emerald-950', text: 'text-emerald-400' },
  closed: { label: '航次结清关闭', bg: 'bg-slate-800', text: 'text-slate-400' },
  disputed: { label: '单证争议中', bg: 'bg-red-950', text: 'text-red-400' }
};

export const OrdersView: React.FC = () => {
  const { orders, selectedOrderId, setSelectedOrderId, setActiveView } = useApp();

  const [selectedStatus, setSelectedStatus] = useState<string>('all');

  const filteredOrders = orders.filter(
    (o) => selectedStatus === 'all' || o.status === selectedStatus
  );

  const activeOrder = orders.find((o) => o.id === selectedOrderId) || orders[0];

  return (
    <div className="h-full flex flex-col bg-slate-950 text-slate-100 font-sans overflow-hidden">
      {/* 顶部标签与过滤 */}
      <div className="p-4 bg-slate-900 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 shrink-0">
        <div className="flex items-center space-x-2">
          <FileCheck2 className="w-5 h-5 text-cyan-400" />
          <h2 className="text-base font-bold text-slate-100">现货水运履约订单管理大厅</h2>
        </div>

        <div className="flex items-center space-x-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs overflow-x-auto">
          <button
            onClick={() => setSelectedStatus('all')}
            className={`px-3 py-1 rounded font-medium transition ${
              selectedStatus === 'all' ? 'bg-blue-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            全部订单 ({orders.length})
          </button>
          <button
            onClick={() => setSelectedStatus('sailing')}
            className={`px-3 py-1 rounded font-medium transition ${
              selectedStatus === 'sailing' ? 'bg-cyan-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            航行在途
          </button>
          <button
            onClick={() => setSelectedStatus('settled')}
            className={`px-3 py-1 rounded font-medium transition ${
              selectedStatus === 'settled' ? 'bg-emerald-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            已结清
          </button>
        </div>
      </div>

      {/* 主体 */}
      <div className="flex-1 flex overflow-hidden">
        {/* 左侧：订单列表 */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {filteredOrders.map((order) => {
              const statusCfg = STATUS_MAP[order.status] || STATUS_MAP.created;
              const isSelected = order.id === activeOrder?.id;

              return (
                <div
                  key={order.id}
                  onClick={() => setSelectedOrderId(order.id)}
                  className={`p-4 rounded-xl border transition cursor-pointer flex flex-col justify-between space-y-3 ${
                    isSelected
                      ? 'bg-slate-900 border-cyan-500 shadow-lg ring-1 ring-cyan-500'
                      : 'bg-slate-900/70 hover:bg-slate-900 border-slate-800'
                  }`}
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-mono font-bold text-slate-400">
                        订单号: #{order.orderNo}
                      </span>
                      <span className={`text-[11px] font-mono font-semibold px-2 py-0.5 rounded ${statusCfg.bg} ${statusCfg.text}`}>
                        {statusCfg.label}
                      </span>
                    </div>

                    <h3 className="text-sm font-bold text-slate-100">{order.cargoTitle}</h3>

                    <div className="text-xs text-slate-300 flex items-center space-x-2">
                      <Ship className="w-3.5 h-3.5 text-blue-400" />
                      <span>承运船: <strong className="text-cyan-300">{order.vesselName}</strong></span>
                      <span className="text-slate-600">|</span>
                      <span>货量: {order.weightTons}吨</span>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs font-mono">
                    <div className="flex items-center space-x-1 text-slate-400">
                      <MapPin className="w-3 h-3 text-cyan-400" />
                      <span>{order.originPortName}</span>
                      <ArrowRight className="w-3 h-3 text-slate-600" />
                      <span>{order.destinationPortName}</span>
                    </div>

                    <div className="font-bold text-amber-400">
                      ¥{order.totalAgreedCostRmb.toLocaleString()}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* 右侧：订单里程碑与指令操作 */}
        {activeOrder && (
          <div className="w-96 bg-slate-900 border-l border-slate-800 p-5 flex flex-col justify-between shrink-0 overflow-y-auto shadow-2xl">
            <div className="space-y-4">
              <div className="pb-3 border-b border-slate-800">
                <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800">
                  订单履约监控 #{activeOrder.orderNo}
                </span>
                <h2 className="text-base font-bold text-slate-100 mt-1">{activeOrder.cargoTitle}</h2>
              </div>

              {/* 订单进度里程碑 (Order Milestones Timeline) */}
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg space-y-3 text-xs">
                <span className="font-bold text-slate-200 block">水运履约节点链:</span>

                <div className="space-y-2.5 relative pl-4 border-l border-slate-800 text-[11px]">
                  <div className="relative">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 absolute -left-[21px] top-0.5" />
                    <p className="font-semibold text-slate-200">1. 电子合同挂牌生成并签署</p>
                    <p className="text-slate-500 text-[10px]">校验主体企业电子签章及防篡改哈希</p>
                  </div>

                  <div className="relative">
                    <span className={`w-2.5 h-2.5 rounded-full absolute -left-[21px] top-0.5 ${
                      ['awaiting_load', 'loading', 'departed', 'sailing', 'awaiting_berth', 'unloading', 'delivered', 'settled'].includes(activeOrder.status)
                        ? 'bg-emerald-500'
                        : 'bg-slate-700'
                    }`} />
                    <p className="font-semibold text-slate-200">2. 银行/e-CNY 运费资金托管锁定</p>
                    <p className="text-slate-500 text-[10px]">托管金额: ¥{activeOrder.totalAgreedCostRmb.toLocaleString()}</p>
                  </div>

                  <div className="relative">
                    <span className={`w-2.5 h-2.5 rounded-full absolute -left-[21px] top-0.5 ${
                      ['sailing', 'awaiting_berth', 'unloading', 'delivered', 'settled'].includes(activeOrder.status)
                        ? 'bg-emerald-500 animate-pulse'
                        : 'bg-slate-700'
                    }`} />
                    <p className="font-semibold text-slate-200">3. 航运在途 AIS 动态追踪与船闸过闸</p>
                    <p className="text-slate-500 text-[10px]">航程完成度: {activeOrder.progressPercent}%</p>
                  </div>

                  <div className="relative">
                    <span className={`w-2.5 h-2.5 rounded-full absolute -left-[21px] top-0.5 ${
                      ['settled'].includes(activeOrder.status)
                        ? 'bg-emerald-500'
                        : 'bg-slate-700'
                    }`} />
                    <p className="font-semibold text-slate-200">4. 卸货交付签章与托管运费全额解冻</p>
                  </div>
                </div>
              </div>

              {/* 核心运价与履约动作按钮 */}
              <div className="p-3 bg-cyan-950/30 border border-cyan-500/30 rounded-lg space-y-1.5 text-xs font-mono">
                <div className="flex justify-between text-slate-300">
                  <span>约定运费总计:</span>
                  <span className="font-bold text-amber-400">¥{activeOrder.totalAgreedCostRmb.toLocaleString()} 元</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>预估抵达 ETA:</span>
                  <span className="text-emerald-400 font-bold">
                    {new Date(activeOrder.estimatedArrival).toLocaleDateString('zh-CN')}
                  </span>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800 space-y-2">
              <button
                onClick={() => setActiveView('voyage_detail')}
                className="w-full py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white font-bold rounded-lg text-xs flex items-center justify-center space-x-1 shadow-md transition"
              >
                <Navigation className="w-4 h-4" />
                <span>进入航次实时跟踪监控 (Voyage Monitor)</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
