/**
 * 中国内河现货航运交易平台 — 港口码头与泊位计划 (Port Operations Workspace)
 * JIANGHAI SPOT Port Operations & Berth Planning
 */

import React from 'react';
import { useApp } from '../../context/AppContext';
import { Port } from '../../types';
import { 
  Building2, 
  MapPin, 
  Anchor, 
  Calendar, 
  Clock, 
  AlertTriangle, 
  CheckCircle2, 
  Sliders, 
  Ship, 
  BarChart2,
  ChevronRight
} from 'lucide-react';

export const PortsView: React.FC = () => {
  const { ports, selectedPortId, setSelectedPortId, triggerSimulatedEvent } = useApp();

  const activePort = ports.find((p) => p.id === selectedPortId) || ports[0];

  return (
    <div className="h-full flex flex-col bg-slate-950 text-slate-100 font-sans overflow-hidden">
      {/* 顶部标签 */}
      <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between shrink-0">
        <div className="flex items-center space-x-2">
          <Building2 className="w-5 h-5 text-purple-400" />
          <h2 className="text-base font-bold text-slate-100">内河枢纽港口作业与泊位调度控制台</h2>
        </div>

        <button
          onClick={() => triggerSimulatedEvent('lock_congestion')}
          className="px-3 py-1.5 bg-amber-600/20 hover:bg-amber-600/30 text-amber-300 border border-amber-500/40 rounded-md text-xs font-semibold flex items-center space-x-1.5 transition"
        >
          <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
          <span>触发港口/船闸拥堵模拟演练</span>
        </button>
      </div>

      {/* 主体 */}
      <div className="flex-1 flex overflow-hidden">
        {/* 左侧：港口列表 */}
        <div className="w-80 bg-slate-900 border-r border-slate-800 p-3 overflow-y-auto space-y-2 shrink-0">
          <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider px-2 py-1">
            主要干线枢纽港口 ({ports.length})
          </div>

          <div className="space-y-1.5">
            {ports.map((port) => {
              const isSelected = port.id === activePort?.id;
              return (
                <div
                  key={port.id}
                  onClick={() => setSelectedPortId(port.id)}
                  className={`p-3 rounded-lg border transition cursor-pointer space-y-1 ${
                    isSelected
                      ? 'bg-blue-950/60 border-blue-500 text-white shadow-md'
                      : 'bg-slate-950 hover:bg-slate-800/80 border-slate-800 text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between font-bold text-xs">
                    <span>{port.name}</span>
                    <span
                      className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${
                        port.status === 'congested'
                          ? 'bg-red-950 text-red-400 border border-red-800'
                          : port.status === 'busy'
                          ? 'bg-amber-950 text-amber-400 border border-amber-800'
                          : 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                      }`}
                    >
                      {port.status === 'congested' ? '严重拥堵' : port.status === 'busy' ? '泊位繁忙' : '畅通'}
                    </span>
                  </div>

                  <div className="text-[11px] text-slate-400 flex items-center justify-between font-mono">
                    <span>水系: {port.regionName}</span>
                    <span>吃水限制: {port.maxDraftLimitMeters}m</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* 右侧：港口详情与泊位调度 Gantt 模拟 */}
        {activePort && (
          <div className="flex-1 p-5 overflow-y-auto space-y-5 bg-slate-950">
            {/* 港口 Header Card */}
            <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-3 shadow-lg">
              <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-800">
                <div>
                  <div className="flex items-center space-x-2">
                    <h1 className="text-base font-bold text-slate-100">{activePort.name}</h1>
                    <span className="text-xs font-mono bg-slate-800 px-2 py-0.5 rounded text-slate-300">
                      代码: {activePort.code}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">
                    所属水系: {activePort.regionName} | 所在城市: {activePort.province} {activePort.city}
                  </p>
                </div>

                <div className="flex items-center space-x-3 text-xs font-mono">
                  <div className="text-right">
                    <span className="text-slate-400 block text-[10px]">平均等泊耗时</span>
                    <span className="text-amber-400 font-bold text-sm">{activePort.avgWaitHours} 小时</span>
                  </div>
                  <div className="text-right">
                    <span className="text-slate-400 block text-[10px]">总仓储能力</span>
                    <span className="text-cyan-400 font-bold text-sm">{activePort.storageCapacityTons.toLocaleString()} 吨</span>
                  </div>
                </div>
              </div>

              {/* 泊位架构 Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                  <span className="text-slate-400 block text-[11px]">总泊位数 (Berths):</span>
                  <span className="text-base font-extrabold font-mono text-slate-100">{activePort.berthCount} 个</span>
                </div>

                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                  <span className="text-slate-400 block text-[11px]">正在靠泊作业:</span>
                  <span className="text-base font-extrabold font-mono text-cyan-400">
                    {activePort.berths.filter(b => b.isOccupied).length} 个
                  </span>
                </div>

                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                  <span className="text-slate-400 block text-[11px]">锚地排队等待:</span>
                  <span className="text-base font-extrabold font-mono text-amber-400">{activePort.queueVesselCount} 艘</span>
                </div>

                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                  <span className="text-slate-400 block text-[11px]">航道最大保证吃水:</span>
                  <span className="text-base font-extrabold font-mono text-emerald-400">{activePort.maxDraftLimitMeters} 米 (m)</span>
                </div>
              </div>
            </div>

            {/* 泊位计划 Gantt 画布模拟 */}
            <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-slate-100 flex items-center space-x-2">
                  <Calendar className="w-4 h-4 text-cyan-400" />
                  <span>泊位实时计划甘特图 (Berth Allocation Timeline)</span>
                </h3>
                <span className="text-[10px] font-mono text-slate-400">时间跨度: 未来 24 小时</span>
              </div>

              <div className="space-y-2 text-xs font-mono pt-2">
                {activePort.berths.map((berth, index) => (
                  <div key={berth.id} className="flex items-center space-x-3 p-2 bg-slate-950 rounded border border-slate-800">
                    <span className="w-16 text-slate-400 font-bold shrink-0">泊位 #{berth.berthNumber}</span>
                    <div className="flex-1 h-7 bg-slate-900 rounded relative overflow-hidden flex items-center">
                      {berth.isOccupied ? (
                        <div
                          className={`h-full flex items-center px-2 text-[10px] text-white font-bold rounded bg-blue-600/80 w-3/4`}
                        >
                          {berth.currentVesselName || '在靠作业船舶'} (作业中)
                        </div>
                      ) : (
                        <div className="text-slate-600 pl-3 text-[10px]">【待靠空闲】</div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
