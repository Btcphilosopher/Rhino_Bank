/**
 * 中国内河现货航运交易平台 — 运营控制台 (Operations Control Workspace)
 * JIANGHAI SPOT Operations & Event Bus Log
 */

import React from 'react';
import { useApp } from '../../context/AppContext';
import { Activity, Radio, AlertTriangle, Cpu, Terminal } from 'lucide-react';

export const OperationsControlView: React.FC = () => {
  const { audits, triggerSimulatedEvent } = useApp();

  return (
    <div className="h-full flex flex-col bg-slate-950 text-slate-100 font-sans overflow-hidden">
      <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between shrink-0">
        <div className="flex items-center space-x-2">
          <Activity className="w-5 h-5 text-cyan-400" />
          <h2 className="text-base font-bold text-slate-100">平台运营监控与事件总线控制台</h2>
        </div>

        <button
          onClick={() => triggerSimulatedEvent('lock_congestion')}
          className="px-3 py-1.5 bg-amber-600/20 hover:bg-amber-600/30 text-amber-300 border border-amber-500/40 rounded-md text-xs font-semibold transition"
        >
          模拟广播船闸拥堵事件
        </button>
      </div>

      <div className="flex-1 p-5 overflow-y-auto space-y-5 font-mono text-xs">
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-3">
          <div className="flex items-center space-x-2 text-slate-300 font-bold">
            <Terminal className="w-4 h-4 text-cyan-400" />
            <span>核心确定性事件总线实时日志 (Event Bus Stream / Audit Log)</span>
          </div>

          <div className="space-y-1.5 p-3 bg-slate-950 rounded-lg border border-slate-800 max-h-80 overflow-y-auto">
            {audits.map((log) => (
              <div key={log.id} className="flex items-start space-x-3 text-[11px] py-1 border-b border-slate-900">
                <span className="text-slate-500 shrink-0">{new Date(log.timestamp).toLocaleTimeString('zh-CN')}</span>
                <span className="text-cyan-400 shrink-0">[{log.module}]</span>
                <span className="text-amber-400 shrink-0">[{log.operator}]</span>
                <span className="text-slate-200">{log.action}: {log.details}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
