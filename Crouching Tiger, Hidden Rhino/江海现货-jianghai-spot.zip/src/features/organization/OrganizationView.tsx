/**
 * 中国内河现货航运交易平台 — 企业档案 (Organization Workspace)
 * JIANGHAI SPOT Org Profile & KYC Verification
 */

import React from 'react';
import { useApp } from '../../context/AppContext';
import { Building, ShieldCheck, CheckCircle2, Award, FileText } from 'lucide-react';

export const OrganizationView: React.FC = () => {
  const { currentRole } = useApp();

  return (
    <div className="h-full flex flex-col bg-slate-950 text-slate-100 font-sans overflow-hidden">
      <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between shrink-0">
        <div className="flex items-center space-x-2">
          <Building className="w-5 h-5 text-amber-400" />
          <h2 className="text-base font-bold text-slate-100">企业资质档案与信用评级认证</h2>
        </div>
      </div>

      <div className="flex-1 p-5 overflow-y-auto space-y-5">
        <div className="p-5 bg-slate-900 border border-slate-800 rounded-xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <h1 className="text-base font-bold text-slate-100">安徽海螺水泥股份有限公司 (示范货主企业)</h1>
              <p className="text-xs text-slate-400 mt-0.5">统一社会信用代码: 91340200149123849A</p>
            </div>
            <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-950 px-2.5 py-1 rounded border border-emerald-800 flex items-center space-x-1">
              <ShieldCheck className="w-4 h-4" />
              <span>AAA 级水运诚信企业</span>
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
              <span className="text-slate-400 block text-[11px]">水路履约完成单数:</span>
              <span className="text-base font-extrabold font-mono text-slate-100">1,248 笔</span>
            </div>

            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
              <span className="text-slate-400 block text-[11px]">按期付款解冻率:</span>
              <span className="text-base font-extrabold font-mono text-emerald-400">99.8%</span>
            </div>

            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
              <span className="text-slate-400 block text-[11px]">现货挂牌违约率:</span>
              <span className="text-base font-extrabold font-mono text-cyan-400">0.02%</span>
            </div>

            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
              <span className="text-slate-400 block text-[11px]">银行托管账户核验:</span>
              <span className="text-base font-extrabold font-mono text-emerald-400">已连通</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
