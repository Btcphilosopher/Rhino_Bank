/**
 * 中国内河现货航运交易平台 — 预警与异常通知 (Alerts Workspace)
 * JIANGHAI SPOT System Alerts & Exceptions
 */

import React from 'react';
import { useApp } from '../../context/AppContext';
import { AlertTriangle, CheckCircle2 } from 'lucide-react';

export const AlertsView: React.FC = () => {
  const { alerts } = useApp();

  return (
    <div className="h-full flex flex-col bg-slate-950 text-slate-100 font-sans overflow-hidden">
      <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between shrink-0">
        <div className="flex items-center space-x-2">
          <AlertTriangle className="w-5 h-5 text-red-400" />
          <h2 className="text-base font-bold text-slate-100">航运预警、气象限深与单证异常中心</h2>
        </div>
      </div>

      <div className="flex-1 p-5 overflow-y-auto space-y-3">
        {alerts.map((alert) => (
          <div
            key={alert.id}
            className={`p-4 rounded-xl border flex items-start justify-between gap-4 transition ${
              alert.resolved
                ? 'bg-slate-900/50 border-slate-800 opacity-60'
                : 'bg-slate-900 border-red-500/40 shadow-lg'
            }`}
          >
            <div className="space-y-1">
              <div className="flex items-center space-x-2">
                <span className="text-xs font-mono font-bold text-red-400 bg-red-950 px-2 py-0.5 rounded border border-red-800">
                  {alert.severity === 'danger' ? '严重异常' : '风控预警'}
                </span>
                <h3 className="text-xs font-bold text-slate-100">{alert.title}</h3>
              </div>
              <p className="text-xs text-slate-300">{alert.message}</p>
              <div className="text-[10px] text-slate-500 font-mono">
                触发时间: {new Date(alert.timestamp).toLocaleString('zh-CN')}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
