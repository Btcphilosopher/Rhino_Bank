/**
 * 中国内河现货航运交易平台 — 平台设置 (Settings Workspace)
 * JIANGHAI SPOT Settings Workspace
 */

import React from 'react';
import { useApp } from '../../context/AppContext';
import { Settings, Shield, Sliders } from 'lucide-react';

export const SettingsView: React.FC = () => {
  return (
    <div className="h-full flex flex-col bg-slate-950 text-slate-100 font-sans overflow-hidden">
      <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between shrink-0">
        <div className="flex items-center space-x-2">
          <Settings className="w-5 h-5 text-slate-400" />
          <h2 className="text-base font-bold text-slate-100">平台系统参数设置</h2>
        </div>
      </div>

      <div className="flex-1 p-5 overflow-y-auto space-y-4 text-xs">
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-3">
          <h3 className="font-bold text-slate-100">交易平台基本配置</h3>
          <p className="text-slate-400">目前平台运行于标准确凿模式 (Deterministic Prototype Engine Mode)。</p>
        </div>
      </div>
    </div>
  );
};
