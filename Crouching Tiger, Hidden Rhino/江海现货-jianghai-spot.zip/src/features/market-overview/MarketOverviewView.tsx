/**
 * 中国内河现货航运交易平台 — 市场总览 (Market Overview Workspace)
 * JIANGHAI SPOT Market Pulse & Spot Index Workspace
 */

import React from 'react';
import { useApp } from '../../context/AppContext';
import { 
  TrendingUp, 
  Package, 
  Ship, 
  GitMerge, 
  AlertTriangle, 
  ArrowUpRight, 
  ArrowDownRight, 
  Activity, 
  Anchor, 
  DollarSign, 
  Clock,
  Layers,
  Sparkles
} from 'lucide-react';

import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from 'recharts';

export const MarketOverviewView: React.FC = () => {
  const { 
    cargoListings, 
    vessels, 
    quotes, 
    matchCandidates, 
    orders, 
    alerts, 
    setActiveView, 
    setSelectedCargoId,
    setSelectedVesselId,
    simulation
  } = useApp();

  // 统计数据
  const totalCargoWeight = cargoListings.reduce((sum, c) => sum + c.weightTons, 0);
  const totalVesselDwt = vessels.reduce((sum, v) => sum + v.capacityTons, 0);
  const activeCargoCount = cargoListings.filter((c) => c.status === 'published' || c.status === 'bidding').length;
  const activeVesselCount = vessels.filter((v) => v.status === 'idle').length;
  const avgFreightRateRmb = Math.round(
    cargoListings.reduce((sum, c) => sum + c.askingPricePerTon, 0) / (cargoListings.length || 1)
  );

  // RMB/t 运价走势模拟图表数据
  const spotRateTrendData = [
    { date: '09-15', yangtze: 32.5, canal: 40.0, pearl: 44.0 },
    { date: '09-16', yangtze: 33.0, canal: 40.5, pearl: 44.2 },
    { date: '09-17', yangtze: 32.8, canal: 41.0, pearl: 45.0 },
    { date: '09-18', yangtze: 34.2, canal: 41.8, pearl: 45.5 },
    { date: '09-19', yangtze: 35.0, canal: 42.0, pearl: 45.2 },
    { date: '09-20', yangtze: 34.8, canal: 42.5, pearl: 46.0 },
    { date: '09-21', yangtze: 35.5, canal: 42.2, pearl: 45.8 },
    { date: '09-22', yangtze: 36.2, canal: 43.0, pearl: 46.5 }
  ];

  // 水运大动脉市场脉搏
  const REGIONAL_PULSE = [
    { name: '长江干线 (Yangtze Main Stream)', demand: '强劲', capacity: '充足', rate: '36.2 元/吨', change: '+2.1%', risk: '三峡船闸排队', riskColor: 'text-amber-400' },
    { name: '京杭运河 (Grand Canal)', demand: '稳健', capacity: '偏紧', rate: '43.0 元/吨', change: '+1.5%', risk: '施桥段正常', riskColor: 'text-emerald-400' },
    { name: '珠江水系 (Pearl River System)', demand: '旺盛', capacity: '平衡', rate: '46.5 元/吨', change: '+0.8%', risk: '长洲船闸拥堵', riskColor: 'text-amber-400' },
    { name: '西江航线 (Xijiang River)', demand: '稳定', capacity: '充沛', rate: '38.5 元/吨', change: '-0.4%', risk: '通航水深控制', riskColor: 'text-slate-400' },
    { name: '内河集装箱快航 (Container Line)', demand: '强劲', capacity: '紧俏', rate: '850 元/TEU', change: '+3.2%', risk: '驳运班期受限', riskColor: 'text-amber-400' }
  ];

  return (
    <div className="p-5 space-y-5 bg-slate-950 min-h-full font-sans text-slate-100 overflow-y-auto">
      {/* 顶部市场标语与模拟警示 */}
      <div className="p-4 bg-gradient-to-r from-slate-900 via-blue-950/40 to-slate-900 border border-slate-800 rounded-xl flex flex-wrap items-center justify-between gap-3 shadow-lg">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <h1 className="text-lg font-bold text-slate-100 font-serif">
              中国内河现货航运交易行情总览
            </h1>
            <span className="text-[10px] font-mono bg-cyan-950 text-cyan-400 border border-cyan-800 px-2 py-0.5 rounded">
              实时确凿引擎
            </span>
          </div>
          <p className="text-xs text-slate-400">
            涵盖长江干线、京杭运河、珠江水系现货货源挂牌、在途运力与即期运价成交指数
          </p>
        </div>

        <div className="flex items-center space-x-2 text-xs">
          <button
            onClick={() => setActiveView('create_cargo')}
            className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded-lg font-semibold flex items-center space-x-1 shadow-md transition"
          >
            <Package className="w-3.5 h-3.5" />
            <span>发布货源需求</span>
          </button>
          <button
            onClick={() => setActiveView('create_vessel')}
            className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-semibold flex items-center space-x-1 shadow-md transition"
          >
            <Ship className="w-3.5 h-3.5" />
            <span>挂牌空船运力</span>
          </button>
        </div>
      </div>

      {/* 核心市场四大 KPI 仪表盘 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-xl space-y-2 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>在线挂牌货源总量</span>
            <Package className="w-4 h-4 text-amber-400" />
          </div>
          <div className="flex items-baseline space-x-2">
            <span className="text-2xl font-extrabold font-mono text-slate-100">
              {totalCargoWeight.toLocaleString()}
            </span>
            <span className="text-xs text-slate-400">吨 ({activeCargoCount} 单)</span>
          </div>
          <div className="text-[11px] text-emerald-400 flex items-center space-x-1 font-mono">
            <ArrowUpRight className="w-3 h-3" />
            <span>今日新增货量 +12.5%</span>
          </div>
        </div>

        <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-xl space-y-2 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>空闲可交易船舶运力</span>
            <Ship className="w-4 h-4 text-blue-400" />
          </div>
          <div className="flex items-baseline space-x-2">
            <span className="text-2xl font-extrabold font-mono text-slate-100">
              {totalVesselDwt.toLocaleString()}
            </span>
            <span className="text-xs text-slate-400">载重吨 ({activeVesselCount} 艘)</span>
          </div>
          <div className="text-[11px] text-cyan-400 flex items-center space-x-1 font-mono">
            <Activity className="w-3 h-3" />
            <span>运力周转率 88.5%</span>
          </div>
        </div>

        <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-xl space-y-2 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>全网即期平均运价</span>
            <TrendingUp className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="flex items-baseline space-x-2">
            <span className="text-2xl font-extrabold font-mono text-slate-100">
              ¥{avgFreightRateRmb}
            </span>
            <span className="text-xs text-slate-400">/ 吨 (RMB)</span>
          </div>
          <div className="text-[11px] text-emerald-400 flex items-center space-x-1 font-mono">
            <ArrowUpRight className="w-3 h-3" />
            <span>周指数上浮 +2.8%</span>
          </div>
        </div>

        <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-xl space-y-2 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>今日撮合成交订单</span>
            <GitMerge className="w-4 h-4 text-purple-400" />
          </div>
          <div className="flex items-baseline space-x-2">
            <span className="text-2xl font-extrabold font-mono text-slate-100">
              {matchCandidates.length + orders.length}
            </span>
            <span className="text-xs text-slate-400">笔撮合单</span>
          </div>
          <div className="text-[11px] text-purple-400 font-mono">
            系统算法匹配度 94.2%
          </div>
        </div>
      </div>

      {/* 运价指数图表与市场脉搏双栏 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* 长江与运河现货运价走势图 */}
        <div className="lg:col-span-2 p-4 bg-slate-900/80 border border-slate-800 rounded-xl space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <TrendingUp className="w-4 h-4 text-cyan-400" />
              <h3 className="text-xs font-bold text-slate-100">内河主要干线现货运价走势 (RMB/吨)</h3>
            </div>
            <span className="text-[10px] text-slate-500 font-mono">近 7 日即期均价</span>
          </div>

          <div className="h-60 w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={spotRateTrendData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="yangtzeFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#38bdf8" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#38bdf8" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="canalFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2dd4bf" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#2dd4bf" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="date" stroke="#64748b" fontSize={10} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={10} tickLine={false} domain={['dataMin - 5', 'dataMax + 5']} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '11px' }}
                />
                <Area type="monotone" dataKey="yangtze" name="长江干线" stroke="#38bdf8" strokeWidth={2} fillOpacity={1} fill="url(#yangtzeFill)" />
                <Area type="monotone" dataKey="canal" name="京杭运河" stroke="#2dd4bf" strokeWidth={2} fillOpacity={1} fill="url(#canalFill)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* 市场脉搏 (Market Pulse) */}
        <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-xl space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div className="flex items-center space-x-2">
              <Activity className="w-4 h-4 text-amber-400" />
              <h3 className="text-xs font-bold text-slate-100">水系区域市场脉搏 (Market Pulse)</h3>
            </div>
          </div>

          <div className="space-y-2.5 text-xs">
            {REGIONAL_PULSE.map((item, i) => (
              <div key={i} className="p-2.5 bg-slate-950 border border-slate-800/80 rounded-lg space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-200">{item.name}</span>
                  <span className="font-mono text-cyan-300 font-bold">{item.rate}</span>
                </div>
                <div className="flex items-center justify-between text-[11px] text-slate-400">
                  <span>需求: <strong className="text-slate-300">{item.demand}</strong> | 运力: <strong className="text-slate-300">{item.capacity}</strong></span>
                  <span className={item.riskColor}>{item.risk}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 待撮合货源与最新询价报价动态 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* 待匹配货源单 */}
        <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-xl space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-100 flex items-center space-x-2">
              <Package className="w-4 h-4 text-amber-400" />
              <span>最新即期挂牌货源需求</span>
            </h3>
            <button
              onClick={() => setActiveView('cargo_market')}
              className="text-xs text-cyan-400 hover:underline"
            >
              进入货源大厅 →
            </button>
          </div>

          <div className="space-y-2 text-xs">
            {cargoListings.slice(0, 3).map((cargo) => (
              <div
                key={cargo.id}
                onClick={() => {
                  setSelectedCargoId(cargo.id);
                  setActiveView('cargo_market');
                }}
                className="p-3 bg-slate-950 hover:bg-slate-800/80 border border-slate-800/80 rounded-lg transition cursor-pointer flex items-center justify-between"
              >
                <div className="space-y-1">
                  <div className="font-bold text-slate-200">{cargo.title}</div>
                  <div className="text-[11px] text-slate-400">
                    起止: {cargo.originPortName} ➔ {cargo.destinationPortName} | 限制吃水: {cargo.maxDraftMeters}米
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-mono text-amber-400 font-bold text-sm">
                    ¥{cargo.askingPricePerTon}/吨
                  </div>
                  <span className="text-[10px] text-slate-500">{cargo.categoryName}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 智能撮合算法推荐 */}
        <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-xl space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-100 flex items-center space-x-2">
              <GitMerge className="w-4 h-4 text-emerald-400" />
              <span>智能撮合引擎优质推荐 (Best Match Candidates)</span>
            </h3>
            <button
              onClick={() => setActiveView('matching_engine')}
              className="text-xs text-emerald-400 hover:underline"
            >
              全网撮合大厅 →
            </button>
          </div>

          <div className="space-y-2 text-xs">
            {matchCandidates.slice(0, 3).map((candidate) => (
              <div
                key={candidate.id}
                className="p-3 bg-slate-950 border border-slate-800/80 rounded-lg flex items-center justify-between"
              >
                <div className="space-y-1 max-w-sm">
                  <div className="font-bold text-slate-200 truncate">
                    {candidate.cargo.title}
                  </div>
                  <div className="text-[11px] text-slate-400">
                    推荐船只: <span className="text-cyan-300 font-medium">{candidate.vessel.name}</span> ({candidate.vessel.capacityTons}吨)
                  </div>
                </div>

                <div className="text-right space-y-1">
                  <div className="text-xs font-mono font-bold text-emerald-400 bg-emerald-950/80 border border-emerald-800/60 px-2 py-0.5 rounded">
                    匹配度 {candidate.scores.overallScore}%
                  </div>
                  <div className="text-[10px] text-slate-400">
                    预估运价: ¥{candidate.suggestedFreightRmbPerTon}/吨
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
