/**
 * 中国内河现货航运交易平台 — 智能撮合工作台 (Matching Engine Workspace)
 * JIANGHAI SPOT Smart Matching Engine
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { MatchCandidate } from '../../types';
import { 
  GitMerge, 
  CheckCircle2, 
  Package, 
  Ship, 
  MapPin, 
  ArrowRight, 
  SlidersHorizontal, 
  ShieldCheck, 
  Scale, 
  Sparkles,
  Info
} from 'lucide-react';

export const MatchingView: React.FC = () => {
  const { matchCandidates, createOrderFromMatch, setActiveView } = useApp();

  const [minScoreFilter, setMinScoreFilter] = useState<number>(75);

  const filteredCandidates = matchCandidates.filter((c) => c.scores.overallScore >= minScoreFilter);

  return (
    <div className="h-full flex flex-col bg-slate-950 text-slate-100 font-sans overflow-hidden">
      {/* 顶部标语与门槛筛选 */}
      <div className="p-4 bg-slate-900 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 shrink-0">
        <div className="flex items-center space-x-2">
          <GitMerge className="w-5 h-5 text-emerald-400" />
          <h2 className="text-base font-bold text-slate-100">算法智能撮合与运力匹配引擎</h2>
          <span className="text-[10px] font-mono bg-emerald-950 text-emerald-400 border border-emerald-800 px-2 py-0.5 rounded">
            确定性加权配载算法
          </span>
        </div>

        <div className="flex items-center space-x-3 text-xs">
          <span className="text-slate-400">最小匹配度门槛:</span>
          <div className="flex items-center space-x-2 bg-slate-950 px-3 py-1 rounded border border-slate-700">
            <input
              type="range"
              min="60"
              max="95"
              value={minScoreFilter}
              onChange={(e) => setMinScoreFilter(Number(e.target.value))}
              className="w-24 accent-emerald-500 cursor-pointer"
            />
            <span className="font-mono text-emerald-400 font-bold">{minScoreFilter}%</span>
          </div>
        </div>
      </div>

      {/* 撮合结果列表 */}
      <div className="flex-1 p-5 overflow-y-auto space-y-4">
        <p className="text-xs text-slate-400">
          根据长江航道枯水限深、船闸排队预估、船舶载重适配、航程运费性价比及企业存证信用算得的自动配载建议：
        </p>

        <div className="space-y-4">
          {filteredCandidates.map((candidate) => {
            const { scores, cargo, vessel } = candidate;

            return (
              <div
                key={candidate.id}
                className="p-5 bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl space-y-4 shadow-xl transition"
              >
                {/* 核心匹配卡片 Header */}
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-3 border-b border-slate-800">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 rounded-xl bg-emerald-950 border border-emerald-500/40 flex items-center justify-center font-mono text-emerald-400 font-extrabold text-base shadow-inner">
                      {scores.overallScore}%
                    </div>
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="text-xs font-bold text-slate-100">{cargo.title}</span>
                        <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
                          {cargo.categoryName} ({cargo.weightTons}吨)
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 mt-0.5">
                        推荐配载船舶: <strong className="text-cyan-300">{vessel.name}</strong> (MMSI: {vessel.mmsi} | {vessel.capacityTons}吨)
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-4">
                    <div className="text-right font-mono">
                      <span className="text-[10px] text-slate-400 block">建议成交运价</span>
                      <span className="text-lg font-extrabold text-amber-400">
                        ¥{candidate.suggestedFreightRmbPerTon}
                      </span>
                      <span className="text-xs text-slate-400"> / 吨</span>
                    </div>

                    <button
                      onClick={() => createOrderFromMatch(candidate.id)}
                      className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-xs flex items-center space-x-1.5 shadow-lg transition transform active:scale-95"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>确认撮合生成订单 (Generate Order)</span>
                    </button>
                  </div>
                </div>

                {/* 6 维度评分细分 (6-Dimensional Score Breakdown) */}
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 text-xs">
                  <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800 space-y-1">
                    <span className="text-slate-400 text-[10px] block">航线适航分</span>
                    <div className="flex items-baseline justify-between font-mono">
                      <span className="text-sm font-bold text-slate-200">{scores.routeMatchPercent}%</span>
                      <span className="text-[10px] text-emerald-400">完美顺航</span>
                    </div>
                  </div>

                  <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800 space-y-1">
                    <span className="text-slate-400 text-[10px] block">载重匹配率</span>
                    <div className="flex items-baseline justify-between font-mono">
                      <span className="text-sm font-bold text-slate-200">{scores.capacityMatchPercent}%</span>
                      <span className="text-[10px] text-cyan-400">利用率 92%</span>
                    </div>
                  </div>

                  <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800 space-y-1">
                    <span className="text-slate-400 text-[10px] block">装期时间窗口</span>
                    <div className="flex items-baseline justify-between font-mono">
                      <span className="text-sm font-bold text-slate-200">{scores.timeMatchPercent}%</span>
                      <span className="text-[10px] text-emerald-400">无缝衔接</span>
                    </div>
                  </div>

                  <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800 space-y-1">
                    <span className="text-slate-400 text-[10px] block">运价契合度</span>
                    <div className="flex items-baseline justify-between font-mono">
                      <span className="text-sm font-bold text-slate-200">{scores.priceMatchPercent}%</span>
                      <span className="text-[10px] text-amber-400">贴合均价</span>
                    </div>
                  </div>

                  <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800 space-y-1">
                    <span className="text-slate-400 text-[10px] block">存证资质合规</span>
                    <div className="flex items-baseline justify-between font-mono">
                      <span className="text-sm font-bold text-slate-200">{scores.documentCompletenessPercent}%</span>
                      <span className="text-[10px] text-emerald-400">五星认证</span>
                    </div>
                  </div>

                  <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800 space-y-1">
                    <span className="text-slate-400 text-[10px] block">吃水通航可行性</span>
                    <div className="flex items-baseline justify-between font-mono">
                      <span className="text-sm font-bold text-slate-200">{scores.fairwayFeasibilityPercent}%</span>
                      <span className="text-[10px] text-emerald-400">富余 0.6m</span>
                    </div>
                  </div>
                </div>

                {/* 算法推荐判定分析 */}
                <div className="p-2.5 bg-slate-950/60 border border-slate-800 rounded-lg text-[11px] text-slate-400 flex items-center justify-between">
                  <span>
                    系统分析结论: 船舶 <strong className="text-slate-200">{vessel.name}</strong> 预计可在装货窗口期内抵达 <strong className="text-slate-200">{cargo.originPortName}</strong>，满载吃水满足当前长江水文公告。
                  </span>
                  <span className="font-mono text-emerald-400">无挂牌违约风险</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
