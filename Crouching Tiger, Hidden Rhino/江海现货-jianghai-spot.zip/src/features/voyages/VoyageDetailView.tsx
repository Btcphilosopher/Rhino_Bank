/**
 * 中国内河现货航运交易平台 — 航次监控 (Voyage Tracking Workspace)
 * JIANGHAI SPOT Live Voyage Tracking & Telemetry
 */

import React from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Navigation, 
  Ship, 
  MapPin, 
  Clock, 
  Radio, 
  AlertTriangle, 
  Fuel, 
  Gauge, 
  FileText, 
  CheckCircle2, 
  ArrowRight,
  ShieldCheck
} from 'lucide-react';

export const VoyageDetailView: React.FC = () => {
  const { orders, selectedOrderId, setSelectedOrderId } = useApp();

  const activeOrder = orders.find((o) => o.id === selectedOrderId) || orders[0];

  if (!activeOrder) {
    return <div className="p-10 text-slate-400 text-xs text-center">暂无在途航次</div>;
  }

  return (
    <div className="h-full flex flex-col bg-slate-950 text-slate-100 font-sans overflow-hidden">
      {/* 顶部标题栏 */}
      <div className="p-4 bg-slate-900 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 shrink-0">
        <div className="flex items-center space-x-3">
          <Navigation className="w-5 h-5 text-cyan-400" />
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-base font-bold text-slate-100">航次实时追踪与电子航海日志</h2>
              <span className="text-[10px] font-mono bg-cyan-950 text-cyan-400 border border-cyan-800 px-2 py-0.5 rounded">
                AIS 信号点定速报
              </span>
            </div>
            <p className="text-xs text-slate-400">
              单号: #{activeOrder.orderNo} | 承运船只: <strong className="text-slate-200">{activeOrder.vesselName}</strong>
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2 text-xs font-mono">
          <span className="text-slate-400">选择监控订单:</span>
          <select
            value={activeOrder.id}
            onChange={(e) => setSelectedOrderId(e.target.value)}
            className="bg-slate-950 text-slate-200 text-xs rounded border border-slate-700 p-1.5 focus:border-cyan-500"
          >
            {orders.map((o) => (
              <option key={o.id} value={o.id}>
                #{o.orderNo} - {o.vesselName} ({o.cargoTitle.slice(0, 10)}...)
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* 主体 */}
      <div className="flex-1 p-5 overflow-y-auto space-y-5">
        {/* 航迹进度条 Card */}
        <div className="p-5 bg-slate-900 border border-slate-800 rounded-xl space-y-4 shadow-xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2 text-xs">
              <MapPin className="w-4 h-4 text-cyan-400" />
              <span className="font-bold text-slate-200">{activeOrder.originPortName}</span>
              <ArrowRight className="w-4 h-4 text-slate-500" />
              <span className="font-bold text-slate-200">{activeOrder.destinationPortName}</span>
            </div>

            <span className="text-xs font-mono font-bold text-cyan-400 bg-cyan-950 px-2.5 py-1 rounded border border-cyan-800">
              航程完成度: {activeOrder.progressPercent}%
            </span>
          </div>

          {/* 进度条 Visual */}
          <div className="space-y-1.5 font-mono text-[11px]">
            <div className="w-full h-3 bg-slate-950 rounded-full border border-slate-800 overflow-hidden relative">
              <div
                className="h-full bg-gradient-to-r from-blue-600 via-cyan-500 to-emerald-400 rounded-full transition-all duration-700 relative"
                style={{ width: `${activeOrder.progressPercent}%` }}
              >
                <div className="absolute right-0 top-0 bottom-0 w-2 bg-white animate-ping" />
              </div>
            </div>

            <div className="flex justify-between text-slate-400">
              <span>起运: {activeOrder.originPortName} (起航)</span>
              <span>中间过闸: 三峡五级船闸 (通过)</span>
              <span>目的港: {activeOrder.destinationPortName} (预计明日到港)</span>
            </div>
          </div>
        </div>

        {/* 遥测与船端仪表 (Telemetry & Bridge Telemetry) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-xl space-y-1">
            <div className="flex items-center justify-between text-slate-400 text-xs">
              <span>AIS 实时对地航速</span>
              <Gauge className="w-4 h-4 text-cyan-400" />
            </div>
            <div className="text-2xl font-extrabold font-mono text-cyan-300">
              9.6 <span className="text-xs font-normal text-slate-400">节 (Knots)</span>
            </div>
            <p className="text-[10px] text-slate-500">顺水顺风航行</p>
          </div>

          <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-xl space-y-1">
            <div className="flex items-center justify-between text-slate-400 text-xs">
              <span>预估剩余到港耗时</span>
              <Clock className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-2xl font-extrabold font-mono text-emerald-400">
              18.5 <span className="text-xs font-normal text-slate-400">小时</span>
            </div>
            <p className="text-[10px] text-emerald-400 font-mono">准点率高</p>
          </div>

          <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-xl space-y-1">
            <div className="flex items-center justify-between text-slate-400 text-xs">
              <span>船用柴油实时耗量</span>
              <Fuel className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-2xl font-extrabold font-mono text-amber-300">
              2.1 <span className="text-xs font-normal text-slate-400">吨 / 24h</span>
            </div>
            <p className="text-[10px] text-slate-500">基准油运比正常</p>
          </div>

          <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-xl space-y-1">
            <div className="flex items-center justify-between text-slate-400 text-xs">
              <span>水文与过闸预警</span>
              <AlertTriangle className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-base font-extrabold font-mono text-slate-200">
              三峡船闸排队通畅
            </div>
            <p className="text-[10px] text-amber-400">预计等待 1.5 小时</p>
          </div>
        </div>

        {/* 电子航运日志 (Electronic Voyage Logbook) */}
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <h3 className="text-xs font-bold text-slate-100 flex items-center space-x-2">
              <FileText className="w-4 h-4 text-cyan-400" />
              <span>区块链存证电子航海日志 (Electronic Voyage Logbook)</span>
            </h3>
            <span className="text-[10px] font-mono text-emerald-400">Hash: 0x7f...82e9</span>
          </div>

          <div className="space-y-2 text-xs font-mono">
            {[
              { time: '2026-09-22 08:30', event: '通过葛洲坝闸室，闸首核验吨位无误，已入长江主干航道。' },
              { time: '2026-09-21 16:00', event: '在宜昌港龙泉码头完成 3,500 吨水泥抓斗快速装船，水尺公重测定完成。' },
              { time: '2026-09-21 10:15', event: '货主与船东双方完成电子水路运单联合盖章。' }
            ].map((log, i) => (
              <div key={i} className="p-2.5 bg-slate-950 border border-slate-800 rounded-lg flex items-start space-x-3">
                <span className="text-cyan-400 text-[11px] shrink-0">{log.time}</span>
                <span className="text-slate-300 text-[11px]">{log.event}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
