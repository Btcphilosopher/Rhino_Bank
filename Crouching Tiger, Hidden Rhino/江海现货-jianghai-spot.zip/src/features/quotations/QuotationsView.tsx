/**
 * 中国内河现货航运交易平台 — 现货报价与竞价大厅 (Spot Quotation Workspace)
 * JIANGHAI SPOT Bidding, RFQs & Offer Matrix
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { FreightQuote } from '../../types';
import { 
  TrendingUp, 
  DollarSign, 
  CheckCircle2, 
  Clock, 
  Send, 
  ArrowRight, 
  Scale, 
  ShieldCheck, 
  FileCheck,
  Building,
  Sparkles
} from 'lucide-react';

export const QuotationsView: React.FC = () => {
  const { quotes, cargoListings, vessels, acceptQuote, submitQuote, addToast } = useApp();

  const [activeTab, setActiveTab] = useState<'firm' | 'reverse_auction' | 'my_quotes'>('firm');
  const [quoteFreightPrice, setQuoteFreightPrice] = useState<number>(36);
  const [selectedCargoIdForQuote, setSelectedCargoIdForQuote] = useState<string>(cargoListings[0]?.id || '');
  const [selectedVesselIdForQuote, setSelectedVesselIdForQuote] = useState<string>(vessels[0]?.id || '');

  // 投标提交
  const handleCreateQuote = (e: React.FormEvent) => {
    e.preventDefault();
    const cargo = cargoListings.find((c) => c.id === selectedCargoIdForQuote);
    const vessel = vessels.find((v) => v.id === selectedVesselIdForQuote);

    if (!cargo || !vessel) return;

    submitQuote({
      cargoId: cargo.id,
      cargoTitle: cargo.title,
      vesselId: vessel.id,
      vesselName: vessel.name,
      carrierOrgId: vessel.operatorOrgId,
      carrierOrgName: vessel.operatorOrgName,
      shipperOrgId: cargo.ownerOrgId,
      shipperOrgName: cargo.ownerOrgName,
      originPortName: cargo.originPortName,
      destinationPortName: cargo.destinationPortName,
      quantityTons: cargo.weightTons,
      freightBasis: 'per_ton',
      unitPriceRmb: Number(quoteFreightPrice),
      baseFreightRmb: Number(quoteFreightPrice) * cargo.weightTons,
      fuelSurchargeRmb: 2000,
      lockFeeRmb: 1200,
      portFeeRmb: 800,
      loadingFeeRmb: 1000,
      unloadingFeeRmb: 1000,
      insuranceCostRmb: 500,
      taxRmb: Math.round(Number(quoteFreightPrice) * cargo.weightTons * 0.09),
      totalEstimatedFreightRmb: Number(quoteFreightPrice) * cargo.weightTons + 6500,
      validityExpiry: new Date(Date.now() + 86400000 * 3).toISOString(),
      estimatedTransitDays: 3.5,
      demurrageRatePerDayRmb: 2500,
      paymentTerms: '托管结算（按阶段放款）'
    });

    addToast({
      type: 'success',
      title: '运费报价已提交',
      message: `已向 [${cargo.title}] 提交 ¥${quoteFreightPrice}/吨 的船东报价`
    });
  };

  return (
    <div className="h-full flex flex-col bg-slate-950 text-slate-100 font-sans overflow-hidden">
      {/* 顶部标签 */}
      <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between shrink-0">
        <div className="flex items-center space-x-2">
          <TrendingUp className="w-5 h-5 text-amber-400" />
          <h2 className="text-base font-bold text-slate-100">现货运费报价与反向竞价大厅</h2>
        </div>

        <div className="flex bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
          <button
            onClick={() => setActiveTab('firm')}
            className={`px-3 py-1.5 rounded-md font-medium transition ${
              activeTab === 'firm' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            现货定额报价列表 ({quotes.length})
          </button>
          <button
            onClick={() => setActiveTab('reverse_auction')}
            className={`px-3 py-1.5 rounded-md font-medium transition ${
              activeTab === 'reverse_auction' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            货主公开反向竞价 (Reverse Auction)
          </button>
        </div>
      </div>

      {/* 主体 */}
      <div className="flex-1 flex overflow-hidden">
        {/* 左侧报价单卡片列 */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3">
          <div className="text-xs font-mono text-slate-400 flex justify-between">
            <span>在线处理中的竞价报价项 ({quotes.length} 笔)</span>
            <span>包含买卖双向撮合盘口</span>
          </div>

          <div className="space-y-3">
            {quotes.map((quote) => {
              const isAccepted = quote.status === 'accepted';
              return (
                <div
                  key={quote.id}
                  className={`p-4 rounded-xl border transition flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                    isAccepted
                      ? 'bg-emerald-950/20 border-emerald-500/40'
                      : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="space-y-1.5">
                    <div className="flex items-center space-x-2">
                      <span className="text-xs font-mono font-bold text-amber-400 bg-amber-950 px-2 py-0.5 rounded border border-amber-800">
                        船东响应报盘
                      </span>
                      <h3 className="text-sm font-bold text-slate-100">{quote.cargoTitle}</h3>
                    </div>

                    <div className="text-xs text-slate-400 flex items-center space-x-3 font-sans">
                      <span>报价承运船: <strong className="text-cyan-300 font-mono">{quote.vesselName}</strong></span>
                      <span className="text-slate-600">|</span>
                      <span>企业: {quote.carrierOrgName}</span>
                    </div>

                    <div className="text-[11px] text-slate-500 flex items-center space-x-2 font-mono">
                      <Clock className="w-3 h-3" />
                      <span>有效期至: {new Date(quote.validityExpiry).toLocaleDateString('zh-CN')}</span>
                      <span>• 预估航程: {quote.estimatedTransitDays} 天</span>
                    </div>
                  </div>

                  <div className="flex items-center space-x-4 shrink-0">
                    <div className="text-right">
                      <div className="text-xs text-slate-400">单价报盘</div>
                      <div className="text-lg font-extrabold font-mono text-amber-400">
                        ¥{quote.unitPriceRmb} <span className="text-xs font-normal text-slate-400">/ 吨</span>
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono">
                        总运费: ¥{quote.totalEstimatedFreightRmb.toLocaleString()}
                      </div>
                    </div>

                    <div>
                      {isAccepted ? (
                        <div className="px-3 py-1.5 bg-emerald-950 text-emerald-400 border border-emerald-800 rounded-lg text-xs font-bold flex items-center space-x-1">
                          <CheckCircle2 className="w-4 h-4" />
                          <span>已被采纳并成单</span>
                        </div>
                      ) : (
                        <button
                          onClick={() => acceptQuote(quote.id)}
                          className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg text-xs shadow-md transition transform active:scale-95"
                        >
                          确认采纳此报价 (Accept)
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* 右侧：快速提交报价控制台 */}
        <div className="w-80 bg-slate-900 border-l border-slate-800 p-4 flex flex-col justify-between shrink-0 font-sans text-xs">
          <form onSubmit={handleCreateQuote} className="space-y-4">
            <div className="flex items-center space-x-2 pb-2 border-b border-slate-800">
              <Send className="w-4 h-4 text-cyan-400" />
              <h3 className="font-bold text-slate-100">在线提交船东运费报价单</h3>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">选择目标挂牌货源:</label>
              <select
                value={selectedCargoIdForQuote}
                onChange={(e) => setSelectedCargoIdForQuote(e.target.value)}
                className="w-full bg-slate-950 text-slate-200 rounded p-2 border border-slate-700"
              >
                {cargoListings.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.title} (意向: ¥{c.askingPricePerTon}/吨)
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">派承运运力船舶:</label>
              <select
                value={selectedVesselIdForQuote}
                onChange={(e) => setSelectedVesselIdForQuote(e.target.value)}
                className="w-full bg-slate-950 text-slate-200 rounded p-2 border border-slate-700"
              >
                {vessels.map((v) => (
                  <option key={v.id} value={v.id}>
                    {v.name} ({v.capacityTons}吨)
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">我的运费报盘单价 (RMB/吨):</label>
              <input
                type="number"
                value={quoteFreightPrice}
                onChange={(e) => setQuoteFreightPrice(Number(e.target.value))}
                className="w-full bg-slate-950 font-mono text-amber-400 font-bold text-sm rounded p-2 border border-slate-700"
              />
            </div>

            <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg space-y-1 text-[11px] text-slate-400">
              <p>• 滞期费约定: 2,000 元/天</p>
              <p>• 报价有效期: 3 天</p>
              <p>• 平台保证金规则: 预冻结 2% 履约金</p>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg shadow-md transition"
            >
              发送竞价报盘 →
            </button>
          </form>

          <div className="pt-3 border-t border-slate-800 text-[10px] text-slate-500 font-mono">
            江海现货交易大厅报价协议规范 v3.6
          </div>
        </div>
      </div>
    </div>
  );
};
