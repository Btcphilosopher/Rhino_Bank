/**
 * 中国内河现货航运交易平台 — 航运大牌分析 (Market Analytics Workspace)
 * JIANGHAI SPOT Shipping Market Analytics
 */

import React from 'react';
import { useApp } from '../../context/AppContext';
import { BarChart3, TrendingUp, PieChart, Activity } from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart as RePieChart,
  Pie,
  Cell
} from 'recharts';

export const AnalyticsView: React.FC = () => {
  const { cargoListings, vessels } = useApp();

  const lockQueueData = [
    { name: '三峡五级船闸', waitHours: 32, shipsWaiting: 42 },
    { name: '葛洲坝船闸', waitHours: 12, shipsWaiting: 15 },
    { name: '施桥船闸', waitHours: 8, shipsWaiting: 18 },
    { name: '高邮船闸', waitHours: 6, shipsWaiting: 10 },
    { name: '桂平枢纽', waitHours: 24, shipsWaiting: 29 }
  ];

  const categoryShareData = [
    { name: '煤炭/电煤', value: 38, color: '#f59e0b' },
    { name: '水泥/熟料', value: 25, color: '#38bdf8' },
    { name: '钢材/卷板', value: 18, color: '#2dd4bf' },
    { name: '砂石建材', value: 12, color: '#a855f7' },
    { name: '集装箱(TEU)', value: 7, color: '#ec4899' }
  ];

  return (
    <div className="h-full flex flex-col bg-slate-950 text-slate-100 font-sans overflow-hidden">
      <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between shrink-0">
        <div className="flex items-center space-x-2">
          <BarChart3 className="w-5 h-5 text-cyan-400" />
          <h2 className="text-base font-bold text-slate-100">中国内河现货水运大数据 analysis 与通航指数</h2>
        </div>
      </div>

      <div className="flex-1 p-5 overflow-y-auto space-y-5">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {/* 船闸排队耗时 BarChart */}
          <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-3">
            <h3 className="text-xs font-bold text-slate-100">主要船闸过闸排队耗时 (小时)</h3>
            <div className="h-64 w-full pt-2">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={lockQueueData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                  <XAxis dataKey="name" stroke="#64748b" fontSize={10} tickLine={false} />
                  <YAxis stroke="#64748b" fontSize={10} tickLine={false} />
                  <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '11px' }} />
                  <Bar dataKey="waitHours" name="平均排队(小时)" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* 货种分布 PieChart */}
          <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-3">
            <h3 className="text-xs font-bold text-slate-100">全网挂牌货种吨位占比</h3>
            <div className="h-64 w-full flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <RePieChart>
                  <Pie
                    data={categoryShareData}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${percent ? (percent * 100).toFixed(0) : 0}%`}
                  >
                    {categoryShareData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '11px' }} />
                </RePieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
