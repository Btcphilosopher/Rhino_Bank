/**
 * 中国内河现货航运交易平台 — 智能撮合引擎 (Matching Engine)
 * JIANGHAI SPOT Deterministic Matching Algorithm
 */

import { CargoListing, Vessel, MatchCandidate, MatchScoreBreakdown } from '../types';

export function calculateMatchScore(cargo: CargoListing, vessel: Vessel): MatchScoreBreakdown {
  const explanation: string[] = [];

  // 1. 路线与航道可行性 (Route & Fairway)
  let routeMatchPercent = 100;
  if (vessel.maxDraftMeters > cargo.maxDraftMeters) {
    routeMatchPercent -= 30;
    explanation.push(`⚠️ 船舶最大吃水 (${vessel.maxDraftMeters}m) 超过货源限定吃水 (${cargo.maxDraftMeters}m)`);
  } else {
    explanation.push(`✅ 航道与吃水匹配完美 (船吃水 ${vessel.maxDraftMeters}m ≤ 限深 ${cargo.maxDraftMeters}m)`);
  }

  // 2. 运力与货种匹配 (Capacity & Cargo Category)
  let capacityMatchPercent = 100;
  if (cargo.containerTeu && cargo.containerTeu > 0) {
    if (!vessel.capacityTeu || vessel.capacityTeu < cargo.containerTeu) {
      capacityMatchPercent = 0;
      explanation.push(`❌ 船舶集装箱运力不足 (${vessel.capacityTeu || 0} TEU < 需求 ${cargo.containerTeu} TEU)`);
    } else {
      explanation.push(`✅ 集装箱箱位匹配 (${vessel.capacityTeu} TEU 适装 ${cargo.containerTeu} TEU)`);
    }
  } else {
    if (vessel.capacityTons < cargo.weightTons) {
      capacityMatchPercent = 0;
      explanation.push(`❌ 载重吨不足 (船舶额定载重 ${vessel.capacityTons}吨 < 货物量 ${cargo.weightTons}吨)`);
    } else {
      const loadFactor = Math.round((cargo.weightTons / vessel.capacityTons) * 100);
      explanation.push(`✅ 舱容配载率良好 (${loadFactor}%, 货重 ${cargo.weightTons}吨 / 舱载 ${vessel.capacityTons}吨)`);
    }
  }

  // 货种特殊要求
  if (cargo.category === 'cement' && !vessel.hasPumpingSystem && vessel.category !== 'self_propelled') {
    capacityMatchPercent -= 40;
    explanation.push(`⚠️ 散装水泥要求自卸打粉设备，该船无泵送气力设备`);
  }

  // 3. 时间匹配 (Time Window)
  let timeMatchPercent = 90;
  const availDate = new Date(vessel.nextAvailableDate).getTime();
  const windowStart = new Date(cargo.loadingWindowStart).getTime();
  const windowEnd = new Date(cargo.loadingWindowEnd).getTime();

  if (availDate <= windowStart) {
    timeMatchPercent = 100;
    explanation.push(`✅ 船舶空放到位时间早于受载期起点`);
  } else if (availDate <= windowEnd) {
    timeMatchPercent = 80;
    explanation.push(`⚠️ 船舶空放到位时间接近受载期截止时间`);
  } else {
    timeMatchPercent = 20;
    explanation.push(`❌ 船舶空运到位时间迟于货主受载期窗口`);
  }

  // 4. 价格匹配 (Price Fit)
  let priceMatchPercent = 85;
  const totalCargoEst = cargo.totalAskingFreight;
  if (totalCargoEst >= vessel.minVoyageRateRmb) {
    priceMatchPercent = 95;
    explanation.push(`✅ 货主预期运费 (¥${totalCargoEst.toLocaleString()}) 高于船舶最低起航运费 (¥${vessel.minVoyageRateRmb.toLocaleString()})`);
  } else {
    priceMatchPercent = 60;
    explanation.push(`⚠️ 货主预期运费偏低，需线下进一步商务协商`);
  }

  // 5. 证件与合规 (Document Completeness)
  let documentCompletenessPercent = 100;
  if (vessel.safetyCertStatus !== 'verified') {
    documentCompletenessPercent = 50;
    explanation.push(`⚠️ 船舶适航安检凭证处于审核中状态`);
  } else {
    explanation.push(`✅ 船舶适航证件与保险全额有效 (已认证)`);
  }

  // 6. 航道可行性 (Fairway Feasibility)
  const fairwayFeasibilityPercent = routeMatchPercent > 50 ? 95 : 40;

  // 综合加权计算
  const overallScore = Math.round(
    routeMatchPercent * 0.2 +
    capacityMatchPercent * 0.3 +
    timeMatchPercent * 0.2 +
    priceMatchPercent * 0.15 +
    documentCompletenessPercent * 0.15
  );

  return {
    routeMatchPercent,
    capacityMatchPercent,
    timeMatchPercent,
    priceMatchPercent,
    documentCompletenessPercent,
    fairwayFeasibilityPercent,
    overallScore,
    explanation
  };
}

export function generateMatchCandidates(
  cargoes: CargoListing[],
  vessels: Vessel[]
): MatchCandidate[] {
  const candidates: MatchCandidate[] = [];

  for (const cargo of cargoes) {
    if (cargo.status === 'completed' || cargo.status === 'cancelled') continue;

    for (const vessel of vessels) {
      if (vessel.status === 'unavailable' || vessel.status === 'maintenance') continue;

      const scores = calculateMatchScore(cargo, vessel);
      if (scores.overallScore >= 50 && scores.capacityMatchPercent > 0) {
        const estPrice = Math.round(cargo.askingPricePerTon * 0.98);
        candidates.push({
          id: `match-${cargo.id}-${vessel.id}`,
          cargoId: cargo.id,
          cargo,
          vesselId: vessel.id,
          vessel,
          carrierOrgName: vessel.operatorOrgName,
          scores,
          suggestedFreightRmbPerTon: estPrice,
          status: cargo.status === 'matched' ? 'both_confirmed' : 'candidate',
          createdAt: new Date().toISOString()
        });
      }
    }
  }

  return candidates.sort((a, b) => b.scores.overallScore - a.scores.overallScore);
}
