/**
 * 中国内河现货航运交易平台 — 主应用入口 (Main Application)
 * JIANGHAI SPOT Main Desktop Workspace Layout
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/layout/Header';
import { LeftNav } from './components/layout/LeftNav';
import { BottomStatusBar } from './components/layout/BottomStatusBar';
import { CommandBarModal } from './components/layout/CommandBarModal';
import { ScenarioRunnerModal } from './components/layout/ScenarioRunnerModal';
import { DataProvenanceModal } from './components/layout/DataProvenanceModal';
import { ToastContainer } from './components/common/ToastContainer';

// Feature Workspace Views
import { MarketOverviewView } from './features/market-overview/MarketOverviewView';
import { CargoMarketView } from './features/cargo-market/CargoMarketView';
import { VesselMarketView } from './features/vessel-market/VesselMarketView';
import { QuotationsView } from './features/quotations/QuotationsView';
import { MatchingView } from './features/matching/MatchingView';
import { WaterwayMap } from './components/maps/WaterwayMap';
import { PortsView } from './features/ports/PortsView';
import { OrdersView } from './features/orders/OrdersView';
import { VoyageDetailView } from './features/voyages/VoyageDetailView';
import { SettlementView } from './features/settlement/SettlementView';
import { DocumentCentreView } from './features/documents/DocumentCentreView';
import { AnalyticsView } from './features/analytics/AnalyticsView';
import { OperationsControlView } from './features/operations/OperationsControlView';
import { AlertsView } from './features/alerts/AlertsView';
import { OrganizationView } from './features/organization/OrganizationView';
import { SettingsView } from './features/settings/SettingsView';
import { SimulationConsoleView } from './features/simulation/SimulationConsoleView';

const WorkspaceRouter: React.FC = () => {
  const { activeView } = useApp();

  switch (activeView) {
    case 'market_overview':
      return <MarketOverviewView />;
    case 'cargo_market':
      return <CargoMarketView />;
    case 'vessel_market':
      return <VesselMarketView />;
    case 'spot_quotation':
      return <QuotationsView />;
    case 'matching_engine':
      return <MatchingView />;
    case 'waterway_network':
      return <WaterwayMap />;
    case 'port_operations':
    case 'berth_planning':
      return <PortsView />;
    case 'orders_list':
      return <OrdersView />;
    case 'voyage_detail':
      return <VoyageDetailView />;
    case 'settlement_ledger':
      return <SettlementView />;
    case 'document_centre':
      return <DocumentCentreView />;
    case 'analytics':
      return <AnalyticsView />;
    case 'operations_control':
      return <OperationsControlView />;
    case 'alerts':
      return <AlertsView />;
    case 'organisation':
      return <OrganizationView />;
    case 'settings':
      return <SettingsView />;
    case 'simulation_console':
      return <SimulationConsoleView />;
    default:
      return <MarketOverviewView />;
  }
};

export function AppContent() {
  return (
    <div className="h-screen w-screen flex flex-col bg-slate-950 text-slate-100 font-sans overflow-hidden select-none">
      {/* 1. 顶部命令栏 */}
      <Header />

      {/* 2. 主体 Workspace 区域 */}
      <div className="flex-1 flex overflow-hidden">
        {/* 左侧导航栏 */}
        <LeftNav />

        {/* 右侧主视图 */}
        <main className="flex-1 overflow-hidden relative">
          <WorkspaceRouter />
        </main>
      </div>

      {/* 3. 底部实时状态栏 */}
      <BottomStatusBar />

      {/* 4. 全局浮层 Modal 与 Toast */}
      <CommandBarModal />
      <ScenarioRunnerModal />
      <DataProvenanceModal />
      <ToastContainer />
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
