/**
 * 中国内河现货航运交易平台 — 核心领域模型定义
 * JIANGHAI SPOT Domain Types
 */

export type RoleType = 'cargo_owner' | 'carrier' | 'broker' | 'port_operator' | 'admin';

export interface User {
  id: string;
  name: string;
  role: RoleType;
  orgId: string;
  avatar?: string;
  phone: string;
  email: string;
}

export interface Organisation {
  id: string;
  name: string;
  type: 'shipper' | 'shipping_company' | 'agency' | 'port' | 'platform';
  creditCode: string; // 统一社会信用代码
  rating: string; // e.g. AAA
  verified: boolean;
  contactPerson: string;
  phone: string;
  location: string;
}

// 货物分类
export type CargoCategory = 
  | 'coal'          // 煤炭
  | 'iron_ore'      // 铁矿石
  | 'steel'         // 钢材
  | 'cement'        // 水泥
  | 'sand_gravel'   // 砂石建材
  | 'grain'         // 粮食
  | 'fertiliser'    // 化肥
  | 'chemicals'     // 液体/固体化工品
  | 'containers'     // 集装箱
  | 'machinery'     // 机械设备
  | 'general_bulk';  // 件杂货

export type CargoListingState = 
  | 'draft'       // 草稿
  | 'pending'     // 待审核
  | 'published'   // 已发布
  | 'bidding'     // 竞价中
  | 'matching'    // 撮合中
  | 'matched'     // 已匹配
  | 'in_transit'  // 运输中
  | 'completed'   // 已完成
  | 'cancelled'   // 已取消
  | 'expired';     // 已过期

export interface CargoListing {
  id: string;
  ownerOrgId: string;
  ownerOrgName: string;
  title: string;
  category: CargoCategory;
  categoryName: string;
  description: string;
  weightTons: number;
  volumeCbm?: number;
  containerTeu?: number;
  
  originPortId: string;
  originPortName: string;
  destinationPortId: string;
  destinationPortName: string;
  
  loadingWindowStart: string;
  loadingWindowEnd: string;
  deliveryWindowStart: string;
  deliveryWindowEnd: string;
  
  requiredVesselType: VesselCategory;
  maxDraftMeters: number;
  loadingMethod: string;
  unloadingMethod: string;
  packaging: string;
  isDangerous: boolean;
  hazardClass?: string;
  insuranceRequired: boolean;
  
  pricingMechanism: 'fixed' | 'rfq' | 'reverse_auction';
  askingPricePerTon: number; // RMB / Ton or RMB / TEU
  currency: string;
  totalAskingFreight: number;
  
  status: CargoListingState;
  readiness: 'ready' | 'in_production' | 'storage_pending';
  docStatus: 'complete' | 'pending_verification' | 'incomplete';
  createdAt: string;
  expiresAt: string;
  verified: boolean;
}

// 船舶分类
export type VesselCategory = 
  | 'dry_bulk_barge'       // 散货驳船
  | 'self_propelled'       // 自航货船
  | 'container_barge'      // 集装箱驳船
  | 'multipurpose'         // 多用途船
  | 'tanker'               // 液货/化学品船
  | 'heavy_lift'           // 重吊船
  | 'tug_barge'            // 拖驳组合
  | 'sand_carrier'         // 砂石自卸船
  | 'grain_carrier';       // 散粮专用船

export type VesselState = 
  | 'idle'           // 空闲
  | 'awaiting_load'  // 待装货
  | 'loading'        // 装货中
  | 'sailing'        // 航行中
  | 'awaiting_unload'// 等待卸货
  | 'unloading'      // 卸货中
  | 'maintenance'    // 维修中
  | 'restricted'     // 受限航行
  | 'unavailable';   // 不可用

export interface Vessel {
  id: string;
  mmsi: string;
  name: string;
  operatorOrgId: string;
  operatorOrgName: string;
  category: VesselCategory;
  categoryName: string;
  capacityTons: number;
  capacityTeu?: number;
  lengthMeters: number;
  beamMeters: number;
  maxDraftMeters: number;
  emptyDraftMeters: number;
  
  currentLocationPortId: string;
  currentLocationPortName: string;
  currentLat: number;
  currentLng: number;
  nextAvailablePortId: string;
  nextAvailablePortName: string;
  nextAvailableDate: string;
  
  fuelType: 'LNG' | 'Diesel' | 'Electric_Hybrid';
  fuelConsumptionEstTonsPerDay: number;
  hasCrane: boolean;
  craneCapacityTons?: number;
  hasPumpingSystem: boolean;
  
  insuranceStatus: 'active' | 'expiring_soon' | 'expired';
  safetyCertStatus: 'verified' | 'pending' | 'rejected';
  verified: boolean;
  
  askingRatePerTonDay?: number;
  minVoyageRateRmb: number;
  status: VesselState;
  availabilityExpiry: string;
}

// 港口与码头
export type PortStatus = 
  | 'normal'        // 正常运营
  | 'busy'          // 繁忙
  | 'congested'     // 拥堵
  | 'partially_closed' // 部分关闭
  | 'weather_impact' // 天气影响
  | 'maintenance'   // 设备维护
  | 'restricted';    // 临时限制

export interface Berth {
  id: string;
  portId: string;
  berthNumber: string;
  name: string;
  maxDraftMeters: number;
  maxDwtTons: number;
  handledCategories: CargoCategory[];
  isOccupied: boolean;
  currentVesselName?: string;
  currentVesselId?: string;
  occupiedUntil?: string;
  craneCount: number;
  loadingRateTonsPerHour: number;
}

export interface Port {
  id: string;
  code: string;
  name: string;
  region: 'yangtze' | 'grand_canal' | 'pearl_river' | 'other_inland';
  regionName: string;
  province: string;
  city: string;
  lat: number;
  lng: number;
  
  berthCount: number;
  berths: Berth[];
  handledCategories: CargoCategory[];
  maxDraftLimitMeters: number;
  operatingHours: string;
  
  storageCapacityTons: number;
  currentStorageTons: number;
  queueVesselCount: number;
  avgWaitHours: number;
  
  weatherSummary: string;
  status: PortStatus;
  contactPhone: string;
  hasRailConnection: boolean;
  hasHighwayConnection: boolean;
}

// 水道与关隘/船闸
export interface Lock {
  id: string;
  name: string;
  waterwayName: string;
  lat: number;
  lng: number;
  status: 'open' | 'congested' | 'maintenance' | 'closed';
  queueVesselCount: number;
  avgLockPassHours: number;
  maxDraftMeters: number;
  maxBeamMeters: number;
}

export interface WaterwaySegment {
  id: string;
  name: string;
  corridor: 'yangtze' | 'grand_canal' | 'pearl_river' | 'xijiang' | 'other';
  corridorName: string;
  startPortId: string;
  endPortId: string;
  distanceKm: number;
  standardDepthMeters: number;
  currentDepthMeters: number;
  currentSpeedKnots: number;
  restrictionNote?: string;
  locks: Lock[];
}

// 报价对象
export type QuoteStatus = 
  | 'draft'       // 草稿
  | 'submitted'   // 已提交
  | 'viewed'      // 已查看
  | 'negotiating' // 谈判中
  | 'accepted'    // 已接受
  | 'rejected'    // 已拒绝
  | 'expired'     // 已过期
  | 'withdrawn';   // 已撤回

export interface FreightQuote {
  id: string;
  quoteNo: string;
  cargoId: string;
  cargoTitle: string;
  vesselId: string;
  vesselName: string;
  carrierOrgId: string;
  carrierOrgName: string;
  shipperOrgId: string;
  shipperOrgName: string;
  
  originPortName: string;
  destinationPortName: string;
  quantityTons: number;
  
  freightBasis: 'per_ton' | 'per_teu' | 'lump_sum';
  unitPriceRmb: number;
  baseFreightRmb: number;
  
  fuelSurchargeRmb: number;
  lockFeeRmb: number;
  portFeeRmb: number;
  loadingFeeRmb: number;
  unloadingFeeRmb: number;
  insuranceCostRmb: number;
  taxRmb: number;
  totalEstimatedFreightRmb: number;
  
  validityExpiry: string;
  estimatedTransitDays: number;
  demurrageRatePerDayRmb: number;
  paymentTerms: string;
  status: QuoteStatus;
  createdAt: string;
  auditTrail: { timestamp: string; action: string; actor: string }[];
}

// 撮合与候选
export interface MatchScoreBreakdown {
  routeMatchPercent: number;
  capacityMatchPercent: number;
  timeMatchPercent: number;
  priceMatchPercent: number;
  documentCompletenessPercent: number;
  fairwayFeasibilityPercent: number;
  overallScore: number;
  explanation: string[];
}

export interface MatchCandidate {
  id: string;
  cargoId: string;
  cargo: CargoListing;
  vesselId: string;
  vessel: Vessel;
  carrierOrgName: string;
  scores: MatchScoreBreakdown;
  suggestedFreightRmbPerTon: number;
  status: 'candidate' | 'pending_confirmation' | 'both_confirmed' | 'contract_generated' | 'cancelled';
  createdAt: string;
}

// 运输订单与航次
export type OrderStatus = 
  | 'created'         // 已创建
  | 'pending_confirm' // 待确认
  | 'awaiting_load'   // 待装货
  | 'loading'         // 装货中
  | 'departed'        // 已离港
  | 'sailing'         // 航行中
  | 'awaiting_berth'  // 等待靠泊
  | 'unloading'       // 卸货中
  | 'delivered'       // 已交付
  | 'settled'         // 已结算
  | 'closed'          // 已关闭
  | 'disputed';       // 争议中

export interface VoyageEvent {
  id: string;
  timestamp: string;
  eventType: 'contract_signed' | 'vessel_assigned' | 'loading_started' | 'loading_finished' | 'departed' | 'lock_passed' | 'delay_reported' | 'arrived' | 'unloading_finished' | 'delivered' | 'settlement_released';
  location: string;
  description: string;
  operator: string;
}

export interface TransportOrder {
  id: string;
  orderNo: string;
  cargoId: string;
  cargoTitle: string;
  cargoOwnerName: string;
  carrierName: string;
  brokerName?: string;
  vesselId: string;
  vesselName: string;
  mmsi: string;
  
  originPortName: string;
  destinationPortName: string;
  weightTons: number;
  
  agreedPricePerTon: number;
  totalAgreedCostRmb: number;
  
  loadingAppointment: string;
  unloadingAppointment: string;
  estimatedArrival: string;
  actualArrival?: string;
  
  currentLat: number;
  currentLng: number;
  progressPercent: number;
  
  status: OrderStatus;
  paymentStatus: 'pending' | 'escrow_locked' | 'partially_paid' | 'fully_paid' | 'disputed';
  insuranceStatus: 'covered' | 'pending_claim' | 'none';
  hasException: boolean;
  exceptionNote?: string;
  
  events: VoyageEvent[];
  createdAt: string;
}

// 结算与发票
export type PaymentMethod = 
  | 'bank_transfer'   // RMB 银行转账
  | 'account_balance' // 企业账户余额
  | 'digital_yuan'    // 数字人民币 Adapter
  | 'escrow'          // 托管结算
  | 'milestone';       // 分期履约结算

export type SettlementState = 
  | 'pending_payment' // 待付款
  | 'initiated'       // 已发起
  | 'processing'      // 处理中
  | 'partially_paid'  // 部分结算
  | 'settled'         // 已结算
  | 'refunded'        // 已退款
  | 'frozen';         // 争议冻结

export interface Invoice {
  id: string;
  invoiceNo: string;
  orderId: string;
  orderNo: string;
  payerName: string;
  payeeName: string;
  
  baseFreightRmb: number;
  portChargesRmb: number;
  lockFeesRmb: number;
  loadingFeeRmb: number;
  unloadingFeeRmb: number;
  fuelSurchargeRmb: number;
  brokerFeeRmb: number;
  insuranceRmb: number;
  taxAmountRmb: number; // 9% 增值税
  totalAmountRmb: number;
  
  paymentMethod: PaymentMethod;
  status: SettlementState;
  issueDate: string;
  dueDate: string;
  paidDate?: string;
}

// 合同与单证
export type DocType = 
  | 'freight_contract'    // 水路货物运输合同
  | 'bill_of_lading'      // 电子提单
  | 'cargo_manifest'      // 载货清单
  | 'delivery_receipt'    // 货物交接签收单
  | 'port_confirmation'   // 港口靠泊通知单
  | 'vessel_certificate'  // 船舶适航证
  | 'inspection_record'   // 航运安检记录
  | 'tax_invoice';        // 增值税发票

export interface Document {
  id: string;
  docNo: string;
  title: string;
  type: DocType;
  orderId: string;
  orderNo: string;
  issuerOrgName: string;
  recipientOrgName: string;
  createdDate: string;
  version: string;
  status: 'draft' | 'valid' | 'pending_signature' | 'signed' | 'revoked';
  signatureState: 'unsigned' | 'shipper_signed' | 'carrier_signed' | 'both_signed';
  shipperSignedAt?: string;
  carrierSignedAt?: string;
  hashVerification: string; // 拟真哈希存证
}

// 系统事件与预警
export interface ServiceAlert {
  id: string;
  timestamp: string;
  severity: 'info' | 'warning' | 'danger';
  category: 'weather' | 'lock_delay' | 'port_congestion' | 'doc_exception' | 'payment_hold' | 'safety';
  title: string;
  message: string;
  relatedId?: string;
  resolved: boolean;
}

export interface AuditEvent {
  id: string;
  timestamp: string;
  action: string;
  module: string;
  operator: string;
  details: string;
}

// 模拟状态
export interface SimulationState {
  isRunning: boolean;
  timeSpeedMultiplier: number; // 1, 10, 60, 3600
  simulatedTime: string; // ISO format string
  demandMultiplier: number; // 1.0
  capacityMultiplier: number; // 1.0
  simulatedFuelPriceRmbPerTon: number; // e.g. 7200 RMB/Ton
  weatherAlertActive: boolean;
  lockCongestionActive: boolean;
  logs: string[];
}
