/**
 * 中国内河现货航运交易平台 — 数据真伪与溯源说明面板 (Data Provenance Panel)
 * JIANGHAI SPOT Data Honesty & Provenance Modal
 */

import React from 'react';
import { useApp } from '../../context/AppContext';
import { ShieldCheck, Info, Database, Cpu, Lock, CheckCircle2, X } from 'lucide-react';

export const DataProvenanceModal: React.FC = () => {
  const { isProvenanceModalOpen, setIsProvenanceModalOpen } = useApp();

  if (!isProvenanceModalOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-2xl bg-slate-900 border border-slate-700 rounded-xl shadow-2xl overflow-hidden font-sans text-slate-200">
        {/* Modal Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <h2 className="text-base font-bold text-slate-100">
              数据透明度与源头说明 (Data Provenance)
            </h2>
          </div>
          <button
            onClick={() => setIsProvenanceModalOpen(false)}
            className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 说明内容 */}
        <div className="p-5 space-y-4 max-h-[70vh] overflow-y-auto text-xs text-slate-300 leading-relaxed">
          <div className="p-3 bg-emerald-950/40 border border-emerald-500/30 rounded-lg text-emerald-300 flex items-start space-x-2.5">
            <Info className="w-4 h-4 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-sm">合规与真实性保障规则</p>
              <p className="text-[11px] text-emerald-300/80 mt-0.5">
                本系统为中国内河现货航运交易平台商业原型。本平台严禁虚构实时交易所价格或伪造未经授权的船只AIS实时轨迹。所有展示数据均附有清晰的数据来源标识。
              </p>
            </div>
          </div>

          <div className="space-y-3">
            <div className="p-3 bg-slate-800/60 border border-slate-700/80 rounded-lg flex items-start space-x-3">
              <Database className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-slate-100 block">1. 种子示范数据 (Seeded Demo Data)</span>
                <p className="text-slate-400 text-[11px] mt-0.5">
                  包括长江、京杭运河及珠江水系的枢纽港口参数、标准吃水限度、船闸名称、企业信用代码以及初始挂牌货源与船舶。来源于真实航运规章与统计公报的确定性采样。
                </p>
              </div>
            </div>

            <div className="p-3 bg-slate-800/60 border border-slate-700/80 rounded-lg flex items-start space-x-3">
              <Cpu className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-slate-100 block">2. 确定性计算与模拟推演 (Deterministic Modelled Engine)</span>
                <p className="text-slate-400 text-[11px] mt-0.5">
                  智能撮合比分、运费总价拆解、在途进度推算、气象与船闸延误风险等，均由前端集成的数学引擎实时算得，过程完全透明可追溯。
                </p>
              </div>
            </div>

            <div className="p-3 bg-slate-800/60 border border-slate-700/80 rounded-lg flex items-start space-x-3">
              <Lock className="w-4 h-4 text-purple-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-slate-100 block">3. 拟真存证与接口 Adapter</span>
                <p className="text-slate-400 text-[11px] mt-0.5">
                  数字人民币(e-CNY)适配器、银行资金托管与电子合同区块链存证，使用无外网依赖的真实加密摘要算法生成验证哈希。
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-3 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span>江海现货 JIANGHAI SPOT | 诚信航运交易协议</span>
          <button
            onClick={() => setIsProvenanceModalOpen(false)}
            className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-medium transition"
          >
            我已了解
          </button>
        </div>
      </div>
    </div>
  );
};
