/**
 * 中国内河现货航运交易平台 — 命令面板与全局搜索 (Command Bar)
 * JIANGHAI SPOT Global Command Search & Quick Actions
 */

import React, { useState, useEffect } from 'react';
import { useApp, WorkspaceView } from '../../context/AppContext';
import { RoleType } from '../../types';
import { 
  Search, 
  Package, 
  Ship, 
  Building2, 
  FileCheck2, 
  Sliders, 
  UserCheck, 
  AlertTriangle, 
  ArrowRight,
  MapPin,
  X
} from 'lucide-react';

export const CommandBarModal: React.FC = () => {
  const { 
    isCommandBarOpen, 
    setIsCommandBarOpen, 
    setActiveView, 
    setCurrentRole,
    cargoListings,
    vessels,
    ports,
    orders,
    triggerSimulatedEvent,
    setSelectedCargoId,
    setSelectedVesselId,
    setSelectedOrderId,
    setSelectedPortId,
    addToast
  } = useApp();

  const [query, setQuery] = useState('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsCommandBarOpen(!isCommandBarOpen);
      }
      if (e.key === 'Escape' && isCommandBarOpen) {
        setIsCommandBarOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isCommandBarOpen, setIsCommandBarOpen]);

  if (!isCommandBarOpen) return null;

  const handleSelectAction = (action: () => void) => {
    action();
    setIsCommandBarOpen(false);
    setQuery('');
  };

  // 过滤数据项
  const filteredCargoes = cargoListings.filter(
    (c) => c.title.includes(query) || c.categoryName.includes(query) || c.ownerOrgName.includes(query)
  );

  const filteredVessels = vessels.filter(
    (v) => v.name.includes(query) || v.mmsi.includes(query) || v.categoryName.includes(query)
  );

  const filteredPorts = ports.filter(
    (p) => p.name.includes(query) || p.city.includes(query) || p.code.includes(query)
  );

  const filteredOrders = orders.filter(
    (o) => o.orderNo.includes(query) || o.cargoTitle.includes(query) || o.vesselName.includes(query)
  );

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-start justify-center pt-20 px-4">
      <div className="w-full max-w-2xl bg-slate-900 border border-slate-700 rounded-xl shadow-2xl overflow-hidden font-sans text-slate-200">
        {/* 输入框 Header */}
        <div className="p-3 border-b border-slate-800 flex items-center space-x-3 bg-slate-950">
          <Search className="w-5 h-5 text-cyan-400 shrink-0" />
          <input
            type="text"
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="输入指令、货源标题、船名、MMSI、港口或订单编号..."
            className="w-full bg-transparent text-slate-100 placeholder-slate-500 text-sm focus:outline-none"
          />
          <button
            onClick={() => setIsCommandBarOpen(false)}
            className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-slate-200"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* 内容搜索结果列表 */}
        <div className="max-h-[60vh] overflow-y-auto p-2 divide-y divide-slate-800/50 space-y-2">
          {/* 快捷系统操作 */}
          <div>
            <div className="px-2 py-1 text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
              快捷指令与系统功能
            </div>
            <div className="space-y-1">
              <button
                onClick={() =>
                  handleSelectAction(() => {
                    setActiveView('create_cargo');
                  })
                }
                className="w-full flex items-center justify-between p-2 rounded-lg hover:bg-slate-800/80 text-xs text-left group transition"
              >
                <div className="flex items-center space-x-2.5">
                  <Package className="w-4 h-4 text-amber-400" />
                  <span>发布新货源挂牌 (Create Cargo Listing)</span>
                </div>
                <ArrowRight className="w-3.5 h-3.5 text-slate-600 group-hover:text-slate-300" />
              </button>

              <button
                onClick={() =>
                  handleSelectAction(() => {
                    setActiveView('create_vessel');
                  })
                }
                className="w-full flex items-center justify-between p-2 rounded-lg hover:bg-slate-800/80 text-xs text-left group transition"
              >
                <div className="flex items-center space-x-2.5">
                  <Ship className="w-4 h-4 text-blue-400" />
                  <span>发布空船运力 (Publish Vessel Capacity)</span>
                </div>
                <ArrowRight className="w-3.5 h-3.5 text-slate-600 group-hover:text-slate-300" />
              </button>

              <button
                onClick={() =>
                  handleSelectAction(() => {
                    setActiveView('waterway_network');
                  })
                }
                className="w-full flex items-center justify-between p-2 rounded-lg hover:bg-slate-800/80 text-xs text-left group transition"
              >
                <div className="flex items-center space-x-2.5">
                  <MapPin className="w-4 h-4 text-emerald-400" />
                  <span>打开长江与京杭运河航线地图 (Waterway Map)</span>
                </div>
                <ArrowRight className="w-3.5 h-3.5 text-slate-600 group-hover:text-slate-300" />
              </button>

              <button
                onClick={() =>
                  handleSelectAction(() => {
                    triggerSimulatedEvent('lock_congestion');
                  })
                }
                className="w-full flex items-center justify-between p-2 rounded-lg hover:bg-amber-950/40 text-xs text-left group text-amber-300 transition"
              >
                <div className="flex items-center space-x-2.5">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  <span>模拟测试：触发三峡船闸拥堵预警</span>
                </div>
                <span className="text-[10px] font-mono bg-amber-900/60 px-1.5 py-0.5 rounded text-amber-300">
                  模拟命令
                </span>
              </button>
            </div>
          </div>

          {/* 角色切换指令 */}
          <div className="pt-2">
            <div className="px-2 py-1 text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
              视角切换 (Role Switcher)
            </div>
            <div className="grid grid-cols-2 gap-1 mt-1">
              {[
                { role: 'cargo_owner', label: '货主视角 (Shipper)' },
                { role: 'carrier', label: '船东视角 (Carrier)' },
                { role: 'broker', label: '经纪人视角 (Broker)' },
                { role: 'port_operator', label: '港口公司视角 (Port Op)' }
              ].map((r) => (
                <button
                  key={r.role}
                  onClick={() =>
                    handleSelectAction(() => {
                      setCurrentRole(r.role as RoleType);
                      addToast({
                        type: 'info',
                        title: '视角已切换',
                        message: `当前界面视角已切至 [${r.label}]`
                      });
                    })
                  }
                  className="flex items-center space-x-2 p-2 rounded hover:bg-slate-800 text-xs text-slate-300 transition"
                >
                  <UserCheck className="w-3.5 h-3.5 text-slate-400" />
                  <span>{r.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* 货源匹配结果 */}
          {filteredCargoes.length > 0 && (
            <div className="pt-2">
              <div className="px-2 py-1 text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                货源列表 ({filteredCargoes.length})
              </div>
              <div className="space-y-1 mt-1">
                {filteredCargoes.map((c) => (
                  <button
                    key={c.id}
                    onClick={() =>
                      handleSelectAction(() => {
                        setSelectedCargoId(c.id);
                        setActiveView('cargo_market');
                      })
                    }
                    className="w-full flex items-center justify-between p-2 rounded hover:bg-slate-800 text-xs text-left"
                  >
                    <div className="flex items-center space-x-2">
                      <Package className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                      <span className="font-medium text-slate-200">{c.title}</span>
                    </div>
                    <span className="text-[11px] font-mono text-slate-400">
                      ¥{c.askingPricePerTon}/吨
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* 船舶匹配结果 */}
          {filteredVessels.length > 0 && (
            <div className="pt-2">
              <div className="px-2 py-1 text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                船舶运力 ({filteredVessels.length})
              </div>
              <div className="space-y-1 mt-1">
                {filteredVessels.map((v) => (
                  <button
                    key={v.id}
                    onClick={() =>
                      handleSelectAction(() => {
                        setSelectedVesselId(v.id);
                        setActiveView('vessel_market');
                      })
                    }
                    className="w-full flex items-center justify-between p-2 rounded hover:bg-slate-800 text-xs text-left"
                  >
                    <div className="flex items-center space-x-2">
                      <Ship className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                      <span className="font-medium text-slate-200">{v.name}</span>
                      <span className="text-[10px] text-slate-400 font-mono">MMSI: {v.mmsi}</span>
                    </div>
                    <span className="text-[11px] text-slate-400">{v.capacityTons} 吨</span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Modal 底部快捷提示 */}
        <div className="p-2.5 bg-slate-950 border-t border-slate-800 text-[10px] font-mono text-slate-500 flex items-center justify-between">
          <span>使用 ↑ ↓ 选择，Enter 确认，Esc 退出</span>
          <span>江海现货交易指令集 v3.6</span>
        </div>
      </div>
    </div>
  );
};
