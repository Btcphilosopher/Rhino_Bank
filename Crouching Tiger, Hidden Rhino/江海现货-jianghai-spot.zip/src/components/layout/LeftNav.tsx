/**
 * 中国内河现货航运交易平台 — 左侧导航栏 (Left Navigation Rail)
 * JIANGHAI SPOT Industrial Logistics Navigation
 */

import React from 'react';
import { useApp, WorkspaceView } from '../../context/AppContext';
import { 
  LayoutDashboard, 
  Package, 
  Ship, 
  TrendingUp, 
  GitMerge, 
  MapPin, 
  Building2, 
  CalendarDays, 
  FileCheck2, 
  Navigation, 
  CreditCard, 
  FileText, 
  BarChart3, 
  Activity, 
  AlertTriangle, 
  Building, 
  Settings, 
  SlidersHorizontal,
  ChevronRight
} from 'lucide-react';

interface NavItem {
  id: WorkspaceView;
  label: string;
  enLabel: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: number | string;
  badgeColor?: string;
}

interface NavGroup {
  groupName: string;
  items: NavItem[];
}

export const LeftNav: React.FC = () => {
  const { 
    activeView, 
    setActiveView, 
    cargoListings, 
    vessels, 
    quotes, 
    matchCandidates, 
    orders, 
    alerts 
  } = useApp();

  const unhandledAlertCount = alerts.filter((a) => !a.resolved).length;
  const activeOrdersCount = orders.filter((o) => o.status === 'sailing' || o.status === 'loading').length;
  const openQuotesCount = quotes.filter((q) => q.status === 'submitted' || q.status === 'negotiating').length;

  const NAV_GROUPS: NavGroup[] = [
    {
      groupName: '核心交易',
      items: [
        { id: 'market_overview', label: '市场总览', enLabel: 'Overview', icon: LayoutDashboard },
        { id: 'cargo_market', label: '货源市场', enLabel: 'Cargoes', icon: Package, badge: cargoListings.length },
        { id: 'vessel_market', label: '运力市场', enLabel: 'Capacity', icon: Ship, badge: vessels.length },
        { id: 'spot_quotation', label: '现货报价', enLabel: 'Quotations', icon: TrendingUp, badge: openQuotesCount > 0 ? openQuotesCount : undefined, badgeColor: 'bg-amber-500' },
        { id: 'matching_engine', label: '智能撮合', enLabel: 'Matching', icon: GitMerge, badge: matchCandidates.length, badgeColor: 'bg-emerald-600' }
      ]
    },
    {
      groupName: '航网与港口',
      items: [
        { id: 'waterway_network', label: '航线水网', enLabel: 'Waterways', icon: MapPin },
        { id: 'port_operations', label: '港口码头', enLabel: 'Port Ops', icon: Building2 },
        { id: 'berth_planning', label: '泊位计划', enLabel: 'Berth Plan', icon: CalendarDays }
      ]
    },
    {
      groupName: '履约与监控',
      items: [
        { id: 'orders_list', label: '订单管理', enLabel: 'Orders', icon: FileCheck2, badge: orders.length },
        { id: 'voyage_detail', label: '航次监控', enLabel: 'Voyages', icon: Navigation, badge: activeOrdersCount > 0 ? `${activeOrdersCount}在途` : undefined, badgeColor: 'bg-blue-600' }
      ]
    },
    {
      groupName: '商业与风控',
      items: [
        { id: 'settlement_ledger', label: '中国式结算', enLabel: 'Settlement', icon: CreditCard },
        { id: 'document_centre', label: '合同与单证', enLabel: 'Documents', icon: FileText },
        { id: 'analytics', label: '航运分析', enLabel: 'Analytics', icon: BarChart3 },
        { id: 'operations_control', label: '运营控制台', enLabel: 'Operations', icon: Activity },
        { id: 'alerts', label: '预警与异常', enLabel: 'Alerts', icon: AlertTriangle, badge: unhandledAlertCount > 0 ? unhandledAlertCount : undefined, badgeColor: 'bg-red-500' }
      ]
    },
    {
      groupName: '系统',
      items: [
        { id: 'organisation', label: '企业档案', enLabel: 'Org Profile', icon: Building },
        { id: 'settings', label: '平台设置', enLabel: 'Settings', icon: Settings },
        { id: 'simulation_console', label: '模拟控制台', enLabel: 'Simulator', icon: SlidersHorizontal }
      ]
    }
  ];

  return (
    <aside className="w-56 bg-slate-900 border-r border-slate-800 flex flex-col justify-between shrink-0 select-none overflow-y-auto font-sans text-slate-300">
      <div className="py-3 px-2 space-y-4">
        {NAV_GROUPS.map((group, idx) => (
          <div key={idx} className="space-y-1">
            <div className="px-3 text-[10px] font-semibold tracking-wider text-slate-400 uppercase flex items-center justify-between">
              <span>{group.groupName}</span>
            </div>
            <div className="space-y-0.5">
              {group.items.map((item) => {
                const Icon = item.icon;
                const isActive = activeView === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveView(item.id)}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-md text-xs font-medium transition-all group ${
                      isActive
                        ? 'bg-blue-600/90 text-white shadow-sm'
                        : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5 min-w-0">
                      <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-slate-400 group-hover:text-slate-200'}`} />
                      <div className="truncate text-left">
                        <span className="block truncate">{item.label}</span>
                      </div>
                    </div>
                    {item.badge !== undefined && (
                      <span
                        className={`ml-1 text-[10px] font-mono font-semibold px-1.5 py-0.2 rounded-full ${
                          item.badgeColor || (isActive ? 'bg-white/20 text-white' : 'bg-slate-800 text-slate-300')
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* 底部运行签名 */}
      <div className="p-3 border-t border-slate-800 bg-slate-950/50">
        <div className="text-[11px] text-slate-400 flex items-center justify-between">
          <span className="font-mono text-cyan-400">v3.6.0 Enterprise</span>
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
        </div>
        <p className="text-[10px] text-slate-400 mt-1 truncate">
          确定性领域引擎 | 运行中
        </p>
      </div>
    </aside>
  );
};
