/**
 * 中国内河现货航运交易平台 — 全局顶部栏 (Top Header)
 * JIANGHAI SPOT Top Command Bar & Role Switcher
 */

import React from 'react';
import { useApp } from '../../context/AppContext';
import { RoleType } from '../../types';
import { 
  Anchor, 
  Search, 
  Command, 
  Bell, 
  ShieldCheck, 
  Sliders, 
  Play, 
  Sparkles, 
  Clock,
  UserCheck
} from 'lucide-react';

const ROLE_LABELS: Record<RoleType, { label: string; tag: string; bg: string }> = {
  cargo_owner: { label: '货主 (Shipper)', tag: '企业货主', bg: 'bg-amber-500/10 text-amber-600 border-amber-500/20' },
  carrier: { label: '船东/承运人 (Carrier)', tag: '航运企业', bg: 'bg-blue-500/10 text-blue-600 border-blue-500/20' },
  broker: { label: '航运经纪人 (Broker)', tag: '居间服务', bg: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20' },
  port_operator: { label: '港口码头公司 (Port)', tag: '枢纽港', bg: 'bg-purple-500/10 text-purple-600 border-purple-500/20' },
  admin: { label: '平台管理员 (Admin)', tag: '监管控制', bg: 'bg-slate-700/10 text-slate-700 border-slate-700/20' }
};

export const Header: React.FC = () => {
  const { 
    currentRole, 
    setCurrentRole, 
    setIsCommandBarOpen, 
    setIsScenarioModalOpen,
    setIsProvenanceModalOpen,
    alerts,
    simulation,
    setActiveView
  } = useApp();

  const activeAlertCount = alerts.filter((a) => !a.resolved).length;

  return (
    <header className="h-16 bg-slate-900 border-b border-slate-800 text-white px-4 flex items-center justify-between sticky top-0 z-30 select-none">
      {/* 品牌 Identity */}
      <div className="flex items-center space-x-3">
        <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyan-600 via-blue-600 to-indigo-800 p-0.5 shadow-md flex items-center justify-center">
          <div className="w-full h-full bg-slate-950 rounded-[7px] flex items-center justify-center">
            <Anchor className="w-5 h-5 text-cyan-400" />
          </div>
        </div>
        <div>
          <div className="flex items-center space-x-2">
            <span className="font-extrabold text-lg tracking-wider text-slate-100 font-serif">
              江海现货
            </span>
            <span className="text-xs font-mono tracking-widest text-cyan-400 bg-cyan-950/80 px-1.5 py-0.5 rounded border border-cyan-800/50">
              JIANGHAI SPOT
            </span>
          </div>
          <p className="text-[11px] text-slate-400 flex items-center space-x-1">
            <span>中国内河现货航运交易平台</span>
            <span className="text-slate-600">|</span>
            <span className="text-slate-400 font-sans">让货物寻找船，让船寻找货</span>
          </p>
        </div>
      </div>

      {/* 全局 Command Bar 触发器 */}
      <div className="flex-1 max-w-md mx-6">
        <button
          onClick={() => setIsCommandBarOpen(true)}
          className="w-full bg-slate-800/80 hover:bg-slate-800 text-slate-400 border border-slate-700/60 rounded-lg px-3 py-1.5 text-xs flex items-center justify-between transition-colors shadow-inner"
        >
          <div className="flex items-center space-x-2">
            <Search className="w-3.5 h-3.5 text-slate-400" />
            <span>搜索货源、船只、港口、订单、指令...</span>
          </div>
          <div className="flex items-center space-x-1 text-[10px] text-slate-400 font-mono bg-slate-900 px-1.5 py-0.5 rounded border border-slate-700">
            <Command className="w-3 h-3" />
            <span>K</span>
          </div>
        </button>
      </div>

      {/* 右侧工具集 & 角色切换 */}
      <div className="flex items-center space-x-3">
        {/* 预设演示场景入口 */}
        <button
          onClick={() => setIsScenarioModalOpen(true)}
          className="px-2.5 py-1.5 bg-gradient-to-r from-amber-500/20 to-orange-500/20 hover:from-amber-500/30 hover:to-orange-500/30 text-amber-300 border border-amber-500/40 rounded-md text-xs font-medium flex items-center space-x-1.5 transition shadow-sm"
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
          <span>预设演示场景</span>
        </button>

        {/* 模拟器控制台快捷 */}
        <button
          onClick={() => setActiveView('simulation_console')}
          className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 rounded-md text-xs flex items-center space-x-1.5 transition"
          title="开发者与模拟控制台"
        >
          <Sliders className="w-3.5 h-3.5 text-cyan-400" />
          <span className="hidden lg:inline">模拟引擎</span>
        </button>

        {/* 数据溯源面板 */}
        <button
          onClick={() => setIsProvenanceModalOpen(true)}
          className="px-2 py-1.5 bg-slate-800/60 hover:bg-slate-800 text-slate-300 border border-slate-700/80 rounded-md text-xs flex items-center space-x-1 transition"
          title="查看数据真伪与模拟说明"
        >
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/60 px-1 rounded">模拟校验</span>
        </button>

        {/* 预警警报快捷 */}
        <button
          onClick={() => setActiveView('alerts')}
          className="relative p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 rounded-md transition"
          title="预警与异常通知"
        >
          <Bell className="w-4 h-4" />
          {activeAlertCount > 0 && (
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center animate-bounce">
              {activeAlertCount}
            </span>
          )}
        </button>

        <div className="h-5 w-px bg-slate-800 my-auto" />

        {/* 角色切换选择器 */}
        <div className="flex items-center space-x-2 bg-slate-950 p-1 rounded-lg border border-slate-800">
          <UserCheck className="w-3.5 h-3.5 text-slate-400 ml-1.5" />
          <span className="text-xs text-slate-400 hidden xl:inline">视角:</span>
          <select
            value={currentRole}
            onChange={(e) => setCurrentRole(e.target.value as RoleType)}
            className="bg-slate-900 text-slate-200 text-xs font-medium rounded px-2 py-1 border border-slate-700 focus:outline-none focus:border-cyan-500 cursor-pointer"
          >
            {Object.entries(ROLE_LABELS).map(([key, item]) => (
              <option key={key} value={key}>
                {item.label}
              </option>
            ))}
          </select>
        </div>
      </div>
    </header>
  );
};
