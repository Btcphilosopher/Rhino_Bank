/**
 * 中国内河现货航运交易平台 — 底部状态栏 (Bottom Status Bar)
 * JIANGHAI SPOT Real-time Simulation Status Bar
 */

import React from 'react';
import { useApp } from '../../context/AppContext';
import { Radio, Clock, ShieldCheck, Zap, Fuel, Activity } from 'lucide-react';

export const BottomStatusBar: React.FC = () => {
  const { simulation, orders, ports, cargoListings, setIsProvenanceModalOpen, advanceSimulationClock } = useApp();

  const activeVoyagesCount = orders.filter((o) => o.status === 'sailing').length;
  const congestedPortCount = ports.filter((p) => p.status === 'congested' || p.status === 'busy').length;

  return (
    <footer className="h-7 bg-slate-950 border-t border-slate-800 text-[11px] font-mono text-slate-400 px-3 flex items-center justify-between shrink-0 select-none">
      {/* 状态与系统脉搏 */}
      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-1.5 text-emerald-400">
          <Radio className="w-3 h-3 animate-pulse" />
          <span>推送节点: 正常 (24 Hubs)</span>
        </div>

        <div className="hidden sm:flex items-center space-x-1 text-slate-400">
          <Activity className="w-3 h-3 text-cyan-400" />
          <span>在途航次: <strong className="text-slate-200">{activeVoyagesCount}</strong></span>
        </div>

        <div className="hidden md:flex items-center space-x-1 text-slate-400">
          <Zap className="w-3 h-3 text-amber-400" />
          <span>拥堵/繁忙港口: <strong className="text-amber-300">{congestedPortCount}</strong></span>
        </div>

        <div className="hidden lg:flex items-center space-x-1 text-slate-400">
          <Fuel className="w-3 h-3 text-orange-400" />
          <span>基准油价: <span className="text-slate-200">¥{simulation.simulatedFuelPriceRmbPerTon}/吨</span></span>
        </div>
      </div>

      {/* 模拟时钟与快进控制 */}
      <div className="flex items-center space-x-3">
        <div className="flex items-center space-x-1 text-slate-300 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
          <Clock className="w-3 h-3 text-cyan-400" />
          <span>模拟时间: </span>
          <span className="text-cyan-300 font-semibold">
            {new Date(simulation.simulatedTime).toLocaleString('zh-CN', {
              month: '2-digit',
              day: '2-digit',
              hour: '2-digit',
              minute: '2-digit'
            })}
          </span>
        </div>

        <div className="flex items-center space-x-1">
          <button
            onClick={() => advanceSimulationClock(1)}
            className="px-1.5 py-0.2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded border border-slate-700 transition"
            title="模拟前进 1 小时"
          >
            +1小时
          </button>
          <button
            onClick={() => advanceSimulationClock(24)}
            className="px-1.5 py-0.2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded border border-slate-700 transition"
            title="模拟前进 1 天"
          >
            +1天
          </button>
        </div>

        <button
          onClick={() => setIsProvenanceModalOpen(true)}
          className="flex items-center space-x-1 text-slate-400 hover:text-emerald-400 transition"
        >
          <ShieldCheck className="w-3 h-3 text-emerald-500" />
          <span className="hidden xl:inline">模拟数据说明</span>
        </button>
      </div>
    </footer>
  );
};
