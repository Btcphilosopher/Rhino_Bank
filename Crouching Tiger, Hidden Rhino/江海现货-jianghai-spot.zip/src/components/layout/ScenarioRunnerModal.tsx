/**
 * 中国内河现货航运交易平台 — 预设业务演示场景 runner (Scenario Runner Modal)
 * JIANGHAI SPOT Preloaded Demo Scenarios
 */

import React from 'react';
import { useApp } from '../../context/AppContext';
import { Sparkles, ArrowRight, X, Play, CheckCircle2, AlertOctagon, RefreshCw, FileText } from 'lucide-react';

export const ScenarioRunnerModal: React.FC = () => {
  const { isScenarioModalOpen, setIsScenarioModalOpen, runScenario } = useApp();

  if (!isScenarioModalOpen) return null;

  const SCENARIOS = [
    {
      id: 1,
      tag: '场景 1',
      title: '水泥干散货即期挂牌与履约',
      subtitle: '安徽水泥厂商发往南京港龙潭码头',
      desc: '演示货主发布 3500吨 散装水泥需求，收到承运人报价谈判，自动匹配配载并推进航次至履约结清全流程。',
      color: 'from-blue-600/20 to-indigo-600/20 border-blue-500/30'
    },
    {
      id: 2,
      tag: '场景 2',
      title: '内河集装箱多式联运驳运',
      subtitle: '梧州港驳运 200 TEU 电子件至广州黄埔大船',
      desc: '展示珠江水系外贸集装箱驳船订舱、箱位调度、集港打单与海关联运放行接驳。',
      color: 'from-emerald-600/20 to-teal-600/20 border-emerald-500/30'
    },
    {
      id: 3,
      tag: '场景 3',
      title: '船闸维护拥堵与预警调度',
      subtitle: '三峡/京杭运河船闸限速通行与航程智能重算',
      desc: '模拟三峡五级船闸例行检修拥堵，平台自动触发风险预警、重新估算抵港 ETA 并推送到手订单客户。',
      color: 'from-amber-600/20 to-orange-600/20 border-amber-500/30'
    },
    {
      id: 4,
      tag: '场景 4',
      title: '货主反向竞价拍卖 (Reverse Auction)',
      subtitle: '武钢 5000吨 钢卷运费公开阶梯竞价',
      desc: '货主设定上限报价，多家船东与经纪人在限定倒计时内实时下竞价单，系统自动比对资质并优选锁定。',
      color: 'from-purple-600/20 to-pink-600/20 border-purple-500/30'
    },
    {
      id: 5,
      tag: '场景 5',
      title: '中国式托管结算与争议单证处理',
      subtitle: '货完单未盖章异常冻结与人工审核解冻',
      desc: '模拟到港交接单缺失承运人完好公章导致托管运费自动冻结，经存证补录校验后解除争议自动划款。',
      color: 'from-rose-600/20 to-red-600/20 border-rose-500/30'
    }
  ];

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-3xl bg-slate-900 border border-slate-700 rounded-xl shadow-2xl overflow-hidden font-sans text-slate-200">
        {/* Modal Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Sparkles className="w-5 h-5 text-amber-400" />
            <h2 className="text-base font-bold text-slate-100">
              预设业务演示场景 runner (Scenario Runner)
            </h2>
          </div>
          <button
            onClick={() => setIsScenarioModalOpen(false)}
            className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 场景卡片列表 */}
        <div className="p-4 max-h-[70vh] overflow-y-auto space-y-3">
          <p className="text-xs text-slate-400 leading-relaxed">
            平台已预置 5 组贴合中国长江、京杭运河及珠江内河真实商业逻辑的典型场景。点击即可一键载入对应数据集与工作台视图：
          </p>

          <div className="space-y-2.5">
            {SCENARIOS.map((sc) => (
              <div
                key={sc.id}
                className={`p-3.5 bg-gradient-to-r ${sc.color} border rounded-xl flex items-center justify-between hover:border-cyan-500/50 transition group`}
              >
                <div className="space-y-1 max-w-xl">
                  <div className="flex items-center space-x-2">
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-900/80 text-amber-300 font-semibold border border-amber-500/20">
                      {sc.tag}
                    </span>
                    <h3 className="text-sm font-bold text-slate-100 group-hover:text-cyan-300 transition-colors">
                      {sc.title}
                    </h3>
                  </div>
                  <p className="text-xs text-slate-300 font-medium">{sc.subtitle}</p>
                  <p className="text-[11px] text-slate-400 leading-relaxed">{sc.desc}</p>
                </div>

                <button
                  onClick={() => runScenario(sc.id)}
                  className="shrink-0 px-3 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold flex items-center space-x-1.5 shadow-md transition transform active:scale-95"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>一键运行</span>
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-3 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span>所有场景均采用确定性数据，支持实时推演与随时重置</span>
          <button
            onClick={() => setIsScenarioModalOpen(false)}
            className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs transition"
          >
            关闭
          </button>
        </div>
      </div>
    </div>
  );
};
