/**
 * 中国内河现货航运交易平台 — Toast 通知组件 (Toast Notification)
 * JIANGHAI SPOT Clean Industrial Toast Container
 */

import React from 'react';
import { useApp } from '../../context/AppContext';
import { CheckCircle2, AlertTriangle, AlertCircle, Info, X } from 'lucide-react';

export const ToastContainer: React.FC = () => {
  const { toasts, removeToast } = useApp();

  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-10 right-4 z-50 flex flex-col space-y-2 max-w-sm w-full pointer-events-none select-none">
      {toasts.map((toast) => {
        const icons = {
          success: <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />,
          info: <Info className="w-5 h-5 text-cyan-400 shrink-0" />,
          warning: <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />,
          error: <AlertCircle className="w-5 h-5 text-red-400 shrink-0" />
        };

        const bgStyles = {
          success: 'bg-slate-900/95 border-emerald-500/40 text-emerald-100',
          info: 'bg-slate-900/95 border-cyan-500/40 text-cyan-100',
          warning: 'bg-slate-900/95 border-amber-500/40 text-amber-100',
          error: 'bg-slate-900/95 border-red-500/40 text-red-100'
        };

        return (
          <div
            key={toast.id}
            className={`pointer-events-auto p-3.5 rounded-lg border shadow-xl flex items-start space-x-3 transition-all transform animate-in slide-in-from-right font-sans backdrop-blur-md ${bgStyles[toast.type]}`}
          >
            {icons[toast.type]}
            <div className="flex-1 space-y-0.5 min-w-0">
              <h4 className="text-xs font-bold leading-tight truncate">{toast.title}</h4>
              <p className="text-[11px] opacity-90 leading-snug">{toast.message}</p>
            </div>
            <button
              onClick={() => removeToast(toast.id)}
              className="opacity-60 hover:opacity-100 p-0.5 rounded transition"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
