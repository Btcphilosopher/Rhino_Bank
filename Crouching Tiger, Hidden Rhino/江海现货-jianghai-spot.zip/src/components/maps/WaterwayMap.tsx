/**
 * 中国内河现货航运交易平台 — 交互式水网航线地图 (Waterway Network Map)
 * JIANGHAI SPOT Interactive Vector Inland Waterway Network Map
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Port, Vessel, Lock } from '../../types';
import { 
  MapPin, 
  Layers, 
  Navigation, 
  AlertTriangle, 
  Ship, 
  Building2, 
  Clock, 
  Compass,
  Info,
  Maximize2,
  Sliders,
  Sparkles
} from 'lucide-react';

export const WaterwayMap: React.FC = () => {
  const { ports, vessels, setSelectedPortId, setSelectedVesselId, setActiveView } = useApp();

  const [showPorts, setShowPorts] = useState(true);
  const [showLocks, setShowLocks] = useState(true);
  const [showVessels, setShowVessels] = useState(true);
  const [showCongestion, setShowCongestion] = useState(true);
  const [selectedMapNode, setSelectedMapNode] = useState<{ type: 'port' | 'vessel' | 'lock'; data: any } | null>(null);

  // 测量路线模式
  const [calcStartPort, setCalcStartPort] = useState<string>('port-shanghai');
  const [calcEndPort, setCalcEndPort] = useState<string>('port-chongqing');

  // 地图节点位置 (坐标映射至 SVG 700x500 画布)
  const MAP_PORTS: { id: string; name: string; x: number; y: number; corridor: string; status: string }[] = [
    { id: 'port-shanghai', name: '上海港', x: 620, y: 310, corridor: '长江干线', status: 'normal' },
    { id: 'port-nanjing', name: '南京港', x: 520, y: 280, corridor: '长江干线', status: 'normal' },
    { id: 'port-wuhu', name: '芜湖港', x: 490, y: 300, corridor: '长江干线', status: 'normal' },
    { id: 'port-jiujiang', name: '九江港', x: 410, y: 315, corridor: '长江干线', status: 'normal' },
    { id: 'port-wuhan', name: '武汉港', x: 350, y: 310, corridor: '长江干线', status: 'busy' },
    { id: 'port-yichang', name: '宜昌港', x: 250, y: 295, corridor: '长江干线', status: 'busy' },
    { id: 'port-chongqing', name: '重庆港', x: 140, y: 310, corridor: '长江干线', status: 'congested' },
    
    // 京杭运河节点
    { id: 'port-jining', name: '济宁港(梁山)', x: 480, y: 140, corridor: '京杭运河', status: 'normal' },
    { id: 'port-xuzhou', name: '徐州港', x: 495, y: 180, corridor: '京杭运河', status: 'normal' },
    { id: 'port-huaian', name: '淮安港', x: 525, y: 215, corridor: '京杭运河', status: 'normal' },
    { id: 'port-yangzhou', name: '扬州港', x: 535, y: 260, corridor: '京杭运河', status: 'normal' },
    { id: 'port-suzhou', name: '苏州港', x: 585, y: 315, corridor: '京杭运河', status: 'normal' },
    { id: 'port-hangzhou', name: '杭州港', x: 575, y: 350, corridor: '京杭运河', status: 'normal' },

    // 珠江水系节点
    { id: 'port-wuzhou', name: '梧州港', x: 260, y: 430, corridor: '珠江水系', status: 'busy' },
    { id: 'port-guangzhou', name: '广州港', x: 380, y: 440, corridor: '珠江水系', status: 'normal' },
    { id: 'port-foshan', name: '佛山港', x: 350, y: 450, corridor: '珠江水系', status: 'normal' }
  ];

  const MAP_LOCKS = [
    { id: 'lock-01', name: '三峡船闸', x: 220, y: 295, status: 'congested', queue: 42 },
    { id: 'lock-02', name: '葛洲坝', x: 235, y: 295, status: 'open', queue: 12 },
    { id: 'lock-03', name: '施桥船闸', x: 535, y: 270, status: 'open', queue: 18 },
    { id: 'lock-04', name: '桂平枢纽', x: 280, y: 430, status: 'congested', queue: 29 }
  ];

  // 计算估算航程与时间
  const calculateRouteDistance = (p1Id: string, p2Id: string) => {
    const p1 = MAP_PORTS.find((p) => p.id === p1Id);
    const p2 = MAP_PORTS.find((p) => p.id === p2Id);
    if (!p1 || !p2) return { distKm: 850, hours: 36, fuelTons: 6.2 };

    const dx = p1.x - p2.x;
    const dy = p1.y - p2.y;
    const pixelDist = Math.sqrt(dx * dx + dy * dy);
    const distKm = Math.round(pixelDist * 3.8);
    const avgSpeedKmH = 18; // ~10 knots
    const hours = Math.round((distKm / avgSpeedKmH) * 10) / 10;
    const fuelTons = Math.round((hours / 24) * 2.5 * 10) / 10;
    return { distKm, hours, fuelTons };
  };

  const routeCalc = calculateRouteDistance(calcStartPort, calcEndPort);

  return (
    <div className="h-full flex flex-col bg-slate-950 text-slate-100 font-sans overflow-hidden select-none">
      {/* 顶部图层与工具栏 */}
      <div className="p-3 bg-slate-900 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 shrink-0">
        <div className="flex items-center space-x-2">
          <Navigation className="w-5 h-5 text-cyan-400" />
          <h2 className="text-sm font-bold text-slate-100">中国内河主干航线与水网拓扑地图</h2>
          <span className="text-[10px] font-mono bg-cyan-950 text-cyan-400 px-2 py-0.5 rounded border border-cyan-800/50">
            Yangtze • Grand Canal • Pearl River
          </span>
        </div>

        {/* 图层开关控制 */}
        <div className="flex items-center space-x-3 text-xs">
          <label className="flex items-center space-x-1.5 cursor-pointer">
            <input
              type="checkbox"
              checked={showPorts}
              onChange={(e) => setShowPorts(e.target.checked)}
              className="rounded bg-slate-800 border-slate-700 text-cyan-500 focus:ring-0"
            />
            <span className="text-slate-300">枢纽港口 ({MAP_PORTS.length})</span>
          </label>

          <label className="flex items-center space-x-1.5 cursor-pointer">
            <input
              type="checkbox"
              checked={showLocks}
              onChange={(e) => setShowLocks(e.target.checked)}
              className="rounded bg-slate-800 border-slate-700 text-amber-500 focus:ring-0"
            />
            <span className="text-slate-300">船闸关隘</span>
          </label>

          <label className="flex items-center space-x-1.5 cursor-pointer">
            <input
              type="checkbox"
              checked={showVessels}
              onChange={(e) => setShowVessels(e.target.checked)}
              className="rounded bg-slate-800 border-slate-700 text-blue-500 focus:ring-0"
            />
            <span className="text-slate-300">在途船位</span>
          </label>

          <label className="flex items-center space-x-1.5 cursor-pointer">
            <input
              type="checkbox"
              checked={showCongestion}
              onChange={(e) => setShowCongestion(e.target.checked)}
              className="rounded bg-slate-800 border-slate-700 text-red-500 focus:ring-0"
            />
            <span className="text-slate-300">拥堵预警</span>
          </label>
        </div>
      </div>

      {/* 地图与侧边测算工具双栏 */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* SVG 水网矢量地图画布 */}
        <div className="flex-1 bg-slate-950 relative overflow-hidden flex items-center justify-center p-4">
          <svg
            viewBox="0 0 700 500"
            className="w-full h-full max-w-5xl max-h-[80vh] border border-slate-800/80 rounded-xl bg-slate-900/60 shadow-2xl"
          >
            <defs>
              {/* 水道渐变 */}
              <linearGradient id="yangtzeGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#0284c7" />
                <stop offset="50%" stopColor="#0369a1" />
                <stop offset="100%" stopColor="#0c4a6e" />
              </linearGradient>

              <linearGradient id="canalGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#0d9488" />
                <stop offset="100%" stopColor="#0f766e" />
              </linearGradient>

              {/* 节点发光 */}
              <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur stdDeviation="2" result="blur" />
                <feComposite in="SourceGraphic" in2="blur" operator="over" />
              </filter>
            </defs>

            {/* 背景网格线 */}
            <pattern id="grid" width="30" height="30" patternUnits="userSpaceOnUse">
              <path d="M 30 0 L 0 0 0 30" fill="none" stroke="#1e293b" strokeWidth="0.5" />
            </pattern>
            <rect width="700" height="500" fill="url(#grid)" />

            {/* 1. 长江干线主航道 (Heavy Blue Curve) */}
            <path
              d="M 140,310 C 200,300 220,295 250,295 C 300,295 330,310 350,310 C 380,310 400,315 410,315 C 440,315 470,300 490,300 C 510,300 515,280 520,280 C 540,280 580,310 620,310 L 670,315"
              fill="none"
              stroke="url(#yangtzeGrad)"
              strokeWidth="7"
              strokeLinecap="round"
              className="transition-all duration-500"
            />
            {/* 长江水流动态流动虚线 */}
            <path
              d="M 140,310 C 200,300 220,295 250,295 C 300,295 330,310 350,310 C 380,310 400,315 410,315 C 440,315 470,300 490,300 C 510,300 515,280 520,280 C 540,280 580,310 620,310 L 670,315"
              fill="none"
              stroke="#38bdf8"
              strokeWidth="2"
              strokeDasharray="8,12"
              className="animate-pulse"
            />

            {/* 2. 京杭运河航道 (Teal Vertical Curve) */}
            <path
              d="M 480,140 C 490,160 495,170 495,180 C 510,200 525,205 525,215 C 530,240 535,250 535,260 C 535,270 520,280 520,280 C 550,295 580,305 585,315 C 585,330 575,340 575,350"
              fill="none"
              stroke="url(#canalGrad)"
              strokeWidth="5"
              strokeLinecap="round"
            />

            {/* 3. 珠江水系航道 */}
            <path
              d="M 260,430 C 310,435 340,445 350,450 C 360,452 370,442 380,440 L 440,435"
              fill="none"
              stroke="#14b8a6"
              strokeWidth="5"
              strokeLinecap="round"
            />

            {/* 长江/运河文本标注 */}
            <text x="280" y="285" fill="#38bdf8" fontSize="10" fontWeight="bold" fontFamily="sans-serif">
              长江干线 (Yangtze Corridor)
            </text>
            <text x="430" y="150" fill="#14b8a6" fontSize="10" fontWeight="bold" fontFamily="sans-serif">
              京杭运河 (Grand Canal)
            </text>
            <text x="270" y="420" fill="#2dd4bf" fontSize="10" fontWeight="bold" fontFamily="sans-serif">
              西江-珠江水系 (Pearl River)
            </text>

            {/* 拥堵重灾区高亮 Circles */}
            {showCongestion && (
              <>
                <circle cx="220" cy="295" r="22" fill="#ef4444" fillOpacity="0.15" className="animate-ping" />
                <circle cx="140" cy="310" r="18" fill="#f59e0b" fillOpacity="0.2" />
              </>
            )}

            {/* 4. 船闸 Lock Markers */}
            {showLocks &&
              MAP_LOCKS.map((lock) => (
                <g
                  key={lock.id}
                  transform={`translate(${lock.x}, ${lock.y})`}
                  className="cursor-pointer hover:scale-125 transition-transform"
                  onClick={() => setSelectedMapNode({ type: 'lock', data: lock })}
                >
                  <rect
                    x="-8"
                    y="-8"
                    width="16"
                    height="16"
                    rx="3"
                    fill={lock.status === 'congested' ? '#ef4444' : '#f59e0b'}
                    stroke="#ffffff"
                    strokeWidth="1.5"
                  />
                  <text x="0" y="3" textAnchor="middle" fill="#ffffff" fontSize="8" fontWeight="bold">
                    闸
                  </text>
                  <text x="0" y="-12" textAnchor="middle" fill="#fca5a5" fontSize="8" fontWeight="bold">
                    {lock.name} ({lock.queue}艘排队)
                  </text>
                </g>
              ))}

            {/* 5. 港口 Port Markers */}
            {showPorts &&
              MAP_PORTS.map((port) => {
                const isSelected = selectedMapNode?.data?.id === port.id;
                return (
                  <g
                    key={port.id}
                    transform={`translate(${port.x}, ${port.y})`}
                    className="cursor-pointer group"
                    onClick={() => {
                      setSelectedMapNode({ type: 'port', data: port });
                      setSelectedPortId(port.id);
                    }}
                  >
                    <circle
                      r={isSelected ? '9' : '6'}
                      fill={port.status === 'congested' ? '#ef4444' : port.status === 'busy' ? '#f59e0b' : '#3b82f6'}
                      stroke="#ffffff"
                      strokeWidth="2"
                      filter="url(#glow)"
                      className="transition-all duration-300 group-hover:r-8"
                    />
                    <text
                      x="0"
                      y="18"
                      textAnchor="middle"
                      fill="#f8fafc"
                      fontSize="9"
                      fontWeight="bold"
                      className="drop-shadow-md select-none"
                    >
                      {port.name}
                    </text>
                  </g>
                );
              })}

            {/* 6. 在途船位 Marker (Simulated) */}
            {showVessels && (
              <g transform="translate(420, 315)" className="cursor-pointer animate-pulse">
                <circle r="5" fill="#10b981" stroke="#ffffff" strokeWidth="1.5" />
                <path d="M-3,-2 L4,0 L-3,2 Z" fill="#ffffff" />
                <text x="10" y="3" fill="#6ee7b7" fontSize="8" className="font-mono">
                  长江交运808 (78%)
                </text>
              </g>
            )}
          </svg>

          {/* 地图图例 Legend */}
          <div className="absolute bottom-6 left-6 bg-slate-900/90 border border-slate-800 backdrop-blur-md p-3 rounded-lg text-[11px] space-y-1.5 shadow-xl font-mono text-slate-300">
            <div className="font-bold text-slate-100 text-xs mb-1">地图图例与状态说明</div>
            <div className="flex items-center space-x-2">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-500" />
              <span>通畅枢纽港口</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
              <span>繁忙/靠泊排队</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500" />
              <span>船闸/港口预警拥堵</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="w-2.5 h-2.5 rounded bg-amber-500" />
              <span>内河主要船闸 (Lock)</span>
            </div>
          </div>
        </div>

        {/* 右侧：路线与航程测算工具 Drawer */}
        <div className="w-80 bg-slate-900 border-l border-slate-800 p-4 flex flex-col justify-between overflow-y-auto">
          <div className="space-y-4">
            <div className="flex items-center space-x-2 pb-2 border-b border-slate-800">
              <Compass className="w-4 h-4 text-cyan-400" />
              <h3 className="text-xs font-bold text-slate-100">航程与燃油预估测算器</h3>
            </div>

            {/* 测算 Form */}
            <div className="space-y-3">
              <div>
                <label className="text-[11px] text-slate-400 block mb-1">起运港 (Origin Port):</label>
                <select
                  value={calcStartPort}
                  onChange={(e) => setCalcStartPort(e.target.value)}
                  className="w-full bg-slate-950 text-slate-200 text-xs rounded border border-slate-700 p-2 focus:border-cyan-500"
                >
                  {MAP_PORTS.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.corridor})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[11px] text-slate-400 block mb-1">目的港 (Destination Port):</label>
                <select
                  value={calcEndPort}
                  onChange={(e) => setCalcEndPort(e.target.value)}
                  className="w-full bg-slate-950 text-slate-200 text-xs rounded border border-slate-700 p-2 focus:border-cyan-500"
                >
                  {MAP_PORTS.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.corridor})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* 测算结果 Card */}
            <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg space-y-2.5 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">估算航道里程:</span>
                <span className="font-mono text-cyan-300 font-bold">{routeCalc.distKm} 公里 (km)</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">估算标准航行时长:</span>
                <span className="font-mono text-emerald-400 font-bold">{routeCalc.hours} 小时 (~{Math.round(routeCalc.hours / 24 * 10) / 10} 天)</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">预估基础燃油消耗:</span>
                <span className="font-mono text-amber-300 font-bold">{routeCalc.fuelTons} 吨</span>
              </div>
              <div className="pt-2 border-t border-slate-800 text-[10px] text-slate-500 leading-relaxed">
                * 注：测算结果基于干线基准水流航速及平均负载计算，遇到船闸排队或枯水限深将自动延长。
              </div>
            </div>

            {/* 点击节点详情 Drawer Card */}
            {selectedMapNode && (
              <div className="p-3 bg-blue-950/40 border border-blue-500/30 rounded-lg space-y-2 text-xs">
                <div className="flex items-center justify-between font-bold text-blue-300">
                  <span>选中的水网节点: {selectedMapNode.data.name}</span>
                  <span className="text-[10px] font-mono px-1.5 py-0.5 bg-blue-900 rounded">
                    {selectedMapNode.type === 'port' ? '枢纽港' : '船闸关隘'}
                  </span>
                </div>

                {selectedMapNode.type === 'port' && (
                  <div className="space-y-1 text-slate-300 text-[11px]">
                    <p>所属水系: {selectedMapNode.data.corridor}</p>
                    <p>运营状态: <span className="text-emerald-400">{selectedMapNode.data.status}</span></p>
                    <button
                      onClick={() => setActiveView('port_operations')}
                      className="mt-2 w-full py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded font-medium text-xs transition"
                    >
                      查看港口码头与泊位计划 →
                    </button>
                  </div>
                )}

                {selectedMapNode.type === 'lock' && (
                  <div className="space-y-1 text-slate-300 text-[11px]">
                    <p>当前排队艘数: <span className="text-amber-400 font-bold">{selectedMapNode.data.queue} 艘</span></p>
                    <p>通航状态: {selectedMapNode.data.status === 'congested' ? '拥堵限速' : '正常通行'}</p>
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="pt-4 border-t border-slate-800 text-[10px] text-slate-500 font-mono">
            中国内河航道图层数据库 v3.6
          </div>
        </div>
      </div>
    </div>
  );
};
