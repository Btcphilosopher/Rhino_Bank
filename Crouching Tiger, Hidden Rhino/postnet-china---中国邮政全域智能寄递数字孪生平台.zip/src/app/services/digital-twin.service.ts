import { Injectable, signal, computed, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';

export interface ParcelTwin {
  tracking_id: string;
  service_type: '特快专递 (EMS)' | '标快包裹' | '农产品直邮' | '国际邮件' | '冷链快递';
  origin: string;
  destination: string;
  weight_kg: number;
  volume_m3: number;
  declared_value_yuan: number;
  sender_name: string;
  receiver_name: string;
  current_node: string;
  next_node: string;
  status: '待揽收' | '已揽收' | '运输中' | '到达处理中心' | '分拣中' | '干线运输' | '到达末端网点' | '派送中' | '自提' | '已签收' | '异常';
  priority: 'URGENT' | 'HIGH' | 'NORMAL';
  deadline_timestamp: string;
  transport_mode: 'AIR' | 'HIGHWAY' | 'RAIL' | 'DRONE' | 'AUTONOMOUS';
  lat: number;
  lng: number;
  eta: string;
  delay_probability_pct: number;
}

export interface FacilityNode {
  id: string;
  name: string;
  level: 'PROCESSING_CENTER' | 'COUNTY_CENTER' | 'TOWNSHIP_CENTER' | 'VILLAGE_STATION' | 'POST_OFFICE' | 'LOCKER';
  province: string;
  city: string;
  lat: number;
  lng: number;
  status: 'NORMAL' | 'CONGESTED' | 'DISRUPTED';
  hourly_volume: number;
  capacity: number;
  agv_count: number;
  conveyor_speed_m_s: number;
  utilization_pct: number;
}

export interface CourierTwin {
  courier_id: string;
  name: string;
  phone: string;
  vehicle_type: '新能源三轮车' | '无人配售车' | '轻型货车' | '无人机';
  current_lat: number;
  current_lng: number;
  parcel_count: number;
  remaining_stops: number;
  working_time_hrs: number;
  status: '待出发' | '配送中' | '暂停' | '返回' | '异常' | '完成';
  assigned_route_id: string;
}

export interface OptimizationResult {
  provenance: string;
  engine: string;
  status: string;
  algorithm: string;
  objective: string;
  objective_value: number;
  summary: {
    before_distance_km: number;
    after_distance_km: number;
    distance_savings_pct: number;
    before_time_mins: number;
    after_time_mins: number;
    time_savings_pct: number;
    vehicles_used: number;
    co2_reduction_kg: number;
    empty_mileage_pct: number;
  };
  routes: Record<string, unknown>[];
}

@Injectable({
  providedIn: 'root'
})
export class DigitalTwinService {
  private http = inject(HttpClient);

  // Active View Tab State
  activeTab = signal<'command-center' | 'gis-map' | 'processing-center' | 'transport' | 'last-mile' | 'rural' | 'unmanned' | 'r-lab' | 'ai-assistant' | 'scenario-lab' | 'mobile'>('command-center');

  // Time Machine Replay Hour ('08:00', '10:00', '12:00', '14:00', '16:00', '18:00', '20:00')
  timeMachineHour = signal<string>('14:00');

  // Global Filter Signals
  parcelFilter = signal<string>('ALL');

  // Loading indicator
  isOptimizing = signal<boolean>(false);

  // Core KPIs Signal
  kpis = signal({
    today_received_volume: 184520900,
    today_delivered_volume: 162980400,
    in_transit_volume: 48920150,
    sorting_throughput_hourly: 14200000,
    avg_processing_time_mins: 18.4,
    avg_transit_time_hrs: 14.2,
    last_mile_delivery_rate_pct: 98.76,
    exceptions_count: 3120,
    vehicle_utilization_pct: 88.4,
    air_capacity_utilization_pct: 92.1,
    rail_capacity_utilization_pct: 84.6,
  });

  // Simulated Parcels List
  parcels = signal<ParcelTwin[]>([
    {
      tracking_id: '1100982301982',
      service_type: '特快专递 (EMS)',
      origin: '上海华东处理中心',
      destination: '北京朝阳区CBD网点',
      weight_kg: 2.4,
      volume_m3: 0.012,
      declared_value_yuan: 1850,
      sender_name: '张三 (上海西门子)',
      receiver_name: '李四 (北京国贸)',
      current_node: 'PC-SHANGHAI-01',
      next_node: 'PC-BEIJING-01',
      status: '干线运输',
      priority: 'URGENT',
      deadline_timestamp: '2026-09-18 18:00',
      transport_mode: 'AIR',
      lat: 35.8617,
      lng: 118.9501,
      eta: '今日 16:30',
      delay_probability_pct: 4.2
    },
    {
      tracking_id: '1100982301983',
      service_type: '农产品直邮',
      origin: '浙江桐庐县分水镇',
      destination: '杭州西湖区求是社区',
      weight_kg: 10.0,
      volume_m3: 0.045,
      declared_value_yuan: 320,
      sender_name: '王五 (桐庐高山高笋专业合作社)',
      receiver_name: '赵六 (杭州)',
      current_node: 'TOWN-201',
      next_node: 'PC-SHANGHAI-01',
      status: '分拣中',
      priority: 'HIGH',
      deadline_timestamp: '2026-09-18 20:00',
      transport_mode: 'HIGHWAY',
      lat: 29.8732,
      lng: 119.5211,
      eta: '今日 17:15',
      delay_probability_pct: 2.1
    },
    {
      tracking_id: '1100982301984',
      service_type: '冷链快递',
      origin: '山东烟台网点',
      destination: '江苏南京新街口自提点',
      weight_kg: 5.5,
      volume_m3: 0.022,
      declared_value_yuan: 980,
      sender_name: '烟台大樱桃直营部',
      receiver_name: '钱七 (南京)',
      current_node: 'PC-BEIJING-01',
      next_node: 'PC-SHANGHAI-01',
      status: '到达处理中心',
      priority: 'URGENT',
      deadline_timestamp: '2026-09-18 15:00',
      transport_mode: 'HIGHWAY',
      lat: 39.9042,
      lng: 116.4074,
      eta: '今日 14:50',
      delay_probability_pct: 28.5
    },
    {
      tracking_id: '1100982301985',
      service_type: '标快包裹',
      origin: '广东广州集散中心',
      destination: '四川成都武侯区网点',
      weight_kg: 1.2,
      volume_m3: 0.005,
      declared_value_yuan: 150,
      sender_name: '广州服装批发',
      receiver_name: '孙八 (成都)',
      current_node: 'PC-GUANGZHOU-01',
      next_node: 'PC-CHONGQING-01',
      status: '运输中',
      priority: 'NORMAL',
      deadline_timestamp: '2026-09-19 12:00',
      transport_mode: 'RAIL',
      lat: 26.5823,
      lng: 110.2938,
      eta: '明日 09:10',
      delay_probability_pct: 1.5
    },
    {
      tracking_id: '1100982301986',
      service_type: '特快专递 (EMS)',
      origin: '浙江桐庐分水镇新农村站点',
      destination: '桐庐深山百江村',
      weight_kg: 0.8,
      volume_m3: 0.003,
      declared_value_yuan: 450,
      sender_name: '县医院药房',
      receiver_name: '老张 (百江村)',
      current_node: 'VILLAGE-301',
      next_node: 'VILLAGE-302',
      status: '派送中',
      priority: 'URGENT',
      deadline_timestamp: '2026-09-18 15:30',
      transport_mode: 'DRONE',
      lat: 29.9102,
      lng: 119.4891,
      eta: '今日 14:15',
      delay_probability_pct: 0.8
    }
  ]);

  // Facilities List Signal
  facilities = signal<FacilityNode[]>([
    { id: 'PC-SHANGHAI-01', name: '华东上海邮件处理中心', level: 'PROCESSING_CENTER', province: '上海市', city: '上海市', lat: 31.2304, lng: 121.4737, status: 'NORMAL', hourly_volume: 380000, capacity: 450000, agv_count: 180, conveyor_speed_m_s: 2.5, utilization_pct: 84.4 },
    { id: 'PC-BEIJING-01', name: '华北北京航空邮件处理中心', level: 'PROCESSING_CENTER', province: '北京市', city: '北京市', lat: 39.9042, lng: 116.4074, status: 'CONGESTED', hourly_volume: 420000, capacity: 420000, agv_count: 220, conveyor_speed_m_s: 2.2, utilization_pct: 100.0 },
    { id: 'PC-GUANGZHOU-01', name: '华南广州智能邮件集散中心', level: 'PROCESSING_CENTER', province: '广东省', city: '广州市', lat: 23.1291, lng: 113.2644, status: 'NORMAL', hourly_volume: 350000, capacity: 400000, agv_count: 160, conveyor_speed_m_s: 2.8, utilization_pct: 87.5 },
    { id: 'PC-CHONGQING-01', name: '西南重庆陆港邮件枢纽', level: 'PROCESSING_CENTER', province: '重庆市', city: '重庆市', lat: 29.5630, lng: 106.5516, status: 'NORMAL', hourly_volume: 210000, capacity: 280000, agv_count: 120, conveyor_speed_m_s: 2.4, utilization_pct: 75.0 },
    { id: 'PC-WUHAN-01', name: '华中武汉转运中心', level: 'PROCESSING_CENTER', province: '湖北省', city: '武汉市', lat: 30.5928, lng: 114.3055, status: 'NORMAL', hourly_volume: 290000, capacity: 340000, agv_count: 150, conveyor_speed_m_s: 2.6, utilization_pct: 85.3 }
  ]);

  // Couriers Signal
  couriers = signal<CourierTwin[]>([
    { courier_id: 'COU-1001', name: '王敏 (工号 88102)', phone: '138****9120', vehicle_type: '新能源三轮车', current_lat: 31.2312, current_lng: 121.4745, parcel_count: 42, remaining_stops: 12, working_time_hrs: 5.2, status: '配送中', assigned_route_id: 'RUT-R-1' },
    { courier_id: 'COU-1002', name: '陈强 (工号 88103)', phone: '139****1823', vehicle_type: '无人配售车', current_lat: 31.2289, current_lng: 121.4690, parcel_count: 65, remaining_stops: 18, working_time_hrs: 4.8, status: '配送中', assigned_route_id: 'RUT-R-2' },
    { courier_id: 'COU-1003', name: '刘洋 (工号 88104)', phone: '137****4491', vehicle_type: '轻型货车', current_lat: 31.2355, current_lng: 121.4810, parcel_count: 110, remaining_stops: 25, working_time_hrs: 6.1, status: '配送中', assigned_route_id: 'RUT-R-3' },
    { courier_id: 'COU-1004', name: '无人机 邮航-UAV-09', phone: '网点遥控哨所', vehicle_type: '无人机', current_lat: 29.9102, current_lng: 119.4891, parcel_count: 2, remaining_stops: 1, working_time_hrs: 1.5, status: '配送中', assigned_route_id: 'RUT-UAV-09' }
  ]);

  // Last R Optimization Result Signal
  lastOptimizationResult = signal<OptimizationResult | null>(null);

  // Selected Parcel Signal
  selectedParcel = signal<ParcelTwin | null>(null);

  // Filtered Parcels Computed
  filteredParcels = computed(() => {
    const filter = this.parcelFilter();
    const list = this.parcels();
    if (filter === 'ALL') return list;
    if (filter === 'TRANSIT') return list.filter(p => p.status === '运输中' || p.status === '干线运输');
    if (filter === 'EXCEPTION') return list.filter(p => p.status === '异常' || p.delay_probability_pct > 20);
    if (filter === 'URGENT') return list.filter(p => p.priority === 'URGENT');
    if (filter === 'RURAL') return list.filter(p => p.service_type === '农产品直邮' || p.transport_mode === 'DRONE');
    return list;
  });

  // Call R VRPTW Optimizer API
  async runVRPOptimization(customersCount = 30, vehicleCount = 6): Promise<OptimizationResult> {
    this.isOptimizing.set(true);
    try {
      const res = await firstValueFrom(this.http.post<OptimizationResult>('/api/r/route/optimize', {
        customers: Array.from({ length: customersCount }, (_, i) => ({
          cust_id: i + 1,
          x: 121.47 + (Math.random() - 0.5) * 0.1,
          y: 31.23 + (Math.random() - 0.5) * 0.1,
          demand_volume: +(0.1 + Math.random() * 0.6).toFixed(2),
          demand_weight: +(0.5 + Math.random() * 2.5).toFixed(2),
          window_start: Math.floor(Math.random() * 120),
          window_end: 240 + Math.floor(Math.random() * 240),
          service_time: 5,
        })),
        vehicles: Array.from({ length: vehicleCount }, (_, i) => ({
          vehicle_id: `VEH-EV-${101 + i}`,
          capacity_volume: 5.0,
          capacity_weight: 50.0,
          shift_max_time: 480,
        })),
        depot: { x: 121.47, y: 31.23 },
      }));
      this.lastOptimizationResult.set(res);
      return res;
    } finally {
      this.isOptimizing.set(false);
    }
  }

  // Call Gemini AI Assistant API
  async queryAIAssistant(prompt: string): Promise<string> {
    const res = await firstValueFrom(this.http.post<{ answer: string }>('/api/gemini/assistant', {
      prompt,
      contextState: this.kpis(),
    }));
    return res.answer;
  }

  // Call R Simulation API
  async runQueueingSimulation(arrival_rate: number, service_rate: number, num_channels: number) {
    return await firstValueFrom(this.http.post<Record<string, unknown>>('/api/r/simulation', {
      arrival_rate,
      service_rate,
      num_channels,
    }));
  }

  // Call R Facility Location API
  async runLockerLocationOptimization(max_lockers: number) {
    return await firstValueFrom(this.http.post<Record<string, unknown>>('/api/r/facility/optimize', {
      max_lockers,
    }));
  }
}
