import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../services/digital-twin.service';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="bg-slate-900 border-b border-emerald-500/20 text-white shadow-xl sticky top-0 z-50">
      <!-- Top Branding & Status Bar -->
      <div class="max-w-7xl mx-auto px-4 py-2.5 flex flex-wrap items-center justify-between gap-3">
        <!-- Logo & Title -->
        <div class="flex items-center space-x-3">
          <div class="bg-gradient-to-br from-emerald-500 to-green-600 text-slate-950 p-2 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-500/20 font-bold">
            <mat-icon class="text-slate-950">hub</mat-icon>
          </div>
          <div>
            <div class="flex items-center space-x-2">
              <h1 class="text-base md:text-lg font-bold tracking-tight text-emerald-400">
                POSTNET CHINA
              </h1>
              <span class="bg-emerald-950/80 text-emerald-300 border border-emerald-500/30 text-[10px] font-semibold px-2 py-0.5 rounded-full">
                [SIMULATION DATA]
              </span>
            </div>
            <p class="text-xs text-slate-400 font-medium hidden sm:block">
              中国邮政全域智能寄递与末端物流数字孪生平台 (R-Optimized Twin)
            </p>
          </div>
        </div>

        <!-- Time Machine & Simulation Controllers -->
        <div class="flex items-center space-x-2 text-xs">
          <!-- Time Machine Replay Selector -->
          <div class="flex items-center bg-slate-800/80 border border-slate-700/80 rounded-xl px-2.5 py-1 text-slate-300 space-x-1.5">
            <mat-icon class="text-emerald-400 text-sm">schedule</mat-icon>
            <span class="text-slate-400 font-mono text-[11px]">数字孪生时光机:</span>
            <select 
              [value]="dtService.timeMachineHour()" 
              (change)="onTimeMachineChange($event)"
              class="bg-slate-900 border border-slate-700 rounded text-emerald-300 px-1.5 py-0.5 text-xs font-mono focus:outline-none focus:border-emerald-500 cursor-pointer">
              <option value="08:00">08:00 早间集配</option>
              <option value="10:00">10:00 第一次分拣</option>
              <option value="12:00">12:00 午间干线</option>
              <option value="14:00">14:00 实时监控 (当前)</option>
              <option value="16:00">16:00 末端派送高峰</option>
              <option value="18:00">18:00 签收归档</option>
            </select>
          </div>

          <!-- Network Operational Status Pill -->
          <div class="hidden lg:flex items-center space-x-1.5 bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 px-2.5 py-1 rounded-xl">
            <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span class="font-semibold text-[11px]">全国网络节点: 1,240 运行中</span>
          </div>
        </div>
      </div>

      <!-- Navigation Tabs Bar -->
      <nav class="bg-slate-950/90 border-t border-slate-800/80 overflow-x-auto">
        <div class="max-w-7xl mx-auto px-4 flex space-x-1 min-w-max text-xs font-medium py-1">
          <button
            (click)="setTab('command-center')"
            [class]="getTabClass('command-center')"
            class="flex items-center space-x-1.5 px-3 py-2 rounded-lg transition-all duration-200">
            <mat-icon class="text-base">dashboard</mat-icon>
            <span>全国控制塔</span>
          </button>

          <button
            (click)="setTab('gis-map')"
            [class]="getTabClass('gis-map')"
            class="flex items-center space-x-1.5 px-3 py-2 rounded-lg transition-all duration-200">
            <mat-icon class="text-base">map</mat-icon>
            <span>全国邮政GIS</span>
          </button>

          <button
            (click)="setTab('processing-center')"
            [class]="getTabClass('processing-center')"
            class="flex items-center space-x-1.5 px-3 py-2 rounded-lg transition-all duration-200">
            <mat-icon class="text-base">precision_manufacturing</mat-icon>
            <span>3D智慧处理中心</span>
          </button>

          <button
            (click)="setTab('last-mile')"
            [class]="getTabClass('last-mile')"
            class="flex items-center space-x-1.5 px-3 py-2 rounded-lg transition-all duration-200">
            <mat-icon class="text-base">local_shipping</mat-icon>
            <span>末端配送控制中心</span>
          </button>

          <button
            (click)="setTab('rural')"
            [class]="getTabClass('rural')"
            class="flex items-center space-x-1.5 px-3 py-2 rounded-lg transition-all duration-200">
            <mat-icon class="text-base">cottage</mat-icon>
            <span>农村三级物流优化</span>
          </button>

          <button
            (click)="setTab('unmanned')"
            [class]="getTabClass('unmanned')"
            class="flex items-center space-x-1.5 px-3 py-2 rounded-lg transition-all duration-200">
            <mat-icon class="text-base">flight_takeoff</mat-icon>
            <span>无人车/无人机</span>
          </button>

          <button
            (click)="setTab('r-lab')"
            [class]="getTabClass('r-lab')"
            class="flex items-center space-x-1.5 px-3 py-2 rounded-lg transition-all duration-200">
            <mat-icon class="text-base">analytics</mat-icon>
            <span>R优化实验室</span>
          </button>

          <button
            (click)="setTab('ai-assistant')"
            [class]="getTabClass('ai-assistant')"
            class="flex items-center space-x-1.5 px-3 py-2 rounded-lg transition-all duration-200">
            <mat-icon class="text-base text-amber-400">smart_toy</mat-icon>
            <span>邮政AI助手</span>
          </button>

          <button
            (click)="setTab('scenario-lab')"
            [class]="getTabClass('scenario-lab')"
            class="flex items-center space-x-1.5 px-3 py-2 rounded-lg transition-all duration-200">
            <mat-icon class="text-base">science</mat-icon>
            <span>战略仿真实验室</span>
          </button>

          <button
            (click)="setTab('mobile')"
            [class]="getTabClass('mobile')"
            class="flex items-center space-x-1.5 px-3 py-2 rounded-lg transition-all duration-200">
            <mat-icon class="text-base">smartphone</mat-icon>
            <span>移动端App模拟</span>
          </button>
        </div>
      </nav>
    </header>
  `
})
export class HeaderComponent {
  dtService = inject(DigitalTwinService);

  setTab(tab: 'command-center' | 'gis-map' | 'processing-center' | 'transport' | 'last-mile' | 'rural' | 'unmanned' | 'r-lab' | 'ai-assistant' | 'scenario-lab' | 'mobile') {
    this.dtService.activeTab.set(tab);
  }

  getTabClass(tab: string) {
    if (this.dtService.activeTab() === tab) {
      return 'bg-emerald-600/30 text-emerald-300 border border-emerald-500/50 font-bold shadow-inner';
    }
    return 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50';
  }

  onTimeMachineChange(event: Event) {
    const val = (event.target as HTMLSelectElement).value;
    this.dtService.timeMachineHour.set(val);
  }
}
