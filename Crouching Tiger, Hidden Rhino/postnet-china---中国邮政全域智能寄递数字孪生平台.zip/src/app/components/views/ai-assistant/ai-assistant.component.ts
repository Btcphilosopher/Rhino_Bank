import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../../services/digital-twin.service';

export interface ChatMessage {
  sender: 'USER' | 'AI';
  text: string;
  timestamp: string;
}

@Component({
  selector: 'app-ai-assistant',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-4 md:p-6 bg-slate-950 min-h-screen text-slate-100 space-y-6">
      <!-- Title Header -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex items-center justify-between">
        <div>
          <div class="flex items-center space-x-2">
            <h2 class="text-base font-bold text-amber-400 flex items-center space-x-2">
              <mat-icon class="text-amber-400">smart_toy</mat-icon>
              <span>中国邮政智能运营助手 (AI Postal Assistant - Gemini Powered)</span>
            </h2>
            <span class="bg-amber-950 text-amber-300 border border-amber-800 text-[10px] font-semibold px-2 py-0.5 rounded-full">
              Gemini 3.8 Flash + R Twin Context
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-0.5">
            融合数字孪生实时 KPI、瓶颈诊断与 R 语言运筹学算法的邮政智能交互大脑
          </p>
        </div>
      </div>

      <!-- Main Chat Area -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Preset Quick Questions -->
        <div class="lg:col-span-4 space-y-4">
          <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3">
            <div class="text-sm font-semibold text-emerald-400 border-b border-slate-800 pb-2 flex items-center space-x-1.5">
              <mat-icon class="text-base">tips_and_updates</mat-icon>
              <span>快速运维提问 (Preset Prompts)</span>
            </div>

            <div class="space-y-2 text-xs">
              <button 
                (click)="sendPresetPrompt('今天哪个处理中心最拥堵？应该如何执行 R 算法分流？')"
                class="w-full text-left bg-slate-950 hover:bg-slate-800 p-2.5 rounded-xl border border-slate-800 transition-all text-slate-300">
                👉 今天哪个处理中心最拥堵？应该如何分流？
              </button>

              <button 
                (click)="sendPresetPrompt('请帮我优化浙江桐庐县最后一公里配送线路与空载率')"
                class="w-full text-left bg-slate-950 hover:bg-slate-800 p-2.5 rounded-xl border border-slate-800 transition-all text-slate-300">
                👉 请帮我优化浙江桐庐县最后一公里配送线路
              </button>

              <button 
                (click)="sendPresetPrompt('如果北京航空邮件处理中心因大雾停运 6 小时，对全国网络有什么影响？')"
                class="w-full text-left bg-slate-950 hover:bg-slate-800 p-2.5 rounded-xl border border-slate-800 transition-all text-slate-300">
                👉 如果北京航空中心停运6小时，网络受损评估？
              </button>

              <button 
                (click)="sendPresetPrompt('分析全国多式联运运力利用率与绿色低碳减排潜能')"
                class="w-full text-left bg-slate-950 hover:bg-slate-800 p-2.5 rounded-xl border border-slate-800 transition-all text-slate-300">
                👉 分析多式联运利用率与低碳减排潜能
              </button>
            </div>
          </div>
        </div>

        <!-- Interactive Chat Window -->
        <div class="lg:col-span-8 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between min-h-[520px] space-y-4">
          <!-- Messages Box -->
          <div class="space-y-3 max-h-[420px] overflow-y-auto pr-2">
            @for (msg of messages(); track msg.timestamp) {
              <div [class]="msg.sender === 'USER' ? 'flex justify-end' : 'flex justify-start'">
                <div 
                  [class]="msg.sender === 'USER' ? 'bg-emerald-600 text-slate-950 font-medium' : 'bg-slate-950 text-slate-200 border border-slate-800'"
                  class="max-w-[85%] p-3.5 rounded-2xl text-xs space-y-1 shadow-lg">
                  <div class="flex items-center justify-between text-[10px] opacity-80 pb-1 border-b border-white/10 font-mono">
                    <span>{{ msg.sender === 'USER' ? '运营工程师' : 'POSTNET AI 智能运营助手' }}</span>
                    <span>{{ msg.timestamp }}</span>
                  </div>
                  <div class="whitespace-pre-wrap leading-relaxed">{{ msg.text }}</div>
                </div>
              </div>
            }

            @if (isThinking()) {
              <div class="flex justify-start">
                <div class="bg-slate-950 text-slate-400 border border-slate-800 p-3 rounded-2xl text-xs flex items-center space-x-2">
                  <mat-icon class="text-amber-400 animate-spin text-sm">sync</mat-icon>
                  <span>AI 正在调阅 POSTNET CHINA 数字孪生与 R 算法引擎数据...</span>
                </div>
              </div>
            }
          </div>

          <!-- Input Bar -->
          <div class="flex items-center space-x-2 pt-2 border-t border-slate-800">
            <input 
              [(ngModel)]="userInput"
              (keyup.enter)="sendMessage()"
              placeholder="请输入有关邮政网络运营、分流策略、R算法调优的问题..."
              class="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-emerald-500">
            <button 
              (click)="sendMessage()"
              [disabled]="isThinking() || !userInput.trim()"
              class="bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-slate-950 font-bold px-4 py-2.5 rounded-xl text-xs transition-all flex items-center space-x-1">
              <span>发送</span>
              <mat-icon class="text-sm">send</mat-icon>
            </button>
          </div>
        </div>
      </div>
    </div>
  `
})
export class AiAssistantComponent {
  dtService = inject(DigitalTwinService);

  userInput = '';
  isThinking = signal<boolean>(false);

  messages = signal<ChatMessage[]>([
    {
      sender: 'AI',
      text: '您好！我是 POSTNET CHINA 邮政智能运营助手。我可以为您实时分析全国 1,240 个网点的运作负荷、解释 R 语言运筹学 VRPTW/排队论算法输出，并提供应对天气或网络故障的动态重排方案。请问有什么可以帮助您？',
      timestamp: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' }),
    }
  ]);

  async sendMessage() {
    if (!this.userInput.trim() || this.isThinking()) return;
    const text = this.userInput.trim();
    this.userInput = '';

    const userMsg: ChatMessage = {
      sender: 'USER',
      text,
      timestamp: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' }),
    };

    this.messages.update(prev => [...prev, userMsg]);
    this.isThinking.set(true);

    try {
      const answer = await this.dtService.queryAIAssistant(text);
      const aiMsg: ChatMessage = {
        sender: 'AI',
        text: answer,
        timestamp: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' }),
      };
      this.messages.update(prev => [...prev, aiMsg]);
    } catch (e) {
      console.error(e);
    } finally {
      this.isThinking.set(false);
    }
  }

  sendPresetPrompt(prompt: string) {
    this.userInput = prompt;
    this.sendMessage();
  }
}
