import { Component, ChangeDetectionStrategy, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-scenario-lab',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-4 md:p-6 bg-slate-950 min-h-screen text-slate-100 space-y-6">
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 class="text-base font-bold text-emerald-400 flex items-center space-x-2">
            <mat-icon class="text-emerald-400">science</mat-icon>
            <span>战略仿真实验室与网络弹性模拟器 (Scenario Lab & Resilience Simulator)</span>
          </h2>
          <p class="text-xs text-slate-400 mt-0.5">
            针对旺季 Peak Season (+200%件量)、极端天气断路、极端大雾机场关闭等极端情境演练
          </p>
        </div>
      </div>

      <!-- Scenarios Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Scenario 1: Peak Season Pressure Test -->
        <div class="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3">
          <div class="text-sm font-semibold text-amber-400 border-b border-slate-800 pb-2 flex items-center justify-between">
            <span class="flex items-center space-x-1.5">
              <mat-icon class="text-base">auto_graph</mat-icon>
              <span>1. 业务高峰压力测试 (旺季 +200% 件量)</span>
            </span>
          </div>

          <div class="space-y-3 text-xs">
            <p class="text-slate-400">
              模拟双11或春节大促期间，全网日均件量飙升至 5.2 亿件时的各枢纽排队溢出与运力缺口。
            </p>

            <button 
              (click)="runPeakTest()"
              class="w-full bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold py-2 rounded-xl text-xs transition-all">
              模拟业务高峰压力测试
            </button>

            @if (peakResult()) {
              <div class="bg-slate-950 p-3 rounded-xl border border-amber-500/40 space-y-1 font-mono">
                <div class="text-amber-300 font-bold">压力测试结论:</div>
                <div class="text-slate-300">· 华北北京中心预计在16:00发生严重的35,000件积压</div>
                <div class="text-emerald-400">· 建议调用 R 分流算法，启动天津与石家庄分拨中心分流22%流量</div>
              </div>
            }
          </div>
        </div>

        <!-- Scenario 2: Network Resilience Disruption Simulation -->
        <div class="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3">
          <div class="text-sm font-semibold text-rose-400 border-b border-slate-800 pb-2 flex items-center justify-between">
            <span class="flex items-center space-x-1.5">
              <mat-icon class="text-base">error</mat-icon>
              <span>2. 节点失效抗摧毁弹性演练 (Resilience Test)</span>
            </span>
          </div>

          <div class="space-y-3 text-xs">
            <p class="text-slate-400">
              模拟因极端天气（如台风降雨）导致核心枢纽或干线通道中断时，网络的自愈能力。
            </p>

            <button 
              (click)="runDisruptionTest()"
              class="w-full bg-rose-600 hover:bg-rose-500 text-slate-100 font-bold py-2 rounded-xl text-xs transition-all">
              演练模拟: 关闭北京航空枢纽 6 小时
            </button>

            @if (disruptionResult()) {
              <div class="bg-slate-950 p-3 rounded-xl border border-rose-500/40 space-y-1 font-mono">
                <div class="text-rose-300 font-bold">网络自愈与重排方案:</div>
                <div class="text-slate-300">· 自动启用京沪高铁极速专列替代 18 个航空班次</div>
                <div class="text-emerald-400">· 邮件全程平均延迟控制在 1.8 小时以内，无丢失隐患</div>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `
})
export class ScenarioLabComponent {
  peakResult = signal<boolean>(false);
  disruptionResult = signal<boolean>(false);

  runPeakTest() {
    this.peakResult.set(true);
  }

  runDisruptionTest() {
    this.disruptionResult.set(true);
  }
}
