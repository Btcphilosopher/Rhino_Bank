import { Component, ChangeDetectionStrategy, inject, signal, ElementRef, ViewChild, AfterViewInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../../services/digital-twin.service';
import * as THREE from 'three';

interface QueueingTimelineItem {
  hour: string;
  volume: number;
  utilization_pct: number;
  avg_delay_mins: number;
  overflow_risk: string;
}

interface QueueingSimResult {
  utilization_pct: number;
  avg_queue_wait_mins: number;
  is_bottleneck: boolean;
  timeline: QueueingTimelineItem[];
}

@Component({
  selector: 'app-processing-center',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-4 md:p-6 bg-slate-950 min-h-screen text-slate-100 space-y-6">
      <!-- Top Title Bar -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <div class="flex items-center space-x-2">
            <h2 class="text-base font-bold text-emerald-400">
              华东上海邮件处理中心 — 3D数字孪生与排队仿真
            </h2>
            <span class="bg-emerald-950 text-emerald-300 border border-emerald-800 text-[10px] font-semibold px-2 py-0.5 rounded-full">
              全局ID: PC-SHANGHAI-01
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-0.5">
            中国邮政新一代5G+AGV自动化智慧矩阵 (卸车 → 扫码 → 识别 → 分拣 → 集包 → 装车)
          </p>
        </div>

        <!-- Run R Queueing Simulation Button -->
        <button 
          (click)="runQueueSimulation()" 
          [disabled]="isLoadingSim()"
          class="bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-slate-950 font-bold px-4 py-2 rounded-xl text-xs transition-all flex items-center space-x-1.5 shadow-lg shadow-emerald-600/20">
          <mat-icon class="text-sm">play_arrow</mat-icon>
          <span>{{ isLoadingSim() ? 'R仿真计算中...' : '运行 R 语言 M/M/c 排队论仿真' }}</span>
        </button>
      </div>

      <!-- Main Layout: Left (3D Sorting Hub Model), Right (Flow Metrics & R Queueing Output) -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- 3D Sorting Center Canvas (Section 6 & 45) -->
        <div class="lg:col-span-8 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between relative overflow-hidden min-h-[550px]">
          <div class="flex items-center justify-between z-10 bg-slate-950/80 backdrop-blur border border-slate-800 p-2.5 rounded-xl text-xs">
            <div class="flex items-center space-x-2">
              <span class="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></span>
              <span class="font-bold text-slate-200">处理中心 3D 实时数字孪生车间</span>
            </div>
            <div class="flex items-center space-x-3 text-[11px]">
              <span class="text-emerald-400">AGV 巡航: 180台</span>
              <span class="text-cyan-400">分拣格口: 1,200个</span>
              <span class="text-amber-400">传送带: 2.5 m/s</span>
            </div>
          </div>

          <!-- Canvas Container -->
          <div #canvasContainer class="absolute inset-0 w-full h-full rounded-2xl"></div>

          <!-- Bottom Stage Step Indicators -->
          <div class="z-10 bg-slate-950/90 border border-slate-800 p-3 rounded-xl backdrop-blur grid grid-cols-2 sm:grid-cols-6 gap-2 text-center text-xs">
            <div class="bg-slate-900 p-1.5 rounded-lg border border-slate-800">
              <div class="text-[10px] text-slate-400">阶段 1</div>
              <div class="font-bold text-slate-200">卸车区</div>
            </div>
            <div class="bg-slate-900 p-1.5 rounded-lg border border-slate-800">
              <div class="text-[10px] text-slate-400">阶段 2</div>
              <div class="font-bold text-emerald-400">称重扫码</div>
            </div>
            <div class="bg-slate-900 p-1.5 rounded-lg border border-slate-800">
              <div class="text-[10px] text-slate-400">阶段 3</div>
              <div class="font-bold text-cyan-400">OCR识别</div>
            </div>
            <div class="bg-slate-900 p-1.5 rounded-lg border border-slate-800">
              <div class="text-[10px] text-slate-400">阶段 4</div>
              <div class="font-bold text-amber-400">AGV矩阵分拣</div>
            </div>
            <div class="bg-slate-900 p-1.5 rounded-lg border border-slate-800">
              <div class="text-[10px] text-slate-400">阶段 5</div>
              <div class="font-bold text-indigo-400">自动集包</div>
            </div>
            <div class="bg-slate-900 p-1.5 rounded-lg border border-slate-800">
              <div class="text-[10px] text-slate-400">阶段 6</div>
              <div class="font-bold text-emerald-300">装车区</div>
            </div>
          </div>
        </div>

        <!-- Right Side: R Queueing Theory Simulation & Conveyor Telemetry (Section 32 & 33) -->
        <div class="lg:col-span-4 space-y-4">
          <!-- Queueing Simulation Results Box -->
          <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3">
            <div class="flex items-center justify-between text-sm font-semibold text-emerald-400 border-b border-slate-800 pb-2">
              <span class="flex items-center space-x-1.5">
                <mat-icon class="text-base">table_rows</mat-icon>
                <span>R 语言 M/M/c 排队论仿真结果</span>
              </span>
              <span class="text-xs text-slate-400 font-mono">r/simulation/queueing.R</span>
            </div>

            @if (simResult(); as sim) {
              <div class="space-y-3 text-xs">
                <div class="grid grid-cols-2 gap-2">
                  <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800 space-y-0.5">
                    <span class="text-slate-400 text-[11px]">系统利用率 (ρ)</span>
                    <div class="text-lg font-bold font-mono text-emerald-400">{{ sim.utilization_pct }}%</div>
                  </div>
                  <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800 space-y-0.5">
                    <span class="text-slate-400 text-[11px]">平均队列等待时间</span>
                    <div class="text-lg font-bold font-mono text-cyan-300">{{ sim.avg_queue_wait_mins }} 分钟</div>
                  </div>
                </div>

                <div class="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-2">
                  <div class="flex justify-between items-center">
                    <span class="text-slate-300 font-medium">拥堵与溢出状态预测:</span>
                    <span [class]="sim.is_bottleneck ? 'bg-rose-950 text-rose-400 border-rose-800' : 'bg-emerald-950 text-emerald-400 border-emerald-800'" class="px-2 py-0.5 rounded-full border text-[10px] font-bold">
                      {{ sim.is_bottleneck ? '存在瓶颈风险' : '畅通无积压' }}
                    </span>
                  </div>
                  <div class="text-[11px] text-slate-400 leading-relaxed">
                    以当前进港流量 (12万件/时) 计算，5组自动化矩阵分拣通道可维持平稳运行，建议维持传送带速度 2.5 m/s。
                  </div>
                </div>

                <!-- 24-Hour Peak Forecast Sparkline Table -->
                <div class="space-y-1">
                  <span class="text-slate-400 text-[11px]">24小时流量与队列模拟:</span>
                  <div class="max-h-40 overflow-y-auto space-y-1 font-mono text-[11px] pr-1">
                    @for (item of sim.timeline; track item.hour) {
                      <div class="flex items-center justify-between bg-slate-950 p-1.5 rounded border border-slate-800/80">
                        <span class="text-slate-400">{{ item.hour }}</span>
                        <span class="text-slate-200">{{ (item.volume/10000).toFixed(1) }}万件</span>
                        <span [class]="item.overflow_risk === 'HIGH' ? 'text-rose-400 font-bold' : 'text-emerald-400'">
                          {{ item.utilization_pct }}%
                        </span>
                      </div>
                    }
                  </div>
                </div>
              </div>
            } @else {
              <div class="text-center py-8 text-slate-500 text-xs">
                点击上方按钮调用 R 排队论模型进行现场仿真
              </div>
            }
          </div>

          <!-- Digital Twin Equipment Telemetry -->
          <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3">
            <div class="text-sm font-semibold text-cyan-400 border-b border-slate-800 pb-2 flex items-center space-x-1.5">
              <mat-icon class="text-base">sensors</mat-icon>
              <span>关键智能设备数字孪生遥测</span>
            </div>

            <div class="space-y-2 text-xs">
              <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between">
                <div>
                  <div class="font-bold text-slate-200">全向DWS扫码称重一体机</div>
                  <div class="text-[10px] text-slate-400">扫码率: 99.98% | 识别速度: 0.15s/件</div>
                </div>
                <span class="text-emerald-400 font-mono text-xs font-bold">在线</span>
              </div>

              <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between">
                <div>
                  <div class="font-bold text-slate-200">5G AGV 搬运机器人机队</div>
                  <div class="text-[10px] text-slate-400">SOC平均电量: 88% | 故障率: 0.00%</div>
                </div>
                <span class="text-emerald-400 font-mono text-xs font-bold">180/180</span>
              </div>

              <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between">
                <div>
                  <div class="font-bold text-slate-200">异形件智能柔性拣选抓取臂</div>
                  <div class="text-[10px] text-slate-400">AI视觉分类正确率: 99.4%</div>
                </div>
                <span class="text-emerald-400 font-mono text-xs font-bold">运行中</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class ProcessingCenterComponent implements AfterViewInit, OnDestroy {
  dtService = inject(DigitalTwinService);
  @ViewChild('canvasContainer') canvasContainer!: ElementRef<HTMLDivElement>;

  simResult = signal<QueueingSimResult | null>(null);
  isLoadingSim = signal<boolean>(false);

  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private animationFrameId = 0;
  private agvGroup!: THREE.Group;

  ngAfterViewInit() {
    this.init3DScene();
    this.runQueueSimulation();
  }

  ngOnDestroy() {
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
  }

  async runQueueSimulation() {
    this.isLoadingSim.set(true);
    try {
      const res = await this.dtService.runQueueingSimulation(120000, 25000, 5);
      this.simResult.set(res as unknown as QueueingSimResult);
    } catch (e) {
      console.error(e);
    } finally {
      this.isLoadingSim.set(false);
    }
  }

  private init3DScene() {
    const container = this.canvasContainer.nativeElement;
    const width = container.clientWidth || 700;
    const height = container.clientHeight || 500;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x020617);

    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    this.camera.position.set(0, 20, 25);
    this.camera.lookAt(0, 0, 0);

    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(this.renderer.domElement);

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
    this.scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0x10b981, 1.5);
    dirLight.position.set(10, 25, 10);
    this.scene.add(dirLight);

    // Floor
    const gridHelper = new THREE.GridHelper(30, 30, 0x1e293b, 0x0f172a);
    this.scene.add(gridHelper);

    // Conveyor Belts (Looping Lines)
    const beltGeo = new THREE.BoxGeometry(20, 0.3, 1.2);
    const beltMat = new THREE.MeshPhongMaterial({ color: 0x334155 });
    const belt1 = new THREE.Mesh(beltGeo, beltMat);
    belt1.position.set(0, 0.2, -4);
    this.scene.add(belt1);

    const belt2 = new THREE.Mesh(beltGeo, beltMat);
    belt2.position.set(0, 0.2, 4);
    this.scene.add(belt2);

    // Unloading Dock Trucks
    const truckGeo = new THREE.BoxGeometry(4, 2.5, 2);
    const truckMat = new THREE.MeshPhongMaterial({ color: 0x059669 });
    const truck = new THREE.Mesh(truckGeo, truckMat);
    truck.position.set(-12, 1.25, -4);
    this.scene.add(truck);

    // AGVs (Moving yellow cubes)
    this.agvGroup = new THREE.Group();
    for (let i = 0; i < 6; i++) {
      const agvGeo = new THREE.BoxGeometry(1.2, 0.4, 0.8);
      const agvMat = new THREE.MeshPhongMaterial({ color: 0xf59e0b });
      const agv = new THREE.Mesh(agvGeo, agvMat);
      agv.position.set(-8 + i * 3, 0.2, (i % 2 === 0 ? -2 : 2));
      this.agvGroup.add(agv);
    }
    this.scene.add(this.agvGroup);

    // Animation Loop
    const animate = () => {
      this.animationFrameId = requestAnimationFrame(animate);

      // Animate AGVs back and forth
      this.agvGroup.children.forEach((agv, idx) => {
        agv.position.x += (idx % 2 === 0 ? 0.05 : -0.05);
        if (agv.position.x > 8) agv.position.x = -8;
        if (agv.position.x < -8) agv.position.x = 8;
      });

      this.renderer.render(this.scene, this.camera);
    };

    animate();
  }
}
