import { Component, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-unmanned-delivery',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-4 md:p-6 bg-slate-950 min-h-screen text-slate-100 space-y-6">
      <!-- Header -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <div class="flex items-center space-x-2">
            <h2 class="text-base font-bold text-emerald-400">
              无人配送与同城即时配调度中心 (Unmanned Drone & Autonomous Vehicle OS)
            </h2>
            <span class="bg-emerald-950 text-emerald-300 border border-emerald-800 text-[10px] font-semibold px-2 py-0.5 rounded-full">
              邮航-UAV + 5G无人小车
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-0.5">
            山区/海岛无人机支线直航 + 城市社区 30分钟同城即时配
          </p>
        </div>

        <button 
          (click)="dispatchDroneTask()" 
          class="bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold px-4 py-2 rounded-xl text-xs transition-all flex items-center space-x-1.5 shadow-lg shadow-emerald-600/20">
          <mat-icon class="text-sm">flight_takeoff</mat-icon>
          <span>新建无人机航线调度指令</span>
        </button>
      </div>

      <!-- Main Layout: Unmanned Fleet Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- UAV Drone Digital Twins Section (Section 28 & 29) -->
        <div class="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2 text-sm font-bold text-cyan-400">
            <span class="flex items-center space-x-1.5">
              <mat-icon class="text-base">flight</mat-icon>
              <span>邮航无人机数字孪生机队 (UAV Drone Fleet)</span>
            </span>
            <span class="text-xs font-mono text-slate-400">在飞: 12 架</span>
          </div>

          <div class="space-y-3 text-xs">
            <div class="bg-slate-950 p-3.5 rounded-xl border border-cyan-500/30 space-y-2">
              <div class="flex items-center justify-between">
                <span class="font-bold text-slate-200 text-sm">架次: 邮航-UAV-09 (六轴多旋翼)</span>
                <span class="bg-emerald-950 text-emerald-400 border border-emerald-800 text-[10px] px-2 py-0.5 rounded-full font-bold">
                  巡航飞行中
                </span>
              </div>

              <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 font-mono text-[11px]">
                <div class="bg-slate-900 p-2 rounded-lg border border-slate-800">
                  <div class="text-[10px] text-slate-400">电池SOC</div>
                  <div class="text-emerald-400 font-bold">82%</div>
                </div>
                <div class="bg-slate-900 p-2 rounded-lg border border-slate-800">
                  <div class="text-[10px] text-slate-400">相对飞行高度</div>
                  <div class="text-slate-200 font-bold">120 m</div>
                </div>
                <div class="bg-slate-900 p-2 rounded-lg border border-slate-800">
                  <div class="text-[10px] text-slate-400">实时载重</div>
                  <div class="text-cyan-300 font-bold">3.2 kg</div>
                </div>
                <div class="bg-slate-900 p-2 rounded-lg border border-slate-800">
                  <div class="text-[10px] text-slate-400">航速/风速</div>
                  <div class="text-amber-300 font-bold">12 m/s</div>
                </div>
              </div>

              <div class="text-[10px] text-slate-400 font-mono border-t border-slate-800 pt-1.5 flex justify-between">
                <span>航线: 桐庐分水镇服务站 ➔ 百江村高山代投点</span>
                <span>预计降落时间: 14:15</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Autonomous Delivery Vehicles & Same-City Instant Delivery (Section 30 & 31) -->
        <div class="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2 text-sm font-bold text-emerald-400">
            <span class="flex items-center space-x-1.5">
              <mat-icon class="text-base">smart_toy</mat-icon>
              <span>5G 无人配售车 & 同城 30 分钟即时配</span>
            </span>
            <span class="text-xs font-mono text-slate-400">运行车队: 28 台</span>
          </div>

          <div class="space-y-3 text-xs">
            <div class="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-2">
              <div class="flex items-center justify-between font-bold">
                <span class="text-slate-200">无人车-SH-102 (L4自动驾驶)</span>
                <span class="bg-emerald-950 text-emerald-400 border border-emerald-800 text-[10px] px-2 py-0.5 rounded-full font-bold">
                  自主无感派送中
                </span>
              </div>

              <p class="text-[11px] text-slate-400">
                服务范围: 陆家嘴环路 2 公里半径社区 | 自动避障: 激光雷达 + 视觉SLAM | 载箱格口: 16 格
              </p>

              <div class="flex justify-between font-mono text-[10px] text-slate-400 pt-1 border-t border-slate-800">
                <span>今日派单: 142 单</span>
                <span>客户满意度: 99.8%</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class UnmannedDeliveryComponent {
  dispatchDroneTask() {
    alert('已成功下发无人机避障航线指令 (邮航-UAV-10)！路线已同步至数字孪生网格。');
  }
}
