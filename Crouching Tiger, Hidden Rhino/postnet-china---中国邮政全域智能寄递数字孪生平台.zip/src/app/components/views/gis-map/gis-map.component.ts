import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService, FacilityNode } from '../../../services/digital-twin.service';

@Component({
  selector: 'app-gis-map',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-4 md:p-6 bg-slate-950 min-h-screen text-slate-100 space-y-4">
      <!-- GIS Controls & Zoom Hierarchy Header (Section 4) -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 class="text-base font-bold text-emerald-400 flex items-center space-x-2">
            <mat-icon class="text-emerald-400">map</mat-icon>
            <span>全国邮政物流GIS数字地图 (National Postal GIS)</span>
          </h2>
          <p class="text-xs text-slate-400 mt-0.5">
            八级联动可缩放拓扑 hierarchy: 全国 → 省 → 城市 → 县 → 乡镇 → 村 → 网点 → 配送道段
          </p>
        </div>

        <!-- Zoom Hierarchy Buttons -->
        <div class="flex flex-wrap items-center gap-1.5 bg-slate-950 p-1.5 rounded-xl border border-slate-800 text-xs">
          <button 
            (click)="setZoomLevel('NATION')" 
            [class]="zoomLevel() === 'NATION' ? 'bg-emerald-600 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'"
            class="px-2.5 py-1 rounded-lg transition-all">
            全国
          </button>
          <button 
            (click)="setZoomLevel('PROVINCE')" 
            [class]="zoomLevel() === 'PROVINCE' ? 'bg-emerald-600 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'"
            class="px-2.5 py-1 rounded-lg transition-all">
            省
          </button>
          <button 
            (click)="setZoomLevel('CITY')" 
            [class]="zoomLevel() === 'CITY' ? 'bg-emerald-600 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'"
            class="px-2.5 py-1 rounded-lg transition-all">
            城市
          </button>
          <button 
            (click)="setZoomLevel('COUNTY')" 
            [class]="zoomLevel() === 'COUNTY' ? 'bg-emerald-600 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'"
            class="px-2.5 py-1 rounded-lg transition-all">
            县
          </button>
          <button 
            (click)="setZoomLevel('TOWN')" 
            [class]="zoomLevel() === 'TOWN' ? 'bg-emerald-600 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'"
            class="px-2.5 py-1 rounded-lg transition-all">
            乡镇
          </button>
          <button 
            (click)="setZoomLevel('VILLAGE')" 
            [class]="zoomLevel() === 'VILLAGE' ? 'bg-emerald-600 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'"
            class="px-2.5 py-1 rounded-lg transition-all">
            村
          </button>
          <button 
            (click)="setZoomLevel('STATION')" 
            [class]="zoomLevel() === 'STATION' ? 'bg-emerald-600 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'"
            class="px-2.5 py-1 rounded-lg transition-all">
            网点/道段
          </button>
        </div>
      </div>

      <!-- Main GIS Canvas & Layers Bar Layout -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- GIS Map Display Area -->
        <div class="lg:col-span-9 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 min-h-[580px] flex flex-col justify-between relative overflow-hidden">
          <!-- Active Layer Toggles Bar -->
          <div class="flex flex-wrap items-center gap-2 z-10 bg-slate-950/90 border border-slate-800 p-2.5 rounded-xl text-xs backdrop-blur">
            <span class="text-slate-400 font-semibold mr-1 flex items-center space-x-1">
              <mat-icon class="text-xs text-emerald-400">layers</mat-icon>
              <span>图层开关:</span>
            </span>

            <label class="flex items-center space-x-1 cursor-pointer bg-slate-900 border border-slate-800 px-2 py-1 rounded text-slate-300">
              <input type="checkbox" [checked]="showNodes()" (change)="showNodes.set(!showNodes())" class="accent-emerald-500">
              <span>邮政网点/枢纽</span>
            </label>

            <label class="flex items-center space-x-1 cursor-pointer bg-slate-900 border border-slate-800 px-2 py-1 rounded text-slate-300">
              <input type="checkbox" [checked]="showHighways()" (change)="showHighways.set(!showHighways())" class="accent-amber-500">
              <span>高速公路干线</span>
            </label>

            <label class="flex items-center space-x-1 cursor-pointer bg-slate-900 border border-slate-800 px-2 py-1 rounded text-slate-300">
              <input type="checkbox" [checked]="showAirports()" (change)="showAirports.set(!showAirports())" class="accent-sky-500">
              <span>航空/机场网</span>
            </label>

            <label class="flex items-center space-x-1 cursor-pointer bg-slate-900 border border-slate-800 px-2 py-1 rounded text-slate-300">
              <input type="checkbox" [checked]="showRailways()" (change)="showRailways.set(!showRailways())" class="accent-indigo-500">
              <span>铁路干线</span>
            </label>

            <label class="flex items-center space-x-1 cursor-pointer bg-slate-900 border border-slate-800 px-2 py-1 rounded text-slate-300">
              <input type="checkbox" [checked]="showWeather()" (change)="showWeather.set(!showWeather())" class="accent-rose-500">
              <span>极端天气层 (台风/大雾)</span>
            </label>
          </div>

          <!-- Interactive GIS Map Simulator Visualizer -->
          <div class="my-auto py-8 text-center space-y-4">
            <div class="relative max-w-2xl mx-auto bg-slate-950 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-4">
              <!-- Current Level Indicator -->
              <div class="flex items-center justify-between text-xs border-b border-slate-800 pb-3">
                <div class="flex items-center space-x-2">
                  <span class="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></span>
                  <span class="text-slate-300 font-bold">当前GIS级别: {{ getZoomName(zoomLevel()) }}</span>
                </div>
                <span class="text-slate-500 font-mono">EPSG:3857 (Web Mercator + PostGIS GeoJSON)</span>
              </div>

              <!-- GIS Map SVG Map Topology Visualizer -->
              <svg viewBox="0 0 800 400" class="w-full h-auto bg-slate-950 rounded-xl border border-slate-800/80">
                <!-- Map Background Grid -->
                <defs>
                  <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                    <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#1e293b" stroke-width="0.8"/>
                  </pattern>
                </defs>
                <rect width="800" height="400" fill="url(#grid)" />

                <!-- China Postal Trunk Network Routes (SVG Paths) -->
                @if (showHighways()) {
                  <path d="M 520,130 L 620,210 L 580,310 L 380,290 L 410,210 Z" fill="none" stroke="#f59e0b" stroke-width="2" stroke-dasharray="6,3" />
                  <path d="M 620,210 L 410,210" fill="none" stroke="#f59e0b" stroke-width="2" stroke-dasharray="6,3" />
                }

                @if (showAirports()) {
                  <path d="M 520,130 C 580,100 620,150 620,210" fill="none" stroke="#38bdf8" stroke-width="2" stroke-dasharray="4,4" />
                  <path d="M 520,130 C 450,150 400,180 410,210" fill="none" stroke="#38bdf8" stroke-width="2" stroke-dasharray="4,4" />
                }

                @if (showRailways()) {
                  <path d="M 520,130 L 410,210 L 380,290" fill="none" stroke="#818cf8" stroke-width="2" />
                }

                <!-- Weather Zone Overlay -->
                @if (showWeather()) {
                  <circle cx="520" cy="130" r="45" fill="#f43f5e" fill-opacity="0.18" stroke="#f43f5e" stroke-dasharray="3,3" />
                  <text x="490" y="90" fill="#f43f5e" font-size="10" font-weight="bold">华北区域大雾警告</text>
                }

                <!-- Processing Centers & Nodes -->
                @if (showNodes()) {
                  <!-- Beijing -->
                  <circle cx="520" cy="130" r="10" fill="#f43f5e" class="cursor-pointer hover:r-12 transition-all" (click)="onNodeClick('PC-BEIJING-01')" />
                  <text x="535" y="135" fill="#f87171" font-size="11" font-weight="bold">北京处理中心 (满负荷)</text>

                  <!-- Shanghai -->
                  <circle cx="620" cy="210" r="10" fill="#10b981" class="cursor-pointer hover:r-12 transition-all" (click)="onNodeClick('PC-SHANGHAI-01')" />
                  <text x="635" y="215" fill="#34d399" font-size="11" font-weight="bold">上海处理中心</text>

                  <!-- Guangzhou -->
                  <circle cx="580" cy="310" r="10" fill="#10b981" class="cursor-pointer hover:r-12 transition-all" (click)="onNodeClick('PC-GUANGZHOU-01')" />
                  <text x="595" y="315" fill="#34d399" font-size="11" font-weight="bold">广州集散中心</text>

                  <!-- Chongqing -->
                  <circle cx="380" cy="290" r="10" fill="#10b981" class="cursor-pointer hover:r-12 transition-all" (click)="onNodeClick('PC-CHONGQING-01')" />
                  <text x="290" y="295" fill="#34d399" font-size="11" font-weight="bold">重庆枢纽</text>

                  <!-- Wuhan -->
                  <circle cx="410" cy="210" r="10" fill="#10b981" class="cursor-pointer hover:r-12 transition-all" (click)="onNodeClick('PC-WUHAN-01')" />
                  <text x="425" y="200" fill="#34d399" font-size="11" font-weight="bold">武汉转运中心</text>

                  <!-- Tonglu Rural Nodes -->
                  <circle cx="600" cy="235" r="6" fill="#fbbf24" class="cursor-pointer" (click)="onNodeClick('COUNTY-101')" />
                  <text x="612" y="240" fill="#fbbf24" font-size="10">桐庐县三级节点</text>
                }
              </svg>

              <div class="flex items-center justify-between text-xs text-slate-400 font-mono pt-2">
                <span>中心视角: 31.23°N, 121.47°E</span>
                <span>动态图层渲染: PostGIS矢量切片引擎</span>
              </div>
            </div>
          </div>

          <!-- Bottom Legend Info -->
          <div class="z-10 bg-slate-950/90 border border-slate-800 p-3 rounded-xl flex items-center justify-between text-xs">
            <div class="flex items-center space-x-4">
              <span class="flex items-center space-x-1.5">
                <span class="w-3 h-3 rounded-full bg-emerald-500"></span>
                <span>正常枢纽</span>
              </span>
              <span class="flex items-center space-x-1.5">
                <span class="w-3 h-3 rounded-full bg-rose-500"></span>
                <span>拥堵/预警枢纽</span>
              </span>
              <span class="flex items-center space-x-1.5">
                <span class="w-3 h-3 rounded-full bg-amber-400"></span>
                <span>县/乡/村级站点</span>
              </span>
            </div>
            <span class="text-slate-400 font-mono">缩放层级 Index: {{ getZoomLevelCode(zoomLevel()) }}</span>
          </div>
        </div>

        <!-- Right Side: GIS Selected Object Details Drawer -->
        <div class="lg:col-span-3 space-y-4">
          <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3">
            <div class="flex items-center justify-between text-sm font-semibold text-emerald-400 border-b border-slate-800 pb-2">
              <span class="flex items-center space-x-1.5">
                <mat-icon class="text-base">info</mat-icon>
                <span>节点孪生档案 (GIS Node)</span>
              </span>
            </div>

            @if (selectedNodeDetail(); as node) {
              <div class="space-y-3 text-xs">
                <div class="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-2">
                  <div class="font-bold text-sm text-emerald-300">{{ node.name }}</div>
                  <div class="text-slate-400 font-mono">ID: {{ node.id }}</div>

                  <div class="space-y-1 pt-1 border-t border-slate-800">
                    <div class="flex justify-between">
                      <span class="text-slate-400">所在行政区:</span>
                      <span class="text-slate-200">{{ node.province }} {{ node.city }}</span>
                    </div>
                    <div class="flex justify-between">
                      <span class="text-slate-400">实时处理量:</span>
                      <span class="text-emerald-400 font-mono font-bold">{{ node.hourly_volume }} 件/时</span>
                    </div>
                    <div class="flex justify-between">
                      <span class="text-slate-400">设计最大容量:</span>
                      <span class="text-slate-300 font-mono">{{ node.capacity }} 件/时</span>
                    </div>
                    <div class="flex justify-between">
                      <span class="text-slate-400">分拣AGV数量:</span>
                      <span class="text-cyan-400 font-mono">{{ node.agv_count }} 台</span>
                    </div>
                    <div class="flex justify-between">
                      <span class="text-slate-400">传送带速度:</span>
                      <span class="text-slate-200 font-mono">{{ node.conveyor_speed_m_s }} m/s</span>
                    </div>
                  </div>
                </div>

                <button 
                  (click)="dtService.activeTab.set('processing-center')"
                  class="w-full bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold py-2 rounded-xl text-xs transition-all flex items-center justify-center space-x-1">
                  <mat-icon class="text-sm">precision_manufacturing</mat-icon>
                  <span>进入该处理中心 3D 数字孪生</span>
                </button>
              </div>
            } @else {
              <div class="text-center py-12 text-slate-500 text-xs space-y-2">
                <mat-icon class="text-3xl text-slate-600">touch_app</mat-icon>
                <p>点击地图上的地图节点以查看详细GIS参数与关联物理资产</p>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `
})
export class GisMapComponent {
  dtService = inject(DigitalTwinService);

  zoomLevel = signal<'NATION' | 'PROVINCE' | 'CITY' | 'COUNTY' | 'TOWN' | 'VILLAGE' | 'STATION'>('NATION');

  showNodes = signal<boolean>(true);
  showHighways = signal<boolean>(true);
  showAirports = signal<boolean>(true);
  showRailways = signal<boolean>(true);
  showWeather = signal<boolean>(false);

  selectedNodeDetail = signal<FacilityNode | null>(null);

  setZoomLevel(level: 'NATION' | 'PROVINCE' | 'CITY' | 'COUNTY' | 'TOWN' | 'VILLAGE' | 'STATION') {
    this.zoomLevel.set(level);
  }

  getZoomName(code: string): string {
    const names: Record<string, string> = {
      NATION: '1级: 全国全景拓扑 (Nationwide)',
      PROVINCE: '2级: 省域干线网络 (Province)',
      CITY: '3级: 城市分拨中心 (City)',
      COUNTY: '4级: 县域集散中心 (County)',
      TOWN: '5级: 乡镇邮政所 (Township)',
      VILLAGE: '6级: 村级服务站 (Village)',
      STATION: '7级: 末端网点/配送道段 (Station & Routes)',
    };
    return names[code] || '全国拓扑';
  }

  getZoomLevelCode(code: string): string {
    const codes: Record<string, string> = {
      NATION: 'L1-NATION-GIS',
      PROVINCE: 'L2-PROVINCE-GIS',
      CITY: 'L3-CITY-GIS',
      COUNTY: 'L4-COUNTY-GIS',
      TOWN: 'L5-TOWN-GIS',
      VILLAGE: 'L6-VILLAGE-GIS',
      STATION: 'L7-STATION-ROUTE-GIS',
    };
    return codes[code] || 'L1';
  }

  onNodeClick(nodeId: string) {
    const facility = this.dtService.facilities().find(f => f.id === nodeId);
    if (facility) {
      this.selectedNodeDetail.set(facility);
    } else {
      this.selectedNodeDetail.set({
        id: nodeId,
        name: '桐庐县三级物流节点群',
        level: 'PROCESSING_CENTER',
        province: '浙江省',
        city: '杭州市',
        lat: 29.7978,
        lng: 119.6896,
        hourly_volume: 45000,
        capacity: 60000,
        agv_count: 28,
        conveyor_speed_m_s: 1.8,
        utilization_pct: 75,
        status: 'NORMAL'
      });
    }
  }
}
