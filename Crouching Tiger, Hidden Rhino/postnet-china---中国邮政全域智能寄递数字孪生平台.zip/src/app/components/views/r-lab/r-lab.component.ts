import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../../services/digital-twin.service';

@Component({
  selector: 'app-r-lab',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-4 md:p-6 bg-slate-950 min-h-screen text-slate-100 space-y-6">
      <!-- Header -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <div class="flex items-center space-x-2">
            <h2 class="text-base font-bold text-emerald-400">
              R 语言运筹优化实验室 (R Operations Research & Optimization Engine)
            </h2>
            <span class="bg-emerald-950 text-emerald-300 border border-emerald-800 text-[10px] font-semibold px-2 py-0.5 rounded-full">
              postoptR + Plumber API
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-0.5">
            采用 R / ompr / lpSolve / fable / igraph 执行真实的运筹学算法与时序预测
          </p>
        </div>

        <div class="flex items-center space-x-2 text-xs">
          <span class="bg-slate-800 px-3 py-1.5 rounded-xl border border-slate-700 font-mono text-emerald-300">
            Engine status: READY
          </span>
        </div>
      </div>

      <!-- Main Layout: Solver Grid & Config Toggles -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Solver Selector & Objective Weight Tuners -->
        <div class="lg:col-span-4 space-y-4">
          <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3">
            <div class="text-sm font-semibold text-emerald-400 border-b border-slate-800 pb-2 flex items-center space-x-1.5">
              <mat-icon class="text-base">tune</mat-icon>
              <span>多目标优化函数权重调参 (Objective Weights)</span>
            </div>

            <div class="space-y-3 text-xs">
              <div class="space-y-1">
                <div class="flex justify-between text-slate-300 font-mono">
                  <span>权重 w1: 最小化行驶里程</span>
                  <span class="text-emerald-400 font-bold">{{ weightDist() }}</span>
                </div>
                <input type="range" min="0" max="1" step="0.1" [value]="weightDist()" (input)="weightDist.set(+($any($event.target).value))" class="w-full accent-emerald-500 cursor-pointer">
              </div>

              <div class="space-y-1">
                <div class="flex justify-between text-slate-300 font-mono">
                  <span>权重 w2: 最小化出动车辆数</span>
                  <span class="text-emerald-400 font-bold">{{ weightVehicles() }}</span>
                </div>
                <input type="range" min="0" max="1" step="0.1" [value]="weightVehicles()" (input)="weightVehicles.set(+($any($event.target).value))" class="w-full accent-emerald-500 cursor-pointer">
              </div>

              <div class="space-y-1">
                <div class="flex justify-between text-slate-300 font-mono">
                  <span>权重 w3: 最小化空载率与碳排放</span>
                  <span class="text-emerald-400 font-bold">{{ weightCarbon() }}</span>
                </div>
                <input type="range" min="0" max="1" step="0.1" [value]="weightCarbon()" (input)="weightCarbon.set(+($any($event.target).value))" class="w-full accent-emerald-500 cursor-pointer">
              </div>
            </div>
          </div>

          <!-- Select R Module to Trigger -->
          <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-2 text-xs">
            <div class="font-bold text-slate-200 border-b border-slate-800 pb-2">调用 R 算法服务:</div>

            <button 
              (click)="runSolver('VRP')" 
              class="w-full bg-slate-950 hover:bg-slate-800 text-left p-2.5 rounded-xl border border-slate-800 transition-all space-y-0.5">
              <div class="font-bold text-emerald-300">1. VRPTW 车辆路径求解 (route_optimizer.R)</div>
              <div class="text-[10px] text-slate-400">带时间窗约束的路径重排与里程压缩</div>
            </button>

            <button 
              (click)="runSolver('LOCKER')" 
              class="w-full bg-slate-950 hover:bg-slate-800 text-left p-2.5 rounded-xl border border-slate-800 transition-all space-y-0.5">
              <div class="font-bold text-cyan-300">2. 智能快递柜选址 (locker_location.R)</div>
              <div class="text-[10px] text-slate-400">覆盖人口与选址成本多目标线性规划</div>
            </button>

            <button 
              (click)="runSolver('FORECAST')" 
              class="w-full bg-slate-950 hover:bg-slate-800 text-left p-2.5 rounded-xl border border-slate-800 transition-all space-y-0.5">
              <div class="font-bold text-amber-300">3. 层级包裹需求预测 (parcel_demand.R)</div>
              <div class="text-[10px] text-slate-400">fable / ARIMA-XGBoost 未来7天件量预测</div>
            </button>
          </div>
        </div>

        <!-- Right Side: R Solver Output & Console Inspector -->
        <div class="lg:col-span-8 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-4 min-h-[500px]">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2 text-sm font-bold text-emerald-400">
            <span class="flex items-center space-x-1.5">
              <mat-icon class="text-base">code</mat-icon>
              <span>R 运行控制台与数学模型响应 (R Execution Log)</span>
            </span>
            <span class="text-xs font-mono text-slate-400">Execution time: {{ executionTime() }} ms</span>
          </div>

          @if (solverOutput()) {
            <div class="bg-slate-950 p-4 rounded-xl border border-slate-800 font-mono text-xs overflow-x-auto max-h-[450px] space-y-2">
              <div class="text-emerald-400 font-bold"># R Plumber API Response Header</div>
              <pre class="text-slate-300">{{ solverOutput() | json }}</pre>
            </div>
          } @else {
            <div class="text-center py-20 text-slate-500 text-xs space-y-2">
              <mat-icon class="text-4xl text-slate-600">terminal</mat-icon>
              <p>请在左侧选择需要调用的 R 运筹学模块与多目标权重</p>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class RLabComponent {
  dtService = inject(DigitalTwinService);

  weightDist = signal<number>(0.5);
  weightVehicles = signal<number>(0.3);
  weightCarbon = signal<number>(0.2);

  solverOutput = signal<unknown>(null);
  executionTime = signal<number>(0);

  async runSolver(type: string) {
    const start = Date.now();
    if (type === 'VRP') {
      const res = await this.dtService.runVRPOptimization(25, 5);
      this.solverOutput.set(res);
    } else if (type === 'LOCKER') {
      const res = await this.dtService.runLockerLocationOptimization(8);
      this.solverOutput.set(res);
    } else if (type === 'FORECAST') {
      this.solverOutput.set({
        provenance: 'SIMULATION DATA',
        engine: 'R/fable/forecast',
        horizon_days: 7,
        forecast_summary: '未来7天华东区域预估日均邮件 38,450,000 件, 峰值出现在周三'
      });
    }
    this.executionTime.set(Date.now() - start);
  }
}
