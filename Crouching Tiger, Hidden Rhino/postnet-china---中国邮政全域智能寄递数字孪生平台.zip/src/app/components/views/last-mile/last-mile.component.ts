import { Component, ChangeDetectionStrategy, inject, ElementRef, ViewChild, AfterViewInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../../services/digital-twin.service';
import * as THREE from 'three';

@Component({
  selector: 'app-last-mile',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-4 md:p-6 bg-slate-950 min-h-screen text-slate-100 space-y-6">
      <!-- Title Bar -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <div class="flex items-center space-x-2">
            <h2 class="text-base font-bold text-emerald-400">
              末端配送控制中心 (Last-Mile Control Center & Digital Twin)
            </h2>
            <span class="bg-emerald-950 text-emerald-300 border border-emerald-800 text-[10px] font-semibold px-2 py-0.5 rounded-full">
              VRPTW + 动态实时重排
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-0.5">
            基于 R 语言 Operations Research 求解快递员道段、车辆分配、自提点与快递柜最优匹配
          </p>
        </div>

        <button 
          (click)="reoptimizeLastMile()" 
          [disabled]="dtService.isOptimizing()"
          class="bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-slate-950 font-bold px-4 py-2 rounded-xl text-xs transition-all flex items-center space-x-1.5 shadow-lg shadow-emerald-600/20">
          <mat-icon class="text-sm">alt_route</mat-icon>
          <span>{{ dtService.isOptimizing() ? 'R VRPTW 优化中...' : '调用 R 求解器重新优化最后一公里' }}</span>
        </button>
      </div>

      <!-- Main Layout: Left (3D Community Digital Twin), Right (Courier Digital Twins & Workload) -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- 3D Neighborhood & Delivery Routes (Section 20) -->
        <div class="lg:col-span-8 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between relative overflow-hidden min-h-[550px]">
          <div class="flex items-center justify-between z-10 bg-slate-950/80 backdrop-blur border border-slate-800 p-2.5 rounded-xl text-xs">
            <div class="flex items-center space-x-2">
              <span class="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></span>
              <span class="font-bold text-slate-200">社区末端 3D 数字孪生 (居民楼/快递柜/无人车/快递员)</span>
            </div>
            <div class="flex items-center space-x-2 text-[11px] text-slate-400">
              <span class="flex items-center space-x-1">
                <span class="w-2.5 h-2.5 bg-blue-500 rounded-sm"></span>
                <span>居民楼/商业楼</span>
              </span>
              <span class="flex items-center space-x-1">
                <span class="w-2.5 h-2.5 bg-amber-400 rounded-full"></span>
                <span>智能快递柜</span>
              </span>
              <span class="flex items-center space-x-1">
                <span class="w-2.5 h-2.5 bg-emerald-400 rounded-full"></span>
                <span>配送员</span>
              </span>
            </div>
          </div>

          <!-- 3D Canvas -->
          <div #canvasContainer class="absolute inset-0 w-full h-full rounded-2xl"></div>

          <!-- Bottom Optimization Results Banner (Section 75) -->
          @if (dtService.lastOptimizationResult(); as res) {
            <div class="z-10 bg-slate-950/90 border border-emerald-500/40 p-3 rounded-xl backdrop-blur space-y-2 text-xs">
              <div class="flex items-center justify-between text-emerald-400 font-bold border-b border-slate-800 pb-1.5">
                <span class="flex items-center space-x-1">
                  <mat-icon class="text-sm">check_circle</mat-icon>
                  <span>R VRPTW 路线优化成功 (Before vs. After 对比)</span>
                </span>
                <span class="font-mono text-[11px] text-slate-400">算法: {{ res.algorithm }}</span>
              </div>

              <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center font-mono text-[11px]">
                <div class="bg-slate-900 p-2 rounded-lg border border-slate-800">
                  <div class="text-[10px] text-slate-400">优化前总里程</div>
                  <div class="text-rose-400 font-bold text-sm">{{ res.summary.before_distance_km }} km</div>
                </div>
                <div class="bg-slate-900 p-2 rounded-lg border border-slate-800">
                  <div class="text-[10px] text-slate-400">优化后总里程</div>
                  <div class="text-emerald-400 font-bold text-sm">{{ res.summary.after_distance_km }} km</div>
                </div>
                <div class="bg-slate-900 p-2 rounded-lg border border-slate-800">
                  <div class="text-[10px] text-slate-400">节省里程比例</div>
                  <div class="text-emerald-300 font-bold text-sm">↓ {{ res.summary.distance_savings_pct }}%</div>
                </div>
                <div class="bg-slate-900 p-2 rounded-lg border border-slate-800">
                  <div class="text-[10px] text-slate-400">预计碳减排</div>
                  <div class="text-cyan-300 font-bold text-sm">-{{ res.summary.co2_reduction_kg }} kg CO₂</div>
                </div>
              </div>
            </div>
          }
        </div>

        <!-- Right Side: Courier Digital Twins List & Workload Detector (Section 21 & 22) -->
        <div class="lg:col-span-4 space-y-4">
          <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3">
            <div class="flex items-center justify-between text-sm font-semibold text-emerald-400 border-b border-slate-800 pb-2">
              <span class="flex items-center space-x-1.5">
                <mat-icon class="text-base">badge</mat-icon>
                <span>快递员数字孪生档案 (Courier Twins)</span>
              </span>
              <span class="text-xs text-slate-400 font-mono">4 位示例员</span>
            </div>

            <div class="space-y-2.5 text-xs">
              @for (c of dtService.couriers(); track c.courier_id) {
                <div class="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1.5">
                  <div class="flex items-center justify-between">
                    <span class="font-bold text-slate-200">{{ c.name }}</span>
                    <span class="bg-emerald-950 text-emerald-400 border border-emerald-800 text-[10px] px-2 py-0.5 rounded-full font-semibold">
                      {{ c.status }}
                    </span>
                  </div>

                  <div class="grid grid-cols-2 gap-2 text-[11px] text-slate-400 font-mono pt-1">
                    <div>工具: <span class="text-slate-200">{{ c.vehicle_type }}</span></div>
                    <div>在送包裹: <span class="text-emerald-400 font-bold">{{ c.parcel_count }} 件</span></div>
                    <div>剩余站点: <span class="text-slate-200">{{ c.remaining_stops }} 站</span></div>
                    <div>班次时长: <span class="text-slate-200">{{ c.working_time_hrs }} 小时</span></div>
                  </div>

                  <div class="text-[10px] text-slate-500 font-mono flex justify-between border-t border-slate-800/80 pt-1">
                    <span>路由ID: {{ c.assigned_route_id }}</span>
                    <span class="text-cyan-400">负荷率: {{ +(c.parcel_count / 1.2).toFixed(1) }}%</span>
                  </div>
                </div>
              }
            </div>
          </div>

          <!-- Workload Anomaly Detector Card -->
          <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3">
            <div class="text-sm font-semibold text-amber-400 border-b border-slate-800 pb-2 flex items-center space-x-1.5">
              <mat-icon class="text-base">assessment</mat-icon>
              <span>快递员负荷平衡诊断</span>
            </div>

            <div class="space-y-2 text-xs">
              <div class="bg-slate-950 p-2.5 rounded-xl border border-amber-500/30 space-y-1">
                <div class="font-bold text-amber-300">过载道段检测: 静安寺CBD道段</div>
                <p class="text-[11px] text-slate-400">
                  刘洋 (工号 88104) 派送量已达 110 件，超过标准负荷 35%。R 求解器已自动划拨 25 件至无人配售车进行分流。
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class LastMileComponent implements AfterViewInit, OnDestroy {
  dtService = inject(DigitalTwinService);
  @ViewChild('canvasContainer') canvasContainer!: ElementRef<HTMLDivElement>;

  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private animationFrameId = 0;

  ngAfterViewInit() {
    this.init3DScene();
  }

  ngOnDestroy() {
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
  }

  async reoptimizeLastMile() {
    await this.dtService.runVRPOptimization(35, 6);
  }

  private init3DScene() {
    const container = this.canvasContainer.nativeElement;
    const width = container.clientWidth || 700;
    const height = container.clientHeight || 500;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x020617);

    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    this.camera.position.set(0, 18, 22);
    this.camera.lookAt(0, 0, 0);

    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(this.renderer.domElement);

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
    this.scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0x10b981, 1.5);
    dirLight.position.set(10, 20, 10);
    this.scene.add(dirLight);

    // Grid Floor
    const gridHelper = new THREE.GridHelper(30, 30, 0x1e293b, 0x0f172a);
    this.scene.add(gridHelper);

    // Neighborhood Buildings (Blue Blocks)
    const buildingGeo = new THREE.BoxGeometry(2.5, 5, 2.5);
    const buildingMat = new THREE.MeshPhongMaterial({ color: 0x3b82f6 });

    const buildingPositions = [
      [-8, 2.5, -6], [-4, 2.5, -6], [4, 2.5, -6], [8, 2.5, -6],
      [-8, 2.5, 6], [-4, 2.5, 6], [4, 2.5, 6], [8, 2.5, 6]
    ];

    buildingPositions.forEach(([x, y, z]) => {
      const b = new THREE.Mesh(buildingGeo, buildingMat);
      b.position.set(x, y, z);
      this.scene.add(b);
    });

    // Lockers (Yellow Cylinders)
    const lockerGeo = new THREE.CylinderGeometry(0.5, 0.5, 1.5, 16);
    const lockerMat = new THREE.MeshPhongMaterial({ color: 0xf59e0b });

    const locker1 = new THREE.Mesh(lockerGeo, lockerMat);
    locker1.position.set(0, 0.75, -2);
    this.scene.add(locker1);

    const locker2 = new THREE.Mesh(lockerGeo, lockerMat);
    locker2.position.set(0, 0.75, 2);
    this.scene.add(locker2);

    // Animation Loop
    const animate = () => {
      this.animationFrameId = requestAnimationFrame(animate);
      this.renderer.render(this.scene, this.camera);
    };

    animate();
  }
}
