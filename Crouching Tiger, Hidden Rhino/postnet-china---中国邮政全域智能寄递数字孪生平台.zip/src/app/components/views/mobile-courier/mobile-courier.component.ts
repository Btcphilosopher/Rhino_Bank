import { Component, ChangeDetectionStrategy, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-mobile-courier',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-4 md:p-6 bg-slate-950 min-h-screen text-slate-100 space-y-6">
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex items-center justify-between">
        <div>
          <h2 class="text-base font-bold text-emerald-400 flex items-center space-x-2">
            <mat-icon class="text-emerald-400">smartphone</mat-icon>
            <span>移动端终端仿真 (Mobile Courier & Customer Apps)</span>
          </h2>
          <p class="text-xs text-slate-400 mt-0.5">
            中国邮政快递员PDA揽派端 ↔ 邮政官方微信小程序/App客户端
          </p>
        </div>

        <div class="flex items-center space-x-2 text-xs">
          <button 
            (click)="activeApp.set('COURIER')"
            [class]="activeApp() === 'COURIER' ? 'bg-emerald-600 text-slate-950 font-bold' : 'bg-slate-800 text-slate-300'"
            class="px-3 py-1.5 rounded-xl transition-all">
            快递员 PDA 揽派端
          </button>
          <button 
            (click)="activeApp.set('CUSTOMER')"
            [class]="activeApp() === 'CUSTOMER' ? 'bg-emerald-600 text-slate-950 font-bold' : 'bg-slate-800 text-slate-300'"
            class="px-3 py-1.5 rounded-xl transition-all">
            邮政客户小程序
          </button>
        </div>
      </div>

      <!-- Mobile Device Frame Container -->
      <div class="flex justify-center py-6">
        <div class="w-full max-w-sm bg-slate-900 border-4 border-slate-800 rounded-[36px] shadow-2xl p-4 space-y-4 relative overflow-hidden">
          <!-- Mobile Speaker / Camera Notch -->
          <div class="w-24 h-4 bg-slate-950 rounded-full mx-auto mb-2"></div>

          @if (activeApp() === 'COURIER') {
            <!-- Courier App Screen (Requirement 86) -->
            <div class="space-y-3 text-xs">
              <div class="flex items-center justify-between border-b border-slate-800 pb-2">
                <span class="font-bold text-emerald-400 text-sm">邮政极速揽派 PDA</span>
                <span class="text-[10px] text-slate-400 font-mono">王敏 (88102)</span>
              </div>

              <div class="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
                <div class="text-[10px] text-slate-400">今日待派任务</div>
                <div class="text-xl font-bold font-mono text-emerald-300">12 件 / 剩余40分钟</div>
                <div class="text-[10px] text-emerald-400">R 路径推荐: 建议先派送 国贸大厦B座</div>
              </div>

              <!-- Task List -->
              <div class="space-y-2">
                <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800 space-y-1">
                  <div class="flex justify-between font-bold">
                    <span>包裹 1100982301982</span>
                    <span class="text-amber-400">特快专递</span>
                  </div>
                  <div class="text-slate-400 text-[11px]">收件人: 李四 (国贸A座 1802)</div>
                  <div class="flex space-x-1 pt-1">
                    <button (click)="actionSign()" class="flex-1 bg-emerald-600 text-slate-950 font-bold py-1 rounded text-[10px]">
                      扫码签收
                    </button>
                    <button (click)="actionPhoto()" class="bg-slate-800 text-slate-200 px-2 py-1 rounded text-[10px]">
                      拍照上传
                    </button>
                  </div>
                </div>
              </div>
            </div>
          } @else {
            <!-- Customer App Screen (Requirement 87) -->
            <div class="space-y-3 text-xs">
              <div class="flex items-center justify-between border-b border-slate-800 pb-2">
                <span class="font-bold text-emerald-400 text-sm">EMS 邮政速递官微</span>
                <span class="text-[10px] text-slate-400">绿色碳积分: 280 分</span>
              </div>

              <div class="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-2">
                <div class="font-bold text-slate-200">您有一件特快包裹派送中</div>
                <div class="text-[11px] text-emerald-400 font-mono">单号: 1100982301982</div>
                <div class="text-[10px] text-slate-400">快递员: 王敏 (138****9120) 距您 300 米</div>

                <button (click)="openLockerRemote()" class="w-full bg-emerald-600 text-slate-950 font-bold py-1.5 rounded-lg text-xs">
                  一键远程开柜 (智能快递柜)
                </button>
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class MobileCourierComponent {
  activeApp = signal<'COURIER' | 'CUSTOMER'>('COURIER');

  actionSign() {
    alert('已成功拍照并上传数字签名，包裹状态已同步更新至数字孪生节点！');
  }

  actionPhoto() {
    alert('已调起 PDA 相机拍摄妥投照片');
  }

  openLockerRemote() {
    alert('智能快递柜 08号门锁已远程解锁！');
  }
}
