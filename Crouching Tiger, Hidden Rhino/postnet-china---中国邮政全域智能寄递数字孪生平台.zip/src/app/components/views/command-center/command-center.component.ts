import { Component, ChangeDetectionStrategy, inject, ElementRef, ViewChild, AfterViewInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService, FacilityNode } from '../../../services/digital-twin.service';
import * as THREE from 'three';

@Component({
  selector: 'app-command-center',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-4 md:p-6 bg-slate-950 min-h-screen text-slate-100 space-y-6">
      <!-- Top KPIs Bar (Requirement 10 & 73) -->
      <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-3.5 shadow-lg relative overflow-hidden group hover:border-emerald-500/50 transition-all">
          <div class="flex items-center justify-between text-slate-400 mb-1 text-xs">
            <span>今日收寄总量</span>
            <mat-icon class="text-emerald-400 text-sm">move_to_inbox</mat-icon>
          </div>
          <div class="text-lg md:text-xl font-bold font-mono text-emerald-400">
            {{ (dtService.kpis().today_received_volume / 10000).toFixed(1) }} 万件
          </div>
          <div class="text-[10px] text-emerald-500/80 mt-1 flex items-center">
            <span>↑ +12.4% 比昨日同期</span>
          </div>
        </div>

        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-3.5 shadow-lg relative overflow-hidden group hover:border-emerald-500/50 transition-all">
          <div class="flex items-center justify-between text-slate-400 mb-1 text-xs">
            <span>今日妥投总量</span>
            <mat-icon class="text-emerald-400 text-sm">mark_email_read</mat-icon>
          </div>
          <div class="text-lg md:text-xl font-bold font-mono text-emerald-300">
            {{ (dtService.kpis().today_delivered_volume / 10000).toFixed(1) }} 万件
          </div>
          <div class="text-[10px] text-emerald-500/80 mt-1 flex items-center">
            <span>末端妥投率 {{ dtService.kpis().last_mile_delivery_rate_pct }}%</span>
          </div>
        </div>

        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-3.5 shadow-lg relative overflow-hidden group hover:border-cyan-500/50 transition-all">
          <div class="flex items-center justify-between text-slate-400 mb-1 text-xs">
            <span>运输中干线邮件</span>
            <mat-icon class="text-cyan-400 text-sm">local_shipping</mat-icon>
          </div>
          <div class="text-lg md:text-xl font-bold font-mono text-cyan-300">
            {{ (dtService.kpis().in_transit_volume / 10000).toFixed(1) }} 万件
          </div>
          <div class="text-[10px] text-cyan-400/80 mt-1">
            <span>平均运输: {{ dtService.kpis().avg_transit_time_hrs }} 小时</span>
          </div>
        </div>

        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-3.5 shadow-lg relative overflow-hidden group hover:border-amber-500/50 transition-all">
          <div class="flex items-center justify-between text-slate-400 mb-1 text-xs">
            <span>处理中心时效</span>
            <mat-icon class="text-amber-400 text-sm">account_tree</mat-icon>
          </div>
          <div class="text-lg md:text-xl font-bold font-mono text-amber-300">
            {{ dtService.kpis().avg_processing_time_mins }} 分钟
          </div>
          <div class="text-[10px] text-amber-400/80 mt-1">
            <span>吞吐: {{ (dtService.kpis().sorting_throughput_hourly / 10000).toFixed(0) }} 万件/时</span>
          </div>
        </div>

        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-3.5 shadow-lg relative overflow-hidden group hover:border-indigo-500/50 transition-all">
          <div class="flex items-center justify-between text-slate-400 mb-1 text-xs">
            <span>运力综合利用率</span>
            <mat-icon class="text-indigo-400 text-sm">flight_land</mat-icon>
          </div>
          <div class="text-lg md:text-xl font-bold font-mono text-indigo-300">
            {{ dtService.kpis().vehicle_utilization_pct }}%
          </div>
          <div class="text-[10px] text-indigo-400/80 mt-1">
            <span>航空 {{ dtService.kpis().air_capacity_utilization_pct }}% | 铁路 {{ dtService.kpis().rail_capacity_utilization_pct }}%</span>
          </div>
        </div>

        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-3.5 shadow-lg relative overflow-hidden group hover:border-rose-500/50 transition-all">
          <div class="flex items-center justify-between text-slate-400 mb-1 text-xs">
            <span>实时预警/异常件</span>
            <mat-icon class="text-rose-400 text-sm">warning</mat-icon>
          </div>
          <div class="text-lg md:text-xl font-bold font-mono text-rose-400">
            {{ dtService.kpis().exceptions_count }} 件
          </div>
          <div class="text-[10px] text-rose-400/80 mt-1">
            <span>主要异常: 节点满负荷拥堵</span>
          </div>
        </div>
      </div>

      <!-- Main Layout Grid (Left: Network/Facilities, Center: 3D Network Twin, Right: Exception Feed) -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Left Panel: Regional Facilities & Operations Hierarchy -->
        <div class="lg:col-span-3 space-y-4">
          <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3">
            <div class="flex items-center justify-between text-sm font-semibold text-emerald-400 border-b border-slate-800 pb-2">
              <span class="flex items-center space-x-1.5">
                <mat-icon class="text-base">hub</mat-icon>
                <span>全国核心处理枢纽状态</span>
              </span>
              <span class="text-xs text-slate-400 font-mono">5大枢纽</span>
            </div>

            <div class="space-y-2.5 text-xs">
              @for (f of dtService.facilities(); track f.id) {
                <button 
                  type="button"
                  (click)="selectFacility(f)"
                  class="w-full text-left bg-slate-950 p-3 rounded-xl border border-slate-800 hover:border-emerald-500/50 cursor-pointer transition-all space-y-1.5">
                  <div class="flex items-center justify-between font-medium">
                    <span class="text-slate-200">{{ f.name }}</span>
                    <span 
                      [class]="f.status === 'CONGESTED' ? 'bg-rose-950 text-rose-400 border-rose-800' : 'bg-emerald-950 text-emerald-400 border-emerald-800'"
                      class="text-[10px] px-2 py-0.5 rounded-full border font-semibold">
                      {{ f.status === 'CONGESTED' ? '拥堵预警' : '正常运行' }}
                    </span>
                  </div>

                  <!-- Volume Bar -->
                  <div class="space-y-1">
                    <div class="flex justify-between text-[11px] text-slate-400 font-mono">
                      <span>负荷率: {{ f.utilization_pct }}%</span>
                      <span>{{ (f.hourly_volume/10000).toFixed(1) }} / {{ (f.capacity/10000).toFixed(1) }}万件</span>
                    </div>
                    <div class="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                      <div 
                        [style.width.%]="f.utilization_pct"
                        [class]="f.utilization_pct >= 95 ? 'bg-rose-500' : f.utilization_pct >= 85 ? 'bg-amber-400' : 'bg-emerald-400'"
                        class="h-full transition-all duration-500">
                      </div>
                    </div>
                  </div>

                  <div class="flex justify-between text-[10px] text-slate-500 font-mono pt-0.5">
                    <span>AGV: {{ f.agv_count }} 台</span>
                    <span>传送带: {{ f.conveyor_speed_m_s }} m/s</span>
                  </div>
                </button>
              }
            </div>
          </div>

          <!-- Multimodal Transport Summary Card -->
          <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3">
            <div class="text-sm font-semibold text-cyan-400 border-b border-slate-800 pb-2 flex items-center space-x-1.5">
              <mat-icon class="text-base">alt_route</mat-icon>
              <span>多式联运运力配比</span>
            </div>
            <div class="space-y-2 text-xs">
              <div class="flex items-center justify-between text-slate-300">
                <span class="flex items-center space-x-1">
                  <mat-icon class="text-xs text-sky-400">flight</mat-icon>
                  <span>邮航专用机队</span>
                </span>
                <span class="font-mono text-sky-300">38 专线航班</span>
              </div>
              <div class="flex items-center justify-between text-slate-300">
                <span class="flex items-center space-x-1">
                  <mat-icon class="text-xs text-emerald-400">train</mat-icon>
                  <span>高铁极速达专列</span>
                </span>
                <span class="font-mono text-emerald-300">120 班列/日</span>
              </div>
              <div class="flex items-center justify-between text-slate-300">
                <span class="flex items-center space-x-1">
                  <mat-icon class="text-xs text-amber-400">directions_truck</mat-icon>
                  <span>干线绿色重卡</span>
                </span>
                <span class="font-mono text-amber-300">8,450 车辆</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Center Panel: 3D Nationwide Postal Digital Twin Canvas (Section 5) -->
        <div class="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between relative overflow-hidden min-h-[520px]">
          <div class="flex items-center justify-between z-10 bg-slate-950/80 backdrop-blur border border-slate-800 p-2.5 rounded-xl text-xs">
            <div class="flex items-center space-x-2">
              <span class="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></span>
              <span class="font-bold text-slate-200">全国3D物流数字孪生网络 (PostNet China 3D)</span>
            </div>
            <div class="flex items-center space-x-2 text-[11px] text-slate-400">
              <span class="flex items-center space-x-1">
                <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
                <span>枢纽节点</span>
              </span>
              <span class="flex items-center space-x-1">
                <span class="w-2 h-2 rounded-full bg-cyan-400"></span>
                <span>航空干线</span>
              </span>
              <span class="flex items-center space-x-1">
                <span class="w-2 h-2 rounded-full bg-amber-400"></span>
                <span>公路干线</span>
              </span>
            </div>
          </div>

          <!-- Three.js Canvas Container -->
          <div #canvasContainer class="absolute inset-0 w-full h-full rounded-2xl"></div>

          <!-- Bottom Floating Quick Overlay Info -->
          <div class="z-10 bg-slate-950/90 border border-slate-800 p-3 rounded-xl backdrop-blur flex items-center justify-between text-xs mt-auto">
            <div class="flex items-center space-x-3">
              <mat-icon class="text-emerald-400 text-lg">3d_rotation</mat-icon>
              <div>
                <div class="font-medium text-slate-200">支持 3D 节点交互与三层数字孪生下钻</div>
                <div class="text-[10px] text-slate-400">物理层 (车辆/枢纽) ↔ 物流层 (邮件/任务) ↔ 客户层 (寄收件人) 统一全局ID</div>
              </div>
            </div>
            <button 
              (click)="dtService.activeTab.set('gis-map')"
              class="bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold px-3 py-1.5 rounded-lg text-xs transition-all flex items-center space-x-1">
              <span>进入GIS地图</span>
              <mat-icon class="text-xs">arrow_forward</mat-icon>
            </button>
          </div>
        </div>

        <!-- Right Panel: Real-time Exceptions Feed & Parcel Inspector -->
        <div class="lg:col-span-3 space-y-4">
          <!-- Real-Time Exception Stream -->
          <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3">
            <div class="flex items-center justify-between text-sm font-semibold text-rose-400 border-b border-slate-800 pb-2">
              <span class="flex items-center space-x-1.5">
                <mat-icon class="text-base">error_outline</mat-icon>
                <span>实时网络异常事件流</span>
              </span>
              <span class="text-xs text-rose-400/80 font-mono">实时更新</span>
            </div>

            <div class="space-y-2.5 text-xs max-h-[220px] overflow-y-auto pr-1">
              <div class="bg-rose-950/40 border border-rose-800/60 p-2.5 rounded-xl space-y-1">
                <div class="flex items-center justify-between font-semibold text-rose-300">
                  <span>北京航空处理中心容量饱和</span>
                  <span class="text-[10px] font-mono text-rose-400">14:02:10</span>
                </div>
                <p class="text-[11px] text-slate-300">
                  受大雾天气影响，进港航班延误，分拣排队队列超过 12,000 件。
                </p>
                <div class="text-[10px] text-emerald-400 font-mono pt-1">
                  [建议操作]: R算法建议分流至石家庄备用枢纽
                </div>
              </div>

              <div class="bg-amber-950/40 border border-amber-800/60 p-2.5 rounded-xl space-y-1">
                <div class="flex items-center justify-between font-semibold text-amber-300">
                  <span>G60沪昆高速局部道路维护</span>
                  <span class="text-[10px] font-mono text-amber-400">13:45:30</span>
                </div>
                <p class="text-[11px] text-slate-300">
                  杭州至金华段车速降至 35km/h，预测 142 班干线货车可能超时 30 分钟。
                </p>
              </div>

              <div class="bg-slate-950 border border-slate-800 p-2.5 rounded-xl space-y-1">
                <div class="flex items-center justify-between font-semibold text-slate-300">
                  <span>百江村无人机投递完成</span>
                  <span class="text-[10px] font-mono text-emerald-400">13:20:15</span>
                </div>
                <p class="text-[11px] text-slate-400">
                  邮航-UAV-09 成功克服山区阵风，将急救药品妥投至村民手上。
                </p>
              </div>
            </div>
          </div>

          <!-- Parcel Twin Quick Lookup Panel (Requirement 7, 8, 9) -->
          <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3">
            <div class="flex items-center justify-between text-sm font-semibold text-emerald-400 border-b border-slate-800 pb-2">
              <span class="flex items-center space-x-1.5">
                <mat-icon class="text-base">inventory_2</mat-icon>
                <span>包裹数字孪生抽样 (Parcel Twin)</span>
              </span>
            </div>

            <div class="space-y-2 text-xs">
              @for (p of dtService.parcels().slice(0, 3); track p.tracking_id) {
                <button 
                  type="button"
                  (click)="dtService.selectedParcel.set(p)"
                  class="w-full text-left bg-slate-950 p-2.5 rounded-xl border border-slate-800 hover:border-emerald-500/50 cursor-pointer space-y-1 transition-all">
                  <div class="flex items-center justify-between font-mono font-bold text-emerald-300">
                    <span>{{ p.tracking_id }}</span>
                    <span class="text-[10px] text-slate-400 bg-slate-800 px-1.5 py-0.5 rounded">{{ p.service_type }}</span>
                  </div>
                  <div class="text-[11px] text-slate-300 flex items-center justify-between">
                    <span>{{ p.origin }} → {{ p.destination }}</span>
                    <span class="text-emerald-400 font-semibold">{{ p.status }}</span>
                  </div>
                  <div class="text-[10px] text-slate-400 flex justify-between font-mono">
                    <span>ETA: {{ p.eta }}</span>
                    <span>超时风险: {{ p.delay_probability_pct }}%</span>
                  </div>
                </button>
              }
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class CommandCenterComponent implements AfterViewInit, OnDestroy {
  dtService = inject(DigitalTwinService);
  @ViewChild('canvasContainer') canvasContainer!: ElementRef<HTMLDivElement>;

  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private animationFrameId = 0;

  ngAfterViewInit() {
    this.init3DScene();
  }

  ngOnDestroy() {
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
  }

  selectFacility(facility: FacilityNode) {
    alert(`已选中数字孪生节点: ${facility.name}\n全局ID: ${facility.id}\n负荷率: ${facility.utilization_pct}%\n正在从后端获取实时AGV与传感器数据...`);
  }

  private init3DScene() {
    const container = this.canvasContainer.nativeElement;
    const width = container.clientWidth || 600;
    const height = container.clientHeight || 500;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x020617); // Slate 950

    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    this.camera.position.set(0, 15, 25);
    this.camera.lookAt(0, 0, 0);

    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(this.renderer.domElement);

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
    this.scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0x10b981, 1.5);
    dirLight.position.set(10, 20, 10);
    this.scene.add(dirLight);

    // Grid Floor
    const gridHelper = new THREE.GridHelper(30, 30, 0x1e293b, 0x0f172a);
    this.scene.add(gridHelper);

    // Node Positions for 5 Major Hubs
    const nodeCoords = [
      { id: 'SH', pos: new THREE.Vector3(5, 0.5, 2), color: 0x10b981, name: '上海枢纽' },
      { id: 'BJ', pos: new THREE.Vector3(2, 0.5, -6), color: 0xf43f5e, name: '北京枢纽' },
      { id: 'GZ', pos: new THREE.Vector3(3, 0.5, 8), color: 0x10b981, name: '广州枢纽' },
      { id: 'CQ', pos: new THREE.Vector3(-6, 0.5, 5), color: 0x10b981, name: '重庆枢纽' },
      { id: 'WH', pos: new THREE.Vector3(-1, 0.5, 1), color: 0x10b981, name: '武汉枢纽' },
    ];

    const nodesGroup = new THREE.Group();

    nodeCoords.forEach(nc => {
      // Create Hub Cylinder
      const geo = new THREE.CylinderGeometry(0.8, 0.8, 0.6, 16);
      const mat = new THREE.MeshPhongMaterial({ color: nc.color, emissive: nc.color, emissiveIntensity: 0.3 });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.copy(nc.pos);
      nodesGroup.add(mesh);

      // Pulse Ring
      const ringGeo = new THREE.RingGeometry(0.9, 1.1, 16);
      const ringMat = new THREE.MeshBasicMaterial({ color: nc.color, side: THREE.DoubleSide, transparent: true, opacity: 0.6 });
      const ring = new THREE.Mesh(ringGeo, ringMat);
      ring.rotation.x = Math.PI / 2;
      ring.position.copy(nc.pos);
      ring.position.y = 0.05;
      nodesGroup.add(ring);
    });

    this.scene.add(nodesGroup);

    // Connect Lines (Highways / Air Lines)
    const lineMat = new THREE.LineDashedMaterial({ color: 0x38bdf8, dashSize: 0.5, gapSize: 0.2 });

    const connections = [
      [nodeCoords[0].pos, nodeCoords[1].pos], // SH - BJ
      [nodeCoords[0].pos, nodeCoords[2].pos], // SH - GZ
      [nodeCoords[0].pos, nodeCoords[4].pos], // SH - WH
      [nodeCoords[4].pos, nodeCoords[3].pos], // WH - CQ
      [nodeCoords[1].pos, nodeCoords[4].pos], // BJ - WH
    ];

    connections.forEach(([p1, p2]) => {
      const mid = new THREE.Vector3().addVectors(p1, p2).multiplyScalar(0.5);
      mid.y += 2.5; // Curve height

      const curve = new THREE.QuadraticBezierCurve3(p1, mid, p2);
      const curvePoints = curve.getPoints(20);
      const lineGeo = new THREE.BufferGeometry().setFromPoints(curvePoints);
      const line = new THREE.Line(lineGeo, lineMat);
      line.computeLineDistances();
      this.scene.add(line);
    });

    // Animation Loop
    const animate = () => {
      this.animationFrameId = requestAnimationFrame(animate);
      nodesGroup.rotation.y += 0.002;
      this.renderer.render(this.scene, this.camera);
    };

    animate();
  }
}
