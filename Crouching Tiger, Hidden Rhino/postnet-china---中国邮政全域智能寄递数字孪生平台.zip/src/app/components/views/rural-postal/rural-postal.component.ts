import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../../services/digital-twin.service';

@Component({
  selector: 'app-rural-postal',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-4 md:p-6 bg-slate-950 min-h-screen text-slate-100 space-y-6">
      <!-- Title Bar -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <div class="flex items-center space-x-2">
            <h2 class="text-base font-bold text-emerald-400">
              农村三级物流寄递体系数字孪生 (County-Township-Village 3-Tier Logistics)
            </h2>
            <span class="bg-emerald-950 text-emerald-300 border border-emerald-800 text-[10px] font-semibold px-2 py-0.5 rounded-full">
              乡村振兴 + 农产品直邮上行
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-0.5">
            县级公共配送中心 → 乡镇邮政所 → 村级寄递物流综合服务站 → 农户
          </p>
        </div>

        <button 
          (click)="runRuralOptimization()" 
          [disabled]="isOptimizingRural()"
          class="bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-slate-950 font-bold px-4 py-2 rounded-xl text-xs transition-all flex items-center space-x-1.5 shadow-lg shadow-emerald-600/20">
          <mat-icon class="text-sm">cottage</mat-icon>
          <span>{{ isOptimizingRural() ? 'R 乡村路径优化中...' : '优化县-乡-村三级串行配送线路' }}</span>
        </button>
      </div>

      <!-- 3-Tier Hierarchy Diagram & Topology Card -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- 3-Tier Interactive Diagram (Section 23 & 24) -->
        <div class="lg:col-span-8 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2 text-sm font-bold text-emerald-400">
            <span>浙江省桐庐县三级寄递网络数字孪生 (示范区)</span>
            <span class="text-xs text-slate-400 font-mono">建有村级服务站 500 个</span>
          </div>

          <!-- Topology Diagram -->
          <div class="bg-slate-950 p-6 rounded-xl border border-slate-800 space-y-6 text-xs">
            <!-- Tier 1: County Center -->
            <div class="flex items-center space-x-4 bg-slate-900/80 p-4 rounded-xl border border-emerald-500/30">
              <div class="bg-emerald-600 text-slate-950 p-3 rounded-xl font-bold flex items-center justify-center">
                <mat-icon class="text-2xl">account_balance</mat-icon>
              </div>
              <div class="space-y-1">
                <div class="text-sm font-bold text-emerald-300">一级节点: 桐庐县公共寄递配送中心</div>
                <div class="text-slate-400">日均处理量: 85,000 件 | 集中自动化分拣分拨 | 统一客货邮融合车辆调度</div>
              </div>
            </div>

            <!-- Arrow Down -->
            <div class="flex justify-center text-emerald-500">
              <mat-icon>south</mat-icon>
            </div>

            <!-- Tier 2: Township Centers -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div class="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 space-y-1">
                <div class="flex items-center justify-between">
                  <span class="font-bold text-slate-200">二级节点: 分水镇邮政所</span>
                  <span class="text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-800 px-2 py-0.5 rounded-full">中转站</span>
                </div>
                <div class="text-slate-400 text-[11px]">辐射 18 个行政村 | 农产品冷链暂存点</div>
              </div>

              <div class="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 space-y-1">
                <div class="flex items-center justify-between">
                  <span class="font-bold text-slate-200">二级节点: 横村镇邮政所</span>
                  <span class="text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-800 px-2 py-0.5 rounded-full">中转站</span>
                </div>
                <div class="text-slate-400 text-[11px]">辐射 22 个行政村 | 针织电商直发网点</div>
              </div>
            </div>

            <!-- Arrow Down -->
            <div class="flex justify-center text-emerald-500">
              <mat-icon>south</mat-icon>
            </div>

            <!-- Tier 3: Village Service Stations -->
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div class="bg-slate-900 p-3 rounded-xl border border-slate-800 space-y-1">
                <div class="font-bold text-amber-300">三级节点: 新农村服务站</div>
                <div class="text-[10px] text-slate-400">综合服务: 邮寄/代缴费/电商自提</div>
              </div>
              <div class="bg-slate-900 p-3 rounded-xl border border-slate-800 space-y-1">
                <div class="font-bold text-amber-300">三级节点: 百江村代投点</div>
                <div class="text-[10px] text-slate-400">无人机末端降落点 (深山区)</div>
              </div>
              <div class="bg-slate-900 p-3 rounded-xl border border-slate-800 space-y-1">
                <div class="font-bold text-amber-300">三级节点: 高山高笋基地站</div>
                <div class="text-[10px] text-slate-400">农产品直邮上行极速揽收点</div>
              </div>
            </div>
          </div>

          <!-- Optimization Output Panel -->
          @if (ruralSimResult()) {
            <div class="bg-slate-950 p-4 rounded-xl border border-emerald-500/40 space-y-2 text-xs">
              <div class="font-bold text-emerald-400 flex items-center space-x-1.5">
                <mat-icon class="text-sm">verified</mat-icon>
                <span>R 语言 3-Tier 乡村物流网络优化方案 (rural_routes.R)</span>
              </div>
              <div class="grid grid-cols-3 gap-2 text-center font-mono">
                <div class="bg-slate-900 p-2 rounded-lg border border-slate-800">
                  <div class="text-slate-400 text-[10px]">综合运输成本降低</div>
                  <div class="text-emerald-400 font-bold text-sm">↓ 28.4%</div>
                </div>
                <div class="bg-slate-900 p-2 rounded-lg border border-slate-800">
                  <div class="text-slate-400 text-[10px]">村站覆盖率</div>
                  <div class="text-cyan-300 font-bold text-sm">100.0%</div>
                </div>
                <div class="bg-slate-900 p-2 rounded-lg border border-slate-800">
                  <div class="text-slate-400 text-[10px]">客货邮融合车次</div>
                  <div class="text-amber-300 font-bold text-sm">12 班列/日</div>
                </div>
              </div>
            </div>
          }
        </div>

        <!-- Right Side: Agricultural Products Direct Mail (农产品上行) Card -->
        <div class="lg:col-span-4 space-y-4">
          <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3">
            <div class="flex items-center justify-between text-sm font-semibold text-amber-400 border-b border-slate-800 pb-2">
              <span class="flex items-center space-x-1.5">
                <mat-icon class="text-base">eco</mat-icon>
                <span>农产品直邮上行极速鲜通道</span>
              </span>
              <span class="text-xs text-slate-400 font-mono">原产地直发</span>
            </div>

            <div class="space-y-2.5 text-xs">
              <div class="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1.5">
                <div class="flex items-center justify-between font-bold text-slate-200">
                  <span>桐庐高山高笋专业合作社</span>
                  <span class="text-emerald-400 font-mono">今日 1,420 件</span>
                </div>
                <p class="text-[11px] text-slate-400">
                  田头直接装车 → 县中心优先冷链专拨 → 华东航空枢纽 → 全国 24 小时达
                </p>
                <div class="text-[10px] text-emerald-400 font-mono">损耗率降低: 1.2% (传统渠道 8.5%)</div>
              </div>

              <div class="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1.5">
                <div class="flex items-center justify-between font-bold text-slate-200">
                  <span>烟台大樱桃极速鲜专线</span>
                  <span class="text-emerald-400 font-mono">今日 3,800 件</span>
                </div>
                <p class="text-[11px] text-slate-400">
                  果园原产地打码 → 专机航空直飞 → 同城优先派送
                </p>
                <div class="text-[10px] text-emerald-400 font-mono">平均全程耗时: 12.8 小时</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class RuralPostalComponent {
  dtService = inject(DigitalTwinService);

  isOptimizingRural = signal<boolean>(false);
  ruralSimResult = signal<unknown>(null);

  async runRuralOptimization() {
    this.isOptimizingRural.set(true);
    setTimeout(() => {
      this.ruralSimResult.set({
        status: 'SUCCESS',
        savings: '28.4%',
      });
      this.isOptimizingRural.set(false);
    }, 1200);
  }
}
