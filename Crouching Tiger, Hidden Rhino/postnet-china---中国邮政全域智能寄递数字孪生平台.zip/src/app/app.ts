import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DigitalTwinService } from './services/digital-twin.service';
import { HeaderComponent } from './components/header/header.component';
import { CommandCenterComponent } from './components/views/command-center/command-center.component';
import { GisMapComponent } from './components/views/gis-map/gis-map.component';
import { ProcessingCenterComponent } from './components/views/processing-center/processing-center.component';
import { LastMileComponent } from './components/views/last-mile/last-mile.component';
import { RuralPostalComponent } from './components/views/rural-postal/rural-postal.component';
import { UnmannedDeliveryComponent } from './components/views/unmanned-delivery/unmanned-delivery.component';
import { RLabComponent } from './components/views/r-lab/r-lab.component';
import { AiAssistantComponent } from './components/views/ai-assistant/ai-assistant.component';
import { MobileCourierComponent } from './components/views/mobile-courier/mobile-courier.component';
import { ScenarioLabComponent } from './components/views/scenario-lab/scenario-lab.component';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    HeaderComponent,
    CommandCenterComponent,
    GisMapComponent,
    ProcessingCenterComponent,
    LastMileComponent,
    RuralPostalComponent,
    UnmannedDeliveryComponent,
    RLabComponent,
    AiAssistantComponent,
    MobileCourierComponent,
    ScenarioLabComponent,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  dtService = inject(DigitalTwinService);
}
