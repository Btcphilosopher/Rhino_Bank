import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import { join } from 'node:path';
import { GoogleGenAI } from '@google/genai';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json({ limit: '10mb' }));

const angularApp = new AngularNodeAppEngine();

// Lazy Gemini AI Client Initialization
let genAIClient: GoogleGenAI | null = null;
function getGenAI(): GoogleGenAI | null {
  if (!genAIClient) {
    const apiKey = process.env['GEMINI_API_KEY'];
    if (apiKey) {
      genAIClient = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });
    }
  }
  return genAIClient;
}

// ==============================================================================
// DIGITAL TWIN SIMULATION DATA ENGINE (SIMULATION DATA explicitly tagged)
// ==============================================================================

const DIGITAL_TWIN_SUMMARY = {
  data_provenance: 'SIMULATION DATA',
  timestamp: new Date().toISOString(),
  kpis: {
    today_received_volume: 184520900,
    today_delivered_volume: 162980400,
    in_transit_volume: 48920150,
    sorting_throughput_hourly: 14200000,
    avg_processing_time_mins: 18.4,
    avg_transit_time_hrs: 14.2,
    last_mile_delivery_rate_pct: 98.76,
    exceptions_count: 3120,
    vehicle_utilization_pct: 88.4,
    air_capacity_utilization_pct: 92.1,
    rail_capacity_utilization_pct: 84.6,
  },
  facilities: [
    {
      id: 'PC-SHANGHAI-01',
      name: '华东上海邮件处理中心 (巨型中心)',
      level: 'PROCESSING_CENTER',
      province: '上海市',
      city: '上海市',
      lat: 31.2304,
      lng: 121.4737,
      status: 'NORMAL',
      hourly_volume: 380000,
      capacity: 450000,
      agv_count: 180,
      conveyor_speed_m_s: 2.5,
      utilization_pct: 84.4,
    },
    {
      id: 'PC-BEIJING-01',
      name: '华北北京航空邮件处理中心',
      level: 'PROCESSING_CENTER',
      province: '北京市',
      city: '北京市',
      lat: 39.9042,
      lng: 116.4074,
      status: 'CONGESTED',
      hourly_volume: 420000,
      capacity: 420000,
      agv_count: 220,
      conveyor_speed_m_s: 2.2,
      utilization_pct: 100.0,
    },
    {
      id: 'PC-GUANGZHOU-01',
      name: '华南广州智能邮件集散中心',
      level: 'PROCESSING_CENTER',
      province: '广东省',
      city: '广州市',
      lat: 23.1291,
      lng: 113.2644,
      status: 'NORMAL',
      hourly_volume: 350000,
      capacity: 400000,
      agv_count: 160,
      conveyor_speed_m_s: 2.8,
      utilization_pct: 87.5,
    },
    {
      id: 'PC-CHONGQING-01',
      name: '西南重庆陆港邮件枢纽',
      level: 'PROCESSING_CENTER',
      province: '重庆市',
      city: '重庆市',
      lat: 29.563,
      lng: 106.5516,
      status: 'NORMAL',
      hourly_volume: 210000,
      capacity: 280000,
      agv_count: 120,
      conveyor_speed_m_s: 2.4,
      utilization_pct: 75.0,
    },
    {
      id: 'PC-WUHAN-01',
      name: '华中武汉转运中心',
      level: 'PROCESSING_CENTER',
      province: '湖北省',
      city: '武汉市',
      lat: 30.5928,
      lng: 114.3055,
      status: 'NORMAL',
      hourly_volume: 290000,
      capacity: 340000,
      agv_count: 150,
      conveyor_speed_m_s: 2.6,
      utilization_pct: 85.3,
    },
  ],
  rural_nodes: [
    { id: 'COUNTY-101', name: '桐庐县中心', type: 'COUNTY_CENTER', province: '浙江省', city: '杭州市', lat: 29.7978, lng: 119.6896 },
    { id: 'TOWN-201', name: '分水镇邮政所', type: 'TOWNSHIP_CENTER', province: '浙江省', city: '杭州市', lat: 29.8732, lng: 119.5211 },
    { id: 'VILLAGE-301', name: '新农村寄递服务站', type: 'VILLAGE_STATION', province: '浙江省', city: '杭州市', lat: 29.9102, lng: 119.4891 },
    { id: 'VILLAGE-302', name: '百江村代投点', type: 'VILLAGE_STATION', province: '浙江省', city: '杭州市', lat: 29.9321, lng: 119.4120 }
  ]
};

// ==============================================================================
// EXPRESS API ROUTES
// ==============================================================================

// Digital Twin Stats Endpoint
app.get('/api/digital-twin/stats', (req, res) => {
  return res.json(DIGITAL_TWIN_SUMMARY);
});

// R Optimization Engine Simulation Routes
app.post('/api/r/route/optimize', (req, res) => {
  const { customers, vehicles } = req.body;
  const numCust = (customers && customers.length) || 20;
  const numVeh = (vehicles && vehicles.length) || 5;

  const routes = [];
  let totalDist = 0;
  let totalDur = 0;

  for (let i = 0; i < numVeh; i++) {
    const stopsCount = Math.ceil(numCust / numVeh);
    const dist = +(12.5 + Math.random() * 8).toFixed(2);
    const dur = +(45 + Math.random() * 25).toFixed(1);
    totalDist += dist;
    totalDur += dur;

    const sequence = Array.from({ length: stopsCount }, (_, idx) => (i * stopsCount) + idx + 1).filter(n => n <= numCust);

    routes.push({
      route_id: `RUT-R-OPT-${i + 1}`,
      courier_id: `COU-EV-${101 + i}`,
      vehicle_id: vehicles?.[i]?.vehicle_id || `VEH-EV-${i + 1}`,
      sequence,
      stops_count: sequence.length,
      distance_km: dist,
      duration_min: dur,
      parcel_count: sequence.length,
      capacity_used_pct: +(75 + Math.random() * 20).toFixed(1),
    });
  }

  return res.json({
    provenance: 'SIMULATION DATA',
    engine: 'R/ompr/lpSolve VRPTW Solver v2.4',
    status: 'OPTIMAL',
    algorithm: 'R VRPTW Insertion-Savings Hybrid with Time Windows',
    objective: 'Minimize total travel distance, fleet count, and empty mileage',
    objective_value: +totalDist.toFixed(2),
    summary: {
      before_distance_km: +(totalDist * 1.34).toFixed(2),
      after_distance_km: +totalDist.toFixed(2),
      distance_savings_pct: 25.37,
      before_time_mins: +(totalDur * 1.28).toFixed(1),
      after_time_mins: +totalDur.toFixed(1),
      time_savings_pct: 21.87,
      vehicles_used: routes.length,
      co2_reduction_kg: +(totalDist * 0.14).toFixed(2),
      empty_mileage_pct: 4.2,
    },
    routes,
  });
});

app.post('/api/r/facility/optimize', (req, res) => {
  const { max_lockers } = req.body;
  const count = max_lockers || 8;

  const sites = [];
  for (let i = 0; i < count; i++) {
    sites.push({
      site_id: `LOCKER-SITE-${100 + i}`,
      candidate_name: `社区智能快递柜站点 ${i + 1}号`,
      lat: +(31.22 + (Math.random() - 0.5) * 0.08).toFixed(4),
      lng: +(121.46 + (Math.random() - 0.5) * 0.08).toFixed(4),
      capacity_compartments: 80 + (i % 3) * 20,
      walking_radius_m: 300,
      coverage_population: Math.floor(1800 + Math.random() * 2200),
      estimated_utilization_pct: +(88 + Math.random() * 10).toFixed(1),
      roi_score: +(8.4 + Math.random() * 1.4).toFixed(2),
    });
  }

  return res.json({
    provenance: 'SIMULATION DATA',
    engine: 'R/postoptR/locker_location.R',
    status: 'OPTIMAL',
    coverage_percentage: 94.85,
    selected_sites: sites,
  });
});

app.post('/api/r/simulation', (req, res) => {
  const { arrival_rate = 120000, service_rate = 25000, num_channels = 5 } = req.body;
  const rho = +(arrival_rate / (num_channels * service_rate)).toFixed(3);

  const timeline = [];
  for (let h = 1; h <= 24; h++) {
    const vol = Math.round(arrival_rate * (1 + 0.35 * Math.sin((h - 8) * Math.PI / 12)));
    const util = Math.min(99.9, +(rho * 100 * (1 + 0.35 * Math.sin((h - 8) * Math.PI / 12))).toFixed(1));
    const delay = +(Math.max(0.5, 3.2 * (1 + 0.5 * Math.sin((h - 8) * Math.PI / 12)))).toFixed(1);
    timeline.push({
      hour: `${h.toString().padStart(2, '0')}:00`,
      volume: vol,
      utilization_pct: util,
      avg_delay_mins: delay,
      overflow_risk: util > 92 ? 'HIGH' : util > 80 ? 'MEDIUM' : 'LOW',
    });
  }

  return res.json({
    provenance: 'SIMULATION DATA',
    engine: 'R/postalSimR/processing_center.R M/M/c Queue Model',
    status: 'SUCCESS',
    utilization_pct: +(rho * 100).toFixed(1),
    is_bottleneck: rho >= 0.88,
    avg_queue_wait_mins: +(rho * 4.8).toFixed(2),
    agv_required_count: Math.ceil(rho * 180),
    timeline,
  });
});

app.post('/api/r/forecast', (req, res) => {
  const { horizon_days = 7 } = req.body;
  const regions = ['华东区域', '华南区域', '华北区域', '华中区域', '西南区域', '西北区域', '东北区域'];
  const forecasts = [];

  const baseDate = new Date();
  for (let d = 1; d <= horizon_days; d++) {
    const targetDate = new Date(baseDate);
    targetDate.setDate(targetDate.getDate() + d);
    const dateStr = targetDate.toISOString().split('T')[0];

    for (const r of regions) {
      const baseVol = r === '华东区域' ? 38000000 : r === '华南区域' ? 29000000 : 18000000;
      const vol = Math.round(baseVol * (1 + (Math.random() - 0.5) * 0.08));
      forecasts.push({
        region: r,
        date: dateStr,
        forecast_volume: vol,
        ci_lower: Math.round(vol * 0.94),
        ci_upper: Math.round(vol * 1.06),
      });
    }
  }

  return res.json({
    provenance: 'SIMULATION DATA',
    engine: 'R/fable/forecast Hierarchical ARIMA-XGBoost',
    status: 'SUCCESS',
    horizon_days,
    forecasts,
  });
});

// AI Postal Assistant Endpoint (Gemini 3.8 Flash)
app.post('/api/gemini/assistant', async (req, res) => {
  try {
    const { prompt, contextState } = req.body;
    const ai = getGenAI();

    if (!ai) {
      return res.json({
        provenance: 'SIMULATION DATA',
        answer: `【系统提示：未配置 GEMINI_API_KEY】
您咨询的问题："${prompt}"
根据POSTNET CHINA数字孪生实时数据分析：
1. **全国物流网络状态**：目前全国共处理邮件 1.84 亿件，妥投率 98.76%，运输中包裹 4,892 万件。
2. **瓶颈诊断**：华北北京航空邮件处理中心处于满负荷拥堵状态 (负荷率 100%)。
3. **R优化建议**：建议调用 \`r/network/resilience.R\` 针对华北枢纽执行动态分流，将 18% 航空小包临时切换至京沪高铁快速揽收通道，预计可降低北京中心 14.5% 延迟。`,
        actionRecommended: 'EXECUTE_R_REROUTE',
      });
    }

    const systemInstruction = `你是在中国邮政全域智慧寄递数字孪生平台 (POSTNET CHINA) 中运行的 AI 邮政智能运营助手。
你的主要工作是解答全国邮政网络运营人员提出的问题，包括但不限于：
- 哪些处理中心拥堵？哪些线路容量不足？
- 如何通过 R 语言 Operations Research (VRPTW, Queueing Theory, Facility Location) 优化最后一公里配送与车辆空载率？
- 乡村三级寄递网络（县-乡-村）的配送道段与代投点优化建议；
- 应急灾害或公路/机场中断时的备选路由重排。

请始终保持专业、数据驱动、条理清晰的语气。在适当的时候引用 R 算法模型（如 ompr, lpSolve, fable, igraph）和数字孪生实体（处理中心、无人车、无人机、快递柜）。`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `[当前数字孪生状态]: ${JSON.stringify(contextState || DIGITAL_TWIN_SUMMARY.kpis)}
[用户提问]: ${prompt}`,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    return res.json({
      provenance: 'SIMULATION DATA',
      answer: response.text,
      status: 'SUCCESS',
    });
  } catch (error: unknown) {
    const errMessage = error instanceof Error ? error.message : 'Error processing AI query';
    console.error('Gemini Assistant Error:', error);
    return res.status(500).json({ error: errMessage });
  }
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }
    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

export const reqHandler = createNodeRequestHandler(app);
