package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.TokyoMetroData

@Composable
fun NetworkMapCanvas(
    selectedStationJa: String? = "渋谷",
    onStationSelect: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(260.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF0F172A))
            .testTag("network_map_canvas")
    ) {
        Canvas(
            modifier = Modifier
                .matchParentSize()
                .pointerInput(Unit) {
                    detectTapGestures { offset ->
                        // Detect tap near station nodes
                        val w = size.width
                        val h = size.height

                        // Sample coordinates map for key nodes
                        val nodeCoords = mapOf(
                            "渋谷" to Offset(w * 0.18f, h * 0.75f),
                            "表参道" to Offset(w * 0.32f, h * 0.65f),
                            "青山一丁目" to Offset(w * 0.44f, h * 0.58f),
                            "赤坂見附" to Offset(w * 0.55f, h * 0.50f),
                            "銀座" to Offset(w * 0.72f, h * 0.52f),
                            "東京" to Offset(w * 0.75f, h * 0.35f),
                            "新宿" to Offset(w * 0.25f, h * 0.35f),
                            "大手町" to Offset(w * 0.82f, h * 0.38f),
                            "上野" to Offset(w * 0.85f, h * 0.20f),
                            "池袋" to Offset(w * 0.45f, h * 0.15f)
                        )

                        nodeCoords.entries.firstOrNull { (_, pos) ->
                            val dx = offset.x - pos.x
                            val dy = offset.y - pos.y
                            (dx * dx + dy * dy) < 1200f
                        }?.let { (name, _) ->
                            onStationSelect(name)
                        }
                    }
                }
        ) {
            val w = size.width
            val h = size.height

            // Key station node coordinates
            val shibuya = Offset(w * 0.18f, h * 0.75f)
            val omotesando = Offset(w * 0.32f, h * 0.65f)
            val aoyama = Offset(w * 0.44f, h * 0.58f)
            val akasaka = Offset(w * 0.55f, h * 0.50f)
            val ginza = Offset(w * 0.72f, h * 0.52f)
            val tokyo = Offset(w * 0.75f, h * 0.35f)
            val shinjuku = Offset(w * 0.25f, h * 0.35f)
            val otemachi = Offset(w * 0.82f, h * 0.38f)
            val ueno = Offset(w * 0.85f, h * 0.20f)
            val ikebukuro = Offset(w * 0.45f, h * 0.15f)

            // Ginza Line (G) - Orange
            val ginzaPath = Path().apply {
                moveTo(shibuya.x, shibuya.y)
                lineTo(omotesando.x, omotesando.y)
                lineTo(aoyama.x, aoyama.y)
                lineTo(akasaka.x, akasaka.y)
                lineTo(ginza.x, ginza.y)
                lineTo(ueno.x, ueno.y)
            }
            drawPath(
                path = ginzaPath,
                color = Color(0xFFF39700),
                style = Stroke(width = 8f)
            )

            // Marunouchi Line (M) - Red
            val marunouchiPath = Path().apply {
                moveTo(shinjuku.x, shinjuku.y)
                lineTo(akasaka.x, akasaka.y)
                lineTo(ginza.x, ginza.y)
                lineTo(tokyo.x, tokyo.y)
                lineTo(otemachi.x, otemachi.y)
                lineTo(ikebukuro.x, ikebukuro.y)
            }
            drawPath(
                path = marunouchiPath,
                color = Color(0xFFE60012),
                style = Stroke(width = 6f)
            )

            // Hanzomon Line (Z) - Purple
            val hanzomonPath = Path().apply {
                moveTo(shibuya.x, shibuya.y)
                lineTo(omotesando.x, omotesando.y)
                lineTo(aoyama.x, aoyama.y)
                lineTo(otemachi.x, otemachi.y)
            }
            drawPath(
                path = hanzomonPath,
                color = Color(0xFF8F4B9B),
                style = Stroke(width = 5f)
            )

            // Draw station nodes
            val nodes = mapOf(
                "渋谷" to shibuya,
                "表参道" to omotesando,
                "青山一丁目" to aoyama,
                "赤坂見附" to akasaka,
                "銀座" to ginza,
                "東京" to tokyo,
                "新宿" to shinjuku,
                "大手町" to otemachi,
                "上野" to ueno,
                "池袋" to ikebukuro
            )

            nodes.forEach { (name, pos) ->
                val isSelected = name == selectedStationJa
                val radius = if (isSelected) 14f else 9f
                val ringColor = if (isSelected) Color(0xFF38BDF8) else Color.White

                drawCircle(
                    color = Color.Black,
                    radius = radius + 4f,
                    center = pos
                )
                drawCircle(
                    color = ringColor,
                    radius = radius,
                    center = pos
                )
                if (isSelected) {
                    drawCircle(
                        color = Color(0xFF00A7E1),
                        radius = 6f,
                        center = pos
                    )
                }
            }
        }
    }
}
