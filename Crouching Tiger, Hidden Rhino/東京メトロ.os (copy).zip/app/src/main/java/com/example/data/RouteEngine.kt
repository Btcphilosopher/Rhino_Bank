package com.example.data

enum class RoutePreference(val labelJa: String, val descriptionJa: String) {
    SHORTEST_TIME("最短時間", "到着時間を優先"),
    FEWEST_TRANSFERS("乗換少なめ", "乗り換え回数を抑える"),
    LEAST_WALKING("徒歩少なめ", "歩行距離を最小に"),
    BARRIER_FREE("バリアフリー", "エレベーター優先・段差回避")
}

data class RouteLeg(
    val lineCode: String,               // "G"
    val boardStationJa: String,         // "渋谷"
    val alightStationJa: String,        // "銀座"
    val boardPlatform: String,          // "1番線 浅草方面"
    val numStations: Int,               // 7
    val durationMinutes: Int,           // 16
    val intermediateStationsJa: List<String> = emptyList(), // ["表参道", "外苑前", ...]
    val recommendedCarJa: String = "1号車・3号車 (乗換・出口に便利)",
    val congestionSummaryJa: String = "やや混雑"
)

data class RouteOption(
    val routeId: String,
    val titleJa: String,                // "ROUTE 01"
    val totalDurationMinutes: Int,      // 16
    val transfersCount: Int,            // 0
    val walkingMinutes: Int,            // 2
    val icFare: Int,                    // 209
    val paperFare: Int,                 // 210
    val departureTimeStr: String,       // "09:20"
    val arrivalTimeStr: String,         // "09:36"
    val legs: List<RouteLeg>,
    val isBarrierFreeApproved: Boolean = true,
    val noteJa: String? = null
)

object RouteEngine {

    fun searchRoutes(
        originNameJa: String,
        destNameJa: String,
        preference: RoutePreference = RoutePreference.SHORTEST_TIME,
        departureHour: Int = 9,
        departureMinute: Int = 20
    ): List<RouteOption> {
        val fareRes = FareEngine.calculateFare(originNameJa, destNameJa)

        val depTimeFormatted = String.format("%02d:%02d", departureHour, departureMinute)

        // Shibuya -> Ginza direct (Ginza Line)
        if ((originNameJa == "渋谷" && destNameJa == "銀座") || (originNameJa == "銀座" && destNameJa == "渋谷")) {
            val arrMinute1 = (departureMinute + 16) % 60
            val arrHour1 = departureHour + (departureMinute + 16) / 60
            val arrTime1 = String.format("%02d:%02d", arrHour1, arrMinute1)

            val arrMinute2 = (departureMinute + 19) % 60
            val arrHour2 = departureHour + (departureMinute + 19) / 60
            val arrTime2 = String.format("%02d:%02d", arrHour2, arrMinute2)

            val route1 = RouteOption(
                routeId = "R1",
                titleJa = "ROUTE 01 (直通)",
                totalDurationMinutes = 16,
                transfersCount = 0,
                walkingMinutes = 2,
                icFare = fareRes.icFare,
                paperFare = fareRes.paperTicketFare,
                departureTimeStr = depTimeFormatted,
                arrivalTimeStr = arrTime1,
                isBarrierFreeApproved = true,
                noteJa = "乗換なし・最速ルート",
                legs = listOf(
                    RouteLeg(
                        lineCode = "G",
                        boardStationJa = "渋谷",
                        alightStationJa = "銀座",
                        boardPlatform = "1番線 浅草方面",
                        numStations = 7,
                        durationMinutes = 16,
                        intermediateStationsJa = listOf("表参道", "外苑前", "青山一丁目", "赤坂見附", "虎ノ門", "新橋"),
                        recommendedCarJa = "3号車 (A1・A2出口直結)",
                        congestionSummaryJa = "やや混雑"
                    )
                )
            )

            val route2 = RouteOption(
                routeId = "R2",
                titleJa = "ROUTE 02 (半蔵門線経由)",
                totalDurationMinutes = 19,
                transfersCount = 1,
                walkingMinutes = 3,
                icFare = fareRes.icFare,
                paperFare = fareRes.paperTicketFare,
                departureTimeStr = depTimeFormatted,
                arrivalTimeStr = arrTime2,
                isBarrierFreeApproved = true,
                noteJa = "表参道で同一ホーム乗換",
                legs = listOf(
                    RouteLeg(
                        lineCode = "Z",
                        boardStationJa = "渋谷",
                        alightStationJa = "表参道",
                        boardPlatform = "1番線 押上方面",
                        numStations = 1,
                        durationMinutes = 2,
                        intermediateStationsJa = emptyList(),
                        recommendedCarJa = "1号車",
                        congestionSummaryJa = "空いています"
                    ),
                    RouteLeg(
                        lineCode = "G",
                        boardStationJa = "表参道",
                        alightStationJa = "銀座",
                        boardPlatform = "1番線 浅草方面",
                        numStations = 6,
                        durationMinutes = 14,
                        intermediateStationsJa = listOf("外苑前", "青山一丁目", "赤坂見附", "虎ノ門", "新橋"),
                        recommendedCarJa = "3号車",
                        congestionSummaryJa = "やや混雑"
                    )
                )
            )

            return if (preference == RoutePreference.FEWEST_TRANSFERS) {
                listOf(route1, route2)
            } else {
                listOf(route1, route2)
            }
        }

        // Default dynamic route generation for any origin/dest
        val arrMinute = (departureMinute + fareRes.durationMinutes) % 60
        val arrHour = departureHour + (departureMinute + fareRes.durationMinutes) / 60
        val arrTimeStr = String.format("%02d:%02d", arrHour, arrMinute)

        val primaryLine = when {
            originNameJa == "新宿" || destNameJa == "新宿" -> "M"
            originNameJa == "六本木" || destNameJa == "六本木" -> "H"
            originNameJa == "大手町" || destNameJa == "大手町" -> "T"
            else -> "G"
        }

        val primaryRoute = RouteOption(
            routeId = "R_GEN_1",
            titleJa = "ROUTE 01",
            totalDurationMinutes = fareRes.durationMinutes,
            transfersCount = if (originNameJa == "六本木" && destNameJa == "渋谷") 1 else 0,
            walkingMinutes = if (preference == RoutePreference.BARRIER_FREE) 4 else 2,
            icFare = fareRes.icFare,
            paperFare = fareRes.paperTicketFare,
            departureTimeStr = depTimeFormatted,
            arrivalTimeStr = arrTimeStr,
            isBarrierFreeApproved = true,
            noteJa = if (preference == RoutePreference.BARRIER_FREE) "全駅エレベーター利用ルート" else "標準ルート",
            legs = listOf(
                RouteLeg(
                    lineCode = primaryLine,
                    boardStationJa = originNameJa,
                    alightStationJa = destNameJa,
                    boardPlatform = "1番線",
                    numStations = 5,
                    durationMinutes = fareRes.durationMinutes,
                    recommendedCarJa = "2号車・4号車",
                    congestionSummaryJa = "平常"
                )
            )
        )

        return listOf(primaryRoute)
    }
}
