package com.example.data

enum class PassengerType(val labelJa: String) {
    ADULT("大人"),
    CHILD("小児")
}

enum class TicketProductType(val labelJa: String, val descriptionJa: String) {
    TOUCH_PAYMENT("タッチ決済", "クレジットカード/スマホを直接タッチ"),
    PASMO_IC("PASMO / ICカード", "交通系ICカードでタッチ乗車"),
    REGULAR_TICKET("普通乗車券", "駅券売機またはアプリで購入"),
    SUBWAY_PASS_24H("東京サブウェイ 24時間券", "東京メトロ・都営地下鉄全線乗り放題"),
    SUBWAY_PASS_48H("東京サブウェイ 48時間券", "東京メトロ・都営地下鉄全線乗り放題"),
    SUBWAY_PASS_72H("東京サブウェイ 72時間券", "東京メトロ・都営地下鉄全線乗り放題")
}

data class FareCalculationResult(
    val icFare: Int,
    val paperTicketFare: Int,
    val passengerType: PassengerType,
    val distanceKm: Double,
    val durationMinutes: Int
)

object FareEngine {

    /**
     * Calculates authentic Tokyo Metro distance-based fare structure
     */
    fun calculateFare(
        originNameJa: String,
        destNameJa: String,
        passengerType: PassengerType = PassengerType.ADULT
    ): FareCalculationResult {
        if (originNameJa == destNameJa) {
            return FareCalculationResult(0, 0, passengerType, 0.0, 0)
        }

        // Estimate distance based on station names
        val estDistanceKm = when {
            (originNameJa == "渋谷" && destNameJa == "表参道") || (originNameJa == "表参道" && destNameJa == "渋谷") -> 1.4
            (originNameJa == "渋谷" && destNameJa == "銀座") || (originNameJa == "銀座" && destNameJa == "渋谷") -> 6.7
            (originNameJa == "新宿" && destNameJa == "東京") || (originNameJa == "東京" && destNameJa == "新宿") -> 7.8
            (originNameJa == "渋谷" && destNameJa == "浅草") || (originNameJa == "浅草" && destNameJa == "渋谷") -> 14.2
            (originNameJa == "東京" && destNameJa == "銀座") || (originNameJa == "銀座" && destNameJa == "東京") -> 2.1
            (originNameJa == "池袋" && destNameJa == "銀座") || (originNameJa == "銀座" && destNameJa == "池袋") -> 10.5
            else -> 8.5
        }

        // Tokyo Metro standard fare tier schedule
        val (baseIc, basePaper) = when {
            estDistanceKm <= 6.0 -> 178 to 180
            estDistanceKm <= 11.0 -> 209 to 210
            estDistanceKm <= 19.0 -> 252 to 260
            estDistanceKm <= 27.0 -> 293 to 300
            else -> 335 to 340
        }

        val multiplier = if (passengerType == PassengerType.CHILD) 0.5 else 1.0
        val finalIcFare = (baseIc * multiplier).toInt()
        val finalPaperFare = (basePaper * multiplier).toInt()
        val estimatedDuration = (estDistanceKm * 2.2 + 3).toInt()

        return FareCalculationResult(
            icFare = finalIcFare,
            paperTicketFare = finalPaperFare,
            passengerType = passengerType,
            distanceKm = estDistanceKm,
            durationMinutes = estimatedDuration
        )
    }

    fun getSubwayPassPrice(type: TicketProductType): Int {
        return when (type) {
            TicketProductType.SUBWAY_PASS_24H -> 800
            TicketProductType.SUBWAY_PASS_48H -> 1200
            TicketProductType.SUBWAY_PASS_72H -> 1500
            else -> 0
        }
    }
}
