package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TokyoMetroData

@Composable
fun LineBadge(
    lineCode: String,
    modifier: Modifier = Modifier,
    size: Dp = 28.dp,
    showName: Boolean = false
) {
    val line = TokyoMetroData.getLine(lineCode)
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(size)
                .clip(CircleShape)
                .background(line.composeColor)
                .testTag("line_badge_$lineCode")
        ) {
            Text(
                text = lineCode,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = (size.value * 0.52).sp
            )
        }
        if (showName) {
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = line.nameJa,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
fun StationNumberPill(
    stationCode: String, // e.g. "G-01" or "G01"
    modifier: Modifier = Modifier
) {
    val lineCode = stationCode.take(1).uppercase()
    val number = if (stationCode.contains("-")) stationCode.substringAfter("-") else stationCode.drop(1)
    val line = TokyoMetroData.getLine(lineCode)

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White)
            .border(2.dp, line.composeColor, RoundedCornerShape(16.dp))
            .padding(horizontal = 8.dp, vertical = 2.dp)
            .testTag("station_code_$stationCode"),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(18.dp)
                    .clip(CircleShape)
                    .background(line.composeColor),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = lineCode,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            }
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = number,
                color = Color.Black,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 13.sp
            )
        }
    }
}
