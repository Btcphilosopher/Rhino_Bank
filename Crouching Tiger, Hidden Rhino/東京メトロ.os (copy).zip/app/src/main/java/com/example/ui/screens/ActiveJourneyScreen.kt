package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.DirectionsSubway
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CarCongestion
import com.example.data.JourneyStatus
import com.example.data.TokyoMetroData
import com.example.ui.components.DepartureBoard
import com.example.ui.components.LineBadge
import com.example.ui.components.TapGateSimulator
import com.example.viewmodel.TokyoMetroViewModel

@Composable
fun ActiveJourneyScreen(
    viewModel: TokyoMetroViewModel,
    modifier: Modifier = Modifier
) {
    val journeyState by viewModel.journeyState.collectAsState()
    val tapGateState by viewModel.tapGateState.collectAsState()
    val paymentCard by viewModel.selectedPaymentCard.collectAsState()

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0B132B))
            .padding(16.dp)
            .verticalScroll(scrollState)
            .testTag("active_journey_screen")
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        // Status Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF00A7E1))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "乗車中 (JOURNEY MODE)",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                LineBadge(lineCode = journeyState.currentLineCode, size = 22.dp)
            }

            Text(
                text = journeyState.status.labelJa,
                color = Color(0xFF38BDF8),
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Destination Title Card
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1C2541)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "目的地: ${journeyState.destinationStationJa}",
                    color = Color.White,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "あと 約 ${journeyState.remainingMinutes} 分",
                    color = Color(0xFFFFD700),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Station Advancement Timeline
                val stationTimeline = listOf("渋谷", "表参道", "青山一丁目", "赤坂見附", "銀座")
                val currentIndex = when (journeyState.currentStationJa) {
                    "渋谷" -> 0
                    "表参道" -> 1
                    "青山一丁目" -> 2
                    "赤坂見附" -> 3
                    "銀座" -> 4
                    else -> 0
                }

                Column(modifier = Modifier.fillMaxWidth()) {
                    stationTimeline.forEachIndexed { idx, stName ->
                        val isPassed = idx < currentIndex
                        val isCurrent = idx == currentIndex
                        val isFuture = idx > currentIndex

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(vertical = 6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(
                                        when {
                                            isPassed -> Color(0xFF10B981)
                                            isCurrent -> Color(0xFF00A7E1)
                                            else -> Color(0xFF475569)
                                        }
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isPassed) {
                                    Icon(
                                        Icons.Default.Check,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(14.dp)
                                    )
                                } else if (isCurrent) {
                                    Icon(
                                        Icons.Default.DirectionsSubway,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Text(
                                text = stName,
                                color = if (isCurrent) Color.White else if (isPassed) Color(0xFF94A3B8) else Color(0xFF64748B),
                                fontSize = if (isCurrent) 18.sp else 15.sp,
                                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium
                            )

                            if (isCurrent) {
                                Spacer(modifier = Modifier.width(10.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Color(0xFF00A7E1))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "現在の位置",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Step Actions depending on status
        if (journeyState.status == JourneyStatus.ROUTE_SELECTED) {
            // Must tap entry at Gate
            TapGateSimulator(
                gateState = tapGateState,
                stationNameJa = journeyState.currentStationJa,
                paymentMethodName = paymentCard,
                isEntry = true,
                onTapTriggered = { viewModel.simulateTapEntry() }
            )
        } else if (journeyState.status == JourneyStatus.ARRIVED_DESTINATION) {
            // Must tap exit at Gate
            TapGateSimulator(
                gateState = tapGateState,
                stationNameJa = journeyState.destinationStationJa,
                paymentMethodName = paymentCard,
                isEntry = false,
                onTapTriggered = { viewModel.simulateTapExit() }
            )
        } else if (journeyState.status == JourneyStatus.GATE_EXIT_APPROVED) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF10B981)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "ご利用ありがとうございました",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "乗車区間: ${journeyState.entryStationJa ?: "渋谷"} → ${journeyState.destinationStationJa}",
                        color = Color.White,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = { viewModel.completeAndResetJourney() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("finish_journey_button")
                    ) {
                        Text(text = "旅程を終了する", color = Color(0xFF065F46), fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            // Currently on train (乗車中) - Simulator controls
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "リアルタイム運行モニター",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Button(
                            onClick = { viewModel.advanceJourneyStep() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00A7E1)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("advance_station_simulation_button")
                        ) {
                            Text("次の駅へ移動", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "車両混雑状況 & 出口案内",
                        color = Color(0xFF94A3B8),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    // Car Diagram (1号車..6号車)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val cars = listOf(
                            CarCongestion(1, "混雑", false),
                            CarCongestion(2, "やや混雑", true, "乗換口"),
                            CarCongestion(3, "空き", true, "A1・A2出口直結"),
                            CarCongestion(4, "やや混雑", false),
                            CarCongestion(5, "空き", false),
                            CarCongestion(6, "空き", false)
                        )
                        cars.forEach { car ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (car.isTransferOptimal) Color(0xFF00A7E1) else Color(0xFF334155))
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = "${car.carNumber}号車",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = car.statusTextJa,
                                        color = if (car.isTransferOptimal) Color.White else Color(0xFFCBD5E1),
                                        fontSize = 9.sp
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "※ 3号車は銀座駅 A1・A2出口エレベーター直近です。",
                        color = Color(0xFF38BDF8),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}
