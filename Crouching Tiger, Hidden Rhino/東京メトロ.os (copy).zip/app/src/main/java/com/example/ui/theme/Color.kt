package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val MetroBluePrimary = Color(0xFF00A7E1)
val MetroNavyDark = Color(0xFF002B49)
val MetroSignboardBlack = Color(0xFF1B2430)
val MetroLightBackground = Color(0xFFF4F6F8)
val MetroDarkBackground = Color(0xFF0B132B)
val MetroSuccessGreen = Color(0xFF10B981)
val MetroWarningRed = Color(0xFFE60012)
val MetroAmberYellow = Color(0xFFFFD700)
