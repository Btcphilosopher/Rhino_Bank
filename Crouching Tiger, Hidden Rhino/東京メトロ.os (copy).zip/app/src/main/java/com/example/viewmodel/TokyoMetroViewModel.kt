package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.example.data.ActiveJourneyState
import com.example.data.FareEngine
import com.example.data.JourneyStatus
import com.example.data.MetroStation
import com.example.data.PassengerType
import com.example.data.RouteEngine
import com.example.data.RouteOption
import com.example.data.RoutePreference
import com.example.data.TicketProductType
import com.example.data.TokyoMetroData
import com.example.data.db.AppDatabase
import com.example.data.db.DigitalTicketEntity
import com.example.data.db.FavouriteEntity
import com.example.data.db.JourneyHistoryEntity
import com.example.data.db.TapEventEntity
import com.example.service.LineServiceStatus
import com.example.service.LiveLineStatus
import com.example.service.SimulatorEngine
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

enum class AppTab(val labelJa: String, val iconSymbol: String) {
    HOME("ホーム", "⌂"),
    ROUTE("経路", "⇄"),
    TICKET("チケット", "▣"),
    STATION("駅", "◎"),
    MY_PAGE("マイページ", "●")
}

enum class TapGateState {
    IDLE,
    READY,
    CARD_DETECTED,
    AUTHENTICATING,
    ENTRY_APPROVED,
    EXIT_APPROVED,
    ERROR
}

class TokyoMetroViewModel(application: Application) : AndroidViewModel(application) {

    private val db = Room.databaseBuilder(
        application,
        AppDatabase::class.java,
        "tokyo_metro_os.db"
    ).fallbackToDestructiveMigration().build()

    private val dao = db.metroDao()

    // Navigation state
    private val _currentTab = MutableStateFlow(AppTab.HOME)
    val currentTab: StateFlow<AppTab> = _currentTab.asStateFlow()

    // Route search inputs
    val searchOrigin = MutableStateFlow("渋谷")
    val searchDestination = MutableStateFlow("銀座")
    val routePreference = MutableStateFlow(RoutePreference.SHORTEST_TIME)

    private val _routeResults = MutableStateFlow<List<RouteOption>>(emptyList())
    val routeResults: StateFlow<List<RouteOption>> = _routeResults.asStateFlow()

    private val _selectedRoute = MutableStateFlow<RouteOption?>(null)
    val selectedRoute: StateFlow<RouteOption?> = _selectedRoute.asStateFlow()

    // Active Journey
    private val _journeyState = MutableStateFlow(ActiveJourneyState())
    val journeyState: StateFlow<ActiveJourneyState> = _journeyState.asStateFlow()

    // Touch & Go / Tap Simulator
    private val _tapGateState = MutableStateFlow(TapGateState.READY)
    val tapGateState: StateFlow<TapGateState> = _tapGateState.asStateFlow()

    val selectedPaymentCard = MutableStateFlow("タッチ決済 (Visa **** 1234)")

    // PASMO Balance
    val pasmoBalance = MutableStateFlow(4280)

    // Service Status
    private val _serviceStatuses = MutableStateFlow(SimulatorEngine.getInitialServiceStatuses())
    val serviceStatuses: StateFlow<List<LiveLineStatus>> = _serviceStatuses.asStateFlow()

    // Selected Station for Station Guide
    val selectedStation = MutableStateFlow(TokyoMetroData.findStationByName("渋谷") ?: TokyoMetroData.STATIONS.first())

    // Language & Theme
    val isDarkMode = MutableStateFlow(false)
    val isEnglishMode = MutableStateFlow(false)

    // Room DB Flows
    val journeyHistory: StateFlow<List<JourneyHistoryEntity>> = dao.getAllJourneyHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val digitalTickets: StateFlow<List<DigitalTicketEntity>> = dao.getAllTickets()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val tapEvents: StateFlow<List<TapEventEntity>> = dao.getAllTapEvents()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favourites: StateFlow<List<FavouriteEntity>> = dao.getAllFavourites()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Pre-populate default route
        executeRouteSearch()
        // Pre-populate sample tickets & favourites if empty
        viewModelScope.launch {
            dao.insertFavourite(FavouriteEntity("G01", "渋谷", "Shibuya", "FAVOURITE"))
            dao.insertFavourite(FavouriteEntity("G08", "銀座", "Ginza", "FAVOURITE"))
            dao.insertFavourite(FavouriteEntity("M17", "東京", "Tokyo", "WORK"))
        }
    }

    fun selectTab(tab: AppTab) {
        _currentTab.value = tab
    }

    fun executeRouteSearch() {
        val results = RouteEngine.searchRoutes(
            originNameJa = searchOrigin.value,
            destNameJa = searchDestination.value,
            preference = routePreference.value
        )
        _routeResults.value = results
        if (results.isNotEmpty()) {
            _selectedRoute.value = results.first()
        }
    }

    fun selectRouteOption(option: RouteOption) {
        _selectedRoute.value = option
    }

    fun startJourneyWithSelectedRoute(option: RouteOption) {
        _selectedRoute.value = option
        val firstLeg = option.legs.firstOrNull()
        _journeyState.value = ActiveJourneyState(
            status = JourneyStatus.ROUTE_SELECTED,
            selectedRoute = option,
            currentStationJa = option.legs.first().boardStationJa,
            nextStationJa = option.legs.first().intermediateStationsJa.firstOrNull() ?: option.legs.first().alightStationJa,
            destinationStationJa = option.legs.last().alightStationJa,
            currentLineCode = firstLeg?.lineCode ?: "G",
            remainingMinutes = option.totalDurationMinutes,
            paymentMethod = selectedPaymentCard.value
        )
        _currentTab.value = AppTab.HOME
    }

    // Touch & Go Entry Tap Simulation
    fun simulateTapEntry() {
        viewModelScope.launch {
            _tapGateState.value = TapGateState.CARD_DETECTED
            delay(400)
            _tapGateState.value = TapGateState.AUTHENTICATING
            delay(600)
            _tapGateState.value = TapGateState.ENTRY_APPROVED

            val nowStr = SimpleDateFormat("HH:mm", Locale.JAPAN).format(Date())
            val dateStr = SimpleDateFormat("M月d日", Locale.JAPAN).format(Date())

            val origin = searchOrigin.value
            val dest = searchDestination.value

            _journeyState.update { current ->
                current.copy(
                    status = JourneyStatus.GATE_ENTRY_APPROVED,
                    entryStationJa = origin,
                    entryTimeStr = nowStr,
                    activeNoticeJa = "改札を通過しました。1番線ホームでお待ちください。"
                )
            }

            // Save tap event
            dao.insertTapEvent(
                TapEventEntity(
                    stationName = origin,
                    gateId = "改札01",
                    actionType = "ENTRY",
                    paymentType = selectedPaymentCard.value,
                    cardIdentifier = "TOUCH_PASS",
                    fareDeducted = 0,
                    dateTimeStr = "$dateStr $nowStr"
                )
            )

            delay(1200)
            // Advance state to BOARDED / ON_TRAIN
            _journeyState.update { current ->
                current.copy(
                    status = JourneyStatus.BOARDED,
                    activeNoticeJa = "次は 表参道です。"
                )
            }
        }
    }

    // Advance simulation step
    fun advanceJourneyStep() {
        val current = _journeyState.value
        if (current.status == JourneyStatus.BOARDED) {
            if (current.currentStationJa == "渋谷") {
                _journeyState.update {
                    it.copy(
                        currentStationJa = "表参道",
                        nextStationJa = "赤坂見附",
                        remainingMinutes = 10,
                        activeNoticeJa = "次は 赤坂見附です。"
                    )
                }
            } else if (current.currentStationJa == "表参道") {
                _journeyState.update {
                    it.copy(
                        currentStationJa = "赤坂見附",
                        nextStationJa = "銀座",
                        remainingMinutes = 4,
                        activeNoticeJa = "まもなく 銀座です。A1・A2出口が便利です。"
                    )
                }
            } else {
                _journeyState.update {
                    it.copy(
                        status = JourneyStatus.ARRIVED_DESTINATION,
                        currentStationJa = current.destinationStationJa,
                        nextStationJa = "到着",
                        remainingMinutes = 0,
                        activeNoticeJa = "${current.destinationStationJa}駅に到着しました。改札でタッチして降車してください。"
                    )
                }
            }
        }
    }

    // Touch & Go Exit Tap Simulation
    fun simulateTapExit() {
        viewModelScope.launch {
            _tapGateState.value = TapGateState.CARD_DETECTED
            delay(400)
            _tapGateState.value = TapGateState.AUTHENTICATING
            delay(600)
            _tapGateState.value = TapGateState.EXIT_APPROVED

            val nowStr = SimpleDateFormat("HH:mm", Locale.JAPAN).format(Date())
            val dateStr = SimpleDateFormat("M月d日", Locale.JAPAN).format(Date())

            val currentJourney = _journeyState.value
            val origin = currentJourney.entryStationJa ?: currentJourney.selectedRoute?.legs?.first()?.boardStationJa ?: "渋谷"
            val dest = currentJourney.destinationStationJa

            val fareRes = FareEngine.calculateFare(origin, dest)

            // Deduct PASMO if PASMO selected
            if (selectedPaymentCard.value.contains("PASMO")) {
                pasmoBalance.update { (it - fareRes.icFare).coerceAtLeast(0) }
            }

            _journeyState.update {
                it.copy(
                    status = JourneyStatus.GATE_EXIT_APPROVED,
                    exitTimeStr = nowStr,
                    activeNoticeJa = "ご利用ありがとうございました。"
                )
            }

            // Save tap event & journey history to DB
            dao.insertTapEvent(
                TapEventEntity(
                    stationName = dest,
                    gateId = "改札02",
                    actionType = "EXIT",
                    paymentType = selectedPaymentCard.value,
                    cardIdentifier = "TOUCH_PASS",
                    fareDeducted = fareRes.icFare,
                    dateTimeStr = "$dateStr $nowStr"
                )
            )

            dao.insertJourneyHistory(
                JourneyHistoryEntity(
                    originStation = origin,
                    destStation = dest,
                    departureTime = currentJourney.entryTimeStr ?: "09:20",
                    arrivalTime = nowStr,
                    fare = fareRes.icFare,
                    paymentMethod = selectedPaymentCard.value,
                    date = dateStr
                )
            )
        }
    }

    fun completeAndResetJourney() {
        _journeyState.value = ActiveJourneyState()
        _tapGateState.value = TapGateState.READY
    }

    // Purchase Digital Ticket
    fun purchaseTicket(productType: TicketProductType) {
        viewModelScope.launch {
            val price = when (productType) {
                TicketProductType.SUBWAY_PASS_24H -> 800
                TicketProductType.SUBWAY_PASS_48H -> 1200
                TicketProductType.SUBWAY_PASS_72H -> 1500
                else -> 210
            }
            val id = UUID.randomUUID().toString().take(8).uppercase()
            val now = System.currentTimeMillis()
            val ticket = DigitalTicketEntity(
                ticketId = "T-$id",
                title = productType.labelJa,
                ticketType = productType.name,
                status = "PURCHASED",
                price = price,
                purchaseTimestamp = now,
                qrCodeData = "TOKYO_METRO_DEMO_QR_$id"
            )
            dao.insertOrUpdateTicket(ticket)
        }
    }

    fun activateTicket(ticket: DigitalTicketEntity) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val validDurationHours = when (ticket.ticketType) {
                "SUBWAY_PASS_24H" -> 24L
                "SUBWAY_PASS_48H" -> 48L
                "SUBWAY_PASS_72H" -> 72L
                else -> 24L
            }
            val validUntil = now + (validDurationHours * 3600 * 1000)
            dao.updateTicketStatus(ticket.ticketId, "ACTIVE", now, validUntil)
        }
    }

    fun chargePasmo(amount: Int) {
        pasmoBalance.update { it + amount }
    }

    // Inject synthetic service disruption delay for testing vertical slice
    fun toggleLineDisruption(lineCode: String) {
        _serviceStatuses.update { list ->
            list.map { item ->
                if (item.lineCode == lineCode) {
                    if (item.status.isNormal) {
                        item.copy(
                            status = LineServiceStatus.DELAYED,
                            delayMinutes = 8,
                            messageJa = "丸ノ内線は車両点検の影響により、約8分遅延が出ています。"
                        )
                    } else {
                        item.copy(
                            status = LineServiceStatus.NORMAL,
                            delayMinutes = 0,
                            messageJa = "全線で平常通り運転を行っています。"
                        )
                    }
                } else item
            }
        }

        // If currently in an active journey affected by line, set notice & recalculate
        if (lineCode == _journeyState.value.currentLineCode) {
            _journeyState.update { current ->
                current.copy(
                    hasDelayDisruption = !current.hasDelayDisruption,
                    delayMinutes = if (!current.hasDelayDisruption) 8 else 0,
                    activeNoticeJa = if (!current.hasDelayDisruption) "【運行情報】ご利用中の路線で約8分の遅延が発生しています。" else null
                )
            }
        }
    }
}
