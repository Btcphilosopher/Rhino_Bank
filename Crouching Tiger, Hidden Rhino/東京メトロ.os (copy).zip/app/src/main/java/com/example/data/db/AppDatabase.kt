package com.example.data.db

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "journey_history")
data class JourneyHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val originStation: String,
    val destStation: String,
    val departureTime: String,
    val arrivalTime: String,
    val fare: Int,
    val paymentMethod: String, // "タッチ決済", "PASMO", "QRチケット", "普通乗車券"
    val date: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "digital_tickets")
data class DigitalTicketEntity(
    @PrimaryKey val ticketId: String,
    val title: String, // "東京サブウェイチケット 24時間", "普通乗車券 (渋谷→銀座)"
    val ticketType: String, // "SUBWAY_24H", "SUBWAY_48H", "SUBWAY_72H", "SINGLE"
    val status: String, // "PURCHASED", "ACTIVE", "USED", "EXPIRED"
    val price: Int,
    val origin: String? = null,
    val destination: String? = null,
    val purchaseTimestamp: Long,
    val activatedTimestamp: Long? = null,
    val validUntilTimestamp: Long? = null,
    val qrCodeData: String
)

@Entity(tableName = "tap_events")
data class TapEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val stationName: String,
    val gateId: String,
    val actionType: String, // "ENTRY", "EXIT"
    val paymentType: String, // "TOUCH_CREDIT", "PASMO", "QR_TICKET"
    val cardIdentifier: String,
    val fareDeducted: Int = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val dateTimeStr: String
)

@Entity(tableName = "favourites")
data class FavouriteEntity(
    @PrimaryKey val stationId: String,
    val stationNameJa: String,
    val stationNameEn: String,
    val customCategory: String // "HOME", "WORK", "SCHOOL", "FAVOURITE"
)

@Dao
interface MetroDao {
    @Query("SELECT * FROM journey_history ORDER BY timestamp DESC")
    fun getAllJourneyHistory(): Flow<List<JourneyHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJourneyHistory(item: JourneyHistoryEntity)

    @Query("SELECT * FROM digital_tickets ORDER BY purchaseTimestamp DESC")
    fun getAllTickets(): Flow<List<DigitalTicketEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateTicket(ticket: DigitalTicketEntity)

    @Query("UPDATE digital_tickets SET status = :status, activatedTimestamp = :activated, validUntilTimestamp = :validUntil WHERE ticketId = :ticketId")
    suspend fun updateTicketStatus(ticketId: String, status: String, activated: Long?, validUntil: Long?)

    @Query("SELECT * FROM tap_events ORDER BY timestamp DESC")
    fun getAllTapEvents(): Flow<List<TapEventEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTapEvent(event: TapEventEntity)

    @Query("SELECT * FROM favourites")
    fun getAllFavourites(): Flow<List<FavouriteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavourite(favourite: FavouriteEntity)

    @Query("DELETE FROM favourites WHERE stationId = :stationId")
    suspend fun deleteFavourite(stationId: String)
}

@Database(
    entities = [
        JourneyHistoryEntity::class,
        DigitalTicketEntity::class,
        TapEventEntity::class,
        FavouriteEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun metroDao(): MetroDao
}
