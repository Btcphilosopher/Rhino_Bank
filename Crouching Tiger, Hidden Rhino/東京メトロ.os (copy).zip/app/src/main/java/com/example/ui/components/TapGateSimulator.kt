package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Contactless
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.viewmodel.TapGateState

@Composable
fun TapGateSimulator(
    gateState: TapGateState,
    stationNameJa: String,
    paymentMethodName: String,
    isEntry: Boolean, // true = 入場 (Entry), false = 降車 (Exit)
    onTapTriggered: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isApproved = gateState == TapGateState.ENTRY_APPROVED || gateState == TapGateState.EXIT_APPROVED
    val scaleAnim by animateFloatAsState(
        targetValue = if (isApproved) 1.1f else 1.0f,
        animationSpec = tween(300),
        label = "scale"
    )

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = Color(0xFF121B2B),
        tonalElevation = 6.dp,
        modifier = modifier
            .fillMaxWidth()
            .testTag("tap_gate_simulator")
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = if (isEntry) "タッチして乗車 (入場)" else "タッチして降車 (精算)",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "$stationNameJa 駅 改札機",
                color = Color(0xFF94A3B8),
                fontSize = 13.sp
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Contactless Gate Reader Circle
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(140.dp)
                    .scale(scaleAnim)
                    .clip(CircleShape)
                    .background(
                        when {
                            isApproved -> Color(0xFF10B981) // Green success
                            gateState == TapGateState.AUTHENTICATING -> Color(0xFFF59E0B) // Amber
                            else -> Color(0xFF00A7E1) // Tokyo Metro Blue
                        }
                    )
                    .border(
                        4.dp,
                        if (isApproved) Color(0xFF34D399) else Color(0xFF38BDF8),
                        CircleShape
                    )
                    .clickable(enabled = gateState == TapGateState.READY) {
                        onTapTriggered()
                    }
                    .testTag("tap_reader_button")
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    if (isApproved) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Approved",
                            tint = Color.White,
                            modifier = Modifier.size(54.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isEntry) "入場 OK" else "降車 OK",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    } else if (gateState == TapGateState.AUTHENTICATING) {
                        Text(
                            text = "認証中…",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Contactless,
                            contentDescription = "Tap Here",
                            tint = Color.White,
                            modifier = Modifier.size(54.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "ここをタッチ",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // State label description
            Text(
                text = when (gateState) {
                    TapGateState.READY -> "カードまたはスマートフォンを\n改札機にタッチしてください"
                    TapGateState.CARD_DETECTED -> "カードを検出しました"
                    TapGateState.AUTHENTICATING -> "決済認証中..."
                    TapGateState.ENTRY_APPROVED -> "ご乗車ありがとうございます"
                    TapGateState.EXIT_APPROVED -> "ご利用ありがとうございました"
                    else -> "タッチ待機中"
                },
                color = if (isApproved) Color(0xFF34D399) else Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF1E293B))
                    .padding(12.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.CreditCard,
                    contentDescription = null,
                    tint = Color(0xFF38BDF8),
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = paymentMethodName,
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            if (gateState == TapGateState.READY) {
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = onTapTriggered,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00A7E1)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("simulate_tap_action_button")
                ) {
                    Text(
                        text = "タッチをシミュレート",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
            }
        }
    }
}
