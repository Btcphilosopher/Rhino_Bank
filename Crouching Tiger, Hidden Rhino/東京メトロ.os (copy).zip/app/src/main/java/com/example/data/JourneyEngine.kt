package com.example.data

import com.example.data.RouteOption

enum class JourneyStatus(val labelJa: String) {
    IDLE("未乗車"),
    ROUTE_SELECTED("経路選択済"),
    TAP_READY("タッチ待機中"),
    GATE_ENTRY_APPROVED("入場完了"),
    BOARDED("乗車中"),
    TRANSFER_IN_PROGRESS("乗換移動中"),
    ARRIVING_SOON("まもなく到着"),
    ARRIVED_DESTINATION("目的地到着"),
    GATE_EXIT_APPROVED("降車・精算完了")
}

data class ActiveJourneyState(
    val status: JourneyStatus = JourneyStatus.IDLE,
    val selectedRoute: RouteOption? = null,
    val currentStationJa: String = "渋谷",
    val nextStationJa: String = "表参道",
    val destinationStationJa: String = "銀座",
    val currentLineCode: String = "G",
    val currentStationIndex: Int = 0,
    val totalStations: Int = 7,
    val remainingMinutes: Int = 14,
    val entryStationJa: String? = null,
    val entryTimeStr: String? = null,
    val exitTimeStr: String? = null,
    val paymentMethod: String = "タッチ決済",
    val activeNoticeJa: String? = null,
    val hasDelayDisruption: Boolean = false,
    val delayMinutes: Int = 0
)
