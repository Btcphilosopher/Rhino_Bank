package com.example.service

import com.example.data.TokyoMetroData
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

enum class LineServiceStatus(val statusJa: String, val isNormal: Boolean) {
    NORMAL("平常運転", true),
    DELAYED("遅延", false),
    PARTIAL_DELAY("一部遅延", false),
    SUSPENDED("運転見合わせ", false)
}

data class LiveLineStatus(
    val lineCode: String,
    val lineNameJa: String,
    val status: LineServiceStatus,
    val delayMinutes: Int = 0,
    val messageJa: String? = null
)

data class LiveDepartureItem(
    val lineCode: String,
    val destinationJa: String,
    val departureTimeStr: String,
    val statusLabelJa: String, // "まもなく", "定刻", "遅延3分"
    val platformStr: String,   // "1番線"
    val carCount: Int = 6
)

object SimulatorEngine {

    fun getInitialServiceStatuses(): List<LiveLineStatus> {
        return TokyoMetroData.LINES.map { line ->
            LiveLineStatus(
                lineCode = line.code,
                lineNameJa = line.nameJa,
                status = LineServiceStatus.NORMAL,
                delayMinutes = 0,
                messageJa = "全線で平常通り運転を行っています。"
            )
        }
    }

    fun getLiveDepartures(stationJa: String): List<LiveDepartureItem> {
        return when (stationJa) {
            "渋谷" -> listOf(
                LiveDepartureItem("G", "浅草行", "09:20", "まもなく", "1番線"),
                LiveDepartureItem("G", "浅草行", "09:26", "定刻", "1番線"),
                LiveDepartureItem("Z", "押上行", "09:22", "定刻", "2番線"),
                LiveDepartureItem("F", "和光市行", "09:25", "定刻", "3番線")
            )
            "銀座" -> listOf(
                LiveDepartureItem("G", "浅草行", "09:36", "まもなく", "1番線"),
                LiveDepartureItem("G", "渋谷行", "09:38", "定刻", "2番線"),
                LiveDepartureItem("M", "池袋行", "09:40", "定刻", "3番線"),
                LiveDepartureItem("H", "北千住行", "09:42", "定刻", "4番線")
            )
            else -> listOf(
                LiveDepartureItem("G", "浅草行", "09:20", "まもなく", "1番線"),
                LiveDepartureItem("G", "浅草行", "09:28", "定刻", "1番線")
            )
        }
    }
}
