package com.example.data

import androidx.compose.ui.graphics.Color

data class MetroLine(
    val code: String,              // "G", "M", "H", "T", "C", "Y", "Z", "N", "F"
    val nameJa: String,            // "銀座線"
    val nameEn: String,            // "Ginza Line"
    val colorHex: Long,            // 0xFFFF9500
    val startStationJa: String,    // "渋谷"
    val endStationJa: String       // "浅草"
) {
    val composeColor: Color get() = Color(colorHex)
}

data class StationExit(
    val exitCode: String,          // "A1", "A2", "B4", "C3"
    val descriptionJa: String,     // "銀座四丁目・和光"
    val walkingMinutes: Int,       // 2
    val hasElevator: Boolean = true,
    val hasEscalator: Boolean = true,
    val nearbyFacilitiesJa: List<String> = emptyList()
)

data class CarCongestion(
    val carNumber: Int,            // 1..6
    val statusTextJa: String,      // "空いています", "やや混雑", "混雑"
    val isTransferOptimal: Boolean = false,
    val noteJa: String? = null
)

data class StationPlatform(
    val platformNumber: String,    // "1番線"
    val directionJa: String,       // "浅草方面"
    val nextTrainMinutes: Int = 2,
    val followingTrainMinutes: Int = 8
)

data class MetroStation(
    val id: String,                 // "G01"
    val code: String,               // "G-01"
    val lineCode: String,           // "G"
    val nameJa: String,             // "渋谷"
    val nameEn: String,             // "Shibuya"
    val stationIndex: Int,          // 1..N on line
    val transferLineCodes: List<String> = emptyList(),
    val platforms: List<StationPlatform> = emptyList(),
    val exits: List<StationExit> = emptyList(),
    val carCongestions: List<CarCongestion> = emptyList(),
    val hasElevator: Boolean = true,
    val hasMultipurposeToilet: Boolean = true,
    val isBarrierFree: Boolean = true
)

object TokyoMetroData {

    val LINES = listOf(
        MetroLine("G", "銀座線", "Ginza Line", 0xFFF39700, "渋谷", "浅草"),
        MetroLine("M", "丸ノ内線", "Marunouchi Line", 0xFFE60012, "荻窪", "池袋"),
        MetroLine("H", "日比谷線", "Hibiya Line", 0xFF97A7B0, "中目黒", "北千住"),
        MetroLine("T", "東西線", "Tozai Line", 0xFF00A7E1, "中野", "西船橋"),
        MetroLine("C", "千代田線", "Chiyoda Line", 0xFF00BB85, "代々木上原", "綾瀬"),
        MetroLine("Y", "有楽町線", "Yurakucho Line", 0xFFD7C447, "和光市", "新木場"),
        MetroLine("Z", "半蔵門線", "Hanzomon Line", 0xFF8F4B9B, "渋谷", "押上"),
        MetroLine("N", "南北線", "Namboku Line", 0xFF00AC9B, "目黒", "赤羽岩淵"),
        MetroLine("F", "副都心線", "Fukutoshin Line", 0xFFBB641D, "和光市", "渋谷")
    )

    fun getLine(code: String): MetroLine {
        return LINES.firstOrNull { it.code == code } ?: LINES.first()
    }

    // Key stations across the network
    val STATIONS: List<MetroStation> = listOf(
        // Ginza Line (G)
        MetroStation("G01", "G-01", "G", "渋谷", "Shibuya", 1, listOf("Z", "F"),
            platforms = listOf(StationPlatform("1番線", "浅草方面", 2, 6)),
            exits = listOf(
                StationExit("A1", "道玄坂・ハチ公広場", 2, true, true, listOf("SHIBUYA 109", "スクランブル交差点")),
                StationExit("A2", "文化村通り", 3, true, true, listOf("Bunkamura", "東急百貨店"))
            ),
            carCongestions = listOf(
                CarCongestion(1, "やや混雑", true, "表参道での乗換に便利"),
                CarCongestion(2, "混雑", false),
                CarCongestion(3, "空いています", true, "銀座での出口に近い"),
                CarCongestion(4, "やや混雑", false),
                CarCongestion(5, "空いています", false),
                CarCongestion(6, "空いています", false)
            )
        ),
        MetroStation("G02", "G-02", "G", "表参道", "Omotesando", 2, listOf("C", "Z"),
            platforms = listOf(StationPlatform("1番線", "浅草方面", 1, 5)),
            exits = listOf(
                StationExit("A1", "神宮前4丁目", 1, true, true, listOf("表参道ヒルズ")),
                StationExit("B2", "青山通り", 2, true, false, listOf("スパイラル"))
            )
        ),
        MetroStation("G03", "G-03", "G", "外苑前", "Gaienmae", 3, emptyList(),
            platforms = listOf(StationPlatform("1番線", "浅草方面", 3, 7)),
            exits = listOf(StationExit("1a", "明治神宮野球場方面", 3, true, true))
        ),
        MetroStation("G04", "G-04", "G", "青山一丁目", "Aoyama-itchome", 4, listOf("Z"),
            platforms = listOf(StationPlatform("1番線", "浅草方面", 2, 6)),
            exits = listOf(StationExit("1", "青山ツインタワー", 2, true, true))
        ),
        MetroStation("G05", "G-05", "G", "赤坂見附", "Akasaka-mitsuke", 5, listOf("M"),
            platforms = listOf(StationPlatform("1番線", "浅草方面", 1, 4)),
            exits = listOf(StationExit("10", "赤坂東急", 2, true, true))
        ),
        MetroStation("G08", "G-08", "G", "銀座", "Ginza", 8, listOf("M", "H"),
            platforms = listOf(
                StationPlatform("1番線", "浅草方面", 2, 6),
                StationPlatform("2番線", "渋谷方面", 3, 7)
            ),
            exits = listOf(
                StationExit("A1", "銀座四丁目・和光", 1, true, true, listOf("和光本館", "GINZA SIX")),
                StationExit("A2", "銀座五丁目・三越", 2, true, true, listOf("銀座三越")),
                StationExit("B4", "みずほ銀行", 3, true, true),
                StationExit("C3", "数寄屋橋・ソニー通り", 2, true, true)
            ),
            carCongestions = listOf(
                CarCongestion(1, "混雑", false),
                CarCongestion(2, "やや混雑", true, "丸ノ内線乗換口付近"),
                CarCongestion(3, "空いています", true, "A1/A2出口階段前"),
                CarCongestion(4, "やや混雑", false),
                CarCongestion(5, "空いています", false),
                CarCongestion(6, "空いています", false)
            )
        ),
        MetroStation("G09", "G-09", "G", "日本橋", "Nihombashi", 9, listOf("T"),
            platforms = listOf(StationPlatform("1番線", "浅草方面", 2, 6)),
            exits = listOf(StationExit("B0", "日本橋高島屋", 2, true, true))
        ),
        MetroStation("G13", "G-13", "G", "上野", "Ueno", 13, listOf("H"),
            platforms = listOf(StationPlatform("1番線", "浅草方面", 2, 5)),
            exits = listOf(StationExit("1", "上野公園・動物園", 3, true, true))
        ),
        MetroStation("G16", "G-16", "G", "浅草", "Asakusa", 16, emptyList(),
            platforms = listOf(StationPlatform("1番線", "降車専用", 0, 0)),
            exits = listOf(StationExit("1", "雷門・浅草寺", 1, true, true))
        ),

        // Marunouchi Line (M)
        MetroStation("M08", "M-08", "M", "新宿", "Shinjuku", 8, listOf("F"),
            platforms = listOf(StationPlatform("1番線", "池袋方面", 1, 4)),
            exits = listOf(
                StationExit("A6", "中村屋ビル", 2, true, true),
                StationExit("B10", "サブナード", 3, true, true)
            )
        ),
        MetroStation("M17", "M-17", "M", "東京", "Tokyo", 17, emptyList(),
            platforms = listOf(StationPlatform("1番線", "荻窪方面", 2, 5)),
            exits = listOf(
                StationExit("M1", "丸の内ビルディング", 2, true, true, listOf("丸ビル", "新丸ビル")),
                StationExit("M3", "皇居前・和田倉噴水公園", 4, true, false)
            )
        ),
        MetroStation("M16", "M-16", "M", "銀座", "Ginza", 16, listOf("G", "H"),
            platforms = listOf(StationPlatform("1番線", "池袋方面", 2, 6)),
            exits = listOf(StationExit("C4", "数寄屋橋公園", 2, true, true))
        ),
        MetroStation("M25", "M-25", "M", "池袋", "Ikebukuro", 25, listOf("Y", "F"),
            platforms = listOf(StationPlatform("1番線", "荻窪方面", 3, 7)),
            exits = listOf(StationExit("C1", "立教大学", 4, true, true))
        ),

        // Hibiya Line (H)
        MetroStation("H08", "H-08", "H", "六本木", "Roppongi", 8, emptyList(),
            platforms = listOf(StationPlatform("1番線", "北千住方面", 2, 5)),
            exits = listOf(
                StationExit("1c", "六本木ヒルズ", 1, true, true, listOf("六本木ヒルズ", "テレビ朝日")),
                StationExit("2", "明治屋", 2, true, true)
            )
        ),
        MetroStation("H09", "H-09", "H", "銀座", "Ginza", 9, listOf("G", "M"),
            platforms = listOf(StationPlatform("1番線", "北千住方面", 2, 6)),
            exits = listOf(StationExit("A6", "三越", 1, true, true))
        ),

        // Tozai Line (T)
        MetroStation("T09", "T-09", "T", "大手町", "Otemachi", 9, listOf("C", "Z", "M"),
            platforms = listOf(StationPlatform("1番線", "西船橋方面", 2, 5)),
            exits = listOf(StationExit("C10", "経団連会館", 3, true, true))
        ),

        // Chiyoda Line (C)
        MetroStation("C07", "C-07", "C", "明治神宮前", "Meiji-jingumae", 7, listOf("F"),
            platforms = listOf(StationPlatform("1番線", "綾瀬方面", 2, 6)),
            exits = listOf(StationExit("2", "原宿駅・代々木公園", 2, true, true))
        ),

        // Hanzomon Line (Z)
        MetroStation("Z01", "Z-01", "Z", "渋谷", "Shibuya", 1, listOf("G", "F"),
            platforms = listOf(StationPlatform("1番線", "押上方面", 2, 5)),
            exits = listOf(StationExit("B1", "宮下公園", 2, true, true))
        ),
        MetroStation("Z02", "Z-02", "Z", "表参道", "Omotesando", 2, listOf("G", "C"),
            platforms = listOf(StationPlatform("1番線", "押上方面", 1, 4)),
            exits = listOf(StationExit("A3", "交差点", 1, true, true))
        ),

        // Fukutoshin Line (F)
        MetroStation("F16", "F-16", "F", "渋谷", "Shibuya", 16, listOf("G", "Z"),
            platforms = listOf(StationPlatform("1番線", "和光市方面", 2, 6)),
            exits = listOf(StationExit("B3", "ヒカリエ", 1, true, true))
        )
    )

    val QUICK_DESTINATIONS = listOf(
        "渋谷", "新宿", "東京", "銀座", "上野", "池袋", "六本木", "浅草"
    )

    fun searchStation(query: String): List<MetroStation> {
        if (query.isBlank()) return STATIONS.take(8)
        val q = query.lowercase().trim()
        return STATIONS.filter {
            it.nameJa.contains(q) || it.nameEn.lowercase().contains(q) || it.code.lowercase().contains(q)
        }
    }

    fun findStationByName(nameJa: String): MetroStation? {
        return STATIONS.firstOrNull { it.nameJa == nameJa }
    }
}
