package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.DirectionsSubway
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Train
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.JourneyStatus
import com.example.ui.screens.ActiveJourneyScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MyPageScreen
import com.example.ui.screens.RoutePlannerScreen
import com.example.ui.screens.StationGuideScreen
import com.example.ui.screens.TicketCenterScreen
import com.example.ui.theme.TokyoMetroTheme
import com.example.viewmodel.AppTab
import com.example.viewmodel.TokyoMetroViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: TokyoMetroViewModel = viewModel()
            val isDarkMode by viewModel.isDarkMode.collectAsState()

            TokyoMetroTheme(darkTheme = isDarkMode) {
                TokyoMetroApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun TokyoMetroApp(viewModel: TokyoMetroViewModel) {
    val currentTab by viewModel.currentTab.collectAsState()
    val journeyState by viewModel.journeyState.collectAsState()

    val isJourneyActive = journeyState.status != JourneyStatus.IDLE

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding(),
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp,
                modifier = Modifier.testTag("bottom_navigation_bar")
            ) {
                AppTab.values().forEach { tab ->
                    val isSelected = currentTab == tab
                    val labelText = if (tab == AppTab.ROUTE && isJourneyActive) "乗車中" else tab.labelJa

                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { viewModel.selectTab(tab) },
                        icon = {
                            val iconVector = when (tab) {
                                AppTab.HOME -> Icons.Default.Home
                                AppTab.ROUTE -> if (isJourneyActive) Icons.Default.Train else Icons.Default.SwapHoriz
                                AppTab.TICKET -> Icons.Default.ConfirmationNumber
                                AppTab.STATION -> Icons.Default.DirectionsSubway
                                AppTab.MY_PAGE -> Icons.Default.Person
                            }
                            Icon(
                                imageVector = iconVector,
                                contentDescription = tab.labelJa,
                                tint = if (isSelected) Color(0xFF00A7E1) else Color.Gray
                            )
                        },
                        label = {
                            Text(
                                text = labelText,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 11.sp,
                                color = if (isSelected) Color(0xFF00A7E1) else Color.Gray
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = Color(0xFF00A7E1).copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.testTag("nav_item_${tab.name}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                AppTab.HOME -> HomeScreen(viewModel = viewModel)
                AppTab.ROUTE -> {
                    if (isJourneyActive) {
                        ActiveJourneyScreen(viewModel = viewModel)
                    } else {
                        RoutePlannerScreen(viewModel = viewModel)
                    }
                }
                AppTab.TICKET -> TicketCenterScreen(viewModel = viewModel)
                AppTab.STATION -> StationGuideScreen(viewModel = viewModel)
                AppTab.MY_PAGE -> MyPageScreen(viewModel = viewModel)
            }
        }
    }
}
