/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { useLocalization } from '../services/localization';
import { systemEngine } from '../services/bankingEngine';
import { Shield, Languages, Laptop, Network, Landmark, AlertTriangle, LogIn, LogOut } from 'lucide-react';

interface HeaderProps {
  currentView: 'retail' | 'corporate' | 'treasury' | 'compliance' | 'operations' | 'simulator' | 'developer';
  onViewChange: (view: 'retail' | 'corporate' | 'treasury' | 'compliance' | 'operations' | 'simulator' | 'developer') => void;
  lang: 'en-GB' | 'zh-CN';
  toggleLang: () => void;
  isLoggedIn: boolean;
  onLoginToggle: () => void;
  stressMode: string;
}

export default function Header({
  currentView,
  onViewChange,
  lang,
  toggleLang,
  isLoggedIn,
  onLoginToggle,
  stressMode
}: HeaderProps) {
  const [tickerTime, setTickerTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setTickerTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const navItems = [
    { id: 'retail', nameEn: 'Retail Banking', nameZh: '零售业务' },
    { id: 'corporate', nameEn: 'Corporate Banking', nameZh: '公司业务' },
    { id: 'treasury', nameEn: 'Treasury Suite', nameZh: '资金与流动性' },
    { id: 'compliance', nameEn: 'Compliance Centre', nameZh: '合规中心' },
    { id: 'operations', nameEn: 'Global Operations', nameZh: '全球运维孪生' },
    { id: 'simulator', nameEn: 'Stress Simulator', nameZh: '压力测试模拟' },
    { id: 'developer', nameEn: 'Developer API', nameZh: '开发者 API' }
  ] as const;

  return (
    <header className="bg-[#0B1E36] text-white border-b border-[#1E3A5F] shadow-sm select-none" id="platform-header">
      {/* Top Banner (Utility Status) */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2 flex justify-between items-center text-xs border-b border-[#1E3A5F]/40 bg-[#071324]">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5 text-slate-300">
            <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="font-medium tracking-wide">
              {lang === 'en-GB' ? 'CORE LEDGER STABLE' : '核心总账内核：稳定'}
            </span>
          </div>
          <div className="hidden sm:flex items-center gap-1.5 text-slate-400">
            <Shield size={12} className="text-blue-400" />
            <span>SCA Mode: Standard TLS v1.3</span>
          </div>
          {stressMode !== 'NORMAL' && (
            <div className="flex items-center gap-1.5 text-red-400 font-bold animate-pulse bg-red-950/40 px-2 py-0.5 rounded border border-red-900/60">
              <AlertTriangle size={12} />
              <span>{lang === 'en-GB' ? `STRESS: ${stressMode}` : `压测态: ${stressMode}`}</span>
            </div>
          )}
        </div>

        <div className="flex items-center gap-4 text-slate-300 font-mono text-[11px]">
          <span>{tickerTime.toLocaleString(lang === 'en-GB' ? 'en-GB' : 'zh-CN')}</span>
          <span className="hidden md:inline bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded text-[10px] uppercase font-semibold">
            {lang === 'en-GB' ? 'SIMULATED ENV' : '模拟操作环境'}
          </span>
        </div>
      </div>

      {/* Main Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex justify-between items-center">
        {/* Brand */}
        <div className="flex items-center gap-3">
          <div className="bg-[#E60000] p-1.5 font-black text-white text-lg tracking-tight flex items-center justify-center transform skew-x-12 rounded-[2px]" style={{ minWidth: '40px' }}>
            <span className="transform -skew-x-12 font-sans font-bold">H</span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-semibold tracking-wide font-serif">HSBC BANKING</h1>
              <span className="text-[10px] text-slate-400 border border-slate-500/40 px-1 py-0.2 rounded font-mono uppercase tracking-widest bg-slate-900/40">
                GOP-v3.6
              </span>
            </div>
            <p className="text-[10px] text-slate-400 uppercase tracking-widest font-mono">
              {lang === 'en-GB' ? 'Global Banking Digital Operating Platform' : '全球银行数字操作平台'}
            </p>
          </div>
        </div>

        {/* Global Controls */}
        <div className="flex items-center gap-3">
          {/* Language switch button */}
          <button
            onClick={toggleLang}
            className="flex items-center gap-1.5 text-xs text-slate-300 hover:text-white bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 px-3 py-1.5 rounded transition-all font-medium"
            id="btn-lang-switch"
            title="Switch Language / 切换语言"
          >
            <Languages size={14} className="text-blue-400" />
            <span>{lang === 'en-GB' ? '简体中文' : 'English'}</span>
          </button>

          {/* User Signout or Signin */}
          <button
            onClick={onLoginToggle}
            className={`flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded border transition-all ${
              isLoggedIn
                ? 'bg-slate-800/80 hover:bg-red-950/20 hover:text-red-300 text-slate-300 border-slate-700/60 hover:border-red-900/40'
                : 'bg-emerald-600 hover:bg-emerald-500 text-white border-emerald-500'
            }`}
            id="btn-login-toggle"
          >
            {isLoggedIn ? (
              <>
                <LogOut size={14} />
                <span className="hidden sm:inline">{lang === 'en-GB' ? 'Secure Sign Out' : '安全退出'}</span>
              </>
            ) : (
              <>
                <LogIn size={14} />
                <span>{lang === 'en-GB' ? 'Sign In' : '安全登录'}</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Nav Menu */}
      <div className="border-t border-[#1E3A5F]/50 bg-[#0E2442]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex space-x-1 sm:space-x-2 py-1 overflow-x-auto scrollbar-none" id="nav-views">
            {navItems.map(item => {
              const active = currentView === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onViewChange(item.id)}
                  className={`text-xs px-3 sm:px-4 py-2.5 font-medium transition-all whitespace-nowrap border-b-2 focus:outline-none ${
                    active
                      ? 'border-[#E60000] text-white bg-[#0A1D35]/80 font-semibold'
                      : 'border-transparent text-slate-300 hover:text-white hover:bg-slate-800/35'
                  }`}
                  id={`nav-item-${item.id}`}
                >
                  {lang === 'en-GB' ? item.nameEn : item.nameZh}
                </button>
              );
            })}
          </nav>
        </div>
      </div>
    </header>
  );
}
