/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { systemEngine } from '../services/bankingEngine';
import { MakerCheckerPayment, Account } from '../types';
import {
  Briefcase,
  Users,
  CheckCircle,
  XCircle,
  Upload,
  Layers,
  ArrowUpRight,
  TrendingUp,
  FileCheck2,
  DollarSign
} from 'lucide-react';

interface CorporateDashboardProps {
  lang: 'en-GB' | 'zh-CN';
}

export default function CorporateDashboard({ lang }: CorporateDashboardProps) {
  const [corporateAccounts, setCorporateAccounts] = useState<Account[]>([]);
  const [mcPayments, setMcPayments] = useState<MakerCheckerPayment[]>([]);

  // User Role Switcher for Demo
  const [activeRole, setActiveRole] = useState<'Payment Maker' | 'Payment Approver'>('Payment Maker');

  // Maker input states
  const [recipientName, setRecipientName] = useState('');
  const [recipientAccount, setRecipientAccount] = useState('');
  const [payAmount, setPayAmount] = useState('');
  const [payType, setPayType] = useState<'Supplier' | 'Payroll' | 'Tax'>('Supplier');

  // Bulk Upload simulator
  const [csvContent, setCsvContent] = useState('');
  const [bulkValidateMsg, setBulkValidateMsg] = useState('');

  useEffect(() => {
    setCorporateAccounts(systemEngine.accounts.filter(a => a.type === 'Business'));
    setMcPayments([...systemEngine.makerCheckerPayments]);
  }, []);

  const refreshPaymentsList = () => {
    setMcPayments([...systemEngine.makerCheckerPayments]);
    setCorporateAccounts(systemEngine.accounts.filter(a => a.type === 'Business'));
  };

  // Submit Maker payment
  const handleMakerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(payAmount);
    if (isNaN(amt) || amt <= 0) return;

    systemEngine.submitMakerPayment({
      makerName: 'Finance Agent Liu (Demo)',
      type: payType,
      amount: amt,
      currency: 'GBP',
      recipientName: recipientName || 'Vendor Settle Ltd',
      recipientAccount: recipientAccount || 'GB40HSBC20104820938472'
    });

    setRecipientName('');
    setRecipientAccount('');
    setPayAmount('');
    refreshPaymentsList();
    alert(lang === 'en-GB' ? 'Payment submitted to Checker approval queue.' : '付款申请成功创建，已送审 Checker 核销队列。');
  };

  // Checker approve
  const handleCheckerApprove = (id: string) => {
    const res = systemEngine.approveMakerPayment(id, 'Director Watson (Approver)');
    if (res.success) {
      refreshPaymentsList();
      alert(lang === 'en-GB' ? 'Transaction approved and debit settled.' : '交易审核通过，核心账户清算完成。');
    } else {
      alert(lang === 'en-GB' ? `Approval failed: ${res.error}` : `审核清算失败: ${res.error}`);
    }
  };

  // Checker reject
  const handleCheckerReject = (id: string) => {
    const payment = systemEngine.makerCheckerPayments.find(p => p.id === id);
    if (payment) {
      payment.status = 'REJECTED';
      payment.rejectionReasonEn = 'Rejected under compliance standard policy';
      payment.rejectionReasonZh = 'Checker 合规政策性否决';
      refreshPaymentsList();
    }
  };

  // Bulk Payment Upload simulator
  const handleBulkCsvUpload = (e: React.FormEvent) => {
    e.preventDefault();
    if (!csvContent.trim()) return;

    // Parse mock CSV
    const rows = csvContent.split('\n');
    let importedCount = 0;
    let duplicateCheck = new Set();

    rows.forEach(row => {
      const parts = row.split(',');
      if (parts.length >= 3) {
        const name = parts[0].trim();
        const acc = parts[1].trim();
        const amt = parseFloat(parts[2].trim());

        if (name && acc && !isNaN(amt)) {
          // Check for duplicate account rows in bulk file
          if (duplicateCheck.has(acc)) {
            return; // Duplicate guard
          }
          duplicateCheck.add(acc);

          systemEngine.submitMakerPayment({
            makerName: 'Bulk File Processor',
            type: 'Bulk',
            amount: amt,
            currency: 'GBP',
            recipientName: name,
            recipientAccount: acc
          });
          importedCount++;
        }
      }
    });

    setBulkValidateMsg(lang === 'en-GB'
      ? `SUCCESS: Validated and loaded ${importedCount} bulk payment vouchers to approval queue. Checked 0 duplicates.`
      : `解析成功：共核对并批量导入 ${importedCount} 张收付记账凭证至审核队列。拦截 0 笔重复项。`
    );
    setCsvContent('');
    refreshPaymentsList();
  };

  const corporateBalance = corporateAccounts[0]?.balances['GBP'] || 84200000;

  return (
    <div className="space-y-6 max-w-7xl mx-auto py-2" id="corporate-banking-dashboard">
      {/* Metrics Banner */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-[#0E223D] border border-[#1E3B5F] p-4 rounded-xl text-white">
          <span className="text-[9px] uppercase tracking-wider text-slate-400 font-mono font-bold block">{lang === 'en-GB' ? 'Company Cash Reserves' : '企业备付总资金'}</span>
          <p className="text-xl font-bold tracking-tight mt-1 font-mono">£{corporateBalance.toLocaleString('en-GB', { minimumFractionDigits: 2 })}</p>
          <span className="text-[10px] text-emerald-400 font-mono mt-1 block">▲ 1.4% MoM</span>
        </div>
        <div className="bg-[#0E223D] border border-[#1E3B5F] p-4 rounded-xl text-white">
          <span className="text-[9px] uppercase tracking-wider text-slate-400 font-mono font-bold block">{lang === 'en-GB' ? 'Receivables (AR)' : '应收未收账款 (A/R)'}</span>
          <p className="text-xl font-bold tracking-tight mt-1 font-mono">£21,400,000.00</p>
          <span className="text-[10px] text-slate-400 font-mono mt-1 block">Due: 30 Days</span>
        </div>
        <div className="bg-[#0E223D] border border-[#1E3B5F] p-4 rounded-xl text-white">
          <span className="text-[9px] uppercase tracking-wider text-slate-400 font-mono font-bold block">{lang === 'en-GB' ? 'Payables (AP)' : '应付应缴账款 (A/P)'}</span>
          <p className="text-xl font-bold tracking-tight mt-1 font-mono">£18,200,000.00</p>
          <span className="text-[10px] text-red-400 font-mono mt-1 block">Vouchers: 12 Pending</span>
        </div>
        <div className="bg-[#0E223D] border border-[#1E3B5F] p-4 rounded-xl text-white">
          <span className="text-[9px] uppercase tracking-wider text-slate-400 font-mono font-bold block">{lang === 'en-GB' ? 'Total Group Liquidity' : '集团池流动性池'}</span>
          <p className="text-xl font-bold tracking-tight mt-1 font-mono">£87,400,000.00</p>
          <span className="text-[10px] text-emerald-400 font-mono mt-1 block">Safe Buffers: Active</span>
        </div>
      </div>

      {/* Corporate User Role Switcher */}
      <div className="bg-[#0A1625] border border-[#1E334D] p-4 rounded-xl flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Users size={16} className="text-blue-400" />
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 font-mono">
              {lang === 'en-GB' ? 'Bilingual Corporate Operator Profile' : '企业财务角色模拟沙盘'}
            </h3>
            <p className="text-[10px] text-slate-400 mt-0.5">
              {lang === 'en-GB' ? 'Swap roles to test the Maker-Checker compliance workflow.' : '切换不同级别角色身份以模拟行内 “制单-复核-审批” 的合规机制。'}
            </p>
          </div>
        </div>

        <div className="flex gap-2">
          <button
            onClick={() => setActiveRole('Payment Maker')}
            className={`px-3 py-1.5 rounded text-xs font-mono font-bold uppercase transition-all ${
              activeRole === 'Payment Maker'
                ? 'bg-red-700 text-white border border-red-600'
                : 'bg-slate-800 text-slate-400 border border-slate-700 hover:text-white'
            }`}
          >
            {lang === 'en-GB' ? 'Maker (Liu)' : '制单员 - 刘先生'}
          </button>
          <button
            onClick={() => setActiveRole('Payment Approver')}
            className={`px-3 py-1.5 rounded text-xs font-mono font-bold uppercase transition-all ${
              activeRole === 'Payment Approver'
                ? 'bg-[#22C55E] text-[#0A1625] border border-emerald-400'
                : 'bg-slate-800 text-slate-400 border border-slate-700 hover:text-white'
            }`}
          >
            {lang === 'en-GB' ? 'Checker (Watson)' : '复核审批员 - 华生'}
          </button>
        </div>
      </div>

      {/* Main Grid: Form / Approve table */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Side: Creation Forms for Maker */}
        <div className="lg:col-span-1 space-y-6">
          {/* Payment creation */}
          <div className="bg-[#0A1625] border border-[#1E334D] p-5 rounded-xl space-y-4">
            <h3 className="text-xs uppercase tracking-wider text-slate-400 font-bold flex items-center gap-1.5 font-mono">
              <Briefcase size={14} className="text-red-400" />
              {lang === 'en-GB' ? 'Maker Payment Order' : '财务转账制单 (Payment Maker)'}
            </h3>

            <form onSubmit={handleMakerSubmit} className="space-y-3.5 text-xs">
              <div>
                <label className="text-[9px] uppercase text-slate-400 font-mono">Beneficiary Name</label>
                <input
                  type="text"
                  required
                  className="w-full bg-[#071324] border border-slate-700 rounded px-2.5 py-1.5 text-white mt-1"
                  value={recipientName}
                  onChange={e => setRecipientName(e.target.value)}
                  placeholder="Acme Raw Materials"
                />
              </div>

              <div>
                <label className="text-[9px] uppercase text-slate-400 font-mono">IBAN / Account Number</label>
                <input
                  type="text"
                  required
                  className="w-full bg-[#071324] border border-slate-700 rounded px-2.5 py-1.5 text-white mt-1 font-mono"
                  value={recipientAccount}
                  onChange={e => setRecipientAccount(e.target.value)}
                  placeholder="GB90BARC2010482093"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[9px] uppercase text-slate-400 font-mono">Amount (GBP)</label>
                  <input
                    type="number"
                    required
                    className="w-full bg-[#071324] border border-slate-700 rounded px-2.5 py-1.5 text-white mt-1 font-mono"
                    value={payAmount}
                    onChange={e => setPayAmount(e.target.value)}
                    placeholder="1500000"
                  />
                </div>
                <div>
                  <label className="text-[9px] uppercase text-slate-400 font-mono">Payment Type</label>
                  <select
                    value={payType}
                    onChange={e => setPayType(e.target.value as any)}
                    className="w-full bg-[#071324] border border-slate-700 rounded px-2 py-1.5 text-white mt-1"
                  >
                    <option value="Supplier">Supplier Settle</option>
                    <option value="Payroll">Payroll Remit</option>
                    <option value="Tax">Tax Remit</option>
                  </select>
                </div>
              </div>

              <button
                type="submit"
                disabled={activeRole !== 'Payment Maker'}
                className={`w-full text-white font-bold py-2 rounded text-xs uppercase tracking-wider ${
                  activeRole === 'Payment Maker'
                    ? 'bg-red-700 hover:bg-red-600'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                }`}
              >
                {lang === 'en-GB' ? 'Draft Payment Vouchers' : '提交付款令审核'}
              </button>
            </form>
          </div>

          {/* CSV Bulk uploader */}
          <div className="bg-[#0A1625] border border-[#1E334D] p-5 rounded-xl space-y-4">
            <h3 className="text-xs uppercase tracking-wider text-slate-400 font-bold flex items-center gap-1.5 font-mono">
              <Upload size={14} className="text-emerald-400" />
              {lang === 'en-GB' ? 'Bulk Vouchers File Upload' : '批量 CSV 收付报表上传'}
            </h3>

            <form onSubmit={handleBulkCsvUpload} className="space-y-3 text-xs">
              <div>
                <label className="text-[9px] uppercase text-slate-400 font-mono block mb-1">
                  CSV Data Vouchers (Format: Name, Account, Amount)
                </label>
                <textarea
                  className="w-full bg-[#071324] border border-slate-700 rounded p-2 text-[10px] font-mono text-emerald-400 h-24"
                  value={csvContent}
                  onChange={e => setCsvContent(e.target.value)}
                  placeholder="Apex Electronics, GB82BARC9012, 450000&#10;Apex Electronics, GB82BARC9012, 450000 (Duplicate Test)&#10;Horizon Settle, HKD88201940, 250000"
                ></textarea>
              </div>

              <button
                type="submit"
                disabled={activeRole !== 'Payment Maker'}
                className={`w-full text-white font-bold py-1.5 rounded text-[10px] uppercase tracking-widest ${
                  activeRole === 'Payment Maker'
                    ? 'bg-emerald-600 hover:bg-emerald-500'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                }`}
              >
                {lang === 'en-GB' ? 'Validate & Run Bulk Batch' : '校对并批量入库凭证'}
              </button>

              {bulkValidateMsg && (
                <div className="p-2.5 bg-slate-900 rounded border border-slate-800 text-[10px] font-mono text-emerald-400">
                  {bulkValidateMsg}
                </div>
              )}
            </form>
          </div>
        </div>

        {/* Right Side: Approval workflow table */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-[#0A1625] border border-[#1E334D] p-5 rounded-xl">
            <h3 className="text-xs uppercase tracking-wider text-slate-400 font-bold mb-4 flex items-center gap-1.5 font-mono">
              <FileCheck2 size={14} className="text-blue-400" />
              {lang === 'en-GB' ? 'Maker-Checker Approval Deck' : '待处理企业凭证风控与审批中心'}
            </h3>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs font-mono">
                <thead>
                  <tr className="border-b border-[#1E334D] text-slate-400">
                    <th className="py-2">Voucher ID</th>
                    <th className="py-2">Beneficiary / Destination</th>
                    <th className="py-2">{lang === 'en-GB' ? 'Drafted by' : '制单人'}</th>
                    <th className="py-2 text-right">Amount</th>
                    <th className="py-2 text-center">Status</th>
                    <th className="py-2 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1E334D]/40 text-slate-300">
                  {mcPayments.map(p => (
                    <tr key={p.id} className="hover:bg-slate-800/10">
                      <td className="py-3 text-[10px] font-bold text-[#E60000]">{p.id}</td>
                      <td className="py-3">
                        <div className="font-sans">
                          <p className="font-semibold text-slate-200">{p.recipientName}</p>
                          <p className="text-[10px] text-slate-500 font-mono">{p.recipientAccount}</p>
                        </div>
                      </td>
                      <td className="py-3 text-[10px] text-slate-400">{p.makerName}</td>
                      <td className="py-3 text-right font-bold text-white">£{p.amount.toLocaleString('en-GB')}</td>
                      <td className="py-3 text-center">
                        <span className={`text-[9px] px-1.5 py-0.5 rounded uppercase font-bold ${
                          p.status === 'APPROVED' ? 'bg-emerald-950 text-emerald-400 border border-emerald-900/60' :
                          p.status === 'REJECTED' ? 'bg-red-950 text-red-400 border border-red-900/60' :
                          'bg-amber-950 text-amber-400 border border-amber-900/60'
                        }`}>
                          {p.status}
                        </span>
                      </td>
                      <td className="py-3 text-right">
                        {p.status === 'PENDING_APPROVAL' ? (
                          <div className="flex gap-1 justify-end">
                            <button
                              disabled={activeRole !== 'Payment Approver'}
                              onClick={() => handleCheckerApprove(p.id)}
                              className={`p-1 rounded text-white ${
                                activeRole === 'Payment Approver'
                                  ? 'bg-emerald-600 hover:bg-emerald-500'
                                  : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                              }`}
                              title={lang === 'en-GB' ? 'Approve' : '核销批准'}
                            >
                              <CheckCircle size={14} />
                            </button>
                            <button
                              disabled={activeRole !== 'Payment Approver'}
                              onClick={() => handleCheckerReject(p.id)}
                              className={`p-1 rounded text-white ${
                                activeRole === 'Payment Approver'
                                  ? 'bg-red-700 hover:bg-red-600'
                                  : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                              }`}
                              title={lang === 'en-GB' ? 'Reject' : '否决退回'}
                            >
                              <XCircle size={14} />
                            </button>
                          </div>
                        ) : (
                          <span className="text-[10px] text-slate-500 italic">
                            {p.checkerName ? 'Signed' : 'Settled'}
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
