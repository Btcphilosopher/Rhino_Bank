/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { systemEngine } from '../services/bankingEngine';
import { Bot, User, Send, Sparkles, ShieldCheck, Database } from 'lucide-react';

interface AiAssistantProps {
  lang: 'en-GB' | 'zh-CN';
  onClose: () => void;
}

interface Message {
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
  isSecureToolData?: boolean;
}

export default function AiAssistant({ lang, onClose }: AiAssistantProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Initial welcome message based on language
    setMessages([
      {
        sender: 'bot',
        text: lang === 'en-GB'
          ? "Hello, I am Aurelia, your Bilingual Banking Assistant. How can I help you manage your accounts today? (Try asking \"How much did I spend on food?\" or \"What is my balance?\")"
          : "您好，我是 Aurelia 双语智能银行助手。今天有什么我可以帮您？(您可以输入 “我现在有多少钱？” 或 “上个月在餐饮消费了多少钱？” 进行查询。)",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ]);
  }, [lang]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = () => {
    if (!input.trim()) return;

    const userText = input.trim();
    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    setMessages(prev => [...prev, { sender: 'user', text: userText, timestamp }]);
    setInput('');

    // Simulate thinking delay
    setTimeout(() => {
      const lowerText = userText.toLowerCase();
      let responseText = '';
      let isSecure = false;

      // Real bilingual intent matching to execute secure state tools
      if (
        lowerText.includes('how much money') ||
        lowerText.includes('balance') ||
        lowerText.includes('how much do i have') ||
        lowerText.includes('账户余额') ||
        lowerText.includes('多少钱') ||
        lowerText.includes('余额')
      ) {
        // Query AccountTool
        const result = systemEngine.executeAiBalanceQuery();
        responseText = lang === 'en-GB' ? result.balancesEn : result.balancesZh;
        isSecure = true;
      } else if (
        lowerText.includes('spend on food') ||
        lowerText.includes('spent on food') ||
        lowerText.includes('food last month') ||
        lowerText.includes('餐饮') ||
        lowerText.includes('吃') ||
        lowerText.includes('食品') ||
        lowerText.includes('乐购')
      ) {
        // Query TransactionTool / CategoryEngine
        const result = systemEngine.executeAiSpendQuery();
        responseText = lang === 'en-GB' ? result.spendEn : result.spendZh;
        isSecure = true;
      } else if (
        lowerText.includes('transfer') ||
        lowerText.includes('send money') ||
        lowerText.includes('汇款') ||
        lowerText.includes('转账')
      ) {
        responseText = lang === 'en-GB'
          ? "To make a transfer, please use the 'Transfer' card in your Retail Banking dashboard. It requires secure double-entry approval."
          : "若要进行转账汇款，请直接点击主控面板上的 “转账” 或 “汇款” 功能卡片，该操作需经由复式记账内核审批。";
      } else if (
        lowerText.includes('freeze') ||
        lowerText.includes('card') ||
        lowerText.includes('冻结') ||
        lowerText.includes('卡')
      ) {
        responseText = lang === 'en-GB'
          ? "You can view, freeze or unfreeze your active cards instantly within the 'Card Management' terminal below."
          : "您可以在下方 “银行卡管理” 部分查看卡状态，或立即对卡片执行冻结和解冻操作。";
      } else {
        responseText = lang === 'en-GB'
          ? "I am connected securely to the HSBC Global Banking Engine. I can resolve balance inquiries, Category-Level transaction analysis, and account state lookups. Please specify an account action."
          : "我已安全接入系统核心数据库。我可以为您执行精准的账户余额核验、交易账单类别流速分析以及银行卡状态锁死。请指定相关的查询命令。";
      }

      setMessages(prev => [
        ...prev,
        {
          sender: 'bot',
          text: responseText,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          isSecureToolData: isSecure
        }
      ]);
    }, 600);
  };

  return (
    <div className="w-full h-full bg-[#091524] flex flex-col overflow-hidden text-slate-100 font-sans" id="ai-drawer">
      {/* Header */}
      <div className="bg-[#0D2440] px-4 py-3 border-b border-[#1E3D66] flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Sparkles size={16} className="text-[#E60000]" />
          <div>
            <h3 className="font-semibold text-sm tracking-wide">
              {lang === 'en-GB' ? 'Aurelia Assistant' : 'Aurelia 智能助理'}
            </h3>
            <span className="text-[9px] text-[#22C55E] flex items-center gap-1">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500"></span>
              BILINGUAL TOOL API ACTIVE
            </span>
          </div>
        </div>
        <button
          onClick={onClose}
          className="text-slate-400 hover:text-white text-xs px-2 py-1 rounded hover:bg-slate-800"
        >
          ✕
        </button>
      </div>

      {/* Message List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-[#06101D]">
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] rounded-lg p-3 text-xs ${
              m.sender === 'user'
                ? 'bg-slate-800 text-slate-100 rounded-tr-none'
                : 'bg-[#122A4A] border border-[#1E3C62] text-slate-200 rounded-tl-none'
            }`}>
              <div className="flex items-center gap-1.5 mb-1 text-[9px] text-slate-400 font-semibold tracking-wider uppercase font-mono">
                {m.sender === 'user' ? <User size={10} /> : <Bot size={10} className="text-[#E60000]" />}
                <span>{m.sender === 'user' ? (lang === 'en-GB' ? 'Alexander' : '用户') : 'Aurelia Core'}</span>
                <span className="ml-auto">{m.timestamp}</span>
              </div>

              <p className="leading-relaxed whitespace-pre-wrap">{m.text}</p>

              {m.isSecureToolData && (
                <div className="mt-2.5 pt-1.5 border-t border-slate-700/60 flex items-center gap-1.5 text-[9px] text-emerald-400 font-mono">
                  <ShieldCheck size={11} />
                  <span className="font-semibold tracking-widest uppercase">
                    {lang === 'en-GB' ? 'SECURED LEDGER SOURCE' : '总账底层接口源核对：真实'}
                  </span>
                </div>
              )}
            </div>
          </div>
        ))}
        <div ref={chatEndRef} />
      </div>

      {/* Quick suggestions */}
      <div className="px-4 py-2 border-t border-[#1E3D66]/40 bg-[#071524] flex gap-2 overflow-x-auto scrollbar-none">
        <button
          onClick={() => setInput(lang === 'en-GB' ? "What is my balance?" : "我现在有多少钱？")}
          className="text-[10px] bg-slate-800/80 hover:bg-slate-700 hover:text-white px-2.5 py-1 rounded-full text-slate-300 border border-slate-700/40 whitespace-nowrap"
        >
          {lang === 'en-GB' ? "💳 Check Balance" : "💳 查询我的余额"}
        </button>
        <button
          onClick={() => setInput(lang === 'en-GB' ? "How much did I spend on food?" : "上个月我在餐饮花了多少钱？")}
          className="text-[10px] bg-slate-800/80 hover:bg-slate-700 hover:text-white px-2.5 py-1 rounded-full text-slate-300 border border-slate-700/40 whitespace-nowrap"
        >
          {lang === 'en-GB' ? "🍔 Food Spending" : "🍔 餐饮开销分析"}
        </button>
      </div>

      {/* Input field */}
      <div className="p-3 border-t border-[#1E3D66] bg-[#0D2440] flex gap-2">
        <input
          type="text"
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleSend()}
          placeholder={lang === 'en-GB' ? "Ask about your balances..." : "询问您的账户余额..."}
          className="flex-1 bg-[#06101D] border border-[#1E3C62] rounded px-3 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500"
        />
        <button
          onClick={handleSend}
          className="bg-[#E60000] hover:bg-[#CC0000] p-2 rounded text-white transition-all flex items-center justify-center"
        >
          <Send size={14} />
        </button>
      </div>
    </div>
  );
}
