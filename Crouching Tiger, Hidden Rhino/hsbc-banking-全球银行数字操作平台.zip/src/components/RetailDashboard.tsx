/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { systemEngine } from '../services/bankingEngine';
import { Account, Transaction, Card, Loan, SavingsGoal, SpendingBudget, Posting } from '../types';
import {
  CreditCard,
  Send,
  Lock,
  Unlock,
  CheckCircle2,
  XCircle,
  AlertOctagon,
  TrendingDown,
  PieChart as PieIcon,
  Calculator,
  Target,
  FileSpreadsheet,
  Layers,
  ArrowRightLeft,
  DollarSign,
  Fingerprint,
  Smartphone
} from 'lucide-react';
import * as echarts from 'echarts';

interface RetailDashboardProps {
  lang: 'en-GB' | 'zh-CN';
  isLoggedIn: boolean;
  onLoginSuccess: () => void;
}

export default function RetailDashboard({ lang, isLoggedIn, onLoginSuccess }: RetailDashboardProps) {
  // State from system engine
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [cards, setCards] = useState<Card[]>([]);
  const [loans, setLoans] = useState<Loan[]>([]);
  const [goals, setGoals] = useState<SavingsGoal[]>([]);
  const [budgets, setBudgets] = useState<SpendingBudget[]>([]);

  // Local state for forms
  const [loginUsername, setLoginUsername] = useState('PTY-84209');
  const [loginPassword, setLoginPassword] = useState('•••••••••');
  const [errorMsg, setErrorMsg] = useState('');

  // Transfer Form state
  const [recipientName, setRecipientName] = useState('');
  const [recipientAccount, setRecipientAccount] = useState('');
  const [transferAmount, setTransferAmount] = useState('');
  const [transferReference, setTransferReference] = useState('');
  const [selectedSourceAccount, setSelectedSourceAccount] = useState('');
  const [selectedTargetAccount, setSelectedTargetAccount] = useState('');

  // FX state
  const [fxFromCurrency, setFxFromCurrency] = useState('GBP');
  const [fxToCurrency, setFxToCurrency] = useState('CNY');
  const [fxAmount, setFxAmount] = useState('1000');
  const [fxOutput, setFxOutput] = useState<number | null>(null);

  // Amortization state
  const [calcPrincipal, setCalcPrincipal] = useState('350000');
  const [calcRate, setCalcRate] = useState('3.75');
  const [calcTerm, setCalcTerm] = useState('300');
  const [calcSchedule, setCalcSchedule] = useState<any[]>([]);

  // Payment Confirmation review
  const [pendingPayment, setPendingPayment] = useState<any | null>(null);
  const [otpCode, setOtpCode] = useState('');
  const [otpVerified, setOtpVerified] = useState(false);
  const [otpError, setOtpError] = useState('');
  const [paymentSuccessData, setPaymentSuccessData] = useState<any | null>(null);

  // Dynamic Transaction Filter states
  const [filterCurrency, setFilterCurrency] = useState('ALL');
  const [filterCategory, setFilterCategory] = useState('ALL');

  // Virtual Card Merchant Spender terminal state
  const [spendMerchantName, setSpendMerchantName] = useState('Starbucks Coffee');
  const [spendAmount, setSpendAmount] = useState('4.80');
  const [spendResult, setSpendResult] = useState<{ success: boolean; msg: string } | null>(null);

  const chartRef = useRef<HTMLDivElement>(null);
  const chartInstance = useRef<echarts.ECharts | null>(null);

  // Sync state with engine
  useEffect(() => {
    setAccounts([...systemEngine.accounts]);
    setTransactions([...systemEngine.transactions]);
    setCards([...systemEngine.cards]);
    setLoans([...systemEngine.loans]);
    setGoals([...systemEngine.savingsGoals]);
    setBudgets([...systemEngine.spendingBudgets]);

    if (systemEngine.accounts.length > 0) {
      setSelectedSourceAccount(systemEngine.accounts[0].id);
      setSelectedTargetAccount(systemEngine.accounts[1].id);
    }
  }, [isLoggedIn, paymentSuccessData]);

  // Recalculate amortization
  useEffect(() => {
    const p = parseFloat(calcPrincipal);
    const r = parseFloat(calcRate);
    const t = parseInt(calcTerm);
    if (!isNaN(p) && !isNaN(r) && !isNaN(t) && t > 0) {
      const schedule = systemEngine.calculateAmortization(p, r, t);
      setCalcSchedule(schedule.slice(0, 12)); // Show first 12 months for brevity
    }
  }, [calcPrincipal, calcRate, calcTerm]);

  // Handle FX quoting
  useEffect(() => {
    if (fxFromCurrency === fxToCurrency) {
      setFxOutput(parseFloat(fxAmount));
    } else {
      const pair = `${fxFromCurrency}/${fxToCurrency}`;
      const rateObj = systemEngine.getExchangeRate(pair);
      const amt = parseFloat(fxAmount);
      if (!isNaN(amt)) {
        setFxOutput(amt * rateObj.customerRate);
      }
    }
  }, [fxFromCurrency, fxToCurrency, fxAmount]);

  // Initialize ECharts spending donut
  useEffect(() => {
    if (!isLoggedIn || !chartRef.current) return;

    if (chartInstance.current) {
      chartInstance.current.dispose();
    }

    const myChart = echarts.init(chartRef.current);
    chartInstance.current = myChart;

    const data = budgets.map(b => ({
      name: b.category,
      value: b.usedAmount
    }));

    const option = {
      tooltip: {
        trigger: 'item',
        formatter: '{b}: £{c} ({d}%)'
      },
      legend: {
        bottom: '0%',
        left: 'center',
        textStyle: { color: '#94A3B8', fontSize: 11 }
      },
      series: [
        {
          name: lang === 'en-GB' ? 'Spending Category' : '消费类别占比',
          type: 'pie',
          radius: ['45%', '70%'],
          avoidLabelOverlap: false,
          itemStyle: {
            borderRadius: 6,
            borderColor: '#0B1E36',
            borderWidth: 2
          },
          label: {
            show: false,
            position: 'center'
          },
          emphasis: {
            label: {
              show: true,
              fontSize: 14,
              fontWeight: 'bold',
              color: '#FFFFFF'
            }
          },
          labelLine: {
            show: false
          },
          data: data,
          color: ['#0A84FF', '#30D158', '#FF9F0A', '#FF453A', '#BF5AF2']
        }
      ]
    };

    myChart.setOption(option);

    const handleResize = () => {
      myChart.resize();
    };

    window.addEventListener('resize', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
      myChart.dispose();
    };
  }, [isLoggedIn, budgets, lang]);

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (loginUsername === 'PTY-84209' || loginUsername.toLowerCase() === 'alexander') {
      onLoginSuccess();
      setErrorMsg('');
    } else {
      setErrorMsg(lang === 'en-GB' ? 'Invalid credentials for demo account' : '演示账号工号不正确');
    }
  };

  // Trigger transfer flow with Step-Up Review
  const initiateTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(transferAmount);
    if (isNaN(amt) || amt <= 0) {
      alert(lang === 'en-GB' ? 'Please enter a valid amount' : '请输入有效的付款金额');
      return;
    }

    const srcAcc = accounts.find(a => a.id === selectedSourceAccount);
    if (!srcAcc) return;

    const currentBal = srcAcc.balances[srcAcc.currency] || 0;
    if (currentBal < amt) {
      alert(lang === 'en-GB' ? 'Insufficient balances in source account' : '扣款账户余额不足');
      return;
    }

    // Set pending payment for user verification
    setPendingPayment({
      sourceAccountId: selectedSourceAccount,
      sourceAccountName: srcAcc.nameEn,
      recipientName: recipientName || 'Transfer Beneficiary',
      recipientAccount: recipientAccount || 'GB40HSBC8219401202',
      amount: amt,
      currency: srcAcc.currency,
      fee: amt > 5000 ? 15.00 : 0.00, // Simulated large transfer fees
      reference: transferReference || 'N/A'
    });
    setOtpCode('');
    setOtpVerified(false);
    setOtpError('');
  };

  const confirmTransferSca = () => {
    if (otpCode !== '8888') {
      setOtpError(lang === 'en-GB' ? 'Invalid security OTP. Use 8888 for demo.' : '安全验证码错误。请输入演示验证码 8888。');
      return;
    }

    // Execute through ledger engine
    const idempotencyKey = 'idemp-' + Math.floor(10000 + Math.random() * 90000);
    const targetAcc = accounts.find(a => a.id === selectedTargetAccount);

    if (!targetAcc) return;

    const result = systemEngine.executeTransfer(
      pendingPayment.sourceAccountId,
      selectedTargetAccount,
      pendingPayment.amount,
      pendingPayment.reference,
      idempotencyKey
    );

    if (result.success) {
      setPaymentSuccessData({
        txId: result.transactionId,
        correlationId: result.correlationId,
        postings: systemEngine.journalEntries[0]?.postings || []
      });
      setPendingPayment(null);
      setTransferAmount('');
      setRecipientName('');
      setRecipientAccount('');
      setTransferReference('');
    } else {
      setOtpError(lang === 'en-GB' ? `System Error: ${result.error}` : `系统记账错误: ${result.error}`);
    }
  };

  // FX Conversion submission
  const executeConversion = () => {
    const amt = parseFloat(fxAmount);
    if (isNaN(amt) || amt <= 0) return;

    const sourceAcc = accounts.find(a => a.id === 'acc-03')!; // Global wallet
    const corrId = 'fx-corr-' + Math.floor(10000 + Math.random() * 90000);

    const result = systemEngine.executeFxConversion(
      sourceAcc.id,
      fxFromCurrency,
      fxToCurrency,
      amt,
      corrId
    );

    if (result.success) {
      setPaymentSuccessData({
        txId: 'FX-JNL-' + Math.floor(10000 + Math.random() * 90000),
        correlationId: corrId,
        postings: [
          { type: 'DEBIT', ledgerCode: '2001', amount: amt, currency: fxFromCurrency, narrative: 'FX Debit Wallet' },
          { type: 'CREDIT', ledgerCode: '2002', amount: result.receiveAmount, currency: fxToCurrency, narrative: 'FX Credit Wallet' }
        ]
      });
      alert(lang === 'en-GB' ? 'FX Conversion booked to ledger successfully!' : '外汇兑换成功，复式科目平衡记账。');
    } else {
      alert(lang === 'en-GB' ? `Conversion failed: ${result.error}` : `汇率兑换失败: ${result.error}`);
    }
  };

  // Freeze/Unfreeze card handler
  const toggleCardFreeze = (cardId: string, currentStatus: string) => {
    const card = systemEngine.cards.find(c => c.id === cardId);
    if (card) {
      const oldState = card.status;
      card.status = currentStatus === 'ACTIVE' ? 'FROZEN' : 'ACTIVE';
      systemEngine.writeAuditLog(
        'Alexander Mercer',
        'RETAIL_USER',
        currentStatus === 'ACTIVE' ? 'FREEZE_CARD' : 'UNFREEZE_CARD',
        'Card',
        oldState,
        card.status,
        'corr-card-' + Math.floor(10000 + Math.random() * 90000)
      );
      setCards([...systemEngine.cards]);
    }
  };

  // Spender Simulator
  const simulateCardSpend = () => {
    const amt = parseFloat(spendAmount);
    if (isNaN(amt) || amt <= 0) return;

    const debitCard = cards[0]; // Everyday Debit Card
    const account = accounts.find(a => a.id === debitCard.accountId)!;

    if (debitCard.status === 'FROZEN') {
      setSpendResult({
        success: false,
        msg: lang === 'en-GB'
          ? "REJECTED: Card is currently FROZEN. Transactions are blocked."
          : "交易拦截：该银行卡处于冻结(FROZEN)锁定状态，支付被拒。"
      });
      return;
    }

    const bal = account.balances[account.currency] || 0;
    if (bal < amt) {
      setSpendResult({
        success: false,
        msg: lang === 'en-GB' ? "REJECTED: Insufficient balance in linked account." : "交易拒绝：相关扣款活期账户内备付金余额不足。"
      });
      return;
    }

    // Process spend
    const corrId = 'corr-spend-' + Math.floor(10000 + Math.random() * 90000);
    const postings: Posting[] = [
      { type: 'DEBIT', ledgerCode: '2001', amount: amt, currency: 'GBP', narrative: `Debit spend ${spendMerchantName}` },
      { type: 'CREDIT', ledgerCode: '1001', amount: amt, currency: 'GBP', narrative: `Credit vault settle ${spendMerchantName}` }
    ];

    systemEngine.postJournalEntry(postings, `Card Spend: ${spendMerchantName}`, corrId);

    // Update balances
    account.balances[account.currency] = bal - amt;
    account.availableBalance = account.balances[account.currency];

    // Add transaction
    const newTx: Transaction = {
      id: 'TX-SPEND-' + Math.floor(10000 + Math.random() * 90000),
      accountId: account.id,
      timestamp: new Date().toISOString(),
      currency: 'GBP',
      amount: -amt,
      type: 'CARD_SPEND',
      counterparty: spendMerchantName,
      reference: `Card Purchase ${debitCard.cardNumberMasked.slice(-4)}`,
      status: 'COMPLETED',
      category: 'Food',
      correlationId: corrId
    };
    systemEngine.transactions.unshift(newTx);

    setTransactions([...systemEngine.transactions]);
    setAccounts([...systemEngine.accounts]);
    setSpendResult({
      success: true,
      msg: lang === 'en-GB'
        ? `APPROVED! Spent £${amt.toFixed(2)} at ${spendMerchantName}. Double-entry balanced.`
        : `交易批准！在 ${spendMerchantName} 消费 £${amt.toFixed(2)}，复式分录对账平。`
    });

    setTimeout(() => setSpendResult(null), 5000);
  };

  // Quick Savings Goal top-up
  const topUpGoal = (goalId: string) => {
    const goal = systemEngine.savingsGoals.find(g => g.id === goalId);
    const everydayAcc = systemEngine.accounts.find(a => a.id === 'acc-01')!;
    const everydayBal = everydayAcc.balances['GBP'] || 0;

    if (everydayBal < 100) {
      alert(lang === 'en-GB' ? 'Insufficient funds in Everyday Account to save.' : '日常账户备付余额不足100英镑，无法储蓄。');
      return;
    }

    if (goal) {
      // Create postings to savings ledger
      const corrId = 'corr-goal-' + Math.floor(10000 + Math.random() * 90000);
      const postings: Posting[] = [
        { type: 'DEBIT', ledgerCode: '2001', amount: 100, currency: 'GBP', narrative: `Everyday transfer to goal ${goal.nameEn}` },
        { type: 'CREDIT', ledgerCode: '2003', amount: 100, currency: 'GBP', narrative: `Goal Savings credit` }
      ];

      systemEngine.postJournalEntry(postings, `Savings Target Boost: ${goal.nameEn}`, corrId);

      // Mutate
      everydayAcc.balances['GBP'] = everydayBal - 100;
      everydayAcc.availableBalance = everydayAcc.balances['GBP'];
      goal.currentAmount += 100;

      // Add transaction record
      const newTx: Transaction = {
        id: 'TX-SAV-' + Math.floor(10000 + Math.random() * 90000),
        accountId: everydayAcc.id,
        timestamp: new Date().toISOString(),
        currency: 'GBP',
        amount: -100,
        type: 'TRANSFER',
        counterparty: lang === 'en-GB' ? `Savings Goal: ${goal.nameEn}` : `储蓄目标: ${goal.nameZh}`,
        reference: `Savings Boost`,
        status: 'COMPLETED',
        category: 'Investment',
        correlationId: corrId
      };
      systemEngine.transactions.unshift(newTx);

      setGoals([...systemEngine.savingsGoals]);
      setAccounts([...systemEngine.accounts]);
      setTransactions([...systemEngine.transactions]);
    }
  };

  // Transaction Filters
  const filteredTransactions = transactions.filter(t => {
    if (filterCurrency !== 'ALL' && t.currency !== filterCurrency) return false;
    if (filterCategory !== 'ALL' && t.category !== filterCategory) return false;
    return true;
  });

  if (!isLoggedIn) {
    return (
      <div className="max-w-md mx-auto my-16 bg-[#0E223D] border border-[#1E3B5F] rounded-xl shadow-2xl p-6 text-slate-100 font-sans" id="login-container">
        <div className="text-center mb-8">
          <div className="inline-flex bg-[#E60000] p-3 rounded font-black text-xl mb-3 skew-x-12">
            <span className="transform -skew-x-12">H</span>
          </div>
          <h2 className="text-lg font-bold uppercase tracking-wider text-white">HSBC BANKING</h2>
          <p className="text-xs text-slate-400 mt-1 uppercase tracking-widest font-mono">
            {lang === 'en-GB' ? 'Secure Gateway Login' : '核心网关安全控制登录'}
          </p>
        </div>

        {errorMsg && (
          <div className="bg-red-950/40 border border-red-900/60 p-3 rounded text-xs text-red-400 mb-4 flex items-center gap-2">
            <AlertOctagon size={14} />
            <span>{errorMsg}</span>
          </div>
        )}

        <form onSubmit={handleLoginSubmit} className="space-y-4">
          <div>
            <label className="block text-xs uppercase tracking-wider text-slate-400 font-semibold mb-1.5 font-mono">
              {lang === 'en-GB' ? 'Employee ID / Party Identifier' : '雇员登录工号 / 唯一身份标识'}
            </label>
            <input
              type="text"
              className="w-full bg-[#071324] border border-[#1E3D66] rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-red-500 font-mono"
              value={loginUsername}
              onChange={e => setLoginUsername(e.target.value)}
              required
            />
          </div>

          <div>
            <label className="block text-xs uppercase tracking-wider text-slate-400 font-semibold mb-1.5 font-mono">
              {lang === 'en-GB' ? 'Access Passcode' : '通行验证密钥'}
            </label>
            <input
              type="password"
              className="w-full bg-[#071324] border border-[#1E3D66] rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-red-500 font-mono"
              value={loginPassword}
              onChange={e => setLoginPassword(e.target.value)}
              required
            />
          </div>

          <div className="bg-slate-900/50 p-2.5 rounded border border-slate-800 flex items-start gap-2 text-[10px] text-slate-400">
            <Layers size={14} className="text-blue-400 shrink-0 mt-0.5" />
            <span>
              {lang === 'en-GB'
                ? "DEMO POLICY: This is a secure operating system environment. For testing, enter the pre-loaded ID 'PTY-84209' to sign in instantly."
                : "系统演示规则：本环境为完全闭环的双语金融推演。请输入系统默认绑定的工号 'PTY-84209' 直接登录。"}
            </span>
          </div>

          <button
            type="submit"
            className="w-full bg-emerald-600 hover:bg-emerald-500 hover:scale-[1.01] text-white py-2.5 rounded text-xs uppercase tracking-widest font-bold transition-all"
            id="btn-login-submit"
          >
            {lang === 'en-GB' ? 'Verify Credentials & Access' : '验证数字凭证并登录'}
          </button>
        </form>
      </div>
    );
  }

  const primaryCurrentAccount = accounts.find(a => a.id === 'acc-01');
  const savingsAccount = accounts.find(a => a.id === 'acc-02');
  const usdAccount = accounts.find(a => a.id === 'acc-03');

  const totalGbpBalance = (primaryCurrentAccount?.balances['GBP'] || 0) + (savingsAccount?.balances['GBP'] || 0);

  return (
    <div className="space-y-6 max-w-7xl mx-auto py-2" id="retail-banking-dashboard">
      {/* Top Welcome Card */}
      <div className="bg-[#0E223D] border border-[#1E3B5F] rounded-xl p-6 text-white flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <span className="text-[10px] uppercase tracking-wider text-slate-400 font-mono font-semibold">
            {lang === 'en-GB' ? 'Customer Profile Connected' : '核心系统个人客户画像：Alexander Mercer'}
          </span>
          <h2 className="text-2xl font-semibold tracking-tight mt-1 font-serif">
            {lang === 'en-GB' ? 'Good morning, Alexander' : '早上好，亚历山大·默瑟 先生'}
          </h2>
          <p className="text-xs text-slate-400 font-mono mt-1">
            Party ID: PTY-84209 • KYC Verified • UK Branch
          </p>
        </div>

        <div className="flex gap-8 border-l border-slate-700/60 pl-0 md:pl-8">
          <div>
            <p className="text-[10px] uppercase tracking-wider text-slate-400 font-mono font-semibold">
              {lang === 'en-GB' ? 'Total Account Balance' : '汇总估算英镑总余额'}
            </p>
            <p className="text-2xl font-bold tracking-tight text-white mt-1">
              £{(totalGbpBalance + (usdAccount?.balances['USD'] || 0) * 0.77).toLocaleString('en-GB', { minimumFractionDigits: 2 })}
            </p>
          </div>
          <div>
            <p className="text-[10px] uppercase tracking-wider text-[#22C55E] font-mono font-semibold">
              {lang === 'en-GB' ? 'Available Balance' : '可用备付总余额'}
            </p>
            <p className="text-2xl font-bold tracking-tight text-emerald-400 mt-1">
              £{totalGbpBalance.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
            </p>
          </div>
        </div>
      </div>

      {/* Main Grid Accounts + Trans */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Accounts list & quick FX */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-[#0A1625] border border-[#1E334D] rounded-xl p-4">
            <h3 className="text-xs uppercase tracking-wider text-slate-400 font-bold mb-4 flex items-center gap-1.5 font-mono">
              <Layers size={14} className="text-blue-400" />
              {lang === 'en-GB' ? 'My Portfolio Accounts' : '持有业务账户明细'}
            </h3>

            <div className="space-y-3">
              {/* Curr card */}
              {primaryCurrentAccount && (
                <div className="bg-[#0E223D]/60 border border-[#1E3B5F] p-3.5 rounded-lg hover:bg-[#0E223D] transition-all">
                  <div className="flex justify-between items-start">
                    <span className="text-xs text-slate-400 font-medium font-mono">
                      {lang === 'en-GB' ? 'Everyday Current' : '日常日常往来活期账户'}
                    </span>
                    <span className="text-[10px] bg-slate-800 text-slate-300 px-1.5 py-0.2 rounded font-mono">
                      GBP
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-500 font-mono mt-0.5">{primaryCurrentAccount.accountNumber}</p>
                  <p className="text-xl font-bold text-white mt-2">
                    £{primaryCurrentAccount.balances['GBP']?.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
                  </p>
                </div>
              )}

              {/* Savings card */}
              {savingsAccount && (
                <div className="bg-[#0E223D]/60 border border-[#1E3B5F] p-3.5 rounded-lg hover:bg-[#0E223D] transition-all">
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="text-xs text-slate-400 font-medium font-mono">
                        {lang === 'en-GB' ? 'High-Yield Savings' : '储蓄高息理财账户'}
                      </span>
                      <span className="block text-[10px] text-[#22C55E] font-semibold mt-0.5">
                        {savingsAccount.interestRate}% Interest APY
                      </span>
                    </div>
                    <span className="text-[10px] bg-slate-800 text-slate-300 px-1.5 py-0.2 rounded font-mono">
                      GBP
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-500 font-mono mt-0.5">{savingsAccount.accountNumber}</p>
                  <p className="text-xl font-bold text-white mt-1">
                    £{savingsAccount.balances['GBP']?.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
                  </p>
                </div>
              )}

              {/* USD Multi-wallet */}
              {usdAccount && (
                <div className="bg-[#0E223D]/60 border border-[#1E3B5F] p-3.5 rounded-lg hover:bg-[#0E223D] transition-all">
                  <div className="flex justify-between items-start">
                    <span className="text-xs text-slate-400 font-medium font-mono">
                      {lang === 'en-GB' ? 'Global USD Wallet' : '多币种国际钱包账户'}
                    </span>
                    <span className="text-[10px] bg-blue-950 text-blue-300 px-1.5 py-0.2 rounded font-mono uppercase font-bold">
                      Multi
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-500 font-mono mt-0.5">{usdAccount.accountNumber}</p>
                  <div className="mt-3 grid grid-cols-3 gap-2 border-t border-slate-700/40 pt-2.5">
                    <div>
                      <span className="text-[9px] text-slate-400 font-mono uppercase">USD</span>
                      <p className="text-xs font-bold text-white">${usdAccount.balances['USD']?.toLocaleString('en-GB')}</p>
                    </div>
                    <div>
                      <span className="text-[9px] text-slate-400 font-mono uppercase">EUR</span>
                      <p className="text-xs font-bold text-slate-300">€{usdAccount.balances['EUR']?.toLocaleString('en-GB')}</p>
                    </div>
                    <div>
                      <span className="text-[9px] text-slate-400 font-mono uppercase">CNY</span>
                      <p className="text-xs font-bold text-slate-300">¥{usdAccount.balances['CNY']?.toLocaleString('en-GB')}</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Quick FX engine spot quote converter */}
          <div className="bg-[#0A1625] border border-[#1E334D] rounded-xl p-4">
            <h3 className="text-xs uppercase tracking-wider text-slate-400 font-bold mb-3 flex items-center gap-1.5 font-mono">
              <ArrowRightLeft size={14} className="text-emerald-400" />
              {lang === 'en-GB' ? 'FX Spot Engine Quote' : '外汇实时汇率与兑换系统'}
            </h3>

            <div className="space-y-3 text-xs">
              <div className="flex gap-2">
                <div className="flex-1">
                  <label className="text-[10px] text-slate-400 font-mono uppercase">From</label>
                  <select
                    value={fxFromCurrency}
                    onChange={e => setFxFromCurrency(e.target.value)}
                    className="w-full bg-[#071324] border border-slate-700 rounded px-2 py-1 text-white font-mono mt-1"
                  >
                    <option value="GBP">GBP (£)</option>
                    <option value="USD">USD ($)</option>
                    <option value="EUR">EUR (€)</option>
                    <option value="CNY">CNY (¥)</option>
                  </select>
                </div>
                <div className="flex-1">
                  <label className="text-[10px] text-slate-400 font-mono uppercase">To</label>
                  <select
                    value={fxToCurrency}
                    onChange={e => setFxToCurrency(e.target.value)}
                    className="w-full bg-[#071324] border border-slate-700 rounded px-2 py-1 text-white font-mono mt-1"
                  >
                    <option value="CNY">CNY (¥)</option>
                    <option value="GBP">GBP (£)</option>
                    <option value="USD">USD ($)</option>
                    <option value="EUR">EUR (€)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-[10px] text-slate-400 font-mono uppercase">{lang === 'en-GB' ? 'You Send' : '您支付'}</label>
                <input
                  type="number"
                  value={fxAmount}
                  onChange={e => setFxAmount(e.target.value)}
                  className="w-full bg-[#071324] border border-slate-700 rounded px-3 py-1.5 text-white font-mono mt-1 focus:outline-none focus:border-emerald-500"
                />
              </div>

              {fxOutput !== null && (
                <div className="bg-[#0E223D] p-3 rounded border border-slate-700/60">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] text-slate-400 font-mono">{lang === 'en-GB' ? 'Customer Rate' : '特惠汇率'}</span>
                    <span className="font-mono text-white text-xs">
                      1 {fxFromCurrency} = {systemEngine.getExchangeRate(`${fxFromCurrency}/${fxToCurrency}`).customerRate.toFixed(4)} {fxToCurrency}
                    </span>
                  </div>
                  <div className="flex justify-between items-center mt-2 pt-2 border-t border-slate-700/40">
                    <span className="text-[10px] text-emerald-400 font-semibold uppercase">{lang === 'en-GB' ? 'You Receive' : '您收到'}</span>
                    <span className="font-mono font-bold text-emerald-400 text-sm">
                      {fxToCurrency === 'GBP' ? '£' : fxToCurrency === 'USD' ? '$' : fxToCurrency === 'EUR' ? '€' : '¥'}
                      {fxOutput.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </span>
                  </div>
                </div>
              )}

              <button
                onClick={executeConversion}
                className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-semibold py-2 rounded transition-all flex items-center justify-center gap-1.5 uppercase tracking-widest text-[10px]"
              >
                <DollarSign size={12} />
                {lang === 'en-GB' ? 'Book FX Conversion' : '提交兑换并记账'}
              </button>
            </div>
          </div>
        </div>

        {/* Right Column (Span 2): Transfer Panel, Live Ledgers, Transactions */}
        <div className="lg:col-span-2 space-y-6">
          {/* Transfer Form or SCA Approval */}
          <div className="bg-[#0A1625] border border-[#1E334D] rounded-xl p-5">
            {pendingPayment ? (
              <div className="space-y-4" id="sca-verification-screen">
                <div className="bg-amber-950/20 border border-amber-900/60 p-4 rounded-lg flex items-start gap-3">
                  <Fingerprint className="text-amber-400 shrink-0 mt-0.5 animate-pulse" size={20} />
                  <div>
                    <h4 className="text-sm font-bold text-amber-300 uppercase tracking-wide">
                      {lang === 'en-GB' ? 'Strong Customer Authentication (SCA)' : '强客户身份安全核验（SCA）'}
                    </h4>
                    <p className="text-xs text-slate-400 mt-1">
                      {lang === 'en-GB'
                        ? 'High-risk internal transfer transaction requires OTP validation code.'
                        : '检测到涉及资金风险，请在移动端查收授权验证码进行交易授权。'}
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 border border-[#1E334D] p-4 rounded-lg bg-[#071324] text-xs">
                  <div>
                    <span className="text-slate-500 font-mono block uppercase">{lang === 'en-GB' ? 'Source Debit Account' : '借记付款账户'}</span>
                    <span className="text-white font-semibold font-mono">{pendingPayment.sourceAccountName}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 font-mono block uppercase">{lang === 'en-GB' ? 'Recipient Account' : '贷记收款人'}</span>
                    <span className="text-white font-semibold font-mono">{pendingPayment.recipientName}</span>
                  </div>
                  <div className="mt-2">
                    <span className="text-slate-500 font-mono block uppercase">{lang === 'en-GB' ? 'Transfer Amount' : '交易结算金额'}</span>
                    <span className="text-emerald-400 font-bold text-sm font-mono">
                      £{pendingPayment.amount.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
                    </span>
                  </div>
                  <div className="mt-2">
                    <span className="text-slate-500 font-mono block uppercase">{lang === 'en-GB' ? 'Transaction Fee' : '跨行网关手续费'}</span>
                    <span className="text-white font-semibold font-mono">£{pendingPayment.fee.toFixed(2)}</span>
                  </div>
                </div>

                <div>
                  <label className="block text-xs uppercase tracking-wider text-slate-400 font-semibold mb-1.5 font-mono">
                    {lang === 'en-GB' ? 'Enter Mobile OTP Code (Use 8888 for demo)' : '输入手机盾验证码 (演示用: 8888)'}
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      className="bg-[#071324] border border-[#1E3D66] rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-red-500 font-mono w-1/2"
                      value={otpCode}
                      onChange={e => setOtpCode(e.target.value)}
                      placeholder="8888"
                    />
                    <button
                      onClick={confirmTransferSca}
                      className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-4 py-2 rounded text-xs uppercase tracking-wider flex items-center gap-1.5"
                    >
                      <CheckCircle2 size={14} />
                      {lang === 'en-GB' ? 'Confirm Payment' : '授权支付并发布总账'}
                    </button>
                    <button
                      onClick={() => setPendingPayment(null)}
                      className="bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold px-4 py-2 rounded text-xs uppercase tracking-wider"
                    >
                      {lang === 'en-GB' ? 'Decline' : '拒绝'}
                    </button>
                  </div>
                  {otpError && <p className="text-xs text-red-400 mt-2 font-mono font-semibold">⚠️ {otpError}</p>}
                </div>
              </div>
            ) : (
              <form onSubmit={initiateTransfer} className="space-y-4">
                <h3 className="text-xs uppercase tracking-wider text-slate-400 font-bold flex items-center gap-1.5 font-mono">
                  <Send size={14} className="text-[#E60000]" />
                  {lang === 'en-GB' ? 'Execute Core Book Transfer' : '发起核心行内转账 (复式记账平衡)'}
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div>
                    <label className="block text-[10px] text-slate-400 font-mono uppercase mb-1">{lang === 'en-GB' ? 'Debit Account' : '付款卡扣款账户'}</label>
                    <select
                      value={selectedSourceAccount}
                      onChange={e => setSelectedSourceAccount(e.target.value)}
                      className="w-full bg-[#071324] border border-slate-700 rounded px-2.5 py-1.5 text-white font-mono"
                    >
                      {accounts.map(a => (
                        <option key={a.id} value={a.id}>
                          {lang === 'en-GB' ? a.nameEn : a.nameZh} (£{a.balances[a.currency]?.toLocaleString('en-GB') || 0})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] text-slate-400 font-mono uppercase mb-1">{lang === 'en-GB' ? 'Credit Beneficiary' : '收款存入账户'}</label>
                    <select
                      value={selectedTargetAccount}
                      onChange={e => setSelectedTargetAccount(e.target.value)}
                      className="w-full bg-[#071324] border border-slate-700 rounded px-2.5 py-1.5 text-white font-mono"
                    >
                      {accounts.map(a => (
                        <option key={a.id} value={a.id}>
                          {lang === 'en-GB' ? a.nameEn : a.nameZh} ({a.accountNumber})
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                  <div>
                    <label className="block text-[10px] text-slate-400 font-mono uppercase mb-1">{lang === 'en-GB' ? 'Transfer Amount' : '划转金额'}</label>
                    <input
                      type="number"
                      required
                      placeholder="500"
                      value={transferAmount}
                      onChange={e => setTransferAmount(e.target.value)}
                      className="w-full bg-[#071324] border border-slate-700 rounded px-3 py-1.5 text-white font-mono focus:outline-none focus:border-red-500"
                    />
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-[10px] text-slate-400 font-mono uppercase mb-1">{lang === 'en-GB' ? 'Payment Reference' : '转账备注明细'}</label>
                    <input
                      type="text"
                      placeholder="Salary, rent or invoice settlement"
                      value={transferReference}
                      onChange={e => setTransferReference(e.target.value)}
                      className="w-full bg-[#071324] border border-slate-700 rounded px-3 py-1.5 text-white text-xs focus:outline-none focus:border-red-500"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="bg-red-700 hover:bg-red-600 hover:scale-[1.01] transition-all text-white font-bold py-2 px-6 rounded text-xs uppercase tracking-widest flex items-center justify-center gap-1.5"
                  id="btn-transfer-submit"
                >
                  <Send size={12} />
                  {lang === 'en-GB' ? 'SCA Authorise & Post Ledger' : '提交核心安全校验转账'}
                </button>
              </form>
            )}

            {/* Dynamic ledger verification notification */}
            {paymentSuccessData && (
              <div className="mt-4 p-4 bg-emerald-950/20 border border-emerald-900/60 rounded-lg text-xs space-y-2">
                <div className="flex items-center gap-2 text-emerald-400 font-bold uppercase tracking-wider font-mono">
                  <CheckCircle2 size={16} />
                  <span>{lang === 'en-GB' ? 'IMMUTABLE GENERAL LEDGER BALANCED' : '总账双分录科目对冲平衡'}</span>
                </div>
                <p className="text-slate-400 text-[11px] font-mono">
                  Tx ID: {paymentSuccessData.txId} | Corr ID: {paymentSuccessData.correlationId}
                </p>
                <div className="border-t border-emerald-900/30 pt-2 text-[10px] space-y-1.5 font-mono text-slate-300">
                  {paymentSuccessData.postings.map((p: any, i: number) => (
                    <div key={i} className="flex justify-between">
                      <span>{p.type === 'DEBIT' ? '🔴 Dr' : '🟢 Cr'} Ledger Code {p.ledgerCode}: {p.narrative}</span>
                      <span className="font-bold text-white">
                        {p.type === 'DEBIT' ? '-' : '+'}{p.currency === 'GBP' ? '£' : '$'}{p.amount.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
                      </span>
                    </div>
                  ))}
                  <div className="border-t border-emerald-900/60 pt-1.5 flex justify-between text-emerald-400 font-bold">
                    <span>SUM(DEBITS) == SUM(CREDITS)</span>
                    <span>{lang === 'en-GB' ? 'TRUE (BALANCED)' : '科目对账平 0.00'}</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Historical transaction ledger */}
          <div className="bg-[#0A1625] border border-[#1E334D] rounded-xl p-5">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4">
              <h3 className="text-xs uppercase tracking-wider text-slate-400 font-bold flex items-center gap-1.5 font-mono">
                <FileSpreadsheet size={14} className="text-blue-400" />
                {lang === 'en-GB' ? 'Bilingual Ledger Audit History' : '不可篡改流水审计账簿'}
              </h3>

              {/* Filters */}
              <div className="flex gap-2 text-[10px] font-mono">
                <select
                  value={filterCurrency}
                  onChange={e => setFilterCurrency(e.target.value)}
                  className="bg-[#071324] border border-slate-700 rounded px-2 py-0.5 text-slate-300"
                >
                  <option value="ALL">Currency: All</option>
                  <option value="GBP">GBP</option>
                  <option value="USD">USD</option>
                </select>

                <select
                  value={filterCategory}
                  onChange={e => setFilterCategory(e.target.value)}
                  className="bg-[#071324] border border-slate-700 rounded px-2 py-0.5 text-slate-300"
                >
                  <option value="ALL">Category: All</option>
                  <option value="Food">Food</option>
                  <option value="Shopping">Shopping</option>
                  <option value="Income">Income</option>
                  <option value="Travel">Travel</option>
                </select>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs font-mono">
                <thead>
                  <tr className="border-b border-[#1E334D] text-slate-400">
                    <th className="py-2">{lang === 'en-GB' ? 'Date' : '日期'}</th>
                    <th className="py-2">{lang === 'en-GB' ? 'Counterparty' : '交易对手/说明'}</th>
                    <th className="py-2">{lang === 'en-GB' ? 'Category' : '账单类别'}</th>
                    <th className="py-2 text-right">{lang === 'en-GB' ? 'Amount' : '结算金额'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1E334D]/40 text-slate-300">
                  {filteredTransactions.map(t => (
                    <tr key={t.id} className="hover:bg-slate-800/20">
                      <td className="py-2.5 text-[10px] text-slate-500">{new Date(t.timestamp).toLocaleDateString()}</td>
                      <td className="py-2.5">
                        <div>
                          <p className="font-semibold text-slate-200">{t.counterparty}</p>
                          <p className="text-[9px] text-slate-500">Ref: {t.reference}</p>
                        </div>
                      </td>
                      <td className="py-2.5 text-[10px]">
                        <span className="bg-slate-800 px-2 py-0.5 rounded text-slate-400 font-medium">
                          {t.category}
                        </span>
                      </td>
                      <td className={`py-2.5 text-right font-bold ${t.amount < 0 ? 'text-slate-300' : 'text-emerald-400'}`}>
                        {t.amount < 0 ? '-' : '+'}{t.currency === 'GBP' ? '£' : '$'}{Math.abs(t.amount).toLocaleString('en-GB', { minimumFractionDigits: 2 })}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* Spender, Card controls, budget analytics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Card Management terminal */}
        <div className="bg-[#0A1625] border border-[#1E334D] rounded-xl p-5 space-y-4">
          <h3 className="text-xs uppercase tracking-wider text-slate-400 font-bold flex items-center gap-1.5 font-mono">
            <CreditCard size={14} className="text-[#E60000]" />
            {lang === 'en-GB' ? 'Card Security Management' : '银行卡安全与动态阻断器'}
          </h3>

          <div className="space-y-4">
            {cards.map(card => {
              const active = card.status === 'ACTIVE';
              return (
                <div key={card.id} className="bg-gradient-to-br from-[#0F2D54] to-[#0A1D35] border border-[#1E4370] rounded-xl p-4 shadow-md text-white relative overflow-hidden">
                  <div className="flex justify-between items-start z-10 relative">
                    <div>
                      <span className="text-[9px] uppercase tracking-widest font-mono text-slate-300 font-bold">
                        {lang === 'en-GB' ? `${card.cardType} Card` : `${card.cardType} 联名卡`}
                      </span>
                      <p className="text-sm font-semibold tracking-wide font-mono mt-1">{card.cardNumberMasked}</p>
                    </div>
                    <span className={`text-[9px] font-mono px-2 py-0.5 rounded uppercase font-bold ${
                      active ? 'bg-emerald-950 text-emerald-400 border border-emerald-900/60' : 'bg-red-950 text-red-400 border border-red-900/60'
                    }`}>
                      {lang === 'en-GB' ? card.status : active ? '正常激活' : '卡片锁死'}
                    </span>
                  </div>

                  <div className="mt-6 flex justify-between items-end z-10 relative">
                    <div>
                      <span className="text-[8px] uppercase tracking-widest text-slate-400 block font-mono">Holder</span>
                      <span className="text-xs font-medium tracking-wide">{card.cardHolderName}</span>
                    </div>
                    <button
                      onClick={() => toggleCardFreeze(card.id, card.status)}
                      className={`flex items-center gap-1 text-[10px] font-mono px-2.5 py-1 rounded transition-all font-bold uppercase ${
                        active
                          ? 'bg-red-700 hover:bg-red-600 text-white'
                          : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                      }`}
                    >
                      {active ? <Lock size={11} /> : <Unlock size={11} />}
                      {active ? (lang === 'en-GB' ? 'Freeze' : '锁卡') : (lang === 'en-GB' ? 'Unfreeze' : '解卡')}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Virtual merchant card spending terminal simulation */}
          <div className="border-t border-slate-700/40 pt-4 space-y-2.5">
            <span className="text-[10px] text-slate-400 font-mono uppercase block">
              {lang === 'en-GB' ? 'Virtual Merchant Spender POS Simulator' : '卡片交易拦截演练终端 (POS Simulator)'}
            </span>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <input
                type="text"
                className="bg-[#071324] border border-slate-700 rounded px-2.5 py-1 text-white text-[11px]"
                value={spendMerchantName}
                onChange={e => setSpendMerchantName(e.target.value)}
                placeholder="Merchant"
              />
              <input
                type="number"
                className="bg-[#071324] border border-slate-700 rounded px-2.5 py-1 text-white text-[11px] font-mono"
                value={spendAmount}
                onChange={e => setSpendAmount(e.target.value)}
                placeholder="Amount"
              />
            </div>
            <button
              onClick={simulateCardSpend}
              className="w-full bg-slate-800 hover:bg-slate-700 text-slate-100 font-bold py-1.5 rounded text-[10px] uppercase tracking-widest border border-slate-700/60"
            >
              🚀 {lang === 'en-GB' ? 'Simulate Card Swipe' : '模拟刷卡支付'}
            </button>
            {spendResult && (
              <div className={`p-2.5 rounded text-[10px] font-mono font-semibold border ${
                spendResult.success
                  ? 'bg-emerald-950/20 border-emerald-900/60 text-emerald-400'
                  : 'bg-red-950/20 border-red-900/60 text-red-400'
              }`}>
                {spendResult.msg}
              </div>
            )}
          </div>
        </div>

        {/* ECharts and Goals */}
        <div className="bg-[#0A1625] border border-[#1E334D] rounded-xl p-5 space-y-4">
          <h3 className="text-xs uppercase tracking-wider text-slate-400 font-bold flex items-center gap-1.5 font-mono">
            <PieIcon size={14} className="text-blue-400" />
            {lang === 'en-GB' ? 'Category Spending Analysis' : '消费类别占比分析'}
          </h3>
          <div ref={chartRef} className="w-full h-44" id="echarts-spending-donut"></div>

          {/* Goal section */}
          <div className="border-t border-slate-700/40 pt-4">
            <h4 className="text-[10px] text-slate-400 uppercase tracking-widest font-mono font-bold mb-3 flex items-center gap-1">
              <Target size={12} className="text-red-400" />
              {lang === 'en-GB' ? 'Savings Milestones Goals' : '心愿攒钱目标进度'}
            </h4>
            <div className="space-y-3">
              {goals.map(g => (
                <div key={g.id} className="text-xs space-y-1 bg-slate-900/40 p-2.5 rounded border border-slate-800">
                  <div className="flex justify-between font-semibold">
                    <span>{lang === 'en-GB' ? g.nameEn : g.nameZh}</span>
                    <span className="font-mono text-slate-400">
                      £{g.currentAmount} / £{g.targetAmount}
                    </span>
                  </div>
                  <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-[#E60000] h-full"
                      style={{ width: `${(g.currentAmount / g.targetAmount) * 100}%` }}
                    ></div>
                  </div>
                  <div className="flex justify-between items-center pt-1 text-[9px] font-mono text-slate-500">
                    <span>Target: {new Date(g.targetDate).toLocaleDateString()}</span>
                    <button
                      onClick={() => topUpGoal(g.id)}
                      className="text-[#E60000] hover:text-white font-bold hover:underline"
                    >
                      + Save £100
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Loan Amortization Engine Calculator */}
        <div className="bg-[#0A1625] border border-[#1E334D] rounded-xl p-5 space-y-4">
          <h3 className="text-xs uppercase tracking-wider text-slate-400 font-bold flex items-center gap-1.5 font-mono">
            <Calculator size={14} className="text-[#E60000]" />
            {lang === 'en-GB' ? 'Amortization Engine' : '信贷资产偿还本息精算器'}
          </h3>

          <div className="space-y-2.5 text-xs">
            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="text-[8px] text-slate-500 uppercase font-mono block">Principal</label>
                <input
                  type="number"
                  className="w-full bg-[#071324] border border-slate-700 rounded px-2 py-1 text-white font-mono mt-0.5"
                  value={calcPrincipal}
                  onChange={e => setCalcPrincipal(e.target.value)}
                />
              </div>
              <div>
                <label className="text-[8px] text-slate-500 uppercase font-mono block">Interest %</label>
                <input
                  type="number"
                  step="0.05"
                  className="w-full bg-[#071324] border border-slate-700 rounded px-2 py-1 text-white font-mono mt-0.5"
                  value={calcRate}
                  onChange={e => setCalcRate(e.target.value)}
                />
              </div>
              <div>
                <label className="text-[8px] text-slate-500 uppercase font-mono block">Term (Mo)</label>
                <input
                  type="number"
                  className="w-full bg-[#071324] border border-slate-700 rounded px-2 py-1 text-white font-mono mt-0.5"
                  value={calcTerm}
                  onChange={e => setCalcTerm(e.target.value)}
                />
              </div>
            </div>

            {calcSchedule.length > 0 && (
              <div className="bg-[#071324] border border-[#1E334D] rounded p-2.5 font-mono text-[10px] space-y-2 max-h-[190px] overflow-y-auto">
                <div className="font-bold border-b border-slate-700/60 pb-1.5 flex justify-between text-slate-400">
                  <span>{lang === 'en-GB' ? 'Month schedule' : '期数还款明细'}</span>
                  <span>{lang === 'en-GB' ? 'Principal + Interest' : '本金+利息'}</span>
                </div>
                {calcSchedule.map(row => (
                  <div key={row.month} className="flex justify-between text-slate-300">
                    <span>Mo {row.month}: {lang === 'en-GB' ? 'Bal' : '期初'} £{row.openingBalance.toLocaleString('en-GB')}</span>
                    <span className="text-slate-100 font-bold">
                      £{row.payment} (P: {row.principal} | I: {row.interest})
                    </span>
                  </div>
                ))}
                <div className="text-[9px] text-slate-500 text-center pt-2 italic">
                  {lang === 'en-GB' ? '* Showing first 12 periods of schedule.' : '* 仅展示还款计划前 12 期。'}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
