/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { systemEngine } from '../services/bankingEngine';
import { AmlCase, AuditLog } from '../types';
import {
  ShieldAlert,
  Search,
  Check,
  Slash,
  Eye,
  Activity,
  UserCheck,
  Layers,
  Lock
} from 'lucide-react';

interface ComplianceDashboardProps {
  lang: 'en-GB' | 'zh-CN';
}

export default function ComplianceDashboard({ lang }: ComplianceDashboardProps) {
  const [amlCases, setAmlCases] = useState<AmlCase[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [selectedCase, setSelectedCase] = useState<AmlCase | null>(null);

  useEffect(() => {
    setAmlCases([...systemEngine.amlCases]);
    setAuditLogs([...systemEngine.auditLogs]);
  }, []);

  const refreshCompliance = () => {
    setAmlCases([...systemEngine.amlCases]);
    setAuditLogs([...systemEngine.auditLogs]);
    if (selectedCase) {
      const refreshedSelected = systemEngine.amlCases.find(c => c.id === selectedCase.id);
      if (refreshedSelected) setSelectedCase(refreshedSelected);
    }
  };

  const handleEscalateCase = (id: string) => {
    const amlCase = systemEngine.amlCases.find(c => c.id === id);
    if (amlCase) {
      const oldStatus = amlCase.status;
      amlCase.status = 'ESCALATED';
      amlCase.auditTrail.unshift({
        timestamp: new Date().toISOString(),
        actionEn: 'Escalated to High Risk Action Group',
        actionZh: '上报送审至高级别金融犯罪特别行动小组',
        actor: 'Compliance Specialist (Demo)'
      });

      systemEngine.writeAuditLog(
        'Compliance Specialist',
        'COMPLIANCE_OFFICER',
        'ESCALATE_AML_CASE',
        'AmlCase',
        oldStatus,
        'ESCALATED',
        'corr-aml-' + Math.floor(10000 + Math.random() * 90000)
      );

      refreshCompliance();
      alert(lang === 'en-GB' ? 'Case escalated to Senior Risk Action Group.' : '案件状态更新：已加急上报至高级风控治理小组。');
    }
  };

  const handleCloseCase = (id: string) => {
    const amlCase = systemEngine.amlCases.find(c => c.id === id);
    if (amlCase) {
      const oldStatus = amlCase.status;
      amlCase.status = 'CLOSED';
      amlCase.auditTrail.unshift({
        timestamp: new Date().toISOString(),
        actionEn: 'Case audited and closed under regular compliance metrics',
        actionZh: '合规排查完成：属于良性误报，予以正常关案核销',
        actor: 'Compliance Specialist (Demo)'
      });

      systemEngine.writeAuditLog(
        'Compliance Specialist',
        'COMPLIANCE_OFFICER',
        'CLOSE_AML_CASE',
        'AmlCase',
        oldStatus,
        'CLOSED',
        'corr-aml-' + Math.floor(10000 + Math.random() * 90000)
      );

      refreshCompliance();
      alert(lang === 'en-GB' ? 'Case closed successfully.' : '案件排查关案。');
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto py-2" id="compliance-control-center">
      {/* Metrics Banner */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <div className="bg-[#0E223D] border border-[#1E3B5F] p-4 rounded-xl text-white">
          <span className="text-[10px] text-slate-400 font-mono font-bold block">{lang === 'en-GB' ? 'Open AML Cases' : '待审查 AML 案件'}</span>
          <p className="text-xl font-bold font-mono text-white mt-1">{amlCases.length} Active</p>
          <span className="text-[9px] text-[#22C55E] font-mono mt-1 block">Live Triage: On</span>
        </div>
        <div className="bg-[#0E223D] border border-[#1E3B5F] p-4 rounded-xl text-white">
          <span className="text-[10px] text-slate-400 font-mono font-bold block">{lang === 'en-GB' ? 'KYC Reviews' : '待审 KYC 准入件'}</span>
          <p className="text-xl font-bold font-mono text-white mt-1">12 Pending</p>
          <span className="text-[9px] text-slate-400 font-mono mt-1 block">SLA Target: 4h</span>
        </div>
        <div className="bg-[#0E223D] border border-[#1E3B5F] p-4 rounded-xl text-white">
          <span className="text-[10px] text-slate-400 font-mono font-bold block">{lang === 'en-GB' ? 'Fraud Alerts' : '实时欺诈事件'}</span>
          <p className="text-xl font-bold font-mono text-red-400 mt-1">0 Flagged</p>
          <span className="text-[9px] text-emerald-400 font-mono mt-1 block">Auto-Block: Active</span>
        </div>
        <div className="bg-[#0E223D] border border-[#1E3B5F] p-4 rounded-xl text-white">
          <span className="text-[10px] text-slate-400 font-mono font-bold block">{lang === 'en-GB' ? 'Sanctions Alerts' : '制裁红名单监测'}</span>
          <p className="text-xl font-bold font-mono text-white mt-1">0 Alerts</p>
          <span className="text-[9px] text-slate-400 font-mono mt-1 block">List Checked: v14.2</span>
        </div>
        <div className="bg-[#0E223D] border border-[#1E3B5F] p-4 rounded-xl text-white">
          <span className="text-[10px] text-slate-400 font-mono font-bold block">{lang === 'en-GB' ? 'High Risk Customers' : '高风险等级客户'}</span>
          <p className="text-xl font-bold font-mono text-white mt-1">3 Customers</p>
          <span className="text-[9px] text-red-400 font-mono mt-1 block">Audits: Quarterly</span>
        </div>
      </div>

      {/* Main Grid: AML Cases & Detail Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-[#0A1625] border border-[#1E334D] p-5 rounded-xl">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono mb-4 flex items-center gap-1.5">
            <ShieldAlert size={14} className="text-[#E60000]" />
            {lang === 'en-GB' ? 'Active Anti-Money Laundering Cases' : '行内活跃合规审查个案中心 (AML Cases)'}
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs font-mono">
              <thead>
                <tr className="border-b border-[#1E334D] text-slate-400 font-bold">
                  <th className="py-2">Case ID</th>
                  <th className="py-2">Party Customer</th>
                  <th className="py-2">Scenario Highlight</th>
                  <th className="py-2 text-center">Risk</th>
                  <th className="py-2 text-center">Status</th>
                  <th className="py-2 text-right">View</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1E334D]/40 text-slate-300">
                {amlCases.map(c => (
                  <tr key={c.id} className="hover:bg-slate-800/10">
                    <td className="py-3 font-bold text-red-500">{c.id}</td>
                    <td className="py-3 font-sans font-semibold text-slate-200">
                      {lang === 'en-GB' ? c.customerNameEn : c.customerNameZh}
                    </td>
                    <td className="py-3">{lang === 'en-GB' ? c.alertTypeEn : c.alertTypeZh}</td>
                    <td className="py-3 text-center">
                      <span className="bg-red-950/40 text-red-400 border border-red-900/60 font-bold px-1.5 py-0.2 rounded text-[10px]">
                        {c.riskLevel}
                      </span>
                    </td>
                    <td className="py-3 text-center">
                      <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded uppercase ${
                        c.status === 'CLOSED' ? 'bg-slate-800 text-slate-400' :
                        c.status === 'ESCALATED' ? 'bg-purple-950 text-purple-400 border border-purple-900/60' :
                        'bg-amber-950 text-amber-400 border border-amber-900/60'
                      }`}>
                        {c.status}
                      </span>
                    </td>
                    <td className="py-3 text-right">
                      <button
                        onClick={() => setSelectedCase(c)}
                        className="text-blue-400 hover:text-white p-1"
                      >
                        <Eye size={14} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Case detail view */}
        <div className="lg:col-span-1 bg-[#0A1625] border border-[#1E334D] p-5 rounded-xl space-y-4 text-xs font-sans">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono flex items-center gap-1.5 border-b border-[#1E334D] pb-2">
            <Activity size={14} className="text-[#E60000]" />
            {lang === 'en-GB' ? 'Auditor Audit Case Terminal' : '洗钱/欺诈个案精细审计台'}
          </h3>

          {selectedCase ? (
            <div className="space-y-4">
              <div>
                <span className="text-[10px] text-slate-500 font-mono block uppercase">Case Identification</span>
                <p className="text-white font-bold font-mono text-sm">{selectedCase.id}</p>
              </div>

              <div>
                <span className="text-[10px] text-slate-500 font-mono block uppercase">Alert Evidence Narrative</span>
                <p className="text-slate-300 mt-1 leading-relaxed text-xs italic">
                  "{lang === 'en-GB' ? selectedCase.evidenceEn : selectedCase.evidenceZh}"
                </p>
              </div>

              {selectedCase.status !== 'CLOSED' && (
                <div className="flex gap-2 border-t border-slate-700/40 pt-3">
                  <button
                    onClick={() => handleEscalateCase(selectedCase.id)}
                    className="flex-1 bg-purple-700 hover:bg-purple-600 text-white font-bold py-1.5 rounded text-[10px] uppercase tracking-wider"
                  >
                    🚀 {lang === 'en-GB' ? 'Escalate' : '合规加急'}
                  </button>
                  <button
                    onClick={() => handleCloseCase(selectedCase.id)}
                    className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-1.5 rounded text-[10px] uppercase tracking-wider"
                  >
                    ✓ {lang === 'en-GB' ? 'Close Case' : '予以结案'}
                  </button>
                </div>
              )}

              <div className="border-t border-slate-700/40 pt-3 space-y-2">
                <span className="text-[10px] text-slate-500 font-mono block uppercase">Immutable Chronological Logs</span>
                <div className="space-y-2 text-[10px] font-mono text-slate-400 max-h-[140px] overflow-y-auto">
                  {selectedCase.auditTrail.map((evt, idx) => (
                    <div key={idx} className="bg-slate-900/60 p-2 rounded border border-slate-800">
                      <p className="text-white font-semibold">{lang === 'en-GB' ? evt.actionEn : evt.actionZh}</p>
                      <div className="flex justify-between text-[9px] text-slate-500 mt-1">
                        <span>By: {evt.actor}</span>
                        <span>{new Date(evt.timestamp).toLocaleTimeString()}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <p className="text-slate-500 text-center italic py-16">
              {lang === 'en-GB' ? 'Select an active AML alert to audit.' : '请在左侧列表中点击具体反洗钱案件以加载审计面板。'}
            </p>
          )}
        </div>
      </div>

      {/* Immutable General System-Wide Audit Log Viewer */}
      <div className="bg-[#0A1625] border border-[#1E334D] p-5 rounded-xl">
        <div className="flex items-center justify-between border-b border-[#1E334D] pb-3 mb-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono flex items-center gap-1.5">
            <Lock size={14} className="text-blue-400" />
            {lang === 'en-GB' ? 'Immutable Operational Audit Trail Ledger' : '全局系统级不可篡改安全与审计记录总账'}
          </h3>
          <span className="text-[9px] bg-emerald-950 text-emerald-400 border border-emerald-900/60 font-mono px-2 py-0.5 rounded font-bold uppercase">
            {lang === 'en-GB' ? 'SECURE BLOCKCHAIN-METRIC COMPLIANT' : '安全可溯：完全符合国际合规'}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs font-mono">
            <thead>
              <tr className="border-b border-[#1E334D] text-slate-400 text-[11px] font-bold">
                <th className="py-2">Correlation ID</th>
                <th className="py-2">Operator (Actor)</th>
                <th className="py-2">Action / Request</th>
                <th className="py-2">Resource Entity</th>
                <th className="py-2">Pre-State</th>
                <th className="py-2 text-right">Post-State (Redacted)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1E334D]/30 text-slate-300">
              {auditLogs.map((log, i) => (
                <tr key={i} className="hover:bg-slate-800/10 text-[11px]">
                  <td className="py-2.5 text-blue-400 font-bold">{log.correlationId}</td>
                  <td className="py-2.5 font-sans">
                    <span className="text-white font-semibold">{log.actor}</span>
                    <span className="block text-[9px] text-slate-500 font-mono font-bold uppercase mt-0.5">{log.role}</span>
                  </td>
                  <td className="py-2.5">
                    <span className="bg-slate-900 px-1.5 py-0.5 rounded border border-slate-800 uppercase text-slate-300 text-[9px]">
                      {log.action}
                    </span>
                  </td>
                  <td className="py-2.5 text-slate-400">{log.resource}</td>
                  <td className="py-2.5 text-red-400 text-[10px] max-w-[120px] truncate">{log.oldState}</td>
                  <td className="py-2.5 text-emerald-400 text-[10px] text-right font-bold font-mono">
                    {/* GDPR Redaction checks */}
                    {log.action.includes('CARD') || log.action.includes('PASS') ? '•••• •••• ••••' : log.newState}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
