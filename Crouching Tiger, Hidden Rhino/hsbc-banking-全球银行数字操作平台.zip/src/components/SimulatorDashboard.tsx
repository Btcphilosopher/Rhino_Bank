/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { systemEngine } from '../services/bankingEngine';
import { SystemHealth } from '../types';
import {
  Zap,
  Activity,
  AlertOctagon,
  RefreshCw,
  Database,
  BarChart2,
  TrendingUp,
  Cpu
} from 'lucide-react';

interface SimulatorDashboardProps {
  lang: 'en-GB' | 'zh-CN';
  stressMode: string;
  onScenarioChange: (mode: any) => void;
}

export default function SimulatorDashboard({ lang, stressMode, onScenarioChange }: SimulatorDashboardProps) {
  const [health, setHealth] = useState<SystemHealth>(systemEngine.systemHealth);

  // What-if state
  const [surgePercent, setSurgePercent] = useState('40');
  const [whatIfResults, setWhatIfResults] = useState<any | null>(null);

  useEffect(() => {
    setHealth({ ...systemEngine.systemHealth });
  }, [stressMode]);

  const handleInjectScenario = (scenario: typeof systemEngine.stressMode) => {
    systemEngine.injectFailure(scenario);
    onScenarioChange(scenario);
    setHealth({ ...systemEngine.systemHealth });
    alert(lang === 'en-GB' ? `Stress scenario '${scenario}' injected successfully.` : `压力场景 / 故障注入成功: '${scenario}'。`);
  };

  const calculateWhatIfSurge = () => {
    const pct = parseFloat(surgePercent);
    if (isNaN(pct) || pct <= 0) return;

    // Numerical projections mimicking real core queues
    const baselineApiThreads = 120;
    const baselineKafkaBytes = 4.2; // MB/s
    const baselineFraudTriggers = 8; // per hour

    const calculatedApiThreads = Math.floor(baselineApiThreads * (1 + pct / 100));
    const calculatedKafkaBytes = Number((baselineKafkaBytes * (1 + pct / 100)).toFixed(1));
    const calculatedFraudTriggers = Math.floor(baselineFraudTriggers * (1 + (pct * 1.5) / 100));

    setWhatIfResults({
      pct,
      before: {
        threads: baselineApiThreads,
        kafka: `${baselineKafkaBytes} MB/s`,
        fraud: `${baselineFraudTriggers} alarms/hr`,
        settleTime: '850ms'
      },
      after: {
        threads: calculatedApiThreads,
        kafka: `${calculatedKafkaBytes} MB/s`,
        fraud: `${calculatedFraudTriggers} alarms/hr`,
        settleTime: pct > 80 ? '2400ms (Saturated)' : `${Math.floor(850 * (1 + pct / 200))}ms`
      }
    });
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto py-2" id="stress-simulator-dashboard">
      {/* Simulation Warning Banner */}
      <div className="bg-[#0B1E36] border border-[#1E3B5F] p-4 rounded-xl text-white flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-sm font-bold uppercase tracking-wider font-mono flex items-center gap-2">
            <Cpu size={16} className="text-[#E60000]" />
            {lang === 'en-GB' ? 'Core Banking Stress Simulator Engine' : '核心网关压力测试与容灾注入引擎'}
          </h2>
          <p className="text-[10px] text-slate-400 mt-1">
            {lang === 'en-GB'
              ? 'Inject operational failures to evaluate circuit breakers, ledger idempotency, and disaster recovery SLA bounds.'
              : '在此模拟高负载、基础设施中断及网络欺诈突水。排查平台熔断器、幂等锁、及冷备热切等应急预案时效。'}
          </p>
        </div>
        <button
          onClick={() => handleInjectScenario('NORMAL')}
          className="bg-emerald-600 hover:bg-emerald-500 hover:scale-[1.01] transition-all text-white font-bold px-4 py-2 rounded text-xs uppercase tracking-widest font-mono flex items-center gap-1.5 shadow"
        >
          <RefreshCw size={12} />
          {lang === 'en-GB' ? 'Reset Operating State' : '系统一键复位正常'}
        </button>
      </div>

      {/* Grid: Scenario Injectors vs Failure Injections */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Scenarios */}
        <div className="bg-[#0A1625] border border-[#1E334D] p-5 rounded-xl space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono flex items-center gap-1.5">
            <Zap size={14} className="text-blue-400" />
            {lang === 'en-GB' ? 'Macro Stress Scenario Injections' : '业务级系统压力测试场景注入'}
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <button
              onClick={() => handleInjectScenario('LIQUIDITY_STRESS')}
              className={`p-4 rounded-lg border text-left space-y-1 transition-all ${
                stressMode === 'LIQUIDITY_STRESS'
                  ? 'bg-red-950/40 border-red-500 text-white'
                  : 'bg-[#0E223D] border-[#1E3B5F] hover:border-slate-500 text-slate-200'
              }`}
            >
              <h4 className="text-xs font-bold uppercase tracking-wide">{lang === 'en-GB' ? 'Liquidity Run Stress' : '爆发式储蓄提现流失 (Liquidity Run)'}</h4>
              <p className="text-[10px] text-slate-400">{lang === 'en-GB' ? 'Simulates severe deposit withdrawals.' : '仿真储蓄备付头寸骤降。'}</p>
            </button>

            <button
              onClick={() => handleInjectScenario('FX_VOLATILITY')}
              className={`p-4 rounded-lg border text-left space-y-1 transition-all ${
                stressMode === 'FX_VOLATILITY'
                  ? 'bg-red-950/40 border-red-500 text-white'
                  : 'bg-[#0E223D] border-[#1E3B5F] hover:border-slate-500 text-slate-200'
              }`}
            >
              <h4 className="text-xs font-bold uppercase tracking-wide">{lang === 'en-GB' ? 'FX Market Volatility' : '汇率剧烈宽幅震荡 (FX Volatility)'}</h4>
              <p className="text-[10px] text-slate-400">{lang === 'en-GB' ? 'Simulates rapid market rate shifts.' : '测试多币种汇率滑点与清算。'}</p>
            </button>

            <button
              onClick={() => handleInjectScenario('FRAUD_SURGE')}
              className={`p-4 rounded-lg border text-left space-y-1 transition-all ${
                stressMode === 'FRAUD_SURGE'
                  ? 'bg-red-950/40 border-red-500 text-white'
                  : 'bg-[#0E223D] border-[#1E3B5F] hover:border-slate-500 text-slate-200'
              }`}
            >
              <h4 className="text-xs font-bold uppercase tracking-wide">{lang === 'en-GB' ? 'Fraud Surge Campaign' : '撞库/洗钱欺诈爆发 (Fraud Surge)'}</h4>
              <p className="text-[10px] text-slate-400">{lang === 'en-GB' ? 'Spike in impossible travel and structural alerts.' : '触发出行轨迹越迁及分账警报。'}</p>
            </button>

            <button
              onClick={() => handleInjectScenario('CYBER_INCIDENT')}
              className={`p-4 rounded-lg border text-left space-y-1 transition-all ${
                stressMode === 'CYBER_INCIDENT'
                  ? 'bg-red-950/40 border-red-500 text-white'
                  : 'bg-[#0E223D] border-[#1E3B5F] hover:border-slate-500 text-slate-200'
              }`}
            >
              <h4 className="text-xs font-bold uppercase tracking-wide">{lang === 'en-GB' ? 'Cyber Security Incident' : '分布式安全攻击流量注入'}</h4>
              <p className="text-[10px] text-slate-400">{lang === 'en-GB' ? 'Degrades payment processors.' : '拦截并阻断高危欺诈网关请求。'}</p>
            </button>
          </div>
        </div>

        {/* Failures */}
        <div className="bg-[#0A1625] border border-[#1E334D] p-5 rounded-xl space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono flex items-center gap-1.5">
            <AlertOctagon size={14} className="text-[#E60000]" />
            {lang === 'en-GB' ? 'Infrastructure Failure Injections' : '基础设施级单点故障注入 (容灾应急演练)'}
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <button
              onClick={() => handleInjectScenario('FAIL_REDIS')}
              className={`p-3 rounded-lg border text-left text-xs font-mono font-bold ${
                stressMode === 'FAIL_REDIS' ? 'bg-red-950 text-red-400 border-red-500' : 'bg-[#0E223D] border-[#1E3B5F] text-slate-300'
              }`}
            >
              🛑 Disable Redis Cluster
            </button>
            <button
              onClick={() => handleInjectScenario('FAIL_DB')}
              className={`p-3 rounded-lg border text-left text-xs font-mono font-bold ${
                stressMode === 'FAIL_DB' ? 'bg-red-950 text-red-400 border-red-500' : 'bg-[#0E223D] border-[#1E3B5F] text-slate-300'
              }`}
            >
              🛑 Degrade Database
            </button>
            <button
              onClick={() => handleInjectScenario('FAIL_KAFKA')}
              className={`p-3 rounded-lg border text-left text-xs font-mono font-bold ${
                stressMode === 'FAIL_KAFKA' ? 'bg-red-950 text-red-400 border-red-500' : 'bg-[#0E223D] border-[#1E3B5F] text-slate-300'
              }`}
            >
              🛑 Disconnect Kafka
            </button>
          </div>

          <div className="bg-[#071324] border border-[#1E3D66] rounded p-4 text-xs font-mono text-slate-400 space-y-2">
            <p className="font-bold text-white uppercase tracking-wider">{lang === 'en-GB' ? 'Simulated Recovery Bounds' : '应急容灾指标监控'}</p>
            <p>• Redis Outage: Fallback to primary database disk query read throughput (API Latency increases).</p>
            <p>• Database Degrade: Active pooling thread throttled (Database Latency increases).</p>
            <p>• Kafka Disconnect: Messages buffered inside local memory queue (SLA Lag accumulated).</p>
          </div>
        </div>
      </div>

      {/* What-If Analysis Engine */}
      <div className="bg-[#0A1625] border border-[#1E334D] p-5 rounded-xl space-y-4">
        <div>
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono flex items-center gap-1.5">
            <BarChart2 size={14} className="text-emerald-400" />
            {lang === 'en-GB' ? 'Quantitative What-If Flow Calculator' : '定量级 What-If 事务流速推演'}
          </h3>
          <p className="text-[10px] text-slate-500 font-mono mt-0.5">
            {lang === 'en-GB' ? 'Evaluate system-wide queue backlogs prior to introducing large payroll batches.' : '在大规模工资扣缴、双十一清算前，定量演算吞吐饱和临界点。'}
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-end gap-4">
          <div className="w-full sm:w-[320px] text-xs">
            <label className="text-[10px] text-slate-400 font-mono uppercase">Simulate surge payment volume %</label>
            <div className="flex gap-2 items-center mt-1">
              <input
                type="number"
                value={surgePercent}
                onChange={e => setSurgePercent(e.target.value)}
                className="bg-[#071324] border border-slate-700 rounded px-3 py-1.5 text-white font-mono flex-1 focus:outline-none focus:border-emerald-500"
                placeholder="40"
              />
              <span className="text-slate-400 font-bold">%</span>
            </div>
          </div>

          <button
            onClick={calculateWhatIfSurge}
            className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-6 py-2 rounded text-xs uppercase tracking-wider font-mono flex items-center gap-1.5 shadow"
          >
            <TrendingUp size={14} />
            {lang === 'en-GB' ? 'Project Load' : '定量演算推敲'}
          </button>
        </div>

        {whatIfResults && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 border-t border-[#1E3D66]/40 pt-4 text-xs font-mono">
            {/* Before */}
            <div className="bg-[#071324] border border-slate-800 rounded p-4 space-y-2">
              <span className="text-slate-500 uppercase">Baseline SLA (Under Standard Load)</span>
              <p className="text-white">API Core Threads: <span className="font-bold">{whatIfResults.before.threads} active</span></p>
              <p className="text-white">Kafka Event IO: <span className="font-bold">{whatIfResults.before.kafka}</span></p>
              <p className="text-white">Fraud Check Alerts: <span className="font-bold">{whatIfResults.before.fraud}</span></p>
              <p className="text-white">Ledger Settlement Latency: <span className="font-bold text-emerald-400">{whatIfResults.before.settleTime}</span></p>
            </div>

            {/* After */}
            <div className="bg-gradient-to-br from-[#0F233A] to-[#071324] border border-emerald-900/60 rounded p-4 space-y-2">
              <span className="text-emerald-400 uppercase font-bold">Projected SLA (+{whatIfResults.pct}% Surge Load)</span>
              <p className="text-white">API Core Threads: <span className="font-bold text-emerald-400">{whatIfResults.after.threads} active</span></p>
              <p className="text-white">Kafka Event IO: <span className="font-bold text-emerald-400">{whatIfResults.after.kafka}</span></p>
              <p className="text-white">Fraud Check Alerts: <span className="font-bold text-red-400 font-bold">{whatIfResults.after.fraud}</span></p>
              <p className="text-white">Ledger Settlement Latency: <span className="font-bold text-emerald-400">{whatIfResults.after.settleTime}</span></p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
