/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { systemEngine } from '../services/bankingEngine';
import { Landmark, TrendingUp, DollarSign, Wallet, ShieldCheck, HelpCircle } from 'lucide-react';

interface TreasuryDashboardProps {
  lang: 'en-GB' | 'zh-CN';
}

export default function TreasuryDashboard({ lang }: TreasuryDashboardProps) {
  // State for demo simulation figures
  const [secPortfolio, setSecPortfolio] = useState<any[]>([]);

  useEffect(() => {
    setSecPortfolio([
      { assetClass: 'US Treasuries AAA 10Y', code: 'US-T10Y', currency: 'USD', cost: 1250000000, marketValue: 1285400000, pAndL: 35400000, type: 'Bonds' },
      { assetClass: 'UK Gilts Sovereign', code: 'UK-GILT', currency: 'GBP', cost: 850000000, marketValue: 842100000, pAndL: -7900000, type: 'Bonds' },
      { assetClass: 'HSBC Sterling Liquid Fund', code: 'MMF-GBP', currency: 'GBP', cost: 2400000000, marketValue: 2405800000, pAndL: 5800000, type: 'Money Market' },
      { assetClass: 'Apple Inc. Common Stock', code: 'AAPL', currency: 'USD', cost: 42000000, marketValue: 56800000, pAndL: 14800000, type: 'Stocks' }
    ]);
  }, []);

  return (
    <div className="space-y-6 max-w-7xl mx-auto py-2" id="treasury-dashboard">
      {/* Simulation Warning Banner */}
      <div className="bg-[#0B1E36] border border-blue-900/60 text-slate-300 p-2.5 rounded-lg text-xs font-mono flex items-center justify-between">
        <span className="flex items-center gap-1.5 uppercase font-bold text-[#0A84FF]">
          <span className="h-2 w-2 bg-blue-500 rounded-full animate-pulse"></span>
          {lang === 'en-GB' ? 'SIMULATED DATA MODEL ACTIVE' : '模拟资金流动与流动性预测活跃'}
        </span>
        <span className="text-[10px] bg-slate-800 text-slate-400 px-1.5 py-0.2 rounded">
          {lang === 'en-GB' ? 'NOT CONNECTED TO LIVE SWIFT/BOE FEED' : '非实时英格兰银行结算通道连接'}
        </span>
      </div>

      {/* Global Liquidity Centers */}
      <div className="bg-[#0A1625] border border-[#1E334D] p-5 rounded-xl space-y-4">
        <div>
          <h2 className="text-sm font-bold uppercase tracking-wider text-white font-mono flex items-center gap-2">
            <Landmark size={16} className="text-[#E60000]" />
            {lang === 'en-GB' ? 'GLOBAL LIQUIDITY PORTFOLIO' : '全球集团流动性备付金池'}
          </h2>
          <p className="text-[10px] text-slate-400 mt-0.5">
            {lang === 'en-GB' ? 'Aggregated real-time cash ledger reserves across international hubs.' : '集团全球主清算行及金丝雀总部备付储备库汇总明细。'}
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-2">
          <div className="bg-[#0E223D] border border-[#1E3B5F] p-4 rounded-xl">
            <span className="text-[10px] text-slate-400 font-mono block">GBP CENTRAL BANK</span>
            <p className="text-xl font-bold font-mono text-white mt-1">£5.82B</p>
            <span className="text-[9px] text-emerald-400 font-mono mt-1 block">Yield: 5.25%</span>
          </div>

          <div className="bg-[#0E223D] border border-[#1E3B5F] p-4 rounded-xl">
            <span className="text-[10px] text-slate-400 font-mono block">USD FED REVERSE REPO</span>
            <p className="text-xl font-bold font-mono text-white mt-1">$4.20B</p>
            <span className="text-[9px] text-emerald-400 font-mono mt-1 block">Yield: 5.33%</span>
          </div>

          <div className="bg-[#0E223D] border border-[#1E3B5F] p-4 rounded-xl">
            <span className="text-[10px] text-slate-400 font-mono block">EUR TARGET2 OVERNIGHT</span>
            <p className="text-xl font-bold font-mono text-white mt-1">€2.10B</p>
            <span className="text-[9px] text-emerald-400 font-mono mt-1 block">Yield: 3.75%</span>
          </div>

          <div className="bg-[#0E223D] border border-[#1E3B5F] p-4 rounded-xl">
            <span className="text-[10px] text-slate-400 font-mono block">CNY PBOC RESERVES</span>
            <p className="text-xl font-bold font-mono text-white mt-1">¥3.82B</p>
            <span className="text-[9px] text-emerald-400 font-mono mt-1 block">Yield: 2.10%</span>
          </div>
        </div>
      </div>

      {/* Cash Flow Forecast (5 points) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 bg-[#0A1625] border border-[#1E334D] p-5 rounded-xl space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono flex items-center gap-1.5">
            <TrendingUp size={14} className="text-[#E60000]" />
            {lang === 'en-GB' ? '5-Point Cash Flow Forecast' : '五维远期现金流预测'}
          </h3>

          <div className="space-y-3 font-mono text-xs">
            <div className="flex justify-between items-center bg-slate-900/60 p-2.5 rounded border border-slate-800">
              <span className="font-bold text-white">T+0 (Today)</span>
              <span className="text-emerald-400 font-bold">+£1.24B Net</span>
            </div>
            <div className="flex justify-between items-center bg-slate-900/60 p-2.5 rounded border border-slate-800">
              <span className="font-bold text-white">T+1 (Tomorrow)</span>
              <span className="text-emerald-400 font-bold">+£842M Net</span>
            </div>
            <div className="flex justify-between items-center bg-slate-900/60 p-2.5 rounded border border-slate-800">
              <span className="font-bold text-white">T+7 (7 Days)</span>
              <span className="text-red-400 font-bold">-£412M Net</span>
            </div>
            <div className="flex justify-between items-center bg-slate-900/60 p-2.5 rounded border border-slate-800">
              <span className="font-bold text-white">T+30 (30 Days)</span>
              <span className="text-emerald-400 font-bold">+£3.24B Net</span>
            </div>
            <div className="flex justify-between items-center bg-slate-900/60 p-2.5 rounded border border-slate-800">
              <span className="font-bold text-white">T+90 (90 Days)</span>
              <span className="text-emerald-400 font-bold">+£5.80B Net</span>
            </div>
          </div>
        </div>

        {/* Securities Portfolio */}
        <div className="lg:col-span-2 bg-[#0A1625] border border-[#1E334D] p-5 rounded-xl space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono flex items-center gap-1.5">
            <Wallet size={14} className="text-blue-400" />
            {lang === 'en-GB' ? 'Simulated Securities & Debt Portfolio' : '证券及附息债券投资头寸 (Simulated Portfolio)'}
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs font-mono">
              <thead>
                <tr className="border-b border-[#1E334D] text-slate-400">
                  <th className="py-2">Asset Class Name</th>
                  <th className="py-2 text-center">Currency</th>
                  <th className="py-2 text-right">Cost Basis</th>
                  <th className="py-2 text-right">Market Value</th>
                  <th className="py-2 text-right">Unrealized P&L</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1E334D]/40 text-slate-300">
                {secPortfolio.map((p, i) => (
                  <tr key={i} className="hover:bg-slate-800/10">
                    <td className="py-3 font-sans font-semibold text-slate-200">
                      <div>
                        {p.assetClass}
                        <span className="block text-[9px] font-mono font-medium text-slate-500 uppercase mt-0.5">{p.type} • {p.code}</span>
                      </div>
                    </td>
                    <td className="py-3 text-center text-slate-400 font-bold">{p.currency}</td>
                    <td className="py-3 text-right">£{(p.cost / 1000000).toFixed(1)}M</td>
                    <td className="py-3 text-right">£{(p.marketValue / 1000000).toFixed(1)}M</td>
                    <td className={`py-3 text-right font-bold ${p.pAndL >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                      {p.pAndL >= 0 ? '+' : ''}£{(p.pAndL / 1000000).toFixed(1)}M
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
