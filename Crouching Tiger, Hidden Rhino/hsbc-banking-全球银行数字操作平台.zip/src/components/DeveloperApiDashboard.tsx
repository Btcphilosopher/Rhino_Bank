/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { systemEngine } from '../services/bankingEngine';
import { Terminal, Send, Check, Code, Play, RefreshCw, Eye } from 'lucide-react';

interface DeveloperApiDashboardProps {
  lang: 'en-GB' | 'zh-CN';
}

export default function DeveloperApiDashboard({ lang }: DeveloperApiDashboardProps) {
  const [endpoints, setEndpoints] = useState<any[]>([]);
  const [selectedEndpoint, setSelectedEndpoint] = useState<any>(null);
  const [apiRequestBody, setApiRequestBody] = useState('');
  const [apiResponse, setApiResponse] = useState<any | null>(null);
  const [apiStatus, setApiStatus] = useState<number | null>(null);
  const [apiHeaders, setApiHeaders] = useState<any>({});
  const [apiLoading, setApiLoading] = useState(false);

  useEffect(() => {
    const list = [
      {
        method: 'POST',
        path: '/api/v1/payments/transfer',
        descriptionEn: 'Submit a standard book transfer payment to immutable double-entry ledger.',
        descriptionZh: '向行内双分录不可篡改总账提交一笔资金划转。',
        body: JSON.stringify({
          sourceAccountId: 'acc-01',
          targetAccountId: 'acc-02',
          amount: 1500.00,
          currency: 'GBP',
          reference: 'API Settle Invoice #401',
          idempotencyKey: 'idem-api-' + Math.floor(10000 + Math.random() * 90000)
        }, null, 2)
      },
      {
        method: 'GET',
        path: '/api/v1/accounts/balances',
        descriptionEn: 'Query core account balances ledger indexes.',
        descriptionZh: '查询核心结算账户当前余额和科目分类索引。',
        body: JSON.stringify({
          partyId: 'PTY-84209'
        }, null, 2)
      },
      {
        method: 'POST',
        path: '/api/v1/fx/spot-rate',
        descriptionEn: 'Fetch spot market rate and quote margins.',
        descriptionZh: '获取外汇远期及即期外币兑换实时汇点加价率。',
        body: JSON.stringify({
          pair: 'GBP/CNY',
          amount: 1000.00
        }, null, 2)
      }
    ];

    setEndpoints(list);
    setSelectedEndpoint(list[0]);
    setApiRequestBody(list[0].body);
  }, []);

  const handleEndpointSelect = (ep: any) => {
    setSelectedEndpoint(ep);
    setApiRequestBody(ep.body);
    setApiResponse(null);
    setApiStatus(null);
  };

  const handleTriggerApi = () => {
    setApiLoading(true);
    setApiResponse(null);

    setTimeout(() => {
      let bodyData;
      try {
        bodyData = JSON.parse(apiRequestBody);
      } catch (err) {
        setApiStatus(400);
        setApiResponse({ error: 'INVALID_JSON', msg: 'The request body payload is not valid JSON.' });
        setApiHeaders({
          'Content-Type': 'application/json',
          'X-Core-Trace-Id': 'err-trace-' + Math.floor(100000 + Math.random() * 900000)
        });
        setApiLoading(false);
        return;
      }

      const traceId = 'trace-' + Math.floor(100000 + Math.random() * 900000);
      const hostTiming = Math.floor(5 + Math.random() * 25);

      if (selectedEndpoint.path.includes('/payments/transfer')) {
        // Execute real transfer on engine
        const sourceAcc = systemEngine.accounts.find(a => a.id === bodyData.sourceAccountId);
        const targetAcc = systemEngine.accounts.find(a => a.id === bodyData.targetAccountId);

        if (!sourceAcc || !targetAcc) {
          setApiStatus(404);
          setApiResponse({ error: 'ACCOUNT_NOT_FOUND', msg: 'Source or Target Account ID is invalid.' });
        } else if ((sourceAcc.balances[sourceAcc.currency] || 0) < bodyData.amount) {
          setApiStatus(422);
          setApiResponse({ error: 'INSUFFICIENT_FUNDS', msg: 'Source deposit account has insufficient funds to clear ledger transfer.' });
        } else {
          // Process on core
          const result = systemEngine.executeTransfer(
            bodyData.sourceAccountId,
            bodyData.targetAccountId,
            bodyData.amount,
            bodyData.reference || 'API Transfer',
            bodyData.idempotencyKey || ('idem-' + Math.random())
          );
          if (result.success) {
            setApiStatus(201);
            setApiResponse({
              status: 'COMPLETED',
              transactionId: result.transactionId,
              correlationId: result.correlationId,
              journalEntriesPosted: 2,
              sumDebitsCreditsBalance: 0.00
            });
          } else {
            setApiStatus(400);
            setApiResponse({ error: 'LEDGER_REJECTED', msg: result.error });
          }
        }
      } else if (selectedEndpoint.path.includes('/balances')) {
        const matchingAccounts = systemEngine.accounts.filter(a => a.id.startsWith('acc-0'));
        if (matchingAccounts.length === 0) {
          setApiStatus(404);
          setApiResponse({ error: 'PARTY_NOT_FOUND', msg: 'Specified Party Identifier has no live records.' });
        } else {
          setApiStatus(200);
          setApiResponse(matchingAccounts.map(a => ({
            id: a.id,
            accountType: a.type,
            accountNumber: a.accountNumber,
            balances: a.balances,
            interestRate: a.interestRate
          })));
        }
      } else {
        // FX
        const pair = bodyData.pair || 'GBP/CNY';
        const rateObj = systemEngine.getExchangeRate(pair);
        const amount = bodyData.amount || 1000;
        setApiStatus(200);
        setApiResponse({
          pair,
          baseCurrency: pair.split('/')[0],
          targetCurrency: pair.split('/')[1],
          midMarketRate: rateObj.rate,
          customerRateWithSpread: rateObj.customerRate,
          receiveAmountEstimated: amount * rateObj.customerRate
        });
      }

      setApiHeaders({
        'Content-Type': 'application/json',
        'Cache-Control': 'no-store, max-age=0',
        'X-Core-Trace-Id': traceId,
        'X-Idempotency-Key': bodyData.idempotencyKey || 'N/A',
        'Server-Timing': `db;dur=${hostTiming};desc="Core Postgres Settle"`
      });
      setApiLoading(false);
    }, 600);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto py-2" id="developer-api-dashboard">
      {/* Metrics Banner */}
      <div className="bg-[#0B1E36] border border-[#1E3B5F] p-4 rounded-xl text-white">
        <div className="flex items-center gap-2">
          <Code size={18} className="text-emerald-400" />
          <h2 className="text-sm font-bold uppercase tracking-wider font-mono">
            {lang === 'en-GB' ? 'Core API Gateway Sandbox' : 'HSBC 核心开放 API 开发者网关'}
          </h2>
        </div>
        <p className="text-xs text-slate-400 mt-1">
          {lang === 'en-GB'
            ? 'Fully functional sandbox. All API POST requests trigger immutable Double-Entry Ledger changes inside the simulation session.'
            : '完全开放的接口调试。所有的 API POST 划转请求均会实时驱动底层金融总账的双分录记账与资产池转移。'}
        </p>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Side: Endpoint selection */}
        <div className="lg:col-span-1 bg-[#0A1625] border border-[#1E334D] p-5 rounded-xl space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono">
            {lang === 'en-GB' ? 'Core Endpoints Catalog' : '可调用核心业务接口'}
          </h3>

          <div className="space-y-2.5">
            {endpoints.map((ep, idx) => {
              const active = selectedEndpoint?.path === ep.path;
              return (
                <button
                  key={idx}
                  onClick={() => handleEndpointSelect(ep)}
                  className={`w-full p-3.5 rounded-lg border text-left space-y-2 transition-all transform ${
                    active
                      ? 'bg-slate-900 border-red-500 text-white shadow-md'
                      : 'bg-[#0E223D]/60 border-[#1E3B5F] hover:border-slate-500 text-slate-300'
                  }`}
                >
                  <div className="flex gap-2 items-center">
                    <span className={`text-[9px] font-mono px-2 py-0.5 rounded font-bold uppercase ${
                      ep.method === 'POST' ? 'bg-emerald-950 text-emerald-400 border border-emerald-900/60' : 'bg-blue-950 text-blue-400 border border-blue-900/60'
                    }`}>
                      {ep.method}
                    </span>
                    <span className="font-mono text-xs font-bold">{ep.path}</span>
                  </div>
                  <p className="text-[10px] text-slate-400 leading-relaxed">
                    {lang === 'en-GB' ? ep.descriptionEn : ep.descriptionZh}
                  </p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Side: Interactive JSON editor & Live HTTP Response console */}
        <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Request Pay Payload */}
          <div className="bg-[#0A1625] border border-[#1E334D] p-5 rounded-xl space-y-3.5 flex flex-col">
            <div className="flex justify-between items-center">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono flex items-center gap-1.5">
                <Terminal size={14} className="text-blue-400" />
                {lang === 'en-GB' ? 'Request Payload JSON' : '请求报文 JSON 载荷'}
              </h3>
              <span className="text-[9px] text-slate-500 font-mono font-bold uppercase">application/json</span>
            </div>

            <textarea
              className="w-full flex-1 bg-slate-950 border border-slate-800 rounded p-3 font-mono text-[11px] text-emerald-400 focus:outline-none focus:border-red-500 h-[280px]"
              value={apiRequestBody}
              onChange={e => setApiRequestBody(e.target.value)}
            ></textarea>

            <button
              onClick={handleTriggerApi}
              disabled={apiLoading}
              className="bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 disabled:text-slate-500 text-white font-bold py-2.5 rounded text-xs uppercase tracking-wider font-mono flex items-center justify-center gap-2 shadow"
            >
              {apiLoading ? <RefreshCw size={12} className="animate-spin" /> : <Play size={12} fill="currentColor" />}
              {lang === 'en-GB' ? 'Execute API HTTP Call' : '触发开放网关调试'}
            </button>
          </div>

          {/* Response payload console */}
          <div className="bg-[#0A1625] border border-[#1E334D] p-5 rounded-xl space-y-3 flex flex-col h-full">
            <div className="flex justify-between items-center border-b border-slate-800 pb-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono">
                {lang === 'en-GB' ? 'HTTP Response Output' : '网关返回响应结果'}
              </h3>
              {apiStatus && (
                <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                  apiStatus < 300 ? 'bg-emerald-950 text-emerald-400 border border-emerald-900/60' : 'bg-red-950 text-red-400 border border-red-900/60'
                }`}>
                  HTTP {apiStatus}
                </span>
              )}
            </div>

            {apiResponse ? (
              <div className="flex-1 flex flex-col space-y-3">
                {/* Headers */}
                <div className="bg-slate-900/60 p-2.5 rounded border border-slate-800/80 font-mono text-[9px] text-slate-400 space-y-1">
                  <p className="font-bold text-slate-500 uppercase pb-1 border-b border-slate-800">{lang === 'en-GB' ? 'Response Headers' : '网关返回响应头'}</p>
                  {Object.entries(apiHeaders).map(([key, val]: [string, any]) => (
                    <div key={key} className="flex justify-between">
                      <span className="text-slate-500">{key}:</span>
                      <span className="text-slate-300 font-bold">{val}</span>
                    </div>
                  ))}
                </div>

                {/* Body */}
                <pre className="flex-1 bg-slate-950 border border-slate-800 rounded p-3 font-mono text-[10px] text-slate-200 overflow-auto max-h-[190px]">
                  {JSON.stringify(apiResponse, null, 2)}
                </pre>
              </div>
            ) : (
              <div className="flex-1 flex flex-col justify-center items-center text-center p-8 border border-dashed border-[#1E3B5F] rounded-lg">
                <Terminal size={24} className="text-[#1E3D66] mb-3" />
                <p className="text-[10px] text-slate-500 font-mono uppercase tracking-wider leading-relaxed">
                  {lang === 'en-GB' ? 'Execute API request to view active JSON response output and headers.' : '请点击左下角调试按钮，网关将实时返回完整的资产及对账应答头。'}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
