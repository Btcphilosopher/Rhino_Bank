/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { systemEngine } from '../services/bankingEngine';
import { Branch, Atm, RealTimeEvent } from '../types';
import {
  Map,
  Activity,
  Terminal,
  Server,
  RefreshCw,
  TrendingUp,
  Clock,
  MapPin,
  CheckCircle,
  Network
} from 'lucide-react';

interface OperationsDashboardProps {
  lang: 'en-GB' | 'zh-CN';
}

export default function OperationsDashboard({ lang }: OperationsDashboardProps) {
  const [branches, setBranches] = useState<Branch[]>([]);
  const [atms, setAtms] = useState<Atm[]>([]);
  const [events, setEvents] = useState<RealTimeEvent[]>([]);
  const [mapSelectedPoint, setMapSelectedPoint] = useState<string | null>(null);

  useEffect(() => {
    setBranches([...systemEngine.branches]);
    setAtms([...systemEngine.atms]);
    setEvents([...systemEngine.realTimeEvents]);

    // Live Event Simulator Ticker
    const interval = setInterval(() => {
      // Procedurally generate a live background banking heartbeat event
      const topics: RealTimeEvent['topic'][] = [
        'transaction.events',
        'card.events',
        'atm.events',
        'fx.events',
        'payment.events'
      ];
      const selectedTopic = topics[Math.floor(Math.random() * topics.length)];

      let payload = {};
      let key = 'SYS-' + Math.floor(1000 + Math.random() * 9000);

      if (selectedTopic === 'transaction.events') {
        payload = { event: 'AtmCardSpent', amount: Math.floor(10 + Math.random() * 200), currency: 'GBP', location: 'London ATM-42' };
      } else if (selectedTopic === 'fx.events') {
        payload = { event: 'FxTickUpdate', pair: 'GBP/CNY', rate: (9.21 + Math.random() * 0.01).toFixed(4) };
      } else if (selectedTopic === 'payment.events') {
        payload = { event: 'BulkPayrollBatchRunning', employeeVouchers: Math.floor(50 + Math.random() * 500) };
      } else {
        payload = { event: 'AtmTelemetryPing', status: 'ONLINE', remainingCashLevelPercent: Math.floor(60 + Math.random() * 40) };
      }

      systemEngine.addEvent(selectedTopic, key, payload);
      setEvents([...systemEngine.realTimeEvents]);

      // Randomly adjust wait queues to simulate live branches
      systemEngine.branches.forEach(b => {
        const delta = Math.random() > 0.5 ? 1 : -1;
        b.customersWaiting = Math.max(0, b.customersWaiting + delta);
        b.averageWaitMinutes = Number((Math.max(2, b.averageWaitMinutes + (delta * 0.2))).toFixed(1));
      });
      setBranches([...systemEngine.branches]);
    }, 3500);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-6 max-w-7xl mx-auto py-2" id="global-operations-center">
      {/* Top Telemetry Overlay */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-[#0A1625] border border-[#1E334D] p-4 rounded-xl text-white flex items-center gap-3">
          <Activity className="text-emerald-400 shrink-0" size={20} />
          <div>
            <span className="text-[10px] text-slate-400 font-mono font-bold block uppercase">{lang === 'en-GB' ? 'Core Event Stream' : '事件总线吞吐量 (Core Kafka)'}</span>
            <p className="text-sm font-bold font-mono text-emerald-400 mt-0.5">38,409 msg/sec</p>
          </div>
        </div>

        <div className="bg-[#0A1625] border border-[#1E334D] p-4 rounded-xl text-white flex items-center gap-3">
          <Server className="text-blue-400 shrink-0" size={20} />
          <div>
            <span className="text-[10px] text-slate-400 font-mono font-bold block uppercase">{lang === 'en-GB' ? 'Microservices Health' : '分布式微服务池集群'}</span>
            <p className="text-sm font-bold font-mono text-white mt-0.5">24 Nodes Stable</p>
          </div>
        </div>

        <div className="bg-[#0A1625] border border-[#1E334D] p-4 rounded-xl text-white flex items-center gap-3">
          <Network className="text-red-400 shrink-0" size={20} />
          <div>
            <span className="text-[10px] text-slate-400 font-mono font-bold block uppercase">{lang === 'en-GB' ? 'Global Core Sync' : '跨海多活可用区容灾'}</span>
            <p className="text-sm font-bold font-mono text-white mt-0.5">London-HK-SGP Active</p>
          </div>
        </div>
      </div>

      {/* Visual Global Operational Map */}
      <div className="bg-[#0A1625] border border-[#1E334D] p-5 rounded-xl space-y-4">
        <div>
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono flex items-center gap-1.5">
            <Map size={14} className="text-[#E60000]" />
            {lang === 'en-GB' ? 'Digital Twin Global Map Operations' : '全球业务分布与资金流向数字孪生 (Interactive Twin)'}
          </h3>
          <p className="text-[10px] text-slate-500 font-mono mt-0.5">
            {lang === 'en-GB' ? 'Simulated operational telemetry overlay. Select node pins to query real-time cash.' : '实时系统流速监测。点击地理坐标引脚查询网点备付资金与排队情况。'}
          </p>
        </div>

        {/* Global Map Representation */}
        <div className="bg-slate-950 rounded-xl relative p-6 border border-slate-900 overflow-hidden flex flex-col justify-center items-center" style={{ minHeight: '280px' }}>
          {/* Custom SVG World Grid representing global bank nodes */}
          <svg className="absolute inset-0 w-full h-full text-slate-900/60 opacity-30 select-none" fill="currentColor">
            <pattern id="world-pattern" width="16" height="16" patternUnits="userSpaceOnUse">
              <circle cx="2" cy="2" r="1"></circle>
            </pattern>
            <rect width="100%" height="100%" fill="url(#world-pattern)"></rect>
          </svg>

          {/* Interactive Bouncing Vectors representing transactional payment links */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-4/5 h-2/3 border border-slate-800/40 rounded-full animate-ping opacity-10"></div>
          </div>

          <div className="z-10 relative flex flex-wrap justify-center gap-6 md:gap-12 w-full max-w-4xl text-center">
            {branches.map(br => {
              const selected = mapSelectedPoint === br.id;
              return (
                <button
                  key={br.id}
                  onClick={() => setMapSelectedPoint(selected ? null : br.id)}
                  className={`flex flex-col items-center bg-[#0D2440]/80 hover:bg-[#0D2440] border p-3 rounded-lg w-[145px] transition-all transform ${
                    selected ? 'border-[#E60000] scale-105 shadow-xl' : 'border-[#1E3E63]'
                  }`}
                >
                  <MapPin size={16} className={selected ? 'text-[#E60000] animate-bounce' : 'text-blue-400'} />
                  <span className="font-bold text-[10px] text-slate-200 mt-1">{br.city}</span>
                  <span className="text-[8px] text-slate-500 font-mono mt-0.5">{br.id}</span>
                  <div className="mt-2 border-t border-slate-800 pt-1.5 w-full text-[9px] font-mono text-slate-400 text-left space-y-0.5">
                    <p className="flex justify-between">
                      <span>Cash:</span>
                      <span className="text-white font-bold">£{(br.cashPosition / 1000000).toFixed(0)}M</span>
                    </p>
                    <p className="flex justify-between">
                      <span>Queue:</span>
                      <span className="text-emerald-400 font-bold">{br.customersWaiting} wait</span>
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Branch Detail Queues & ATM status */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* ATM Network panel */}
        <div className="lg:col-span-1 bg-[#0A1625] border border-[#1E334D] p-5 rounded-xl space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono flex items-center gap-1.5">
            <Server size={14} className="text-[#E60000]" />
            {lang === 'en-GB' ? 'ATM Network Digital Twin' : 'ATM 全球自助网络监测 (Digital Twin)'}
          </h3>

          <div className="space-y-3 font-mono text-xs max-h-[300px] overflow-y-auto">
            {atms.map(atm => (
              <div key={atm.id} className="bg-slate-900/60 border border-slate-800 rounded p-2.5 space-y-1">
                <div className="flex justify-between font-bold">
                  <span className="text-slate-300 font-sans">{lang === 'en-GB' ? atm.locationEn : atm.locationZh}</span>
                  <span className={`text-[9px] px-1.5 py-0.1 rounded ${
                    atm.status === 'ONLINE' ? 'bg-emerald-950 text-emerald-400' :
                    atm.status === 'LOW_CASH' ? 'bg-amber-950 text-amber-400' :
                    'bg-red-950 text-red-400'
                  }`}>
                    {atm.status}
                  </span>
                </div>
                <div className="flex justify-between text-[9px] text-slate-500 pt-1">
                  <span>ID: {atm.id}</span>
                  <span>Cash Capacity: {atm.cashLevel}%</span>
                </div>
                <div className="w-full bg-slate-800 h-1 rounded-full overflow-hidden mt-1">
                  <div
                    className={`h-full ${atm.cashLevel < 20 ? 'bg-amber-500' : 'bg-emerald-500'}`}
                    style={{ width: `${atm.cashLevel}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Real-Time Live event stream (Kafka Terminal Ticker) */}
        <div className="lg:col-span-2 bg-[#0A1625] border border-[#1E334D] p-5 rounded-xl space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono flex items-center gap-1.5">
              <Terminal size={14} className="text-emerald-400" />
              {lang === 'en-GB' ? 'Real-Time Bank Event Stream' : '实时核心事件总线通道 (Core Kafka Stream)'}
            </h3>
            <span className="text-[10px] text-slate-400 font-mono flex items-center gap-1">
              <RefreshCw size={10} className="animate-spin text-emerald-500" />
              STREAM_READY
            </span>
          </div>

          {/* Scrolling Terminal output */}
          <div className="bg-[#030912] border border-slate-800 rounded-lg p-3 h-[250px] overflow-y-auto font-mono text-[10px] space-y-2 select-none text-emerald-500 scrollbar-thin">
            {events.map((evt, idx) => (
              <div key={idx} className="flex gap-2 items-start hover:bg-slate-900/40 p-1 rounded">
                <span className="text-slate-500 whitespace-nowrap">[{new Date(evt.timestamp).toLocaleTimeString()}]</span>
                <span className="text-blue-400 font-bold whitespace-nowrap">{evt.topic}</span>
                <span className="text-slate-400 whitespace-nowrap font-bold">Key: {evt.key}</span>
                <span className="text-slate-300 break-all">{evt.payload}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
