/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  Account,
  ExchangeRate,
  Customer,
  LedgerAccount,
  JournalEntry,
  Transaction,
  PaymentRequest,
  Card,
  Loan,
  AmortizationScheduleRow,
  SavingsGoal,
  SpendingBudget,
  MakerCheckerPayment,
  RiskMetric,
  FraudAlert,
  AmlCase,
  OpenBankingConsent,
  Branch,
  Atm,
  SystemHealth,
  AuditLog,
  RealTimeEvent,
  Posting
} from '../types';

// Deterministic generator helper for realistic simulated counts
export const SIMULATED_STATS = {
  totalCustomers: 50000,
  totalAccounts: 100000,
  totalBranches: 1000,
  totalAtms: 5000,
  totalTransactions: 500000,
  totalCards: 20000,
  totalLoans: 5000,
  totalCorporateCustomers: 1000
};

export class BankingEngine {
  // State
  public accounts: Account[] = [];
  public customers: Customer[] = [];
  public ledgerAccounts: LedgerAccount[] = [];
  public journalEntries: JournalEntry[] = [];
  public transactions: Transaction[] = [];
  public payments: PaymentRequest[] = [];
  public cards: Card[] = [];
  public loans: Loan[] = [];
  public savingsGoals: SavingsGoal[] = [];
  public spendingBudgets: SpendingBudget[] = [];
  public makerCheckerPayments: MakerCheckerPayment[] = [];
  public riskMetrics: RiskMetric[] = [];
  public fraudAlerts: FraudAlert[] = [];
  public amlCases: AmlCase[] = [];
  public openBankingConsents: OpenBankingConsent[] = [];
  public branches: Branch[] = [];
  public atms: Atm[] = [];
  public auditLogs: AuditLog[] = [];
  public systemHealth: SystemHealth;
  public realTimeEvents: RealTimeEvent[] = [];
  public stressMode: 'NORMAL' | 'LIQUIDITY_STRESS' | 'FX_VOLATILITY' | 'FRAUD_SURGE' | 'CYBER_INCIDENT' | 'FAIL_REDIS' | 'FAIL_DB' | 'FAIL_KAFKA' = 'NORMAL';

  constructor() {
    this.systemHealth = {
      apiLatencyMs: 42,
      databaseLatencyMs: 4,
      kafkaLag: 12,
      redisStatus: 'ONLINE',
      paymentProcessorStatus: 'ONLINE',
      kafkaStatus: 'ONLINE',
      dbStatus: 'ONLINE'
    };
    this.initializeData();
  }

  private initializeData() {
    // 1. Initial Ledger Accounts (Double-Entry Core)
    this.ledgerAccounts = [
      { code: '1001', nameEn: 'Bank Vault Cash', nameZh: '银行现金库库款', type: 'ASSETS', balance: 125000000 },
      { code: '1100', nameEn: 'Due from Central Bank', nameZh: '央行法定存款准备金', type: 'ASSETS', balance: 350000000 },
      { code: '1200', nameEn: 'Retail Loans Outstanding', nameZh: '零售贷款余额', type: 'ASSETS', balance: 85000000 },
      { code: '2001', nameEn: 'Retail Customer Deposits (GBP)', nameZh: '零售客户存款-英镑', type: 'LIABILITIES', balance: 128420.55 },
      { code: '2002', nameEn: 'Retail Customer Deposits (USD)', nameZh: '零售客户存款-美元', type: 'LIABILITIES', balance: 32500 },
      { code: '2003', nameEn: 'Retail Customer Deposits (Savings)', nameZh: '零售客户存款-储蓄账户', type: 'LIABILITIES', balance: 85000 },
      { code: '2100', nameEn: 'Corporate Operating Deposits', nameZh: '企业活期存款账户', type: 'LIABILITIES', balance: 84200000 },
      { code: '3001', nameEn: 'Share Capital', nameZh: '股本', type: 'EQUITY', balance: 400000000 },
      { code: '4001', nameEn: 'Interest Income from Loans', nameZh: '贷款利息收入', type: 'INCOME', balance: 4200000 },
      { code: '4100', nameEn: 'Fee & Commission Income', nameZh: '手续费及佣金收入', type: 'INCOME', balance: 125000 },
      { code: '5001', nameEn: 'Interest Expense on Deposits', nameZh: '存款利息支出', type: 'EXPENSES', balance: 850000 }
    ];

    // 2. Customers
    this.customers = [
      {
        id: 'cust-01',
        partyNumber: 'PTY-84209',
        nameEn: 'Alexander Mercer',
        nameZh: '亚历山大·默瑟',
        email: 'a.mercer@aurelia.com',
        riskClassification: 'LOW',
        kycStatus: 'VERIFIED',
        kycVerificationDate: '2026-01-15',
        country: 'United Kingdom'
      },
      {
        id: 'corp-01',
        partyNumber: 'PTY-99021',
        nameEn: 'Horizon Global Trading Ltd',
        nameZh: '地平线全球贸易有限公司',
        email: 'treasury@horizon-trading.com',
        riskClassification: 'MEDIUM',
        kycStatus: 'VERIFIED',
        kycVerificationDate: '2025-11-20',
        country: 'Hong Kong'
      }
    ];

    // 3. Customer Accounts
    this.accounts = [
      {
        id: 'acc-01',
        accountNumber: '40-12-84 82194012',
        nameEn: 'Everyday Current Account',
        nameZh: '日常往来活期账户',
        type: 'Current',
        currency: 'GBP',
        balances: { 'GBP': 12820.20 },
        availableBalance: 12820.20,
        interestRate: 0.0,
        openDate: '2023-04-10',
        status: 'ACTIVE'
      },
      {
        id: 'acc-02',
        accountNumber: '40-12-84 99201482',
        nameEn: 'Premium High-Yield Savings',
        nameZh: '尊享高息储蓄账户',
        type: 'Savings',
        currency: 'GBP',
        balances: { 'GBP': 85000.00 },
        availableBalance: 85000.00,
        interestRate: 4.25,
        openDate: '2023-08-15',
        status: 'ACTIVE'
      },
      {
        id: 'acc-03',
        accountNumber: '40-12-84 10029302',
        nameEn: 'Global USD Wallet',
        nameZh: '美元多币种钱包账户',
        type: 'Multi-Currency',
        currency: 'USD',
        balances: { 'USD': 32500.00, 'EUR': 1500, 'CNY': 5000 },
        availableBalance: 32500.00,
        interestRate: 1.5,
        openDate: '2024-01-10',
        status: 'ACTIVE'
      },
      // Corporate Accounts
      {
        id: 'acc-corp-01',
        accountNumber: '80-50-22 93847291',
        nameEn: 'Corporate Operating Account',
        nameZh: '企业日常经营主账户',
        type: 'Business',
        currency: 'GBP',
        balances: { 'GBP': 84200000 },
        availableBalance: 84200000,
        interestRate: 0.5,
        openDate: '2021-02-18',
        status: 'ACTIVE'
      }
    ];

    // 4. Initial Transactions (Matches requested list)
    this.transactions = [
      {
        id: 'tx-001',
        accountId: 'acc-01',
        timestamp: '2026-09-17T08:30:00-07:00',
        currency: 'GBP',
        amount: -54.20,
        type: 'CARD_SPEND',
        counterparty: 'Tesco Superstore',
        reference: 'Card Purchase 4821',
        status: 'COMPLETED',
        category: 'Food',
        correlationId: 'corr-tx-tesco'
      },
      {
        id: 'tx-002',
        accountId: 'acc-01',
        timestamp: '2026-09-16T12:00:00-07:00',
        currency: 'GBP',
        amount: 4820.00,
        type: 'SALARY',
        counterparty: 'Aurelia Systems Ltd',
        reference: 'MONTHLY SALARY REF-940',
        status: 'COMPLETED',
        category: 'Income',
        correlationId: 'corr-tx-salary'
      },
      {
        id: 'tx-003',
        accountId: 'acc-01',
        timestamp: '2026-09-15T15:45:00-07:00',
        currency: 'GBP',
        amount: -82.40,
        type: 'CARD_SPEND',
        counterparty: 'Amazon.co.uk',
        reference: 'Order AMZ-920148',
        status: 'COMPLETED',
        category: 'Shopping',
        correlationId: 'corr-tx-amazon'
      },
      {
        id: 'tx-004',
        accountId: 'acc-01',
        timestamp: '2026-09-14T09:15:00-07:00',
        currency: 'GBP',
        amount: -2000.00,
        type: 'TRANSFER',
        counterparty: 'Sofia Kowalski (PL89...)',
        reference: 'Family Support Transfer',
        status: 'COMPLETED',
        category: 'Travel',
        correlationId: 'corr-tx-intl'
      }
    ];

    // 5. Cards (Debit + Credit)
    this.cards = [
      {
        id: 'card-01',
        accountId: 'acc-01',
        cardNumberMasked: '•••• •••• •••• 4821',
        cardHolderName: 'Alexander Mercer',
        expiryDate: '12/29',
        cvvMasked: '•••',
        cardType: 'Debit',
        status: 'ACTIVE',
        spendingLimitDaily: 5000,
        spendingLimitSpent: 136.60,
        merchantControls: { online: true, contactless: true, international: true, atm: true },
        travelMode: false
      },
      {
        id: 'card-02',
        accountId: 'acc-01',
        cardNumberMasked: '•••• •••• •••• 9912',
        cardHolderName: 'Alexander Mercer',
        expiryDate: '06/30',
        cvvMasked: '•••',
        cardType: 'Credit',
        status: 'ACTIVE',
        creditLimit: 10000,
        availableCredit: 7420,
        statementBalance: 2580,
        spendingLimitDaily: 10000,
        spendingLimitSpent: 2580,
        merchantControls: { online: true, contactless: true, international: true, atm: true },
        travelMode: false
      }
    ];

    // 6. Loans
    this.loans = [
      {
        id: 'loan-01',
        type: 'Mortgage',
        principal: 350000,
        outstandingBalance: 312500,
        interestRate: 3.75,
        termMonths: 300,
        startDate: '2023-01-01',
        monthlyPayment: 1802.14,
        propertyValue: 500000,
        deposit: 150000,
        loanToValue: 70.0
      },
      {
        id: 'loan-02',
        type: 'Personal',
        principal: 25000,
        outstandingBalance: 18400,
        interestRate: 6.9,
        termMonths: 60,
        startDate: '2024-05-10',
        monthlyPayment: 493.86
      }
    ];

    // 7. Savings Goals
    this.savingsGoals = [
      { id: 'goal-01', nameEn: 'Luxury Japan Tour', nameZh: '日本奢华探索之旅', targetAmount: 5000, currentAmount: 2100, targetDate: '2027-04-01' },
      { id: 'goal-02', nameEn: 'Tesla Down Payment', nameZh: '特斯拉首付款攒钱计划', targetAmount: 15000, currentAmount: 8400, targetDate: '2027-10-15' }
    ];

    // 8. Spending Budgets
    this.spendingBudgets = [
      { category: 'Food', budgetAmount: 500, usedAmount: 328 },
      { category: 'Shopping', budgetAmount: 400, usedAmount: 182 },
      { category: 'Entertainment', budgetAmount: 300, usedAmount: 90 },
      { category: 'Travel', budgetAmount: 1000, usedAmount: 640 }
    ];

    // 9. Compliance KYC & Cases
    this.riskMetrics = [
      { metric: 'Credit Risk LTV', value: '70.0%', threshold: '80.0%', status: 'LOW', explanationEn: 'LTV is within conservative lending thresholds.', explanationZh: '贷值比在保守信贷区间内。', timestamp: '2026-09-17T06:00:00Z' },
      { metric: 'DTI (Debt-to-Income)', value: '28.4%', threshold: '40.0%', status: 'LOW', explanationEn: 'Affordability ratios suggest healthy repayment capacity.', explanationZh: '债务收入比处于健康还款能力区间。', timestamp: '2026-09-17T06:00:00Z' },
      { metric: 'Capital Adequacy Ratio (CET1)', value: '18.4%', threshold: '12.5%', status: 'LOW', explanationEn: 'Tier 1 Capital is robust and conforms to Basel III rules.', explanationZh: '核心一级资本充足率非常强劲，符合巴塞尔协议III要求。', timestamp: '2026-09-17T06:00:00Z' }
    ];

    this.amlCases = [
      {
        id: 'aml-case-102',
        customerId: 'cust-01',
        customerNameEn: 'Alexander Mercer',
        customerNameZh: '亚历山大·默瑟',
        alertTypeEn: 'Potential Structuring Alert',
        alertTypeZh: '潜在分拆交易拆分规避监控警报',
        riskLevel: 'MEDIUM',
        evidenceEn: 'Multiple cash transfers summing up to £9,850 over 24 hours under reporting threshold.',
        evidenceZh: '24小时内发生多笔累计9,850英镑的资金划转，逼近监管申报线。',
        status: 'ANALYST_REVIEW',
        analyst: 'Officer Sarah Chen',
        auditTrail: [
          { timestamp: '2026-09-16T14:30:00Z', actionEn: 'Automated Sanction alert triggered', actionZh: '系统自动触发生理或拆分警报', actor: 'Compliance AI Engine' },
          { timestamp: '2026-09-16T15:00:00Z', actionEn: 'Assigned to senior analyst', actionZh: '分配给高级合规分析师审核', actor: 'Compliance Desk Admin' }
        ]
      }
    ];

    // 10. Maker Checker initial payments
    this.makerCheckerPayments = [
      {
        id: 'mc-01',
        makerName: 'Finance Specialist Liu',
        createdAt: '2026-09-17T09:00:00Z',
        type: 'Supplier',
        amount: 1250000,
        currency: 'GBP',
        recipientName: 'Acme Materials Corp',
        recipientAccount: 'GB90BARC20104820938472',
        status: 'PENDING_APPROVAL',
        correlationId: 'mc-corr-001'
      },
      {
        id: 'mc-02',
        makerName: 'Payroll Clerk Smith',
        createdAt: '2026-09-16T16:30:00Z',
        approvedAt: '2026-09-17T08:00:00Z',
        checkerName: 'VP Finance Watson',
        type: 'Payroll',
        amount: 820000,
        currency: 'GBP',
        recipientName: 'Staff Payroll Sept 2026',
        recipientAccount: 'GB88HSBC40128490218492',
        status: 'APPROVED',
        correlationId: 'mc-corr-002'
      }
    ];

    // 11. Digital Twins Branches & ATMs
    this.branches = [
      { id: 'br-lon-01', nameEn: 'London Canary Wharf HQ', nameZh: '伦敦金丝雀码头总部大楼营业厅', city: 'London', latitude: 51.5054, longitude: -0.0195, employeesCount: 45, customersWaiting: 12, averageWaitMinutes: 8.4, cashPosition: 25000000, status: 'ONLINE' },
      { id: 'br-hkg-01', nameEn: 'Hong Kong Central Office', nameZh: '香港中环大厦营业厅', city: 'Hong Kong', latitude: 22.2855, longitude: 114.1577, employeesCount: 38, customersWaiting: 18, averageWaitMinutes: 14.2, cashPosition: 35000000, status: 'ONLINE' },
      { id: 'br-sgp-01', nameEn: 'Singapore Marina Bay Hub', nameZh: '新加坡滨海湾营业部', city: 'Singapore', latitude: 1.2804, longitude: 103.8548, employeesCount: 22, customersWaiting: 4, averageWaitMinutes: 3.5, cashPosition: 12000000, status: 'ONLINE' },
      { id: 'br-shg-01', nameEn: 'Shanghai Pudong Branch', nameZh: '上海浦东陆家嘴支行', city: 'Shanghai', latitude: 31.2397, longitude: 121.4998, employeesCount: 30, customersWaiting: 21, averageWaitMinutes: 19.5, cashPosition: 45000000, status: 'ONLINE' }
    ];

    this.atms = [
      { id: 'atm-lon-01', locationEn: 'Canary Wharf Mall West', locationZh: '金丝雀码头购物中心西区ATM', latitude: 51.5050, longitude: -0.0190, status: 'ONLINE', cashLevel: 85, recentTransactionsCount: 142 },
      { id: 'atm-lon-02', locationEn: 'London Euston Station lobby', locationZh: '伦敦尤斯顿车站进站大厅ATM', latitude: 51.5281, longitude: -0.1336, status: 'LOW_CASH', cashLevel: 14, recentTransactionsCount: 380 },
      { id: 'atm-hkg-01', locationEn: 'MTR Central Station Exit A', locationZh: '港铁中环站A出口ATM', latitude: 22.2850, longitude: 114.1570, status: 'ONLINE', cashLevel: 72, recentTransactionsCount: 290 },
      { id: 'atm-shg-01', locationEn: 'Lujiazui Metro Station Gate 3', locationZh: '陆家嘴地铁站3号口旁ATM', latitude: 31.2390, longitude: 121.4990, status: 'MAINTENANCE', cashLevel: 0, recentTransactionsCount: 0 }
    ];

    // Seed Initial Events Flow Ticker
    this.addEvent('account.events', 'acc-01', { event: 'AccountInitialized', type: 'Current', currency: 'GBP', status: 'ACTIVE' });
    this.addEvent('card.events', 'card-01', { event: 'CardActivated', cardNumber: '•••• 4821', limit: 5000 });
  }

  // Double-Entry Ledger Posting Engine (Immutable Source of Truth)
  public postJournalEntry(postings: Posting[], reference: string, correlationId: string): JournalEntry {
    // 1. Math Check: SUM(DEBITS) MUST EQUAL SUM(CREDITS)
    const debitsSum = postings.filter(p => p.type === 'DEBIT').reduce((acc, p) => acc + p.amount, 0);
    const creditsSum = postings.filter(p => p.type === 'CREDIT').reduce((acc, p) => acc + p.amount, 0);

    // Guarding floating point precision
    const diff = Math.abs(debitsSum - creditsSum);
    if (diff > 0.0001) {
      const errorMsg = `UNBALANCED_LEDGER: SUM(DEBITS) £${debitsSum.toFixed(2)} must equal SUM(CREDITS) £${creditsSum.toFixed(2)}. Difference: £${diff.toFixed(4)}`;
      this.writeAuditLog('SYSTEM_ENGINE', 'SYSTEM_CORE', 'POST_JOURNAL', 'LEDGER_ACCOUNTS', 'FAIL', errorMsg, correlationId);
      throw new Error(errorMsg);
    }

    // 2. Perform Account Value Updates
    postings.forEach(posting => {
      const ledgerAcc = this.ledgerAccounts.find(l => l.code === posting.ledgerCode);
      if (ledgerAcc) {
        const oldBalance = ledgerAcc.balance;
        // Asset/Expense: Debit increases, Credit decreases. Liability/Equity/Income: Credit increases, Debit decreases.
        if (ledgerAcc.type === 'ASSETS' || ledgerAcc.type === 'EXPENSES') {
          ledgerAcc.balance += posting.type === 'DEBIT' ? posting.amount : -posting.amount;
        } else {
          ledgerAcc.balance += posting.type === 'CREDIT' ? posting.amount : -posting.amount;
        }
        this.writeAuditLog('SYSTEM_ENGINE', 'LEDGER_AGENT', `UPDATE_LEDGER_CODE_${posting.ledgerCode}`, `LedgerAccount`, oldBalance.toString(), ledgerAcc.balance.toString(), correlationId);
      }
    });

    // 3. Save Immutable Journal entry
    const entryId = 'JNL-' + Math.floor(100000 + Math.random() * 900000);
    const entry: JournalEntry = {
      id: entryId,
      transactionId: 'TX-' + Math.floor(100000 + Math.random() * 900000),
      timestamp: new Date().toISOString(),
      postings,
      isBalanced: true,
      correlationId
    };
    this.journalEntries.push(entry);

    // Push into event stream
    this.addEvent('account.events', entryId, { event: 'JournalPosted', entriesCount: postings.length, isBalanced: true });

    return entry;
  }

  // --- CORE BANKING TRANSACTIONS ---
  public executeTransfer(
    fromAccountId: string,
    toAccountId: string,
    amount: number,
    reference: string,
    idempotencyKey: string
  ): { success: boolean; transactionId: string; correlationId: string; error?: string } {
    const correlationId = 'corr-' + Math.floor(100000 + Math.random() * 900000);

    // 1. Idempotency Check
    const existingPayment = this.payments.find(p => p.idempotencyKey === idempotencyKey);
    if (existingPayment) {
      this.writeAuditLog('CLIENT_APP', 'IDEMPOTENCY_STORE', 'DUPLICATE_PREVENTED', 'IdempotencyStore', 'EXISTS', existingPayment.id, correlationId);
      return { success: true, transactionId: existingPayment.id, correlationId };
    }

    // 2. Get and validate Accounts
    const fromAcc = this.accounts.find(a => a.id === fromAccountId);
    const toAcc = this.accounts.find(a => a.id === toAccountId);

    if (!fromAcc) return { success: false, transactionId: '', correlationId, error: 'SENDER_ACCOUNT_NOT_FOUND' };
    if (!toAcc) return { success: false, transactionId: '', correlationId, error: 'RECIPIENT_ACCOUNT_NOT_FOUND' };

    if (fromAcc.status === 'FROZEN') {
      return { success: false, transactionId: '', correlationId, error: 'SENDER_ACCOUNT_FROZEN' };
    }

    const currentBal = fromAcc.balances[fromAcc.currency] || 0;
    if (currentBal < amount) {
      return { success: false, transactionId: '', correlationId, error: 'INSUFFICIENT_FUNDS' };
    }

    // 3. Strict State Machine Payment Logging
    const payReqId = 'PAY-' + Math.floor(100000 + Math.random() * 900000);
    const paymentRecord: PaymentRequest = {
      id: payReqId,
      idempotencyKey,
      type: 'Internal',
      senderAccountId: fromAccountId,
      senderName: fromAcc.nameEn,
      recipientName: toAcc.nameEn,
      recipientBank: 'HSBC BANKING',
      recipientAccount: toAcc.accountNumber,
      currency: fromAcc.currency,
      amount,
      fee: 0,
      reference,
      status: 'CREATED',
      createdAt: new Date().toISOString()
    };
    this.payments.push(paymentRecord);

    // Phase: VALIDATED
    paymentRecord.status = 'VALIDATED';

    // Phase: FRAUD & AML SCENARIO ANALYSIS
    const fraudScore = this.evaluateFraudRisk(fromAcc, amount, toAcc.nameEn);
    if (fraudScore.score >= 80) {
      paymentRecord.status = 'REJECTED';
      this.addEvent('fraud.events', payReqId, { alert: 'FRAUD_BLOCK', score: fraudScore.score, reasons: fraudScore.reasonsEn });
      return { success: false, transactionId: '', correlationId, error: 'FRAUD_THREAT_DETECTION' };
    }

    // Phase: AUTHORIZED
    paymentRecord.status = 'AUTHORIZED';

    // Phase: PROCESSING -> LEDGER POSTING
    paymentRecord.status = 'PROCESSING';

    try {
      // Map ledger codes (Usually 2001 represent Current/Retail Deposits in GBP)
      const debitLedger = fromAcc.type === 'Savings' ? '2003' : '2001';
      const creditLedger = toAcc.type === 'Savings' ? '2003' : '2001';

      // Record double-entry postings
      const postings: Posting[] = [
        { type: 'DEBIT', ledgerCode: debitLedger, amount, currency: fromAcc.currency, narrative: `Debit customer ${fromAcc.id} - Trsf to ${toAcc.id}` },
        { type: 'CREDIT', ledgerCode: creditLedger, amount, currency: toAcc.currency, narrative: `Credit customer ${toAcc.id} - Trsf from ${fromAcc.id}` }
      ];

      // Atomic Posting Batch Execution
      const journal = this.postJournalEntry(postings, reference, correlationId);

      // Mutate UI Available Balances strictly from Ledger Posting Source of Truth
      fromAcc.balances[fromAcc.currency] = (fromAcc.balances[fromAcc.currency] || 0) - amount;
      fromAcc.availableBalance = fromAcc.balances[fromAcc.currency];

      toAcc.balances[toAcc.currency] = (toAcc.balances[toAcc.currency] || 0) + amount;
      toAcc.availableBalance = toAcc.balances[toAcc.currency];

      // Record Immutable History Entry for Customer A
      const txDebit: Transaction = {
        id: 'TXD-' + Math.floor(100000 + Math.random() * 900000),
        accountId: fromAccountId,
        timestamp: new Date().toISOString(),
        currency: fromAcc.currency,
        amount: -amount,
        type: 'TRANSFER',
        counterparty: toAcc.nameEn,
        reference,
        status: 'COMPLETED',
        category: 'Utilities',
        correlationId,
        debitAccount: fromAcc.accountNumber,
        creditAccount: toAcc.accountNumber
      };
      this.transactions.unshift(txDebit);

      // Record Immutable History Entry for Customer B
      const txCredit: Transaction = {
        id: 'TXC-' + Math.floor(100000 + Math.random() * 900000),
        accountId: toAccountId,
        timestamp: new Date().toISOString(),
        currency: toAcc.currency,
        amount: amount,
        type: 'TRANSFER',
        counterparty: fromAcc.nameEn,
        reference,
        status: 'COMPLETED',
        category: 'Income',
        correlationId,
        debitAccount: fromAcc.accountNumber,
        creditAccount: toAcc.accountNumber
      };
      this.transactions.unshift(txCredit);

      // Phase: SETTLED
      paymentRecord.status = 'SETTLED';

      this.writeAuditLog(
        'RETAIL_USER',
        'PAYMENT_AGENT',
        'POST_TRANSFER',
        'ACCOUNTS',
        currentBal.toString(),
        fromAcc.availableBalance.toString(),
        correlationId
      );

      // Trigger AML Structuring check
      this.evaluateAmlLimits(fromAcc, amount, correlationId);

      // Stream events
      this.addEvent('payment.events', payReqId, { event: 'PaymentSettled', amount, currency: fromAcc.currency });
      this.addEvent('transaction.events', txDebit.id, { event: 'TransactionRecorded', amount: -amount });

      return { success: true, transactionId: journal.transactionId, correlationId };
    } catch (e: any) {
      paymentRecord.status = 'FAILED';
      this.addEvent('payment.events', payReqId, { event: 'PaymentFailed', error: e.message });
      return { success: false, transactionId: '', correlationId, error: e.message };
    }
  }

  // --- FX CORE ENGINE & QUOTING ---
  // Returns precise FX rates with configurable customer spreads
  public getExchangeRate(pair: string): ExchangeRate {
    const rates: { [key: string]: number } = {
      'GBP/CNY': 9.2148,
      'GBP/USD': 1.3042,
      'EUR/GBP': 0.8415,
      'USD/CNY': 7.0650,
      'CNY/HKD': 1.1025,
      'GBP/EUR': 1.1882
    };

    const rate = rates[pair] || 1.0;
    // Spread matches typical tier-1 bank pricing spread (e.g. 0.04 Spread)
    const spread = pair === 'GBP/CNY' ? 0.042 : 0.015;
    const customerRate = rate - spread; // Bank buys base cheaper, sells target more expensive

    return { pair, rate, spread, customerRate };
  }

  public executeFxConversion(
    accountId: string,
    fromCurrency: string,
    toCurrency: string,
    fromAmount: number,
    correlationId: string
  ): { success: boolean; receiveAmount: number; error?: string } {
    const acc = this.accounts.find(a => a.id === accountId);
    if (!acc) return { success: false, receiveAmount: 0, error: 'ACCOUNT_NOT_FOUND' };

    const sourceBal = acc.balances[fromCurrency] || 0;
    if (sourceBal < fromAmount) return { success: false, receiveAmount: 0, error: 'INSUFFICIENT_FUNDS' };

    const pair = `${fromCurrency}/${toCurrency}`;
    const rateData = this.getExchangeRate(pair);
    const received = fromAmount * rateData.customerRate;

    try {
      // 1. Post to Double-Entry Ledger
      // Convert our source and destination balances inside general deposits ledger
      const postings: Posting[] = [
        { type: 'DEBIT', ledgerCode: '2001', amount: fromAmount, currency: fromCurrency, narrative: `FX Debit Customer ${fromCurrency}` },
        { type: 'CREDIT', ledgerCode: '2002', amount: received, currency: toCurrency, narrative: `FX Credit Customer ${toCurrency}` }
      ];

      // Mutate user state
      acc.balances[fromCurrency] = sourceBal - fromAmount;
      acc.balances[toCurrency] = (acc.balances[toCurrency] || 0) + received;

      if (acc.currency === fromCurrency) {
        acc.availableBalance = acc.balances[fromCurrency];
      }

      // Record Conversion Transactions
      const txConverted: Transaction = {
        id: 'FXT-' + Math.floor(100000 + Math.random() * 900000),
        accountId,
        timestamp: new Date().toISOString(),
        currency: fromCurrency,
        amount: -fromAmount,
        type: 'FX_CONVERSION',
        counterparty: `FX Conv (${toCurrency})`,
        reference: `Fx Convert @ ${rateData.customerRate.toFixed(4)}`,
        status: 'COMPLETED',
        category: 'Investment',
        correlationId
      };
      this.transactions.unshift(txConverted);

      const txReceived: Transaction = {
        id: 'FXR-' + Math.floor(100000 + Math.random() * 900000),
        accountId,
        timestamp: new Date().toISOString(),
        currency: toCurrency,
        amount: received,
        type: 'FX_CONVERSION',
        counterparty: `FX Conv (${fromCurrency})`,
        reference: `Fx Conversion Credit`,
        status: 'COMPLETED',
        category: 'Investment',
        correlationId
      };
      this.transactions.unshift(txReceived);

      this.addEvent('fx.events', txConverted.id, { event: 'FXTradeCompleted', pair, fromAmount, received });
      return { success: true, receiveAmount: received };
    } catch (e: any) {
      return { success: false, receiveAmount: 0, error: e.message };
    }
  }

  // --- LOAN AMORTIZATION ENGINE ---
  public calculateAmortization(principal: number, annualRate: number, termMonths: number): AmortizationScheduleRow[] {
    const monthlyRate = (annualRate / 100) / 12;
    const monthlyPayment = (principal * monthlyRate) / (1 - Math.pow(1 + monthlyRate, -termMonths));

    const schedule: AmortizationScheduleRow[] = [];
    let currentBalance = principal;

    for (let m = 1; m <= termMonths; m++) {
      const interest = currentBalance * monthlyRate;
      const principalPaid = monthlyPayment - interest;
      const closingBalance = currentBalance - principalPaid;

      schedule.push({
        month: m,
        openingBalance: Number(currentBalance.toFixed(2)),
        interest: Number(interest.toFixed(2)),
        principal: Number(principalPaid.toFixed(2)),
        payment: Number(monthlyPayment.toFixed(2)),
        closingBalance: Number(Math.max(0, closingBalance).toFixed(2))
      });

      currentBalance = closingBalance;
      if (currentBalance < 0.01) break;
    }

    return schedule;
  }

  // --- FRAUD VELOCITY DETECTION ENGINE (RULE-BASED, DETERMINISTIC) ---
  public evaluateFraudRisk(fromAcc: Account, amount: number, recipientName: string): { score: number; reasonsEn: string[]; reasonsZh: string[] } {
    const reasonsEn: string[] = [];
    const reasonsZh: string[] = [];
    let score = 0;

    // Rule 1: Limit velocity
    if (amount > 10000) {
      score += 45;
      reasonsEn.push('Large payment amount detected above profile limits');
      reasonsZh.push('检测到大额款项支出，超出常规客户画像配置');
    }

    // Rule 2: Unregistered beneficiary suspicious indicators
    const isNewBeneficiary = !this.transactions.some(t => t.counterparty === recipientName);
    if (isNewBeneficiary) {
      score += 25;
      reasonsEn.push('First time transaction to this recipient');
      reasonsZh.push('首次向该收款方发起资金划拨');
    }

    // Rule 3: Simulated Stress conditions
    if (this.stressMode === 'FRAUD_SURGE') {
      score += 20;
      reasonsEn.push('Global Operations alert: Ongoing credential stuffing surge detected');
      reasonsZh.push('全球网络安全预警：系统当前遭受凭据填充式撞库欺诈攻击');
    }

    return { score, reasonsEn, reasonsZh };
  }

  // --- AML MONITORING CENTRE ---
  public evaluateAmlLimits(fromAcc: Account, amount: number, correlationId: string) {
    if (amount > 9000 && amount < 10000) {
      // AML structuring pattern (Trying to bypass £10,000 threshold)
      const customer = this.customers[0];
      const caseId = 'aml-case-' + Math.floor(100000 + Math.random() * 900000);
      const amlAlert: AmlCase = {
        id: caseId,
        customerId: customer.id,
        customerNameEn: customer.nameEn,
        customerNameZh: customer.nameZh,
        alertTypeEn: 'Potential Structuring Alert (Anti-Reporting Bypass)',
        alertTypeZh: '潜在拆单逃避监管申报行为监控警报',
        riskLevel: 'HIGH',
        evidenceEn: `Customer initiated a transaction of £${amount.toFixed(2)} which sits suspiciously close to the regulatory £10,000 Cash Transaction Report threshold.`,
        evidenceZh: `客户发起了 £${amount.toFixed(2)} 的汇划交易，高度逼近监管要求的 £10,000 现金/跨境交易报告阈值。`,
        status: 'ALERT',
        auditTrail: [
          { timestamp: new Date().toISOString(), actionEn: 'AML Transaction alert flagged', actionZh: 'AML 交易流速预警器红旗标记', actor: 'Automated AML Engine' }
        ]
      };

      this.amlCases.unshift(amlAlert);
      this.addEvent('aml.events', caseId, { event: 'AMLPotentialStructuringFlagged', amount });
      this.writeAuditLog('SYSTEM_COMPLIANCE', 'AML_MONITOR', 'FLAG_AML_CASE', 'AmlCase', 'NONE', caseId, correlationId);
    }
  }

  // --- CORPORATE MAKER-CHECKER FLOW ---
  public submitMakerPayment(payment: Omit<MakerCheckerPayment, 'id' | 'createdAt' | 'status' | 'correlationId'>): MakerCheckerPayment {
    const id = 'MCP-' + Math.floor(100000 + Math.random() * 900000);
    const correlationId = 'corr-mc-' + Math.floor(100000 + Math.random() * 900000);
    const record: MakerCheckerPayment = {
      ...payment,
      id,
      createdAt: new Date().toISOString(),
      status: 'PENDING_APPROVAL',
      correlationId
    };

    this.makerCheckerPayments.unshift(record);
    this.addEvent('payment.events', id, { event: 'MakerPaymentCreated', amount: payment.amount });
    this.writeAuditLog(payment.makerName, 'CORPORATE_APP', 'CREATE_MAKER_PAYMENT', 'MakerCheckerPayment', 'NONE', id, correlationId);
    return record;
  }

  public approveMakerPayment(id: string, checkerName: string): { success: boolean; error?: string } {
    const payment = this.makerCheckerPayments.find(p => p.id === id);
    if (!payment) return { success: false, error: 'PAYMENT_NOT_FOUND' };
    if (payment.status !== 'PENDING_APPROVAL') return { success: false, error: 'INVALID_STATUS' };

    // Debit business accounts
    const corpAcc = this.accounts.find(a => a.id === 'acc-corp-01');
    if (!corpAcc) return { success: false, error: 'CORPORATE_ACCOUNT_NOT_FOUND' };

    const bal = corpAcc.balances['GBP'] || 0;
    if (bal < payment.amount) {
      payment.status = 'REJECTED';
      payment.rejectionReasonEn = 'Insufficient corporate deposit reserves';
      payment.rejectionReasonZh = '企业备付准备金头寸不足';
      return { success: false, error: 'INSUFFICIENT_CORPORATE_FUNDS' };
    }

    try {
      // 1. Post to Double Entry Ledger
      const postings: Posting[] = [
        { type: 'DEBIT', ledgerCode: '2100', amount: payment.amount, currency: payment.currency, narrative: `Maker-Checker approved debit - ${payment.id}` },
        { type: 'CREDIT', ledgerCode: '1001', amount: payment.amount, currency: payment.currency, narrative: `Corporate outflow settlement` }
      ];

      this.postJournalEntry(postings, `Maker-Checker Approver: ${checkerName}`, payment.correlationId);

      // Mutate Corporate account
      corpAcc.balances['GBP'] = bal - payment.amount;
      corpAcc.availableBalance = corpAcc.balances['GBP'];

      // Mark payment as Settled
      payment.status = 'APPROVED';
      payment.checkerName = checkerName;
      payment.approvedAt = new Date().toISOString();

      // Record Company transaction history
      const tx: Transaction = {
        id: 'CORP-TX-' + Math.floor(100000 + Math.random() * 900000),
        accountId: corpAcc.id,
        timestamp: new Date().toISOString(),
        currency: payment.currency,
        amount: -payment.amount,
        type: 'TRANSFER',
        counterparty: payment.recipientName,
        reference: `Maker-Checker ${payment.id}`,
        status: 'COMPLETED',
        category: 'Utilities',
        correlationId: payment.correlationId
      };
      this.transactions.unshift(tx);

      this.addEvent('payment.events', id, { event: 'MakerPaymentApproved', checker: checkerName });
      this.writeAuditLog(checkerName, 'CORPORATE_APP', 'APPROVE_MAKER_PAYMENT', 'MakerCheckerPayment', 'PENDING_APPROVAL', 'APPROVED', payment.correlationId);

      return { success: true };
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  }

  // --- FAILURE INJECTION & DISASTER RECOVERY ---
  public injectFailure(scenario: typeof this.stressMode) {
    this.stressMode = scenario;

    if (scenario === 'FAIL_REDIS') {
      this.systemHealth.redisStatus = 'OFFLINE';
      this.systemHealth.apiLatencyMs = 245; // Cache bypass degrades latency
    } else if (scenario === 'FAIL_DB') {
      this.systemHealth.dbStatus = 'SLOW';
      this.systemHealth.databaseLatencyMs = 120; // Simulated disk fail degrade
    } else if (scenario === 'FAIL_KAFKA') {
      this.systemHealth.kafkaStatus = 'OFFLINE';
      this.systemHealth.kafkaLag = 14209; // Stalled consumers
    } else if (scenario === 'CYBER_INCIDENT') {
      this.systemHealth.paymentProcessorStatus = 'DEGRADED';
      this.systemHealth.apiLatencyMs = 500;
    } else if (scenario === 'LIQUIDITY_STRESS') {
      // Severe drawdowns
      const cashLedger = this.ledgerAccounts.find(l => l.code === '1001');
      if (cashLedger) cashLedger.balance = Math.floor(cashLedger.balance * 0.4); // Run on the bank
    } else if (scenario === 'NORMAL') {
      this.systemHealth = {
        apiLatencyMs: 42,
        databaseLatencyMs: 4,
        kafkaLag: 12,
        redisStatus: 'ONLINE',
        paymentProcessorStatus: 'ONLINE',
        kafkaStatus: 'ONLINE',
        dbStatus: 'ONLINE'
      };
    }

    const corrId = 'corr-fail-' + Math.floor(100000 + Math.random() * 900000);
    this.writeAuditLog('OPERATION_DESK', 'HEALTH_MONITOR', 'FAILURE_INJECTION', 'StressMode', 'NORMAL', scenario, corrId);
    this.addEvent('branch.events', 'global-ops', { alert: 'HEALTH_DEGRADED', mode: scenario });
  }

  // --- AUDIT LOGGER ---
  public writeAuditLog(
    actor: string,
    role: string,
    action: string,
    resource: string,
    oldState: string,
    newState: string,
    correlationId: string
  ) {
    const log: AuditLog = {
      correlationId,
      actor,
      role,
      timestamp: new Date().toISOString(),
      action,
      resource,
      oldState,
      newState,
      ip: '10.240.42.109',
      device: 'Secure Terminal (Bilingual OS X)'
    };
    this.auditLogs.unshift(log);
  }

  // --- EVENT GENERATION & LOGGING ---
  public addEvent(topic: RealTimeEvent['topic'], key: string, payload: any) {
    const evt: RealTimeEvent = {
      topic,
      timestamp: new Date().toISOString(),
      key,
      payload: JSON.stringify(payload)
    };
    this.realTimeEvents.unshift(evt);
    if (this.realTimeEvents.length > 50) this.realTimeEvents.pop(); // Keep list bounded
  }

  // --- BILINGUAL AI SYSTEM SECURE TOOLS ---
  public executeAiBalanceQuery(): { balancesEn: string; balancesZh: string } {
    const current = this.accounts.find(a => a.id === 'acc-01')!;
    const savings = this.accounts.find(a => a.id === 'acc-02')!;
    const usd = this.accounts.find(a => a.id === 'acc-03')!;

    const currentBal = current.balances['GBP'] || 0;
    const savingsBal = savings.balances['GBP'] || 0;
    const usdBal = usd.balances['USD'] || 0;

    const totalGBP = currentBal + savingsBal + (usdBal * 0.77); // Approx conversion

    return {
      balancesEn: `Your Everyday current balance is £${currentBal.toLocaleString('en-GB', { minimumFractionDigits: 2 })}, Savings balance is £${savingsBal.toLocaleString('en-GB', { minimumFractionDigits: 2 })}, and Global Wallet balance is $${usdBal.toLocaleString('en-GB', { minimumFractionDigits: 2 })}. Estimated total across wallets is £${totalGBP.toLocaleString('en-GB', { minimumFractionDigits: 2 })}.`,
      balancesZh: `您的日常往来活期余额为 £${currentBal.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}，储蓄余额为 £${savingsBal.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}，多币种美元账户余额为 $${usdBal.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}。资产折算总额约为 £${totalGBP.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}。`
    };
  }

  public executeAiSpendQuery(): { spendEn: string; spendZh: string } {
    // Total foods spending from initialized mock transactions
    const foodTxSum = Math.abs(this.transactions.filter(t => t.category === 'Food' && t.amount < 0).reduce((sum, t) => sum + t.amount, 0));
    const shoppingTxSum = Math.abs(this.transactions.filter(t => t.category === 'Shopping' && t.amount < 0).reduce((sum, t) => sum + t.amount, 0));

    return {
      spendEn: `Based on your recent transactions, you spent £${foodTxSum.toFixed(2)} on Food (Tesco) and £${shoppingTxSum.toFixed(2)} on Shopping (Amazon) over the current billing cycle.`,
      spendZh: `根据您的近期账单明细，您在本计息周期内在餐饮消费（如乐购 Tesco）共支出 £${foodTxSum.toFixed(2)}，在购物商超（如亚马逊 Amazon）共支出 £${shoppingTxSum.toFixed(2)}。`
    };
  }
}

// Instantiate Global Shared OS instance
export const systemEngine = new BankingEngine();
