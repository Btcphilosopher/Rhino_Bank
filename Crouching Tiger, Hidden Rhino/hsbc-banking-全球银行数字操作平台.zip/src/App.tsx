/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import Header from './components/Header';
import AiAssistant from './components/AiAssistant';
import RetailDashboard from './components/RetailDashboard';
import CorporateDashboard from './components/CorporateDashboard';
import TreasuryDashboard from './components/TreasuryDashboard';
import ComplianceDashboard from './components/ComplianceDashboard';
import OperationsDashboard from './components/OperationsDashboard';
import SimulatorDashboard from './components/SimulatorDashboard';
import DeveloperApiDashboard from './components/DeveloperApiDashboard';

export default function App() {
  const [lang, setLang] = useState<'en-GB' | 'zh-CN'>('en-GB');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [activeView, setActiveView] = useState<'retail' | 'corporate' | 'treasury' | 'compliance' | 'operations' | 'simulator' | 'developer'>('retail');
  const [stressMode, setStressMode] = useState<string>('NORMAL');
  const [aiOpen, setAiOpen] = useState(false);

  // Sync stress scenario change from Simulator
  const handleScenarioChange = (mode: string) => {
    setStressMode(mode);
  };

  const handleLanguageToggle = () => {
    setLang(prev => (prev === 'en-GB' ? 'zh-CN' : 'en-GB'));
  };

  const handleViewChange = (view: any) => {
    setActiveView(view);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setActiveView('retail');
  };

  return (
    <div className="min-h-screen bg-[#071324] text-slate-100 flex flex-col justify-between selection:bg-red-700 selection:text-white" id="app-root">
      <div className="space-y-4">
        {/* Global Bank Header */}
        <Header
          lang={lang}
          currentView={activeView}
          isLoggedIn={isLoggedIn}
          stressMode={stressMode}
          toggleLang={handleLanguageToggle}
          onViewChange={handleViewChange}
          onLoginToggle={() => {
            if (isLoggedIn) {
              handleLogout();
            } else {
              handleViewChange('retail');
            }
          }}
        />

        {/* Core Main Operating Dashboard Canvas */}
        <main className="max-w-7xl mx-auto px-4 md:px-6 pb-20 w-full" id="main-operating-deck">
          {activeView === 'retail' && (
            <RetailDashboard
              lang={lang}
              isLoggedIn={isLoggedIn}
              onLoginSuccess={() => setIsLoggedIn(true)}
            />
          )}

          {activeView === 'corporate' && (
            <CorporateDashboard lang={lang} />
          )}

          {activeView === 'treasury' && (
            <TreasuryDashboard lang={lang} />
          )}

          {activeView === 'compliance' && (
            <ComplianceDashboard lang={lang} />
          )}

          {activeView === 'operations' && (
            <OperationsDashboard lang={lang} />
          )}

          {activeView === 'simulator' && (
            <SimulatorDashboard
              lang={lang}
              stressMode={stressMode}
              onScenarioChange={handleScenarioChange}
            />
          )}

          {activeView === 'developer' && (
            <DeveloperApiDashboard lang={lang} />
          )}
        </main>
      </div>

      {/* Floating Aurelia AI Assistant Portal */}
      {isLoggedIn && (
        <div className="fixed bottom-6 right-6 z-50">
          <button
            onClick={() => setAiOpen(!aiOpen)}
            className="bg-red-700 hover:bg-red-600 text-white p-3.5 rounded-full shadow-2xl hover:scale-105 active:scale-95 transition-all flex items-center justify-center border border-red-500"
            id="btn-ai-assistant-toggle"
            title={lang === 'en-GB' ? 'Launch Aurelia Assistant' : '召唤 Aurelia 智能客服助手'}
          >
            <span className="font-extrabold text-sm tracking-widest px-1 font-serif">Aurelia</span>
          </button>

          {aiOpen && (
            <div className="absolute bottom-16 right-0 w-[380px] h-[520px] shadow-3xl rounded-xl overflow-hidden border border-slate-700">
              <AiAssistant lang={lang} onClose={() => setAiOpen(false)} />
            </div>
          )}
        </div>
      )}

      {/* Corporate Status/Compliance Bar */}
      <footer className="bg-[#040C16] border-t border-slate-900 py-3.5 px-6 text-[10px] text-slate-500 font-mono flex flex-col md:flex-row justify-between items-center gap-3 w-full">
        <div className="flex items-center gap-4">
          <span>© 2026 HSBC BANKING GLOBAL PLC. ALL DIGITAL TWIN CHANNELS PROTECTED.</span>
          <span className="hidden md:inline text-slate-700">|</span>
          <span className="hidden md:inline">SECURITY LEVEL: TLS_1.3_AES_GCM_256</span>
        </div>
        <div className="flex gap-4">
          <span className="flex items-center gap-1.5">
            <span className="h-2 w-2 bg-emerald-500 rounded-full"></span>
            LEDGER STATUS: VERIFIED BALANCE
          </span>
          {stressMode !== 'NORMAL' && (
            <span className="flex items-center gap-1.5 text-amber-400 font-bold">
              ⚠️ STRESS ACTIVE: {stressMode}
            </span>
          )}
        </div>
      </footer>
    </div>
  );
}
