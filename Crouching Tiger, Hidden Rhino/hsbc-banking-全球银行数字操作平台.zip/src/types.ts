/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type Language = 'en-GB' | 'zh-CN';

// --- CORE BANKING & ACCOUNT TYPES ---
export type AccountType = 'Current' | 'Savings' | 'Business' | 'Multi-Currency' | 'Term Deposit';

export interface CurrencyPair {
  base: string;
  target: string;
}

export interface ExchangeRate {
  pair: string; // e.g. "GBP/CNY"
  rate: number; // Market rate
  spread: number;
  customerRate: number; // rate - spread or rate + spread
}

export interface Account {
  id: string;
  accountNumber: string;
  nameEn: string;
  nameZh: string;
  type: AccountType;
  currency: string;
  balances: { [currency: string]: number }; // For multi-currency
  availableBalance: number;
  interestRate: number;
  openDate: string;
  status: 'ACTIVE' | 'FROZEN' | 'CLOSED';
}

export interface Customer {
  id: string;
  partyNumber: string;
  nameEn: string;
  nameZh: string;
  email: string;
  riskClassification: 'LOW' | 'MEDIUM' | 'HIGH';
  kycStatus: 'NOT_STARTED' | 'PENDING' | 'VERIFIED' | 'REVIEW' | 'REJECTED' | 'EXPIRED';
  kycVerificationDate?: string;
  country: string;
}

// --- DOUBLE-ENTRY LEDGER ---
export interface LedgerAccount {
  code: string; // e.g. "1001" (Cash), "2001" (Deposits), "3001" (Equity), "4001" (Interest Income)
  nameEn: string;
  nameZh: string;
  type: 'ASSETS' | 'LIABILITIES' | 'EQUITY' | 'INCOME' | 'EXPENSES';
  balance: number;
}

export interface Posting {
  type: 'DEBIT' | 'CREDIT';
  ledgerCode: string;
  amount: number;
  currency: string;
  narrative: string;
}

export interface JournalEntry {
  id: string;
  transactionId: string;
  timestamp: string;
  postings: Posting[];
  isBalanced: boolean;
  correlationId: string;
}

// --- TRANSACTION HISTORY ---
export interface Transaction {
  id: string;
  accountId: string;
  timestamp: string;
  currency: string;
  amount: number; // Negative for outflow, positive for inflow
  type: 'TRANSFER' | 'CARD_SPEND' | 'SALARY' | 'FEE' | 'INTEREST' | 'FX_CONVERSION' | 'LOAN_DISBURSEMENT' | 'MORTGAGE_REPAYMENT' | 'BILL_PAY';
  counterparty: string;
  reference: string;
  status: 'PENDING' | 'COMPLETED' | 'REJECTED' | 'REVERSED';
  category: 'Housing' | 'Transport' | 'Food' | 'Shopping' | 'Travel' | 'Entertainment' | 'Utilities' | 'Healthcare' | 'Education' | 'Income' | 'Investment';
  debitAccount?: string;
  creditAccount?: string;
  correlationId: string;
}

// --- PAYMENTS ---
export type PaymentType = 'Domestic' | 'International' | 'Scheduled' | 'Recurring' | 'Bill' | 'Internal';
export type PaymentStatus = 'CREATED' | 'VALIDATED' | 'AUTHORIZED' | 'PROCESSING' | 'SETTLED' | 'FAILED' | 'REJECTED' | 'REVERSED';

export interface PaymentRequest {
  id: string;
  idempotencyKey: string;
  type: PaymentType;
  senderAccountId: string;
  senderName: string;
  recipientName: string;
  recipientBank: string;
  recipientAccount: string;
  currency: string;
  amount: number;
  fee: number;
  reference: string;
  fxRate?: number;
  fxQuoteId?: string;
  purposeCodeEn?: string;
  purposeCodeZh?: string;
  status: PaymentStatus;
  createdAt: string;
}

// --- CARDS ---
export type CardType = 'Debit' | 'Credit' | 'Virtual' | 'Corporate';

export interface Card {
  id: string;
  accountId: string;
  cardNumberMasked: string; // e.g. "•••• 4821"
  cardHolderName: string;
  expiryDate: string;
  cvvMasked: string;
  cardType: CardType;
  status: 'ACTIVE' | 'FROZEN' | 'CANCELLED';
  creditLimit?: number;
  availableCredit?: number;
  statementBalance?: number;
  spendingLimitDaily: number;
  spendingLimitSpent: number;
  merchantControls: {
    online: boolean;
    contactless: boolean;
    international: boolean;
    atm: boolean;
  };
  travelMode: boolean;
}

// --- LOANS & MORTGAGES ---
export interface Loan {
  id: string;
  type: 'Personal' | 'Business' | 'Mortgage' | 'Overdraft';
  principal: number;
  outstandingBalance: number;
  interestRate: number;
  termMonths: number;
  startDate: string;
  monthlyPayment: number;
  propertyValue?: number; // For Mortgage
  deposit?: number; // For Mortgage
  loanToValue?: number; // For Mortgage
}

export interface AmortizationScheduleRow {
  month: number;
  openingBalance: number;
  interest: number;
  principal: number;
  payment: number;
  closingBalance: number;
}

// --- BUDGETS & SAVINGS ---
export interface SavingsGoal {
  id: string;
  nameEn: string;
  nameZh: string;
  targetAmount: number;
  currentAmount: number;
  targetDate: string;
}

export interface SpendingBudget {
  category: string;
  budgetAmount: number;
  usedAmount: number;
}

// --- CORPORATE BANKING ---
export type CorporateRole = 'Company Admin' | 'Treasurer' | 'Finance Manager' | 'Accountant' | 'Payment Maker' | 'Payment Approver' | 'Viewer' | 'Auditor';

export interface MakerCheckerPayment {
  id: string;
  makerName: string;
  checkerName?: string;
  createdAt: string;
  approvedAt?: string;
  type: 'Supplier' | 'Payroll' | 'Tax' | 'Bulk';
  amount: number;
  currency: string;
  recipientName: string;
  recipientAccount: string;
  status: 'PENDING_APPROVAL' | 'APPROVED' | 'REJECTED';
  rejectionReasonEn?: string;
  rejectionReasonZh?: string;
  correlationId: string;
}

// --- COMPLIANCE, RISK, AML, KYC ---
export interface RiskMetric {
  metric: string;
  value: string | number;
  threshold: string | number;
  status: 'LOW' | 'MEDIUM' | 'HIGH';
  explanationEn: string;
  explanationZh: string;
  timestamp: string;
}

export interface FraudAlert {
  id: string;
  transactionId?: string;
  timestamp: string;
  score: number; // 0-100
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH';
  reasonsEn: string[];
  reasonsZh: string[];
  actionEn: string;
  actionZh: string;
  status: 'PENDING_STEP_UP' | 'VERIFIED' | 'REJECTED';
}

export interface AmlCase {
  id: string;
  customerId: string;
  customerNameEn: string;
  customerNameZh: string;
  alertTypeEn: string;
  alertTypeZh: string;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH';
  evidenceEn: string;
  evidenceZh: string;
  analyst?: string;
  status: 'ALERT' | 'CASE_CREATED' | 'ANALYST_REVIEW' | 'ESCALATED' | 'CLOSED';
  auditTrail: {
    timestamp: string;
    actionEn: string;
    actionZh: string;
    actor: string;
  }[];
}

// --- OPEN BANKING ---
export interface OpenBankingConsent {
  id: string;
  tppName: string;
  scope: string[];
  status: 'REQUESTED' | 'AUTHORIZED' | 'ACTIVE' | 'EXPIRED' | 'REVOKED';
  createdAt: string;
  expiresAt: string;
}

// --- DIGITAL TWINS & OPERATIONS ---
export interface Branch {
  id: string;
  nameEn: string;
  nameZh: string;
  city: string;
  latitude: number;
  longitude: number;
  employeesCount: number;
  customersWaiting: number;
  averageWaitMinutes: number;
  cashPosition: number;
  status: 'ONLINE' | 'OFFLINE' | 'LIMITED_SERVICE';
}

export interface Atm {
  id: string;
  locationEn: string;
  locationZh: string;
  latitude: number;
  longitude: number;
  status: 'ONLINE' | 'OFFLINE' | 'LOW_CASH' | 'MAINTENANCE' | 'ERROR';
  cashLevel: number; // 0 to 100
  recentTransactionsCount: number;
}

export interface SystemHealth {
  apiLatencyMs: number;
  databaseLatencyMs: number;
  kafkaLag: number;
  redisStatus: 'ONLINE' | 'OFFLINE' | 'SLOW';
  paymentProcessorStatus: 'ONLINE' | 'OFFLINE' | 'DEGRADED';
  kafkaStatus: 'ONLINE' | 'OFFLINE';
  dbStatus: 'ONLINE' | 'SLOW' | 'OFFLINE';
}

// --- OBSERVABILITY & AUDIT ---
export interface AuditLog {
  correlationId: string;
  actor: string;
  role: string;
  timestamp: string;
  action: string;
  resource: string;
  oldState: string;
  newState: string;
  ip: string;
  device: string;
}

export interface RealTimeEvent {
  topic: 'account.events' | 'transaction.events' | 'payment.events' | 'card.events' | 'loan.events' | 'fx.events' | 'fraud.events' | 'aml.events' | 'kyc.events' | 'branch.events' | 'atm.events';
  timestamp: string;
  key: string;
  payload: string; // JSON string
}
