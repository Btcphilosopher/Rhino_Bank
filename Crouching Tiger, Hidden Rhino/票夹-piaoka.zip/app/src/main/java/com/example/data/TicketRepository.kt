package com.example.data

import com.example.database.TicketDao
import com.example.model.Ticket
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.text.SimpleDateFormat
import java.util.Locale

class TicketRepository(private val ticketDao: TicketDao) {
    val allTickets: Flow<List<Ticket>> = ticketDao.getAllTickets()

    suspend fun getTicketById(id: Int): Ticket? {
        return ticketDao.getTicketById(id)
    }

    suspend fun insertTicket(ticket: Ticket): Long {
        return ticketDao.insertTicket(ticket)
    }

    suspend fun updateTicket(ticket: Ticket) {
        ticketDao.updateTicket(ticket)
    }

    suspend fun deleteTicket(ticket: Ticket) {
        ticketDao.deleteTicket(ticket)
    }

    suspend fun deleteTicketById(id: Int) {
        ticketDao.deleteTicketById(id)
    }

    suspend fun prepopulateIfEmpty() {
        val currentTickets = ticketDao.getAllTickets().first()
        if (currentTickets.isEmpty()) {
            val testTickets = listOf(
                Ticket(
                    type = "电影票",
                    category = "电影",
                    title = "《星海计划》",
                    date = "2026-09-18",
                    time = "19:30",
                    timestamp = parseDateTimeToTimestamp("2026-09-18", "19:30"),
                    location = "万达影城 北京CBD店",
                    seat = "IMAX厅 5排6座, 5排7座",
                    ticketNo = "9182374981",
                    orderNo = "20260918001234",
                    qrCodeData = "piaoka://ticket/movie/xinghai/9182374981",
                    notes = "请提前15分钟入场，1号IMAX厅",
                    reminderMinutes = 30
                ),
                Ticket(
                    type = "高铁票",
                    category = "交通",
                    title = "北京南 → 上海虹桥",
                    date = "2026-09-20",
                    time = "09:15",
                    timestamp = parseDateTimeToTimestamp("2026-09-20", "09:15"),
                    location = "北京南站",
                    seat = "08车 12A",
                    ticketNo = "G1234-0812A",
                    orderNo = "TR20260920G1234",
                    qrCodeData = "G1234 北京南-上海虹桥 202609200915 08车12A",
                    notes = "车次 G1234，检票口 B12。到达上海虹桥预计 13:48",
                    reminderMinutes = 60
                ),
                Ticket(
                    type = "演唱会门票",
                    category = "演出",
                    title = "周杰伦 2026 世界巡回演唱会",
                    date = "2026-09-25",
                    time = "19:30",
                    timestamp = parseDateTimeToTimestamp("2026-09-25", "19:30"),
                    location = "国家体育场 (鸟巢)",
                    seat = "看台 A区12排18座",
                    ticketNo = "ZJL20260925991",
                    orderNo = "OD888777123",
                    qrCodeData = "jay_world_tour_2026_nest_a12_18",
                    notes = "强实名制，请务必携带身份证原件入场",
                    reminderMinutes = 120
                ),
                Ticket(
                    type = "景区门票",
                    category = "景区",
                    title = "北京故宫博物院",
                    date = "2026-09-28",
                    time = "10:00",
                    timestamp = parseDateTimeToTimestamp("2026-09-28", "10:00"),
                    location = "北京故宫",
                    seat = "成人一日票 (下午场)",
                    ticketNo = "GG202609280123",
                    orderNo = "GG_ORDER_991823",
                    qrCodeData = "gugong://ticket/20260928/adult",
                    notes = "刷身份证直接入园，下午12点后可检票入园",
                    reminderMinutes = 1440
                )
            )
            for (ticket in testTickets) {
                ticketDao.insertTicket(ticket)
            }
        }
    }

    private fun parseDateTimeToTimestamp(dateStr: String, timeStr: String): Long {
        return try {
            val format = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
            val date = format.parse("$dateStr $timeStr")
            date?.time ?: System.currentTimeMillis()
        } catch (e: Exception) {
            System.currentTimeMillis()
        }
    }
}
