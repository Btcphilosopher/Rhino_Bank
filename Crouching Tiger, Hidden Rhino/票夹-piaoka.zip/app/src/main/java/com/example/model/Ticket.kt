package com.example.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "tickets")
data class Ticket(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val type: String,               // 详细票种, e.g., "电影票", "演唱会门票", "高铁票", "景区门票"
    val category: String,           // 顶层大类, e.g., "电影", "演出", "交通", "体育", "景区", "展览", "其他"
    val title: String,              // 票务名称, e.g., "《星海计划》", "周杰伦 2026 世界巡回演唱会", "北京南 → 上海虹桥"
    val date: String,               // 日期, e.g., "2026-09-18" or "2026年9月20日"
    val time: String,               // 时间, e.g., "19:30", "09:15"
    val timestamp: Long,            // 用于排序和过期的具体时间戳 (毫秒)
    val location: String,           // 地点/场馆, e.g., "万达影城北京CBD店"
    val seat: String,               // 座位/席位, e.g., "5排6座", "08车12A", "看台 A区12排18座"
    val ticketNo: String,           // 票号
    val orderNo: String,            // 订单号
    val qrCodeData: String,         // 二维码/条形码内容
    val notes: String = "",         // 备注
    val isUsed: Boolean = false,    // 是否已使用/历史票
    val reminderMinutes: Int = -1,  // 提醒设置: -1 不提醒, 15, 30, 60 (1小时), 120 (2小时), 1440 (1天)
    val createdAt: Long = System.currentTimeMillis()
) : Serializable
