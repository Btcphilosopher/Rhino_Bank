package com.example.ui.ticket

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import kotlin.math.abs

@Composable
fun QRCodeView(
    data: String,
    modifier: Modifier = Modifier,
    color: Color = Color.Black,
    backgroundColor: Color = Color.White
) {
    Box(
        modifier = modifier
            .background(backgroundColor)
            .aspectRatio(1f)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val sizePx = size.width
            val gridSize = 25 // 25x25 QR matrix (Version 2)
            val cellSize = sizePx / gridSize

            // Draw background
            drawRect(color = backgroundColor)

            // Finder patterns: top-left (0,0), top-right (0, gridSize-7), bottom-left (gridSize-7, 0)
            val finders = listOf(
                Pair(0, 0),
                Pair(0, gridSize - 7),
                Pair(gridSize - 7, 0)
            )

            // Matrix array to keep track of filled pixels
            val matrix = Array(gridSize) { BooleanArray(gridSize) }

            // Mark finders in the mask
            for (f in finders) {
                val rStart = f.first
                val cStart = f.second
                for (r in 0 until 7) {
                    for (c in 0 until 7) {
                        matrix[rStart + r][cStart + c] = true
                    }
                }
            }

            // Draw data modules (pseudorandom based on data hash)
            val hash = data.hashCode()
            for (r in 0 until gridSize) {
                for (c in 0 until gridSize) {
                    if (matrix[r][c]) continue
                    // Deterministic grid generator based on grid coords and data hash
                    val cellHash = abs((r * 113 + c * 223 + 47) xor hash)
                    if (cellHash % 2 == 0) {
                        drawRect(
                            color = color,
                            topLeft = Offset(c * cellSize, r * cellSize),
                            size = Size(cellSize + 0.3f, cellSize + 0.3f)
                        )
                    }
                }
            }

            // Draw sharp Finder Patterns (Outer 7x7 outer square, inner 3x3 solid block)
            for (f in finders) {
                val rStart = f.first
                val cStart = f.second

                for (r in 0 until 7) {
                    for (c in 0 until 7) {
                        val isOuterBorder = r == 0 || r == 6 || c == 0 || c == 6
                        val isInnerBlock = r in 2..4 && c in 2..4
                        val fill = isOuterBorder || isInnerBlock

                        drawRect(
                            color = if (fill) color else backgroundColor,
                            topLeft = Offset((cStart + c) * cellSize, (rStart + r) * cellSize),
                            size = Size(cellSize + 0.3f, cellSize + 0.3f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun BarcodeView(
    data: String,
    modifier: Modifier = Modifier,
    color: Color = Color.Black,
    backgroundColor: Color = Color.White
) {
    Box(
        modifier = modifier
            .background(backgroundColor)
            .fillMaxWidth()
            .height(70.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val widthPx = size.width
            val heightPx = size.height
            val barCount = 101
            val barWidth = widthPx / barCount

            // Background
            drawRect(color = backgroundColor)

            val hash = data.hashCode()
            for (i in 0 until barCount) {
                val isFinder = i < 4 || i > barCount - 5 || i == barCount / 2
                val isFilled = if (isFinder) {
                    i % 2 == 0
                } else {
                    val barHash = abs((i * 47) xor hash)
                    barHash % 2 == 0
                }

                if (isFilled) {
                    drawRect(
                        color = color,
                        topLeft = Offset(i * barWidth, 0f),
                        size = Size(barWidth + 0.2f, heightPx)
                    )
                }
            }
        }
    }
}
