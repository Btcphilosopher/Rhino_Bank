package com.example.ui.wallet

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.TicketRepository
import com.example.database.AppDatabase
import com.example.model.Ticket
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class TicketViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    private val repository = TicketRepository(database.ticketDao())

    val rawTickets = repository.allTickets

    // Filter states
    val selectedCategory = MutableStateFlow("全部")
    val searchQuery = MutableStateFlow("")
    val selectedCalendarDate = MutableStateFlow("")

    // Calendar navigation states (Current Year and Month)
    val calendarYear = MutableStateFlow(2026)
    val calendarMonth = MutableStateFlow(9) // September is 9 (1-indexed for simple UI)

    init {
        viewModelScope.launch {
            // Prepopulate database with mock tickets if empty
            repository.prepopulateIfEmpty()
            
            // Set default selected calendar date to today (relative to current system)
            val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            selectedCalendarDate.value = todayStr
            
            // Set calendar month to today's month
            val cal = Calendar.getInstance()
            calendarYear.value = cal.get(Calendar.YEAR)
            calendarMonth.value = cal.get(Calendar.MONTH) + 1
        }
    }

    // Combined list of tickets after searching and filtering by category
    val filteredTickets: StateFlow<List<Ticket>> = combine(
        rawTickets,
        selectedCategory,
        searchQuery
    ) { ticketList, category, query ->
        var list = ticketList

        // 1. Category Filter
        if (category != "全部") {
            list = list.filter { it.category == category }
        }

        // 2. Search Query Filter
        if (query.isNotBlank()) {
            val q = query.trim().lowercase()
            list = list.filter {
                it.title.lowercase().contains(q) ||
                it.location.lowercase().contains(q) ||
                it.ticketNo.lowercase().contains(q) ||
                it.orderNo.lowercase().contains(q) ||
                it.type.lowercase().contains(q) ||
                it.seat.lowercase().contains(q) ||
                it.notes.lowercase().contains(q)
            }
        }

        list
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Tickets on the selected calendar date
    val ticketsOnSelectedDate: StateFlow<List<Ticket>> = combine(
        rawTickets,
        selectedCalendarDate
    ) { ticketList, date ->
        if (date.isBlank()) emptyList()
        else ticketList.filter { it.date == date }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // All dates that have tickets (to show dots on calendar)
    val ticketDates: StateFlow<Set<String>> = rawTickets.map { list ->
        list.map { it.date }.toSet()
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptySet()
    )

    fun addTicket(ticket: Ticket) {
        viewModelScope.launch {
            repository.insertTicket(ticket)
        }
    }

    fun updateTicket(ticket: Ticket) {
        viewModelScope.launch {
            repository.updateTicket(ticket)
        }
    }

    fun deleteTicket(ticket: Ticket) {
        viewModelScope.launch {
            repository.deleteTicket(ticket)
        }
    }

    fun toggleTicketUsed(ticket: Ticket) {
        viewModelScope.launch {
            repository.updateTicket(ticket.copy(isUsed = !ticket.isUsed))
        }
    }

    fun selectCategory(category: String) {
        selectedCategory.value = category
    }

    fun updateSearchQuery(query: String) {
        searchQuery.value = query
    }

    fun selectCalendarDate(date: String) {
        selectedCalendarDate.value = date
    }

    fun adjustCalendarMonth(offset: Int) {
        var newMonth = calendarMonth.value + offset
        var newYear = calendarYear.value
        if (newMonth > 12) {
            newMonth = 1
            newYear++
        } else if (newMonth < 1) {
            newMonth = 12
            newYear--
        }
        calendarMonth.value = newMonth
        calendarYear.value = newYear
    }
}
