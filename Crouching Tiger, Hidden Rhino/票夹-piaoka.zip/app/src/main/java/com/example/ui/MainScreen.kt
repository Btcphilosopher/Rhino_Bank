package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.ConfirmationNumber
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.Ticket
import com.example.ui.calendar.CalendarTab
import com.example.ui.settings.MeTab
import com.example.ui.ticket.AddTicketScreen
import com.example.ui.ticket.TicketDetailScreen
import com.example.ui.wallet.WalletTab
import com.example.ui.wallet.TicketViewModel

enum class MainTab {
    WALLET,
    CALENDAR,
    ME
}

@Composable
fun MainScreen(
    viewModel: TicketViewModel = viewModel(),
    modifier: Modifier = Modifier
) {
    var currentTab by remember { mutableStateOf(MainTab.WALLET) }
    var activeDetailTicket by remember { mutableStateOf<Ticket?>(null) }
    var isAddingTicket by remember { mutableStateOf(false) }

    // Intercept back presses
    if (activeDetailTicket != null) {
        BackHandler {
            activeDetailTicket = null
        }
    } else if (isAddingTicket) {
        BackHandler {
            isAddingTicket = false
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        Scaffold(
            bottomBar = {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 0.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding() // Satisfy technical safety guidelines
                        .testTag("bottom_nav_bar")
                ) {
                    // WALLET Tab
                    NavigationBarItem(
                        selected = currentTab == MainTab.WALLET,
                        onClick = { currentTab = MainTab.WALLET },
                        icon = {
                            Icon(
                                imageVector = if (currentTab == MainTab.WALLET) Icons.Filled.ConfirmationNumber else Icons.Outlined.ConfirmationNumber,
                                contentDescription = "票夹"
                            )
                        },
                        label = { Text("票夹", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = Color.Transparent
                        ),
                        modifier = Modifier.testTag("tab_wallet")
                    )

                    // CALENDAR Tab
                    NavigationBarItem(
                        selected = currentTab == MainTab.CALENDAR,
                        onClick = { currentTab = MainTab.CALENDAR },
                        icon = {
                            Icon(
                                imageVector = if (currentTab == MainTab.CALENDAR) Icons.Filled.CalendarMonth else Icons.Outlined.CalendarMonth,
                                contentDescription = "日历"
                            )
                        },
                        label = { Text("日历", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = Color.Transparent
                        ),
                        modifier = Modifier.testTag("tab_calendar")
                    )

                    // ME Tab
                    NavigationBarItem(
                        selected = currentTab == MainTab.ME,
                        onClick = { currentTab = MainTab.ME },
                        icon = {
                            Icon(
                                imageVector = if (currentTab == MainTab.ME) Icons.Filled.Person else Icons.Outlined.Person,
                                contentDescription = "我的"
                            )
                        },
                        label = { Text("我的", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = Color.Transparent
                        ),
                        modifier = Modifier.testTag("tab_me")
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                // Smooth transition
                AnimatedContent(
                    targetState = currentTab,
                    transitionSpec = {
                        fadeIn(tween(220)) togetherWith fadeOut(tween(220))
                    },
                    label = "tab_switch"
                ) { targetTab ->
                    when (targetTab) {
                        MainTab.WALLET -> {
                            WalletTab(
                                viewModel = viewModel,
                                onAddTicketClick = { isAddingTicket = true },
                                onTicketClick = { ticket -> activeDetailTicket = ticket }
                            )
                        }
                        MainTab.CALENDAR -> {
                            CalendarTab(
                                viewModel = viewModel,
                                onTicketClick = { ticket -> activeDetailTicket = ticket }
                            )
                        }
                        MainTab.ME -> {
                            MeTab()
                        }
                    }
                }
            }
        }

        // FULL SCREEN OVERLAYS (No complex navigation backstack bugs, extremely solid!)
        
        // 1. Full Screen Adding Overlay
        AnimatedVisibility(
            visible = isAddingTicket,
            enter = fadeIn(tween(250)),
            exit = fadeOut(tween(250))
        ) {
            AddTicketScreen(
                onBack = { isAddingTicket = false },
                onAddSuccess = { newTicket ->
                    viewModel.addTicket(newTicket)
                    isAddingTicket = false
                }
            )
        }

        // 2. Full Screen Detail Overlay
        AnimatedVisibility(
            visible = activeDetailTicket != null,
            enter = fadeIn(tween(250)),
            exit = fadeOut(tween(250))
        ) {
            val ticketToShow = activeDetailTicket
            if (ticketToShow != null) {
                // Query fresh ticket status or use current matching ID in model list to avoid stale properties
                val ticketList by viewModel.rawTickets.collectAsState(initial = emptyList())
                val freshTicket = ticketList.find { it.id == ticketToShow.id } ?: ticketToShow

                TicketDetailScreen(
                    ticket = freshTicket,
                    onBack = { activeDetailTicket = null },
                    onDelete = { ticketToDelete ->
                        viewModel.deleteTicket(ticketToDelete)
                        activeDetailTicket = null
                    },
                    onToggleUsed = { ticketToToggle ->
                        viewModel.toggleTicketUsed(ticketToToggle)
                    }
                )
            }
        }
    }
}
