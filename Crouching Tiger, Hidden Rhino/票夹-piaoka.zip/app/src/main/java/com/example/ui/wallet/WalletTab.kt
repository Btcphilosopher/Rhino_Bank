package com.example.ui.wallet

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AirplaneTicket
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.DirectionsTransit
import androidx.compose.material.icons.filled.EventNote
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LocalActivity
import androidx.compose.material.icons.filled.LocalMovie
import androidx.compose.material.icons.filled.Museum
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Ticket
import com.example.ui.theme.BlackPrimary
import com.example.ui.theme.GrayBg
import com.example.ui.theme.PureWhite
import com.example.ui.ticket.getTicketColor
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun WalletTab(
    viewModel: TicketViewModel,
    onAddTicketClick: () -> Unit,
    onTicketClick: (Ticket) -> Unit,
    modifier: Modifier = Modifier
) {
    val tickets by viewModel.filteredTickets.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()

    // Separate active tickets from historical tickets
    // Active: not marked isUsed AND ticket date is >= today (or simply not isUsed)
    val activeTickets = tickets.filter { !it.isUsed }
    val historyTickets = tickets.filter { it.isUsed }

    // List of categories requested
    val categories = listOf("全部", "交通", "电影", "演出", "体育", "景区", "展览", "其他")

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "票夹",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onBackground,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "把所有票，都放进一个 App。",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }

                IconButton(
                    onClick = onAddTicketClick,
                    modifier = Modifier
                        .size(44.dp)
                        .background(MaterialTheme.colorScheme.primary, CircleShape)
                        .testTag("add_ticket_fab")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "添加电子票",
                        tint = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.updateSearchQuery(it) },
                placeholder = { Text("搜索电影、演唱会、高铁、场馆...", fontSize = 14.sp) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "搜索",
                        tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
                        modifier = Modifier.size(20.dp)
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 6.dp)
                    .testTag("search_field"),
                shape = RoundedCornerShape(16.dp),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.08f),
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )

            // Category Horizontal Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { category ->
                    val isSelected = selectedCategory == category
                    val chipBg = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface
                    val chipText = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    val chipBorder = if (isSelected) Color.Transparent else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.06f)

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(chipBg)
                            .clickable { viewModel.selectCategory(category) }
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                            .testTag("category_chip_$category")
                    ) {
                        Text(
                            text = category,
                            color = chipText,
                            fontSize = 13.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }

            // Main Ticket List
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Empty State if no tickets found
                if (activeTickets.isEmpty() && historyTickets.isEmpty()) {
                    item {
                        EmptyWalletState()
                    }
                }

                // 1. "即将使用" Section
                if (activeTickets.isNotEmpty()) {
                    item {
                        Text(
                            text = "即将使用",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.onBackground,
                            modifier = Modifier.padding(horizontal = 20.dp, top = 8.dp)
                        )
                    }

                    // Group active tickets by relative date
                    val groupedActive = activeTickets.groupBy { formatRelativeDate(it.date) }

                    groupedActive.forEach { (relativeDate, dateTickets) ->
                        item {
                            Text(
                                text = relativeDate,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
                                modifier = Modifier.padding(horizontal = 20.dp, top = 8.dp, bottom = 4.dp)
                            )
                        }

                        items(dateTickets) { ticket ->
                            TicketItemCard(
                                ticket = ticket,
                                onClick = { onTicketClick(ticket) },
                                modifier = Modifier
                                    .padding(horizontal = 20.dp)
                                    .testTag("ticket_card_${ticket.id}")
                            )
                        }
                    }
                }

                // 2. "历史票据" Section
                if (historyTickets.isNotEmpty()) {
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp, top = 16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.History,
                                contentDescription = "历史",
                                tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "历史票证",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Black,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f)
                            )
                        }
                    }

                    items(historyTickets) { ticket ->
                        TicketItemCard(
                            ticket = ticket,
                            onClick = { onTicketClick(ticket) },
                            modifier = Modifier
                                .padding(horizontal = 20.dp)
                                .testTag("ticket_card_history_${ticket.id}")
                        )
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(80.dp)) // Leave space for bottom nav bar
                }
            }
        }
    }
}

// EMPTY STATE VIEW
@Composable
fun EmptyWalletState() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 80.dp, horizontal = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.ConfirmationNumber,
            contentDescription = "暂无门票",
            tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.1f),
            modifier = Modifier.size(100.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "票夹空空如也",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "点击右上角 ＋ 扫描或导入你的电子门票、高铁车票、机票等",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.3f),
            textAlign = TextAlign.Center,
            lineHeight = 18.sp
        )
    }
}

// TICKET CARD COMPONENT WITH TICKET HOLES AND DASHED COUPON DIVISION
@Composable
fun TicketItemCard(
    ticket: Ticket,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val brandColor = getTicketColor(ticket.type)
    val cardBg = MaterialTheme.colorScheme.surface

    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(IntrinsicSize.Min)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = cardBg),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth()) {
            // Left Accent Color Band
            Box(
                modifier = Modifier
                    .width(6.dp)
                    .fillMaxHeight()
                    .background(if (ticket.isUsed) Color.LightGray else brandColor)
            )

            // Core Content
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(18.dp)
            ) {
                // Category Label
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = ticket.type,
                        fontSize = 11.sp,
                        color = if (ticket.isUsed) Color.Gray else brandColor,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )

                    Icon(
                        imageVector = getCategoryIcon(ticket.category),
                        contentDescription = null,
                        tint = if (ticket.isUsed) Color.LightGray else brandColor.copy(alpha = 0.6f),
                        modifier = Modifier.size(16.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Title
                Text(
                    text = ticket.title,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (ticket.isUsed) Color.Gray else MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Sub Info Row 1: Location
                Text(
                    text = ticket.location,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Sub Info Row 2: Date, Time & Seat
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "${ticket.date}  ${ticket.time}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (ticket.isUsed) Color.Gray else MaterialTheme.colorScheme.onSurface
                    )

                    Text(
                        text = ticket.seat,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (ticket.isUsed) Color.LightGray else brandColor
                    )
                }
            }

            // Dashed coupon division line with ticket-punched semicircle holes
            Box(
                modifier = Modifier
                    .width(20.dp)
                    .fillMaxHeight()
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxHeight().width(1.dp)) {
                    val pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                    drawLine(
                        color = Color.LightGray.copy(alpha = 0.6f),
                        start = Offset(0f, 0f),
                        end = Offset(0f, size.height),
                        pathEffect = pathEffect,
                        strokeWidth = 2f
                    )
                }
            }

            // Right "Show Ticket" coupon card segment
            Box(
                modifier = Modifier
                    .width(84.dp)
                    .fillMaxHeight()
                    .background(if (ticket.isUsed) Color.White.copy(alpha = 0.05f) else brandColor.copy(alpha = 0.05f))
                    .clickable(onClick = onClick)
                    .padding(horizontal = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (ticket.isUsed) "查看历史" else "出示电子票",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (ticket.isUsed) Color.Gray else brandColor,
                    textAlign = TextAlign.Center,
                    lineHeight = 16.sp
                )
            }
        }
    }
}

fun getCategoryIcon(category: String): ImageVector {
    return when (category) {
        "电影" -> Icons.Default.LocalMovie
        "演出" -> Icons.Default.LocalActivity
        "交通" -> Icons.Default.DirectionsTransit
        "体育" -> Icons.Default.SportsSoccer
        "景区" -> Icons.Default.AirplaneTicket
        "展览" -> Icons.Default.Museum
        else -> Icons.Default.ConfirmationNumber
    }
}

// Relative date helper mapping 2026-09-18 as "今天"
fun formatRelativeDate(dateStr: String): String {
    return try {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val ticketDate = sdf.parse(dateStr) ?: return dateStr

        // Parse relative to 2026-09-18
        val baseCal = Calendar.getInstance().apply {
            set(Calendar.YEAR, 2026)
            set(Calendar.MONTH, Calendar.SEPTEMBER)
            set(Calendar.DAY_OF_MONTH, 18)
        }
        val baseDateStr = sdf.format(baseCal.time)

        if (dateStr == baseDateStr) {
            return "今天  9月18日"
        }

        // Check tomorrow (relative to Sept 18)
        baseCal.add(Calendar.DAY_OF_MONTH, 1)
        val tomorrowStr = sdf.format(baseCal.time)
        if (dateStr == tomorrowStr) {
            return "明天  9月19日"
        }

        // Check day after tomorrow (Saturday, Sept 20)
        baseCal.add(Calendar.DAY_OF_MONTH, 1)
        val afterTomorrowStr = sdf.format(baseCal.time)
        if (dateStr == afterTomorrowStr) {
            return "周六  9月20日"
        }

        // Otherwise format as standard "M月d日"
        val outputSdf = SimpleDateFormat("M月d日", Locale.getDefault())
        outputSdf.format(ticketDate)
    } catch (e: Exception) {
        dateStr
    }
}
