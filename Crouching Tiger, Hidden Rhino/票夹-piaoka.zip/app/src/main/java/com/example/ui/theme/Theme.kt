package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = PureWhite,
    secondary = GrayLight,
    background = BlackPrimary,
    surface = BlackSecondary,
    onPrimary = BlackPrimary,
    onSecondary = PureWhite,
    onBackground = PureWhite,
    onSurface = PureWhite,
    error = AccentRed
)

private val LightColorScheme = lightColorScheme(
    primary = BlackPrimary,
    secondary = BlackSecondary,
    background = GrayBg,
    surface = PureWhite,
    onPrimary = PureWhite,
    onSecondary = BlackPrimary,
    onBackground = BlackPrimary,
    onSurface = BlackPrimary,
    error = AccentRed
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
