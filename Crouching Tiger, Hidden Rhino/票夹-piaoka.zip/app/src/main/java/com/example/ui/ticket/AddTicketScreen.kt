package com.example.ui.ticket

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Ticket
import com.example.ui.theme.BlackPrimary
import com.example.ui.theme.BlackSecondary
import com.example.ui.theme.GrayBg
import com.example.ui.theme.GrayDark
import com.example.ui.theme.GrayLight
import com.example.ui.theme.PureWhite
import com.example.ui.theme.TicketColorConcert
import com.example.ui.theme.TicketColorFlight
import com.example.ui.theme.TicketColorMovie
import com.example.ui.theme.TicketColorOther
import com.example.ui.theme.TicketColorScenic
import com.example.ui.theme.TicketColorShow
import com.example.ui.theme.TicketColorTransit
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

enum class AddMode {
    CHOOSE, // 首页选择加票方式
    SCAN,   // 扫码添加
    ALBUM,  // 从相册添加
    MANUAL  // 手动输入
}

@Composable
fun AddTicketScreen(
    onBack: () -> Unit,
    onAddSuccess: (Ticket) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var currentMode by remember { mutableStateOf(AddMode.CHOOSE) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        when (currentMode) {
            AddMode.CHOOSE -> {
                ChooseAddModeView(
                    onBack = onBack,
                    onSelectScan = { currentMode = AddMode.SCAN },
                    onSelectAlbum = { currentMode = AddMode.ALBUM },
                    onSelectManual = { currentMode = AddMode.MANUAL }
                )
            }
            AddMode.SCAN -> {
                ScanView(
                    onBack = { currentMode = AddMode.CHOOSE },
                    onScanSuccess = { ticket ->
                        onAddSuccess(ticket)
                        Toast.makeText(context, "扫码添加成功！已放入票夹", Toast.LENGTH_SHORT).show()
                    }
                )
            }
            AddMode.ALBUM -> {
                AlbumView(
                    onBack = { currentMode = AddMode.CHOOSE },
                    onImportSuccess = { ticket ->
                        onAddSuccess(ticket)
                        Toast.makeText(context, "相册图片票据解析并添加成功！", Toast.LENGTH_SHORT).show()
                    }
                )
            }
            AddMode.MANUAL -> {
                ManualInputView(
                    onBack = { currentMode = AddMode.CHOOSE },
                    onSave = { ticket ->
                        onAddSuccess(ticket)
                        Toast.makeText(context, "手动保存成功！", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }
    }
}

@Composable
fun ChooseAddModeView(
    onBack: () -> Unit,
    onSelectScan: () -> Unit,
    onSelectAlbum: () -> Unit,
    onSelectManual: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(WindowInsets.safeDrawing.asPaddingValues())
    ) {
        // App bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack, modifier = Modifier.testTag("add_back_button")) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "返回",
                    tint = MaterialTheme.colorScheme.onBackground
                )
            }
            Text(
                text = "添加电子票",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(start = 8.dp)
            )
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 24.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "选择电子票添加方式",
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                modifier = Modifier.padding(bottom = 12.dp)
            )

            // Scan card
            AddModeOptionCard(
                title = "扫码添加",
                subtitle = "扫描票纸、屏幕上的二维码或条形码",
                icon = Icons.Default.QrCodeScanner,
                color = BlackPrimary,
                onClick = onSelectScan,
                modifier = Modifier.testTag("option_scan")
            )

            // Album card
            AddModeOptionCard(
                title = "从相册导入",
                subtitle = "解析包含电子票二维码的截图或照片",
                icon = Icons.Default.PhotoLibrary,
                color = TicketColorMovie,
                onClick = onSelectAlbum,
                modifier = Modifier.testTag("option_album")
            )

            // Manual card
            AddModeOptionCard(
                title = "手动填写添加",
                subtitle = "录入票名、日期、场馆等信息生成数字票卡",
                icon = Icons.Default.UploadFile,
                color = TicketColorTransit,
                onClick = onSelectManual,
                modifier = Modifier.testTag("option_manual")
            )

            Spacer(modifier = Modifier.weight(1f))

            // Policy Disclaimer Note
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.onBackground.copy(alpha = 0.04f))
                    .padding(14.dp),
                verticalAlignment = Alignment.Top
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = "说明",
                    tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
                    modifier = Modifier
                        .size(16.dp)
                        .offset(y = 1.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "票务数据仅保存在本地安全数据库中，不经过任何云端服务器，保障隐私安全。",
                    fontSize = 11.sp,
                    lineHeight = 16.sp,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f)
                )
            }
        }
    }
}

@Composable
fun AddModeOptionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(110.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(color.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = color,
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = title,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = subtitle,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                    lineHeight = 18.sp
                )
            }
        }
    }
}

// SIMULATED SCAN VIEW
@Composable
fun ScanView(
    onBack: () -> Unit,
    onScanSuccess: (Ticket) -> Unit
) {
    var isScanning by remember { mutableStateOf(true) }
    var scanTargetFound by remember { mutableStateOf<Ticket?>(null) }
    var showErrorToast by remember { mutableStateOf(false) }

    // Floating horizontal laser line animation
    val infiniteTransition = rememberInfiniteTransition(label = "laser")
    val laserOffsetFraction by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laser"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BlackPrimary)
            .padding(WindowInsets.safeDrawing.asPaddingValues())
    ) {
        // App bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "返回",
                    tint = PureWhite
                )
            }
            Text(
                text = "扫码添加",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = PureWhite,
                modifier = Modifier.padding(start = 8.dp)
            )
        }

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            if (isScanning) {
                // Simulated Camera Feed & Scan overlay
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxSize()
                ) {
                    Text(
                        text = "将票面二维码 / 条形码放入框内即可自动扫描",
                        color = PureWhite.copy(alpha = 0.6f),
                        fontSize = 13.sp,
                        modifier = Modifier.padding(bottom = 24.dp)
                    )

                    // Square Scanner Frame
                    Box(
                        modifier = Modifier
                            .size(260.dp)
                            .border(BorderStroke(2.dp, PureWhite.copy(alpha = 0.3f)), RoundedCornerShape(16.dp))
                            .clip(RoundedCornerShape(16.dp))
                            .clipToBounds()
                    ) {
                        // 4 corner marks
                        val cornerColor = TicketColorMovie
                        Box(modifier = Modifier.align(Alignment.TopStart).padding(8.dp).size(20.dp).border(BorderStroke(3.dp, cornerColor), RoundedCornerShape(topStart = 4.dp)))
                        Box(modifier = Modifier.align(Alignment.TopEnd).padding(8.dp).size(20.dp).border(BorderStroke(3.dp, cornerColor), RoundedCornerShape(topEnd = 4.dp)))
                        Box(modifier = Modifier.align(Alignment.BottomStart).padding(8.dp).size(20.dp).border(BorderStroke(3.dp, cornerColor), RoundedCornerShape(bottomStart = 4.dp)))
                        Box(modifier = Modifier.align(Alignment.BottomEnd).padding(8.dp).size(20.dp).border(BorderStroke(3.dp, cornerColor), RoundedCornerShape(bottomEnd = 4.dp)))

                        // Simulated QR Image in the background (very dim)
                        Box(
                            modifier = Modifier
                                .size(120.dp)
                                .align(Alignment.Center)
                                .background(PureWhite.copy(alpha = 0.05f))
                        ) {
                            QRCodeView(
                                data = "simulated_scannable_data",
                                color = PureWhite.copy(alpha = 0.15f),
                                backgroundColor = Color.Transparent,
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        // Laser line
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(3.dp)
                                .offset { IntOffset(0, (260.dp.toPx() * laserOffsetFraction).toInt()) }
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(
                                            Color.Transparent,
                                            TicketColorMovie,
                                            TicketColorMovie,
                                            Color.Transparent
                                        )
                                    )
                                )
                        )
                    }

                    Spacer(modifier = Modifier.height(40.dp))

                    Text(
                        text = "模拟演示：点击下方示例模拟摄像头成功扫码",
                        color = PureWhite.copy(alpha = 0.4f),
                        fontSize = 12.sp,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    // Quick simulation buttons representing real tickets!
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                val t = Ticket(
                                    type = "电影票",
                                    category = "电影",
                                    title = "《黑神话：悟空》IMAX 点映首映礼",
                                    date = "2026-09-18",
                                    time = "20:00",
                                    timestamp = parseDateTimeToTimestamp("2026-09-18", "20:00"),
                                    location = "上海大剧院 影音大厅",
                                    seat = "3排16座",
                                    ticketNo = "99882231",
                                    orderNo = "ORD202609189912",
                                    qrCodeData = "piaoka://ticket/99882231",
                                    notes = "凭此二维码检票换取首映纪念卡"
                                )
                                scanTargetFound = t
                                isScanning = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.15f)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("扫电影票", color = PureWhite, fontSize = 12.sp)
                        }

                        Button(
                            onClick = {
                                val t = Ticket(
                                    type = "演唱会门票",
                                    category = "演出",
                                    title = "陈奕迅 Fear and Dreams 演唱会",
                                    date = "2026-10-12",
                                    time = "19:30",
                                    timestamp = parseDateTimeToTimestamp("2026-10-12", "19:30"),
                                    location = "梅赛德斯-奔驰文化中心",
                                    seat = "内场 5区 3排2座",
                                    ticketNo = "CYX101299",
                                    orderNo = "CYX_ORDER_1992",
                                    qrCodeData = "piaoka://concert/eason/cyx101299",
                                    notes = "请在19:15前检票入场"
                                )
                                scanTargetFound = t
                                isScanning = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.15f)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("扫演唱会", color = PureWhite, fontSize = 12.sp)
                        }

                        Button(
                            onClick = {
                                val t = Ticket(
                                    type = "机票",
                                    category = "交通",
                                    title = "北京大兴 PKX → 深圳宝安 SZX",
                                    date = "2026-09-21",
                                    time = "13:20",
                                    timestamp = parseDateTimeToTimestamp("2026-09-21", "13:20"),
                                    location = "大兴国际机场 T1",
                                    seat = "32A (靠窗)",
                                    ticketNo = "CA1314-9981",
                                    orderNo = "AIRORD9987A",
                                    qrCodeData = "BOARDING_PASS_CA1314_20260921",
                                    notes = "登机口 A15，12:40 开始登机"
                                )
                                scanTargetFound = t
                                isScanning = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.15f)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("扫机票", color = PureWhite, fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            showErrorToast = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
                        modifier = Modifier.padding(top = 8.dp)
                    ) {
                        Text("测试扫码识别失败提示", color = Color.LightGray, fontSize = 11.sp)
                    }

                    if (showErrorToast) {
                        Box(
                            modifier = Modifier
                                .padding(top = 16.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.Red.copy(alpha = 0.2f))
                                .padding(horizontal = 16.dp, vertical = 8.dp)
                        ) {
                            Text(
                                "无法自动读取票面信息，请手动填写",
                                color = PureWhite,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            } else {
                // Showing Scanner parser successful screen
                val parsedTicket = scanTargetFound
                if (parsedTicket != null) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(TicketColorTransit)
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Done,
                                contentDescription = "成功",
                                tint = PureWhite,
                                modifier = Modifier.size(40.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        Text(
                            text = "扫码读取成功！",
                            color = PureWhite,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black
                        )

                        Spacer(modifier = Modifier.height(32.dp))

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.1f))
                        ) {
                            Column(modifier = Modifier.padding(20.dp)) {
                                Text("智能识别结果：", color = Color.LightGray, fontSize = 12.sp)
                                Spacer(modifier = Modifier.height(12.dp))

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("票种", color = Color.Gray, fontSize = 14.sp)
                                    Text(parsedTicket.type, color = PureWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("名称", color = Color.Gray, fontSize = 14.sp)
                                    Text(parsedTicket.title, color = PureWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("日期", color = Color.Gray, fontSize = 14.sp)
                                    Text("${parsedTicket.date} ${parsedTicket.time}", color = PureWhite, fontSize = 14.sp)
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("场馆", color = Color.Gray, fontSize = 14.sp)
                                    Text(parsedTicket.location, color = PureWhite, fontSize = 14.sp)
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("席位", color = Color.Gray, fontSize = 14.sp)
                                    Text(parsedTicket.seat, color = PureWhite, fontSize = 14.sp)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(40.dp))

                        Button(
                            onClick = { onScanSuccess(parsedTicket) },
                            colors = ButtonDefaults.buttonColors(containerColor = TicketColorTransit),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                        ) {
                            Text("一键存入票夹", color = PureWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                isScanning = true
                                scanTargetFound = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("重新扫描", color = Color.LightGray)
                        }
                    }
                }
            }
        }
    }
}

// SIMULATED ALBUM SCREEN (IMAGING SELECTION & SIMULATED LOCAL OCR)
@Composable
fun AlbumView(
    onBack: () -> Unit,
    onImportSuccess: (Ticket) -> Unit
) {
    var isReading by remember { mutableStateOf(false) }
    var readingProgressText by remember { mutableStateOf("") }
    var parsedResult by remember { mutableStateOf<Ticket?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(WindowInsets.safeDrawing.asPaddingValues())
    ) {
        // App bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "返回",
                    tint = MaterialTheme.colorScheme.onBackground
                )
            }
            Text(
                text = "从相册导入电子票",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(start = 8.dp)
            )
        }

        if (!isReading && parsedResult == null) {
            // Photos Grid
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(24.dp)
            ) {
                Text(
                    text = "选择相册中包含电子票或二维码的截图",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                    modifier = Modifier.padding(bottom = 20.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Album Item 1: Concert Screenshot
                    AlbumItemCard(
                        category = "演唱会截图",
                        title = "周杰伦大麦截图",
                        color = TicketColorConcert,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            isReading = true
                            readingProgressText = "正在扫描图片寻找二维码..."
                            val t = Ticket(
                                type = "演唱会门票",
                                category = "演出",
                                title = "周杰伦 2026 世界巡回演唱会",
                                date = "2026-09-25",
                                time = "19:30",
                                timestamp = parseDateTimeToTimestamp("2026-09-25", "19:30"),
                                location = "国家体育场 (鸟巢)",
                                seat = "看台 A区12排18座",
                                ticketNo = "ZJL20260925991",
                                orderNo = "OD888777123",
                                qrCodeData = "jay_world_tour_2026_nest_a12_18",
                                notes = "模拟相册识别：通过本地神经解析模型自动抓取周董鸟巢演唱会",
                                reminderMinutes = 120
                            )
                            parsedResult = t
                        }
                    )

                    // Album Item 2: Train Screenshot
                    AlbumItemCard(
                        category = "高铁票截图",
                        title = "12306车票截图",
                        color = TicketColorTransit,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            isReading = true
                            readingProgressText = "正在扫描图片寻找二维码..."
                            val t = Ticket(
                                type = "高铁票",
                                category = "交通",
                                title = "上海虹桥 → 北京南",
                                date = "2026-09-20",
                                time = "09:15",
                                timestamp = parseDateTimeToTimestamp("2026-09-20", "09:15"),
                                location = "上海虹桥站",
                                seat = "08车 12A",
                                ticketNo = "G1234-SHBJ",
                                orderNo = "TR777888992",
                                qrCodeData = "G1234 上海虹桥-北京南 202609200915 08车12A",
                                notes = "模拟相册识别：成功提取 12306 订单条形码与车次信息",
                                reminderMinutes = 60
                            )
                            parsedResult = t
                        }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Album Item 3: Movie Ticket
                    AlbumItemCard(
                        category = "电影截图",
                        title = "淘票票核销码",
                        color = TicketColorMovie,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            isReading = true
                            readingProgressText = "正在扫描图片寻找二维码..."
                            val t = Ticket(
                                type = "电影票",
                                category = "电影",
                                title = "《星海计划》影票",
                                date = "2026-09-18",
                                time = "19:30",
                                timestamp = parseDateTimeToTimestamp("2026-09-18", "19:30"),
                                location = "万达影城 北京CBD店",
                                seat = "5排6座, 5排7座",
                                ticketNo = "9182374981",
                                orderNo = "20260918001234",
                                qrCodeData = "piaoka://ticket/movie/xinghai/9182374981",
                                notes = "模拟相册识别：成功提取万达影城取票核销码",
                                reminderMinutes = 30
                            )
                            parsedResult = t
                        }
                    )

                    // Fake select local photo
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .height(140.dp)
                            .clickable {
                                Toast
                                    .makeText(
                                        context,
                                        "由于沙箱限制，请点击预置的高保真电子票截图进行导入演示",
                                        Toast.LENGTH_LONG
                                    )
                                    .show()
                            },
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.03f)),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.onBackground.copy(alpha = 0.08f))
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.CameraAlt,
                                contentDescription = "打开相机",
                                tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                "打开本机相册",
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }

        // Reading animation and success view
        if (isReading) {
            val result = parsedResult
            LaunchedEffect(key1 = true) {
                delay(1200)
                readingProgressText = "正在运行本地深度 OCR 字符识别..."
                delay(1200)
                readingProgressText = "已检测到票面：${result?.title}！"
                delay(800)
                isReading = false
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.05f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.QrCodeScanner,
                        contentDescription = "OCR",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(48.dp)
                    )
                }

                Spacer(modifier = Modifier.height(32.dp))

                Text(
                    text = readingProgressText,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.onBackground,
                    textAlign = TextAlign.Center,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(horizontal = 24.dp)
                )
            }
        } else if (parsedResult != null && !isReading) {
            val result = parsedResult!!
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(24.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.Done,
                    contentDescription = "成功",
                    tint = TicketColorTransit,
                    modifier = Modifier
                        .size(60.dp)
                        .background(TicketColorTransit.copy(alpha = 0.1f), CircleShape)
                        .padding(12.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "AI 智能识别完成",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Spacer(modifier = Modifier.height(24.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = "电子票元数据",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        DetailRow("票种", result.type)
                        DetailRow("名称", result.title)
                        DetailRow("时间", "${result.date} ${result.time}")
                        DetailRow("场馆", result.location)
                        DetailRow("座位", result.seat)
                        DetailRow("票号", result.ticketNo)
                    }
                }

                Spacer(modifier = Modifier.height(40.dp))

                Button(
                    onClick = { onImportSuccess(result) },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                ) {
                    Text("导入电子票夹", color = PureWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = { parsedResult = null },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("重新选择", color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f))
                }
            }
        }
    }
}

@Composable
fun AlbumItemCard(
    category: String,
    title: String,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .height(140.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(color.copy(alpha = 0.15f))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = category,
                    color = color,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Column {
                Text(
                    text = title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "点击模拟导入...",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                )
            }
        }
    }
}

@Composable
fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
        Text(text = value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
    }
}

// MANUAL FORM INPUT VIEW
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManualInputView(
    onBack: () -> Unit,
    onSave: (Ticket) -> Unit
) {
    var ticketType by remember { mutableStateOf("电影票") }
    var title by remember { mutableStateOf("") }
    var date by remember { mutableStateOf("2026-09-18") }
    var time by remember { mutableStateOf("19:30") }
    var location by remember { mutableStateOf("") }
    var seat by remember { mutableStateOf("") }
    var ticketNo by remember { mutableStateOf("") }
    var orderNo by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var reminderMinutes by remember { mutableStateOf(30) } // Default 30 mins

    val ticketTypes = listOf("电影票", "演唱会门票", "音乐节门票", "话剧票", "高铁票", "飞机票", "博物馆门票", "景区门票", "体育比赛门票")
    var expandedDropdown by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(WindowInsets.safeDrawing.asPaddingValues())
    ) {
        // App bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "返回",
                    tint = MaterialTheme.colorScheme.onBackground
                )
            }
            Text(
                text = "手动录入电子票",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(start = 8.dp)
            )
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp)
        ) {
            // Dropdown Selector for Ticket Type
            Box(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = ticketType,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("票务种类") },
                    trailingIcon = {
                        IconButton(onClick = { expandedDropdown = !expandedDropdown }) {
                            Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = "展开")
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { expandedDropdown = true }
                        .testTag("input_type"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.15f)
                    )
                )

                DropdownMenu(
                    expanded = expandedDropdown,
                    onDismissRequest = { expandedDropdown = false },
                    modifier = Modifier.fillMaxWidth(0.8f)
                ) {
                    ticketTypes.forEach { type ->
                        DropdownMenuItem(
                            text = { Text(type) },
                            onClick = {
                                ticketType = type
                                expandedDropdown = false
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Title Input
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("票务名称 (如：周杰伦演唱会)") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_title"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.15f)
                )
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Date & Time Grid
            Row(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = date,
                    onValueChange = { date = it },
                    label = { Text("日期 (YYYY-MM-DD)") },
                    modifier = Modifier
                        .weight(1.2f)
                        .testTag("input_date"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.15f)
                    )
                )
                Spacer(modifier = Modifier.width(12.dp))
                OutlinedTextField(
                    value = time,
                    onValueChange = { time = it },
                    label = { Text("时间 (HH:MM)") },
                    modifier = Modifier
                        .weight(0.8f)
                        .testTag("input_time"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.15f)
                    )
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Location
            OutlinedTextField(
                value = location,
                onValueChange = { location = it },
                label = { Text("地点/场馆 (如：国家体育场)") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_location"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.15f)
                )
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Seat
            OutlinedTextField(
                value = seat,
                onValueChange = { seat = it },
                label = { Text("座位 / 席位 (如：5排6座)") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_seat"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.15f)
                )
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Ticket Numbers Grid
            Row(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = ticketNo,
                    onValueChange = { ticketNo = it },
                    label = { Text("票号") },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("input_ticket_no"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.15f)
                    )
                )
                Spacer(modifier = Modifier.width(12.dp))
                OutlinedTextField(
                    value = orderNo,
                    onValueChange = { orderNo = it },
                    label = { Text("订单号 (选填)") },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("input_order_no"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.15f)
                    )
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Notes Input
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("备注说明") },
                modifier = Modifier.fillMaxWidth(),
                maxLines = 3,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.15f)
                )
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Reminder Radio Row
            Text(
                text = "设置出行/开演提醒",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
            )

            val reminderOptions = listOf(
                Pair(-1, "不提醒"),
                Pair(15, "提前15分"),
                Pair(30, "提前30分"),
                Pair(60, "提前1小时"),
                Pair(120, "提前2小时"),
                Pair(1440, "提前1天")
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                // Render as 2 grid rows
                reminderOptions.chunked(3).forEach { rowList ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        rowList.forEach { option ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .clickable { reminderMinutes = option.first }
                                    .padding(vertical = 4.dp)
                            ) {
                                RadioButton(
                                    selected = reminderMinutes == option.first,
                                    onClick = { reminderMinutes = option.first },
                                    colors = RadioButtonDefaults.colors(selectedColor = MaterialTheme.colorScheme.primary)
                                )
                                Text(
                                    text = option.second,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Save Action
            Button(
                onClick = {
                    if (title.isBlank() || location.isBlank()) {
                        Toast.makeText(context, "请务必填写票务名称和地点！", Toast.LENGTH_SHORT).show()
                    } else {
                        val parsedCategory = getCategoryFromType(ticketType)
                        val timestamp = parseDateTimeToTimestamp(date, time)
                        
                        // Fallback unique ticket number if blank
                        val finalTicketNo = if (ticketNo.isBlank()) {
                            Random.nextInt(10000000, 99999999).toString()
                        } else {
                            ticketNo
                        }

                        val mockQR = "piaoka://manual/${parsedCategory}/${finalTicketNo}"

                        val ticket = Ticket(
                            type = ticketType,
                            category = parsedCategory,
                            title = title,
                            date = date,
                            time = time,
                            timestamp = timestamp,
                            location = location,
                            seat = seat,
                            ticketNo = finalTicketNo,
                            orderNo = orderNo,
                            qrCodeData = mockQR,
                            notes = notes,
                            reminderMinutes = reminderMinutes
                        )
                        onSave(ticket)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("save_ticket_button")
            ) {
                Text(
                    text = "保存并放入票夹",
                    color = PureWhite,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(48.dp))
        }
    }
}

private fun getCategoryFromType(type: String): String {
    return when {
        type.contains("电影") -> "电影"
        type.contains("演唱会") || type.contains("音乐节") || type.contains("演出") || type.contains("话剧") -> "演出"
        type.contains("高铁") || type.contains("火车") || type.contains("飞机") || type.contains("机票") || type.contains("客车") -> "交通"
        type.contains("体育") || type.contains("比赛") -> "体育"
        type.contains("景区") || type.contains("乐园") -> "景区"
        type.contains("博物馆") || type.contains("展览") -> "展览"
        else -> "其他"
    }
}

private fun parseDateTimeToTimestamp(dateStr: String, timeStr: String): Long {
    return try {
        val format = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
        val date = format.parse("$dateStr $timeStr")
        date?.time ?: System.currentTimeMillis()
    } catch (e: Exception) {
        System.currentTimeMillis()
    }
}
