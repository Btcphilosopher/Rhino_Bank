package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BlackPrimary = Color(0xFF111111)
val BlackSecondary = Color(0xFF1E1E1E)
val GrayDark = Color(0xFF555555)
val GrayMedium = Color(0xFF888888)
val GrayLight = Color(0xFFE5E5E5)
val GrayBg = Color(0xFFF6F6F8)
val PureWhite = Color(0xFFFFFFFF)
val AccentRed = Color(0xFFE53935)

// Ticket Type Branding Colors
val TicketColorMovie = Color(0xFFFF4757)       // 电影票：珊瑚红
val TicketColorConcert = Color(0xFF70a1ff)     // 演出/演唱会：雅致天蓝/紫
val TicketColorShow = Color(0xFF9b59b6)        // 话剧/音乐会：高级雅紫
val TicketColorTransit = Color(0xFF2ed573)     // 交通（火车）：翡翠绿
val TicketColorFlight = Color(0xFF1e90ff)      // 交通（飞机）：航空蓝
val TicketColorSports = Color(0xFFffa502)      // 体育比赛：活力橙/金
val TicketColorScenic = Color(0xFFff6b81)      // 景区：柔美樱红
val TicketColorExhibition = Color(0xFF2f3542)  // 展览/博物馆：高级石墨灰
val TicketColorOther = Color(0xFF747d8c)       // 其他：经典水泥灰
