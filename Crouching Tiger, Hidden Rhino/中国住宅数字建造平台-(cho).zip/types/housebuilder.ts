/**
 * CHINA RESIDENTIAL DIGITAL TWIN & HOUSEBUILDER OS (CHO)
 * Core Type Definitions & Data Entities
 */

export type ProjectStage = 'planning' | 'design' | 'bim' | 'costing' | 'procurement' | 'construction' | 'inspection' | 'handover' | 'property';

export type UserRole = 
  | 'developer'      // 房地产开发商 / 项目总指挥
  | 'architect'      // 建筑设计院 / 建筑师
  | 'structural'     // 结构工程师
  | 'mep'            // 机电工程师
  | 'cost_engineer'  // 成本造价工程师
  | 'procurement'    // 招采经理
  | 'site_manager'   // 施工经理 / 总包
  | 'subcontractor'  // 专业分包
  | 'supervisor'     // 监理单位
  | 'qa_engineer'    // 质量安全工程师
  | 'property_admin' // 物业公司
  | 'homeowner';     // 住宅业主

export interface ProjectOverview {
  id: string;
  code: string; // 房屋建筑统一项目代码
  name: string;
  city: string;
  district: string;
  coordinates: [number, number]; // [lng, lat]
  status: 'planning' | 'in_construction' | 'topping_out' | 'accepting' | 'delivered' | 'operational';
  totalGFA: number; // 总建筑面积 m²
  residentialGFA: number; // 住宅建筑面积 m²
  commercialGFA: number; // 商业配套 m²
  undergroundGFA: number; // 地下车库 m²
  totalUnits: number; // 总户数
  totalBuildings: number; // 楼栋数
  plotRatio: number; // 容积率
  greeningRate: number; // 绿化率 %
  buildingDensity: number; // 建筑密度 %
  startDate: string;
  plannedCompletionDate: string;
  currentProgressPct: number; // 67.4%
  totalBudget: number; // 亿元
  currentSpent: number;
}

export interface BuildingEntity {
  id: string;
  code: string; // 楼栋统一编码
  name: string; // e.g. "1号楼"
  type: 'high_rise' | 'mid_rise' | 'villa' | 'commercial';
  floorsCount: number; // e.g. 26
  undergroundFloors: number; // e.g. 2
  floorHeight: number; // e.g. 3.0m
  buildingHeight: number; // e.g. 78.0m
  length: number; // m
  width: number; // m
  unitsPerFloor: number; // e.g. 4 (两梯四户)
  totalUnits: number; // e.g. 104
  elevatorsCount: number; // e.g. 2
  stairsCount: number; // e.g. 2
  position: [number, number, number]; // [x, y, z] in community 3D space
  rotation: number; // deg
  status: 'foundation' | 'structure' | 'topping' | 'mep' | 'facade' | 'finishing' | 'completed';
  progressPct: number;
  structureType: 'shear_wall' | 'frame_shear_wall' | 'precast_concrete' | 'steel';
  currentFloorUnderConstruction: number;
  concreteVolumeTotal: number; // m³
  rebarTonnageTotal: number; // t
}

export interface UnitFloorPlan {
  id: string;
  name: string; // e.g. "雅颂-128㎡三室两厅两卫"
  typeCategory: '1_bed' | '2_bed' | '3_bed' | '4_bed' | '5_bed' | 'duplex' | 'villa';
  grossArea: number; // 建筑面积 m²
  innerArea: number; // 套内建筑面积 m²
  usableArea: number; // 套内使用面积 m²
  sharedArea: number; // 公摊面积 m²
  efficiencyRatio: number; // 得房率 % (e.g. 80.5%)
  orientation: 'south' | 'south_east' | 'south_west' | 'north';
  daylightRating: '优秀' | '良好' | '合格';
  ventilationRating: '南北通透' | '良好' | '一般';
  windowToWallRatio: number; // e.g. 0.32
  ceilingHeight: number; // e.g. 3.0m
  rooms: RoomEntity[];
  walls: WallEntity[];
  doors: DoorEntity[];
  windows: WindowEntity[];
  decorOptions: InteriorDecorOption[];
}

export interface RoomEntity {
  id: string;
  name: string; // 主卧, 次卧, 客厅, 餐厅, 厨房, 主卫, 客卫, 景观阳台, 玄关
  type: 'master_bedroom' | 'bedroom' | 'living' | 'dining' | 'kitchen' | 'bathroom' | 'balcony' | 'entry' | 'study';
  area: number; // m²
  x: number; // 2D layout coord x (m)
  y: number; // 2D layout coord y (m)
  w: number; // width (m)
  h: number; // depth (m)
  orientation: 'south' | 'north' | 'east' | 'west';
  windowsCount: number;
  daylightScore: number; // 0-100
  floorFinish: string; // e.g. "实木复合地板", "防滑仿古瓷砖"
  wallFinish: string; // e.g. "立邦净味乳胶漆", "浅灰微水泥"
  ceilingFinish: string;
  hvacType: string; // "中央空调" | "分体空调"
  freshAir: boolean; // 新风系统
  underfloorHeating: boolean; // 地暖
  fixtures: FixtureEntity[];
}

export interface WallEntity {
  id: string;
  start: [number, number];
  end: [number, number];
  thickness: number; // e.g. 0.2m or 0.1m
  height: number;
  isBearing: boolean; // 是否承重墙
  material: string; // 钢筋混凝土 / 加气混凝土砌块
}

export interface DoorEntity {
  id: string;
  wallId: string;
  position: [number, number];
  width: number;
  height: number;
  type: 'wooden' | 'glass_sliding' | 'security_fireproof' | 'flush';
  brand: string;
}

export interface WindowEntity {
  id: string;
  wallId: string;
  position: [number, number];
  width: number;
  height: number;
  sillHeight: number;
  type: 'double_glazing_low_e' | 'triple_glazing' | 'floor_to_ceiling';
  shadingCoef: number;
}

export interface FixtureEntity {
  id: string;
  name: string;
  category: 'cabinet' | 'sanitary' | 'hvac' | 'electrical' | 'furniture';
  model: string;
  brand: string;
  x: number;
  y: number;
  powerKW?: number;
}

export interface BIMObjectEntity {
  id: string;
  guid: string;
  name: string;
  category: 'Wall' | 'Column' | 'Beam' | 'Slab' | 'Door' | 'Window' | 'Stair' | 'Elevator' | 'HVAC' | 'Pipe' | 'CableTray' | 'Sanitary' | 'Furniture' | 'CurtainWall';
  system: 'architecture' | 'structure' | 'mep_plumbing' | 'mep_hvac' | 'mep_electrical' | 'finishing';
  buildingId: string;
  floorNumber: number;
  unitId?: string;
  material: string;
  manufacturer: string;
  unitCost: number;
  quantity: number;
  unit: string;
  totalCost: number;
  installDate: string;
  constructionStatus: 'not_started' | 'preparing' | 'in_progress' | 'completed' | 'accepted' | 'rework';
  qaStatus: 'passed' | 'pending' | 'defect_found';
  carbonEmissionKg: number;
  maintenanceCycleDays: number;
  lastInspectionDate: string;
  bbox: { min: [number, number, number]; max: [number, number, number] };
}

export interface ConstructionTask4D {
  id: string;
  wbsCode: string;
  name: string;
  buildingId: string;
  floorRange: string;
  trade: 'foundation' | 'civil_structure' | 'masonry' | 'facade' | 'mep' | 'interior' | 'landscape';
  startDate: string;
  endDate: string;
  plannedDays: number;
  actualDays: number;
  progressPct: number;
  status: 'not_started' | 'active' | 'delayed' | 'completed';
  crewLeader: string;
  workersCount: number;
  subcontractor: string;
  linkedBIMGuids: string[];
  equipmentRequired: string[];
}

export interface CostItem5D {
  id: string;
  code: string; // 建设工程清单计价编码
  category: 'land' | 'civil_structure' | 'architecture' | 'mep' | 'finishing' | 'landscape' | 'basement' | 'equipment' | 'measures_and_taxes';
  name: string;
  specification: string;
  unit: string;
  quantity: number;
  materialUnitPrice: number;
  laborUnitPrice: number;
  machineryUnitPrice: number;
  totalAmount: number;
  buildingId?: string;
}

export interface MaterialItem {
  id: string;
  code: string;
  name: string;
  category: 'concrete' | 'rebar' | 'steel' | 'masonry' | 'stone' | 'ceramic' | 'wood' | 'glass' | 'aluminum' | 'insulation' | 'waterproofing' | 'paint' | 'door_window' | 'mep_pipe' | 'cable' | 'equipment';
  specification: string;
  unit: string;
  basePrice: number; // 元
  currentCityPrice: number; // 根据城市动态调整
  supplier: string;
  originProvince: string;
  carbonEmissionKgPerUnit: number;
  inventoryQty: number;
  leadTimeDays: number;
  certifications: string[]; // e.g. ["GB/T 50080", "中国绿色建材三星认证"]
  riskLevel: 'low' | 'medium' | 'high';
}

export interface DefectEntity {
  id: string;
  code: string;
  title: string;
  buildingId: string;
  floorNumber: number;
  unitCode: string;
  roomName: string;
  position3D: [number, number, number];
  category: 'crack' | 'seepage' | 'hollow' | 'door_window' | 'mep_leak' | 'levelness' | 'electrical';
  severity: 'minor' | 'moderate' | 'critical';
  status: 'reported' | 'rectifying' | 'reinspected' | 'closed';
  responsibleParty: string;
  reportDate: string;
  deadlineDate: string;
  inspectorName: string;
  description: string;
  photoUrl: string;
}

export interface TowerCraneEntity {
  id: string;
  name: string;
  model: string;
  position: [number, number, number];
  height: number; // m
  armLength: number; // m
  rotationAngle: number; // deg
  trolleyRadius: number; // m
  currentLoadKg: number;
  maxLoadKg: number;
  windSpeedMs: number;
  status: 'operating' | 'idle' | 'warning' | 'maintenance';
  operator: string;
}

export interface HeavyEquipmentEntity {
  id: string;
  name: string;
  category: 'tower_crane' | 'excavator' | 'crawler_crane' | 'concrete_pump' | 'mixer_truck' | 'construction_hoist' | 'forklift';
  plateNumber: string;
  driver: string;
  gpsCoords: [number, number];
  status: 'running' | 'standby' | 'fault';
  workingHours: number;
  fuelOrPowerKWh: number;
  maintenanceDue: string;
}

export interface BuildingRuleItem {
  id: string;
  ruleCode: string; // e.g. "GB50096-5.1.1"
  standardName: string; // e.g. "《住宅设计规范》GB 50096-2011"
  version: string;
  region: 'National' | 'Shanghai' | 'Beijing' | 'Guangdong' | 'Sichuan';
  buildingType: 'residential_high_rise' | 'residential_mid_rise' | 'all';
  parameterName: string;
  minAllowed?: number;
  maxAllowed?: number;
  unit: string;
  effectiveDate: string;
  description: string;
  level: 'mandatory' | 'recommended';
}

export interface CityConfig {
  id: string;
  name: string;
  pinyin: string;
  province: string;
  latitude: number;
  longitude: number;
  climateZone: string; // e.g. "夏热冬冷地区" | "严寒寒冷地区" | "夏热冬暖地区"
  localCodeName: string;
  sunshineWinterSolsticeReqHours: number; // 冬至日照要求 (小时)
  rebarPriceMultiplier: number;
  concretePriceMultiplier: number;
  laborDailyRate: number; // 元/工日
  benchmarkUnitCost: number; // 元/m²
  seismicIntensity?: number; // 设防烈度 (度)
}

export interface InteriorDecorOption {
  category: 'flooring' | 'walls' | 'doors' | 'cabinets' | 'sanitary' | 'lighting' | 'smart_home';
  selectedOptionId: string;
  options: {
    id: string;
    name: string;
    brand: string;
    material: string;
    colorHex: string;
    priceDelta: number; // 差价 元/m²
    previewTexture: string;
  }[];
}

export interface DigitalHandoverArchive {
  houseCode: string; // 310115-2026-CHO-008-3-1204
  residentName: string;
  buildingName: string;
  unitNumber: string;
  floorNumber: number;
  apartmentTypeName: string;
  grossArea: number;
  usableArea: number;
  handoverDate: string;
  warrantyExpireDate: string;
  asBuiltBimModelId: string;
  qualityCertificateNo: string;
  installedEquipments: {
    name: string;
    model: string;
    serialNo: string;
    brand: string;
    warrantyYears: number;
    iotDeviceId: string;
  }[];
  materialPassport: {
    item: string;
    spec: string;
    supplier: string;
    ecoGrade: string;
  }[];
}

export interface PropertyIoTDevice {
  id: string;
  name: string;
  buildingId: string;
  location: string;
  category: 'elevator' | 'booster_pump' | 'fresh_air' | 'fire_system' | 'smart_meter' | 'solar_inverter';
  status: 'normal' | 'warning' | 'alarm' | 'offline';
  currentReading: string;
  unit: string;
  dailyPowerKWh: number;
  lastMaintenance: string;
  nextMaintenance: string;
}

export interface WorkOrderEntity {
  id: string;
  code: string;
  houseCode: string;
  buildingName: string;
  unitNo: string;
  category: 'plumbing' | 'electrical' | 'hvac' | 'door_window' | 'wall_finish' | 'smart_home';
  urgency: 'low' | 'medium' | 'emergency';
  status: 'dispatched' | 'in_progress' | 'completed' | 'rated';
  title: string;
  createTime: string;
  assignedTechnician: string;
  residentPhone: string;
}
