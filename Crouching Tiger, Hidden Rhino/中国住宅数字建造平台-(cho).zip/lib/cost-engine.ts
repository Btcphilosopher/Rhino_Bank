/**
 * CHINA RESIDENTIAL DIGITAL TWIN & HOUSEBUILDER OS (CHO)
 * 5D Cost & Quantity Takeoff Engine (算量与工程计价引擎)
 */

import { BuildingEntity, UnitFloorPlan, CostItem5D, CityConfig } from '@/types/housebuilder';
import { DEMO_5D_COST_ITEMS, DEMO_MATERIALS } from './sample-data';

export interface CalculatedQuantities {
  concreteM3: number;
  rebarTons: number;
  formworkM2: number;
  masonryM3: number;
  facadeWindowsM2: number;
  interiorFinishingM2: number;
  paintM2: number;
  tilesM2: number;
  pipeMeters: number;
  cableMeters: number;
  hvacUnits: number;
  elevatorUnits: number;
}

export interface CalculatedProjectCost {
  totalCostYuan: number;
  totalCostYiYuan: number;
  costPerSqm: number;
  breakdown: {
    civilStructure: number;
    architecture: number;
    mep: number;
    finishing: number;
    landscape: number;
    basement: number;
    equipment: number;
    indirectAndTax: number;
  };
  carbonTotalTons: number;
  quantities: CalculatedQuantities;
  costItems: CostItem5D[];
}

export function calculateQuantitiesForBuilding(
  building: BuildingEntity,
  wallThicknessMultiplier = 1.0
): CalculatedQuantities {
  const floors = building.floorsCount;
  const floorArea = building.length * building.width;
  const totalGFA = floorArea * floors;

  // Concrete estimation: ~0.36 m³ concrete per m² GFA for Chinese shear wall high-rise
  const concreteM3 = totalGFA * 0.36 * wallThicknessMultiplier;
  
  // Rebar estimation: ~48 kg/m² (~0.048 t/m²) for seismic zone
  const rebarTons = totalGFA * 0.048 * wallThicknessMultiplier;

  // Formwork: ~2.4 m² per m² GFA
  const formworkM2 = totalGFA * 2.35;

  // Masonry partition walls: ~0.12 m³ per m² GFA
  const masonryM3 = totalGFA * 0.12 * wallThicknessMultiplier;

  // Windows and exterior curtain wall: ~0.28 m² per m² GFA
  const facadeWindowsM2 = totalGFA * 0.28;

  // Interior finishing floor area
  const interiorFinishingM2 = totalGFA * 0.78;

  // Wall paint/plaster: ~2.8 m² per m² GFA
  const paintM2 = totalGFA * 2.65;

  // Ceramic tiles: kitchen/bathrooms ~0.35 m² per m² GFA
  const tilesM2 = totalGFA * 0.35;

  // MEP Pipe & Cable
  const pipeMeters = totalGFA * 3.8;
  const cableMeters = totalGFA * 8.5;

  // Equipment
  const hvacUnits = building.totalUnits;
  const elevatorUnits = building.elevatorsCount;

  return {
    concreteM3: Math.round(concreteM3),
    rebarTons: Math.round(rebarTons),
    formworkM2: Math.round(formworkM2),
    masonryM3: Math.round(masonryM3),
    facadeWindowsM2: Math.round(facadeWindowsM2),
    interiorFinishingM2: Math.round(interiorFinishingM2),
    paintM2: Math.round(paintM2),
    tilesM2: Math.round(tilesM2),
    pipeMeters: Math.round(pipeMeters),
    cableMeters: Math.round(cableMeters),
    hvacUnits,
    elevatorUnits
  };
}

export function calculateProjectCost5D(
  buildings: BuildingEntity[],
  city: CityConfig,
  customParams?: {
    wallThicknessFactor?: number;
    floorsDelta?: number;
    finishingGrade?: 'standard' | 'luxury' | 'eco';
  }
): CalculatedProjectCost {
  const wallFactor = customParams?.wallThicknessFactor || 1.0;
  const finishingGrade = customParams?.finishingGrade || 'standard';

  let totalConcrete = 0;
  let totalRebar = 0;
  let totalFormwork = 0;
  let totalMasonry = 0;
  let totalWindows = 0;
  let totalFinishing = 0;
  let totalPaint = 0;
  let totalTiles = 0;
  let totalPipes = 0;
  let totalCables = 0;
  let totalHvac = 0;
  let totalElevators = 0;
  let totalGFA = 0;

  buildings.forEach(b => {
    const q = calculateQuantitiesForBuilding(b, wallFactor);
    totalConcrete += q.concreteM3;
    totalRebar += q.rebarTons;
    totalFormwork += q.formworkM2;
    totalMasonry += q.masonryM3;
    totalWindows += q.facadeWindowsM2;
    totalFinishing += q.interiorFinishingM2;
    totalPaint += q.paintM2;
    totalTiles += q.tilesM2;
    totalPipes += q.pipeMeters;
    totalCables += q.cableMeters;
    totalHvac += q.hvacUnits;
    totalElevators += q.elevatorUnits;
    totalGFA += b.length * b.width * b.floorsCount;
  });

  // Apply City Price Multipliers
  const concPrice = 512 * city.concretePriceMultiplier;
  const rebarPrice = 3920 * city.rebarPriceMultiplier;
  const laborMultiplier = city.laborDailyRate / 380; // Baseline Shanghai 380

  const civilStructureCost = 
    (totalConcrete * concPrice + totalRebar * rebarPrice + totalFormwork * 45) * 
    (1 + (laborMultiplier - 1) * 0.25);

  const architectureCost = totalWindows * 620 + totalMasonry * 320;

  const mepCost = 
    totalPipes * 32 + 
    totalCables * 18 + 
    totalHvac * 26000 + 
    totalElevators * 260000;

  const finishingMultiplier = finishingGrade === 'luxury' ? 1.35 : finishingGrade === 'eco' ? 1.15 : 1.0;
  const finishingCost = totalFinishing * 1850 * finishingMultiplier * laborMultiplier;

  const landscapeCost = 48000 * 420; // Community outdoor landscaping
  const basementCost = 45000 * 1380 * city.concretePriceMultiplier;
  const equipmentCost = totalElevators * 260000 + 12000000; // Substation, pumps, BMS
  
  const subtotal = civilStructureCost + architectureCost + mepCost + finishingCost + landscapeCost + basementCost + equipmentCost;
  const indirectAndTax = subtotal * 0.092; // 规费税金措施费 ~9.2%
  const grandTotal = subtotal + indirectAndTax;

  // Carbon calculation
  const carbonTotalTons = (
    totalConcrete * 0.31 + 
    totalRebar * 1.85 + 
    totalWindows * 0.045 + 
    totalMasonry * 0.12
  );

  const costPerSqm = totalGFA > 0 ? Math.round(grandTotal / (totalGFA + 45000)) : city.benchmarkUnitCost;

  const costItems: CostItem5D[] = [
    {
      id: 'calc-01',
      code: '010401001',
      category: 'civil_structure',
      name: '主体结构现浇商品混凝土',
      specification: `C30~C50 强度等级 (${city.name}地材价格适配)`,
      unit: 'm³',
      quantity: totalConcrete,
      materialUnitPrice: Math.round(concPrice),
      laborUnitPrice: Math.round(110 * laborMultiplier),
      machineryUnitPrice: 48,
      totalAmount: Math.round(totalConcrete * (concPrice + 110 * laborMultiplier + 48))
    },
    {
      id: 'calc-02',
      code: '010416001',
      category: 'civil_structure',
      name: '高强抗震钢筋 HRB400E/HRB500E',
      specification: '全规格机械套筒连接',
      unit: 't',
      quantity: totalRebar,
      materialUnitPrice: Math.round(rebarPrice),
      laborUnitPrice: Math.round(850 * laborMultiplier),
      machineryUnitPrice: 120,
      totalAmount: Math.round(totalRebar * (rebarPrice + 850 * laborMultiplier + 120))
    },
    {
      id: 'calc-03',
      code: '010801001',
      category: 'architecture',
      name: '高性能节能门窗与幕墙工程',
      specification: 'Low-E中空断桥铝系统',
      unit: 'm²',
      quantity: totalWindows,
      materialUnitPrice: 580,
      laborUnitPrice: Math.round(140 * laborMultiplier),
      machineryUnitPrice: 35,
      totalAmount: Math.round(totalWindows * 620)
    },
    {
      id: 'calc-04',
      code: '020101001',
      category: 'finishing',
      name: '全屋品质精装修工程',
      specification: `${finishingGrade === 'luxury' ? '天境奢雅' : '云栖现代'} 定制级装配式精装`,
      unit: 'm²',
      quantity: totalFinishing,
      materialUnitPrice: Math.round(1680 * finishingMultiplier),
      laborUnitPrice: Math.round(620 * laborMultiplier),
      machineryUnitPrice: 80,
      totalAmount: Math.round(finishingCost)
    },
    {
      id: 'calc-05',
      code: '030801001',
      category: 'mep',
      name: '暖通给排水及电气安装工程',
      specification: 'VRV空调+新风+同层排水+智能配电',
      unit: '项',
      quantity: 1,
      materialUnitPrice: Math.round(mepCost * 0.75),
      laborUnitPrice: Math.round(mepCost * 0.22),
      machineryUnitPrice: Math.round(mepCost * 0.03),
      totalAmount: Math.round(mepCost)
    }
  ];

  return {
    totalCostYuan: Math.round(grandTotal),
    totalCostYiYuan: Number((grandTotal / 100000000).toFixed(2)),
    costPerSqm,
    breakdown: {
      civilStructure: Math.round(civilStructureCost),
      architecture: Math.round(architectureCost),
      mep: Math.round(mepCost),
      finishing: Math.round(finishingCost),
      landscape: Math.round(landscapeCost),
      basement: Math.round(basementCost),
      equipment: Math.round(equipmentCost),
      indirectAndTax: Math.round(indirectAndTax)
    },
    carbonTotalTons: Math.round(carbonTotalTons),
    quantities: {
      concreteM3: totalConcrete,
      rebarTons: totalRebar,
      formworkM2: totalFormwork,
      masonryM3: totalMasonry,
      facadeWindowsM2: totalWindows,
      interiorFinishingM2: totalFinishing,
      paintM2: totalPaint,
      tilesM2: totalTiles,
      pipeMeters: totalPipes,
      cableMeters: totalCables,
      hvacUnits: totalHvac,
      elevatorUnits: totalElevators
    },
    costItems
  };
}
