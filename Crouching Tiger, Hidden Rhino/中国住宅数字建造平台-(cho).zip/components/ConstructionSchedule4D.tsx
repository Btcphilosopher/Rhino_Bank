'use client';

import React from 'react';
import {
  ConstructionTask4D,
  TowerCraneEntity,
  HeavyEquipmentEntity
} from '@/types/housebuilder';
import {
  HardHat,
  Calendar,
  Users,
  Activity,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Truck,
  Wind,
  Gauge
} from 'lucide-react';

interface ConstructionSchedule4DProps {
  tasks: ConstructionTask4D[];
  cranes: TowerCraneEntity[];
  heavyMachines: HeavyEquipmentEntity[];
  constructionDay: number;
}

export default function ConstructionSchedule4D({
  tasks,
  cranes,
  heavyMachines,
  constructionDay
}: ConstructionSchedule4DProps) {
  return (
    <div className="flex flex-col h-full bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-2xl text-white">
      {/* Header */}
      <div className="p-4 bg-slate-800/80 border-b border-slate-700/80 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/30">
            <HardHat className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <span>4D 智慧施工现场管控中心</span>
              <span className="text-[11px] font-normal px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800 font-mono">
                总包单位: 上海建工一建集团
              </span>
            </h3>
            <p className="text-[11px] text-slate-400">
              工程总承包 WBS 工序节点、班组人力、智能塔吊群与重型机械物联网
            </p>
          </div>
        </div>

        {/* Site Real-time Stats */}
        <div className="flex items-center gap-3 text-xs">
          <div className="flex items-center gap-1.5 bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700">
            <Users className="w-3.5 h-3.5 text-sky-400" />
            <span className="text-slate-400">在场施工作业人员:</span>
            <span className="font-bold text-sky-300 font-mono">415 人</span>
          </div>
          <div className="flex items-center gap-1.5 bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700">
            <Activity className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-slate-400">现场安全施工天数:</span>
            <span className="font-bold text-emerald-300 font-mono">562 天</span>
          </div>
        </div>
      </div>

      {/* Main Grid: WBS Tasks Timeline (Left 7 Cols) & Live IoT Machinery (Right 5 Cols) */}
      <div className="grid grid-cols-12 flex-1 min-h-0 divide-x divide-slate-800">
        {/* Left: WBS Task List */}
        <div className="col-span-7 p-4 overflow-y-auto bg-slate-900/90 text-xs space-y-3">
          <div className="flex items-center justify-between border-b border-slate-700 pb-2">
            <h4 className="font-bold text-white text-sm flex items-center gap-1.5">
              <Calendar className="w-4 h-4 text-sky-400" />
              <span>关键路径工序施工进度表 (WBS)</span>
            </h4>
            <span className="text-slate-400 text-[11px]">4D 时间轴联动</span>
          </div>

          <div className="space-y-2.5">
            {tasks.map(task => {
              const isCompleted = task.status === 'completed';
              const isActive = task.status === 'active';

              return (
                <div
                  key={task.id}
                  className={`p-3 rounded-lg border transition ${
                    isActive
                      ? 'bg-sky-950/40 border-sky-700/80 shadow-md'
                      : isCompleted
                      ? 'bg-slate-800/40 border-slate-800 opacity-80'
                      : 'bg-slate-800/20 border-slate-800'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-sky-400 font-semibold">{task.wbsCode}</span>
                        <span className="font-bold text-slate-100">{task.name}</span>
                        <span className="px-1.5 py-0.5 rounded text-[10px] bg-slate-800 text-slate-300 font-mono">
                          {task.floorRange}
                        </span>
                      </div>
                      <div className="flex items-center gap-4 text-[11px] text-slate-400 mt-1">
                        <span>专业分包: {task.subcontractor}</span>
                        <span>班组长: {task.crewLeader}</span>
                        <span>作业工人: {task.workersCount}人</span>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          isCompleted
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                            : isActive
                            ? 'bg-amber-950 text-amber-300 border border-amber-800 animate-pulse'
                            : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {isCompleted ? '已完成' : isActive ? '正在施工' : '未开始'}
                      </span>
                      <span className="block font-mono text-slate-300 text-[11px] mt-1">
                        {task.progressPct}%
                      </span>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden mt-2.5">
                    <div
                      className={`h-full transition-all duration-300 ${
                        isCompleted ? 'bg-emerald-500' : 'bg-sky-500'
                      }`}
                      style={{ width: `${task.progressPct}%` }}
                    />
                  </div>

                  {/* Machinery Tag */}
                  <div className="mt-2 flex items-center gap-2 text-[10px] text-slate-400">
                    <Truck className="w-3 h-3 text-amber-400" />
                    <span>联动施工设备: {task.equipmentRequired.join('、')}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Smart Crane & Heavy Machinery IoT Telemetry (5 Cols) */}
        <div className="col-span-5 p-4 overflow-y-auto bg-slate-900/90 text-xs space-y-4">
          <div className="border-b border-slate-700 pb-2 flex items-center justify-between">
            <h4 className="font-bold text-white text-sm flex items-center gap-1.5">
              <Gauge className="w-4 h-4 text-amber-400" />
              <span>智能塔吊群与机械实况</span>
            </h4>
            <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 text-[10px] font-mono">
              GPS/IoT 在线
            </span>
          </div>

          {/* Tower Cranes */}
          <div className="space-y-3">
            <span className="font-bold text-slate-300 text-[11px] block">智慧群塔防碰撞监测系统</span>
            {cranes.map(crane => (
              <div
                key={crane.id}
                className="bg-slate-800/60 p-3 rounded-lg border border-slate-700 space-y-2"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-100">{crane.name}</span>
                  <span
                    className={`px-1.5 py-0.5 rounded text-[10px] font-mono ${
                      crane.status === 'operating'
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                        : 'bg-slate-700 text-slate-400'
                    }`}
                  >
                    {crane.status === 'operating' ? '作业中' : '待机'}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div>
                    <span className="text-slate-400 block text-[10px]">实时起吊载荷</span>
                    <span className="font-bold font-mono text-amber-300">
                      {crane.currentLoadKg} kg / {crane.maxLoadKg} kg
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">回转角度 / 幅度</span>
                    <span className="font-mono text-slate-200">
                      {crane.rotationAngle}° / {crane.trolleyRadius}m
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">现场瞬时风速</span>
                    <span className="font-mono text-sky-300 flex items-center gap-1">
                      <Wind className="w-3 h-3 text-sky-400" />
                      {crane.windSpeedMs} m/s (安全)
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">持证塔司</span>
                    <span className="text-slate-300">{crane.operator.split(' ')[0]}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Heavy Machinery */}
          <div className="space-y-2 pt-2 border-t border-slate-800">
            <span className="font-bold text-slate-300 text-[11px] block">大型工程机械设备调度</span>
            {heavyMachines.map(m => (
              <div
                key={m.id}
                className="bg-slate-800/40 p-2.5 rounded-lg border border-slate-800 flex items-center justify-between text-[11px]"
              >
                <div>
                  <span className="font-bold text-slate-200 block">{m.name}</span>
                  <span className="text-[10px] text-slate-400">
                    车牌: {m.plateNumber} | 司机: {m.driver}
                  </span>
                </div>
                <div className="text-right">
                  <span className="font-mono text-emerald-400 font-bold">{m.workingHours} h</span>
                  <span className="text-[10px] text-slate-500 block">累计工时</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
