'use client';

import React, { useState } from 'react';
import { MaterialItem, CityConfig } from '@/types/housebuilder';
import {
  Boxes,
  Truck,
  TrendingUp,
  AlertTriangle,
  Leaf,
  ShieldCheck,
  Search,
  Building,
  CheckCircle2,
  ShoppingCart
} from 'lucide-react';

interface MaterialProcurementProps {
  materials: MaterialItem[];
  city: CityConfig;
}

export default function MaterialProcurement({ materials, city }: MaterialProcurementProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedMaterialId, setSelectedMaterialId] = useState<string | null>(materials[0]?.id || null);

  const selectedMat = materials.find(m => m.id === selectedMaterialId) || materials[0];

  const filteredMaterials = materials.filter(m => {
    if (selectedCategory !== 'all' && m.category !== selectedCategory) return false;
    if (searchTerm && !m.name.toLowerCase().includes(searchTerm.toLowerCase()) && !m.code.toLowerCase().includes(searchTerm.toLowerCase())) return false;
    return true;
  });

  return (
    <div className="flex flex-col h-full bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-2xl text-white">
      {/* Top Header */}
      <div className="p-4 bg-slate-800/80 border-b border-slate-700/80 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-sky-500/20 text-sky-400 border border-sky-500/30">
            <Boxes className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <span>中国住宅工程材料数据库与战略采购系统</span>
              <span className="text-[11px] font-normal px-2 py-0.5 rounded bg-sky-950 text-sky-300 border border-sky-800 font-mono">
                当前采购城市: {city.name} (信息价联动)
              </span>
            </h3>
            <p className="text-[11px] text-slate-400">
              国家绿色建材认证、原产地溯源、实时库存供需风险与碳足迹全生命周期台账
            </p>
          </div>
        </div>

        {/* Search */}
        <div className="flex items-center gap-2 text-xs">
          <input
            type="text"
            placeholder="搜索材料名称、规格型号或编码..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="bg-slate-700 border border-slate-600 rounded-lg px-3 py-1 text-slate-200 text-xs w-60"
          />
        </div>
      </div>

      {/* Main Grid: Material Table (Left 7 Cols) & Material Passport / Supplier Deep Dive (Right 5 Cols) */}
      <div className="grid grid-cols-12 flex-1 min-h-0 divide-x divide-slate-800">
        {/* Left Material List */}
        <div className="col-span-7 p-4 overflow-y-auto bg-slate-900/90 text-xs space-y-3">
          {/* Category Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
            {[
              { id: 'all', name: '全部建材' },
              { id: 'concrete', name: '商品混凝土' },
              { id: 'rebar', name: '抗震钢筋' },
              { id: 'masonry', name: '轻质砌块' },
              { id: 'glass', name: '节能玻璃' },
              { id: 'insulation', name: '保温材料' },
              { id: 'mep_pipe', name: '管道线缆' },
              { id: 'equipment', name: '特种设备' }
            ].map(cat => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-2.5 py-1 rounded whitespace-nowrap transition ${
                  selectedCategory === cat.id
                    ? 'bg-sky-600 text-white font-bold'
                    : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                {cat.name}
              </button>
            ))}
          </div>

          {/* List Cards */}
          <div className="space-y-2">
            {filteredMaterials.map(mat => {
              const isSelected = mat.id === selectedMaterialId;
              return (
                <div
                  key={mat.id}
                  onClick={() => setSelectedMaterialId(mat.id)}
                  className={`p-3 rounded-lg border transition cursor-pointer ${
                    isSelected
                      ? 'bg-sky-950/40 border-sky-600 shadow-lg'
                      : 'bg-slate-800/40 border-slate-700/80 hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-sky-400 font-bold">{mat.code}</span>
                        <span className="font-bold text-slate-100 text-sm">{mat.name}</span>
                      </div>
                      <span className="text-[11px] text-slate-400 block mt-0.5">{mat.specification}</span>
                    </div>

                    <div className="text-right shrink-0">
                      <div className="flex items-baseline gap-1">
                        <span className="text-sm font-bold font-mono text-emerald-400">
                          ¥ {mat.currentCityPrice.toLocaleString()}
                        </span>
                        <span className="text-[10px] text-slate-400">/ {mat.unit}</span>
                      </div>
                      <span
                        className={`text-[9px] px-1.5 py-0.2 rounded font-medium mt-1 inline-block ${
                          mat.riskLevel === 'low'
                            ? 'bg-emerald-950 text-emerald-300'
                            : mat.riskLevel === 'medium'
                            ? 'bg-amber-950 text-amber-300'
                            : 'bg-red-950 text-red-300'
                        }`}
                      >
                        {mat.riskLevel === 'low' ? '供应充裕' : mat.riskLevel === 'medium' ? '交期适中' : '长周期预定'}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[10px] text-slate-400 mt-2 pt-2 border-t border-slate-800">
                    <span>供应商: {mat.supplier}</span>
                    <span>现存量: {mat.inventoryQty.toLocaleString()} {mat.unit}</span>
                    <span>到货周期: {mat.leadTimeDays} 天</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Material Detail Sheet */}
        <div className="col-span-5 p-4 overflow-y-auto bg-slate-900/90 text-xs space-y-4">
          {selectedMat ? (
            <div className="space-y-4">
              <div className="border-b border-slate-700 pb-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-white text-base">{selectedMat.name}</h4>
                  <span className="font-mono text-xs text-emerald-400 font-bold">
                    ¥ {selectedMat.currentCityPrice.toLocaleString()} / {selectedMat.unit}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 mt-1">{selectedMat.specification}</p>
              </div>

              {/* Manufacturer & Province */}
              <div className="bg-slate-800/60 p-3 rounded-lg border border-slate-700 space-y-2">
                <span className="font-bold text-slate-200 text-[11px] flex items-center gap-1.5">
                  <Building className="w-3.5 h-3.5 text-sky-400" />
                  <span>供应厂家与生产基地</span>
                </span>
                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div>
                    <span className="text-slate-400 block text-[10px]">战略签约供应商</span>
                    <span className="text-slate-200 font-medium">{selectedMat.supplier}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">原产地省市</span>
                    <span className="text-slate-200 font-medium">{selectedMat.originProvince}</span>
                  </div>
                </div>
              </div>

              {/* Carbon Emission & Eco Certifications */}
              <div className="bg-slate-800/60 p-3 rounded-lg border border-slate-700 space-y-2">
                <span className="font-bold text-slate-200 text-[11px] flex items-center gap-1.5">
                  <Leaf className="w-3.5 h-3.5 text-emerald-400" />
                  <span>绿色建材与隐含碳排放</span>
                </span>
                <div className="space-y-1.5">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-slate-400">单体隐含碳排放</span>
                    <span className="font-mono text-emerald-400 font-bold">
                      {selectedMat.carbonEmissionKgPerUnit} kg CO₂e / {selectedMat.unit}
                    </span>
                  </div>
                  <div className="pt-1">
                    <span className="text-[10px] text-slate-400 block mb-1">权威产品检验与环保认证:</span>
                    <div className="flex flex-wrap gap-1">
                      {selectedMat.certifications.map(cert => (
                        <span
                          key={cert}
                          className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 text-[10px] border border-emerald-800"
                        >
                          {cert}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-12 text-slate-500">请选择左侧材料项</div>
          )}
        </div>
      </div>
    </div>
  );
}
