'use client';

import React, { useState } from 'react';
import {
  Bot,
  Send,
  Sparkles,
  User,
  Lightbulb,
  FileCheck,
  ShieldAlert,
  Calculator,
  Building,
  RotateCcw
} from 'lucide-react';

export default function AICopilotAssistant() {
  const [messages, setMessages] = useState<
    Array<{ role: 'user' | 'assistant'; text: string; time: string }>
  >([
    {
      role: 'assistant',
      text: `您好！我是 **CHO 首席总工程师 AI 智脑**。\n\n我已完全接入本项目 180,000m² 8栋高层住宅全部 **BIM 几何数据、5D 算量计价清单与《住宅设计规范》GB 50096-2011 规范库**。\n\n您可以随时向我咨询：\n- 📐 **户型空间与窗地比合规性诊断**\n- 💰 **5D 结构含钢量与混凝土单方成本敏感度优化**\n- 🏗️ **铝模爬架、PC 装配式与群塔防碰撞工法**\n- 🔍 **隐蔽工程验收与一房一档数字化交付标准**`,
      time: '09:00'
    }
  ]);
  const [inputPrompt, setInputPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const quickPrompts = [
    '请分析本项目剪力墙含钢量指标并给出节约 5% 造价的结构优化方案',
    '如何根据《住宅设计规范》评估 128m² 三室两厅的窗地面积比与通风动线？',
    '铝模+全钢爬架工法在 26 层主体结构施工中的提效与质量控制要点',
    '地暖盘管与同层排水在隐蔽工程数字化移交中的验收标准'
  ];

  const handleSend = async (textToSend?: string) => {
    const prompt = (textToSend || inputPrompt).trim();
    if (!prompt || isLoading) return;

    const userMsg = {
      role: 'user' as const,
      text: prompt,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputPrompt('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/gemini/copilot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt })
      });
      const data = await res.json();

      setMessages(prev => [
        ...prev,
        {
          role: 'assistant',
          text: data.reply || '分析完成。',
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } catch (e: any) {
      setMessages(prev => [
        ...prev,
        {
          role: 'assistant',
          text: '抱歉，服务响应超时，请稍后重试。',
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-2xl text-white">
      {/* Header */}
      <div className="p-4 bg-slate-800/80 border-b border-slate-700/80 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-sky-500/20 text-sky-400 border border-sky-500/30">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <span>CHO 住宅数字建造首席总工程师 AI 智脑</span>
              <span className="text-[10px] font-medium px-2 py-0.5 rounded bg-sky-950 text-sky-300 border border-sky-800 font-mono">
                GEMINI 3.8 FLASH ENGINE
              </span>
            </h3>
            <p className="text-[11px] text-slate-400">
              融合中国国家建筑标准设计图集、GB 规范与工程总承包施工经验
            </p>
          </div>
        </div>

        <button
          onClick={() =>
            setMessages([
              {
                role: 'assistant',
                text: '工程咨询会话已重置，请随时提问。',
                time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
              }
            ])
          }
          className="p-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-300 hover:text-white"
          title="清空对话"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {/* Chat Messages */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4 text-xs">
        {messages.map((msg, i) => (
          <div
            key={i}
            className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            {msg.role === 'assistant' && (
              <div className="w-7 h-7 rounded-lg bg-sky-600 flex items-center justify-center text-white shrink-0 mt-0.5">
                <Bot className="w-4 h-4" />
              </div>
            )}

            <div
              className={`max-w-2xl rounded-2xl p-3.5 space-y-1 shadow-md ${
                msg.role === 'user'
                  ? 'bg-sky-600 text-white rounded-tr-none'
                  : 'bg-slate-800/90 text-slate-200 border border-slate-700 rounded-tl-none leading-relaxed'
              }`}
            >
              <div className="whitespace-pre-wrap">{msg.text}</div>
              <span
                className={`text-[9px] block text-right font-mono ${
                  msg.role === 'user' ? 'text-sky-200' : 'text-slate-400'
                }`}
              >
                {msg.time}
              </span>
            </div>

            {msg.role === 'user' && (
              <div className="w-7 h-7 rounded-lg bg-slate-700 flex items-center justify-center text-slate-200 shrink-0 mt-0.5">
                <User className="w-4 h-4" />
              </div>
            )}
          </div>
        ))}

        {isLoading && (
          <div className="flex gap-3 justify-start">
            <div className="w-7 h-7 rounded-lg bg-sky-600 flex items-center justify-center text-white shrink-0">
              <Bot className="w-4 h-4 animate-spin" />
            </div>
            <div className="bg-slate-800/90 text-slate-300 p-3 rounded-2xl border border-slate-700 text-xs flex items-center gap-2">
              <Sparkles className="w-3.5 h-3.5 text-sky-400 animate-pulse" />
              <span>首席总工 AI 正在深度检索 GB 规范与工程清单数据库...</span>
            </div>
          </div>
        )}
      </div>

      {/* Quick Prompts */}
      <div className="px-4 py-2 bg-slate-950/40 border-t border-slate-800 flex items-center gap-2 overflow-x-auto text-[11px]">
        <span className="text-slate-500 shrink-0 flex items-center gap-1 font-medium">
          <Lightbulb className="w-3 h-3 text-amber-400" />
          快捷咨询:
        </span>
        {quickPrompts.map((q, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(q)}
            className="px-2.5 py-1 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 whitespace-nowrap transition"
          >
            {q}
          </button>
        ))}
      </div>

      {/* Input Bar */}
      <div className="p-3 bg-slate-800/80 border-t border-slate-700/80">
        <form
          onSubmit={e => {
            e.preventDefault();
            handleSend();
          }}
          className="flex items-center gap-2"
        >
          <input
            type="text"
            placeholder="输入工程技术问题、结构指标优化、造价敏感度分析或国家规范条款..."
            value={inputPrompt}
            onChange={e => setInputPrompt(e.target.value)}
            className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-3.5 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
          />
          <button
            type="submit"
            disabled={!inputPrompt.trim() || isLoading}
            className="px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white text-xs font-bold flex items-center gap-1.5 shadow transition"
          >
            <Send className="w-3.5 h-3.5" />
            <span>发送</span>
          </button>
        </form>
      </div>
    </div>
  );
}
