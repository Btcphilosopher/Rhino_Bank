'use client';

import React, { useState } from 'react';
import { BuildingEntity, CityConfig } from '@/types/housebuilder';
import { calculateProjectCost5D } from '@/lib/cost-engine';
import {
  DollarSign,
  TrendingUp,
  Layers,
  Sliders,
  FileSpreadsheet,
  AlertCircle,
  Building2,
  PieChart,
  RefreshCw,
  Sparkles
} from 'lucide-react';

interface CostManagement5DProps {
  buildings: BuildingEntity[];
  city: CityConfig;
}

export default function CostManagement5D({ buildings, city }: CostManagement5DProps) {
  const [wallThicknessFactor, setWallThicknessFactor] = useState<number>(1.0);
  const [finishingGrade, setFinishingGrade] = useState<'standard' | 'luxury' | 'eco'>('standard');
  const [selectedScenario, setSelectedScenario] = useState<'baseline' | 'scenario_a' | 'scenario_b'>('baseline');

  // Calculate baseline cost
  const baselineCost = calculateProjectCost5D(buildings, city, {
    wallThicknessFactor: 1.0,
    finishingGrade: 'standard'
  });

  // Calculate current active scenario cost
  const activeCost = calculateProjectCost5D(buildings, city, {
    wallThicknessFactor: selectedScenario === 'baseline' ? 1.0 : wallThicknessFactor,
    finishingGrade: selectedScenario === 'baseline' ? 'standard' : finishingGrade
  });

  const deltaCostYi = Number((activeCost.totalCostYiYuan - baselineCost.totalCostYiYuan).toFixed(2));
  const deltaCostPct = Number((((activeCost.totalCostYuan - baselineCost.totalCostYuan) / baselineCost.totalCostYuan) * 100).toFixed(2));

  return (
    <div className="flex flex-col h-full bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-2xl text-white">
      {/* Top Header */}
      <div className="p-4 bg-slate-800/80 border-b border-slate-700/80 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
            <DollarSign className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <span>5D BIM 算量计价与全生命周期成本管控</span>
              <span className="text-[11px] font-normal px-2 py-0.5 rounded bg-sky-950 text-sky-300 border border-sky-800">
                计价规范: GB 50500-2013
              </span>
            </h3>
            <p className="text-[11px] text-slate-400">
              几何构件 → 工程量清单 → 地区定额与市场综合单价 → 动态全成本联动
            </p>
          </div>
        </div>

        {/* Scenario Switcher */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400">情景实验室:</span>
          <div className="flex bg-slate-700/80 p-0.5 rounded border border-slate-600">
            <button
              onClick={() => {
                setSelectedScenario('baseline');
                setWallThicknessFactor(1.0);
                setFinishingGrade('standard');
              }}
              className={`px-3 py-1 rounded text-xs transition ${
                selectedScenario === 'baseline' ? 'bg-emerald-600 text-white font-medium' : 'text-slate-300 hover:text-white'
              }`}
            >
              BASELINE 基准方案
            </button>
            <button
              onClick={() => setSelectedScenario('scenario_a')}
              className={`px-3 py-1 rounded text-xs transition ${
                selectedScenario === 'scenario_a' ? 'bg-sky-600 text-white font-medium' : 'text-slate-300 hover:text-white'
              }`}
            >
              情景 A: 优化结构厚度
            </button>
            <button
              onClick={() => setSelectedScenario('scenario_b')}
              className={`px-3 py-1 rounded text-xs transition ${
                selectedScenario === 'scenario_b' ? 'bg-indigo-600 text-white font-medium' : 'text-slate-300 hover:text-white'
              }`}
            >
              情景 B: 顶奢精装+超低能耗
            </button>
          </div>
        </div>
      </div>

      {/* KPI Highlight Strip */}
      <div className="grid grid-cols-5 gap-3 p-4 bg-slate-950/60 border-b border-slate-800">
        <div className="bg-slate-800/80 p-3 rounded-lg border border-slate-700/70">
          <span className="text-slate-400 text-[11px] block">项目建安总造价</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl font-bold font-mono text-emerald-400">
              {activeCost.totalCostYiYuan}
            </span>
            <span className="text-xs text-slate-400">亿元</span>
          </div>
          {selectedScenario !== 'baseline' && (
            <span className={`text-[10px] font-mono ${deltaCostYi >= 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
              {deltaCostYi >= 0 ? `+${deltaCostYi}` : deltaCostYi} 亿元 ({deltaCostPct >= 0 ? `+${deltaCostPct}` : deltaCostPct}%)
            </span>
          )}
        </div>

        <div className="bg-slate-800/80 p-3 rounded-lg border border-slate-700/70">
          <span className="text-slate-400 text-[11px] block">单方综合造价 (含地下室)</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl font-bold font-mono text-sky-400">
              ¥ {activeCost.costPerSqm.toLocaleString()}
            </span>
            <span className="text-xs text-slate-400">/m²</span>
          </div>
          <span className="text-[10px] text-slate-400">{city.name}地标定额基准: ¥{city.benchmarkUnitCost}/m²</span>
        </div>

        <div className="bg-slate-800/80 p-3 rounded-lg border border-slate-700/70">
          <span className="text-slate-400 text-[11px] block">总混凝土方量 (BOM)</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl font-bold font-mono text-slate-100">
              {activeCost.quantities.concreteM3.toLocaleString()}
            </span>
            <span className="text-xs text-slate-400">m³</span>
          </div>
          <span className="text-[10px] text-slate-400">强度 C30~C50</span>
        </div>

        <div className="bg-slate-800/80 p-3 rounded-lg border border-slate-700/70">
          <span className="text-slate-400 text-[11px] block">总钢筋吨位 (HRB400E)</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl font-bold font-mono text-slate-100">
              {activeCost.quantities.rebarTons.toLocaleString()}
            </span>
            <span className="text-xs text-slate-400">吨</span>
          </div>
          <span className="text-[10px] text-slate-400">抗震级钢材</span>
        </div>

        <div className="bg-slate-800/80 p-3 rounded-lg border border-slate-700/70">
          <span className="text-slate-400 text-[11px] block">全生命周期隐含碳足迹</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl font-bold font-mono text-amber-400">
              {activeCost.carbonTotalTons.toLocaleString()}
            </span>
            <span className="text-xs text-slate-400">t CO₂e</span>
          </div>
          <span className="text-[10px] text-emerald-400">满足国家绿建三星标准</span>
        </div>
      </div>

      {/* Main Grid: Parameters / Interactive Lab & Bill of Quantities */}
      <div className="grid grid-cols-12 flex-1 min-h-0 divide-x divide-slate-800">
        {/* Left: Parametric Lab Controller (4 Cols) */}
        <div className="col-span-4 p-4 overflow-y-auto bg-slate-900/90 text-xs space-y-4">
          <div className="border-b border-slate-700/80 pb-2 flex items-center gap-1.5 text-slate-200 font-bold">
            <Sliders className="w-4 h-4 text-sky-400" />
            <span>参数化成本情景调节 (What-If)</span>
          </div>

          <div className="space-y-4">
            {/* Wall Thickness Factor Slider */}
            <div className="bg-slate-800/60 p-3 rounded-lg border border-slate-700 space-y-2">
              <div className="flex justify-between text-slate-300">
                <span className="font-medium">剪力墙/隔墙厚度优化系数</span>
                <span className="font-mono text-sky-300 font-bold">
                  {(wallThicknessFactor * 100).toFixed(0)}%
                </span>
              </div>
              <input
                type="range"
                min="0.85"
                max="1.20"
                step="0.05"
                value={wallThicknessFactor}
                onChange={e => {
                  setWallThicknessFactor(parseFloat(e.target.value));
                  if (selectedScenario === 'baseline') setSelectedScenario('scenario_a');
                }}
                className="w-full h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-sky-500"
              />
              <span className="text-[10px] text-slate-400 block">
                调节结构截面尺寸可直接影响混凝土与钢筋采购总量
              </span>
            </div>

            {/* Finishing Grade Options */}
            <div className="bg-slate-800/60 p-3 rounded-lg border border-slate-700 space-y-2">
              <span className="font-medium text-slate-300 block">精装修交付标准</span>
              <div className="grid grid-cols-3 gap-1.5">
                {[
                  { id: 'standard', name: '云栖标配', desc: '¥1,680/m²' },
                  { id: 'luxury', name: '天境尊享', desc: '¥2,260/m²' },
                  { id: 'eco', name: '超低能耗', desc: '¥1,930/m²' }
                ].map(item => (
                  <button
                    key={item.id}
                    onClick={() => {
                      setFinishingGrade(item.id as any);
                      if (selectedScenario === 'baseline') setSelectedScenario('scenario_b');
                    }}
                    className={`p-2 rounded text-left transition border ${
                      finishingGrade === item.id
                        ? 'bg-indigo-600 border-indigo-400 text-white shadow'
                        : 'bg-slate-700/60 border-slate-600 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    <span className="font-bold text-[11px] block">{item.name}</span>
                    <span className="text-[10px] opacity-80">{item.desc}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Category Cost Distribution Breakdown */}
            <div className="bg-slate-800/40 p-3 rounded-lg border border-slate-800 space-y-2">
              <span className="font-bold text-slate-300 text-[11px] block">造价分类构成 (万元)</span>
              <div className="space-y-1.5 text-[11px]">
                <div className="flex justify-between text-slate-300">
                  <span>主体结构工程 (土建/钢筋/砼)</span>
                  <span className="font-mono font-bold text-slate-100">
                    ¥ {(activeCost.breakdown.civilStructure / 10000).toFixed(0)} 万
                  </span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>室内装配式精装修</span>
                  <span className="font-mono font-bold text-slate-100">
                    ¥ {(activeCost.breakdown.finishing / 10000).toFixed(0)} 万
                  </span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>机电安装 (暖通/给排水/强弱电)</span>
                  <span className="font-mono font-bold text-slate-100">
                    ¥ {(activeCost.breakdown.mep / 10000).toFixed(0)} 万
                  </span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>地下两层车库及人防工程</span>
                  <span className="font-mono font-bold text-slate-100">
                    ¥ {(activeCost.breakdown.basement / 10000).toFixed(0)} 万
                  </span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>现代滨水景观与海绵水系</span>
                  <span className="font-mono font-bold text-slate-100">
                    ¥ {(activeCost.breakdown.landscape / 10000).toFixed(0)} 万
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Bill of Quantities List (8 Cols) */}
        <div className="col-span-8 p-4 overflow-y-auto bg-slate-900/90 text-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-slate-700/80 pb-2 mb-3">
              <div className="flex items-center gap-2">
                <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
                <h4 className="font-bold text-white text-sm">国家工程量清单计价明细 (BOQ)</h4>
              </div>
              <span className="text-slate-400 text-[11px]">8栋住宅楼 + 地下车库综合总计</span>
            </div>

            {/* Table */}
            <div className="overflow-x-auto border border-slate-800 rounded-lg">
              <table className="w-full text-left font-sans">
                <thead className="bg-slate-800/90 text-slate-300 text-[11px] uppercase tracking-wider font-semibold border-b border-slate-700">
                  <tr>
                    <th className="p-2.5">清单项目编码</th>
                    <th className="p-2.5">项目名称与特征</th>
                    <th className="p-2.5 text-right">工程量</th>
                    <th className="p-2.5 text-center">单位</th>
                    <th className="p-2.5 text-right">综合单价</th>
                    <th className="p-2.5 text-right">合价 (元)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 font-mono text-[11px]">
                  {activeCost.costItems.map(item => (
                    <tr key={item.id} className="hover:bg-slate-800/50 transition">
                      <td className="p-2.5 text-sky-400">{item.code}</td>
                      <td className="p-2.5 font-sans">
                        <span className="text-slate-100 font-bold block">{item.name}</span>
                        <span className="text-[10px] text-slate-400">{item.specification}</span>
                      </td>
                      <td className="p-2.5 text-right text-slate-200">{item.quantity.toLocaleString()}</td>
                      <td className="p-2.5 text-center text-slate-400">{item.unit}</td>
                      <td className="p-2.5 text-right text-slate-200">
                        ¥ {(item.materialUnitPrice + item.laborUnitPrice + item.machineryUnitPrice).toLocaleString()}
                      </td>
                      <td className="p-2.5 text-right font-bold text-emerald-400">
                        ¥ {item.totalAmount.toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-slate-400 text-[11px]">
            <span>计价依据：建设工程工程量清单计价规范 (GB50500-2013) 及最新地方信息价</span>
            <span className="text-emerald-400 font-medium">数据已与BIM对象模型完全对齐</span>
          </div>
        </div>
      </div>
    </div>
  );
}
