'use client';

import React, { useState } from 'react';
import { BIMObjectEntity, BuildingEntity } from '@/types/housebuilder';
import {
  FolderTree,
  Box,
  ChevronRight,
  ChevronDown,
  Layers,
  Search,
  Sliders,
  DollarSign,
  ShieldCheck,
  Calendar,
  Flame,
  Wrench,
  FileSpreadsheet
} from 'lucide-react';

interface BIMModelTreeProps {
  buildings: BuildingEntity[];
  bimObjects: BIMObjectEntity[];
  selectedBIMId: string | null;
  onSelectBIMObject: (id: string | null) => void;
  selectedBuildingId: string | null;
  onSelectBuilding: (id: string | null) => void;
}

export default function BIMModelTree({
  buildings,
  bimObjects,
  selectedBIMId,
  onSelectBIMObject,
  selectedBuildingId,
  onSelectBuilding
}: BIMModelTreeProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedNodes, setExpandedNodes] = useState<Record<string, boolean>>({
    'root': true,
    'bldg-1': true,
    'bldg-1-arch': true,
    'bldg-1-struct': true,
    'bldg-1-mep': true
  });

  const selectedObject = bimObjects.find(o => o.id === selectedBIMId) || bimObjects[0];

  const toggleNode = (nodeKey: string) => {
    setExpandedNodes(prev => ({ ...prev, [nodeKey]: !prev[nodeKey] }));
  };

  const filteredObjects = bimObjects.filter(
    o => o.name.toLowerCase().includes(searchTerm.toLowerCase()) || o.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="flex flex-col h-full bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-2xl text-white">
      {/* Header */}
      <div className="p-3.5 bg-slate-800/80 border-b border-slate-700/80 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 rounded-lg bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
            <FolderTree className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-100">BIM 构件系统模型树</h3>
            <span className="text-[11px] text-slate-400">HouseBuilder Object Model (HOM) 统一数据标准</span>
          </div>
        </div>
      </div>

      {/* Search Bar */}
      <div className="p-2.5 bg-slate-900/60 border-b border-slate-800">
        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-400" />
          <input
            type="text"
            placeholder="搜索构件名称、GUID、类别或系统..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
          />
        </div>
      </div>

      {/* Split View: Tree List (Left) & BIM Property Inspector (Right) */}
      <div className="grid grid-cols-12 flex-1 min-h-0 divide-x divide-slate-800">
        {/* Left: Tree View (5 Cols) */}
        <div className="col-span-5 p-2 overflow-y-auto font-mono text-xs space-y-1">
          {/* Root Project */}
          <div>
            <div
              onClick={() => toggleNode('root')}
              className="flex items-center gap-1.5 px-2 py-1 rounded hover:bg-slate-800 cursor-pointer font-bold text-sky-400"
            >
              {expandedNodes['root'] ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
              <span>上海滨江示范项目 (310115)</span>
            </div>

            {expandedNodes['root'] && (
              <div className="pl-4 space-y-1 mt-1 border-l border-slate-800 ml-3">
                {/* Master Site Plan */}
                <div className="px-2 py-1 rounded hover:bg-slate-800 cursor-pointer text-slate-300 flex items-center gap-1.5">
                  <Box className="w-3.5 h-3.5 text-emerald-400" />
                  <span>总图与地块规划 (Site)</span>
                </div>

                {/* Buildings */}
                {buildings.map(bldg => {
                  const bldgKey = bldg.id;
                  const isBldgExpanded = !!expandedNodes[bldgKey];
                  const isSelectedBldg = selectedBuildingId === bldg.id;

                  return (
                    <div key={bldg.id}>
                      <div
                        onClick={() => {
                          toggleNode(bldgKey);
                          onSelectBuilding(bldg.id);
                        }}
                        className={`flex items-center gap-1.5 px-2 py-1 rounded cursor-pointer transition ${
                          isSelectedBldg ? 'bg-sky-950/80 text-sky-300 font-bold border border-sky-800' : 'hover:bg-slate-800 text-slate-200'
                        }`}
                      >
                        {isBldgExpanded ? <ChevronDown className="w-3.5 h-3.5 text-slate-400" /> : <ChevronRight className="w-3.5 h-3.5 text-slate-400" />}
                        <span>{bldg.name} ({bldg.floorsCount}F)</span>
                      </div>

                      {isBldgExpanded && (
                        <div className="pl-4 space-y-0.5 mt-0.5 border-l border-slate-800 ml-3">
                          {/* Discipline Categories */}
                          <div className="px-2 py-1 rounded text-slate-400 text-[11px] font-sans">
                            <span className="text-slate-500">├── 建筑工程 (Architecture)</span>
                          </div>
                          <div className="px-2 py-1 rounded text-slate-400 text-[11px] font-sans">
                            <span className="text-slate-500">├── 结构工程 (Structure)</span>
                          </div>
                          <div className="px-2 py-1 rounded text-slate-400 text-[11px] font-sans">
                            <span className="text-slate-500">├── 给排水 (Plumbing)</span>
                          </div>
                          <div className="px-2 py-1 rounded text-slate-400 text-[11px] font-sans">
                            <span className="text-slate-500">├── 暖通空调 (HVAC)</span>
                          </div>
                          <div className="px-2 py-1 rounded text-slate-400 text-[11px] font-sans">
                            <span className="text-slate-500">├── 建筑电气 (Electrical)</span>
                          </div>
                          <div className="px-2 py-1 rounded text-slate-400 text-[11px] font-sans">
                            <span className="text-slate-500">└── 室内精装 (Finishing)</span>
                          </div>

                          {/* Specific BIM Objects for this Building */}
                          {bimObjects
                            .filter(obj => obj.buildingId === bldg.id)
                            .map(obj => {
                              const isSelectedObj = selectedBIMId === obj.id;
                              return (
                                <div
                                  key={obj.id}
                                  onClick={() => onSelectBIMObject(obj.id)}
                                  className={`flex items-center justify-between px-2 py-1 rounded cursor-pointer transition text-[11px] ${
                                    isSelectedObj
                                      ? 'bg-indigo-600 text-white font-bold'
                                      : 'hover:bg-slate-800 text-slate-300'
                                  }`}
                                >
                                  <div className="flex items-center gap-1.5 truncate">
                                    <Box className="w-3 h-3 text-indigo-400 shrink-0" />
                                    <span className="truncate">{obj.name}</span>
                                  </div>
                                  <span
                                    className={`px-1 rounded text-[9px] font-sans shrink-0 ${
                                      obj.constructionStatus === 'completed'
                                        ? 'bg-emerald-950 text-emerald-300'
                                        : 'bg-amber-950 text-amber-300'
                                    }`}
                                  >
                                    {obj.constructionStatus === 'completed' ? '已完成' : '施工中'}
                                  </span>
                                </div>
                              );
                            })}
                        </div>
                      )}
                    </div>
                  );
                })}

                {/* Underground Garage */}
                <div className="px-2 py-1 rounded hover:bg-slate-800 cursor-pointer text-slate-300 flex items-center gap-1.5">
                  <Box className="w-3.5 h-3.5 text-amber-400" />
                  <span>地下两层智慧车库 (45,000m²)</span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right: Selected BIM Object Inspector (7 Cols) */}
        <div className="col-span-7 p-4 overflow-y-auto bg-slate-900/90 text-xs space-y-4">
          {selectedObject ? (
            <div className="space-y-4">
              {/* Header Info */}
              <div className="border-b border-slate-700/80 pb-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-white text-base">{selectedObject.name}</h4>
                  <span className="px-2 py-0.5 rounded bg-indigo-900/60 text-indigo-300 border border-indigo-700 font-mono text-[10px]">
                    {selectedObject.category}
                  </span>
                </div>
                <p className="text-[11px] font-mono text-slate-400 mt-1">
                  IFC GUID: <span className="text-sky-400">{selectedObject.guid}</span>
                </p>
              </div>

              {/* Spatial Location */}
              <div className="bg-slate-800/60 p-3 rounded-lg border border-slate-700 space-y-2">
                <span className="font-bold text-slate-200 text-[11px] flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-sky-400" />
                  <span>空间赋码与位置</span>
                </span>
                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div>
                    <span className="text-slate-400 block text-[10px]">所属楼栋</span>
                    <span className="text-slate-200 font-medium">
                      {buildings.find(b => b.id === selectedObject.buildingId)?.name || '1号楼'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">所在楼层</span>
                    <span className="text-slate-200 font-medium">{selectedObject.floorNumber} 层</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">专业系统</span>
                    <span className="text-sky-300 font-medium capitalize">{selectedObject.system}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">关联套户</span>
                    <span className="text-slate-200 font-medium">{selectedObject.unitId || '公共区域/核心筒'}</span>
                  </div>
                </div>
              </div>

              {/* Engineering Quantity & Cost (5D BIM) */}
              <div className="bg-slate-800/60 p-3 rounded-lg border border-slate-700 space-y-2">
                <span className="font-bold text-slate-200 text-[11px] flex items-center gap-1.5">
                  <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
                  <span>工程量清单与成本造价 (5D BIM)</span>
                </span>
                <div className="grid grid-cols-3 gap-2 text-[11px]">
                  <div>
                    <span className="text-slate-400 block text-[10px]">工程量</span>
                    <span className="text-slate-100 font-bold font-mono">
                      {selectedObject.quantity} {selectedObject.unit}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">综合单价</span>
                    <span className="text-slate-100 font-bold font-mono">
                      ¥ {selectedObject.unitCost.toLocaleString()}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">合价造价</span>
                    <span className="text-emerald-400 font-bold font-mono">
                      ¥ {selectedObject.totalCost.toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>

              {/* Material & Supply Chain */}
              <div className="bg-slate-800/60 p-3 rounded-lg border border-slate-700 space-y-2">
                <span className="font-bold text-slate-200 text-[11px] flex items-center gap-1.5">
                  <FileSpreadsheet className="w-3.5 h-3.5 text-amber-400" />
                  <span>材料与生产厂家</span>
                </span>
                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div>
                    <span className="text-slate-400 block text-[10px]">规格材料</span>
                    <span className="text-slate-200">{selectedObject.material}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">供应商/承建方</span>
                    <span className="text-slate-200">{selectedObject.manufacturer}</span>
                  </div>
                </div>
              </div>

              {/* Construction, QA & Lifecycle */}
              <div className="bg-slate-800/60 p-3 rounded-lg border border-slate-700 space-y-2">
                <span className="font-bold text-slate-200 text-[11px] flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  <span>施工状态、质量检验与全生命周期</span>
                </span>
                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div>
                    <span className="text-slate-400 block text-[10px]">施工进度状态</span>
                    <span className="text-emerald-400 font-bold">
                      {selectedObject.constructionStatus === 'completed'
                        ? '已完成浇筑/安装'
                        : selectedObject.constructionStatus === 'in_progress'
                        ? '正在施工中'
                        : '已验收合格'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">质检验收结论</span>
                    <span className="text-sky-300 font-bold">
                      {selectedObject.qaStatus === 'passed' ? '实测实量合格' : '待复检'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">碳足迹排放</span>
                    <span className="text-slate-200 font-mono">{selectedObject.carbonEmissionKg} kg CO₂e</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">维保巡检周期</span>
                    <span className="text-slate-200 font-mono">{selectedObject.maintenanceCycleDays} 天 / 次</span>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-12 text-slate-500">请在左侧构件树中选择一个BIM对象查看详情</div>
          )}
        </div>
      </div>
    </div>
  );
}
