'use client';

import React, { useState } from 'react';
import { UnitFloorPlan } from '@/types/housebuilder';
import {
  Smartphone,
  Home,
  ShieldCheck,
  FileText,
  Wrench,
  Flame,
  Zap,
  Droplets,
  Calendar,
  CheckCircle2,
  PhoneCall,
  QrCode,
  KeyRound
} from 'lucide-react';

interface OwnerTwinPortalProps {
  floorplan: UnitFloorPlan;
}

export default function OwnerTwinPortal({ floorplan }: OwnerTwinPortalProps) {
  const [activeTab, setActiveTab] = useState<'twin' | 'xray' | 'equipment' | 'service'>('twin');

  return (
    <div className="flex flex-col h-full bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-2xl text-white">
      {/* Top Header */}
      <div className="p-4 bg-slate-800/80 border-b border-slate-700/80 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
            <Smartphone className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <span>中国住宅「一房一档」业主数字孪生交付与智慧运维终端</span>
              <span className="text-[11px] font-normal px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                产权唯一孪生码: SH-2026-310115-01-1602
              </span>
            </h3>
            <p className="text-[11px] text-slate-400">
              隐蔽工程三维透视、设备原厂质保说明书、全生命周期维保记录与物业管家闭环服务
            </p>
          </div>
        </div>

        {/* Tab Navigator */}
        <div className="flex bg-slate-700/80 p-0.5 rounded border border-slate-600 text-xs">
          <button
            onClick={() => setActiveTab('twin')}
            className={`px-3 py-1 rounded transition ${
              activeTab === 'twin' ? 'bg-indigo-600 text-white font-medium' : 'text-slate-300 hover:text-white'
            }`}
          >
            房屋数字档案
          </button>
          <button
            onClick={() => setActiveTab('xray')}
            className={`px-3 py-1 rounded transition ${
              activeTab === 'xray' ? 'bg-indigo-600 text-white font-medium' : 'text-slate-300 hover:text-white'
            }`}
          >
            隐蔽工程管线透视
          </button>
          <button
            onClick={() => setActiveTab('equipment')}
            className={`px-3 py-1 rounded transition ${
              activeTab === 'equipment' ? 'bg-indigo-600 text-white font-medium' : 'text-slate-300 hover:text-white'
            }`}
          >
            设备健康与维保
          </button>
          <button
            onClick={() => setActiveTab('service')}
            className={`px-3 py-1 rounded transition ${
              activeTab === 'service' ? 'bg-indigo-600 text-white font-medium' : 'text-slate-300 hover:text-white'
            }`}
          >
            一键智慧报修
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="grid grid-cols-12 flex-1 min-h-0 divide-x divide-slate-800">
        {/* Left Simulated Mobile / Owner View (4 Cols) */}
        <div className="col-span-4 p-4 bg-slate-950/60 overflow-y-auto flex flex-col items-center">
          <div className="w-full max-w-xs bg-slate-900 border-4 border-slate-700 rounded-3xl p-4 shadow-2xl space-y-3 relative text-xs">
            {/* Phone Notch */}
            <div className="w-24 h-3.5 bg-slate-700 rounded-full mx-auto mb-1" />

            {/* Property Passport Card */}
            <div className="bg-gradient-to-br from-indigo-900 to-slate-800 p-3.5 rounded-2xl border border-indigo-700/50 shadow-lg text-white space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-300">
                  DIGITAL HOUSE TWIN
                </span>
                <QrCode className="w-4 h-4 text-slate-300" />
              </div>
              <div>
                <h4 className="font-bold text-base">上海滨江示范项目 1# 1602室</h4>
                <p className="text-[11px] text-slate-300">
                  {floorplan.name} ({floorplan.grossArea} m²)
                </p>
              </div>
              <div className="flex items-center justify-between text-[10px] text-slate-300 pt-2 border-t border-indigo-800/80">
                <span>业主: 陆先生</span>
                <span className="text-emerald-400 font-bold">交付状态: 已认证</span>
              </div>
            </div>

            {/* Quick Actions in Mobile UI */}
            <div className="grid grid-cols-3 gap-1.5 text-center text-[10px]">
              <div className="bg-slate-800 p-2 rounded-xl border border-slate-700 flex flex-col items-center">
                <ShieldCheck className="w-4 h-4 text-emerald-400 mb-1" />
                <span>质量保证书</span>
              </div>
              <div className="bg-slate-800 p-2 rounded-xl border border-slate-700 flex flex-col items-center">
                <FileText className="w-4 h-4 text-sky-400 mb-1" />
                <span>使用说明书</span>
              </div>
              <div className="bg-slate-800 p-2 rounded-xl border border-slate-700 flex flex-col items-center">
                <KeyRound className="w-4 h-4 text-amber-400 mb-1" />
                <span>智能门锁授权</span>
              </div>
            </div>

            {/* Indoor Environment Snapshot */}
            <div className="bg-slate-800/80 p-3 rounded-2xl border border-slate-700 space-y-1.5 text-[11px]">
              <span className="font-bold text-slate-200 block text-[10px]">室内环境物联感知</span>
              <div className="grid grid-cols-3 gap-1 text-center font-mono">
                <div className="bg-slate-900 p-1.5 rounded">
                  <span className="text-[9px] text-slate-400 block">温度</span>
                  <span className="text-emerald-400 font-bold">23.5 ℃</span>
                </div>
                <div className="bg-slate-900 p-1.5 rounded">
                  <span className="text-[9px] text-slate-400 block">湿度</span>
                  <span className="text-sky-400 font-bold">52 %</span>
                </div>
                <div className="bg-slate-900 p-1.5 rounded">
                  <span className="text-[9px] text-slate-400 block">PM 2.5</span>
                  <span className="text-emerald-400 font-bold">12 ug</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Detail Pane based on Tab (8 Cols) */}
        <div className="col-span-8 p-4 overflow-y-auto bg-slate-900/90 text-xs space-y-4">
          {activeTab === 'twin' && (
            <div className="space-y-4">
              <div className="border-b border-slate-700 pb-2">
                <h4 className="font-bold text-white text-base">住宅全生命周期数字档案 (一房一档)</h4>
                <p className="text-[11px] text-slate-400">
                  包含从建筑规划、结构验筋、机电打压、精装材料到交房查验的完整数字化证据链
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="bg-slate-800/60 p-3 rounded-lg border border-slate-700 space-y-2">
                  <span className="font-bold text-slate-200 text-[11px] flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <span>住宅两书一表法定交付凭证</span>
                  </span>
                  <div className="space-y-1 text-[11px] text-slate-300">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span>《住宅质量保证书》 (结构终身保修，防水5年，地暖2个采暖期)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span>《住宅使用说明书》 (荷载限制、插座回路分布与检修口位置)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span>《竣工联合验收合格一览表》</span>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-800/60 p-3 rounded-lg border border-slate-700 space-y-2">
                  <span className="font-bold text-slate-200 text-[11px] flex items-center gap-1.5">
                    <FileText className="w-4 h-4 text-sky-400" />
                    <span>面积实测报告 (房管局测绘)</span>
                  </span>
                  <div className="space-y-1 text-[11px] text-slate-300 font-mono">
                    <div className="flex justify-between">
                      <span>预测建筑面积:</span>
                      <span>{floorplan.grossArea} m²</span>
                    </div>
                    <div className="flex justify-between text-emerald-400 font-bold">
                      <span>实测建筑面积:</span>
                      <span>{floorplan.grossArea} m² (误差 0.00%)</span>
                    </div>
                    <div className="flex justify-between">
                      <span>实测套内面积:</span>
                      <span>{floorplan.innerArea} m²</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'xray' && (
            <div className="space-y-4">
              <div className="border-b border-slate-700 pb-2">
                <h4 className="font-bold text-white text-base">隐蔽工程三维透视 (X-Ray MEP)</h4>
                <p className="text-[11px] text-slate-400">
                  永久留存隐蔽工程管线位置，防止业主二次装修钻孔破坏地暖管或强电电缆
                </p>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="bg-slate-800/60 p-3 rounded-lg border border-slate-700 space-y-2">
                  <div className="flex items-center gap-2 text-amber-400 font-bold">
                    <Flame className="w-4 h-4" />
                    <span>地暖盘管走向 (PE-RT)</span>
                  </div>
                  <p className="text-slate-300 text-[11px]">
                    全屋回字形铺设间距 150mm，已通过 0.8MPa 闭水保压测试，保护层厚度 30mm。
                  </p>
                </div>

                <div className="bg-slate-800/60 p-3 rounded-lg border border-slate-700 space-y-2">
                  <div className="flex items-center gap-2 text-sky-400 font-bold">
                    <Droplets className="w-4 h-4" />
                    <span>给排水管网 (PP-R/PVC)</span>
                  </div>
                  <p className="text-slate-300 text-[11px]">
                    同层排水系统，卫生间设吉博力隐藏式水箱，主立管带消音降噪螺旋消能构造。
                  </p>
                </div>

                <div className="bg-slate-800/60 p-3 rounded-lg border border-slate-700 space-y-2">
                  <div className="flex items-center gap-2 text-emerald-400 font-bold">
                    <Zap className="w-4 h-4" />
                    <span>强弱电桥架回路 (阻燃PVC)</span>
                  </div>
                  <p className="text-slate-300 text-[11px]">
                    顶板与地面开槽规范布线，客厅/主卧预留万兆光纤入户与智能家居中控总线。
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'equipment' && (
            <div className="space-y-3">
              <div className="border-b border-slate-700 pb-2">
                <h4 className="font-bold text-white text-base">套内大宗设备台账与维保日历</h4>
              </div>

              <div className="space-y-2">
                {[
                  {
                    name: '大金 VRV 系列中央空调室内外机',
                    model: 'VRV-X7 8HP 超级智能变频多联机',
                    warrantyUntil: '2034-06-28 (10年整机质保)',
                    nextService: '2026-11-15 (换季滤网清洗与冷媒测压)',
                    status: '运行正常'
                  },
                  {
                    name: '松下全热交换新风机组',
                    model: 'FY-E35PMA (HEPA微静电滤网)',
                    warrantyUntil: '2033-06-28',
                    nextService: '2026-12-01 (滤芯更换提醒)',
                    status: '运行正常'
                  },
                  {
                    name: '林内冷凝式燃气采暖热水两用炉',
                    model: 'RBS-28K88 (一级能效)',
                    warrantyUntil: '2036-06-28',
                    nextService: '2027-01-10 (热交换器除垢保养)',
                    status: '运行正常'
                  }
                ].map(eq => (
                  <div
                    key={eq.name}
                    className="bg-slate-800/60 p-3 rounded-lg border border-slate-700 flex items-center justify-between"
                  >
                    <div>
                      <h5 className="font-bold text-slate-100">{eq.name}</h5>
                      <span className="text-[11px] text-slate-400 block">{eq.model}</span>
                      <div className="flex items-center gap-3 text-[10px] text-slate-400 mt-1">
                        <span>保修期至: {eq.warrantyUntil}</span>
                        <span className="text-amber-300">下次建议维保: {eq.nextService}</span>
                      </div>
                    </div>
                    <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 text-[10px] font-bold border border-emerald-800">
                      {eq.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'service' && (
            <div className="space-y-4">
              <div className="border-b border-slate-700 pb-2">
                <h4 className="font-bold text-white text-base">物业管家一键报修派单闭环</h4>
              </div>

              <div className="bg-slate-800/60 p-4 rounded-lg border border-slate-700 space-y-3">
                <div>
                  <label className="block text-slate-300 text-[11px] font-bold mb-1">报修问题类型</label>
                  <select className="w-full bg-slate-700 border border-slate-600 rounded p-2 text-slate-200">
                    <option>空调/地暖/新风系统异常</option>
                    <option>智能门锁/可视对讲调试</option>
                    <option>卫浴龙头/管道轻微渗水</option>
                    <option>精装木地板/踢脚线收口维护</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 text-[11px] font-bold mb-1">问题详细描述</label>
                  <textarea
                    rows={3}
                    placeholder="请描述具体位置与故障现象，管家将在15分钟内响应上门..."
                    className="w-full bg-slate-700 border border-slate-600 rounded p-2 text-slate-200 placeholder-slate-400"
                  />
                </div>

                <button className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 font-bold rounded-lg text-white shadow-lg transition">
                  提交报修工单并通知专职物业管家
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
