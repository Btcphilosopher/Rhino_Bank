'use client';

import React, { useState } from 'react';
import { UnitFloorPlan, RoomEntity } from '@/types/housebuilder';
import {
  Maximize,
  Compass,
  Sun,
  Wind,
  Layers,
  FileCheck,
  Plus,
  Trash2,
  Move,
  Info,
  Sliders,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

interface FloorplanEditor2DProps {
  floorplan: UnitFloorPlan;
  onUpdateFloorplan: (updated: UnitFloorPlan) => void;
  availablePlans: UnitFloorPlan[];
  onSelectPlan: (plan: UnitFloorPlan) => void;
}

export default function FloorplanEditor2D({
  floorplan,
  onUpdateFloorplan,
  availablePlans,
  onSelectPlan
}: FloorplanEditor2DProps) {
  const [selectedRoomId, setSelectedRoomId] = useState<string | null>(floorplan.rooms[0]?.id || null);
  const [activeTab, setActiveTab] = useState<'editor' | 'analysis' | 'decor'>('editor');
  const [wallThickness, setWallThickness] = useState<number>(0.24);

  const selectedRoom = floorplan.rooms.find(r => r.id === selectedRoomId);

  // Recalculate areas when room dimensions change
  const handleUpdateRoom = (roomId: string, updates: Partial<RoomEntity>) => {
    const newRooms = floorplan.rooms.map(r => {
      if (r.id === roomId) {
        const newW = updates.w !== undefined ? updates.w : r.w;
        const newH = updates.h !== undefined ? updates.h : r.h;
        const newArea = Number((newW * newH).toFixed(1));
        return {
          ...r,
          ...updates,
          w: newW,
          h: newH,
          area: newArea
        };
      }
      return r;
    });

    // Recompute total usable area
    const usableArea = Number(newRooms.reduce((sum, r) => sum + r.area, 0).toFixed(1));
    const innerArea = Number((usableArea * 1.085).toFixed(1)); // factoring structural walls
    const sharedArea = Number((innerArea * 0.225).toFixed(1)); // ~18-22% public shared core
    const grossArea = Number((innerArea + sharedArea).toFixed(1));
    const efficiencyRatio = Number(((innerArea / grossArea) * 100).toFixed(1));

    onUpdateFloorplan({
      ...floorplan,
      rooms: newRooms,
      usableArea,
      innerArea,
      grossArea,
      sharedArea,
      efficiencyRatio
    });
  };

  const svgScale = 38; // 38px per meter
  const svgWidth = 520;
  const svgHeight = 440;
  const originX = 40;
  const originY = 60;

  return (
    <div className="flex flex-col h-full bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-2xl text-white">
      {/* Header Bar */}
      <div className="flex items-center justify-between px-4 py-3 bg-slate-800/80 border-b border-slate-700/80">
        <div className="flex items-center gap-3">
          <div className="p-1.5 rounded-lg bg-sky-500/20 text-sky-400 border border-sky-500/30">
            <Compass className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <span>中国住宅户型参数化设计器</span>
              <span className="text-[11px] font-normal px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                套内赋码: {floorplan.id}
              </span>
            </h3>
            <p className="text-[11px] text-slate-400">
              精准计算套内建筑面积、得房率、窗地比与南北通风动线
            </p>
          </div>
        </div>

        {/* Floorplan Presets Selector */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400">标准户型库:</span>
          <select
            value={floorplan.id}
            onChange={e => {
              const p = availablePlans.find(x => x.id === e.target.value);
              if (p) onSelectPlan(p);
            }}
            className="bg-slate-700 border border-slate-600 rounded px-2.5 py-1 text-xs text-slate-100 focus:outline-none focus:ring-1 focus:ring-sky-500 font-medium"
          >
            {availablePlans.map(p => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>

          <div className="flex bg-slate-700/80 p-0.5 rounded border border-slate-600 ml-2">
            <button
              onClick={() => setActiveTab('editor')}
              className={`px-2.5 py-1 rounded text-xs transition ${
                activeTab === 'editor' ? 'bg-sky-600 text-white font-medium' : 'text-slate-300 hover:text-white'
              }`}
            >
              2D平面交互
            </button>
            <button
              onClick={() => setActiveTab('analysis')}
              className={`px-2.5 py-1 rounded text-xs transition ${
                activeTab === 'analysis' ? 'bg-sky-600 text-white font-medium' : 'text-slate-300 hover:text-white'
              }`}
            >
              户型诊断报告
            </button>
          </div>
        </div>
      </div>

      {/* Main Area: Split 2D Canvas & Parameter Dashboard */}
      <div className="grid grid-cols-12 flex-1 min-h-0 divide-x divide-slate-800">
        {/* Left: 2D Interactive SVG Floorplan Canvas (7 Cols) */}
        <div className="col-span-7 p-4 flex flex-col justify-between bg-slate-950/60 relative overflow-hidden">
          {/* Compass Rose */}
          <div className="absolute top-4 right-4 z-10 flex flex-col items-center bg-slate-800/80 px-2 py-1.5 rounded-lg border border-slate-700 text-[10px] text-slate-300">
            <span className="font-bold text-red-400">N (北)</span>
            <div className="w-4 h-4 my-0.5 border border-slate-500 rounded-full flex items-center justify-center">
              <div className="w-0.5 h-3 bg-red-400 -translate-y-0.5" />
            </div>
            <span className="font-bold text-sky-400">S (南)</span>
          </div>

          {/* SVG Floorplan Canvas */}
          <div className="flex-1 flex items-center justify-center">
            <svg
              width={svgWidth}
              height={svgHeight}
              className="bg-slate-900 border border-slate-800 rounded-lg shadow-inner"
            >
              {/* Grid Background */}
              <defs>
                <pattern id="grid" width="38" height="38" patternUnits="userSpaceOnUse">
                  <path d="M 38 0 L 0 0 0 38" fill="none" stroke="#1e293b" strokeWidth="0.8" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grid)" />

              {/* Render Room Boundaries */}
              {floorplan.rooms.map(room => {
                const rx = originX + room.x * svgScale;
                const ry = originY + room.y * svgScale;
                const rw = room.w * svgScale;
                const rh = room.h * svgScale;
                const isSelected = selectedRoomId === room.id;

                let fillBg = '#1e293b';
                let strokeColor = '#475569';
                if (room.type === 'master_bedroom' || room.type === 'bedroom') {
                  fillBg = isSelected ? '#1e3a8a' : '#172554';
                  strokeColor = '#3b82f6';
                } else if (room.type === 'living') {
                  fillBg = isSelected ? '#065f46' : '#064e3b';
                  strokeColor = '#10b981';
                } else if (room.type === 'kitchen' || room.type === 'bathroom') {
                  fillBg = isSelected ? '#78350f' : '#451a03';
                  strokeColor = '#f59e0b';
                } else if (room.type === 'balcony') {
                  fillBg = isSelected ? '#581c87' : '#3b0764';
                  strokeColor = '#a855f7';
                }

                return (
                  <g
                    key={room.id}
                    onClick={() => setSelectedRoomId(room.id)}
                    className="cursor-pointer transition duration-150"
                  >
                    {/* Room Floor Rectangle */}
                    <rect
                      x={rx}
                      y={ry}
                      width={rw}
                      height={rh}
                      fill={fillBg}
                      stroke={strokeColor}
                      strokeWidth={isSelected ? 2.5 : 1.2}
                      opacity={0.85}
                      rx={3}
                    />

                    {/* Room Name & Area Labels */}
                    <text
                      x={rx + rw / 2}
                      y={ry + rh / 2 - 6}
                      textAnchor="middle"
                      fill="#ffffff"
                      fontSize="12"
                      fontWeight="bold"
                    >
                      {room.name}
                    </text>
                    <text
                      x={rx + rw / 2}
                      y={ry + rh / 2 + 10}
                      textAnchor="middle"
                      fill="#94a3b8"
                      fontSize="11"
                      fontFamily="monospace"
                    >
                      {room.area.toFixed(1)} m²
                    </text>
                    <text
                      x={rx + rw / 2}
                      y={ry + rh / 2 + 24}
                      textAnchor="middle"
                      fill="#64748b"
                      fontSize="9"
                      fontFamily="monospace"
                    >
                      {room.w.toFixed(1)}m × {room.h.toFixed(1)}m
                    </text>

                    {/* Window symbols on exterior edges */}
                    {room.windowsCount > 0 && (
                      <line
                        x1={rx + rw * 0.2}
                        y1={room.orientation === 'south' ? ry + rh : ry}
                        x2={rx + rw * 0.8}
                        y2={room.orientation === 'south' ? ry + rh : ry}
                        stroke="#38bdf8"
                        strokeWidth="3.5"
                      />
                    )}
                  </g>
                );
              })}

              {/* Master Outer Dimension Markers */}
              <line x1={originX} y1={originY - 20} x2={originX + 11.2 * svgScale} y2={originY - 20} stroke="#64748b" strokeWidth="1" />
              <text x={originX + 5.6 * svgScale} y={originY - 25} fill="#94a3b8" fontSize="10" textAnchor="middle" fontFamily="monospace">
                总开间面宽：11.20 m
              </text>

              <line x1={originX - 20} y1={originY} x2={originX - 20} y2={originY + 9.5 * svgScale} stroke="#64748b" strokeWidth="1" />
              <text
                x={originX - 25}
                y={originY + 4.75 * svgScale}
                fill="#94a3b8"
                fontSize="10"
                textAnchor="middle"
                transform={`rotate(-90 ${originX - 25} ${originY + 4.75 * svgScale})`}
                fontFamily="monospace"
              >
                总进深长度：9.50 m
              </text>
            </svg>
          </div>

          {/* Quick Metrics Strip */}
          <div className="grid grid-cols-4 gap-2 pt-2 border-t border-slate-800 text-xs">
            <div className="bg-slate-800/80 p-2 rounded-lg">
              <span className="text-slate-400 text-[10px] block">建筑面积 (GFA)</span>
              <span className="text-sm font-bold text-white font-mono">{floorplan.grossArea} m²</span>
            </div>
            <div className="bg-slate-800/80 p-2 rounded-lg">
              <span className="text-slate-400 text-[10px] block">套内使用面积</span>
              <span className="text-sm font-bold text-emerald-400 font-mono">{floorplan.usableArea} m²</span>
            </div>
            <div className="bg-slate-800/80 p-2 rounded-lg">
              <span className="text-slate-400 text-[10px] block">得房率</span>
              <span className="text-sm font-bold text-sky-400 font-mono">{floorplan.efficiencyRatio}%</span>
            </div>
            <div className="bg-slate-800/80 p-2 rounded-lg">
              <span className="text-slate-400 text-[10px] block">采光通风等级</span>
              <span className="text-sm font-bold text-amber-400">{floorplan.daylightRating}·{floorplan.ventilationRating}</span>
            </div>
          </div>
        </div>

        {/* Right: Room Inspector & Parametric Engine Panel (5 Cols) */}
        <div className="col-span-5 p-4 flex flex-col justify-between overflow-y-auto bg-slate-900/90 text-xs space-y-4">
          {activeTab === 'editor' ? (
            <>
              {selectedRoom ? (
                <div className="space-y-3.5">
                  <div className="flex items-center justify-between border-b border-slate-700/80 pb-2">
                    <div>
                      <h4 className="font-bold text-white text-sm flex items-center gap-1.5">
                        <span>{selectedRoom.name}</span>
                        <span className="px-1.5 py-0.5 rounded bg-sky-900/60 text-sky-300 text-[10px] font-mono">
                          {selectedRoom.type}
                        </span>
                      </h4>
                      <span className="text-[11px] text-slate-400">房间精细参数与BIM建筑构件绑定</span>
                    </div>
                    <span className="text-base font-bold text-emerald-400 font-mono">
                      {selectedRoom.area.toFixed(1)} m²
                    </span>
                  </div>

                  {/* Parametric Dimension Sliders */}
                  <div className="space-y-3 bg-slate-800/60 p-3 rounded-lg border border-slate-700">
                    <div className="space-y-1">
                      <div className="flex justify-between text-slate-300 text-[11px]">
                        <span>开间面宽 (W)</span>
                        <span className="font-mono text-sky-300 font-bold">{selectedRoom.w.toFixed(1)} m</span>
                      </div>
                      <input
                        type="range"
                        min="1.8"
                        max="7.2"
                        step="0.1"
                        value={selectedRoom.w}
                        onChange={e => handleUpdateRoom(selectedRoom.id, { w: parseFloat(e.target.value) })}
                        className="w-full h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-sky-500"
                      />
                    </div>

                    <div className="space-y-1">
                      <div className="flex justify-between text-slate-300 text-[11px]">
                        <span>进深长度 (H)</span>
                        <span className="font-mono text-sky-300 font-bold">{selectedRoom.h.toFixed(1)} m</span>
                      </div>
                      <input
                        type="range"
                        min="1.8"
                        max="7.2"
                        step="0.1"
                        value={selectedRoom.h}
                        onChange={e => handleUpdateRoom(selectedRoom.id, { h: parseFloat(e.target.value) })}
                        className="w-full h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-sky-500"
                      />
                    </div>

                    <div className="flex items-center justify-between text-[11px] pt-1 text-slate-300">
                      <span>采光窗洞数量</span>
                      <div className="flex items-center gap-1">
                        {[0, 1, 2, 3].map(cnt => (
                          <button
                            key={cnt}
                            onClick={() => handleUpdateRoom(selectedRoom.id, { windowsCount: cnt })}
                            className={`px-2 py-0.5 rounded font-mono ${
                              selectedRoom.windowsCount === cnt
                                ? 'bg-sky-600 text-white font-bold'
                                : 'bg-slate-700 text-slate-400 hover:text-white'
                            }`}
                          >
                            {cnt}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Room Specifications & Interior Systems */}
                  <div className="space-y-2 bg-slate-800/40 p-3 rounded-lg border border-slate-800">
                    <span className="font-bold text-slate-300 text-[11px] block">房间精装与暖通配置</span>
                    <div className="grid grid-cols-2 gap-2 text-[11px]">
                      <div>
                        <span className="text-slate-400 block text-[10px]">地面材质</span>
                        <span className="text-slate-200 font-medium">{selectedRoom.floorFinish}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px]">墙面面层</span>
                        <span className="text-slate-200 font-medium">{selectedRoom.wallFinish}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px]">空调新风</span>
                        <span className="text-slate-200 font-medium">{selectedRoom.hvacType}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px]">地暖配置</span>
                        <span className="text-emerald-400 font-medium">
                          {selectedRoom.underfloorHeating ? '已覆盖地暖管网' : '未敷设'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-12 text-slate-500">
                  请在左侧平面图中点击选择房间进行参数化调整
                </div>
              )}
            </>
          ) : (
            /* Analysis Tab */
            <div className="space-y-3">
              <div className="border-b border-slate-700 pb-2">
                <h4 className="font-bold text-white text-sm">户型空间价值与规范诊断</h4>
                <p className="text-[11px] text-slate-400">基于《住宅设计规范》GB 50096-2011 智能评估</p>
              </div>

              <div className="space-y-2 text-[11px]">
                <div className="flex items-center justify-between p-2.5 rounded bg-emerald-950/40 border border-emerald-800/60 text-emerald-300">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <div>
                      <span className="font-bold block">空间动静分区与干湿分离</span>
                      <span className="text-[10px] text-emerald-400/80">主卧独立卫浴套房，动线流畅零干扰</span>
                    </div>
                  </div>
                  <span className="font-bold">合规</span>
                </div>

                <div className="flex items-center justify-between p-2.5 rounded bg-sky-950/40 border border-sky-800/60 text-sky-300">
                  <div className="flex items-center gap-2">
                    <Sun className="w-4 h-4 text-sky-400" />
                    <div>
                      <span className="font-bold block">南向采光面宽比 (三开间朝南)</span>
                      <span className="text-[10px] text-sky-400/80">南向总采光面宽 11.2m，采光极佳</span>
                    </div>
                  </div>
                  <span className="font-bold">优秀</span>
                </div>

                <div className="flex items-center justify-between p-2.5 rounded bg-slate-800 p-2.5 border border-slate-700 text-slate-300">
                  <div className="flex items-center gap-2">
                    <Wind className="w-4 h-4 text-slate-400" />
                    <div>
                      <span className="font-bold block">自然对流通风 (南北通透)</span>
                      <span className="text-[10px] text-slate-400">客餐厅贯通阳台与北向厨房窗</span>
                    </div>
                  </div>
                  <span className="font-bold">达标</span>
                </div>
              </div>
            </div>
          )}

          {/* Bottom Action */}
          <div className="pt-2 border-t border-slate-800 flex justify-between items-center text-[11px] text-slate-400">
            <span>层高：3.00m (净高 2.75m)</span>
            <span className="text-sky-400 font-medium">BIM模型已同步联动更新</span>
          </div>
        </div>
      </div>
    </div>
  );
}
