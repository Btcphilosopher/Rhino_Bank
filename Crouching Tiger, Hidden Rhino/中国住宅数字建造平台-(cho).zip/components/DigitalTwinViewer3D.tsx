'use client';

import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import {
  BuildingEntity,
  UnitFloorPlan,
  TowerCraneEntity,
  DefectEntity,
  CityConfig
} from '@/types/housebuilder';
import {
  Play,
  Pause,
  RotateCcw,
  Sun,
  Layers,
  Eye,
  AlertTriangle,
  Compass,
  Maximize2,
  Box,
  Building,
  Zap
} from 'lucide-react';

interface DigitalTwinViewer3DProps {
  buildings: BuildingEntity[];
  selectedBuildingId: string | null;
  onSelectBuilding: (id: string | null) => void;
  selectedFloor: number | null;
  onSelectFloor: (floor: number | null) => void;
  selectedFloorPlan: UnitFloorPlan;
  viewMode: 'community' | 'building' | 'floor' | 'interior';
  onViewModeChange: (mode: 'community' | 'building' | 'floor' | 'interior') => void;
  daylightHour: number;
  onDaylightHourChange: (hour: number) => void;
  city: CityConfig;
  constructionDay: number;
  onConstructionDayChange: (day: number) => void;
  isSimulatingConstruction: boolean;
  onToggleSimulatingConstruction: () => void;
  cranes: TowerCraneEntity[];
  defects: DefectEntity[];
  onSelectDefect?: (defect: DefectEntity) => void;
  renderStyle: 'realistic' | 'clay' | 'wireframe' | 'construction_status';
  onRenderStyleChange: (style: 'realistic' | 'clay' | 'wireframe' | 'construction_status') => void;
}

export default function DigitalTwinViewer3D({
  buildings,
  selectedBuildingId,
  onSelectBuilding,
  selectedFloor,
  onSelectFloor,
  selectedFloorPlan,
  viewMode,
  onViewModeChange,
  daylightHour,
  onDaylightHourChange,
  city,
  constructionDay,
  onConstructionDayChange,
  isSimulatingConstruction,
  onToggleSimulatingConstruction,
  cranes,
  defects,
  onSelectDefect,
  renderStyle,
  onRenderStyleChange
}: DigitalTwinViewer3DProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const sunLightRef = useRef<THREE.DirectionalLight | null>(null);
  const sunSphereRef = useRef<THREE.Mesh | null>(null);
  const buildingMeshesRef = useRef<Map<string, THREE.Group>>(new Map());
  const craneMeshesRef = useRef<Map<string, { group: THREE.Group; arm: THREE.Group; trolley: THREE.Mesh }>>(new Map());
  const defectPinsRef = useRef<Map<string, THREE.Mesh>>(new Map());
  const raycasterRef = useRef<THREE.Raycaster>(new THREE.Raycaster());
  const mouseRef = useRef<THREE.Vector2>(new THREE.Vector2());

  // Camera Orbit Control state
  const isDraggingRef = useRef(false);
  const isPanningRef = useRef(false);
  const previousMousePositionRef = useRef({ x: 0, y: 0 });
  const cameraTargetRef = useRef<THREE.Vector3>(new THREE.Vector3(0, 20, 0));
  const cameraSphericalRef = useRef<{ radius: number; theta: number; phi: number }>({
    radius: 180,
    theta: Math.PI / 4,
    phi: Math.PI / 3.2
  });

  // Helper to update camera from spherical coords
  const updateCamera = () => {
    if (!cameraRef.current) return;
    const { radius, theta, phi } = cameraSphericalRef.current;
    const target = cameraTargetRef.current;

    const x = target.x + radius * Math.sin(phi) * Math.sin(theta);
    const y = target.y + radius * Math.cos(phi);
    const z = target.z + radius * Math.sin(phi) * Math.cos(theta);

    cameraRef.current.position.set(x, y, z);
    cameraRef.current.lookAt(target);
  };

  const [hoveredBuildingName, setHoveredBuildingName] = useState<string | null>(null);
  const [isExploded, setIsExploded] = useState(false);

  // Initialize Three.js Scene
  useEffect(() => {
    if (!containerRef.current) return;
    const container = containerRef.current;
    const width = container.clientWidth;
    const height = container.clientHeight;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0xf1f5f9); // High-spec slate background
    scene.fog = new THREE.FogExp2(0xf1f5f9, 0.0025);
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.5, 2000);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Ambient & Hemisphere Lights
    const hemiLight = new THREE.HemisphereLight(0xffffff, 0x444455, 0.65);
    hemiLight.position.set(0, 200, 0);
    scene.add(hemiLight);

    const ambientLight = new THREE.AmbientLight(0xffffff, 0.35);
    scene.add(ambientLight);

    // Directional Sun Light with Shadows
    const sunLight = new THREE.DirectionalLight(0xfff8ee, 1.6);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.width = 2048;
    sunLight.shadow.mapSize.height = 2048;
    sunLight.shadow.camera.near = 10;
    sunLight.shadow.camera.far = 400;
    sunLight.shadow.camera.left = -150;
    sunLight.shadow.camera.right = 150;
    sunLight.shadow.camera.top = 150;
    sunLight.shadow.camera.bottom = -150;
    sunLight.shadow.bias = -0.0005;
    scene.add(sunLight);
    sunLightRef.current = sunLight;

    // Sun visual orb
    const sunGeo = new THREE.SphereGeometry(4, 16, 16);
    const sunMat = new THREE.MeshBasicMaterial({ color: 0xffd166 });
    const sunMesh = new THREE.Mesh(sunGeo, sunMat);
    scene.add(sunMesh);
    sunSphereRef.current = sunMesh;

    // Build Master Site: Ground, Roads, Courtyard, Underground Garage Entrance
    buildSiteTerrain(scene);

    // Update Camera position initially
    updateCamera();

    // Render loop
    const animate = () => {
      animationFrameRef.current = requestAnimationFrame(animate);

      // Rotate cranes slightly for live feel
      craneMeshesRef.current.forEach((craneObj, id) => {
        const craneData = cranes.find(c => c.id === id);
        if (craneData && craneData.status === 'operating') {
          craneObj.arm.rotation.y += 0.002;
        }
      });

      if (rendererRef.current && sceneRef.current && cameraRef.current) {
        rendererRef.current.render(sceneRef.current, cameraRef.current);
      }
    };
    animate();

    const handleResize = () => {
      if (!containerRef.current || !rendererRef.current || !cameraRef.current) return;
      const w = containerRef.current.clientWidth;
      const h = containerRef.current.clientHeight;
      cameraRef.current.aspect = w / h;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
      renderer.dispose();
    };
  }, []);

  // Update Sun Position based on daylightHour & city latitude
  useEffect(() => {
    if (!sunLightRef.current || !sunSphereRef.current || !sceneRef.current) return;
    const hour = daylightHour;
    const latRad = (city.latitude * Math.PI) / 180;
    // Solar calculation approximate
    const solarHourAngle = ((hour - 12) * 15 * Math.PI) / 180;
    const declination = (23.45 * Math.PI) / 180 * Math.sin(((284 + 172) / 365) * 2 * Math.PI); // Summer/Fall mid

    const sinAlt = Math.sin(latRad) * Math.sin(declination) + Math.cos(latRad) * Math.cos(declination) * Math.cos(solarHourAngle);
    const altitude = Math.asin(Math.max(-1, Math.min(1, sinAlt)));
    const cosAz = (Math.sin(declination) - Math.sin(latRad) * sinAlt) / (Math.cos(latRad) * Math.cos(altitude));
    let azimuth = Math.acos(Math.max(-1, Math.min(1, cosAz)));
    if (solarHourAngle > 0) azimuth = 2 * Math.PI - azimuth;

    const sunDist = 180;
    const sunY = Math.max(2, Math.sin(altitude) * sunDist);
    const sunX = Math.sin(azimuth) * Math.cos(altitude) * sunDist;
    const sunZ = Math.cos(azimuth) * Math.cos(altitude) * sunDist;

    sunLightRef.current.position.set(sunX, sunY, sunZ);
    sunSphereRef.current.position.set(sunX, sunY, sunZ);

    const isNight = hour < 6 || hour > 19;
    sunLightRef.current.intensity = isNight ? 0.05 : Math.max(0.2, Math.sin(altitude) * 1.8);
    sunLightRef.current.color.set(hour < 7.5 || hour > 17.5 ? 0xffaa66 : 0xfff8ee);

    // Adjust scene background for day/dusk/night
    if (sceneRef.current) {
      if (isNight) {
        sceneRef.current.background = new THREE.Color(0x0f172a);
        if (sceneRef.current.fog) sceneRef.current.fog.color = new THREE.Color(0x0f172a);
      } else if (hour < 7.5 || hour > 17.5) {
        sceneRef.current.background = new THREE.Color(0xfde68a);
        if (sceneRef.current.fog) sceneRef.current.fog.color = new THREE.Color(0xfde68a);
      } else {
        sceneRef.current.background = new THREE.Color(0xf1f5f9);
        if (sceneRef.current.fog) sceneRef.current.fog.color = new THREE.Color(0xf1f5f9);
      }
    }
  }, [daylightHour, city]);

  // Build / Update 3D Buildings based on Construction Day, View Mode & Render Style
  useEffect(() => {
    if (!sceneRef.current) return;
    const scene = sceneRef.current;

    // Remove existing buildings from scene
    buildingMeshesRef.current.forEach(mesh => scene.remove(mesh));
    buildingMeshesRef.current.clear();

    // 4D Construction progress logic
    // Days 0-100: Ground & Foundation
    // Days 100-400: Floors 1-26 structure
    // Days 400-550: MEP & Facade
    // Days 550-700: Interior & Handover
    const activeFloorsMax = Math.min(26, Math.max(0, Math.floor((constructionDay - 80) / 12)));

    buildings.forEach(bldg => {
      const bldgGroup = new THREE.Group();
      bldgGroup.position.set(bldg.position[0], bldg.position[1], bldg.position[2]);
      bldgGroup.rotation.y = (bldg.rotation * Math.PI) / 180;
      bldgGroup.userData = { buildingId: bldg.id, name: bldg.name };

      const isSelected = selectedBuildingId === bldg.id;
      const bldgFloors = isSimulatingConstruction ? activeFloorsMax : bldg.floorsCount;

      if (bldgFloors > 0) {
        // Create floors
        for (let f = 1; f <= bldgFloors; f++) {
          const isFloorSelected = isSelected && selectedFloor === f;
          const floorY = (f - 1) * bldg.floorHeight + (isExploded && isSelected ? f * 1.5 : 0);

          const floorMesh = createFloorMesh({
            building: bldg,
            floorIndex: f,
            renderStyle,
            isSelected: isFloorSelected || (isSelected && selectedFloor === null),
            isTopActiveFloor: isSimulatingConstruction && f === bldgFloors && f < bldg.floorsCount
          });
          floorMesh.position.y = floorY;
          floorMesh.userData = { buildingId: bldg.id, floorIndex: f };
          bldgGroup.add(floorMesh);
        }

        // Add Podium & Underground Base
        const baseGeo = new THREE.BoxGeometry(bldg.length + 4, 3.5, bldg.width + 4);
        const baseMat = new THREE.MeshStandardMaterial({
          color: renderStyle === 'clay' ? 0xe2e8f0 : 0x334155,
          roughness: 0.8
        });
        const baseMesh = new THREE.Mesh(baseGeo, baseMat);
        baseMesh.position.y = -1.75;
        baseMesh.receiveShadow = true;
        bldgGroup.add(baseMesh);

        // Add Crown / Roof structure if completed
        if (bldgFloors >= bldg.floorsCount) {
          const roofGeo = new THREE.BoxGeometry(bldg.length - 2, 4.0, bldg.width - 2);
          const roofMat = new THREE.MeshStandardMaterial({
            color: renderStyle === 'clay' ? 0xf8fafc : 0x1e293b,
            metalness: 0.2,
            roughness: 0.6
          });
          const roofMesh = new THREE.Mesh(roofGeo, roofMat);
          roofMesh.position.y = bldg.floorsCount * bldg.floorHeight + 2.0 + (isExploded && isSelected ? (bldg.floorsCount + 1) * 1.5 : 0);
          roofMesh.castShadow = true;
          bldgGroup.add(roofMesh);
        }
      }

      scene.add(bldgGroup);
      buildingMeshesRef.current.set(bldg.id, bldgGroup);
    });

    // Rebuild Tower Cranes
    craneMeshesRef.current.forEach(c => scene.remove(c.group));
    craneMeshesRef.current.clear();

    cranes.forEach(crane => {
      const craneObj = createTowerCraneMesh(crane);
      scene.add(craneObj.group);
      craneMeshesRef.current.set(crane.id, craneObj);
    });

    // Rebuild Defect Pins
    defectPinsRef.current.forEach(p => scene.remove(p));
    defectPinsRef.current.clear();

    defects.forEach(defect => {
      const pin = createDefectPinMesh(defect);
      scene.add(pin);
      defectPinsRef.current.set(defect.id, pin);
    });
  }, [
    buildings,
    selectedBuildingId,
    selectedFloor,
    renderStyle,
    constructionDay,
    isSimulatingConstruction,
    isExploded,
    cranes,
    defects
  ]);

  // Camera Focus Switch based on View Mode and Selection
  useEffect(() => {
    if (viewMode === 'community') {
      cameraTargetRef.current.set(0, 15, 0);
      cameraSphericalRef.current = { radius: 210, theta: Math.PI / 4, phi: Math.PI / 3.2 };
    } else if (viewMode === 'building' && selectedBuildingId) {
      const bldg = buildings.find(b => b.id === selectedBuildingId);
      if (bldg) {
        cameraTargetRef.current.set(bldg.position[0], 40, bldg.position[2]);
        cameraSphericalRef.current = { radius: 95, theta: Math.PI / 4.5, phi: Math.PI / 2.8 };
      }
    } else if ((viewMode === 'floor' || viewMode === 'interior') && selectedBuildingId) {
      const bldg = buildings.find(b => b.id === selectedBuildingId);
      if (bldg) {
        const floorY = ((selectedFloor || 12) - 1) * bldg.floorHeight;
        cameraTargetRef.current.set(bldg.position[0], floorY + 4, bldg.position[2]);
        cameraSphericalRef.current = { radius: 45, theta: Math.PI / 5, phi: Math.PI / 3 };
      }
    }
    updateCamera();
  }, [viewMode, selectedBuildingId, selectedFloor, buildings]);

  // Mouse Interaction handlers for Pan / Orbit / Zoom
  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button === 0) {
      isDraggingRef.current = true;
    } else if (e.button === 2) {
      isPanningRef.current = true;
    }
    previousMousePositionRef.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!containerRef.current || !cameraRef.current || !sceneRef.current) return;

    const deltaX = e.clientX - previousMousePositionRef.current.x;
    const deltaY = e.clientY - previousMousePositionRef.current.y;
    previousMousePositionRef.current = { x: e.clientX, y: e.clientY };

    if (isDraggingRef.current) {
      cameraSphericalRef.current.theta -= deltaX * 0.006;
      cameraSphericalRef.current.phi = Math.max(
        0.1,
        Math.min(Math.PI / 2.05, cameraSphericalRef.current.phi - deltaY * 0.006)
      );
      updateCamera();
    } else if (isPanningRef.current) {
      const panSpeed = cameraSphericalRef.current.radius * 0.001;
      const right = new THREE.Vector3();
      cameraRef.current.getWorldDirection(right);
      right.cross(cameraRef.current.up).normalize();

      cameraTargetRef.current.addScaledVector(right, -deltaX * panSpeed);
      cameraTargetRef.current.y += deltaY * panSpeed;
      updateCamera();
    } else {
      // Raycasting for hover tooltip
      const rect = containerRef.current.getBoundingClientRect();
      mouseRef.current.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouseRef.current.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      raycasterRef.current.setFromCamera(mouseRef.current, cameraRef.current);
      const intersects = raycasterRef.current.intersectObjects(sceneRef.current.children, true);

      let foundBldg: string | null = null;
      for (const hit of intersects) {
        let cur: THREE.Object3D | null = hit.object;
        while (cur) {
          if (cur.userData?.buildingId) {
            foundBldg = cur.userData.name || '住宅楼栋';
            break;
          }
          cur = cur.parent;
        }
        if (foundBldg) break;
      }
      setHoveredBuildingName(foundBldg);
    }
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
    isPanningRef.current = false;
  };

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    cameraSphericalRef.current.radius = Math.max(
      15,
      Math.min(450, cameraSphericalRef.current.radius + e.deltaY * 0.15)
    );
    updateCamera();
  };

  const handleClick = (e: React.MouseEvent) => {
    if (!containerRef.current || !cameraRef.current || !sceneRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    mouseRef.current.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    mouseRef.current.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    raycasterRef.current.setFromCamera(mouseRef.current, cameraRef.current);
    const intersects = raycasterRef.current.intersectObjects(sceneRef.current.children, true);

    for (const hit of intersects) {
      // Check defect pin hit first
      if (hit.object.userData?.defectId) {
        const d = defects.find(x => x.id === hit.object.userData.defectId);
        if (d && onSelectDefect) {
          onSelectDefect(d);
          return;
        }
      }

      // Check building hit
      let cur: THREE.Object3D | null = hit.object;
      while (cur) {
        if (cur.userData?.buildingId) {
          onSelectBuilding(cur.userData.buildingId);
          if (cur.userData.floorIndex) {
            onSelectFloor(cur.userData.floorIndex);
          }
          if (viewMode === 'community') {
            onViewModeChange('building');
          }
          return;
        }
        cur = cur.parent;
      }
    }
  };

  return (
    <div className="relative w-full h-full select-none overflow-hidden bg-slate-900">
      {/* 3D WebGL Canvas */}
      <div
        ref={containerRef}
        className="w-full h-full cursor-grab active:cursor-grabbing"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onWheel={handleWheel}
        onClick={handleClick}
        onContextMenu={e => e.preventDefault()}
      />

      {/* Top Floating Viewport Control Bar */}
      <div className="absolute top-4 left-4 z-20 flex items-center gap-2 bg-slate-900/85 backdrop-blur-md px-3 py-2 rounded-lg border border-slate-700 shadow-xl text-white text-xs">
        <div className="flex items-center gap-1.5 border-r border-slate-700 pr-3 mr-1">
          <Building className="w-4 h-4 text-emerald-400" />
          <span className="font-semibold tracking-wide">3D DIGITAL TWIN</span>
        </div>

        {/* View mode switcher */}
        <div className="flex bg-slate-800 rounded p-0.5 border border-slate-700">
          <button
            onClick={() => onViewModeChange('community')}
            className={`px-2.5 py-1 rounded font-medium transition ${
              viewMode === 'community' ? 'bg-sky-600 text-white shadow' : 'text-slate-300 hover:text-white'
            }`}
          >
            社区全景 (8栋)
          </button>
          <button
            onClick={() => {
              if (!selectedBuildingId) onSelectBuilding(buildings[0]?.id || null);
              onViewModeChange('building');
            }}
            className={`px-2.5 py-1 rounded font-medium transition ${
              viewMode === 'building' ? 'bg-sky-600 text-white shadow' : 'text-slate-300 hover:text-white'
            }`}
          >
            楼栋单体
          </button>
          <button
            onClick={() => {
              if (!selectedBuildingId) onSelectBuilding(buildings[0]?.id || null);
              if (!selectedFloor) onSelectFloor(12);
              onViewModeChange('floor');
            }}
            className={`px-2.5 py-1 rounded font-medium transition ${
              viewMode === 'floor' ? 'bg-sky-600 text-white shadow' : 'text-slate-300 hover:text-white'
            }`}
          >
            标准层/户型
          </button>
        </div>

        {/* Render Style switcher */}
        <div className="flex bg-slate-800 rounded p-0.5 border border-slate-700 ml-2">
          <button
            onClick={() => onRenderStyleChange('realistic')}
            className={`px-2 py-1 rounded transition ${renderStyle === 'realistic' ? 'bg-slate-700 text-white font-medium' : 'text-slate-400 hover:text-slate-200'}`}
          >
            真实材质
          </button>
          <button
            onClick={() => onRenderStyleChange('clay')}
            className={`px-2 py-1 rounded transition ${renderStyle === 'clay' ? 'bg-slate-700 text-white font-medium' : 'text-slate-400 hover:text-slate-200'}`}
          >
            设计白模
          </button>
          <button
            onClick={() => onRenderStyleChange('construction_status')}
            className={`px-2 py-1 rounded transition ${renderStyle === 'construction_status' ? 'bg-amber-600 text-white font-medium' : 'text-slate-400 hover:text-slate-200'}`}
          >
            4D工序状态
          </button>
        </div>

        {/* Floor Explode toggle (for single building) */}
        {viewMode !== 'community' && (
          <button
            onClick={() => setIsExploded(!isExploded)}
            className={`px-2.5 py-1 rounded border transition flex items-center gap-1 ml-1 ${
              isExploded ? 'bg-indigo-600 border-indigo-400 text-white' : 'bg-slate-800 border-slate-700 text-slate-300 hover:text-white'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            {isExploded ? '合拢楼层' : '楼层爆炸图'}
          </button>
        )}
      </div>

      {/* Top-Right Sunlight & Solar Trajectory Controller */}
      <div className="absolute top-4 right-4 z-20 flex flex-col gap-2 bg-slate-900/85 backdrop-blur-md p-3 rounded-lg border border-slate-700 shadow-xl text-white w-64 text-xs">
        <div className="flex items-center justify-between border-b border-slate-700/80 pb-2">
          <div className="flex items-center gap-1.5 text-amber-400 font-semibold">
            <Sun className="w-4 h-4" />
            <span>日照轨迹与阴影模拟</span>
          </div>
          <span className="text-[11px] text-slate-400">{city.name}·{city.climateZone}</span>
        </div>

        <div className="space-y-1.5 pt-1">
          <div className="flex justify-between text-[11px] text-slate-300">
            <span>太阳时刻</span>
            <span className="font-mono text-amber-300 font-bold">
              {Math.floor(daylightHour).toString().padStart(2, '0')}:
              {Math.floor((daylightHour % 1) * 60).toString().padStart(2, '0')}
            </span>
          </div>
          <input
            type="range"
            min="6"
            max="19"
            step="0.25"
            value={daylightHour}
            onChange={e => onDaylightHourChange(parseFloat(e.target.value))}
            className="w-full h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-amber-500"
          />
          <div className="flex justify-between text-[10px] text-slate-500 font-mono">
            <span>06:00 (日出)</span>
            <span>12:00 (正午)</span>
            <span>19:00 (日落)</span>
          </div>
        </div>

        <div className="mt-1 bg-slate-800/80 p-2 rounded border border-slate-700 text-[11px] flex items-center justify-between text-slate-300">
          <span>大寒日有效日照满足度</span>
          <span className="text-emerald-400 font-bold font-mono">≥ 3.8h (达标)</span>
        </div>
      </div>

      {/* Bottom Floating 4D Construction Timeline Simulator */}
      <div className="absolute bottom-4 left-4 right-4 z-20 bg-slate-900/90 backdrop-blur-md p-3.5 rounded-xl border border-slate-700 shadow-2xl text-white">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/40">
              <Zap className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold tracking-wide">4D BIM 施工建造数字孪生演进</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-medium bg-sky-900/60 text-sky-300 border border-sky-700">
                  DAY {constructionDay} / 750 (2026.03 ~ 2028.06)
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                当前施工工序：
                <span className="text-amber-300 font-medium ml-1">
                  {constructionDay < 100
                    ? '地下基坑围护与桩基工程 (B2F)'
                    : constructionDay < 220
                    ? '地下室结构浇筑与顶板出正负零'
                    : constructionDay < 420
                    ? `地上主体剪力墙与铝模爬架施工 (正在浇筑 1#~8# 楼 ${Math.min(26, Math.floor((constructionDay - 80) / 12))} 层)`
                    : constructionDay < 550
                    ? '主体结构全域封顶 + 铝合金门窗幕墙 + 机电立管安装'
                    : constructionDay < 680
                    ? '室内精装修 (地暖/卫浴/橱柜) + 滨水园林海绵绿化水系'
                    : '五方责任主体联合综合竣工验收 + 数字化一房一档交付'}
                </span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onToggleSimulatingConstruction}
              className={`px-3.5 py-1.5 rounded-lg font-medium text-xs flex items-center gap-1.5 transition ${
                isSimulatingConstruction
                  ? 'bg-amber-600 hover:bg-amber-500 text-white'
                  : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg'
              }`}
            >
              {isSimulatingConstruction ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              {isSimulatingConstruction ? '暂停演进' : '自动播放建造'}
            </button>
            <button
              onClick={() => onConstructionDayChange(0)}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 hover:text-white"
              title="重置至开工日"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* 4D Construction Slider with Milestone markers */}
        <div className="relative pt-1 pb-1">
          <input
            type="range"
            min="0"
            max="750"
            step="5"
            value={constructionDay}
            onChange={e => onConstructionDayChange(parseInt(e.target.value, 10))}
            className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-sky-500"
          />
          <div className="flex justify-between text-[10px] font-mono text-slate-400 mt-1 px-1">
            <span>D0 桩基开挖</span>
            <span>D100 正负零</span>
            <span>D220 主体过半</span>
            <span>D400 结构封顶</span>
            <span>D520 机电安装</span>
            <span>D620 精装施工</span>
            <span className="text-emerald-400 font-bold">D750 竣工交付</span>
          </div>
        </div>
      </div>

      {/* Hover Tooltip */}
      {hoveredBuildingName && (
        <div className="absolute bottom-32 left-1/2 -translate-x-1/2 z-20 bg-slate-900/90 backdrop-blur-md px-3 py-1.5 rounded-full border border-sky-500/50 shadow-xl text-sky-200 text-xs font-medium pointer-events-none flex items-center gap-1.5">
          <Box className="w-3.5 h-3.5 text-sky-400" />
          <span>点击选择进入：{hoveredBuildingName}</span>
        </div>
      )}
    </div>
  );
}

// -------------------------------------------------------------
// Procedural 3D Mesh Builders
// -------------------------------------------------------------

function buildSiteTerrain(scene: THREE.Scene) {
  // Master ground slab (Asphalt & grass layout)
  const groundGeo = new THREE.PlaneGeometry(320, 260);
  const groundMat = new THREE.MeshStandardMaterial({
    color: 0x243038,
    roughness: 0.9,
    metalness: 0.1
  });
  const ground = new THREE.Mesh(groundGeo, groundMat);
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = -0.1;
  ground.receiveShadow = true;
  scene.add(ground);

  // Courtyard Central Green Park
  const parkGeo = new THREE.PlaneGeometry(160, 60);
  const parkMat = new THREE.MeshStandardMaterial({
    color: 0x2e4a36, // Rich landscape grass green
    roughness: 0.8
  });
  const park = new THREE.Mesh(parkGeo, parkMat);
  park.rotation.x = -Math.PI / 2;
  park.position.set(0, 0.05, 10);
  park.receiveShadow = true;
  scene.add(park);

  // Central Water feature pool
  const waterGeo = new THREE.PlaneGeometry(50, 18);
  const waterMat = new THREE.MeshStandardMaterial({
    color: 0x1e3a5f,
    roughness: 0.1,
    metalness: 0.85
  });
  const water = new THREE.Mesh(waterGeo, waterMat);
  water.rotation.x = -Math.PI / 2;
  water.position.set(0, 0.1, 10);
  scene.add(water);

  // Underground Parking Garage Ramps (地下车库出入口)
  const garageRampGeo = new THREE.BoxGeometry(12, 1.5, 24);
  const garageRampMat = new THREE.MeshStandardMaterial({ color: 0x475569, roughness: 0.7 });
  const garageMesh = new THREE.Mesh(garageRampGeo, garageRampMat);
  garageMesh.position.set(90, 0.6, -10);
  garageMesh.rotation.x = -0.12;
  scene.add(garageMesh);

  // Site Perimeter Fence / Wall
  const fenceMat = new THREE.MeshStandardMaterial({ color: 0x1e293b });
  const fenceGeoH = new THREE.BoxGeometry(320, 2.5, 0.6);
  const fTop = new THREE.Mesh(fenceGeoH, fenceMat);
  fTop.position.set(0, 1.25, -125);
  scene.add(fTop);

  const fBottom = new THREE.Mesh(fenceGeoH, fenceMat);
  fBottom.position.set(0, 1.25, 125);
  scene.add(fBottom);

  // Trees and Landscaping instanced approximation
  const treeTrunkGeo = new THREE.CylinderGeometry(0.3, 0.4, 2.5, 8);
  const treeFoliageGeo = new THREE.ConeGeometry(2.2, 4.5, 8);
  const trunkMat = new THREE.MeshStandardMaterial({ color: 0x5c4033 });
  const foliageMat = new THREE.MeshStandardMaterial({ color: 0x22543d, roughness: 0.7 });

  for (let i = -60; i <= 60; i += 15) {
    if (Math.abs(i) < 20) continue;
    const treeGroup = new THREE.Group();
    const trunk = new THREE.Mesh(treeTrunkGeo, trunkMat);
    trunk.position.y = 1.25;
    trunk.castShadow = true;
    const foliage = new THREE.Mesh(treeFoliageGeo, foliageMat);
    foliage.position.y = 4.2;
    foliage.castShadow = true;
    treeGroup.add(trunk);
    treeGroup.add(foliage);
    treeGroup.position.set(i, 0, 32);
    scene.add(treeGroup);
  }
}

function createFloorMesh({
  building,
  floorIndex,
  renderStyle,
  isSelected,
  isTopActiveFloor
}: {
  building: BuildingEntity;
  floorIndex: number;
  renderStyle: 'realistic' | 'clay' | 'wireframe' | 'construction_status';
  isSelected: boolean;
  isTopActiveFloor?: boolean;
}) {
  const group = new THREE.Group();
  const w = building.length;
  const d = building.width;
  const h = building.floorHeight;

  // Floor slab
  const slabGeo = new THREE.BoxGeometry(w, 0.3, d);
  let slabColor = 0x94a3b8;
  if (renderStyle === 'clay') slabColor = 0xf8fafc;
  else if (renderStyle === 'construction_status') {
    slabColor = isTopActiveFloor ? 0xf59e0b : 0x10b981; // Orange active pouring vs Green accepted
  }

  const slabMat = new THREE.MeshStandardMaterial({
    color: slabColor,
    roughness: 0.7,
    wireframe: renderStyle === 'wireframe'
  });
  const slab = new THREE.Mesh(slabGeo, slabMat);
  slab.position.y = 0.15;
  slab.castShadow = true;
  slab.receiveShadow = true;
  group.add(slab);

  // Exterior Glass Windows & Facade Panels
  const glassGeo = new THREE.BoxGeometry(w - 0.8, h - 0.4, d - 0.8);
  let glassColor = isSelected ? 0x38bdf8 : 0x1e3a5f;
  let opacity = 0.85;
  let metalness = 0.6;
  let roughness = 0.2;

  if (renderStyle === 'clay') {
    glassColor = 0xe2e8f0;
    opacity = 1.0;
    metalness = 0.1;
    roughness = 0.9;
  } else if (renderStyle === 'construction_status') {
    glassColor = isTopActiveFloor ? 0xf59e0b : 0x3b82f6;
  }

  const glassMat = new THREE.MeshStandardMaterial({
    color: glassColor,
    metalness,
    roughness,
    transparent: opacity < 1.0,
    opacity,
    wireframe: renderStyle === 'wireframe'
  });
  const glassMesh = new THREE.Mesh(glassGeo, glassMat);
  glassMesh.position.y = h / 2;
  glassMesh.castShadow = true;
  group.add(glassMesh);

  // Balconies & Architectural Mullions (South-facing decorative protrusion)
  const balconyGeo = new THREE.BoxGeometry(w * 0.6, 1.1, 1.6);
  const balconyMat = new THREE.MeshStandardMaterial({
    color: renderStyle === 'clay' ? 0xffffff : (isSelected ? 0x0284c7 : 0x64748b),
    roughness: 0.4
  });
  const balcony = new THREE.Mesh(balconyGeo, balconyMat);
  balcony.position.set(0, 0.7, d / 2 + 0.6);
  balcony.castShadow = true;
  group.add(balcony);

  // Safety Mesh for Active Pouring Top Floor
  if (isTopActiveFloor) {
    const safetyMeshGeo = new THREE.BoxGeometry(w + 1.2, h + 1.0, d + 1.2);
    const safetyMat = new THREE.MeshStandardMaterial({
      color: 0x22c55e, // Green safety mesh
      wireframe: true
    });
    const safetyMesh = new THREE.Mesh(safetyMeshGeo, safetyMat);
    safetyMesh.position.y = h / 2;
    group.add(safetyMesh);
  }

  return group;
}

function createTowerCraneMesh(crane: TowerCraneEntity) {
  const group = new THREE.Group();
  group.position.set(crane.position[0], crane.position[1], crane.position[2]);

  const craneColor = 0xf59e0b; // High-visibility construction yellow/orange
  const craneMat = new THREE.MeshStandardMaterial({ color: craneColor, metalness: 0.6, roughness: 0.4 });

  // Main vertical mast (tower truss)
  const mastGeo = new THREE.CylinderGeometry(1.2, 1.2, crane.height, 4);
  const mast = new THREE.Mesh(mastGeo, craneMat);
  mast.position.y = crane.height / 2;
  mast.castShadow = true;
  group.add(mast);

  // Operator cabin
  const cabinGeo = new THREE.BoxGeometry(2.4, 2.5, 2.4);
  const cabinMat = new THREE.MeshStandardMaterial({ color: 0x1e293b });
  const cabin = new THREE.Mesh(cabinGeo, cabinMat);
  cabin.position.set(0, crane.height - 4, 1.8);
  group.add(cabin);

  // Horizontal Rotating Jib Arm
  const armGroup = new THREE.Group();
  armGroup.position.set(0, crane.height, 0);
  armGroup.rotation.y = (crane.rotationAngle * Math.PI) / 180;

  // Front Working Jib
  const jibGeo = new THREE.BoxGeometry(0.8, 1.0, crane.armLength);
  const jib = new THREE.Mesh(jibGeo, craneMat);
  jib.position.set(0, 0, crane.armLength / 2);
  jib.castShadow = true;
  armGroup.add(jib);

  // Counter Jib
  const counterJibGeo = new THREE.BoxGeometry(1.2, 1.2, 20);
  const counterJib = new THREE.Mesh(counterJibGeo, craneMat);
  counterJib.position.set(0, 0, -10);
  armGroup.add(counterJib);

  // Counter weight blocks
  const weightGeo = new THREE.BoxGeometry(2.5, 2.0, 4.0);
  const weightMat = new THREE.MeshStandardMaterial({ color: 0x475569 });
  const weight = new THREE.Mesh(weightGeo, weightMat);
  weight.position.set(0, -0.5, -16);
  armGroup.add(weight);

  // Trolley & Hook
  const trolleyGeo = new THREE.BoxGeometry(1.4, 0.6, 1.4);
  const trolleyMat = new THREE.MeshStandardMaterial({ color: 0xd97706 });
  const trolley = new THREE.Mesh(trolleyGeo, trolleyMat);
  trolley.position.set(0, -0.8, crane.trolleyRadius);
  armGroup.add(trolley);

  // Cable
  const cableGeo = new THREE.CylinderGeometry(0.04, 0.04, 25, 6);
  const cableMat = new THREE.MeshBasicMaterial({ color: 0x111827 });
  const cable = new THREE.Mesh(cableGeo, cableMat);
  cable.position.set(0, -13, 0);
  trolley.add(cable);

  group.add(armGroup);
  return { group, arm: armGroup, trolley };
}

function createDefectPinMesh(defect: DefectEntity) {
  const pinGeo = new THREE.SphereGeometry(1.2, 16, 16);
  const pinColor = defect.severity === 'critical' ? 0xef4444 : defect.severity === 'moderate' ? 0xf59e0b : 0x3b82f6;
  const pinMat = new THREE.MeshBasicMaterial({ color: pinColor });
  const pin = new THREE.Mesh(pinGeo, pinMat);
  pin.position.set(defect.position3D[0], defect.position3D[1], defect.position3D[2]);
  pin.userData = { defectId: defect.id, title: defect.title };
  return pin;
}
