'use client';

import React, { useState } from 'react';
import { DefectEntity, BuildingEntity } from '@/types/housebuilder';
import {
  ShieldAlert,
  CheckCircle2,
  Clock,
  Camera,
  AlertTriangle,
  FileCheck,
  Plus,
  UserCheck,
  Search,
  Filter
} from 'lucide-react';

interface QualityDefectManagerProps {
  defects: DefectEntity[];
  buildings: BuildingEntity[];
  onSelectDefect?: (defect: DefectEntity) => void;
  onAddDefect?: (defect: DefectEntity) => void;
}

export default function QualityDefectManager({
  defects,
  buildings,
  onSelectDefect,
  onAddDefect
}: QualityDefectManagerProps) {
  const [selectedDefectId, setSelectedDefectId] = useState<string | null>(defects[0]?.id || null);
  const [filterSeverity, setFilterSeverity] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  const selectedDefect = defects.find(d => d.id === selectedDefectId) || defects[0];

  const filteredDefects = defects.filter(d => {
    if (filterSeverity !== 'all' && d.severity !== filterSeverity) return false;
    if (filterStatus !== 'all' && d.status !== filterStatus) return false;
    return true;
  });

  return (
    <div className="flex flex-col h-full bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-2xl text-white">
      {/* Top Header */}
      <div className="p-4 bg-slate-800/80 border-b border-slate-700/80 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-red-500/20 text-red-400 border border-red-500/30">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <span>工程质量验收与 3D 缺陷空间孪生闭环系统</span>
              <span className="text-[11px] font-normal px-2 py-0.5 rounded bg-red-950 text-red-300 border border-red-800 font-mono">
                标准: GB 50300-2013
              </span>
            </h3>
            <p className="text-[11px] text-slate-400">
              精准定位楼栋/楼层/户型/构件三维坐标，实时跟踪整改前、中、后照片与五方责任主体复验
            </p>
          </div>
        </div>

        {/* Filters */}
        <div className="flex items-center gap-2 text-xs">
          <select
            value={filterSeverity}
            onChange={e => setFilterSeverity(e.target.value)}
            className="bg-slate-700 border border-slate-600 rounded px-2 py-1 text-slate-200 text-xs"
          >
            <option value="all">所有严重等级</option>
            <option value="critical">严重缺陷 (Critical)</option>
            <option value="moderate">一般缺陷 (Moderate)</option>
            <option value="minor">轻微瑕疵 (Minor)</option>
          </select>

          <select
            value={filterStatus}
            onChange={e => setFilterStatus(e.target.value)}
            className="bg-slate-700 border border-slate-600 rounded px-2 py-1 text-slate-200 text-xs"
          >
            <option value="all">所有闭环状态</option>
            <option value="reported">待整改 (Reported)</option>
            <option value="rectifying">整改中 (Rectifying)</option>
            <option value="reinspected">已复验 (Reinspected)</option>
            <option value="closed">合格闭环 (Closed)</option>
          </select>
        </div>
      </div>

      {/* Main Grid: Defect List (Left 6 Cols) & Defect Details / Spatial Evidence (Right 6 Cols) */}
      <div className="grid grid-cols-12 flex-1 min-h-0 divide-x divide-slate-800">
        {/* Left List */}
        <div className="col-span-6 p-4 overflow-y-auto bg-slate-900/90 text-xs space-y-2.5">
          {filteredDefects.map(def => {
            const isSelected = def.id === selectedDefectId;
            return (
              <div
                key={def.id}
                onClick={() => {
                  setSelectedDefectId(def.id);
                  if (onSelectDefect) onSelectDefect(def);
                }}
                className={`p-3 rounded-lg border transition cursor-pointer ${
                  isSelected
                    ? 'bg-red-950/40 border-red-600 shadow-lg'
                    : 'bg-slate-800/50 border-slate-700/80 hover:bg-slate-800'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-red-400 font-bold">{def.code}</span>
                      <span
                        className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                          def.severity === 'critical'
                            ? 'bg-red-900 text-red-200'
                            : def.severity === 'moderate'
                            ? 'bg-amber-900 text-amber-200'
                            : 'bg-sky-900 text-sky-200'
                        }`}
                      >
                        {def.severity === 'critical' ? '严重' : def.severity === 'moderate' ? '一般' : '轻微'}
                      </span>
                    </div>
                    <h5 className="font-bold text-slate-100">{def.title}</h5>
                  </div>

                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-medium shrink-0 ${
                      def.status === 'closed'
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                        : def.status === 'rectifying'
                        ? 'bg-amber-950 text-amber-300 border border-amber-800 animate-pulse'
                        : 'bg-sky-950 text-sky-300 border border-sky-800'
                    }`}
                  >
                    {def.status === 'closed'
                      ? '验收闭环'
                      : def.status === 'rectifying'
                      ? '整改中'
                      : def.status === 'reinspected'
                      ? '待复核'
                      : '已指派'}
                  </span>
                </div>

                <div className="flex items-center gap-4 text-[10px] text-slate-400 mt-2">
                  <span>责任单位: {def.responsibleParty}</span>
                  <span>发现日期: {def.reportDate}</span>
                  <span>整改截止: {def.deadlineDate}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right Inspector */}
        <div className="col-span-6 p-4 overflow-y-auto bg-slate-900/90 text-xs space-y-4">
          {selectedDefect ? (
            <div className="space-y-4">
              <div className="border-b border-slate-700 pb-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-white text-base">{selectedDefect.title}</h4>
                  <span className="font-mono text-xs text-sky-400 font-bold">{selectedDefect.code}</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-1">
                  空间位置：
                  <span className="text-slate-200 font-medium">
                    {buildings.find(b => b.id === selectedDefect.buildingId)?.name || '3号楼'} ·{' '}
                    {selectedDefect.floorNumber}层 · {selectedDefect.unitCode} ({selectedDefect.roomName})
                  </span>
                </p>
              </div>

              {/* Description & Inspector Notes */}
              <div className="bg-slate-800/60 p-3 rounded-lg border border-slate-700 space-y-2">
                <span className="font-bold text-slate-200 text-[11px] block">缺陷详情与监理意见</span>
                <p className="text-slate-300 leading-relaxed text-[11px]">{selectedDefect.description}</p>
                <div className="flex items-center gap-3 pt-2 text-[10px] text-slate-400 border-t border-slate-700/80">
                  <span>监理工程师: {selectedDefect.inspectorName}</span>
                  <span>整改责任单位: {selectedDefect.responsibleParty}</span>
                </div>
              </div>

              {/* 3D Spatial Coordinates */}
              <div className="bg-slate-800/40 p-3 rounded-lg border border-slate-800 text-[11px] space-y-1">
                <span className="font-bold text-slate-300 block">3D数字孪生空间定位锚点</span>
                <div className="font-mono text-slate-400">
                  X: {selectedDefect.position3D[0]}m | Y: {selectedDefect.position3D[1]}m (标高) | Z:{' '}
                  {selectedDefect.position3D[2]}m
                </div>
              </div>

              {/* Quality Checklist Standard */}
              <div className="bg-slate-800/40 p-3 rounded-lg border border-slate-800 text-[11px] space-y-2">
                <span className="font-bold text-slate-300 block flex items-center gap-1.5">
                  <FileCheck className="w-3.5 h-3.5 text-emerald-400" />
                  <span>国家规范验收条款核验</span>
                </span>
                <div className="space-y-1 text-slate-300 text-[10px]">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>《建筑给水排水及采暖工程施工质量验收规范》GB 50242-2002 蓄水试验合格</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>《地下防水工程质量验收规范》GB 50208-2011 细部构造附加防水层验收</span>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-12 text-slate-500">请选择左侧缺陷项</div>
          )}
        </div>
      </div>
    </div>
  );
}
