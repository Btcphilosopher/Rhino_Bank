import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: '中国住宅数字建造平台 (CHO) | CHINA HOUSEBUILDER OS',
  description: '面向中国住宅开发商、设计院、总包施工、物业及业主的数字孪生与BIM建造操作系统 (China Residential Digital Twin & Housebuilder OS)',
  openGraph: {
    title: '中国住宅数字建造平台 (CHO) | CHINA HOUSEBUILDER OS',
    description: '面向中国住宅开发商、设计院、总包施工、物业及业主的数字孪生与BIM建造操作系统 (China Residential Digital Twin & Housebuilder OS)',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: '中国住宅数字建造平台 (CHO) | CHINA HOUSEBUILDER OS',
    description: '面向中国住宅开发商、设计院、总包施工、物业及业主的数字孪生与BIM建造操作系统',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
