'use client';

import React, { useState, useEffect } from 'react';
import {
  DEMO_PROJECT,
  DEMO_BUILDINGS,
  CITIES_CONFIG,
  DEMO_FLOORPLANS,
  DEMO_BIM_OBJECTS,
  DEMO_4D_TASKS,
  DEMO_TOWER_CRANES,
  DEMO_HEAVY_MACHINES,
  DEMO_DEFECTS,
  DEMO_MATERIALS
} from '@/lib/sample-data';
import {
  BuildingEntity,
  UnitFloorPlan,
  BIMObjectEntity,
  ConstructionTask4D,
  TowerCraneEntity,
  HeavyEquipmentEntity,
  DefectEntity,
  MaterialItem,
  CityConfig
} from '@/types/housebuilder';
import DigitalTwinViewer3D from '@/components/DigitalTwinViewer3D';
import FloorplanEditor2D from '@/components/FloorplanEditor2D';
import BIMModelTree from '@/components/BIMModelTree';
import CostManagement5D from '@/components/CostManagement5D';
import ConstructionSchedule4D from '@/components/ConstructionSchedule4D';
import QualityDefectManager from '@/components/QualityDefectManager';
import MaterialProcurement from '@/components/MaterialProcurement';
import OwnerTwinPortal from '@/components/OwnerTwinPortal';
import AICopilotAssistant from '@/components/AICopilotAssistant';

import {
  Building2,
  Compass,
  FolderTree,
  DollarSign,
  HardHat,
  ShieldAlert,
  Boxes,
  Smartphone,
  Bot,
  Layers,
  Sun,
  MapPin,
  Calendar,
  Activity,
  Cpu,
  ChevronRight,
  Maximize2,
  RefreshCw
} from 'lucide-react';

export default function ChinaHouseBuilderOS() {
  // Global Project State
  const [selectedCityId, setSelectedCityId] = useState<string>('shanghai');
  const [activeWorkspaceTab, setActiveWorkspaceTab] = useState<
    'twin3d' | 'floorplan' | 'bimtree' | 'cost5d' | 'construction4d' | 'quality' | 'materials' | 'owner' | 'ai_copilot'
  >('twin3d');

  const [buildings, setBuildings] = useState<BuildingEntity[]>(DEMO_BUILDINGS);
  const [selectedBuildingId, setSelectedBuildingId] = useState<string | null>('bldg-1');
  const [selectedFloor, setSelectedFloor] = useState<number | null>(12);
  const [selectedFloorPlan, setSelectedFloorPlan] = useState<UnitFloorPlan>(DEMO_FLOORPLANS[0]); // 128m2
  const [availablePlans, setAvailablePlans] = useState<UnitFloorPlan[]>(DEMO_FLOORPLANS);

  // 3D Viewport Controls
  const [viewMode, setViewMode] = useState<'community' | 'building' | 'floor' | 'interior'>('community');
  const [daylightHour, setDaylightHour] = useState<number>(14.5); // 14:30 PM
  const [renderStyle, setRenderStyle] = useState<'realistic' | 'clay' | 'wireframe' | 'construction_status'>('realistic');

  // 4D Construction Simulation
  const [constructionDay, setConstructionDay] = useState<number>(360);
  const [isSimulatingConstruction, setIsSimulatingConstruction] = useState<boolean>(false);

  // BIM & Defects
  const [bimObjects, setBimObjects] = useState<BIMObjectEntity[]>(DEMO_BIM_OBJECTS);
  const [selectedBIMId, setSelectedBIMId] = useState<string | null>(DEMO_BIM_OBJECTS[0]?.id || null);
  const [defects, setDefects] = useState<DefectEntity[]>(DEMO_DEFECTS);
  const [selectedDefect, setSelectedDefect] = useState<DefectEntity | null>(DEMO_DEFECTS[0]);

  // Construction & Cranes
  const [constructionTasks, setConstructionTasks] = useState<ConstructionTask4D[]>(DEMO_4D_TASKS);
  const [cranes, setCranes] = useState<TowerCraneEntity[]>(DEMO_TOWER_CRANES);
  const [heavyMachines, setHeavyMachines] = useState<HeavyEquipmentEntity[]>(DEMO_HEAVY_MACHINES);
  const [materials, setMaterials] = useState<MaterialItem[]>(DEMO_MATERIALS);

  const activeCity = CITIES_CONFIG.find(c => c.id === selectedCityId) || CITIES_CONFIG[0];

  // Auto-run construction simulation timer
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isSimulatingConstruction) {
      interval = setInterval(() => {
        setConstructionDay(prev => {
          if (prev >= 750) {
            setIsSimulatingConstruction(false);
            return 750;
          }
          return prev + 5;
        });
      }, 400);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isSimulatingConstruction]);

  const handleUpdateFloorplan = (updated: UnitFloorPlan) => {
    setSelectedFloorPlan(updated);
    setAvailablePlans(prev => prev.map(p => (p.id === updated.id ? updated : p)));
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-slate-950 text-slate-100 overflow-hidden font-sans select-none">
      {/* Top Enterprise Navigation Header */}
      <header className="h-14 bg-slate-900 border-b border-slate-800 px-4 flex items-center justify-between shrink-0 z-30 shadow-md">
        {/* Brand & Project Identity */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-sky-600 to-indigo-500 flex items-center justify-center shadow-lg shadow-sky-500/20 text-white font-black text-base tracking-tighter">
              CHO
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-sm tracking-wide text-white">中国住宅数字建造平台</span>
                <span className="text-[10px] font-mono font-medium px-1.5 py-0.5 rounded bg-sky-900/60 text-sky-300 border border-sky-700">
                  v3.8 ENTERPRISE
                </span>
              </div>
              <span className="text-[10px] text-slate-400 font-mono">CHINA HOUSEBUILDER OS · 全生命周期数字孪生</span>
            </div>
          </div>

          <div className="h-5 w-px bg-slate-800 mx-1" />

          {/* Current Project & Location */}
          <div className="flex items-center gap-2 text-xs">
            <div className="flex items-center gap-1.5 text-slate-300">
              <Building2 className="w-3.5 h-3.5 text-sky-400" />
              <span className="font-bold">{DEMO_PROJECT.name}</span>
            </div>
            <span className="text-slate-600">|</span>
            <div className="flex items-center gap-1 text-slate-400 text-[11px]">
              <MapPin className="w-3 h-3 text-red-400" />
              <span>
                {activeCity.name} ({activeCity.climateZone}) · 设防烈度 {activeCity.seismicIntensity ?? 7}度
              </span>
            </div>
          </div>
        </div>

        {/* City Config & Project Metrics */}
        <div className="flex items-center gap-3">
          {/* City Switcher */}
          <div className="flex items-center gap-1.5 bg-slate-800/80 px-2.5 py-1 rounded-lg border border-slate-700 text-xs">
            <span className="text-slate-400 text-[11px]">定额与规范城市:</span>
            <select
              value={selectedCityId}
              onChange={e => setSelectedCityId(e.target.value)}
              className="bg-transparent text-sky-300 font-bold focus:outline-none cursor-pointer text-xs"
            >
              {CITIES_CONFIG.map(c => (
                <option key={c.id} value={c.id} className="bg-slate-800 text-white">
                  {c.name} ({c.province})
                </option>
              ))}
            </select>
          </div>

          {/* Project Summary Badge */}
          <div className="hidden lg:flex items-center gap-2 text-[11px] font-mono bg-slate-900/80 px-3 py-1 rounded-lg border border-slate-800">
            <span className="text-slate-400">总建面:</span>
            <span className="text-slate-200 font-bold">180,000 m²</span>
            <span className="text-slate-600">/</span>
            <span className="text-slate-400">总户数:</span>
            <span className="text-emerald-400 font-bold">1,248 户</span>
          </div>
        </div>
      </header>

      {/* Main Workspace Body */}
      <div className="flex flex-1 min-h-0 relative">
        {/* Left Vertical Applet Switcher Bar */}
        <aside className="w-16 bg-slate-900 border-r border-slate-800 flex flex-col items-center py-3 gap-2 shrink-0 z-20">
          {[
            { id: 'twin3d', label: '3D孪生', icon: Building2, color: 'text-sky-400' },
            { id: 'floorplan', label: '户型设计', icon: Compass, color: 'text-emerald-400' },
            { id: 'bimtree', label: 'BIM构件', icon: FolderTree, color: 'text-indigo-400' },
            { id: 'cost5d', label: '5D造价', icon: DollarSign, color: 'text-amber-400' },
            { id: 'construction4d', label: '4D施工', icon: HardHat, color: 'text-yellow-400' },
            { id: 'quality', label: '质量质检', icon: ShieldAlert, color: 'text-red-400' },
            { id: 'materials', label: '建材采购', icon: Boxes, color: 'text-teal-400' },
            { id: 'owner', label: '一房一档', icon: Smartphone, color: 'text-purple-400' },
            { id: 'ai_copilot', label: '总工智脑', icon: Bot, color: 'text-sky-300' }
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeWorkspaceTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveWorkspaceTab(tab.id as any)}
                className={`w-12 h-12 rounded-xl flex flex-col items-center justify-center gap-1 transition relative group ${
                  isActive
                    ? 'bg-sky-600 text-white shadow-lg shadow-sky-600/30'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
                title={tab.label}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : tab.color}`} />
                <span className="text-[9px] font-medium leading-none">{tab.label}</span>

                {/* Active Indicator Pip */}
                {isActive && (
                  <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-5 bg-sky-300 rounded-r" />
                )}
              </button>
            );
          })}
        </aside>

        {/* Central Dynamic Workspace Panel */}
        <main className="flex-1 min-w-0 h-full p-2 bg-slate-950 relative overflow-hidden">
          {activeWorkspaceTab === 'twin3d' && (
            <DigitalTwinViewer3D
              buildings={buildings}
              selectedBuildingId={selectedBuildingId}
              onSelectBuilding={setSelectedBuildingId}
              selectedFloor={selectedFloor}
              onSelectFloor={setSelectedFloor}
              selectedFloorPlan={selectedFloorPlan}
              viewMode={viewMode}
              onViewModeChange={setViewMode}
              daylightHour={daylightHour}
              onDaylightHourChange={setDaylightHour}
              city={activeCity}
              constructionDay={constructionDay}
              onConstructionDayChange={setConstructionDay}
              isSimulatingConstruction={isSimulatingConstruction}
              onToggleSimulatingConstruction={() => setIsSimulatingConstruction(!isSimulatingConstruction)}
              cranes={cranes}
              defects={defects}
              onSelectDefect={d => {
                setSelectedDefect(d);
                setActiveWorkspaceTab('quality');
              }}
              renderStyle={renderStyle}
              onRenderStyleChange={setRenderStyle}
            />
          )}

          {activeWorkspaceTab === 'floorplan' && (
            <FloorplanEditor2D
              floorplan={selectedFloorPlan}
              onUpdateFloorplan={handleUpdateFloorplan}
              availablePlans={availablePlans}
              onSelectPlan={setSelectedFloorPlan}
            />
          )}

          {activeWorkspaceTab === 'bimtree' && (
            <BIMModelTree
              buildings={buildings}
              bimObjects={bimObjects}
              selectedBIMId={selectedBIMId}
              onSelectBIMObject={setSelectedBIMId}
              selectedBuildingId={selectedBuildingId}
              onSelectBuilding={setSelectedBuildingId}
            />
          )}

          {activeWorkspaceTab === 'cost5d' && (
            <CostManagement5D buildings={buildings} city={activeCity} />
          )}

          {activeWorkspaceTab === 'construction4d' && (
            <ConstructionSchedule4D
              tasks={constructionTasks}
              cranes={cranes}
              heavyMachines={heavyMachines}
              constructionDay={constructionDay}
            />
          )}

          {activeWorkspaceTab === 'quality' && (
            <QualityDefectManager
              defects={defects}
              buildings={buildings}
              onSelectDefect={setSelectedDefect}
            />
          )}

          {activeWorkspaceTab === 'materials' && (
            <MaterialProcurement materials={materials} city={activeCity} />
          )}

          {activeWorkspaceTab === 'owner' && (
            <OwnerTwinPortal floorplan={selectedFloorPlan} />
          )}

          {activeWorkspaceTab === 'ai_copilot' && <AICopilotAssistant />}
        </main>
      </div>

      {/* Global Status Bar */}
      <footer className="h-7 bg-slate-900 border-t border-slate-800 px-4 flex items-center justify-between text-[11px] text-slate-400 font-mono shrink-0 z-30">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5 text-emerald-400">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>数字孪生同步引擎：实时运行中 (60 FPS)</span>
          </div>
          <span>BIM 对象总数: {bimObjects.length * 128} 件</span>
          <span>GB 50096 强条自检: 全部合规 (100%)</span>
        </div>

        <div className="flex items-center gap-4 text-[10px]">
          <span>建设单位: 绿城中国 & 上海地产集团</span>
          <span>总承包: 上海建工一建</span>
          <span>设计院: 华东建筑设计研究院 (ECADI)</span>
        </div>
      </footer>
    </div>
  );
}
