import { DiningItem } from '../types';
import { diningImg, archImg, heroImg, hangzhouImg } from './hotels';

export const DINING_DATA: DiningItem[] = [
  {
    id: 'dine-1',
    name: 'Jade Pavilion (碧玉轩)',
    nameZh: '碧玉轩 · 米其林二星中餐厅',
    hotel: 'YUNQI SHANGHAI',
    hotelZh: '上海云栖酒店',
    cuisine: 'Contemporary Huaiyang & Cantonese Fine Dining',
    cuisineZh: '当代淮扬与精细粤菜',
    description: 'Awarded Two Michelin Stars, Jade Pavilion celebrates the poetic subtlety of Jiangnan gastronomy elevated with modern culinary techniques. Overlooking the illuminated Bund skyline.',
    descriptionZh: '荣膺米其林二星殊荣，以现代先锋烹饪手法重塑江南风物与淮扬刀工精粹，坐拥浦江繁华夜景。',
    hours: '11:30 - 14:30 | 17:30 - 22:00',
    dressCode: 'Smart Elegant (Jackets recommended)',
    dressCodeZh: '优雅便服（建议男士着西装外套）',
    image: diningImg,
    signatureDish: 'Slow-Poached Dongpo Pork with 30-Year Aged Huadiao Wine & Caviar',
    signatureDishZh: '三十年陈酿花雕低温慢煮东坡肉配鲟鱼子酱'
  },
  {
    id: 'dine-2',
    name: 'Bamboo Shadow Salon (竹影茶宴)',
    nameZh: '竹影茶宴 · 宋代四般闲事私房菜',
    hotel: 'YUNQI HANGZHOU',
    hotelZh: '杭州云栖度假酒店',
    cuisine: 'Song Dynasty Heritage & Imperial Tea Cuisine',
    cuisineZh: '南宋雅宴与御茶养生料理',
    description: 'Set within an 800-year bamboo grove with classical water fountains. Each seasonal course is paired with rare artisanal teas brewed using fresh Tiger Spring water.',
    descriptionZh: '隐于西湖古竹林泉石之间，每一道四时风物菜品皆由国家级侍茶师以虎跑泉水冲泡的珍稀御茶完美相配。',
    hours: '12:00 - 15:00 | 18:00 - 21:30',
    dressCode: 'Resort Chic',
    dressCodeZh: '度假雅致',
    image: hangzhouImg,
    signatureDish: 'Steamed West Lake Wild Carp with Grade-A Mingqian Dragon Well Tea Leaves',
    signatureDishZh: '特级明前狮峰龙井清蒸西湖开江野生桂鱼'
  },
  {
    id: 'dine-3',
    name: 'Celestial Peak Cellar & Grill (云顶之巅)',
    nameZh: '云顶之巅 · 高原野生菌与雪域炙烤',
    hotel: 'YUNQI LHASA',
    hotelZh: '拉萨云栖度假酒店',
    cuisine: 'Himalayan Wild Foraged & Contemporary Highland Gastronomy',
    cuisineZh: '喜马拉雅原生态野生菌与高原法式炙烤',
    description: 'Located at 3,650 metres with floor-to-ceiling glass confronting the snow peaks. Featuring a walk-in temperature-controlled Himalayan cellar of over 1,800 grand crus.',
    descriptionZh: '置身海拔3,650米之巅，全景落地窗面对巍峨雪山。内设恒温天然岩穴酒窖，珍藏逾1800款名庄佳酿。',
    hours: '12:00 - 14:30 | 18:00 - 22:30',
    dressCode: 'Smart Casual / Warm Layers',
    dressCodeZh: '休闲雅致 / 建议保暖着装',
    image: archImg,
    signatureDish: 'Matsutake & Black Truffle Infused Yak Tenderloin with Mountain Herbs',
    signatureDishZh: '极品高山松茸与黑松露煨高原牦牛嫩柳'
  },
  {
    id: 'dine-4',
    name: 'Azure Waves Pavilion (沧海阁)',
    nameZh: '沧海阁 · 临海顶级海鲜珍馔',
    hotel: 'YUNQI SANYA',
    hotelZh: '三亚云栖度假酒店',
    cuisine: 'Modern South China Sea Seafood & Hainan Terroir',
    cuisineZh: '当代南海野生海鲜与热带风物盛宴',
    description: 'Overlooking the gentle surf of Haitang Bay, this open-air pavilion presents freshly landed catch from deep South China Sea waters grilled over charcoal and fragrant coconut shells.',
    descriptionZh: '临海棠湾碧波而建，汇集南海深海生猛海鲜，以传统古法天然椰壳炭火慢炙，锁住极致原汁原味。',
    hours: '11:00 - 23:00',
    dressCode: 'Tropical Elegance',
    dressCodeZh: '海岛优雅度假风',
    image: heroImg,
    signatureDish: 'Charcoal-Grilled Deep Sea Red Grouper with Local Wenchang Coconut Broth',
    signatureDishZh: '炭火慢烤深海东星斑配文昌生榨椰子清汤'
  }
];
