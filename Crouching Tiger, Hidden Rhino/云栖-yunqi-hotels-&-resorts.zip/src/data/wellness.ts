import { wellnessImg, hangzhouImg, lhasaImg } from './hotels';

export interface WellnessPillar {
  id: string;
  title: string;
  titleZh: string;
  subtitle: string;
  subtitleZh: string;
  description: string;
  descriptionZh: string;
  image: string;
  therapies: { name: string; nameZh: string; duration: string; durationZh: string; benefit: string; benefitZh: string }[];
}

export const WELLNESS_PILLARS: WellnessPillar[] = [
  {
    id: 'tcm-hydro',
    title: 'HERBAL HYDROTHERAPY',
    titleZh: '本草水疗与温泉秘汤',
    subtitle: 'Nourishing the Five Elements through Thermal Water & Rare Botanicals',
    subtitleZh: '以天然矿物温泉与五行草本调和阴阳',
    description: 'Immerse in mineral-rich spring waters infused with wild Ginseng, Angelica root, and wild Longjing tea extracts, calibrated to restore energetic equilibrium.',
    descriptionZh: '浸润于天然高山富锶矿物温泉中，融入野生长白山人参、当归与明前龙井精华，滋养气血，通经活络。',
    image: wellnessImg,
    therapies: [
      { name: 'Imperial Dragon Well Thermal Soak', nameZh: '御前龙井温泉沐汤', duration: '60 Mins', durationZh: '60分钟', benefit: 'Deep detox & skin radiance', benefitZh: '深层排毒，唤醒肌肤光泽' },
      { name: 'Tibetan Red Salt Hot Stone Therapy', nameZh: '藏地红盐热石排湿理疗', duration: '90 Mins', durationZh: '90分钟', benefit: 'Relieves chronic tension & coldness', benefitZh: '温经散寒，舒缓深层肌肉酸痛' },
      { name: 'Five-Element Essential Oil Fusion', nameZh: '五行本草精油能量抚触', duration: '75 Mins', durationZh: '75分钟', benefit: 'Aligns meridian pathways', benefitZh: '疏通经络，平衡五脏之气' }
    ]
  },
  {
    id: 'sound-mind',
    title: 'MEDITATIVE SOUND HEALING',
    titleZh: '古琴与天籁颂钵音疗',
    subtitle: 'Acoustic Resonance Calibrated for Deep Neurological Calm',
    subtitleZh: '以千年声学共振抚平浮躁思绪，进入深层脑波静修',
    description: 'Experience pure harmonic frequencies produced by 300-year-old Himalayan bronze singing bowls, tuned gongs, and seven-string Guqin zithers in acoustic bamboo chambers.',
    descriptionZh: '置身原竹静音禅堂，由声音疗愈大师敲击古董七音铜钵与泛音风锣，古琴清音如泉流淌，引导大脑进入Theta波深层休眠与自愈。',
    image: hangzhouImg,
    therapies: [
      { name: 'Chakra Awakening Singing Bowl Bath', nameZh: '七脉轮沉浸式颂钵音疗', duration: '60 Mins', durationZh: '60分钟', benefit: 'Reduces cortisol & enhances sleep', benefitZh: '极速降低皮质醇，改善睡眠质量' },
      { name: 'Song Dynasty Guqin Breath Ritual', nameZh: '南宋古琴吐纳调息修持', duration: '45 Mins', durationZh: '45分钟', benefit: 'Deep diaphragmatic oxygenation', benefitZh: '腹式深度吐纳，净化心神' }
    ]
  },
  {
    id: 'oxygen-sanctuary',
    title: 'HIGH-ALTITUDE CELLULAR RENEWAL',
    titleZh: '雪域高原细胞新生与高压氧疗',
    subtitle: 'Pioneering Mountain Longevity Medicine at Lhasa Sanctuary',
    subtitleZh: '拉萨云栖独创高原长寿医学与细胞抗衰赋能',
    description: 'At Yunqi Lhasa (3,650m), state-of-the-art oxygen-regulated chambers combine with traditional Sowa Rigpa herbal compresses to optimize cellular recovery.',
    descriptionZh: '拉萨云栖配备前沿高压微循环富氧舱，结合千年藏医索瓦日巴草本敷包与静脉抗氧化补充，赋予细胞持久充沛活力。',
    image: lhasaImg,
    therapies: [
      { name: 'Hyperbaric Oxygen Longevity Session', nameZh: '高压微压富氧抗衰焕活', duration: '50 Mins', durationZh: '50分钟', benefit: 'Cellular ATP renewal & acclimatization', benefitZh: '加速细胞ATP再生，抵御高原衰竭' },
      { name: 'Highland Rhodiola Revitalizing Facial', nameZh: '高山红景天逆龄水光面部护理', duration: '80 Mins', durationZh: '80分钟', benefit: 'Intense hydration & UV defense repair', benefitZh: '深层锁水保湿，修复紫外线损伤' }
    ]
  }
];
