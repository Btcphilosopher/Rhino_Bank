import { ExperienceItem } from '../types';
import { archImg, diningImg, wellnessImg, hangzhouImg, lhasaImg, sanyaImg } from './hotels';

export const EXPERIENCES_DATA: ExperienceItem[] = [
  {
    id: 'exp-1',
    category: 'journeys',
    categoryLabel: 'PRIVATE JOURNEYS',
    categoryLabelZh: '专属定制旅程',
    title: 'Song Dynasty Scholar Garden Pilgrimage',
    titleZh: '南宋文人园林与隐世雅集之旅',
    duration: 'Full Day / 私享全日',
    durationZh: '全天私享导览',
    description: 'An exclusive after-hours private journey through historic Southern Song gardens and private heritage estates in Hangzhou, guided by a renowned architectural historian.',
    descriptionZh: '由国家级古典建筑学者全程陪同，闭馆后包场探访西湖隐世私家园林，沉浸式体验宋代美学风雅。',
    image: hangzhouImg,
    highlights: [
      'Private access to closed heritage tea pavilions',
      'Exclusive Guqin live recital in 800-year courtyard',
      'Song dynasty imperial banquet pairing'
    ],
    highlightsZh: [
      '私享探访非对外开放的御茶古亭',
      '八百年古井庭院内聆听非遗古琴独奏',
      '复刻宋代宫廷御筵四般闲事美馔'
    ]
  },
  {
    id: 'exp-2',
    category: 'culinary',
    categoryLabel: 'CULINARY DISCOVERY',
    categoryLabelZh: '当代华夏美馔溯源',
    title: 'Imperial Tea Harvest & Master Kungfu Ritual',
    titleZh: '西湖龙井御茶开采与大师奉茶仪式',
    duration: 'Half Day / 半日研学',
    durationZh: '半日深度体验',
    description: 'Harvest first-flush Mingqian tea leaves with national tea masters at Yunqi’s private reserve plantation, followed by a ceremonial wood-fired wok roasting and bespoke tea pairing.',
    descriptionZh: '深入云栖私享明前核心茶园，跟随国家级制茶非遗传承人亲手采青、手工炭火炒茶，并由资深茶艺大师主持专属奉茶仪式。',
    image: diningImg,
    highlights: [
      'Hand-picking Mingqian Longjing Grade A leaves',
      'Traditional bronze wok artisan roasting technique',
      'Cellar aged Pu’er tasting with rare vintage cakes'
    ],
    highlightsZh: [
      '亲采狮峰龙井特级明前初芽',
      '古法铜锅手工炭火炒制秘技传授',
      '品鉴百年号级古树普洱与宋代点茶'
    ]
  },
  {
    id: 'exp-3',
    category: 'art',
    categoryLabel: 'ART & CULTURE',
    categoryLabelZh: '东方艺术与人文',
    title: 'Himalayan Thangka Masterclass & Sacred Sanctuaries',
    titleZh: '雪域唐卡非遗巨匠工坊与秘境朝圣',
    duration: '2 Days / 两日深度',
    durationZh: '两日深度艺术修持',
    description: 'Private immersion with a master Thangka artist in Lhasa. Discover mineral pigment grinding from lapis lazuli and gold leaf, complemented by private monastery sanctuary meditation.',
    descriptionZh: '特邀国家级唐卡宗师于拉萨云栖专属画廊亲授，研磨纯天然青金石与纯金箔矿物颜料，并获高僧开光加持。',
    image: lhasaImg,
    highlights: [
      'One-on-one painting guidance with master artist',
      'Sacred incense formulation workshop',
      'VIP monastery crypt access guided by elder lamas'
    ],
    highlightsZh: [
      '唐卡画派宗师一对一绘画指点',
      '古法藏香天然药材调香制作',
      '高僧大德专属护持进入古寺秘殿禅修'
    ]
  },
  {
    id: 'exp-4',
    category: 'mountains',
    categoryLabel: 'MOUNTAIN RETREATS',
    categoryLabelZh: '高山隐世修心',
    title: 'High-Altitude Stargazing & Himalayan Alpine Trek',
    titleZh: '喜马拉雅巅峰观星与高山秘境徒步',
    duration: 'Evening & Morning / 晨昏相伴',
    durationZh: '星夜与晨光之旅',
    description: 'Traverse untouched Himalayan valleys with high-altitude sherpas, followed by a midnight celestial observation session with our resident astrophysicist using research-grade telescopes.',
    descriptionZh: '由专业高山向导护航探访未经开发的雪山冰川河谷，入夜后由驻店天文学家携专业科研级望远镜开启银河深空摄影。',
    image: archImg,
    highlights: [
      'Research grade 16-inch computerized telescope',
      'Warm cashmere tent lounge with hot butter tea & single malts',
      'Private wildlife photography guidance'
    ],
    highlightsZh: [
      '16英寸高精度专业天文望远镜观测',
      '星空暖意羊绒帐篷搭配温热藏茶与单一麦芽威士忌',
      '国家地理摄影师高原珍稀野生动物向导'
    ]
  },
  {
    id: 'exp-5',
    category: 'wellness',
    categoryLabel: 'WELLNESS',
    categoryLabelZh: '身心静修疗愈',
    title: 'Sound Healing Bath & Thermal Spring Cleansing',
    titleZh: '天籁颂钵音疗与天然矿物温泉净润',
    duration: '3 Hours / 3小时疗程',
    durationZh: '3小时深度静愈',
    description: 'Harmonize your energy fields in a private bamboo pavilion with antique 7-metal singing bowls, accompanied by tailored mineral hydrotherapy and herbal elixir tonics.',
    descriptionZh: '在竹林环抱的露天水榭中，以百年七矿纯手工古董颂钵震频共鸣深层疗愈，结合天然弱碱性高山矿物温泉与定制草本滋补饮。',
    image: wellnessImg,
    highlights: [
      'Vibrational acoustic therapy with 7 chakra bowls',
      'Customized herbal steam infused with Agarwood and Ginseng',
      'One-on-one pulse reading with senior TCM doctor'
    ],
    highlightsZh: [
      '七脉轮古董颂钵深层声波共振疗法',
      '沉香与高丽参秘方中草药矿物私汤',
      '资深国医大师一对一把脉辨体质调理'
    ]
  },
  {
    id: 'exp-6',
    category: 'aviation',
    categoryLabel: 'PRIVATE AVIATION',
    categoryLabelZh: '专属公务飞行与海空巡礼',
    title: 'Scenic Helicopter Flight Over Yarlung Tsangpo Canyon',
    titleZh: '私人直升机俯瞰雅鲁藏布大峡谷与南迦巴瓦峰',
    duration: '3.5 Hours / 3.5小时空中礼遇',
    durationZh: '3.5小时奢华航程',
    description: 'Board our luxury twin-engine Airbus ACH130 helicopter from Yunqi’s private helipad for a breathtaking flight over the world’s deepest canyon and sacred snow peaks.',
    descriptionZh: '从云栖专属停机坪起飞，搭乘空客ACH130豪华商务直升机，低空掠过世界第一大峡谷与南迦巴瓦雪山雄峰，并在冰川之巅品味极品年份香槟。',
    image: sanyaImg,
    highlights: [
      'Direct takeoff from private resort helipad',
      'Glacier landing with vintage Dom Pérignon toast',
      'High-resolution cinematic drone recording included'
    ],
    highlightsZh: [
      '度假村私家停机坪即刻起飞无需繁琐手续',
      '千年冰川之巅降落并开启唐培里侬年份香槟祝捷',
      '专业航拍摄影团队全程跟拍制作4K纪念大片'
    ]
  }
];
