export const TRANSLATIONS = {
  en: {
    brandName: 'YUNQI HOTELS & RESORTS',
    brandChinese: '云栖',
    tagline: 'A JOURNEY INTO TIMELESS CHINA',
    heroSubtitle: '不止于下榻 · 邂逅永恒的中国',
    heroEyebrow: 'MORE THAN A STAY',
    heroCopy: 'Extraordinary destinations. Unrivalled service. The finest hotels and resorts across China.',
    exploreHotelsCTA: 'EXPLORE OUR HOTELS',
    scrollToDiscover: 'SCROLL TO DISCOVER',
    
    // Nav
    navHome: 'HOME',
    navHotels: 'OUR HOTELS',
    navExperiences: 'EXPERIENCES',
    navDining: 'DINING',
    navWellness: 'WELLNESS',
    navArchitecture: 'ARCHITECTURE',
    navAbout: 'ABOUT',
    bookNow: 'BOOK NOW',
    
    // Booking
    planYourStay: 'PLAN YOUR STAY',
    destination: 'DESTINATION',
    selectDestination: 'Select a destination',
    checkIn: 'CHECK IN',
    checkOut: 'CHECK OUT',
    guests: 'GUESTS',
    adults: 'Adults',
    children: 'Children',
    guestsCount: (adults: number) => `${adults} Adult${adults > 1 ? 's' : ''}`,
    night: 'night',
    nights: 'nights',
    bookStay: 'BOOK NOW',
    viewRates: 'CHECK AVAILABILITY',
    
    // Hotels Section
    ourHotels: 'OUR HOTELS',
    hotelsSubheading: 'Exceptional places. Extraordinary perspectives.',
    viewProperty: 'EXPLORE SANCTUARY',
    fromPrice: 'From',
    perNight: '/ night',
    
    // Signature Services
    servicesTitle: 'SIGNATURE PRIVILEGES',
    serviceDining: 'WORLD-CLASS DINING',
    serviceDiningSub: 'Michelin-grade gastronomic artistry',
    serviceTransfers: 'PRIVATE TRANSFERS',
    serviceTransfersSub: 'Rolls-Royce & Maybach fleet',
    serviceExperiences: 'BESPOKE EXPERIENCES',
    serviceExperiencesSub: 'Tailor-made cultural immersions',
    serviceWellness: 'WELLNESS & SPA',
    serviceWellnessSub: 'Body & mind healing sanctuaries',
    servicePrivileges: 'EXCLUSIVE PRIVILEGES',
    servicePrivilegesSub: 'Elite inner-circle hospitality',
    
    // Experience
    artOfHospitality: 'THE ART OF HOSPITALITY',
    hospitalityHeadline: 'Where China Meets Contemporary Luxury',
    hospitalityBody: 'Yunqi Hotels & Resorts creates extraordinary stays shaped by place, architecture, cuisine and culture. Every property is designed as a gateway into its surroundings — combining contemporary design with the timeless principles of Chinese hospitality.',
    discoverYunqi: 'DISCOVER YUNQI',
    
    // Architecture
    archTitle: 'ARCHITECTURE OF PLACE',
    archOverlay: 'DESIGNED FOR THE LANDSCAPE',
    archSubtitle: 'Monuments of quiet grandeur shaped by sacred topographies',
    locationMeta: 'LOCATION',
    architectMeta: 'ARCHITECT',
    yearMeta: 'YEAR',
    roomsMeta: 'ROOMS',
    elevationMeta: 'ELEVATION',
    
    // Dining
    diningTitle: 'DINING & CUISINE',
    diningHeadline: 'A TABLE WORTH TRAVELLING FOR',
    diningSubheading: 'From Michelin-starred Jiangnan delicacies to Song Dynasty imperial tea rituals.',
    discoverDining: 'DISCOVER DINING',
    signatureDishLabel: 'Signature Creation',
    reserveTable: 'RESERVE TABLE',
    
    // Wellness
    wellnessTitle: 'HOLISTIC WELLNESS',
    wellnessHeadline: 'THE QUIET WITHIN',
    wellnessSubheading: 'Wellness shaped by ancient traditions and contemporary science.',
    exploreWellness: 'EXPLORE WELLNESS',
    
    // Bespoke
    bespokeTitle: 'CURATED DISCOVERY',
    bespokeHeadline: 'BESPOKE EXPERIENCES',
    bespokeSubheading: 'Exclusive access to China’s hidden heritage, master artisans, and sacred mountains.',
    
    // Membership
    membershipTitle: 'INNER CIRCLE',
    membershipHeadline: 'YUNQI PRIVILEGES',
    membershipSubheading: 'A private world beyond the stay.',
    discoverPrivileges: 'DISCOVER PRIVILEGES',
    applyMembership: 'REQUEST AN INVITATION',
    
    // Footer
    footerCopy: '© 2026 YUNQI HOTELS & RESORTS. ALL RIGHTS RESERVED.',
    footerLegal: 'Crafted with precision for discerning global travellers.',
    privacy: 'Privacy Policy',
    terms: 'Terms of Service',
    accessibility: 'Accessibility',
    contact: 'CONTACT',
    newsletterTitle: 'THE YUNQI GAZETTE',
    newsletterSub: 'Receive private invitations and seasonal cultural releases.',
    subscribe: 'JOIN',
    
    // Modal
    closeModal: 'Close',
    bookThisRoom: 'RESERVE SUITE',
    roomFeatures: 'Suite Amenities & Privileges',
    suiteDetails: 'Suite Specifications'
  },
  zh: {
    brandName: 'YUNQI HOTELS & RESORTS',
    brandChinese: '云栖',
    tagline: '不止于下榻 · 邂逅永恒的中国',
    heroSubtitle: 'A JOURNEY INTO TIMELESS CHINA',
    heroEyebrow: 'MORE THAN A STAY · 隐世奢境',
    heroCopy: '非凡境地 · 传世待客之道 · 遍布华夏的顶级避世奢华酒店与度假村',
    exploreHotelsCTA: '探索云栖秘境',
    scrollToDiscover: '向下滑动 · 开启探索',
    
    // Nav
    navHome: '首页',
    navHotels: '旗下酒店',
    navExperiences: '私享旅程',
    navDining: '云端美馔',
    navWellness: '身心疗愈',
    navArchitecture: '建筑美学',
    navAbout: '品牌故事',
    bookNow: '即刻预订',
    
    // Booking
    planYourStay: '预订您的隐奢之旅',
    destination: '目的地',
    selectDestination: '请选择目的地酒店',
    checkIn: '入住日期',
    checkOut: '离店日期',
    guests: '入住人数',
    adults: '成人',
    children: '儿童',
    guestsCount: (adults: number) => `${adults}位成人`,
    night: '晚',
    nights: '晚',
    bookStay: '立即查询预订',
    viewRates: '查看房型与房价',
    
    // Hotels Section
    ourHotels: '旗下酒店与度假村',
    hotelsSubheading: '非凡胜境 · 极致视野 · 东方大美',
    viewProperty: '探索此间秘境',
    fromPrice: '每晚自',
    perNight: '/ 晚起',
    
    // Signature Services
    servicesTitle: '尊崇礼遇',
    serviceDining: '米其林级餐饮体验',
    serviceDiningSub: '融汇古今东方美食艺术',
    serviceTransfers: '专属专车接送服务',
    serviceTransfersSub: '劳斯莱斯与迈巴赫专属车队',
    serviceExperiences: '定制专属文化旅程',
    serviceExperiencesSub: '非遗大师与文化学者独家私享',
    serviceWellness: '身心疗愈静修之旅',
    serviceWellnessSub: '古法本草温泉与颂钵音疗',
    servicePrivileges: '尊享会员礼遇',
    servicePrivilegesSub: '私属会员圈层定制礼遇',
    
    // Experience
    artOfHospitality: '东方待客之道',
    hospitalityHeadline: '当代建筑美学与华夏永恒奢华的交汇',
    hospitalityBody: '云栖酒店及度假村依山就势，以当代建筑为骨，以东方文脉为魂。每一处居所皆为通往当地自然与人文的灵性之门，将先锋建筑艺术与中国千年传世礼遇融为一体。',
    discoverYunqi: '探索云栖哲学',
    
    // Architecture
    archTitle: '场所之境 · 建筑大美',
    archOverlay: '为自然山水而生的纯粹构造',
    archSubtitle: '于壮丽山河之中，筑起宁静庄严的东方当代丰碑',
    locationMeta: '地理位置',
    architectMeta: '主创设计大师',
    yearMeta: '落成年份',
    roomsMeta: '客房体量',
    elevationMeta: '海拔高度',
    
    // Dining
    diningTitle: '珍馐美馔',
    diningHeadline: '一场值得为之远行的味蕾盛宴',
    diningSubheading: '从米其林星级江南私房菜，到宋代御茶道与高原风物探索。',
    discoverDining: '品味珍馔',
    signatureDishLabel: '主厨招牌传世名馔',
    reserveTable: '预订珍席',
    
    // Wellness
    wellnessTitle: '东方康养',
    wellnessHeadline: '静水流深 · 养心之境',
    wellnessSubheading: '融合数千年传统本草智慧与现代前沿细胞医学科学。',
    exploreWellness: '开启疗愈之旅',
    
    // Bespoke
    bespokeTitle: '私享定制',
    bespokeHeadline: '探索未至之境',
    bespokeSubheading: '独家探访华夏隐世文化遗产、非遗宗师工坊与雪山秘境。',
    
    // Membership
    membershipTitle: '私享会员体系',
    membershipHeadline: '云栖尊享礼遇',
    membershipSubheading: '超越下榻的私密尊崇世界。',
    discoverPrivileges: '了解会员权益',
    applyMembership: '申请尊荣会籍',
    
    // Footer
    footerCopy: '© 2026 云栖酒店及度假村集团版权所有。',
    footerLegal: '为全球品味卓绝的旅行家悉心缔造。',
    privacy: '隐私政策',
    terms: '服务条款',
    accessibility: '无障碍访问',
    contact: '联系礼宾部',
    newsletterTitle: '云栖雅集刊',
    newsletterSub: '订阅尊享季度文化私函与新酒店首发特权。',
    subscribe: '即刻订阅',
    
    // Modal
    closeModal: '关闭',
    bookThisRoom: '即刻预订此房型',
    roomFeatures: '尊享设施与专属礼遇',
    suiteDetails: '府邸套房规格'
  }
};
