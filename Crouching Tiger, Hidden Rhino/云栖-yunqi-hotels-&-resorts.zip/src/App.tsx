import React, { useState } from 'react';
import { LanguageProvider } from './context/LanguageContext';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { BookingEngine } from './components/BookingEngine';
import { DestinationGrid } from './components/DestinationGrid';
import { SignatureServices } from './components/SignatureServices';
import { YunqiExperience } from './components/YunqiExperience';
import { ArchitectureSection } from './components/ArchitectureSection';
import { DiningSection } from './components/DiningSection';
import { WellnessSection } from './components/WellnessSection';
import { BespokeExperiences } from './components/BespokeExperiences';
import { MembershipSection } from './components/MembershipSection';
import { Footer } from './components/Footer';
import { HotelDetailModal } from './components/HotelDetailModal';
import { BookingModal } from './components/BookingModal';
import { InquiryModal } from './components/InquiryModal';
import { Hotel, DiningItem, ExperienceItem } from './types';
import { HOTELS_DATA } from './data/hotels';

const AppContent: React.FC = () => {
  // Modal states
  const [selectedHotel, setSelectedHotel] = useState<Hotel | null>(null);
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [bookingDestination, setBookingDestination] = useState<string>('shanghai');
  const [bookingRoomId, setBookingRoomId] = useState<string | undefined>(undefined);
  const [isInquiryOpen, setIsInquiryOpen] = useState(false);
  const [inquiryMeta, setInquiryMeta] = useState<{ title: string; subtitle: string }>({
    title: 'YUNQI PRIVILEGES INVITATION',
    subtitle: 'A private world beyond the stay'
  });

  // Navigation handler
  const handleNavigate = (sectionId: string) => {
    const targetMap: Record<string, string> = {
      hotels: 'hotels-section',
      experience: 'about-section',
      about: 'about-section',
      architecture: 'architecture-section',
      dining: 'dining-section',
      wellness: 'wellness-section',
      experiences: 'experiences-section',
      membership: 'membership-section',
      contact: 'footer-section'
    };

    const elementId = targetMap[sectionId] || sectionId;
    const element = document.getElementById(elementId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Booking handlers
  const handleOpenBooking = (destinationId?: string, roomId?: string) => {
    if (destinationId) setBookingDestination(destinationId);
    if (roomId) setBookingRoomId(roomId);
    setIsBookingOpen(true);
  };

  const handleBookingEngineSearch = (params: {
    destination: string;
    checkIn: string;
    checkOut: string;
    guests: number;
  }) => {
    setBookingDestination(params.destination);
    setIsBookingOpen(true);
  };

  // Dining reservation handler
  const handleReserveDining = (dining: DiningItem) => {
    setInquiryMeta({
      title: `TABLE RESERVATION — ${dining.name.toUpperCase()}`,
      subtitle: `${dining.hotel} • ${dining.cuisine}`
    });
    setIsInquiryOpen(true);
  };

  // Bespoke experience inquiry handler
  const handleInquireExperience = (exp: ExperienceItem) => {
    setInquiryMeta({
      title: `BESPOKE ITINERARY — ${exp.title.toUpperCase()}`,
      subtitle: `${exp.categoryLabel} • ${exp.duration}`
    });
    setIsInquiryOpen(true);
  };

  // Membership application handler
  const handleApplyMembership = () => {
    setInquiryMeta({
      title: 'YUNQI PRIVILEGES COUNCIL INVITATION',
      subtitle: 'Apply for the Jade Circle, Amber Residence, or Obsidian Council'
    });
    setIsInquiryOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#071019] text-[#F3EFE7] selection:bg-[#C8A66A] selection:text-[#071019] overflow-x-hidden">
      {/* Sticky Global Luxury Header */}
      <Header
        onNavigate={handleNavigate}
        onOpenBooking={() => handleOpenBooking()}
      />

      {/* Hero Section with Cinematic Imagery & Soundscape */}
      <Hero
        onExploreClick={() => handleNavigate('hotels')}
        onBookClick={() => handleOpenBooking()}
      />

      {/* Floating Booking Engine Bar */}
      <BookingEngine
        onBookSubmit={(params) => {
          handleOpenBooking(params.destinationId);
        }}
      />

      {/* 4 Major Destination Cards Grid */}
      <DestinationGrid
        onSelectHotel={(hotel) => setSelectedHotel(hotel)}
      />

      {/* 5 Signature Services Luxury Bar */}
      <SignatureServices />

      {/* The Yunqi Experience / Art of Hospitality */}
      <YunqiExperience
        onDiscoverClick={() => handleNavigate('architecture')}
      />

      {/* Architecture of Place (Architectural Monographs & Metadata) */}
      <ArchitectureSection
        onSelectHotel={(hotel) => setSelectedHotel(hotel)}
      />

      {/* Fine Dining & Master Tea Ceremony */}
      <DiningSection
        onReserveClick={handleReserveDining}
      />

      {/* The Quiet Within - Wellness & Longevity */}
      <WellnessSection
        onExploreWellness={() => handleOpenBooking()}
      />

      {/* Bespoke Experiences Horizontal Gallery */}
      <BespokeExperiences
        onInquireExperience={handleInquireExperience}
      />

      {/* Membership & Sovereign Privileges */}
      <MembershipSection
        onApplyClick={handleApplyMembership}
      />

      {/* Luxury Footer */}
      <Footer
        onNavigate={handleNavigate}
        onOpenBooking={() => handleOpenBooking()}
      />

      {/* MODALS */}
      {/* 1. Hotel Detail Modal */}
      <HotelDetailModal
        hotel={selectedHotel}
        onClose={() => setSelectedHotel(null)}
        onBookRoom={(hotelId, roomId) => {
          setSelectedHotel(null);
          handleOpenBooking(hotelId, roomId);
        }}
      />

      {/* 2. Full Booking Checkout & Confirmation Slip Modal */}
      <BookingModal
        isOpen={isBookingOpen}
        onClose={() => setIsBookingOpen(false)}
        initialDestinationId={bookingDestination}
        initialRoomId={bookingRoomId}
      />

      {/* 3. Concierge Inquiry / Membership Application Modal */}
      <InquiryModal
        isOpen={isInquiryOpen}
        onClose={() => setIsInquiryOpen(false)}
        title={inquiryMeta.title}
        subtitle={inquiryMeta.subtitle}
      />
    </div>
  );
};

export default function App() {
  return (
    <LanguageProvider>
      <AppContent />
    </LanguageProvider>
  );
}
