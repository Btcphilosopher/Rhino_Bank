export type Language = 'en' | 'zh';

export interface RoomSuite {
  id: string;
  name: string;
  nameZh: string;
  size: string;
  occupancy: string;
  occupancyZh: string;
  view: string;
  viewZh: string;
  pricePerNight: number;
  description: string;
  descriptionZh: string;
  image: string;
  features: string[];
  featuresZh: string[];
}

export interface Hotel {
  id: string;
  name: string;
  nameZh: string;
  location: string;
  locationZh: string;
  tagline: string;
  taglineZh: string;
  shortDescription: string;
  shortDescriptionZh: string;
  longDescription: string;
  longDescriptionZh: string;
  heroImage: string;
  galleryImages: string[];
  architect: string;
  yearBuilt: string;
  elevation: string;
  totalRooms: number;
  keyFeatures: string[];
  keyFeaturesZh: string[];
  rooms: RoomSuite[];
  coordinates: { lat: number; lng: number };
  diningSummary: string;
  diningSummaryZh: string;
  wellnessSummary: string;
  wellnessSummaryZh: string;
}

export interface ExperienceItem {
  id: string;
  category: 'journeys' | 'culinary' | 'art' | 'mountains' | 'wellness' | 'aviation';
  categoryLabel: string;
  categoryLabelZh: string;
  title: string;
  titleZh: string;
  duration: string;
  durationZh: string;
  description: string;
  descriptionZh: string;
  image: string;
  highlights: string[];
  highlightsZh: string[];
}

export interface DiningItem {
  id: string;
  name: string;
  nameZh: string;
  hotel: string;
  hotelZh: string;
  cuisine: string;
  cuisineZh: string;
  description: string;
  descriptionZh: string;
  hours: string;
  dressCode: string;
  dressCodeZh: string;
  image: string;
  signatureDish: string;
  signatureDishZh: string;
}

export interface BookingState {
  destinationId: string;
  checkInDate: string;
  checkOutDate: string;
  guests: number;
  selectedRoomId?: string;
  specialRequests?: string;
  transfersIncluded?: boolean;
  teaCeremonyIncluded?: boolean;
}
