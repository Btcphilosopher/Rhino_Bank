import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { archImg } from '../data/hotels';
import { ArrowRight, Sparkles } from 'lucide-react';

interface YunqiExperienceProps {
  onDiscoverClick: () => void;
}

export const YunqiExperience: React.FC<YunqiExperienceProps> = ({ onDiscoverClick }) => {
  const { language, t } = useLanguage();

  return (
    <section id="about-section" className="relative bg-[#0D1720] py-20 lg:py-28 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Large Editorial Photography */}
          <div className="lg:col-span-6 relative">
            <div className="relative z-10 overflow-hidden border border-[#C8A66A]/25 shadow-2xl">
              <img
                src={archImg}
                alt="Contemporary Chinese Architectural Walkway"
                referrerPolicy="no-referrer"
                className="w-full h-[460px] sm:h-[540px] object-cover hover:scale-105 transition-transform duration-1000 ease-out"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#071019]/80 via-transparent to-transparent" />
              
              {/* Floating Caption Seal */}
              <div className="absolute bottom-6 left-6 right-6 p-4 bg-[#071019]/80 backdrop-blur-md border border-[#C8A66A]/20 flex items-center justify-between">
                <div>
                  <div className="text-[10px] tracking-[0.25em] text-[#C8A66A] uppercase font-cinzel">
                    PHILOSOPHY OF SPACE
                  </div>
                  <div className="font-chinese text-xs text-[#F3EFE7] mt-0.5">
                    融山水于室 · 纳天地于心
                  </div>
                </div>
                <div className="text-right font-mono text-[10px] text-[#A7A7A2]">
                  EST. 2024
                </div>
              </div>
            </div>

            {/* Subtle background decorative geometric border */}
            <div className="absolute -top-4 -left-4 w-32 h-32 border-t-2 border-l-2 border-[#C8A66A]/30 pointer-events-none -z-0" />
            <div className="absolute -bottom-4 -right-4 w-32 h-32 border-b-2 border-r-2 border-[#C8A66A]/30 pointer-events-none -z-0" />
          </div>

          {/* Right Column: Editorial Text & Tenets */}
          <div className="lg:col-span-6 flex flex-col justify-center">
            <div className="inline-flex items-center space-x-2.5 mb-3">
              <span className="w-5 h-[1px] bg-[#C8A66A]" />
              <span className="font-cinzel text-xs tracking-[0.3em] text-[#C8A66A] uppercase font-semibold">
                {t.artOfHospitality}
              </span>
            </div>

            <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-normal text-[#F3EFE7] leading-[1.15] mb-6">
              {language === 'en' ? (
                <>
                  Where China Meets <br />
                  <span className="text-gold-gradient font-light">Contemporary Luxury</span>
                </>
              ) : (
                <>
                  当代建筑美学与 <br />
                  <span className="text-gold-gradient font-light">华夏永恒奢华的交汇</span>
                </>
              )}
            </h2>

            <p className="text-sm sm:text-base text-[#A7A7A2] font-light leading-relaxed mb-6">
              {t.hospitalityBody}
            </p>

            {/* Three Philosophical Pillars */}
            <div className="space-y-4 mb-8 pt-4 border-t border-[#C8A66A]/15">
              <div className="flex items-start space-x-3.5">
                <span className="text-[#C8A66A] font-serif-luxury text-lg mt-0.5">壹</span>
                <div>
                  <h4 className="text-xs font-cinzel tracking-[0.18em] text-[#E4CC98] uppercase font-semibold">
                    {language === 'en' ? 'Architectural Harmony with Nature' : '天人合一 · 依山筑居'}
                  </h4>
                  <p className="text-xs text-[#A7A7A2] mt-0.5 font-light">
                    {language === 'en'
                      ? 'Structures designed to disappear into their dramatic landscapes, celebrating light, shadow, and stone.'
                      : '建筑依地势而生，借景纳翠，以光影与原石构筑安放心灵的精神殿堂。'}
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-3.5">
                <span className="text-[#C8A66A] font-serif-luxury text-lg mt-0.5">贰</span>
                <div>
                  <h4 className="text-xs font-cinzel tracking-[0.18em] text-[#E4CC98] uppercase font-semibold">
                    {language === 'en' ? 'Bespoke Cultural Resonance' : '文脉承传 · 四般闲事'}
                  </h4>
                  <p className="text-xs text-[#A7A7A2] mt-0.5 font-light">
                    {language === 'en'
                      ? 'Reinterpreting the classical scholar arts of tea, incense, calligraphy, and seasonal gastronomy.'
                      : '重现宋明文人焚香、点茶、挂画、插花之雅，将千年文化注入当代居停。'}
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-3.5">
                <span className="text-[#C8A66A] font-serif-luxury text-lg mt-0.5">叁</span>
                <div>
                  <h4 className="text-xs font-cinzel tracking-[0.18em] text-[#E4CC98] uppercase font-semibold">
                    {language === 'en' ? 'Quiet & Intuitive Care' : '润物无声 · 极致私享'}
                  </h4>
                  <p className="text-xs text-[#A7A7A2] mt-0.5 font-light">
                    {language === 'en'
                      ? 'Unobtrusive, heartfelt hospitality guided by ancient Chinese rites of genuine warmth.'
                      : '秉承东方至诚礼乐之道，专属管家随候无形，知您所想，予您从容。'}
                  </p>
                </div>
              </div>
            </div>

            {/* CTA */}
            <div>
              <button
                id="experience-discover-btn"
                onClick={onDiscoverClick}
                className="group inline-flex items-center space-x-3 text-xs font-semibold tracking-[0.25em] uppercase text-[#E4CC98] hover:text-white transition-colors"
              >
                <span>{t.discoverYunqi}</span>
                <ArrowRight className="w-4 h-4 text-[#C8A66A] group-hover:translate-x-1.5 transition-transform" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
