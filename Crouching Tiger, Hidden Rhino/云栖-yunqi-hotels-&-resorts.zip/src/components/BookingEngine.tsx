import React, { useState, useRef, useEffect } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { HOTELS_DATA } from '../data/hotels';
import { Calendar, Users, MapPin, ChevronDown, Check } from 'lucide-react';

interface BookingEngineProps {
  onBookSubmit: (params: {
    destinationId: string;
    checkInDate: string;
    checkOutDate: string;
    guests: number;
  }) => void;
  selectedHotelId?: string;
}

export const BookingEngine: React.FC<BookingEngineProps> = ({
  onBookSubmit,
  selectedHotelId = 'shanghai'
}) => {
  const { language, t } = useLanguage();
  const [destinationId, setDestinationId] = useState(selectedHotelId);
  const [checkIn, setCheckIn] = useState('2026-10-25');
  const [checkOut, setCheckOut] = useState('2026-10-28');
  const [adults, setAdults] = useState(2);
  const [children, setChildren] = useState(0);

  // Dropdown menus states
  const [destDropdownOpen, setDestDropdownOpen] = useState(false);
  const [guestsDropdownOpen, setGuestsDropdownOpen] = useState(false);
  const [dateModalOpen, setDateModalOpen] = useState(false);

  const destRef = useRef<HTMLDivElement>(null);
  const guestsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (selectedHotelId) {
      setDestinationId(selectedHotelId);
    }
  }, [selectedHotelId]);

  // Click outside to close dropdowns
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (destRef.current && !destRef.current.contains(e.target as Node)) {
        setDestDropdownOpen(false);
      }
      if (guestsRef.current && !guestsRef.current.contains(e.target as Node)) {
        setGuestsDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const currentHotel = HOTELS_DATA.find((h) => h.id === destinationId) || HOTELS_DATA[0];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onBookSubmit({
      destinationId,
      checkInDate: checkIn,
      checkOutDate: checkOut,
      guests: adults + children
    });
  };

  return (
    <div
      id="booking-engine-widget"
      className="w-full bg-[#0D1720]/90 border border-[#C8A66A]/25 backdrop-blur-xl p-5 sm:p-6 shadow-2xl flex flex-col justify-between"
    >
      <div className="flex items-center justify-between mb-4 pb-2 border-b border-[#C8A66A]/15">
        <h3 className="font-cinzel text-xs sm:text-[13px] tracking-[0.25em] text-[#E4CC98] uppercase font-semibold">
          {t.planYourStay}
        </h3>
        <span className="text-[10px] text-[#A7A7A2] tracking-wider uppercase font-mono">
          DIRECT GUARANTEE
        </span>
      </div>

      <form onSubmit={handleSubmit} className="space-y-3.5">
        {/* Destination Dropdown Field */}
        <div className="relative" ref={destRef}>
          <label className="block text-[10px] font-medium tracking-[0.18em] text-[#A7A7A2] uppercase mb-1">
            {t.destination}
          </label>
          <button
            type="button"
            id="booking-dest-selector-btn"
            onClick={() => {
              setDestDropdownOpen(!destDropdownOpen);
              setGuestsDropdownOpen(false);
            }}
            className="w-full flex items-center justify-between bg-[#071019]/80 border border-[#C8A66A]/30 hover:border-[#C8A66A] px-3.5 py-2.5 text-left text-xs tracking-wide text-[#F3EFE7] transition-all focus:outline-none"
          >
            <div className="flex items-center space-x-2 truncate">
              <MapPin className="w-3.5 h-3.5 text-[#C8A66A] shrink-0" />
              <span className="font-medium truncate">
                {language === 'en' ? currentHotel.name : currentHotel.nameZh} —{' '}
                <span className="text-[#A7A7A2] text-[11px] font-normal">
                  {language === 'en' ? currentHotel.tagline : currentHotel.taglineZh}
                </span>
              </span>
            </div>
            <ChevronDown
              className={`w-3.5 h-3.5 text-[#C8A66A] shrink-0 transition-transform ${
                destDropdownOpen ? 'rotate-180' : ''
              }`}
            />
          </button>

          {/* Destination Dropdown Menu */}
          {destDropdownOpen && (
            <div className="absolute top-full left-0 right-0 mt-1 z-30 bg-[#0D1720] border border-[#C8A66A]/40 shadow-2xl py-1 max-h-60 overflow-y-auto animate-fade-in">
              {HOTELS_DATA.map((hotel) => (
                <button
                  key={hotel.id}
                  type="button"
                  onClick={() => {
                    setDestinationId(hotel.id);
                    setDestDropdownOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 text-left text-xs tracking-wide transition-colors ${
                    destinationId === hotel.id
                      ? 'bg-[#C8A66A]/20 text-[#E4CC98]'
                      : 'text-[#F3EFE7] hover:bg-[#071019]'
                  }`}
                >
                  <div className="flex items-center space-x-2.5 truncate">
                    <img
                      src={hotel.heroImage}
                      alt={hotel.name}
                      referrerPolicy="no-referrer"
                      className="w-8 h-8 object-cover rounded-[2px] border border-[#C8A66A]/30"
                    />
                    <div>
                      <div className="font-medium text-[#F3EFE7]">
                        {language === 'en' ? hotel.name : hotel.nameZh}
                      </div>
                      <div className="text-[10px] text-[#A7A7A2]">
                        {language === 'en' ? hotel.location : hotel.locationZh}
                      </div>
                    </div>
                  </div>
                  {destinationId === hotel.id && (
                    <Check className="w-3.5 h-3.5 text-[#C8A66A]" />
                  )}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Dates Selection (Check In & Check Out) */}
        <div className="grid grid-cols-2 gap-2.5">
          {/* Check In */}
          <div>
            <label className="block text-[10px] font-medium tracking-[0.18em] text-[#A7A7A2] uppercase mb-1">
              {t.checkIn}
            </label>
            <div className="relative">
              <input
                type="date"
                id="booking-checkin-input"
                value={checkIn}
                onChange={(e) => setCheckIn(e.target.value)}
                className="w-full bg-[#071019]/80 border border-[#C8A66A]/30 hover:border-[#C8A66A] focus:border-[#C8A66A] px-3 py-2 text-xs text-[#F3EFE7] font-mono tracking-wider focus:outline-none transition-colors cursor-pointer"
              />
              <Calendar className="w-3.5 h-3.5 text-[#C8A66A] absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>
          </div>

          {/* Check Out */}
          <div>
            <label className="block text-[10px] font-medium tracking-[0.18em] text-[#A7A7A2] uppercase mb-1">
              {t.checkOut}
            </label>
            <div className="relative">
              <input
                type="date"
                id="booking-checkout-input"
                value={checkOut}
                onChange={(e) => setCheckOut(e.target.value)}
                className="w-full bg-[#071019]/80 border border-[#C8A66A]/30 hover:border-[#C8A66A] focus:border-[#C8A66A] px-3 py-2 text-xs text-[#F3EFE7] font-mono tracking-wider focus:outline-none transition-colors cursor-pointer"
              />
              <Calendar className="w-3.5 h-3.5 text-[#C8A66A] absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>
          </div>
        </div>

        {/* Guests Selector */}
        <div className="relative" ref={guestsRef}>
          <label className="block text-[10px] font-medium tracking-[0.18em] text-[#A7A7A2] uppercase mb-1">
            {t.guests}
          </label>
          <button
            type="button"
            id="booking-guests-selector-btn"
            onClick={() => {
              setGuestsDropdownOpen(!guestsDropdownOpen);
              setDestDropdownOpen(false);
            }}
            className="w-full flex items-center justify-between bg-[#071019]/80 border border-[#C8A66A]/30 hover:border-[#C8A66A] px-3.5 py-2.5 text-left text-xs tracking-wide text-[#F3EFE7] transition-all focus:outline-none"
          >
            <div className="flex items-center space-x-2">
              <Users className="w-3.5 h-3.5 text-[#C8A66A]" />
              <span className="font-medium">
                {language === 'en'
                  ? `${adults} Adult${adults > 1 ? 's' : ''}${
                      children > 0 ? `, ${children} Child` : ''
                    }`
                  : `${adults} 位成人${children > 0 ? `，${children} 位儿童` : ''}`}
              </span>
            </div>
            <ChevronDown
              className={`w-3.5 h-3.5 text-[#C8A66A] transition-transform ${
                guestsDropdownOpen ? 'rotate-180' : ''
              }`}
            />
          </button>

          {/* Guests Popover */}
          {guestsDropdownOpen && (
            <div className="absolute bottom-full left-0 right-0 mb-1 sm:bottom-auto sm:top-full sm:mt-1 z-30 bg-[#0D1720] border border-[#C8A66A]/40 shadow-2xl p-4 space-y-3 animate-fade-in">
              {/* Adults Counter */}
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs font-medium text-[#F3EFE7]">{t.adults}</div>
                  <div className="text-[10px] text-[#A7A7A2]">Age 12+</div>
                </div>
                <div className="flex items-center space-x-3">
                  <button
                    type="button"
                    onClick={() => setAdults(Math.max(1, adults - 1))}
                    className="w-6 h-6 rounded border border-[#C8A66A]/40 flex items-center justify-center text-xs text-[#E4CC98] hover:bg-[#C8A66A]/20"
                  >
                    -
                  </button>
                  <span className="text-xs font-mono font-bold w-4 text-center">{adults}</span>
                  <button
                    type="button"
                    onClick={() => setAdults(Math.min(6, adults + 1))}
                    className="w-6 h-6 rounded border border-[#C8A66A]/40 flex items-center justify-center text-xs text-[#E4CC98] hover:bg-[#C8A66A]/20"
                  >
                    +
                  </button>
                </div>
              </div>

              {/* Children Counter */}
              <div className="flex items-center justify-between pt-2 border-t border-white/5">
                <div>
                  <div className="text-xs font-medium text-[#F3EFE7]">{t.children}</div>
                  <div className="text-[10px] text-[#A7A7A2]">Age 0-11</div>
                </div>
                <div className="flex items-center space-x-3">
                  <button
                    type="button"
                    onClick={() => setChildren(Math.max(0, children - 1))}
                    className="w-6 h-6 rounded border border-[#C8A66A]/40 flex items-center justify-center text-xs text-[#E4CC98] hover:bg-[#C8A66A]/20"
                  >
                    -
                  </button>
                  <span className="text-xs font-mono font-bold w-4 text-center">{children}</span>
                  <button
                    type="button"
                    onClick={() => setChildren(Math.min(4, children + 1))}
                    className="w-6 h-6 rounded border border-[#C8A66A]/40 flex items-center justify-center text-xs text-[#E4CC98] hover:bg-[#C8A66A]/20"
                  >
                    +
                  </button>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setGuestsDropdownOpen(false)}
                className="w-full py-1.5 bg-[#C8A66A]/20 hover:bg-[#C8A66A]/30 text-[#E4CC98] text-[11px] font-semibold tracking-wider uppercase mt-2 transition-colors"
              >
                Apply
              </button>
            </div>
          )}
        </div>

        {/* Primary Book Now CTA */}
        <button
          type="submit"
          id="booking-submit-btn"
          className="w-full py-3 text-center text-xs font-semibold tracking-[0.22em] uppercase text-[#071019] bg-[#C8A66A] hover:bg-[#E4CC98] transition-all duration-300 shadow-lg hover:shadow-[0_0_25px_rgba(200,166,106,0.4)] focus:outline-none cursor-pointer"
        >
          {t.bookStay}
        </button>
      </form>
    </div>
  );
};
