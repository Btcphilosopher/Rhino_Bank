import React from 'react';
import { useLanguage } from '../context/LanguageContext';

interface ServiceItemProps {
  iconType: 'dining' | 'transfers' | 'experiences' | 'wellness' | 'privileges';
  title: string;
  titleZh: string;
  subtitle: string;
}

// Minimal gold line SVG traditional emblems matching the reference aesthetic
const ServiceIcon: React.FC<{ type: string }> = ({ type }) => {
  const gold = '#C8A66A';
  
  switch (type) {
    case 'dining':
      return (
        <svg width="36" height="36" viewBox="0 0 48 48" fill="none" className="transition-transform duration-500 group-hover:scale-110">
          <circle cx="24" cy="24" r="22" stroke={gold} strokeWidth="1" strokeOpacity="0.8" />
          <circle cx="24" cy="24" r="18" stroke={gold} strokeWidth="0.5" strokeOpacity="0.4" strokeDasharray="2 2" />
          {/* Porcelain Cloche & Chopsticks / Classical symmetry */}
          <path d="M16 28 C16 20, 32 20, 32 28 Z" stroke={gold} strokeWidth="1.2" />
          <line x1="14" y1="29" x2="34" y2="29" stroke={gold} strokeWidth="1.2" />
          <line x1="24" y1="16" x2="24" y2="19" stroke={gold} strokeWidth="1.2" />
          <circle cx="24" cy="15" r="1.5" fill={gold} />
          {/* Subtle tea leaf or chopsticks motif */}
          <line x1="18" y1="33" x2="30" y2="33" stroke={gold} strokeWidth="0.8" />
        </svg>
      );
    case 'transfers':
      return (
        <svg width="36" height="36" viewBox="0 0 48 48" fill="none" className="transition-transform duration-500 group-hover:scale-110">
          <circle cx="24" cy="24" r="22" stroke={gold} strokeWidth="1" strokeOpacity="0.8" />
          <circle cx="24" cy="24" r="18" stroke={gold} strokeWidth="0.5" strokeOpacity="0.4" strokeDasharray="2 2" />
          {/* Chariot wheel / fleet compass motif */}
          <circle cx="24" cy="24" r="9" stroke={gold} strokeWidth="1.2" />
          <circle cx="24" cy="24" r="3" fill={gold} />
          <line x1="24" y1="11" x2="24" y2="37" stroke={gold} strokeWidth="0.8" />
          <line x1="11" y1="24" x2="37" y2="24" stroke={gold} strokeWidth="0.8" />
          <line x1="15" y1="15" x2="33" y2="33" stroke={gold} strokeWidth="0.6" strokeDasharray="1 1" />
          <line x1="33" y1="15" x2="15" y2="33" stroke={gold} strokeWidth="0.6" strokeDasharray="1 1" />
        </svg>
      );
    case 'experiences':
      return (
        <svg width="36" height="36" viewBox="0 0 48 48" fill="none" className="transition-transform duration-500 group-hover:scale-110">
          <circle cx="24" cy="24" r="22" stroke={gold} strokeWidth="1" strokeOpacity="0.8" />
          <circle cx="24" cy="24" r="18" stroke={gold} strokeWidth="0.5" strokeOpacity="0.4" strokeDasharray="2 2" />
          {/* Chinese mountain peaks & moon motif */}
          <path d="M14 31 L22 19 L28 27 L34 21" stroke={gold} strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
          <circle cx="31" cy="16" r="2.5" stroke={gold} strokeWidth="1" />
          <line x1="12" y1="33" x2="36" y2="33" stroke={gold} strokeWidth="1" />
        </svg>
      );
    case 'wellness':
      return (
        <svg width="36" height="36" viewBox="0 0 48 48" fill="none" className="transition-transform duration-500 group-hover:scale-110">
          <circle cx="24" cy="24" r="22" stroke={gold} strokeWidth="1" strokeOpacity="0.8" />
          <circle cx="24" cy="24" r="18" stroke={gold} strokeWidth="0.5" strokeOpacity="0.4" strokeDasharray="2 2" />
          {/* Lotus / Bamboo leaf tranquil symmetry */}
          <path d="M24 14 C24 22, 17 26, 17 30 C17 33, 20 34, 24 34 C28 34, 31 33, 31 30 C31 26, 24 22, 24 14 Z" stroke={gold} strokeWidth="1.2" fill="none" />
          <path d="M24 20 C21 24, 14 26, 14 30" stroke={gold} strokeWidth="0.8" strokeLinecap="round" />
          <path d="M24 20 C27 24, 34 26, 34 30" stroke={gold} strokeWidth="0.8" strokeLinecap="round" />
        </svg>
      );
    case 'privileges':
      return (
        <svg width="36" height="36" viewBox="0 0 48 48" fill="none" className="transition-transform duration-500 group-hover:scale-110">
          <circle cx="24" cy="24" r="22" stroke={gold} strokeWidth="1" strokeOpacity="0.8" />
          <circle cx="24" cy="24" r="18" stroke={gold} strokeWidth="0.5" strokeOpacity="0.4" strokeDasharray="2 2" />
          {/* Chinese royal seal / Bi disc key */}
          <rect x="18" y="16" width="12" height="16" stroke={gold} strokeWidth="1.2" />
          <line x1="24" y1="16" x2="24" y2="32" stroke={gold} strokeWidth="0.8" />
          <line x1="18" y1="24" x2="30" y2="24" stroke={gold} strokeWidth="0.8" />
          <circle cx="24" cy="24" r="2" fill={gold} />
          <path d="M20 34 L24 37 L28 34" stroke={gold} strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    default:
      return null;
  }
};

export const SignatureServices: React.FC = () => {
  const { language, t } = useLanguage();

  const services = [
    {
      id: 'dining',
      title: t.serviceDining,
      titleZh: '米其林餐级餐饮体验',
      subtitle: t.serviceDiningSub,
      type: 'dining' as const
    },
    {
      id: 'transfers',
      title: t.serviceTransfers,
      titleZh: '专属接送服务',
      subtitle: t.serviceTransfersSub,
      type: 'transfers' as const
    },
    {
      id: 'experiences',
      title: t.serviceExperiences,
      titleZh: '定制专属旅程',
      subtitle: t.serviceExperiencesSub,
      type: 'experiences' as const
    },
    {
      id: 'wellness',
      title: t.serviceWellness,
      titleZh: '身心疗愈之旅',
      subtitle: t.serviceWellnessSub,
      type: 'wellness' as const
    },
    {
      id: 'privileges',
      title: t.servicePrivileges,
      titleZh: '尊享会员礼遇',
      subtitle: t.servicePrivilegesSub,
      type: 'privileges' as const
    }
  ];

  return (
    <section className="bg-[#071019] border-y border-[#C8A66A]/20 py-8 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-6 sm:gap-8 items-center">
          {services.map((service, index) => (
            <div
              key={service.id}
              className={`group flex items-center space-x-3.5 transition-all duration-300 hover:translate-y-[-2px] ${
                index === 4 ? 'col-span-2 md:col-span-1 justify-center md:justify-start' : ''
              }`}
            >
              <div className="shrink-0 text-[#C8A66A]">
                <ServiceIcon type={service.type} />
              </div>
              <div className="flex flex-col">
                <span className="font-cinzel text-[11px] font-semibold tracking-[0.18em] text-[#F3EFE7] group-hover:text-[#E4CC98] transition-colors leading-tight">
                  {service.title}
                </span>
                <span className="font-chinese text-[11px] text-[#A7A7A2] group-hover:text-[#F3EFE7]/90 transition-colors mt-0.5 font-light">
                  {service.titleZh}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
