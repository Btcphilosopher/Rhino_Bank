import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { HOTELS_DATA } from '../data/hotels';
import { Emblem, ChineseSeal } from './Emblem';
import { X, Calendar, MapPin, Users, Check, Sparkles, CheckCircle2, ShieldCheck, Printer, Phone } from 'lucide-react';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialDestinationId?: string;
  initialRoomId?: string;
}

export const BookingModal: React.FC<BookingModalProps> = ({
  isOpen,
  onClose,
  initialDestinationId = 'shanghai',
  initialRoomId
}) => {
  const { language, t } = useLanguage();
  const [destinationId, setDestinationId] = useState(initialDestinationId);
  const [checkIn, setCheckIn] = useState('2026-10-25');
  const [checkOut, setCheckOut] = useState('2026-10-28');
  const [adults, setAdults] = useState(2);
  const [guestName, setGuestName] = useState('');
  const [guestEmail, setGuestEmail] = useState('');
  const [guestPhone, setGuestPhone] = useState('');
  const [specialRequests, setSpecialRequests] = useState('');
  
  // Add-on options
  const [transferAddon, setTransferAddon] = useState(true);
  const [teaAddon, setTeaAddon] = useState(true);
  const [spaAddon, setSpaAddon] = useState(false);

  // Success state
  const [isConfirmed, setIsConfirmed] = useState(false);
  const [reservationCode, setReservationCode] = useState('');

  if (!isOpen) return null;

  const currentHotel = HOTELS_DATA.find((h) => h.id === destinationId) || HOTELS_DATA[0];
  const selectedRoom = currentHotel.rooms.find((r) => r.id === initialRoomId) || currentHotel.rooms[0];
  const [roomId, setRoomId] = useState(selectedRoom.id);
  const activeRoom = currentHotel.rooms.find((r) => r.id === roomId) || currentHotel.rooms[0];

  // Calculate nights
  const checkInDate = new Date(checkIn);
  const checkOutDate = new Date(checkOut);
  const diffTime = Math.abs(checkOutDate.getTime() - checkInDate.getTime());
  const nights = Math.max(1, Math.ceil(diffTime / (1000 * 60 * 60 * 24))) || 3;

  const roomTotal = activeRoom.pricePerNight * nights;
  const transferPrice = transferAddon ? 1800 : 0;
  const teaPrice = teaAddon ? 980 : 0;
  const spaPrice = spaAddon ? 2600 : 0;
  const grandTotal = roomTotal + transferPrice + teaPrice + spaPrice;

  const handleConfirmReservation = (e: React.FormEvent) => {
    e.preventDefault();
    const randomCode = 'YQ-' + Math.floor(100000 + Math.random() * 900000);
    setReservationCode(randomCode);
    setIsConfirmed(true);
  };

  return (
    <div
      id="booking-checkout-modal"
      className="fixed inset-0 z-50 overflow-y-auto bg-black/90 backdrop-blur-xl flex justify-center items-center p-3 sm:p-6 animate-fade-in"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-4xl bg-[#071019] border border-[#C8A66A]/40 shadow-[0_0_90px_rgba(0,0,0,0.9)] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-30 w-9 h-9 rounded-full bg-[#0D1720] border border-[#C8A66A]/30 text-[#E4CC98] hover:text-white flex items-center justify-center transition-colors focus:outline-none"
          aria-label="Close Booking"
        >
          <X className="w-4 h-4" />
        </button>

        {isConfirmed ? (
          /* SUCCESS CONFIRMATION SLIP */
          <div className="p-8 sm:p-12 text-center bg-grain">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-[#C8A66A]/15 border border-[#C8A66A] text-[#E4CC98] mb-4">
              <CheckCircle2 className="w-8 h-8 text-[#C8A66A]" />
            </div>

            <div className="inline-flex items-center space-x-2 text-xs font-cinzel tracking-[0.3em] text-[#C8A66A] uppercase mb-2">
              <span>RESERVATION CONFIRMED</span>
            </div>

            <h2 className="font-serif-luxury text-3xl sm:text-4xl text-[#F3EFE7] mb-2">
              {language === 'en' ? 'Your Timeless Sanctuary Awaits' : '云栖居停 · 恭候大驾'}
            </h2>
            
            <p className="text-xs sm:text-sm text-[#A7A7A2] max-w-md mx-auto mb-8 font-light">
              {language === 'en'
                ? 'Your private concierge has received your reservation and will contact you directly to curate bespoke arrival arrangements.'
                : '专属私人管家已接收您的居停预订，稍后将致电恭候，为您安排无微不至的到店礼遇。'}
            </p>

            {/* Luxurious Reservation Voucher Box */}
            <div className="max-w-lg mx-auto bg-[#0D1720] border border-[#C8A66A]/40 p-6 sm:p-8 text-left relative shadow-2xl mb-8">
              <div className="flex items-center justify-between pb-4 border-b border-[#C8A66A]/20 mb-4">
                <div className="flex items-center space-x-3">
                  <Emblem size={32} />
                  <div>
                    <span className="font-chinese text-base text-[#F3EFE7] tracking-widest">云栖</span>
                    <span className="font-cinzel text-[9px] text-[#C8A66A] block">HOTELS & RESORTS</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-[9.5px] font-cinzel text-[#A7A7A2] block uppercase">CONFIRMATION CODE</span>
                  <span className="font-mono text-sm sm:text-base font-bold text-[#E4CC98] tracking-widest">{reservationCode}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 text-xs mb-4">
                <div>
                  <span className="text-[#A7A7A2] text-[10px] block uppercase">SANCTUARY</span>
                  <span className="text-[#F3EFE7] font-medium font-serif-luxury text-sm">
                    {language === 'en' ? currentHotel.name : currentHotel.nameZh}
                  </span>
                </div>
                <div>
                  <span className="text-[#A7A7A2] text-[10px] block uppercase">SUITE TYPE</span>
                  <span className="text-[#F3EFE7] font-medium text-xs">
                    {language === 'en' ? activeRoom.name : activeRoom.nameZh}
                  </span>
                </div>
                <div>
                  <span className="text-[#A7A7A2] text-[10px] block uppercase">DATES</span>
                  <span className="text-[#F3EFE7] font-mono text-[11.5px]">
                    {checkIn} → {checkOut} ({nights} {t.nights})
                  </span>
                </div>
                <div>
                  <span className="text-[#A7A7A2] text-[10px] block uppercase">GUEST</span>
                  <span className="text-[#F3EFE7]">{guestName || 'VIP Patron'} ({adults} Guests)</span>
                </div>
              </div>

              <div className="pt-4 border-t border-white/5 flex items-center justify-between text-xs">
                <span className="text-[#A7A7A2] font-cinzel">TOTAL RESERVATION</span>
                <span className="font-mono text-base text-[#E4CC98] font-bold">
                  ¥{grandTotal.toLocaleString()} CNY
                </span>
              </div>
            </div>

            <div className="flex items-center justify-center space-x-4">
              <button
                onClick={() => window.print()}
                className="px-5 py-2.5 bg-[#0D1720] hover:bg-[#C8A66A]/20 border border-[#C8A66A]/40 text-xs text-[#E4CC98] font-cinzel tracking-wider uppercase transition-colors inline-flex items-center space-x-2"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print Slip</span>
              </button>
              <button
                onClick={onClose}
                className="px-6 py-2.5 bg-[#C8A66A] hover:bg-[#E4CC98] text-[#071019] text-xs font-semibold tracking-widest uppercase transition-colors"
              >
                Return to Site
              </button>
            </div>
          </div>
        ) : (
          /* BOOKING CHECKOUT FORM */
          <div className="grid grid-cols-1 lg:grid-cols-12">
            {/* Left: Interactive Form */}
            <div className="lg:col-span-7 p-6 sm:p-8 bg-[#071019]">
              <div className="flex items-center space-x-2 text-[10.5px] font-cinzel tracking-[0.25em] text-[#C8A66A] uppercase mb-1">
                <span>DIRECT RESERVATION</span>
              </div>
              <h2 className="font-serif-luxury text-2xl sm:text-3xl text-[#F3EFE7] mb-6">
                {t.planYourStay}
              </h2>

              <form onSubmit={handleConfirmReservation} className="space-y-4">
                {/* Destination Picker */}
                <div>
                  <label className="block text-[10px] font-cinzel tracking-wider text-[#A7A7A2] uppercase mb-1">
                    {t.destination}
                  </label>
                  <select
                    value={destinationId}
                    onChange={(e) => setDestinationId(e.target.value)}
                    className="w-full bg-[#0D1720] border border-[#C8A66A]/30 px-3.5 py-2.5 text-xs text-[#F3EFE7] focus:border-[#C8A66A] focus:outline-none"
                  >
                    {HOTELS_DATA.map((h) => (
                      <option key={h.id} value={h.id}>
                        {language === 'en' ? h.name : h.nameZh} — {language === 'en' ? h.tagline : h.taglineZh}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Room Selection */}
                <div>
                  <label className="block text-[10px] font-cinzel tracking-wider text-[#A7A7A2] uppercase mb-1">
                    {language === 'en' ? 'SUITE SELECTION' : '房型选择'}
                  </label>
                  <select
                    value={roomId}
                    onChange={(e) => setRoomId(e.target.value)}
                    className="w-full bg-[#0D1720] border border-[#C8A66A]/30 px-3.5 py-2.5 text-xs text-[#F3EFE7] focus:border-[#C8A66A] focus:outline-none"
                  >
                    {currentHotel.rooms.map((r) => (
                      <option key={r.id} value={r.id}>
                        {language === 'en' ? r.name : r.nameZh} (¥{r.pricePerNight.toLocaleString()}/{t.night})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Dates & Guests */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-cinzel tracking-wider text-[#A7A7A2] uppercase mb-1">
                      {t.checkIn}
                    </label>
                    <input
                      type="date"
                      value={checkIn}
                      onChange={(e) => setCheckIn(e.target.value)}
                      required
                      className="w-full bg-[#0D1720] border border-[#C8A66A]/30 px-3 py-2 text-xs text-[#F3EFE7] font-mono focus:border-[#C8A66A] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-cinzel tracking-wider text-[#A7A7A2] uppercase mb-1">
                      {t.checkOut}
                    </label>
                    <input
                      type="date"
                      value={checkOut}
                      onChange={(e) => setCheckOut(e.target.value)}
                      required
                      className="w-full bg-[#0D1720] border border-[#C8A66A]/30 px-3 py-2 text-xs text-[#F3EFE7] font-mono focus:border-[#C8A66A] focus:outline-none"
                    />
                  </div>
                </div>

                {/* Guest Contact Details */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <div>
                    <label className="block text-[10px] font-cinzel tracking-wider text-[#A7A7A2] uppercase mb-1">
                      {language === 'en' ? 'GUEST FULL NAME' : '宾客尊姓大名'}
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Lord Alexander / 王先生"
                      value={guestName}
                      onChange={(e) => setGuestName(e.target.value)}
                      required
                      className="w-full bg-[#0D1720] border border-[#C8A66A]/30 px-3.5 py-2 text-xs text-[#F3EFE7] focus:border-[#C8A66A] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-cinzel tracking-wider text-[#A7A7A2] uppercase mb-1">
                      {language === 'en' ? 'CONTACT NUMBER' : '贵宾联络电话'}
                    </label>
                    <input
                      type="tel"
                      placeholder="+86 / +1 888-000-0000"
                      value={guestPhone}
                      onChange={(e) => setGuestPhone(e.target.value)}
                      required
                      className="w-full bg-[#0D1720] border border-[#C8A66A]/30 px-3.5 py-2 text-xs text-[#F3EFE7] focus:border-[#C8A66A] focus:outline-none"
                    />
                  </div>
                </div>

                {/* Add-on Privileges */}
                <div className="pt-2">
                  <span className="block text-[10px] font-cinzel tracking-wider text-[#E4CC98] uppercase mb-2">
                    {language === 'en' ? 'BESPOKE ENHANCEMENTS' : '定制增值礼遇'}
                  </span>
                  <div className="space-y-2">
                    <label className="flex items-center justify-between p-2.5 bg-[#0D1720] border border-[#C8A66A]/20 cursor-pointer text-xs">
                      <div className="flex items-center space-x-2.5">
                        <input
                          type="checkbox"
                          checked={transferAddon}
                          onChange={(e) => setTransferAddon(e.target.checked)}
                          className="accent-[#C8A66A]"
                        />
                        <span className="text-[#F3EFE7]">
                          {language === 'en' ? 'Private Rolls-Royce / Maybach VIP Airport Transfer' : '劳斯莱斯/迈巴赫机场专车接送'}
                        </span>
                      </div>
                      <span className="font-mono text-[#E4CC98]">+¥1,800</span>
                    </label>

                    <label className="flex items-center justify-between p-2.5 bg-[#0D1720] border border-[#C8A66A]/20 cursor-pointer text-xs">
                      <div className="flex items-center space-x-2.5">
                        <input
                          type="checkbox"
                          checked={teaAddon}
                          onChange={(e) => setTeaAddon(e.target.checked)}
                          className="accent-[#C8A66A]"
                        />
                        <span className="text-[#F3EFE7]">
                          {language === 'en' ? 'In-Suite Imperial Tea Ceremony by Master' : '国家级茶艺大师客房专属奉茶雅集'}
                        </span>
                      </div>
                      <span className="font-mono text-[#E4CC98]">+¥980</span>
                    </label>

                    <label className="flex items-center justify-between p-2.5 bg-[#0D1720] border border-[#C8A66A]/20 cursor-pointer text-xs">
                      <div className="flex items-center space-x-2.5">
                        <input
                          type="checkbox"
                          checked={spaAddon}
                          onChange={(e) => setSpaAddon(e.target.checked)}
                          className="accent-[#C8A66A]"
                        />
                        <span className="text-[#F3EFE7]">
                          {language === 'en' ? '90-min Thermal Stone & Sound Healing Spa' : '90分钟高山温泉矿物热石与颂钵水疗'}
                        </span>
                      </div>
                      <span className="font-mono text-[#E4CC98]">+¥2,600</span>
                    </label>
                  </div>
                </div>

                {/* Submit button */}
                <button
                  type="submit"
                  className="w-full py-3.5 bg-[#C8A66A] hover:bg-[#E4CC98] text-[#071019] text-xs font-semibold tracking-[0.25em] uppercase transition-all duration-300 shadow-xl mt-4"
                >
                  {language === 'en' ? 'CONFIRM LUXURY RESERVATION' : '确认尊贵居停预订'}
                </button>
              </form>
            </div>

            {/* Right: Stay Summary Card */}
            <div className="lg:col-span-5 p-6 sm:p-8 bg-[#0D1720] border-t lg:border-t-0 lg:border-l border-[#C8A66A]/25 flex flex-col justify-between">
              <div>
                <div className="relative h-36 overflow-hidden border border-[#C8A66A]/20 mb-4">
                  <img
                    src={activeRoom.image}
                    alt={activeRoom.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#071019] via-transparent to-transparent" />
                  <div className="absolute bottom-2 left-2 right-2 flex justify-between items-baseline">
                    <span className="font-cinzel text-xs text-[#E4CC98] font-bold">
                      {currentHotel.name}
                    </span>
                    <span className="text-[10px] text-white/80">{activeRoom.size}</span>
                  </div>
                </div>

                <h4 className="font-serif-luxury text-lg text-[#F3EFE7] mb-1">
                  {language === 'en' ? activeRoom.name : activeRoom.nameZh}
                </h4>
                <div className="text-[11px] text-[#A7A7A2] mb-4">
                  {language === 'en' ? activeRoom.view : activeRoom.viewZh}
                </div>

                {/* Price Breakdown */}
                <div className="space-y-2 text-xs py-3 border-y border-white/5">
                  <div className="flex justify-between text-[#A7A7A2]">
                    <span>
                      ¥{activeRoom.pricePerNight.toLocaleString()} × {nights} {t.nights}
                    </span>
                    <span className="font-mono text-[#F3EFE7]">¥{roomTotal.toLocaleString()}</span>
                  </div>

                  {transferAddon && (
                    <div className="flex justify-between text-[#A7A7A2]">
                      <span>VIP Transfer</span>
                      <span className="font-mono text-[#F3EFE7]">¥1,800</span>
                    </div>
                  )}

                  {teaAddon && (
                    <div className="flex justify-between text-[#A7A7A2]">
                      <span>Imperial Tea Ceremony</span>
                      <span className="font-mono text-[#F3EFE7]">¥980</span>
                    </div>
                  )}

                  {spaAddon && (
                    <div className="flex justify-between text-[#A7A7A2]">
                      <span>Thermal Spa Protocol</span>
                      <span className="font-mono text-[#F3EFE7]">¥2,600</span>
                    </div>
                  )}

                  <div className="flex justify-between text-[#A7A7A2]">
                    <span>Taxes & Service Charge</span>
                    <span className="text-[#C8A66A]">Complimentary</span>
                  </div>
                </div>
              </div>

              <div className="pt-4">
                <div className="flex justify-between items-baseline mb-4">
                  <span className="text-xs font-cinzel text-[#A7A7A2] tracking-wider uppercase">
                    ESTIMATED TOTAL
                  </span>
                  <span className="font-mono text-2xl text-[#E4CC98] font-bold">
                    ¥{grandTotal.toLocaleString()} <span className="text-xs font-normal text-[#A7A7A2]">CNY</span>
                  </span>
                </div>

                <div className="p-3 bg-[#071019] border border-[#C8A66A]/20 flex items-center space-x-2 text-[10.5px] text-[#A7A7A2]">
                  <ShieldCheck className="w-4 h-4 text-[#C8A66A] shrink-0" />
                  <span>Free cancellation up to 48 hours prior to arrival.</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
