import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Crown, Check, Shield, Sparkles, ArrowRight } from 'lucide-react';
import { Emblem } from './Emblem';

interface MembershipSectionProps {
  onApplyClick: () => void;
}

export const MembershipSection: React.FC<MembershipSectionProps> = ({ onApplyClick }) => {
  const { language, t } = useLanguage();
  const [selectedTier, setSelectedTier] = useState<'jade' | 'amber' | 'obsidian'>('amber');

  const tiers = [
    {
      id: 'jade' as const,
      name: 'JADE CIRCLE',
      nameZh: '碧玉席',
      subtitle: 'By Direct Invitation / Qualification',
      subtitleZh: '受邀礼遇席',
      color: '#4A6B5D',
      benefits: [
        'Priority suite reservation window (up to 12 months ahead)',
        'Welcome Imperial Longjing tea ceremony in suite',
        'Late check-out guaranteed until 16:00',
        '10% dining & spa privileges across all properties'
      ],
      benefitsZh: [
        '享最高提前12个月优先锁房预订特权',
        '入住享大师级西湖龙井御茶迎宾奉茶礼仪',
        '保证延迟退房至下午16:00',
        '全旗下酒店餐饮与水疗专属9折礼遇'
      ]
    },
    {
      id: 'amber' as const,
      name: 'AMBER RESIDENCE',
      nameZh: '琥珀阁',
      subtitle: 'Premier Benefactor Tier',
      subtitleZh: '核心贵宾席',
      featured: true,
      color: '#C8A66A',
      benefits: [
        'All Jade privileges included',
        'Complimentary private Rolls-Royce airport transfers',
        'Guaranteed one-category suite upgrade upon booking',
        'Dedicated 24-hour private lifestyle curator',
        'Private dining room access at Jade Pavilion (Michelin 2-Star)'
      ],
      benefitsZh: [
        '囊括碧玉席全部会员尊崇特权',
        '每次入住尊享劳斯莱斯/迈巴赫专车往返接送机',
        '预订即享保证升一级套房特权',
        '24小时专属私人旅行生活策展人一对一服务',
        '米其林二星「碧玉轩」私密包厢免最低消费预留'
      ]
    },
    {
      id: 'obsidian' as const,
      name: 'OBSIDIAN COUNCIL',
      nameZh: '墨曜宗',
      subtitle: 'The Sovereign Sanctuary Circle',
      subtitleZh: '至尊终身宗席',
      color: '#A68A56',
      benefits: [
        'All Amber privileges included',
        'Private helicopter charter transfers at Lhasa & Sanya',
        'Annual complimentary 3-night stay at Presidential Residence',
        'Curated after-hours monastery & imperial palace private access',
        'Bespoke culinary menu customized with Group Executive Chef'
      ],
      benefitsZh: [
        '囊括琥珀阁全部尊崇特权',
        '拉萨与三亚度假村尊享私人直升机接驳起降',
        '每年赠送总统府邸3晚无限制私享入住',
        '全国名胜古迹与皇家寺院闭馆包场私享参访',
        '集团行政总厨亲自主理定制家宴菜谱'
      ]
    }
  ];

  return (
    <section id="membership-section" className="relative bg-[#071019] py-20 lg:py-28 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center space-x-2 text-[11px] font-cinzel tracking-[0.35em] text-[#C8A66A] uppercase mb-3">
            <Crown className="w-3.5 h-3.5" />
            <span>{t.membershipTitle}</span>
          </div>
          <h2 className="font-serif-luxury text-3xl sm:text-5xl text-[#F3EFE7] font-normal mb-4">
            {t.membershipHeadline}
          </h2>
          <p className="text-sm sm:text-base text-[#A7A7A2] font-light leading-relaxed">
            {t.membershipSubheading}
          </p>
        </div>

        {/* Membership Tier Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8 mb-12">
          {tiers.map((tier) => (
            <div
              key={tier.id}
              onClick={() => setSelectedTier(tier.id)}
              className={`relative p-6 sm:p-8 border transition-all duration-500 flex flex-col justify-between cursor-pointer ${
                tier.featured
                  ? 'bg-[#0D1720] border-[#C8A66A] shadow-[0_0_40px_rgba(200,166,106,0.15)] ring-1 ring-[#C8A66A]'
                  : 'bg-[#0D1720]/70 border-[#C8A66A]/20 hover:border-[#C8A66A]/60'
              }`}
            >
              {tier.featured && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 bg-[#C8A66A] text-[#071019] text-[9.5px] font-cinzel tracking-[0.25em] font-bold uppercase">
                  RECOMMENDED PATRON
                </div>
              )}

              <div>
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="font-cinzel text-base tracking-[0.2em] text-[#E4CC98] font-bold">
                      {tier.name}
                    </h3>
                    <div className="font-chinese text-sm text-[#F3EFE7] mt-0.5">
                      {tier.nameZh}
                    </div>
                  </div>
                  <Emblem size={28} color={tier.featured ? '#C8A66A' : '#A7A7A2'} />
                </div>

                <div className="text-[11px] text-[#A7A7A2] pb-4 mb-4 border-b border-white/5">
                  {language === 'en' ? tier.subtitle : tier.subtitleZh}
                </div>

                <div className="space-y-3 mb-8">
                  {(language === 'en' ? tier.benefits : tier.benefitsZh).map((benefit, i) => (
                    <div key={i} className="flex items-start space-x-2.5">
                      <Check className="w-3.5 h-3.5 text-[#C8A66A] shrink-0 mt-0.5" />
                      <span className="text-xs text-[#F3EFE7]/80 font-light leading-relaxed">
                        {benefit}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onApplyClick();
                  }}
                  className={`w-full py-3 text-xs font-semibold tracking-[0.22em] uppercase transition-all duration-300 ${
                    tier.featured
                      ? 'bg-[#C8A66A] hover:bg-[#E4CC98] text-[#071019] shadow-md'
                      : 'bg-[#071019] hover:bg-[#C8A66A]/20 text-[#E4CC98] border border-[#C8A66A]/40'
                  }`}
                >
                  {t.applyMembership}
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Direct Concierge Assistance */}
        <div className="p-6 bg-[#0D1720]/80 border border-[#C8A66A]/20 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-4">
            <div className="w-10 h-10 rounded-full bg-[#C8A66A]/15 border border-[#C8A66A]/40 flex items-center justify-center text-[#C8A66A]">
              <Shield className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-cinzel tracking-wider text-[#E4CC98] uppercase">
                {language === 'en' ? 'PRIVATE CLIENT CONCIERGE' : '私享礼宾尊属热线'}
              </div>
              <div className="text-xs text-[#A7A7A2] font-light">
                {language === 'en'
                  ? 'For bespoke corporate charters or discreet sovereign memberships.'
                  : '为家族办公室、企业私董会及名流提供全私密定制会籍咨询。'}
              </div>
            </div>
          </div>
          <button
            onClick={onApplyClick}
            className="shrink-0 px-5 py-2.5 border border-[#C8A66A] text-xs text-[#E4CC98] hover:bg-[#C8A66A] hover:text-[#071019] font-cinzel tracking-widest uppercase transition-colors"
          >
            {language === 'en' ? 'SPEAK WITH A CURATOR' : '联系会籍策展人'}
          </button>
        </div>
      </div>
    </section>
  );
};
