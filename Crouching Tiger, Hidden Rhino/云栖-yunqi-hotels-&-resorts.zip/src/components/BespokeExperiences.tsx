import React, { useState, useRef } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { EXPERIENCES_DATA } from '../data/experiences';
import { ExperienceItem } from '../types';
import { Compass, ChevronLeft, ChevronRight, CheckCircle2, Calendar } from 'lucide-react';

interface BespokeExperiencesProps {
  onInquireExperience: (exp: ExperienceItem) => void;
}

export const BespokeExperiences: React.FC<BespokeExperiencesProps> = ({ onInquireExperience }) => {
  const { language, t } = useLanguage();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const categories = [
    { id: 'all', label: 'ALL EXPERIENCES', labelZh: '全部旅程' },
    { id: 'journeys', label: 'PRIVATE JOURNEYS', labelZh: '专属定制' },
    { id: 'culinary', label: 'CULINARY DISCOVERY', labelZh: '美馔溯源' },
    { id: 'art', label: 'ART & CULTURE', labelZh: '艺术人文' },
    { id: 'mountains', label: 'MOUNTAIN RETREATS', labelZh: '高山隐世' },
    { id: 'wellness', label: 'WELLNESS', labelZh: '身心修持' },
    { id: 'aviation', label: 'PRIVATE AVIATION', labelZh: '海空巡礼' },
  ];

  const filtered = selectedCategory === 'all'
    ? EXPERIENCES_DATA
    : EXPERIENCES_DATA.filter((item) => item.category === selectedCategory);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollContainerRef.current) {
      const scrollAmount = direction === 'left' ? -380 : 380;
      scrollContainerRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  return (
    <section id="experiences-section" className="relative bg-[#0D1720] py-20 lg:py-28 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between pb-6 border-b border-[#C8A66A]/20">
          <div>
            <div className="inline-flex items-center space-x-2 text-[11px] font-cinzel tracking-[0.3em] text-[#C8A66A] uppercase mb-1.5">
              <Compass className="w-3.5 h-3.5" />
              <span>{t.bespokeTitle}</span>
            </div>
            <h2 className="font-serif-luxury text-3xl sm:text-5xl text-[#F3EFE7] font-normal">
              {t.bespokeHeadline}
            </h2>
          </div>

          {/* Navigation Arrows */}
          <div className="flex items-center space-x-3 mt-4 md:mt-0">
            <button
              onClick={() => scroll('left')}
              className="w-10 h-10 rounded-full border border-[#C8A66A]/30 hover:border-[#C8A66A] flex items-center justify-center text-[#E4CC98] hover:bg-[#C8A66A]/10 transition-colors"
              aria-label="Scroll left"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => scroll('right')}
              className="w-10 h-10 rounded-full border border-[#C8A66A]/30 hover:border-[#C8A66A] flex items-center justify-center text-[#E4CC98] hover:bg-[#C8A66A]/10 transition-colors"
              aria-label="Scroll right"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="flex items-center space-x-2 overflow-x-auto pb-4 pt-2">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3.5 py-1.5 text-[11px] font-cinzel tracking-[0.18em] uppercase transition-all duration-300 shrink-0 border ${
                selectedCategory === cat.id
                  ? 'bg-[#C8A66A] text-[#071019] border-[#C8A66A] font-semibold'
                  : 'bg-[#071019]/70 text-[#A7A7A2] hover:text-[#F3EFE7] border-[#C8A66A]/15'
              }`}
            >
              {language === 'en' ? cat.label : cat.labelZh}
            </button>
          ))}
        </div>
      </div>

      {/* Horizontal Scrolling Gallery */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div
          ref={scrollContainerRef}
          className="flex space-x-6 overflow-x-auto pb-6 scrollbar-none snap-x snap-mandatory"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {filtered.map((item) => (
            <div
              key={item.id}
              className="w-[320px] sm:w-[380px] shrink-0 snap-start bg-[#071019] border border-[#C8A66A]/20 hover:border-[#C8A66A] transition-all duration-500 flex flex-col justify-between overflow-hidden group shadow-xl"
            >
              {/* Image Banner */}
              <div className="relative h-56 overflow-hidden">
                <img
                  src={item.image}
                  alt={item.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-out"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#071019] via-transparent to-black/30" />
                <span className="absolute top-3 left-3 text-[10px] font-cinzel tracking-[0.2em] uppercase px-2.5 py-1 bg-[#071019]/80 backdrop-blur-sm border border-[#C8A66A]/30 text-[#E4CC98]">
                  {language === 'en' ? item.categoryLabel : item.categoryLabelZh}
                </span>
                <span className="absolute bottom-3 right-3 text-[10px] font-mono text-[#F3EFE7]/90 px-2 py-0.5 bg-[#071019]/80 border border-white/10">
                  {language === 'en' ? item.duration : item.durationZh}
                </span>
              </div>

              {/* Content Body */}
              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="font-serif-luxury text-xl text-[#F3EFE7] group-hover:text-[#E4CC98] transition-colors leading-snug mb-2">
                    {language === 'en' ? item.title : item.titleZh}
                  </h3>
                  <p className="text-xs text-[#A7A7A2] font-light leading-relaxed mb-4 line-clamp-3">
                    {language === 'en' ? item.description : item.descriptionZh}
                  </p>

                  {/* Highlights Bullet List */}
                  <div className="space-y-1.5 pt-3 border-t border-white/5 mb-5">
                    {(language === 'en' ? item.highlights : item.highlightsZh).map((h, i) => (
                      <div key={i} className="flex items-center space-x-2 text-[11px] text-[#A7A7A2]">
                        <CheckCircle2 className="w-3 h-3 text-[#C8A66A] shrink-0" />
                        <span className="truncate">{h}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <button
                  onClick={() => onInquireExperience(item)}
                  className="w-full py-2.5 bg-[#0D1720] hover:bg-[#C8A66A] text-[#E4CC98] hover:text-[#071019] border border-[#C8A66A]/40 text-xs font-semibold tracking-[0.2em] uppercase transition-colors"
                >
                  {language === 'en' ? 'CURATE ITINERARY' : '定制专属行程'}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
