import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { HOTELS_DATA } from '../data/hotels';
import { Hotel } from '../types';
import { Eye, Layers, Compass, Maximize2 } from 'lucide-react';

interface ArchitectureSectionProps {
  onSelectHotel: (hotel: Hotel) => void;
}

export const ArchitectureSection: React.FC<ArchitectureSectionProps> = ({ onSelectHotel }) => {
  const { language, t } = useLanguage();
  const [activeHotelIndex, setActiveHotelIndex] = useState(0);

  const activeHotel = HOTELS_DATA[activeHotelIndex];

  return (
    <section id="architecture-section" className="relative bg-[#071019] py-20 lg:py-28 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between pb-6 border-b border-[#C8A66A]/20">
          <div>
            <div className="flex items-center space-x-2 text-[11px] font-cinzel tracking-[0.3em] text-[#C8A66A] uppercase mb-1.5">
              <Compass className="w-3.5 h-3.5" />
              <span>SPATIAL MASTERPIECES</span>
            </div>
            <h2 className="font-serif-luxury text-3xl sm:text-5xl text-[#F3EFE7] font-normal">
              {t.archTitle}
            </h2>
          </div>

          {/* Interactive Property Selector Pills */}
          <div className="flex items-center space-x-2 mt-4 md:mt-0 overflow-x-auto pb-2 md:pb-0">
            {HOTELS_DATA.map((h, idx) => (
              <button
                key={h.id}
                onClick={() => setActiveHotelIndex(idx)}
                className={`px-3.5 py-1.5 text-[11px] font-cinzel tracking-[0.2em] uppercase transition-all duration-300 border ${
                  activeHotelIndex === idx
                    ? 'bg-[#C8A66A] text-[#071019] border-[#C8A66A] font-semibold shadow-md'
                    : 'bg-[#0D1720]/80 text-[#A7A7A2] hover:text-[#F3EFE7] border-[#C8A66A]/20 hover:border-[#C8A66A]/50'
                }`}
              >
                {language === 'en' ? h.name : h.nameZh}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Full-Width Architectural Showcase */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative border border-[#C8A66A]/30 overflow-hidden bg-[#0D1720] shadow-2xl">
          {/* Architectural Hero Image */}
          <div className="relative h-[480px] sm:h-[620px] w-full overflow-hidden">
            <img
              src={activeHotel.heroImage}
              alt={activeHotel.name}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center transition-all duration-1000 transform scale-100 hover:scale-105"
            />
            {/* Architectural Vignette */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#071019] via-[#071019]/40 to-black/30" />
            
            {/* Editorial Architectural Overlay */}
            <div className="absolute top-8 left-8 sm:top-12 sm:left-12 max-w-xl">
              <span className="inline-block font-cinzel text-[10.5px] tracking-[0.35em] text-[#E4CC98] uppercase px-2.5 py-1 bg-[#071019]/80 border border-[#C8A66A]/30 mb-3">
                {t.archOverlay}
              </span>
              <h3 className="font-serif-luxury text-3xl sm:text-5xl text-[#F3EFE7] font-light leading-tight drop-shadow-lg">
                {language === 'en' ? activeHotel.tagline : activeHotel.taglineZh}
              </h3>
              <p className="font-chinese text-sm sm:text-base text-[#E4CC98]/90 tracking-wide mt-2">
                {language === 'en' ? activeHotel.nameZh + ' · 云栖当代建筑巡礼' : activeHotel.tagline}
              </p>
            </div>

            {/* View Detail Quick CTA */}
            <button
              onClick={() => onSelectHotel(activeHotel)}
              className="absolute top-8 right-8 hidden sm:inline-flex items-center space-x-2 px-4 py-2 bg-[#071019]/85 hover:bg-[#C8A66A] hover:text-[#071019] border border-[#C8A66A]/40 text-[#E4CC98] text-xs font-cinzel tracking-[0.2em] uppercase transition-all duration-300"
            >
              <Maximize2 className="w-3.5 h-3.5" />
              <span>{language === 'en' ? 'Architectural Portfolio' : '查看完整建筑档案'}</span>
            </button>
          </div>

          {/* Technical Metadata Bar (Magazine Style) */}
          <div className="grid grid-cols-2 sm:grid-cols-5 border-t border-[#C8A66A]/25 bg-[#0D1720]/95 backdrop-blur-md divide-y sm:divide-y-0 sm:divide-x divide-[#C8A66A]/15">
            {/* Location */}
            <div className="p-4 sm:p-5">
              <span className="block text-[9.5px] font-cinzel tracking-[0.25em] text-[#C8A66A] uppercase font-semibold mb-1">
                {t.locationMeta}
              </span>
              <span className="block text-xs text-[#F3EFE7] font-medium leading-snug">
                {language === 'en' ? activeHotel.location : activeHotel.locationZh}
              </span>
            </div>

            {/* Architect */}
            <div className="p-4 sm:p-5">
              <span className="block text-[9.5px] font-cinzel tracking-[0.25em] text-[#C8A66A] uppercase font-semibold mb-1">
                {t.architectMeta}
              </span>
              <span className="block text-xs text-[#F3EFE7] font-medium leading-snug">
                {activeHotel.architect}
              </span>
            </div>

            {/* Year */}
            <div className="p-4 sm:p-5">
              <span className="block text-[9.5px] font-cinzel tracking-[0.25em] text-[#C8A66A] uppercase font-semibold mb-1">
                {t.yearMeta}
              </span>
              <span className="block text-xs text-[#F3EFE7] font-mono">
                {activeHotel.yearBuilt}
              </span>
            </div>

            {/* Rooms */}
            <div className="p-4 sm:p-5">
              <span className="block text-[9.5px] font-cinzel tracking-[0.25em] text-[#C8A66A] uppercase font-semibold mb-1">
                {t.roomsMeta}
              </span>
              <span className="block text-xs text-[#F3EFE7] font-mono">
                {activeHotel.totalRooms} Key Sanctuaries
              </span>
            </div>

            {/* Elevation */}
            <div className="p-4 sm:p-5 col-span-2 sm:col-span-1">
              <span className="block text-[9.5px] font-cinzel tracking-[0.25em] text-[#C8A66A] uppercase font-semibold mb-1">
                {t.elevationMeta}
              </span>
              <span className="block text-xs text-[#F3EFE7] font-mono">
                {activeHotel.elevation}
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
