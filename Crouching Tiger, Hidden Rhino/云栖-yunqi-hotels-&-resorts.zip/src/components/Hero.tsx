import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { ChineseSeal } from './Emblem';
import { heroImg } from '../data/hotels';
import { ArrowRight, ChevronDown, Volume2, VolumeX } from 'lucide-react';

interface HeroProps {
  onExploreClick: () => void;
  onBookClick?: () => void;
  onScrollDiscover?: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onExploreClick, onBookClick, onScrollDiscover }) => {
  const { language, t } = useLanguage();
  const [isAudioPlaying, setIsAudioPlaying] = useState(false);

  // Subtle web audio ambient chime generator for five-star zen atmosphere
  const toggleAmbientSound = () => {
    if (!isAudioPlaying) {
      try {
        const AudioContext = window.AudioContext || (window as unknown as { webkitAudioContext: typeof window.AudioContext }).webkitAudioContext;
        const ctx = new AudioContext();
        
        // Gentle pentatonic harp / guqin frequencies (G, A, C, D, E)
        const notes = [196.0, 220.0, 261.63, 293.66, 329.63, 392.0, 523.25];
        
        const playTone = () => {
          if (ctx.state === 'suspended') {
            ctx.resume();
          }
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          const note = notes[Math.floor(Math.random() * notes.length)];
          
          osc.type = 'sine';
          osc.frequency.setValueAtTime(note, ctx.currentTime);
          
          gain.gain.setValueAtTime(0.001, ctx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.04, ctx.currentTime + 1.2);
          gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 5.5);
          
          osc.connect(gain);
          gain.connect(ctx.destination);
          
          osc.start();
          osc.stop(ctx.currentTime + 6.0);
        };

        playTone();
        const interval = window.setInterval(playTone, 4500);
        (window as unknown as { __yunqiAudioInterval: number }).__yunqiAudioInterval = interval;
        setIsAudioPlaying(true);
      } catch {
        setIsAudioPlaying(true);
      }
    } else {
      const interval = (window as unknown as { __yunqiAudioInterval?: number }).__yunqiAudioInterval;
      if (interval) {
        clearInterval(interval);
      }
      setIsAudioPlaying(false);
    }
  };

  return (
    <section
      id="hero-section"
      className="relative min-h-screen w-full flex flex-col justify-between overflow-hidden bg-[#071019]"
    >
      {/* Background Cinematic Image with Subtle Slow Zoom/Parallax */}
      <div className="absolute inset-0 z-0 overflow-hidden select-none">
        <img
          src={heroImg}
          alt="Yunqi Luxury Chinese Mountain Resort overlooking Lake at Sunset"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center scale-105 animate-[pulse_14s_ease-in-out_infinite] transition-transform duration-[12000ms] hover:scale-110 opacity-90"
        />
        {/* Layered Cinematic Vignette & Gradient Overlays */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#071019]/90 via-[#071019]/45 to-transparent pointer-events-none" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#071019] via-[#071019]/20 to-[#071019]/70 pointer-events-none" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(200,166,106,0.12)_0%,transparent_65%)] pointer-events-none" />
      </div>

      {/* Right Vertical Traditional Chinese Brand Calligraphy Stamp (as in reference image) */}
      <aside
        className="hidden md:flex absolute right-8 lg:right-14 top-36 z-20 flex-col items-center space-y-3 pointer-events-none select-none"
        aria-hidden="true"
      >
        <div className="writing-vertical text-xl lg:text-2xl font-chinese font-light tracking-[0.45em] text-[#F3EFE7]/90 drop-shadow-md">
          云栖
        </div>
        <div className="writing-vertical text-[10px] tracking-[0.4em] text-[#C8A66A]/80 font-serif-luxury">
          酒店及度假村
        </div>
        <ChineseSeal text="栖" className="mt-1.5" />
      </aside>

      {/* Ambient Soundscape Controller */}
      <div className="absolute top-24 right-6 sm:right-12 z-20">
        <button
          id="ambient-sound-toggle-btn"
          onClick={toggleAmbientSound}
          className="group flex items-center space-x-2 px-3 py-1.5 rounded-full bg-[#071019]/60 hover:bg-[#071019]/90 border border-[#C8A66A]/25 backdrop-blur-md text-xs text-[#E4CC98] transition-all duration-300 focus:outline-none"
          title="Toggle tranquil sanctuary soundscape"
          aria-label="Toggle tranquil sanctuary soundscape"
        >
          {isAudioPlaying ? (
            <>
              <Volume2 className="w-3.5 h-3.5 text-[#C8A66A] animate-pulse" />
              <span className="text-[10px] tracking-wider uppercase hidden sm:inline text-[#C8A66A]">
                {language === 'en' ? 'Sanctuary Audio: On' : '静心音景：开启'}
              </span>
            </>
          ) : (
            <>
              <VolumeX className="w-3.5 h-3.5 text-[#A7A7A2]" />
              <span className="text-[10px] tracking-wider uppercase hidden sm:inline text-[#A7A7A2] group-hover:text-[#F3EFE7]">
                {language === 'en' ? 'Soundscape' : '静心音景'}
              </span>
            </>
          )}
        </button>
      </div>

      {/* Main Hero Headline and Copy Overlay */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full pt-32 sm:pt-40 lg:pt-44 pb-12 sm:pb-20">
        <div className="max-w-3xl">
          {/* Eyebrow */}
          <div className="inline-flex items-center space-x-2.5 mb-4">
            <span className="w-6 h-[1px] bg-[#C8A66A]/80" />
            <span className="font-cinzel text-xs tracking-[0.35em] text-[#E4CC98] uppercase font-semibold">
              {t.heroEyebrow}
            </span>
          </div>

          {/* Primary Headline */}
          <h1 className="font-serif-luxury text-4xl sm:text-6xl lg:text-7xl font-normal leading-[1.08] tracking-tight text-[#F3EFE7] mb-4">
            {language === 'en' ? (
              <>
                <span className="block text-white">A JOURNEY INTO</span>
                <span className="block text-gold-gradient font-light">TIMELESS CHINA</span>
              </>
            ) : (
              <>
                <span className="block text-white">不止于下榻</span>
                <span className="block text-gold-gradient font-light">邂逅永恒的中国</span>
              </>
            )}
          </h1>

          {/* Chinese Supporting Banner */}
          <div className="font-chinese text-base sm:text-xl text-[#E4CC98]/90 tracking-[0.2em] font-light mb-6">
            {language === 'en' ? '不止于下榻 · 邂逅永恒的中国' : 'A JOURNEY INTO TIMELESS CHINA'}
          </div>

          {/* Supporting Copy */}
          <p className="text-sm sm:text-base lg:text-lg text-[#F3EFE7]/80 font-light leading-relaxed max-w-xl mb-8 tracking-wide">
            {t.heroCopy}
          </p>

          {/* Primary CTA Button */}
          <div className="flex flex-wrap items-center gap-4">
            <button
              id="hero-explore-btn"
              onClick={onExploreClick}
              className="group inline-flex items-center space-x-3 px-6 py-3.5 bg-transparent hover:bg-[#C8A66A]/10 border border-[#C8A66A] text-[#E4CC98] hover:text-[#F3EFE7] text-xs font-semibold tracking-[0.25em] uppercase transition-all duration-300 focus:outline-none"
            >
              <span className="w-5 h-5 rounded-full border border-[#C8A66A]/60 flex items-center justify-center group-hover:border-[#E4CC98] transition-colors">
                <ArrowRight className="w-3 h-3 text-[#C8A66A] group-hover:translate-x-0.5 transition-transform" />
              </span>
              <span>{t.exploreHotelsCTA}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Scroll Down Indicator */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full pb-8 flex items-center justify-between">
        <button
          id="hero-scroll-discover-btn"
          onClick={onScrollDiscover}
          className="group flex items-center space-x-3 text-left focus:outline-none"
          aria-label="Scroll down to discover our properties"
        >
          <div className="w-6 h-6 rounded-full border border-white/20 flex items-center justify-center group-hover:border-[#C8A66A] transition-colors">
            <ChevronDown className="w-3.5 h-3.5 text-[#C8A66A] group-hover:translate-y-0.5 transition-transform" />
          </div>
          <span className="font-cinzel text-[10.5px] tracking-[0.25em] text-[#A7A7A2] group-hover:text-[#F3EFE7] uppercase transition-colors">
            {t.scrollToDiscover}
          </span>
        </button>

        {/* Quiet Luxury Coordinates Indicator */}
        <div className="hidden sm:flex items-center space-x-4 text-[10px] tracking-[0.2em] text-[#A7A7A2]/60 font-mono">
          <span>LAT 31°14′N</span>
          <span>•</span>
          <span>LON 121°28′E</span>
          <span>•</span>
          <span>EST. 2024</span>
        </div>
      </div>
    </section>
  );
};
