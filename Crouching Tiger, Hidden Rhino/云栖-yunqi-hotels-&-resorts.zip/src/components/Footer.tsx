import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Emblem, ChineseSeal } from './Emblem';
import { Globe, Phone, Mail, MapPin, ArrowRight, CheckCircle2, QrCode, X } from 'lucide-react';

interface FooterProps {
  onNavigate: (sectionId: string) => void;
  onOpenBooking: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate, onOpenBooking }) => {
  const { language, toggleLanguage, t } = useLanguage();
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const [qrModalOpen, setQrModalOpen] = useState(false);

  const handleNewsletter = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setEmail('');
    }
  };

  return (
    <footer id="footer-section" className="bg-[#071019] border-t border-[#C8A66A]/25 pt-16 pb-12 relative text-[#A7A7A2]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Newsletter & Brand Gazette Strip */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 pb-14 border-b border-[#C8A66A]/15 items-center">
          <div className="lg:col-span-6 flex items-start space-x-4">
            <Emblem size={48} className="shrink-0 text-[#C8A66A] mt-1" />
            <div>
              <div className="flex items-baseline space-x-2">
                <span className="font-chinese text-2xl text-[#F3EFE7] tracking-[0.2em]">云栖</span>
                <span className="font-cinzel text-xs text-[#C8A66A] tracking-[0.25em] font-semibold">
                  YUNQI HOTELS & RESORTS
                </span>
              </div>
              <p className="font-chinese text-xs text-[#E4CC98] mt-1 font-light">
                {language === 'en' ? 'A Journey Into Timeless China · 不止于下榻 邂逅永恒的中国' : '不止于下榻 · 邂逅永恒的中国'}
              </p>
              <p className="text-xs text-[#A7A7A2] mt-2 font-light max-w-md">
                {t.newsletterSub}
              </p>
            </div>
          </div>

          <div className="lg:col-span-6">
            {subscribed ? (
              <div className="p-3 bg-[#0D1720] border border-[#C8A66A]/40 flex items-center space-x-3 text-xs text-[#E4CC98]">
                <CheckCircle2 className="w-4 h-4 text-[#C8A66A]" />
                <span>{language === 'en' ? 'Thank you for subscribing to The Yunqi Gazette.' : '感谢订阅云栖雅集季刊，季度私函将如期送达。'}</span>
              </div>
            ) : (
              <form onSubmit={handleNewsletter} className="flex flex-col sm:flex-row gap-2">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder={language === 'en' ? 'Enter your email for private releases...' : '输入贵宾邮箱，订阅云栖雅集...'}
                  className="flex-1 bg-[#0D1720] border border-[#C8A66A]/30 px-4 py-2.5 text-xs text-[#F3EFE7] placeholder-[#A7A7A2]/50 focus:border-[#C8A66A] focus:outline-none"
                />
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-[#C8A66A] hover:bg-[#E4CC98] text-[#071019] text-xs font-semibold tracking-[0.2em] uppercase transition-colors shrink-0"
                >
                  {t.subscribe}
                </button>
              </form>
            )}
          </div>
        </div>

        {/* Multi-Column Luxury Navigation Links */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-8 py-12 border-b border-[#C8A66A]/15 text-xs">
          {/* Column 1: HOTELS */}
          <div>
            <h4 className="font-cinzel text-xs font-semibold tracking-[0.2em] text-[#E4CC98] uppercase mb-4">
              {language === 'en' ? 'SANCTUARIES' : '旗下酒店'}
            </h4>
            <ul className="space-y-2.5 font-light">
              <li>
                <button onClick={() => onNavigate('hotels')} className="hover:text-[#F3EFE7] transition-colors text-left">
                  Shanghai (上海)
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('hotels')} className="hover:text-[#F3EFE7] transition-colors text-left">
                  Hangzhou (杭州)
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('hotels')} className="hover:text-[#F3EFE7] transition-colors text-left">
                  Lhasa (拉萨)
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('hotels')} className="hover:text-[#F3EFE7] transition-colors text-left">
                  Sanya (三亚)
                </button>
              </li>
              <li className="text-[#C8A66A]/60 text-[11px] pt-1">
                Coming 2027: Dunhuang, Kyoto
              </li>
            </ul>
          </div>

          {/* Column 2: EXPERIENCES */}
          <div>
            <h4 className="font-cinzel text-xs font-semibold tracking-[0.2em] text-[#E4CC98] uppercase mb-4">
              {t.navExperiences}
            </h4>
            <ul className="space-y-2.5 font-light">
              <li>
                <button onClick={() => onNavigate('experiences')} className="hover:text-[#F3EFE7] transition-colors text-left">
                  Private Journeys
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('experiences')} className="hover:text-[#F3EFE7] transition-colors text-left">
                  Culinary Discovery
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('experiences')} className="hover:text-[#F3EFE7] transition-colors text-left">
                  Art & Culture
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('experiences')} className="hover:text-[#F3EFE7] transition-colors text-left">
                  Mountain Retreats
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('experiences')} className="hover:text-[#F3EFE7] transition-colors text-left">
                  Private Aviation
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: DINING */}
          <div>
            <h4 className="font-cinzel text-xs font-semibold tracking-[0.2em] text-[#E4CC98] uppercase mb-4">
              {t.navDining}
            </h4>
            <ul className="space-y-2.5 font-light">
              <li>
                <button onClick={() => onNavigate('dining')} className="hover:text-[#F3EFE7] transition-colors text-left">
                  Jade Pavilion (米其林二星)
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('dining')} className="hover:text-[#F3EFE7] transition-colors text-left">
                  Bamboo Shadow (宋代雅宴)
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('dining')} className="hover:text-[#F3EFE7] transition-colors text-left">
                  Celestial Peak Cellar
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('dining')} className="hover:text-[#F3EFE7] transition-colors text-left">
                  Azure Waves Seafood
                </button>
              </li>
            </ul>
          </div>

          {/* Column 4: WELLNESS */}
          <div>
            <h4 className="font-cinzel text-xs font-semibold tracking-[0.2em] text-[#E4CC98] uppercase mb-4">
              {t.navWellness}
            </h4>
            <ul className="space-y-2.5 font-light">
              <li>
                <button onClick={() => onNavigate('wellness')} className="hover:text-[#F3EFE7] transition-colors text-left">
                  TCM Herbal Hydrotherapy
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('wellness')} className="hover:text-[#F3EFE7] transition-colors text-left">
                  Guqin & Singing Bowl Baths
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('wellness')} className="hover:text-[#F3EFE7] transition-colors text-left">
                  High-Altitude Cellular Spa
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('wellness')} className="hover:text-[#F3EFE7] transition-colors text-left">
                  Thermal Hot Springs
                </button>
              </li>
            </ul>
          </div>

          {/* Column 5: ABOUT */}
          <div>
            <h4 className="font-cinzel text-xs font-semibold tracking-[0.2em] text-[#E4CC98] uppercase mb-4">
              {t.navAbout}
            </h4>
            <ul className="space-y-2.5 font-light">
              <li>
                <button onClick={() => onNavigate('about')} className="hover:text-[#F3EFE7] transition-colors text-left">
                  Our Heritage
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('architecture')} className="hover:text-[#F3EFE7] transition-colors text-left">
                  Architecture of Place
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('about')} className="hover:text-[#F3EFE7] transition-colors text-left">
                  Architectural Monographs
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('about')} className="hover:text-[#F3EFE7] transition-colors text-left">
                  Sustainability Rites
                </button>
              </li>
            </ul>
          </div>

          {/* Column 6: CONCIERGE & CONTACT */}
          <div>
            <h4 className="font-cinzel text-xs font-semibold tracking-[0.2em] text-[#E4CC98] uppercase mb-4">
              {t.contact}
            </h4>
            <ul className="space-y-2.5 font-light">
              <li className="flex items-center space-x-2">
                <Phone className="w-3.5 h-3.5 text-[#C8A66A] shrink-0" />
                <span className="font-mono text-[11px]">+86 (21) 8088 8888</span>
              </li>
              <li className="flex items-center space-x-2">
                <Mail className="w-3.5 h-3.5 text-[#C8A66A] shrink-0" />
                <span className="text-[11px]">concierge@yunqi-hotels.com</span>
              </li>
              <li className="pt-2">
                <button
                  onClick={() => setQrModalOpen(true)}
                  className="inline-flex items-center space-x-1.5 text-[10.5px] px-2.5 py-1 bg-[#0D1720] border border-[#C8A66A]/30 text-[#E4CC98] hover:bg-[#C8A66A]/20 transition-colors"
                >
                  <QrCode className="w-3.5 h-3.5" />
                  <span>WeChat Mini Program</span>
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar: Copyright, Language, Legal */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-[#A7A7A2]/70">
          <div className="flex items-center space-x-4">
            <span className="font-mono">{t.footerCopy}</span>
            <span className="hidden sm:inline">•</span>
            <span className="hidden sm:inline font-chinese">{t.footerLegal}</span>
          </div>

          <div className="flex items-center space-x-6">
            <button
              onClick={toggleLanguage}
              className="flex items-center space-x-1.5 text-[#E4CC98] hover:text-white transition-colors"
            >
              <Globe className="w-3.5 h-3.5 text-[#C8A66A]" />
              <span>{language === 'en' ? '中文 (简体)' : 'English'}</span>
            </button>
            <a href="#privacy" onClick={(e) => e.preventDefault()} className="hover:text-white transition-colors">
              {t.privacy}
            </a>
            <a href="#terms" onClick={(e) => e.preventDefault()} className="hover:text-white transition-colors">
              {t.terms}
            </a>
            <a href="#accessibility" onClick={(e) => e.preventDefault()} className="hover:text-white transition-colors">
              {t.accessibility}
            </a>
          </div>
        </div>
      </div>

      {/* WeChat QR Code Modal */}
      {qrModalOpen && (
        <div
          className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-4 animate-fade-in"
          onClick={() => setQrModalOpen(false)}
        >
          <div
            className="bg-[#0D1720] border border-[#C8A66A]/40 p-6 max-w-xs w-full text-center relative shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setQrModalOpen(false)}
              className="absolute top-3 right-3 text-[#A7A7A2] hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
            <Emblem size={32} className="mx-auto mb-2 text-[#C8A66A]" />
            <div className="font-chinese text-base text-[#F3EFE7] mb-1">云栖微服务平台</div>
            <div className="text-[10px] text-[#A7A7A2] mb-4">Scan via WeChat for In-Stay Butler Services</div>
            <div className="w-44 h-44 mx-auto bg-white p-2 border border-[#C8A66A]/50 flex items-center justify-center">
              {/* Stylized QR placeholder */}
              <div className="w-full h-full bg-[#071019] flex flex-col items-center justify-center text-[#C8A66A] p-2 text-center">
                <QrCode className="w-16 h-16 text-[#E4CC98] mb-1" />
                <span className="font-mono text-[9px]">YUNQI-VIP-2026</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </footer>
  );
};
