import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Emblem, ChineseSeal } from './Emblem';
import { X, CheckCircle2, ShieldCheck, Mail, Phone, User, Send } from 'lucide-react';

interface InquiryModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  subtitle?: string;
}

export const InquiryModal: React.FC<InquiryModalProps> = ({
  isOpen,
  onClose,
  title = 'YUNQI PRIVILEGES INVITATION',
  subtitle = 'A private world beyond the stay'
}) => {
  const { language } = useLanguage();
  const [submitted, setSubmitted] = useState(false);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [tier, setTier] = useState('Amber Residence (琥珀阁)');
  const [message, setMessage] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-black/90 backdrop-blur-xl flex justify-center items-center p-4 animate-fade-in"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-lg bg-[#0D1720] border border-[#C8A66A]/40 shadow-[0_0_80px_rgba(0,0,0,0.9)] p-6 sm:p-8 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-30 w-8 h-8 rounded-full bg-[#071019] border border-[#C8A66A]/30 text-[#E4CC98] hover:text-white flex items-center justify-center transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {submitted ? (
          <div className="text-center py-8">
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-[#C8A66A]/20 border border-[#C8A66A] text-[#E4CC98] mb-4">
              <CheckCircle2 className="w-7 h-7 text-[#C8A66A]" />
            </div>
            <h3 className="font-serif-luxury text-2xl text-[#F3EFE7] mb-2">
              {language === 'en' ? 'Invitation Request Submitted' : '尊荣邀请函申请已呈递'}
            </h3>
            <p className="text-xs text-[#A7A7A2] max-w-sm mx-auto mb-6 leading-relaxed">
              {language === 'en'
                ? 'Your private membership concierge will review your inquiry discretely and extend an invitation within 24 hours.'
                : '云栖私享会籍理事会将在24小时内严格审核您的申请，并由专属管家致电奉上定制礼遇函。'}
            </p>
            <button
              onClick={onClose}
              className="px-6 py-2.5 bg-[#C8A66A] hover:bg-[#E4CC98] text-[#071019] text-xs font-semibold tracking-widest uppercase transition-colors"
            >
              Close
            </button>
          </div>
        ) : (
          <div>
            <div className="flex items-center space-x-3 mb-3">
              <Emblem size={28} />
              <div>
                <span className="font-chinese text-sm text-[#F3EFE7]">云栖</span>
                <span className="font-cinzel text-[8.5px] text-[#C8A66A] block">YUNQI HOTELS & RESORTS</span>
              </div>
            </div>

            <h3 className="font-serif-luxury text-2xl text-[#F3EFE7] mb-1">
              {title}
            </h3>
            <p className="text-xs text-[#A7A7A2] mb-6">
              {subtitle}
            </p>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-[10px] font-cinzel tracking-wider text-[#A7A7A2] uppercase mb-1">
                  Full Name / 贵宾尊姓
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Lord Alexander / 李先生"
                  className="w-full bg-[#071019] border border-[#C8A66A]/30 px-3.5 py-2.5 text-xs text-[#F3EFE7] focus:border-[#C8A66A] focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-cinzel tracking-wider text-[#A7A7A2] uppercase mb-1">
                    Phone / 联络电话
                  </label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+86 / +1 888..."
                    className="w-full bg-[#071019] border border-[#C8A66A]/30 px-3.5 py-2.5 text-xs text-[#F3EFE7] focus:border-[#C8A66A] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-cinzel tracking-wider text-[#A7A7A2] uppercase mb-1">
                    Email / 电子邮箱
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="patron@estate.com"
                    className="w-full bg-[#071019] border border-[#C8A66A]/30 px-3.5 py-2.5 text-xs text-[#F3EFE7] focus:border-[#C8A66A] focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-cinzel tracking-wider text-[#A7A7A2] uppercase mb-1">
                  Membership Tier of Interest / 意向席位
                </label>
                <select
                  value={tier}
                  onChange={(e) => setTier(e.target.value)}
                  className="w-full bg-[#071019] border border-[#C8A66A]/30 px-3.5 py-2.5 text-xs text-[#F3EFE7] focus:border-[#C8A66A] focus:outline-none"
                >
                  <option value="Jade Circle (碧玉席)">Jade Circle (碧玉席)</option>
                  <option value="Amber Residence (琥珀阁)">Amber Residence (琥珀阁)</option>
                  <option value="Obsidian Council (墨曜宗)">Obsidian Council (墨曜宗)</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-cinzel tracking-wider text-[#A7A7A2] uppercase mb-1">
                  Special Notes & Travel Preferences / 旅居偏好
                </label>
                <textarea
                  rows={2}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Tell us about your bespoke travel requirements..."
                  className="w-full bg-[#071019] border border-[#C8A66A]/30 px-3.5 py-2 text-xs text-[#F3EFE7] focus:border-[#C8A66A] focus:outline-none resize-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-[#C8A66A] hover:bg-[#E4CC98] text-[#071019] text-xs font-semibold tracking-[0.25em] uppercase transition-all duration-300 shadow-lg mt-2"
              >
                {language === 'en' ? 'REQUEST INVITATION' : '呈递入会申请'}
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
