import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Hotel, RoomSuite } from '../types';
import { Emblem, ChineseSeal } from './Emblem';
import { X, MapPin, Compass, Calendar, Users, Check, ArrowRight, Sparkles, Utensils, Heart, ChevronRight } from 'lucide-react';

interface HotelDetailModalProps {
  hotel: Hotel | null;
  onClose: () => void;
  onBookRoom: (hotelId: string, roomId?: string) => void;
}

export const HotelDetailModal: React.FC<HotelDetailModalProps> = ({
  hotel,
  onClose,
  onBookRoom
}) => {
  const { language, t } = useLanguage();
  const [activeTab, setActiveTab] = useState<'overview' | 'suites' | 'dining' | 'wellness' | 'architecture'>('overview');
  const [selectedRoom, setSelectedRoom] = useState<RoomSuite | null>(null);

  if (!hotel) return null;

  return (
    <div
      id="hotel-detail-modal"
      className="fixed inset-0 z-50 overflow-y-auto bg-black/90 backdrop-blur-xl flex justify-center items-start animate-fade-in"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-5xl my-6 sm:my-10 mx-3 sm:mx-6 bg-[#071019] border border-[#C8A66A]/40 shadow-[0_0_80px_rgba(0,0,0,0.9)] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          id="close-hotel-modal-btn"
          className="absolute top-4 right-4 z-30 w-10 h-10 rounded-full bg-[#071019]/80 border border-[#C8A66A]/40 text-[#E4CC98] hover:text-white hover:bg-[#C8A66A]/20 flex items-center justify-center transition-colors focus:outline-none"
          aria-label="Close Hotel Details"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Hero Banner */}
        <div className="relative h-72 sm:h-96 w-full overflow-hidden">
          <img
            src={hotel.heroImage}
            alt={hotel.name}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#071019] via-[#071019]/40 to-transparent" />
          
          {/* Header Title Overlay */}
          <div className="absolute bottom-6 left-6 sm:left-8 right-6 sm:right-8 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
              <div className="flex items-center space-x-2 text-[10.5px] font-cinzel tracking-[0.3em] text-[#C8A66A] uppercase mb-1">
                <MapPin className="w-3.5 h-3.5" />
                <span>{language === 'en' ? hotel.location : hotel.locationZh}</span>
              </div>
              <div className="flex items-baseline space-x-3">
                <h2 className="font-serif-luxury text-3xl sm:text-4xl text-[#F3EFE7] font-normal">
                  YUNQI {hotel.name}
                </h2>
                <span className="font-chinese text-xl text-[#E4CC98]">
                  {hotel.nameZh}
                </span>
              </div>
              <p className="font-chinese text-sm text-[#A7A7A2] mt-0.5">
                {language === 'en' ? hotel.tagline : hotel.taglineZh}
              </p>
            </div>

            <button
              onClick={() => onBookRoom(hotel.id)}
              className="shrink-0 px-6 py-3 bg-[#C8A66A] hover:bg-[#E4CC98] text-[#071019] font-semibold text-xs tracking-[0.22em] uppercase transition-colors shadow-lg"
            >
              {t.bookStay}
            </button>
          </div>
        </div>

        {/* Modal Tab Navigation Bar */}
        <div className="flex border-b border-[#C8A66A]/20 bg-[#0D1720] px-6 sm:px-8 overflow-x-auto">
          {[
            { id: 'overview' as const, label: 'OVERVIEW', labelZh: '概览与特色' },
            { id: 'suites' as const, label: 'ROOMS & SUITES', labelZh: '客房与套房' },
            { id: 'dining' as const, label: 'DINING', labelZh: '珍馐美馔' },
            { id: 'wellness' as const, label: 'WELLNESS & SPA', labelZh: '水疗疗愈' },
            { id: 'architecture' as const, label: 'ARCHITECTURE', labelZh: '建筑规制' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`py-3.5 px-4 text-xs font-cinzel tracking-[0.18em] uppercase transition-all whitespace-nowrap border-b-2 -mb-[1px] ${
                activeTab === tab.id
                  ? 'border-[#C8A66A] text-[#E4CC98] font-bold'
                  : 'border-transparent text-[#A7A7A2] hover:text-[#F3EFE7]'
              }`}
            >
              {language === 'en' ? tab.label : tab.labelZh}
            </button>
          ))}
        </div>

        {/* Modal Body Content */}
        <div className="p-6 sm:p-8 max-h-[60vh] overflow-y-auto">
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-8 animate-fade-in">
              <div>
                <h3 className="text-xs font-cinzel tracking-[0.2em] text-[#C8A66A] uppercase mb-2 font-semibold">
                  {language === 'en' ? 'THE SANCTUARY STORY' : '居停述略'}
                </h3>
                <p className="text-sm text-[#F3EFE7]/90 font-light leading-relaxed">
                  {language === 'en' ? hotel.longDescription : hotel.longDescriptionZh}
                </p>
              </div>

              {/* Key Features */}
              <div>
                <h3 className="text-xs font-cinzel tracking-[0.2em] text-[#C8A66A] uppercase mb-3 font-semibold">
                  {language === 'en' ? 'DISTINCTIVE PRIVILEGES' : '专属尊崇特色'}
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {(language === 'en' ? hotel.keyFeatures : hotel.keyFeaturesZh).map((feat, i) => (
                    <div key={i} className="p-3 bg-[#0D1720] border border-[#C8A66A]/15 flex items-start space-x-2.5">
                      <Sparkles className="w-3.5 h-3.5 text-[#C8A66A] shrink-0 mt-0.5" />
                      <span className="text-xs text-[#F3EFE7]/80 font-light">{feat}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Gallery Strip */}
              <div>
                <h3 className="text-xs font-cinzel tracking-[0.2em] text-[#C8A66A] uppercase mb-3 font-semibold">
                  {language === 'en' ? 'SANCTUARY PERSPECTIVES' : '空间画卷'}
                </h3>
                <div className="grid grid-cols-3 gap-3">
                  {hotel.galleryImages.map((img, i) => (
                    <div key={i} className="h-28 sm:h-36 overflow-hidden border border-[#C8A66A]/20">
                      <img
                        src={img}
                        alt="Gallery"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover hover:scale-110 transition-transform duration-700"
                      />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: ROOMS & SUITES */}
          {activeTab === 'suites' && (
            <div className="space-y-6 animate-fade-in">
              <div className="grid grid-cols-1 gap-6">
                {hotel.rooms.map((room) => (
                  <div
                    key={room.id}
                    className="p-5 bg-[#0D1720] border border-[#C8A66A]/25 hover:border-[#C8A66A] transition-all grid grid-cols-1 md:grid-cols-12 gap-6 items-center"
                  >
                    <div className="md:col-span-5 h-48 overflow-hidden border border-[#C8A66A]/20">
                      <img
                        src={room.image}
                        alt={room.name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover hover:scale-105 transition-transform duration-700"
                      />
                    </div>
                    <div className="md:col-span-7 flex flex-col justify-between h-full">
                      <div>
                        <div className="flex items-start justify-between">
                          <div>
                            <h4 className="font-serif-luxury text-xl text-[#F3EFE7]">
                              {language === 'en' ? room.name : room.nameZh}
                            </h4>
                            <div className="text-[11px] text-[#C8A66A] mt-0.5">
                              {room.size} • {language === 'en' ? room.view : room.viewZh}
                            </div>
                          </div>
                          <div className="text-right">
                            <span className="text-[10px] text-[#A7A7A2] block">{t.fromPrice}</span>
                            <span className="font-mono text-base text-[#E4CC98] font-bold">
                              ¥{room.pricePerNight.toLocaleString()}
                            </span>
                            <span className="text-[10px] text-[#A7A7A2]"> / {t.night}</span>
                          </div>
                        </div>

                        <p className="text-xs text-[#A7A7A2] font-light leading-relaxed mt-2 mb-3">
                          {language === 'en' ? room.description : room.descriptionZh}
                        </p>

                        <div className="flex flex-wrap gap-1.5 mb-4">
                          {(language === 'en' ? room.features : room.featuresZh).map((f, i) => (
                            <span key={i} className="text-[10px] px-2 py-0.5 bg-[#071019] text-[#A7A7A2] border border-white/5">
                              {f}
                            </span>
                          ))}
                        </div>
                      </div>

                      <button
                        onClick={() => onBookRoom(hotel.id, room.id)}
                        className="w-full py-2.5 bg-[#C8A66A] hover:bg-[#E4CC98] text-[#071019] font-semibold text-xs tracking-[0.2em] uppercase transition-colors"
                      >
                        {t.bookThisRoom}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: DINING */}
          {activeTab === 'dining' && (
            <div className="space-y-6 animate-fade-in">
              <div className="p-6 bg-[#0D1720] border border-[#C8A66A]/20">
                <div className="flex items-center space-x-2 text-xs font-cinzel tracking-wider text-[#C8A66A] uppercase mb-2">
                  <Utensils className="w-3.5 h-3.5" />
                  <span>{language === 'en' ? 'PROPERTY GASTRONOMY' : '名馔指南'}</span>
                </div>
                <h4 className="font-serif-luxury text-2xl text-[#F3EFE7] mb-3">
                  {language === 'en' ? hotel.diningSummary : hotel.diningSummaryZh}
                </h4>
                <p className="text-xs text-[#A7A7A2] font-light leading-relaxed">
                  {language === 'en'
                    ? 'Our culinary artisans curate seasonal menus grounded in the local terroir and ancient imperial records. Private dining salons with dedicated tea masters available upon reservation.'
                    : '每一季美馔均深植于当地节令风物与宫廷典籍。尊荣宾客可提前预约私密包厢，享国家级侍茶师全程奉茶与定制餐酒搭配。'}
                </p>
              </div>
            </div>
          )}

          {/* TAB 4: WELLNESS */}
          {activeTab === 'wellness' && (
            <div className="space-y-6 animate-fade-in">
              <div className="p-6 bg-[#0D1720] border border-[#C8A66A]/20">
                <div className="flex items-center space-x-2 text-xs font-cinzel tracking-wider text-[#C8A66A] uppercase mb-2">
                  <Heart className="w-3.5 h-3.5" />
                  <span>{language === 'en' ? 'SANCTUARY SPA & VITALITY' : '身心修养中心'}</span>
                </div>
                <h4 className="font-serif-luxury text-2xl text-[#F3EFE7] mb-3">
                  {language === 'en' ? hotel.wellnessSummary : hotel.wellnessSummaryZh}
                </h4>
                <p className="text-xs text-[#A7A7A2] font-light leading-relaxed">
                  {language === 'en'
                    ? 'Grounded in Traditional Chinese Medicine philosophy and holistic thermal therapies, each ritual is customized after an initial constitutional assessment.'
                    : '以传统中医辨证养生与天然温泉水疗为基石，每位宾客在疗程前均由驻店养生专家把脉测体质，量身定制专属养生修持方案。'}
                </p>
              </div>
            </div>
          )}

          {/* TAB 5: ARCHITECTURE */}
          {activeTab === 'architecture' && (
            <div className="space-y-6 animate-fade-in">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-5 bg-[#0D1720] border border-[#C8A66A]/20">
                <div>
                  <span className="text-[10px] text-[#C8A66A] block font-cinzel uppercase">{t.architectMeta}</span>
                  <span className="text-xs text-[#F3EFE7] font-medium">{hotel.architect}</span>
                </div>
                <div>
                  <span className="text-[10px] text-[#C8A66A] block font-cinzel uppercase">{t.yearMeta}</span>
                  <span className="text-xs text-[#F3EFE7] font-mono">{hotel.yearBuilt}</span>
                </div>
                <div>
                  <span className="text-[10px] text-[#C8A66A] block font-cinzel uppercase">{t.elevationMeta}</span>
                  <span className="text-xs text-[#F3EFE7] font-mono">{hotel.elevation}</span>
                </div>
                <div>
                  <span className="text-[10px] text-[#C8A66A] block font-cinzel uppercase">{t.roomsMeta}</span>
                  <span className="text-xs text-[#F3EFE7] font-mono">{hotel.totalRooms} Sanctuaries</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Bottom Action Footer */}
        <div className="p-4 sm:p-6 bg-[#071019] border-t border-[#C8A66A]/20 flex items-center justify-between">
          <div className="text-xs text-[#A7A7A2]">
            {language === 'en' ? 'Direct Booking Benefits: Complimentary daily champagne breakfast & late checkout.' : '官方直订礼遇：每日精选香槟双人早膳与保证延迟退房。'}
          </div>
          <button
            onClick={() => onBookRoom(hotel.id)}
            className="px-6 py-2.5 bg-[#C8A66A] hover:bg-[#E4CC98] text-[#071019] text-xs font-semibold tracking-[0.2em] uppercase transition-colors"
          >
            {t.bookStay}
          </button>
        </div>
      </div>
    </div>
  );
};
