import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { WELLNESS_PILLARS } from '../data/wellness';
import { Sparkles, ArrowRight, ShieldCheck, Heart } from 'lucide-react';

interface WellnessSectionProps {
  onExploreWellness: () => void;
}

export const WellnessSection: React.FC<WellnessSectionProps> = ({ onExploreWellness }) => {
  const { language, t } = useLanguage();
  const [activeTab, setActiveTab] = useState(0);

  const activePillar = WELLNESS_PILLARS[activeTab];

  return (
    <section id="wellness-section" className="relative bg-[#071019] py-20 lg:py-28 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 pb-6 border-b border-[#C8A66A]/20">
          <div>
            <div className="inline-flex items-center space-x-2 text-[11px] font-cinzel tracking-[0.3em] text-[#C8A66A] uppercase mb-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{t.wellnessTitle}</span>
            </div>
            <h2 className="font-serif-luxury text-3xl sm:text-5xl text-[#F3EFE7] font-normal">
              {t.wellnessHeadline}
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-[#A7A7A2] tracking-wider mt-2 md:mt-0 font-light max-w-md">
            {t.wellnessSubheading}
          </p>
        </div>

        {/* Interactive Modality Tabs */}
        <div className="flex items-center space-x-3 mb-8 overflow-x-auto pb-2">
          {WELLNESS_PILLARS.map((pillar, idx) => (
            <button
              key={pillar.id}
              onClick={() => setActiveTab(idx)}
              className={`px-4 py-2 text-xs font-cinzel tracking-[0.2em] uppercase transition-all duration-300 border ${
                activeTab === idx
                  ? 'bg-[#C8A66A] text-[#071019] border-[#C8A66A] font-semibold shadow-md'
                  : 'bg-[#0D1720]/80 text-[#A7A7A2] hover:text-[#F3EFE7] border-[#C8A66A]/20'
              }`}
            >
              {language === 'en' ? pillar.title : pillar.titleZh}
            </button>
          ))}
        </div>

        {/* Active Modality Feature Card */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center bg-[#0D1720]/90 border border-[#C8A66A]/25 p-6 sm:p-10 shadow-2xl">
          {/* Visual Canvas */}
          <div className="lg:col-span-6 relative overflow-hidden border border-[#C8A66A]/20 h-[320px] sm:h-[420px]">
            <img
              src={activePillar.image}
              alt={activePillar.title}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center hover:scale-105 transition-transform duration-1000 ease-out"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#071019]/90 via-transparent to-transparent" />
            <div className="absolute bottom-4 left-4 right-4 p-3 bg-[#071019]/80 backdrop-blur-sm border border-[#C8A66A]/20">
              <span className="font-chinese text-xs text-[#E4CC98]">
                {language === 'en' ? activePillar.subtitleZh : activePillar.subtitle}
              </span>
            </div>
          </div>

          {/* Details & Signature Therapies */}
          <div className="lg:col-span-6 flex flex-col justify-between">
            <div>
              <span className="font-cinzel text-xs tracking-[0.25em] text-[#C8A66A] font-semibold uppercase block mb-1">
                {language === 'en' ? 'Holistic Sanctuary Protocol' : '云栖东方疗愈法'}
              </span>
              <h3 className="font-serif-luxury text-2xl sm:text-3xl text-[#F3EFE7] font-normal mb-3">
                {language === 'en' ? activePillar.title : activePillar.titleZh}
              </h3>
              <p className="text-xs sm:text-sm text-[#A7A7A2] font-light leading-relaxed mb-6">
                {language === 'en' ? activePillar.description : activePillar.descriptionZh}
              </p>

              {/* Signature Therapy List */}
              <div className="space-y-3 mb-8">
                <span className="block text-[10px] font-cinzel tracking-[0.2em] text-[#E4CC98] uppercase font-semibold">
                  {language === 'en' ? 'Signature Protocols' : '精选专属疗程'}
                </span>
                {activePillar.therapies.map((th, i) => (
                  <div
                    key={i}
                    className="p-3 bg-[#071019]/60 border border-[#C8A66A]/15 flex items-center justify-between"
                  >
                    <div>
                      <div className="text-xs font-serif-luxury text-[#F3EFE7] font-medium">
                        {language === 'en' ? th.name : th.nameZh}
                      </div>
                      <div className="text-[10.5px] text-[#A7A7A2] mt-0.5">
                        {language === 'en' ? th.benefit : th.benefitZh}
                      </div>
                    </div>
                    <span className="font-mono text-[10.5px] text-[#C8A66A] px-2 py-0.5 bg-[#C8A66A]/10 border border-[#C8A66A]/20">
                      {language === 'en' ? th.duration : th.durationZh}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <button
                onClick={onExploreWellness}
                className="inline-flex items-center space-x-3 px-6 py-3 bg-[#C8A66A] hover:bg-[#E4CC98] text-[#071019] text-xs font-semibold tracking-[0.25em] uppercase transition-all duration-300 shadow-md"
              >
                <span>{t.exploreWellness}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
