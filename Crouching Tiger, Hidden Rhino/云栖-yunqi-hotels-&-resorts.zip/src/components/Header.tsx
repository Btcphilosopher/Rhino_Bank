import React, { useState, useEffect } from 'react';
import { Emblem } from './Emblem';
import { useLanguage } from '../context/LanguageContext';
import { Menu, X, Globe, Phone, ChevronRight } from 'lucide-react';

interface HeaderProps {
  onOpenBooking: () => void;
  activeSection?: string;
  onNavigate: (sectionId: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenBooking, activeSection = 'home', onNavigate }) => {
  const { language, toggleLanguage, t } = useLanguage();
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { id: 'home', label: t.navHome },
    { id: 'hotels', label: t.navHotels },
    { id: 'experiences', label: t.navExperiences },
    { id: 'dining', label: t.navDining },
    { id: 'wellness', label: t.navWellness },
    { id: 'architecture', label: t.navArchitecture },
    { id: 'about', label: t.navAbout },
  ];

  const handleItemClick = (id: string) => {
    setMobileMenuOpen(false);
    onNavigate(id);
  };

  return (
    <>
      <header
        id="main-header"
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          isScrolled
            ? 'bg-[#071019]/90 backdrop-blur-md border-b border-[#C8A66A]/20 py-3 shadow-2xl'
            : 'bg-gradient-to-b from-[#071019]/80 via-[#071019]/30 to-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            {/* Brand Logo & Emblem */}
            <button
              id="header-logo-btn"
              onClick={() => handleItemClick('home')}
              className="group flex items-center space-x-3.5 text-left focus:outline-none focus-visible:ring-1 focus-visible:ring-[#C8A66A]"
              aria-label="Yunqi Hotels & Resorts Homepage"
            >
              <Emblem size={38} color="#C8A66A" className="shrink-0" />
              <div className="flex flex-col">
                <span className="font-chinese text-xl tracking-[0.25em] text-[#F3EFE7] font-normal leading-tight group-hover:text-[#E4CC98] transition-colors">
                  云栖
                </span>
                <span className="font-cinzel text-[9.5px] tracking-[0.22em] text-[#C8A66A] font-semibold leading-tight">
                  YUNQI HOTELS & RESORTS
                </span>
              </div>
            </button>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center space-x-8" aria-label="Main Navigation">
              {navItems.map((item) => {
                const isActive = activeSection === item.id;
                return (
                  <button
                    key={item.id}
                    id={`nav-link-${item.id}`}
                    onClick={() => handleItemClick(item.id)}
                    className={`text-[12px] font-medium tracking-[0.18em] transition-all duration-300 relative py-1 focus:outline-none ${
                      isActive
                        ? 'text-[#E4CC98]'
                        : 'text-[#F3EFE7]/80 hover:text-[#F3EFE7]'
                    }`}
                  >
                    {item.label}
                    {isActive && (
                      <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-4 h-[1px] bg-[#C8A66A] rounded-full animate-fade-in" />
                    )}
                  </button>
                );
              })}
            </nav>

            {/* Right Controls: Language & Book Now */}
            <div className="hidden sm:flex items-center space-x-5">
              {/* Language Switch */}
              <button
                id="language-toggle-btn"
                onClick={toggleLanguage}
                className="flex items-center space-x-1.5 text-xs tracking-wider text-[#A7A7A2] hover:text-[#F3EFE7] transition-colors px-2 py-1 rounded focus:outline-none focus-visible:ring-1 focus-visible:ring-[#C8A66A]"
                aria-label="Toggle language between Chinese and English"
              >
                <Globe className="w-3.5 h-3.5 text-[#C8A66A]" />
                <span className="font-medium text-[11px] tracking-widest">
                  {language === 'en' ? '中文 / EN' : 'EN / 中文'}
                </span>
              </button>

              {/* Book Now Button */}
              <button
                id="header-book-now-btn"
                onClick={onOpenBooking}
                className="group relative inline-flex items-center justify-center px-5 py-2 text-[11.5px] font-semibold tracking-[0.2em] uppercase text-[#071019] bg-[#C8A66A] hover:bg-[#E4CC98] transition-all duration-300 shadow-md hover:shadow-[0_0_20px_rgba(200,166,106,0.35)] focus:outline-none"
              >
                <span className="relative z-10">{t.bookNow}</span>
              </button>
            </div>

            {/* Mobile Menu Button */}
            <div className="flex sm:hidden items-center space-x-2">
              <button
                id="mobile-language-btn"
                onClick={toggleLanguage}
                className="p-1.5 text-xs text-[#C8A66A]"
                aria-label="Language switch"
              >
                {language === 'en' ? '中文' : 'EN'}
              </button>
              <button
                id="mobile-menu-toggle-btn"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 text-[#F3EFE7] hover:text-[#C8A66A] focus:outline-none"
                aria-label="Toggle Navigation Menu"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div
          id="mobile-nav-drawer"
          className="fixed inset-0 z-40 lg:hidden bg-[#071019]/95 backdrop-blur-xl pt-24 px-6 pb-8 flex flex-col justify-between overflow-y-auto animate-fade-in"
        >
          <div className="space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-[#C8A66A]/20">
              <span className="text-xs tracking-[0.2em] text-[#C8A66A] uppercase font-cinzel">
                {language === 'en' ? 'Navigation Menu' : '导航目录'}
              </span>
              <button
                onClick={toggleLanguage}
                className="flex items-center space-x-1.5 text-xs text-[#E4CC98] border border-[#C8A66A]/30 px-2.5 py-1 rounded"
              >
                <Globe className="w-3.5 h-3.5 text-[#C8A66A]" />
                <span>{language === 'en' ? '切换为中文' : 'Switch to English'}</span>
              </button>
            </div>

            <nav className="flex flex-col space-y-4">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleItemClick(item.id)}
                  className="flex items-center justify-between text-left text-lg font-serif-luxury tracking-wide text-[#F3EFE7] hover:text-[#C8A66A] py-2 border-b border-white/5 transition-colors"
                >
                  <span>{item.label}</span>
                  <ChevronRight className="w-4 h-4 text-[#C8A66A]/60" />
                </button>
              ))}
            </nav>
          </div>

          <div className="mt-8 space-y-4 pt-6 border-t border-[#C8A66A]/20">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenBooking();
              }}
              className="w-full py-3.5 text-center font-semibold text-xs tracking-[0.25em] uppercase text-[#071019] bg-[#C8A66A] hover:bg-[#E4CC98] transition-colors shadow-lg"
            >
              {t.bookNow}
            </button>

            <div className="flex items-center justify-center space-x-2 text-xs text-[#A7A7A2]">
              <Phone className="w-3.5 h-3.5 text-[#C8A66A]" />
              <span className="tracking-wider">Concierge: +86 (21) 8088 8888</span>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
