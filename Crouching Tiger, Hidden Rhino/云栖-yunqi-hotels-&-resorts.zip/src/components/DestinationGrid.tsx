import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { HOTELS_DATA } from '../data/hotels';
import { Hotel } from '../types';
import { ArrowRight, ArrowUpRight } from 'lucide-react';

interface DestinationGridProps {
  onSelectHotel: (hotel: Hotel) => void;
}

export const DestinationGrid: React.FC<DestinationGridProps> = ({ onSelectHotel }) => {
  const { language, t } = useLanguage();

  return (
    <section id="hotels-section" className="relative bg-[#071019] pt-12 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 pb-4 border-b border-[#C8A66A]/15">
          <div>
            <div className="flex items-center space-x-2 text-[11px] font-cinzel tracking-[0.3em] text-[#C8A66A] uppercase mb-1.5">
              <span>SANCTUARIES ACROSS CHINA</span>
            </div>
            <h2 className="font-serif-luxury text-3xl sm:text-4xl text-[#F3EFE7] font-normal">
              {t.ourHotels}
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-[#A7A7A2] tracking-wider mt-2 md:mt-0 font-light">
            {t.hotelsSubheading}
          </p>
        </div>

        {/* 4 Cards Grid matching the Reference Image */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
          {HOTELS_DATA.map((hotel) => (
            <div
              key={hotel.id}
              id={`hotel-card-${hotel.id}`}
              onClick={() => onSelectHotel(hotel)}
              className="group relative cursor-pointer overflow-hidden bg-[#0D1720] border border-[#C8A66A]/20 hover:border-[#C8A66A] transition-all duration-700 flex flex-col justify-between h-[380px] sm:h-[420px]"
            >
              {/* Card Image with Luxury Slow Zoom */}
              <div className="absolute inset-0 z-0 overflow-hidden">
                <img
                  src={hotel.heroImage}
                  alt={hotel.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-center scale-100 group-hover:scale-110 transition-transform duration-1000 ease-out"
                />
                {/* Dynamic Gradient Overlays */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#071019] via-[#071019]/50 to-black/20 group-hover:via-[#071019]/40 transition-colors duration-500" />
                <div className="absolute inset-0 bg-[#071019]/25 group-hover:bg-transparent transition-colors duration-500" />
              </div>

              {/* Top Meta Indicator */}
              <div className="relative z-10 p-4 sm:p-5 flex items-center justify-between">
                <span className="font-chinese text-sm text-[#F3EFE7]/90 px-2 py-0.5 bg-[#071019]/70 backdrop-blur-sm border border-[#C8A66A]/20">
                  {hotel.nameZh}
                </span>
                <span className="w-7 h-7 rounded-full bg-[#071019]/60 backdrop-blur-md border border-[#C8A66A]/30 flex items-center justify-center text-[#C8A66A] group-hover:bg-[#C8A66A] group-hover:text-[#071019] group-hover:border-[#E4CC98] transition-all duration-300">
                  <ArrowUpRight className="w-3.5 h-3.5 transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                </span>
              </div>

              {/* Bottom Content Area */}
              <div className="relative z-10 p-4 sm:p-5 flex flex-col justify-end">
                {/* Gold animated reveal line */}
                <div className="w-0 group-hover:w-12 h-[1px] bg-[#C8A66A] transition-all duration-500 mb-2.5" />

                {/* Location & Name */}
                <div className="font-cinzel text-xs tracking-[0.25em] text-[#C8A66A] font-semibold mb-0.5">
                  {hotel.name}
                </div>
                <div className="font-chinese text-xs text-[#E4CC98]/90 font-light mb-1.5">
                  {hotel.nameZh}
                </div>

                {/* Tagline */}
                <div className="font-serif-luxury text-base sm:text-lg text-[#F3EFE7] group-hover:text-white font-medium leading-tight mb-2 transition-colors">
                  {language === 'en' ? hotel.tagline : hotel.taglineZh}
                </div>

                {/* Short description */}
                <p className="text-[11.5px] text-[#A7A7A2] group-hover:text-[#F3EFE7]/80 line-clamp-2 leading-relaxed font-light transition-colors mb-3">
                  {language === 'en' ? hotel.shortDescription : hotel.shortDescriptionZh}
                </p>

                {/* Interactive Link */}
                <div className="flex items-center space-x-1.5 text-[10.5px] font-semibold tracking-[0.2em] uppercase text-[#E4CC98] group-hover:text-white transition-colors">
                  <span>{t.viewProperty}</span>
                  <ArrowRight className="w-3 h-3 transform group-hover:translate-x-1.5 transition-transform" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
