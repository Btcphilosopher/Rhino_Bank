import React from 'react';

interface EmblemProps {
  className?: string;
  size?: number;
  color?: string;
}

export const Emblem: React.FC<EmblemProps> = ({
  className = '',
  size = 40,
  color = '#C8A66A'
}) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`transition-transform duration-700 ease-out hover:rotate-45 ${className}`}
      aria-label="Yunqi Emblem"
    >
      {/* Outer refined circle */}
      <circle cx="50" cy="50" r="46" stroke={color} strokeWidth="1.5" strokeOpacity="0.85" />
      {/* Inner delicate guide circle */}
      <circle cx="50" cy="50" r="41" stroke={color} strokeWidth="0.75" strokeOpacity="0.4" />
      
      {/* Architectural Chinese cloud / pavilion geometry */}
      {/* Central pillar */}
      <line x1="50" y1="20" x2="50" y2="80" stroke={color} strokeWidth="1.5" strokeLinecap="round" />
      
      {/* Roof eave arches */}
      <path
        d="M24 38 Q50 30 76 38"
        stroke={color}
        strokeWidth="1.5"
        strokeLinecap="round"
        fill="none"
      />
      <path
        d="M30 50 Q50 44 70 50"
        stroke={color}
        strokeWidth="1.2"
        strokeLinecap="round"
        fill="none"
      />
      <path
        d="M34 64 Q50 58 66 64"
        stroke={color}
        strokeWidth="1.2"
        strokeLinecap="round"
        fill="none"
      />

      {/* Symmetric vertical accents echoing traditional seal character 栖 / 云 */}
      <line x1="38" y1="36" x2="38" y2="68" stroke={color} strokeWidth="1.2" strokeLinecap="round" />
      <line x1="62" y1="36" x2="62" y2="68" stroke={color} strokeWidth="1.2" strokeLinecap="round" />
      
      {/* Horizontal base ground line */}
      <line x1="32" y1="78" x2="68" y2="78" stroke={color} strokeWidth="1.5" strokeLinecap="round" />
      
      {/* Subtle central node */}
      <circle cx="50" cy="50" r="2.5" fill={color} />
    </svg>
  );
};

export const ChineseSeal: React.FC<{ text?: string; className?: string }> = ({
  text = '栖',
  className = ''
}) => {
  return (
    <div
      className={`inline-flex flex-col items-center justify-center bg-[#A63529] text-[#F3EFE7] px-1 py-1.5 rounded-[2px] shadow-md border border-[#C8A66A]/40 select-none ${className}`}
      style={{
        boxShadow: '0 2px 8px rgba(166, 53, 41, 0.4)'
      }}
    >
      <span className="font-chinese text-[11px] leading-tight font-bold tracking-widest writing-vertical">
        {text}
      </span>
    </div>
  );
};
