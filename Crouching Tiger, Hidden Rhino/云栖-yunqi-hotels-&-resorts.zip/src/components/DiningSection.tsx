import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { DINING_DATA } from '../data/dining';
import { DiningItem } from '../types';
import { Utensils, Clock, Sparkles, ArrowRight, Award } from 'lucide-react';

interface DiningSectionProps {
  onReserveClick: (dining: DiningItem) => void;
}

export const DiningSection: React.FC<DiningSectionProps> = ({ onReserveClick }) => {
  const { language, t } = useLanguage();
  const [selectedDining, setSelectedDining] = useState<DiningItem>(DINING_DATA[0]);

  return (
    <section id="dining-section" className="relative bg-[#0D1720] py-20 lg:py-28 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 pb-6 border-b border-[#C8A66A]/20">
          <div>
            <div className="inline-flex items-center space-x-2 text-[11px] font-cinzel tracking-[0.3em] text-[#C8A66A] uppercase mb-1.5">
              <Utensils className="w-3.5 h-3.5" />
              <span>{t.diningTitle}</span>
            </div>
            <h2 className="font-serif-luxury text-3xl sm:text-5xl text-[#F3EFE7] font-normal">
              {t.diningHeadline}
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-[#A7A7A2] tracking-wider mt-2 md:mt-0 font-light max-w-md">
            {t.diningSubheading}
          </p>
        </div>

        {/* Highlight Restaurant Showcase */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center mb-16">
          {/* Main Visual */}
          <div className="lg:col-span-7 relative">
            <div className="overflow-hidden border border-[#C8A66A]/30 shadow-2xl relative h-[380px] sm:h-[480px]">
              <img
                src={selectedDining.image}
                alt={selectedDining.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-1000 ease-out"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#071019] via-transparent to-transparent opacity-80" />

              {/* Floating Michelin / Master badge */}
              <div className="absolute top-6 left-6 flex items-center space-x-2 px-3 py-1.5 bg-[#071019]/85 backdrop-blur-md border border-[#C8A66A]/30">
                <Award className="w-3.5 h-3.5 text-[#C8A66A]" />
                <span className="font-cinzel text-[10.5px] tracking-widest text-[#E4CC98] uppercase">
                  MICHELIN GUIDE & HERITAGE
                </span>
              </div>
            </div>
          </div>

          {/* Restaurant Details */}
          <div className="lg:col-span-5 flex flex-col justify-center">
            <div className="font-cinzel text-xs tracking-[0.25em] text-[#C8A66A] font-semibold mb-1">
              {language === 'en' ? selectedDining.hotel : selectedDining.hotelZh}
            </div>
            
            <h3 className="font-serif-luxury text-2xl sm:text-3xl lg:text-4xl text-[#F3EFE7] font-normal leading-tight mb-2">
              {language === 'en' ? selectedDining.name : selectedDining.nameZh}
            </h3>

            <div className="font-chinese text-sm text-[#E4CC98] font-light mb-4">
              {language === 'en' ? selectedDining.cuisine : selectedDining.cuisineZh}
            </div>

            <p className="text-xs sm:text-sm text-[#A7A7A2] font-light leading-relaxed mb-6">
              {language === 'en' ? selectedDining.description : selectedDining.descriptionZh}
            </p>

            {/* Signature Creation Box */}
            <div className="bg-[#071019]/70 border-l-2 border-[#C8A66A] p-4 mb-6">
              <span className="block text-[10px] font-cinzel tracking-[0.2em] text-[#C8A66A] uppercase font-semibold mb-1">
                {t.signatureDishLabel}
              </span>
              <span className="block text-xs sm:text-sm font-serif-luxury text-[#F3EFE7]">
                {language === 'en' ? selectedDining.signatureDish : selectedDining.signatureDishZh}
              </span>
            </div>

            {/* Meta Info */}
            <div className="grid grid-cols-2 gap-4 text-xs text-[#A7A7A2] mb-6 pt-4 border-t border-white/5">
              <div>
                <span className="block text-[10px] text-[#C8A66A] tracking-wider uppercase">HOURS</span>
                <span className="font-mono text-[11px] text-[#F3EFE7]">{selectedDining.hours}</span>
              </div>
              <div>
                <span className="block text-[10px] text-[#C8A66A] tracking-wider uppercase">DRESS CODE</span>
                <span className="text-[11px] text-[#F3EFE7]">
                  {language === 'en' ? selectedDining.dressCode : selectedDining.dressCodeZh}
                </span>
              </div>
            </div>

            {/* Action */}
            <button
              onClick={() => onReserveClick(selectedDining)}
              className="inline-flex items-center justify-center space-x-3 px-6 py-3 bg-[#C8A66A] hover:bg-[#E4CC98] text-[#071019] text-xs font-semibold tracking-[0.25em] uppercase transition-all duration-300 shadow-md"
            >
              <span>{t.reserveTable}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Quick Restaurant Navigation Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {DINING_DATA.map((item) => (
            <button
              key={item.id}
              onClick={() => setSelectedDining(item)}
              className={`p-4 text-left border transition-all duration-300 flex flex-col justify-between ${
                selectedDining.id === item.id
                  ? 'bg-[#C8A66A]/15 border-[#C8A66A] shadow-lg'
                  : 'bg-[#071019]/60 border-[#C8A66A]/15 hover:border-[#C8A66A]/40'
              }`}
            >
              <div>
                <div className="text-[10px] font-cinzel tracking-widest text-[#C8A66A] uppercase mb-1">
                  {language === 'en' ? item.hotel : item.hotelZh}
                </div>
                <div className="font-serif-luxury text-base text-[#F3EFE7] font-medium">
                  {language === 'en' ? item.name : item.nameZh}
                </div>
              </div>
              <div className="text-[11px] text-[#A7A7A2] mt-2 font-chinese truncate">
                {language === 'en' ? item.cuisine : item.cuisineZh}
              </div>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
};
