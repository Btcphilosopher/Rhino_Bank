package com.example.simulator

import com.example.data.model.MetroLine
import com.example.data.model.MetroNetwork
import com.example.data.model.Station
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.random.Random

data class Train(
    val id: String,
    val line: MetroLine,
    val currentStationId: String,
    val nextStationId: String,
    val directionName: String, // Destination e.g. "福岡空港"
    val isUpward: Boolean, // Direction along line index
    val status: String, // "定刻", "遅延", "停車中", "運転見合わせ"
    val delaySeconds: Int = 0,
    val occupancy: String = "空いています", // "空いています", "やや混雑", "混雑", "非常に混雑"
    val speedKmh: Int = 55
)

object MetroSimulator {
    private val _trains = MutableStateFlow<List<Train>>(emptyList())
    val trains: StateFlow<List<Train>> = _trains.asStateFlow()

    // Global line delay triggers (for testing Journey 02)
    private val _lineDelays = MutableStateFlow<Map<MetroLine, Int>>(
        mapOf(
            MetroLine.KUKO to 0,
            MetroLine.HAKOZAKI to 0,
            MetroLine.NANAKUMA to 0
        )
    )
    val lineDelays: StateFlow<Map<MetroLine, Int>> = _lineDelays.asStateFlow()

    init {
        initializeTrains()
    }

    private fun initializeTrains() {
        val initialTrains = mutableListOf<Train>()

        // Airport Line trains (4 trains in different positions)
        val kukoStations = MetroNetwork.getStationsForLine(MetroLine.KUKO)
        initialTrains.add(Train("K-101", MetroLine.KUKO, "K04", "K05", "福岡空港", true, "定刻", occupancy = "やや混雑"))
        initialTrains.add(Train("K-102", MetroLine.KUKO, "K11", "K10", "姪浜", false, "定刻", occupancy = "空いています"))
        initialTrains.add(Train("K-103", MetroLine.KUKO, "K13", "K12", "姪浜", false, "定刻", occupancy = "非常に混雑"))
        initialTrains.add(Train("K-104", MetroLine.KUKO, "K01", "K02", "福岡空港", true, "定刻", occupancy = "混雑"))

        // Hakozaki Line trains (2 trains)
        val hakoStations = MetroNetwork.getStationsForLine(MetroLine.HAKOZAKI)
        initialTrains.add(Train("H-201", MetroLine.HAKOZAKI, "H02", "H03", "貝塚", true, "定刻", occupancy = "空いています"))
        initialTrains.add(Train("H-202", MetroLine.HAKOZAKI, "H07", "H06", "中洲川端", false, "定刻", occupancy = "やや混雑"))

        // Nanakuma Line trains (3 trains)
        val nanaStations = MetroNetwork.getStationsForLine(MetroLine.NANAKUMA)
        initialTrains.add(Train("N-301", MetroLine.NANAKUMA, "N05", "N06", "博多", true, "定刻", occupancy = "やや混雑"))
        initialTrains.add(Train("N-302", MetroLine.NANAKUMA, "N18", "N17", "橋本", false, "定刻", occupancy = "空いています"))
        initialTrains.add(Train("N-303", MetroLine.NANAKUMA, "N11", "N12", "博多", true, "定刻", occupancy = "混雑"))

        _trains.value = initialTrains
    }

    // Set line delay in minutes (for Journey 02)
    fun injectDelay(line: MetroLine, delayMinutes: Int) {
        val current = _lineDelays.value.toMutableMap()
        current[line] = delayMinutes
        _lineDelays.value = current

        // Update train statuses for that line
        val updatedTrains = _trains.value.map { train ->
            if (train.line == line) {
                train.copy(
                    status = if (delayMinutes > 0) "遅延" else "定刻",
                    delaySeconds = delayMinutes * 60
                )
            } else {
                train
            }
        }
        _trains.value = updatedTrains
    }

    // Periodically advance trains to create a living simulation
    fun tick() {
        val updated = _trains.value.map { train ->
            val stations = MetroNetwork.getStationsForLine(train.line)
            val currentIdx = stations.indexOfFirst { it.id == train.currentStationId }
            val nextIdx = stations.indexOfFirst { it.id == train.nextStationId }

            if (currentIdx == -1 || nextIdx == -1) return@map train

            // Move current station to next, and calculate subsequent station
            val newCurrentIdx = nextIdx
            var newIsUpward = train.isUpward
            var newNextIdx = if (train.isUpward) nextIdx + 1 else nextIdx - 1

            if (newNextIdx >= stations.size) {
                newIsUpward = false
                newNextIdx = stations.size - 2
            } else if (newNextIdx < 0) {
                newIsUpward = true
                newNextIdx = 1
            }

            val newCurrent = stations[newCurrentIdx].id
            val newNext = stations[newNextIdx].id
            val destName = if (newIsUpward) stations.last().name else stations.first().name

            // Randomize occupancy slightly to feel organic
            val occupancies = listOf("空いています", "やや混雑", "混雑", "非常に混雑")
            val newOccupancy = if (Random.nextFloat() < 0.2f) occupancies.random() else train.occupancy

            // Get live status based on delay mapping
            val delayMins = _lineDelays.value[train.line] ?: 0
            val delaySecs = delayMins * 60
            val status = if (delayMins > 0) "遅延" else "定刻"

            train.copy(
                currentStationId = newCurrent,
                nextStationId = newNext,
                directionName = destName,
                isUpward = newIsUpward,
                status = status,
                delaySeconds = delaySecs,
                occupancy = newOccupancy
            )
        }
        _trains.value = updated
    }

    // Gets departures for a station
    fun getDeparturesForStation(stationId: String): List<DepartureItem> {
        val station = MetroNetwork.getStationById(stationId) ?: return emptyList()
        val lineTrains = _trains.value.filter { it.line == station.line }
        
        val list = mutableListOf<DepartureItem>()
        
        // Find direction 1 (Upward) and direction 2 (Downward)
        val lineStations = MetroNetwork.getStationsForLine(station.line)
        val termUp = lineStations.last().name
        val termDown = lineStations.first().name

        // Construct 3 realistic immediate future departures based on simulation
        val baseHour = 10
        val baseMin = 32
        
        val delaySecs = _lineDelays.value[station.line]?.times(60) ?: 0
        val delayStatusLabel = if (delaySecs > 0) "遅延 ${delaySecs / 60}分" else "定刻"
        
        list.add(DepartureItem("${baseHour}:${baseMin}", termUp, "2", "まもなく", delayStatusLabel, "やや混雑"))
        list.add(DepartureItem("${baseHour}:${baseMin + 6}", termDown, "1", "定刻", "定刻", "空いています"))
        list.add(DepartureItem("${baseHour}:${baseMin + 12}", termUp, "2", "定刻", delayStatusLabel, "混雑"))
        list.add(DepartureItem("${baseHour}:${baseMin + 18}", termDown, "1", "定刻", "定刻", "非常に混雑"))

        return list
    }
}

data class DepartureItem(
    val time: String,
    val destination: String,
    val platform: String,
    val status: String, // まもなく, 定刻, 遅延
    val delayInfo: String,
    val occupancy: String
)
