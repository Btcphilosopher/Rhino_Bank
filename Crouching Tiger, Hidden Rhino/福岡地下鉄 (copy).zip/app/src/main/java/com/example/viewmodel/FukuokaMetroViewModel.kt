package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.*
import com.example.data.model.*
import com.example.data.repository.MetroRepository
import com.example.simulator.MetroSimulator
import com.example.simulator.Train
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class JourneyState {
    IDLE,
    ROUTE_SEARCHED,
    ROUTE_SELECTED,
    TICKET_SELECTED,
    TICKET_PURCHASED,
    AT_STATION,
    ENTERING, // Touch gate animation
    WAITING,  // On platform
    BOARDING, // Entering train
    ON_TRAIN, // Active transit
    TRANSFER, // Walking transfer
    ARRIVING, // Nearing destination
    EXITING,  // Exit tap out
    COMPLETED
}

class FukuokaMetroViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: MetroRepository

    init {
        val database = AppDatabase.getDatabase(application)
        repository = MetroRepository(database)
        
        // Start simulation loop ticker
        startSimulatorTicker()
        
        // Insert sample favorites on startup if database is empty
        viewModelScope.launch {
            repository.allFavorites.first().let { favs ->
                if (favs.isEmpty()) {
                    repository.insertFavorite(FavoriteEntity(label = "自宅 (姪浜)", fromStationId = "K01", toStationId = "K11", fromStationName = "姪浜", toStationName = "博多"))
                    repository.insertFavorite(FavoriteEntity(label = "職場 (天神)", fromStationId = "K11", toStationId = "K08", fromStationName = "博多", toStationName = "天神"))
                }
            }
        }
    }

    // Reactive streams from database
    val allTickets: StateFlow<List<TicketEntity>> = repository.allTickets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTapEvents: StateFlow<List<TapEventEntity>> = repository.allTapEvents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allJourneys: StateFlow<List<JourneyEntity>> = repository.allJourneys
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allFavorites: StateFlow<List<FavoriteEntity>> = repository.allFavorites
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allNotifications: StateFlow<List<NotificationEntity>> = repository.allNotifications
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Simulator streams
    val liveTrains: StateFlow<List<Train>> = MetroSimulator.trains
    val liveLineDelays: StateFlow<Map<MetroLine, Int>> = MetroSimulator.lineDelays

    // UI state
    private val _journeyState = MutableStateFlow(JourneyState.IDLE)
    val journeyState: StateFlow<JourneyState> = _journeyState.asStateFlow()

    private val _startStation = MutableStateFlow<Station?>(MetroNetwork.getStationById("K08")) // Default Tenjin
    val startStation: StateFlow<Station?> = _startStation.asStateFlow()

    private val _endStation = MutableStateFlow<Station?>(MetroNetwork.getStationById("K11")) // Default Hakata
    val endStation: StateFlow<Station?> = _endStation.asStateFlow()

    private val _searchPreference = MutableStateFlow(RouteSearchPreference.FASTEST)
    val searchPreference: StateFlow<RouteSearchPreference> = _searchPreference.asStateFlow()

    private val _routeAlternatives = MutableStateFlow<List<RouteAlternative>>(emptyList())
    val routeAlternatives: StateFlow<List<RouteAlternative>> = _routeAlternatives.asStateFlow()

    private val _selectedRoute = MutableStateFlow<RouteAlternative?>(null)
    val selectedRoute: StateFlow<RouteAlternative?> = _selectedRoute.asStateFlow()

    private val _selectedTicketType = MutableStateFlow("普通乗車券") // 普通乗車券, 1日乗車券, デジタル乗車券
    val selectedTicketType: StateFlow<String> = _selectedTicketType.asStateFlow()

    private val _purchasedTicket = MutableStateFlow<TicketEntity?>(null)
    val purchasedTicket: StateFlow<TicketEntity?> = _purchasedTicket.asStateFlow()

    // Transit simulation states
    private val _currentLegIndex = MutableStateFlow(0)
    val currentLegIndex: StateFlow<Int> = _currentLegIndex.asStateFlow()

    private val _currentStationOnJourney = MutableStateFlow<Station?>(null)
    val currentStationOnJourney: StateFlow<Station?> = _currentStationOnJourney.asStateFlow()

    private val _minutesRemaining = MutableStateFlow(0)
    val minutesRemaining: StateFlow<Int> = _minutesRemaining.asStateFlow()

    // Tap Gate animation and sound status triggers
    private val _isTappingGate = MutableStateFlow(false)
    val isTappingGate: StateFlow<Boolean> = _isTappingGate.asStateFlow()

    private val _gateMessage = MutableStateFlow("")
    val gateMessage: StateFlow<String> = _gateMessage.asStateFlow()

    // Simulator tick job
    private var simulatorJob: Job? = null

    private fun startSimulatorTicker() {
        simulatorJob?.cancel()
        simulatorJob = viewModelScope.launch {
            while (true) {
                delay(4000) // Speed up time for interactive prototype
                MetroSimulator.tick()
                
                // If we are currently ON_TRAIN, advance the simulated journey position!
                if (_journeyState.value == JourneyState.ON_TRAIN) {
                    advanceOnTrainJourney()
                }
            }
        }
    }

    // Setters
    fun setStartStation(station: Station?) {
        _startStation.value = station
    }

    fun setEndStation(station: Station?) {
        _endStation.value = station
    }

    fun setPreference(pref: RouteSearchPreference) {
        _searchPreference.value = pref
    }

    fun setTicketType(type: String) {
        _selectedTicketType.value = type
    }

    // Trigger route search recalculation (Journey 01 & Journey 02)
    fun searchRoutes() {
        val start = _startStation.value ?: return
        val end = _endStation.value ?: return
        val pref = _searchPreference.value

        _routeAlternatives.value = RouteCalculator.findRoutes(start, end, pref)
        _journeyState.value = JourneyState.ROUTE_SEARCHED
        
        viewModelScope.launch {
            repository.insertNotification(
                NotificationEntity(
                    title = "経路検索完了",
                    body = "${start.name} から ${end.name} の最適経路を検索しました。",
                    type = "SERVICE"
                )
            )
        }
    }

    fun selectRoute(alternative: RouteAlternative) {
        _selectedRoute.value = alternative
        _journeyState.value = JourneyState.ROUTE_SELECTED
    }

    fun selectTicketProduct() {
        _journeyState.value = JourneyState.TICKET_SELECTED
    }

    // Purchase digital ticket wallet insertion (Journey 01)
    fun purchaseTicket() {
        val route = _selectedRoute.value ?: return
        viewModelScope.launch {
            val qrContent = "FUKUOKA-METRO-${route.fromStation.id}-${route.toStation.id}-${System.currentTimeMillis()}"
            val newTicket = TicketEntity(
                productType = _selectedTicketType.value,
                fromStationId = route.fromStation.id,
                toStationId = route.toStation.id,
                fromStationName = route.fromStation.name,
                toStationName = route.toStation.name,
                fare = route.totalFare,
                status = "PURCHASED",
                qrCodeContent = qrContent
            )
            val ticketId = repository.insertTicket(newTicket)
            val ticketWithId = newTicket.copy(id = ticketId.toInt())
            _purchasedTicket.value = ticketWithId

            repository.insertNotification(
                NotificationEntity(
                    title = "チケット購入完了",
                    body = "${route.fromStation.name} から ${route.toStation.name} の ${newTicket.productType} を購入しました。",
                    type = "TICKET"
                )
            )
            _journeyState.value = JourneyState.TICKET_PURCHASED
        }
    }

    fun goToStation() {
        _journeyState.value = JourneyState.AT_STATION
    }

    // Simulate contactless or ticket gate tap-in (Journey 01 & Journey 03)
    fun simulateGateEntry() {
        val start = _startStation.value ?: return
        viewModelScope.launch {
            _isTappingGate.value = true
            _gateMessage.value = "認証中..."
            delay(1200)

            // Perform DB insertions for tap event
            val event = TapEventEntity(
                type = "ENTRY",
                stationId = start.id,
                stationName = start.name,
                fareCharged = 0,
                balanceRemaining = 2000
            )
            repository.insertTapEvent(event)

            // Update ticket status to active if using a purchased ticket
            _purchasedTicket.value?.let { ticket ->
                val activated = ticket.copy(status = "ACTIVE", activationTimestamp = System.currentTimeMillis())
                repository.updateTicket(activated)
                _purchasedTicket.value = activated
            }

            _gateMessage.value = "乗車しました (残高 ¥2,000)"
            delay(1000)
            _isTappingGate.value = false

            repository.insertNotification(
                NotificationEntity(
                    title = "改札通過 (入場)",
                    body = "${start.name}駅 の自動改札機を通過しました。列車をお待ちください。",
                    type = "JOURNEY"
                )
            )

            // Advance to platform waiting state
            _journeyState.value = JourneyState.WAITING
        }
    }

    fun simulateBoarding() {
        val route = _selectedRoute.value ?: return
        _currentLegIndex.value = 0
        _currentStationOnJourney.value = route.legs.first().fromStation
        _minutesRemaining.value = route.totalDurationMinutes
        _journeyState.value = JourneyState.BOARDING
        
        viewModelScope.launch {
            delay(1200)
            _journeyState.value = JourneyState.ON_TRAIN
            repository.insertNotification(
                NotificationEntity(
                    title = "列車に乗車しました",
                    body = "${route.legs.first().fromStation.name} から列車に乗車しました。${route.legs.first().toStation.name}方面 へ進みます。",
                    type = "JOURNEY"
                )
            )
        }
    }

    // Step-by-step advance of transit state
    private fun advanceOnTrainJourney() {
        val route = _selectedRoute.value ?: return
        val currentLegs = route.legs
        val currentLeg = currentLegs.getOrNull(_currentLegIndex.value) ?: return

        val fromList = MetroNetwork.getStationsForLine(currentLeg.line ?: MetroLine.KUKO)
        val fromIdx = fromList.indexOfFirst { it.id == _currentStationOnJourney.value?.id }
        val toIdx = fromList.indexOfFirst { it.id == currentLeg.toStation.id }

        if (fromIdx != -1 && toIdx != -1 && fromIdx != toIdx) {
            // Move train marker closer to target station on the line
            val nextIdx = if (toIdx > fromIdx) fromIdx + 1 else fromIdx - 1
            val nextStation = fromList[nextIdx]
            _currentStationOnJourney.value = nextStation
            
            val durationUnit = 2
            _minutesRemaining.value = maxOf(0, _minutesRemaining.value - durationUnit)

            viewModelScope.launch {
                repository.insertNotification(
                    NotificationEntity(
                        title = "まもなく ${nextStation.name}",
                        body = "次の停車駅は ${nextStation.name} です。",
                        type = "JOURNEY"
                    )
                )
            }

            if (nextStation.id == currentLeg.toStation.id) {
                // Leg completed! Check if there is a next leg
                if (_currentLegIndex.value < currentLegs.size - 1) {
                    // There is a transfer next!
                    _currentLegIndex.value += 1
                    val nextLeg = currentLegs[_currentLegIndex.value]
                    if (nextLeg.type == LegType.TRANSFER) {
                        _journeyState.value = JourneyState.TRANSFER
                        viewModelScope.launch {
                            repository.insertNotification(
                                NotificationEntity(
                                    title = "乗換のお知らせ",
                                    body = "次は ${nextLeg.fromStation.name}駅 での乗換です。${nextLeg.description}",
                                    type = "JOURNEY"
                                )
                            )
                        }
                    }
                } else {
                    // Arrived at destination!
                    _journeyState.value = JourneyState.ARRIVING
                }
            }
        } else {
            // Safe fallback
            _journeyState.value = JourneyState.ARRIVING
        }
    }

    // Completing walking transfers
    fun completeTransfer() {
        val route = _selectedRoute.value ?: return
        if (_journeyState.value == JourneyState.TRANSFER) {
            // Advance past the transfer leg to the next train leg
            _currentLegIndex.value += 1
            val nextLeg = route.legs.getOrNull(_currentLegIndex.value)
            if (nextLeg != null) {
                _currentStationOnJourney.value = nextLeg.fromStation
                _journeyState.value = JourneyState.ON_TRAIN
                viewModelScope.launch {
                    repository.insertNotification(
                        NotificationEntity(
                            title = "乗換完了",
                            body = "${nextLeg.fromStation.name} から ${nextLeg.line?.displayName} に乗車しました。",
                            type = "JOURNEY"
                        )
                    )
                }
            } else {
                _journeyState.value = JourneyState.ARRIVING
            }
        }
    }

    fun goToExiting() {
        _journeyState.value = JourneyState.EXITING
    }

    // Simulate exit tap-out and compute final transaction
    fun simulateGateExit() {
        val end = _endStation.value ?: return
        val route = _selectedRoute.value ?: return
        viewModelScope.launch {
            _isTappingGate.value = true
            _gateMessage.value = "認証中..."
            delay(1200)

            // Perform DB insertions for exit tap event
            val event = TapEventEntity(
                type = "EXIT",
                stationId = end.id,
                stationName = end.name,
                fareCharged = route.totalFare,
                balanceRemaining = 2000 - route.totalFare
            )
            repository.insertTapEvent(event)

            // Update ticket status to USED
            _purchasedTicket.value?.let { ticket ->
                val used = ticket.copy(status = "USED")
                repository.updateTicket(used)
                _purchasedTicket.value = null // clear from active pocket
            }

            // Save completed journey history to Room database (Journey 01, 03, 04)
            val journey = JourneyEntity(
                fromStationId = route.fromStation.id,
                toStationId = route.toStation.id,
                fromStationName = route.fromStation.name,
                toStationName = route.toStation.name,
                startTime = System.currentTimeMillis() - (route.totalDurationMinutes * 60 * 1000),
                endTime = System.currentTimeMillis(),
                fare = route.totalFare,
                isDelayed = route.isDelayed,
                delayMinutes = route.delayMinutes
            )
            repository.insertJourney(journey)

            _gateMessage.value = "降車しました (運賃 ¥${route.totalFare} 引)"
            delay(1000)
            _isTappingGate.value = false

            repository.insertNotification(
                NotificationEntity(
                    title = "ご乗車ありがとうございました",
                    body = "${end.name}駅 の改札機を通過しました。目的地までの出口案内をご確認ください。",
                    type = "JOURNEY"
                )
            )

            _journeyState.value = JourneyState.COMPLETED
        }
    }

    // Complete the flow entirely and return to IDLE
    fun completeJourney() {
        _journeyState.value = JourneyState.IDLE
        _selectedRoute.value = null
        _routeAlternatives.value = emptyList()
    }

    // Reset current active journey if user wants to quit
    fun resetActiveJourney() {
        _journeyState.value = JourneyState.IDLE
        _selectedRoute.value = null
        _routeAlternatives.value = emptyList()
        _purchasedTicket.value = null
    }

    // Inject synthetic 8-minute delay on Airport Line (Journey 02 test toggle)
    fun triggerAirportLineDelay(isDelayed: Boolean) {
        viewModelScope.launch {
            val delayMinutes = if (isDelayed) 8 else 0
            MetroSimulator.injectDelay(MetroLine.KUKO, delayMinutes)

            repository.insertNotification(
                NotificationEntity(
                    title = "運行情報 (空港線)",
                    body = if (isDelayed) {
                        "空港線で一部列車に遅延が発生しています。最大 8分 の影響が予測されます。"
                    } else {
                        "空港線は平常運転に復旧しました。"
                    },
                    type = "SERVICE"
                )
            )

            // If we have an active search result or route, recalculate on delay detection! (Journey 02 recalculation logic!)
            if (_journeyState.value == JourneyState.ROUTE_SEARCHED || _journeyState.value == JourneyState.ROUTE_SELECTED) {
                searchRoutes() // automatically updates alternatives using delayed weights
            }
        }
    }

    fun markAllNotificationsRead() {
        viewModelScope.launch {
            repository.markAllNotificationsRead()
        }
    }
}
