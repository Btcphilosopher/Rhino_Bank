package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MetroLine
import com.example.data.model.MetroNetwork
import com.example.data.model.RouteLeg
import com.example.data.model.LegType
import com.example.ui.theme.*
import com.example.viewmodel.FukuokaMetroViewModel
import com.example.viewmodel.JourneyState

@Composable
fun ActiveJourneyScreen(
    viewModel: FukuokaMetroViewModel,
    modifier: Modifier = Modifier
) {
    val journeyState by viewModel.journeyState.collectAsState()
    val selectedRoute by viewModel.selectedRoute.collectAsState()
    val currentLegIndex by viewModel.currentLegIndex.collectAsState()
    val currentStationOnJourney by viewModel.currentStationOnJourney.collectAsState()
    val minutesRemaining by viewModel.minutesRemaining.collectAsState()
    val isTappingGate by viewModel.isTappingGate.collectAsState()
    val gateMessage by viewModel.gateMessage.collectAsState()

    val route = selectedRoute ?: return

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(if (MaterialTheme.colorScheme.background == DarkBg) DarkBg else LightBg)
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 120.dp)
        ) {
            // Immersive Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(RoundedCornerShape(5.dp))
                                .background(MetroAccent)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = when (journeyState) {
                                JourneyState.WAITING -> "列車到着待ち"
                                JourneyState.BOARDING -> "まもなく発車"
                                JourneyState.ON_TRAIN -> "乗車中 (Active Transit)"
                                JourneyState.TRANSFER -> "乗換案内 (Transfer)"
                                JourneyState.ARRIVING -> "まもなく到着"
                                JourneyState.EXITING -> "改札出場 (Tap Out)"
                                JourneyState.COMPLETED -> "目的地到着"
                                else -> "案内中"
                            },
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            color = MetroAccent,
                            letterSpacing = 1.sp
                        )
                    }

                    // Cancel ride trigger
                    TextButton(onClick = { viewModel.resetActiveJourney() }) {
                        Text("案内を終了", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Path segment title
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${route.fromStation.name} から ${route.toStation.name} へ",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "残り ${minutesRemaining}分",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                color = MetroAccent
                            )
                        }
                    }
                }
            }

            // Stateful Journey Sections
            when (journeyState) {
                JourneyState.WAITING -> {
                    item {
                        WaitingForTrainCard(
                            fromStation = route.fromStation,
                            onBoardTrain = { viewModel.simulateBoarding() }
                        )
                    }
                }
                JourneyState.BOARDING -> {
                    item {
                        BoardingSimulationCard()
                    }
                }
                JourneyState.ON_TRAIN -> {
                    item {
                        OnTrainProgressCard(
                            currentStation = currentStationOnJourney,
                            destination = route.legs.getOrNull(currentLegIndex)?.toStation ?: route.toStation,
                            minutesRemaining = minutesRemaining,
                            leg = route.legs.getOrNull(currentLegIndex)
                        )
                    }
                }
                JourneyState.TRANSFER -> {
                    item {
                        TransferGuideCard(
                            leg = route.legs.getOrNull(currentLegIndex),
                            onCompleteTransfer = { viewModel.completeTransfer() }
                        )
                    }
                }
                JourneyState.ARRIVING -> {
                    item {
                        ArrivingCard(
                            destination = route.toStation,
                            onGoToExit = { viewModel.goToExiting() }
                        )
                    }
                }
                JourneyState.EXITING -> {
                    item {
                        TapOutGateCard(
                            destination = route.toStation,
                            isTapping = isTappingGate,
                            message = gateMessage,
                            onTapOut = { viewModel.simulateGateExit() }
                        )
                    }
                }
                JourneyState.COMPLETED -> {
                    item {
                        JourneyCompletedCard(
                            destination = route.toStation,
                            onFinish = { viewModel.completeJourney() }
                        )
                    }
                }
                else -> {}
            }
        }
    }
}

@Composable
fun WaitingForTrainCard(
    fromStation: com.example.data.model.Station,
    onBoardTrain: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(imageVector = Icons.Default.DirectionsTransit, contentDescription = null, tint = MetroPrimary, modifier = Modifier.size(48.dp))
            Spacer(modifier = Modifier.height(12.dp))
            Text("ホームでお待ちください", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text(
                text = "${fromStation.name}駅 の乗車ホームでお待ちください。列車が接近すると通知します。",
                fontSize = 11.sp,
                color = Color.Gray,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
            )

            // Direct simulation trigger
            Button(
                onClick = onBoardTrain,
                colors = ButtonDefaults.buttonColors(containerColor = MetroPrimary),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("board_train_simulation_button")
            ) {
                Text("列車に乗車する (シミュレート)", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun BoardingSimulationCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            CircularProgressIndicator(color = MetroAccent)
            Spacer(modifier = Modifier.height(16.dp))
            Text("扉が閉まります。ご注意ください...", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
        }
    }
}

@Composable
fun OnTrainProgressCard(
    currentStation: com.example.data.model.Station?,
    destination: com.example.data.model.Station,
    minutesRemaining: Int,
    leg: RouteLeg?
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = leg?.line?.displayName ?: "地下鉄",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = leg?.line?.let { when (it) {
                    MetroLine.KUKO -> LineKuko
                    MetroLine.HAKOZAKI -> LineHakozaki
                    MetroLine.NANAKUMA -> LineNanakuma
                } } ?: Color.Gray
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Progress Indicators Station dots
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(StatusNormal)
                    ) {
                        Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp).align(Alignment.Center))
                    }
                    Text(leg?.fromStation?.name ?: "現在地", fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
                }

                Box(
                    modifier = Modifier
                        .height(3.dp)
                        .weight(1.5f)
                        .background(StatusNormal)
                )

                // Current transit node
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.weight(1f)
                ) {
                    val infiniteTransition = rememberInfiniteTransition()
                    val pulseScale by infiniteTransition.animateFloat(
                        initialValue = 0.8f,
                        targetValue = 1.2f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(1000, easing = LinearEasing),
                            repeatMode = RepeatMode.Reverse
                        )
                    )
                    
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(MetroAccent.copy(alpha = pulseScale))
                    )
                    Text(currentStation?.name ?: "走行中", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MetroAccent, modifier = Modifier.padding(top = 4.dp))
                }

                Box(
                    modifier = Modifier
                        .height(3.dp)
                        .weight(1.5f)
                        .background(Color.LightGray)
                )

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .border(2.dp, Color.LightGray, RoundedCornerShape(8.dp))
                    )
                    Text(destination.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Gray, modifier = Modifier.padding(top = 4.dp))
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Divider()

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("次の停車駅", fontSize = 10.sp, color = Color.Gray)
                    Text(
                        text = if (currentStation?.id == destination.id) "まもなく到着" else "走行中...",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("到着予定", fontSize = 10.sp, color = Color.Gray)
                    Text("10:42", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MetroPrimary)
                }
            }
            
            if (currentStation?.id == destination.id) {
                Spacer(modifier = Modifier.height(16.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(StatusNormal.copy(alpha = 0.1f))
                        .padding(12.dp)
                ) {
                    Text("🔔 降車駅が近づいています。お乗り換え・お出口の準備をお願いします。", fontSize = 11.sp, color = StatusNormal, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun TransferGuideCard(
    leg: RouteLeg?,
    onCompleteTransfer: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text("🔁 乗り換え案内 (Transfer Instructions)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MetroPrimary)
            
            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "${leg?.fromStation?.name}駅 での乗り換えが必要です",
                fontSize = 16.sp,
                fontWeight = FontWeight.Black
            )

            Text(
                text = leg?.description ?: "乗り換え通路に沿ってお進みください",
                fontSize = 13.sp,
                modifier = Modifier.padding(vertical = 8.dp)
            )

            // Dynamic directions guide
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(LightBg)
                    .padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.DirectionsWalk, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("徒歩連絡時間：約 2分", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                leg?.accessibilityDetails?.forEach { detail ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Accessible, contentDescription = null, tint = MetroPrimary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(detail, fontSize = 12.sp, color = MetroPrimary)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = onCompleteTransfer,
                colors = ButtonDefaults.buttonColors(containerColor = MetroPrimary),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("complete_transfer_button")
            ) {
                Text("乗り換えを完了して次の列車に乗車", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun ArrivingCard(
    destination: com.example.data.model.Station,
    onGoToExit: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(imageVector = Icons.Default.LocationOn, contentDescription = null, tint = StatusNormal, modifier = Modifier.size(48.dp))
            Spacer(modifier = Modifier.height(12.dp))
            Text("${destination.name}駅に到着しました", fontSize = 18.sp, fontWeight = FontWeight.Black, color = StatusNormal)
            Text(
                text = "ドアが開きます。足元にご注意ください。自動改札口へ進み、出場用タッチを行ってください。",
                fontSize = 11.sp,
                color = Color.Gray,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
            )

            Button(
                onClick = onGoToExit,
                colors = ButtonDefaults.buttonColors(containerColor = MetroAccent),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("go_to_exit_action_button")
            ) {
                Text("改札出口へ進む", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun TapOutGateCard(
    destination: com.example.data.model.Station,
    isTapping: Boolean,
    message: String,
    onTapOut: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(imageVector = Icons.Default.SettingsCell, contentDescription = null, tint = MetroPrimary, modifier = Modifier.size(48.dp))
            Spacer(modifier = Modifier.height(12.dp))
            Text("出場用改札機タッチ", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text(
                text = "降車駅 (${destination.name}) の自動改札機にスマートフォンをかざしてください。",
                fontSize = 11.sp,
                color = Color.Gray,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
            )

            if (isTapping) {
                CircularProgressIndicator(color = MetroAccent)
                Spacer(modifier = Modifier.height(8.dp))
                Text(message, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MetroPrimary)
            } else {
                Button(
                    onClick = onTapOut,
                    colors = ButtonDefaults.buttonColors(containerColor = MetroAccent),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("gate_tap_out_action_button")
                ) {
                    Text("改札機にタッチ (出場)", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun JourneyCompletedCard(
    destination: com.example.data.model.Station,
    onFinish: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text("🎉 ご乗車ありがとうございました", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = StatusNormal)
            Text("移動履歴がマイページに保存されました。", fontSize = 11.sp, color = Color.Gray)

            Spacer(modifier = Modifier.height(16.dp))

            Text("🚪 目的地周辺・出口おすすめ (Hakata Terminal Exit)", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            
            // Street level suggestion
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(MetroAccent.copy(alpha = 0.1f))
                        .padding(6.dp)
                ) {
                    Text("東5出口", color = MetroAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text("JR博多シティ / アミュプラザ 方面へ徒歩3分", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = onFinish,
                colors = ButtonDefaults.buttonColors(containerColor = MetroPrimary),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("案内を終了してホームへ戻る", fontWeight = FontWeight.Bold)
            }
        }
    }
}
