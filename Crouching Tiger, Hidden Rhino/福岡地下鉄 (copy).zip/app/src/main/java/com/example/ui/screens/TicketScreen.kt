package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.TicketEntity
import com.example.ui.theme.*
import com.example.viewmodel.FukuokaMetroViewModel
import com.example.viewmodel.JourneyState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TicketScreen(
    viewModel: FukuokaMetroViewModel,
    modifier: Modifier = Modifier
) {
    val journeyState by viewModel.journeyState.collectAsState()
    val selectedRoute by viewModel.selectedRoute.collectAsState()
    val selectedTicketType by viewModel.selectedTicketType.collectAsState()
    val purchasedTicket by viewModel.purchasedTicket.collectAsState()
    val allTickets by viewModel.allTickets.collectAsState()
    val isTappingGate by viewModel.isTappingGate.collectAsState()
    val gateMessage by viewModel.gateMessage.collectAsState()

    var activeSubTab by remember { mutableStateOf("有効") } // 有効, 使用済み, ICカード

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp)
    ) {
        // Form Title
        item {
            Text(
                text = "チケット・乗車券",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = if (MaterialTheme.colorScheme.background == DarkBg) TextDarkPrimary else TextLightPrimary
            )
        }

        // Subtabs: 有効, 使用済み, ICカード
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(4.dp)
            ) {
                listOf("有効", "使用済み", "IC・タッチ").forEach { tab ->
                    val isSelected = activeSubTab == tab
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) MetroPrimary else Color.Transparent)
                            .clickable { activeSubTab = tab }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = tab,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) Color.White else Color.Gray
                        )
                    }
                }
            }
        }

        // Conditionally render based on Subtab selection
        when (activeSubTab) {
            "有効" -> {
                // If there's a selected ticket to buy
                if (journeyState == JourneyState.TICKET_SELECTED) {
                    item {
                        TicketPurchaseSummaryCard(
                            routeLabel = "${selectedRoute?.fromStation?.name} → ${selectedRoute?.toStation?.name}",
                            fare = selectedRoute?.totalFare ?: 260,
                            selectedType = selectedTicketType,
                            onTypeChange = { viewModel.setTicketType(it) },
                            onPurchase = { viewModel.purchaseTicket() }
                        )
                    }
                }

                // Currently active/purchased digital tickets
                val activeTickets = allTickets.filter { it.status == "PURCHASED" || it.status == "ACTIVE" }
                if (activeTickets.isEmpty() && journeyState != JourneyState.TICKET_SELECTED) {
                    item {
                        EmptyPocketState(onAction = { activeSubTab = "IC・タッチ" })
                    }
                } else {
                    items(activeTickets) { ticket ->
                        DigitalTicketCard(
                            ticket = ticket,
                            isTappingGate = isTappingGate,
                            gateMessage = gateMessage,
                            onTapGate = { viewModel.simulateGateEntry() },
                            onProceedToTrain = { viewModel.goToStation() }
                        )
                    }
                }
            }
            "使用済み" -> {
                val usedTickets = allTickets.filter { it.status == "USED" || it.status == "EXPIRED" }
                if (usedTickets.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surface)
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("使用済みのチケットはありません", fontSize = 12.sp, color = Color.Gray)
                        }
                    }
                } else {
                    items(usedTickets) { ticket ->
                        UsedTicketItem(ticket)
                    }
                }
            }
            "IC・タッチ" -> {
                item {
                    ContactlessIcCardTab(
                        isTappingGate = isTappingGate,
                        gateMessage = gateMessage,
                        onTapIn = { viewModel.simulateGateEntry() },
                        onTapOut = { viewModel.simulateGateExit() }
                    )
                }
            }
        }
    }
}

@Composable
fun TicketPurchaseSummaryCard(
    routeLabel: String,
    fare: Int,
    selectedType: String,
    onTypeChange: (String) -> Unit,
    onPurchase: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("乗車券の種類を選択", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
            
            Spacer(modifier = Modifier.height(12.dp))

            listOf("普通乗車券", "1日乗車券", "デジタル乗車券").forEach { type ->
                val isSelected = selectedType == type
                val productFare = if (type == "1日乗車券") 640 else fare
                
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) MetroPrimary.copy(alpha = 0.08f) else Color.Transparent)
                        .border(1.dp, if (isSelected) MetroPrimary else Color.LightGray.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                        .clickable { onTypeChange(type) }
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = isSelected, onClick = { onTypeChange(type) })
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(type, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Text(
                                text = if (type == "1日乗車券") "福岡地下鉄全線が1日乗り放題" else "指定区間片道1回のみ有効",
                                fontSize = 10.sp,
                                color = Color.Gray
                            )
                        }
                    }
                    Text("¥$productFare", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MetroAccent)
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            Spacer(modifier = Modifier.height(16.dp))

            Divider()

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("合計金額", fontSize = 11.sp, color = Color.Gray)
                    Text(
                        text = "¥${if (selectedType == "1日乗車券") 640 else fare}",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black,
                        color = MetroAccent
                    )
                }

                Button(
                    onClick = onPurchase,
                    colors = ButtonDefaults.buttonColors(containerColor = MetroAccent),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .height(44.dp)
                        .testTag("buy_ticket_action_button")
                ) {
                    Text("チケットを購入する", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun DigitalTicketCard(
    ticket: TicketEntity,
    isTappingGate: Boolean,
    gateMessage: String,
    onTapGate: () -> Unit,
    onProceedToTrain: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "福岡市地下鉄",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MetroPrimary
                )
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (ticket.status == "ACTIVE") StatusNormal.copy(alpha = 0.15f) else Color.LightGray.copy(alpha = 0.2f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (ticket.status == "ACTIVE") "使用中" else "未使用",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (ticket.status == "ACTIVE") StatusNormal else Color.Gray
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Body Ticket parameters
            Text(
                text = ticket.productType,
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = ticket.fromStationName,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f)
                )
                Icon(
                    imageVector = Icons.Default.ArrowForward,
                    contentDescription = null,
                    tint = MetroPrimary,
                    modifier = Modifier.padding(horizontal = 12.dp)
                )
                Text(
                    text = ticket.toStationName,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("運賃 ¥${ticket.fare}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MetroAccent)
                Text("有効期限: 当日限り", fontSize = 11.sp, color = Color.Gray)
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Custom beautiful QR Code Canvas Drawing
            Box(
                modifier = Modifier
                    .size(160.dp)
                    .border(1.dp, Color.LightGray, RoundedCornerShape(8.dp))
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val side = size.width
                    val cols = 15
                    val blockSize = side / cols

                    // Anchor markers at corners
                    // Top-Left
                    drawRect(Color.Black, Offset(0f, 0f), Size(blockSize * 4, blockSize * 4))
                    drawRect(Color.White, Offset(blockSize, blockSize), Size(blockSize * 2, blockSize * 2))
                    drawRect(Color.Black, Offset(blockSize * 1.5f, blockSize * 1.5f), Size(blockSize, blockSize))

                    // Top-Right
                    drawRect(Color.Black, Offset(side - blockSize * 4, 0f), Size(blockSize * 4, blockSize * 4))
                    drawRect(Color.White, Offset(side - blockSize * 3, blockSize), Size(blockSize * 2, blockSize * 2))
                    drawRect(Color.Black, Offset(side - blockSize * 2.5f, blockSize * 1.5f), Size(blockSize, blockSize))

                    // Bottom-Left
                    drawRect(Color.Black, Offset(0f, side - blockSize * 4), Size(blockSize * 4, blockSize * 4))
                    drawRect(Color.White, Offset(blockSize, side - blockSize * 3), Size(blockSize * 2, blockSize * 2))
                    drawRect(Color.Black, Offset(blockSize * 1.5f, side - blockSize * 2.5f), Size(blockSize, blockSize))

                    // Random noise dots in center
                    val stateRand = java.util.Random(ticket.id.toLong() + 45L)
                    for (r in 0 until cols) {
                        for (c in 0 until cols) {
                            if (r < 4 && c < 4) continue
                            if (r < 4 && c > cols - 5) continue
                            if (r > cols - 5 && c < 4) continue
                            
                            if (stateRand.nextBoolean()) {
                                drawRect(
                                    color = Color.Black,
                                    topLeft = Offset(c * blockSize, r * blockSize),
                                    size = Size(blockSize, blockSize)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text("デモ用QR (支払いは発生しません)", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Bold)

            Spacer(modifier = Modifier.height(16.dp))

            // Gate tap action button
            if (isTappingGate) {
                CircularProgressIndicator(color = MetroAccent, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.height(8.dp))
                Text(gateMessage, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MetroPrimary)
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (ticket.status == "PURCHASED") {
                        Button(
                            onClick = onTapGate,
                            colors = ButtonDefaults.buttonColors(containerColor = MetroAccent),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("gate_tap_button")
                        ) {
                            Icon(imageVector = Icons.Default.QrCodeScanner, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("改札にタッチ (入場)", fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Button(
                            onClick = onProceedToTrain,
                            colors = ButtonDefaults.buttonColors(containerColor = StatusNormal),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(imageVector = Icons.Default.Train, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("列車乗車ガイドへ進む", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ContactlessIcCardTab(
    isTappingGate: Boolean,
    gateMessage: String,
    onTapIn: () -> Unit,
    onTapOut: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("デジタルはやかけん / タッチ決済", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MetroPrimary)
            Text("プロトタイプ機能 (NFC/QRタッチ擬似シミュレート)", fontSize = 11.sp, color = Color.Gray, modifier = Modifier.padding(top = 2.dp))

            Spacer(modifier = Modifier.height(24.dp))

            // Elegant IC Card Visual Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(LineHakozaki)
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("はやかけん", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                        Icon(imageVector = Icons.Default.Nfc, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                    }

                    Column {
                        Text("残高", color = Color.White.copy(alpha = 0.7f), fontSize = 10.sp)
                        Text("¥2,000", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            if (isTappingGate) {
                CircularProgressIndicator(color = MetroAccent, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.height(8.dp))
                Text(gateMessage, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MetroPrimary)
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onTapIn,
                        colors = ButtonDefaults.buttonColors(containerColor = MetroPrimary),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("ic_tap_in_button")
                    ) {
                        Text("改札入場タッチ", fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = onTapOut,
                        colors = ButtonDefaults.buttonColors(containerColor = MetroAccent),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("ic_tap_out_button")
                    ) {
                        Text("改札出場タッチ", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun EmptyPocketState(onAction: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(imageVector = Icons.Default.ConfirmationNumber, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(48.dp))
            Text("有効な乗車券がありません", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
            Text("経路検索からチケットを購入するか、\n「IC・タッチ」タブからタッチ乗車が可能です。", fontSize = 11.sp, color = Color.Gray, textAlign = TextAlign.Center)
            Spacer(modifier = Modifier.height(4.dp))
            Button(
                onClick = onAction,
                colors = ButtonDefaults.buttonColors(containerColor = MetroPrimary),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("ICタッチ乗車を試す", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun UsedTicketItem(ticket: TicketEntity) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(ticket.productType, fontSize = 12.sp, color = Color.Gray)
                Text("${ticket.fromStationName} → ${ticket.toStationName}", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                val sdf = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.JAPAN)
                Text("購入: ${sdf.format(Date(ticket.purchaseTimestamp))}", fontSize = 10.sp, color = Color.Gray)
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color.LightGray.copy(alpha = 0.3f))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = if (ticket.status == "USED") "使用済" else "期限切",
                    fontSize = 10.sp,
                    color = Color.Gray,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
