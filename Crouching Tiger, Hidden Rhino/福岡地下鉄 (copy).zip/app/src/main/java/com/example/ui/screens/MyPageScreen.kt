package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.FukuokaMetroViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MyPageScreen(
    viewModel: FukuokaMetroViewModel,
    modifier: Modifier = Modifier
) {
    val allJourneys by viewModel.allJourneys.collectAsState()
    val liveLineDelays by viewModel.liveLineDelays.collectAsState()
    val isKukoDelayed = (liveLineDelays[com.example.data.model.MetroLine.KUKO] ?: 0) > 0

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp)
    ) {
        // Page Title
        item {
            Text(
                text = "マイページ・設定",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = if (MaterialTheme.colorScheme.background == DarkBg) TextDarkPrimary else TextLightPrimary
            )
        }

        // Prototype Disclaimer Section (MANDATORY)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "⚠️ デモンストレーション用プロトタイプ",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.error
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "プロトタイプ / 合成データによるデモンストレーション",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                    Text(
                        text = "福岡市地下鉄の公式アプリではありません。",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }
        }

        // Demo Delay Controls (Journey 02 triggering engine!)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "デモ制御盤 (Delay Simulation)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MetroPrimary
                    )
                    Text(
                        text = "空港線に8分の遅延を発生させて、う回路線の再検索機能を体験します (JOURNEY 02)",
                        fontSize = 11.sp,
                        color = Color.Gray,
                        modifier = Modifier.padding(top = 2.dp, bottom = 12.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "空港線 8分遅延をシミュレート",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Switch(
                            checked = isKukoDelayed,
                            onCheckedChange = { viewModel.triggerAirportLineDelay(it) },
                            modifier = Modifier.testTag("delay_simulator_switch")
                        )
                    }
                }
            }
        }

        // Travel logs history (Room persistence confirmation!)
        item {
            Text(
                text = "利用履歴 (Travel History)",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = if (MaterialTheme.colorScheme.background == DarkBg) TextDarkPrimary else TextLightPrimary,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        if (allJourneys.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("乗車履歴はありません。チケットを使用すると自動で記録されます。", fontSize = 11.sp, color = Color.Gray)
                }
            }
        } else {
            items(allJourneys) { journey ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(MetroPrimary)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "${journey.fromStationName} → ${journey.toStationName}",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = "¥${journey.fare}",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MetroAccent
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val sdf = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.JAPAN)
                            Text(
                                text = sdf.format(Date(journey.startTime)),
                                fontSize = 10.sp,
                                color = Color.Gray
                            )
                            
                            if (journey.isDelayed) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(StatusDelay.copy(alpha = 0.15f))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("遅延遭遇 (${journey.delayMinutes}分)", fontSize = 10.sp, color = StatusDelay, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Settings items: language, accessibility list
        item {
            Text(
                text = "一般設定",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = if (MaterialTheme.colorScheme.background == DarkBg) TextDarkPrimary else TextLightPrimary,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surface)
            ) {
                // Language Setting Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { }
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("言語 (Language)", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Text("日本語 / English", fontSize = 12.sp, color = Color.Gray)
                }

                Divider(color = Color.LightGray.copy(alpha = 0.2f))

                // Accessibility Setting Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { }
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("バリアフリー設定", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Text("車いす・スロープ対応", fontSize = 12.sp, color = Color.Gray)
                }

                Divider(color = Color.LightGray.copy(alpha = 0.2f))

                // App Version Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("バージョン", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Text("v1.0.0 (Demo)", fontSize = 12.sp, color = Color.Gray)
                }
            }
        }
    }
}
