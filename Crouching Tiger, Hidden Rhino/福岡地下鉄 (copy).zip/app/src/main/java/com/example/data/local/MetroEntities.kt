package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "tickets")
data class TicketEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val productType: String, // "普通乗車券", "1日乗車券", "デジタル乗車券", "回数券"
    val fromStationId: String,
    val toStationId: String,
    val fromStationName: String,
    val toStationName: String,
    val fare: Int,
    val passengerCount: Int = 1,
    val status: String, // "AVAILABLE", "PURCHASED", "ACTIVE", "USED", "EXPIRED"
    val purchaseTimestamp: Long = System.currentTimeMillis(),
    val activationTimestamp: Long? = null,
    val qrCodeContent: String = ""
) : Serializable

@Entity(tableName = "tap_events")
data class TapEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val type: String, // "ENTRY" (乗車), "EXIT" (降車)
    val stationId: String,
    val stationName: String,
    val timestamp: Long = System.currentTimeMillis(),
    val fareCharged: Int = 0,
    val balanceRemaining: Int = 2000
) : Serializable

@Entity(tableName = "journeys")
data class JourneyEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val fromStationId: String,
    val toStationId: String,
    val fromStationName: String,
    val toStationName: String,
    val startTime: Long,
    val endTime: Long,
    val fare: Int,
    val isDelayed: Boolean = false,
    val delayMinutes: Int = 0
) : Serializable

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val label: String, // "自宅", "職場", "学校", etc.
    val fromStationId: String,
    val toStationId: String,
    val fromStationName: String,
    val toStationName: String
) : Serializable

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val body: String,
    val type: String, // "SERVICE", "JOURNEY", "TICKET"
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
) : Serializable
