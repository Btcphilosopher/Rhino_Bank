package com.example.data.model

import java.io.Serializable

data class RouteLeg(
    val type: LegType, // WALK, TRAIN, TRANSFER
    val line: MetroLine?, // null if WALK or TRANSFER
    val fromStation: Station,
    val toStation: Station,
    val durationMinutes: Int,
    val description: String,
    val platform: String? = null,
    val direction: String? = null,
    val accessibilityDetails: List<String> = emptyList()
) : Serializable

enum class LegType {
    WALK,
    TRAIN,
    TRANSFER
}

data class RouteAlternative(
    val id: Int,
    val legs: List<RouteLeg>,
    val totalDurationMinutes: Int,
    val totalFare: Int,
    val transfersCount: Int,
    val routeTypeLabel: String, // "最短時間", "乗換少なめ", "バリアフリー優先", etc.
    val congestionLabel: String, // "空いています", "やや混雑", "混雑"
    val isDelayed: Boolean = false,
    val delayMinutes: Int = 0
) : Serializable {
    val fromStation: Station get() = legs.first().fromStation
    val toStation: Station get() = legs.last().toStation
}

enum class RouteSearchPreference {
    FASTEST, // 最短
    FEWER_TRANSFERS, // 乗換少なめ
    LESS_WALKING, // 徒歩少なめ
    CHEAPEST, // 安い
    BARRIER_FREE // バリアフリー
}
