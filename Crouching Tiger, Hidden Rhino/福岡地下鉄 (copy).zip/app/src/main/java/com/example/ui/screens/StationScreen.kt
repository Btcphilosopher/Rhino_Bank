package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MetroLine
import com.example.data.model.MetroNetwork
import com.example.data.model.Station
import com.example.simulator.DepartureItem
import com.example.simulator.MetroSimulator
import com.example.ui.theme.*
import com.example.viewmodel.FukuokaMetroViewModel

@Composable
fun StationScreen(
    viewModel: FukuokaMetroViewModel,
    modifier: Modifier = Modifier
) {
    val liveTrains by viewModel.liveTrains.collectAsState()
    
    var searchQuery by remember { mutableStateOf("") }
    var selectedStation by remember { mutableStateOf<Station?>(MetroNetwork.getStationById("K11")) } // Default Hakata

    // Filter stations based on search query
    val filteredStations = remember(searchQuery) {
        if (searchQuery.isBlank()) {
            MetroNetwork.stations.distinctBy { it.name }
        } else {
            MetroNetwork.stations.distinctBy { it.name }.filter {
                it.name.contains(searchQuery) || it.nameEn.contains(searchQuery, ignoreCase = true) || it.code.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    var selectedMapTab by remember { mutableStateOf("改札") } // 駅構内, 改札, ホーム, 出口

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp)
    ) {
        // Form Title
        item {
            Text(
                text = "駅情報・発車案内",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = if (MaterialTheme.colorScheme.background == DarkBg) TextDarkPrimary else TextLightPrimary
            )
        }

        // Search bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("駅名、駅番号で検索 (例: 博多、天神、K08)") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("station_search_bar"),
                leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(imageVector = Icons.Default.Clear, contentDescription = null)
                        }
                    }
                },
                shape = RoundedCornerShape(8.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MetroPrimary,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                    focusedContainerColor = MaterialTheme.colorScheme.surface
                ),
                singleLine = true
            )
        }

        // Search Results selection pills if query is active
        if (searchQuery.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    filteredStations.take(4).forEach { station ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(MetroPrimary.copy(alpha = 0.1f))
                                .clickable {
                                    selectedStation = station
                                    searchQuery = ""
                                }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text("${station.name} (${station.code})", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MetroPrimary)
                        }
                    }
                }
            }
        }

        // Station Info Header
        selectedStation?.let { station ->
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Badge
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(when (station.line) {
                                    MetroLine.KUKO -> LineKuko
                                    MetroLine.HAKOZAKI -> LineHakozaki
                                    MetroLine.NANAKUMA -> LineNanakuma
                                }),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(station.code.take(1), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Text(station.code.drop(1), color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Black)
                            }
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(station.name, fontSize = 22.sp, fontWeight = FontWeight.Black)
                            Text(station.nameEn, fontSize = 12.sp, color = Color.Gray)
                        }

                        // Nearby connections details
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color.LightGray.copy(alpha = 0.2f))
                                .padding(6.dp)
                        ) {
                            Text(
                                text = when (station.line) {
                                    MetroLine.KUKO -> "空港線"
                                    MetroLine.HAKOZAKI -> "箱崎線"
                                    MetroLine.NANAKUMA -> "七隈線"
                                },
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray
                            )
                        }
                    }
                }
            }

            // Train departure board (発車案内)
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (MaterialTheme.colorScheme.background == DarkBg) DarkSurface else Color(0xFF1E293B))
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("発車案内 (Live Departures)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.LightGray)
                        Text("天神・博多方面", fontSize = 11.sp, color = Color.LightGray.copy(alpha = 0.6f))
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Departure Grid Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("時刻", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.weight(1.5f))
                        Text("行先", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.weight(3f))
                        Text("番線", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                        Text("状態", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.weight(2.5f), textAlign = TextAlign.End)
                    }

                    Divider(color = Color.DarkGray, modifier = Modifier.padding(vertical = 6.dp))

                    // Simulated live departures
                    val departures = MetroSimulator.getDeparturesForStation(station.id)
                    departures.forEach { departure ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = departure.time,
                                color = Color(0xFFF1F5F9),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                modifier = Modifier.weight(1.5f)
                            )
                            Text(
                                text = departure.destination,
                                color = Color(0xFFF1F5F9),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(3f)
                            )
                            Text(
                                text = departure.platform,
                                color = Color(0xFFF59E0B),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f),
                                textAlign = TextAlign.Center
                            )
                            
                            Box(
                                modifier = Modifier.weight(2.5f),
                                contentAlignment = Alignment.CenterEnd
                            ) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (departure.status == "まもなく") StatusDelay.copy(alpha = 0.15f) else StatusNormal.copy(alpha = 0.15f))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = departure.status,
                                        color = if (departure.status == "まもなく") StatusDelay else StatusNormal,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                        Divider(color = Color.Gray.copy(alpha = 0.15f))
                    }
                }
            }

            // Interactive digital station map (構内図 / 案内)
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .padding(16.dp)
                ) {
                    Text("デジタル駅案内・構内図", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                    
                    Spacer(modifier = Modifier.height(12.dp))

                    // Wayfinding subtabs
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (MaterialTheme.colorScheme.background == DarkBg) DarkBg else LightBg)
                            .padding(2.dp)
                    ) {
                        listOf("改札", "ホーム", "出口", "設備").forEach { tab ->
                            val isSelected = selectedMapTab == tab
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (isSelected) MetroPrimary else Color.Transparent)
                                    .clickable { selectedMapTab = tab }
                                    .padding(vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(tab, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (isSelected) Color.White else Color.Gray)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Content based on subtab
                    when (selectedMapTab) {
                        "改札" -> {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("🎟️ 北改札口 / 南改札口 (地下1階)", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text("・天神地下街直結通路、岩田屋・福岡市役所方面へ便利です。", fontSize = 11.sp, color = Color.Gray)
                                Text("・全ての改札で「はやかけん」及び交通系IC、タッチ決済に対応。", fontSize = 11.sp, color = Color.Gray)
                            }
                        }
                        "ホーム" -> {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("🚇 1番線 / 2番線 ホーム (地下2階)", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text("・1番線: 福岡空港・博多方面", fontSize = 12.sp, color = LineKuko, fontWeight = FontWeight.Bold)
                                Text("・2番線: 姪浜・筑前前原方面", fontSize = 12.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                                Text("・ホームドア完全設置、転落事故防止対策済です。", fontSize = 11.sp, color = Color.Gray)
                            }
                        }
                        "出口" -> {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("🚪 主要出口案内", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                station.exits.forEach { exit ->
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(MetroAccent.copy(alpha = 0.1f))
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(exit, fontSize = 10.sp, color = MetroAccent, fontWeight = FontWeight.Bold)
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text("徒歩 3〜5分・周辺オフィス・観光地直結", fontSize = 11.sp, color = Color.Gray)
                                    }
                                }
                            }
                        }
                        "設備" -> {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("♿ バリアフリー・駅設備一覧", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                station.facilities.forEach { facility ->
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = StatusNormal, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(facility, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
