package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import com.example.data.local.*
import com.example.data.model.MetroLine
import com.example.ui.components.MetroMapCanvas
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.DarkBg
import com.example.ui.theme.MetroPrimary
import com.example.ui.theme.MetroAccent
import com.example.ui.theme.StatusDelay
import com.example.ui.theme.StatusInfo
import com.example.viewmodel.FukuokaMetroViewModel
import com.example.viewmodel.JourneyState

class MainActivity : ComponentActivity() {
    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val viewModel: FukuokaMetroViewModel = viewModel()
                
                val journeyState by viewModel.journeyState.collectAsState()
                val liveLineDelays by viewModel.liveLineDelays.collectAsState()
                val liveTrains by viewModel.liveTrains.collectAsState()
                val notifications by viewModel.allNotifications.collectAsState()

                var currentTab by remember { mutableStateOf("ホーム") }
                var showNotificationCenter by remember { mutableStateOf(false) }

                val isKukoDelayed = (liveLineDelays[MetroLine.KUKO] ?: 0) > 0

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = {
                        Column {
                            CenterAlignedTopAppBar(
                                title = {
                                    Text(
                                        text = "福岡地下鉄.OS",
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Black,
                                        letterSpacing = 1.sp
                                    )
                                },
                                navigationIcon = {
                                    // Live Status banner in top bar
                                    Row(
                                        modifier = Modifier
                                            .padding(start = 12.dp)
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(if (isKukoDelayed) StatusDelay.copy(alpha = 0.15f) else MetroPrimary.copy(alpha = 0.15f))
                                            .padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(6.dp)
                                                .clip(RoundedCornerShape(3.dp))
                                                .background(if (isKukoDelayed) StatusDelay else MetroPrimary)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = if (isKukoDelayed) "遅延 8分" else "平常運転",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isKukoDelayed) StatusDelay else MetroPrimary
                                        )
                                    }
                                },
                                actions = {
                                    // Notification badge bell icon (simulated notification tray)
                                    IconButton(
                                        onClick = { showNotificationCenter = true },
                                        modifier = Modifier.testTag("bell_notification_icon")
                                    ) {
                                        BadgedBox(
                                            badge = {
                                                val unreadCount = notifications.size
                                                if (unreadCount > 0) {
                                                    Badge(containerColor = MetroAccent) {
                                                        Text("$unreadCount", color = Color.White)
                                                    }
                                                }
                                            }
                                        ) {
                                            Icon(imageVector = Icons.Default.Notifications, contentDescription = "Alerts")
                                        }
                                    }
                                },
                                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                                    containerColor = MaterialTheme.colorScheme.surface
                                )
                            )

                            // Quick interactive Fukuoka Map folding banner on Home tab for high visual polish
                            if (currentTab == "ホーム") {
                                MetroMapCanvas(
                                    trains = liveTrains,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    },
                    bottomBar = {
                        // Persistent standard bottom navigation bar
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface,
                            tonalElevation = 8.dp
                        ) {
                            val tabs = listOf(
                                Triple("ホーム", Icons.Default.Home, "home_tab"),
                                Triple("経路", Icons.Default.Search, "route_tab"),
                                Triple("チケット", Icons.Default.ConfirmationNumber, "ticket_tab"),
                                Triple("駅", Icons.Default.Place, "station_tab"),
                                Triple("設定", Icons.Default.Person, "settings_tab")
                            )

                            tabs.forEach { (tabName, icon, tag) ->
                                val isSelected = currentTab == tabName
                                NavigationBarItem(
                                    selected = isSelected,
                                    onClick = { currentTab = tabName },
                                    icon = { Icon(imageVector = icon, contentDescription = tabName) },
                                    label = { Text(tabName, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                    modifier = Modifier.testTag(tag),
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Color.White,
                                        selectedTextColor = MetroPrimary,
                                        indicatorColor = MetroPrimary,
                                        unselectedIconColor = Color.Gray,
                                        unselectedTextColor = Color.Gray
                                    )
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        // Render main screens based on bottom nav selection
                        when (currentTab) {
                            "ホーム" -> HomeScreen(
                                viewModel = viewModel,
                                onNavigateToTab = { currentTab = it }
                            )
                            "経路" -> RouteScreen(viewModel = viewModel)
                            "チケット" -> TicketScreen(viewModel = viewModel)
                            "駅" -> StationScreen(viewModel = viewModel)
                            "設定" -> MyPageScreen(viewModel = viewModel)
                        }

                        // Immersive Journey Mode active ride overlay (Chapters 15, 16, 17)
                        val isRideActive = journeyState != JourneyState.IDLE &&
                                           journeyState != JourneyState.ROUTE_SEARCHED &&
                                           journeyState != JourneyState.ROUTE_SELECTED &&
                                           journeyState != JourneyState.TICKET_SELECTED &&
                                           journeyState != JourneyState.TICKET_PURCHASED

                        AnimatedVisibility(
                            visible = isRideActive,
                            enter = fadeIn() + expandVertically(),
                            exit = fadeOut() + shrinkVertically(),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            ActiveJourneyScreen(viewModel = viewModel)
                        }
                    }
                }

                // Simulated Notification center tray alert dialogue
                if (showNotificationCenter) {
                    AlertDialog(
                        onDismissRequest = { showNotificationCenter = false },
                        title = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(imageVector = Icons.Default.NotificationsActive, contentDescription = null, tint = MetroAccent)
                                Text("運行・お乗り換え通知履歴", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                        },
                        text = {
                            Box(modifier = Modifier.height(280.dp)) {
                                if (notifications.isEmpty()) {
                                    Box(
                                        modifier = Modifier.fillMaxSize(),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("新着の通知はありません", fontSize = 12.sp, color = Color.Gray)
                                    }
                                } else {
                                    LazyColumn(
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        items(notifications) { item ->
                                            Card(
                                                colors = CardDefaults.cardColors(
                                                    containerColor = when (item.type) {
                                                        "SERVICE" -> StatusDelay.copy(alpha = 0.05f)
                                                        "JOURNEY" -> StatusInfo.copy(alpha = 0.05f)
                                                        else -> MaterialTheme.colorScheme.surface
                                                    }
                                                )
                                            ) {
                                                Column(modifier = Modifier.padding(10.dp)) {
                                                    Text(item.title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (item.type == "SERVICE") StatusDelay else MetroPrimary)
                                                    Text(item.body, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.padding(top = 2.dp))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        },
                        confirmButton = {
                            TextButton(
                                onClick = {
                                    viewModel.markAllNotificationsRead()
                                    showNotificationCenter = false
                                }
                            ) {
                                Text("すべて既読にする", fontWeight = FontWeight.Bold)
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { showNotificationCenter = false }) {
                                Text("閉じる")
                            }
                        }
                    )
                }
            }
        }
    }
}
