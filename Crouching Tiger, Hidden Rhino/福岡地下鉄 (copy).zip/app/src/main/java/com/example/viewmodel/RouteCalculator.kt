package com.example.viewmodel

import com.example.data.model.*
import com.example.simulator.MetroSimulator

object RouteCalculator {

    // Computes routes between start and destination stations taking preference & current delays into account
    fun findRoutes(
        from: Station,
        to: Station,
        preference: RouteSearchPreference,
        isAdult: Boolean = true
    ): List<RouteAlternative> {
        if (from.id == to.id) return emptyList()

        val list = mutableListOf<RouteAlternative>()

        // Get live delays
        val kukoDelay = MetroSimulator.lineDelays.value[MetroLine.KUKO] ?: 0
        val hakoDelay = MetroSimulator.lineDelays.value[MetroLine.HAKOZAKI] ?: 0
        val nanaDelay = MetroSimulator.lineDelays.value[MetroLine.NANAKUMA] ?: 0

        // We will generate up to 2 realistic route alternatives for the Fukuoka network
        // Route 1: Direct or natural connection
        val naturalLegs = buildNaturalRoute(from, to, preference)
        val naturalDuration = calculateTotalDuration(naturalLegs, preference, kukoDelay, hakoDelay, nanaDelay)
        val naturalFare = MetroNetwork.calculateFare(from, to)

        val route1 = RouteAlternative(
            id = 1,
            legs = naturalLegs,
            totalDurationMinutes = naturalDuration,
            totalFare = if (isAdult) naturalFare else naturalFare / 2,
            transfersCount = naturalLegs.count { it.type == LegType.TRANSFER },
            routeTypeLabel = when (preference) {
                RouteSearchPreference.FASTEST -> "最短時間"
                RouteSearchPreference.FEWER_TRANSFERS -> "乗換少なめ"
                RouteSearchPreference.LESS_WALKING -> "徒歩少なめ"
                RouteSearchPreference.CHEAPEST -> "最安料金"
                RouteSearchPreference.BARRIER_FREE -> "バリアフリー優先"
            },
            congestionLabel = if (naturalLegs.any { it.line == MetroLine.KUKO }) "やや混雑" else "空いています",
            isDelayed = naturalLegs.any { 
                (it.line == MetroLine.KUKO && kukoDelay > 0) || 
                (it.line == MetroLine.HAKOZAKI && hakoDelay > 0) || 
                (it.line == MetroLine.NANAKUMA && nanaDelay > 0) 
            },
            delayMinutes = when {
                naturalLegs.any { it.line == MetroLine.KUKO } -> kukoDelay
                naturalLegs.any { it.line == MetroLine.HAKOZAKI } -> hakoDelay
                naturalLegs.any { it.line == MetroLine.NANAKUMA } -> nanaDelay
                else -> 0
            }
        )
        list.add(route1)

        // If from and to are on different lines, we can offer an alternative route (e.g. transfering at Hakata vs Tenjin)
        val hasAlternateTransfer = (from.line == MetroLine.KUKO && to.line == MetroLine.NANAKUMA) ||
                                   (from.line == MetroLine.NANAKUMA && to.line == MetroLine.KUKO)

        if (hasAlternateTransfer) {
            // Generate second alternative route using a different transfer station
            val alternativeLegs = buildAlternativeRoute(from, to, preference)
            val alternativeDuration = calculateTotalDuration(alternativeLegs, preference, kukoDelay, hakoDelay, nanaDelay)
            
            // If the primary route has a massive delay, the alternative route might be faster!
            val route2 = RouteAlternative(
                id = 2,
                legs = alternativeLegs,
                totalDurationMinutes = alternativeDuration,
                totalFare = if (isAdult) naturalFare else naturalFare / 2, // Fares inside Fukuoka subway are transfer-independent
                transfersCount = alternativeLegs.count { it.type == LegType.TRANSFER },
                routeTypeLabel = if (alternativeDuration < route1.totalDurationMinutes) "おすすめ代替ルート" else "迂回ルート",
                congestionLabel = "空いています",
                isDelayed = alternativeLegs.any { 
                    (it.line == MetroLine.KUKO && kukoDelay > 0) || 
                    (it.line == MetroLine.HAKOZAKI && hakoDelay > 0) || 
                    (it.line == MetroLine.NANAKUMA && nanaDelay > 0) 
                },
                delayMinutes = 0
            )
            list.add(route2)
        }

        // Sort: Fast preferences first
        return list.sortedBy { it.totalDurationMinutes }
    }

    private fun calculateTotalDuration(
        legs: List<RouteLeg>,
        pref: RouteSearchPreference,
        kukoD: Int,
        hakoD: Int,
        nanaD: Int
    ): Int {
        var base = legs.sumOf { it.durationMinutes }
        
        // Add delays
        legs.forEach { leg ->
            if (leg.line == MetroLine.KUKO) base += kukoD
            if (leg.line == MetroLine.HAKOZAKI) base += hakoD
            if (leg.line == MetroLine.NANAKUMA) base += nanaD
        }

        // Apply preference modifier for user comfort displays
        if (pref == RouteSearchPreference.BARRIER_FREE) {
            // Barrier free routes add ~2 mins of elevator wait time buffers
            base += 1
        }
        return base
    }

    private fun buildNaturalRoute(from: Station, to: Station, preference: RouteSearchPreference): List<RouteLeg> {
        val legs = mutableListOf<RouteLeg>()

        if (from.line == to.line) {
            // Direct route
            val travelTime = kotlin.math.abs(from.index - to.index) * 2
            legs.add(
                RouteLeg(
                    type = LegType.TRAIN,
                    line = from.line,
                    fromStation = from,
                    toStation = to,
                    durationMinutes = travelTime,
                    description = "${from.line.displayName} (${if (to.index > from.index) "下り" else "上り"}方面)",
                    platform = if (to.index > from.index) "2番線" else "1番線",
                    direction = if (to.index > from.index) "空港・博多方面" else "姪浜方面",
                    accessibilityDetails = if (preference == RouteSearchPreference.BARRIER_FREE) {
                        listOf("エレベーター乗降に対応", "ホーム・車両の段差なし")
                    } else emptyList()
                )
            )
        } else {
            // Transfer required
            // Case 1: Kuko <-> Hakozaki. Transfer is always Nakasu-Kawabata (K09 / H01)
            if ((from.line == MetroLine.KUKO && to.line == MetroLine.HAKOZAKI) ||
                (from.line == MetroLine.HAKOZAKI && to.line == MetroLine.KUKO)) {
                
                val midKuko = MetroNetwork.getStationById("K09")!!
                val midHako = MetroNetwork.getStationById("H01")!!

                if (from.line == MetroLine.KUKO) {
                    val t1 = kotlin.math.abs(from.index - 8) * 2
                    legs.add(RouteLeg(LegType.TRAIN, MetroLine.KUKO, from, midKuko, t1, "空港線", "2番線", "貝塚方面"))
                    legs.add(RouteLeg(LegType.TRANSFER, null, midKuko, midHako, 2, "中洲川端駅 改札内乗換", null, null, listOf("エレベーター完備")))
                    val t2 = kotlin.math.abs(to.index - 0) * 2
                    legs.add(RouteLeg(LegType.TRAIN, MetroLine.HAKOZAKI, midHako, to, t2, "箱崎線", "1番線", "貝塚行"))
                } else {
                    val t1 = kotlin.math.abs(from.index - 0) * 2
                    legs.add(RouteLeg(LegType.TRAIN, MetroLine.HAKOZAKI, from, midHako, t1, "箱崎線", "2番線", "中洲川端行"))
                    legs.add(RouteLeg(LegType.TRANSFER, null, midHako, midKuko, 2, "中洲川端駅 改札内乗換", null, null, listOf("エレベーター完備")))
                    val t2 = kotlin.math.abs(to.index - 8) * 2
                    legs.add(RouteLeg(LegType.TRAIN, MetroLine.KUKO, midKuko, to, t2, "空港線", "1番線", "姪浜方面・福岡空港方面"))
                }
            }
            // Case 2: Kuko <-> Nanakuma. Preferred transfer is Hakata (K11 / N18) which has beautiful same-station escalators
            else {
                val midKuko = MetroNetwork.getStationById("K11")!!
                val midNana = MetroNetwork.getStationById("N18")!!

                if (from.line == MetroLine.KUKO) {
                    val t1 = kotlin.math.abs(from.index - 10) * 2
                    legs.add(RouteLeg(LegType.TRAIN, MetroLine.KUKO, from, midKuko, t1, "空港線", "2番線", "博多・福岡空港行"))
                    legs.add(RouteLeg(LegType.TRANSFER, null, midKuko, midNana, 3, "博多駅 七隈線乗換通路 (改札内)", null, null, listOf("動く歩道・エレベーター有")))
                    val t2 = kotlin.math.abs(to.index - 17) * 2
                    legs.add(RouteLeg(LegType.TRAIN, MetroLine.NANAKUMA, midNana, to, t2, "七隈線", "4番線", "橋本行"))
                } else {
                    val t1 = kotlin.math.abs(from.index - 17) * 2
                    legs.add(RouteLeg(LegType.TRAIN, MetroLine.NANAKUMA, from, midNana, t1, "七隈線", "3番線", "博多行"))
                    legs.add(RouteLeg(LegType.TRANSFER, null, midNana, midKuko, 3, "博多駅 空港線乗換通路 (改札内)", null, null, listOf("動く歩道・エレベーター有")))
                    val t2 = kotlin.math.abs(to.index - 10) * 2
                    legs.add(RouteLeg(LegType.TRAIN, MetroLine.KUKO, midKuko, to, t2, "空港線", "1番線", "姪浜方面"))
                }
            }
        }

        return legs
    }

    private fun buildAlternativeRoute(from: Station, to: Station, preference: RouteSearchPreference): List<RouteLeg> {
        val legs = mutableListOf<RouteLeg>()

        // Alternative transfer for Kuko <-> Nanakuma is Tenjin <-> Tenjin-Minami (K08 <-> N16)
        val midKuko = MetroNetwork.getStationById("K08")!!
        val midNana = MetroNetwork.getStationById("N16")!!

        if (from.line == MetroLine.KUKO) {
            val t1 = kotlin.math.abs(from.index - 7) * 2
            legs.add(RouteLeg(LegType.TRAIN, MetroLine.KUKO, from, midKuko, t1, "空港線", "1番線", "姪浜方面"))
            legs.add(RouteLeg(LegType.TRANSFER, null, midKuko, midNana, 8, "天神地下街 徒歩連絡 (改札外乗換)", null, null, listOf("天神地下街を経由、車いす対応スロープ有")))
            val t2 = kotlin.math.abs(to.index - 15) * 2
            legs.add(RouteLeg(LegType.TRAIN, MetroLine.NANAKUMA, midNana, to, t2, "七隈線", "2番線", "橋本方面"))
        } else {
            val t1 = kotlin.math.abs(from.index - 15) * 2
            legs.add(RouteLeg(LegType.TRAIN, MetroLine.NANAKUMA, from, midNana, t1, "七隈線", "1番線", "天神南行"))
            legs.add(RouteLeg(LegType.TRANSFER, null, midNana, midKuko, 8, "天神地下街 徒歩連絡 (改札外乗換)", null, null, listOf("天神地下街を経由、車いす対応スロープ有")))
            val t2 = kotlin.math.abs(to.index - 7) * 2
            legs.add(RouteLeg(LegType.TRAIN, MetroLine.KUKO, midKuko, to, t2, "空港線", "2番線", "福岡空港行"))
        }

        return legs
    }
}
