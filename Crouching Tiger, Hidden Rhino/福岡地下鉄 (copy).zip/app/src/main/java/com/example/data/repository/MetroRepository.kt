package com.example.data.repository

import com.example.data.local.*
import kotlinx.coroutines.flow.Flow

class MetroRepository(private val database: AppDatabase) {
    val allTickets: Flow<List<TicketEntity>> = database.ticketDao().getAllTickets()
    val activeTickets: Flow<List<TicketEntity>> = database.ticketDao().getTicketsByStatus("ACTIVE")
    val purchasedTickets: Flow<List<TicketEntity>> = database.ticketDao().getTicketsByStatus("PURCHASED")
    
    val allTapEvents: Flow<List<TapEventEntity>> = database.tapEventDao().getAllTapEvents()
    val allJourneys: Flow<List<JourneyEntity>> = database.journeyDao().getAllJourneys()
    val allFavorites: Flow<List<FavoriteEntity>> = database.favoriteDao().getAllFavorites()
    val allNotifications: Flow<List<NotificationEntity>> = database.notificationDao().getAllNotifications()

    suspend fun insertTicket(ticket: TicketEntity): Long {
        return database.ticketDao().insertTicket(ticket)
    }

    suspend fun updateTicket(ticket: TicketEntity) {
        database.ticketDao().updateTicket(ticket)
    }

    suspend fun getTicketById(id: Int): TicketEntity? {
        return database.ticketDao().getTicketById(id)
    }

    suspend fun insertTapEvent(event: TapEventEntity) {
        database.tapEventDao().insertTapEvent(event)
    }

    suspend fun insertJourney(journey: JourneyEntity) {
        database.journeyDao().insertJourney(journey)
    }

    suspend fun insertFavorite(favorite: FavoriteEntity) {
        database.favoriteDao().insertFavorite(favorite)
    }

    suspend fun deleteFavorite(id: Int) {
        database.favoriteDao().deleteFavorite(id)
    }

    suspend fun insertNotification(notification: NotificationEntity) {
        database.notificationDao().insertNotification(notification)
    }

    suspend fun markAllNotificationsRead() {
        database.notificationDao().markAllAsRead()
    }
}
