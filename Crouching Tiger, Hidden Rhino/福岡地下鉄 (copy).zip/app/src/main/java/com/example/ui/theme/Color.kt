package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Japanese Transit Palette
val DarkBg = Color(0xFF121214)
val DarkSurface = Color(0xFF1E1E22)
val DarkCard = Color(0xFF26262B)
val LightBg = Color(0xFFF6F8FA)
val LightSurface = Color(0xFFFFFFFF)
val LightCard = Color(0xFFECEFF1)

// Brand Colors
val MetroPrimary = Color(0xFF005BAC) // Deep elegant navy blue
val MetroAccent = Color(0xFFE94E1B)  // Accent orange

// Fukuoka Subway Line Colors
val LineKuko = Color(0xFFEA5415)      // 空港線 Orange
val LineHakozaki = Color(0xFF0091D5)  // 箱崎線 Blue
val LineNanakuma = Color(0xFF009B4F)  // 七隈線 Green

// Status Colors
val StatusNormal = Color(0xFF2E7D32)  // 平常運転 (Green)
val StatusDelay = Color(0xFFD84315)   // 遅延・見合わせ (Orange/Red)
val StatusInfo = Color(0xFF1976D2)    // お知らせ (Blue)

// Text Colors
val TextDarkPrimary = Color(0xFFE0E0E6)
val TextDarkSecondary = Color(0xFF9090A0)
val TextLightPrimary = Color(0xFF1C1C1E)
val TextLightSecondary = Color(0xFF636366)
