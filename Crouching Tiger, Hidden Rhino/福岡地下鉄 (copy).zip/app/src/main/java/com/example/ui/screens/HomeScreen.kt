package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MetroLine
import com.example.data.model.MetroNetwork
import com.example.ui.theme.*
import com.example.viewmodel.FukuokaMetroViewModel
import com.example.viewmodel.JourneyState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    viewModel: FukuokaMetroViewModel,
    onNavigateToTab: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val liveLineDelays by viewModel.liveLineDelays.collectAsState()
    val favorites by viewModel.allFavorites.collectAsState()
    
    val timeString = remember {
        val sdf = SimpleDateFormat("M月d日 (E) HH:mm", Locale.JAPAN)
        sdf.format(Date())
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp)
    ) {
        // App Title Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "福岡地下鉄.OS",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.primary,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = timeString,
                        fontSize = 12.sp,
                        color = Color.Gray,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
                
                // Status badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (liveLineDelays[MetroLine.KUKO] ?: 0 > 0) StatusDelay.copy(alpha = 0.15f) else StatusNormal.copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (liveLineDelays[MetroLine.KUKO] ?: 0 > 0) "⚠️ 運行情報有" else "● 平常運転",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (liveLineDelays[MetroLine.KUKO] ?: 0 > 0) StatusDelay else StatusNormal
                    )
                }
            }
        }

        // Live Service Status Bulletin Card
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(16.dp)
            ) {
                Text(
                    text = "運行状況",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Gray
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                // Line Status Row: 空港線
                LineStatusRow(
                    lineName = "空港線",
                    lineColor = LineKuko,
                    statusText = if (liveLineDelays[MetroLine.KUKO] ?: 0 > 0) "一部遅延 (${liveLineDelays[MetroLine.KUKO]}分)" else "平常運転",
                    isDelayed = (liveLineDelays[MetroLine.KUKO] ?: 0) > 0,
                    onRecalculateClick = {
                        viewModel.setStartStation(MetroNetwork.getStationById("K08")) // Tenjin
                        viewModel.setEndStation(MetroNetwork.getStationById("K11")) // Hakata
                        viewModel.searchRoutes()
                        onNavigateToTab("経路")
                    }
                )

                Divider(modifier = Modifier.padding(vertical = 8.dp))

                // Line Status Row: 箱崎線
                LineStatusRow(
                    lineName = "箱崎線",
                    lineColor = LineHakozaki,
                    statusText = "平常運転",
                    isDelayed = false
                )

                Divider(modifier = Modifier.padding(vertical = 8.dp))

                // Line Status Row: 七隈線
                LineStatusRow(
                    lineName = "七隈線",
                    lineColor = LineNanakuma,
                    statusText = "平常運転",
                    isDelayed = false
                )
            }
        }

        // Prominent Call-to-action: "今、どう移動するか？"
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp)
                ) {
                    Text(
                        text = "「今、どう移動するか？」",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "目的地を入力して最適な乗車券・経路を確認します",
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.8f),
                        modifier = Modifier.padding(top = 4.dp)
                    )
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Button(
                        onClick = {
                            onNavigateToTab("経路")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = MetroPrimary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("home_search_route_button"),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("経路を検索する", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Next Journey Commute Recommendation
        item {
            Text(
                text = "次の移動",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = if (MaterialTheme.colorScheme.background == DarkBg) TextDarkPrimary else TextLightPrimary,
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }

        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        // Quick load Tenjin to Hakata commute
                        viewModel.setStartStation(MetroNetwork.getStationById("K08"))
                        viewModel.setEndStation(MetroNetwork.getStationById("K11"))
                        viewModel.searchRoutes()
                        onNavigateToTab("経路")
                    },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "おすすめの移動経路",
                            fontSize = 12.sp,
                            color = Color.Gray,
                            fontWeight = FontWeight.Bold
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(MetroPrimary.copy(alpha = 0.1f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("マイ通勤", fontSize = 10.sp, color = MetroPrimary, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("天神駅 (K08)", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Icon(imageVector = Icons.Default.ArrowForward, contentDescription = null, tint = MetroPrimary, modifier = Modifier.size(16.dp))
                        Text("博多駅 (K11)", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("所要時間", fontSize = 10.sp, color = Color.Gray)
                            Text(
                                text = if (liveLineDelays[MetroLine.KUKO] ?: 0 > 0) "約14分" else "約6分",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (liveLineDelays[MetroLine.KUKO] ?: 0 > 0) StatusDelay else MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Column {
                            Text("通常運賃", fontSize = 10.sp, color = Color.Gray)
                            Text("260円", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("次発予定", fontSize = 10.sp, color = Color.Gray)
                            Text("10:32発", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("乗換", fontSize = 10.sp, color = Color.Gray)
                            Text("なし (直通)", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (liveLineDelays[MetroLine.KUKO] ?: 0 > 0) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(StatusDelay.copy(alpha = 0.1f))
                                .padding(8.dp)
                        ) {
                            Text(
                                text = "⚠️ 空港線の遅延により、迂回経路（七隈線利用：約11分）の検討を推奨します。",
                                fontSize = 11.sp,
                                color = StatusDelay,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }

        // Saved Favorite Routes Shortcuts (Favourites)
        item {
            Text(
                text = "登録したお気に入り",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = if (MaterialTheme.colorScheme.background == DarkBg) TextDarkPrimary else TextLightPrimary,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        if (favorites.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("お気に入りは登録されていません", fontSize = 12.sp, color = Color.Gray)
                }
            }
        } else {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    favorites.forEach { favorite ->
                        Card(
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    viewModel.setStartStation(MetroNetwork.getStationById(favorite.fromStationId))
                                    viewModel.setEndStation(MetroNetwork.getStationById(favorite.toStationId))
                                    viewModel.searchRoutes()
                                    onNavigateToTab("経路")
                                },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Icon(
                                    imageVector = if (favorite.label.contains("自宅")) Icons.Default.Home else Icons.Default.Work,
                                    contentDescription = null,
                                    tint = MetroPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(favorite.label, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("${favorite.fromStationName} → ${favorite.toStationName}", fontSize = 10.sp, color = Color.Gray, modifier = Modifier.padding(top = 2.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LineStatusRow(
    lineName: String,
    lineColor: Color,
    statusText: String,
    isDelayed: Boolean,
    onRecalculateClick: () -> Unit = {}
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(lineColor)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(lineName, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
        
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = statusText,
                fontSize = 13.sp,
                color = if (isDelayed) StatusDelay else StatusNormal,
                fontWeight = FontWeight.Bold
            )
            
            if (isDelayed) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(StatusDelay)
                        .clickable { onRecalculateClick() }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text("う回路線", fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
