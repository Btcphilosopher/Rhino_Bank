package com.example.data.model

import kotlin.math.abs

enum class MetroLine(val id: String, val displayName: String, val englishName: String) {
    KUKO("kuko", "空港線", "Kuko Line"),
    HAKOZAKI("hakozaki", "箱崎線", "Hakozaki Line"),
    NANAKUMA("nanakuma", "七隈線", "Nanakuma Line")
}

data class Station(
    val id: String,
    val name: String,
    val nameEn: String,
    val code: String, // e.g. "K08"
    val line: MetroLine,
    val index: Int, // Order on the line for distance/time calculations
    val facilities: List<String> = listOf("トイレ", "コインロッカー", "エレベーター", "エスカレーター", "バリアフリー通路"),
    val exits: List<String> = listOf("東1口", "東2口", "西1口", "西2口", "博多口", "筑紫口"),
    val nearbyPlaces: List<String> = listOf("ショッピングセンター", "バスターミナル", "中央公園", "区役所")
)

object MetroNetwork {
    val stations = listOf(
        // Kuko Line (Airport Line) - K01 to K13
        Station("K01", "姪浜", "Meinohama", "K01", MetroLine.KUKO, 0, nearbyPlaces = listOf("姪浜小", "ウエストコート姪浜")),
        Station("K02", "室見", "Muromi", "K02", MetroLine.KUKO, 1, nearbyPlaces = listOf("室見川公園", "福岡高速1号線")),
        Station("K03", "藤崎", "Fujisaki", "K03", MetroLine.KUKO, 2, nearbyPlaces = listOf("早良区役所", "早良図書館", "藤崎バスターミナル")),
        Station("K04", "西新", "Nishijin", "K04", MetroLine.KUKO, 3, nearbyPlaces = listOf("西南学院大学", "西新商店街", "福岡記念病院")),
        Station("K05", "唐人町", "Tojinmachi", "K05", MetroLine.KUKO, 4, nearbyPlaces = listOf("福岡PayPayドーム", "マークイズ福岡ももち")),
        Station("K06", "大濠公園", "Ohorikoen", "Ohori Park", MetroLine.KUKO, 5, nearbyPlaces = listOf("大濠公園", "福岡市美術館", "福岡城跡")),
        Station("K07", "赤坂", "Akasaka", "K07", MetroLine.KUKO, 6, nearbyPlaces = listOf("中央区役所", "舞鶴公園", "法務局")),
        Station("K08", "天神", "Tenjin", "K08", MetroLine.KUKO, 7, nearbyPlaces = listOf("天神地下街", "岩田屋", "福岡市役所", "天神中央公園")),
        Station("K09", "中洲川端", "Nakasu-Kawabata", "K09", MetroLine.KUKO, 8, nearbyPlaces = listOf("川端通商店街", "キャナルシティ博多", "博多座")),
        Station("K10", "祇園", "Gion", "K10", MetroLine.KUKO, 9, nearbyPlaces = listOf("東長寺", "櫛田神社", "博多区役所")),
        Station("K11", "博多", "Hakata", "K11", MetroLine.KUKO, 10, nearbyPlaces = listOf("JR博多シティ", "アミュプラザ博多", "博多阪急")),
        Station("K12", "東比恵", "Higashi-Hie", "Higashi-Hie", MetroLine.KUKO, 11, nearbyPlaces = listOf("比恵公園", "山王公園")),
        Station("K13", "福岡空港", "Fukuokakuko", "Fukuoka Airport", MetroLine.KUKO, 12, nearbyPlaces = listOf("福岡空港国内線ターミナル", "福岡空港国際線")),

        // Hakozaki Line - H01 to H07 (H01 is Nakasu-Kawabata)
        Station("H01", "中洲川端", "Nakasu-Kawabata", "H01", MetroLine.HAKOZAKI, 0, nearbyPlaces = listOf("川端通商店街", "キャナルシティ博多", "博多座")),
        Station("H02", "呉服町", "Gofukumachi", "H02", MetroLine.HAKOZAKI, 1, nearbyPlaces = listOf("呉服町ビジネスセンター", "博多小学校")),
        Station("H03", "千代県庁口", "Chiyo-Kenchomae", "H03", MetroLine.HAKOZAKI, 2, nearbyPlaces = listOf("福岡県庁", "福岡県警察本部")),
        Station("H04", "馬出九大病院前", "Maidashi-Kyudaibyoinmae", "H04", MetroLine.HAKOZAKI, 3, nearbyPlaces = listOf("九州大学病院", "県立図書館")),
        Station("H05", "箱崎宮前", "Hakozaki-Miyamae", "H05", MetroLine.HAKOZAKI, 4, nearbyPlaces = listOf("筥崎宮", "東区役所")),
        Station("H06", "箱崎九大前", "Hakozaki-Kyudaimae", "H06", MetroLine.HAKOZAKI, 5, nearbyPlaces = listOf("旧九州大学箱崎キャンパス")),
        Station("H07", "Kaizuka", "Kaizuka", "H07", MetroLine.HAKOZAKI, 6, nearbyPlaces = listOf("貝塚公園", "西鉄貝塚駅")),

        // Nanakuma Line - N01 to N18
        Station("N01", "橋本", "Hashimoto", "N01", MetroLine.NANAKUMA, 0, nearbyPlaces = listOf("木の葉モール橋本", "橋本中央公園")),
        Station("N02", "次郎丸", "Jiroyo", "N02", MetroLine.NANAKUMA, 1, nearbyPlaces = listOf("次郎丸中学校")),
        Station("N03", "賀茂", "Kamo", "N03", MetroLine.NANAKUMA, 2, nearbyPlaces = listOf("賀茂神社", "金屑川")),
        Station("N04", "野芥", "Noke", "N04", MetroLine.NANAKUMA, 3, nearbyPlaces = listOf("イオンスタイル野芥")),
        Station("N05", "梅林", "Umebayashi", "N05", MetroLine.NANAKUMA, 4, nearbyPlaces = listOf("福岡大学梅林グラウンド")),
        Station("N06", "福大前", "Fukudaimae", "N06", MetroLine.NANAKUMA, 5, nearbyPlaces = listOf("福岡大学", "福岡大学病院")),
        Station("N07", "七隈", "Nanakuma", "N07", MetroLine.NANAKUMA, 6, nearbyPlaces = listOf("七隈小学校", "西南杜の湖畔公園")),
        Station("N08", "金山", "Kanayama", "N08", MetroLine.NANAKUMA, 7, nearbyPlaces = listOf("金山団地", "七隈東公園")),
        Station("N09", "茶山", "Chayama", "N09", MetroLine.NANAKUMA, 8, nearbyPlaces = listOf("城南体育館", "茶山幼稚園")),
        Station("N10", "別府", "Befu", "N10", MetroLine.NANAKUMA, 9, nearbyPlaces = listOf("城南区役所", "別府小学校")),
        Station("N11", "六本松", "Ropponmatsu", "N11", MetroLine.NANAKUMA, 10, nearbyPlaces = listOf("福岡市科学館", "九州大学六本松地区跡地")),
        Station("N12", "桜坂", "Sakurazaka", "N12", MetroLine.NANAKUMA, 11, nearbyPlaces = listOf("南公園", "福岡市動植物園")),
        Station("N13", "薬院大通", "Yakuin-odori", "Yakuin-odori", MetroLine.NANAKUMA, 12, nearbyPlaces = listOf("浄水通り", "福岡中央高校")),
        Station("N14", "薬院", "Yakuin", "N14", MetroLine.NANAKUMA, 13, nearbyPlaces = listOf("西鉄薬院駅", "電気ビル")),
        Station("N15", "渡辺通", "Watanabe-dori", "Watanabe-dori", MetroLine.NANAKUMA, 14, nearbyPlaces = listOf("サンセルコ", "ホテルニューオータニ博多")),
        Station("N16", "天神南", "Tenjin-Minami", "N16", MetroLine.NANAKUMA, 15, nearbyPlaces = listOf("天神地下街", "大丸福岡天神店", "エルガーラ")),
        Station("N17", "櫛田神社前", "Kushida-Ginja-mae", "N17", MetroLine.NANAKUMA, 16, nearbyPlaces = listOf("櫛田神社", "キャナルシティ博多", "博多町家ふるさと館")),
        Station("N18", "博多", "Hakata", "N18", MetroLine.NANAKUMA, 17, nearbyPlaces = listOf("JR博多シティ", "博多阪急", "アミュプラザ博多"))
    )

    // Gets station by id (e.g. "K08") or by name (matching current line where context permits)
    fun getStationById(id: String): Station? {
        return stations.find { it.id == id }
    }

    fun getStationsForLine(line: MetroLine): List<Station> {
        return stations.filter { it.line == line }.sortedBy { it.index }
    }

    // Calculates standard fare based on the number of stations traversed
    // Standard Fukuoka City Subway Fare structure (approximate)
    fun calculateFare(fromStation: Station, toStation: Station): Int {
        if (fromStation.name == toStation.name) return 0
        
        // Simple zone fare logic based on approximate transit stops
        val stops = if (fromStation.line == toStation.line) {
            abs(fromStation.index - toStation.index)
        } else {
            // If they are on different lines, estimate stops through known transfers:
            // Transfer 1: Nakasu-Kawabata (K09 / H01)
            // Transfer 2: Tenjin <-> Tenjin-Minami (K08 <-> N16) (with safe 500m pedestrian transfer)
            // Transfer 3: Hakata (K11 <-> N18)
            when {
                // Kuko <-> Hakozaki transfer at Nakasu-Kawabata
                (fromStation.line == MetroLine.KUKO && toStation.line == MetroLine.HAKOZAKI) ||
                (fromStation.line == MetroLine.HAKOZAKI && toStation.line == MetroLine.KUKO) -> {
                    val kukoStat = if (fromStation.line == MetroLine.KUKO) fromStation else toStation
                    val hakoStat = if (fromStation.line == MetroLine.HAKOZAKI) fromStation else toStation
                    abs(kukoStat.index - 8) + abs(hakoStat.index - 0) // K09 index is 8, H01 index is 0
                }
                // Kuko <-> Nanakuma transfer at Hakata (or Tenjin/Tenjin-Minami)
                (fromStation.line == MetroLine.KUKO && toStation.line == MetroLine.NANAKUMA) ||
                (fromStation.line == MetroLine.NANAKUMA && toStation.line == MetroLine.KUKO) -> {
                    val kukoStat = if (fromStation.line == MetroLine.KUKO) fromStation else toStation
                    val nanaStat = if (fromStation.line == MetroLine.NANAKUMA) fromStation else toStation
                    
                    // Route via Hakata transfer (K11 index 10 <-> N18 index 17) or Tenjin (K08 index 7 <-> N16 index 15)
                    val viaHakata = abs(kukoStat.index - 10) + abs(nanaStat.index - 17)
                    val viaTenjin = abs(kukoStat.index - 7) + abs(nanaStat.index - 15)
                    minOf(viaHakata, viaTenjin)
                }
                // Hakozaki <-> Nanakuma via Nakasu-Kawabata -> Kuko -> Nanakuma
                else -> {
                    val hakoStat = if (fromStation.line == MetroLine.HAKOZAKI) fromStation else toStation
                    val nanaStat = if (fromStation.line == MetroLine.NANAKUMA) fromStation else toStation
                    val stopsToTransfer = abs(hakoStat.index - 0) // H01 Nakasu-Kawabata
                    val kukoStops = abs(8 - 10) // K09 Nakasu-Kawabata to K11 Hakata
                    val nanaStops = abs(nanaStat.index - 17) // N18 Hakata
                    stopsToTransfer + kukoStops + nanaStops
                }
            }
        }

        return when {
            stops <= 1 -> 210
            stops <= 3 -> 260
            stops <= 5 -> 300
            stops <= 7 -> 340
            else -> 380
        }
    }
}
