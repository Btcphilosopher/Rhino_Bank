package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MetroLine
import com.example.data.model.MetroNetwork
import com.example.simulator.Train
import com.example.ui.theme.*

@OptIn(ExperimentalTextApi::class)
@Composable
fun MetroMapCanvas(
    trains: List<Train>,
    selectedStationId: String? = null,
    onStationSelect: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val textMeasurer = rememberTextMeasurer()
    val isDark = MaterialTheme.colorScheme.background == DarkBg
    
    // Simple zooming and panning gesture state
    var scale by remember { mutableStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    val state = rememberTransformableState { zoomChange, offsetChange, _ ->
        scale = (scale * zoomChange).coerceIn(0.8f, 3f)
        offset += offsetChange
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(280.dp)
            .background(if (MaterialTheme.colorScheme.background == DarkBg) DarkSurface else Color(0xFFF0F4F8))
            .transformable(state = state)
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer(
                    scaleX = scale,
                    scaleY = scale,
                    translationX = offset.x,
                    translationY = offset.y
                )
        ) {
            val width = size.width
            val height = size.height
            val centerX = width / 2
            val centerY = height / 2

            // Mapping coordinate positions for stations to look like Fukuoka network
            // Kuko Line (Orange): Left to Right diagonally down-ish
            val kukoCoords = mapOf(
                "K01" to Offset(centerX - 160, centerY - 60),  // Meinohama
                "K04" to Offset(centerX - 100, centerY - 40),  // Nishijin
                "K06" to Offset(centerX - 50, centerY - 20),   // Ohori Park
                "K08" to Offset(centerX, centerY),             // Tenjin
                "K09" to Offset(centerX + 40, centerY + 10),   // Nakasu-Kawabata
                "K11" to Offset(centerX + 100, centerY + 40),  // Hakata
                "K13" to Offset(centerX + 160, centerY + 80)   // Airport
            )

            // Hakozaki Line (Blue): Shoots Up-Right from Nakasu-Kawabata
            val hakoCoords = mapOf(
                "H01" to Offset(centerX + 40, centerY + 10),   // Nakasu-Kawabata
                "H03" to Offset(centerX + 80, centerY - 30),   // Chiyo-Kenchomae
                "H05" to Offset(centerX + 120, centerY - 70),  // Hakozaki-Miyamae
                "H07" to Offset(centerX + 160, centerY - 110)  // Kaizuka
            )

            // Nanakuma Line (Green): Arc from Bottom-Left to Hakata
            val nanaCoords = mapOf(
                "N01" to Offset(centerX - 160, centerY + 80),  // Hashimoto
                "N06" to Offset(centerX - 100, centerY + 100), // Fukudaimae
                "N11" to Offset(centerX - 40, centerY + 70),   // Ropponmatsu
                "N14" to Offset(centerX, centerY + 40),        // Yakuin
                "N16" to Offset(centerX + 10, centerY + 25),   // Tenjin-Minami
                "N17" to Offset(centerX + 60, centerY + 30),   // Kushida Shrine
                "N18" to Offset(centerX + 100, centerY + 40)   // Hakata
            )

            // Draw line tracks
            // 1. Kuko Line
            val kukoKeys = kukoCoords.keys.toList()
            for (i in 0 until kukoKeys.size - 1) {
                drawLine(
                    color = LineKuko,
                    start = kukoCoords[kukoKeys[i]]!!,
                    end = kukoCoords[kukoKeys[i+1]]!!,
                    strokeWidth = 6.dp.toPx()
                )
            }

            // 2. Hakozaki Line
            val hakoKeys = hakoCoords.keys.toList()
            for (i in 0 until hakoKeys.size - 1) {
                drawLine(
                    color = LineHakozaki,
                    start = hakoCoords[hakoKeys[i]]!!,
                    end = hakoCoords[hakoKeys[i+1]]!!,
                    strokeWidth = 6.dp.toPx()
                )
            }

            // 3. Nanakuma Line
            val nanaKeys = nanaCoords.keys.toList()
            for (i in 0 until nanaKeys.size - 1) {
                drawLine(
                    color = LineNanakuma,
                    start = nanaCoords[nanaKeys[i]]!!,
                    end = nanaCoords[nanaKeys[i+1]]!!,
                    strokeWidth = 6.dp.toPx()
                )
            }

            // Draw transfer indicator links (dashed grey)
            // Tenjin (K08) <-> Tenjin-Minami (N16)
            drawLine(
                color = Color.Gray,
                start = kukoCoords["K08"]!!,
                end = nanaCoords["N16"]!!,
                strokeWidth = 3.dp.toPx(),
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
            )

            // Draw Stations nodes
            val allNodes = kukoCoords + hakoCoords + nanaCoords
            allNodes.forEach { (id, offset) ->
                val station = MetroNetwork.getStationById(id) ?: return@forEach
                val isSelected = selectedStationId == id
                
                // Outer ring
                drawCircle(
                    color = if (isSelected) MetroAccent else Color.White,
                    radius = if (isSelected) 10.dp.toPx() else 7.dp.toPx(),
                    center = offset,
                    style = Stroke(width = 3.dp.toPx())
                )
                // Inner center dot
                drawCircle(
                    color = when (station.line) {
                        MetroLine.KUKO -> LineKuko
                        MetroLine.HAKOZAKI -> LineHakozaki
                        MetroLine.NANAKUMA -> LineNanakuma
                    },
                    radius = if (isSelected) 6.dp.toPx() else 4.dp.toPx(),
                    center = offset
                )

                // Station Label Text (discreet elegant typography)
                drawText(
                    textMeasurer = textMeasurer,
                    text = station.name,
                    topLeft = offset + Offset(8.dp.toPx(), -12.dp.toPx()),
                    style = androidx.compose.ui.text.TextStyle(
                        color = if (isDark) TextDarkPrimary else TextLightPrimary,
                        fontSize = 8.sp
                    )
                )
            }

            // Draw simulated live trains moving
            trains.forEach { train ->
                // Interpolate train position between current and next station coords
                val startOffset = allNodes[train.currentStationId]
                val endOffset = allNodes[train.nextStationId]
                
                if (startOffset != null && endOffset != null) {
                    // Let's position it at 50% between stations for simple rendering
                    val trainPos = Offset(
                        x = (startOffset.x + endOffset.x) / 2f,
                        y = (startOffset.y + endOffset.y) / 2f
                    )

                    // Draw Train marker
                    drawCircle(
                        color = when (train.line) {
                            MetroLine.KUKO -> LineKuko
                            MetroLine.HAKOZAKI -> LineHakozaki
                            MetroLine.NANAKUMA -> LineNanakuma
                        },
                        radius = 8.dp.toPx(),
                        center = trainPos
                    )
                    // Inner white triangle/symbol indicating motion
                    drawCircle(
                        color = Color.White,
                        radius = 3.dp.toPx(),
                        center = trainPos
                    )
                }
            }
        }
    }
}
