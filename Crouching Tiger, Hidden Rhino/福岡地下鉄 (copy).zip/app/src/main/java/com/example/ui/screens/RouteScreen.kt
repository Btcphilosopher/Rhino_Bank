package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.theme.*
import com.example.viewmodel.FukuokaMetroViewModel
import com.example.viewmodel.JourneyState

@Composable
fun RouteScreen(
    viewModel: FukuokaMetroViewModel,
    modifier: Modifier = Modifier
) {
    val startStation by viewModel.startStation.collectAsState()
    val endStation by viewModel.endStation.collectAsState()
    val searchPreference by viewModel.searchPreference.collectAsState()
    val routeAlternatives by viewModel.routeAlternatives.collectAsState()
    val selectedRoute by viewModel.selectedRoute.collectAsState()
    val journeyState by viewModel.journeyState.collectAsState()

    var showStartPicker by remember { mutableStateOf(false) }
    var showEndPicker by remember { mutableStateOf(false) }
    var isAdult by remember { mutableStateOf(true) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp)
    ) {
        // Form Title
        item {
            Text(
                text = "経路検索・旅程設計",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = if (MaterialTheme.colorScheme.background == DarkBg) TextDarkPrimary else TextLightPrimary
            )
        }

        // Stations inputs
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Departure Input Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (MaterialTheme.colorScheme.background == DarkBg) DarkBg else LightBg)
                        .clickable { showStartPicker = true }
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(MetroAccent)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("出発地", fontSize = 10.sp, color = Color.Gray)
                            Text(
                                text = startStation?.let { "${it.name} (${it.code})" } ?: "駅を選択してください",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Icon(imageVector = Icons.Default.SwapVert, contentDescription = "Swap", tint = Color.Gray)
                }

                // Swap Button trigger
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ) {
                    IconButton(
                        onClick = {
                            val temp = startStation
                            viewModel.setStartStation(endStation)
                            viewModel.setEndStation(temp)
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(imageVector = Icons.Default.SwapVert, contentDescription = "Swap stations", tint = MetroPrimary)
                    }
                }

                // Destination Input Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (MaterialTheme.colorScheme.background == DarkBg) DarkBg else LightBg)
                        .clickable { showEndPicker = true }
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(MetroPrimary)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("到着地", fontSize = 10.sp, color = Color.Gray)
                            Text(
                                text = endStation?.let { "${it.name} (${it.code})" } ?: "駅を選択してください",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Icon(imageVector = Icons.Default.LocationOn, contentDescription = "Destination", tint = Color.Gray)
                }
            }
        }

        // Preference Filter options
        item {
            Column {
                Text(
                    text = "検索オプション",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Gray,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(
                        RouteSearchPreference.FASTEST to "最短",
                        RouteSearchPreference.FEWER_TRANSFERS to "乗換少",
                        RouteSearchPreference.CHEAPEST to "安い",
                        RouteSearchPreference.BARRIER_FREE to "段差無"
                    ).forEach { (pref, label) ->
                        val isSelected = searchPreference == pref
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) MetroPrimary else MaterialTheme.colorScheme.surface)
                                .border(
                                    1.dp,
                                    if (isSelected) MetroPrimary else Color.LightGray.copy(alpha = 0.5f),
                                    RoundedCornerShape(6.dp)
                                )
                                .clickable { viewModel.setPreference(pref) }
                                .padding(vertical = 8.dp, horizontal = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }

        // Adult / child selector & search button
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .padding(4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isAdult) MetroPrimary.copy(alpha = 0.1f) else Color.Transparent)
                            .clickable { isAdult = true }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text("大人", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (isAdult) MetroPrimary else Color.Gray)
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (!isAdult) MetroPrimary.copy(alpha = 0.1f) else Color.Transparent)
                            .clickable { isAdult = false }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text("小児", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (!isAdult) MetroPrimary else Color.Gray)
                    }
                }

                Button(
                    onClick = { viewModel.searchRoutes() },
                    colors = ButtonDefaults.buttonColors(containerColor = MetroPrimary),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .height(44.dp)
                        .testTag("route_search_action_button")
                ) {
                    Text("検索開始", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Route Alternatives List results
        if (journeyState == JourneyState.ROUTE_SEARCHED || journeyState == JourneyState.ROUTE_SELECTED) {
            item {
                Text(
                    text = "検索結果一覧",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Gray,
                    modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                )
            }

            if (routeAlternatives.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("一致する経路が見つかりませんでした", fontSize = 12.sp, color = Color.Gray)
                    }
                }
            } else {
                items(routeAlternatives) { alt ->
                    val isSelected = selectedRoute?.id == alt.id
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = if (isSelected) 2.dp else 0.dp,
                                color = if (isSelected) MetroPrimary else Color.Transparent,
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable { viewModel.selectRoute(alt) },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(MetroPrimary)
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text("ROUTE 0${alt.id}", fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                    }
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(if (alt.isDelayed) StatusDelay.copy(alpha = 0.1f) else StatusNormal.copy(alpha = 0.1f))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = if (alt.isDelayed) "遅延有 (+${alt.delayMinutes}分)" else "定刻運行",
                                            fontSize = 10.sp,
                                            color = if (alt.isDelayed) StatusDelay else StatusNormal,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Text("${alt.routeTypeLabel}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MetroPrimary)
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("所要時間", fontSize = 10.sp, color = Color.Gray)
                                    Text("約 ${alt.totalDurationMinutes}分", fontSize = 20.sp, fontWeight = FontWeight.Black, color = if (alt.isDelayed) StatusDelay else MaterialTheme.colorScheme.onSurface)
                                }
                                Column {
                                    Text("乗換回数", fontSize = 10.sp, color = Color.Gray)
                                    Text("${alt.transfersCount}回", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                }
                                Column {
                                    Text("運賃", fontSize = 10.sp, color = Color.Gray)
                                    Text("¥${alt.totalFare}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MetroAccent)
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Simplified Station leg list
                            Column(
                                verticalArrangement = Arrangement.spacedBy(4.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (MaterialTheme.colorScheme.background == DarkBg) DarkBg else LightBg)
                                    .padding(12.dp)
                            ) {
                                alt.legs.forEach { leg ->
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(12.dp)
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(leg.line?.let { when (it) {
                                                    MetroLine.KUKO -> LineKuko
                                                    MetroLine.HAKOZAKI -> LineHakozaki
                                                    MetroLine.NANAKUMA -> LineNanakuma
                                                } } ?: Color.Gray)
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text(
                                            text = "${leg.fromStation.name} (${leg.fromStation.code}) → ${leg.toStation.name} (${leg.toStation.code})",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Spacer(modifier = Modifier.weight(1f))
                                        Text("${leg.durationMinutes}分", fontSize = 12.sp, color = Color.Gray)
                                    }
                                }
                            }

                            if (isSelected) {
                                Spacer(modifier = Modifier.height(12.dp))
                                Button(
                                    onClick = { viewModel.selectTicketProduct() },
                                    colors = ButtonDefaults.buttonColors(containerColor = MetroAccent),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("route_confirm_button"),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("この経路を選択してチケット購入へ", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal dialogue station picker: Start station
    if (showStartPicker) {
        StationPickerDialog(
            title = "出発駅を選択",
            onDismiss = { showStartPicker = false },
            onSelect = {
                viewModel.setStartStation(it)
                showStartPicker = false
            }
        )
    }

    // Modal dialogue station picker: End station
    if (showEndPicker) {
        StationPickerDialog(
            title = "到着駅を選択",
            onDismiss = { showEndPicker = false },
            onSelect = {
                viewModel.setEndStation(it)
                showEndPicker = false
            }
        )
    }
}

@Composable
fun StationPickerDialog(
    title: String,
    onDismiss: () -> Unit,
    onSelect: (Station) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp) },
        text = {
            Box(modifier = Modifier.height(320.dp)) {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(MetroNetwork.stations.distinctBy { it.name }) { station ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onSelect(station) }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(16.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(when (station.line) {
                                        MetroLine.KUKO -> LineKuko
                                        MetroLine.HAKOZAKI -> LineHakozaki
                                        MetroLine.NANAKUMA -> LineNanakuma
                                    }),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(station.code.take(1), color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "${station.name} (${station.code})",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("キャンセル")
            }
        }
    )
}
