package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tickets")
data class TicketEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val movieId: String,
    val movieTitle: String,
    val moviePosterResId: Int,
    val cinemaId: String,
    val cinemaName: String,
    val sessionTime: String,
    val sessionDate: String,
    val sessionHall: String,
    val seats: String, // comma-separated seats, e.g., "5排6座,5排7座"
    val totalPrice: Int,
    val ticketCode: String,
    val purchaseTime: Long = System.currentTimeMillis()
)
