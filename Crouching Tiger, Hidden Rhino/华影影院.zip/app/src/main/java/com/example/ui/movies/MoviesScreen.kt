package com.example.ui.movies

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Movie
import com.example.navigation.Screen
import com.example.ui.components.RatingBadge
import com.example.ui.theme.CinemaRed
import com.example.ui.theme.DarkCard
import com.example.ui.theme.TextGrey
import com.example.ui.theme.TextWhite
import com.example.ui.viewmodel.CinemaViewModel

@Composable
fun MoviesScreen(
    viewModel: CinemaViewModel,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(0) }
    val tabTitles = listOf("正在热映", "即将上映")

    val hotMovies = viewModel.movies.filter { it.isHot }
    val upcomingMovies = viewModel.movies.filter { it.isUpcoming }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // App bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF16161C))
                .padding(top = 40.dp, bottom = 12.dp)
        ) {
            Text(
                text = "电影",
                color = TextWhite,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Tabs
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color(0xFF16161C),
            contentColor = CinemaRed,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = CinemaRed,
                    height = 3.dp
                )
            },
            divider = {}
        ) {
            tabTitles.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = {
                        Text(
                            text = title,
                            fontSize = 15.sp,
                            fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTab == index) TextWhite else TextGrey
                        )
                    },
                    modifier = Modifier.testTag("movie_tab_$index")
                )
            }
        }

        // Grids
        val currentMovies = if (selectedTab == 0) hotMovies else upcomingMovies

        if (currentMovies.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(text = "暂无电影数据", color = TextGrey, fontSize = 14.sp)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(currentMovies) { movie ->
                    GridMovieCard(
                        movie = movie,
                        isUpcoming = selectedTab == 1,
                        onClick = {
                            viewModel.selectMovie(movie)
                            onNavigate(Screen.MovieDetail(movie.id))
                        },
                        onActionClick = {
                            viewModel.selectMovie(movie)
                            if (selectedTab == 0) {
                                // Go to movie details to choose cinema
                                onNavigate(Screen.MovieDetail(movie.id))
                            } else {
                                // Simulated toggle 'want to see'
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun GridMovieCard(
    movie: Movie,
    isUpcoming: Boolean,
    onClick: () -> Unit,
    onActionClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(240.dp)
                .clip(RoundedCornerShape(12.dp))
                .border(1.dp, Color(0xFF2E2E36), RoundedCornerShape(12.dp))
        ) {
            Image(
                painter = painterResource(id = movie.posterResId),
                contentDescription = movie.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            if (!isUpcoming) {
                RatingBadge(
                    rating = movie.rating,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "《${movie.title}》",
            color = TextWhite,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )

        Text(
            text = if (isUpcoming) "${movie.releaseDate}上映" else "${movie.genres} | ${movie.duration}分钟",
            color = if (isUpcoming) CinemaRed else TextGrey,
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 2.dp, bottom = 6.dp)
        )

        Button(
            onClick = onActionClick,
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isUpcoming) Color(0xFF1C1C24) else CinemaRed,
                contentColor = if (isUpcoming) CinemaRed else Color.White
            ),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(34.dp)
                .then(
                    if (isUpcoming) Modifier.border(
                        0.5.dp,
                        CinemaRed,
                        RoundedCornerShape(8.dp)
                    ) else Modifier
                ),
            contentPadding = PaddingValues(0.dp)
        ) {
            Text(
                text = if (isUpcoming) "想看" else "购票",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
