package com.example.ui.tickets

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.navigation.Screen
import com.example.ui.theme.CinemaRed
import com.example.ui.theme.DarkCard
import com.example.ui.theme.TextGrey
import com.example.ui.theme.TextWhite
import com.example.ui.viewmodel.CinemaViewModel

@Composable
fun TicketDetailScreen(
    ticketId: Int,
    isJustPurchased: Boolean,
    viewModel: CinemaViewModel,
    onNavigate: (Screen) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val tickets by viewModel.bookedTickets.collectAsState()
    val ticket = tickets.firstOrNull { it.id == ticketId }

    if (ticket == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("未找到该电影票", color = TextGrey)
        }
        return
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // App Bar
        Surface(
            color = Color(0xFF16161C),
            tonalElevation = 4.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .statusBarsPadding()
                    .fillMaxWidth()
                    .padding(vertical = 12.dp, horizontal = 16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(DarkCard)
                        .clickable {
                            if (isJustPurchased) {
                                onNavigate(Screen.Home)
                            } else {
                                onBack()
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = TextWhite,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(16.dp))

                Text(
                    text = if (isJustPurchased) "购票成功" else "电影票详情",
                    color = TextWhite,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Success header icon (only shown when just purchased)
            if (isJustPurchased) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(bottom = 20.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Success",
                        tint = Color(0xFF4CAF50),
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "您已成功购买电影票！",
                        color = TextWhite,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "祝您观影愉快",
                        color = TextGrey,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }

            // High-Tech Digital Cinema Ticket Container
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(DarkCard)
                    .border(0.5.dp, Color(0xFF2E2E36), RoundedCornerShape(16.dp))
                    .testTag("digital_ticket")
            ) {
                Column {
                    // Top Section - Movie Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Image(
                            painter = painterResource(id = ticket.moviePosterResId),
                            contentDescription = ticket.movieTitle,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(64.dp, 88.dp)
                                .clip(RoundedCornerShape(8.dp))
                        )

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "华影影院",
                                color = CinemaRed,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "《${ticket.movieTitle}》",
                                color = TextWhite,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = ticket.sessionHall,
                                color = TextWhite.copy(alpha = 0.9f),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    // Ticket Side Cutouts & Dotted Line
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // Left semi-circle cutout
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .background(
                                    MaterialTheme.colorScheme.background,
                                    shape = RoundedCornerShape(topEnd = 12.dp, bottomEnd = 12.dp)
                                )
                                .border(
                                    0.5.dp, Color(0xFF2E2E36),
                                    shape = RoundedCornerShape(topEnd = 12.dp, bottomEnd = 12.dp)
                                )
                        )

                        // Dotted Line
                        Canvas(
                            modifier = Modifier
                                .weight(1f)
                                .height(1.dp)
                                .padding(horizontal = 10.dp)
                        ) {
                            drawLine(
                                color = Color(0xFF2E2E36),
                                start = Offset(0f, 0f),
                                end = Offset(size.width, 0f),
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f),
                                strokeWidth = 2f
                            )
                        }

                        // Right semi-circle cutout
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .background(
                                    MaterialTheme.colorScheme.background,
                                    shape = RoundedCornerShape(topStart = 12.dp, bottomStart = 12.dp)
                                )
                                .border(
                                    0.5.dp, Color(0xFF2E2E36),
                                    shape = RoundedCornerShape(topStart = 12.dp, bottomStart = 12.dp)
                                )
                        )
                    }

                    // Middle Section - Date & Time Details
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(modifier = Modifier.fillMaxWidth()) {
                            TicketDetailItem(label = "日期", value = ticket.sessionDate, modifier = Modifier.weight(1f))
                            TicketDetailItem(label = "时间", value = ticket.sessionTime, modifier = Modifier.weight(1f))
                        }

                        Row(modifier = Modifier.fillMaxWidth()) {
                            TicketDetailItem(label = "座位", value = ticket.seats, modifier = Modifier.weight(1f))
                            TicketDetailItem(label = "影院", value = ticket.cinemaName, modifier = Modifier.weight(1f))
                        }
                    }

                    HorizontalDivider(color = Color(0xFF2E2E36), modifier = Modifier.padding(horizontal = 20.dp))

                    // Bottom Section - Ticket Code, Barcode & QR Mockup
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "取票码",
                            color = TextGrey,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = ticket.ticketCode,
                            color = TextWhite,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 4.sp,
                            fontFamily = FontFamily.Monospace
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        // High fidelity barcode mockup
                        Canvas(
                            modifier = Modifier
                                .width(220.dp)
                                .height(50.dp)
                        ) {
                            val lineCount = 38
                            val seed = ticket.ticketCode.hashCode()
                            val random = java.util.Random(seed.toLong())

                            var currentX = 0f
                            val maxWidth = size.width
                            val step = maxWidth / lineCount

                            for (i in 0 until lineCount) {
                                // alternate between drawing black-filled bars and space
                                val isBar = random.nextBoolean()
                                val barWidth = if (random.nextBoolean()) step * 1.5f else step * 0.6f

                                if (isBar) {
                                    drawRect(
                                        color = TextWhite.copy(alpha = 0.9f),
                                        topLeft = Offset(currentX, 0f),
                                        size = Size(barWidth, size.height)
                                    )
                                }
                                currentX += step
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        // QR Code canvas mockup (High tech matrix)
                        Box(
                            modifier = Modifier
                                .background(Color.White, RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Canvas(modifier = Modifier.size(120.dp)) {
                                val seed = ticket.ticketCode.hashCode()
                                val random = java.util.Random(seed.toLong())

                                val gridSize = 15
                                val blockSize = size.width / gridSize

                                // Draw simulated QR code
                                for (row in 0 until gridSize) {
                                    for (col in 0 until gridSize) {
                                        // Draw corner tracking squares
                                        val isTracker = (row < 4 && col < 4) ||
                                                (row < 4 && col >= gridSize - 4) ||
                                                (row >= gridSize - 4 && col < 4)

                                        if (isTracker) {
                                            // Frame tracking outer square
                                            val isOuter = row == 0 || row == 3 || col == 0 || col == 3 ||
                                                    (row == 0 && col >= gridSize - 4) || (row == 3 && col >= gridSize - 4) ||
                                                    (col == gridSize - 4 && row < 4) || (col == gridSize - 1 && row < 4) ||
                                                    (row == gridSize - 4 && col < 4) || (row == gridSize - 1 && col < 4) ||
                                                    (col == 0 && row >= gridSize - 4) || (col == 3 && row >= gridSize - 4)

                                            val isCenter = (row == 1 && col == 1) ||
                                                    (row == 1 && col == gridSize - 3) ||
                                                    (row == gridSize - 3 && col == 1) ||
                                                    (row == 2 && col == 2) ||
                                                    (row == 2 && col == gridSize - 2) ||
                                                    (row == gridSize - 2 && col == 2)

                                            if (isOuter || isCenter) {
                                                drawRect(
                                                    color = Color.Black,
                                                    topLeft = Offset(col * blockSize, row * blockSize),
                                                    size = Size(blockSize + 0.5f, blockSize + 0.5f)
                                                )
                                            }
                                        } else {
                                            // Regular matrix noise
                                            if (random.nextBoolean()) {
                                                drawRect(
                                                    color = Color.Black,
                                                    topLeft = Offset(col * blockSize, row * blockSize),
                                                    size = Size(blockSize + 0.5f, blockSize + 0.5f)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Action buttons
            if (isJustPurchased) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Button(
                        onClick = { onNavigate(Screen.Home) },
                        colors = ButtonDefaults.buttonColors(containerColor = DarkCard, contentColor = TextWhite),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .border(0.5.dp, Color(0xFF2E2E36), RoundedCornerShape(10.dp))
                    ) {
                        Icon(imageVector = Icons.Default.Home, contentDescription = "Home", modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("返回首页", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { onNavigate(Screen.Profile) },
                        colors = ButtonDefaults.buttonColors(containerColor = CinemaRed, contentColor = Color.White),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Text("查看我的电影票", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun TicketDetailItem(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier.padding(vertical = 4.dp)) {
        Text(
            text = label,
            color = TextGrey,
            fontSize = 11.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = value,
            color = TextWhite,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
