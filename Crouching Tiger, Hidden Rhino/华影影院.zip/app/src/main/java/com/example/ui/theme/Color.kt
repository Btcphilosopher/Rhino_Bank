package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CinemaRed = Color(0xFFE50914)
val CinemaRedPressed = Color(0xFFB8070F)
val DarkBackground = Color(0xFF0C0C0E)
val DarkSurface = Color(0xFF16161A)
val DarkCard = Color(0xFF222228)
val BorderGrey = Color(0xFF2E2E36)
val TextWhite = Color(0xFFFFFFFF)
val TextGrey = Color(0xFF9E9EA8)
val RatingGold = Color(0xFFFFB300)
val SeatAvailable = Color(0xFF42424F)
val SeatSelected = Color(0xFFE50914)
val SeatSold = Color(0xFF222228)
val SeatLabelSold = Color(0xFF555562)
