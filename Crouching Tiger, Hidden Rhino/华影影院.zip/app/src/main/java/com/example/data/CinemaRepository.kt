package com.example.data

import com.example.R
import com.example.model.Cinema
import com.example.model.Movie
import com.example.model.ShowSession
import kotlinx.coroutines.flow.Flow

class CinemaRepository(private val ticketDao: TicketDao) {

    val allTickets: Flow<List<TicketEntity>> = ticketDao.getAllTickets()

    suspend fun insertTicket(ticket: TicketEntity): Long {
        return ticketDao.insertTicket(ticket)
    }

    suspend fun getTicketById(id: Int): TicketEntity? {
        return ticketDao.getTicketById(id)
    }

    suspend fun deleteTicketById(id: Int) {
        ticketDao.deleteTicketById(id)
    }

    // Static Mock Data for Movies
    val movies: List<Movie> = listOf(
        Movie(
            id = "m1",
            title = "星海计划",
            rating = 9.1,
            posterResId = R.drawable.poster_star_sea,
            releaseDate = "2026年9月20日",
            duration = 132,
            genres = "科幻 / 剧情",
            director = "张某某",
            cast = listOf("李某某", "王某某", "陈某某"),
            description = "在人类面临星系危机的边缘，一项被命名为‘星海计划’的秘密太空探测项目启动。科学家们必须穿越未知星域，寻找文明繁衍的新家园，同时面对来自宇宙深处的神秘力量与人性终极拷问。",
            isUpcoming = false,
            isHot = true
        ),
        Movie(
            id = "m2",
            title = "长安2099",
            rating = 8.9,
            posterResId = R.drawable.poster_changan_2099,
            releaseDate = "2026年10月1日",
            duration = 125,
            genres = "赛博朋克 / 动作",
            director = "李某某",
            cast = listOf("赵某某", "钱某某", "孙某某"),
            description = "公元2099年，新西安市改名为长安市。霓虹闪烁的巨型飞檐楼宇、虚拟全息投影的古装诗仙在巨幅屏幕上吟诗。在底层江湖中，一个无名义体浪客揭开了一个企图控制全城大局的巨无霸科技集团的惊天阴谋。",
            isUpcoming = true,
            isHot = false
        ),
        Movie(
            id = "m3",
            title = "深空回声",
            rating = 8.5,
            posterResId = R.drawable.poster_deep_space,
            releaseDate = "2026年8月15日",
            duration = 118,
            genres = "科幻 / 悬疑",
            director = "王某某",
            cast = listOf("周某某", "吴某某", "郑某某"),
            description = "一艘深太空采矿船在静默航行十年后突然发回一段诡异的声波信号。搜救队登船后发现空无一人，只有重重回声在冰冷走廊中不断激荡，诉说着超越维度的惊天秘密...",
            isUpcoming = false,
            isHot = true
        ),
        Movie(
            id = "m4",
            title = "霓虹上海",
            rating = 8.7,
            posterResId = R.drawable.poster_neon_shanghai,
            releaseDate = "2026年9月10日",
            duration = 142,
            genres = "剧情 / 爱情",
            director = "陈某某",
            cast = listOf("冯某某", "陈某某", "楚某某"),
            description = "2026年的上海，繁华的霓虹下，两个在都市底层奋斗的年轻人因为一次偶然的轨道交通晚点相遇。他们在光影变幻的城市节奏中寻找自我的归属与爱的微光。",
            isUpcoming = false,
            isHot = true
        ),
        Movie(
            id = "m5",
            title = "最后的月球城",
            rating = 8.3,
            posterResId = R.drawable.poster_star_sea, // reuse poster
            releaseDate = "2026年11月12日",
            duration = 135,
            genres = "动作 / 科幻",
            director = "韩某某",
            cast = listOf("朱某某", "秦某某", "尤某某"),
            description = "在地球资源耗尽后，最后一座月球城成为人类最后的庇护所。然而，氧气配给系统的控制权争夺引发了城内的阶级博弈。一名普通的管道工为了拯救女儿，踏上了一段险象环生的月面逃亡之旅。",
            isUpcoming = true,
            isHot = false
        ),
        Movie(
            id = "m6",
            title = "北京零点",
            rating = 8.6,
            posterResId = R.drawable.poster_neon_shanghai, // reuse poster
            releaseDate = "2026年9月1日",
            duration = 120,
            genres = "悬疑 / 犯罪",
            director = "高某某",
            cast = listOf("沈某某", "韩某某", "杨某某"),
            description = "在北京闷热的夏夜，零点钟声敲响的一瞬间，四起看似毫无关联的案件同时发生。老刑警暗中排查，发现所有线索都指向一个早已在一年前‘消失’的神秘人。时间正在一分一秒流逝...",
            isUpcoming = false,
            isHot = true
        )
    )

    // Static Mock Data for Cinemas
    val cinemas: List<Cinema> = listOf(
        Cinema(
            id = "c1",
            name = "万达影城 北京CBD店",
            address = "北京市朝阳区建国路93号万达广场3层",
            distance = "2.3 km",
            tags = listOf("IMAX", "杜比影院", "VIP厅"),
            minPrice = 39
        ),
        Cinema(
            id = "c2",
            name = "CGV影城 北京朝阳店",
            address = "北京市朝阳区朝阳北路101号大悦城8层",
            distance = "4.1 km",
            tags = listOf("IMAX", "4DX"),
            minPrice = 45
        ),
        Cinema(
            id = "c3",
            name = "博纳国际影城 北京国贸店",
            address = "北京市朝阳区建国门外大街1号国贸商城地下2层",
            distance = "5.2 km",
            tags = listOf("IMAX", "杜比影院"),
            minPrice = 42
        ),
        Cinema(
            id = "c4",
            name = "百老汇影城 北京三里屯店",
            address = "北京市朝阳区三里屯路19号太古里南区B1层",
            distance = "6.5 km",
            tags = listOf("杜比影院", "VIP厅"),
            minPrice = 48
        )
    )

    // Static dates
    val dates: List<String> = listOf("9月18日", "9月19日", "9月20日", "9月21日")

    // Generate Sessions Dynamically
    fun getSessionsForMovieAndCinema(movieId: String, cinemaId: String, date: String): List<ShowSession> {
        val cinema = cinemas.firstOrNull { it.id == cinemaId } ?: return emptyList()
        val basePrice = cinema.minPrice

        return listOf(
            ShowSession(
                id = "${movieId}_${cinemaId}_${date}_s1",
                movieId = movieId,
                cinemaId = cinemaId,
                time = "10:20",
                date = date,
                hall = "普通5号厅",
                price = basePrice
            ),
            ShowSession(
                id = "${movieId}_${cinemaId}_${date}_s2",
                movieId = movieId,
                cinemaId = cinemaId,
                time = "12:40",
                date = date,
                hall = "IMAX厅",
                price = basePrice + 20
            ),
            ShowSession(
                id = "${movieId}_${cinemaId}_${date}_s3",
                movieId = movieId,
                cinemaId = cinemaId,
                time = "15:20",
                date = date,
                hall = "IMAX厅",
                price = basePrice + 20
            ),
            ShowSession(
                id = "${movieId}_${cinemaId}_${date}_s4",
                movieId = movieId,
                cinemaId = cinemaId,
                time = "18:30",
                date = date,
                hall = "杜比影院",
                price = basePrice + 30
            ),
            ShowSession(
                id = "${movieId}_${cinemaId}_${date}_s5",
                movieId = movieId,
                cinemaId = cinemaId,
                time = "21:15",
                date = date,
                hall = "普通3号厅",
                price = basePrice
            )
        )
    }
}
