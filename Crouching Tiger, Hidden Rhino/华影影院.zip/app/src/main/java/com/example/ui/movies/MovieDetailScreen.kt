package com.example.ui.movies

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Movie
import com.example.navigation.Screen
import com.example.ui.components.PremiumButton
import com.example.ui.components.RatingBadge
import com.example.ui.theme.DarkCard
import com.example.ui.theme.TextGrey
import com.example.ui.theme.TextWhite
import com.example.ui.viewmodel.CinemaViewModel

@Composable
fun MovieDetailScreen(
    movieId: String,
    viewModel: CinemaViewModel,
    onNavigate: (Screen) -> Unit,
    onBack: () -> Unit
) {
    val movie = viewModel.movies.firstOrNull { it.id == movieId }

    if (movie == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("未找到该电影", color = TextGrey)
        }
        return
    }

    val scrollState = rememberScrollState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(bottom = 90.dp) // Leave space for bottom persistent buy button
        ) {
            // Movie Poster Hero Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(380.dp)
            ) {
                Image(
                    painter = painterResource(id = movie.posterResId),
                    contentDescription = movie.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Black gradient overlay from bottom to top for movie details text backdrop
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    Color(0x7F000000),
                                    Color(0xFF0C0C0E)
                                ),
                                startY = 100f,
                                endY = 1100f
                            )
                        )
                )

                // Back Button
                Box(
                    modifier = Modifier
                        .statusBarsPadding()
                        .padding(top = 16.dp, start = 16.dp)
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0x99000000))
                        .clickable { onBack() }
                        .testTag("back_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }

                // Movie details floating overlay
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "《${movie.title}》",
                            color = TextWhite,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold
                        )

                        RatingBadge(rating = movie.rating)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "2026年 | ${movie.duration}分钟 | ${movie.genres}",
                        color = TextWhite.copy(alpha = 0.9f),
                        fontSize = 14.sp
                    )
                }
            }

            // Movie Credits
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "导演：${movie.director}",
                    color = TextWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "主演：${movie.cast.joinToString(" / ")}",
                    color = TextWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Synopsis Section
                Text(
                    text = "剧情简介",
                    color = TextWhite,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = movie.description,
                    color = TextGrey,
                    fontSize = 14.sp,
                    lineHeight = 22.sp
                )

                Spacer(modifier = Modifier.height(24.dp))

                HorizontalDivider(color = Color(0xFF1C1C24))

                Spacer(modifier = Modifier.height(20.dp))

                // Detail Information
                Text(
                    text = "电影信息",
                    color = TextWhite,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(12.dp))

                InfoRow(label = "上映日期", value = movie.releaseDate)
                InfoRow(label = "片长", value = "${movie.duration}分钟")
                InfoRow(label = "类型", value = movie.genres)
                InfoRow(label = "制片国家", value = "中国大陆")
            }
        }

        // Persistent Bottom Buy Tickets Bar
        Surface(
            color = Color(0xFF16161C),
            tonalElevation = 8.dp,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                PremiumButton(
                    text = if (movie.isUpcoming) "开始预售" else "立即购票",
                    onClick = {
                        // Enter the choosing session flow
                        viewModel.selectMovie(movie)
                        // By default we select the first cinema
                        if (viewModel.selectedCinema == null && viewModel.cinemas.isNotEmpty()) {
                            viewModel.selectCinema(viewModel.cinemas.first())
                        }
                        onNavigate(Screen.BookingSession)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "buy_ticket_now_button"
                )
            }
        }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.Start
    ) {
        Text(
            text = label,
            color = TextGrey,
            fontSize = 14.sp,
            modifier = Modifier.width(100.dp)
        )
        Text(
            text = value,
            color = TextWhite,
            fontSize = 14.sp
        )
    }
}
