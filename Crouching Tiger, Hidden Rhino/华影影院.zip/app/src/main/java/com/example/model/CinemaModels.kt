package com.example.model

import java.io.Serializable

data class Movie(
    val id: String,
    val title: String,
    val rating: Double,
    val posterResId: Int,
    val releaseDate: String,
    val duration: Int,
    val genres: String,
    val director: String,
    val cast: List<String>,
    val description: String,
    val isUpcoming: Boolean,
    val isHot: Boolean
) : Serializable

data class Cinema(
    val id: String,
    val name: String,
    val address: String,
    val distance: String,
    val tags: List<String>, // e.g., ["IMAX", "杜比影院", "VIP厅"]
    val minPrice: Int
) : Serializable

data class ShowSession(
    val id: String,
    val movieId: String,
    val cinemaId: String,
    val time: String, // e.g., "18:30"
    val date: String, // e.g., "9月18日"
    val hall: String, // e.g., "IMAX厅"
    val price: Int
) : Serializable

data class Seat(
    val row: Int,
    val col: Int,
    val status: SeatStatus // AVAILABLE, SELECTED, SOLD
)

enum class SeatStatus {
    AVAILABLE,
    SELECTED,
    SOLD
}
