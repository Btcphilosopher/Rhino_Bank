package com.example.ui.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.CinemaRepository
import com.example.data.TicketEntity
import com.example.model.Cinema
import com.example.model.Movie
import com.example.model.Seat
import com.example.model.SeatStatus
import com.example.model.ShowSession
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.random.Random

class CinemaViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: CinemaRepository

    init {
        val database = AppDatabase.getDatabase(application)
        repository = CinemaRepository(database.ticketDao())
    }

    // Expose lists of data
    val movies: List<Movie> = repository.movies
    val cinemas: List<Cinema> = repository.cinemas
    val dates: List<String> = repository.dates

    // Tickets from database
    val bookedTickets: StateFlow<List<TicketEntity>> = repository.allTickets
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // User Selection States
    var selectedMovie by mutableStateOf<Movie?>(null)
        private set

    var selectedCinema by mutableStateOf<Cinema?>(null)
        private set

    var selectedDate by mutableStateOf<String>(dates.firstOrNull() ?: "9月18日")
        private set

    var selectedSession by mutableStateOf<ShowSession?>(null)
        private set

    var selectedSeats by mutableStateOf<List<Pair<Int, Int>>>(emptyList())
        private set

    // Dynamically generated seats for the current session
    var sessionSeats by mutableStateOf<List<Seat>>(emptyList())
        private set

    // Search query
    var searchQuery by mutableStateOf("")
        private set

    fun selectMovie(movie: Movie) {
        selectedMovie = movie
    }

    fun selectCinema(cinema: Cinema) {
        selectedCinema = cinema
    }

    fun selectDate(date: String) {
        selectedDate = date
        // Refresh session if needed
        selectedSession = null
        selectedSeats = emptyList()
    }

    fun selectSession(session: ShowSession) {
        selectedSession = session
        selectedSeats = emptyList()
        generateSeatsForSession(session.id)
    }

    fun updateSearchQuery(query: String) {
        searchQuery = query
    }

    // Toggle seat selection
    fun toggleSeat(row: Int, col: Int) {
        val seatPair = Pair(row, col)
        if (selectedSeats.contains(seatPair)) {
            selectedSeats = selectedSeats.filter { it != seatPair }
            // Update seat status in list
            sessionSeats = sessionSeats.map {
                if (it.row == row && it.col == col) {
                    it.copy(status = SeatStatus.AVAILABLE)
                } else {
                    it
                }
            }
        } else {
            if (selectedSeats.size < 4) { // Max 4 tickets
                selectedSeats = selectedSeats + seatPair
                // Update seat status in list
                sessionSeats = sessionSeats.map {
                    if (it.row == row && it.col == col) {
                        it.copy(status = SeatStatus.SELECTED)
                    } else {
                        it
                    }
                }
            }
        }
    }

    // Generate simulated seats for a session (consistent based on session id)
    private fun generateSeatsForSession(sessionId: String) {
        // Use sessionId's hashCode as seed to make pre-sold seats consistent for the same session!
        val random = Random(sessionId.hashCode())
        val seatsList = mutableListOf<Seat>()
        val totalRows = 6
        val totalCols = 8

        for (row in 1..totalRows) {
            for (col in 1..totalCols) {
                // ~30% seats are sold out
                val isSold = random.nextFloat() < 0.35f
                seatsList.add(
                    Seat(
                        row = row,
                        col = col,
                        status = if (isSold) SeatStatus.SOLD else SeatStatus.AVAILABLE
                    )
                )
            }
        }
        sessionSeats = seatsList
    }

    // Get Sessions for currently selected movie and cinema
    fun getAvailableSessions(): List<ShowSession> {
        val movie = selectedMovie ?: return emptyList()
        val cinema = selectedCinema ?: return emptyList()
        return repository.getSessionsForMovieAndCinema(movie.id, cinema.id, selectedDate)
    }

    // Get Sessions for a cinema and a date (showing all movies showtimes)
    fun getMoviesWithSessionsForCinema(cinemaId: String, date: String): List<Pair<Movie, List<ShowSession>>> {
        return movies.filter { !it.isUpcoming }.map { movie ->
            val sessions = repository.getSessionsForMovieAndCinema(movie.id, cinemaId, date)
            Pair(movie, sessions)
        }
    }

    // Search logic
    fun getFilteredMovies(): List<Movie> {
        if (searchQuery.isBlank()) return movies
        return movies.filter { it.title.contains(searchQuery, ignoreCase = true) || it.genres.contains(searchQuery, ignoreCase = true) }
    }

    fun getFilteredCinemas(): List<Cinema> {
        if (searchQuery.isBlank()) return cinemas
        return cinemas.filter { it.name.contains(searchQuery, ignoreCase = true) || it.address.contains(searchQuery, ignoreCase = true) }
    }

    // Confirm booking and write to local Room database
    fun confirmPayment(onSuccess: (TicketEntity) -> Unit) {
        val movie = selectedMovie ?: return
        val cinema = selectedCinema ?: return
        val session = selectedSession ?: return
        if (selectedSeats.isEmpty()) return

        val seatsStr = selectedSeats.joinToString(", ") { "${it.first}排${it.second}座" }
        val ticketCode = (100000..999999).random().toString() // Generates random 6 digit pickup code

        val ticket = TicketEntity(
            movieId = movie.id,
            movieTitle = movie.title,
            moviePosterResId = movie.posterResId,
            cinemaId = cinema.id,
            cinemaName = cinema.name,
            sessionTime = session.time,
            sessionDate = session.date,
            sessionHall = session.hall,
            seats = seatsStr,
            totalPrice = session.price * selectedSeats.size,
            ticketCode = ticketCode
        )

        viewModelScope.launch {
            val id = repository.insertTicket(ticket)
            val insertedTicket = ticket.copy(id = id.toInt())
            onSuccess(insertedTicket)

            // Clear selections after successful booking
            selectedMovie = null
            selectedCinema = null
            selectedSession = null
            selectedSeats = emptyList()
        }
    }
}
