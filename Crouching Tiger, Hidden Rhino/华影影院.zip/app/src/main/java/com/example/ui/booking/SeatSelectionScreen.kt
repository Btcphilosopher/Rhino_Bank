package com.example.ui.booking

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.SeatStatus
import com.example.navigation.Screen
import com.example.ui.components.PremiumButton
import com.example.ui.theme.CinemaRed
import com.example.ui.theme.DarkCard
import com.example.ui.theme.SeatAvailable
import com.example.ui.theme.SeatLabelSold
import com.example.ui.theme.SeatSelected
import com.example.ui.theme.SeatSold
import com.example.ui.theme.TextGrey
import com.example.ui.theme.TextWhite
import com.example.ui.viewmodel.CinemaViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SeatSelectionScreen(
    viewModel: CinemaViewModel,
    onNavigate: (Screen) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val movie = viewModel.selectedMovie
    val cinema = viewModel.selectedCinema
    val session = viewModel.selectedSession

    if (movie == null || cinema == null || session == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("会话失效，请重新选择", color = TextGrey)
        }
        return
    }

    val seats = viewModel.sessionSeats
    val selectedSeats = viewModel.selectedSeats

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // App bar
        Surface(
            color = Color(0xFF16161C),
            tonalElevation = 4.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .statusBarsPadding()
                    .fillMaxWidth()
                    .padding(vertical = 12.dp, horizontal = 16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(DarkCard)
                        .clickable { onBack() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = TextWhite,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(16.dp))

                Column {
                    Text(
                        text = cinema.name,
                        color = TextWhite,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "《${movie.title}》 ${session.date} ${session.time} (${session.hall})",
                        color = TextGrey,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Screen Representation (银幕)
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp)
        ) {
            Box(
                modifier = Modifier
                    .width(180.dp)
                    .height(6.dp)
                    .clip(RoundedCornerShape(50.dp))
                    .background(
                        Brush.radialGradient(
                            colors = listOf(CinemaRed, Color.Transparent),
                            radius = 400f
                        )
                    )
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "银幕中央",
                color = TextGrey,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = 1.sp
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Seat Status Legend Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            SeatLegend(label = "可选", color = Color.Transparent, border = SeatAvailable)
            Spacer(modifier = Modifier.width(20.dp))
            SeatLegend(label = "已选", color = SeatSelected, border = Color.Transparent)
            Spacer(modifier = Modifier.width(20.dp))
            SeatLegend(label = "已售", color = SeatSold, border = Color.Transparent)
        }

        Spacer(modifier = Modifier.height(30.dp))

        // Seat Map Scrollable Grid
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            val rowsCount = 6
            val colsCount = 8

            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(16.dp)
            ) {
                for (r in 1..rowsCount) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Row Number Label
                        Text(
                            text = "$r",
                            color = TextGrey,
                            fontSize = 11.sp,
                            modifier = Modifier.width(16.dp),
                            textAlign = TextAlign.Center
                        )

                        for (c in 1..colsCount) {
                            val seat = seats.firstOrNull { it.row == r && it.col == c }
                            val isSelected = selectedSeats.contains(Pair(r, c))
                            val isSold = seat?.status == SeatStatus.SOLD

                            Box(
                                modifier = Modifier
                                    .size(30.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(
                                        when {
                                            isSold -> SeatSold
                                            isSelected -> SeatSelected
                                            else -> Color.Transparent
                                        }
                                    )
                                    .border(
                                        width = 1.dp,
                                        color = if (isSold) Color.Transparent else SeatAvailable,
                                        shape = RoundedCornerShape(4.dp)
                                    )
                                    .clickable(enabled = !isSold) {
                                        viewModel.toggleSeat(r, c)
                                    }
                                    .testTag("seat_${r}_${c}"),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isSold) {
                                    // A small cross or dot for sold out
                                    Box(
                                        modifier = Modifier
                                            .size(4.dp)
                                            .background(SeatLabelSold, CircleShape)
                                    )
                                }
                            }
                        }

                        // Mirror Row Number Label
                        Text(
                            text = "$r",
                            color = TextGrey,
                            fontSize = 11.sp,
                            modifier = Modifier.width(16.dp),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        // Selection & Checkout Bar
        Surface(
            color = Color(0xFF16161C),
            tonalElevation = 8.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(16.dp)
            ) {
                // Show chosen seats
                if (selectedSeats.isNotEmpty()) {
                    Text(
                        text = "已选座位",
                        color = TextWhite,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        selectedSeats.forEach { seatPair ->
                            Box(
                                modifier = Modifier
                                    .background(Color(0xFF2C2C35), RoundedCornerShape(6.dp))
                                    .border(0.5.dp, CinemaRed, RoundedCornerShape(6.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "${seatPair.first}排${seatPair.second}座",
                                    color = TextWhite,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                }

                HorizontalDivider(color = Color(0xFF2E2E36))

                Spacer(modifier = Modifier.height(16.dp))

                // Price and Submit Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (selectedSeats.isEmpty()) "请先选择座位" else "票价详情",
                            color = TextGrey,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                text = "¥",
                                color = CinemaRed,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(bottom = 2.dp)
                            )
                            Text(
                                text = "${session.price * selectedSeats.size}",
                                color = CinemaRed,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    PremiumButton(
                        text = "确认选座",
                        onClick = { onNavigate(Screen.ConfirmOrder) },
                        enabled = selectedSeats.isNotEmpty(),
                        modifier = Modifier.width(160.dp),
                        testTag = "confirm_seat_button"
                    )
                }
            }
        }
    }
}

@Composable
fun SeatLegend(
    label: String,
    color: Color,
    border: Color
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(16.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(color)
                .then(
                    if (border != Color.Transparent) Modifier.border(
                        1.dp,
                        border,
                        RoundedCornerShape(2.dp)
                    ) else Modifier
                )
        )
        Text(
            text = label,
            color = TextGrey,
            fontSize = 12.sp
        )
    }
}
