package com.example.ui.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Cinema
import com.example.model.Movie
import com.example.navigation.Screen
import com.example.ui.components.CinemaSearchBar
import com.example.ui.components.RatingBadge
import com.example.ui.theme.CinemaRed
import com.example.ui.theme.DarkCard
import com.example.ui.theme.TextGrey
import com.example.ui.theme.TextWhite
import com.example.ui.viewmodel.CinemaViewModel

@Composable
fun HomeScreen(
    viewModel: CinemaViewModel,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    val hotMovies = viewModel.movies.filter { it.isHot }
    val upcomingMovies = viewModel.movies.filter { it.isUpcoming }
    val cinemas = viewModel.cinemas

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // 1. Header (华影影院 + Location + Search Entry)
        item {
            HomeHeader(
                onLocationClick = {},
                onSearchClick = { onNavigate(Screen.Search) }
            )
        }

        // 2. Banner/正在热映 Section Header
        item {
            SectionHeader(
                title = "正在热映",
                onSeeAllClick = { onNavigate(Screen.Movies) }
            )
        }

        // 3. 正在热映 Horizontal Row
        item {
            LazyRow(
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(hotMovies) { movie ->
                    HotMovieCard(
                        movie = movie,
                        onClick = {
                            viewModel.selectMovie(movie)
                            onNavigate(Screen.MovieDetail(movie.id))
                        },
                        onBuyTicketClick = {
                            viewModel.selectMovie(movie)
                            onNavigate(Screen.MovieDetail(movie.id)) // Go to details or start booking
                        }
                    )
                }
            }
        }

        // 4. 即将上映 Section Header
        item {
            SectionHeader(
                title = "即将上映",
                onSeeAllClick = { onNavigate(Screen.Movies) }
            )
        }

        // 5. 即将上映 Horizontal Row
        item {
            LazyRow(
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(upcomingMovies) { movie ->
                    UpcomingMovieCard(
                        movie = movie,
                        onClick = {
                            viewModel.selectMovie(movie)
                            onNavigate(Screen.MovieDetail(movie.id))
                        }
                    )
                }
            }
        }

        // 6. 附近影院 Section Header
        item {
            SectionHeader(
                title = "附近影院",
                onSeeAllClick = { onNavigate(Screen.Cinemas) }
            )
        }

        // 7. 附近影院 List
        items(cinemas.take(3)) { cinema ->
            HomeCinemaCard(
                cinema = cinema,
                onClick = {
                    viewModel.selectCinema(cinema)
                    onNavigate(Screen.CinemaDetail(cinema.id))
                }
            )
        }

        // Spacer at the bottom to clear bottom nav
        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun HomeHeader(
    onLocationClick: () -> Unit,
    onSearchClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF16161C), DarkCard, Color.Transparent),
                    startY = 0f,
                    endY = 500f
                )
            )
            .padding(top = 40.dp, start = 16.dp, end = 16.dp, bottom = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "华影影院",
                    color = TextWhite,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
                Text(
                    text = "HUAYING CINEMA",
                    color = CinemaRed,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(DarkCard)
                    .clickable { onLocationClick() }
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(text = "北京", color = TextWhite, fontSize = 14.sp)
                Icon(
                    imageVector = Icons.Default.ArrowDropDown,
                    contentDescription = "Dropdown",
                    tint = TextWhite,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Read-only SearchBar that acts as an entry point
        CinemaSearchBar(
            value = "",
            onValueChange = {},
            readOnly = true,
            onClick = onSearchClick,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun SectionHeader(
    title: String,
    onSeeAllClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Bottom
    ) {
        Text(
            text = title,
            color = TextWhite,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp
        )
        Text(
            text = "全部 >",
            color = TextGrey,
            fontSize = 13.sp,
            modifier = Modifier
                .clickable { onSeeAllClick() }
                .padding(4.dp)
        )
    }
}

@Composable
fun HotMovieCard(
    movie: Movie,
    onClick: () -> Unit,
    onBuyTicketClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .width(160.dp)
            .clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(220.dp)
                .clip(RoundedCornerShape(12.dp))
                .border(1.dp, Color(0xFF2E2E36), RoundedCornerShape(12.dp))
        ) {
            Image(
                painter = painterResource(id = movie.posterResId),
                contentDescription = movie.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            // Rating badge on bottom right of image
            RatingBadge(
                rating = movie.rating,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(8.dp)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "《${movie.title}》",
            color = TextWhite,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )

        Text(
            text = "${movie.genres} | ${movie.duration}分钟",
            color = TextGrey,
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 2.dp, bottom = 6.dp)
        )

        Button(
            onClick = onBuyTicketClick,
            colors = ButtonDefaults.buttonColors(
                containerColor = CinemaRed,
                contentColor = Color.White
            ),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(32.dp),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
        ) {
            Text("购票", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun UpcomingMovieCard(
    movie: Movie,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .width(130.dp)
            .clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .clip(RoundedCornerShape(10.dp))
                .border(1.dp, Color(0xFF1E1E24), RoundedCornerShape(10.dp))
        ) {
            Image(
                painter = painterResource(id = movie.posterResId),
                contentDescription = movie.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = "《${movie.title}》",
            color = TextWhite,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )

        Text(
            text = "${movie.releaseDate}上映",
            color = CinemaRed,
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 2.dp, bottom = 4.dp)
        )

        // Mock 想看 button
        var hasClickedLike = false
        Button(
            onClick = { /* Simulated like */ },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF1C1C24),
                contentColor = CinemaRed
            ),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(28.dp)
                .border(0.5.dp, CinemaRed, RoundedCornerShape(8.dp)),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
        ) {
            Text("想看", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun HomeCinemaCard(
    cinema: Cinema,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = DarkCard
        ),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = cinema.name,
                    color = TextWhite,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    Text(
                        text = "距离 ${cinema.distance}",
                        color = TextGrey,
                        fontSize = 12.sp
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.padding(top = 8.dp)
                ) {
                    cinema.tags.forEach { tag ->
                        Box(
                            modifier = Modifier
                                .border(0.5.dp, CinemaRed, RoundedCornerShape(4.dp))
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = tag,
                                color = CinemaRed,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.Center
            ) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        text = "¥",
                        color = CinemaRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 2.dp)
                    )
                    Text(
                        text = "${cinema.minPrice}",
                        color = CinemaRed,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "起",
                        color = TextGrey,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(start = 2.dp, bottom = 2.dp)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = onClick,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF2C2C35),
                        contentColor = TextWhite
                    ),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.height(28.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp)
                ) {
                    Text("查看场次", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
