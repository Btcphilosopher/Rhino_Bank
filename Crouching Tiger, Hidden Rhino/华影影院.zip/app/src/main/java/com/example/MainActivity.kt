package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.navigation.Screen
import com.example.ui.booking.BookingSessionScreen
import com.example.ui.booking.ConfirmOrderScreen
import com.example.ui.booking.SeatSelectionScreen
import com.example.ui.cinemas.CinemaDetailScreen
import com.example.ui.cinemas.CinemasScreen
import com.example.ui.components.CinemaBottomNavigation
import com.example.ui.home.HomeScreen
import com.example.ui.movies.MovieDetailScreen
import com.example.ui.movies.MoviesScreen
import com.example.ui.movies.SearchScreen
import com.example.ui.profile.ProfileScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.tickets.TicketDetailScreen
import com.example.ui.viewmodel.CinemaViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: CinemaViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                CinemaAppMain(viewModel)
            }
        }
    }
}

@Composable
fun CinemaAppMain(viewModel: CinemaViewModel) {
    // Custom robust state-based backstack navigation
    var backstack by remember { mutableStateOf<List<Screen>>(listOf(Screen.Home)) }
    val currentScreen = backstack.lastOrNull() ?: Screen.Home

    fun navigateTo(screen: Screen) {
        // If navigating to main bottom bar tabs, reset the backstack to prevent deep nesting!
        if (screen is Screen.Home || screen is Screen.Movies || screen is Screen.Cinemas || screen is Screen.Profile) {
            backstack = listOf(screen)
        } else {
            backstack = backstack + screen
        }
    }

    fun navigateBack() {
        if (backstack.size > 1) {
            backstack = backstack.dropLast(1)
        }
    }

    // Intercept hardware/gesture system back press to pop screens correctly
    BackHandler(enabled = backstack.size > 1) {
        val lastScreen = backstack.lastOrNull()
        if (lastScreen is Screen.TicketDetail && lastScreen.isJustPurchased) {
            navigateTo(Screen.Home)
        } else {
            navigateBack()
        }
    }

    // List of main screens that should show bottom navigation
    val showBottomNav = currentScreen is Screen.Home ||
            currentScreen is Screen.Movies ||
            currentScreen is Screen.Cinemas ||
            currentScreen is Screen.Profile

    Scaffold(
        bottomBar = {
            if (showBottomNav) {
                CinemaBottomNavigation(
                    currentScreen = currentScreen,
                    onNavigate = { screen -> navigateTo(screen) }
                )
            }
        },
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = if (showBottomNav) innerPadding.calculateBottomPadding() else 0.dp)
        ) {
            // Standard M3 spring crossfade between screen navigations (under 280ms)
            Crossfade(
                targetState = currentScreen,
                animationSpec = tween(durationMillis = 250)
            ) { screen ->
                when (screen) {
                    Screen.Home -> HomeScreen(
                        viewModel = viewModel,
                        onNavigate = { navigateTo(it) }
                    )
                    Screen.Movies -> MoviesScreen(
                        viewModel = viewModel,
                        onNavigate = { navigateTo(it) }
                    )
                    Screen.Cinemas -> CinemasScreen(
                        viewModel = viewModel,
                        onNavigate = { navigateTo(it) }
                    )
                    Screen.Profile -> ProfileScreen(
                        viewModel = viewModel,
                        onNavigate = { navigateTo(it) }
                    )
                    is Screen.MovieDetail -> MovieDetailScreen(
                        movieId = screen.movieId,
                        viewModel = viewModel,
                        onNavigate = { navigateTo(it) },
                        onBack = { navigateBack() }
                    )
                    is Screen.CinemaDetail -> CinemaDetailScreen(
                        cinemaId = screen.cinemaId,
                        viewModel = viewModel,
                        onNavigate = { navigateTo(it) },
                        onBack = { navigateBack() }
                    )
                    Screen.BookingSession -> BookingSessionScreen(
                        viewModel = viewModel,
                        onNavigate = { navigateTo(it) },
                        onBack = { navigateBack() }
                    )
                    Screen.SeatSelection -> SeatSelectionScreen(
                        viewModel = viewModel,
                        onNavigate = { navigateTo(it) },
                        onBack = { navigateBack() }
                    )
                    Screen.ConfirmOrder -> ConfirmOrderScreen(
                        viewModel = viewModel,
                        onNavigate = { navigateTo(it) },
                        onBack = { navigateBack() }
                    )
                    is Screen.TicketDetail -> TicketDetailScreen(
                        ticketId = screen.ticketId,
                        isJustPurchased = screen.isJustPurchased,
                        viewModel = viewModel,
                        onNavigate = { navigateTo(it) },
                        onBack = { navigateBack() }
                    )
                    Screen.Search -> SearchScreen(
                        viewModel = viewModel,
                        onNavigate = { navigateTo(it) },
                        onBack = { navigateBack() }
                    )
                }
            }
        }
    }
}
