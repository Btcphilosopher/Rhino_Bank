package com.example.navigation

sealed class Screen {
    object Home : Screen()
    object Movies : Screen()
    object Cinemas : Screen()
    object Profile : Screen()
    
    // Sub-flows
    data class MovieDetail(val movieId: String) : Screen()
    data class CinemaDetail(val cinemaId: String) : Screen()
    object BookingSession : Screen()
    object SeatSelection : Screen()
    object ConfirmOrder : Screen()
    data class TicketDetail(val ticketId: Int, val isJustPurchased: Boolean = false) : Screen()
    object Search : Screen()
}
