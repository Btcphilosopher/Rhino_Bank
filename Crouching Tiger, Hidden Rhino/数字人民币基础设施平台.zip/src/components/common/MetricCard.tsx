import React from 'react';
import { LucideIcon } from 'lucide-react';

interface MetricCardProps {
  id?: string;
  title: string;
  value: string | number;
  subValue?: string;
  subLabel?: string;
  icon?: LucideIcon;
  trend?: {
    value: string;
    isPositive: boolean;
  };
  highlight?: boolean;
  badgeText?: string;
  secondaryInfo?: string;
}

export const MetricCard: React.FC<MetricCardProps> = ({
  id,
  title,
  value,
  subValue,
  subLabel,
  icon: Icon,
  trend,
  highlight = false,
  badgeText,
  secondaryInfo
}) => {
  return (
    <div 
      id={id}
      className={`p-4 rounded-lg border transition-all relative overflow-hidden ${
        highlight 
          ? 'bg-gradient-to-br from-[#1a1215] to-[#12151c] border-[#991b1b]/40 shadow-sm shadow-[#991b1b]/10' 
          : 'bg-[#12151d] border-[#1e2433] hover:border-[#2d374d]'
      }`}
    >
      <div className="flex items-center justify-between gap-2 mb-2">
        <span className="text-xs font-medium text-[#94a3b8] tracking-wide flex items-center gap-1.5">
          {Icon && <Icon className="w-3.5 h-3.5 text-[#64748b]" />}
          {title}
        </span>
        {badgeText && (
          <span className="text-[10px] uppercase font-mono-num px-1.5 py-0.5 rounded bg-[#1e2433] text-[#cbd5e1] border border-[#334155]">
            {badgeText}
          </span>
        )}
      </div>

      <div className="flex items-baseline gap-2">
        <span className="text-2xl font-semibold tracking-tight text-white font-mono-num">
          {value}
        </span>
      </div>

      {(subValue || trend || secondaryInfo) && (
        <div className="mt-2.5 pt-2 border-t border-[#1a202c] flex items-center justify-between text-xs">
          {subValue && (
            <span className="text-[#94a3b8] text-[11px]">
              {subLabel && <span className="text-[#64748b] mr-1">{subLabel}:</span>}
              <span className="font-mono-num font-medium text-[#e2e8f0]">{subValue}</span>
            </span>
          )}
          {trend && (
            <span className={`text-[11px] font-mono-num font-medium flex items-center ${trend.isPositive ? 'text-[#4ade80]' : 'text-[#f87171]'}`}>
              {trend.isPositive ? '↑' : '↓'} {trend.value}
            </span>
          )}
          {secondaryInfo && (
            <span className="text-[11px] text-[#64748b] font-mono-num truncate">
              {secondaryInfo}
            </span>
          )}
        </div>
      )}
    </div>
  );
};
