import React from 'react';
import { TransactionStatus, ClearingStatus, WalletStatus, KycLevel, RiskAlert, ProgrammableRule } from '../../types';

interface BadgeProps {
  children: React.ReactNode;
  variant?: 'red' | 'green' | 'amber' | 'blue' | 'graphite' | 'gold' | 'purple';
  size?: 'sm' | 'md';
  pulse?: boolean;
}

export const Badge: React.FC<BadgeProps> = ({ 
  children, 
  variant = 'graphite', 
  size = 'sm',
  pulse = false 
}) => {
  const variantStyles = {
    red: 'bg-[#3b1216] text-[#f87171] border-[#7f1d1d]/60',
    green: 'bg-[#0f291e] text-[#4ade80] border-[#166534]/60',
    amber: 'bg-[#2e200b] text-[#fbbf24] border-[#92400e]/60',
    blue: 'bg-[#0f233a] text-[#60a5fa] border-[#1e40af]/60',
    graphite: 'bg-[#1a1f2c] text-[#94a3b8] border-[#334155]/60',
    gold: 'bg-[#2a2412] text-[#fcd34d] border-[#854d0e]/60',
    purple: 'bg-[#241434] text-[#c084fc] border-[#6b21a8]/60',
  };

  const sizeStyles = {
    sm: 'text-[11px] px-2 py-0.5',
    md: 'text-xs px-2.5 py-1',
  };

  return (
    <span className={`inline-flex items-center gap-1.5 font-medium border rounded whitespace-nowrap ${variantStyles[variant]} ${sizeStyles[size]}`}>
      {pulse && (
        <span className="relative flex h-1.5 w-1.5">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 bg-current"></span>
          <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-current"></span>
        </span>
      )}
      {children}
    </span>
  );
};

export const TxStatusBadge: React.FC<{ status: TransactionStatus }> = ({ status }) => {
  switch (status) {
    case 'SETTLED':
      return <Badge variant="green">已清算</Badge>;
    case 'COMPLETED':
      return <Badge variant="blue">已完成</Badge>;
    case 'PROCESSING':
      return <Badge variant="amber" pulse>处理中</Badge>;
    case 'PENDING':
      return <Badge variant="graphite">待处理</Badge>;
    case 'INTERCEPTED':
      return <Badge variant="red">风险拦截</Badge>;
    case 'REJECTED':
      return <Badge variant="red">已拒绝</Badge>;
    case 'ANOMALY':
      return <Badge variant="red" pulse>异常挂起</Badge>;
    default:
      return <Badge variant="graphite">{status}</Badge>;
  }
};

export const ClearingStatusBadge: React.FC<{ status: ClearingStatus }> = ({ status }) => {
  switch (status) {
    case 'SETTLED':
      return <Badge variant="green">已轧差结算</Badge>;
    case 'IN_QUEUE':
      return <Badge variant="amber" pulse>清算队列中</Badge>;
    case 'UNSETTLED':
      return <Badge variant="graphite">待入清算</Badge>;
    case 'FAILED':
      return <Badge variant="red">清算失败</Badge>;
    default:
      return <Badge variant="graphite">{status}</Badge>;
  }
};

export const WalletStatusBadge: React.FC<{ status: WalletStatus }> = ({ status }) => {
  switch (status) {
    case 'ACTIVE':
      return <Badge variant="green">正常运行</Badge>;
    case 'FROZEN':
      return <Badge variant="red" pulse>全网冻结</Badge>;
    case 'RESTRICTED':
      return <Badge variant="amber">限额受控</Badge>;
    case 'CANCELLED':
      return <Badge variant="graphite">已注销</Badge>;
    default:
      return <Badge variant="graphite">{status}</Badge>;
  }
};

export const KycBadge: React.FC<{ level: KycLevel }> = ({ level }) => {
  switch (level) {
    case 'LEVEL_1':
      return <Badge variant="gold">一类实名强认证 (无额度上限)</Badge>;
    case 'LEVEL_2':
      return <Badge variant="blue">二类实名认证 (单笔5万/日10万)</Badge>;
    case 'LEVEL_3':
      return <Badge variant="amber">三类有效证件 (单笔5千/日1万)</Badge>;
    case 'LEVEL_4':
      return <Badge variant="graphite">四类匿名小额 (单笔1千/日2千)</Badge>;
    default:
      return <Badge variant="graphite">{level}</Badge>;
  }
};

export const RiskBadge: React.FC<{ severity: 'WARNING' | 'ALERT' | 'CRITICAL' }> = ({ severity }) => {
  switch (severity) {
    case 'CRITICAL':
      return <Badge variant="red" pulse>紧急高危</Badge>;
    case 'ALERT':
      return <Badge variant="amber">预警关注</Badge>;
    case 'WARNING':
      return <Badge variant="gold">常规提示</Badge>;
    default:
      return <Badge variant="graphite">{severity}</Badge>;
  }
};

export const ContractStatusBadge: React.FC<{ status: 'ACTIVE' | 'PAUSED' | 'COMPLETED' | 'EXPIRED' }> = ({ status }) => {
  switch (status) {
    case 'ACTIVE':
      return <Badge variant="green">运行中 (ACTIVE)</Badge>;
    case 'PAUSED':
      return <Badge variant="amber">已暂停 (PAUSED)</Badge>;
    case 'COMPLETED':
      return <Badge variant="blue">已核销完毕</Badge>;
    case 'EXPIRED':
      return <Badge variant="graphite">已过期</Badge>;
    default:
      return <Badge variant="graphite">{status}</Badge>;
  }
};
