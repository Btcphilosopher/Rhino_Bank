import React from 'react';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  ShieldCheck, 
  Activity, 
  Wifi, 
  Database, 
  Landmark, 
  Layers
} from 'lucide-react';
import { useSimulation } from '../../simulation/SimulationContext';

export const Header: React.FC = () => {
  const { 
    isRunning, 
    speed, 
    toggleSimulation, 
    setSpeed, 
    resetSimulation, 
    stats
  } = useSimulation();

  return (
    <header className="bg-[#0e1117] border-b border-[#1f2637] text-[#e2e8f0] px-4 py-2.5 flex items-center justify-between gap-4 sticky top-0 z-40 select-none">
      {/* Left: Brand Identity */}
      <div className="flex items-center gap-3 min-w-fit">
        <div className="flex items-center justify-center w-8 h-8 rounded bg-[#8b111a] border border-[#b91c1c] text-white shadow-md shadow-[#8b111a]/20">
          <Landmark className="w-4 h-4" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-sm font-bold tracking-wide text-white">
              数字人民币基础设施平台
            </h1>
            <span className="text-[10px] font-mono-num font-semibold text-[#f87171] px-1.5 py-0.2 rounded bg-[#3b1216] border border-[#7f1d1d]/60">
              CBDC CORE
            </span>
          </div>
          <p className="text-[11px] text-[#94a3b8] tracking-tight">
            中央银行数字货币运行、清算与监管仿真系统
          </p>
        </div>
      </div>

      {/* Center: System Environmental Status telemetry */}
      <div className="hidden lg:flex items-center gap-4 text-xs">
        {/* System State */}
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#131722] border border-[#222a3d]">
          <Activity className="w-3.5 h-3.5 text-emerald-400" />
          <span className="text-[#94a3b8]">运行状态:</span>
          <span className="text-emerald-400 font-medium font-mono-num">正常运行 (99.999%)</span>
        </div>

        {/* Network State */}
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#131722] border border-[#222a3d]">
          <Wifi className="w-3.5 h-3.5 text-sky-400" />
          <span className="text-[#94a3b8]">网络通道:</span>
          <span className="text-sky-300 font-mono-num font-medium">金融专网 / 国密SM4双向认证</span>
        </div>

        {/* Data Sync */}
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#131722] border border-[#222a3d]">
          <Database className="w-3.5 h-3.5 text-amber-400" />
          <span className="text-[#94a3b8]">账本同步:</span>
          <span className="text-amber-300 font-mono-num font-medium">同城多活 / 延迟 {Math.floor(stats.realTimeTps / 800)}ms</span>
        </div>
      </div>

      {/* Right: Simulation Controls & User Context */}
      <div className="flex items-center gap-3">
        {/* Simulation Speed & State Switcher */}
        <div className="flex items-center gap-1 bg-[#141824] p-1 rounded-md border border-[#263045]">
          <button
            onClick={toggleSimulation}
            className={`px-2 py-1 rounded text-xs font-medium flex items-center gap-1 transition-all ${
              isRunning 
                ? 'bg-[#1e293b] text-amber-300 hover:bg-[#334155]' 
                : 'bg-[#15803d] text-white hover:bg-[#16a34a]'
            }`}
            title={isRunning ? '暂停仿真引擎' : '启动仿真引擎'}
          >
            {isRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            <span>{isRunning ? '暂停仿真' : '启动仿真'}</span>
          </button>

          <div className="flex items-center border-l border-[#2d374e] pl-1 ml-1">
            {([1, 10, 100] as const).map((s) => (
              <button
                key={s}
                onClick={() => setSpeed(s)}
                className={`px-1.5 py-0.5 text-[11px] font-mono-num rounded transition-colors ${
                  speed === s 
                    ? 'bg-[#8b111a] text-white font-bold' 
                    : 'text-[#94a3b8] hover:text-white hover:bg-[#1e2434]'
                }`}
              >
                ×{s}
              </button>
            ))}
          </div>

          <button
            onClick={resetSimulation}
            className="p-1 rounded text-[#94a3b8] hover:text-white hover:bg-[#1f2638] transition-colors ml-1"
            title="重置全部仿真数据到初始状态"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* User / Institution badge */}
        <div className="hidden sm:flex items-center gap-2 pl-2 border-l border-[#1f2637]">
          <div className="text-right">
            <div className="text-xs font-semibold text-white flex items-center justify-end gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>中国人民银行数字货币研究所</span>
            </div>
            <div className="text-[10px] text-[#94a3b8] font-mono-num">
              权限: <span className="text-amber-400 font-medium">特权一级 (央行总调度室)</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
