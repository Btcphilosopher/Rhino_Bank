import React from 'react';
import { 
  LayoutDashboard, 
  Coins, 
  ArrowLeftRight, 
  WalletCards, 
  Building2, 
  RefreshCcw, 
  Scale, 
  SmartphoneNfc, 
  FileCode2, 
  ShieldAlert, 
  SlidersHorizontal, 
  LineChart, 
  MapPin, 
  Server,
  FileCheck2
} from 'lucide-react';
import { useSimulation } from '../../simulation/SimulationContext';

export type NavTabId = 
  | 'overview' 
  | 'issuance' 
  | 'circulation' 
  | 'wallet' 
  | 'institution' 
  | 'clearing' 
  | 'interbank' 
  | 'offline' 
  | 'programmable' 
  | 'regulatory' 
  | 'risk' 
  | 'policy' 
  | 'datacenter' 
  | 'system';

interface SidebarProps {
  activeTab: NavTabId;
  onSelectTab: (tab: NavTabId) => void;
}

interface NavItem {
  id: NavTabId;
  label: string;
  subLabel: string;
  icon: React.ElementType;
  badgeCount?: number;
  badgeType?: 'alert' | 'info';
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, onSelectTab }) => {
  const { riskAlerts, transactions } = useSimulation();

  const pendingRiskCount = riskAlerts.filter(r => r.status === 'PENDING').length;
  const pendingClearingCount = transactions.filter(t => t.clearingStatus === 'IN_QUEUE').length;

  const navItems: NavItem[] = [
    {
      id: 'overview',
      label: '1. 运行总览',
      subLabel: '央行宏观数据与全景监控',
      icon: LayoutDashboard
    },
    {
      id: 'issuance',
      label: '2. 数字人民币发行',
      subLabel: '发行、兑换、回笼与注销',
      icon: Coins
    },
    {
      id: 'circulation',
      label: '3. 货币流通',
      subLabel: '核心交易账本与实时流水',
      icon: ArrowLeftRight
    },
    {
      id: 'wallet',
      label: '4. 钱包管理',
      subLabel: '一至四类钱包与对公账户',
      icon: WalletCards
    },
    {
      id: 'institution',
      label: '5. 机构管理',
      subLabel: '商业银行与运营机构节点',
      icon: Building2
    },
    {
      id: 'clearing',
      label: '6. 支付清算',
      subLabel: '多边净额轧差与清算队列',
      icon: RefreshCcw,
      badgeCount: pendingClearingCount > 0 ? pendingClearingCount : undefined,
      badgeType: 'info'
    },
    {
      id: 'interbank',
      label: '7. 跨行结算',
      subLabel: '机构头寸与流动性调拨',
      icon: Scale
    },
    {
      id: 'offline',
      label: '8. 离线支付',
      subLabel: '双离线与SE硬件安全芯片',
      icon: SmartphoneNfc
    },
    {
      id: 'programmable',
      label: '9. 智能合约',
      subLabel: '可编程支付与条件履约',
      icon: FileCode2
    },
    {
      id: 'regulatory',
      label: '10. 监管分析',
      subLabel: '穿透式监管与大额可疑',
      icon: FileCheck2
    },
    {
      id: 'risk',
      label: '11. 风险控制',
      subLabel: '反洗钱规则与异常拦截',
      icon: ShieldAlert,
      badgeCount: pendingRiskCount > 0 ? pendingRiskCount : undefined,
      badgeType: 'alert'
    },
    {
      id: 'policy',
      label: '12. 货币政策仿真',
      subLabel: 'M0替代率与流动性模型',
      icon: LineChart
    },
    {
      id: 'datacenter',
      label: '13. CBDC 数据中心',
      subLabel: '全国七大经济区热力分布',
      icon: MapPin
    },
    {
      id: 'system',
      label: '14. 系统运维',
      subLabel: '两层架构状态与审计日志',
      icon: Server
    }
  ];

  return (
    <aside className="w-64 bg-[#0b0d13] border-r border-[#1a1f2c] flex flex-col flex-shrink-0 h-full overflow-y-auto select-none">
      {/* Navigation Group */}
      <div className="p-3">
        <div className="text-[10px] font-semibold text-[#64748b] uppercase tracking-wider px-2 py-1 mb-1">
          中央银行控制台导航
        </div>

        <nav className="space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => onSelectTab(item.id)}
                className={`w-full text-left px-3 py-2.5 rounded-lg flex items-center justify-between transition-all group ${
                  isActive
                    ? 'bg-[#181a24] text-white border border-[#8b111a]/70 shadow-sm'
                    : 'text-[#94a3b8] hover:bg-[#12151d] hover:text-[#e2e8f0] border border-transparent'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`p-1.5 rounded transition-colors ${
                      isActive
                        ? 'bg-[#8b111a] text-white'
                        : 'bg-[#141824] text-[#64748b] group-hover:text-[#cbd5e1]'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs font-semibold tracking-tight truncate flex items-center gap-1.5">
                      {item.label}
                    </div>
                    <div className="text-[10px] text-[#64748b] truncate mt-0.5">
                      {item.subLabel}
                    </div>
                  </div>
                </div>

                {item.badgeCount !== undefined && (
                  <span
                    className={`text-[10px] font-mono-num font-bold px-1.5 py-0.2 rounded-full ${
                      item.badgeType === 'alert'
                        ? 'bg-[#ef4444] text-white animate-pulse'
                        : 'bg-[#1e40af] text-[#93c5fd]'
                    }`}
                  >
                    {item.badgeCount}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Footer System Version info */}
      <div className="mt-auto p-3 m-3 rounded-lg bg-[#0e1118] border border-[#1b2233] text-[11px] text-[#64748b]">
        <div className="flex items-center justify-between text-[#94a3b8] font-semibold mb-1">
          <span>e-CNY Core v4.8</span>
          <span className="text-emerald-400 font-mono-num">SEC-LEVEL 4</span>
        </div>
        <p className="text-[10px] leading-relaxed text-[#64748b]">
          符合中国人民银行数字人民币技术白皮书架构规范 (仿真验证版)
        </p>
      </div>
    </aside>
  );
};
