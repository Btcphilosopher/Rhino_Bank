import React from 'react';
import { AlertCircle, Cpu, RefreshCw, Zap } from 'lucide-react';
import { useSimulation } from '../../simulation/SimulationContext';

export const SimulationBanner: React.FC = () => {
  const { isRunning, speed, simulatedTime, injectBurstTransactions, executeClearingBatch } = useSimulation();

  return (
    <div className="bg-[#181114] border-b border-[#7f1d1d]/40 px-4 py-2 flex flex-wrap items-center justify-between gap-3 text-xs">
      <div className="flex items-center gap-2.5">
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-[#3b1216] border border-[#7f1d1d] text-[#fca5a5] font-semibold text-[11px] tracking-wide">
          <AlertCircle className="w-3.5 h-3.5 text-[#ef4444]" />
          仿真系统 / 模拟数据
        </span>
        <span className="text-[#cbd5e1] font-medium hidden sm:inline">
          中央银行数字货币 (e-CNY) 运行、清算与监管仿真原型平台
        </span>
        <span className="text-[#94a3b8] text-[11px] hidden md:inline">
          (所有资金流水、机构准备金及钱包余额均为模型测算，非央行真实生产系统)
        </span>
      </div>

      <div className="flex items-center gap-2">
        <div className="flex items-center gap-1.5 text-[#94a3b8] text-[11px] font-mono-num bg-[#0d0f15] px-2.5 py-1 rounded border border-[#262c3d]">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span>仿真时钟: {simulatedTime}</span>
          <span className="text-amber-400 ml-1">[{speed}x 速率]</span>
        </div>

        <button
          onClick={() => injectBurstTransactions(3)}
          className="flex items-center gap-1 px-2.5 py-1 rounded bg-[#1e2434] hover:bg-[#2b344a] text-[#e2e8f0] text-xs font-medium border border-[#334155] transition-colors"
          title="立即向系统注入多笔模拟业务交易"
        >
          <Zap className="w-3.5 h-3.5 text-amber-400" />
          <span>注入交易</span>
        </button>

        <button
          onClick={executeClearingBatch}
          className="flex items-center gap-1 px-2.5 py-1 rounded bg-[#152a20] hover:bg-[#1e3d2f] text-[#86efac] text-xs font-medium border border-[#166534] transition-colors"
          title="立即触发全网跨行净额清算"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>即时清算</span>
        </button>
      </div>
    </div>
  );
};
