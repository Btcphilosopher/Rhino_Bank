import React, { useState, useMemo } from 'react';
import { 
  ArrowLeftRight, 
  Search, 
  Filter, 
  Send, 
  QrCode, 
  SmartphoneNfc, 
  Receipt, 
  Download, 
  ShieldCheck, 
  CheckCircle2, 
  AlertTriangle,
  FileText,
  Clock,
  Layers,
  Sparkles
} from 'lucide-react';
import { useSimulation } from '../simulation/SimulationContext';
import { Transaction, TransactionType, TransactionStatus } from '../types';
import { TxStatusBadge, ClearingStatusBadge, Badge } from '../components/common/Badge';
import { InstitutionalModal } from '../components/common/InstitutionalModal';

export const CirculationPage: React.FC = () => {
  const { 
    transactions, 
    wallets, 
    banks, 
    transferFunds, 
    injectBurstTransactions 
  } = useSimulation();

  // Filter states
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedBankFilter, setSelectedBankFilter] = useState<string>('ALL');
  const [selectedTypeFilter, setSelectedTypeFilter] = useState<string>('ALL');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>('ALL');
  const [minAmount, setMinAmount] = useState<string>('');
  const [maxAmount, setMaxAmount] = useState<string>('');

  // Payment Simulator Modal State
  const [isPayModalOpen, setIsPayModalOpen] = useState<boolean>(false);
  const [senderWalletId, setSenderWalletId] = useState<string>(wallets[0]?.id || '');
  const [receiverWalletId, setReceiverWalletId] = useState<string>(wallets[1]?.id || '');
  const [paymentAmount, setPaymentAmount] = useState<string>('120.00');
  const [paymentType, setPaymentType] = useState<TransactionType>('QR_CODE');
  const [paymentPurpose, setPaymentPurpose] = useState<string>('日常商业与政企服务结算');

  // Selected Tx receipt inspection
  const [selectedTx, setSelectedTx] = useState<Transaction | null>(null);
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);

  // Filter transactions
  const filteredTransactions = useMemo(() => {
    return transactions.filter(tx => {
      if (searchTerm) {
        const query = searchTerm.toLowerCase();
        const matchesId = tx.id.toLowerCase().includes(query);
        const matchesFrom = tx.fromWalletName.toLowerCase().includes(query);
        const matchesTo = tx.toWalletName.toLowerCase().includes(query);
        const matchesPurpose = tx.purpose.toLowerCase().includes(query);
        if (!matchesId && !matchesFrom && !matchesTo && !matchesPurpose) return false;
      }

      if (selectedBankFilter !== 'ALL') {
        if (tx.fromBankId !== selectedBankFilter && tx.toBankId !== selectedBankFilter) return false;
      }

      if (selectedTypeFilter !== 'ALL' && tx.type !== selectedTypeFilter) return false;
      if (selectedStatusFilter !== 'ALL' && tx.status !== selectedStatusFilter) return false;

      if (minAmount && tx.amount < parseFloat(minAmount)) return false;
      if (maxAmount && tx.amount > parseFloat(maxAmount)) return false;

      return true;
    });
  }, [transactions, searchTerm, selectedBankFilter, selectedTypeFilter, selectedStatusFilter, minAmount, maxAmount]);

  const handleExecutePayment = (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseFloat(paymentAmount);
    if (isNaN(amountNum) || amountNum <= 0) {
      alert('请输入有效的支付金额');
      return;
    }

    if (senderWalletId === receiverWalletId) {
      alert('付款方与收款方钱包不能相同');
      return;
    }

    const res = transferFunds({
      fromWalletId: senderWalletId,
      toWalletId: receiverWalletId,
      amount: amountNum,
      type: paymentType,
      purpose: paymentPurpose
    });

    if (res.success) {
      setFeedbackMsg(res.message);
      setIsPayModalOpen(false);
      if (res.tx) setSelectedTx(res.tx);
      setTimeout(() => setFeedbackMsg(null), 5000);
    } else {
      alert(res.message);
    }
  };

  const activeWallets = wallets.filter(w => w.status === 'ACTIVE');

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="bg-[#12151d] border border-[#1e2433] p-5 rounded-lg flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <ArrowLeftRight className="w-5 h-5 text-[#ef4444]" />
            <h2 className="text-lg font-bold text-white tracking-wide">
              数字人民币流通与核心账本 (Monetary Circulation & Core Ledger)
            </h2>
          </div>
          <p className="text-xs text-[#94a3b8] mt-1">
            提供全国跨行流通流水监控、支付类型分类过滤、实时验签上账及不可篡改账簿核查
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsPayModalOpen(true)}
            className="px-4 py-2 rounded-md bg-[#8b111a] hover:bg-[#a81622] text-white text-xs font-bold flex items-center gap-1.5 shadow-md transition-colors"
          >
            <Send className="w-3.5 h-3.5" />
            <span>发起模拟支付交易</span>
          </button>
          <button
            onClick={() => injectBurstTransactions(3)}
            className="px-3 py-2 rounded-md bg-[#182030] hover:bg-[#222c42] text-[#cbd5e1] border border-[#334155] text-xs font-medium flex items-center gap-1.5 transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>生成连续流水</span>
          </button>
        </div>
      </div>

      {/* Feedback banner */}
      {feedbackMsg && (
        <div className="p-3.5 bg-[#0f291e] border border-[#166534] rounded-lg text-emerald-300 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{feedbackMsg}</span>
          </div>
          <span className="font-mono-num text-[11px] text-emerald-400">核心账本状态机已完成状态推进</span>
        </div>
      )}

      {/* Filter Bar */}
      <div className="bg-[#12151d] border border-[#1e2433] p-4 rounded-lg space-y-3">
        <div className="flex items-center gap-2 text-xs font-semibold text-[#94a3b8]">
          <Filter className="w-3.5 h-3.5 text-[#ef4444]" />
          <span>账本多维度检索与穿透式筛选 (Ledger Filter Criteria)</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3 text-xs">
          {/* Search */}
          <div className="lg:col-span-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-[#64748b]" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="搜索流水号、付款方、收款方或用途..."
                className="w-full bg-[#0a0c10] border border-[#2a3449] rounded-md pl-8 pr-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#ef4444]"
              />
            </div>
          </div>

          {/* Bank */}
          <div>
            <select
              value={selectedBankFilter}
              onChange={(e) => setSelectedBankFilter(e.target.value)}
              className="w-full bg-[#0a0c10] border border-[#2a3449] rounded-md px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-[#ef4444]"
            >
              <option value="ALL">全部运营机构 (银行)</option>
              {banks.map(b => (
                <option key={b.id} value={b.id}>{b.name}</option>
              ))}
            </select>
          </div>

          {/* Type */}
          <div>
            <select
              value={selectedTypeFilter}
              onChange={(e) => setSelectedTypeFilter(e.target.value)}
              className="w-full bg-[#0a0c10] border border-[#2a3449] rounded-md px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-[#ef4444]"
            >
              <option value="ALL">全部支付方式</option>
              <option value="QR_CODE">扫码支付</option>
              <option value="NFC">NFC 碰一碰</option>
              <option value="TRANSFER">钱包转账</option>
              <option value="MERCHANT_PAY">商户收款</option>
              <option value="API_PAY">API 网关支付</option>
              <option value="DUAL_OFFLINE">双离线支付</option>
              <option value="PROGRAMMABLE">可编程支付</option>
            </select>
          </div>

          {/* Status */}
          <div>
            <select
              value={selectedStatusFilter}
              onChange={(e) => setSelectedStatusFilter(e.target.value)}
              className="w-full bg-[#0a0c10] border border-[#2a3449] rounded-md px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-[#ef4444]"
            >
              <option value="ALL">全部状态</option>
              <option value="SETTLED">已清算</option>
              <option value="COMPLETED">已完成 (待清算)</option>
              <option value="INTERCEPTED">风险拦截</option>
              <option value="REJECTED">已拒绝</option>
            </select>
          </div>

          {/* Amount range */}
          <div className="flex items-center gap-1.5">
            <input
              type="number"
              value={minAmount}
              onChange={(e) => setMinAmount(e.target.value)}
              placeholder="最小金额"
              className="w-1/2 bg-[#0a0c10] border border-[#2a3449] rounded-md px-2 py-1.5 text-xs text-white focus:outline-none"
            />
            <span className="text-[#64748b]">-</span>
            <input
              type="number"
              value={maxAmount}
              onChange={(e) => setMaxAmount(e.target.value)}
              placeholder="最大金额"
              className="w-1/2 bg-[#0a0c10] border border-[#2a3449] rounded-md px-2 py-1.5 text-xs text-white focus:outline-none"
            />
          </div>
        </div>
      </div>

      {/* Transactions Ledger Table */}
      <div className="bg-[#12151d] border border-[#1e2433] rounded-lg p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="text-xs text-[#94a3b8]">
            当前展示 <strong className="text-white font-mono-num">{filteredTransactions.length}</strong> 条交易记录 (累计总交易 {transactions.length} 笔)
          </div>
          <div className="text-[11px] text-[#64748b] font-mono-num flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
            <span>央行中心化账本实时写入</span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#0f121a] text-[#94a3b8] uppercase text-[11px] border-b border-[#1e2433]">
              <tr>
                <th className="py-3 px-3 font-semibold">流水编号</th>
                <th className="py-3 px-3 font-semibold">支付方式</th>
                <th className="py-3 px-3 font-semibold">付款方 (机构)</th>
                <th className="py-3 px-3 font-semibold">收款方 (机构)</th>
                <th className="py-3 px-3 font-semibold text-right">交易金额</th>
                <th className="py-3 px-3 font-semibold">用途 / 备注</th>
                <th className="py-3 px-3 font-semibold text-center">交易状态</th>
                <th className="py-3 px-3 font-semibold text-center">清算状态</th>
                <th className="py-3 px-3 font-semibold text-right">时间戳</th>
                <th className="py-3 px-3 font-semibold text-center">操作</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1a202c]">
              {filteredTransactions.map((tx) => (
                <tr key={tx.id} className="hover:bg-[#161a24] transition-colors">
                  <td className="py-3 px-3 font-mono-num font-medium text-white">
                    <div className="flex items-center gap-1.5">
                      {tx.isOffline && (
                        <span className="px-1 py-0.2 rounded bg-amber-950 text-amber-300 text-[9px] border border-amber-800">
                          脱机
                        </span>
                      )}
                      <span>{tx.id}</span>
                    </div>
                  </td>
                  <td className="py-3 px-3">
                    <span className="text-[11px] font-medium text-[#cbd5e1] px-1.5 py-0.5 rounded bg-[#181c28] border border-[#273042]">
                      {tx.type === 'QR_CODE' && '扫码支付'}
                      {tx.type === 'NFC' && 'NFC 碰一碰'}
                      {tx.type === 'TRANSFER' && '钱包转账'}
                      {tx.type === 'MERCHANT_PAY' && '商户收款'}
                      {tx.type === 'API_PAY' && 'API 网关'}
                      {tx.type === 'DUAL_OFFLINE' && '双离线支付'}
                      {tx.type === 'PROGRAMMABLE' && '智能合约'}
                      {tx.type === 'ISSUANCE' && '央行发行'}
                      {tx.type === 'REDEMPTION' && '机构回笼'}
                    </span>
                  </td>
                  <td className="py-3 px-3">
                    <div className="font-semibold text-white truncate max-w-[130px]">{tx.fromWalletName}</div>
                    <div className="text-[10px] text-[#64748b]">{tx.fromBankName}</div>
                  </td>
                  <td className="py-3 px-3">
                    <div className="font-semibold text-white truncate max-w-[130px]">{tx.toWalletName}</div>
                    <div className="text-[10px] text-[#64748b]">{tx.toBankName}</div>
                  </td>
                  <td className="py-3 px-3 text-right font-mono-num font-bold text-base text-white">
                    ¥ {tx.amount.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}
                  </td>
                  <td className="py-3 px-3">
                    <div className="text-xs text-[#cbd5e1] truncate max-w-[150px]">{tx.purpose}</div>
                    {tx.notes && (
                      <div className="text-[10px] text-red-400 truncate max-w-[150px]">{tx.notes}</div>
                    )}
                  </td>
                  <td className="py-3 px-3 text-center">
                    <TxStatusBadge status={tx.status} />
                  </td>
                  <td className="py-3 px-3 text-center">
                    <ClearingStatusBadge status={tx.clearingStatus} />
                  </td>
                  <td className="py-3 px-3 text-right font-mono-num text-[11px] text-[#64748b]">
                    {tx.timestamp}
                  </td>
                  <td className="py-3 px-3 text-center">
                    <button
                      onClick={() => setSelectedTx(tx)}
                      className="px-2 py-1 rounded bg-[#182133] hover:bg-[#26344f] text-sky-400 text-xs font-medium transition-colors"
                    >
                      凭证
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Payment Simulator Modal */}
      {isPayModalOpen && (
        <InstitutionalModal
          isOpen={isPayModalOpen}
          onClose={() => setIsPayModalOpen(false)}
          title="发起数字人民币模拟业务支付 (Payment Simulator)"
          subtitle="真实扣减付款方余额、增加收款方余额并同步生成清算轧差凭据"
        >
          <form onSubmit={handleExecutePayment} className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-[#94a3b8] mb-1">
                  付款方钱包 *
                </label>
                <select
                  value={senderWalletId}
                  onChange={(e) => setSenderWalletId(e.target.value)}
                  className="w-full bg-[#0a0c10] border border-[#2a3449] rounded-md px-3 py-2 text-xs text-white focus:outline-none focus:border-[#ef4444]"
                >
                  {wallets.map(w => (
                    <option key={w.id} value={w.id} disabled={w.status === 'FROZEN'}>
                      {w.name} ({w.bankName}) - 余额: ¥{w.balance.toLocaleString()} {w.status === 'FROZEN' ? '[已冻结]' : ''}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#94a3b8] mb-1">
                  收款方钱包 *
                </label>
                <select
                  value={receiverWalletId}
                  onChange={(e) => setReceiverWalletId(e.target.value)}
                  className="w-full bg-[#0a0c10] border border-[#2a3449] rounded-md px-3 py-2 text-xs text-white focus:outline-none focus:border-[#ef4444]"
                >
                  {wallets.map(w => (
                    <option key={w.id} value={w.id}>
                      {w.name} ({w.bankName})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-[#94a3b8] mb-1">
                  支付金额 (元) *
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2 text-xs text-[#64748b]">¥</span>
                  <input
                    type="number"
                    value={paymentAmount}
                    onChange={(e) => setPaymentAmount(e.target.value)}
                    className="w-full bg-[#0a0c10] border border-[#2a3449] rounded-md pl-7 pr-3 py-2 text-xs font-mono-num text-white focus:outline-none focus:border-[#ef4444]"
                    placeholder="100.00"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#94a3b8] mb-1">
                  支付方式 *
                </label>
                <select
                  value={paymentType}
                  onChange={(e) => setPaymentType(e.target.value as TransactionType)}
                  className="w-full bg-[#0a0c10] border border-[#2a3449] rounded-md px-3 py-2 text-xs text-white focus:outline-none focus:border-[#ef4444]"
                >
                  <option value="QR_CODE">扫码支付 (主扫/被扫)</option>
                  <option value="NFC">NFC 碰一碰即时感应</option>
                  <option value="TRANSFER">钱包直接转账</option>
                  <option value="MERCHANT_PAY">商户收银台收款</option>
                  <option value="API_PAY">政企 API 自动扣款</option>
                  <option value="DUAL_OFFLINE">双离线安全硬件支付</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#94a3b8] mb-1">
                交易用途与业务背景 *
              </label>
              <input
                type="text"
                value={paymentPurpose}
                onChange={(e) => setPaymentPurpose(e.target.value)}
                className="w-full bg-[#0a0c10] border border-[#2a3449] rounded-md px-3 py-2 text-xs text-white focus:outline-none focus:border-[#ef4444]"
              />
            </div>

            <div className="p-3 bg-[#0a0c10] rounded border border-[#1e2434] text-[11px] text-[#94a3b8] space-y-1">
              <div>交易验签: <span className="text-emerald-400 font-mono-num">国密 SM2 签名 + SM3 摘要哈希</span></div>
              <div>清算路径: <span className="text-sky-400 font-mono-num">同行内部即时到账 / 跨行自动排队入清算总中心</span></div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsPayModalOpen(false)}
                className="px-4 py-2 rounded bg-[#1a202c] hover:bg-[#252e40] text-[#94a3b8] text-xs"
              >
                取消
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded bg-[#8b111a] hover:bg-[#a81622] text-white text-xs font-bold shadow-md flex items-center gap-1.5"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>确认支付并写入账本</span>
              </button>
            </div>
          </form>
        </InstitutionalModal>
      )}

      {/* Transaction Receipt Inspector */}
      {selectedTx && (
        <InstitutionalModal
          isOpen={true}
          onClose={() => setSelectedTx(null)}
          title={`数字人民币交易凭证 (${selectedTx.id})`}
          subtitle="国家级中央银行数字货币电子回单 (带防伪签章)"
        >
          <div className="space-y-4 text-xs font-mono-num">
            <div className="p-5 bg-[#0a0c10] border border-[#1e2433] rounded-lg space-y-3 relative overflow-hidden">
              {/* Seal background effect */}
              <div className="absolute right-4 bottom-4 border-2 border-[#8b111a]/30 text-[#8b111a]/40 rounded-full w-24 h-24 flex items-center justify-center text-center text-[10px] font-bold rotate-[-15deg] pointer-events-none select-none">
                央行清算中心<br />电子验讫章
              </div>

              <div className="flex justify-between border-b border-[#1b2233] pb-2 text-sm font-bold text-white">
                <span>交易流水号</span>
                <span className="text-sky-400">{selectedTx.id}</span>
              </div>

              <div className="grid grid-cols-2 gap-3 py-2 border-b border-[#1b2233]">
                <div>
                  <span className="text-[#64748b] text-[11px] block">付款方主体:</span>
                  <span className="font-semibold text-white">{selectedTx.fromWalletName}</span>
                  <span className="text-[10px] text-[#94a3b8] block">{selectedTx.fromBankName} ({selectedTx.fromWalletId})</span>
                </div>
                <div>
                  <span className="text-[#64748b] text-[11px] block">收款方主体:</span>
                  <span className="font-semibold text-white">{selectedTx.toWalletName}</span>
                  <span className="text-[10px] text-[#94a3b8] block">{selectedTx.toBankName} ({selectedTx.toWalletId})</span>
                </div>
              </div>

              <div className="flex justify-between items-center py-2 border-b border-[#1b2233]">
                <span className="text-[#64748b]">交易金额 (人民币):</span>
                <span className="text-2xl font-bold text-emerald-400">
                  ¥ {selectedTx.amount.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3 py-1 text-xs">
                <div>
                  <span className="text-[#64748b]">支付方式:</span>
                  <span className="text-white font-medium ml-2">{selectedTx.type}</span>
                </div>
                <div>
                  <span className="text-[#64748b]">交易状态:</span>
                  <span className="text-emerald-400 font-medium ml-2">{selectedTx.status}</span>
                </div>
                <div>
                  <span className="text-[#64748b]">清算状态:</span>
                  <span className="text-sky-400 font-medium ml-2">{selectedTx.clearingStatus}</span>
                </div>
                <div>
                  <span className="text-[#64748b]">交易时间:</span>
                  <span className="text-white ml-2">{selectedTx.timestamp}</span>
                </div>
              </div>

              <div className="pt-2 border-t border-[#1b2233] text-[11px] text-[#64748b]">
                <div>用途说明: <span className="text-[#cbd5e1]">{selectedTx.purpose}</span></div>
                {selectedTx.isOffline && (
                  <div className="text-amber-400 mt-1">
                    * 本笔交易通过设备硬件 SE 芯片脱机完成，已于 {selectedTx.offlineSyncTime || '即时'} 完成对账上账。
                  </div>
                )}
              </div>
            </div>
          </div>
        </InstitutionalModal>
      )}
    </div>
  );
};
