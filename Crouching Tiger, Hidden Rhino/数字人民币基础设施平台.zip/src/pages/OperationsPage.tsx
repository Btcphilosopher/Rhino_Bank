import React, { useState } from 'react';
import { 
  Server, 
  Activity, 
  Cpu, 
  HardDrive, 
  ShieldCheck, 
  AlertCircle, 
  CheckCircle2, 
  RefreshCcw, 
  Wifi, 
  Layers, 
  Zap,
  Terminal,
  Database,
  Lock
} from 'lucide-react';
import { useSimulation } from '../simulation/SimulationContext';
import { MetricCard } from '../components/common/MetricCard';
import { Badge } from '../components/common/Badge';

export const OperationsPage: React.FC = () => {
  const { stats, banks, simulatedTime } = useSimulation();
  const [failoverStatus, setFailoverStatus] = useState<string | null>(null);
  const [isFailoverTesting, setIsFailoverTesting] = useState<boolean>(false);

  const triggerFailover = () => {
    setIsFailoverTesting(true);
    setFailoverStatus('正在执行【异地多活灾备中心】毫秒级无损流量切换演练...');
    setTimeout(() => {
      setIsFailoverTesting(false);
      setFailoverStatus('灾备演练圆满成功：已完成华北总中心至华东灾备中心的流量无缝切换，数据零丢失，RPO=0，RTO < 1.2s。');
      setTimeout(() => setFailoverStatus(null), 6000);
    }, 1500);
  };

  const systemServices = [
    { name: '央行法定数字货币核心账本记账引擎', status: 'HEALTHY', latency: '4.2ms', tps: '124,500', load: '18%' },
    { name: '跨机构多边净额与大额RTGS清算总中心', status: 'HEALTHY', latency: '6.8ms', tps: '85,200', load: '24%' },
    { name: '国家级国密算法硬件密码机 (SM2/SM3/SM4)', status: 'HEALTHY', latency: '1.1ms', tps: '320,000', load: '32%' },
    { name: '全网双离线安全硬件SE芯片对账与反双花中心', status: 'HEALTHY', latency: '12.4ms', tps: '42,000', load: '15%' },
    { name: '数字人民币智能合约与可编程执行沙箱 VM', status: 'HEALTHY', latency: '8.6ms', tps: '18,500', load: '19%' },
    { name: '实时毫秒级反洗钱(AML)风险研判与止付引擎', status: 'HEALTHY', latency: '5.3ms', tps: '110,000', load: '28%' },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#12151d] border border-[#1e2433] p-5 rounded-lg flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Server className="w-5 h-5 text-[#ef4444]" />
            <h2 className="text-lg font-bold text-white tracking-wide">
              系统运维与高可用集群控制台 (CBDC Infrastructure & Operations)
            </h2>
          </div>
          <p className="text-xs text-[#94a3b8] mt-1">
            监控“两地三中心”国家金融级分布式集群高可用状态、国密硬件加密机负载及微服务拓扑
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={triggerFailover}
            disabled={isFailoverTesting}
            className="px-3.5 py-2 rounded-md bg-[#1e2538] hover:bg-[#2c374f] text-sky-300 border border-[#334155] text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <RefreshCcw className={`w-3.5 h-3.5 ${isFailoverTesting ? 'animate-spin text-amber-400' : ''}`} />
            <span>执行异地灾备无损切换演练</span>
          </button>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
        <MetricCard
          title="系统整体可用性 (SLA)"
          value="99.999%"
          subLabel="年度连续无故障运行"
          subValue="365 天 24 小时"
          icon={ShieldCheck}
          highlight={true}
        />
        <MetricCard
          title="核心集群 CPU 平均负载"
          value="23.4%"
          subLabel="分布式节点数"
          subValue="128 物理服务器"
          icon={Cpu}
        />
        <MetricCard
          title="系统端到端平均延迟"
          value="18.2 ms"
          subLabel="实时吞吐量"
          subValue={`${stats.realTimeTps} TPS`}
          icon={Activity}
        />
        <MetricCard
          title="国密硬件加密机状态"
          value="全部在线 (32台)"
          subLabel="硬件真随机数熵源"
          subValue="100% 达标"
          icon={Lock}
        />
      </div>

      {/* Failover Feedback */}
      {failoverStatus && (
        <div className="p-4 bg-[#0a0c10] border border-[#232c3f] rounded-lg text-xs flex items-center justify-between text-emerald-300">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span className="font-semibold">{failoverStatus}</span>
          </div>
          <span className="font-mono-num text-sky-400 text-[11px]">容灾恢复指标 RPO=0 RTO=1.18s</span>
        </div>
      )}

      {/* Microservice Health Grid */}
      <div className="bg-[#12151d] border border-[#1e2433] rounded-lg p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-[#ef4444]" />
              央行核心业务微服务与密码机集群健康矩阵
            </h3>
            <p className="text-xs text-[#94a3b8] mt-0.5">
              全量采用容器化分布式架构，支持秒级弹性横向扩展与热升级
            </p>
          </div>
          <Badge variant="green">全服务集群正常</Badge>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#0f121a] text-[#94a3b8] uppercase text-[11px] border-b border-[#1e2433]">
              <tr>
                <th className="py-2.5 px-3">服务与组件名称</th>
                <th className="py-2.5 px-3">运行状态</th>
                <th className="py-2.5 px-3 text-right">处理延迟</th>
                <th className="py-2.5 px-3 text-right">实时承载能力 (TPS)</th>
                <th className="py-2.5 px-3 text-right">资源占用率</th>
                <th className="py-2.5 px-3 text-center">加密等级</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1a202c]">
              {systemServices.map((s, idx) => (
                <tr key={idx} className="hover:bg-[#161a24]">
                  <td className="py-3 px-3 font-semibold text-white flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                    <span>{s.name}</span>
                  </td>
                  <td className="py-3 px-3">
                    <Badge variant="green">HEALTHY</Badge>
                  </td>
                  <td className="py-3 px-3 text-right font-mono-num text-emerald-400 font-semibold">{s.latency}</td>
                  <td className="py-3 px-3 text-right font-mono-num font-bold text-white">{s.tps}</td>
                  <td className="py-3 px-3 text-right font-mono-num text-[#cbd5e1]">{s.load}</td>
                  <td className="py-3 px-3 text-center">
                    <span className="text-[10px] font-mono-num px-1.5 py-0.5 rounded bg-[#1c2233] text-sky-400 border border-[#27354f]">
                      GM/T 0028 4级
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Cluster Nodes & Real-Time Console Log */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Node Topology */}
        <div className="bg-[#12151d] border border-[#1e2433] rounded-lg p-5 space-y-3 text-xs">
          <h3 className="text-sm font-semibold text-white flex items-center gap-2">
            <Server className="w-4 h-4 text-sky-400" />
            国家级“两地三中心”物理节点拓扑
          </h3>

          <div className="space-y-2">
            {[
              { site: '北京金融街总中心 (生产中心A)', status: 'ACTIVE 主中心', ip: '10.120.10.1', role: '全量记账与RTGS清算' },
              { site: '北京稻香湖数据中心 (生产中心B)', status: 'ACTIVE 双活节点', ip: '10.120.20.1', role: '微服务负载均衡与风控' },
              { site: '上海张江异地容灾中心 (灾备中心C)', status: 'STANDBY 热备双向同步', ip: '10.130.10.1', role: '异地实时容灾与冷归档' },
            ].map((node, i) => (
              <div key={i} className="p-3 bg-[#0a0c10] rounded border border-[#1e2433] flex justify-between items-center">
                <div>
                  <div className="font-semibold text-white">{node.site}</div>
                  <div className="text-[10px] text-[#64748b] font-mono-num mt-0.5">{node.ip} | {node.role}</div>
                </div>
                <Badge variant="blue">{node.status}</Badge>
              </div>
            ))}
          </div>
        </div>

        {/* Live Terminal Log */}
        <div className="bg-[#12151d] border border-[#1e2433] rounded-lg p-5 space-y-3 text-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <Terminal className="w-4 h-4 text-emerald-400" />
              央行核心运维控制台日志流
            </h3>
            <span className="text-[10px] font-mono-num text-emerald-400">● LIVE</span>
          </div>

          <div className="p-3 bg-[#050608] rounded-md border border-[#19202f] font-mono-num text-[11px] text-[#86efac] space-y-1.5 h-[160px] overflow-y-auto">
            <div>[{simulatedTime}] [INFO] [CoreLedgerEngine] Block checkpoint verified. Consensus state: Synced.</div>
            <div>[{simulatedTime}] [INFO] [SM2KeyCluster] Hardware cryptographic entropy test: PASS (Shannon score 7.9999).</div>
            <div>[{simulatedTime}] [INFO] [ClearingDaemon] Bilateral & Multilateral queue balance checked. 0 mismatch.</div>
            <div>[{simulatedTime}] [INFO] [DualOfflineSync] Monotonic counter verification batch #4812 completed.</div>
            <div>[{simulatedTime}] [INFO] [AMLFilter] High-frequency pattern scanning active. Zero anomaly threshold exceeded.</div>
          </div>
        </div>
      </div>
    </div>
  );
};
