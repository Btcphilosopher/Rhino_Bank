import React, { useState } from 'react';
import { 
  WalletCards, 
  User, 
  Building2, 
  Store, 
  ShieldCheck, 
  Plus, 
  Lock, 
  Unlock, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Search, 
  Filter, 
  CreditCard, 
  CheckCircle2, 
  SmartphoneNfc,
  Cpu,
  History
} from 'lucide-react';
import { useSimulation } from '../simulation/SimulationContext';
import { Wallet, WalletType, KycLevel } from '../types';
import { WalletStatusBadge, KycBadge, Badge } from '../components/common/Badge';
import { InstitutionalModal } from '../components/common/InstitutionalModal';

export const WalletManagerPage: React.FC = () => {
  const { 
    wallets, 
    banks, 
    freezeWallet, 
    unfreezeWallet, 
    createWallet, 
    transferFunds,
    simulatedTime 
  } = useSimulation();

  const [selectedWallet, setSelectedWallet] = useState<Wallet | null>(null);
  const [filterType, setFilterType] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Modals
  const [isCreateOpen, setIsCreateOpen] = useState<boolean>(false);
  const [isTopUpOpen, setIsTopUpOpen] = useState<boolean>(false);
  const [topUpAmount, setTopUpAmount] = useState<string>('1000.00');

  // Create Wallet Form
  const [newName, setNewName] = useState<string>('');
  const [newType, setNewType] = useState<WalletType>('PERSONAL');
  const [newBankId, setNewBankId] = useState<string>('ICBC');
  const [newKyc, setNewKyc] = useState<KycLevel>('LEVEL_1');
  const [newInitialBalance, setNewInitialBalance] = useState<string>('5000.00');

  // Filtered Wallets
  const filteredWallets = wallets.filter(w => {
    if (filterType !== 'ALL' && w.type !== filterType) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return w.id.toLowerCase().includes(q) || w.name.toLowerCase().includes(q) || w.bankName.toLowerCase().includes(q);
    }
    return true;
  });

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) {
      alert('请输入钱包名称或主体姓名');
      return;
    }
    const balanceNum = parseFloat(newInitialBalance) || 0;
    const created = createWallet({
      name: newName,
      type: newType,
      bankId: newBankId,
      kycLevel: newKyc,
      initialBalance: balanceNum
    });

    setIsCreateOpen(false);
    setSelectedWallet(created);
    setNewName('');
    alert(`成功开立数字人民币钱包：${created.name} (${created.id})`);
  };

  const handleTopUpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedWallet) return;
    const amountNum = parseFloat(topUpAmount);
    if (isNaN(amountNum) || amountNum <= 0) return;

    // Find a bank source or funding wallet
    const fundSource = wallets.find(w => w.type === 'INSTITUTION' || w.type === 'ENTERPRISE') || wallets[1];
    transferFunds({
      fromWalletId: fundSource.id,
      toWalletId: selectedWallet.id,
      amount: amountNum,
      type: 'TRANSFER',
      purpose: '商业银行借记卡对公/对私数字人民币等额充值兑换'
    });

    setIsTopUpOpen(false);
    alert(`充值成功：已为 ${selectedWallet.name} 注入 ¥${amountNum.toFixed(2)}`);
  };

  const getWalletTypeLabel = (type: WalletType) => {
    switch (type) {
      case 'PERSONAL': return '个人钱包';
      case 'ENTERPRISE': return '企业对公钱包';
      case 'MERCHANT': return '商户收银钱包';
      case 'INSTITUTION': return '政府/机构钱包';
      case 'BANK': return '银行储备钱包';
      case 'SPECIAL': return '特殊监管专户';
      default: return type;
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-[#12151d] border border-[#1e2433] p-5 rounded-lg flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <WalletCards className="w-5 h-5 text-[#ef4444]" />
            <h2 className="text-lg font-bold text-white tracking-wide">
              数字人民币钱包体系管理中心 (Digital Wallet System)
            </h2>
          </div>
          <p className="text-xs text-[#94a3b8] mt-1">
            支持一至四类个人钱包、企业对公钱包、政务机构专户及硬件安全SE芯片绑定管理
          </p>
        </div>

        <button
          onClick={() => setIsCreateOpen(true)}
          className="px-4 py-2 rounded-md bg-[#8b111a] hover:bg-[#a81622] text-white text-xs font-bold flex items-center gap-1.5 shadow-md transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>开立新数字钱包</span>
        </button>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-[#12151d] border border-[#1e2433] p-4 rounded-lg flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 flex-1 max-w-md">
          <div className="relative w-full">
            <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-[#64748b]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="搜索钱包编号、主体名称或运营银行..."
              className="w-full bg-[#0a0c10] border border-[#2a3449] rounded-md pl-8 pr-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#ef4444]"
            />
          </div>
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto">
          {[
            { id: 'ALL', label: '全部钱包' },
            { id: 'PERSONAL', label: '个人钱包' },
            { id: 'ENTERPRISE', label: '企业钱包' },
            { id: 'MERCHANT', label: '商户钱包' },
            { id: 'INSTITUTION', label: '机构专户' },
            { id: 'SPECIAL', label: '特殊用途' }
          ].map(t => (
            <button
              key={t.id}
              onClick={() => setFilterType(t.id)}
              className={`px-3 py-1.5 rounded text-xs font-medium transition-colors whitespace-nowrap ${
                filterType === t.id ? 'bg-[#8b111a] text-white' : 'bg-[#181c28] text-[#94a3b8] hover:text-white'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Wallet Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {filteredWallets.map((w) => (
          <div
            key={w.id}
            onClick={() => setSelectedWallet(w)}
            className={`p-5 rounded-lg border cursor-pointer transition-all relative overflow-hidden flex flex-col justify-between ${
              selectedWallet?.id === w.id
                ? 'bg-[#1a1722] border-[#8b111a] shadow-md shadow-[#8b111a]/20'
                : 'bg-[#12151d] border-[#1e2433] hover:border-[#2f3a52]'
            }`}
          >
            <div>
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="text-[10px] font-mono-num font-medium px-1.5 py-0.5 rounded bg-[#1b2130] text-[#94a3b8] border border-[#2a3449]">
                  {w.bankName}
                </span>
                <WalletStatusBadge status={w.status} />
              </div>

              <div className="font-bold text-white text-sm tracking-tight mb-1 truncate" title={w.name}>
                {w.name}
              </div>

              <div className="text-[11px] font-mono-num text-[#64748b] mb-4">
                {w.id}
              </div>

              {/* Balance display */}
              <div className="bg-[#0a0c10] p-3 rounded border border-[#1b202e] mb-3">
                <span className="text-[10px] text-[#64748b] block mb-0.5">钱包余额</span>
                <span className="text-xl font-bold font-mono-num text-white">
                  ¥ {w.balance.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}
                </span>
                {w.frozenBalance > 0 && (
                  <span className="text-[10px] text-red-400 block mt-1">
                    (冻结 ¥{w.frozenBalance.toLocaleString()})
                  </span>
                )}
              </div>
            </div>

            <div className="space-y-2 pt-2 border-t border-[#181e2b] text-[11px]">
              <div className="flex justify-between text-[#94a3b8]">
                <span>类型:</span>
                <span className="text-[#cbd5e1] font-medium">{getWalletTypeLabel(w.type)}</span>
              </div>
              <div className="flex justify-between text-[#94a3b8]">
                <span>KYC 等级:</span>
                <span className="text-amber-400 font-medium">{w.kycLevel}</span>
              </div>
              {w.hardwareChipId && (
                <div className="flex justify-between text-[#94a3b8]">
                  <span>离线芯片:</span>
                  <span className="text-sky-300 font-mono-num text-[10px]">{w.hardwareChipId}</span>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Selected Wallet Detail Inspector Drawer/Card */}
      {selectedWallet && (
        <div className="bg-[#12151d] border border-[#1e2433] rounded-lg p-6 space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-[#1e2433]">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-[#291419] border border-[#7f1d1d] flex items-center justify-center text-[#f87171]">
                <CreditCard className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-bold text-white">{selectedWallet.name}</h3>
                  <WalletStatusBadge status={selectedWallet.status} />
                  <KycBadge level={selectedWallet.kycLevel} />
                </div>
                <div className="text-xs text-[#94a3b8] font-mono-num mt-0.5">
                  钱包编号: {selectedWallet.id} | 运营机构: {selectedWallet.bankName} ({selectedWallet.bankId})
                </div>
              </div>
            </div>

            {/* Quick Actions for selected wallet */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsTopUpOpen(true)}
                className="px-3 py-1.5 rounded bg-[#163e2c] hover:bg-[#1f543c] text-[#86efac] border border-[#166534] text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <ArrowDownLeft className="w-3.5 h-3.5" />
                <span>充值 / 兑换</span>
              </button>

              {selectedWallet.status === 'ACTIVE' ? (
                <button
                  onClick={() => freezeWallet(selectedWallet.id, '央行反洗钱风险应急管控')}
                  className="px-3 py-1.5 rounded bg-[#3b1216] hover:bg-[#4d171d] text-[#fca5a5] border border-[#7f1d1d] text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>全网冻结</span>
                </button>
              ) : (
                <button
                  onClick={() => unfreezeWallet(selectedWallet.id)}
                  className="px-3 py-1.5 rounded bg-[#172554] hover:bg-[#1e3a8a] text-[#93c5fd] border border-[#1d4ed8] text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <Unlock className="w-3.5 h-3.5" />
                  <span>解除冻结</span>
                </button>
              )}
            </div>
          </div>

          {/* 4 Financial Sub-accounts of Wallet */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            <div className="p-4 bg-[#0a0c10] border border-[#1e2433] rounded-lg">
              <span className="text-xs text-[#64748b]">总余额 (总资产)</span>
              <div className="text-2xl font-bold text-white font-mono-num mt-1">
                ¥ {selectedWallet.balance.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}
              </div>
            </div>

            <div className="p-4 bg-[#0a0c10] border border-[#1e2433] rounded-lg">
              <span className="text-xs text-[#64748b]">可用余额</span>
              <div className="text-2xl font-bold text-emerald-400 font-mono-num mt-1">
                ¥ {selectedWallet.availableBalance.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}
              </div>
            </div>

            <div className="p-4 bg-[#0a0c10] border border-[#1e2433] rounded-lg">
              <span className="text-xs text-[#64748b]">冻结金额 (风险止付)</span>
              <div className="text-2xl font-bold text-red-400 font-mono-num mt-1">
                ¥ {selectedWallet.frozenBalance.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}
              </div>
            </div>

            <div className="p-4 bg-[#0a0c10] border border-[#1e2433] rounded-lg">
              <span className="text-xs text-[#64748b]">离线可用额度 (SE芯片)</span>
              <div className="text-2xl font-bold text-sky-400 font-mono-num mt-1">
                ¥ {selectedWallet.offlineQuota.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}
              </div>
            </div>
          </div>

          {/* Detailed Specifications */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div className="p-4 bg-[#141824] rounded-lg border border-[#20283d] space-y-2">
              <div className="font-semibold text-white">限额与支付控制</div>
              <div className="flex justify-between text-[#94a3b8]">
                <span>单笔限额:</span>
                <span className="font-mono-num text-white">¥ {selectedWallet.singleLimit.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-[#94a3b8]">
                <span>日累计限额:</span>
                <span className="font-mono-num text-white">¥ {selectedWallet.dailyLimit.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-[#94a3b8]">
                <span>KYC 认证级别:</span>
                <span className="text-amber-400">{selectedWallet.kycLevel}</span>
              </div>
            </div>

            <div className="p-4 bg-[#141824] rounded-lg border border-[#20283d] space-y-2">
              <div className="font-semibold text-white">交易流水统计</div>
              <div className="flex justify-between text-[#94a3b8]">
                <span>累计交易总笔数:</span>
                <span className="font-mono-num text-white">{selectedWallet.txCount} 笔</span>
              </div>
              <div className="flex justify-between text-[#94a3b8]">
                <span>累计入账金额:</span>
                <span className="font-mono-num text-emerald-400">¥ {selectedWallet.totalInflow.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-[#94a3b8]">
                <span>累计支出金额:</span>
                <span className="font-mono-num text-[#94a3b8]">¥ {selectedWallet.totalOutflow.toLocaleString()}</span>
              </div>
            </div>

            <div className="p-4 bg-[#141824] rounded-lg border border-[#20283d] space-y-2">
              <div className="font-semibold text-white">安全与硬件凭证</div>
              <div className="flex justify-between text-[#94a3b8]">
                <span>风险评级:</span>
                <span className="text-emerald-400 font-bold">{selectedWallet.riskLevel}</span>
              </div>
              <div className="flex justify-between text-[#94a3b8]">
                <span>硬件SE芯片号:</span>
                <span className="font-mono-num text-sky-300">{selectedWallet.hardwareChipId || '未绑定脱机硬件'}</span>
              </div>
              <div className="flex justify-between text-[#94a3b8]">
                <span>最近交易时戳:</span>
                <span className="font-mono-num text-[#cbd5e1] text-[10px]">{selectedWallet.lastTxTime}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Create Wallet Modal */}
      {isCreateOpen && (
        <InstitutionalModal
          isOpen={isCreateOpen}
          onClose={() => setIsCreateOpen(false)}
          title="开立数字人民币新钱包 (Create Digital Wallet)"
          subtitle="完成实名认证、二级运营机构绑定与初始账户初始化"
        >
          <form onSubmit={handleCreateSubmit} className="space-y-4 text-xs">
            <div>
              <label className="block text-xs font-medium text-[#94a3b8] mb-1">
                钱包主体姓名 / 企业全称 *
              </label>
              <input
                type="text"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="例如：北京首钢高新技术分公司 或 王秀兰"
                className="w-full bg-[#0a0c10] border border-[#2a3449] rounded-md px-3 py-2 text-xs text-white focus:outline-none focus:border-[#ef4444]"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-[#94a3b8] mb-1">
                  钱包类型 *
                </label>
                <select
                  value={newType}
                  onChange={(e) => setNewType(e.target.value as WalletType)}
                  className="w-full bg-[#0a0c10] border border-[#2a3449] rounded-md px-3 py-2 text-xs text-white focus:outline-none focus:border-[#ef4444]"
                >
                  <option value="PERSONAL">个人钱包</option>
                  <option value="ENTERPRISE">企业对公钱包</option>
                  <option value="MERCHANT">商户收款钱包</option>
                  <option value="INSTITUTION">政府机构专户</option>
                  <option value="SPECIAL">特殊监管用途</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#94a3b8] mb-1">
                  开户运营机构 (银行) *
                </label>
                <select
                  value={newBankId}
                  onChange={(e) => setNewBankId(e.target.value)}
                  className="w-full bg-[#0a0c10] border border-[#2a3449] rounded-md px-3 py-2 text-xs text-white focus:outline-none focus:border-[#ef4444]"
                >
                  {banks.map(b => (
                    <option key={b.id} value={b.id}>{b.name}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-[#94a3b8] mb-1">
                  KYC 认证级别 *
                </label>
                <select
                  value={newKyc}
                  onChange={(e) => setNewKyc(e.target.value as KycLevel)}
                  className="w-full bg-[#0a0c10] border border-[#2a3449] rounded-md px-3 py-2 text-xs text-white focus:outline-none focus:border-[#ef4444]"
                >
                  <option value="LEVEL_1">一类 (强实名认证/无额度上限)</option>
                  <option value="LEVEL_2">二类 (实名认证/单笔5万/日10万)</option>
                  <option value="LEVEL_3">三类 (有效身份证/单笔5千/日1万)</option>
                  <option value="LEVEL_4">四类 (匿名手机号/单笔1千/日2千)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#94a3b8] mb-1">
                  初始充值金额 (元)
                </label>
                <input
                  type="number"
                  value={newInitialBalance}
                  onChange={(e) => setNewInitialBalance(e.target.value)}
                  className="w-full bg-[#0a0c10] border border-[#2a3449] rounded-md px-3 py-2 text-xs font-mono-num text-white focus:outline-none focus:border-[#ef4444]"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsCreateOpen(false)}
                className="px-4 py-2 rounded bg-[#1a202c] hover:bg-[#252e40] text-[#94a3b8] text-xs"
              >
                取消
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded bg-[#8b111a] hover:bg-[#a81622] text-white text-xs font-bold"
              >
                核准开立钱包
              </button>
            </div>
          </form>
        </InstitutionalModal>
      )}

      {/* Top-up Modal */}
      {isTopUpOpen && selectedWallet && (
        <InstitutionalModal
          isOpen={isTopUpOpen}
          onClose={() => setIsTopUpOpen(false)}
          title={`向 ${selectedWallet.name} 充值兑换`}
          subtitle="商业银行借记账户等额扣减并存入数字人民币"
        >
          <form onSubmit={handleTopUpSubmit} className="space-y-4 text-xs">
            <div>
              <label className="block text-xs font-medium text-[#94a3b8] mb-1">
                充值金额 (元) *
              </label>
              <input
                type="number"
                value={topUpAmount}
                onChange={(e) => setTopUpAmount(e.target.value)}
                className="w-full bg-[#0a0c10] border border-[#2a3449] rounded-md px-3 py-2 text-xs font-mono-num text-white focus:outline-none focus:border-emerald-400"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsTopUpOpen(false)}
                className="px-4 py-2 rounded bg-[#1a202c] hover:bg-[#252e40] text-[#94a3b8] text-xs"
              >
                取消
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded bg-[#166534] hover:bg-[#15803d] text-white text-xs font-bold"
              >
                确认兑换存入
              </button>
            </div>
          </form>
        </InstitutionalModal>
      )}
    </div>
  );
};
