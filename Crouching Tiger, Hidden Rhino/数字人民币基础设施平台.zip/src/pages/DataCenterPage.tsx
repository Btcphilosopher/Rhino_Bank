import React, { useState } from 'react';
import { 
  Database, 
  Download, 
  FileText, 
  CheckCircle2, 
  Search, 
  Layers, 
  HardDrive, 
  Calendar, 
  ShieldCheck, 
  FileCheck 
} from 'lucide-react';
import { useSimulation } from '../simulation/SimulationContext';
import { MetricCard } from '../components/common/MetricCard';
import { Badge } from '../components/common/Badge';

export const DataCenterPage: React.FC = () => {
  const { transactions, issuanceBatches, banks, wallets, stats } = useSimulation();
  const [reportType, setReportType] = useState<string>('DAILY_CLEARING');
  const [exportFeedback, setExportFeedback] = useState<string | null>(null);

  const handleExport = (name: string) => {
    setExportFeedback(`成功导出【${name}】电子数据包 (SHA256 签名校验完毕)`);
    setTimeout(() => setExportFeedback(null), 4000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#12151d] border border-[#1e2433] p-5 rounded-lg flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Database className="w-5 h-5 text-[#ef4444]" />
            <h2 className="text-lg font-bold text-white tracking-wide">
              数字人民币国家级数据中心 (CBDC Big Data & Audit Center)
            </h2>
          </div>
          <p className="text-xs text-[#94a3b8] mt-1">
            提供法定数字货币全网历史流水冷热分层归档、央行会计日终决算报表生成及不可篡改防伪验签
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Badge variant="blue">数据分级分类与商密保护已启用</Badge>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
        <MetricCard
          title="数据中心归档总量"
          value="48.6 TB"
          subLabel="存储压缩比"
          subValue="12 : 1 (高效冷存储)"
          icon={HardDrive}
          highlight={true}
        />
        <MetricCard
          title="不可篡改审计日志"
          value={`${transactions.length + issuanceBatches.length + 12480} 条`}
          subLabel="国密签名完整度"
          subValue="100.00%"
          icon={ShieldCheck}
        />
        <MetricCard
          title="日终批处理耗时"
          value="4 分 12 秒"
          subLabel="全网总分核对"
          subValue="分毫不差"
          icon={Calendar}
        />
        <MetricCard
          title="监管调阅合规审计"
          value="0 违规"
          subLabel="数据脱敏评级"
          subValue="符合金融数据安全规范"
          icon={FileCheck}
        />
      </div>

      {/* Export Feedback Banner */}
      {exportFeedback && (
        <div className="p-3.5 bg-[#0f291e] border border-[#166534] rounded-lg text-emerald-300 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{exportFeedback}</span>
          </div>
          <span className="font-mono-num text-[11px] text-emerald-400">已生成防篡改数字签名水印</span>
        </div>
      )}

      {/* Report Generation & Data Export Console */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-[#12151d] border border-[#1e2433] rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#1e2433]">
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <FileText className="w-4 h-4 text-[#ef4444]" />
              央行标准化会计决算与清算报表导出
            </h3>
            <span className="text-[11px] text-[#64748b]">支持 CSV / PDF / XML 格式</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="p-4 bg-[#0a0c10] rounded-lg border border-[#1e2433] flex flex-col justify-between space-y-3">
              <div>
                <div className="font-bold text-white text-sm">中国人民银行数字人民币日终清算决算总表</div>
                <p className="text-[11px] text-[#94a3b8] mt-1 leading-relaxed">
                  包含九大运营机构今日备付金借贷轧差、发行回笼及期末余额对账明细。
                </p>
              </div>
              <button
                onClick={() => handleExport('中国人民银行数字人民币日终清算决算总表')}
                className="w-full py-2 bg-[#1b2538] hover:bg-[#25354f] text-sky-400 font-bold rounded flex items-center justify-center gap-1.5 transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>生成并下载日终报告</span>
              </button>
            </div>

            <div className="p-4 bg-[#0a0c10] rounded-lg border border-[#1e2433] flex flex-col justify-between space-y-3">
              <div>
                <div className="font-bold text-white text-sm">全网反洗钱 AML 可疑交易穿透式审计清单</div>
                <p className="text-[11px] text-[#94a3b8] mt-1 leading-relaxed">
                  汇总今日全部触及风控拦截、冻结、高频小额离线等可疑线索及处置结果。
                </p>
              </div>
              <button
                onClick={() => handleExport('全网反洗钱 AML 可疑交易穿透式审计清单')}
                className="w-full py-2 bg-[#1b2538] hover:bg-[#25354f] text-sky-400 font-bold rounded flex items-center justify-center gap-1.5 transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>导出 AML 监管台账</span>
              </button>
            </div>

            <div className="p-4 bg-[#0a0c10] rounded-lg border border-[#1e2433] flex flex-col justify-between space-y-3">
              <div>
                <div className="font-bold text-white text-sm">各省市试点区域数字人民币流通活跃度评估</div>
                <p className="text-[11px] text-[#94a3b8] mt-1 leading-relaxed">
                  统计粤港澳、长三角、京津冀等核心城市群 M0 渗透率、商户覆核及消费流向。
                </p>
              </div>
              <button
                onClick={() => handleExport('各省市试点区域流通活跃度评估')}
                className="w-full py-2 bg-[#1b2538] hover:bg-[#25354f] text-sky-400 font-bold rounded flex items-center justify-center gap-1.5 transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>导出区域评估报告</span>
              </button>
            </div>

            <div className="p-4 bg-[#0a0c10] rounded-lg border border-[#1e2433] flex flex-col justify-between space-y-3">
              <div>
                <div className="font-bold text-white text-sm">可编程智能合约专项资金托管执行台账</div>
                <p className="text-[11px] text-[#94a3b8] mt-1 leading-relaxed">
                  财政定向补贴、消费红包及供应链金融智能合约预算拨付与核销明细。
                </p>
              </div>
              <button
                onClick={() => handleExport('可编程智能合约专项资金托管执行台账')}
                className="w-full py-2 bg-[#1b2538] hover:bg-[#25354f] text-sky-400 font-bold rounded flex items-center justify-center gap-1.5 transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>导出合约资金台账</span>
              </button>
            </div>
          </div>
        </div>

        {/* Audit Log Stream */}
        <div className="bg-[#12151d] border border-[#1e2433] rounded-lg p-5 space-y-3 text-xs">
          <h3 className="text-sm font-semibold text-white flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            核心不可篡改审计日志
          </h3>

          <div className="space-y-2 font-mono-num text-[11px]">
            {issuanceBatches.slice(0, 4).map((b, i) => (
              <div key={i} className="p-2.5 bg-[#0a0c10] rounded border border-[#1c2230]">
                <div className="flex justify-between text-[#94a3b8]">
                  <span>{b.id}</span>
                  <span className="text-emerald-400">HASH OK</span>
                </div>
                <div className="text-white truncate mt-0.5">{b.purpose}</div>
                <div className="text-[10px] text-[#64748b] truncate">{b.auditHash}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
