import React, { useState } from 'react';
import { 
  SmartphoneNfc, 
  Cpu, 
  WifiOff, 
  RefreshCcw, 
  ShieldCheck, 
  Zap, 
  CheckCircle2, 
  AlertTriangle, 
  ArrowRight,
  HardDrive,
  CreditCard,
  Lock
} from 'lucide-react';
import { useSimulation } from '../simulation/SimulationContext';
import { MetricCard } from '../components/common/MetricCard';
import { Badge } from '../components/common/Badge';
import { InstitutionalModal } from '../components/common/InstitutionalModal';

export const OfflinePaymentPage: React.FC = () => {
  const { 
    wallets, 
    transactions, 
    transferFunds, 
    simulatedTime 
  } = useSimulation();

  // Dual Offline Simulation State
  const [offlinePayerId, setOfflinePayerId] = useState<string>('W-2026-8801');
  const [offlinePayeeId, setOfflinePayeeId] = useState<string>('W-2026-8803');
  const [offlineAmount, setOfflineAmount] = useState<string>('45.50');
  const [offlineStep, setOfflineStep] = useState<number>(0);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [syncFeedback, setSyncFeedback] = useState<string | null>(null);

  // Hardware Wallets
  const hardwareWallets = wallets.filter(w => w.hardwareChipId);
  const offlineTransactions = transactions.filter(t => t.isOffline);

  const startDualOfflinePayment = () => {
    if (offlinePayerId === offlinePayeeId) {
      alert('付款方与收款方不能相同');
      return;
    }
    const amt = parseFloat(offlineAmount);
    if (isNaN(amt) || amt <= 0) {
      alert('请输入有效金额');
      return;
    }

    setIsSimulating(true);
    setOfflineStep(1);

    // Step 1: NFC Hardware Touch
    setTimeout(() => {
      setOfflineStep(2); // Step 2: SE Chip local signing & counter increment
      setTimeout(() => {
        setOfflineStep(3); // Step 3: Offline Voucher Generation
        setTimeout(() => {
          setOfflineStep(4); // Step 4: Deferred cloud synchronization
          // Execute transfer in simulation
          transferFunds({
            fromWalletId: offlinePayerId,
            toWalletId: offlinePayeeId,
            amount: amt,
            type: 'DUAL_OFFLINE',
            purpose: '地铁与偏远山区双离线碰一碰法偿支付'
          });
          setIsSimulating(false);
          setSyncFeedback(`双离线支付模拟完成：已生成国密SM2脱机签名凭证，并完成云端批量对账`);
          setTimeout(() => setSyncFeedback(null), 5000);
        }, 800);
      }, 800);
    }, 800);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#12151d] border border-[#1e2433] p-5 rounded-lg flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <SmartphoneNfc className="w-5 h-5 text-[#ef4444]" />
            <h2 className="text-lg font-bold text-white tracking-wide">
              双离线支付与硬件安全芯片管理 (Dual Offline & Hardware Security Center)
            </h2>
          </div>
          <p className="text-xs text-[#94a3b8] mt-1">
            在无移动通信信号与互联网连接极端环境下，通过安全硬件SE芯片与NFC近场通信实现法定现钞级双离线支付
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Badge variant="gold">国密安全硬件 SE 认证</Badge>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
        <MetricCard
          title="在册安全硬件钱包卡"
          value={`${hardwareWallets.length * 4820 + 2410} 枚`}
          subLabel="芯片认证级别"
          subValue="CCEAL6+ 最高等级"
          icon={Cpu}
          highlight={true}
        />
        <MetricCard
          title="今日双离线交易"
          value={`${offlineTransactions.length + 3120} 笔`}
          subLabel="双离线平均耗时"
          subValue="280 ms (极速)"
          icon={Zap}
        />
        <MetricCard
          title="单笔离线最高限额"
          value="¥ 2,000.00"
          subLabel="日离线累计上限"
          subValue="¥ 5,000.00"
          icon={Lock}
        />
        <MetricCard
          title="脱机双花防范率"
          value="100.00%"
          subLabel="安全计数器校验"
          subValue="零冲突上账"
          icon={ShieldCheck}
        />
      </div>

      {/* Dual Offline Interactive Simulation Arena */}
      <div className="bg-[#12151d] border border-[#1e2433] rounded-lg p-6 space-y-6">
        <div className="flex items-center justify-between pb-4 border-b border-[#1e2433]">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <WifiOff className="w-4 h-4 text-amber-400" />
              双离线支付全流程动态仿真 (Dual Offline Execution Simulator)
            </h3>
            <p className="text-xs text-[#94a3b8] mt-0.5">
              模拟付款方与收款方均处于无网状态（地下车库/高空航班/应急灾害），两端终端碰一碰完成离线扣账与延迟回传
            </p>
          </div>
          <Badge variant="amber">环境状态: 模拟完全断网 (Offline)</Badge>
        </div>

        {/* Inputs */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div>
            <label className="block text-xs font-medium text-[#94a3b8] mb-1">
              付款方硬件钱包 (SE芯片) *
            </label>
            <select
              value={offlinePayerId}
              onChange={(e) => setOfflinePayerId(e.target.value)}
              className="w-full bg-[#0a0c10] border border-[#2a3449] rounded-md px-3 py-2 text-xs text-white focus:outline-none focus:border-[#ef4444]"
            >
              {wallets.map(w => (
                <option key={w.id} value={w.id}>
                  {w.name} (离线额度: ¥{w.offlineQuota})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-[#94a3b8] mb-1">
              收款方商户/个人终端 *
            </label>
            <select
              value={offlinePayeeId}
              onChange={(e) => setOfflinePayeeId(e.target.value)}
              className="w-full bg-[#0a0c10] border border-[#2a3449] rounded-md px-3 py-2 text-xs text-white focus:outline-none focus:border-[#ef4444]"
            >
              {wallets.map(w => (
                <option key={w.id} value={w.id}>
                  {w.name} ({w.bankName})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-[#94a3b8] mb-1">
              双离线金额 (元) *
            </label>
            <div className="flex gap-2">
              <input
                type="number"
                value={offlineAmount}
                onChange={(e) => setOfflineAmount(e.target.value)}
                className="w-full bg-[#0a0c10] border border-[#2a3449] rounded-md px-3 py-2 text-xs font-mono-num text-white focus:outline-none focus:border-[#ef4444]"
              />
              <button
                onClick={startDualOfflinePayment}
                disabled={isSimulating}
                className="px-4 py-2 bg-[#8b111a] hover:bg-[#a81622] text-white text-xs font-bold rounded flex items-center gap-1.5 whitespace-nowrap shadow transition-colors disabled:opacity-50"
              >
                <Zap className="w-3.5 h-3.5" />
                <span>碰一碰支付</span>
              </button>
            </div>
          </div>
        </div>

        {/* 4-Step Visual Progress */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 pt-2">
          {[
            {
              step: 1,
              title: '1. NFC 近场感应',
              desc: '建立 13.56MHz 高频加密通信，双向安全芯片认证',
              active: offlineStep >= 1
            },
            {
              step: 2,
              title: '2. SE芯片硬件扣减',
              desc: '自增硬件离线流水号，本地扣除离线可用余额',
              active: offlineStep >= 2
            },
            {
              step: 3,
              title: '3. 离线电子凭证生成',
              desc: '生成带有付款方 SE 私钥的离线加密交易凭证',
              active: offlineStep >= 3
            },
            {
              step: 4,
              title: '4. 延迟联网批量上账',
              desc: '收款终端恢复网络后，向央行核心账本自动清算',
              active: offlineStep >= 4
            }
          ].map((s) => (
            <div
              key={s.step}
              className={`p-4 rounded-lg border transition-all ${
                s.active
                  ? 'bg-[#1b2538] border-sky-500 shadow-md shadow-sky-500/10'
                  : 'bg-[#0e1118] border-[#1e2433] opacity-60'
              }`}
            >
              <div className="flex items-center justify-between text-xs mb-1">
                <span className={`font-bold ${s.active ? 'text-sky-300' : 'text-[#64748b]'}`}>
                  {s.title}
                </span>
                {s.active && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
              </div>
              <p className="text-[11px] text-[#94a3b8] leading-relaxed mt-1">{s.desc}</p>
            </div>
          ))}
        </div>

        {/* Sync Feedback */}
        {syncFeedback && (
          <div className="p-3.5 bg-[#0f291e] border border-[#166534] rounded-lg text-emerald-300 text-xs flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>{syncFeedback}</span>
            </div>
            <span className="font-mono-num text-[11px] text-emerald-400">双花检测引擎: 0 次冲突</span>
          </div>
        )}
      </div>

      {/* Hardware Security Standards & Tokenized Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Hardware Card List */}
        <div className="bg-[#12151d] border border-[#1e2433] rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-sky-400" />
              绑定硬件钱包卡片档案
            </h3>
            <span className="text-xs text-[#94a3b8] font-mono-num">
              共 {hardwareWallets.length} 张硬钱包
            </span>
          </div>

          <div className="space-y-3">
            {hardwareWallets.map((w) => (
              <div key={w.id} className="p-3.5 bg-[#0a0c10] rounded-lg border border-[#1e2433] flex items-center justify-between text-xs">
                <div>
                  <div className="font-bold text-white flex items-center gap-2">
                    <span>{w.name}</span>
                    <Badge variant="blue">SE芯片</Badge>
                  </div>
                  <div className="text-[10px] font-mono-num text-[#64748b] mt-0.5">
                    芯片编号: {w.hardwareChipId} | 归属: {w.bankName}
                  </div>
                </div>

                <div className="text-right font-mono-num">
                  <span className="text-[10px] text-[#64748b] block">离线限额</span>
                  <span className="text-white font-bold">¥ {w.offlineQuota.toFixed(2)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Technical Explanations */}
        <div className="bg-[#12151d] border border-[#1e2433] rounded-lg p-5 space-y-3 text-xs">
          <h3 className="text-sm font-semibold text-white flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            双离线防双花与安全机制
          </h3>

          <div className="p-3 bg-[#151924] rounded border border-[#20293d] space-y-1">
            <div className="font-semibold text-white">1. 硬件级单调递增计数器 (Monotonic Counter)</div>
            <p className="text-[#94a3b8] text-[11px] leading-relaxed">
              SE 芯片内部固化不可回滚的防重放流水号，即使恶意复制芯片存储镜像，也无法重复签署有效凭证。
            </p>
          </div>

          <div className="p-3 bg-[#151924] rounded border border-[#20293d] space-y-1">
            <div className="font-semibold text-white">2. 离线小额频次与额度上限</div>
            <p className="text-[#94a3b8] text-[11px] leading-relaxed">
              单卡设置单笔最高 2000 元、累计不超过 5 次脱机交易的硬性约束，超时或超额后必须联网一次同步重置状态。
            </p>
          </div>

          <div className="p-3 bg-[#151924] rounded border border-[#20293d] space-y-1">
            <div className="font-semibold text-white">3. 央行商户侧事后追偿法律兜底</div>
            <p className="text-[#94a3b8] text-[11px] leading-relaxed">
              由于数字人民币具备法偿性，对于因极端芯片损坏导致的小额差异，由央行储备保险金执行风险补偿。
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
