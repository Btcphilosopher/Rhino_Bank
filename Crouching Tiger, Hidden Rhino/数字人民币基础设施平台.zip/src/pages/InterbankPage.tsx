import React, { useState } from 'react';
import { 
  Network, 
  Scale, 
  ArrowLeftRight, 
  TrendingUp, 
  RefreshCw, 
  Building2, 
  CheckCircle2, 
  ShieldCheck, 
  ArrowUpRight, 
  ArrowDownLeft,
  DollarSign
} from 'lucide-react';
import { useSimulation } from '../simulation/SimulationContext';
import { MetricCard } from '../components/common/MetricCard';
import { Badge } from '../components/common/Badge';
import { InstitutionalModal } from '../components/common/InstitutionalModal';

export const InterbankPage: React.FC = () => {
  const { 
    banks, 
    transactions, 
    executeClearingBatch, 
    transferFunds 
  } = useSimulation();

  const [isTransferOpen, setIsTransferOpen] = useState<boolean>(false);
  const [sourceBankId, setSourceBankId] = useState<string>('ICBC');
  const [destBankId, setDestBankId] = useState<string>('CCB');
  const [transferAmount, setTransferAmount] = useState<string>('50000000.00');
  const [feedback, setFeedback] = useState<string | null>(null);

  // Cross-bank transactions
  const crossBankTxs = transactions.filter(t => t.fromBankId !== t.toBankId);

  const handleInterbankTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    if (sourceBankId === destBankId) {
      alert('调出银行与调入银行不能相同');
      return;
    }
    const amt = parseFloat(transferAmount);
    if (isNaN(amt) || amt <= 0) {
      alert('请输入有效的调拨金额');
      return;
    }

    const srcBank = banks.find(b => b.id === sourceBankId);
    if (!srcBank || srcBank.digitalYuanInventory < amt) {
      alert('调出机构数字人民币备付头寸不足');
      return;
    }

    // Direct bank-level liquidity adjustment in simulation
    srcBank.digitalYuanInventory -= amt;
    srcBank.settlementPosition -= amt;

    const dstBank = banks.find(b => b.id === destBankId);
    if (dstBank) {
      dstBank.digitalYuanInventory += amt;
      dstBank.settlementPosition += amt;
    }

    setIsTransferOpen(false);
    setFeedback(`成功完成 ${srcBank.name} 向 ${dstBank?.name} 跨行流动性头寸调拨 ¥${amt.toLocaleString()} 元`);
    setTimeout(() => setFeedback(null), 5000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#12151d] border border-[#1e2433] p-5 rounded-lg flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Network className="w-5 h-5 text-[#ef4444]" />
            <h2 className="text-lg font-bold text-white tracking-wide">
              跨行结算与多边轧差体系 (Interbank Settlement & Multilateral Netting)
            </h2>
          </div>
          <p className="text-xs text-[#94a3b8] mt-1">
            监控二级运营银行跨行头寸互斥、多边多对多借贷关系矩阵、RTGS大额即时划拨及流动性调配
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsTransferOpen(true)}
            className="px-4 py-2 rounded-md bg-[#8b111a] hover:bg-[#a81622] text-white text-xs font-bold flex items-center gap-1.5 shadow-md transition-colors"
          >
            <ArrowLeftRight className="w-3.5 h-3.5" />
            <span>发起跨行头寸调拨</span>
          </button>
        </div>
      </div>

      {/* Telemetry Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
        <MetricCard
          title="跨机构交易累计总量"
          value={`${crossBankTxs.length + 8652} 笔`}
          subLabel="跨行渗透率"
          subValue="74.2%"
          icon={ArrowLeftRight}
          highlight={true}
        />
        <MetricCard
          title="多边净额轧差周期"
          value="15 分钟 / 批次"
          subLabel="下个批次结算"
          subValue="08:45:00"
          icon={RefreshCw}
        />
        <MetricCard
          title="跨行大额RTGS通道"
          value="7×24 全天候"
          subLabel="系统峰值处理能力"
          subValue="120,000 TPS"
          icon={TrendingUp}
        />
        <MetricCard
          title="日间透支备付金"
          value="¥ 0.00 元"
          subLabel="流动性风险敞口"
          subValue="0.00% (安全)"
          icon={Scale}
        />
      </div>

      {/* Feedback Banner */}
      {feedback && (
        <div className="p-3.5 bg-[#0f291e] border border-[#166534] rounded-lg text-emerald-300 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span className="font-semibold">{feedback}</span>
          </div>
          <span className="font-mono-num text-[11px] text-emerald-400">大额结算核心实时借记贷记已完成</span>
        </div>
      )}

      {/* Interbank Matrix View */}
      <div className="bg-[#12151d] border border-[#1e2433] rounded-lg p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <Scale className="w-4 h-4 text-[#ef4444]" />
              运营银行间多边净额头寸关系矩阵 (Multilateral Netting Position Matrix)
            </h3>
            <p className="text-xs text-[#94a3b8] mt-0.5">
              绿色表示净应收资金（清算债权方），红色表示净应付资金（清算债务方）
            </p>
          </div>
          <Badge variant="blue">动态多边轧差已使能</Badge>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#0f121a] text-[#94a3b8] uppercase text-[11px] border-b border-[#1e2433]">
              <tr>
                <th className="py-2.5 px-3">运营机构代码</th>
                <th className="py-2.5 px-3">机构全称</th>
                <th className="py-2.5 px-3 text-right">法定备付头寸</th>
                <th className="py-2.5 px-3 text-right">跨行净头寸 (轧差额)</th>
                <th className="py-2.5 px-3 text-center">清算债权/债务状态</th>
                <th className="py-2.5 px-3 text-right">准备金充足率</th>
                <th className="py-2.5 px-3 text-center">操作</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1a202c]">
              {banks.map((b) => (
                <tr key={b.id} className="hover:bg-[#161a24]">
                  <td className="py-3 px-3 font-mono-num font-semibold text-[#cbd5e1]">{b.code}</td>
                  <td className="py-3 px-3 font-bold text-white flex items-center gap-2">
                    <Building2 className="w-3.5 h-3.5 text-[#94a3b8]" />
                    <span>{b.name}</span>
                  </td>
                  <td className="py-3 px-3 text-right font-mono-num font-bold text-white">
                    ¥ {(b.digitalYuanInventory / 100000000).toFixed(2)} 亿元
                  </td>
                  <td className={`py-3 px-3 text-right font-mono-num font-bold text-sm ${
                    b.settlementPosition >= 0 ? 'text-emerald-400' : 'text-red-400'
                  }`}>
                    {b.settlementPosition >= 0 ? '+' : ''}¥ {(b.settlementPosition / 10000).toFixed(1)} 万元
                  </td>
                  <td className="py-3 px-3 text-center">
                    <Badge variant={b.settlementPosition >= 0 ? 'green' : 'amber'}>
                      {b.settlementPosition >= 0 ? '多边净应收 (债权)' : '多边净应付 (债务)'}
                    </Badge>
                  </td>
                  <td className="py-3 px-3 text-right font-mono-num text-sky-400 font-semibold">
                    100.0% (足额)
                  </td>
                  <td className="py-3 px-3 text-center">
                    <button
                      onClick={() => {
                        setSourceBankId(b.id);
                        setIsTransferOpen(true);
                      }}
                      className="px-2 py-1 rounded bg-[#1b2336] text-sky-400 hover:bg-[#283552] text-xs font-medium"
                    >
                      调拨头寸
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Cross-Bank Recent Ledger */}
      <div className="bg-[#12151d] border border-[#1e2433] rounded-lg p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-white flex items-center gap-2">
            <ArrowLeftRight className="w-4 h-4 text-sky-400" />
            跨行交易实时划拨流水
          </h3>
          <span className="text-xs text-[#94a3b8]">最近实时跨行流水</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#0f121a] text-[#94a3b8] uppercase text-[11px] border-b border-[#1e2433]">
              <tr>
                <th className="py-2.5 px-3">流水号</th>
                <th className="py-2.5 px-3">调出机构</th>
                <th className="py-2.5 px-3 text-center">调拨方向</th>
                <th className="py-2.5 px-3">调入机构</th>
                <th className="py-2.5 px-3 text-right">金额 (元)</th>
                <th className="py-2.5 px-3">用途说明</th>
                <th className="py-2.5 px-3 text-right">结算时间</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1a202c]">
              {crossBankTxs.slice(0, 6).map((t) => (
                <tr key={t.id} className="hover:bg-[#161a24]">
                  <td className="py-2.5 px-3 font-mono-num text-white">{t.id}</td>
                  <td className="py-2.5 px-3 font-semibold text-white">{t.fromBankName}</td>
                  <td className="py-2.5 px-3 text-center text-[#64748b]">➔</td>
                  <td className="py-2.5 px-3 font-semibold text-white">{t.toBankName}</td>
                  <td className="py-2.5 px-3 text-right font-mono-num font-bold text-white">
                    ¥ {t.amount.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}
                  </td>
                  <td className="py-2.5 px-3 text-[#cbd5e1]">{t.purpose}</td>
                  <td className="py-2.5 px-3 text-right font-mono-num text-[#64748b]">{t.timestamp}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Interbank Transfer Modal */}
      {isTransferOpen && (
        <InstitutionalModal
          isOpen={isTransferOpen}
          onClose={() => setIsTransferOpen(false)}
          title="运营机构间跨行流动性头寸调拨 (Interbank Position Reallocation)"
          subtitle="通过央行大额实时支付通道 (CBDC-RTGS) 调拨二级机构数字人民币准备金头寸"
        >
          <form onSubmit={handleInterbankTransfer} className="space-y-4 text-xs">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-[#94a3b8] mb-1">
                  调出机构 (扣减头寸) *
                </label>
                <select
                  value={sourceBankId}
                  onChange={(e) => setSourceBankId(e.target.value)}
                  className="w-full bg-[#0a0c10] border border-[#2a3449] rounded-md px-3 py-2 text-xs text-white focus:outline-none focus:border-[#ef4444]"
                >
                  {banks.map(b => (
                    <option key={b.id} value={b.id}>
                      {b.name} (可用库存: ¥{(b.digitalYuanInventory / 100000000).toFixed(1)}亿)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#94a3b8] mb-1">
                  调入机构 (增加头寸) *
                </label>
                <select
                  value={destBankId}
                  onChange={(e) => setDestBankId(e.target.value)}
                  className="w-full bg-[#0a0c10] border border-[#2a3449] rounded-md px-3 py-2 text-xs text-white focus:outline-none focus:border-[#ef4444]"
                >
                  {banks.map(b => (
                    <option key={b.id} value={b.id}>
                      {b.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#94a3b8] mb-1">
                调拨金额 (元) *
              </label>
              <input
                type="number"
                value={transferAmount}
                onChange={(e) => setTransferAmount(e.target.value)}
                className="w-full bg-[#0a0c10] border border-[#2a3449] rounded-md px-3 py-2 text-xs font-mono-num text-white focus:outline-none focus:border-[#ef4444]"
              />
            </div>

            <div className="p-3 bg-[#0a0c10] rounded border border-[#1e2535] text-[11px] text-[#94a3b8]">
              <div>清算时效: <span className="text-emerald-400 font-bold">RTGS 毫秒级即时到账</span></div>
              <div>准备金核验: <span className="text-sky-400 font-bold">央行清算总中心直接过账</span></div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsTransferOpen(false)}
                className="px-4 py-2 rounded bg-[#1a202c] hover:bg-[#252e40] text-[#94a3b8] text-xs"
              >
                取消
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded bg-[#8b111a] hover:bg-[#a81622] text-white text-xs font-bold"
              >
                核准头寸调拨
              </button>
            </div>
          </form>
        </InstitutionalModal>
      )}
    </div>
  );
};
