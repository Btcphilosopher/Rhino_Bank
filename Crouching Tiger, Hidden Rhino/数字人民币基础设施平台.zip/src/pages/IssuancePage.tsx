import React, { useState } from 'react';
import { 
  Coins, 
  ArrowDownCircle, 
  ArrowUpCircle, 
  CheckCircle2, 
  Landmark, 
  Building2, 
  ShieldCheck, 
  Layers, 
  Sliders, 
  Clock, 
  FileText,
  AlertCircle,
  HelpCircle,
  Hash
} from 'lucide-react';
import { useSimulation } from '../simulation/SimulationContext';
import { MetricCard } from '../components/common/MetricCard';
import { Badge } from '../components/common/Badge';
import { InstitutionalModal } from '../components/common/InstitutionalModal';

export const IssuancePage: React.FC = () => {
  const { 
    banks, 
    issuanceBatches, 
    issueDigitalYuan, 
    redeemDigitalYuan, 
    simulatedTime 
  } = useSimulation();

  const [activeSubTab, setActiveSubTab] = useState<'ISSUANCE' | 'REDEMPTION' | 'BATCHES' | 'LIFECYCLE'>('ISSUANCE');
  
  // Issuance Form States
  const [targetBankId, setTargetBankId] = useState<string>('ICBC');
  const [issuanceAmount, setIssuanceAmount] = useState<string>('1000000000');
  const [fundSource, setFundSource] = useState<string>('商业银行存入央行法定准备金账户 1:1 等额扣减');
  const [issuancePurpose, setIssuancePurpose] = useState<string>('节假日与跨行清算备付金补充');
  const [selectedBatch, setSelectedBatch] = useState<any | null>(null);
  
  // Redemption Form States
  const [redeemBankId, setRedeemBankId] = useState<string>('BOC');
  const [redeemAmount, setRedeemAmount] = useState<string>('500000000');
  const [redeemPurpose, setRedeemPurpose] = useState<string>('商业银行数字人民币头寸回笼与准备金解冻');

  // Success Feedback
  const [actionSuccessMsg, setActionSuccessMsg] = useState<string | null>(null);

  const handleIssue = (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseFloat(issuanceAmount);
    if (isNaN(amountNum) || amountNum <= 0) {
      alert('请输入有效的发行金额');
      return;
    }

    const res = issueDigitalYuan({
      targetBankId,
      amount: amountNum,
      fundSource,
      purpose: issuancePurpose
    });

    if (res.success) {
      setActionSuccessMsg(res.message);
      if (res.batch) setSelectedBatch(res.batch);
      setTimeout(() => setActionSuccessMsg(null), 5000);
    } else {
      alert(res.message);
    }
  };

  const handleRedeem = (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseFloat(redeemAmount);
    if (isNaN(amountNum) || amountNum <= 0) {
      alert('请输入有效回笼金额');
      return;
    }

    const res = redeemDigitalYuan({
      targetBankId: redeemBankId,
      amount: amountNum,
      purpose: redeemPurpose
    });

    if (res.success) {
      setActionSuccessMsg(res.message);
      if (res.batch) setSelectedBatch(res.batch);
      setTimeout(() => setActionSuccessMsg(null), 5000);
    } else {
      alert(res.message);
    }
  };

  const selectedBank = banks.find(b => b.id === targetBankId) || banks[0];
  const selectedRedeemBank = banks.find(b => b.id === redeemBankId) || banks[0];

  const totalVaultIssued = issuanceBatches
    .filter(b => b.type === 'ISSUANCE')
    .reduce((acc, b) => acc + b.amount, 0);

  const totalVaultRedeemed = issuanceBatches
    .filter(b => b.type === 'REDEMPTION')
    .reduce((acc, b) => acc + b.amount, 0);

  return (
    <div className="space-y-6">
      {/* Title & Navigation Tabs */}
      <div className="bg-[#12151d] border border-[#1e2433] p-5 rounded-lg flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Coins className="w-5 h-5 text-[#ef4444]" />
            <h2 className="text-lg font-bold text-white tracking-wide">
              数字人民币发行与回笼管理中心 (Digital Yuan Issuance & Redemption Engine)
            </h2>
          </div>
          <p className="text-xs text-[#94a3b8] mt-1">
            执行中央银行对二级运营机构的法定等额对换发行、回笼注销、流通量动态监控及全生命周期审计
          </p>
        </div>

        {/* Sub Navigation */}
        <div className="flex items-center bg-[#0e1118] p-1 rounded-md border border-[#232a3d]">
          <button
            onClick={() => setActiveSubTab('ISSUANCE')}
            className={`px-3 py-1.5 rounded text-xs font-semibold transition-colors flex items-center gap-1.5 ${
              activeSubTab === 'ISSUANCE' ? 'bg-[#8b111a] text-white' : 'text-[#94a3b8] hover:text-white'
            }`}
          >
            <ArrowDownCircle className="w-3.5 h-3.5" />
            <span>央行发行</span>
          </button>
          <button
            onClick={() => setActiveSubTab('REDEMPTION')}
            className={`px-3 py-1.5 rounded text-xs font-semibold transition-colors flex items-center gap-1.5 ${
              activeSubTab === 'REDEMPTION' ? 'bg-[#1e293b] text-white border border-[#334155]' : 'text-[#94a3b8] hover:text-white'
            }`}
          >
            <ArrowUpCircle className="w-3.5 h-3.5 text-amber-400" />
            <span>回笼与注销</span>
          </button>
          <button
            onClick={() => setActiveSubTab('BATCHES')}
            className={`px-3 py-1.5 rounded text-xs font-semibold transition-colors flex items-center gap-1.5 ${
              activeSubTab === 'BATCHES' ? 'bg-[#1e293b] text-white border border-[#334155]' : 'text-[#94a3b8] hover:text-white'
            }`}
          >
            <FileText className="w-3.5 h-3.5 text-sky-400" />
            <span>发行批次记录</span>
          </button>
          <button
            onClick={() => setActiveSubTab('LIFECYCLE')}
            className={`px-3 py-1.5 rounded text-xs font-semibold transition-colors flex items-center gap-1.5 ${
              activeSubTab === 'LIFECYCLE' ? 'bg-[#1e293b] text-white border border-[#334155]' : 'text-[#94a3b8] hover:text-white'
            }`}
          >
            <Layers className="w-3.5 h-3.5 text-emerald-400" />
            <span>货币全生命周期</span>
          </button>
        </div>
      </div>

      {/* Metric Cards Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
        <MetricCard
          title="中央银行累计发行总量"
          value={`¥ ${(totalVaultIssued / 100000000).toFixed(2)} 亿元`}
          subLabel="已入运营机构库"
          subValue="100% 准备金锚定"
          icon={Coins}
          highlight={true}
        />
        <MetricCard
          title="累计回笼注销总量"
          value={`¥ ${(totalVaultRedeemed / 100000000).toFixed(2)} 亿元`}
          subLabel="准备金返还比例"
          subValue="100.0%"
          icon={ArrowUpCircle}
        />
        <MetricCard
          title="当前在网流通净总量"
          value={`¥ ${((totalVaultIssued - totalVaultRedeemed) / 100000000).toFixed(2)} 亿元`}
          subLabel="M0 现金替代"
          subValue="38.6%"
          icon={Landmark}
        />
        <MetricCard
          title="发行批次总数"
          value={`${issuanceBatches.length} 批次`}
          subLabel="最近批次状态"
          subValue="已完成入账"
          icon={CheckCircle2}
        />
      </div>

      {/* Action Notification */}
      {actionSuccessMsg && (
        <div className="p-4 bg-[#0f291e] border border-[#166534] rounded-lg text-emerald-300 text-xs flex items-center justify-between animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span className="font-semibold">{actionSuccessMsg}</span>
          </div>
          <span className="text-[11px] text-emerald-400 font-mono-num">不可篡改审计日志已生成</span>
        </div>
      )}

      {/* Main Tab Views */}
      {activeSubTab === 'ISSUANCE' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left 2 Cols: Issuance Simulator Terminal */}
          <div className="lg:col-span-2 bg-[#12151d] border border-[#1e2433] rounded-lg p-6">
            <div className="flex items-center justify-between pb-4 border-b border-[#1f2637] mb-6">
              <div>
                <h3 className="text-base font-semibold text-white flex items-center gap-2">
                  <ArrowDownCircle className="w-4 h-4 text-[#ef4444]" />
                  数字人民币央行发行申请与仿真执行 (CBDC Issuance Terminal)
                </h3>
                <p className="text-xs text-[#94a3b8] mt-0.5">
                  央行对商业银行等额准备金对冲，生成全网唯一定位发行流水
                </p>
              </div>
              <Badge variant="gold">央行特权发行通道</Badge>
            </div>

            <form onSubmit={handleIssue} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Target Institution */}
                <div>
                  <label className="block text-xs font-medium text-[#94a3b8] mb-1.5">
                    目标运营商业银行 (二级机构) *
                  </label>
                  <select
                    value={targetBankId}
                    onChange={(e) => setTargetBankId(e.target.value)}
                    className="w-full bg-[#0a0c10] border border-[#2a3449] rounded-md px-3 py-2 text-xs text-white focus:outline-none focus:border-[#ef4444]"
                  >
                    {banks.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.name} ({b.code}) - 当前库存: ¥{(b.digitalYuanInventory / 100000000).toFixed(1)} 亿
                      </option>
                    ))}
                  </select>
                </div>

                {/* Amount */}
                <div>
                  <label className="block text-xs font-medium text-[#94a3b8] mb-1.5">
                    发行金额 (元 / 人民币) *
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-2 text-xs text-[#64748b]">¥</span>
                    <input
                      type="number"
                      value={issuanceAmount}
                      onChange={(e) => setIssuanceAmount(e.target.value)}
                      className="w-full bg-[#0a0c10] border border-[#2a3449] rounded-md pl-7 pr-3 py-2 text-xs font-mono-num text-white focus:outline-none focus:border-[#ef4444]"
                      placeholder="1000000000"
                    />
                  </div>
                  <div className="flex gap-2 mt-1.5">
                    {[100000000, 500000000, 1000000000, 2000000000].map((amt) => (
                      <button
                        type="button"
                        key={amt}
                        onClick={() => setIssuanceAmount(amt.toString())}
                        className="text-[10px] px-2 py-0.5 rounded bg-[#181c28] border border-[#252f44] text-[#cbd5e1] hover:bg-[#263147]"
                      >
                        +{(amt / 100000000)} 亿
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Fund Source */}
              <div>
                <label className="block text-xs font-medium text-[#94a3b8] mb-1.5">
                  资金来源 (准备金对冲机制) *
                </label>
                <select
                  value={fundSource}
                  onChange={(e) => setFundSource(e.target.value)}
                  className="w-full bg-[#0a0c10] border border-[#2a3449] rounded-md px-3 py-2 text-xs text-white focus:outline-none focus:border-[#ef4444]"
                >
                  <option value="商业银行存入央行法定准备金账户 1:1 等额扣减">
                    商业银行存入央行法定准备金账户 1:1 等额扣减 (标准 M0 投放)
                  </option>
                  <option value="中央银行流动性支持特种专项定向发放">
                    中央银行流动性支持特种专项定向发放 (政策性支农支小专项)
                  </option>
                  <option value="重大突发事件数字人民币紧急流动性备付注入">
                    重大突发事件数字人民币紧急流动性备付注入 (特批应急头寸)
                  </option>
                </select>
              </div>

              {/* Purpose */}
              <div>
                <label className="block text-xs font-medium text-[#94a3b8] mb-1.5">
                  发行用途分类与批注说明 *
                </label>
                <input
                  type="text"
                  value={issuancePurpose}
                  onChange={(e) => setIssuancePurpose(e.target.value)}
                  className="w-full bg-[#0a0c10] border border-[#2a3449] rounded-md px-3 py-2 text-xs text-white focus:outline-none focus:border-[#ef4444]"
                  placeholder="请输入用途说明..."
                />
              </div>

              {/* Real-time Math Preview box */}
              <div className="p-4 bg-[#0a0c10] border border-[#1e2535] rounded-md space-y-2 text-xs">
                <div className="text-xs font-semibold text-[#94a3b8] flex items-center justify-between border-b border-[#181f2c] pb-1.5">
                  <span>对冲结算前瞻测算 (Simulation Preview)</span>
                  <span className="font-mono-num text-[11px] text-sky-400">100% 准备金校验通过</span>
                </div>
                <div className="grid grid-cols-3 gap-2 pt-1 text-xs">
                  <div>
                    <span className="text-[#64748b]">发行前商业银行库存:</span>
                    <div className="font-mono-num font-semibold text-white mt-0.5">
                      ¥ {selectedBank.digitalYuanInventory.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}
                    </div>
                  </div>
                  <div>
                    <span className="text-[#64748b]">本次计划发行额:</span>
                    <div className="font-mono-num font-semibold text-emerald-400 mt-0.5">
                      + ¥ {(parseFloat(issuanceAmount) || 0).toLocaleString('zh-CN', { minimumFractionDigits: 2 })}
                    </div>
                  </div>
                  <div>
                    <span className="text-[#64748b]">发行后头寸预测:</span>
                    <div className="font-mono-num font-semibold text-sky-300 mt-0.5">
                      ¥ {(selectedBank.digitalYuanInventory + (parseFloat(issuanceAmount) || 0)).toLocaleString('zh-CN', { minimumFractionDigits: 2 })}
                    </div>
                  </div>
                </div>
              </div>

              {/* Submit Button */}
              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded bg-[#8b111a] hover:bg-[#a81622] text-white text-xs font-bold flex items-center gap-2 shadow-lg transition-all"
                >
                  <Coins className="w-4 h-4" />
                  <span>核准并执行央行发行</span>
                </button>
              </div>
            </form>
          </div>

          {/* Right 1 Col: Institutional Rule Explanations */}
          <div className="bg-[#12151d] border border-[#1e2433] rounded-lg p-5 flex flex-col justify-between space-y-4">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <h3 className="text-sm font-semibold text-white">
                  央行双层运营与准备金机制
                </h3>
              </div>
              <p className="text-xs text-[#94a3b8] leading-relaxed mb-4">
                数字人民币采取<strong>“中央银行—商业银行/运营机构”</strong>的双层运营体系。
              </p>

              <div className="space-y-3 text-xs">
                <div className="p-3 bg-[#161a24] rounded border border-[#232a3d] space-y-1">
                  <div className="font-semibold text-white">1. 100% 准备金缴纳</div>
                  <p className="text-[#94a3b8] text-[11px] leading-relaxed">
                    商业银行向央行申请数字人民币头寸时，必须以其在央行开立的法定存款准备金按 1:1 比例等额对换，不计付利息，不引发货币超发。
                  </p>
                </div>

                <div className="p-3 bg-[#161a24] rounded border border-[#232a3d] space-y-1">
                  <div className="font-semibold text-white">2. M0 定位与法定偿付</div>
                  <p className="text-[#94a3b8] text-[11px] leading-relaxed">
                    数字人民币属于法定现钞 M0 范畴，中央银行承担最终兑付兜底责任，支持离线与无网环境法偿支付。
                  </p>
                </div>

                <div className="p-3 bg-[#161a24] rounded border border-[#232a3d] space-y-1">
                  <div className="font-semibold text-white">3. 不可篡改审计流水</div>
                  <p className="text-[#94a3b8] text-[11px] leading-relaxed">
                    每一次发行或回笼批次均由央行核心账本生成唯一的数字签名与校验 Hash，同步写入系统不可篡改审计追踪库。
                  </p>
                </div>
              </div>
            </div>

            <div className="p-3 bg-[#1e2433] rounded text-xs text-[#cbd5e1] font-mono-num flex items-center justify-between">
              <span>当前央行总账状态:</span>
              <span className="text-emerald-400 font-bold">借贷平衡 (100.00%)</span>
            </div>
          </div>
        </div>
      )}

      {/* Redemption Tab */}
      {activeSubTab === 'REDEMPTION' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-[#12151d] border border-[#1e2433] rounded-lg p-6">
            <div className="flex items-center justify-between pb-4 border-b border-[#1f2637] mb-6">
              <div>
                <h3 className="text-base font-semibold text-white flex items-center gap-2">
                  <ArrowUpCircle className="w-4 h-4 text-amber-400" />
                  商业银行数字人民币头寸回笼与注销
                </h3>
                <p className="text-xs text-[#94a3b8] mt-0.5">
                  将商业银行闲置或超出配额的数字人民币库存回笼销毁，解冻等额法定准备金
                </p>
              </div>
              <Badge variant="amber">头寸销毁通道</Badge>
            </div>

            <form onSubmit={handleRedeem} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-[#94a3b8] mb-1.5">
                    回笼申请机构 (二级运营银行) *
                  </label>
                  <select
                    value={redeemBankId}
                    onChange={(e) => setRedeemBankId(e.target.value)}
                    className="w-full bg-[#0a0c10] border border-[#2a3449] rounded-md px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  >
                    {banks.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.name} - 可用库存: ¥{(b.digitalYuanInventory / 100000000).toFixed(1)} 亿
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#94a3b8] mb-1.5">
                    回笼金额 (元) *
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-2 text-xs text-[#64748b]">¥</span>
                    <input
                      type="number"
                      value={redeemAmount}
                      onChange={(e) => setRedeemAmount(e.target.value)}
                      className="w-full bg-[#0a0c10] border border-[#2a3449] rounded-md pl-7 pr-3 py-2 text-xs font-mono-num text-white focus:outline-none focus:border-amber-400"
                      placeholder="500000000"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#94a3b8] mb-1.5">
                  回笼原因及准备金归还说明 *
                </label>
                <input
                  type="text"
                  value={redeemPurpose}
                  onChange={(e) => setRedeemPurpose(e.target.value)}
                  className="w-full bg-[#0a0c10] border border-[#2a3449] rounded-md px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              {/* Preview Box */}
              <div className="p-4 bg-[#0a0c10] border border-[#1e2535] rounded-md space-y-2 text-xs">
                <div className="text-xs font-semibold text-[#94a3b8] border-b border-[#181f2c] pb-1.5">
                  回笼注销对冲测算
                </div>
                <div className="grid grid-cols-3 gap-2 pt-1 text-xs">
                  <div>
                    <span className="text-[#64748b]">回笼前库存:</span>
                    <div className="font-mono-num font-semibold text-white mt-0.5">
                      ¥ {selectedRedeemBank.digitalYuanInventory.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}
                    </div>
                  </div>
                  <div>
                    <span className="text-[#64748b]">本次销毁额:</span>
                    <div className="font-mono-num font-semibold text-amber-400 mt-0.5">
                      - ¥ {(parseFloat(redeemAmount) || 0).toLocaleString('zh-CN', { minimumFractionDigits: 2 })}
                    </div>
                  </div>
                  <div>
                    <span className="text-[#64748b]">返还准备金金额:</span>
                    <div className="font-mono-num font-semibold text-emerald-400 mt-0.5">
                      + ¥ {(parseFloat(redeemAmount) || 0).toLocaleString('zh-CN', { minimumFractionDigits: 2 })}
                    </div>
                  </div>
                </div>
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded bg-[#b45309] hover:bg-[#d97706] text-white text-xs font-bold flex items-center gap-2 shadow-lg transition-all"
                >
                  <ArrowUpCircle className="w-4 h-4" />
                  <span>核准回笼并解冻准备金</span>
                </button>
              </div>
            </form>
          </div>

          <div className="bg-[#12151d] border border-[#1e2433] rounded-lg p-5 space-y-4">
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <Landmark className="w-4 h-4 text-amber-400" />
              回笼注销控制规范
            </h3>
            <p className="text-xs text-[#94a3b8] leading-relaxed">
              为防止商业银行产生多余头寸挤占准备金流动性，二级运营机构可在非高峰交易时段发起常规头寸回笼。
            </p>
            <div className="p-3 bg-[#161a24] rounded border border-[#232a3d] text-xs space-y-1">
              <div className="font-semibold text-white">即时到账与清算轧差</div>
              <p className="text-[11px] text-[#94a3b8]">
                回笼销毁经央行核心账本确认后，系统在 100ms 内向商业银行法定账户恢复流动性。
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Batches Tab */}
      {activeSubTab === 'BATCHES' && (
        <div className="bg-[#12151d] border border-[#1e2433] rounded-lg p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                <FileText className="w-4 h-4 text-[#ef4444]" />
                央行发行与回笼不可篡改批次账簿 (CBDC Issuance Ledger)
              </h3>
              <p className="text-xs text-[#94a3b8] mt-0.5">
                包含每一笔发行批次编号、目标机构、对冲前后头寸及数字签名
              </p>
            </div>
            <span className="text-xs text-[#64748b] font-mono-num">
              共记录 {issuanceBatches.length} 批次
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#0f121a] text-[#94a3b8] uppercase text-[11px] border-b border-[#1e2433]">
                <tr>
                  <th className="py-2.5 px-3 font-semibold">批次号 / 验签Hash</th>
                  <th className="py-2.5 px-3 font-semibold">类型</th>
                  <th className="py-2.5 px-3 font-semibold">目标机构</th>
                  <th className="py-2.5 px-3 font-semibold text-right">金额 (元)</th>
                  <th className="py-2.5 px-3 font-semibold text-right">发行前头寸</th>
                  <th className="py-2.5 px-3 font-semibold text-right">发行后头寸</th>
                  <th className="py-2.5 px-3 font-semibold">资金来源 / 用途</th>
                  <th className="py-2.5 px-3 font-semibold text-right">时间戳</th>
                  <th className="py-2.5 px-3 font-semibold text-center">操作</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1a202c]">
                {issuanceBatches.map((b) => (
                  <tr key={b.id} className="hover:bg-[#161a24] transition-colors">
                    <td className="py-2.5 px-3">
                      <div className="font-mono-num font-bold text-white">{b.id}</div>
                      <div className="font-mono-num text-[10px] text-[#64748b]">{b.auditHash}</div>
                    </td>
                    <td className="py-2.5 px-3">
                      <Badge variant={b.type === 'ISSUANCE' ? 'red' : 'amber'}>
                        {b.type === 'ISSUANCE' ? '等额发行' : '头寸回笼'}
                      </Badge>
                    </td>
                    <td className="py-2.5 px-3 font-medium text-[#e2e8f0]">
                      {b.targetBankName}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono-num font-bold text-white">
                      ¥ {b.amount.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono-num text-[#94a3b8]">
                      ¥ {(b.preBalance / 100000000).toFixed(1)} 亿
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono-num text-emerald-400 font-semibold">
                      ¥ {(b.postBalance / 100000000).toFixed(1)} 亿
                    </td>
                    <td className="py-2.5 px-3">
                      <div className="text-xs text-[#cbd5e1] truncate max-w-[200px]">{b.purpose}</div>
                      <div className="text-[10px] text-[#64748b] truncate max-w-[200px]">{b.fundSource}</div>
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono-num text-[#64748b]">
                      {b.timestamp}
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      <button
                        onClick={() => setSelectedBatch(b)}
                        className="text-sky-400 hover:text-sky-300 font-medium text-xs px-2 py-1 rounded bg-[#131b2c]"
                      >
                        详情凭证
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Lifecycle Visualization */}
      {activeSubTab === 'LIFECYCLE' && (
        <div className="bg-[#12151d] border border-[#1e2433] rounded-lg p-6">
          <div className="mb-6">
            <h3 className="text-base font-semibold text-white flex items-center gap-2">
              <Layers className="w-5 h-5 text-[#ef4444]" />
              数字人民币货币全生命周期流转图谱 (Monetary Lifecycle Flow)
            </h3>
            <p className="text-xs text-[#94a3b8] mt-1">
              展示央行 M0 从发行、商业银行兑换、终端支付、跨行轧差清算到最终回笼注销的完整闭环
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 lg:grid-cols-7 gap-3">
            {[
              { step: '01', title: '中央银行', desc: '总金库发行准备金 1:1 锚定', role: '发行与注销总控', color: 'border-[#991b1b] bg-[#1d1215]' },
              { step: '02', title: '数字人民币发行', desc: '生成带防伪数字签名的 M0', role: '核心账本记账', color: 'border-[#7f1d1d] bg-[#1a141a]' },
              { step: '03', title: '运营机构', desc: '六大国有行与指定股份行', role: '二级头寸分发', color: 'border-[#252f44] bg-[#141824]' },
              { step: '04', title: '商业银行/非银', desc: '接入钱包服务与兑换网点', role: '客户账户管理', color: 'border-[#252f44] bg-[#141824]' },
              { step: '05', title: '个人/企业钱包', desc: '一至四类实名及匿名钱包', role: '终端持有主体', color: 'border-[#1e3a5f] bg-[#101a2b]' },
              { step: '06', title: '支付与流通', desc: '扫码、NFC、双离线、合约', role: '实体经济流转', color: 'border-[#14532d] bg-[#0f241a]' },
              { step: '07', title: '清算与回笼', desc: '实时轧差清算 / 超额回笼', role: '资金闭环归集', color: 'border-[#78350f] bg-[#22180d]' },
            ].map((node, i) => (
              <div key={node.step} className={`p-4 rounded-lg border ${node.color} space-y-2 relative`}>
                <div className="flex justify-between items-center text-xs">
                  <span className="font-mono-num font-bold text-[#f87171]">{node.step}</span>
                  <span className="text-[10px] text-[#94a3b8] font-mono-num">{node.role}</span>
                </div>
                <div className="text-sm font-bold text-white tracking-tight">{node.title}</div>
                <p className="text-[11px] text-[#94a3b8] leading-relaxed">{node.desc}</p>
                {i < 6 && (
                  <div className="hidden lg:block absolute -right-2 top-1/2 -translate-y-1/2 z-20 text-[#64748b] font-bold">
                    →
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="mt-6 p-4 rounded bg-[#0a0c10] border border-[#1e2433] text-xs text-[#94a3b8] flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>全生命周期不可逆审计追踪校验通过</span>
            </div>
            <div className="text-[11px] font-mono-num text-[#64748b]">
              共识机制: 中心化权威记账 + 机构分布式协同校验
            </div>
          </div>
        </div>
      )}

      {/* Batch Detail Inspector Modal */}
      {selectedBatch && (
        <InstitutionalModal
          isOpen={true}
          onClose={() => setSelectedBatch(null)}
          title={`发行/回笼电子批次凭证 (${selectedBatch.id})`}
          subtitle="中国人民银行数字货币发行司 官方电子回执"
        >
          <div className="space-y-4 text-xs">
            <div className="p-4 bg-[#0a0c10] rounded border border-[#1e2433] space-y-3 font-mono-num">
              <div className="flex justify-between border-b border-[#181f2c] pb-2">
                <span className="text-[#64748b]">批次流水号:</span>
                <span className="text-white font-bold">{selectedBatch.id}</span>
              </div>
              <div className="flex justify-between border-b border-[#181f2c] pb-2">
                <span className="text-[#64748b]">业务类型:</span>
                <span className="text-emerald-400 font-bold">{selectedBatch.type === 'ISSUANCE' ? '数字人民币央行等额发行' : '数字人民币商业银行回笼注销'}</span>
              </div>
              <div className="flex justify-between border-b border-[#181f2c] pb-2">
                <span className="text-[#64748b]">目标运营机构:</span>
                <span className="text-white">{selectedBatch.targetBankName}</span>
              </div>
              <div className="flex justify-between border-b border-[#181f2c] pb-2">
                <span className="text-[#64748b]">交易金额:</span>
                <span className="text-xl text-white font-bold">¥ {selectedBatch.amount.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}</span>
              </div>
              <div className="flex justify-between border-b border-[#181f2c] pb-2">
                <span className="text-[#64748b]">准备金对冲渠道:</span>
                <span className="text-sky-300">{selectedBatch.fundSource}</span>
              </div>
              <div className="flex justify-between border-b border-[#181f2c] pb-2">
                <span className="text-[#64748b]">用途说明:</span>
                <span className="text-white">{selectedBatch.purpose}</span>
              </div>
              <div className="flex justify-between border-b border-[#181f2c] pb-2">
                <span className="text-[#64748b]">数字签名 (SHA256 Hash):</span>
                <span className="text-amber-400 text-[11px] truncate max-w-[280px]">{selectedBatch.auditHash}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#64748b]">操作签发人:</span>
                <span className="text-white">{selectedBatch.operator}</span>
              </div>
            </div>
          </div>
        </InstitutionalModal>
      )}
    </div>
  );
};
