import React, { useState } from 'react';
import { 
  Building2, 
  Activity, 
  Layers, 
  Coins, 
  ArrowLeftRight, 
  RefreshCcw, 
  ShieldAlert, 
  Wifi, 
  Scale, 
  CheckCircle2, 
  HelpCircle,
  Network
} from 'lucide-react';
import { useSimulation } from '../simulation/SimulationContext';
import { BankNode } from '../types';
import { MetricCard } from '../components/common/MetricCard';
import { Badge } from '../components/common/Badge';

export const InstitutionPage: React.FC = () => {
  const { banks, transactions, executeClearingBatch, injectBurstTransactions } = useSimulation();
  const [selectedBankId, setSelectedBankId] = useState<string>('ICBC');

  const selectedBank = banks.find(b => b.id === selectedBankId) || banks[0];

  const totalBankInventory = banks.reduce((a, b) => a + b.digitalYuanInventory, 0);
  const totalReserve = banks.reduce((a, b) => a + b.depositReserve, 0);

  // Bank transactions
  const bankTransactions = transactions.filter(
    t => t.fromBankId === selectedBank.id || t.toBankId === selectedBank.id
  );

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-[#12151d] border border-[#1e2433] p-5 rounded-lg flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Building2 className="w-5 h-5 text-[#ef4444]" />
            <h2 className="text-lg font-bold text-white tracking-wide">
              二级运营机构与商业银行节点 (Commercial Bank & Operator Nodes)
            </h2>
          </div>
          <p className="text-xs text-[#94a3b8] mt-1">
            监控 9 家一级运营商业银行与持牌机构的数字人民币备付头寸、准备金充足率及网关通信状态
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => executeClearingBatch()}
            className="px-3 py-1.5 rounded-md bg-[#16382b] hover:bg-[#1e4b3b] text-[#86efac] border border-[#166534] text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <RefreshCcw className="w-4 h-4" />
            <span>发起全网多边轧差</span>
          </button>
        </div>
      </div>

      {/* Aggregate Overview Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
        <MetricCard
          title="全网商业银行头寸总库"
          value={`¥ ${(totalBankInventory / 100000000).toFixed(1)} 亿元`}
          subLabel="准备金覆盖率"
          subValue="100.0%"
          icon={Coins}
          highlight={true}
        />
        <MetricCard
          title="央行法定准备金池"
          value={`¥ ${(totalReserve / 100000000).toFixed(1)} 亿元`}
          subLabel="对冲抵押率"
          subValue="足额担保"
          icon={Scale}
        />
        <MetricCard
          title="在役运营机构节点"
          value={`${banks.length} 家`}
          subLabel="API 平均延迟"
          subValue="16.4 ms"
          icon={Building2}
        />
        <MetricCard
          title="互联清算通道"
          value="72 条双向专线"
          subLabel="国密加密强度"
          subValue="SM2/SM3/SM4"
          icon={Network}
        />
      </div>

      {/* Bank Nodes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {banks.map((bank) => {
          const isSelected = bank.id === selectedBank.id;
          return (
            <div
              key={bank.id}
              onClick={() => setSelectedBankId(bank.id)}
              className={`p-5 rounded-lg border cursor-pointer transition-all ${
                isSelected
                  ? 'bg-[#191d29] border-[#8b111a] shadow-lg shadow-[#8b111a]/20'
                  : 'bg-[#12151d] border-[#1e2433] hover:border-[#2f3a52]'
              }`}
            >
              <div className="flex items-center justify-between gap-2 mb-3">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                  <span className="font-bold text-white text-sm">{bank.name}</span>
                </div>
                <span className="text-[10px] font-mono-num px-1.5 py-0.5 rounded bg-[#1e2434] text-[#94a3b8]">
                  代码: {bank.code}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 bg-[#0a0c10] p-3 rounded border border-[#1b212f] mb-3 text-xs">
                <div>
                  <span className="text-[#64748b] text-[10px] block">数字人民币库存:</span>
                  <span className="font-mono-num font-bold text-white">
                    ¥ {(bank.digitalYuanInventory / 100000000).toFixed(2)} 亿
                  </span>
                </div>
                <div>
                  <span className="text-[#64748b] text-[10px] block">准备金存款:</span>
                  <span className="font-mono-num font-bold text-sky-400">
                    ¥ {(bank.depositReserve / 100000000).toFixed(2)} 亿
                  </span>
                </div>
              </div>

              <div className="space-y-1.5 text-[11px] text-[#94a3b8]">
                <div className="flex justify-between">
                  <span>接入钱包规模:</span>
                  <span className="font-mono-num text-[#cbd5e1]">{(bank.walletCount / 10000).toFixed(1)} 万户</span>
                </div>
                <div className="flex justify-between">
                  <span>今日交易量:</span>
                  <span className="font-mono-num text-[#cbd5e1]">{(bank.todayTxCount / 10000).toFixed(1)} 万笔</span>
                </div>
                <div className="flex justify-between">
                  <span>清算净头寸:</span>
                  <span className={`font-mono-num font-semibold ${bank.settlementPosition >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                    {bank.settlementPosition >= 0 ? '+' : ''}¥ {(bank.settlementPosition / 10000).toFixed(1)} 万元
                  </span>
                </div>
                <div className="flex justify-between pt-1 border-t border-[#1a2130]">
                  <span>网关延迟:</span>
                  <span className="text-emerald-400 font-mono-num">{bank.latencyMs} ms ({bank.ipAddress})</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Bank Node Detailed Control Center */}
      <div className="bg-[#12151d] border border-[#1e2433] rounded-lg p-6 space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-[#1e2433]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#2b1517] border border-[#7f1d1d] flex items-center justify-center text-[#f87171]">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-white">{selectedBank.name} 节点监控中台</h3>
                <Badge variant="green">专网通道已加密</Badge>
              </div>
              <p className="text-xs text-[#94a3b8] font-mono-num mt-0.5">
                机构代码: {selectedBank.code} | 机构IP: {selectedBank.ipAddress} | API 状态: 正常运行
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => injectBurstTransactions(2)}
              className="px-3 py-1.5 rounded bg-[#1e2434] hover:bg-[#2b344a] text-[#e2e8f0] text-xs font-semibold border border-[#334155] transition-colors"
            >
              模拟该行交易流入
            </button>
          </div>
        </div>

        {/* 4 Core Financial indicators of Bank */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          <div className="p-4 bg-[#0a0c10] border border-[#1e2433] rounded-lg">
            <span className="text-xs text-[#64748b]">数字人民币库存头寸</span>
            <div className="text-2xl font-bold text-white font-mono-num mt-1">
              ¥ {selectedBank.digitalYuanInventory.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}
            </div>
            <span className="text-[10px] text-emerald-400 mt-1 block">可即时兑换个人/企业钱包</span>
          </div>

          <div className="p-4 bg-[#0a0c10] border border-[#1e2433] rounded-lg">
            <span className="text-xs text-[#64748b]">央行准备金存款 (1:1 备付)</span>
            <div className="text-2xl font-bold text-sky-400 font-mono-num mt-1">
              ¥ {selectedBank.depositReserve.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}
            </div>
            <span className="text-[10px] text-sky-400 mt-1 block">符合宏观审慎准备金要求</span>
          </div>

          <div className="p-4 bg-[#0a0c10] border border-[#1e2433] rounded-lg">
            <span className="text-xs text-[#64748b]">清算净头寸 (跨行轧差额)</span>
            <div className={`text-2xl font-bold font-mono-num mt-1 ${selectedBank.settlementPosition >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
              {selectedBank.settlementPosition >= 0 ? '+' : ''}¥ {selectedBank.settlementPosition.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}
            </div>
            <span className="text-[10px] text-[#94a3b8] mt-1 block">
              {selectedBank.settlementPosition >= 0 ? '应收其他银行清算款' : '应付其他银行清算款'}
            </span>
          </div>

          <div className="p-4 bg-[#0a0c10] border border-[#1e2433] rounded-lg">
            <span className="text-xs text-[#64748b]">待入清算资金</span>
            <div className="text-2xl font-bold text-amber-400 font-mono-num mt-1">
              ¥ {selectedBank.pendingSettlement.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}
            </div>
            <span className="text-[10px] text-amber-400 mt-1 block">等待下一个清算批次轧差</span>
          </div>
        </div>

        {/* Bank Recent Transactions stream */}
        <div>
          <h4 className="text-xs font-bold uppercase tracking-wider text-[#94a3b8] mb-3">
            {selectedBank.name} - 实时跨行与同行交易流水
          </h4>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#0f121a] text-[#94a3b8] uppercase text-[11px] border-b border-[#1e2433]">
                <tr>
                  <th className="py-2.5 px-3">流水号</th>
                  <th className="py-2.5 px-3">付款方</th>
                  <th className="py-2.5 px-3">收款方</th>
                  <th className="py-2.5 px-3 text-right">金额</th>
                  <th className="py-2.5 px-3">用途</th>
                  <th className="py-2.5 px-3 text-center">状态</th>
                  <th className="py-2.5 px-3 text-right">时间</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1a202c]">
                {bankTransactions.slice(0, 5).map((t) => (
                  <tr key={t.id} className="hover:bg-[#161a24]">
                    <td className="py-2 px-3 font-mono-num text-[#94a3b8]">{t.id.slice(0, 16)}...</td>
                    <td className="py-2 px-3 font-medium text-white">{t.fromWalletName} ({t.fromBankName})</td>
                    <td className="py-2 px-3 font-medium text-white">{t.toWalletName} ({t.toBankName})</td>
                    <td className="py-2 px-3 text-right font-mono-num font-bold text-white">¥ {t.amount.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}</td>
                    <td className="py-2 px-3 text-[#cbd5e1]">{t.purpose}</td>
                    <td className="py-2 px-3 text-center">
                      <span className="px-1.5 py-0.5 rounded bg-[#102419] text-emerald-400 text-[10px] border border-emerald-800">
                        {t.status}
                      </span>
                    </td>
                    <td className="py-2 px-3 text-right font-mono-num text-[#64748b]">{t.timestamp.slice(11)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
