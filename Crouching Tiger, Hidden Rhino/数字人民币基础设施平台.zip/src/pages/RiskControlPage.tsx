import React, { useState } from 'react';
import { 
  ShieldAlert, 
  AlertTriangle, 
  CheckCircle2, 
  Lock, 
  Search, 
  Filter, 
  Ban, 
  ShieldCheck, 
  Activity
} from 'lucide-react';
import { useSimulation } from '../simulation/SimulationContext';
import { RiskAlert } from '../types';
import { RiskBadge, Badge } from '../components/common/Badge';
import { MetricCard } from '../components/common/MetricCard';
import { InstitutionalModal } from '../components/common/InstitutionalModal';

export const RiskControlPage: React.FC = () => {
  const { 
    riskAlerts, 
    resolveRiskAlert, 
    wallets,
    injectBurstTransactions 
  } = useSimulation();

  const [selectedAlert, setSelectedAlert] = useState<RiskAlert | null>(null);
  const [filterSeverity, setFilterSeverity] = useState<string>('ALL');
  const [feedback, setFeedback] = useState<string | null>(null);

  const filteredAlerts = riskAlerts.filter(a => {
    if (filterSeverity !== 'ALL' && a.severity !== filterSeverity) return false;
    return true;
  });

  const handleMitigate = (alertId: string, action: 'DISMISS' | 'FREEZE' | 'RESOLVE', label: string) => {
    resolveRiskAlert(alertId, action);
    setFeedback(`已成功执行处置：【${label}】并同步全网核心风控与司法监测中心`);
    if (selectedAlert?.id === alertId) {
      setSelectedAlert(null);
    }
    setTimeout(() => setFeedback(null), 5000);
  };

  const pendingAlerts = riskAlerts.filter(a => a.status === 'PENDING' || a.status === 'INVESTIGATING');
  const highRiskAlerts = riskAlerts.filter(a => a.severity === 'CRITICAL' || a.severity === 'ALERT');

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#12151d] border border-[#1e2433] p-5 rounded-lg flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-[#ef4444]" />
            <h2 className="text-lg font-bold text-white tracking-wide">
              智能风控与反洗钱监管中台 (Risk Defense & AML Center)
            </h2>
          </div>
          <p className="text-xs text-[#94a3b8] mt-1">
            实时反洗钱(AML)、可疑大额跨机构洗钱网络识别、高频异常分散汇入集中转出实时阻断
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => injectBurstTransactions(3)}
            className="px-3 py-2 rounded-md bg-[#3a181c] hover:bg-[#522026] text-[#fca5a5] border border-[#7f1d1d] text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>注入实时高频可疑流水</span>
          </button>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
        <MetricCard
          title="待核查可疑预警"
          value={`${pendingAlerts.length} 起`}
          subLabel="高危与紧急预警"
          subValue={`${highRiskAlerts.length} 起`}
          icon={AlertTriangle}
          highlight={pendingAlerts.length > 0}
        />
        <MetricCard
          title="AI 反洗钱模型命中率"
          value="99.72%"
          subLabel="误报率"
          subValue="< 0.05%"
          icon={ShieldCheck}
        />
        <MetricCard
          title="自动拦截高危交易"
          value="182 笔"
          subLabel="挽回潜在涉诈资金"
          subValue="¥ 4,820 万元"
          icon={Ban}
        />
        <MetricCard
          title="全网止付冻结钱包"
          value={`${wallets.filter(w => w.status === 'FROZEN').length} 户`}
          subLabel="司法与监管指令"
          subValue="100% 同步执行"
          icon={Lock}
        />
      </div>

      {/* Feedback Banner */}
      {feedback && (
        <div className="p-3.5 bg-[#0f291e] border border-[#166534] rounded-lg text-emerald-300 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{feedback}</span>
          </div>
          <span className="font-mono-num text-[11px] text-emerald-400">央行反洗钱监测中心备案存档</span>
        </div>
      )}

      {/* Risk Alert Queue Table */}
      <div className="bg-[#12151d] border border-[#1e2433] rounded-lg p-5">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div>
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-[#ef4444]" />
              反洗钱与异常行为预警监控流水 (AML Suspicious Activity Log)
            </h3>
            <p className="text-xs text-[#94a3b8] mt-0.5">
              点击详情可执行全网实时止付、资金原路返还或人工核查归档
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs">
            {['ALL', 'CRITICAL', 'ALERT', 'WARNING'].map(lvl => (
              <button
                key={lvl}
                onClick={() => setFilterSeverity(lvl)}
                className={`px-2.5 py-1 rounded text-xs font-semibold transition-colors ${
                  filterSeverity === lvl ? 'bg-[#8b111a] text-white' : 'bg-[#181c28] text-[#94a3b8] hover:text-white'
                }`}
              >
                {lvl === 'ALL' && '全部预警'}
                {lvl === 'CRITICAL' && '紧急高危'}
                {lvl === 'ALERT' && '预警关注'}
                {lvl === 'WARNING' && '常规提示'}
              </button>
            ))}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#0f121a] text-[#94a3b8] uppercase text-[11px] border-b border-[#1e2433]">
              <tr>
                <th className="py-2.5 px-3">预警编号</th>
                <th className="py-2.5 px-3">风险等级</th>
                <th className="py-2.5 px-3">规则名称</th>
                <th className="py-2.5 px-3">涉案钱包主体</th>
                <th className="py-2.5 px-3">研判描述与特征</th>
                <th className="py-2.5 px-3 text-center">处置状态</th>
                <th className="py-2.5 px-3 text-right">触发时间</th>
                <th className="py-2.5 px-3 text-center">操作</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1a202c]">
              {filteredAlerts.map((a) => (
                <tr key={a.id} className="hover:bg-[#161a24]">
                  <td className="py-2.5 px-3 font-mono-num font-bold text-white">{a.id}</td>
                  <td className="py-2.5 px-3">
                    <RiskBadge severity={a.severity} />
                  </td>
                  <td className="py-2.5 px-3 font-semibold text-white">
                    {a.ruleName}
                  </td>
                  <td className="py-2.5 px-3">
                    <div className="font-semibold text-white">{a.walletName}</div>
                    <div className="text-[10px] text-[#64748b] font-mono-num">{a.walletId}</div>
                  </td>
                  <td className="py-2.5 px-3">
                    <div className="text-xs text-[#cbd5e1] truncate max-w-[240px]" title={a.triggerReason}>
                      {a.triggerReason}
                    </div>
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    <Badge variant={a.status === 'PENDING' ? 'amber' : a.status === 'FROZEN' ? 'red' : 'green'}>
                      {a.status === 'PENDING' ? '待核查' : a.status === 'INVESTIGATING' ? '调查中' : a.status === 'FROZEN' ? '已全网冻结' : '已核实结案'}
                    </Badge>
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono-num text-[#64748b]">{a.timestamp}</td>
                  <td className="py-2.5 px-3 text-center">
                    <button
                      onClick={() => setSelectedAlert(a)}
                      className="px-2 py-1 rounded bg-[#1e2538] text-sky-400 hover:bg-[#2b3652] text-xs font-semibold transition-colors"
                    >
                      处置
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Alert Mitigation Modal */}
      {selectedAlert && (
        <InstitutionalModal
          isOpen={true}
          onClose={() => setSelectedAlert(null)}
          title={`反洗钱与风险处置工单 (${selectedAlert.id})`}
          subtitle="国家反洗钱监测分析中心 实时协同处置"
        >
          <div className="space-y-4 text-xs">
            <div className="p-4 bg-[#0a0c10] rounded border border-[#1e2433] space-y-2.5">
              <div className="flex justify-between border-b border-[#181f2c] pb-2">
                <span className="text-[#64748b]">涉案主体:</span>
                <span className="text-white font-bold">{selectedAlert.walletName} ({selectedAlert.walletId})</span>
              </div>
              <div className="flex justify-between border-b border-[#181f2c] pb-2">
                <span className="text-[#64748b]">命中规则:</span>
                <span className="text-amber-400 font-semibold">{selectedAlert.ruleName} ({selectedAlert.ruleId})</span>
              </div>
              <div className="flex justify-between border-b border-[#181f2c] pb-2">
                <span className="text-[#64748b]">风险等级:</span>
                <RiskBadge severity={selectedAlert.severity} />
              </div>
              <div className="border-b border-[#181f2c] pb-2">
                <span className="text-[#64748b] block mb-1">可疑研判特征:</span>
                <p className="text-[#cbd5e1] leading-relaxed">{selectedAlert.triggerReason}</p>
              </div>
            </div>

            <div className="space-y-2">
              <div className="text-xs font-semibold text-white">选择处置行动:</div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <button
                  onClick={() => handleMitigate(selectedAlert.id, 'FREEZE', '紧急全网止付并冻结涉案钱包')}
                  className="p-3 rounded bg-[#3b1216] hover:bg-[#4d171d] border border-[#7f1d1d] text-left text-red-300 space-y-1 transition-colors"
                >
                  <div className="font-bold flex items-center gap-1">
                    <Lock className="w-3.5 h-3.5" />
                    <span>全网紧急止付冻结</span>
                  </div>
                  <p className="text-[10px] text-[#fca5a5]">阻断后续任何转出与充值操作</p>
                </button>

                <button
                  onClick={() => handleMitigate(selectedAlert.id, 'DISMISS', '经人工穿透核查确认为合规政企往来，误报排除')}
                  className="p-3 rounded bg-[#2e1d10] hover:bg-[#422915] border border-[#78350f] text-left text-amber-300 space-y-1 transition-colors"
                >
                  <div className="font-bold flex items-center gap-1">
                    <ShieldAlert className="w-3.5 h-3.5" />
                    <span>排除误报并归档</span>
                  </div>
                  <p className="text-[10px] text-amber-200">消除风险标记并记录核查日志</p>
                </button>

                <button
                  onClick={() => handleMitigate(selectedAlert.id, 'RESOLVE', '已完成涉案资金溯源并移交反诈专班处置')}
                  className="p-3 rounded bg-[#0f291e] hover:bg-[#153e2e] border border-[#166534] text-left text-emerald-300 space-y-1 transition-colors"
                >
                  <div className="font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>办结移交专班</span>
                  </div>
                  <p className="text-[10px] text-emerald-200">完成资金穿透并生成调查报告</p>
                </button>
              </div>
            </div>
          </div>
        </InstitutionalModal>
      )}
    </div>
  );
};
