import React from 'react';
import { 
  BarChart3, 
  PieChart as PieIcon, 
  TrendingUp, 
  MapPin, 
  Layers, 
  ShieldCheck, 
  Globe2, 
  Scale, 
  Building, 
  Landmark,
  ArrowUpRight,
  Activity
} from 'lucide-react';
import { useSimulation } from '../simulation/SimulationContext';
import { MetricCard } from '../components/common/MetricCard';
import { Badge } from '../components/common/Badge';

export const RegulatoryPage: React.FC = () => {
  const { stats, banks, transactions, wallets } = useSimulation();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#12151d] border border-[#1e2433] p-5 rounded-lg flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-[#ef4444]" />
            <h2 className="text-lg font-bold text-white tracking-wide">
              中央银行监管分析与宏观审慎中台 (Macro Regulatory Analytics)
            </h2>
          </div>
          <p className="text-xs text-[#94a3b8] mt-1">
            穿透式实时监测法定数字货币对广义流动性、M0替代率、跨区域资本流向及实体经济传导速率
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Badge variant="green">央行宏观调控实时通道在线</Badge>
        </div>
      </div>

      {/* Core Macro KPI Indicators */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
        <MetricCard
          title="数字人民币在网流通总额 (M0)"
          value={`¥ ${(stats.totalCirculation / 100000000).toFixed(2)} 亿元`}
          subLabel="占全国流通M0比重"
          subValue="38.6% (逐年递增)"
          icon={Landmark}
          highlight={true}
        />
        <MetricCard
          title="数字货币流通速度 (Velocity)"
          value="4.82 次 / 年"
          subLabel="相较传统现钞"
          subValue="+ 31.4% (加速)"
          icon={TrendingUp}
        />
        <MetricCard
          title="终端实名钱包渗透率"
          value="71.8%"
          subLabel="高等级一/二类KYC"
          subValue="58.4%"
          icon={ShieldCheck}
        />
        <MetricCard
          title="跨区域流通结算总额"
          value={`¥ ${((transactions.reduce((a, b) => a + b.amount, 0) + 980000000) / 100000000).toFixed(1)} 亿元`}
          subLabel="跨省调配摩擦成本"
          subValue="0.00% (零手续费)"
          icon={Globe2}
        />
      </div>

      {/* Regional & Sector Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Regional Flow */}
        <div className="bg-[#12151d] border border-[#1e2433] rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <MapPin className="w-4 h-4 text-[#ef4444]" />
              国家重点战略区域流通分布 (Regional Breakdown)
            </h3>
            <span className="text-[11px] text-[#64748b]">实时总量占比</span>
          </div>

          <div className="space-y-3">
            {[
              { region: '粤港澳大湾区 (深圳/广州/跨境)', share: '32.4%', amount: '408.2 亿元', color: 'bg-[#8b111a]' },
              { region: '长三角一体化示范区 (上海/苏杭)', share: '28.6%', amount: '360.3 亿元', color: 'bg-sky-500' },
              { region: '京津冀协同发展区 (北京/雄安)', share: '21.5%', amount: '270.9 亿元', color: 'bg-emerald-500' },
              { region: '成渝双城经济圈 (成都/重庆)', share: '11.8%', amount: '148.6 亿元', color: 'bg-amber-500' },
              { region: '海南自贸港与沿边口岸专项', share: '5.7%', amount: '71.8 亿元', color: 'bg-indigo-500' },
            ].map((r, i) => (
              <div key={i} className="p-3 bg-[#0a0c10] rounded border border-[#1e2433] space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="font-semibold text-white">{r.region}</span>
                  <div className="flex items-center gap-2 font-mono-num">
                    <span className="text-white font-bold">{r.amount}</span>
                    <span className="text-[#94a3b8]">({r.share})</span>
                  </div>
                </div>
                <div className="w-full bg-[#161a24] h-1.5 rounded-full overflow-hidden">
                  <div className={`h-full ${r.color} rounded-full`} style={{ width: r.share }}></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Sector Breakdown */}
        <div className="bg-[#12151d] border border-[#1e2433] rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <Building className="w-4 h-4 text-emerald-400" />
              国民经济行业场景流向分析 (Sectoral Penetration)
            </h3>
            <span className="text-[11px] text-[#64748b]">场景渗透率</span>
          </div>

          <div className="space-y-3">
            {[
              { sector: '日常零售与大宗商超消费', pct: '38.2%', volume: '481.3 亿元', rate: '99.4% 成功率' },
              { sector: '公共交通与智慧出行 (含脱机)', pct: '24.6%', volume: '309.9 亿元', rate: '毫秒级结算' },
              { sector: '政务便民与税费社保非税征缴', pct: '18.4%', volume: '231.8 亿元', rate: '100% 自动入库' },
              { sector: '供应链金融与大宗物资采购', pct: '12.8%', volume: '161.2 亿元', rate: '智能合约保障' },
              { sector: '跨境贸易与多边央行数字货币桥 (mBridge)', pct: '6.0%', volume: '75.6 亿元', rate: '即时本币对付' },
            ].map((s, i) => (
              <div key={i} className="p-3 bg-[#0a0c10] rounded border border-[#1e2433] flex items-center justify-between text-xs">
                <div>
                  <div className="font-semibold text-white">{s.sector}</div>
                  <div className="text-[10px] text-[#64748b] mt-0.5">{s.rate}</div>
                </div>
                <div className="text-right font-mono-num">
                  <div className="font-bold text-emerald-400">{s.volume}</div>
                  <div className="text-[10px] text-[#94a3b8]">{s.pct}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Penetration & Financial Stability Assessment */}
      <div className="bg-[#12151d] border border-[#1e2433] rounded-lg p-5 space-y-3">
        <h3 className="text-sm font-semibold text-white flex items-center gap-2">
          <Scale className="w-4 h-4 text-sky-400" />
          穿透式监管与货币政策传导报告
        </h3>
        <p className="text-xs text-[#94a3b8] leading-relaxed">
          基于数字人民币中心化权威账本与分布式二级运营，央行能够<strong>实时掌握基础货币精准流向与流转速率</strong>，消除传统纸钞现金沉淀、洗钱假币与统计时滞弊端。同时，不计付利息的设计有效防范了商业银行存款“狭义银行化”脱媒风险。
        </p>
      </div>
    </div>
  );
};
