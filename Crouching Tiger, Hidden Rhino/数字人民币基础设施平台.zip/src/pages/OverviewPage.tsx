import React, { useState } from 'react';
import { 
  Coins, 
  WalletCards, 
  TrendingUp, 
  ArrowLeftRight, 
  Building2, 
  RefreshCcw, 
  SmartphoneNfc, 
  ShieldAlert, 
  Store, 
  Activity, 
  Layers,
  Zap,
  ArrowUpRight,
  ShieldCheck
} from 'lucide-react';
import { useSimulation } from '../simulation/SimulationContext';
import { MetricCard } from '../components/common/MetricCard';
import { Badge, TxStatusBadge, ClearingStatusBadge } from '../components/common/Badge';

export const OverviewPage: React.FC<{ onNavigate: (tab: any) => void }> = ({ onNavigate }) => {
  const { 
    stats, 
    banks, 
    transactions, 
    riskAlerts, 
    injectBurstTransactions, 
    executeClearingBatch 
  } = useSimulation();

  const [timeRange, setTimeRange] = useState<'TODAY' | '7D' | '30D'>('TODAY');

  // Format currency helpers
  const formatYuan = (val: number) => {
    if (val >= 100000000) {
      return `¥ ${(val / 100000000).toFixed(2)} 亿元`;
    }
    return `¥ ${val.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}`;
  };

  const formatRawCurrency = (val: number) => `¥ ${val.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}`;

  return (
    <div className="space-y-6">
      {/* Top Banner with Actions */}
      <div className="bg-gradient-to-r from-[#171b26] via-[#131620] to-[#171b26] border border-[#232a3d] p-5 rounded-lg flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#ef4444] animate-pulse"></span>
            <h2 className="text-lg font-bold text-white tracking-wide">
              数字人民币运行总览 (CBDC Central Bank Dashboard)
            </h2>
          </div>
          <p className="text-xs text-[#94a3b8] mt-1">
            全国法定数字货币实时发行总量、商业银行头寸准备金对冲、全网清算与风险态势感知
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('issuance')}
            className="px-3 py-1.5 rounded-md bg-[#8b111a] hover:bg-[#a81622] text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <Coins className="w-4 h-4" />
            <span>央行发行与回笼</span>
          </button>

          <button
            onClick={() => {
              const res = executeClearingBatch();
              alert(`成功执行全网多边净额清算：轧差 ${res.settledCount} 笔跨行交易，调拨金额 ¥${res.totalAmount.toLocaleString()} 元`);
            }}
            className="px-3 py-1.5 rounded-md bg-[#16382b] hover:bg-[#1e4b3b] text-[#86efac] border border-[#166534] text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <RefreshCcw className="w-4 h-4" />
            <span>执行批量清算</span>
          </button>

          <button
            onClick={() => injectBurstTransactions(5)}
            className="px-3 py-1.5 rounded-md bg-[#1a2030] hover:bg-[#252e45] text-[#cbd5e1] border border-[#334155] text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <Zap className="w-4 h-4 text-amber-400" />
            <span>注入并发流量</span>
          </button>
        </div>
      </div>

      {/* 12 Core CBDC Indicators Grid */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#94a3b8] flex items-center gap-1.5">
            <Activity className="w-4 h-4 text-[#ef4444]" />
            全国法定数字货币 12 项核心运行指标 (Simulated Live Telemetry)
          </h3>
          <span className="text-[11px] text-[#64748b] font-mono-num">
            更新频率: 实时连续
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3.5">
          <MetricCard
            title="数字人民币流通总量 (M0)"
            value={formatYuan(stats.totalCirculation)}
            subLabel="央行总金库对冲"
            subValue="100% 准备金锚定"
            icon={Coins}
            highlight={true}
            badgeText="法定M0"
            trend={{ value: '+1.42%', isPositive: true }}
          />

          <MetricCard
            title="累计开立钱包总数"
            value={`${(stats.totalWalletsCount / 10000).toFixed(1)} 万个`}
            subLabel="个人/对公比例"
            subValue="84.2% : 15.8%"
            icon={WalletCards}
            trend={{ value: '+0.88%', isPositive: true }}
          />

          <MetricCard
            title="月度活跃钱包规模"
            value={`${(stats.activeWalletsCount / 10000).toFixed(1)} 万个`}
            subLabel="活跃度系数"
            subValue="72.4%"
            icon={Activity}
            trend={{ value: '+2.10%', isPositive: true }}
          />

          <MetricCard
            title="今日交易处理笔数"
            value={`${(stats.todayTxCount / 10000).toFixed(2)} 万笔`}
            subLabel="系统峰值容量"
            subValue="100,000+ TPS"
            icon={ArrowLeftRight}
            trend={{ value: '+5.32%', isPositive: true }}
          />

          <MetricCard
            title="今日全网交易金额"
            value={formatYuan(stats.todayTxVolume)}
            subLabel="笔均消费金额"
            subValue="¥ 409.50"
            icon={TrendingUp}
            trend={{ value: '+3.15%', isPositive: true }}
          />

          <MetricCard
            title="实时交易处理速率 (TPS)"
            value={`${stats.realTimeTps} 笔/秒`}
            subLabel="当前网关延迟"
            subValue="8.4 ms"
            icon={Zap}
            badgeText="毫秒级"
            trend={{ value: '峰值 9,400', isPositive: true }}
          />

          <MetricCard
            title="今日清算总额 (RTGS+轧差)"
            value={formatYuan(stats.todayClearingVolume)}
            subLabel="清算对账完成率"
            subValue="100.00%"
            icon={RefreshCcw}
            trend={{ value: '轧差无差错', isPositive: true }}
          />

          <MetricCard
            title="全网商户覆盖数量"
            value={`${(stats.merchantCount / 10000).toFixed(1)} 万户`}
            subLabel="线下/线上接入"
            subValue="68% : 32%"
            icon={Store}
            trend={{ value: '+1.75%', isPositive: true }}
          />

          <MetricCard
            title="一级运营机构 (银行)"
            value={`${stats.bankCount} 家银行`}
            subLabel="六大行+股份行+互联网行"
            subValue="全部在线"
            icon={Building2}
            badgeText="双层架构"
          />

          <MetricCard
            title="双离线支付交易笔数"
            value={`${stats.offlineTxCount.toLocaleString()} 笔`}
            subLabel="SE硬件芯片状态"
            subValue="全部验签正常"
            icon={SmartphoneNfc}
            trend={{ value: '脱机安全', isPositive: true }}
          />

          <MetricCard
            title="跨机构清算交易笔数"
            value={`${(stats.crossBankTxCount / 10000).toFixed(1)} 万笔`}
            subLabel="跨行占比"
            subValue="38.4%"
            icon={Layers}
            trend={{ value: '+4.20%', isPositive: true }}
          />

          <MetricCard
            title="实时异常与风控预警"
            value={`${stats.anomalyTxCount} 件挂起`}
            subLabel="规则引擎"
            subValue="毫秒级阻断"
            icon={ShieldAlert}
            highlight={stats.anomalyTxCount > 0}
            badgeText={stats.anomalyTxCount > 0 ? '需研判' : '平稳'}
          />
        </div>
      </div>

      {/* Main Charts & Analytics Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Left 2 Cols: Monetary Circulation & Transaction Dynamics Chart */}
        <div className="lg:col-span-2 bg-[#12151d] border border-[#1e2433] rounded-lg p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-white">
                数字人民币流通规模与交易吞吐量时序走势 (24-Hour Dynamics)
              </h3>
              <p className="text-xs text-[#94a3b8] mt-0.5">
                实时采集各运营机构 M0 投放额度与跨机构交易速率 (笔/秒)
              </p>
            </div>
            <div className="flex items-center gap-1 bg-[#181c28] p-1 rounded border border-[#2a3449]">
              {(['TODAY', '7D', '30D'] as const).map(t => (
                <button
                  key={t}
                  onClick={() => setTimeRange(t)}
                  className={`px-2 py-0.5 text-xs rounded transition-colors ${
                    timeRange === t ? 'bg-[#8b111a] text-white font-medium' : 'text-[#94a3b8] hover:text-white'
                  }`}
                >
                  {t === 'TODAY' ? '今日24H' : t === '7D' ? '近7日' : '近30日'}
                </button>
              ))}
            </div>
          </div>

          {/* Simulated High-Density SVG Area & Line Chart */}
          <div className="relative h-64 w-full bg-[#0a0c10] rounded border border-[#1a1f2c] p-4 flex flex-col justify-between">
            {/* Grid Lines */}
            <div className="absolute inset-0 grid grid-rows-4 grid-cols-6 pointer-events-none opacity-20">
              <div className="border-b border-r border-[#64748b]/40"></div>
              <div className="border-b border-r border-[#64748b]/40"></div>
              <div className="border-b border-r border-[#64748b]/40"></div>
              <div className="border-b border-r border-[#64748b]/40"></div>
              <div className="border-b border-r border-[#64748b]/40"></div>
              <div className="border-b border-[#64748b]/40"></div>
              <div className="border-b border-r border-[#64748b]/40"></div>
              <div className="border-b border-r border-[#64748b]/40"></div>
              <div className="border-b border-r border-[#64748b]/40"></div>
              <div className="border-b border-r border-[#64748b]/40"></div>
              <div className="border-b border-r border-[#64748b]/40"></div>
              <div className="border-b border-[#64748b]/40"></div>
              <div className="border-b border-r border-[#64748b]/40"></div>
              <div className="border-b border-r border-[#64748b]/40"></div>
              <div className="border-b border-r border-[#64748b]/40"></div>
              <div className="border-b border-r border-[#64748b]/40"></div>
              <div className="border-b border-r border-[#64748b]/40"></div>
              <div className="border-b border-[#64748b]/40"></div>
              <div className="border-r border-[#64748b]/40"></div>
              <div className="border-r border-[#64748b]/40"></div>
              <div className="border-r border-[#64748b]/40"></div>
              <div className="border-r border-[#64748b]/40"></div>
              <div className="border-r border-[#64748b]/40"></div>
              <div></div>
            </div>

            {/* SVG Polylines for Circulation & TPS */}
            <svg className="w-full h-full overflow-visible z-10" viewBox="0 0 500 180" preserveAspectRatio="none">
              <defs>
                <linearGradient id="circGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#ef4444" stopOpacity="0.35" />
                  <stop offset="100%" stopColor="#ef4444" stopOpacity="0.0" />
                </linearGradient>
                <linearGradient id="tpsGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.25" />
                  <stop offset="100%" stopColor="#38bdf8" stopOpacity="0.0" />
                </linearGradient>
              </defs>

              {/* Area 1: Circulation Volume */}
              <polygon
                points="0,150 40,140 80,135 120,110 160,115 200,95 240,75 280,80 320,60 360,50 400,45 440,35 480,28 500,25 500,180 0,180"
                fill="url(#circGradient)"
              />
              <polyline
                fill="none"
                stroke="#ef4444"
                strokeWidth="2.5"
                points="0,150 40,140 80,135 120,110 160,115 200,95 240,75 280,80 320,60 360,50 400,45 440,35 480,28 500,25"
              />

              {/* Line 2: Real-time TPS Fluctuations */}
              <polygon
                points="0,170 40,165 80,160 120,130 160,140 200,105 240,90 280,100 320,80 360,70 400,65 440,55 480,48 500,42 500,180 0,180"
                fill="url(#tpsGradient)"
              />
              <polyline
                fill="none"
                stroke="#38bdf8"
                strokeWidth="2"
                strokeDasharray="4 2"
                points="0,170 40,165 80,160 120,130 160,140 200,105 240,90 280,100 320,80 360,70 400,65 440,55 480,48 500,42"
              />

              {/* Current Point */}
              <circle cx="500" cy="25" r="4" fill="#ef4444" />
              <circle cx="500" cy="42" r="4" fill="#38bdf8" />
            </svg>

            {/* X-Axis labels */}
            <div className="flex justify-between text-[10px] text-[#64748b] font-mono-num z-10 pt-2 border-t border-[#1e2433]">
              <span>00:00</span>
              <span>04:00</span>
              <span>08:00</span>
              <span>12:00</span>
              <span>16:00</span>
              <span>20:00</span>
              <span>实时 (NOW)</span>
            </div>
          </div>

          {/* Chart Legend & Telemetry stats */}
          <div className="mt-3 flex flex-wrap items-center justify-between text-xs text-[#94a3b8] gap-4">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-1 bg-[#ef4444] rounded"></span>
                <span>数字人民币流通量 (亿元)</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-1 bg-[#38bdf8] rounded border-b border-dashed border-[#38bdf8]"></span>
                <span>交易处理速率 (TPS 负载)</span>
              </span>
            </div>
            <div className="text-[11px] text-[#64748b] font-mono-num">
              央行全天清算峰值: <span className="text-white font-medium">102,400 TPS</span> | 平均延迟: <span className="text-emerald-400">8.2ms</span>
            </div>
          </div>
        </div>

        {/* Right 1 Col: Commercial Banks Node Liquidity Share */}
        <div className="bg-[#12151d] border border-[#1e2433] rounded-lg p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-white flex items-center gap-1.5">
                <Building2 className="w-4 h-4 text-[#ef4444]" />
                运营机构头寸库存占比
              </h3>
              <button 
                onClick={() => onNavigate('institution')}
                className="text-xs text-sky-400 hover:text-sky-300 flex items-center gap-0.5"
              >
                机构详情 <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>
            <p className="text-xs text-[#94a3b8] mb-4">
              9 家运营机构数字人民币备付库存分布情况
            </p>

            {/* Bank Bars */}
            <div className="space-y-2.5">
              {banks.slice(0, 6).map((bank) => {
                const totalInventory = banks.reduce((a, b) => a + b.digitalYuanInventory, 0);
                const percent = ((bank.digitalYuanInventory / totalInventory) * 100).toFixed(1);
                return (
                  <div key={bank.id} className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="text-[#cbd5e1] font-medium flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                        {bank.name}
                      </span>
                      <span className="text-white font-mono-num font-semibold">
                        ¥ {(bank.digitalYuanInventory / 100000000).toFixed(1)} 亿 ({percent}%)
                      </span>
                    </div>
                    <div className="w-full h-1.5 bg-[#1a202c] rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-gradient-to-r from-[#991b1b] to-[#ef4444] rounded-full transition-all duration-500"
                        style={{ width: `${percent}%` }}
                      ></div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-[#1e2433] flex items-center justify-between text-xs text-[#94a3b8]">
            <span>法定准备金总池: <strong className="text-white font-mono-num">¥ 895.0 亿元</strong></span>
            <span className="text-emerald-400 font-mono-num font-medium">100% 准备金履约</span>
          </div>
        </div>
      </div>

      {/* Recent Ledger Stream & Active Risk Center */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Left 2 Cols: Real-time Transaction Ledger stream */}
        <div className="lg:col-span-2 bg-[#12151d] border border-[#1e2433] rounded-lg p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-white flex items-center gap-1.5">
                <ArrowLeftRight className="w-4 h-4 text-[#ef4444]" />
                全网实时核心交易流水 (Live Transaction Stream)
              </h3>
              <p className="text-xs text-[#94a3b8] mt-0.5">
                各钱包与商户端即时结算广播日志 (不可篡改核心账本)
              </p>
            </div>
            <button
              onClick={() => onNavigate('circulation')}
              className="text-xs text-sky-400 hover:text-sky-300 flex items-center gap-1"
            >
              查看全量账本 <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Compact Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#0f121a] text-[#94a3b8] uppercase text-[11px] border-b border-[#1e2433]">
                <tr>
                  <th className="py-2.5 px-3 font-semibold">流水号</th>
                  <th className="py-2.5 px-3 font-semibold">付款方 / 机构</th>
                  <th className="py-2.5 px-3 font-semibold">收款方 / 机构</th>
                  <th className="py-2.5 px-3 font-semibold text-right">金额 (元)</th>
                  <th className="py-2.5 px-3 font-semibold">类型</th>
                  <th className="py-2.5 px-3 font-semibold text-center">状态</th>
                  <th className="py-2.5 px-3 font-semibold text-right">时间戳</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1a202c]">
                {transactions.slice(0, 6).map((tx) => (
                  <tr key={tx.id} className="hover:bg-[#161a24] transition-colors">
                    <td className="py-2.5 px-3 font-mono-num text-[#94a3b8] font-medium">
                      {tx.id.slice(0, 16)}...
                    </td>
                    <td className="py-2.5 px-3">
                      <div className="font-medium text-[#e2e8f0] truncate max-w-[120px]">{tx.fromWalletName}</div>
                      <div className="text-[10px] text-[#64748b]">{tx.fromBankName}</div>
                    </td>
                    <td className="py-2.5 px-3">
                      <div className="font-medium text-[#e2e8f0] truncate max-w-[120px]">{tx.toWalletName}</div>
                      <div className="text-[10px] text-[#64748b]">{tx.toBankName}</div>
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono-num font-bold text-white">
                      ¥ {tx.amount.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="text-[11px] text-[#cbd5e1]">{tx.purpose}</span>
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      <TxStatusBadge status={tx.status} />
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono-num text-[11px] text-[#64748b]">
                      {tx.timestamp.slice(11)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right 1 Col: Risk & AML Real-time Anomaly Panel */}
        <div className="bg-[#12151d] border border-[#1e2433] rounded-lg p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-white flex items-center gap-1.5">
                <ShieldAlert className="w-4 h-4 text-amber-400" />
                央行实时反洗钱与风险态势
              </h3>
              <button
                onClick={() => onNavigate('risk')}
                className="text-xs text-sky-400 hover:text-sky-300 flex items-center gap-0.5"
              >
                风控中心 <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>
            <p className="text-xs text-[#94a3b8] mb-4">
              规则引擎实时阻断涉案可疑资金流向
            </p>

            <div className="space-y-3">
              {riskAlerts.slice(0, 3).map((alert) => (
                <div key={alert.id} className="p-3 rounded bg-[#161a24] border border-[#232a3d] space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-white flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-red-400 animate-ping"></span>
                      {alert.ruleName}
                    </span>
                    <Badge variant={alert.severity === 'CRITICAL' ? 'red' : 'amber'}>
                      {alert.severity === 'CRITICAL' ? '高危拦截' : '预警关注'}
                    </Badge>
                  </div>
                  <p className="text-[11px] text-[#94a3b8] leading-relaxed line-clamp-2">
                    {alert.triggerReason}
                  </p>
                  <div className="flex justify-between items-center text-[10px] text-[#64748b] font-mono-num pt-1 border-t border-[#1f2636]">
                    <span>主体: {alert.walletName}</span>
                    <span>{alert.timestamp.slice(11)}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-[#1e2433] flex items-center justify-between text-xs">
            <span className="text-[#94a3b8]">国家级AML规则库: <strong className="text-white">48 项在役</strong></span>
            <span className="text-sky-400 font-mono-num font-medium">毫秒级图计算引擎</span>
          </div>
        </div>
      </div>
    </div>
  );
};
