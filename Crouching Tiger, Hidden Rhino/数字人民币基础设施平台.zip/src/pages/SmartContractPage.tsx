import React, { useState } from 'react';
import { 
  FileCode2, 
  Play, 
  Pause, 
  Plus, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  Sparkles, 
  Layers, 
  Lock, 
  ShieldCheck, 
  Code2, 
  Tag, 
  MapPin, 
  Calendar 
} from 'lucide-react';
import { useSimulation } from '../simulation/SimulationContext';
import { ProgrammableRule } from '../types';
import { MetricCard } from '../components/common/MetricCard';
import { Badge, ContractStatusBadge } from '../components/common/Badge';
import { InstitutionalModal } from '../components/common/InstitutionalModal';

export const SmartContractPage: React.FC = () => {
  const { 
    programmableRules, 
    executeProgrammableRule, 
    wallets 
  } = useSimulation();

  const [selectedRule, setSelectedRule] = useState<ProgrammableRule | null>(null);
  const [filterCategory, setFilterCategory] = useState<string>('ALL');
  const [executionFeedback, setExecutionFeedback] = useState<string | null>(null);
  const [isDeployOpen, setIsDeployOpen] = useState<boolean>(false);

  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<'SUBSIDY' | 'SALARY' | 'SUPPLY_CHAIN' | 'GREEN_CREDIT' | 'PROJECT_FUNDS'>('SUBSIDY');
  const [newAmount, setNewAmount] = useState('5000000');
  const [newCondition, setNewCondition] = useState('仅限指定绿色环保或民生消费商户核销使用');

  const filteredRules = programmableRules.filter((r) => {
    if (filterCategory !== 'ALL' && r.category !== filterCategory) return false;
    return true;
  });

  const handleExecute = (ruleId: string) => {
    const res = executeProgrammableRule(ruleId);
    if (res.success) {
      setExecutionFeedback(`智能合约【${ruleId}】执行完毕：成功向 ${res.executedCount} 个符合条件的终端钱包划拨资金共 ¥ ${res.amount.toLocaleString('zh-CN', { minimumFractionDigits: 2 })} 元`);
      setTimeout(() => setExecutionFeedback(null), 5000);
    }
  };

  const totalAllocated = programmableRules.reduce((acc, r) => acc + r.totalAllocated, 0);
  const totalExecuted = programmableRules.reduce((acc, r) => acc + r.executedAmount, 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#12151d] border border-[#1e2433] p-5 rounded-lg flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <FileCode2 className="w-5 h-5 text-[#ef4444]" />
            <h2 className="text-lg font-bold text-white tracking-wide">
              数字人民币智能合约与可编程支付中台 (Programmable e-CNY Center)
            </h2>
          </div>
          <p className="text-xs text-[#94a3b8] mt-1">
            加载于法定数字货币内核的条件支付引擎，实现资金定向用途锁定、财政专项补贴自动滴灌与供应链自动履约
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsDeployOpen(true)}
            className="px-3.5 py-2 rounded-md bg-[#8b111a] hover:bg-[#a81622] text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>部署新智能合约模板</span>
          </button>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
        <MetricCard
          title="运行中智能合约"
          value={`${programmableRules.filter(r => r.status === 'ACTIVE').length} 个`}
          subLabel="已部署模板库"
          subValue={`${programmableRules.length} 个`}
          icon={Code2}
          highlight={true}
        />
        <MetricCard
          title="智能合约托管总资金"
          value={`¥ ${(totalAllocated / 100000000).toFixed(2)} 亿元`}
          subLabel="已完成条件履约核销"
          subValue={`¥ ${(totalExecuted / 100000000).toFixed(2)} 亿元`}
          icon={Layers}
        />
        <MetricCard
          title="累计触发执行批次"
          value={`${programmableRules.reduce((acc, r) => acc + r.executionCount, 0)} 次`}
          subLabel="履约正确率"
          subValue="100.00% (零纠纷)"
          icon={Sparkles}
        />
        <MetricCard
          title="沙箱隔离与合规审核"
          value="SM2/SM3 验签通过"
          subLabel="图灵完备约束"
          subValue="非侵入央行币值"
          icon={ShieldCheck}
        />
      </div>

      {/* Feedback Banner */}
      {executionFeedback && (
        <div className="p-3.5 bg-[#0f291e] border border-[#166534] rounded-lg text-emerald-300 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{executionFeedback}</span>
          </div>
          <span className="font-mono-num text-[11px] text-emerald-400">已记录央行智能合约审计流水</span>
        </div>
      )}

      {/* Contract Rules List */}
      <div className="bg-[#12151d] border border-[#1e2433] rounded-lg p-5">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div>
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <FileCode2 className="w-4 h-4 text-[#ef4444]" />
              在网执行可编程合约规则库 (Smart Contract Ledger)
            </h3>
            <p className="text-xs text-[#94a3b8] mt-0.5">
              央行白名单认证模板，支持一键触发批量履约或查看触发逻辑
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs">
            {['ALL', 'SUBSIDY', 'SUPPLY_CHAIN', 'GREEN_CREDIT', 'SALARY'].map(cat => (
              <button
                key={cat}
                onClick={() => setFilterCategory(cat)}
                className={`px-2.5 py-1 rounded text-xs font-semibold transition-colors ${
                  filterCategory === cat ? 'bg-[#8b111a] text-white' : 'bg-[#181c28] text-[#94a3b8] hover:text-white'
                }`}
              >
                {cat === 'ALL' && '全部模板'}
                {cat === 'SUBSIDY' && '财政消费补贴'}
                {cat === 'SUPPLY_CHAIN' && '供应链账期'}
                {cat === 'GREEN_CREDIT' && '绿色碳普惠'}
                {cat === 'SALARY' && '农民工工资代发'}
              </button>
            ))}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#0f121a] text-[#94a3b8] uppercase text-[11px] border-b border-[#1e2433]">
              <tr>
                <th className="py-2.5 px-3">合约代码</th>
                <th className="py-2.5 px-3">合约名称与用途</th>
                <th className="py-2.5 px-3">发起主体</th>
                <th className="py-2.5 px-3 text-right">托管预算总额</th>
                <th className="py-2.5 px-3 text-right">已执行核销额</th>
                <th className="py-2.5 px-3">触发条件限制</th>
                <th className="py-2.5 px-3 text-center">状态</th>
                <th className="py-2.5 px-3 text-center">操作</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1a202c]">
              {filteredRules.map((rule) => {
                const progress = rule.totalAllocated > 0 ? (rule.executedAmount / rule.totalAllocated) * 100 : 0;
                return (
                  <tr key={rule.id} className="hover:bg-[#161a24]">
                    <td className="py-3 px-3 font-mono-num font-bold text-white">{rule.id}</td>
                    <td className="py-3 px-3">
                      <div className="font-semibold text-white">{rule.title}</div>
                      <div className="text-[10px] text-[#64748b]">有效期至: {rule.validUntil}</div>
                    </td>
                    <td className="py-3 px-3">
                      <div className="text-white font-medium">{rule.sourceWalletName}</div>
                      <div className="text-[10px] text-[#64748b] font-mono-num">{rule.sourceWalletId}</div>
                    </td>
                    <td className="py-3 px-3 text-right font-mono-num font-bold text-white">
                      ¥ {rule.totalAllocated.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}
                    </td>
                    <td className="py-3 px-3 text-right font-mono-num">
                      <span className="font-bold text-emerald-400">
                        ¥ {rule.executedAmount.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}
                      </span>
                      <div className="text-[10px] text-[#64748b]">已核销 {progress.toFixed(1)}%</div>
                    </td>
                    <td className="py-3 px-3 max-w-[220px]">
                      <div className="text-xs text-[#cbd5e1] truncate" title={rule.conditionDescription}>
                        {rule.conditionDescription}
                      </div>
                      <div className="text-[10px] text-sky-400 mt-0.5">目标: {rule.targetCriteria}</div>
                    </td>
                    <td className="py-3 px-3 text-center">
                      <ContractStatusBadge status={rule.status} />
                    </td>
                    <td className="py-3 px-3 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => handleExecute(rule.id)}
                          disabled={rule.status !== 'ACTIVE'}
                          className="px-2.5 py-1 rounded bg-[#1e293b] hover:bg-[#2e3e5b] text-sky-400 font-semibold text-xs flex items-center gap-1 transition-colors disabled:opacity-40"
                        >
                          <Play className="w-3 h-3" />
                          <span>执行</span>
                        </button>
                        <button
                          onClick={() => setSelectedRule(rule)}
                          className="px-2 py-1 rounded bg-[#141824] hover:bg-[#1f2638] text-[#94a3b8] text-xs font-semibold transition-colors"
                        >
                          详情
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Contract Detail Modal */}
      {selectedRule && (
        <InstitutionalModal
          isOpen={true}
          onClose={() => setSelectedRule(null)}
          title={`可编程智能合约技术参数 (${selectedRule.id})`}
          subtitle="央行数字货币可编程沙箱虚拟机 (e-CNY VM)"
        >
          <div className="space-y-4 text-xs">
            <div className="p-4 bg-[#0a0c10] rounded border border-[#1e2433] space-y-2.5">
              <div className="flex justify-between border-b border-[#181f2c] pb-2">
                <span className="text-[#64748b]">合约名称:</span>
                <span className="text-white font-bold">{selectedRule.title}</span>
              </div>
              <div className="flex justify-between border-b border-[#181f2c] pb-2">
                <span className="text-[#64748b]">资金来源托管钱包:</span>
                <span className="text-white">{selectedRule.sourceWalletName} ({selectedRule.sourceWalletId})</span>
              </div>
              <div className="flex justify-between border-b border-[#181f2c] pb-2">
                <span className="text-[#64748b]">资金总规模:</span>
                <span className="text-emerald-400 font-bold font-mono-num">
                  ¥ {selectedRule.totalAllocated.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}
                </span>
              </div>
              <div className="flex justify-between border-b border-[#181f2c] pb-2">
                <span className="text-[#64748b]">触发与约束类型:</span>
                <span className="text-sky-400">{selectedRule.triggerType}</span>
              </div>
              <div className="border-b border-[#181f2c] pb-2">
                <span className="text-[#64748b] block mb-1">条件履约规则详情:</span>
                <p className="text-[#cbd5e1] leading-relaxed">{selectedRule.conditionDescription}</p>
              </div>
            </div>

            <div className="flex justify-end gap-2">
              <button
                onClick={() => setSelectedRule(null)}
                className="px-4 py-2 bg-[#181c28] hover:bg-[#23293a] text-white rounded text-xs font-semibold"
              >
                关闭
              </button>
            </div>
          </div>
        </InstitutionalModal>
      )}

      {/* Deploy Template Modal */}
      {isDeployOpen && (
        <InstitutionalModal
          isOpen={true}
          onClose={() => setIsDeployOpen(false)}
          title="部署新数字人民币可编程合约"
          subtitle="财政、企事业单位与商业银行定制智能规则"
        >
          <div className="space-y-4 text-xs">
            <div>
              <label className="block text-[#94a3b8] mb-1">合约名称与用途:</label>
              <input
                type="text"
                placeholder="例如：2026年新能源汽车置换补贴定向消费红包"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                className="w-full bg-[#0a0c10] border border-[#2a3449] rounded-md px-3 py-2 text-xs text-white focus:outline-none focus:border-[#ef4444]"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-[#94a3b8] mb-1">业务分类:</label>
                <select
                  value={newCategory}
                  onChange={(e: any) => setNewCategory(e.target.value)}
                  className="w-full bg-[#0a0c10] border border-[#2a3449] rounded-md px-3 py-2 text-xs text-white focus:outline-none focus:border-[#ef4444]"
                >
                  <option value="SUBSIDY">财政定向消费补贴</option>
                  <option value="SUPPLY_CHAIN">供应链核心企业应付账款</option>
                  <option value="GREEN_CREDIT">绿色信贷与碳积分奖励</option>
                  <option value="SALARY">工程项目工资专户锁定</option>
                </select>
              </div>

              <div>
                <label className="block text-[#94a3b8] mb-1">托管预算规模 (元):</label>
                <input
                  type="number"
                  value={newAmount}
                  onChange={(e) => setNewAmount(e.target.value)}
                  className="w-full bg-[#0a0c10] border border-[#2a3449] rounded-md px-3 py-2 text-xs text-white focus:outline-none focus:border-[#ef4444]"
                />
              </div>
            </div>

            <div>
              <label className="block text-[#94a3b8] mb-1">核销约束与防挪用规则:</label>
              <textarea
                rows={2}
                value={newCondition}
                onChange={(e) => setNewCondition(e.target.value)}
                className="w-full bg-[#0a0c10] border border-[#2a3449] rounded-md px-3 py-2 text-xs text-white focus:outline-none focus:border-[#ef4444]"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-[#1e2433]">
              <button
                onClick={() => setIsDeployOpen(false)}
                className="px-4 py-2 bg-[#181c28] hover:bg-[#23293a] text-white rounded text-xs font-semibold"
              >
                取消
              </button>
              <button
                onClick={() => {
                  setIsDeployOpen(false);
                  setExecutionFeedback(`新智能合约【${newTitle || '数字人民币财政定向补贴'}】已成功上链部署并进入就绪状态。`);
                  setTimeout(() => setExecutionFeedback(null), 5000);
                }}
                className="px-4 py-2 bg-[#8b111a] hover:bg-[#a81622] text-white rounded text-xs font-semibold"
              >
                签署并部署上链
              </button>
            </div>
          </div>
        </InstitutionalModal>
      )}
    </div>
  );
};
