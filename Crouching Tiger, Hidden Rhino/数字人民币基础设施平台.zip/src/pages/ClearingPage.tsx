import React, { useState } from 'react';
import { 
  RefreshCcw, 
  Layers, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  ArrowRight, 
  Scale, 
  Filter, 
  Play, 
  Sparkles,
  Zap,
  Building2
} from 'lucide-react';
import { useSimulation } from '../simulation/SimulationContext';
import { ClearingStatusBadge, TxStatusBadge } from '../components/common/Badge';
import { MetricCard } from '../components/common/MetricCard';

export const ClearingPage: React.FC = () => {
  const { 
    transactions, 
    banks, 
    executeClearingBatch, 
    injectBurstTransactions 
  } = useSimulation();

  const [isClearingInProgress, setIsClearingInProgress] = useState<boolean>(false);
  const [lastClearingResult, setLastClearingResult] = useState<{ settledCount: number; totalAmount: number } | null>(null);

  // Queue transactions
  const queueTxs = transactions.filter(t => t.clearingStatus === 'IN_QUEUE' || t.status === 'COMPLETED');
  const settledTxs = transactions.filter(t => t.clearingStatus === 'SETTLED');
  const failedTxs = transactions.filter(t => t.clearingStatus === 'FAILED' || t.status === 'REJECTED' || t.status === 'INTERCEPTED');

  const handleRunClearing = () => {
    setIsClearingInProgress(true);
    setTimeout(() => {
      const res = executeClearingBatch();
      setLastClearingResult(res);
      setIsClearingInProgress(false);
    }, 600);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#12151d] border border-[#1e2433] p-5 rounded-lg flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <RefreshCcw className="w-5 h-5 text-[#ef4444]" />
            <h2 className="text-lg font-bold text-white tracking-wide">
              支付清算中心 (CBDC Payment Clearing & Settlement Center)
            </h2>
          </div>
          <p className="text-xs text-[#94a3b8] mt-1">
            全国法定数字货币实时清算队列、多边净额轧差、跨机构资金清算与全天候对账总控
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleRunClearing}
            disabled={isClearingInProgress}
            className={`px-4 py-2 rounded-md text-xs font-bold flex items-center gap-2 shadow-md transition-all ${
              isClearingInProgress
                ? 'bg-[#1b3a2a] text-emerald-300 cursor-not-allowed'
                : 'bg-[#166534] hover:bg-[#15803d] text-white'
            }`}
          >
            <RefreshCcw className={`w-4 h-4 ${isClearingInProgress ? 'animate-spin' : ''}`} />
            <span>{isClearingInProgress ? '正在执行多边净额轧差...' : '立即执行批量清算'}</span>
          </button>

          <button
            onClick={() => injectBurstTransactions(4)}
            className="px-3 py-2 rounded-md bg-[#1a2030] hover:bg-[#252e45] text-[#cbd5e1] border border-[#334155] text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span>注入队列交易</span>
          </button>
        </div>
      </div>

      {/* Clearing Telemetry Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
        <MetricCard
          title="实时清算待处理队列"
          value={`${queueTxs.length} 笔`}
          subLabel="排队总金额"
          subValue={`¥ ${(queueTxs.reduce((a, b) => a + b.amount, 0)).toLocaleString()}`}
          icon={Clock}
          highlight={queueTxs.length > 0}
          badgeText="实时排队"
        />

        <MetricCard
          title="今日已完成清算笔数"
          value={`${settledTxs.length + 12840} 笔`}
          subLabel="对账成功率"
          subValue="100.00%"
          icon={CheckCircle2}
        />

        <MetricCard
          title="全网跨机构净头寸轧差"
          value="¥ 8,420.5 万元"
          subLabel="节省流动性比例"
          subValue="88.4%"
          icon={Scale}
        />

        <MetricCard
          title="清算失败 / 风险拦截"
          value={`${failedTxs.length} 笔`}
          subLabel="异常挂起"
          subValue="已隔离处置"
          icon={AlertCircle}
        />
      </div>

      {/* Clearing Execution Feedback */}
      {lastClearingResult && (
        <div className="p-4 bg-[#0f291e] border border-[#166534] rounded-lg text-emerald-300 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span className="font-semibold">
              清算批次执行成功：已对 {lastClearingResult.settledCount} 笔跨机构交易执行净额轧差，调拨总额 ¥{lastClearingResult.totalAmount.toLocaleString()} 元。
            </span>
          </div>
          <span className="font-mono-num text-[11px] text-emerald-400">央行核心大额RTGS对账平账</span>
        </div>
      )}

      {/* Real-time Clearing Queue Stream */}
      <div className="bg-[#12151d] border border-[#1e2433] rounded-lg p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <Clock className="w-4 h-4 text-amber-400" />
              当前实时待清算队列 (Real-Time Clearing Queue)
            </h3>
            <p className="text-xs text-[#94a3b8] mt-0.5">
              已完成端到端支付但尚未在央行核心账户完成机构间准备金净额划拨的交易
            </p>
          </div>
          <span className="text-xs font-mono-num text-[#94a3b8]">
            队列长度: <strong className="text-white">{queueTxs.length}</strong> 笔
          </span>
        </div>

        {queueTxs.length === 0 ? (
          <div className="p-8 text-center bg-[#0a0c10] border border-[#1c2230] rounded-lg text-xs text-[#64748b]">
            <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto mb-2 opacity-80" />
            <div className="text-white font-semibold">当前清算队列无挂起交易</div>
            <p className="text-[#94a3b8] mt-1">所有跨行交易均已实时轧差并完成央行准备金划拨入账</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#0f121a] text-[#94a3b8] uppercase text-[11px] border-b border-[#1e2433]">
                <tr>
                  <th className="py-2.5 px-3">流水编号</th>
                  <th className="py-2.5 px-3">付款机构</th>
                  <th className="py-2.5 px-3 text-center">流向</th>
                  <th className="py-2.5 px-3">收款机构</th>
                  <th className="py-2.5 px-3 text-right">交易金额</th>
                  <th className="py-2.5 px-3">支付用途</th>
                  <th className="py-2.5 px-3 text-center">清算状态</th>
                  <th className="py-2.5 px-3 text-right">发生时间</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1a202c]">
                {queueTxs.map((tx) => (
                  <tr key={tx.id} className="hover:bg-[#161a24]">
                    <td className="py-2.5 px-3 font-mono-num text-white">{tx.id}</td>
                    <td className="py-2.5 px-3 font-semibold text-white">{tx.fromBankName}</td>
                    <td className="py-2.5 px-3 text-center text-[#64748b]">→</td>
                    <td className="py-2.5 px-3 font-semibold text-white">{tx.toBankName}</td>
                    <td className="py-2.5 px-3 text-right font-mono-num font-bold text-emerald-400">
                      ¥ {tx.amount.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}
                    </td>
                    <td className="py-2.5 px-3 text-[#cbd5e1]">{tx.purpose}</td>
                    <td className="py-2.5 px-3 text-center">
                      <ClearingStatusBadge status={tx.clearingStatus} />
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono-num text-[#64748b]">{tx.timestamp}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Settled Historical Clearing Ledger */}
      <div className="bg-[#12151d] border border-[#1e2433] rounded-lg p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              已完成清算轧差全量总账 (Settled Clearing Ledger)
            </h3>
            <p className="text-xs text-[#94a3b8] mt-0.5">
              央行 CNAPS-CBDC 系统最终确权入账记录
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#0f121a] text-[#94a3b8] uppercase text-[11px] border-b border-[#1e2433]">
              <tr>
                <th className="py-2.5 px-3">流水号</th>
                <th className="py-2.5 px-3">付款方 (机构)</th>
                <th className="py-2.5 px-3">收款方 (机构)</th>
                <th className="py-2.5 px-3 text-right">金额 (元)</th>
                <th className="py-2.5 px-3">用途分类</th>
                <th className="py-2.5 px-3 text-center">清算状态</th>
                <th className="py-2.5 px-3 text-right">时间戳</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1a202c]">
              {settledTxs.slice(0, 8).map((tx) => (
                <tr key={tx.id} className="hover:bg-[#161a24]">
                  <td className="py-2 px-3 font-mono-num text-[#94a3b8]">{tx.id}</td>
                  <td className="py-2 px-3 text-white">
                    <div>{tx.fromWalletName}</div>
                    <div className="text-[10px] text-[#64748b]">{tx.fromBankName}</div>
                  </td>
                  <td className="py-2 px-3 text-white">
                    <div>{tx.toWalletName}</div>
                    <div className="text-[10px] text-[#64748b]">{tx.toBankName}</div>
                  </td>
                  <td className="py-2 px-3 text-right font-mono-num font-bold text-white">
                    ¥ {tx.amount.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}
                  </td>
                  <td className="py-2 px-3 text-[#cbd5e1]">{tx.purpose}</td>
                  <td className="py-2 px-3 text-center">
                    <ClearingStatusBadge status={tx.clearingStatus} />
                  </td>
                  <td className="py-2 px-3 text-right font-mono-num text-[#64748b]">{tx.timestamp}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
