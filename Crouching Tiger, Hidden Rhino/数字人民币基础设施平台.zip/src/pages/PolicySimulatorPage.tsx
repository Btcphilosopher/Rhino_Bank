import React, { useState } from 'react';
import { 
  Sliders, 
  Play, 
  TrendingUp, 
  Scale, 
  AlertTriangle, 
  ShieldAlert, 
  Coins, 
  Sparkles, 
  Flame, 
  CheckCircle2, 
  RefreshCcw, 
  Zap,
  Activity
} from 'lucide-react';
import { useSimulation } from '../simulation/SimulationContext';
import { MetricCard } from '../components/common/MetricCard';
import { Badge } from '../components/common/Badge';

export const PolicySimulatorPage: React.FC = () => {
  const { 
    stats, 
    injectBurstTransactions, 
    issueDigitalYuan, 
    executeClearingBatch 
  } = useSimulation();

  // Policy parameter levers
  const [rrrRate, setRrrRate] = useState<number>(100.0); // 100% reserve
  const [txBurstMultiplier, setTxBurstMultiplier] = useState<number>(1.5);
  const [targetM0Growth, setTargetM0Growth] = useState<number>(8.5);
  const [offlineQuotaCap, setOfflineQuotaCap] = useState<number>(2000);
  const [stressTestStatus, setStressTestStatus] = useState<string | null>(null);
  const [isRunningStress, setIsRunningStress] = useState<boolean>(false);

  const runStressScenario = (scenarioName: string, desc: string) => {
    setIsRunningStress(true);
    setStressTestStatus(`正在执行【${scenarioName}】高压脉冲推演...`);

    setTimeout(() => {
      injectBurstTransactions(6);
      setTimeout(() => {
        setIsRunningStress(false);
        setStressTestStatus(`【${scenarioName}】压力测试完成：央行数字人民币核心结算引擎表现出韧性，TPS 峰值平稳消化，无结算挂账。`);
      }, 1200);
    }, 800);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#12151d] border border-[#1e2433] p-5 rounded-lg flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-[#ef4444]" />
            <h2 className="text-lg font-bold text-white tracking-wide">
              货币政策仿真沙盘与极端压力测试 (Monetary Policy & Stress Testing)
            </h2>
          </div>
          <p className="text-xs text-[#94a3b8] mt-1">
            动态调整准备金约束、流通投放速率、离线参数配置，并对高并发峰值与跨行流动性挤兑进行宏观推演
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Badge variant="gold">宏观政策推演沙盘</Badge>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
        <MetricCard
          title="系统抗压容量上限"
          value="300,000 TPS"
          subLabel="当前实时负载"
          subValue="4.2% (极度充裕)"
          icon={Activity}
          highlight={true}
        />
        <MetricCard
          title="准备金刚性对冲率"
          value={`${rrrRate.toFixed(1)}%`}
          subLabel="防超发锁定"
          subValue="法定等额锚定"
          icon={Scale}
        />
        <MetricCard
          title="仿真时钟加速系数"
          value={`${txBurstMultiplier}x`}
          subLabel="宏观推演粒度"
          subValue="毫秒级离散事件"
          icon={TrendingUp}
        />
        <MetricCard
          title="全网系统韧性评分"
          value="99.98 分"
          subLabel="极端断网抗灾"
          subValue="具备独立脱机履约"
          icon={ShieldAlert}
        />
      </div>

      {/* Stress Testing Trigger Arena */}
      <div className="bg-[#12151d] border border-[#1e2433] rounded-lg p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Flame className="w-4 h-4 text-red-500" />
              极端金融风险场景压力测试矩阵 (Stress Testing Scenarios)
            </h3>
            <p className="text-xs text-[#94a3b8] mt-0.5">
              点击场景一键向仿真引擎注入高阶金融冲击与基础设施中断指令
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <button
            onClick={() => runStressScenario('特大自然灾害全国大面积断网', '模拟基站断电，海量市民使用双离线碰一碰法偿支付')}
            disabled={isRunningStress}
            className="p-4 rounded-lg bg-[#1a1418] border border-[#7f1d1d] hover:bg-[#2b161c] text-left transition-all space-y-2 group"
          >
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-red-400 group-hover:text-red-300">1. 全域断网双离线冲击</span>
              <Zap className="w-4 h-4 text-amber-400" />
            </div>
            <p className="text-[11px] text-[#94a3b8] leading-relaxed">
              测试脱机芯片在无通信环境下支撑 50,000 笔连续离线消费，验证事后回传防双花机制。
            </p>
          </button>

          <button
            onClick={() => runStressScenario('电商消费节瞬间超高并发脉冲', '模拟零点 150,000 TPS 峰值并发交易')}
            disabled={isRunningStress}
            className="p-4 rounded-lg bg-[#141b29] border border-[#1e3a5f] hover:bg-[#1a253a] text-left transition-all space-y-2 group"
          >
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-sky-400 group-hover:text-sky-300">2. 超高并发瞬时脉冲</span>
              <Activity className="w-4 h-4 text-sky-400" />
            </div>
            <p className="text-[11px] text-[#94a3b8] leading-relaxed">
              瞬间向央行核心记账系统灌入多笔并发流水，评估分布式多节点队列与延迟抖动。
            </p>
          </button>

          <button
            onClick={() => runStressScenario('某大型商业银行跨行流动性极度短缺', '模拟单一运营机构头寸枯竭与央行紧急注入')}
            disabled={isRunningStress}
            className="p-4 rounded-lg bg-[#241a12] border border-[#78350f] hover:bg-[#382618] text-left transition-all space-y-2 group"
          >
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-amber-400 group-hover:text-amber-300">3. 跨行流动性枯竭对冲</span>
              <Scale className="w-4 h-4 text-amber-400" />
            </div>
            <p className="text-[11px] text-[#94a3b8] leading-relaxed">
              测试跨行多边轧差在单一银行头寸不足时的自动排队、借贷撮合与央行救助机制。
            </p>
          </button>

          <button
            onClick={() => runStressScenario('大规模可编程资金精准定向滴灌', '财政一键向 100 万农户和中小微企业发放定向补贴')}
            disabled={isRunningStress}
            className="p-4 rounded-lg bg-[#102419] border border-[#14532d] hover:bg-[#163824] text-left transition-all space-y-2 group"
          >
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-emerald-400 group-hover:text-emerald-300">4. 百万级智能合约秒级分发</span>
              <Sparkles className="w-4 h-4 text-emerald-400" />
            </div>
            <p className="text-[11px] text-[#94a3b8] leading-relaxed">
              验证智能合约在千万级终端钱包中批量加载与带条件锁定核销的算力开销。
            </p>
          </button>
        </div>

        {/* Stress Result Banner */}
        {stressTestStatus && (
          <div className="p-4 bg-[#0a0c10] border border-[#222d42] rounded-lg text-xs flex items-center justify-between text-[#cbd5e1]">
            <div className="flex items-center gap-2">
              {isRunningStress ? (
                <RefreshCcw className="w-4 h-4 text-amber-400 animate-spin" />
              ) : (
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              )}
              <span className="font-semibold">{stressTestStatus}</span>
            </div>
            <span className="font-mono-num text-sky-400 text-[11px]">央行沙箱压力测试评估报告</span>
          </div>
        )}
      </div>

      {/* Parameter Control Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-[#12151d] border border-[#1e2433] rounded-lg p-5 space-y-4">
          <h3 className="text-sm font-semibold text-white flex items-center gap-2">
            <Sliders className="w-4 h-4 text-sky-400" />
            货币宏观调控杠杆调节
          </h3>

          <div className="space-y-4 text-xs">
            <div>
              <div className="flex justify-between text-[#94a3b8] mb-1">
                <span>准备金对冲刚性比率 (法定准备金率):</span>
                <span className="text-white font-mono-num font-bold">{rrrRate}% (法定 100% 准备金)</span>
              </div>
              <input
                type="range"
                min="90"
                max="100"
                step="0.5"
                value={rrrRate}
                onChange={(e) => setRrrRate(parseFloat(e.target.value))}
                className="w-full accent-[#ef4444]"
              />
            </div>

            <div>
              <div className="flex justify-between text-[#94a3b8] mb-1">
                <span>全网交易脉冲生成速率 (倍率):</span>
                <span className="text-white font-mono-num font-bold">{txBurstMultiplier}x 速率</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="5.0"
                step="0.5"
                value={txBurstMultiplier}
                onChange={(e) => setTxBurstMultiplier(parseFloat(e.target.value))}
                className="w-full accent-[#ef4444]"
              />
            </div>

            <div>
              <div className="flex justify-between text-[#94a3b8] mb-1">
                <span>单卡离线额度上限标准:</span>
                <span className="text-white font-mono-num font-bold">¥ {offlineQuotaCap} 元</span>
              </div>
              <input
                type="range"
                min="500"
                max="5000"
                step="500"
                value={offlineQuotaCap}
                onChange={(e) => setOfflineQuotaCap(parseInt(e.target.value))}
                className="w-full accent-[#ef4444]"
              />
            </div>
          </div>
        </div>

        <div className="bg-[#12151d] border border-[#1e2433] rounded-lg p-5 space-y-3 text-xs">
          <h3 className="text-sm font-semibold text-white flex items-center gap-2">
            <Scale className="w-4 h-4 text-emerald-400" />
            宏观货币政策启示与设计原则
          </h3>
          <p className="text-[#94a3b8] leading-relaxed">
            数字人民币作为央行法偿法定货币，其核心优势在于：
          </p>
          <ul className="space-y-2 text-[11px] text-[#cbd5e1] list-disc list-inside">
            <li><strong>零信用风险：</strong>由国家主权信用兜底，免除商业支付机构破产清算风险。</li>
            <li><strong>无息属性与反脱媒：</strong>定位 M0 不计付利息，防范商业银行存款大规模搬家。</li>
            <li><strong>支付即结算：</strong>零售端与批发端均达成终局性确权，缩短社会资金融通链路。</li>
          </ul>
        </div>
      </div>
    </div>
  );
};
