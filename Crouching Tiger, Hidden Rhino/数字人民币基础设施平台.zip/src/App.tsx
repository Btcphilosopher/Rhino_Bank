import React, { useState } from 'react';
import { SimulationProvider } from './simulation/SimulationContext';
import { Header } from './components/layout/Header';
import { Sidebar, NavTabId } from './components/layout/Sidebar';
import { SimulationBanner } from './components/layout/SimulationBanner';

// Page Components
import { OverviewPage } from './pages/OverviewPage';
import { IssuancePage } from './pages/IssuancePage';
import { CirculationPage } from './pages/CirculationPage';
import { WalletManagerPage } from './pages/WalletManagerPage';
import { InstitutionPage } from './pages/InstitutionPage';
import { ClearingPage } from './pages/ClearingPage';
import { InterbankPage } from './pages/InterbankPage';
import { OfflinePaymentPage } from './pages/OfflinePaymentPage';
import { SmartContractPage } from './pages/SmartContractPage';
import { RegulatoryPage } from './pages/RegulatoryPage';
import { RiskControlPage } from './pages/RiskControlPage';
import { PolicySimulatorPage } from './pages/PolicySimulatorPage';
import { DataCenterPage } from './pages/DataCenterPage';
import { OperationsPage } from './pages/OperationsPage';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTabId>('overview');

  const renderActivePage = () => {
    switch (activeTab) {
      case 'overview':
        return <OverviewPage onNavigate={(tab) => setActiveTab(tab as NavTabId)} />;
      case 'issuance':
        return <IssuancePage />;
      case 'circulation':
        return <CirculationPage />;
      case 'wallet':
        return <WalletManagerPage />;
      case 'institution':
        return <InstitutionPage />;
      case 'clearing':
        return <ClearingPage />;
      case 'interbank':
        return <InterbankPage />;
      case 'offline':
        return <OfflinePaymentPage />;
      case 'programmable':
        return <SmartContractPage />;
      case 'regulatory':
        return <RegulatoryPage />;
      case 'risk':
        return <RiskControlPage />;
      case 'policy':
        return <PolicySimulatorPage />;
      case 'datacenter':
        return <DataCenterPage />;
      case 'system':
        return <OperationsPage />;
      default:
        return <OverviewPage onNavigate={(tab) => setActiveTab(tab as NavTabId)} />;
    }
  };

  return (
    <SimulationProvider>
      <div className="flex flex-col h-screen w-screen bg-[#07080c] text-[#e2e8f0] font-sans antialiased overflow-hidden">
        {/* Top Institutional Header */}
        <Header />

        {/* Global Simulation Control Ribbon */}
        <SimulationBanner />

        {/* Main Content Area */}
        <div className="flex flex-1 overflow-hidden">
          {/* 14-Item Institutional Sidebar */}
          <Sidebar activeTab={activeTab} onSelectTab={setActiveTab} />

          {/* Dynamic Page Stage */}
          <main className="flex-1 overflow-y-auto p-6 bg-[#07080c]">
            <div className="max-w-[1600px] mx-auto animate-in fade-in duration-200">
              {renderActivePage()}
            </div>
          </main>
        </div>
      </div>
    </SimulationProvider>
  );
}
