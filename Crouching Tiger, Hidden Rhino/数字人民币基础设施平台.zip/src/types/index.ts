// CBDC Infrastructure Platform Type Definitions
// 数字人民币中央银行数字货币平台 数据类型定义

export type SystemStatus = 'NORMAL' | 'SETTLING' | 'HIGH_LOAD' | 'MAINTENANCE';

export type WalletType = 'PERSONAL' | 'ENTERPRISE' | 'MERCHANT' | 'INSTITUTION' | 'BANK' | 'SPECIAL';

export type KycLevel = 'LEVEL_1' | 'LEVEL_2' | 'LEVEL_3' | 'LEVEL_4';

export type WalletStatus = 'ACTIVE' | 'FROZEN' | 'RESTRICTED' | 'CANCELLED';

export type TransactionType = 
  | 'QR_CODE'       // 扫码支付
  | 'NFC'           // NFC 碰一碰
  | 'TRANSFER'      // 钱包转账
  | 'MERCHANT_PAY'  // 商户消费
  | 'API_PAY'       // API 网关支付
  | 'OFFLINE'       // 单离线支付
  | 'DUAL_OFFLINE'  // 双离线支付
  | 'ISSUANCE'      // 央行发行
  | 'REDEMPTION'    // 商业银行回笼
  | 'PROGRAMMABLE'  // 可编程智能合约支付
  | 'INTERBANK';    // 跨行清算调拨

export type TransactionStatus = 
  | 'PENDING'       // 待处理
  | 'PROCESSING'    // 处理中
  | 'COMPLETED'     // 已完成
  | 'SETTLED'       // 已清算
  | 'REJECTED'      // 已拒绝
  | 'INTERCEPTED'   // 风险拦截
  | 'ANOMALY';      // 异常挂起

export type ClearingStatus = 'UNSETTLED' | 'IN_QUEUE' | 'SETTLED' | 'FAILED';

export interface Wallet {
  id: string; // 钱包编号 e.g. "ECNY-2026-8839-0192"
  name: string; // 钱包主体名称
  type: WalletType;
  bankId: string; // 运营机构代码
  bankName: string; // 运营机构名称
  status: WalletStatus;
  balance: number; // 当前余额 (元)
  availableBalance: number; // 可用余额
  frozenBalance: number; // 冻结金额
  pendingSettlement: number; // 待结算金额
  totalInflow: number; // 累计收入
  totalOutflow: number; // 累计支出
  txCount: number; // 交易总笔数
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH';
  kycLevel: KycLevel;
  singleLimit: number; // 单笔限额
  dailyLimit: number; // 日累计限额
  lastTxTime: string;
  createTime: string;
  hardwareChipId?: string; // 硬件SE/TEE安全芯片ID (用于离线支付)
  offlineQuota: number; // 离线可用余额
}

export interface Transaction {
  id: string; // 流水编号 e.g. "TX202609190018829"
  batchId?: string; // 清算/发行批次号
  type: TransactionType;
  fromWalletId: string;
  fromWalletName: string;
  fromBankId: string;
  fromBankName: string;
  toWalletId: string;
  toWalletName: string;
  toBankId: string;
  toBankName: string;
  amount: number;
  purpose: string; // 交易用途
  status: TransactionStatus;
  clearingStatus: ClearingStatus;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH';
  timestamp: string;
  isOffline?: boolean;
  offlineSyncTime?: string;
  notes?: string;
  programmableRuleId?: string;
}

export interface BankNode {
  id: string; // e.g. "ICBC", "CCB", "BOC", "ABC", "BOCOM", "PSBC", "CMB", "MYBANK", "WEBANK"
  name: string; // e.g. "中国工商银行"
  shortName: string; // e.g. "工行"
  code: string; // e.g. "102"
  digitalYuanInventory: number; // 数字人民币库存头寸
  depositReserve: number; // 央行准备金存款
  walletCount: number; // 接入钱包数
  todayTxCount: number; // 今日交易笔数
  todayTxVolume: number; // 今日交易总额
  settlementPosition: number; // 清算头寸 (净头寸)
  pendingSettlement: number; // 待结算资金
  riskAlertCount: number; // 风险事件数
  apiStatus: 'HEALTHY' | 'DEGRADED' | 'UNAVAILABLE';
  latencyMs: number;
  ipAddress: string;
}

export interface IssuanceBatch {
  id: string; // 批次号 e.g. "ISSUE-20260919-01"
  type: 'ISSUANCE' | 'REDEMPTION' | 'CIRCULATION_ADJUST';
  targetBankId: string;
  targetBankName: string;
  amount: number;
  preBalance: number;
  postBalance: number;
  fundSource: string; // 资金来源，例如 "商业银行准备金账户扣款" 或 "中央银行法定货币资产发行"
  purpose: string;
  operator: string;
  status: 'AUDITED' | 'EXECUTED' | 'SETTLED';
  timestamp: string;
  auditHash: string;
}

export interface ProgrammableRule {
  id: string; // e.g. "PR-2026-SUB-01"
  title: string;
  category: 'SUBSIDY' | 'SALARY' | 'SUPPLY_CHAIN' | 'GREEN_CREDIT' | 'PROJECT_FUNDS';
  sourceWalletId: string;
  sourceWalletName: string;
  targetCriteria: string;
  totalAllocated: number;
  executedAmount: number;
  conditionDescription: string;
  validUntil: string;
  status: 'ACTIVE' | 'PAUSED' | 'COMPLETED' | 'EXPIRED';
  triggerType: 'TIME_SCHEDULE' | 'EVENT_TRIGGER' | 'GEO_FENCE' | 'MERCHANT_TAG';
  executionCount: number;
  lastExecutedTime?: string;
}

export interface RiskAlert {
  id: string; // e.g. "RISK-2026-8821"
  ruleId: string; // e.g. "AML-04-HIGH_FREQ"
  ruleName: string;
  category: 'AML' | 'SUSPICIOUS_AMOUNT' | 'CROSS_REGION_BURST' | 'OFFLINE_ABUSE' | 'LIMIT_EXCEEDED';
  severity: 'WARNING' | 'ALERT' | 'CRITICAL';
  txId?: string;
  walletId: string;
  walletName: string;
  triggerReason: string;
  status: 'PENDING' | 'INVESTIGATING' | 'DISMISSED' | 'FROZEN';
  timestamp: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  operatorOrg: string;
  operatorUser: string;
  actionType: string;
  targetResource: string;
  result: 'SUCCESS' | 'FAILED' | 'INTERCEPTED';
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH';
  ipAddress: string;
  detail: string;
}

export interface RegionMetric {
  id: string;
  name: string; // 华北, 东北, 华东, 华中, 华南, 西南, 西北
  provinces: string[];
  txCount: number;
  txVolume: number; // 亿元
  walletCount: number; // 万户
  merchantCount: number; // 万户
  clearingVolume: number; // 亿元
  growthRate: number; // %
  status: 'NORMAL' | 'HIGH_LOAD';
}

export interface SystemServiceMetric {
  id: string;
  name: string;
  description: string;
  status: 'RUNNING' | 'DEGRADED' | 'STANDBY';
  latencyMs: number;
  qps: number;
  errorRate: number; // %
  uptime: string;
  lastHeartbeat: string;
}

export interface MonetaryPolicyParams {
  moneySupplyTarget: number; // 目标发行总量 (亿元)
  reserveRatio: number; // 准备金率 (%)
  digitalVelocity: number; // 货币流通速度指数 (V)
  interestRateBenchmark: number; // 基准利率 (%)
  liquidityBuffer: number; // 商业银行流动性缓冲系数
  cashSubstitutionRatio: number; // M0 替代率 (%)
}
