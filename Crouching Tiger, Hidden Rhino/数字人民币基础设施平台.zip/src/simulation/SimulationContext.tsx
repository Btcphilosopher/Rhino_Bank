import React, { createContext, useContext, useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { 
  Wallet, 
  BankNode, 
  Transaction, 
  IssuanceBatch, 
  ProgrammableRule, 
  RiskAlert, 
  AuditLog, 
  RegionMetric, 
  SystemServiceMetric, 
  MonetaryPolicyParams, 
  SystemStatus,
  TransactionType,
  KycLevel
} from '../types';
import { 
  INITIAL_BANKS, 
  INITIAL_WALLETS, 
  INITIAL_TRANSACTIONS, 
  INITIAL_ISSUANCE_BATCHES, 
  INITIAL_PROGRAMMABLE_RULES, 
  INITIAL_RISK_ALERTS, 
  INITIAL_AUDIT_LOGS, 
  INITIAL_REGIONS, 
  INITIAL_SERVICES, 
  INITIAL_MONETARY_POLICY 
} from '../data/seedData';

interface SimulationContextType {
  // States
  isRunning: boolean;
  speed: 1 | 10 | 100;
  systemStatus: SystemStatus;
  simulatedTime: string;
  wallets: Wallet[];
  banks: BankNode[];
  transactions: Transaction[];
  issuanceBatches: IssuanceBatch[];
  programmableRules: ProgrammableRule[];
  riskAlerts: RiskAlert[];
  auditLogs: AuditLog[];
  regions: RegionMetric[];
  services: SystemServiceMetric[];
  policyParams: MonetaryPolicyParams;
  
  // Computed Statistics
  stats: {
    totalCirculation: number;
    totalWalletsCount: number;
    activeWalletsCount: number;
    todayTxCount: number;
    todayTxVolume: number;
    realTimeTps: number;
    todayClearingVolume: number;
    merchantCount: number;
    bankCount: number;
    offlineTxCount: number;
    crossBankTxCount: number;
    anomalyTxCount: number;
  };

  // Actions
  toggleSimulation: () => void;
  setSpeed: (speed: 1 | 10 | 100) => void;
  resetSimulation: () => void;
  
  // Monetary actions
  issueDigitalYuan: (params: {
    targetBankId: string;
    amount: number;
    fundSource: string;
    purpose: string;
  }) => { success: boolean; message: string; batch?: IssuanceBatch };
  
  redeemDigitalYuan: (params: {
    targetBankId: string;
    amount: number;
    purpose: string;
  }) => { success: boolean; message: string; batch?: IssuanceBatch };
  
  transferFunds: (params: {
    fromWalletId: string;
    toWalletId: string;
    amount: number;
    type: TransactionType;
    purpose: string;
    isOffline?: boolean;
    programmableRuleId?: string;
  }) => { success: boolean; message: string; tx?: Transaction };
  
  executeClearingBatch: () => { settledCount: number; totalAmount: number };
  
  triggerOfflineSync: (walletId: string) => { success: boolean; syncedCount: number };
  
  freezeWallet: (walletId: string, reason: string) => void;
  unfreezeWallet: (walletId: string) => void;
  
  createWallet: (params: {
    name: string;
    type: Wallet['type'];
    bankId: string;
    kycLevel: KycLevel;
    initialBalance: number;
  }) => Wallet;

  resolveRiskAlert: (alertId: string, action: 'DISMISS' | 'FREEZE' | 'RESOLVE') => void;
  executeProgrammableRule: (ruleId: string) => { success: boolean; executedCount: number; amount: number };
  updatePolicyParams: (params: Partial<MonetaryPolicyParams>) => void;
  injectBurstTransactions: (count?: number) => void;
}

const SimulationContext = createContext<SimulationContextType | null>(null);

export const SimulationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isRunning, setIsRunning] = useState<boolean>(true);
  const [speed, setSpeed] = useState<1 | 10 | 100>(1);
  const [systemStatus] = useState<SystemStatus>('NORMAL');
  const [currentTime, setCurrentTime] = useState<Date>(new Date(2026, 8, 19, 10, 35, 0));
  
  // Core Entities
  const [wallets, setWallets] = useState<Wallet[]>(INITIAL_WALLETS);
  const [banks, setBanks] = useState<BankNode[]>(INITIAL_BANKS);
  const [transactions, setTransactions] = useState<Transaction[]>(INITIAL_TRANSACTIONS);
  const [issuanceBatches, setIssuanceBatches] = useState<IssuanceBatch[]>(INITIAL_ISSUANCE_BATCHES);
  const [programmableRules, setProgrammableRules] = useState<ProgrammableRule[]>(INITIAL_PROGRAMMABLE_RULES);
  const [riskAlerts, setRiskAlerts] = useState<RiskAlert[]>(INITIAL_RISK_ALERTS);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(INITIAL_AUDIT_LOGS);
  const [regions, setRegions] = useState<RegionMetric[]>(INITIAL_REGIONS);
  const [services, setServices] = useState<SystemServiceMetric[]>(INITIAL_SERVICES);
  const [policyParams, setPolicyParams] = useState<MonetaryPolicyParams>(INITIAL_MONETARY_POLICY);
  
  // Real-time instantaneous TPS simulation
  const [realTimeTps, setRealTimeTps] = useState<number>(4280);

  // Format simulated time string
  const simulatedTime = useMemo(() => {
    const pad = (n: number) => n.toString().padStart(2, '0');
    const y = currentTime.getFullYear();
    const m = pad(currentTime.getMonth() + 1);
    const d = pad(currentTime.getDate());
    const h = pad(currentTime.getHours());
    const min = pad(currentTime.getMinutes());
    const s = pad(currentTime.getSeconds());
    return `${y}-${m}-${d} ${h}:${min}:${s}`;
  }, [currentTime]);

  // Helper for generating unique sequential IDs
  const generateTxId = () => {
    const timeStr = simulatedTime.replace(/[- :]/g, '');
    const rand = Math.floor(1000 + Math.random() * 9000);
    return `TX${timeStr}${rand}`;
  };

  const generateAuditId = () => {
    const dateStr = simulatedTime.slice(0, 10).replace(/-/g, '');
    const rand = Math.floor(100 + Math.random() * 900);
    return `AUD-${dateStr}-${rand}`;
  };

  // Add immutable-looking audit record
  const logAudit = useCallback((entry: Omit<AuditLog, 'id' | 'timestamp'>) => {
    const newLog: AuditLog = {
      id: generateAuditId(),
      timestamp: simulatedTime,
      ...entry
    };
    setAuditLogs(prev => [newLog, ...prev.slice(0, 99)]); // Keep recent 100
  }, [simulatedTime]);

  // Compute top-level summary metrics
  const stats = useMemo(() => {
    const totalCirculation = banks.reduce((acc, b) => acc + b.digitalYuanInventory, 0) +
      wallets.reduce((acc, w) => acc + w.balance, 0);

    const totalWalletsCount = banks.reduce((acc, b) => acc + b.walletCount, 0);
    const activeWalletsCount = Math.floor(totalWalletsCount * 0.724);

    const todayTxCount = banks.reduce((acc, b) => acc + b.todayTxCount, 0);
    const todayTxVolume = banks.reduce((acc, b) => acc + b.todayTxVolume, 0);

    const todayClearingVolume = transactions
      .filter(t => t.clearingStatus === 'SETTLED')
      .reduce((acc, t) => acc + t.amount, 0) + 12850000000.00;

    const merchantCount = regions.reduce((acc, r) => acc + r.merchantCount * 10000, 0);
    const bankCount = banks.length;

    const offlineTxCount = transactions.filter(t => t.isOffline || t.type === 'OFFLINE' || t.type === 'DUAL_OFFLINE').length + 8490;
    const crossBankTxCount = transactions.filter(t => t.fromBankId !== t.toBankId).length + 382000;
    const anomalyTxCount = riskAlerts.filter(r => r.status === 'PENDING' || r.status === 'INVESTIGATING').length;

    return {
      totalCirculation,
      totalWalletsCount,
      activeWalletsCount,
      todayTxCount,
      todayTxVolume,
      realTimeTps,
      todayClearingVolume,
      merchantCount,
      bankCount,
      offlineTxCount,
      crossBankTxCount,
      anomalyTxCount
    };
  }, [banks, wallets, transactions, regions, riskAlerts, realTimeTps]);

  // Execute issuance of Digital Yuan (Central Bank -> Commercial Bank)
  const issueDigitalYuan = useCallback(({
    targetBankId,
    amount,
    fundSource,
    purpose
  }: {
    targetBankId: string;
    amount: number;
    fundSource: string;
    purpose: string;
  }) => {
    const bank = banks.find(b => b.id === targetBankId);
    if (!bank) {
      return { success: false, message: '未找到目标商业银行机构' };
    }

    if (amount <= 0) {
      return { success: false, message: '发行金额必须大于零' };
    }

    // Check if bank has enough reserve
    if (fundSource.includes('准备金') && bank.depositReserve < amount) {
      return { success: false, message: '商业银行存入央行准备金不足以完成等额兑换发行' };
    }

    const preBalance = bank.digitalYuanInventory;
    const postBalance = preBalance + amount;

    const batchId = `ISSUE-${simulatedTime.slice(0, 10).replace(/-/g, '')}-${String(issuanceBatches.length + 1).padStart(2, '0')}`;
    const newBatch: IssuanceBatch = {
      id: batchId,
      type: 'ISSUANCE',
      targetBankId: bank.id,
      targetBankName: bank.name,
      amount,
      preBalance,
      postBalance,
      fundSource,
      purpose,
      operator: '中国人民银行数字货币发行司 (操作员 8012)',
      status: 'SETTLED',
      timestamp: simulatedTime,
      auditHash: `0x${Math.random().toString(16).substring(2, 10)}${Math.random().toString(16).substring(2, 10)}`
    };

    // Mutate bank inventory & reserve
    setBanks(prev => prev.map(b => {
      if (b.id === bank.id) {
        return {
          ...b,
          digitalYuanInventory: postBalance,
          depositReserve: fundSource.includes('准备金') ? b.depositReserve - amount : b.depositReserve
        };
      }
      return b;
    }));

    setIssuanceBatches(prev => [newBatch, ...prev]);

    logAudit({
      operatorOrg: '中国人民银行数字货币研究所',
      operatorUser: 'sys_issuer_pboc',
      actionType: '法定数字货币定向核准发行',
      targetResource: `${bank.name} (${bank.code})`,
      result: 'SUCCESS',
      riskLevel: 'LOW',
      ipAddress: '10.0.1.18',
      detail: `核准向 ${bank.name} 发行数字人民币 ¥${amount.toLocaleString()}，批次号 ${batchId}，已完成 1:1 准备金对冲扣减。`
    });

    return { success: true, message: `成功向 ${bank.name} 发行 ¥${amount.toLocaleString('zh-CN', { minimumFractionDigits: 2 })} 数字人民币`, batch: newBatch };
  }, [banks, issuanceBatches.length, logAudit, simulatedTime]);

  // Execute redemption of Digital Yuan (Commercial Bank -> Central Bank Vault)
  const redeemDigitalYuan = useCallback(({
    targetBankId,
    amount,
    purpose
  }: {
    targetBankId: string;
    amount: number;
    purpose: string;
  }) => {
    const bank = banks.find(b => b.id === targetBankId);
    if (!bank) {
      return { success: false, message: '未找到目标商业银行机构' };
    }

    if (amount <= 0) {
      return { success: false, message: '回笼金额必须大于零' };
    }

    if (bank.digitalYuanInventory < amount) {
      return { success: false, message: '该商业银行数字人民币库存头寸不足以执行回笼' };
    }

    const preBalance = bank.digitalYuanInventory;
    const postBalance = preBalance - amount;

    const batchId = `REDEMPTION-${simulatedTime.slice(0, 10).replace(/-/g, '')}-${String(issuanceBatches.length + 1).padStart(2, '0')}`;
    const newBatch: IssuanceBatch = {
      id: batchId,
      type: 'REDEMPTION',
      targetBankId: bank.id,
      targetBankName: bank.name,
      amount,
      preBalance,
      postBalance,
      fundSource: '商业银行数字人民币头寸注销并返还准备金',
      purpose,
      operator: '中国人民银行数字货币发行司 (操作员 8012)',
      status: 'SETTLED',
      timestamp: simulatedTime,
      auditHash: `0x${Math.random().toString(16).substring(2, 10)}${Math.random().toString(16).substring(2, 10)}`
    };

    setBanks(prev => prev.map(b => {
      if (b.id === bank.id) {
        return {
          ...b,
          digitalYuanInventory: postBalance,
          depositReserve: b.depositReserve + amount
        };
      }
      return b;
    }));

    setIssuanceBatches(prev => [newBatch, ...prev]);

    logAudit({
      operatorOrg: '中国人民银行数字货币研究所',
      operatorUser: 'sys_issuer_pboc',
      actionType: '法定数字货币回笼销毁',
      targetResource: `${bank.name} (${bank.code})`,
      result: 'SUCCESS',
      riskLevel: 'LOW',
      ipAddress: '10.0.1.18',
      detail: `核准回笼销毁 ${bank.name} 头寸 ¥${amount.toLocaleString()}，准备金已全额返还入账。`
    });

    return { success: true, message: `成功执行 ${bank.name} ¥${amount.toLocaleString('zh-CN', { minimumFractionDigits: 2 })} 头寸回笼`, batch: newBatch };
  }, [banks, issuanceBatches.length, logAudit, simulatedTime]);

  // Execute transfer between wallets
  const transferFunds = useCallback(({
    fromWalletId,
    toWalletId,
    amount,
    type,
    purpose,
    isOffline = false,
    programmableRuleId
  }: {
    fromWalletId: string;
    toWalletId: string;
    amount: number;
    type: TransactionType;
    purpose: string;
    isOffline?: boolean;
    programmableRuleId?: string;
  }) => {
    if (amount <= 0) {
      return { success: false, message: '交易金额必须大于零' };
    }

    const sender = wallets.find(w => w.id === fromWalletId);
    const receiver = wallets.find(w => w.id === toWalletId);

    if (!sender) {
      return { success: false, message: '付款方钱包不存在' };
    }
    if (!receiver) {
      return { success: false, message: '收款方钱包不存在' };
    }

    // Check sender status
    if (sender.status === 'FROZEN') {
      const txId = generateTxId();
      const failTx: Transaction = {
        id: txId,
        type,
        fromWalletId: sender.id,
        fromWalletName: sender.name,
        fromBankId: sender.bankId,
        fromBankName: sender.bankName,
        toWalletId: receiver.id,
        toWalletName: receiver.name,
        toBankId: receiver.bankId,
        toBankName: receiver.bankName,
        amount,
        purpose,
        status: 'REJECTED',
        clearingStatus: 'FAILED',
        riskLevel: 'HIGH',
        timestamp: simulatedTime,
        notes: '付款方钱包已被司法/风控冻结'
      };
      setTransactions(prev => [failTx, ...prev]);
      return { success: false, message: '交易失败：付款方钱包已被冻结止付', tx: failTx };
    }

    if (isOffline) {
      if (sender.offlineQuota < amount) {
        return { success: false, message: `离线可用额度不足 (当前离线额度: ¥${sender.offlineQuota.toFixed(2)})` };
      }
    } else {
      if (sender.availableBalance < amount) {
        return { success: false, message: `钱包可用余额不足 (当前余额: ¥${sender.availableBalance.toFixed(2)})` };
      }
    }

    // Check single limit
    if (amount > sender.singleLimit) {
      const txId = generateTxId();
      const interceptedTx: Transaction = {
        id: txId,
        type,
        fromWalletId: sender.id,
        fromWalletName: sender.name,
        fromBankId: sender.bankId,
        fromBankName: sender.bankName,
        toWalletId: receiver.id,
        toWalletName: receiver.name,
        toBankId: receiver.bankId,
        toBankName: receiver.bankName,
        amount,
        purpose,
        status: 'INTERCEPTED',
        clearingStatus: 'FAILED',
        riskLevel: 'HIGH',
        timestamp: simulatedTime,
        notes: `超过单笔限额 ¥${sender.singleLimit.toLocaleString()}`
      };
      setTransactions(prev => [interceptedTx, ...prev]);

      // Create risk alert
      const newAlert: RiskAlert = {
        id: `RISK-${simulatedTime.slice(0, 10).replace(/-/g, '')}-${Math.floor(1000 + Math.random() * 9000)}`,
        ruleId: 'LIMIT-01-SINGLE_EXCEEDED',
        ruleName: '钱包单笔交易限额越限拦截',
        category: 'LIMIT_EXCEEDED',
        severity: 'WARNING',
        txId,
        walletId: sender.id,
        walletName: sender.name,
        triggerReason: `单笔支付 ¥${amount.toLocaleString()} 超过钱包级别限额 ¥${sender.singleLimit.toLocaleString()}`,
        status: 'PENDING',
        timestamp: simulatedTime
      };
      setRiskAlerts(prev => [newAlert, ...prev]);

      return { success: false, message: `交易被风控拦截：超出单笔限额 ¥${sender.singleLimit.toLocaleString()}`, tx: interceptedTx };
    }

    // Determine status & clearing
    const isInterbank = sender.bankId !== receiver.bankId;
    const txId = generateTxId();
    const txStatus = 'SETTLED';
    const clearingStatus = isInterbank ? (isOffline ? 'IN_QUEUE' : 'SETTLED') : 'SETTLED';

    const newTx: Transaction = {
      id: txId,
      type,
      fromWalletId: sender.id,
      fromWalletName: sender.name,
      fromBankId: sender.bankId,
      fromBankName: sender.bankName,
      toWalletId: receiver.id,
      toWalletName: receiver.name,
      toBankId: receiver.bankId,
      toBankName: receiver.bankName,
      amount,
      purpose,
      status: txStatus,
      clearingStatus,
      riskLevel: 'LOW',
      timestamp: simulatedTime,
      isOffline,
      offlineSyncTime: isOffline ? simulatedTime : undefined,
      programmableRuleId
    };

    // Mutate wallets
    setWallets(prev => prev.map(w => {
      if (w.id === sender.id) {
        return {
          ...w,
          balance: w.balance - amount,
          availableBalance: isOffline ? w.availableBalance : w.availableBalance - amount,
          offlineQuota: isOffline ? w.offlineQuota - amount : w.offlineQuota,
          totalOutflow: w.totalOutflow + amount,
          txCount: w.txCount + 1,
          lastTxTime: simulatedTime
        };
      }
      if (w.id === receiver.id) {
        return {
          ...w,
          balance: w.balance + amount,
          availableBalance: w.availableBalance + amount,
          offlineQuota: isOffline ? w.offlineQuota + amount : w.offlineQuota,
          totalInflow: w.totalInflow + amount,
          txCount: w.txCount + 1,
          lastTxTime: simulatedTime
        };
      }
      return w;
    }));

    // Mutate Banks metrics
    setBanks(prev => prev.map(b => {
      let updated = { ...b };
      if (b.id === sender.bankId) {
        updated.todayTxCount += 1;
        updated.todayTxVolume += amount;
        if (isInterbank) {
          updated.settlementPosition -= amount;
        }
      }
      if (b.id === receiver.bankId && isInterbank) {
        updated.settlementPosition += amount;
      }
      return updated;
    }));

    setTransactions(prev => [newTx, ...prev]);

    // Update programmable rule stats if applicable
    if (programmableRuleId) {
      setProgrammableRules(prev => prev.map(r => {
        if (r.id === programmableRuleId) {
          return {
            ...r,
            executedAmount: r.executedAmount + amount,
            executionCount: r.executionCount + 1,
            lastExecutedTime: simulatedTime
          };
        }
        return r;
      }));
    }

    return { success: true, message: `交易已完成，流水号 ${txId}`, tx: newTx };
  }, [generateTxId, simulatedTime, wallets]);

  // Execute Clearing batch
  const executeClearingBatch = useCallback(() => {
    let settledCount = 0;
    let totalAmount = 0;

    setTransactions(prev => prev.map(tx => {
      if (tx.clearingStatus === 'IN_QUEUE' || (tx.status === 'COMPLETED' && tx.clearingStatus === 'UNSETTLED')) {
        settledCount += 1;
        totalAmount += tx.amount;
        return {
          ...tx,
          status: 'SETTLED',
          clearingStatus: 'SETTLED'
        };
      }
      return tx;
    }));

    logAudit({
      operatorOrg: '中央清算总中心 (CNAPS-CBDC)',
      operatorUser: 'clearing_cron_scheduler',
      actionType: '全网跨机构周期性批量净额清算',
      targetResource: '清算队列结算池',
      result: 'SUCCESS',
      riskLevel: 'LOW',
      ipAddress: '10.0.2.10',
      detail: `完成清算队列处理，共轧差结算 ${settledCount || 12} 笔跨行挂起交易，调拨金额 ¥${(totalAmount || 3420000).toLocaleString()} 元。`
    });

    return { settledCount: settledCount || 12, totalAmount: totalAmount || 3420000 };
  }, [logAudit]);

  // Offline sync trigger
  const triggerOfflineSync = useCallback((walletId: string) => {
    const wallet = wallets.find(w => w.id === walletId);
    if (!wallet) return { success: false, syncedCount: 0 };

    // Settle all offline transactions from this wallet
    setTransactions(prev => prev.map(tx => {
      if ((tx.fromWalletId === walletId || tx.toWalletId === walletId) && tx.isOffline && tx.clearingStatus === 'IN_QUEUE') {
        return {
          ...tx,
          status: 'SETTLED',
          clearingStatus: 'SETTLED',
          offlineSyncTime: simulatedTime
        };
      }
      return tx;
    }));

    // Reset offline quota to 2000 standard
    setWallets(prev => prev.map(w => {
      if (w.id === walletId) {
        return {
          ...w,
          offlineQuota: Math.min(w.balance, 2000.00)
        };
      }
      return w;
    }));

    logAudit({
      operatorOrg: '国家CBDC离线安全认证中心',
      operatorUser: 'se_hardware_gateway',
      actionType: '硬件SE安全芯片断点同步与防重放验签',
      targetResource: walletId,
      result: 'SUCCESS',
      riskLevel: 'LOW',
      ipAddress: '10.0.9.14',
      detail: `钱包 ${wallet.name} 安全芯片 (${wallet.hardwareChipId || 'SE-CHIP'}) 联网同步成功，离线凭证已验签上账。`
    });

    return { success: true, syncedCount: 2 };
  }, [logAudit, simulatedTime, wallets]);

  // Freeze/Unfreeze wallet
  const freezeWallet = useCallback((walletId: string, reason: string) => {
    setWallets(prev => prev.map(w => {
      if (w.id === walletId) {
        return {
          ...w,
          status: 'FROZEN',
          frozenBalance: w.balance,
          availableBalance: 0
        };
      }
      return w;
    }));

    logAudit({
      operatorOrg: '全国反洗钱监管与司法协助系统',
      operatorUser: 'pbc_investigator_02',
      actionType: '司法/监管账户紧急全网止付冻结',
      targetResource: walletId,
      result: 'SUCCESS',
      riskLevel: 'HIGH',
      ipAddress: '10.0.8.10',
      detail: `对钱包 ${walletId} 实施全网中心化止付冻结。原因：${reason}`
    });
  }, [logAudit]);

  const unfreezeWallet = useCallback((walletId: string) => {
    setWallets(prev => prev.map(w => {
      if (w.id === walletId) {
        return {
          ...w,
          status: 'ACTIVE',
          frozenBalance: 0,
          availableBalance: w.balance
        };
      }
      return w;
    }));

    logAudit({
      operatorOrg: '全国反洗钱监管与司法协助系统',
      operatorUser: 'pbc_investigator_02',
      actionType: '账户止付解除与合规恢复',
      targetResource: walletId,
      result: 'SUCCESS',
      riskLevel: 'LOW',
      ipAddress: '10.0.8.10',
      detail: `对钱包 ${walletId} 解除止付冻结状态，恢复一类账户全功能运营。`
    });
  }, [logAudit]);

  // Create Wallet
  const createWallet = useCallback(({
    name,
    type,
    bankId,
    kycLevel,
    initialBalance
  }: {
    name: string;
    type: Wallet['type'];
    bankId: string;
    kycLevel: KycLevel;
    initialBalance: number;
  }) => {
    const bank = banks.find(b => b.id === bankId) || banks[0];
    const limits = {
      LEVEL_1: { single: 500000, daily: 1000000 },
      LEVEL_2: { single: 50000, daily: 100000 },
      LEVEL_3: { single: 5000, daily: 10000 },
      LEVEL_4: { single: 1000, daily: 2000 },
    }[kycLevel];

    const randNum = Math.floor(1000 + Math.random() * 9000);
    const newId = `ECNY-2026-${randNum}-${Math.floor(1000 + Math.random() * 9000)}`;

    const newWallet: Wallet = {
      id: newId,
      name,
      type,
      bankId: bank.id,
      bankName: bank.name,
      status: 'ACTIVE',
      balance: initialBalance,
      availableBalance: initialBalance,
      frozenBalance: 0,
      pendingSettlement: 0,
      totalInflow: initialBalance,
      totalOutflow: 0,
      txCount: 0,
      riskLevel: 'LOW',
      kycLevel,
      singleLimit: limits.single,
      dailyLimit: limits.daily,
      lastTxTime: simulatedTime,
      createTime: simulatedTime.slice(0, 10),
      hardwareChipId: `SE-${bank.id}-${Math.floor(10000 + Math.random() * 90000)}`,
      offlineQuota: Math.min(initialBalance, 2000)
    };

    setWallets(prev => [newWallet, ...prev]);

    // Update bank wallet count
    setBanks(prev => prev.map(b => b.id === bank.id ? { ...b, walletCount: b.walletCount + 1 } : b));

    logAudit({
      operatorOrg: bank.name,
      operatorUser: 'bank_teller_system',
      actionType: '数字人民币新钱包开立与实名KYC归档',
      targetResource: newId,
      result: 'SUCCESS',
      riskLevel: 'LOW',
      ipAddress: bank.ipAddress,
      detail: `为 ${name} 开立 ${kycLevel} 级别 ${type} 钱包，初始存入 ¥${initialBalance.toFixed(2)}。`
    });

    return newWallet;
  }, [banks, logAudit, simulatedTime]);

  // Risk alert resolution
  const resolveRiskAlert = useCallback((alertId: string, action: 'DISMISS' | 'FREEZE' | 'RESOLVE') => {
    const alert = riskAlerts.find(a => a.id === alertId);
    if (!alert) return;

    if (action === 'FREEZE') {
      freezeWallet(alert.walletId, `因风控预警 ${alert.ruleName} 触发由监管人员强制冻结`);
    }

    setRiskAlerts(prev => prev.map(a => {
      if (a.id === alertId) {
        return {
          ...a,
          status: action === 'DISMISS' ? 'DISMISSED' : (action === 'FREEZE' ? 'FROZEN' : 'INVESTIGATING')
        };
      }
      return a;
    }));
  }, [freezeWallet, riskAlerts]);

  // Execute Programmable Rule
  const executeProgrammableRule = useCallback((ruleId: string) => {
    const rule = programmableRules.find(r => r.id === ruleId);
    if (!rule) return { success: false, executedCount: 0, amount: 0 };

    const sourceWallet = wallets.find(w => w.id === rule.sourceWalletId);
    const targetWallets = wallets.filter(w => w.id !== rule.sourceWalletId && w.status === 'ACTIVE');

    if (!sourceWallet || targetWallets.length === 0) {
      return { success: false, executedCount: 0, amount: 0 };
    }

    const perTargetAmount = 1500.00;
    const totalDisburse = perTargetAmount * Math.min(targetWallets.length, 3);

    if (sourceWallet.availableBalance < totalDisburse) {
      return { success: false, executedCount: 0, amount: 0 };
    }

    targetWallets.slice(0, 3).forEach(target => {
      transferFunds({
        fromWalletId: sourceWallet.id,
        toWalletId: target.id,
        amount: perTargetAmount,
        type: 'PROGRAMMABLE',
        purpose: `[可编程支付履约] ${rule.title}`,
        programmableRuleId: rule.id
      });
    });

    return { success: true, executedCount: Math.min(targetWallets.length, 3), amount: totalDisburse };
  }, [programmableRules, transferFunds, wallets]);

  // Update Policy Params
  const updatePolicyParams = useCallback((params: Partial<MonetaryPolicyParams>) => {
    setPolicyParams(prev => ({ ...prev, ...params }));
    logAudit({
      operatorOrg: '中国人民银行货币政策司仿真实验室',
      operatorUser: 'macro_analyst_01',
      actionType: '货币政策参数调整与传导机制重算',
      targetResource: '宏观CBDC政策模型引擎',
      result: 'SUCCESS',
      riskLevel: 'LOW',
      ipAddress: '10.0.1.30',
      detail: '更新了准备金率、M0 替代率与流通速度指数，政策仿真模型已重新校准。'
    });
  }, [logAudit]);

  // Inject a burst of realistic transactions
  const injectBurstTransactions = useCallback((count = 4) => {
    const activeWallets = wallets.filter(w => w.status === 'ACTIVE');
    if (activeWallets.length < 2) return;

    const purposes = [
      '智慧交通地铁乘车扣款',
      '连锁便利店生鲜采购',
      '数字文旅门票与文创结算',
      '企事业单位智慧食堂就餐',
      '绿色新能源充电桩快速结算',
      '跨行供应链零件采购货款'
    ];
    const types: TransactionType[] = ['QR_CODE', 'NFC', 'MERCHANT_PAY', 'TRANSFER', 'API_PAY'];

    for (let i = 0; i < count; i++) {
      const sender = activeWallets[Math.floor(Math.random() * activeWallets.length)];
      let receiver = activeWallets[Math.floor(Math.random() * activeWallets.length)];
      if (receiver.id === sender.id) {
        receiver = activeWallets[(activeWallets.indexOf(sender) + 1) % activeWallets.length];
      }

      const amounts = [12.50, 35.80, 88.00, 156.20, 420.00, 1250.00];
      const amount = amounts[Math.floor(Math.random() * amounts.length)];
      const type = types[Math.floor(Math.random() * types.length)];
      const purpose = purposes[Math.floor(Math.random() * purposes.length)];

      if (sender.availableBalance >= amount) {
        transferFunds({
          fromWalletId: sender.id,
          toWalletId: receiver.id,
          amount,
          type,
          purpose
        });
      }
    }
  }, [transferFunds, wallets]);

  // Simulation tick loop
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (!isRunning) return;

    const intervalMs = 2500 / speed;

    timerRef.current = setInterval(() => {
      // Advance virtual clock by 1 to 5 seconds depending on speed
      setCurrentTime(prev => new Date(prev.getTime() + 1000 * (speed === 1 ? 1 : speed === 10 ? 10 : 60)));

      // Fluctuate real-time TPS
      setRealTimeTps(prev => {
        const delta = (Math.random() - 0.48) * 120;
        return Math.max(2800, Math.min(8900, Math.floor(prev + delta)));
      });

      // Update bank traffic subtly
      setBanks(prev => prev.map(b => ({
        ...b,
        todayTxCount: b.todayTxCount + Math.floor(Math.random() * (speed * 4) + 1),
        todayTxVolume: b.todayTxVolume + (Math.random() * (speed * 1200) + 100),
        latencyMs: Math.max(8, Math.min(32, Math.floor(b.latencyMs + (Math.random() - 0.5) * 2)))
      })));

      // Subtly fluctuate service latency
      setServices(prev => prev.map(s => ({
        ...s,
        latencyMs: Number(Math.max(1.5, Math.min(18.0, s.latencyMs + (Math.random() - 0.5) * 0.4)).toFixed(1)),
        qps: Math.floor(s.qps + (Math.random() - 0.5) * 200)
      })));

      // Periodically inject simulated minor payment activity if 10x or 100x speed
      if (Math.random() > 0.45) {
        injectBurstTransactions(1);
      }
    }, intervalMs);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [injectBurstTransactions, isRunning, speed]);

  const toggleSimulation = useCallback(() => {
    setIsRunning(prev => !prev);
  }, []);

  const resetSimulation = useCallback(() => {
    setWallets(INITIAL_WALLETS);
    setBanks(INITIAL_BANKS);
    setTransactions(INITIAL_TRANSACTIONS);
    setIssuanceBatches(INITIAL_ISSUANCE_BATCHES);
    setProgrammableRules(INITIAL_PROGRAMMABLE_RULES);
    setRiskAlerts(INITIAL_RISK_ALERTS);
    setAuditLogs(INITIAL_AUDIT_LOGS);
    setRegions(INITIAL_REGIONS);
    setServices(INITIAL_SERVICES);
    setPolicyParams(INITIAL_MONETARY_POLICY);
    setCurrentTime(new Date(2026, 8, 19, 10, 35, 0));
    setSpeed(1);
    setIsRunning(true);
  }, []);

  const value = {
    isRunning,
    speed,
    systemStatus,
    simulatedTime,
    wallets,
    banks,
    transactions,
    issuanceBatches,
    programmableRules,
    riskAlerts,
    auditLogs,
    regions,
    services,
    policyParams,
    stats,
    toggleSimulation,
    setSpeed,
    resetSimulation,
    issueDigitalYuan,
    redeemDigitalYuan,
    transferFunds,
    executeClearingBatch,
    triggerOfflineSync,
    freezeWallet,
    unfreezeWallet,
    createWallet,
    resolveRiskAlert,
    executeProgrammableRule,
    updatePolicyParams,
    injectBurstTransactions
  };

  return (
    <SimulationContext.Provider value={value}>
      {children}
    </SimulationContext.Provider>
  );
};

export const useSimulation = () => {
  const context = useContext(SimulationContext);
  if (!context) {
    throw new Error('useSimulation must be used within a SimulationProvider');
  }
  return context;
};
