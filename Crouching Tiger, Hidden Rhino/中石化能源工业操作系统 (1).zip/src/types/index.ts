/**
 * 中石化能源工业操作系统 (SEIOS)
 * 统一数据模型与工业接口定义
 */

// 数据血缘与溯源元数据 (用于点击任意数据弹出血缘)
export interface DataLineage {
  metricName: string;
  displayValue: string;
  rawValue: number | string;
  rawUnit: string;
  standardValue: number | string;
  standardUnit: string;
  conversionFactor: number;
  sourceSystem: 'DCS' | 'SCADA' | 'RTU' | 'PLC' | 'LIMS' | 'ERP' | 'MES' | 'IoT网关' | '仿真引擎';
  deviceId: string;
  deviceName: string;
  location: string;
  timestamp: string;
  calculationFormula: string;
  algorithmModel?: string;
  modelVersion?: string;
  confidenceInterval?: string;
  dataQuality: '优 (A级)' | '良 (B级)' | '校准中 (C级)' | '异常待核验';
  dataVersion: string;
}

// 统一单位定义
export type MetricUnit = 'bbl' | 't' | 'm3' | 'Nm3' | 'MMBtu' | 'GJ' | 'kWh' | 'MWh' | 'CNY' | 'USD';

export type TimeHorizon = 'realtime' | '1h' | '24h' | '30d' | '1y' | 'forecast' | 'scenario';

export type SystemMode = 'realtime' | 'simulation' | 'scenario' | 'history';

export type DashboardTabId = 
  | 'overview' 
  | 'asset_map' 
  | 'production' 
  | 'underground_twin' 
  | 'well_drilling' 
  | 'pipeline_twin' 
  | 'refinery_twin' 
  | 'chemicals_balance' 
  | 'inventory' 
  | 'trading' 
  | 'retail_station' 
  | 'new_energy' 
  | 'maintenance' 
  | 'hse_safety' 
  | 'carbon_ccus' 
  | 'ai_assistant' 
  | 'scenario_lab';

// 资产层级节点
export interface AssetHierarchyNode {
  id: string;
  name: string;
  level: 'group' | 'country' | 'region' | 'oilfield' | 'block' | 'well' | 'station' | 'pipeline' | 'tank' | 'refinery' | 'unit' | 'chemical' | 'warehouse' | 'port' | 'gas_station' | 'new_energy';
  parentId?: string;
  country: string;
  status: '正常运行' | '轻度预警' | '高危报警' | '计划检修' | '停产闭环';
  lat?: number;
  lng?: number;
  tags: string[];
}
