/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Header } from './components/Header';
import { DataLineageModal } from './components/DataLineageModal';
import { GlobalOverview } from './components/GlobalOverview';
import { GlobalAssetMap } from './components/GlobalAssetMap';
import { ProductionCenter } from './components/ProductionCenter';
import { UndergroundGeologyTwin } from './components/UndergroundGeologyTwin';
import { WellAndDrillingCenter } from './components/WellAndDrillingCenter';
import { PipelineHydraulicTwin } from './components/PipelineHydraulicTwin';
import { RefineryDigitalTwin } from './components/RefineryDigitalTwin';
import { PetrochemicalBalanceCenter } from './components/PetrochemicalBalanceCenter';
import { GlobalInventoryCenter } from './components/GlobalInventoryCenter';
import { EnergyTradingCenter } from './components/EnergyTradingCenter';
import { RetailStationTwin } from './components/RetailStationTwin';
import { NewEnergyHydrogenCenter } from './components/NewEnergyHydrogenCenter';
import { PredictiveMaintenanceCenter } from './components/PredictiveMaintenanceCenter';
import { HSESafetyCenter } from './components/HSESafetyCenter';
import { CarbonAndCCUSTwin } from './components/CarbonAndCCUSTwin';
import { AIEnergyAssistant } from './components/AIEnergyAssistant';
import { ScenarioLab } from './components/ScenarioLab';
import { DashboardTabId, MetricUnit, SystemMode, DataLineage } from './types';
import { DATA_LINEAGE_DICTIONARY, generateLineage } from './data/mockData';

export default function App() {
  const [activeTab, setActiveTab] = useState<DashboardTabId>('overview');
  const [systemMode, setSystemMode] = useState<SystemMode>('realtime');
  const [currentUnit, setCurrentUnit] = useState<MetricUnit>('t');
  
  // 数据血缘模态框状态
  const [selectedLineage, setSelectedLineage] = useState<DataLineage | null>(null);

  // 打开数据血缘弹窗
  const handleOpenDataLineage = (metricName: string, displayValue: string) => {
    // 查找血缘字典中匹配项或动态构造标准工业血缘链
    const matched = DATA_LINEAGE_DICTIONARY.find(d => 
      d.metricName.includes(metricName) || metricName.includes(d.metricName)
    );

    if (matched) {
      setSelectedLineage(
        generateLineage(
          metricName,
          displayValue,
          'SCADA',
          matched.sensorTag,
          `${metricName} 现场高精度智能仪表`,
          '国家管网/油气田/炼化核心生产现场',
          matched.calculationFormula
        )
      );
    } else {
      setSelectedLineage(
        generateLineage(
          metricName,
          displayValue,
          'DCS',
          'SINOPEC-SENSOR-TAG-2026',
          `${metricName} 工业在线测控系统`,
          '集团生产调度指挥中心',
          `${metricName} = 实时传感器采样物理量 × 标准工况标定系数`
        )
      );
    }
  };

  return (
    <div className="min-h-screen bg-[#07090e] text-slate-100 flex flex-col selection:bg-red-500 selection:text-white font-sans antialiased">
      
      {/* 统一工业控制中心导航顶栏 */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        systemMode={systemMode}
        setSystemMode={setSystemMode}
        currentUnit={currentUnit}
        setCurrentUnit={setCurrentUnit}
        onOpenDataLineage={handleOpenDataLineage}
      />

      {/* 业务中心主体工作区 */}
      <main className="flex-1 max-w-[1720px] w-full mx-auto p-3 sm:p-4 md:p-6 space-y-4">
        {activeTab === 'overview' && (
          <GlobalOverview 
            onOpenDataLineage={handleOpenDataLineage} 
            onNavigateTab={setActiveTab} 
            currentUnit={currentUnit} 
          />
        )}

        {activeTab === 'asset_map' && (
          <GlobalAssetMap 
            onOpenDataLineage={handleOpenDataLineage} 
            onNavigateTab={setActiveTab} 
          />
        )}

        {activeTab === 'production' && (
          <ProductionCenter
            onOpenDataLineage={handleOpenDataLineage}
            onNavigateTab={setActiveTab}
            currentUnit={currentUnit}
          />
        )}

        {activeTab === 'underground_twin' && (
          <UndergroundGeologyTwin
            onOpenDataLineage={handleOpenDataLineage}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'well_drilling' && (
          <WellAndDrillingCenter
            onOpenDataLineage={handleOpenDataLineage}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'pipeline_twin' && (
          <PipelineHydraulicTwin
            onOpenDataLineage={handleOpenDataLineage}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'refinery_twin' && (
          <RefineryDigitalTwin
            onOpenDataLineage={handleOpenDataLineage}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'chemicals_balance' && (
          <PetrochemicalBalanceCenter
            onOpenDataLineage={handleOpenDataLineage}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'inventory' && (
          <GlobalInventoryCenter
            onOpenDataLineage={handleOpenDataLineage}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'trading' && (
          <EnergyTradingCenter
            onOpenDataLineage={handleOpenDataLineage}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'retail_station' && (
          <RetailStationTwin
            onOpenDataLineage={handleOpenDataLineage}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'new_energy' && (
          <NewEnergyHydrogenCenter
            onOpenDataLineage={handleOpenDataLineage}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'maintenance' && (
          <PredictiveMaintenanceCenter
            onOpenDataLineage={handleOpenDataLineage}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'hse_safety' && (
          <HSESafetyCenter
            onOpenDataLineage={handleOpenDataLineage}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'carbon_ccus' && (
          <CarbonAndCCUSTwin
            onOpenDataLineage={handleOpenDataLineage}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'ai_assistant' && (
          <AIEnergyAssistant
            onOpenDataLineage={handleOpenDataLineage}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'scenario_lab' && (
          <ScenarioLab
            onOpenDataLineage={handleOpenDataLineage}
            onNavigateTab={setActiveTab}
          />
        )}
      </main>

      {/* 底部工业级安全与环境水印条 */}
      <footer className="bg-[#090b10] border-t border-slate-900 py-3 px-4 text-xs text-slate-500">
        <div className="max-w-[1720px] mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center space-x-3">
            <span className="font-bold text-slate-400">SEIOS v3.6.0 企业工业发行版</span>
            <span>·</span>
            <span>中国石化工业物联网与生产管控操作系统</span>
            <span>·</span>
            <span className="text-amber-500/80 bg-amber-950/30 px-2 py-0.5 rounded border border-amber-800/40 text-[10px]">
              内部工业控制系统 · 全链路工业机理仿真验证
            </span>
          </div>
          <div className="flex items-center space-x-4 text-[11px]">
            <span>OT 安全边界: 等保四级严防</span>
            <span>时钟源: 北斗高精度原子时钟同步</span>
            <span className="text-slate-400 font-mono">2026 SINOPEC CORP. ALL RIGHTS RESERVED</span>
          </div>
        </div>
      </footer>

      {/* 全局数据血缘审计与追溯模态框 */}
      <DataLineageModal
        lineage={selectedLineage}
        onClose={() => setSelectedLineage(null)}
      />

    </div>
  );
}
