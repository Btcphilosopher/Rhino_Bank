/**
 * 模块 12：综合新能源与氢能产业链 (New Energy & Hydrogen Center)
 * 新疆库车2万吨绿氢示范基地、雄安地热供暖、胜利油田微电网与绿氢平准化度电成本 (LCOH)
 */

import React from 'react';
import { 
  Zap, 
  Wind, 
  Sun, 
  Flame, 
  Activity, 
  Database, 
  CheckCircle2, 
  TrendingUp, 
  Leaf 
} from 'lucide-react';
import { NEW_ENERGY_PROJECTS } from '../data/mockData';

interface NewEnergyHydrogenCenterProps {
  onOpenDataLineage: (metricName: string, displayValue: string) => void;
  onNavigateTab: (tab: any) => void;
}

export const NewEnergyHydrogenCenter: React.FC<NewEnergyHydrogenCenterProps> = ({
  onOpenDataLineage
}) => {
  return (
    <div className="space-y-4">
      
      {/* 顶栏新能源战略概述 */}
      <div className="bg-[#121620] border border-slate-800 rounded-lg p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center space-x-3">
          <span className="flex items-center space-x-1.5 font-bold text-white">
            <Zap className="w-4 h-4 text-cyan-400" />
            <span>中国第一大氢能公司 & 地热开发领航者</span>
          </span>
          <span className="text-slate-400">
            绿氢累计制备: <strong className="text-cyan-400 font-mono">1.82 万吨</strong> | 
            地热供暖面积: <strong className="text-amber-400 font-mono">8,500 万㎡</strong>
          </span>
        </div>

        <span className="text-[11px] text-emerald-400 font-medium">
          绿电消纳率 99.2% · 全绿电溯源绿证可核查
        </span>
      </div>

      {/* 3大旗舰新能源工程卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
        {NEW_ENERGY_PROJECTS.map((project) => (
          <div key={project.id} className="bg-[#121620] border border-slate-800 rounded-lg p-4 space-y-3">
            
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div>
                <span className="text-[10px] text-cyan-400 font-semibold">{project.type}</span>
                <h4 className="text-sm font-bold text-white mt-0.5">{project.name}</h4>
              </div>
              <button
                onClick={() => onOpenDataLineage(`${project.name} 指标`, `${project.capacity}`)}
                className="text-slate-500 hover:text-red-400 p-1"
              >
                <Database className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-2 text-slate-300">
              <div className="flex justify-between p-2 bg-[#161c28] rounded border border-slate-800">
                <span className="text-slate-400">装机容量 / 规模:</span>
                <span className="font-bold text-white">{project.capacity}</span>
              </div>
              <div className="flex justify-between p-2 bg-[#161c28] rounded border border-slate-800">
                <span className="text-slate-400">当前实时负荷 / 产量:</span>
                <span className="font-bold text-cyan-400 font-mono">{project.currentOutput}</span>
              </div>
              <div className="flex justify-between p-2 bg-[#161c28] rounded border border-slate-800">
                <span className="text-slate-400">年碳减排量 (CO₂e):</span>
                <span className="font-bold text-emerald-400 font-mono">{project.annualCo2ReductionTonne.toLocaleString()} 吨/年</span>
              </div>
              <div className="flex justify-between p-2 bg-[#161c28] rounded border border-slate-800">
                <span className="text-slate-400">项目地理位置:</span>
                <span className="text-slate-200">{project.location}</span>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800 flex justify-between items-center text-[11px]">
              <span className="text-slate-400">运行状态</span>
              <span className="text-emerald-400 font-medium">{project.status}</span>
            </div>

          </div>
        ))}
      </div>

    </div>
  );
};
