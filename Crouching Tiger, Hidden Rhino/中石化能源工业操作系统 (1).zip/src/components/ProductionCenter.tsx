/**
 * 模块 3：油气生产中心 (Production Center)
 * 集团 -> 油田 -> 区块 -> 井组级联钻取，实时产油/产气/产水/含水率/流压/注水分析
 */

import React, { useState } from 'react';
import { 
  Flame, 
  Zap, 
  Droplet, 
  Activity, 
  Database, 
  SlidersHorizontal, 
  ChevronRight, 
  ArrowUpRight, 
  TrendingDown, 
  AlertTriangle,
  Layers,
  ChevronDown
} from 'lucide-react';
import { DETAILED_OILFIELDS, DETAILED_WELLS } from '../data/mockData';
import { MetricUnit } from '../types';

interface ProductionCenterProps {
  onOpenDataLineage: (metricName: string, displayValue: string) => void;
  onNavigateTab: (tab: any) => void;
  currentUnit: MetricUnit;
}

export const ProductionCenter: React.FC<ProductionCenterProps> = ({
  onOpenDataLineage,
  onNavigateTab,
}) => {
  const [selectedFieldId, setSelectedFieldId] = useState<string>('OF-02'); // 顺北超深油气田
  const currentField = DETAILED_OILFIELDS.find(f => f.id === selectedFieldId) || DETAILED_OILFIELDS[0];
  const fieldWells = DETAILED_WELLS.filter(w => w.fieldId === selectedFieldId);

  return (
    <div className="space-y-4">
      
      {/* 级联油田选择器与概况条 */}
      <div className="bg-[#121620] border border-slate-800 rounded-lg p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
        
        {/* 左侧选择油田 */}
        <div className="flex items-center space-x-2">
          <span className="text-slate-400 font-semibold flex items-center space-x-1">
            <Flame className="w-3.5 h-3.5 text-amber-500" />
            <span>选择油气田单元:</span>
          </span>
          
          <div className="relative">
            <select
              value={selectedFieldId}
              onChange={(e) => setSelectedFieldId(e.target.value)}
              className="bg-[#182030] border border-slate-700 text-slate-100 font-semibold px-3 py-1.5 rounded text-xs focus:outline-none focus:border-red-500"
            >
              {DETAILED_OILFIELDS.map(f => (
                <option key={f.id} value={f.id}>
                  {f.name} ({f.type} · 储量 {f.provenReservesMMBbl} 百万桶)
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* 快捷跳转到地质体 3D 孪生 */}
        <div className="flex items-center space-x-3">
          <button
            onClick={() => onNavigateTab('underground_twin')}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-red-600 hover:bg-red-500 text-white font-medium rounded transition"
          >
            <Layers className="w-3.5 h-3.5" />
            <span>查看本油田 3D 地质藏与井网孪生</span>
          </button>
        </div>

      </div>

      {/* 选中油田的工业属性与实时大盘 */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        
        {/* 产油量 */}
        <div className="bg-[#121620] border border-slate-800 rounded-lg p-3">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span>日产原油</span>
            <button 
              onClick={() => onOpenDataLineage(`${currentField.name} 日产油量`, `${currentField.dailyOilProduction.toLocaleString()} 桶/日`)}
              className="text-slate-500 hover:text-red-400"
              title="查看血缘"
            >
              <Database className="w-3 h-3" />
            </button>
          </div>
          <div className="text-xl font-bold text-amber-400 font-mono">
            {currentField.dailyOilProduction.toLocaleString()} <span className="text-xs text-slate-400 font-normal">bbl/d</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex justify-between">
            <span>折合: {(currentField.dailyOilProduction * 0.137).toFixed(1)} 吨/日</span>
            <span className="text-emerald-400">稳定受控</span>
          </div>
        </div>

        {/* 产气量 */}
        <div className="bg-[#121620] border border-slate-800 rounded-lg p-3">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span>日产天然气</span>
            <button 
              onClick={() => onOpenDataLineage(`${currentField.name} 日产天然气`, `${(currentField.dailyGasProduction / 10000).toFixed(0)} 万方/日`)}
              className="text-slate-500 hover:text-red-400"
              title="查看血缘"
            >
              <Database className="w-3 h-3" />
            </button>
          </div>
          <div className="text-xl font-bold text-cyan-400 font-mono">
            {(currentField.dailyGasProduction / 10000).toFixed(0)} <span className="text-xs text-slate-400 font-normal">万方/d</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex justify-between">
            <span>折标方输送中</span>
            <span className="text-cyan-400">管网直供</span>
          </div>
        </div>

        {/* 综合含水率与产水 */}
        <div className="bg-[#121620] border border-slate-800 rounded-lg p-3">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span>综合含水率 (Water Cut)</span>
            <button 
              onClick={() => onOpenDataLineage(`${currentField.name} 综合含水率`, `${currentField.waterCutPercent}% (日产水 ${currentField.dailyWaterProduction} 桶)`)}
              className="text-slate-500 hover:text-red-400"
              title="查看血缘"
            >
              <Database className="w-3 h-3" />
            </button>
          </div>
          <div className={`text-xl font-bold font-mono ${currentField.waterCutPercent > 50 ? 'text-rose-400' : 'text-emerald-400'}`}>
            {currentField.waterCutPercent}%
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex justify-between">
            <span>日产水: {currentField.dailyWaterProduction.toLocaleString()} 桶</span>
            <span>回注利用率 99.4%</span>
          </div>
        </div>

        {/* 储层流压与采收率 */}
        <div className="bg-[#121620] border border-slate-800 rounded-lg p-3">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span>平均储层流压 / 采收率</span>
            <button 
              onClick={() => onOpenDataLineage(`${currentField.name} 地层原始与当前压力`, `${currentField.reservoirPressureMPa} MPa / 采收率 ${currentField.currentRecoveryRate}%`)}
              className="text-slate-500 hover:text-red-400"
              title="查看血缘"
            >
              <Database className="w-3 h-3" />
            </button>
          </div>
          <div className="text-xl font-bold text-white font-mono">
            {currentField.reservoirPressureMPa} <span className="text-xs text-slate-400 font-normal">MPa</span> / <span className="text-emerald-400">{currentField.currentRecoveryRate}%</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex justify-between">
            <span>储层埋深: {currentField.geologyDepth}m</span>
            <span>年递减: {currentField.declineRateAnnual}%</span>
          </div>
        </div>

      </div>

      {/* 油田详细地质地质构造参数与生产态势 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        
        {/* 地质构造与开发指标 (1列) */}
        <div className="bg-[#121620] border border-slate-800 rounded-lg p-4 space-y-3 text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 className="text-sm font-bold text-white flex items-center space-x-1.5">
              <span>油藏与地质开发参数</span>
            </h3>
            <span className="text-[10px] bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded">{currentField.basin}</span>
          </div>

          <div className="space-y-2 text-slate-300">
            <div className="flex justify-between p-2 bg-[#161c28] rounded border border-slate-800/80">
              <span className="text-slate-400">构造盆地 / 圈闭类型:</span>
              <span className="font-semibold text-white">{currentField.basin}</span>
            </div>
            <div className="flex justify-between p-2 bg-[#161c28] rounded border border-slate-800/80">
              <span className="text-slate-400">含油气含水层温度:</span>
              <span className="font-mono text-amber-300">{currentField.reservoirTempC} ℃ (超深高温)</span>
            </div>
            <div className="flex justify-between p-2 bg-[#161c28] rounded border border-slate-800/80">
              <span className="text-slate-400">地质探明总储量:</span>
              <span className="font-mono font-bold text-white">{currentField.provenReservesMMBbl.toLocaleString()} 百万桶 (MMBbl)</span>
            </div>
            <div className="flex justify-between p-2 bg-[#161c28] rounded border border-slate-800/80">
              <span className="text-slate-400">剩余经济可采储量:</span>
              <span className="font-mono text-emerald-400">{currentField.remainingRecoverableMMBbl.toLocaleString()} MMBbl</span>
            </div>
            <div className="flex justify-between p-2 bg-[#161c28] rounded border border-slate-800/80">
              <span className="text-slate-400">在役生产井 / 注水井:</span>
              <span className="font-mono font-bold text-white">{currentField.activeWellsCount} 口 / {currentField.injectionWellsCount} 口</span>
            </div>
            <div className="flex justify-between p-2 bg-[#161c28] rounded border border-slate-800/80">
              <span className="text-slate-400">水驱采收率提升技术:</span>
              <span className="text-blue-300">高压微泡驱 + CO2驱 (CCUS)</span>
            </div>
          </div>
        </div>

        {/* 旗下单井列表与实时传感器监测 (2列) */}
        <div className="lg:col-span-2 bg-[#121620] border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
            <div className="flex items-center space-x-2">
              <SlidersHorizontal className="w-4 h-4 text-red-500" />
              <h3 className="text-sm font-bold text-white">旗下重点单井实时工况与传感器遥测</h3>
            </div>
            <button
              onClick={() => onNavigateTab('well_drilling')}
              className="text-xs text-red-400 hover:text-red-300 flex items-center space-x-1"
            >
              <span>查看单井与钻井深度分析</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="text-slate-400 border-b border-slate-800 text-[11px]">
                  <th className="py-2">井号 / 井名</th>
                  <th className="py-2">井型</th>
                  <th className="py-2">完钻深度 (m)</th>
                  <th className="py-2">产油 (bbl/d)</th>
                  <th className="py-2">产气 (m³/d)</th>
                  <th className="py-2">含水率 %</th>
                  <th className="py-2">井口压力 (MPa)</th>
                  <th className="py-2">状态</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                {fieldWells.length > 0 ? (
                  fieldWells.map((well) => (
                    <tr 
                      key={well.id}
                      onClick={() => onNavigateTab('well_drilling')}
                      className="hover:bg-slate-800/50 cursor-pointer transition"
                    >
                      <td className="py-2.5 font-medium text-white">
                        <div className="font-bold">{well.name}</div>
                        <div className="text-[10px] text-slate-500">{well.producingLayer}</div>
                      </td>
                      <td className="py-2.5 text-slate-300">{well.wellType}</td>
                      <td className="py-2.5 font-mono">{well.depthTotalMD}m</td>
                      <td className="py-2.5 font-mono font-bold text-amber-300">{well.dailyOilBbl}</td>
                      <td className="py-2.5 font-mono text-cyan-300">{well.dailyGasM3.toLocaleString()}</td>
                      <td className="py-2.5 font-mono">
                        <span className={well.waterCut > 50 ? 'text-rose-400 font-bold' : 'text-emerald-400'}>
                          {well.waterCut}%
                        </span>
                      </td>
                      <td className="py-2.5 font-mono text-white">{well.wellheadPressure}</td>
                      <td className="py-2.5">
                        <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                          well.status.includes('报警') 
                            ? 'bg-rose-950 text-rose-300 border border-rose-800' 
                            : 'bg-emerald-950 text-emerald-300 border border-emerald-800/50'
                        }`}>
                          {well.status}
                        </span>
                      </td>
                    </tr>
                  ))
                ) : (
                  DETAILED_WELLS.map((well) => (
                    <tr 
                      key={well.id}
                      onClick={() => onNavigateTab('well_drilling')}
                      className="hover:bg-slate-800/50 cursor-pointer transition"
                    >
                      <td className="py-2.5 font-medium text-white">
                        <div className="font-bold">{well.name}</div>
                        <div className="text-[10px] text-slate-500">{well.producingLayer}</div>
                      </td>
                      <td className="py-2.5 text-slate-300">{well.wellType}</td>
                      <td className="py-2.5 font-mono">{well.depthTotalMD}m</td>
                      <td className="py-2.5 font-mono font-bold text-amber-300">{well.dailyOilBbl}</td>
                      <td className="py-2.5 font-mono text-cyan-300">{well.dailyGasM3.toLocaleString()}</td>
                      <td className="py-2.5 font-mono">
                        <span className={well.waterCut > 50 ? 'text-rose-400 font-bold' : 'text-emerald-400'}>
                          {well.waterCut}%
                        </span>
                      </td>
                      <td className="py-2.5 font-mono text-white">{well.wellheadPressure}</td>
                      <td className="py-2.5">
                        <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                          well.status.includes('报警') 
                            ? 'bg-rose-950 text-rose-300 border border-rose-800' 
                            : 'bg-emerald-950 text-emerald-300 border border-emerald-800/50'
                        }`}>
                          {well.status}
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

      </div>

    </div>
  );
};
