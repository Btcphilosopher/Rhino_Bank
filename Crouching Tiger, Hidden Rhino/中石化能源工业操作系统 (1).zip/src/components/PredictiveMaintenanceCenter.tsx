/**
 * 模块 13：设备健康与预测性维护中心 (Predictive Maintenance Center)
 * 大型旋转机组 (裂解气压缩机、原油主泵、高压注水泵) 振动频谱、轴承温度与 RUL 剩余寿命预测
 */

import React, { useState } from 'react';
import { 
  Wrench, 
  Activity, 
  Database, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  Radio, 
  ShieldAlert,
  Send
} from 'lucide-react';
import { CRITICAL_EQUIPMENT } from '../data/mockData';

interface PredictiveMaintenanceCenterProps {
  onOpenDataLineage: (metricName: string, displayValue: string) => void;
  onNavigateTab: (tab: any) => void;
}

export const PredictiveMaintenanceCenter: React.FC<PredictiveMaintenanceCenterProps> = ({
  onOpenDataLineage
}) => {
  const [selectedEquipId, setSelectedEquipId] = useState<string>('EQ-001');
  const [workOrderSent, setWorkOrderSent] = useState<boolean>(false);

  const equip = CRITICAL_EQUIPMENT.find(e => e.id === selectedEquipId) || CRITICAL_EQUIPMENT[0];

  const handleSendWorkOrder = () => {
    setWorkOrderSent(true);
    setTimeout(() => setWorkOrderSent(false), 4000);
  };

  return (
    <div className="space-y-4">
      
      {/* 顶栏机组选择与设备健康态势 */}
      <div className="bg-[#121620] border border-slate-800 rounded-lg p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center space-x-2">
          <span className="text-slate-400 font-semibold flex items-center space-x-1">
            <Wrench className="w-3.5 h-3.5 text-amber-500" />
            <span>选择关键旋转/特种机组:</span>
          </span>
          <select
            value={selectedEquipId}
            onChange={(e) => setSelectedEquipId(e.target.value)}
            className="bg-[#182030] border border-slate-700 text-slate-100 font-bold px-3 py-1.5 rounded text-xs focus:outline-none focus:border-amber-500"
          >
            {CRITICAL_EQUIPMENT.map(e => (
              <option key={e.id} value={e.id}>
                {e.name} ({e.type} · {e.location})
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-center space-x-3 text-slate-300">
          <span>AI 诊断健康度: <strong className="text-emerald-400 font-mono text-sm">{equip.healthScore}/100</strong></span>
          <span className={`px-2 py-0.5 rounded text-[11px] ${
            equip.status.includes('预警') || equip.status.includes('异常') 
              ? 'bg-rose-950 text-rose-300 border border-rose-800 animate-pulse' 
              : 'bg-emerald-950 text-emerald-300 border border-emerald-800/60'
          }`}>
            {equip.status}
          </span>
        </div>
      </div>

      {/* 4大关键设备遥测传感器 */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
        
        <div className="bg-[#121620] border border-slate-800 rounded-lg p-3">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span>主轴振动烈度 (RMS)</span>
            <button 
              onClick={() => onOpenDataLineage(`${equip.name} 振动传感器`, `${equip.vibrationMmS} mm/s [ISO 10816 振动标准]`)}
              className="text-slate-500 hover:text-red-400"
            >
              <Database className="w-3 h-3" />
            </button>
          </div>
          <div className={`text-xl font-bold font-mono ${equip.vibrationMmS > 3.0 ? 'text-amber-400' : 'text-emerald-400'}`}>
            {equip.vibrationMmS} <span className="text-xs text-slate-400 font-normal">mm/s</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex justify-between">
            <span>报警门限: 4.5 mm/s</span>
            <span>频段: 1X ~ 5X 阶次</span>
          </div>
        </div>

        <div className="bg-[#121620] border border-slate-800 rounded-lg p-3">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span>轴承瓦温 (Bearing Temp)</span>
            <span className="text-emerald-400 font-mono">PT100 在线</span>
          </div>
          <div className={`text-xl font-bold font-mono ${equip.bearingTempC > 75 ? 'text-amber-400' : 'text-cyan-300'}`}>
            {equip.bearingTempC} <span className="text-xs text-slate-400 font-normal">℃</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex justify-between">
            <span>跳闸停机阈值: 95℃</span>
            <span>润滑油膜完好</span>
          </div>
        </div>

        <div className="bg-[#121620] border border-slate-800 rounded-lg p-3">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span>润滑油品质指数 (Lubrication)</span>
            <span className="text-slate-400 font-mono">在线介电常数</span>
          </div>
          <div className="text-xl font-bold text-white font-mono">
            {equip.oilLubricationQuality}
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex justify-between">
            <span>水分 &lt; 50 ppm</span>
            <span>磨损颗粒 NAS 6级</span>
          </div>
        </div>

        <div className="bg-[#121620] border border-slate-800 rounded-lg p-3">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span>RUL 剩余无故障寿命预测</span>
            <button 
              onClick={() => onOpenDataLineage('机组 RUL 寿命预测', `${equip.remainingUsefulLifeDays} 天 [AI 双向 LSTM + 威布尔分布]`)}
              className="text-slate-500 hover:text-red-400"
            >
              <Database className="w-3 h-3" />
            </button>
          </div>
          <div className="text-xl font-bold text-amber-400 font-mono">
            {equip.remainingUsefulLifeDays} <span className="text-xs text-slate-400 font-normal">天</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex justify-between">
            <span>建议检修窗口</span>
            <span className="text-cyan-400">计划性大修前 15 天</span>
          </div>
        </div>

      </div>

      {/* 故障诊断、工单派发与频谱分析 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        
        {/* 故障诊断与应急处置建议 (2列) */}
        <div className="lg:col-span-2 bg-[#121620] border border-slate-800 rounded-lg p-4 space-y-3 text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h4 className="text-sm font-bold text-white flex items-center space-x-2">
              <Activity className="w-4 h-4 text-red-500" />
              <span>机组智能故障模式分析与机理诊断 (AI Vibration Diagnostics)</span>
            </h4>
            <span className="text-slate-400 font-mono text-[11px]">{equip.location}</span>
          </div>

          <div className="p-3 bg-[#161c28] rounded border border-slate-800 space-y-2">
            <div className="flex items-center space-x-2">
              <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
              <div className="font-bold text-white text-xs">当前机理分析诊断结论:</div>
            </div>
            <p className="text-slate-300 text-xs leading-relaxed pl-6">
              {equip.faultDiagnosis}
            </p>
          </div>

          <div className="flex items-center justify-between pt-2">
            <div className="text-slate-400 text-[11px]">
              联动资产管理系统 (Maximo/SAP PM) 自动生成预防性工单
            </div>
            <button
              onClick={handleSendWorkOrder}
              className="flex items-center space-x-1.5 px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white font-medium rounded transition"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{workOrderSent ? '工单已下发至现场班组！' : '一键派发检修工单'}</span>
            </button>
          </div>
        </div>

        {/* 备件库存与换件档案 (1列) */}
        <div className="bg-[#121620] border border-slate-800 rounded-lg p-4 space-y-3 text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h4 className="text-sm font-bold text-white">原厂备件库存与更换历史</h4>
            <span className="text-[10px] text-emerald-400">现货充足</span>
          </div>

          <div className="space-y-2 text-slate-300">
            <div className="p-2 bg-[#161c28] rounded border border-slate-800">
              <div className="text-slate-400 text-[11px]">机械密封总成 (Cartridge Seal)</div>
              <div className="font-bold text-white mt-0.5">库房现存 2 套 (库位: A-12-04)</div>
            </div>
            <div className="p-2 bg-[#161c28] rounded border border-slate-800">
              <div className="text-slate-400 text-[11px]">滚动/滑动轴瓦 (SKF/NSK)</div>
              <div className="font-bold text-white mt-0.5">库房现存 4 组 (检验合格)</div>
            </div>
            <div className="p-2 bg-[#161c28] rounded border border-slate-800">
              <div className="text-slate-400 text-[11px]">上次预防性保养维护日期</div>
              <div className="text-slate-200 mt-0.5">2026-06-15 (已连续安全运行 95 天)</div>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
