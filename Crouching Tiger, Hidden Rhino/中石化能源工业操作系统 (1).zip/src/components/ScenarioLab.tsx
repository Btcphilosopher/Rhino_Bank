/**
 * 模块 17：能源情景与宏观策略实验室 (Scenario Lab)
 * 地缘冲突油价异动、极端气候保供、碳税政策收紧与新能源替代跨系统压力测试及宏观推演
 */

import React, { useState } from 'react';
import { 
  Sliders, 
  TrendingUp, 
  Database, 
  Flame, 
  Leaf, 
  ShieldAlert, 
  DollarSign, 
  RotateCcw, 
  CheckCircle2,
  Sparkles
} from 'lucide-react';

interface ScenarioLabProps {
  onOpenDataLineage: (metricName: string, displayValue: string) => void;
  onNavigateTab: (tab: any) => void;
}

export const ScenarioLab: React.FC<ScenarioLabProps> = ({
  onOpenDataLineage
}) => {
  // 宏观情景变量
  const [brentPrice, setBrentPrice] = useState<number>(84.5); // $/bbl
  const [carbonPrice, setCarbonPrice] = useState<number>(85.0); // ¥/吨
  const [refineryLoad, setRefineryLoad] = useState<number>(92.8); // %
  const [evPenetration, setEvPenetration] = useState<number>(38.0); // %

  // 预设宏观冲击情景
  const applyPreset = (type: 'war_spike' | 'winter_cold' | 'carbon_tax' | 'ev_boom' | 'reset') => {
    if (type === 'war_spike') {
      setBrentPrice(125.0);
      setCarbonPrice(90.0);
      setRefineryLoad(96.0);
      setEvPenetration(42.0);
    } else if (type === 'winter_cold') {
      setBrentPrice(95.0);
      setCarbonPrice(85.0);
      setRefineryLoad(95.0);
      setEvPenetration(38.0);
    } else if (type === 'carbon_tax') {
      setBrentPrice(82.0);
      setCarbonPrice(160.0);
      setRefineryLoad(88.0);
      setEvPenetration(48.0);
    } else if (type === 'ev_boom') {
      setBrentPrice(75.0);
      setCarbonPrice(110.0);
      setRefineryLoad(82.0);
      setEvPenetration(65.0);
    } else {
      setBrentPrice(84.5);
      setCarbonPrice(85.0);
      setRefineryLoad(92.8);
      setEvPenetration(38.0);
    }
  };

  // 跨系统测算结果
  const simulatedRevenueBillionCNY = (3250 * (brentPrice / 84.5) * (refineryLoad / 92.8)).toFixed(1);
  const simulatedEbitBillionCNY = (88.5 * (1 + (brentPrice - 84.5) * 0.015) - (carbonPrice - 85) * 0.08).toFixed(1);
  const simulatedCarbonEmissionMillionTonne = (168.4 * (refineryLoad / 92.8) * (1 - (evPenetration - 38) * 0.005)).toFixed(1);
  const upstreamProfitShift = ((brentPrice - 84.5) * 1.8).toFixed(1);
  const downstreamMarginShift = ((84.5 - brentPrice) * 0.9).toFixed(1);

  return (
    <div className="space-y-4">
      
      {/* 顶栏情景实验室概述与预设剧本 */}
      <div className="bg-[#121620] border border-slate-800 rounded-lg p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center space-x-2">
          <span className="text-slate-400 font-semibold flex items-center space-x-1">
            <Sliders className="w-3.5 h-3.5 text-red-500" />
            <span>宏观与极端冲击情景预设:</span>
          </span>
          
          <button
            onClick={() => applyPreset('war_spike')}
            className="px-2.5 py-1 bg-[#161c28] hover:bg-rose-950 text-rose-300 border border-rose-900/60 rounded text-xs transition font-medium"
          >
            地缘危机 (油价 $125)
          </button>

          <button
            onClick={() => applyPreset('winter_cold')}
            className="px-2.5 py-1 bg-[#161c28] hover:bg-cyan-950 text-cyan-300 border border-cyan-900/60 rounded text-xs transition font-medium"
          >
            极寒气候 (气需求 +30%)
          </button>

          <button
            onClick={() => applyPreset('carbon_tax')}
            className="px-2.5 py-1 bg-[#161c28] hover:bg-emerald-950 text-emerald-300 border border-emerald-900/60 rounded text-xs transition font-medium"
          >
            高碳税收紧 (碳价 ¥160)
          </button>

          <button
            onClick={() => applyPreset('ev_boom')}
            className="px-2.5 py-1 bg-[#161c28] hover:bg-purple-950 text-purple-300 border border-purple-900/60 rounded text-xs transition font-medium"
          >
            新能源车大爆发 (渗透率 65%)
          </button>

          <button
            onClick={() => applyPreset('reset')}
            className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs transition flex items-center space-x-1"
          >
            <RotateCcw className="w-3 h-3" />
            <span>基准常态</span>
          </button>
        </div>

        <span className="text-slate-400 text-[11px]">
          蒙特卡洛敏感性分析 (10,000次模拟迭代)
        </span>
      </div>

      {/* 变量敏感性调节滑块 */}
      <div className="bg-[#121620] border border-slate-800 rounded-lg p-4 grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
        
        {/* 国际布伦特原油价格 */}
        <div className="space-y-1.5 bg-[#161c28] p-3 rounded border border-slate-800">
          <div className="flex justify-between">
            <span className="text-slate-400 font-medium">国际布伦特油价 (Brent):</span>
            <span className="font-mono font-bold text-amber-400 text-sm">${brentPrice.toFixed(1)} /bbl</span>
          </div>
          <input
            type="range"
            min="40"
            max="150"
            step="0.5"
            value={brentPrice}
            onChange={(e) => setBrentPrice(parseFloat(e.target.value))}
            className="w-full accent-amber-500"
          />
          <div className="flex justify-between text-[10px] text-slate-500">
            <span>$40 萧条</span>
            <span>$84.5 基线</span>
            <span>$150 极值</span>
          </div>
        </div>

        {/* 全国碳交易基准碳价 */}
        <div className="space-y-1.5 bg-[#161c28] p-3 rounded border border-slate-800">
          <div className="flex justify-between">
            <span className="text-slate-400 font-medium">全国碳市场碳价:</span>
            <span className="font-mono font-bold text-emerald-400 text-sm">¥{carbonPrice.toFixed(1)} /吨</span>
          </div>
          <input
            type="range"
            min="40"
            max="200"
            step="1"
            value={carbonPrice}
            onChange={(e) => setCarbonPrice(parseFloat(e.target.value))}
            className="w-full accent-emerald-500"
          />
          <div className="flex justify-between text-[10px] text-slate-500">
            <span>¥40 宽松</span>
            <span>¥85 基线</span>
            <span>¥200 严苛</span>
          </div>
        </div>

        {/* 炼化开工加工负荷 */}
        <div className="space-y-1.5 bg-[#161c28] p-3 rounded border border-slate-800">
          <div className="flex justify-between">
            <span className="text-slate-400 font-medium">全集团炼油开工负荷:</span>
            <span className="font-mono font-bold text-cyan-400 text-sm">{refineryLoad.toFixed(1)}%</span>
          </div>
          <input
            type="range"
            min="65"
            max="105"
            step="0.5"
            value={refineryLoad}
            onChange={(e) => setRefineryLoad(parseFloat(e.target.value))}
            className="w-full accent-cyan-500"
          />
          <div className="flex justify-between text-[10px] text-slate-500">
            <span>65% 降负</span>
            <span>92.8% 常态</span>
            <span>105% 超负荷</span>
          </div>
        </div>

        {/* 新能源车渗透率 */}
        <div className="space-y-1.5 bg-[#161c28] p-3 rounded border border-slate-800">
          <div className="flex justify-between">
            <span className="text-slate-400 font-medium">新能源车 (EV) 新车渗透率:</span>
            <span className="font-mono font-bold text-purple-400 text-sm">{evPenetration.toFixed(1)}%</span>
          </div>
          <input
            type="range"
            min="20"
            max="80"
            step="1"
            value={evPenetration}
            onChange={(e) => setEvPenetration(parseFloat(e.target.value))}
            className="w-full accent-purple-500"
          />
          <div className="flex justify-between text-[10px] text-slate-500">
            <span>20% 早期</span>
            <span>38% 现状</span>
            <span>80% 主导</span>
          </div>
        </div>

      </div>

      {/* 宏观经济与生产经营推演结果面板 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        
        {/* 测算核心效益指标 (2列) */}
        <div className="lg:col-span-2 bg-[#121620] border border-slate-800 rounded-lg p-4 space-y-4 text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center space-x-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              <h4 className="text-sm font-bold text-white">推演情景下集团整体经营指标重算</h4>
            </div>
            <button
              onClick={() => onOpenDataLineage('宏观情景跨系统经济学测算', `营业收入 ¥${simulatedRevenueBillionCNY} 亿元, 息税前利润 EBIT ¥${simulatedEbitBillionCNY} 亿元`)}
              className="text-slate-500 hover:text-red-400"
            >
              <Database className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="p-3 bg-[#161c28] rounded border border-slate-800">
              <div className="text-slate-400 text-[11px]">测算年度营业收入</div>
              <div className="text-xl font-bold text-white font-mono mt-0.5">
                ¥{simulatedRevenueBillionCNY} <span className="text-xs text-slate-400 font-normal">亿元</span>
              </div>
              <div className="text-[10px] text-emerald-400 mt-1">
                {parseFloat(simulatedRevenueBillionCNY) >= 3250 ? '↑ 规模同比扩张' : '↓ 需求收缩'}
              </div>
            </div>

            <div className="p-3 bg-[#161c28] rounded border border-slate-800">
              <div className="text-slate-400 text-[11px]">测算息税前利润 (EBIT)</div>
              <div className="text-xl font-bold text-emerald-400 font-mono mt-0.5">
                ¥{simulatedEbitBillionCNY} <span className="text-xs text-slate-400 font-normal">亿元</span>
              </div>
              <div className="text-[10px] text-slate-400 mt-1">
                上游贡献: {upstreamProfitShift >= '0' ? `+¥${upstreamProfitShift}亿` : `¥${upstreamProfitShift}亿`}
              </div>
            </div>

            <div className="p-3 bg-[#161c28] rounded border border-slate-800">
              <div className="text-slate-400 text-[11px]">测算全集团碳排放量</div>
              <div className="text-xl font-bold text-cyan-300 font-mono mt-0.5">
                {simulatedCarbonEmissionMillionTonne} <span className="text-xs text-slate-400 font-normal">百万吨</span>
              </div>
              <div className="text-[10px] text-slate-400 mt-1">
                碳履约成本: ¥{((parseFloat(simulatedCarbonEmissionMillionTonne) * carbonPrice) / 10).toFixed(0)} 亿元
              </div>
            </div>
          </div>

          {/* 业务板块风险与对冲策略 */}
          <div className="p-3 bg-[#161c28] rounded border border-slate-800 space-y-2">
            <div className="font-bold text-white flex items-center space-x-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>全产业链上中下游天然对冲机制评估</span>
            </div>
            <p className="text-slate-300 text-xs leading-relaxed">
              中国石化拥有「勘探开发 - 炼油化工 - 管道储运 - 零售氢能」完整垂直一体化结构。在高油价冲击下，上游勘探（顺北、塔河、普光）实现超额利润，有效对冲炼化端原料采购成本上涨；在新能源替代场景下，全国 3.1 万座加油站加速转型为「油气氢电服」综合能源服务站，非油业务易捷便利店与超充网络形成强劲新增量。
            </p>
          </div>
        </div>

        {/* 战略推演专家建议 (1列) */}
        <div className="bg-[#121620] border border-slate-800 rounded-lg p-4 space-y-3 text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h4 className="text-sm font-bold text-white flex items-center space-x-1.5">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>党组战略决策智库建议</span>
            </h4>
            <span className="text-[10px] bg-red-950 text-red-300 border border-red-800 px-1.5 py-0.5 rounded">
              机密决策内参
            </span>
          </div>

          <div className="space-y-2 text-slate-300">
            <div className="p-2.5 bg-[#161c28] rounded border border-slate-800">
              <div className="text-amber-400 font-bold mb-1">1. 稳油增气，加大深层勘探</div>
              <p className="text-[11px] text-slate-400">
                保持新疆顺北超深层与四川盆地普光、元坝百亿方级常规天然气高强度钻探，筑牢国家能源安全压舱石。
              </p>
            </div>

            <div className="p-2.5 bg-[#161c28] rounded border border-slate-800">
              <div className="text-cyan-400 font-bold mb-1">2. 推进「减油增化增特」</div>
              <p className="text-[11px] text-slate-400">
                加快镇海、茂名等大型基地由传统燃料型向高端聚烯烃、48K大丝束碳纤维与特种润滑油升级转型。
              </p>
            </div>

            <div className="p-2.5 bg-[#161c28] rounded border border-slate-800">
              <div className="text-emerald-400 font-bold mb-1">3. 规模化发展 CCUS 与绿氢</div>
              <p className="text-[11px] text-slate-400">
                以库车绿氢示范工程与齐鲁-胜利 CCUS 为基底，构筑百万吨级工业绿氢走廊与碳中和先导产业。
              </p>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
