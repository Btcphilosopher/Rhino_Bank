/**
 * 模块 7：炼厂数字孪生 (Refinery Digital Twin)
 * 交互式炼化一体化工艺流程、装置单元工况、原油品质调配与实时产品收率/能耗/碳排/毛利重算
 */

import React, { useState } from 'react';
import { 
  Factory, 
  Flame, 
  Activity, 
  Sliders, 
  Database, 
  TrendingUp, 
  Leaf, 
  Boxes, 
  ArrowRight,
  ShieldCheck
} from 'lucide-react';
import { DETAILED_REFINERIES, CRUDE_SLATE_OPTIONS } from '../data/mockData';

interface RefineryDigitalTwinProps {
  onOpenDataLineage: (metricName: string, displayValue: string) => void;
  onNavigateTab: (tab: any) => void;
}

export const RefineryDigitalTwin: React.FC<RefineryDigitalTwinProps> = ({
  onOpenDataLineage,
  onNavigateTab
}) => {
  const [selectedRefineryId, setSelectedRefineryId] = useState<string>('REF-01'); // 镇海炼化
  const [selectedCrudeIdx, setSelectedCrudeIdx] = useState<number>(0); // Oman
  const [cduLoadRate, setCduLoadRate] = useState<number>(92); // %
  const [activeUnitId, setActiveUnitId] = useState<string>('U-CDU4');

  const refinery = DETAILED_REFINERIES.find(r => r.id === selectedRefineryId) || DETAILED_REFINERIES[0];
  const crude = CRUDE_SLATE_OPTIONS[selectedCrudeIdx];
  const activeUnit = refinery.units.find(u => u.id === activeUnitId) || refinery.units[0];

  // 动态实时收率与经济性模型测算 (LP 模拟引擎)
  const baseThroughput = refinery.actualThroughputTonneDay * (cduLoadRate / refinery.operatingRatePercent);
  const gasolineYield = baseThroughput * (crude.yieldGasolinePercent / 100);
  const dieselYield = baseThroughput * (crude.yieldDieselPercent / 100);
  const keroseneYield = baseThroughput * (crude.yieldKerosenePercent / 100);
  const naphthaYield = baseThroughput * (crude.yieldNaphthaPercent / 100);
  const residueYield = baseThroughput * (crude.yieldResiduePercent / 100);

  // 能耗与碳排修正 (原油越轻、硫含量越低，能耗与碳排越少)
  const energyCostMJ = (refinery.integratedEnergyCostMJ * (0.95 + crude.sulfurContentPercent * 0.05) * (cduLoadRate / 90)).toFixed(1);
  const carbonEmissionDaily = (baseThroughput * (refinery.co2IntensityKgTonne / 1000) * (0.92 + crude.sulfurContentPercent * 0.08)).toFixed(0);
  
  // 炼油毛利
  const marginPerBbl = (crude.spotPriceUSD > 80 ? 14.8 : 12.5) + (crude.name.includes('ESPO') ? 2.4 : crude.name.includes('Brent') ? -0.8 : 0.0);
  const dailyProfitMillionCNY = ((baseThroughput * 7.3 * marginPerBbl * 7.25) / 1000000).toFixed(2);

  return (
    <div className="space-y-4">
      
      {/* 顶栏炼厂选择与原油调配控制器 */}
      <div className="bg-[#121620] border border-slate-800 rounded-lg p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
        
        {/* 选择炼厂 */}
        <div className="flex items-center space-x-2">
          <span className="text-slate-400 font-semibold flex items-center space-x-1">
            <Factory className="w-3.5 h-3.5 text-red-500" />
            <span>选择炼化基地:</span>
          </span>
          <select
            value={selectedRefineryId}
            onChange={(e) => setSelectedRefineryId(e.target.value)}
            className="bg-[#182030] border border-slate-700 text-slate-100 font-bold px-3 py-1.5 rounded text-xs focus:outline-none focus:border-red-500"
          >
            {DETAILED_REFINERIES.map(r => (
              <option key={r.id} value={r.id}>
                {r.name} (产能 {r.designCapacityTonneYear} 万吨/年 · {r.location})
              </option>
            ))}
          </select>
        </div>

        {/* 进料原油品种切换 (Crude Slate) */}
        <div className="flex items-center space-x-2">
          <span className="text-slate-400 font-semibold">进料原油配方 (Crude Slate):</span>
          <select
            value={selectedCrudeIdx}
            onChange={(e) => setSelectedCrudeIdx(parseInt(e.target.value))}
            className="bg-[#182030] border border-slate-700 text-amber-300 font-bold px-3 py-1 rounded text-xs focus:outline-none"
          >
            {CRUDE_SLATE_OPTIONS.map((c, i) => (
              <option key={i} value={i}>
                {c.name} (API {c.apiGravity} · 硫 {c.sulfurContentPercent}% · 到岸 ${c.cifLandedCostUSD}/bbl)
              </option>
            ))}
          </select>
        </div>

        {/* 常减压负荷滑块 */}
        <div className="flex items-center space-x-2 bg-[#161c28] px-3 py-1 rounded border border-slate-800">
          <span className="text-slate-400">CDU 加工负荷率:</span>
          <span className="font-mono font-bold text-red-400">{cduLoadRate}%</span>
          <input
            type="range"
            min="70"
            max="105"
            step="1"
            value={cduLoadRate}
            onChange={(e) => setCduLoadRate(parseInt(e.target.value))}
            className="w-24 accent-red-500"
          />
        </div>

      </div>

      {/* 实时动态测算 KPI 大盘 */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
        
        <div className="bg-[#121620] border border-slate-800 rounded-lg p-3">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span>原油实际日加工量</span>
            <button 
              onClick={() => onOpenDataLineage(`${refinery.name} 原油日加工量`, `${baseThroughput.toFixed(0)} 吨/日`)}
              className="text-slate-500 hover:text-red-400"
            >
              <Database className="w-3 h-3" />
            </button>
          </div>
          <div className="text-xl font-bold text-white font-mono">
            {baseThroughput.toFixed(0)} <span className="text-xs text-slate-400 font-normal">吨/日</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex justify-between">
            <span>折合: {(baseThroughput * 7.3 / 10000).toFixed(1)} 万桶/日</span>
            <span className="text-emerald-400">负荷 {cduLoadRate}%</span>
          </div>
        </div>

        <div className="bg-[#121620] border border-slate-800 rounded-lg p-3">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span>综合单桶炼油毛利</span>
            <button 
              onClick={() => onOpenDataLineage('综合炼油单桶毛利 GRM', `$${marginPerBbl.toFixed(2)}/桶 (LP 线性规划最优解)`)}
              className="text-slate-500 hover:text-red-400"
            >
              <Database className="w-3 h-3" />
            </button>
          </div>
          <div className="text-xl font-bold text-emerald-400 font-mono">
            ${marginPerBbl.toFixed(2)} <span className="text-xs text-slate-400 font-normal">/bbl</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex justify-between">
            <span>日度毛利折合: <strong className="text-white">¥{dailyProfitMillionCNY} 万元/日</strong></span>
          </div>
        </div>

        <div className="bg-[#121620] border border-slate-800 rounded-lg p-3">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span>吨油综合能耗</span>
            <span className="text-emerald-400 font-mono">优于标杆</span>
          </div>
          <div className="text-xl font-bold text-cyan-300 font-mono">
            {energyCostMJ} <span className="text-xs text-slate-400 font-normal">MJ/吨</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex justify-between">
            <span>新鲜水耗: {refinery.waterConsumptionTonne} t/t</span>
            <span>蒸汽平衡 100%</span>
          </div>
        </div>

        <div className="bg-[#121620] border border-slate-800 rounded-lg p-3">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span>Scope 1 装置碳排放</span>
            <span className="text-slate-400 font-mono">CCUS 协同</span>
          </div>
          <div className="text-xl font-bold text-purple-400 font-mono">
            {carbonEmissionDaily} <span className="text-xs text-slate-400 font-normal">吨 CO₂/日</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex justify-between">
            <span>碳排放强度: {refinery.co2IntensityKgTonne} kg/t</span>
            <span className="text-emerald-400">捕集率 22%</span>
          </div>
        </div>

      </div>

      {/* 工艺流程拓扑与装置单元实时交互 (Process CAD Flow Twin) */}
      <div className="bg-[#121620] border border-slate-800 rounded-lg p-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
          <div className="flex items-center space-x-2">
            <Activity className="w-4 h-4 text-red-500" />
            <h3 className="text-sm font-bold text-white">炼化一体化数字孪生工艺流 (点击装置单元查看 DCS 传感器)</h3>
          </div>
          <span className="text-xs text-slate-400">DCS / APC 先进控制闭环在线</span>
        </div>

        {/* 交互式流程图节点 */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2 text-xs">
          {refinery.units.map((unit) => {
            const isSelected = activeUnitId === unit.id;
            return (
              <div
                key={unit.id}
                onClick={() => setActiveUnitId(unit.id)}
                className={`p-3 rounded-lg border cursor-pointer transition ${
                  isSelected 
                    ? 'bg-[#1e273a] border-red-500 shadow-lg ring-2 ring-red-500/20' 
                    : 'bg-[#161c28] border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[10px] text-slate-400 font-mono">{unit.category.split(' ')[0]}</span>
                  <span className={`w-2 h-2 rounded-full ${unit.status === '正常' ? 'bg-emerald-500' : 'bg-amber-500'}`}></span>
                </div>
                <div className="font-bold text-white text-xs mb-1 truncate">{unit.name}</div>
                <div className="space-y-1 text-[11px] text-slate-300">
                  <div className="flex justify-between">
                    <span className="text-slate-400">进料负荷:</span>
                    <span className="font-mono text-cyan-300">{unit.operatingLoad}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">操作温度:</span>
                    <span className="font-mono text-amber-400">{unit.inletTemperatureC} ℃</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">出口压力:</span>
                    <span className="font-mono text-white">{unit.outletPressureMPa} MPa</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 底部两栏：选中装置工况与产品收率详细账单 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        
        {/* 选中装置单元详细参数 (1列) */}
        <div className="bg-[#121620] border border-slate-800 rounded-lg p-4 space-y-3 text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div>
              <div className="text-[11px] text-red-400 font-semibold">UNIT DCS TELEMETRY</div>
              <h4 className="text-sm font-bold text-white">{activeUnit.name}</h4>
            </div>
            <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800/60 px-1.5 py-0.5 rounded">
              {activeUnit.status}
            </span>
          </div>

          <div className="space-y-2 text-slate-300">
            <div className="flex justify-between p-2 bg-[#161c28] rounded border border-slate-800">
              <span className="text-slate-400">设计处理能力:</span>
              <span className="font-mono font-bold text-white">{activeUnit.capacityTonneDay.toLocaleString()} 吨/日</span>
            </div>
            <div className="flex justify-between p-2 bg-[#161c28] rounded border border-slate-800">
              <span className="text-slate-400">当前实际进料量:</span>
              <span className="font-mono font-bold text-cyan-300">{activeUnit.currentFeedrate.toLocaleString()} 吨/日</span>
            </div>
            <div className="flex justify-between p-2 bg-[#161c28] rounded border border-slate-800">
              <span className="text-slate-400">催化剂剩余寿命:</span>
              <span className="font-mono text-amber-400">{activeUnit.catalystLifeRemainingDays} 天 (活性指数 94%)</span>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-800">
            <button
              onClick={() => onNavigateTab('chemicals_balance')}
              className="w-full py-1.5 bg-[#182030] hover:bg-slate-800 text-slate-200 border border-slate-700 rounded text-xs transition"
            >
              查看化工物料与能量平衡 &rarr;
            </button>
          </div>
        </div>

        {/* 产物收率与质量标准表 (2列) */}
        <div className="lg:col-span-2 bg-[#121620] border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
            <h4 className="text-sm font-bold text-white">基于当前原油与负荷的产品收率实时衡算</h4>
            <span className="text-xs text-slate-400">按 GB 国标与清洁燃油标准</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="text-slate-400 border-b border-slate-800 text-[11px]">
                  <th className="py-2">主要产品名称</th>
                  <th className="py-2">测算日产量 (吨/日)</th>
                  <th className="py-2">质量收率 %</th>
                  <th className="py-2">质量执行标准与指标</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                <tr className="hover:bg-slate-800/40">
                  <td className="py-2 font-medium text-white">国VI-B 清洁汽油 (95#/98#)</td>
                  <td className="py-2 font-mono font-bold text-amber-300">{gasolineYield.toFixed(0)}</td>
                  <td className="py-2 font-mono text-white">{crude.yieldGasolinePercent}%</td>
                  <td className="py-2 text-[11px] text-slate-400">GB 17930-2016 硫 &lt; 10ppm, 烯烃 &lt; 15%</td>
                </tr>
                <tr className="hover:bg-slate-800/40">
                  <td className="py-2 font-medium text-white">国VI-B 0# 低凝柴油</td>
                  <td className="py-2 font-mono font-bold text-cyan-300">{dieselYield.toFixed(0)}</td>
                  <td className="py-2 font-mono text-white">{crude.yieldDieselPercent}%</td>
                  <td className="py-2 text-[11px] text-slate-400">GB 19147-2016 十六烷值 &gt; 51</td>
                </tr>
                <tr className="hover:bg-slate-800/40">
                  <td className="py-2 font-medium text-white">3号 Jet A-1 航空煤油</td>
                  <td className="py-2 font-mono font-bold text-white">{keroseneYield.toFixed(0)}</td>
                  <td className="py-2 font-mono text-white">{crude.yieldKerosenePercent}%</td>
                  <td className="py-2 text-[11px] text-slate-400">GB 6537 闪点 &gt; 38℃, 冰点 &lt; -47℃</td>
                </tr>
                <tr className="hover:bg-slate-800/40">
                  <td className="py-2 font-medium text-white">轻质石脑油 (优质裂解原料)</td>
                  <td className="py-2 font-mono font-bold text-purple-300">{naphthaYield.toFixed(0)}</td>
                  <td className="py-2 font-mono text-white">{crude.yieldNaphthaPercent}%</td>
                  <td className="py-2 text-[11px] text-slate-400">链烷烃含量 &gt; 72%, 送 120万吨乙烯装置</td>
                </tr>
                <tr className="hover:bg-slate-800/40">
                  <td className="py-2 font-medium text-white">减压渣油与高标号沥青</td>
                  <td className="py-2 font-mono font-bold text-slate-300">{residueYield.toFixed(0)}</td>
                  <td className="py-2 font-mono text-white">{crude.yieldResiduePercent}%</td>
                  <td className="py-2 text-[11px] text-slate-400">AH-70 高等级公路沥青 / 焦化装置原料</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

      </div>

    </div>
  );
};
