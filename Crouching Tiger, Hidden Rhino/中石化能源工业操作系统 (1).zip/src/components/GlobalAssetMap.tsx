/**
 * 模块 2：全球资产地图 (Global Asset Map)
 * 多图层筛选：油田、气田、海上平台、炼化一体化基地、主干管网、保税油库、综合能源站
 */

import React, { useState } from 'react';
import { 
  Globe, 
  Layers, 
  MapPin, 
  Filter, 
  Flame, 
  Factory, 
  GitPullRequest, 
  Boxes, 
  Fuel, 
  Zap, 
  Search,
  ExternalLink,
  ChevronRight
} from 'lucide-react';
import { GLOBAL_ASSETS, DETAILED_OILFIELDS, DETAILED_REFINERIES, PIPELINE_NETWORK, STORAGE_FACILITIES } from '../data/mockData';

interface GlobalAssetMapProps {
  onNavigateTab: (tab: any) => void;
  onOpenDataLineage: (metricName: string, displayValue: string) => void;
}

export const GlobalAssetMap: React.FC<GlobalAssetMapProps> = ({ onNavigateTab }) => {
  const [selectedCountry, setSelectedCountry] = useState<string>('CN');
  const [activeLayers, setActiveLayers] = useState({
    oilfields: true,
    refineries: true,
    pipelines: true,
    storage: true,
    stations: true
  });
  const [searchQuery, setSearchQuery] = useState('');

  const currentCountryData = GLOBAL_ASSETS.find(c => c.code === selectedCountry) || GLOBAL_ASSETS[0];

  const toggleLayer = (layerKey: keyof typeof activeLayers) => {
    setActiveLayers(prev => ({ ...prev, [layerKey]: !prev[layerKey] }));
  };

  return (
    <div className="space-y-4">
      
      {/* 顶栏图层控制与搜索 */}
      <div className="bg-[#121620] border border-slate-800 rounded-lg p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
        
        {/* 图层开关 */}
        <div className="flex items-center flex-wrap gap-2">
          <div className="flex items-center space-x-1.5 text-slate-400 font-semibold mr-1">
            <Filter className="w-3.5 h-3.5 text-red-500" />
            <span>地图实体图层:</span>
          </div>

          <button
            onClick={() => toggleLayer('oilfields')}
            className={`flex items-center space-x-1 px-2 py-1 rounded transition border ${
              activeLayers.oilfields 
                ? 'bg-amber-950/60 border-amber-600/80 text-amber-300 font-medium' 
                : 'bg-slate-900 border-slate-800 text-slate-500'
            }`}
          >
            <Flame className="w-3 h-3" />
            <span>油气田 / 海上平台 ({DETAILED_OILFIELDS.length})</span>
          </button>

          <button
            onClick={() => toggleLayer('refineries')}
            className={`flex items-center space-x-1 px-2 py-1 rounded transition border ${
              activeLayers.refineries 
                ? 'bg-red-950/60 border-red-600/80 text-red-300 font-medium' 
                : 'bg-slate-900 border-slate-800 text-slate-500'
            }`}
          >
            <Factory className="w-3 h-3" />
            <span>炼化一体化基地 ({DETAILED_REFINERIES.length})</span>
          </button>

          <button
            onClick={() => toggleLayer('pipelines')}
            className={`flex items-center space-x-1 px-2 py-1 rounded transition border ${
              activeLayers.pipelines 
                ? 'bg-blue-950/60 border-blue-600/80 text-blue-300 font-medium' 
                : 'bg-slate-900 border-slate-800 text-slate-500'
            }`}
          >
            <GitPullRequest className="w-3 h-3" />
            <span>主干输油气管道 ({PIPELINE_NETWORK.length})</span>
          </button>

          <button
            onClick={() => toggleLayer('storage')}
            className={`flex items-center space-x-1 px-2 py-1 rounded transition border ${
              activeLayers.storage 
                ? 'bg-purple-950/60 border-purple-600/80 text-purple-300 font-medium' 
                : 'bg-slate-900 border-slate-800 text-slate-500'
            }`}
          >
            <Boxes className="w-3 h-3" />
            <span>战略油气储气库 ({STORAGE_FACILITIES.length})</span>
          </button>
        </div>

        {/* 快速定位搜索 */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-2.5 top-2 text-slate-500" />
          <input
            type="text"
            placeholder="搜索油田/炼厂/管道名称..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-[#0b0e14] border border-slate-800 rounded pl-8 pr-3 py-1 text-slate-200 placeholder-slate-500 text-xs w-56 focus:outline-none focus:border-red-500"
          />
        </div>

      </div>

      {/* 主地图展示与右侧资产详情双栏 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        
        {/* 全球工业地理沙盘 (2列宽) */}
        <div className="lg:col-span-2 bg-[#121620] border border-slate-800 rounded-lg p-4 relative overflow-hidden flex flex-col justify-between min-h-[500px]">
          
          {/* 地图顶层标识 */}
          <div className="flex items-center justify-between z-10">
            <div className="flex items-center space-x-2">
              <Globe className="w-4 h-4 text-red-500" />
              <span className="text-sm font-bold text-white">中国石化全球资产拓扑地图 (SEIOS Geographic Core)</span>
            </div>
            <span className="text-[11px] text-slate-400 bg-[#161c28] px-2 py-0.5 rounded border border-slate-800">
              投影坐标系: WGS-84 / 工业GIS拓扑层
            </span>
          </div>

          {/* 工业地图视觉渲染区 (高质量工业暗黑底图交互) */}
          <div className="my-3 w-full flex-1 rounded bg-[#0a0d13] border border-slate-800 relative overflow-hidden flex items-center justify-center p-4">
            
            {/* 经纬度网格线 */}
            <div className="absolute inset-0 opacity-15 pointer-events-none grid grid-cols-6 grid-rows-4 divide-x divide-y divide-cyan-500">
              {Array.from({ length: 24 }).map((_, i) => (
                <div key={i} className="border-cyan-500/20"></div>
              ))}
            </div>

            {/* 世界大陆轮廓示意 SVG */}
            <svg viewBox="0 0 1000 500" className="w-full h-full opacity-40">
              <path 
                d="M150,120 Q180,80 250,90 T350,150 T280,240 T180,210 Z" 
                fill="#1e293b" stroke="#334155" strokeWidth="1.5" 
              />
              <path 
                d="M250,280 Q290,260 320,310 T300,420 T240,400 T230,300 Z" 
                fill="#1e293b" stroke="#334155" strokeWidth="1.5" 
              />
              <path 
                d="M480,90 Q560,70 650,100 T720,130 T640,210 T520,180 Z" 
                fill="#1e293b" stroke="#334155" strokeWidth="1.5" 
              />
              <path 
                d="M490,200 Q560,190 580,260 T560,380 T480,320 T460,220 Z" 
                fill="#1e293b" stroke="#334155" strokeWidth="1.5" 
              />
              <path 
                d="M650,110 Q780,80 880,120 T920,240 T800,280 T680,220 Z" 
                fill="#1e293b" stroke="#334155" strokeWidth="1.5" 
              />
              <path 
                d="M780,330 Q860,320 880,380 T800,430 T750,370 Z" 
                fill="#1e293b" stroke="#334155" strokeWidth="1.5" 
              />
              {/* 主干航运与管道物流线 */}
              <path 
                d="M620,190 Q720,240 760,200" 
                fill="none" stroke="#38bdf8" strokeWidth="2" strokeDasharray="4 4" 
              />
              <path 
                d="M510,310 Q620,320 750,210" 
                fill="none" stroke="#f59e0b" strokeWidth="2" strokeDasharray="4 4" 
              />
            </svg>

            {/* 动态资产锚点 */}
            {GLOBAL_ASSETS.map((asset) => {
              // 简易将经纬度映射到比例尺寸
              const xPercent = ((asset.lng + 180) / 360) * 100;
              const yPercent = ((90 - asset.lat) / 180) * 100;
              const isSelected = selectedCountry === asset.code;

              return (
                <div
                  key={asset.code}
                  style={{ left: `${xPercent}%`, top: `${yPercent}%` }}
                  onClick={() => setSelectedCountry(asset.code)}
                  className={`absolute -translate-x-1/2 -translate-y-1/2 cursor-pointer group transition duration-200 z-20`}
                >
                  <div className={`flex items-center space-x-1 px-1.5 py-0.5 rounded-full border shadow-lg ${
                    isSelected 
                      ? 'bg-red-600 border-white text-white ring-4 ring-red-500/30 scale-110' 
                      : 'bg-[#161c28]/90 border-slate-700 text-slate-200 hover:border-red-500'
                  }`}>
                    <span className="text-xs">{asset.flag}</span>
                    <span className="text-[10px] font-bold whitespace-nowrap">{asset.name.split(' ')[0]}</span>
                  </div>

                  {/* 悬浮气泡预览 */}
                  <div className="hidden group-hover:block absolute left-1/2 -translate-x-1/2 bottom-full mb-2 bg-[#121620] border border-slate-700 text-slate-200 p-2.5 rounded shadow-2xl w-48 text-[11px] z-30 pointer-events-none">
                    <div className="font-bold text-white border-b border-slate-800 pb-1 mb-1">
                      {asset.name}
                    </div>
                    <div className="text-amber-400">原油日产: {(asset.dailyProductionOilBbl / 10000).toFixed(1)} 万桶/日</div>
                    <div className="text-cyan-400">天然气: {(asset.dailyGasM3 / 10000).toFixed(0)} 万方/日</div>
                    <div className="text-slate-400 mt-1">在役油气田: {asset.oilfieldsCount} 座</div>
                  </div>
                </div>
              );
            })}

          </div>

          {/* 底部图例说明 */}
          <div className="flex flex-wrap items-center justify-between text-[11px] text-slate-400 bg-[#161c28] p-2 rounded border border-slate-800">
            <div className="flex items-center space-x-4">
              <span className="flex items-center space-x-1">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
                <span>上游产区 (胜利/顺北/中东)</span>
              </span>
              <span className="flex items-center space-x-1">
                <span className="w-2.5 h-2.5 rounded-full bg-red-500"></span>
                <span>炼化基地 (镇海/茂名/上海)</span>
              </span>
              <span className="flex items-center space-x-1">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span>
                <span>保税储备港口 (舟山岙山)</span>
              </span>
            </div>
            <span className="text-slate-500">点击任意国家锚点查看驻地资产详情</span>
          </div>

        </div>

        {/* 右侧：选中国家/地区资产档案与下钻通道 */}
        <div className="bg-[#121620] border border-slate-800 rounded-lg p-4 flex flex-col justify-between">
          <div>
            
            {/* 资产所属国标题 */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
              <div className="flex items-center space-x-2">
                <span className="text-2xl">{currentCountryData.flag}</span>
                <div>
                  <h3 className="text-sm font-bold text-white">{currentCountryData.name}</h3>
                  <span className="text-[11px] text-slate-400">{currentCountryData.continent} · 投资总额 ${currentCountryData.investmentAmountUSD} 亿美元</span>
                </div>
              </div>
              <span className={`px-2 py-0.5 rounded text-[11px] font-medium ${
                currentCountryData.riskLevel === '低风险' 
                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-800/60' 
                  : 'bg-amber-950 text-amber-300 border border-amber-800/60'
              }`}>
                {currentCountryData.riskLevel}
              </span>
            </div>

            {/* 关键生产能力卡片 */}
            <div className="grid grid-cols-2 gap-2 mb-4 text-xs">
              <div className="bg-[#161c28] p-2.5 rounded border border-slate-800">
                <div className="text-slate-400">原油日产配额</div>
                <div className="text-base font-bold text-amber-400 font-mono mt-0.5">
                  {currentCountryData.dailyProductionOilBbl.toLocaleString()} <span className="text-[10px] text-slate-400">bbl/d</span>
                </div>
              </div>
              <div className="bg-[#161c28] p-2.5 rounded border border-slate-800">
                <div className="text-slate-400">天然气日产能力</div>
                <div className="text-base font-bold text-cyan-400 font-mono mt-0.5">
                  {(currentCountryData.dailyGasM3 / 10000).toFixed(0)} <span className="text-[10px] text-slate-400">万方/d</span>
                </div>
              </div>
              <div className="bg-[#161c28] p-2.5 rounded border border-slate-800">
                <div className="text-slate-400">在产油气田</div>
                <div className="text-sm font-bold text-white font-mono mt-0.5">
                  {currentCountryData.oilfieldsCount} 座
                </div>
              </div>
              <div className="bg-[#161c28] p-2.5 rounded border border-slate-800">
                <div className="text-slate-400">炼厂 / 合作厂</div>
                <div className="text-sm font-bold text-white font-mono mt-0.5">
                  {currentCountryData.refineriesCount} 座
                </div>
              </div>
            </div>

            {/* 核心项目与资产清单 */}
            <div className="space-y-2">
              <div className="text-xs font-semibold text-slate-300 flex items-center justify-between">
                <span>该区域重点工程与合作项目</span>
                <span className="text-[10px] text-slate-500">{currentCountryData.keyProjects.length} 个重大实体</span>
              </div>
              
              <div className="space-y-1.5">
                {currentCountryData.keyProjects.map((project, idx) => (
                  <div 
                    key={idx}
                    className="p-2 bg-[#161c28] hover:bg-[#1c2434] border border-slate-800 rounded text-xs text-slate-200 flex items-center justify-between transition"
                  >
                    <div className="flex items-center space-x-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-red-500"></span>
                      <span className="font-medium">{project}</span>
                    </div>
                    <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
                  </div>
                ))}
              </div>
            </div>

          </div>

          {/* 快捷跳转该区域数字孪生 */}
          <div className="mt-4 pt-3 border-t border-slate-800 flex items-center gap-2">
            <button
              onClick={() => onNavigateTab('production')}
              className="flex-1 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded text-xs font-medium transition flex items-center justify-center space-x-1"
            >
              <span>查看上游油气生产中心</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => onNavigateTab('refinery_twin')}
              className="flex-1 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs font-medium transition flex items-center justify-center space-x-1"
            >
              <span>进入炼厂数字孪生</span>
            </button>
          </div>

        </div>

      </div>

    </div>
  );
};
