/**
 * 模块 1：中国石化全球能源控制中心 (集团总览)
 * 100% 简体中文，高密度工业控制台与数据溯源
 */

import React from 'react';
import { 
  Flame, 
  Factory, 
  Fuel, 
  Boxes, 
  Zap, 
  Leaf, 
  ShieldCheck, 
  TrendingUp, 
  Activity, 
  AlertTriangle,
  ArrowUpRight,
  Database,
  ArrowRight,
  Info,
  GitPullRequest
} from 'lucide-react';
import { GROUP_CORE_METRICS, GLOBAL_ASSETS, DETAILED_OILFIELDS, DETAILED_REFINERIES } from '../data/mockData';
import { MetricUnit } from '../types';

interface GlobalOverviewProps {
  onOpenDataLineage: (metricName: string, displayValue: string) => void;
  onNavigateTab: (tab: any) => void;
  currentUnit: MetricUnit;
}

export const GlobalOverview: React.FC<GlobalOverviewProps> = ({
  onOpenDataLineage,
  onNavigateTab,
  currentUnit,
}) => {
  // 单位换算显示逻辑
  const formatOil = (bbl: number) => {
    if (currentUnit === 't') return `${(bbl * 0.137).toFixed(1)} 万吨/日`;
    return `${(bbl / 10000).toFixed(2)} 万桶/日`;
  };

  const formatGas = (m3: number) => {
    if (currentUnit === 'bbl') return `${((m3 / 1000000) * 0.167).toFixed(2)} 百万桶油当量/日`;
    return `${(m3 / 100000000).toFixed(2)} 亿方/日`;
  };

  return (
    <div className="space-y-4">
      
      {/* 顶部警报与核心运行概况横幅 */}
      <div className="bg-[#121620] border border-slate-800 rounded-lg p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2 px-2.5 py-1 bg-emerald-950/60 border border-emerald-800/60 rounded text-emerald-400 font-semibold">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            <span>全局生产调度：平稳运行中</span>
          </div>
          <span className="text-slate-400">
            在产油气田 <strong className="text-slate-200">{DETAILED_OILFIELDS.length}</strong> 座 | 
            在运大型炼化基地 <strong className="text-slate-200">{DETAILED_REFINERIES.length}</strong> 座 | 
            关键在役管网 <strong className="text-slate-200">34,500 km</strong> | 
            智慧零售网络 <strong className="text-slate-200">5,240</strong> 座
          </span>
        </div>
        <div className="flex items-center space-x-2">
          <span className="text-slate-500">点击任意卡片右上方</span>
          <span className="inline-flex items-center text-[11px] text-red-400 bg-red-950/50 border border-red-800/40 px-1.5 py-0.5 rounded">
            <Database className="w-3 h-3 mr-1" /> 溯源
          </span>
          <span className="text-slate-500">可穿透查看一次传感器与计算公式</span>
        </div>
      </div>

      {/* 12大核心指标卡片矩阵 */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        
        {/* 1. 原油日产量 */}
        <div className="bg-[#121620] border border-slate-800/80 hover:border-slate-700 rounded-lg p-3 transition shadow-sm relative group">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span className="flex items-center space-x-1">
              <Flame className="w-3.5 h-3.5 text-amber-500" />
              <span>全球原油日产</span>
            </span>
            <button 
              onClick={() => onOpenDataLineage('全球原油日产量', formatOil(GROUP_CORE_METRICS.oilProductionDaily))}
              className="text-slate-500 hover:text-red-400 p-0.5 rounded transition"
              title="查看数据血缘"
            >
              <Database className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="text-lg font-bold text-white tracking-tight">
            {formatOil(GROUP_CORE_METRICS.oilProductionDaily)}
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-400 mt-1">
            <span className="text-emerald-400 flex items-center">
              <ArrowUpRight className="w-3 h-3" /> +1.2% 同比
            </span>
            <span className="text-slate-500">在产井 2,180 口</span>
          </div>
        </div>

        {/* 2. 天然气日产 */}
        <div className="bg-[#121620] border border-slate-800/80 hover:border-slate-700 rounded-lg p-3 transition shadow-sm relative group">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span className="flex items-center space-x-1">
              <Zap className="w-3.5 h-3.5 text-cyan-400" />
              <span>天然气日产</span>
            </span>
            <button 
              onClick={() => onOpenDataLineage('天然气日产量', formatGas(GROUP_CORE_METRICS.gasProductionDaily))}
              className="text-slate-500 hover:text-red-400 p-0.5 rounded transition"
              title="查看数据血缘"
            >
              <Database className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="text-lg font-bold text-white tracking-tight">
            {formatGas(GROUP_CORE_METRICS.gasProductionDaily)}
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-400 mt-1">
            <span className="text-emerald-400 flex items-center">
              <ArrowUpRight className="w-3 h-3" /> +4.8% 增储上产
            </span>
            <span className="text-slate-500">川气/涪陵贡献68%</span>
          </div>
        </div>

        {/* 3. 炼油日加工量 */}
        <div className="bg-[#121620] border border-slate-800/80 hover:border-slate-700 rounded-lg p-3 transition shadow-sm relative group">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span className="flex items-center space-x-1">
              <Factory className="w-3.5 h-3.5 text-blue-400" />
              <span>炼油日加工量</span>
            </span>
            <button 
              onClick={() => onOpenDataLineage('炼油日加工量', '685.0 万桶/日 (93.8 万吨/日)')}
              className="text-slate-500 hover:text-red-400 p-0.5 rounded transition"
              title="查看数据血缘"
            >
              <Database className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="text-lg font-bold text-white tracking-tight">
            93.8 <span className="text-xs font-normal text-slate-400">万吨/日</span>
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-400 mt-1">
            <span className="text-slate-300">开工负荷 88.4%</span>
            <span className="text-emerald-400">+0.6%</span>
          </div>
        </div>

        {/* 4. 化工品与乙烯产出 */}
        <div className="bg-[#121620] border border-slate-800/80 hover:border-slate-700 rounded-lg p-3 transition shadow-sm relative group">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span className="flex items-center space-x-1">
              <Boxes className="w-3.5 h-3.5 text-purple-400" />
              <span>核心化工品日产</span>
            </span>
            <button 
              onClick={() => onOpenDataLineage('核心化工品日产量', '19.84 万吨/日')}
              className="text-slate-500 hover:text-red-400 p-0.5 rounded transition"
              title="查看数据血缘"
            >
              <Database className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="text-lg font-bold text-white tracking-tight">
            19.84 <span className="text-xs font-normal text-slate-400">万吨/日</span>
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-400 mt-1">
            <span className="text-purple-400">乙烯负荷 94.2%</span>
            <span className="text-slate-500">高端料 28%</span>
          </div>
        </div>

        {/* 5. 成品油终端销量 */}
        <div className="bg-[#121620] border border-slate-800/80 hover:border-slate-700 rounded-lg p-3 transition shadow-sm relative group">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span className="flex items-center space-x-1">
              <Fuel className="w-3.5 h-3.5 text-red-500" />
              <span>成品油日销量</span>
            </span>
            <button 
              onClick={() => onOpenDataLineage('成品油日销量', '42.5 万吨/日')}
              className="text-slate-500 hover:text-red-400 p-0.5 rounded transition"
              title="查看数据血缘"
            >
              <Database className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="text-lg font-bold text-white tracking-tight">
            42.50 <span className="text-xs font-normal text-slate-400">万吨/日</span>
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-400 mt-1">
            <span className="text-emerald-400">产销率 101.2%</span>
            <span className="text-slate-500">零售率 72%</span>
          </div>
        </div>

        {/* 6. 原油战略与商业库存 */}
        <div className="bg-[#121620] border border-slate-800/80 hover:border-slate-700 rounded-lg p-3 transition shadow-sm relative group">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span className="flex items-center space-x-1">
              <Boxes className="w-3.5 h-3.5 text-amber-400" />
              <span>原油储备库存</span>
            </span>
            <button 
              onClick={() => onOpenDataLineage('原油储备库存总量', '8,450 万桶 (81.2% 库容比)')}
              className="text-slate-500 hover:text-red-400 p-0.5 rounded transition"
              title="查看数据血缘"
            >
              <Database className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="text-lg font-bold text-white tracking-tight">
            8,450 <span className="text-xs font-normal text-slate-400">万桶</span>
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-400 mt-1">
            <span className="text-amber-400">库容比 81.2%</span>
            <span className="text-slate-500">保障 92 天</span>
          </div>
        </div>

        {/* 7. 天然气有效储气量 */}
        <div className="bg-[#121620] border border-slate-800/80 hover:border-slate-700 rounded-lg p-3 transition shadow-sm relative group">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span className="flex items-center space-x-1">
              <Zap className="w-3.5 h-3.5 text-cyan-300" />
              <span>管网与储气库容</span>
            </span>
            <button 
              onClick={() => onOpenDataLineage('储气库与管网管存量', '46.8 亿立方米 (86.5% 饱和度)')}
              className="text-slate-500 hover:text-red-400 p-0.5 rounded transition"
              title="查看数据血缘"
            >
              <Database className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="text-lg font-bold text-white tracking-tight">
            46.80 <span className="text-xs font-normal text-slate-400">亿方</span>
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-400 mt-1">
            <span className="text-cyan-400">饱和度 86.5%</span>
            <span className="text-slate-500">冬季保供备用</span>
          </div>
        </div>

        {/* 8. 吨油加工能耗 */}
        <div className="bg-[#121620] border border-slate-800/80 hover:border-slate-700 rounded-lg p-3 transition shadow-sm relative group">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span className="flex items-center space-x-1">
              <Activity className="w-3.5 h-3.5 text-emerald-400" />
              <span>吨油加工综合能耗</span>
            </span>
            <button 
              onClick={() => onOpenDataLineage('吨油综合加工能耗', '574.0 MJ/吨 (优于国标)')}
              className="text-slate-500 hover:text-red-400 p-0.5 rounded transition"
              title="查看数据血缘"
            >
              <Database className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="text-lg font-bold text-white tracking-tight">
            574.0 <span className="text-xs font-normal text-slate-400">MJ/t</span>
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-400 mt-1">
            <span className="text-emerald-400">-12 MJ 同比节能量</span>
            <span className="text-slate-500">行业标杆</span>
          </div>
        </div>

        {/* 9. 碳排与CCUS封存 */}
        <div className="bg-[#121620] border border-slate-800/80 hover:border-slate-700 rounded-lg p-3 transition shadow-sm relative group">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span className="flex items-center space-x-1">
              <Leaf className="w-3.5 h-3.5 text-emerald-500" />
              <span>CCUS 日碳捕集封存</span>
            </span>
            <button 
              onClick={() => onOpenDataLineage('CCUS 碳捕集与驱油封存量', '13,500 吨/日')}
              className="text-slate-500 hover:text-red-400 p-0.5 rounded transition"
              title="查看数据血缘"
            >
              <Database className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="text-lg font-bold text-white tracking-tight">
            1.35 <span className="text-xs font-normal text-slate-400">万吨/日</span>
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-400 mt-1">
            <span className="text-emerald-400">齐鲁-胜利示范工程</span>
            <span className="text-slate-500">封存率 98%</span>
          </div>
        </div>

        {/* 10. 设备健康可用率 */}
        <div className="bg-[#121620] border border-slate-800/80 hover:border-slate-700 rounded-lg p-3 transition shadow-sm relative group">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span className="flex items-center space-x-1">
              <Activity className="w-3.5 h-3.5 text-cyan-400" />
              <span>关键动设备可用率</span>
            </span>
            <button 
              onClick={() => onOpenDataLineage('关键大型动设备健康可用率', '98.7%')}
              className="text-slate-500 hover:text-red-400 p-0.5 rounded transition"
              title="查看数据血缘"
            >
              <Database className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="text-lg font-bold text-white tracking-tight">
            98.7%
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-400 mt-1">
            <span className="text-slate-300">在线监控 5,200 台</span>
            <span className="text-emerald-400">无非计划停机</span>
          </div>
        </div>

        {/* 11. HSE 安全连续天数 */}
        <div className="bg-[#121620] border border-slate-800/80 hover:border-slate-700 rounded-lg p-3 transition shadow-sm relative group">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span className="flex items-center space-x-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>HSE 零事故连续运行</span>
            </span>
            <button 
              onClick={() => onOpenDataLineage('HSE 安全生产记录', '1,420 天连续无重大责任安全事故')}
              className="text-slate-500 hover:text-red-400 p-0.5 rounded transition"
              title="查看数据血缘"
            >
              <Database className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="text-lg font-bold text-emerald-400 tracking-tight">
            1,420 <span className="text-xs font-normal text-slate-400">天</span>
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-400 mt-1">
            <span className="text-emerald-400">一级危险源受控 100%</span>
            <span className="text-slate-500">零火灾</span>
          </div>
        </div>

        {/* 12. 经营分析 EBITDA */}
        <div className="bg-[#121620] border border-slate-800/80 hover:border-slate-700 rounded-lg p-3 transition shadow-sm relative group">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span className="flex items-center space-x-1">
              <TrendingUp className="w-3.5 h-3.5 text-amber-500" />
              <span>经营效益 (YTD EBITDA)</span>
            </span>
            <button 
              onClick={() => onOpenDataLineage('年初至今 EBITDA 经营效益', '3,420.8 亿元 (炼化毛利 14.8 美元/桶)')}
              className="text-slate-500 hover:text-red-400 p-0.5 rounded transition"
              title="查看数据血缘"
            >
              <Database className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="text-lg font-bold text-white tracking-tight">
            3,420.8 <span className="text-xs font-normal text-slate-400">亿元</span>
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-400 mt-1">
            <span className="text-emerald-400">综合炼油毛利 $14.8/bbl</span>
          </div>
        </div>

      </div>

      {/* 核心业务板块全景流向与平衡中枢 */}
      <div className="bg-[#121620] border border-slate-800 rounded-lg p-4">
        <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
          <div className="flex items-center space-x-2">
            <Activity className="w-4 h-4 text-red-500" />
            <h2 className="text-sm font-bold text-white">中国石化全产业链全景物料流与协同运行拓扑</h2>
            <span className="text-[11px] text-slate-400 bg-slate-800 px-2 py-0.5 rounded">从井口到车头 · 实时物质与能量平衡</span>
          </div>
          <span className="text-xs text-slate-400">
            日均全系统吞吐质量守恒偏差: <strong className="text-emerald-400">0.08% (合格)</strong>
          </span>
        </div>

        {/* 工业拓扑卡片流程 */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 text-xs">
          
          {/* 上游勘探开发 */}
          <div 
            onClick={() => onNavigateTab('production')}
            className="p-3 bg-[#161c28] hover:bg-[#1a2333] border border-amber-900/30 rounded-lg cursor-pointer transition group"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="font-bold text-amber-400 flex items-center space-x-1">
                <Flame className="w-4 h-4" />
                <span>1. 上游勘探开发</span>
              </span>
              <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-white transition" />
            </div>
            <div className="space-y-1.5 text-slate-300">
              <div className="flex justify-between">
                <span className="text-slate-400">顺北/塔河/胜利:</span>
                <span className="font-mono font-bold text-white">124.58 万桶/日</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">普光/涪陵天然气:</span>
                <span className="font-mono font-bold text-cyan-300">2.95 亿方/日</span>
              </div>
              <div className="flex justify-between text-[11px]">
                <span className="text-slate-400">平均综合含水率:</span>
                <span className="text-amber-400">34.2%</span>
              </div>
            </div>
          </div>

          {/* 中游管网与港口储运 */}
          <div 
            onClick={() => onNavigateTab('pipeline_twin')}
            className="p-3 bg-[#161c28] hover:bg-[#1a2333] border border-blue-900/30 rounded-lg cursor-pointer transition group"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="font-bold text-blue-400 flex items-center space-x-1">
                <GitPullRequest className="w-4 h-4" />
                <span>2. 中游储运与管网</span>
              </span>
              <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-white transition" />
            </div>
            <div className="space-y-1.5 text-slate-300">
              <div className="flex justify-between">
                <span className="text-slate-400">川气东送主干:</span>
                <span className="font-mono text-cyan-300">154万方/h (8.8MPa)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">仪长/鲁皖原油管线:</span>
                <span className="font-mono font-bold text-white">1,770 m³/h</span>
              </div>
              <div className="flex justify-between text-[11px]">
                <span className="text-slate-400">舟山岙山原油库容:</span>
                <span className="text-blue-400">3,850 万桶 (85.5%)</span>
              </div>
            </div>
          </div>

          {/* 下游炼油加工 */}
          <div 
            onClick={() => onNavigateTab('refinery_twin')}
            className="p-3 bg-[#161c28] hover:bg-[#1a2333] border border-red-900/30 rounded-lg cursor-pointer transition group"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="font-bold text-red-400 flex items-center space-x-1">
                <Factory className="w-4 h-4" />
                <span>3. 炼油加工与转化</span>
              </span>
              <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-white transition" />
            </div>
            <div className="space-y-1.5 text-slate-300">
              <div className="flex justify-between">
                <span className="text-slate-400">五大基地原油加工:</span>
                <span className="font-mono font-bold text-white">93.8 万吨/日</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">清洁汽柴航煤收率:</span>
                <span className="font-mono text-emerald-400">62.8%</span>
              </div>
              <div className="flex justify-between text-[11px]">
                <span className="text-slate-400">炼厂开工负荷率:</span>
                <span className="text-red-400">88.4% (平稳)</span>
              </div>
            </div>
          </div>

          {/* 化工与高新材料 */}
          <div 
            onClick={() => onNavigateTab('chemicals_balance')}
            className="p-3 bg-[#161c28] hover:bg-[#1a2333] border border-purple-900/30 rounded-lg cursor-pointer transition group"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="font-bold text-purple-400 flex items-center space-x-1">
                <Boxes className="w-4 h-4" />
                <span>4. 化工与高新材料</span>
              </span>
              <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-white transition" />
            </div>
            <div className="space-y-1.5 text-slate-300">
              <div className="flex justify-between">
                <span className="text-slate-400">乙烯及衍生物日产:</span>
                <span className="font-mono font-bold text-purple-300">19.84 万吨/日</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">芳烃PX与PTA原料:</span>
                <span className="font-mono text-white">5,200 吨/日</span>
              </div>
              <div className="flex justify-between text-[11px]">
                <span className="text-slate-400">碳纤维大丝束(48K):</span>
                <span className="text-purple-400">450 吨/日</span>
              </div>
            </div>
          </div>

          {/* 智慧零售与氢能新能源 */}
          <div 
            onClick={() => onNavigateTab('retail_station')}
            className="p-3 bg-[#161c28] hover:bg-[#1a2333] border border-emerald-900/30 rounded-lg cursor-pointer transition group"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="font-bold text-emerald-400 flex items-center space-x-1">
                <Fuel className="w-4 h-4" />
                <span>5. 终端零售与新能源</span>
              </span>
              <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-white transition" />
            </div>
            <div className="space-y-1.5 text-slate-300">
              <div className="flex justify-between">
                <span className="text-slate-400">成品油全国销售:</span>
                <span className="font-mono font-bold text-white">42.50 万吨/日</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">智慧加氢站日加氢:</span>
                <span className="font-mono text-cyan-300">18.5 吨/日</span>
              </div>
              <div className="flex justify-between text-[11px]">
                <span className="text-slate-400">极速超充日用电量:</span>
                <span className="text-emerald-400">342 万 kWh</span>
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* 底部两栏：全球资产分布概况与今日运行调度令 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        
        {/* 全球核心国家资产列表 (2列宽) */}
        <div className="lg:col-span-2 bg-[#121620] border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
            <h3 className="text-sm font-bold text-white flex items-center space-x-2">
              <span>全球10个重点国家与海外运营区</span>
              <span className="text-[11px] text-slate-500 font-normal">点击可快速穿透至该国数字孪生</span>
            </h3>
            <button 
              onClick={() => onNavigateTab('asset_map')}
              className="text-xs text-red-400 hover:text-red-300 flex items-center space-x-1"
            >
              <span>查看全球三维地图</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="text-slate-400 border-b border-slate-800 text-[11px]">
                  <th className="py-2">国家 / 地区</th>
                  <th className="py-2">大洲</th>
                  <th className="py-2">油气田</th>
                  <th className="py-2">炼化基地</th>
                  <th className="py-2">原油日产 (bbl)</th>
                  <th className="py-2">天然气日产 (m³)</th>
                  <th className="py-2">投资额 (亿美元)</th>
                  <th className="py-2">风险等级</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                {GLOBAL_ASSETS.map((country) => (
                  <tr 
                    key={country.code} 
                    onClick={() => onNavigateTab('asset_map')}
                    className="hover:bg-slate-800/50 cursor-pointer transition"
                  >
                    <td className="py-2.5 font-medium text-white flex items-center space-x-1.5">
                      <span>{country.flag}</span>
                      <span>{country.name}</span>
                    </td>
                    <td className="py-2.5 text-slate-400">{country.continent}</td>
                    <td className="py-2.5 font-mono">{country.oilfieldsCount}</td>
                    <td className="py-2.5 font-mono">{country.refineriesCount}</td>
                    <td className="py-2.5 font-mono font-bold text-amber-300">{country.dailyProductionOilBbl.toLocaleString()}</td>
                    <td className="py-2.5 font-mono text-cyan-300">{(country.dailyGasM3 / 10000).toFixed(0)} 万</td>
                    <td className="py-2.5 font-mono">${country.investmentAmountUSD}</td>
                    <td className="py-2.5">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                        country.riskLevel === '低风险' 
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800/50' 
                          : country.riskLevel === '中等'
                          ? 'bg-amber-950 text-amber-300 border border-amber-800/50'
                          : 'bg-red-950 text-red-300 border border-red-800/50'
                      }`}>
                        {country.riskLevel}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* 智能生产调度日志与告警跟踪 (1列宽) */}
        <div className="bg-[#121620] border border-slate-800 rounded-lg p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
              <h3 className="text-sm font-bold text-white flex items-center space-x-2">
                <AlertTriangle className="w-4 h-4 text-amber-400" />
                <span>调度中心事件与智能建议</span>
              </h3>
              <span className="text-[10px] bg-red-950 text-red-400 px-1.5 py-0.5 rounded">实时监听</span>
            </div>

            <div className="space-y-2.5 text-xs">
              
              {/* 事件 1 */}
              <div className="p-2.5 bg-[#161c28] border-l-2 border-amber-500 rounded-r">
                <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                  <span className="font-semibold text-amber-300">油田开发预警 · 胜科1井 (WELL-003)</span>
                  <span className="font-mono">10:35</span>
                </div>
                <p className="text-slate-300 text-[11px]">
                  东辛区块胜科1井含水率突升至 73.8%，压力下降至 10.4 MPa。已建议协同降低对应注水井胜注-104注入量 15%。
                </p>
                <div className="mt-1.5 flex justify-end">
                  <button 
                    onClick={() => onNavigateTab('well_drilling')}
                    className="text-[11px] text-amber-400 hover:underline"
                  >
                    前往单井诊断 &rarr;
                  </button>
                </div>
              </div>

              {/* 事件 2 */}
              <div className="p-2.5 bg-[#161c28] border-l-2 border-cyan-500 rounded-r">
                <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                  <span className="font-semibold text-cyan-300">管网调度指令 · 川气东送全线增压</span>
                  <span className="font-mono">09:15</span>
                </div>
                <p className="text-slate-300 text-[11px]">
                  华东地区受冷空气影响用气需求预测上涨 8%，普光首站压缩机出口压力调节至 8.8 MPa，管存增储完成。
                </p>
                <div className="mt-1.5 flex justify-end">
                  <button 
                    onClick={() => onNavigateTab('pipeline_twin')}
                    className="text-[11px] text-cyan-400 hover:underline"
                  >
                    查看水力管存 &rarr;
                  </button>
                </div>
              </div>

              {/* 事件 3 */}
              <div className="p-2.5 bg-[#161c28] border-l-2 border-purple-500 rounded-r">
                <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                  <span className="font-semibold text-purple-300">炼化经济优化 · 镇海进料组分优化</span>
                  <span className="font-mono">08:00</span>
                </div>
                <p className="text-slate-300 text-[11px]">
                  Crude Slate 优化器建议今日掺炼 25% ESPO 原油，测算综合单桶炼油毛利提升 $0.85/bbl。
                </p>
                <div className="mt-1.5 flex justify-end">
                  <button 
                    onClick={() => onNavigateTab('refinery_twin')}
                    className="text-[11px] text-purple-400 hover:underline"
                  >
                    查看优化报告 &rarr;
                  </button>
                </div>
              </div>

            </div>
          </div>

          <div className="mt-3 pt-2 border-t border-slate-800 text-[11px] text-slate-500 flex items-center justify-between">
            <span>安全审计：OT指令受控防呆隔离</span>
            <span className="text-emerald-400">双人授权审核已就绪</span>
          </div>
        </div>

      </div>

    </div>
  );
};
