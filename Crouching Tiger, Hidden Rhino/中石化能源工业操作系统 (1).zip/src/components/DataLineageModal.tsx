/**
 * 数据血缘与溯源查看器 (Data Lineage Inspector)
 * 允许用户点击任意工业指标或数据点，透明查看原始数据源、传感器ID、计算公式与模型版本
 */

import React from 'react';
import { DataLineage } from '../types';
import { ShieldCheck, Activity, Database, Cpu, Layers, GitCommit, FileText, X } from 'lucide-react';

interface DataLineageModalProps {
  lineage: DataLineage | null;
  onClose: () => void;
}

export const DataLineageModal: React.FC<DataLineageModalProps> = ({ lineage, onClose }) => {
  if (!lineage) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
      <div className="bg-[#12161f] border border-slate-700 rounded-lg max-w-3xl w-full text-slate-200 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* 头部 */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-[#161c28]">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded bg-red-600/20 text-red-500 border border-red-600/40 flex items-center justify-center">
              <Database className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xs font-semibold text-red-400 tracking-wider">SEIOS 工业数据血缘与计算溯源</span>
                <span className="text-[10px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded">审计可追溯</span>
              </div>
              <h3 className="text-base font-bold text-white mt-0.5">{lineage.metricName}</h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 内容区 */}
        <div className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          
          {/* 核心值与标准转换 */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 bg-[#0d1117] p-4 rounded-md border border-slate-800">
            <div>
              <div className="text-xs text-slate-400">展示数值</div>
              <div className="text-xl font-bold text-white mt-1">{lineage.displayValue}</div>
            </div>
            <div>
              <div className="text-xs text-slate-400">原始传感器/账单读数</div>
              <div className="text-sm font-semibold text-cyan-400 mt-1">
                {lineage.rawValue} <span className="text-xs text-slate-400">{lineage.rawUnit}</span>
              </div>
              <div className="text-[11px] text-slate-500">转换系数: ×{lineage.conversionFactor}</div>
            </div>
            <div>
              <div className="text-xs text-slate-400">数据质量等级</div>
              <div className="flex items-center space-x-1.5 mt-1">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span className="text-sm font-medium text-emerald-300">{lineage.dataQuality}</span>
              </div>
              <div className="text-[11px] text-slate-500">置信区间: {lineage.confidenceInterval}</div>
            </div>
          </div>

          {/* 数据链路脉络图 (Source -> Processing -> Calculation -> Model -> Result) */}
          <div>
            <div className="text-xs font-semibold text-slate-400 mb-2 flex items-center space-x-1.5">
              <Layers className="w-3.5 h-3.5 text-blue-400" />
              <span>数据物理拓扑与处理血缘流向</span>
            </div>
            <div className="grid grid-cols-4 gap-2 text-center text-xs">
              <div className="p-2.5 bg-[#161c28] border border-blue-900/40 rounded">
                <div className="text-[10px] text-blue-400 font-mono">1. 边缘采集</div>
                <div className="font-bold text-white mt-0.5">{lineage.sourceSystem}</div>
                <div className="text-[10px] text-slate-400 mt-1 truncate">{lineage.deviceId}</div>
              </div>
              <div className="p-2.5 bg-[#161c28] border border-blue-900/40 rounded">
                <div className="text-[10px] text-blue-400 font-mono">2. 工业网关</div>
                <div className="font-bold text-white mt-0.5">Kafka / MQTT</div>
                <div className="text-[10px] text-slate-400 mt-1">毫秒级时序清洗</div>
              </div>
              <div className="p-2.5 bg-[#161c28] border border-blue-900/40 rounded">
                <div className="text-[10px] text-blue-400 font-mono">3. 计算引擎</div>
                <div className="font-bold text-white mt-0.5">Rust 物质平衡</div>
                <div className="text-[10px] text-slate-400 mt-1">守恒定律校验</div>
              </div>
              <div className="p-2.5 bg-[#161c28] border border-blue-900/40 rounded">
                <div className="text-[10px] text-blue-400 font-mono">4. 业务中台</div>
                <div className="font-bold text-white mt-0.5">SEIOS Lakehouse</div>
                <div className="text-[10px] text-slate-400 mt-1">版本 {lineage.dataVersion}</div>
              </div>
            </div>
          </div>

          {/* 详细技术源头与物理实体 */}
          <div className="space-y-2 text-xs">
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-[#161c28] p-3 rounded border border-slate-800">
                <div className="text-slate-400 mb-1 flex items-center space-x-1">
                  <Cpu className="w-3.5 h-3.5 text-slate-300" />
                  <span>设备实体名称</span>
                </div>
                <div className="text-slate-200 font-medium">{lineage.deviceName}</div>
                <div className="text-[11px] text-slate-500 mt-0.5 font-mono">设备代码: {lineage.deviceId}</div>
              </div>
              <div className="bg-[#161c28] p-3 rounded border border-slate-800">
                <div className="text-slate-400 mb-1 flex items-center space-x-1">
                  <Activity className="w-3.5 h-3.5 text-slate-300" />
                  <span>所在装置 / 站场地理位置</span>
                </div>
                <div className="text-slate-200 font-medium">{lineage.location}</div>
                <div className="text-[11px] text-slate-500 mt-0.5">采集采样时间: {lineage.timestamp}</div>
              </div>
            </div>

            {/* 明确公式与模型算法 */}
            <div className="bg-[#161c28] p-3 rounded border border-slate-800">
              <div className="text-slate-400 mb-1 flex items-center space-x-1">
                <FileText className="w-3.5 h-3.5 text-amber-400" />
                <span>工程物理 / 化学 / 经济学计算公式</span>
              </div>
              <div className="font-mono text-amber-300 bg-[#0d1117] p-2.5 rounded border border-slate-900 text-xs">
                {lineage.calculationFormula}
              </div>
            </div>

            {lineage.algorithmModel && (
              <div className="bg-[#161c28] p-3 rounded border border-slate-800">
                <div className="text-slate-400 mb-1 flex items-center space-x-1">
                  <GitCommit className="w-3.5 h-3.5 text-cyan-400" />
                  <span>工业算法模型与引擎版本</span>
                </div>
                <div className="text-slate-200 font-medium">{lineage.algorithmModel}</div>
                <div className="text-[11px] text-slate-500 mt-0.5">核心版本: {lineage.modelVersion}</div>
              </div>
            )}
          </div>

          <div className="text-[11px] text-slate-500 bg-slate-900/50 p-2.5 rounded border border-slate-800">
            声明：本系统遵循《中国石化工业数据治理体系》，所有计算因子与原始采样点已通过区块链防篡改校验，数据可追溯至一次仪表端点。
          </div>
        </div>

        {/* 底部 */}
        <div className="px-6 py-3 bg-[#161c28] border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded transition"
          >
            关闭溯源查看
          </button>
        </div>

      </div>
    </div>
  );
};
