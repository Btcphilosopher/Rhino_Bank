/**
 * 模块 8：化工与物料平衡引擎 (Chemical & Material Balance Center)
 * 质量守恒、能量守恒、乙烯裂解全产业链拓扑与仪表漂移核验
 */

import React, { useState } from 'react';
import { 
  Database, 
  Boxes, 
  Activity, 
  CheckCircle2, 
  AlertCircle, 
  Scale, 
  ArrowRight,
  Flame,
  Zap
} from 'lucide-react';
import { MATERIAL_BALANCE_DATA } from '../data/mockData';

interface PetrochemicalBalanceCenterProps {
  onOpenDataLineage: (metricName: string, displayValue: string) => void;
  onNavigateTab: (tab: any) => void;
}

export const PetrochemicalBalanceCenter: React.FC<PetrochemicalBalanceCenterProps> = ({
  onOpenDataLineage
}) => {
  const [selectedBalanceIdx, setSelectedBalanceIdx] = useState<number>(0);
  const balance = MATERIAL_BALANCE_DATA[selectedBalanceIdx];

  const totalInFlow = balance.inputs.reduce((acc, cur) => acc + cur.flowTonneHour, 0);
  const totalOutFlow = balance.outputs.reduce((acc, cur) => acc + cur.flowTonneHour, 0);

  return (
    <div className="space-y-4">
      
      {/* 顶栏物料平衡单元选择 */}
      <div className="bg-[#121620] border border-slate-800 rounded-lg p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center space-x-2">
          <span className="text-slate-400 font-semibold flex items-center space-x-1">
            <Scale className="w-3.5 h-3.5 text-purple-400" />
            <span>选择物料平衡核算单元:</span>
          </span>
          <select
            value={selectedBalanceIdx}
            onChange={(e) => setSelectedBalanceIdx(parseInt(e.target.value))}
            className="bg-[#182030] border border-slate-700 text-slate-100 font-bold px-3 py-1.5 rounded text-xs focus:outline-none focus:border-purple-500"
          >
            {MATERIAL_BALANCE_DATA.map((mb, i) => (
              <option key={mb.unitId} value={i}>
                {mb.unitName} ({mb.location})
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-center space-x-2">
          <span className="flex items-center space-x-1 px-2.5 py-1 bg-emerald-950/60 border border-emerald-800/60 rounded text-emerald-300 font-medium">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>质量守恒定律核验：通过 (偏差 {balance.unbalancedTolerancePercent}%)</span>
          </span>
        </div>
      </div>

      {/* 进出料质量与能量平衡汇总卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
        
        <div className="bg-[#121620] border border-slate-800 rounded-lg p-3">
          <div className="text-slate-400 mb-1">总物料输入 (ΣMass_In)</div>
          <div className="text-xl font-bold text-cyan-400 font-mono">
            {totalInFlow.toFixed(1)} <span className="text-xs font-normal text-slate-400">t/h</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            进料流股数: {balance.inputs.length} 路 (DCS 质量流量计在线)
          </div>
        </div>

        <div className="bg-[#121620] border border-slate-800 rounded-lg p-3">
          <div className="text-slate-400 mb-1">总产物输出 (ΣMass_Out) + 允许损耗</div>
          <div className="text-xl font-bold text-white font-mono">
            {(totalOutFlow + balance.lossTonneHour).toFixed(1)} <span className="text-xs font-normal text-slate-400">t/h</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex justify-between">
            <span>产物流股: {balance.outputs.length} 路</span>
            <span className="text-slate-500">工艺损耗: {balance.lossTonneHour} t/h</span>
          </div>
        </div>

        <div className="bg-[#121620] border border-slate-800 rounded-lg p-3">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span>平衡偏差与仪表漂移状态</span>
            <button
              onClick={() => onOpenDataLineage('物料平衡衡算公式', balance.massBalanceEquation)}
              className="text-slate-500 hover:text-red-400"
            >
              <Database className="w-3 h-3" />
            </button>
          </div>
          <div className="text-xl font-bold text-emerald-400 font-mono">
            ΔM = {(totalInFlow - (totalOutFlow + balance.lossTonneHour)).toFixed(2)} t/h ({balance.unbalancedTolerancePercent}%)
          </div>
          <div className="text-[11px] text-emerald-400 mt-1">
            符合国家《石化企业物料计量与平衡规范》&le; 0.5% 严苛标准
          </div>
        </div>

      </div>

      {/* 进出料详细流股与焓值清单 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        
        {/* 输入流股 */}
        <div className="bg-[#121620] border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
            <h4 className="text-sm font-bold text-cyan-300">进料流股 (Inputs Stream)</h4>
            <span className="text-xs text-slate-400 font-mono">总计: {totalInFlow.toFixed(1)} t/h</span>
          </div>

          <div className="space-y-2 text-xs">
            {balance.inputs.map((inStream, idx) => (
              <div key={idx} className="p-2.5 bg-[#161c28] rounded border border-slate-800/80 flex items-center justify-between">
                <div>
                  <div className="font-bold text-white">{inStream.name}</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">温度: {inStream.tempC} ℃</div>
                </div>
                <div className="text-right">
                  <div className="font-mono font-bold text-cyan-400 text-sm">{inStream.flowTonneHour} t/h</div>
                  <div className="text-[10px] text-slate-500 font-mono">焓值: {inStream.enthalpyMJ.toLocaleString()} MJ</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 输出流股 */}
        <div className="bg-[#121620] border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
            <h4 className="text-sm font-bold text-purple-300">产出与副产流股 (Outputs Stream)</h4>
            <span className="text-xs text-slate-400 font-mono">总计: {totalOutFlow.toFixed(1)} t/h</span>
          </div>

          <div className="space-y-2 text-xs">
            {balance.outputs.map((outStream, idx) => (
              <div key={idx} className="p-2.5 bg-[#161c28] rounded border border-slate-800/80 flex items-center justify-between">
                <div>
                  <div className="font-bold text-white">{outStream.name}</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">出料温度: {outStream.tempC} ℃</div>
                </div>
                <div className="text-right">
                  <div className="font-mono font-bold text-purple-300 text-sm">{outStream.flowTonneHour} t/h</div>
                  <div className="text-[10px] text-slate-500 font-mono">焓值: {outStream.enthalpyMJ.toLocaleString()} MJ</div>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* 数学物理守恒公式溯源栏 */}
      <div className="bg-[#121620] border border-slate-800 rounded-lg p-4 space-y-2 text-xs">
        <div className="text-slate-400 font-semibold flex items-center space-x-1.5">
          <Database className="w-3.5 h-3.5 text-red-400" />
          <span>实时物质平衡与热力学第一定律公式审计</span>
        </div>
        <div className="p-2.5 bg-[#0b0e14] border border-slate-900 rounded font-mono text-amber-300 text-xs">
          {balance.massBalanceEquation}
        </div>
        <div className="p-2.5 bg-[#0b0e14] border border-slate-900 rounded font-mono text-cyan-300 text-xs">
          {balance.energyBalanceEquation}
        </div>
      </div>

    </div>
  );
};
