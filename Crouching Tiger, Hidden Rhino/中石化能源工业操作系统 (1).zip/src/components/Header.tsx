/**
 * SEIOS 工业操作系统顶栏与导航中心
 * 100% 简体中文，专业工业控制中心交互
 */

import React, { useState, useEffect } from 'react';
import { 
  Globe, 
  MapPin, 
  Layers, 
  Flame, 
  GitPullRequest, 
  Factory, 
  Boxes, 
  TrendingUp, 
  Fuel, 
  Zap, 
  Wrench, 
  ShieldAlert, 
  Leaf, 
  Sparkles, 
  SlidersHorizontal,
  Clock,
  ShieldCheck,
  RotateCcw,
  CheckCircle2,
  ChevronRight,
  Database
} from 'lucide-react';
import { MetricUnit, SystemMode } from '../types';

export type ActiveTabId = 
  | 'overview' 
  | 'asset_map' 
  | 'production' 
  | 'underground_twin' 
  | 'well_drilling' 
  | 'pipeline_twin' 
  | 'refinery_twin' 
  | 'chemicals_balance' 
  | 'inventory' 
  | 'trading' 
  | 'retail_station' 
  | 'new_energy' 
  | 'maintenance' 
  | 'hse_safety' 
  | 'carbon_ccus' 
  | 'ai_assistant' 
  | 'scenario_lab';

interface HeaderProps {
  activeTab: ActiveTabId;
  setActiveTab: (tab: ActiveTabId) => void;
  currentUnit: MetricUnit;
  setCurrentUnit: (unit: MetricUnit) => void;
  systemMode: SystemMode;
  setSystemMode: (mode: SystemMode) => void;
  onOpenDataLineage: (metricName: string, displayValue: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  currentUnit,
  setCurrentUnit,
  systemMode,
  setSystemMode,
}) => {
  const [timeStr, setTimeStr] = useState<string>('');
  const [otSafeConfirmed, setOtSafeConfirmed] = useState<boolean>(true);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(now.toLocaleString('zh-CN', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
      }) + ' CST');
    };
    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  // 17大模块分组
  const MODULE_GROUPS = [
    {
      groupName: '集团大盘',
      items: [
        { id: 'overview' as ActiveTabId, label: '1. 集团总览', icon: Globe },
        { id: 'asset_map' as ActiveTabId, label: '2. 全球资产地图', icon: MapPin },
      ]
    },
    {
      groupName: '勘探与开发 (上游)',
      items: [
        { id: 'production' as ActiveTabId, label: '3. 油气生产中心', icon: Flame },
        { id: 'underground_twin' as ActiveTabId, label: '4. 三维地下地质孪生', icon: Layers },
        { id: 'well_drilling' as ActiveTabId, label: '5. 单井与钻井分析', icon: SlidersHorizontal },
      ]
    },
    {
      groupName: '储运与管网 (中游)',
      items: [
        { id: 'pipeline_twin' as ActiveTabId, label: '6. 全球管网水力孪生', icon: GitPullRequest },
        { id: 'inventory' as ActiveTabId, label: '9. 全球能源库存', icon: Boxes },
        { id: 'trading' as ActiveTabId, label: '10. 国际贸易与原油配置', icon: TrendingUp },
      ]
    },
    {
      groupName: '炼化与零售 (下游)',
      items: [
        { id: 'refinery_twin' as ActiveTabId, label: '7. 炼厂数字孪生', icon: Factory },
        { id: 'chemicals_balance' as ActiveTabId, label: '8. 化工与物料平衡', icon: Database },
        { id: 'retail_station' as ActiveTabId, label: '11. 零售网络与单站孪生', icon: Fuel },
        { id: 'new_energy' as ActiveTabId, label: '12. 氢能与综合新能源', icon: Zap },
      ]
    },
    {
      groupName: '工业保障与双碳',
      items: [
        { id: 'maintenance' as ActiveTabId, label: '13. 设备预测性维护', icon: Wrench },
        { id: 'hse_safety' as ActiveTabId, label: '14. HSE安全与环保', icon: ShieldAlert },
        { id: 'carbon_ccus' as ActiveTabId, label: '15. 工业碳管理与CCUS', icon: Leaf },
      ]
    },
    {
      groupName: 'AI 与情景实验室',
      items: [
        { id: 'ai_assistant' as ActiveTabId, label: '16. 中石化能源AI助手', icon: Sparkles },
        { id: 'scenario_lab' as ActiveTabId, label: '17. 能源情景实验室', icon: RotateCcw },
      ]
    }
  ];

  return (
    <header className="bg-[#0b0e14] text-slate-100 border-b border-slate-800 sticky top-0 z-40 shadow-md">
      
      {/* 顶部状态栏 */}
      <div className="px-4 py-2 border-b border-slate-800/80 flex flex-wrap items-center justify-between gap-2 bg-[#080a0f]">
        
        {/* 左侧品牌与系统名称 */}
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2">
            <div className="w-7 h-7 rounded bg-[#c8102e] flex items-center justify-center font-black text-white text-sm shadow-sm border border-red-500/40">
              化
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-extrabold text-sm tracking-wide text-white">中国石化 SINOPEC</span>
                <span className="text-[11px] bg-red-950/80 text-red-400 border border-red-800/50 px-1.5 py-0.2 rounded font-mono">SEIOS 4.2</span>
              </div>
              <div className="text-[11px] text-slate-400 font-medium">中石化能源工业操作系统 · 全球数字孪生与运营中枢</div>
            </div>
          </div>

          <div className="hidden lg:flex items-center text-xs text-slate-500 space-x-1 pl-3 border-l border-slate-800">
            <span>集团总部</span>
            <ChevronRight className="w-3 h-3" />
            <span className="text-slate-300">全球能源控制中心</span>
          </div>
        </div>

        {/* 右侧系统状态、单位切换、安全网闸与时钟 */}
        <div className="flex items-center flex-wrap gap-2 text-xs">
          
          {/* 系统运行模式 */}
          <div className="flex items-center bg-[#141923] border border-slate-700/60 rounded px-1.5 py-1 space-x-1">
            <span className="text-[11px] text-slate-400 px-1">模式:</span>
            {[
              { id: 'realtime' as SystemMode, name: '实时工况' },
              { id: 'simulation' as SystemMode, name: '仿真演练' },
              { id: 'scenario' as SystemMode, name: '情景推演' },
            ].map(m => (
              <button
                key={m.id}
                onClick={() => setSystemMode(m.id)}
                className={`px-2 py-0.5 rounded text-[11px] font-medium transition ${
                  systemMode === m.id
                    ? 'bg-red-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
              >
                {m.name}
              </button>
            ))}
          </div>

          {/* 单位制自动转换器 */}
          <div className="flex items-center bg-[#141923] border border-slate-700/60 rounded px-1.5 py-1 space-x-1">
            <span className="text-[11px] text-slate-400 px-1">单位:</span>
            {[
              { id: 'bbl' as MetricUnit, name: '桶(bbl)' },
              { id: 't' as MetricUnit, name: '吨(t)' },
              { id: 'Nm3' as MetricUnit, name: '标方(Nm³)' },
            ].map(u => (
              <button
                key={u.id}
                onClick={() => setCurrentUnit(u.id)}
                className={`px-1.5 py-0.5 rounded text-[11px] font-medium transition ${
                  currentUnit === u.id
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
              >
                {u.name}
              </button>
            ))}
          </div>

          {/* OT / IT 安全隔离状态 */}
          <div 
            onClick={() => setOtSafeConfirmed(!otSafeConfirmed)}
            title="点击切换OT工控控制指令安全隔离锁"
            className={`flex items-center space-x-1 px-2 py-1 rounded border cursor-pointer transition text-[11px] ${
              otSafeConfirmed 
                ? 'bg-emerald-950/40 text-emerald-300 border-emerald-800/60' 
                : 'bg-amber-950/40 text-amber-300 border-amber-800/60'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>OT/IT 物理隔离: {otSafeConfirmed ? '已锁定保护' : '人工特许授权'}</span>
          </div>

          {/* 时钟 */}
          <div className="flex items-center space-x-1.5 text-slate-300 font-mono text-[11px] bg-[#141923] border border-slate-800 px-2 py-1 rounded">
            <Clock className="w-3.5 h-3.5 text-red-400" />
            <span>{timeStr || '加载时钟...'}</span>
          </div>

        </div>

      </div>

      {/* 模拟数据警告条 */}
      <div className="bg-[#1c1917] border-b border-amber-900/40 px-4 py-1 flex items-center justify-between text-[11px] text-amber-300">
        <div className="flex items-center space-x-2">
          <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse"></span>
          <span className="font-semibold">【系统模式：模拟数据 (Synthetic Engine)】</span>
          <span className="text-amber-200/80">
            本系统内所有指标、传感器读数、油藏模型、管网流体参数及财务数据均为工业级演示仿真数据，不代表中国石化真实生产数据。
          </span>
        </div>
        <div className="hidden md:flex items-center space-x-3 text-amber-400/70 text-[10px]">
          <span>数据血缘: 激活</span>
          <span>•</span>
          <span>双碳核算: 开启</span>
          <span>•</span>
          <span>AI 算力引擎: 在线</span>
        </div>
      </div>

      {/* 17大模块滚动导航菜单 */}
      <div className="px-4 py-1.5 overflow-x-auto scrollbar-thin flex items-center gap-4 bg-[#10141d]">
        {MODULE_GROUPS.map((group, idx) => (
          <div key={idx} className="flex items-center space-x-1 shrink-0">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider px-1 border-r border-slate-800 mr-1">
              {group.groupName}
            </span>
            {group.items.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center space-x-1.5 px-2.5 py-1.5 rounded text-xs font-medium transition whitespace-nowrap ${
                    isActive
                      ? 'bg-red-600 text-white shadow-md font-semibold'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/70'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
        ))}
      </div>

    </header>
  );
};
