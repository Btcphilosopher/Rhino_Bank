/**
 * 模块 4：油田与三维地下地质模型数字孪生 (Underground Geology Twin)
 * 采用 Three.js 渲染地层切片、断裂带、储集体、水平井眼轨迹、射孔段与油水接触面
 */

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { 
  Layers, 
  Eye, 
  RotateCw, 
  Sliders, 
  MapPin, 
  Database, 
  Activity, 
  Flame, 
  Info,
  Maximize2
} from 'lucide-react';
import { DETAILED_WELLS } from '../data/mockData';

interface UndergroundGeologyTwinProps {
  onOpenDataLineage: (metricName: string, displayValue: string) => void;
  onNavigateTab: (tab: any) => void;
}

export const UndergroundGeologyTwin: React.FC<UndergroundGeologyTwinProps> = ({
  onOpenDataLineage,
  onNavigateTab
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [selectedWellId, setSelectedWellId] = useState<string>('WELL-001');
  const [displayProperty, setDisplayProperty] = useState<'oil_sat' | 'porosity' | 'permeability' | 'pressure'>('oil_sat');
  const [stratumOpacity, setStratumOpacity] = useState<number>(0.75);
  const [showFaults, setShowFaults] = useState<boolean>(true);
  const [showFractures, setShowFractures] = useState<boolean>(true);
  const [sliceZ, setSliceZ] = useState<number>(100);

  const selectedWell = DETAILED_WELLS.find(w => w.id === selectedWellId) || DETAILED_WELLS[0];

  useEffect(() => {
    if (!mountRef.current) return;

    const width = mountRef.current.clientWidth;
    const height = mountRef.current.clientHeight || 520;

    // 1. Scene, Camera, Renderer
    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#07090e');
    scene.fog = new THREE.FogExp2('#07090e', 0.008);

    const camera = new THREE.PerspectiveCamera(45, width / height, 1, 1000);
    camera.position.set(50, 45, 65);
    camera.lookAt(0, -10, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    mountRef.current.replaceChildren(renderer.domElement);

    // 2. Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.9);
    scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0xffffff, 1.2);
    dirLight1.position.set(30, 50, 30);
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0x38bdf8, 0.6);
    dirLight2.position.set(-30, -20, -30);
    scene.add(dirLight2);

    // 3. Grid & Coordinate Axes Box
    const grid = new THREE.GridHelper(80, 20, 0xef4444, 0x334155);
    grid.position.y = 15;
    scene.add(grid);

    // 4. 地层体 (Geological Stratigraphic Layers)
    const stratumGroup = new THREE.Group();

    // 盖层 泥岩 (Caprock)
    const caprockGeo = new THREE.BoxGeometry(60, 6, 60);
    const caprockMat = new THREE.MeshStandardMaterial({
      color: 0x475569,
      roughness: 0.8,
      transparent: true,
      opacity: stratumOpacity * 0.9
    });
    const caprock = new THREE.Mesh(caprockGeo, caprockMat);
    caprock.position.y = 9;
    stratumGroup.add(caprock);

    // 储集层 (Reservoir 优质砂岩/溶洞碳酸盐岩)
    const reservoirGeo = new THREE.BoxGeometry(60, 14, 60);
    const reservoirColor = 
      displayProperty === 'oil_sat' ? 0xd97706 :
      displayProperty === 'porosity' ? 0x0284c7 :
      displayProperty === 'permeability' ? 0x10b981 : 0x8b5cf6;
      
    const reservoirMat = new THREE.MeshStandardMaterial({
      color: reservoirColor,
      roughness: 0.6,
      transparent: true,
      opacity: stratumOpacity
    });
    const reservoir = new THREE.Mesh(reservoirGeo, reservoirMat);
    reservoir.position.y = -2;
    stratumGroup.add(reservoir);

    // 油水过渡带与底层基岩 (Water zone & Basement)
    const waterGeo = new THREE.BoxGeometry(60, 10, 60);
    const waterMat = new THREE.MeshStandardMaterial({
      color: 0x1e3a8a,
      roughness: 0.7,
      transparent: true,
      opacity: stratumOpacity * 0.85
    });
    const water = new THREE.Mesh(waterGeo, waterMat);
    water.position.y = -14;
    stratumGroup.add(water);

    scene.add(stratumGroup);

    // 5. 断裂带 Fault Plane (红色半透明构造断层)
    if (showFaults) {
      const faultGeo = new THREE.PlaneGeometry(65, 45);
      const faultMat = new THREE.MeshStandardMaterial({
        color: 0xef4444,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.45,
        wireframe: false
      });
      const faultMesh = new THREE.Mesh(faultGeo, faultMat);
      faultMesh.rotation.x = Math.PI / 3;
      faultMesh.rotation.y = Math.PI / 6;
      faultMesh.position.set(5, -2, 0);
      scene.add(faultMesh);
    }

    // 6. 三维井眼轨迹 (3D Wellbore Trajectories)
    const wellPoints = [
      new THREE.Vector3(0, 15, 0),       // 井口
      new THREE.Vector3(0, 5, 0),        // 直井段
      new THREE.Vector3(2, -2, 4),       // 造斜段
      new THREE.Vector3(12, -4, 18),     // 水平段靶点 A
      new THREE.Vector3(24, -4.5, 26)    // 水平段靶点 B (终点)
    ];
    const curve = new THREE.CatmullRomCurve3(wellPoints);
    const tubeGeo = new THREE.TubeGeometry(curve, 64, 0.75, 12, false);
    const tubeMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      emissive: 0x38bdf8,
      emissiveIntensity: 0.6,
      roughness: 0.2
    });
    const wellTube = new THREE.Mesh(tubeGeo, tubeMat);
    scene.add(wellTube);

    // 7. 水力压裂缝网 (Hydraulic Fracture Wings)
    if (showFractures) {
      for (let i = 0; i < 6; i++) {
        const fracGeo = new THREE.PlaneGeometry(8, 10);
        const fracMat = new THREE.MeshBasicMaterial({
          color: 0x38bdf8,
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.7
        });
        const fracMesh = new THREE.Mesh(fracGeo, fracMat);
        const t = 0.4 + i * 0.1;
        const pt = curve.getPoint(t);
        fracMesh.position.copy(pt);
        fracMesh.rotation.y = Math.PI / 4;
        scene.add(fracMesh);
      }
    }

    // 8. 动画与交互控制
    let animationId: number;
    let angle = 0;
    let isDragging = false;
    let prevMouseX = 0;
    let prevMouseY = 0;
    let customRotationY = 0;
    let customRotationX = 0;

    const onMouseDown = (e: MouseEvent) => {
      isDragging = true;
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isDragging) return;
      const deltaX = e.clientX - prevMouseX;
      const deltaY = e.clientY - prevMouseY;
      customRotationY += deltaX * 0.008;
      customRotationX += deltaY * 0.008;
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;
    };

    const onMouseUp = () => {
      isDragging = false;
    };

    const dom = mountRef.current;
    dom.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);

    const animate = () => {
      animationId = requestAnimationFrame(animate);

      if (!isDragging) {
        angle += 0.002;
      }

      const currentRotY = angle + customRotationY;
      const r = 85;
      camera.position.x = r * Math.sin(currentRotY);
      camera.position.z = r * Math.cos(currentRotY);
      camera.position.y = 45 + Math.sin(customRotationX) * 20;
      camera.lookAt(0, -3, 0);

      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!mountRef.current) return;
      const w = mountRef.current.clientWidth;
      const h = mountRef.current.clientHeight || 520;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      dom.removeEventListener('mousedown', onMouseDown);
      renderer.dispose();
    };
  }, [displayProperty, stratumOpacity, showFaults, showFractures, sliceZ]);

  return (
    <div className="space-y-4">
      
      {/* 顶栏控制器 */}
      <div className="bg-[#121620] border border-slate-800 rounded-lg p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
        
        {/* 储层属性热图切换 */}
        <div className="flex items-center space-x-2">
          <span className="text-slate-400 font-semibold flex items-center space-x-1">
            <Sliders className="w-3.5 h-3.5 text-red-500" />
            <span>三维储层物性场:</span>
          </span>
          {[
            { id: 'oil_sat', name: '含油饱和度 (So)', color: 'text-amber-400 border-amber-500/50' },
            { id: 'porosity', name: '孔隙度 (Φ)', color: 'text-sky-400 border-sky-500/50' },
            { id: 'permeability', name: '渗透率 (K)', color: 'text-emerald-400 border-emerald-500/50' },
            { id: 'pressure', name: '地层流压 (Pf)', color: 'text-purple-400 border-purple-500/50' },
          ].map(p => (
            <button
              key={p.id}
              onClick={() => setDisplayProperty(p.id as any)}
              className={`px-2.5 py-1 rounded text-xs transition border ${
                displayProperty === p.id 
                  ? `bg-[#1a2233] font-bold ${p.color} border` 
                  : 'bg-[#0d1017] text-slate-400 border-slate-800 hover:text-white'
              }`}
            >
              {p.name}
            </button>
          ))}
        </div>

        {/* 构造与压裂开关 */}
        <div className="flex items-center space-x-3">
          <label className="flex items-center space-x-1.5 cursor-pointer text-slate-300">
            <input 
              type="checkbox" 
              checked={showFaults} 
              onChange={(e) => setShowFaults(e.target.checked)} 
              className="rounded bg-slate-800 border-slate-700 text-red-600 focus:ring-0" 
            />
            <span>显示断层带</span>
          </label>
          <label className="flex items-center space-x-1.5 cursor-pointer text-slate-300">
            <input 
              type="checkbox" 
              checked={showFractures} 
              onChange={(e) => setShowFractures(e.target.checked)} 
              className="rounded bg-slate-800 border-slate-700 text-cyan-600 focus:ring-0" 
            />
            <span>显示水力压裂缝网</span>
          </label>
        </div>

      </div>

      {/* 3D 渲染舞台 + 右侧地质单井诊断 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        
        {/* Three.js 3D 舞台 (2列) */}
        <div className="lg:col-span-2 bg-[#090c12] border border-slate-800 rounded-lg p-2 relative overflow-hidden flex flex-col justify-between min-h-[520px]">
          
          {/* 3D 舞台顶层叠加信息 */}
          <div className="absolute top-4 left-4 z-10 space-y-1 pointer-events-none">
            <div className="flex items-center space-x-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
              <span className="text-xs font-bold text-white bg-slate-900/80 px-2 py-0.5 rounded border border-slate-700">
                西北油田 · 顺北奥陶系超深断溶体油气藏 (8600m 埋深)
              </span>
            </div>
            <div className="text-[11px] text-slate-400 bg-slate-900/80 px-2 py-0.5 rounded border border-slate-800 max-w-xs">
              鼠标按住左键拖拽可多角度旋转观察地层与水平井眼轨迹
            </div>
          </div>

          {/* 右上角透明度滑动条 */}
          <div className="absolute top-4 right-4 z-10 bg-slate-900/90 border border-slate-700 p-2.5 rounded text-xs space-y-1.5 text-slate-300 shadow-xl">
            <div className="flex justify-between text-[11px]">
              <span>地层透明度</span>
              <span className="font-mono text-cyan-400">{(stratumOpacity * 100).toFixed(0)}%</span>
            </div>
            <input
              type="range"
              min="0.2"
              max="1.0"
              step="0.05"
              value={stratumOpacity}
              onChange={(e) => setStratumOpacity(parseFloat(e.target.value))}
              className="w-28 accent-red-500 cursor-pointer"
            />
          </div>

          {/* 实际 WebGL Canvas 挂载点 */}
          <div ref={mountRef} className="w-full h-full min-h-[480px] rounded cursor-grab active:cursor-grabbing"></div>

          {/* 底部物性色带标尺 */}
          <div className="absolute bottom-3 left-4 right-4 z-10 flex items-center justify-between bg-slate-900/85 border border-slate-800 px-3 py-1.5 rounded text-[11px] text-slate-400">
            <div className="flex items-center space-x-2">
              <span>低值 (0.0)</span>
              <div className="w-32 h-2.5 rounded bg-gradient-to-r from-blue-900 via-emerald-600 via-amber-500 to-rose-600"></div>
              <span className="text-amber-400 font-bold">高丰度 (1.0)</span>
            </div>
            <div className="flex items-center space-x-3 text-slate-400">
              <span className="flex items-center space-x-1">
                <span className="w-2 h-2 bg-white rounded-full"></span>
                <span>水平井眼: 顺北5-10H (8840m)</span>
              </span>
              <span className="flex items-center space-x-1">
                <span className="w-2 h-2 bg-cyan-400 rounded-sm"></span>
                <span>射孔缝网 (6段)</span>
              </span>
            </div>
          </div>

        </div>

        {/* 右侧：单井轨迹与射孔地质参数 */}
        <div className="bg-[#121620] border border-slate-800 rounded-lg p-4 space-y-4 text-xs">
          
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div>
              <div className="text-[11px] text-red-400 font-semibold">TARGET WELL PROFILE</div>
              <h3 className="text-sm font-bold text-white">{selectedWell.name}</h3>
            </div>
            <select
              value={selectedWellId}
              onChange={(e) => setSelectedWellId(e.target.value)}
              className="bg-[#182030] border border-slate-700 text-slate-200 px-2 py-1 rounded text-xs focus:outline-none"
            >
              {DETAILED_WELLS.map(w => (
                <option key={w.id} value={w.id}>{w.name}</option>
              ))}
            </select>
          </div>

          <div className="space-y-2 text-slate-300">
            <div className="p-2.5 bg-[#161c28] rounded border border-slate-800">
              <div className="text-slate-400 text-[11px]">目的产层</div>
              <div className="font-bold text-white mt-0.5">{selectedWell.producingLayer}</div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="p-2 bg-[#161c28] rounded border border-slate-800">
                <div className="text-slate-400 text-[11px]">测深 (MD) / 垂深 (TVD)</div>
                <div className="font-bold text-amber-400 font-mono mt-0.5">
                  {selectedWell.depthTotalMD}m / {selectedWell.depthTVD}m
                </div>
              </div>
              <div className="p-2 bg-[#161c28] rounded border border-slate-800">
                <div className="text-slate-400 text-[11px]">水平段长度</div>
                <div className="font-bold text-cyan-400 font-mono mt-0.5">
                  {selectedWell.horizontalLength > 0 ? `${selectedWell.horizontalLength} m` : '直井'}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="p-2 bg-[#161c28] rounded border border-slate-800">
                <div className="text-slate-400 text-[11px]">套管程序</div>
                <div className="text-slate-200 font-mono text-[11px] mt-0.5 truncate">{selectedWell.casingSpec}</div>
              </div>
              <div className="p-2 bg-[#161c28] rounded border border-slate-800">
                <div className="text-slate-400 text-[11px]">油管规格</div>
                <div className="text-slate-200 font-mono text-[11px] mt-0.5 truncate">{selectedWell.tubingSize}</div>
              </div>
            </div>

            {/* 实时生产监测 */}
            <div className="p-3 bg-[#161c28] rounded border border-slate-800 space-y-1.5">
              <div className="text-xs font-semibold text-white flex justify-between">
                <span>实时井口参数监测</span>
                <span className="text-emerald-400">{selectedWell.status}</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span className="text-slate-400">日产油量:</span>
                <span className="font-mono font-bold text-amber-400">{selectedWell.dailyOilBbl} bbl/d</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span className="text-slate-400">日产天然气:</span>
                <span className="font-mono text-cyan-400">{selectedWell.dailyGasM3.toLocaleString()} m³/d</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span className="text-slate-400">井口 / 井底流压:</span>
                <span className="font-mono text-white">{selectedWell.wellheadPressure} / {selectedWell.bottomHolePressure} MPa</span>
              </div>
            </div>
          </div>

          <button
            onClick={() => onNavigateTab('well_drilling')}
            className="w-full py-2 bg-red-600 hover:bg-red-500 text-white rounded text-xs font-medium transition"
          >
            进入该井 Arps 递减分析与钻井遥测 &rarr;
          </button>

        </div>

      </div>

    </div>
  );
};
