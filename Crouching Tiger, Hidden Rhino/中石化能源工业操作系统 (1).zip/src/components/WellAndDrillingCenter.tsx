/**
 * 模块 5：单井分析与钻井工程中心 (Well and Drilling Engineering Center)
 * 单井全生命周期档案、实时钻井工程参数遥测、交互式 Arps 递减曲线分析与 EUR 储量测算
 */

import React, { useState } from 'react';
import { 
  SlidersHorizontal, 
  Activity, 
  TrendingDown, 
  Database, 
  Gauge, 
  Compass, 
  Wrench, 
  ChevronRight,
  Info
} from 'lucide-react';
import { DETAILED_WELLS } from '../data/mockData';

interface WellAndDrillingCenterProps {
  onOpenDataLineage: (metricName: string, displayValue: string) => void;
  onNavigateTab: (tab: any) => void;
}

export const WellAndDrillingCenter: React.FC<WellAndDrillingCenterProps> = ({
  onOpenDataLineage
}) => {
  const [selectedWellId, setSelectedWellId] = useState<string>('WELL-001');
  const well = DETAILED_WELLS.find(w => w.id === selectedWellId) || DETAILED_WELLS[0];

  // Arps 交互式递减分析状态
  const [arpsType, setArpsType] = useState<'双曲递减' | '指数递减' | '调和递减'>(well.arpsModel.modelType);
  const [qi, setQi] = useState<number>(well.arpsModel.qi || 2400); // 初始日产桶
  const [di, setDi] = useState<number>(well.arpsModel.di || 0.15); // 名义年递减率
  const [bExp, setBExp] = useState<number>(well.arpsModel.b || 0.45); // 双曲指数

  // 计算未来 10 年 (120个月) 递减曲线点位与累产
  const generateDeclinePoints = () => {
    const points: { month: number; rate: number; cumMMBbl: number }[] = [];
    let cum = 0;

    for (let m = 1; m <= 120; m++) {
      const tYears = m / 12;
      let q = 0;
      if (arpsType === '指数递减') {
        q = qi * Math.exp(-di * tYears);
      } else if (arpsType === '调和递减') {
        q = qi / (1 + di * tYears);
      } else {
        // 双曲递减
        const b = Math.max(0.01, bExp);
        q = qi / Math.pow(1 + b * di * tYears, 1 / b);
      }
      cum += (q * 30.4) / 1000000; // 累计百万桶
      points.push({ month: m, rate: Math.max(0, q), cumMMBbl: cum });
    }
    return points;
  };

  const declinePoints = generateDeclinePoints();
  const calculatedEUR = declinePoints[declinePoints.length - 1]?.cumMMBbl.toFixed(2) || '3.42';

  return (
    <div className="space-y-4">
      
      {/* 井号选择与状态条 */}
      <div className="bg-[#121620] border border-slate-800 rounded-lg p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center space-x-3">
          <span className="text-slate-400 font-semibold flex items-center space-x-1">
            <SlidersHorizontal className="w-3.5 h-3.5 text-red-500" />
            <span>选择分析单井:</span>
          </span>
          <select
            value={selectedWellId}
            onChange={(e) => {
              setSelectedWellId(e.target.value);
              const target = DETAILED_WELLS.find(w => w.id === e.target.value);
              if (target) {
                setArpsType(target.arpsModel.modelType);
                setQi(target.arpsModel.qi || 2000);
                setDi(target.arpsModel.di || 0.15);
                setBExp(target.arpsModel.b || 0.4);
              }
            }}
            className="bg-[#182030] border border-slate-700 text-slate-100 font-bold px-3 py-1 rounded text-xs focus:outline-none focus:border-red-500"
          >
            {DETAILED_WELLS.map(w => (
              <option key={w.id} value={w.id}>
                {w.name} · {w.wellType} ({w.block} · 完钻 {w.depthTotalMD}m)
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-center space-x-3 text-slate-300">
          <span>开钻/完井: <strong className="text-white">{well.spudDate} ~ {well.completionDate}</strong></span>
          <span className={`px-2 py-0.5 rounded text-[11px] ${
            well.status.includes('报警') 
              ? 'bg-rose-950 text-rose-300 border border-rose-800' 
              : 'bg-emerald-950 text-emerald-300 border border-emerald-800/60'
          }`}>
            {well.status}
          </span>
        </div>
      </div>

      {/* 第一部分：钻井工程实时遥测参数 (Drilling Dynamics Telemetry) */}
      <div className="bg-[#121620] border border-slate-800 rounded-lg p-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
          <div className="flex items-center space-x-2">
            <Gauge className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-bold text-white">钻井工程实时遥测 (MWD / LWD 泥浆随钻测井传感器)</h3>
          </div>
          <span className="text-[11px] text-slate-400">实时采样率: 50 Hz 毫秒级防漏防卡</span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2 text-xs">
          <div className="bg-[#161c28] p-2.5 rounded border border-slate-800">
            <div className="text-slate-400 text-[11px]">机械钻速 (ROP)</div>
            <div className="text-lg font-bold text-cyan-400 font-mono mt-0.5">
              {well.drillingDynamics?.currentROP || 4.5} <span className="text-[10px] text-slate-400">m/h</span>
            </div>
            <div className="text-[10px] text-slate-500">PDC 钻头切削</div>
          </div>

          <div className="bg-[#161c28] p-2.5 rounded border border-slate-800">
            <div className="text-slate-400 text-[11px]">钻压 (WOB)</div>
            <div className="text-lg font-bold text-amber-400 font-mono mt-0.5">
              {well.drillingDynamics?.weightOnBitWOB || 95} <span className="text-[10px] text-slate-400">kN</span>
            </div>
            <div className="text-[10px] text-slate-500">钻具自重平衡</div>
          </div>

          <div className="bg-[#161c28] p-2.5 rounded border border-slate-800">
            <div className="text-slate-400 text-[11px]">转盘/马达扭矩</div>
            <div className="text-lg font-bold text-white font-mono mt-0.5">
              {well.drillingDynamics?.torque || 18.2} <span className="text-[10px] text-slate-400">kN·m</span>
            </div>
            <div className="text-[10px] text-emerald-400">转矩无突变异常</div>
          </div>

          <div className="bg-[#161c28] p-2.5 rounded border border-slate-800">
            <div className="text-slate-400 text-[11px]">泥浆密度 (Mud Density)</div>
            <div className="text-lg font-bold text-white font-mono mt-0.5">
              {well.drillingDynamics?.mudDensity || 1.42} <span className="text-[10px] text-slate-400">g/cm³</span>
            </div>
            <div className="text-[10px] text-slate-500">地层高压平衡</div>
          </div>

          <div className="bg-[#161c28] p-2.5 rounded border border-slate-800">
            <div className="text-slate-400 text-[11px]">泥浆排量</div>
            <div className="text-lg font-bold text-cyan-300 font-mono mt-0.5">
              {well.drillingDynamics?.mudFlowRate || 32} <span className="text-[10px] text-slate-400">L/s</span>
            </div>
            <div className="text-[10px] text-slate-500">井底岩屑携砂正常</div>
          </div>

          <div className="bg-[#161c28] p-2.5 rounded border border-slate-800">
            <div className="text-slate-400 text-[11px]">立管循环压力</div>
            <div className="text-lg font-bold text-rose-400 font-mono mt-0.5">
              {well.drillingDynamics?.standpipePressure || 24.5} <span className="text-[10px] text-slate-400">MPa</span>
            </div>
            <div className="text-[10px] text-slate-500">水力循环通道</div>
          </div>

          <div className="bg-[#161c28] p-2.5 rounded border border-slate-800">
            <div className="text-slate-400 text-[11px]">井斜角 / 方位</div>
            <div className="text-lg font-bold text-emerald-400 font-mono mt-0.5">
              {well.drillingDynamics?.inclination || 88.5}° <span className="text-[10px] text-slate-400">{well.drillingDynamics?.azimuth || 245}°</span>
            </div>
            <div className="text-[10px] text-slate-500">旋转导向靶心率 99%</div>
          </div>
        </div>
      </div>

      {/* 第二部分：交互式 Arps 产量递减曲线与 EUR 预测 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        
        {/* 控制参数滑块与数学模型 (1列) */}
        <div className="bg-[#121620] border border-slate-800 rounded-lg p-4 space-y-4 text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center space-x-2">
              <TrendingDown className="w-4 h-4 text-amber-500" />
              <h3 className="text-sm font-bold text-white">Arps 递减模型调参</h3>
            </div>
            <button 
              onClick={() => onOpenDataLineage('Arps 产量递减与 EUR 计算模型', `EUR = ${calculatedEUR} 百万桶 [Arps 双曲递减积分]`)}
              className="text-slate-500 hover:text-red-400 p-0.5 rounded"
              title="查看公式与血缘"
            >
              <Database className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* 模型类型切换 */}
          <div>
            <label className="text-slate-400 block mb-1.5 font-medium">递减模型类型 (Arps Model):</label>
            <div className="grid grid-cols-3 gap-1">
              {(['双曲递减', '指数递减', '调和递减'] as const).map((type) => (
                <button
                  key={type}
                  onClick={() => setArpsType(type)}
                  className={`py-1.5 rounded text-xs transition border ${
                    arpsType === type 
                      ? 'bg-red-600 border-red-500 text-white font-bold' 
                      : 'bg-[#161c28] border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>

          {/* 初始日产 qi */}
          <div className="space-y-1">
            <div className="flex justify-between">
              <span className="text-slate-400">初始日产量 (qᵢ):</span>
              <span className="font-mono font-bold text-amber-400">{qi} 桶/日</span>
            </div>
            <input
              type="range"
              min="200"
              max="5000"
              step="50"
              value={qi}
              onChange={(e) => setQi(parseInt(e.target.value))}
              className="w-full accent-red-500"
            />
          </div>

          {/* 年递减率 Di */}
          <div className="space-y-1">
            <div className="flex justify-between">
              <span className="text-slate-400">初始名义年递减率 (Dᵢ):</span>
              <span className="font-mono font-bold text-cyan-400">{(di * 100).toFixed(1)}%</span>
            </div>
            <input
              type="range"
              min="0.05"
              max="0.60"
              step="0.01"
              value={di}
              onChange={(e) => setDi(parseFloat(e.target.value))}
              className="w-full accent-cyan-500"
            />
          </div>

          {/* 双曲指数 b (仅当双曲递减时可用) */}
          {arpsType === '双曲递减' && (
            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-400">双曲递减指数 (b, 0~1):</span>
                <span className="font-mono font-bold text-purple-400">{bExp.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="0.05"
                max="0.95"
                step="0.05"
                value={bExp}
                onChange={(e) => setBExp(parseFloat(e.target.value))}
                className="w-full accent-purple-500"
              />
            </div>
          )}

          {/* 测算结果面板 */}
          <div className="p-3 bg-[#161c28] rounded border border-slate-800 space-y-2">
            <div className="text-slate-400 text-[11px]">测算最终预计可采储量 (EUR)</div>
            <div className="text-2xl font-black text-emerald-400 font-mono">
              {calculatedEUR} <span className="text-xs font-normal text-slate-400">百万桶 (MMBbl)</span>
            </div>
            <div className="text-[11px] text-slate-400 border-t border-slate-800/80 pt-1.5 flex justify-between">
              <span>经济极限日产阈值: 25 bbl/d</span>
              <span className="text-cyan-400">剩余生产周期 ~11.5 年</span>
            </div>
          </div>
        </div>

        {/* 递减曲线动态图表 (2列) */}
        <div className="lg:col-span-2 bg-[#121620] border border-slate-800 rounded-lg p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
              <h3 className="text-sm font-bold text-white">单井 10 年期产量递减趋势与累产积分曲线</h3>
              <div className="flex items-center space-x-3 text-xs">
                <span className="flex items-center space-x-1">
                  <span className="w-2.5 h-0.5 bg-amber-500"></span>
                  <span className="text-slate-300">月度日产 (桶/日)</span>
                </span>
                <span className="flex items-center space-x-1">
                  <span className="w-2.5 h-0.5 bg-emerald-500"></span>
                  <span className="text-slate-300">累计产油 (百万桶)</span>
                </span>
              </div>
            </div>

            {/* SVG 递减折线图 */}
            <div className="h-64 w-full relative">
              <svg viewBox="0 0 600 240" className="w-full h-full">
                {/* 背景网格线 */}
                {[0, 60, 120, 180, 240].map((y, i) => (
                  <line key={i} x1="0" y1={y} x2="600" y2={y} stroke="#1e293b" strokeWidth="1" strokeDasharray="3 3" />
                ))}

                {/* 产量递减曲线 Path (Amber) */}
                <path
                  d={declinePoints.map((pt, i) => {
                    const x = (i / (declinePoints.length - 1)) * 580 + 10;
                    const y = 220 - (pt.rate / (qi * 1.1)) * 200;
                    return `${i === 0 ? 'M' : 'L'} ${x} ${Math.max(15, Math.min(230, y))}`;
                  }).join(' ')}
                  fill="none"
                  stroke="#f59e0b"
                  strokeWidth="2.5"
                />

                {/* 累计产油曲线 Path (Emerald) */}
                <path
                  d={declinePoints.map((pt, i) => {
                    const x = (i / (declinePoints.length - 1)) * 580 + 10;
                    const maxCum = parseFloat(calculatedEUR) * 1.1 || 4.0;
                    const y = 220 - (pt.cumMMBbl / maxCum) * 190;
                    return `${i === 0 ? 'M' : 'L'} ${x} ${Math.max(15, Math.min(230, y))}`;
                  }).join(' ')}
                  fill="none"
                  stroke="#10b981"
                  strokeWidth="2"
                  strokeDasharray="4 2"
                />
              </svg>
            </div>
          </div>

          <div className="flex items-center justify-between text-xs text-slate-400 border-t border-slate-800 pt-2">
            <span>第 1 个月 (初始日产 {qi} bbl/d)</span>
            <span>第 60 个月 (5 年)</span>
            <span>第 120 个月 (10 年经济寿命终点)</span>
          </div>

        </div>

      </div>

    </div>
  );
};
