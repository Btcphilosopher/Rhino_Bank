/**
 * 模块 10：国际贸易与原油配置优化中心 (Energy Trading & Crude Slate Optimizer)
 * 国际油气现货/期货/升贴水追踪 + 炼厂原油调配线性规划 (LP) 计算引擎
 */

import React, { useState } from 'react';
import { 
  TrendingUp, 
  Database, 
  Sliders, 
  Scale, 
  DollarSign, 
  ArrowUpRight, 
  ArrowDownRight, 
  CheckCircle2, 
  Activity,
  Sparkles
} from 'lucide-react';
import { MARKET_PRICES, CRUDE_SLATE_OPTIONS } from '../data/mockData';

interface EnergyTradingCenterProps {
  onOpenDataLineage: (metricName: string, displayValue: string) => void;
  onNavigateTab: (tab: any) => void;
}

export const EnergyTradingCenter: React.FC<EnergyTradingCenterProps> = ({
  onOpenDataLineage,
  onNavigateTab
}) => {
  // 原油配比比例
  const [omanRatio, setOmanRatio] = useState<number>(40);
  const [espoRatio, setEspoRatio] = useState<number>(30);
  const [arabRatio, setArabRatio] = useState<number>(20);
  const [brentRatio, setBrentRatio] = useState<number>(10);

  // 目标优化偏好
  const [optGoal, setOptGoal] = useState<'max_margin' | 'min_carbon' | 'max_jet_fuel'>('max_margin');

  // 计算加权到岸价格 CIF
  const totalWeight = omanRatio + espoRatio + arabRatio + brentRatio || 100;
  const normOman = omanRatio / totalWeight;
  const normEspo = espoRatio / totalWeight;
  const normArab = arabRatio / totalWeight;
  const normBrent = brentRatio / totalWeight;

  const weightedCIF = (
    normOman * CRUDE_SLATE_OPTIONS[0].cifLandedCostUSD +
    normEspo * CRUDE_SLATE_OPTIONS[3].cifLandedCostUSD +
    normArab * CRUDE_SLATE_OPTIONS[1].cifLandedCostUSD +
    normBrent * CRUDE_SLATE_OPTIONS[2].cifLandedCostUSD
  ).toFixed(2);

  const weightedSulfur = (
    normOman * CRUDE_SLATE_OPTIONS[0].sulfurContentPercent +
    normEspo * CRUDE_SLATE_OPTIONS[3].sulfurContentPercent +
    normArab * CRUDE_SLATE_OPTIONS[1].sulfurContentPercent +
    normBrent * CRUDE_SLATE_OPTIONS[2].sulfurContentPercent
  ).toFixed(2);

  const estimatedGRM = (
    14.2 + (normEspo * 2.5) + (normBrent * -0.5) - (parseFloat(weightedSulfur) * 0.4)
  ).toFixed(2);

  return (
    <div className="space-y-4">
      
      {/* 国际油气大宗交易实时行情盘 */}
      <div className="bg-[#121620] border border-slate-800 rounded-lg p-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
          <div className="flex items-center space-x-2">
            <TrendingUp className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-bold text-white">全球油气现货、期货与基差升贴水交易盘面</h3>
          </div>
          <span className="text-xs text-slate-400 font-mono">普氏 Platts / 洲际交易所 ICE 实时接入</span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2 text-xs">
          {MARKET_PRICES.map((item, idx) => (
            <div key={idx} className="bg-[#161c28] p-2.5 rounded border border-slate-800/80 space-y-1">
              <div className="text-slate-400 text-[11px] truncate font-medium">{item.name}</div>
              <div className="text-base font-bold text-white font-mono mt-0.5">
                ${item.spot.toFixed(2)}
              </div>
              <div className="flex items-center justify-between text-[11px]">
                <span className={item.change >= 0 ? 'text-emerald-400 font-medium' : 'text-rose-400 font-medium'}>
                  {item.change >= 0 ? `+${item.change}%` : `${item.change}%`}
                </span>
                <span className="text-[10px] text-slate-500 font-mono">{item.vol}</span>
              </div>
              <div className="text-[10px] text-slate-500 truncate border-t border-slate-800/60 pt-1">
                {item.spread}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Crude Slate 线性规划 (LP) 原油调配优化器 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        
        {/* 左侧：原油混配比例调控滑块 (1列) */}
        <div className="bg-[#121620] border border-slate-800 rounded-lg p-4 space-y-4 text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center space-x-2">
              <Sliders className="w-4 h-4 text-red-500" />
              <h4 className="text-sm font-bold text-white">Crude Slate 原油混配调配</h4>
            </div>
            <button
              onClick={() => onOpenDataLineage('Crude Slate 混配加权计算', `加权到岸价 $${weightedCIF}/bbl, 加权硫含量 ${weightedSulfur}%`)}
              className="text-slate-500 hover:text-red-400"
            >
              <Database className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* 优化目标选择 */}
          <div>
            <label className="text-slate-400 block mb-1.5 font-medium">线性规划优化目标 (Objective):</label>
            <div className="grid grid-cols-3 gap-1">
              {[
                { id: 'max_margin', label: '最大化毛利' },
                { id: 'min_carbon', label: '最小化碳排' },
                { id: 'max_jet_fuel', label: '多产航煤' },
              ].map(item => (
                <button
                  key={item.id}
                  onClick={() => setOptGoal(item.id as any)}
                  className={`py-1 rounded text-[11px] transition border ${
                    optGoal === item.id 
                      ? 'bg-red-600 border-red-500 text-white font-bold' 
                      : 'bg-[#161c28] border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          {/* 各原油比例滑块 */}
          <div className="space-y-3">
            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-300">阿曼原油 (Oman Medium):</span>
                <span className="font-mono font-bold text-amber-400">{omanRatio}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="80"
                value={omanRatio}
                onChange={(e) => setOmanRatio(parseInt(e.target.value))}
                className="w-full accent-amber-500"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-300">ESPO 远东低硫原油:</span>
                <span className="font-mono font-bold text-cyan-400">{espoRatio}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="80"
                value={espoRatio}
                onChange={(e) => setEspoRatio(parseInt(e.target.value))}
                className="w-full accent-cyan-500"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-300">沙特阿拉伯轻质 (Arab Light):</span>
                <span className="font-mono font-bold text-purple-400">{arabRatio}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="80"
                value={arabRatio}
                onChange={(e) => setArabRatio(parseInt(e.target.value))}
                className="w-full accent-purple-500"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-300">北海布伦特 (Brent):</span>
                <span className="font-mono font-bold text-emerald-400">{brentRatio}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="80"
                value={brentRatio}
                onChange={(e) => setBrentRatio(parseInt(e.target.value))}
                className="w-full accent-emerald-500"
              />
            </div>
          </div>

          <div className="p-2.5 bg-[#161c28] rounded border border-slate-800 text-[11px] text-slate-400">
            配比总和: <strong className="text-white font-mono">{totalWeight}%</strong> (系统自动归一化计算)
          </div>
        </div>

        {/* 右侧：LP 求解结果与经济性收益评估报告 (2列) */}
        <div className="lg:col-span-2 bg-[#121620] border border-slate-800 rounded-lg p-4 flex flex-col justify-between text-xs">
          <div>
            <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
              <div className="flex items-center space-x-2">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <h4 className="text-sm font-bold text-white">Crude Slate LP 求解报告与炼油效益核算</h4>
              </div>
              <span className="text-[11px] bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded font-mono">
                求解状态: 最优解 (Optimal)
              </span>
            </div>

            {/* 核心求解指标 */}
            <div className="grid grid-cols-3 gap-3 mb-4">
              <div className="bg-[#161c28] p-3 rounded border border-slate-800">
                <div className="text-slate-400 text-[11px]">加权混合到岸成本 (CIF)</div>
                <div className="text-xl font-bold text-white font-mono mt-0.5">
                  ${weightedCIF} <span className="text-xs text-slate-400 font-normal">/bbl</span>
                </div>
                <div className="text-[10px] text-slate-500 mt-1">包含海运费与港杂费</div>
              </div>

              <div className="bg-[#161c28] p-3 rounded border border-slate-800">
                <div className="text-slate-400 text-[11px]">加权原油硫含量 (Sulfur)</div>
                <div className="text-xl font-bold text-amber-400 font-mono mt-0.5">
                  {weightedSulfur}%
                </div>
                <div className="text-[10px] text-slate-500 mt-1">加氢脱硫负荷适中</div>
              </div>

              <div className="bg-[#161c28] p-3 rounded border border-slate-800">
                <div className="text-slate-400 text-[11px]">预估单桶炼油毛利 (GRM)</div>
                <div className="text-xl font-bold text-emerald-400 font-mono mt-0.5">
                  ${estimatedGRM} <span className="text-xs text-slate-400 font-normal">/bbl</span>
                </div>
                <div className="text-[10px] text-emerald-400 mt-1">+ $1.25/bbl 相比基线</div>
              </div>
            </div>

            {/* 智能建议 */}
            <div className="p-3 bg-[#161c28] rounded border border-slate-800 space-y-2">
              <div className="font-bold text-white flex items-center space-x-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>LP 调度专家建议 (AI Linear Programming Dispatch)</span>
              </div>
              <p className="text-slate-300 text-xs leading-relaxed">
                当前配方下，ESPO 远东低硫原油由于其短航程运费优势及优异柴油收率，能有效提升单桶毛利。建议将镇海炼化 CDU-4 的 ESPO 掺炼比维持在 30%~35%，配合阿曼中质原油提供充足重整进料，实现全厂物料与汽柴航煤产品价值最大化。
              </p>
            </div>
          </div>

          <div className="mt-4 pt-2 border-t border-slate-800 flex justify-end">
            <button
              onClick={() => onNavigateTab('refinery_twin')}
              className="py-1.5 px-4 bg-red-600 hover:bg-red-500 text-white rounded font-medium transition"
            >
              将该配方下发至炼厂数字孪生模拟器 &rarr;
            </button>
          </div>

        </div>

      </div>

    </div>
  );
};
