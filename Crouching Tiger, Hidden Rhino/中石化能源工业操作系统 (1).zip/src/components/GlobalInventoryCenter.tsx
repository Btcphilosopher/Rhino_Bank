/**
 * 模块 9：全球能源库存中心 (Global Inventory Center)
 * 原油保税库、成品油库、沿海大型LNG低温储罐、枯竭气藏地下储气库与盐穴储氢
 */

import React from 'react';
import { 
  Boxes, 
  Database, 
  AlertTriangle, 
  TrendingUp, 
  TrendingDown, 
  CheckCircle2, 
  Flame, 
  Zap, 
  ShieldCheck 
} from 'lucide-react';
import { STORAGE_FACILITIES } from '../data/mockData';

interface GlobalInventoryCenterProps {
  onOpenDataLineage: (metricName: string, displayValue: string) => void;
  onNavigateTab: (tab: any) => void;
}

export const GlobalInventoryCenter: React.FC<GlobalInventoryCenterProps> = ({
  onOpenDataLineage
}) => {
  return (
    <div className="space-y-4">
      
      {/* 顶栏全局库容战略总揽 */}
      <div className="bg-[#121620] border border-slate-800 rounded-lg p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center space-x-3">
          <span className="flex items-center space-x-1.5 font-bold text-white">
            <Boxes className="w-4 h-4 text-amber-500" />
            <span>国家能源安全与商业储备中枢</span>
          </span>
          <span className="text-slate-400">
            原油平均保障天数: <strong className="text-amber-400 font-mono">92 天</strong> | 
            天然气地下储气库容比: <strong className="text-cyan-400 font-mono">86.5%</strong>
          </span>
        </div>

        <div className="flex items-center space-x-2 text-slate-400">
          <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
          <span>高精度雷达液位仪与超声波测厚实时在线</span>
        </div>
      </div>

      {/* 4大重点储罐与战略储气库卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {STORAGE_FACILITIES.map((facility) => (
          <div key={facility.id} className="bg-[#121620] border border-slate-800 rounded-lg p-4 space-y-3 text-xs">
            
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div>
                <span className="text-[10px] text-red-400 font-semibold">{facility.category}</span>
                <h4 className="text-sm font-bold text-white mt-0.5">{facility.name}</h4>
              </div>
              <button
                onClick={() => onOpenDataLineage(`${facility.name} 库存`, `${facility.currentInventoryVolume.toLocaleString()} ${facility.unit}`)}
                className="text-slate-500 hover:text-red-400 p-1"
                title="查看数据血缘"
              >
                <Database className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* 库容饱和度进度条 */}
            <div className="space-y-1">
              <div className="flex justify-between text-slate-300">
                <span>当前库容饱和度 (Fill Rate):</span>
                <span className="font-mono font-bold text-amber-400">{facility.fillRatePercent}%</span>
              </div>
              <div className="w-full h-3 bg-slate-900 rounded-full overflow-hidden p-0.5 border border-slate-800">
                <div 
                  className={`h-full rounded-full transition-all duration-500 ${
                    facility.fillRatePercent > 90 ? 'bg-rose-500' : 'bg-gradient-to-r from-blue-500 via-amber-500 to-emerald-500'
                  }`}
                  style={{ width: `${facility.fillRatePercent}%` }}
                ></div>
              </div>
              <div className="flex justify-between text-[11px] text-slate-500 font-mono">
                <span>现存: {facility.currentInventoryVolume.toLocaleString()} {facility.unit}</span>
                <span>设计容量: {facility.maxCapacityVolume.toLocaleString()} {facility.unit}</span>
              </div>
            </div>

            {/* 进出料与保供天数 */}
            <div className="grid grid-cols-3 gap-2 pt-2">
              <div className="p-2 bg-[#161c28] rounded border border-slate-800">
                <div className="text-slate-400 text-[10px]">日均入库</div>
                <div className="font-bold text-emerald-400 font-mono text-xs mt-0.5">
                  +{facility.dailyInflow.toLocaleString()}
                </div>
              </div>
              <div className="p-2 bg-[#161c28] rounded border border-slate-800">
                <div className="text-slate-400 text-[10px]">日均外输</div>
                <div className="font-bold text-cyan-400 font-mono text-xs mt-0.5">
                  -{facility.dailyOutflow.toLocaleString()}
                </div>
              </div>
              <div className="p-2 bg-[#161c28] rounded border border-slate-800">
                <div className="text-slate-400 text-[10px]">保供支撑天数</div>
                <div className="font-bold text-amber-400 font-mono text-xs mt-0.5">
                  {facility.daysToExhaustion} 天
                </div>
              </div>
            </div>

            <div className="flex justify-between items-center text-[11px] text-slate-400 pt-1 border-t border-slate-800/80">
              <span>位置: {facility.location}</span>
              <span className="text-emerald-400 flex items-center space-x-1">
                <CheckCircle2 className="w-3 h-3" />
                <span>储罐压力: {facility.safetyPressureMPa} MPa (受控)</span>
              </span>
            </div>

          </div>
        ))}
      </div>

    </div>
  );
};
