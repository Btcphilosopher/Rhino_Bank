/**
 * 模块 16：中石化能源工业 AI 助手 (AI Energy Assistant)
 * 工业级石化大模型问答、机理分析诊断、原油调配推荐、生产调度建议与严格数据血缘链溯源
 */

import React, { useState } from 'react';
import { 
  Bot, 
  Send, 
  Sparkles, 
  Database, 
  Layers, 
  Activity, 
  Flame, 
  Sliders, 
  CheckCircle2,
  HelpCircle
} from 'lucide-react';
import { AI_ASSISTANT_KNOWLEDGE } from '../data/mockData';

interface AIEnergyAssistantProps {
  onOpenDataLineage: (metricName: string, displayValue: string) => void;
  onNavigateTab: (tab: any) => void;
}

export const AIEnergyAssistant: React.FC<AIEnergyAssistantProps> = ({
  onOpenDataLineage,
  onNavigateTab
}) => {
  const [messages, setMessages] = useState<Array<{ sender: 'user' | 'ai'; text: string; lineage?: any; timestamp: string }>>([
    {
      sender: 'ai',
      text: '您好！我是「中石化能源工业操作系统」内置的石化工业机理与智能调度 AI 助手。已全面接入 SEIOS 17大业务中枢的实时 OT/IT 数据、LP 线性规划优化器、地下地质水动力学模型以及 HSE 安全规则库。请问您需要进行什么分析或决策支持？',
      timestamp: '09:00:15'
    }
  ]);

  const [inputQuery, setInputQuery] = useState('');
  const [isThinking, setIsThinking] = useState(false);

  const handleSend = (queryText: string) => {
    const q = queryText.trim();
    if (!q) return;

    const userMsg = {
      sender: 'user' as const,
      text: q,
      timestamp: new Date().toTimeString().slice(0, 8)
    };

    setMessages(prev => [...prev, userMsg]);
    setInputQuery('');
    setIsThinking(true);

    setTimeout(() => {
      // 匹配知识库或生成工业级回答
      const matched = AI_ASSISTANT_KNOWLEDGE.find(k => q.includes(k.keyword) || k.query.includes(q)) || {
        query: q,
        response: `【SEIOS 工业智能推演中心】已对您提交的「${q}」进行跨业务域关联分析：\n1. 结合当前全集团原油加工负荷 (92.8%) 与川气东送实时管存 (8,420万方)，系统整体运行平稳。\n2. 如需更精准的机理测算，建议前往对应的业务孪生模块进行参数敏感性调优。\n3. 所有涉及的生产与经济指标均遵循《石化企业技术经济指标计算规则》并支持毫秒级底层传感器血缘审计。`,
        lineageRef: 'SEIOS 统一工业知识图谱与实时流计算引擎'
      };

      const aiMsg = {
        sender: 'ai' as const,
        text: matched.response,
        lineage: matched.lineageRef,
        timestamp: new Date().toTimeString().slice(0, 8)
      };

      setMessages(prev => [...prev, aiMsg]);
      setIsThinking(false);
    }, 600);
  };

  return (
    <div className="space-y-4">
      
      {/* 顶栏助手状态与算力指示 */}
      <div className="bg-[#121620] border border-slate-800 rounded-lg p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center space-x-3">
          <div className="w-7 h-7 rounded-lg bg-red-600/20 border border-red-500/40 flex items-center justify-center">
            <Bot className="w-4 h-4 text-red-500" />
          </div>
          <div>
            <div className="font-bold text-white flex items-center space-x-2">
              <span>SEIOS 工业大模型 (Industrial Foundation Model)</span>
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            </div>
            <div className="text-[11px] text-slate-400">已对齐 SINOPEC 石化工程与能源经济全量行业机理</div>
          </div>
        </div>

        <div className="flex items-center space-x-3 text-slate-400 text-[11px]">
          <span>推理延迟: <strong className="text-cyan-400 font-mono">18ms</strong></span>
          <span>置信度门限: <strong className="text-emerald-400 font-mono">&gt;99.2%</strong></span>
        </div>
      </div>

      {/* 常见工业级快速预设指令 (Prompt Chips) */}
      <div className="flex flex-wrap items-center gap-2 text-xs">
        <span className="text-slate-400 font-medium">推荐工业决策场景:</span>
        {AI_ASSISTANT_KNOWLEDGE.map((item, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(item.query)}
            className="px-2.5 py-1 bg-[#161c28] hover:bg-[#1f2738] text-slate-200 border border-slate-800 rounded text-xs transition truncate max-w-xs"
          >
            {item.query}
          </button>
        ))}
      </div>

      {/* 对话历史记录与问答主区域 */}
      <div className="bg-[#121620] border border-slate-800 rounded-lg p-4 flex flex-col h-[480px]">
        
        {/* 消息滚动列表 */}
        <div className="flex-1 overflow-y-auto space-y-4 pr-2">
          {messages.map((msg, i) => (
            <div
              key={i}
              className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-2xl rounded-lg p-3.5 text-xs leading-relaxed ${
                  msg.sender === 'user'
                    ? 'bg-red-600 text-white font-medium'
                    : 'bg-[#161c28] text-slate-200 border border-slate-800 space-y-2'
                }`}
              >
                {msg.sender === 'ai' && (
                  <div className="flex items-center justify-between text-[10px] text-slate-400 border-b border-slate-800 pb-1 mb-1">
                    <span className="flex items-center space-x-1 text-red-400 font-bold">
                      <Sparkles className="w-3 h-3" />
                      <span>SEIOS 工业智能推理机</span>
                    </span>
                    <span>{msg.timestamp}</span>
                  </div>
                )}

                <div className="whitespace-pre-line text-xs">{msg.text}</div>

                {msg.lineage && (
                  <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-400">
                    <span className="flex items-center space-x-1">
                      <Database className="w-3 h-3 text-cyan-400" />
                      <span>数据血缘: {msg.lineage}</span>
                    </span>
                    <button
                      onClick={() => onOpenDataLineage('AI 建议数据血缘审计', msg.lineage)}
                      className="text-cyan-400 hover:underline"
                    >
                      审计核验
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}

          {isThinking && (
            <div className="flex justify-start">
              <div className="bg-[#161c28] border border-slate-800 rounded-lg p-3 text-xs text-slate-400 flex items-center space-x-2">
                <span className="w-2 h-2 rounded-full bg-red-500 animate-bounce"></span>
                <span className="w-2 h-2 rounded-full bg-red-500 animate-bounce delay-100"></span>
                <span className="w-2 h-2 rounded-full bg-red-500 animate-bounce delay-200"></span>
                <span className="text-[11px] text-slate-400 ml-1">正在调用石化热力学计算与多系统数据血缘...</span>
              </div>
            </div>
          )}
        </div>

        {/* 底部输入框 */}
        <div className="mt-3 pt-3 border-t border-slate-800 flex items-center space-x-2">
          <input
            type="text"
            value={inputQuery}
            onChange={(e) => setInputQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleSend(inputQuery);
            }}
            placeholder="输入工业生产指令或提问（例如：分析镇海炼化原油混配策略、排查顺北5-10H井下漏失...）"
            className="flex-1 bg-[#182030] border border-slate-700 text-slate-100 text-xs px-3.5 py-2.5 rounded-lg focus:outline-none focus:border-red-500 placeholder-slate-500"
          />
          <button
            onClick={() => handleSend(inputQuery)}
            className="px-4 py-2.5 bg-red-600 hover:bg-red-500 text-white text-xs font-bold rounded-lg transition flex items-center space-x-1.5"
          >
            <Send className="w-3.5 h-3.5" />
            <span>发送</span>
          </button>
        </div>

      </div>

    </div>
  );
};
