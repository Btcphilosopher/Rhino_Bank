/**
 * 模块 14：HSE 安全生产与生态环保中心 (HSE Safety & Environmental Center)
 * 重大危险源监控、特殊作业八大票证、可燃有毒气体泄漏探测 (H2S/CH4/VOCs) 与 CEMS 烟气水质在线
 */

import React from 'react';
import { 
  ShieldCheck, 
  AlertTriangle, 
  FileText, 
  Wind, 
  Droplets, 
  Activity, 
  Database, 
  CheckCircle2, 
  Radio 
} from 'lucide-react';
import { HSE_PERMITS, GAS_DETECTORS } from '../data/mockData';

interface HSESafetyCenterProps {
  onOpenDataLineage: (metricName: string, displayValue: string) => void;
  onNavigateTab: (tab: any) => void;
}

export const HSESafetyCenter: React.FC<HSESafetyCenterProps> = ({
  onOpenDataLineage
}) => {
  return (
    <div className="space-y-4">
      
      {/* 顶栏 HSE 安全红线态势 */}
      <div className="bg-[#121620] border border-slate-800 rounded-lg p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center space-x-3">
          <span className="flex items-center space-x-1.5 font-bold text-white">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>中国石化安全生产与绿色低碳红线监控</span>
          </span>
          <span className="text-slate-400">
            全集团连续安全生产天数: <strong className="text-emerald-400 font-mono text-sm">1,280 天</strong> | 
            重特大事故: <strong className="text-emerald-400 font-mono">0 起</strong>
          </span>
        </div>

        <span className="text-[11px] text-emerald-400 font-medium flex items-center space-x-1">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span>应急指挥调度中心 24×7 实时在岗</span>
        </span>
      </div>

      {/* 4大环境与泄漏监测大盘指标 */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
        
        <div className="bg-[#121620] border border-slate-800 rounded-lg p-3">
          <div className="text-slate-400 mb-1">今日特殊作业有效票证</div>
          <div className="text-xl font-bold text-white font-mono">
            {HSE_PERMITS.filter(p => p.status === '作业中').length} <span className="text-xs text-slate-400 font-normal">张在执行</span>
          </div>
          <div className="text-[11px] text-emerald-400 mt-1">
            全部完成气体检测与双人监护
          </div>
        </div>

        <div className="bg-[#121620] border border-slate-800 rounded-lg p-3">
          <div className="text-slate-400 mb-1">可燃/有毒气体探测探头</div>
          <div className="text-xl font-bold text-cyan-400 font-mono">
            18,420 <span className="text-xs text-slate-400 font-normal">个在线</span>
          </div>
          <div className="text-[11px] text-emerald-400 mt-1">
            在线率 99.98% · 零泄漏超标
          </div>
        </div>

        <div className="bg-[#121620] border border-slate-800 rounded-lg p-3">
          <div className="text-slate-400 mb-1">CEMS 烟气 SO₂/NOx 达标率</div>
          <div className="text-xl font-bold text-emerald-400 font-mono">
            100.0%
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            超低排放标准（SO₂ &lt; 35mg/m³）
          </div>
        </div>

        <div className="bg-[#121620] border border-slate-800 rounded-lg p-3">
          <div className="text-slate-400 mb-1">工业污水回用率与 COD</div>
          <div className="text-xl font-bold text-emerald-400 font-mono">
            98.6%
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            COD &lt; 30mg/L (地表水IV类水准)
          </div>
        </div>

      </div>

      {/* 特殊作业八大票证与危险气体探头两栏 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        
        {/* 特殊作业八大票证 */}
        <div className="bg-[#121620] border border-slate-800 rounded-lg p-4 space-y-3 text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h4 className="text-sm font-bold text-white flex items-center space-x-1.5">
              <FileText className="w-4 h-4 text-amber-500" />
              <span>现场高风险特殊作业电子票证</span>
            </h4>
            <span className="text-xs text-slate-400">GB 30871-2021 严苛合规</span>
          </div>

          <div className="space-y-2">
            {HSE_PERMITS.map((permit) => (
              <div key={permit.id} className="p-3 bg-[#161c28] rounded border border-slate-800 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white text-xs">{permit.type} · {permit.id}</span>
                  <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800/60 px-1.5 py-0.5 rounded">
                    {permit.status}
                  </span>
                </div>
                <div className="text-[11px] text-slate-300">
                  <span>作业区域: </span><span className="text-slate-200 font-medium">{permit.location}</span>
                </div>
                <div className="flex justify-between text-[11px] text-slate-400">
                  <span>监护人: {permit.guardian} | 负责人: {permit.approver}</span>
                  <span className="text-cyan-400 font-mono">有效期至: {permit.validUntil}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 可燃与有毒气体泄漏探测探头 */}
        <div className="bg-[#121620] border border-slate-800 rounded-lg p-4 space-y-3 text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h4 className="text-sm font-bold text-white flex items-center space-x-1.5">
              <Wind className="w-4 h-4 text-cyan-400" />
              <span>重点装置可燃/有毒气体 (H₂S / CH₄ / VOCs) 探头</span>
            </h4>
            <span className="text-xs text-slate-400 font-mono">SIS 联锁在线</span>
          </div>

          <div className="space-y-2">
            {GAS_DETECTORS.map((detector) => (
              <div key={detector.id} className="p-3 bg-[#161c28] rounded border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="font-bold text-white">{detector.gasType} 探头 · {detector.id}</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">布置点位: {detector.location}</div>
                  <div className="text-[10px] text-slate-500">报警阈值: {detector.alarmThreshold}</div>
                </div>
                <div className="text-right">
                  <div className="text-base font-bold text-white font-mono">{detector.currentValue}</div>
                  <div className="text-[10px] text-emerald-400 font-medium mt-0.5 flex items-center justify-end space-x-1">
                    <CheckCircle2 className="w-3 h-3" />
                    <span>{detector.status}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
};
