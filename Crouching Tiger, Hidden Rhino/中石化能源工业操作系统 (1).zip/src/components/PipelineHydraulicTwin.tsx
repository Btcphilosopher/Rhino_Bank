/**
 * 模块 6：全球管网水力数字孪生 (Pipeline Hydraulic Twin)
 * 实时水力学模拟、Weymouth 压降计算、管存量分析、故障跳闸与严寒需求突变水力推演
 */

import React, { useState } from 'react';
import { 
  GitPullRequest, 
  Activity, 
  Database, 
  AlertTriangle, 
  RotateCcw, 
  Flame, 
  Zap, 
  Sliders, 
  ArrowRight,
  ShieldCheck
} from 'lucide-react';
import { PIPELINE_NETWORK } from '../data/mockData';

interface PipelineHydraulicTwinProps {
  onOpenDataLineage: (metricName: string, displayValue: string) => void;
  onNavigateTab: (tab: any) => void;
}

export const PipelineHydraulicTwin: React.FC<PipelineHydraulicTwinProps> = ({
  onOpenDataLineage
}) => {
  const [selectedPipeId, setSelectedPipeId] = useState<string>('PIPE-001'); // 川气东送
  const [simScenario, setSimScenario] = useState<'normal' | 'compressor_trip' | 'winter_surge' | 'valve_throttle'>('normal');

  const pipe = PIPELINE_NETWORK.find(p => p.id === selectedPipeId) || PIPELINE_NETWORK[0];

  // 水力计算参数响应
  let inletPressure = pipe.currentInletPressureMPa;
  let outletPressure = pipe.currentOutletPressureMPa;
  let flowRate = pipe.flowRateHour;
  let linepack = pipe.hydraulicModel.linepackStorageM3;
  let warningMessage = '';

  if (simScenario === 'compressor_trip') {
    inletPressure = 4.2;
    outletPressure = 1.8;
    flowRate = pipe.flowRateHour * 0.45;
    linepack = pipe.hydraulicModel.linepackStorageM3 * 0.52;
    warningMessage = '【紧急告警】首站压缩机跳闸断供！中途管存正在以 145万方/h 速度加速消耗，预计 3.5 小时后到达临界死压！已自动触发 LNG 气化应急调峰。';
  } else if (simScenario === 'winter_surge') {
    inletPressure = 9.8;
    outletPressure = 3.6;
    flowRate = pipe.flowRateHour * 1.25;
    linepack = pipe.hydraulicModel.linepackStorageM3 * 1.15;
    warningMessage = '【大负荷调度】华东极寒需求突增 +25%，管道处于超负荷增压输送工况，全线压降陡增 28%。';
  } else if (simScenario === 'valve_throttle') {
    inletPressure = 9.2;
    outletPressure = 2.1;
    flowRate = pipe.flowRateHour * 0.70;
    linepack = pipe.hydraulicModel.linepackStorageM3 * 0.88;
    warningMessage = '【节流调压】中途分输站节流阀开度收紧 30%，后半程流速放缓。';
  }

  // 沿线 6 个站点的压力梯度模拟计算 (0km -> 2170km)
  const stations = [
    { name: '普光首站 (0km)', km: 0, p: inletPressure },
    { name: '达州压气站 (320km)', km: 320, p: inletPressure * 0.92 },
    { name: '宜昌过江站 (750km)', km: 750, p: inletPressure * 0.84 },
    { name: '武汉分输站 (1280km)', km: 1280, p: inletPressure * 0.72 },
    { name: '南京枢纽站 (1750km)', km: 1750, p: inletPressure * 0.60 },
    { name: '上海白鹤末站 (2170km)', km: 2170, p: outletPressure }
  ];

  return (
    <div className="space-y-4">
      
      {/* 顶栏管道选择与工况推演控制 */}
      <div className="bg-[#121620] border border-slate-800 rounded-lg p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
        
        {/* 选择干线 */}
        <div className="flex items-center space-x-2">
          <span className="text-slate-400 font-semibold flex items-center space-x-1">
            <GitPullRequest className="w-3.5 h-3.5 text-blue-400" />
            <span>选择主干管网:</span>
          </span>
          <select
            value={selectedPipeId}
            onChange={(e) => {
              setSelectedPipeId(e.target.value);
              setSimScenario('normal');
            }}
            className="bg-[#182030] border border-slate-700 text-slate-100 font-bold px-3 py-1.5 rounded text-xs focus:outline-none focus:border-blue-500"
          >
            {PIPELINE_NETWORK.map(p => (
              <option key={p.id} value={p.id}>
                {p.name} ({p.category} · {p.lengthKm} km · Φ{p.outerDiameterMm}mm)
              </option>
            ))}
          </select>
        </div>

        {/* 水力动态仿真推演触发器 */}
        <div className="flex items-center space-x-2">
          <span className="text-slate-400 font-semibold">水力仿真工况注入:</span>
          
          <button
            onClick={() => setSimScenario('normal')}
            className={`px-2.5 py-1 rounded transition border ${
              simScenario === 'normal' 
                ? 'bg-blue-600 text-white font-bold border-blue-500' 
                : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
            }`}
          >
            标准稳态
          </button>

          <button
            onClick={() => setSimScenario('compressor_trip')}
            className={`px-2.5 py-1 rounded transition border ${
              simScenario === 'compressor_trip' 
                ? 'bg-rose-600 text-white font-bold border-rose-500 animate-pulse' 
                : 'bg-slate-900 text-rose-400 border-rose-900/60 hover:bg-rose-950'
            }`}
          >
            模拟首站跳闸 12h
          </button>

          <button
            onClick={() => setSimScenario('winter_surge')}
            className={`px-2.5 py-1 rounded transition border ${
              simScenario === 'winter_surge' 
                ? 'bg-amber-600 text-white font-bold border-amber-500' 
                : 'bg-slate-900 text-amber-400 border-amber-900/60 hover:bg-amber-950'
            }`}
          >
            模拟极寒需求突增 +25%
          </button>
        </div>

      </div>

      {/* 警告通知条 (当非稳态时触发) */}
      {warningMessage && (
        <div className="bg-rose-950/70 border border-rose-800 p-3 rounded-lg flex items-center justify-between text-xs text-rose-200 animate-in fade-in">
          <div className="flex items-center space-x-2">
            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
            <span className="font-medium">{warningMessage}</span>
          </div>
          <button
            onClick={() => setSimScenario('normal')}
            className="px-2 py-0.5 bg-rose-900 hover:bg-rose-800 rounded text-[11px] text-white"
          >
            复位水力参数
          </button>
        </div>
      )}

      {/* 4大核心水力指标卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
        
        <div className="bg-[#121620] border border-slate-800 rounded-lg p-3">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span>首站进站压力 / 末站压力</span>
            <button 
              onClick={() => onOpenDataLineage('管网进出口水力压力', `${inletPressure.toFixed(1)} MPa / ${outletPressure.toFixed(1)} MPa`)}
              className="text-slate-500 hover:text-red-400"
            >
              <Database className="w-3 h-3" />
            </button>
          </div>
          <div className="text-xl font-bold text-white font-mono">
            {inletPressure.toFixed(1)} <span className="text-slate-400 text-xs">MPa</span> &rarr; {outletPressure.toFixed(1)} <span className="text-slate-400 text-xs">MPa</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex justify-between">
            <span>设计上限: {pipe.designPressureMPa} MPa</span>
            <span className={simScenario === 'compressor_trip' ? 'text-rose-400' : 'text-emerald-400'}>
              ΔP: {(inletPressure - outletPressure).toFixed(1)} MPa
            </span>
          </div>
        </div>

        <div className="bg-[#121620] border border-slate-800 rounded-lg p-3">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span>实时输送流量 (Flow Rate)</span>
            <button 
              onClick={() => onOpenDataLineage('管网实时流量', `${flowRate.toLocaleString()} ${pipe.category.includes('天然气') ? 'Nm³/h' : 'm³/h'}`)}
              className="text-slate-500 hover:text-red-400"
            >
              <Database className="w-3 h-3" />
            </button>
          </div>
          <div className="text-xl font-bold text-cyan-400 font-mono">
            {flowRate.toLocaleString()} <span className="text-xs text-slate-400 font-normal">{pipe.category.includes('天然气') ? 'Nm³/h' : 'm³/h'}</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex justify-between">
            <span>介质流速: {pipe.velocityMs} m/s</span>
            <span>流态: 充分发展紊流</span>
          </div>
        </div>

        <div className="bg-[#121620] border border-slate-800 rounded-lg p-3">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span>当前动态管存量 (Linepack)</span>
            <button 
              onClick={() => onOpenDataLineage('管网动态管存量 Linepack', `${(linepack / 10000).toFixed(0)} 万方 [Weymouth积分模型]`)}
              className="text-slate-500 hover:text-red-400"
            >
              <Database className="w-3 h-3" />
            </button>
          </div>
          <div className="text-xl font-bold text-amber-400 font-mono">
            {(linepack / 10000).toFixed(0)} <span className="text-xs text-slate-400 font-normal">万方</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex justify-between">
            <span>管存支撑能力</span>
            <span className={simScenario === 'compressor_trip' ? 'text-rose-400 font-bold' : 'text-emerald-400'}>
              {simScenario === 'compressor_trip' ? '仅剩 3.5 小时' : '常态 14.8 小时'}
            </span>
          </div>
        </div>

        <div className="bg-[#121620] border border-slate-800 rounded-lg p-3">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span>沿线加压泵站 / 压气站状态</span>
            <span className="text-[10px] text-emerald-400 font-mono">SCADA 在线</span>
          </div>
          <div className="text-xl font-bold text-white font-mono">
            {pipe.activePumps} / {pipe.pumpingStationsCount} <span className="text-xs text-slate-400 font-normal">座运行中</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex justify-between">
            <span>壁厚腐蚀裕量: {pipe.corrosionIndexMm} mm</span>
            <span className="text-emerald-400">无泄漏告警</span>
          </div>
        </div>

      </div>

      {/* 压力沿线水力梯度曲线与站点拓扑 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        
        {/* 沿线水力压降梯度图 (2列) */}
        <div className="lg:col-span-2 bg-[#121620] border border-slate-800 rounded-lg p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
              <h3 className="text-sm font-bold text-white flex items-center space-x-2">
                <span>沿线水力压力梯度曲线 (Pressure Hydraulic Gradient)</span>
              </h3>
              <span className="text-xs text-slate-400">基于 Weymouth 气体流动方程积分</span>
            </div>

            {/* SVG 沿程压力梯度折线图 */}
            <div className="h-64 w-full relative">
              <svg viewBox="0 0 600 240" className="w-full h-full">
                {/* 网格线 */}
                {[0, 60, 120, 180, 240].map((y, i) => (
                  <line key={i} x1="0" y1={y} x2="600" y2={y} stroke="#1e293b" strokeWidth="1" strokeDasharray="3 3" />
                ))}

                {/* 压力沿程下降曲线 (Cyan/Rose) */}
                <path
                  d={stations.map((st, i) => {
                    const x = (st.km / 2170) * 560 + 20;
                    const y = 220 - (st.p / 12) * 200;
                    return `${i === 0 ? 'M' : 'L'} ${x} ${Math.max(10, y)}`;
                  }).join(' ')}
                  fill="none"
                  stroke={simScenario === 'compressor_trip' ? '#f43f5e' : '#38bdf8'}
                  strokeWidth="3"
                />

                {/* 站点节点打点 */}
                {stations.map((st, i) => {
                  const x = (st.km / 2170) * 560 + 20;
                  const y = 220 - (st.p / 12) * 200;
                  return (
                    <g key={i}>
                      <circle cx={x} cy={Math.max(10, y)} r="5" fill="#0f172a" stroke="#38bdf8" strokeWidth="2" />
                      <text x={x} y={Math.max(10, y) - 10} fill="#f8fafc" fontSize="10" textAnchor="middle" fontWeight="bold">
                        {st.p.toFixed(1)} MPa
                      </text>
                    </g>
                  );
                })}
              </svg>
            </div>
          </div>

          <div className="grid grid-cols-6 gap-1 text-[11px] text-slate-400 border-t border-slate-800 pt-2 text-center">
            {stations.map((st, i) => (
              <div key={i} className="truncate">
                <div className="font-semibold text-slate-300">{st.name.split(' ')[0]}</div>
                <div className="text-[10px] text-slate-500">{st.km} km</div>
              </div>
            ))}
          </div>
        </div>

        {/* 右侧：水力学物理模型与应急保供方案 */}
        <div className="bg-[#121620] border border-slate-800 rounded-lg p-4 space-y-3 text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 className="text-sm font-bold text-white">水力学物理模型与调度</h3>
            <span className="text-[10px] bg-blue-950 text-blue-300 px-1.5 py-0.5 rounded">Weymouth</span>
          </div>

          <div className="space-y-2 text-slate-300">
            <div className="p-2.5 bg-[#161c28] rounded border border-slate-800">
              <div className="text-slate-400 text-[11px]">流动阻力与摩阻系数</div>
              <div className="font-mono text-cyan-300 mt-0.5">λ = 0.0125 (雷诺数 Re = 1.4×10⁷)</div>
            </div>

            <div className="p-2.5 bg-[#161c28] rounded border border-slate-800">
              <div className="text-slate-400 text-[11px]">气体摩尔组分与相对密度</div>
              <div className="text-slate-200 mt-0.5">CH₄: 98.2%, C₂H₆: 0.8%, G = 0.585</div>
            </div>

            <div className="p-2.5 bg-[#161c28] rounded border border-slate-800">
              <div className="text-slate-400 text-[11px]">联锁联动应急储气库</div>
              <div className="text-emerald-400 font-medium mt-0.5">
                文96地下储气库 (5.8亿方) + 天津南港LNG (82万方)
              </div>
              <div className="text-[10px] text-slate-500 mt-1">应急启动响应时间: &lt; 15 分钟</div>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-400">
            当管存压力跌破 4.0 MPa 时，系统自动切断下游非关键工业大用户，优先保障居民采暖与重点民生用气。
          </div>
        </div>

      </div>

    </div>
  );
};
