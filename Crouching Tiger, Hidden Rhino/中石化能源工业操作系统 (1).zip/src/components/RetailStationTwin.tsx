/**
 * 模块 11：零售网络与单站数字孪生 (Retail Station Twin)
 * 全国智慧加油站网络监控 + 综合能源单站数字孪生 (地下油罐、加油机、超充桩、加氢机、易捷便利店)
 */

import React, { useState } from 'react';
import { 
  Fuel, 
  Zap, 
  Boxes, 
  Activity, 
  Database, 
  ShoppingCart, 
  Coffee, 
  CheckCircle2, 
  AlertTriangle 
} from 'lucide-react';
import { DETAILED_STATIONS } from '../data/mockData';

interface RetailStationTwinProps {
  onOpenDataLineage: (metricName: string, displayValue: string) => void;
  onNavigateTab: (tab: any) => void;
}

export const RetailStationTwin: React.FC<RetailStationTwinProps> = ({
  onOpenDataLineage
}) => {
  const [selectedStationId, setSelectedStationId] = useState<string>('STA-001');
  const station = DETAILED_STATIONS.find(s => s.id === selectedStationId) || DETAILED_STATIONS[0];

  return (
    <div className="space-y-4">
      
      {/* 顶栏单站选择与状态 */}
      <div className="bg-[#121620] border border-slate-800 rounded-lg p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center space-x-2">
          <span className="text-slate-400 font-semibold flex items-center space-x-1">
            <Fuel className="w-3.5 h-3.5 text-red-500" />
            <span>选择零售网点/单站数字孪生:</span>
          </span>
          <select
            value={selectedStationId}
            onChange={(e) => setSelectedStationId(e.target.value)}
            className="bg-[#182030] border border-slate-700 text-slate-100 font-bold px-3 py-1.5 rounded text-xs focus:outline-none focus:border-red-500"
          >
            {DETAILED_STATIONS.map(s => (
              <option key={s.id} value={s.id}>
                {s.name} ({s.stationType} · {s.city})
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-center space-x-3 text-slate-300">
          <span>日营业额: <strong className="text-emerald-400 font-mono">¥{station.dailyRevenueCNY.toLocaleString()} 元</strong></span>
          <span>进站车次: <strong className="text-cyan-400 font-mono">{station.dailyTrafficCount} 车次</strong></span>
        </div>
      </div>

      {/* 地下储油罐 & 高压氢气罐实时液位与压力孪生 (Underground Tanks Twin) */}
      <div className="bg-[#121620] border border-slate-800 rounded-lg p-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
          <div className="flex items-center space-x-2">
            <Boxes className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-bold text-white">地下储油罐与储氢罐实时液位仪传感器 (Magnetostrictive Gauges)</h3>
          </div>
          <button
            onClick={() => onOpenDataLineage(`${station.name} 地下罐存`, `总罐存 ${(station.undergroundTanks.reduce((a,b)=>a+b.currentVolumeL,0)/1000).toFixed(1)} m³`)}
            className="text-xs text-slate-500 hover:text-red-400 flex items-center space-x-1"
          >
            <Database className="w-3 h-3" />
            <span>数据溯源</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-3 text-xs">
          {station.undergroundTanks.map((tank) => {
            const fillPercent = ((tank.currentVolumeL / tank.maxCapacityL) * 100).toFixed(1);
            return (
              <div key={tank.tankId} className="bg-[#161c28] p-3 rounded-lg border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white text-xs">{tank.product}</span>
                  <span className="text-[10px] text-slate-500 font-mono">{tank.tankId}</span>
                </div>

                {/* 罐位示意柱状 */}
                <div className="w-full bg-slate-900 h-20 rounded p-1 flex flex-col justify-end border border-slate-800 relative overflow-hidden">
                  <div 
                    className="w-full bg-gradient-to-t from-amber-600 to-amber-400 rounded-sm transition-all duration-500"
                    style={{ height: `${fillPercent}%` }}
                  ></div>
                  <span className="absolute top-2 left-2 text-[10px] text-slate-300 font-mono">
                    {fillPercent}% 饱和
                  </span>
                </div>

                <div className="space-y-1 text-[11px] text-slate-300">
                  <div className="flex justify-between">
                    <span className="text-slate-400">现存储量:</span>
                    <span className="font-mono text-white">{tank.currentVolumeL.toLocaleString()} {tank.product.includes('氢') ? 'kg' : 'L'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">罐内压力 / 液位:</span>
                    <span className="font-mono text-cyan-300">{tank.tankPressureMPa} MPa / {tank.currentLevelM}m</span>
                  </div>
                  <div className="flex justify-between text-[10px] text-slate-500">
                    <span>水杂高度: {tank.waterHeightMm} mm</span>
                    <span className="text-emerald-400">密封正常</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 加油机、超充桩与便利店多维业态三栏 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        
        {/* 加油机与加氢机工位 */}
        <div className="bg-[#121620] border border-slate-800 rounded-lg p-4 space-y-3 text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h4 className="text-sm font-bold text-white flex items-center space-x-1.5">
              <Fuel className="w-4 h-4 text-red-500" />
              <span>加油机与加氢机岛</span>
            </h4>
            <span className="text-[10px] text-slate-500">{station.dispensers.length} 台设备在役</span>
          </div>

          <div className="space-y-2">
            {station.dispensers.map((dispenser) => (
              <div key={dispenser.dispenserId} className="p-2.5 bg-[#161c28] rounded border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="font-bold text-white flex items-center space-x-1.5">
                    <span>{dispenser.dispenserId}</span>
                    <span className="text-[10px] text-slate-400">({dispenser.products.join(', ')})</span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">日出油/气量: {dispenser.dailyFlowL.toLocaleString()} L</div>
                </div>
                <div>
                  <span className={`px-2 py-0.5 rounded text-[10px] ${
                    dispenser.isOccupied ? 'bg-amber-950 text-amber-300 border border-amber-800/60' : 'bg-slate-900 text-slate-500'
                  }`}>
                    {dispenser.isOccupied ? '加油中' : '空闲待机'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 极速超充与充电桩矩阵 */}
        <div className="bg-[#121620] border border-slate-800 rounded-lg p-4 space-y-3 text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h4 className="text-sm font-bold text-white flex items-center space-x-1.5">
              <Zap className="w-4 h-4 text-cyan-400" />
              <span>极速液冷超充桩 (EV Piles)</span>
            </h4>
            <span className="text-[10px] text-cyan-400 font-mono">新能源微电网</span>
          </div>

          <div className="space-y-2">
            {station.evChargingPiles.map((pile) => (
              <div key={pile.pileId} className="p-2.5 bg-[#161c28] rounded border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="font-bold text-white">{pile.pileId} · {pile.type}</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">功率: {pile.powerKw} kW | 今日已充: {pile.dailyKwh} kWh</div>
                </div>
                <span className={`px-2 py-0.5 rounded text-[10px] ${
                  pile.status === '充电中' ? 'bg-cyan-950 text-cyan-300 border border-cyan-800' : 'bg-slate-900 text-slate-500'
                }`}>
                  {pile.status}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* 易捷便利店与非油业务 */}
        <div className="bg-[#121620] border border-slate-800 rounded-lg p-4 space-y-3 text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h4 className="text-sm font-bold text-white flex items-center space-x-1.5">
              <ShoppingCart className="w-4 h-4 text-emerald-400" />
              <span>易捷 (Easy Joy) 智慧便利店</span>
            </h4>
            <span className="text-[10px] text-emerald-400 font-mono">非油零售</span>
          </div>

          <div className="p-3 bg-[#161c28] rounded border border-slate-800 space-y-2">
            <div className="flex justify-between">
              <span className="text-slate-400">非油品日营业额:</span>
              <span className="font-bold text-emerald-400 font-mono text-sm">¥{station.convenienceStore.dailySalesCNY.toLocaleString()} 元</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400 flex items-center space-x-1">
                <Coffee className="w-3.5 h-3.5 text-amber-500" />
                <span>易捷现磨咖啡出杯:</span>
              </span>
              <span className="font-bold text-white font-mono">{station.convenienceStore.coffeeCupsSold} 杯</span>
            </div>
            <div className="text-[11px] text-slate-400 border-t border-slate-800/80 pt-1.5">
              <span>热销品榜单: </span>
              <span className="text-slate-200">{station.convenienceStore.topProducts.join('、')}</span>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
