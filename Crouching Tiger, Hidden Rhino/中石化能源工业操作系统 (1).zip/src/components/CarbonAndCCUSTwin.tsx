/**
 * 模块 15：工业碳管理与 CCUS 全产业链数字孪生 (Carbon & CCUS Twin)
 * 齐鲁石化-胜利油田百万吨级 CCUS 示范项目、超临界CO2管道输送、CO2驱油提高采收率与永久地质封存
 */

import React, { useState } from 'react';
import { 
  Leaf, 
  Flame, 
  Activity, 
  Database, 
  Layers, 
  ArrowRight, 
  ShieldCheck, 
  TrendingDown,
  Sparkles
} from 'lucide-react';
import { CCUS_PROJECT_DATA } from '../data/mockData';

interface CarbonAndCCUSTwinProps {
  onOpenDataLineage: (metricName: string, displayValue: string) => void;
  onNavigateTab: (tab: any) => void;
}

export const CarbonAndCCUSTwin: React.FC<CarbonAndCCUSTwinProps> = ({
  onOpenDataLineage
}) => {
  const ccus = CCUS_PROJECT_DATA;

  return (
    <div className="space-y-4">
      
      {/* 顶栏 CCUS 百万吨示范项目概览 */}
      <div className="bg-[#121620] border border-slate-800 rounded-lg p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center space-x-3">
          <span className="flex items-center space-x-1.5 font-bold text-white">
            <Leaf className="w-4 h-4 text-emerald-400" />
            <span>中国首个百万吨级 CCUS 全产业链示范工程 (齐鲁石化-胜利油田)</span>
          </span>
          <span className="text-slate-400">
            年碳捕集与封存规模: <strong className="text-emerald-400 font-mono">100 万吨/年</strong>
          </span>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => onOpenDataLineage('CCUS 碳捕集量与地质封存审计', '年捕集 100万吨，超临界相态 8.5 MPa 管道输送，驱油采收率提升 12%')}
            className="flex items-center space-x-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded transition"
          >
            <Database className="w-3.5 h-3.5 text-red-400" />
            <span>碳排放配额与封存核证 (CCER) 溯源</span>
          </button>
        </div>
      </div>

      {/* 4大 CCUS 全链条技术参数指标 */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
        
        <div className="bg-[#121620] border border-slate-800 rounded-lg p-3">
          <div className="text-slate-400 mb-1">齐鲁石化 CO₂ 捕集纯度</div>
          <div className="text-xl font-bold text-emerald-400 font-mono">
            {ccus.capturePurityPercent}%
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            低温甲醇洗 + 深度液化提纯
          </div>
        </div>

        <div className="bg-[#121620] border border-slate-800 rounded-lg p-3">
          <div className="text-slate-400 mb-1">超临界密相管道输送</div>
          <div className="text-xl font-bold text-cyan-400 font-mono">
            {ccus.pipelineLengthKm} <span className="text-xs text-slate-400 font-normal">km</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            管道内压: {ccus.pipelinePressureMPa} MPa (超临界流体)
          </div>
        </div>

        <div className="bg-[#121620] border border-slate-800 rounded-lg p-3">
          <div className="text-slate-400 mb-1">CO₂-EOR 驱油提高采收率</div>
          <div className="text-xl font-bold text-amber-400 font-mono">
            +{ccus.recoveryImprovementPercent}%
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            低渗透致密油藏混相驱
          </div>
        </div>

        <div className="bg-[#121620] border border-slate-800 rounded-lg p-3">
          <div className="text-slate-400 mb-1">胜利油田地下永久封存量</div>
          <div className="text-xl font-bold text-white font-mono">
            {(ccus.totalSequestrationToDateTonne / 10000).toFixed(1)} <span className="text-xs text-slate-400 font-normal">万吨</span>
          </div>
          <div className="text-[11px] text-emerald-400 mt-1">
            深部咸水层微震监测安全稳定
          </div>
        </div>

      </div>

      {/* CCUS 工艺全链条流程拓扑 */}
      <div className="bg-[#121620] border border-slate-800 rounded-lg p-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-4">
          <h4 className="text-sm font-bold text-white">齐鲁-胜利 CCUS 跨企业一体化全流程拓扑</h4>
          <span className="text-xs text-slate-400">碳源捕集 &rarr; 密相管输 &rarr; 驱油埋存</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          
          {/* 节点 1: 齐鲁石化捕集源 */}
          <div className="p-4 bg-[#161c28] rounded-lg border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[10px] text-red-400 font-bold">SOURCE 01 · 碳源捕集</span>
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            </div>
            <div className="font-bold text-white text-sm">齐鲁石化第二化肥厂</div>
            <p className="text-slate-300 text-[11px] leading-relaxed">
              煤气化装置高浓度尾气经过变压吸附 (PSA) 及深度液化制冷，产出工业级超纯液态 CO₂，年捕集能力达 100 万吨。
            </p>
          </div>

          {/* 节点 2: 齐鲁-胜利 109km 超临界管道 */}
          <div className="p-4 bg-[#161c28] rounded-lg border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[10px] text-cyan-400 font-bold">TRANSPORT 02 · 密相管输</span>
              <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
            </div>
            <div className="font-bold text-white text-sm">109km 超临界高压管道</div>
            <p className="text-slate-300 text-[11px] leading-relaxed">
              中国首条百公里级高压常温密相二氧化碳输送管道，运行压力 8.5~10.5 MPa，相比槽车运输年减少碳排放 4 万吨。
            </p>
          </div>

          {/* 节点 3: 胜利油田正理庄封存 */}
          <div className="p-4 bg-[#161c28] rounded-lg border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[10px] text-emerald-400 font-bold">SINK 03 · 驱油与封存</span>
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
            </div>
            <div className="font-bold text-white text-sm">胜利油田正理庄/高青油区</div>
            <p className="text-slate-300 text-[11px] leading-relaxed">
              将超临界 CO₂ 注入 2800m 埋深低渗储层，溶解原油降黏膨胀增产，并在地下咸水层与盖层中实现数千年永久矿化封存。
            </p>
          </div>

        </div>
      </div>

    </div>
  );
};
