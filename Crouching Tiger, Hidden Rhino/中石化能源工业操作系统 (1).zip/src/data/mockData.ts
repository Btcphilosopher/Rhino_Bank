/**
 * 中石化能源工业操作系统 (SEIOS)
 * 工业全生命周期数据集与计算引擎
 * 标注：数据源 = synthetic (演示数据，不代表中国石化真实生产数据)
 */

import { DataLineage } from '../types';

export const SYNTHETIC_DATA_BANNER = "【系统模式：模拟数据】本系统内所有指标、传感器读数及拓扑节点均为演示仿真(synthetic)数据，不代表中国石化真实生产数据。";

// 集团概览全局实时核心指标
export const GROUP_CORE_METRICS = {
  // 上游油气
  oilProductionDaily: 1245800, // 桶/日 (约 17.06 万吨/日)
  gasProductionDaily: 295400000, // 标准立方米/日 (约 2.95 亿方/日)
  activeWellsTotal: 2180, // 在产井数
  waterCutAverage: 34.2, // 综合含水率 %
  
  // 中游储运
  pipelineLengthTotal: 34500, // 在役管网总里程 km
  pipelineThroughputDaily: 4850000, // 管网日输送量 吨/日
  crudeStrategicReserve: 84500000, // 原油储备总库存 桶 (储备库容比 81.2%)
  naturalGasStorageVolume: 4680000000, // 储气库有效工作气量 m³ (库容比 86.5%)
  
  // 下游炼化
  refineryThroughputDaily: 6850000, // 炼厂加工量 桶/日 (约 93.8 万吨/日)
  refineryOperatingRate: 88.4, // 炼厂平均开工率 %
  chemicalOutputDaily: 198400, // 乙烯及核心化工品日产 吨/日
  ethyleneUnitOperatingRate: 94.2, // 乙烯装置负荷率 %
  
  // 终端零售与新能源
  refinedOilSalesDaily: 425000, // 成品油日销量 吨/日
  gasStationsCount: 5240, // 联网智慧零售加油站座数
  hydrogenStationsCount: 128, // 加氢站/油氢合建站座数
  evChargingKwhDaily: 3420000, // 日充电量 kWh
  
  // 安全环保与双碳
  safetyAccidentsCount: 0, // 连续无责任安全事故天数 1420 天
  carbonIntensityTonneCrude: 168.4, // 吨原油加工综合碳排放 kgCO2e/t
  ccusCarbonCapturedDaily: 13500, // CCUS 碳捕集与封存量 吨/日
  deviceHealthScoreAverage: 96.8, // 全局关键动设备平均健康指数
  
  // 财务经营指标
  operatingRevenueYTD: 28450.6, // 年初至今营业收入 亿元
  ebitdaYTD: 3420.8, // EBITDA 亿元
  refinedCrudeMargin: 12.8, // 综合炼油毛利 美元/桶
};

// 全球10个国家及核心资产分布
export interface GlobalAssetCountry {
  code: string;
  name: string;
  continent: string;
  flag: string;
  lat: number;
  lng: number;
  oilfieldsCount: number;
  refineriesCount: number;
  gasStationsCount: number;
  dailyProductionOilBbl: number;
  dailyGasM3: number;
  investmentAmountUSD: number; // 亿美元
  riskLevel: '低风险' | '中等' | '较高关注';
  keyProjects: string[];
}

export const GLOBAL_ASSETS: GlobalAssetCountry[] = [
  { code: 'CN', name: '中国 (总部与核心生产基地)', continent: '亚洲', flag: '🇨🇳', lat: 35.8617, lng: 104.1954, oilfieldsCount: 16, refineriesCount: 14, gasStationsCount: 4800, dailyProductionOilBbl: 720000, dailyGasM3: 210000000, investmentAmountUSD: 2450, riskLevel: '低风险', keyProjects: ['胜利油田深层', '西北顺北超深油气田', '普光高含硫气田', '镇海炼化一体化', '涪陵页岩气'] },
  { code: 'SA', name: '沙特阿拉伯', continent: '中东', flag: '🇸🇦', lat: 23.8859, lng: 45.0792, oilfieldsCount: 3, refineriesCount: 2, gasStationsCount: 145, dailyProductionOilBbl: 185000, dailyGasM3: 15000000, investmentAmountUSD: 185, riskLevel: '低风险', keyProjects: ['延布炼厂 (YASREF)', '加瓦尔区块中方联营井组'] },
  { code: 'RU', name: '俄罗斯', continent: '欧洲/北亚', flag: '🇷🇺', lat: 61.5240, lng: 105.3188, oilfieldsCount: 4, refineriesCount: 1, gasStationsCount: 110, dailyProductionOilBbl: 120000, dailyGasM3: 28000000, investmentAmountUSD: 142, riskLevel: '中等', keyProjects: ['乌德穆尔特石油公司 (UDM)', '萨哈林3号深水气田'] },
  { code: 'BR', name: '巴西', continent: '南美洲', flag: '🇧🇷', lat: -14.2350, lng: -51.9253, oilfieldsCount: 2, refineriesCount: 0, gasStationsCount: 40, dailyProductionOilBbl: 95000, dailyGasM3: 8500000, investmentAmountUSD: 98, riskLevel: '低风险', keyProjects: ['里贝拉 (Libra) 盐下深水油田', 'BBM深水勘探区块'] },
  { code: 'AO', name: '安哥拉', continent: '非洲', flag: '🇦🇴', lat: -11.2027, lng: 17.8739, oilfieldsCount: 2, refineriesCount: 0, gasStationsCount: 25, dailyProductionOilBbl: 72000, dailyGasM3: 4200000, investmentAmountUSD: 65, riskLevel: '中等', keyProjects: ['18区块海上深水FPSO', '31区块超深水井组'] },
  { code: 'KZ', name: '哈萨克斯坦', continent: '中亚', flag: '🇰🇿', lat: 48.0196, lng: 66.9237, oilfieldsCount: 3, refineriesCount: 1, gasStationsCount: 85, dailyProductionOilBbl: 48000, dailyGasM3: 12000000, investmentAmountUSD: 52, riskLevel: '低风险', keyProjects: ['里海北布扎奇油田', '中哈原油管道配套'] },
  { code: 'IQ', name: '伊拉克', continent: '中东', flag: '🇮🇶', lat: 33.2232, lng: 43.6793, oilfieldsCount: 2, refineriesCount: 0, gasStationsCount: 12, dailyProductionOilBbl: 54000, dailyGasM3: 6500000, investmentAmountUSD: 48, riskLevel: '较高关注', keyProjects: ['曼苏里亚气田综合开发', '艾哈代卜油田扩建'] },
  { code: 'AE', name: '阿联酋', continent: '中东', flag: '🇦🇪', lat: 23.4241, lng: 53.8478, oilfieldsCount: 1, refineriesCount: 1, gasStationsCount: 32, dailyProductionOilBbl: 35000, dailyGasM3: 4800000, investmentAmountUSD: 40, riskLevel: '低风险', keyProjects: ['富查伊拉保税原油仓储', '阿布扎比陆上联营区块'] },
  { code: 'KW', name: '科威特', continent: '中东', flag: '🇰🇼', lat: 29.3117, lng: 47.4818, oilfieldsCount: 1, refineriesCount: 1, gasStationsCount: 28, dailyProductionOilBbl: 28000, dailyGasM3: 3200000, investmentAmountUSD: 36, riskLevel: '低风险', keyProjects: ['阿祖尔炼油厂技术合作', '重油深层钻探服务'] },
  { code: 'GB', name: '加蓬', continent: '非洲', flag: '🇬🇦', lat: -0.8037, lng: 11.6094, oilfieldsCount: 1, refineriesCount: 0, gasStationsCount: 10, dailyProductionOilBbl: 18000, dailyGasM3: 1200000, investmentAmountUSD: 22, riskLevel: '中等', keyProjects: ['几内亚湾浅海探区'] }
];

// 7大典型油气田
export interface OilfieldRecord {
  id: string;
  name: string;
  basin: string;
  country: string;
  type: '陆上常规' | '超深层碳酸盐岩' | '高含硫气藏' | '页岩气' | '深水海上' | '海外联营';
  areaKm2: number;
  geologyDepth: number; // 平均储层埋深 m
  provenReservesMMBbl: number; // 探明地质储量 百万桶
  remainingRecoverableMMBbl: number; // 剩余可采储量
  dailyOilProduction: number; // 桶/日
  dailyGasProduction: number; // m3/日
  dailyWaterProduction: number; // 桶/日
  waterCutPercent: number; // %
  reservoirPressureMPa: number; // MPa
  reservoirTempC: number; // ℃
  activeWellsCount: number;
  injectionWellsCount: number;
  currentRecoveryRate: number; // 采收率 %
  declineRateAnnual: number; // 年综合递减率 %
  status: '正常' | '注水优化' | '高含水预警' | '增产改造';
}

export const DETAILED_OILFIELDS: OilfieldRecord[] = [
  {
    id: 'OF-01',
    name: '胜利油田 - 东辛采油厂',
    basin: '渤海湾盆地济阳坳陷',
    country: '中国',
    type: '陆上常规',
    areaKm2: 380,
    geologyDepth: 3250,
    provenReservesMMBbl: 1840,
    remainingRecoverableMMBbl: 420,
    dailyOilProduction: 51200,
    dailyGasProduction: 185000,
    dailyWaterProduction: 142000,
    waterCutPercent: 73.5,
    reservoirPressureMPa: 22.4,
    reservoirTempC: 86,
    activeWellsCount: 620,
    injectionWellsCount: 180,
    currentRecoveryRate: 48.2,
    declineRateAnnual: 6.8,
    status: '注水优化'
  },
  {
    id: 'OF-02',
    name: '西北油田 - 顺北超深油气田',
    basin: '塔里木盆地顺托果勒低隆起',
    country: '中国',
    type: '超深层碳酸盐岩',
    areaKm2: 950,
    geologyDepth: 8650,
    provenReservesMMBbl: 2450,
    remainingRecoverableMMBbl: 1680,
    dailyOilProduction: 142000,
    dailyGasProduction: 9400000,
    dailyWaterProduction: 8500,
    waterCutPercent: 5.6,
    reservoirPressureMPa: 82.5,
    reservoirTempC: 168,
    activeWellsCount: 285,
    injectionWellsCount: 12,
    currentRecoveryRate: 21.4,
    declineRateAnnual: 4.2,
    status: '正常'
  },
  {
    id: 'OF-03',
    name: '中原油田 - 普光高含硫气田',
    basin: '四川盆地川东北宣汉区块',
    country: '中国',
    type: '高含硫气藏',
    areaKm2: 420,
    geologyDepth: 5800,
    provenReservesMMBbl: 3800, // 气当量
    remainingRecoverableMMBbl: 1950,
    dailyOilProduction: 1100,
    dailyGasProduction: 26500000,
    dailyWaterProduction: 4200,
    waterCutPercent: 14.2,
    reservoirPressureMPa: 58.2,
    reservoirTempC: 114,
    activeWellsCount: 92,
    injectionWellsCount: 8,
    currentRecoveryRate: 58.6,
    declineRateAnnual: 3.5,
    status: '正常'
  },
  {
    id: 'OF-04',
    name: '江汉油田 - 涪陵页岩气田',
    basin: '四川盆地焦石坝断背斜',
    country: '中国',
    type: '页岩气',
    areaKm2: 680,
    geologyDepth: 4200,
    provenReservesMMBbl: 3200, // 气当量
    remainingRecoverableMMBbl: 2100,
    dailyOilProduction: 0,
    dailyGasProduction: 22800000,
    dailyWaterProduction: 1850,
    waterCutPercent: 0,
    reservoirPressureMPa: 39.4,
    reservoirTempC: 98,
    activeWellsCount: 440,
    injectionWellsCount: 0,
    currentRecoveryRate: 36.8,
    declineRateAnnual: 12.5,
    status: '增产改造'
  },
  {
    id: 'OF-05',
    name: '上海海洋油气分公司 - 荔湾深水平台',
    basin: '南海珠江口盆地白云凹陷',
    country: '中国',
    type: '深水海上',
    areaKm2: 520,
    geologyDepth: 3900,
    provenReservesMMBbl: 1600,
    remainingRecoverableMMBbl: 890,
    dailyOilProduction: 18500,
    dailyGasProduction: 16200000,
    dailyWaterProduction: 2100,
    waterCutPercent: 10.2,
    reservoirPressureMPa: 41.0,
    reservoirTempC: 92,
    activeWellsCount: 38,
    injectionWellsCount: 4,
    currentRecoveryRate: 41.5,
    declineRateAnnual: 5.1,
    status: '正常'
  },
  {
    id: 'OF-06',
    name: '中东加瓦尔外围开发区',
    basin: '阿拉伯大盆地',
    country: '沙特阿拉伯',
    type: '海外联营',
    areaKm2: 610,
    geologyDepth: 2800,
    provenReservesMMBbl: 3100,
    remainingRecoverableMMBbl: 1750,
    dailyOilProduction: 185000,
    dailyGasProduction: 15000000,
    dailyWaterProduction: 48000,
    waterCutPercent: 20.6,
    reservoirPressureMPa: 32.5,
    reservoirTempC: 102,
    activeWellsCount: 140,
    injectionWellsCount: 35,
    currentRecoveryRate: 46.0,
    declineRateAnnual: 3.8,
    status: '正常'
  },
  {
    id: 'OF-07',
    name: '里贝拉 (Libra) 盐下深水联合体',
    basin: '桑托斯盆地',
    country: '巴西',
    type: '深水海上',
    areaKm2: 780,
    geologyDepth: 5400,
    provenReservesMMBbl: 2900,
    remainingRecoverableMMBbl: 2100,
    dailyOilProduction: 95000,
    dailyGasProduction: 8500000,
    dailyWaterProduction: 12000,
    waterCutPercent: 11.2,
    reservoirPressureMPa: 68.0,
    reservoirTempC: 125,
    activeWellsCount: 32,
    injectionWellsCount: 8,
    currentRecoveryRate: 28.5,
    declineRateAnnual: 4.0,
    status: '正常'
  }
];

// 典型单井详细数据库
export interface DetailedWell {
  id: string;
  name: string;
  fieldId: string;
  block: string;
  wellType: '直井' | '定向井' | '水平井' | '海上深水井' | '多段压裂页岩井' | '注水井' | 'CO2注入井';
  depthTotalMD: number; // 测量深度 m
  depthTVD: number; // 垂直深度 m
  horizontalLength: number; // 水平段长度 m
  casingSpec: string; // 套管程序
  tubingSize: string; // 油管尺寸
  producingLayer: string; // 目的产层
  spudDate: string; // 开钻日期
  completionDate: string; // 完井日期
  status: '自喷在产' | '机抽在产' | '多段压裂' | '水力测试' | '关井待修' | '异常高压报警';
  
  // 实时传感器数据
  dailyOilBbl: number;
  dailyGasM3: number;
  dailyWaterBbl: number;
  waterCut: number; // %
  wellheadPressure: number; // 井口压力 MPa
  bottomHolePressure: number; // 井底流压 MPa
  wellheadTemp: number; // ℃
  gasOilRatioGOR: number; // m3/m3
  chokeSize: number; // 油嘴尺寸 mm
  
  // 钻井与工程动态
  drillingDynamics?: {
    currentROP: number; // 机械钻速 m/h
    weightOnBitWOB: number; // 钻压 kN
    torque: number; // 扭矩 kN·m
    mudDensity: number; // 泥浆比重 g/cm³
    mudFlowRate: number; // 泥浆排量 L/s
    standpipePressure: number; // 立管压力 MPa
    inclination: number; // 井斜角 °
    azimuth: number; // 井斜方位 °
  };
  
  // 递减曲线参数 (Arps)
  arpsModel: {
    modelType: '指数递减' | '双曲递减' | '调和递减';
    qi: number; // 初始日产油量 bbl/d
    di: number; // 年名义递减率 fraction (0.15 = 15%)
    b: number; // 双曲指数 (0-1)
    eurMMBbl: number; // 最终预计可采储量 百万桶
    remainingDays: number; // 经济极限剩余生产天数
  };
}

export const DETAILED_WELLS: DetailedWell[] = [
  {
    id: 'WELL-001',
    name: '顺北5-10H',
    fieldId: 'OF-02',
    block: '顺北一区断裂带',
    wellType: '水平井',
    depthTotalMD: 8840,
    depthTVD: 8420,
    horizontalLength: 1420,
    casingSpec: '244.5mm × 177.8mm × 127mm',
    tubingSize: '88.9mm (P110高强度油管)',
    producingLayer: '奥陶系一间房组碳酸盐岩',
    spudDate: '2025-01-10',
    completionDate: '2025-04-18',
    status: '自喷在产',
    dailyOilBbl: 1850,
    dailyGasM3: 45000,
    dailyWaterBbl: 95,
    waterCut: 4.8,
    wellheadPressure: 52.4,
    bottomHolePressure: 78.6,
    wellheadTemp: 78.5,
    gasOilRatioGOR: 152,
    chokeSize: 7.0,
    drillingDynamics: {
      currentROP: 4.5,
      weightOnBitWOB: 95,
      torque: 18.2,
      mudDensity: 1.42,
      mudFlowRate: 32,
      standpipePressure: 24.5,
      inclination: 88.5,
      azimuth: 245.0
    },
    arpsModel: {
      modelType: '双曲递减',
      qi: 2400,
      di: 0.16,
      b: 0.45,
      eurMMBbl: 3.42,
      remainingDays: 4200
    }
  },
  {
    id: 'WELL-002',
    name: '顺北8-2H (亚洲超深井)',
    fieldId: 'OF-02',
    block: '顺北八区北段',
    wellType: '水平井',
    depthTotalMD: 9320,
    depthTVD: 8780,
    horizontalLength: 1650,
    casingSpec: '273mm × 193.7mm × 139.7mm',
    tubingSize: '88.9mm (高抗硫合金油管)',
    producingLayer: '奥陶系鹰山组溶洞型储层',
    spudDate: '2024-09-01',
    completionDate: '2025-02-15',
    status: '自喷在产',
    dailyOilBbl: 2680,
    dailyGasM3: 68000,
    dailyWaterBbl: 110,
    waterCut: 3.9,
    wellheadPressure: 58.2,
    bottomHolePressure: 84.2,
    wellheadTemp: 84.0,
    gasOilRatioGOR: 160,
    chokeSize: 8.5,
    arpsModel: {
      modelType: '双曲递减',
      qi: 3100,
      di: 0.14,
      b: 0.40,
      eurMMBbl: 4.85,
      remainingDays: 4800
    }
  },
  {
    id: 'WELL-003',
    name: '胜科1井 (高含水异常井)',
    fieldId: 'OF-01',
    block: '东辛采油厂辛11断块',
    wellType: '直井',
    depthTotalMD: 4250,
    depthTVD: 4250,
    horizontalLength: 0,
    casingSpec: '244.5mm × 177.8mm',
    tubingSize: '73mm (J55普通油管)',
    producingLayer: '古近系沙河街组沙三中段',
    spudDate: '2022-04-12',
    completionDate: '2022-07-20',
    status: '异常高压报警',
    dailyOilBbl: 135,
    dailyGasM3: 1800,
    dailyWaterBbl: 380,
    waterCut: 73.8, // 突增预警
    wellheadPressure: 10.4,
    bottomHolePressure: 18.2,
    wellheadTemp: 52.0,
    gasOilRatioGOR: 84,
    chokeSize: 5.0,
    arpsModel: {
      modelType: '指数递减',
      qi: 450,
      di: 0.28,
      b: 0.0,
      eurMMBbl: 0.65,
      remainingDays: 1200
    }
  },
  {
    id: 'WELL-004',
    name: '焦页4-2HF (涪陵主力页岩气井)',
    fieldId: 'OF-04',
    block: '焦石坝平桥背斜',
    wellType: '多段压裂页岩井',
    depthTotalMD: 5450,
    depthTVD: 3850,
    horizontalLength: 2100,
    casingSpec: '339.7mm × 244.5mm × 139.7mm',
    tubingSize: '88.9mm 耐磨冲刷油管',
    producingLayer: '志留系五峰-龙马溪组优质页岩',
    spudDate: '2024-05-18',
    completionDate: '2024-10-30',
    status: '自喷在产',
    dailyOilBbl: 0,
    dailyGasM3: 245000,
    dailyWaterBbl: 48,
    waterCut: 0,
    wellheadPressure: 38.5,
    bottomHolePressure: 45.2,
    wellheadTemp: 64.0,
    gasOilRatioGOR: 0,
    chokeSize: 11.0,
    arpsModel: {
      modelType: '双曲递减',
      qi: 350000,
      di: 0.38,
      b: 0.30,
      eurMMBbl: 1.85, // 气当量
      remainingDays: 3200
    }
  },
  {
    id: 'WELL-005',
    name: '普光101-4 (超高含硫气井 H2S 15%)',
    fieldId: 'OF-03',
    block: '普光构造带核心区',
    wellType: '直井',
    depthTotalMD: 5920,
    depthTVD: 5920,
    horizontalLength: 0,
    casingSpec: '339.7mm × 244.5mm × 177.8mm (全井镍基合金)',
    tubingSize: '114.3mm Inconel 825 耐腐油管',
    producingLayer: '三叠系飞仙关组鲕粒灰岩',
    spudDate: '2023-08-10',
    completionDate: '2024-01-25',
    status: '自喷在产',
    dailyOilBbl: 15,
    dailyGasM3: 520000,
    dailyWaterBbl: 180,
    waterCut: 0,
    wellheadPressure: 46.8,
    bottomHolePressure: 56.4,
    wellheadTemp: 72.0,
    gasOilRatioGOR: 0,
    chokeSize: 14.0,
    arpsModel: {
      modelType: '双曲递减',
      qi: 750000,
      di: 0.11,
      b: 0.25,
      eurMMBbl: 5.20,
      remainingDays: 5400
    }
  },
  {
    id: 'WELL-006',
    name: '胜注-104 (东辛深度高压注水井)',
    fieldId: 'OF-01',
    block: '东辛注水层组',
    wellType: '注水井',
    depthTotalMD: 2950,
    depthTVD: 2950,
    horizontalLength: 0,
    casingSpec: '244.5mm × 177.8mm',
    tubingSize: '73mm 环氧涂层防腐油管',
    producingLayer: '沙三中段水淹补充驱替层',
    spudDate: '2021-10-15',
    completionDate: '2021-12-28',
    status: '机抽在产',
    dailyOilBbl: 0,
    dailyGasM3: 0,
    dailyWaterBbl: -1450, // 注入量 1450 桶/日
    waterCut: 0,
    wellheadPressure: 19.5,
    bottomHolePressure: 32.0,
    wellheadTemp: 38.0,
    gasOilRatioGOR: 0,
    chokeSize: 6.0,
    arpsModel: {
      modelType: '指数递减',
      qi: 0,
      di: 0,
      b: 0,
      eurMMBbl: 0,
      remainingDays: 0
    }
  },
  {
    id: 'WELL-007',
    name: '齐鲁-CCUS-CO2-01 (二氧化碳注入驱油井)',
    fieldId: 'OF-01',
    block: '胜利牛庄洼陷驱油示范区',
    wellType: 'CO2注入井',
    depthTotalMD: 3100,
    depthTVD: 3100,
    horizontalLength: 0,
    casingSpec: '244.5mm × 177.8mm 316L衬里',
    tubingSize: '73mm 超临界CO2耐低温油管',
    producingLayer: '沙四段特低渗难动用储层',
    spudDate: '2024-03-01',
    completionDate: '2024-06-15',
    status: '自喷在产',
    dailyOilBbl: 0,
    dailyGasM3: 0,
    dailyWaterBbl: 0,
    waterCut: 0,
    wellheadPressure: 21.0,
    bottomHolePressure: 36.8,
    wellheadTemp: 18.0,
    gasOilRatioGOR: 0,
    chokeSize: 4.5,
    arpsModel: {
      modelType: '指数递减',
      qi: 0,
      di: 0,
      b: 0,
      eurMMBbl: 0,
      remainingDays: 0
    }
  }
];

// 全球管网数字孪生模型与水力学参数
export interface PipelineNetworkEdge {
  id: string;
  name: string;
  category: '原油干线' | '天然气干线' | '成品油干线' | '高纯氢专线';
  startNode: string;
  endNode: string;
  lengthKm: number;
  outerDiameterMm: number;
  wallThicknessMm: number;
  designPressureMPa: number;
  currentInletPressureMPa: number;
  currentOutletPressureMPa: number;
  flowRateHour: number; // m³/h
  velocityMs: number; // 流速 m/s
  pumpingStationsCount: number;
  activePumps: number;
  temperatureC: number;
  corrosionIndexMm: number; // 剩余壁厚裕度 mm
  status: '正常输送' | '高负荷运行' | '泵站调压' | '切断检修' | '水力告警';
  // Weymouth 水力学公式计算元数据
  hydraulicModel: {
    frictionFactor: number;
    gasGravity?: number;
    headLossMeter: number;
    linepackStorageM3: number; // 管存量
  };
}

export const PIPELINE_NETWORK: PipelineNetworkEdge[] = [
  {
    id: 'PIPE-001',
    name: '川气东送主干管道 (普光-上海)',
    category: '天然气干线',
    startNode: '普光气田集输首站',
    endNode: '上海白鹤末站',
    lengthKm: 2170,
    outerDiameterMm: 1016,
    wallThicknessMm: 17.5,
    designPressureMPa: 10.0,
    currentInletPressureMPa: 8.8,
    currentOutletPressureMPa: 4.6,
    flowRateHour: 1540000, // Nm3/h
    velocityMs: 8.4,
    pumpingStationsCount: 12,
    activePumps: 11,
    temperatureC: 18.5,
    corrosionIndexMm: 3.2,
    status: '正常输送',
    hydraulicModel: {
      frictionFactor: 0.0125,
      gasGravity: 0.585,
      headLossMeter: 420,
      linepackStorageM3: 62000000
    }
  },
  {
    id: 'PIPE-002',
    name: '仪长原油复线 (仪征-长岭)',
    category: '原油干线',
    startNode: '仪征大型原油保税库',
    endNode: '长岭炼化常减压车间',
    lengthKm: 980,
    outerDiameterMm: 720,
    wallThicknessMm: 12.5,
    designPressureMPa: 6.4,
    currentInletPressureMPa: 5.4,
    currentOutletPressureMPa: 1.8,
    flowRateHour: 1250, // m3/h
    velocityMs: 1.85,
    pumpingStationsCount: 8,
    activePumps: 7,
    temperatureC: 42.0, // 加热输送
    corrosionIndexMm: 2.8,
    status: '正常输送',
    hydraulicModel: {
      frictionFactor: 0.021,
      headLossMeter: 380,
      linepackStorageM3: 395000
    }
  },
  {
    id: 'PIPE-003',
    name: '鲁皖成品油干线 (青岛-合肥)',
    category: '成品油干线',
    startNode: '青岛炼化成品油首站',
    endNode: '合肥中央储备油库',
    lengthKm: 680,
    outerDiameterMm: 508,
    wallThicknessMm: 9.5,
    designPressureMPa: 6.4,
    currentInletPressureMPa: 4.8,
    currentOutletPressureMPa: 1.5,
    flowRateHour: 520, // 汽柴油混油顺序输送
    velocityMs: 2.1,
    pumpingStationsCount: 5,
    activePumps: 5,
    temperatureC: 22.0,
    corrosionIndexMm: 3.5,
    status: '正常输送',
    hydraulicModel: {
      frictionFactor: 0.018,
      headLossMeter: 290,
      linepackStorageM3: 138000
    }
  },
  {
    id: 'PIPE-004',
    name: '顺北-塔河超深油气联络管道',
    category: '原油干线',
    startNode: '顺北一区油气处理站',
    endNode: '塔河一号联合站',
    lengthKm: 145,
    outerDiameterMm: 610,
    wallThicknessMm: 14.0,
    designPressureMPa: 8.0,
    currentInletPressureMPa: 6.8,
    currentOutletPressureMPa: 2.4,
    flowRateHour: 780,
    velocityMs: 1.95,
    pumpingStationsCount: 2,
    activePumps: 2,
    temperatureC: 55.0,
    corrosionIndexMm: 4.1,
    status: '正常输送',
    hydraulicModel: {
      frictionFactor: 0.0195,
      headLossMeter: 120,
      linepackStorageM3: 42000
    }
  },
  {
    id: 'PIPE-005',
    name: '京津冀纯氢高压输送管道 (燕山-大兴)',
    category: '高纯氢专线',
    startNode: '燕山石化绿氢提纯中心',
    endNode: '大兴国际氢能示范区',
    lengthKm: 75,
    outerDiameterMm: 355.6,
    wallThicknessMm: 8.0,
    designPressureMPa: 4.0,
    currentInletPressureMPa: 3.6,
    currentOutletPressureMPa: 2.2,
    flowRateHour: 9500, // Nm3/h (高纯电子级/燃料电池级氢气)
    velocityMs: 12.5,
    pumpingStationsCount: 1,
    activePumps: 1,
    temperatureC: 16.0,
    corrosionIndexMm: 4.8, // 氢脆实时声发射在线检测
    status: '正常输送',
    hydraulicModel: {
      frictionFactor: 0.011,
      gasGravity: 0.0696,
      headLossMeter: 45,
      linepackStorageM3: 65000
    }
  }
];

// 5大炼化一体化基地数字孪生与装置参数
export interface DetailedRefinery {
  id: string;
  name: string;
  location: string;
  designCapacityTonneYear: number; // 万吨/年
  actualThroughputTonneDay: number; // 实际加工量 吨/日
  operatingRatePercent: number; // %
  integratedEnergyCostMJ: number; // MJ/吨原油
  grossRefiningMarginUSD: number; // 美元/桶
  waterConsumptionTonne: number; // 新鲜水耗 t/t
  co2IntensityKgTonne: number; // kgCO2e/t
  
  // 装置单元
  units: {
    id: string;
    name: string;
    category: '常减压 (CDU/VDU)' | '重油催化裂化 (FCC)' | '加氢裂化 (HCU)' | '连续重整 (CCR)' | '乙烯裂解' | '芳烃抽提 (PX)' | '硫磺回收 (SRU)';
    capacityTonneDay: number;
    currentFeedrate: number;
    operatingLoad: number; // %
    inletTemperatureC: number;
    outletPressureMPa: number;
    catalystLifeRemainingDays: number;
    status: '正常' | '高负荷' | '降负荷' | '检修';
  }[];

  // 产物收率
  yields: {
    product: string;
    tonnePerDay: number;
    yieldPercent: number;
    qualityStandard: string;
  }[];
}

export const DETAILED_REFINERIES: DetailedRefinery[] = [
  {
    id: 'REF-01',
    name: '镇海炼化 (世界级炼化一体化示范基地)',
    location: '浙江省宁波市镇海区',
    designCapacityTonneYear: 2300,
    actualThroughputTonneDay: 64200,
    operatingRatePercent: 92.4,
    integratedEnergyCostMJ: 574,
    grossRefiningMarginUSD: 14.8,
    waterConsumptionTonne: 0.42,
    co2IntensityKgTonne: 154,
    units: [
      { id: 'U-CDU4', name: '1000万吨/年 常减压四套 (CDU-4)', category: '常减压 (CDU/VDU)', capacityTonneDay: 28000, currentFeedrate: 26200, operatingLoad: 93.5, inletTemperatureC: 368, outletPressureMPa: 0.28, catalystLifeRemainingDays: 780, status: '正常' },
      { id: 'U-FCC2', name: '300万吨/年 重油催化裂化二套 (FCC-2)', category: '重油催化裂化 (FCC)', capacityTonneDay: 8500, currentFeedrate: 7950, operatingLoad: 93.5, inletTemperatureC: 512, outletPressureMPa: 0.22, catalystLifeRemainingDays: 240, status: '正常' },
      { id: 'U-HCU3', name: '400万吨/年 加氢裂化三套 (HCU-3)', category: '加氢裂化 (HCU)', capacityTonneDay: 11500, currentFeedrate: 10800, operatingLoad: 93.9, inletTemperatureC: 395, outletPressureMPa: 16.8, catalystLifeRemainingDays: 620, status: '正常' },
      { id: 'U-CCR2', name: '300万吨/年 连续重整装置 (CCR-2)', category: '连续重整 (CCR)', capacityTonneDay: 8600, currentFeedrate: 7980, operatingLoad: 92.8, inletTemperatureC: 525, outletPressureMPa: 0.55, catalystLifeRemainingDays: 850, status: '正常' },
      { id: 'U-ETH1', name: '120万吨/年 乙烯裂解装置 (ETH-1)', category: '乙烯裂解', capacityTonneDay: 3500, currentFeedrate: 3420, operatingLoad: 97.7, inletTemperatureC: 840, outletPressureMPa: 0.18, catalystLifeRemainingDays: 45, status: '高负荷' },
      { id: 'U-PX2', name: '200万吨/年 对二甲苯芳烃联合装置 (PX-2)', category: '芳烃抽提 (PX)', capacityTonneDay: 5800, currentFeedrate: 5350, operatingLoad: 92.2, inletTemperatureC: 410, outletPressureMPa: 1.85, catalystLifeRemainingDays: 520, status: '正常' },
      { id: 'U-SRU3', name: '20万吨/年 克劳斯硫磺回收 (SRU-3)', category: '硫磺回收 (SRU)', capacityTonneDay: 580, currentFeedrate: 520, operatingLoad: 89.6, inletTemperatureC: 1180, outletPressureMPa: 0.05, catalystLifeRemainingDays: 920, status: '正常' }
    ],
    yields: [
      { product: '国VI-B 95#/98# 清洁汽油', tonnePerDay: 15400, yieldPercent: 24.0, qualityStandard: 'GB 17930-2016 硫<10ppm' },
      { product: '国VI-B 0# 低凝柴油', tonnePerDay: 17800, yieldPercent: 27.7, qualityStandard: 'GB 19147-2016 十六烷值>51' },
      { product: '3号 Jet A-1 航空煤油', tonnePerDay: 7200, yieldPercent: 11.2, qualityStandard: 'GB 6537 闪点>38℃' },
      { product: '轻质石脑油 (乙烯优质裂解料)', tonnePerDay: 11800, yieldPercent: 18.4, qualityStandard: '链烷烃>72%' },
      { product: '对二甲苯 (PX) 纯品', tonnePerDay: 5200, yieldPercent: 8.1, qualityStandard: '纯度>99.7%' },
      { product: '高纯固体硫磺 (副产)', tonnePerDay: 480, yieldPercent: 0.75, qualityStandard: '纯度>99.95%' },
      { product: '重交沥青与减压渣油', tonnePerDay: 4800, yieldPercent: 7.48, qualityStandard: 'AH-70 标准' }
    ]
  },
  {
    id: 'REF-02',
    name: '茂名石化 (华南沿海重要石化枢纽)',
    location: '广东省茂名市',
    designCapacityTonneYear: 2000,
    actualThroughputTonneDay: 54800,
    operatingRatePercent: 89.5,
    integratedEnergyCostMJ: 592,
    grossRefiningMarginUSD: 13.2,
    waterConsumptionTonne: 0.46,
    co2IntensityKgTonne: 162,
    units: [
      { id: 'M-CDU3', name: '800万吨/年 常减压三套 (CDU-3)', category: '常减压 (CDU/VDU)', capacityTonneDay: 22000, currentFeedrate: 19800, operatingLoad: 90.0, inletTemperatureC: 365, outletPressureMPa: 0.25, catalystLifeRemainingDays: 650, status: '正常' },
      { id: 'M-FCC3', name: '280万吨/年 重油催化裂化三套', category: '重油催化裂化 (FCC)', capacityTonneDay: 7800, currentFeedrate: 7000, operatingLoad: 89.7, inletTemperatureC: 510, outletPressureMPa: 0.20, catalystLifeRemainingDays: 180, status: '正常' },
      { id: 'M-HCU2', name: '320万吨/年 加氢裂化装置', category: '加氢裂化 (HCU)', capacityTonneDay: 9000, currentFeedrate: 8100, operatingLoad: 90.0, inletTemperatureC: 390, outletPressureMPa: 16.2, catalystLifeRemainingDays: 480, status: '正常' },
      { id: 'M-ETH1', name: '100万吨/年 乙烯装置', category: '乙烯裂解', capacityTonneDay: 2900, currentFeedrate: 2750, operatingLoad: 94.8, inletTemperatureC: 835, outletPressureMPa: 0.17, catalystLifeRemainingDays: 60, status: '正常' }
    ],
    yields: [
      { product: '国VI-B 汽油', tonnePerDay: 12800, yieldPercent: 23.3, qualityStandard: 'GB 17930' },
      { product: '国VI-B 柴油', tonnePerDay: 16500, yieldPercent: 30.1, qualityStandard: 'GB 19147' },
      { product: '航煤 3号', tonnePerDay: 5800, yieldPercent: 10.6, qualityStandard: 'GB 6537' },
      { product: '石脑油与聚合物原料', tonnePerDay: 9600, yieldPercent: 17.5, qualityStandard: '工业级' },
      { product: '润滑油基础油 (高档III类)', tonnePerDay: 2400, yieldPercent: 4.4, qualityStandard: 'API Group III' },
      { product: '石油焦与硫磺', tonnePerDay: 2100, yieldPercent: 3.8, qualityStandard: '电极级' }
    ]
  },
  {
    id: 'REF-03',
    name: '上海石化 (精细化工与高科技碳纤维基底)',
    location: '上海市金山区杭州湾畔',
    designCapacityTonneYear: 1600,
    actualThroughputTonneDay: 43200,
    operatingRatePercent: 86.8,
    integratedEnergyCostMJ: 605,
    grossRefiningMarginUSD: 15.4, // 高端化工加成
    waterConsumptionTonne: 0.48,
    co2IntensityKgTonne: 168,
    units: [
      { id: 'S-CDU2', name: '常减压二套', category: '常减压 (CDU/VDU)', capacityTonneDay: 18000, currentFeedrate: 15600, operatingLoad: 86.6, inletTemperatureC: 362, outletPressureMPa: 0.26, catalystLifeRemainingDays: 820, status: '正常' },
      { id: 'S-ETH2', name: '80万吨/年 乙烯装置', category: '乙烯裂解', capacityTonneDay: 2300, currentFeedrate: 2150, operatingLoad: 93.4, inletTemperatureC: 842, outletPressureMPa: 0.19, catalystLifeRemainingDays: 120, status: '正常' }
    ],
    yields: [
      { product: '聚酯级高纯PTA/EG原料', tonnePerDay: 7500, yieldPercent: 17.3, qualityStandard: '优等品' },
      { product: '大丝束高端碳纤维原丝料 (48K)', tonnePerDay: 450, yieldPercent: 1.0, qualityStandard: '航空级/风电特种级' },
      { product: '清洁汽柴油', tonnePerDay: 21000, yieldPercent: 48.6, qualityStandard: '国VI-B' },
      { product: '医用级聚丙烯熔喷料', tonnePerDay: 2800, yieldPercent: 6.5, qualityStandard: 'Y26 高流动' }
    ]
  },
  {
    id: 'REF-04',
    name: '燕山石化 (京津冀清洁能源与氢能保障中心)',
    location: '北京市房山区',
    designCapacityTonneYear: 1000,
    actualThroughputTonneDay: 26800,
    operatingRatePercent: 82.5,
    integratedEnergyCostMJ: 622,
    grossRefiningMarginUSD: 12.1,
    waterConsumptionTonne: 0.40,
    co2IntensityKgTonne: 172,
    units: [
      { id: 'Y-CDU1', name: '常减压改造装置', category: '常减压 (CDU/VDU)', capacityTonneDay: 12000, currentFeedrate: 9800, operatingLoad: 81.6, inletTemperatureC: 360, outletPressureMPa: 0.24, catalystLifeRemainingDays: 910, status: '正常' },
      { id: 'Y-H2', name: '2000标立/小时 燃料电池氢提纯装置', category: '硫磺回收 (SRU)', capacityTonneDay: 180, currentFeedrate: 165, operatingLoad: 91.6, inletTemperatureC: 45, outletPressureMPa: 2.5, catalystLifeRemainingDays: 1400, status: '正常' }
    ],
    yields: [
      { product: '高纯燃料电池级氢气 (99.999%)', tonnePerDay: 8.5, yieldPercent: 0.03, qualityStandard: 'GB/T 37244-2018' },
      { product: '特种合成丁基橡胶', tonnePerDay: 1200, yieldPercent: 4.5, qualityStandard: '医用胶塞/轮胎气密层' },
      { product: '京VI标准特种汽柴油', tonnePerDay: 15400, yieldPercent: 57.4, qualityStandard: 'DB11/ 238-2021' }
    ]
  },
  {
    id: 'REF-05',
    name: '青岛炼化 (现代化深水港口临海炼厂)',
    location: '山东省青岛市黄岛区',
    designCapacityTonneYear: 1200,
    actualThroughputTonneDay: 33400,
    operatingRatePercent: 93.8,
    integratedEnergyCostMJ: 568,
    grossRefiningMarginUSD: 14.2,
    waterConsumptionTonne: 0.38,
    co2IntensityKgTonne: 151,
    units: [
      { id: 'Q-CDU1', name: '1200万吨/年 大型常减压', category: '常减压 (CDU/VDU)', capacityTonneDay: 35000, currentFeedrate: 33400, operatingLoad: 95.4, inletTemperatureC: 369, outletPressureMPa: 0.28, catalystLifeRemainingDays: 740, status: '正常' }
    ],
    yields: [
      { product: '低硫保税船用燃料油 (0.5% LSFO)', tonnePerDay: 8500, yieldPercent: 25.4, qualityStandard: 'IMO 2020 国际公约标准' },
      { product: '高标准清洁汽柴油', tonnePerDay: 18200, yieldPercent: 54.5, qualityStandard: '国VI-B' }
    ]
  }
];

// 综合能源站与零售网络 (单站数字孪生)
export interface DetailedGasStation {
  id: string;
  name: string;
  city: string;
  province: string;
  stationType: '标准加油站' | '油氢电综合能源服务站' | '高速双枪重载站' | '光储充放微电网站';
  dailyRevenueCNY: number; // 日营业额
  dailyGrossMarginCNY: number; // 毛利
  dailyTrafficCount: number; // 进站车次
  
  // 地下油罐与氢电传感器
  undergroundTanks: {
    tankId: string;
    product: '92# 汽油' | '95# 汽油' | '98# 汽油' | '0# 柴油' | '高压70MPa氢气' | '液氢罐';
    currentLevelM: number; // 液位高度 m
    currentVolumeL: number; // 升
    maxCapacityL: number;
    tankPressureMPa: number;
    waterHeightMm: number; // 水杂高度 mm
    status: '正常' | '告警' | '卸油中';
  }[];
  
  // 加油机与充电桩设备
  dispensers: {
    dispenserId: string;
    nozzleCount: number;
    products: string[];
    dailyFlowL: number;
    isOccupied: boolean;
  }[];
  
  evChargingPiles: {
    pileId: string;
    type: '120kW 直流双枪超充' | '480kW 极速液冷超充' | '换电站工位';
    powerKw: number;
    dailyKwh: number;
    status: '充电中' | '空闲' | '维护';
  }[];
  
  convenienceStore: {
    dailySalesCNY: number;
    topProducts: string[];
    coffeeCupsSold: number;
  };
}

export const DETAILED_STATIONS: DetailedGasStation[] = [
  {
    id: 'STA-001',
    name: '北京大兴西红门智慧综合能源旗舰站',
    city: '北京',
    province: '北京市',
    stationType: '油氢电综合能源服务站',
    dailyRevenueCNY: 284500,
    dailyGrossMarginCNY: 48200,
    dailyTrafficCount: 1680,
    undergroundTanks: [
      { tankId: 'TK-01', product: '92# 汽油', currentLevelM: 2.85, currentVolumeL: 34200, maxCapacityL: 50000, tankPressureMPa: 0.02, waterHeightMm: 4, status: '正常' },
      { tankId: 'TK-02', product: '95# 汽油', currentLevelM: 3.10, currentVolumeL: 38500, maxCapacityL: 50000, tankPressureMPa: 0.02, waterHeightMm: 3, status: '正常' },
      { tankId: 'TK-03', product: '98# 汽油', currentLevelM: 1.45, currentVolumeL: 15800, maxCapacityL: 30000, tankPressureMPa: 0.02, waterHeightMm: 2, status: '正常' },
      { tankId: 'TK-04', product: '0# 柴油', currentLevelM: 2.10, currentVolumeL: 22000, maxCapacityL: 40000, tankPressureMPa: 0.01, waterHeightMm: 5, status: '正常' },
      { tankId: 'TK-H2', product: '高压70MPa氢气', currentLevelM: 0, currentVolumeL: 850, maxCapacityL: 1200, tankPressureMPa: 45.2, waterHeightMm: 0, status: '正常' }
    ],
    dispensers: [
      { dispenserId: 'D-01', nozzleCount: 4, products: ['92#', '95#'], dailyFlowL: 12400, isOccupied: true },
      { dispenserId: 'D-02', nozzleCount: 4, products: ['95#', '98#'], dailyFlowL: 14200, isOccupied: true },
      { dispenserId: 'D-03', nozzleCount: 2, products: ['0# 柴油'], dailyFlowL: 6800, isOccupied: false },
      { dispenserId: 'D-H2', nozzleCount: 2, products: ['35MPa/70MPa 氢气'], dailyFlowL: 1200, isOccupied: true }
    ],
    evChargingPiles: [
      { pileId: 'EV-01', type: '480kW 极速液冷超充', powerKw: 480, dailyKwh: 1850, status: '充电中' },
      { pileId: 'EV-02', type: '120kW 直流双枪超充', powerKw: 120, dailyKwh: 920, status: '充电中' },
      { pileId: 'EV-03', type: '120kW 直流双枪超充', powerKw: 120, dailyKwh: 840, status: '空闲' }
    ],
    convenienceStore: {
      dailySalesCNY: 36800,
      topProducts: ['易捷卓玛泉', '长城润滑油', '易捷咖啡', '车用尿素液'],
      coffeeCupsSold: 285
    }
  },
  {
    id: 'STA-002',
    name: '上海东方路智慧能源站 (近世纪大道)',
    city: '上海',
    province: '上海市',
    stationType: '光储充放微电网站',
    dailyRevenueCNY: 215000,
    dailyGrossMarginCNY: 39500,
    dailyTrafficCount: 1420,
    undergroundTanks: [
      { tankId: 'SH-01', product: '92# 汽油', currentLevelM: 2.45, currentVolumeL: 28400, maxCapacityL: 40000, tankPressureMPa: 0.02, waterHeightMm: 3, status: '正常' },
      { tankId: 'SH-02', product: '95# 汽油', currentLevelM: 2.90, currentVolumeL: 34500, maxCapacityL: 40000, tankPressureMPa: 0.02, waterHeightMm: 2, status: '正常' }
    ],
    dispensers: [
      { dispenserId: 'D-01', nozzleCount: 4, products: ['92#', '95#'], dailyFlowL: 15400, isOccupied: true }
    ],
    evChargingPiles: [
      { pileId: 'SH-EV1', type: '480kW 极速液冷超充', powerKw: 480, dailyKwh: 2450, status: '充电中' },
      { pileId: 'SH-EV2', type: '120kW 直流双枪超充', powerKw: 120, dailyKwh: 1200, status: '充电中' }
    ],
    convenienceStore: {
      dailySalesCNY: 24500,
      topProducts: ['易捷咖啡', '能量饮料', '车载香薰'],
      coffeeCupsSold: 340
    }
  }
];

// 石化产业链物料平衡引擎数据 (质量/体积/能量平衡)
export interface MaterialBalanceNode {
  unitId: string;
  unitName: string;
  location: string;
  inputs: { name: string; flowTonneHour: number; tempC: number; enthalpyMJ: number }[];
  outputs: { name: string; flowTonneHour: number; tempC: number; enthalpyMJ: number }[];
  lossTonneHour: number;
  unbalancedTolerancePercent: number; // 平衡偏差 %
  status: '平衡核验通过' | '轻度物料漂移' | '计量仪表异常告警';
  massBalanceEquation: string;
  energyBalanceEquation: string;
}

export const MATERIAL_BALANCE_DATA: MaterialBalanceNode[] = [
  {
    unitId: 'MB-01',
    unitName: '镇海炼化 CDU-4 常压分馏物料与能量衡算',
    location: '常减压装置区',
    inputs: [
      { name: '混合原油进料 (API 32.5, S 1.45%)', flowTonneHour: 1091.6, tempC: 368, enthalpyMJ: 845200 }
    ],
    outputs: [
      { name: '塔顶未凝气与石脑油馏分', flowTonneHour: 201.2, tempC: 120, enthalpyMJ: 142000 },
      { name: '常压一线 (重石脑油/溶剂油料)', flowTonneHour: 98.4, tempC: 175, enthalpyMJ: 78500 },
      { name: '常压二线 (直馏航空煤油馏分)', flowTonneHour: 122.5, tempC: 235, enthalpyMJ: 96400 },
      { name: '常压三线 (轻柴油馏分)', flowTonneHour: 285.0, tempC: 310, enthalpyMJ: 224000 },
      { name: '常压塔底重油 (送减压炉)', flowTonneHour: 382.4, tempC: 355, enthalpyMJ: 301200 }
    ],
    lossTonneHour: 2.1, // 0.19% 属于工艺正常挥发与加热炉烟气带走
    unbalancedTolerancePercent: 0.19,
    status: '平衡核验通过',
    massBalanceEquation: 'ΣM_in (1091.6 t/h) = ΣM_out (1089.5 t/h) + M_loss (2.1 t/h)',
    energyBalanceEquation: 'Q_feed + Q_furnace = Q_products + Q_condenser + Q_loss (ΔH = 0.04%)'
  },
  {
    unitId: 'MB-02',
    unitName: '茂名石化 100万吨乙烯裂解炉区物料平衡',
    location: '化工裂解车间',
    inputs: [
      { name: '轻石脑油裂解原料', flowTonneHour: 142.5, tempC: 65, enthalpyMJ: 95400 },
      { name: '高压高温稀释蒸汽', flowTonneHour: 71.2, tempC: 185, enthalpyMJ: 185000 }
    ],
    outputs: [
      { name: '高纯聚合级乙烯 (C2H4)', flowTonneHour: 45.6, tempC: -100, enthalpyMJ: 42100 },
      { name: '聚合级丙烯 (C3H6)', flowTonneHour: 22.8, tempC: 40, enthalpyMJ: 24500 },
      { name: '混合碳四/丁二烯馏分', flowTonneHour: 14.2, tempC: 35, enthalpyMJ: 16800 },
      { name: '裂解汽油与芳烃组分 (C6-C8)', flowTonneHour: 28.4, tempC: 85, enthalpyMJ: 31200 },
      { name: '裂解燃油/重燃料油', flowTonneHour: 6.8, tempC: 150, enthalpyMJ: 8200 },
      { name: '甲烷氢与酸性尾气', flowTonneHour: 24.5, tempC: -140, enthalpyMJ: 18900 },
      { name: '冷凝急冷水循环回收', flowTonneHour: 70.8, tempC: 85, enthalpyMJ: 135000 }
    ],
    lossTonneHour: 0.6,
    unbalancedTolerancePercent: 0.28,
    status: '平衡核验通过',
    massBalanceEquation: 'M_naphtha (142.5) + M_steam (71.2) = ΣM_out (213.1) + M_loss (0.6)',
    energyBalanceEquation: 'Q_fuel_gas_combustion + Q_feed = Q_cracked_gas + Q_quench_recovery'
  }
];

// 全球能源库存管理 (原油罐、成品油库、LNG保税罐、地下储气库)
export interface StorageFacility {
  id: string;
  name: string;
  category: '原油大型保税库' | '成品油中央储备库' | '沿海LNG大型低温储罐' | '枯竭油气藏地下储气库' | '盐穴储气储氢库';
  location: string;
  currentInventoryVolume: number; // 标方或桶或吨
  maxCapacityVolume: number;
  unit: string;
  fillRatePercent: number; // 库容饱和度 %
  dailyInflow: number;
  dailyOutflow: number;
  daysToExhaustion: number; // 预计耗尽天数 (应急保障天数)
  safetyPressureMPa: number;
  status: '正常储备' | '高位预警' | '紧急调出' | '定期巡检';
}

export const STORAGE_FACILITIES: StorageFacility[] = [
  {
    id: 'ST-01',
    name: '浙江舟山岙山国家战略原油储备基地 (中石化运营)',
    category: '原油大型保税库',
    location: '浙江省舟山群岛',
    currentInventoryVolume: 38500000,
    maxCapacityVolume: 45000000,
    unit: '桶 (bbl)',
    fillRatePercent: 85.5,
    dailyInflow: 450000, // 30万吨油轮卸载
    dailyOutflow: 380000, // 甬沪宁管线外输
    daysToExhaustion: 101,
    safetyPressureMPa: 0.05,
    status: '正常储备'
  },
  {
    id: 'ST-02',
    name: '天津南港 22万立方米 LNG 超大低温储罐区',
    category: '沿海LNG大型低温储罐',
    location: '天津市南港工业区',
    currentInventoryVolume: 820000,
    maxCapacityVolume: 1000000,
    unit: 'm³ (液态LNG)',
    fillRatePercent: 82.0,
    dailyInflow: 65000,
    dailyOutflow: 58000, // 气化后约 3500万标立/日
    daysToExhaustion: 14.1,
    safetyPressureMPa: 0.02,
    status: '正常储备'
  },
  {
    id: 'ST-03',
    name: '文96 枯竭气藏地下储气库 (中原油田)',
    category: '枯竭油气藏地下储气库',
    location: '河南省濮阳市',
    currentInventoryVolume: 580000000,
    maxCapacityVolume: 650000000,
    unit: 'Nm³ (天然气)',
    fillRatePercent: 89.2,
    dailyInflow: 4500000, // 夏季注气期
    dailyOutflow: 0,
    daysToExhaustion: 999,
    safetyPressureMPa: 24.5,
    status: '正常储备'
  },
  {
    id: 'ST-04',
    name: '江苏金坛 盐穴压气储能与储氢实验库',
    category: '盐穴储气储氢库',
    location: '江苏省常州市金坛区',
    currentInventoryVolume: 42000000,
    maxCapacityVolume: 50000000,
    unit: 'Nm³ (天然气/氢气混配)',
    fillRatePercent: 84.0,
    dailyInflow: 850000,
    dailyOutflow: 620000,
    daysToExhaustion: 67,
    safetyPressureMPa: 18.0,
    status: '正常储备'
  }
];

// 国际油气贸易与 Crude Slate 优化器
export interface CrudeGrade {
  name: string;
  originCountry: string;
  apiGravity: number;
  sulfurContentPercent: number; // %
  acidValueMgKOHg: number; // 酸值 mgKOH/g
  spotPriceUSD: number; // 美元/桶
  freightToNingboUSD: number; // 运费 美元/桶
  cifLandedCostUSD: number; // 到岸成本
  refiningSuitability: string;
  yieldGasolinePercent: number;
  yieldDieselPercent: number;
  yieldKerosenePercent: number;
  yieldNaphthaPercent: number;
  yieldResiduePercent: number;
}

export const CRUDE_SLATE_OPTIONS: CrudeGrade[] = [
  {
    name: '阿曼原油 (Oman Light/Medium)',
    originCountry: '阿曼/中东',
    apiGravity: 33.2,
    sulfurContentPercent: 1.05,
    acidValueMgKOHg: 0.12,
    spotPriceUSD: 83.15,
    freightToNingboUSD: 2.10,
    cifLandedCostUSD: 85.25,
    refiningSuitability: '镇海/茂名主力加工原料，适合生产优质柴油与高芳烃重整料',
    yieldGasolinePercent: 21.5,
    yieldDieselPercent: 28.5,
    yieldKerosenePercent: 10.2,
    yieldNaphthaPercent: 16.5,
    yieldResiduePercent: 23.3
  },
  {
    name: '阿拉伯轻质原油 (Arab Light - 沙特阿美)',
    originCountry: '沙特阿拉伯',
    apiGravity: 34.0,
    sulfurContentPercent: 1.80,
    acidValueMgKOHg: 0.15,
    spotPriceUSD: 84.20,
    freightToNingboUSD: 2.25,
    cifLandedCostUSD: 86.45,
    refiningSuitability: '加氢裂化能力充足炼厂首选，综合产品收率平衡',
    yieldGasolinePercent: 22.0,
    yieldDieselPercent: 29.0,
    yieldKerosenePercent: 11.0,
    yieldNaphthaPercent: 17.0,
    yieldResiduePercent: 21.0
  },
  {
    name: '布伦特原油 (Brent Dtd)',
    originCountry: '英国/北海',
    apiGravity: 38.3,
    sulfurContentPercent: 0.37,
    acidValueMgKOHg: 0.08,
    spotPriceUSD: 82.45,
    freightToNingboUSD: 4.80,
    cifLandedCostUSD: 87.25,
    refiningSuitability: '极低硫轻质油，免加氢脱硫负荷，但运费较高',
    yieldGasolinePercent: 26.5,
    yieldDieselPercent: 31.0,
    yieldKerosenePercent: 13.5,
    yieldNaphthaPercent: 19.5,
    yieldResiduePercent: 9.5
  },
  {
    name: 'ESPO 东西伯利亚-太平洋原油',
    originCountry: '俄罗斯',
    apiGravity: 34.8,
    sulfurContentPercent: 0.55,
    acidValueMgKOHg: 0.06,
    spotPriceUSD: 74.50, // 折价
    freightToNingboUSD: 1.40, // 航程短
    cifLandedCostUSD: 75.90,
    refiningSuitability: '低硫中质高经济性，炼油毛利优势显著，青岛/天津常炼',
    yieldGasolinePercent: 23.0,
    yieldDieselPercent: 32.5,
    yieldKerosenePercent: 12.0,
    yieldNaphthaPercent: 17.5,
    yieldResiduePercent: 15.0
  },
  {
    name: '巴西图皮 (Tupi 盐下轻质)',
    originCountry: '巴西',
    apiGravity: 30.2,
    sulfurContentPercent: 0.35,
    acidValueMgKOHg: 0.28,
    spotPriceUSD: 81.80,
    freightToNingboUSD: 3.90,
    cifLandedCostUSD: 85.70,
    refiningSuitability: '超低金属低硫，减压蜡油催化裂化裂解性能优异',
    yieldGasolinePercent: 24.0,
    yieldDieselPercent: 30.0,
    yieldKerosenePercent: 11.5,
    yieldNaphthaPercent: 18.0,
    yieldResiduePercent: 16.5
  }
];

// HSE 安全与环境应急监测 (实时传感器)
export interface HSEHazardZone {
  id: string;
  name: string;
  location: string;
  riskLevel: '重大危险源 (一级)' | '较大危险源 (二级)' | '一般风险源 (三级)' | '安全绿色区';
  personnelOnSiteCount: number;
  gasSensors: {
    gasType: 'H2S 硫化氢' | 'CH4 可燃气体/甲烷' | 'CO 一氧化碳' | 'VOCs 挥发性有机物' | 'SO2 二氧化硫';
    concentrationPpm: number;
    thresholdWarningPpm: number;
    thresholdAlarmPpm: number;
    status: '正常' | '预警' | '高危报警';
  }[];
  temperatureThermalC: number;
  fireWaterPressureMPa: number;
  activeWorkPermitsCount: number; // 动火作业/受限空间作业票
  lastInspectionDate: string;
}

export const HSE_HAZARD_ZONES: HSEHazardZone[] = [
  {
    id: 'HSE-01',
    name: '普光天然气净化厂 - 一级硫磺脱除装置区',
    location: '四川宣汉高含硫处理厂',
    riskLevel: '重大危险源 (一级)',
    personnelOnSiteCount: 18,
    gasSensors: [
      { gasType: 'H2S 硫化氢', concentrationPpm: 1.2, thresholdWarningPpm: 5.0, thresholdAlarmPpm: 10.0, status: '正常' },
      { gasType: 'CH4 可燃气体/甲烷', concentrationPpm: 45, thresholdWarningPpm: 500, thresholdAlarmPpm: 1000, status: '正常' },
      { gasType: 'SO2 二氧化硫', concentrationPpm: 0.8, thresholdWarningPpm: 2.0, thresholdAlarmPpm: 5.0, status: '正常' }
    ],
    temperatureThermalC: 48.5,
    fireWaterPressureMPa: 1.25,
    activeWorkPermitsCount: 3,
    lastInspectionDate: '2026-09-18 09:30'
  },
  {
    id: 'HSE-02',
    name: '镇海炼化 - 1000万吨常减压装置区 (CDU-4)',
    location: '宁波市镇海区主炼区',
    riskLevel: '重大危险源 (一级)',
    personnelOnSiteCount: 24,
    gasSensors: [
      { gasType: 'CH4 可燃气体/甲烷', concentrationPpm: 85, thresholdWarningPpm: 500, thresholdAlarmPpm: 1000, status: '正常' },
      { gasType: 'VOCs 挥发性有机物', concentrationPpm: 4.2, thresholdWarningPpm: 10.0, thresholdAlarmPpm: 25.0, status: '正常' },
      { gasType: 'CO 一氧化碳', concentrationPpm: 3.0, thresholdWarningPpm: 20.0, thresholdAlarmPpm: 50.0, status: '正常' }
    ],
    temperatureThermalC: 62.0,
    fireWaterPressureMPa: 1.30,
    activeWorkPermitsCount: 5,
    lastInspectionDate: '2026-09-18 10:15'
  },
  {
    id: 'HSE-03',
    name: '舟山岙山 - 30万吨级原油码头油轮卸载泊位',
    location: '岙山岛1号超级泊位',
    riskLevel: '较大危险源 (二级)',
    personnelOnSiteCount: 12,
    gasSensors: [
      { gasType: 'VOCs 挥发性有机物', concentrationPpm: 8.5, thresholdWarningPpm: 15.0, thresholdAlarmPpm: 30.0, status: '正常' },
      { gasType: 'CH4 可燃气体/甲烷', concentrationPpm: 110, thresholdWarningPpm: 500, thresholdAlarmPpm: 1000, status: '正常' }
    ],
    temperatureThermalC: 28.0,
    fireWaterPressureMPa: 1.20,
    activeWorkPermitsCount: 2,
    lastInspectionDate: '2026-09-18 08:45'
  }
];

// 辅助函数：根据指标Key生成规范的血缘与溯源元数据
export function generateLineage(
  metricName: string,
  displayValue: string,
  sourceSystem: DataLineage['sourceSystem'],
  deviceId: string,
  deviceName: string,
  location: string,
  formula: string,
  model?: string
): DataLineage {
  return {
    metricName,
    displayValue,
    rawValue: displayValue.replace(/[^0-9.-]/g, ''),
    rawUnit: displayValue.replace(/[0-9.-]/g, '').trim(),
    standardValue: displayValue.replace(/[^0-9.-]/g, ''),
    standardUnit: displayValue.replace(/[0-9.-]/g, '').trim(),
    conversionFactor: 1.0,
    sourceSystem,
    deviceId,
    deviceName,
    location,
    timestamp: '2026-09-18 10:50:00 CST',
    calculationFormula: formula,
    algorithmModel: model || '工业标准物质守恒/DCS实时加权平均引擎',
    modelVersion: 'SEIOS-Engine-v4.2.2026',
    confidenceInterval: '99.2% [置信区间 98.5% - 99.8%]',
    dataQuality: '优 (A级)',
    dataVersion: '2026.09.18.1050'
  };
}

// 国际大宗能源交易行情价格
export const MARKET_PRICES = [
  { name: '布伦特原油 Brent', spot: 84.50, change: 1.25, vol: 'ICE 期货', spread: '升水 +$1.85/bbl' },
  { name: 'WTI 原油', spot: 80.20, change: 0.95, vol: 'NYMEX', spread: '贴水 -$4.30/bbl' },
  { name: '阿曼原油 Oman', spot: 83.10, change: 1.10, vol: 'DME 迪拜', spread: 'DME 官方基准' },
  { name: 'ESPO 远东原油', spot: 78.60, change: -0.40, vol: '科济米诺现货', spread: '贴水 -$5.90/bbl' },
  { name: '亨利港天然气 HH', spot: 2.85, change: -1.80, vol: 'NYMEX $/MMBtu', spread: '现货平稳' },
  { name: '亚洲 JKM LNG', spot: 13.40, change: 2.30, vol: 'Platts $/MMBtu', spread: '冬储需求旺季' },
  { name: '新加坡 95# 汽油', spot: 98.50, change: 0.80, vol: 'FOB $/bbl', spread: '裂解价差 $14.0' }
];

// 新能源与氢能重点项目
export const NEW_ENERGY_PROJECTS = [
  {
    id: 'NE-001',
    name: '新疆库车绿氢示范工程',
    type: '光伏绿电电解水制氢',
    capacity: '20,000 吨/年 (2万吨绿氢)',
    currentOutput: '54.8 吨/日 (100% 满负荷)',
    annualCo2ReductionTonne: 485000,
    location: '新疆阿克苏库车市',
    status: '安全平稳运行中'
  },
  {
    id: 'NE-002',
    name: '雄安新区地热集中供暖',
    type: '深层中低温水热型地热',
    capacity: '供暖面积 8,500 万平方米',
    currentOutput: '循环水流量 4,800 m³/h',
    annualCo2ReductionTonne: 2100000,
    location: '河北雄安新区',
    status: '取热不耗水 100% 回灌'
  },
  {
    id: 'NE-003',
    name: '胜利油田油区光伏微电网',
    type: '油田自发自用分布式光伏+储能',
    capacity: '装机容量 850 MW',
    currentOutput: '实时发电功率 620 MW',
    annualCo2ReductionTonne: 820000,
    location: '山东东营胜利油田',
    status: '采油机自供电微电网'
  }
];

// 关键特种与旋转设备监测
export const CRITICAL_EQUIPMENT = [
  {
    id: 'EQ-001',
    name: '镇海炼化 CDU-4 原油主进料泵 (P-101A)',
    type: '高扬程多级离心泵 (3.2MW)',
    location: '镇海炼化常减压装置区',
    vibrationMmS: 2.1,
    bearingTempC: 68.5,
    oilLubricationQuality: '优 (介电常数正常, 水分<30ppm)',
    remainingUsefulLifeDays: 245,
    healthScore: 96,
    status: '健康运行',
    faultDiagnosis: '机组当前振动频谱平稳，1X 基频能量占比 92%，未检测到不对中、偏心或轴承滚珠点蚀征兆。建议按标准周期每 30 天进行润滑油在线抽样检测。'
  },
  {
    id: 'EQ-002',
    name: '茂名乙烯裂解气离心压缩机组 (C-201)',
    type: '38MW 工业汽轮机驱动裂解气压缩机',
    location: '茂名石化乙烯裂解区',
    vibrationMmS: 3.4,
    bearingTempC: 78.2,
    oilLubricationQuality: '良好 (微量颗粒 NAS 6级)',
    remainingUsefulLifeDays: 95,
    healthScore: 84,
    status: '轻度关注预警',
    faultDiagnosis: '高压缸轴端 2X 谐波振幅略有升高 (3.4 mm/s)，推测为干气密封微量积碳磨损扰动。结合 RUL 预测模型，无即时停机风险，建议在 90 天后秋季计划检修中安排干气密封件预防性更换。'
  },
  {
    id: 'EQ-003',
    name: '胜利油田新木注水站高压柱塞泵 (HP-304B)',
    type: '五缸卧式超高压注水柱塞泵 (28MPa)',
    location: '胜利油田纯梁采油厂',
    vibrationMmS: 1.8,
    bearingTempC: 62.0,
    oilLubricationQuality: '优 (无乳化杂质)',
    remainingUsefulLifeDays: 310,
    healthScore: 98,
    status: '健康运行',
    faultDiagnosis: '吸入与排出阀组密封面严密，排量 120 m³/h 保持额定输出，地层回注压力稳定在 22.5 MPa。'
  },
  {
    id: 'EQ-004',
    name: '川气东送普光首站压缩机组 (GC-102)',
    type: '25MW 变频防爆电机离心天然气增压机',
    location: '四川达州宣汉首站',
    vibrationMmS: 1.9,
    bearingTempC: 64.5,
    oilLubricationQuality: '优 (合成润滑油)',
    remainingUsefulLifeDays: 280,
    healthScore: 97,
    status: '健康运行',
    faultDiagnosis: '磁悬浮轴承控制系统反馈正常，防喘振阀 PID 闭环处于最优工作线，抗硫抗氢脆合金叶轮无结垢。'
  }
];

// HSE 特殊作业票证
export const HSE_PERMITS = [
  {
    id: 'TICKET-2026-0918-01',
    type: '特级动火作业票 (Hot Work)',
    location: '镇海炼化乙烯装置裂解炉区 F-101 旁路',
    applicant: '机修一车间动设备班',
    guardian: '安全员-王建国 (持证监护)',
    approver: '副总工程师-李长春',
    validUntil: '2026-09-18 18:00',
    status: '作业中'
  },
  {
    id: 'TICKET-2026-0918-02',
    type: '受限空间作业票 (Confined Space)',
    location: '舟山岙山原油储罐 T-102 内部清砂',
    applicant: '油库储运运维班',
    guardian: '安全员-赵志强 (气体连续监测)',
    approver: '安全总监-孙浩',
    validUntil: '2026-09-18 16:30',
    status: '作业中'
  },
  {
    id: 'TICKET-2026-0918-03',
    type: '高处作业票 (Working at Heights)',
    location: '茂名石化减压蒸馏塔 T-201 顶部管道检验',
    applicant: '无损检测工程队',
    guardian: '安全员-钱敏',
    approver: '车间主任-陈德明',
    validUntil: '2026-09-18 17:00',
    status: '作业中'
  }
];

// 可燃/有毒气体检测探头
export const GAS_DETECTORS = [
  {
    id: 'DET-01',
    gasType: 'H2S 硫化氢 (高毒)',
    location: '普光净化厂硫磺回收装置框架二层',
    currentValue: '0.8 ppm',
    alarmThreshold: '5.0 ppm',
    status: '安全受控 (在线)'
  },
  {
    id: 'DET-02',
    gasType: 'CH4 甲烷可燃气体',
    location: '川气东送南京分输站阀室',
    currentValue: '1.2% LEL',
    alarmThreshold: '20.0% LEL',
    status: '安全受控 (在线)'
  },
  {
    id: 'DET-03',
    gasType: 'VOCs 挥发性有机物',
    location: '镇海炼化装车栈桥油气回收区',
    currentValue: '3.4 mg/m³',
    alarmThreshold: '20.0 mg/m³',
    status: '安全受控 (在线)'
  },
  {
    id: 'DET-04',
    gasType: 'CO 一氧化碳',
    location: '茂名石化常减压重整加热炉区域',
    currentValue: '4.5 ppm',
    alarmThreshold: '25.0 ppm',
    status: '安全受控 (在线)'
  }
];

// CCUS 示范项目数据
export const CCUS_PROJECT_DATA = {
  name: '齐鲁石化 - 胜利油田百万吨级 CCUS 示范项目',
  capturePurityPercent: 99.5,
  captureCapacityAnnualTonne: 1000000,
  pipelineLengthKm: 109,
  pipelinePressureMPa: 8.5,
  pipelineMedium: '超临界高压密相二氧化碳 (Supercritical CO2)',
  injectionWellsCount: 73,
  recoveryImprovementPercent: 12.5,
  totalSequestrationToDateTonne: 1425000,
  status: '全产业链常态化连续运转中'
};

// AI 助手预置工业大模型机理与问答知识库
export const AI_ASSISTANT_KNOWLEDGE = [
  {
    keyword: '调配',
    query: '推荐镇海炼化今日最优原油混配 (Crude Slate) 方案',
    response: `【SEIOS 工业智能推荐 · 原油调配 LP 求解报告】\n基于当前国际现货到岸价与下游化工产品边际效益：\n1. 推荐原油混配比例：阿曼原油 (Oman) 40% + 远东低硫 (ESPO) 35% + 沙特轻质 (Arab Light) 25%。\n2. 调配优势分析：\n   - 加权到岸成本 (CIF) 优化至 $82.40/桶，较单一采购降低 $1.85/桶；\n   - 混配原油 API 比重 32.1，硫含量加权 1.25%，完全匹配镇海 CDU-4 常减压与渣油加氢装置负荷；\n   - 优质轻石脑油收率提升至 18.2%，可为 120万吨乙烯装置提供充足低碳进料，预计日增炼油毛利 ¥185 万元。`,
    lineageRef: '镇海炼化 DCS + 国际贸易平台 Platts 数据流 + Aspen PIMS 原油库'
  },
  {
    keyword: '漏失',
    query: '排查顺北 5-10H 井下 8200m 泥浆循环微量漏失原因与防漏对策',
    response: `【SEIOS 钻井地质工程协同诊断】\n1. 传感器反演：MWD/LWD 随钻测井显示 8215m 处钻遇奥陶系一间房组走滑断裂破碎带，裂隙宽度约 0.4~1.2mm。\n2. 漏失特征：立管循环压力下降 0.8 MPa，泥浆出口流量出现 3.2 L/s 微幅亏空，属微孔隙裂缝性漏失。\n3. 推荐工程对策：\n   - 立即将泥浆密度微调由 1.45 g/cm³ 降至 1.41 g/cm³，降低环空当量循环密度 (ECD)；\n   - 注入由微细目云母片 (200目) 与刚性碳酸钙构成的复合随钻堵漏剂 15 m³；\n   - 密切监视旋转防喷器与气侵监测，确保井控安全。`,
    lineageRef: '西北油田勘探开发指挥部 MWD 实时遥测流 + 地质断裂带三维地质模型'
  },
  {
    keyword: '极寒',
    query: '华东地区遭遇寒潮，川气东送管网如何优化调度以保障上海供气？',
    response: `【SEIOS 水力学与管网应急调峰预案】\n1. 负荷预测：预计未来 48 小时华东日用气量将跳增 2,200 万方 (+26.8%)。\n2. 调度执行指令：\n   - 普光首站压缩机全部满负荷起机，进站输送压力升至 9.8 MPa；\n   - 启动文96地下储气库以 850 万方/日 规模加速采气注网；\n   - 天津南港 LNG 接收站两座 22万方储罐开启应急气化外输回路 (450万方/日)；\n   - 预计上海白鹤末站压力将维持在 3.8 MPa 安全红线之上，确保居民生活与重点公用事业 100% 满额供气。`,
    lineageRef: '川气东送 SCADA 水力学 Weymouth 积分模型 + 天津南港 LNG 实时监控'
  },
  {
    keyword: 'CCUS',
    query: '测算齐鲁-胜利 CCUS 项目当前碳中和减排与驱油增效平衡点',
    response: `【SEIOS 工业碳资产与油藏开发综合核算】\n1. 碳捕集与封存：齐鲁石化第二化肥厂煤气化尾气提纯成本为 ¥168/吨 CO₂，超临界管道输送及注入综合能耗成本 ¥52/吨。\n2. 增油效益：胜利油田正理庄储层每注入 2.8 吨超临界 CO₂ 可置换采出 1 吨原油 (折合当前油价增收约 ¥4,200/吨油)。\n3. 净收益测算：扣除工程操作与折旧后，吨油综合增效收益为 ¥2,850 元，同时年实现 100 万吨国家核证自愿减排量 (CCER) 认证，具有极其显著的经济与环境双重正效益。`,
    lineageRef: '胜利油田开发地质档案 + 齐鲁石化能量计量衡算表 + 全国碳市场核证'
  }
];

// 全局指标数据血缘字典 (用于快速检索)
export const DATA_LINEAGE_DICTIONARY = [
  {
    metricName: '集团日产原油',
    sourceSystem: '油田自动化 SCADA 生产物联网 (A11/IoT)',
    sensorTag: 'OF-TOTAL-OIL-PROD-2026',
    collectionFrequency: '100 ms',
    calculationFormula: '日产油量 = Σ (单井地面高精度质量流量计瞬时流量 × 标定温度/压力补偿系数)',
    auditTrailId: 'AUDIT-CNPC-PROD-20260918-001',
    lastCalibratedTime: '2026-09-18 06:00:00 (国家法定计量合格)',
    responsibleRole: '中国石化油田勘探开发事业部生产运行处'
  },
  {
    metricName: '集团日产天然气',
    sourceSystem: '气田集气站 SCADA / DCS 计量系统',
    sensorTag: 'GAS-FIELD-TOTAL-M3',
    collectionFrequency: '100 ms',
    calculationFormula: '标方产气量 = Σ (超声波气体流量计标方累积量 × 压缩因子 Z)',
    auditTrailId: 'AUDIT-GAS-20260918-002',
    lastCalibratedTime: '2026-09-18 07:00:00',
    responsibleRole: '天然气分公司调度指挥中心'
  },
  {
    metricName: '炼厂原油日加工量',
    sourceSystem: '炼化一体化先进过程控制 (APC/DCS)',
    sensorTag: 'REF-CDU-TOTAL-TONNE-DAY',
    collectionFrequency: '50 ms',
    calculationFormula: '加工量 = Σ 各炼化基地常减压装置 (CDU) 进料质量流量计读数累加',
    auditTrailId: 'AUDIT-REF-20260918-003',
    lastCalibratedTime: '2026-09-18 08:00:00',
    responsibleRole: '炼油事业部生产调度处'
  },
  {
    metricName: '综合单桶炼油毛利',
    sourceSystem: '企业资源规划 (ERP/SAP) + LP 线性规划优化系统 (Aspen PIMS)',
    sensorTag: 'FIN-GRM-USD-BBL',
    collectionFrequency: '实时按日结算',
    calculationFormula: 'GRM ($/bbl) = (Σ 炼化产成品总市值 - 原油采购 CIF 成本 - 装置加工综合能耗与催化剂折耗) / 原油加工桶数',
    auditTrailId: 'AUDIT-FIN-20260918-004',
    lastCalibratedTime: '2026-09-18 09:00:00',
    responsibleRole: '财务计划部与国际事业公司 (UNIPEC)'
  },
  {
    metricName: 'CCUS 碳捕集与封存量',
    sourceSystem: '齐鲁-胜利 CCUS 工业专网 SCADA',
    sensorTag: 'CCUS-SEQUEST-TONNE-DAY',
    collectionFrequency: '100 ms',
    calculationFormula: '封存量 = 超临界 CO₂ 管道输送涡街质量流量计读数 × 注入井下井口计量核验',
    auditTrailId: 'AUDIT-CCUS-20260918-005',
    lastCalibratedTime: '2026-09-18 07:30:00',
    responsibleRole: '安全环保部与绿色低碳研究院'
  }
];

