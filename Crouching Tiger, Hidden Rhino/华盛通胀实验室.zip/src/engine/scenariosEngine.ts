import { ScenarioShockInput, ScenarioResult } from '../types/inflation';

/**
 * 华盛通胀实验室 - 宏观情景模拟引擎 (Scenario Lab Simulation Engine)
 */

export const presetScenarios: { id: string; name: string; description: string; input: ScenarioShockInput }[] = [
  {
    id: 'sc_energy_spike',
    name: '地缘冲击：国际能源价格飙升 25%',
    description: '原油与天然气大宗价格暴涨25%，伴随二阶通胀传导至运输与化学制品。',
    input: {
      energyPricePct: 25.0,
      foodPricePct: 5.0,
      fxDepreciationPct: 2.0,
      wageGrowthPct: 0.8,
      productivityGrowthPct: -0.5,
      unemploymentGap: 0.2,
      outputGap: -0.4,
      globalDemandPct: -1.0,
      importPricePct: 8.0,
      inflationExpectationsPct: 0.45,
      policyRateBp: 25,
    },
  },
  {
    id: 'sc_wage_spiral',
    name: '劳动力市场紧张：工资-物价螺旋 (+3% 工资增速)',
    description: '名义工资增速意外上行3个百分点，服务业单位劳动成本(ULC)高企，推动核心服务通胀粘性。',
    input: {
      energyPricePct: 0.0,
      foodPricePct: 1.0,
      fxDepreciationPct: 0.0,
      wageGrowthPct: 3.0,
      productivityGrowthPct: 0.2,
      unemploymentGap: -0.8,
      outputGap: 1.2,
      globalDemandPct: 1.0,
      importPricePct: 1.0,
      inflationExpectationsPct: 0.60,
      policyRateBp: 50,
    },
  },
  {
    id: 'sc_fx_depreciation',
    name: '汇率贬值冲击：本币即期汇率贬值 8%',
    description: '本币对美元汇率贬值8%，进口大宗商品与耐用消费品价格直接上行，推高输入性通胀。',
    input: {
      energyPricePct: 6.0,
      foodPricePct: 4.0,
      fxDepreciationPct: 8.0,
      wageGrowthPct: 0.5,
      productivityGrowthPct: 0.0,
      unemploymentGap: 0.1,
      outputGap: 0.2,
      globalDemandPct: -0.5,
      importPricePct: 12.0,
      inflationExpectationsPct: 0.35,
      policyRateBp: 25,
    },
  },
  {
    id: 'sc_demand_boom',
    name: '需求过热：全球与国内需求扩张 (产出缺口 +2.0%)',
    description: '财政与信贷扩张导致产出缺口提升2%，需求拉动型通胀显现，商品与服务全面提价。',
    input: {
      energyPricePct: 8.0,
      foodPricePct: 3.0,
      fxDepreciationPct: -1.0,
      wageGrowthPct: 1.8,
      productivityGrowthPct: 1.0,
      unemploymentGap: -1.2,
      outputGap: 2.0,
      globalDemandPct: 3.0,
      importPricePct: 3.5,
      inflationExpectationsPct: 0.50,
      policyRateBp: 75,
    },
  },
  {
    id: 'sc_supply_chain',
    name: '全球供应链梗阻与运费上涨 (+15% 进口价格)',
    description: '航运红海与关键港口梗阻导致全球运价飙升，输入性中间品价格大幅提升。',
    input: {
      energyPricePct: 12.0,
      foodPricePct: 8.0,
      fxDepreciationPct: 3.0,
      wageGrowthPct: 0.4,
      productivityGrowthPct: -0.8,
      unemploymentGap: 0.3,
      outputGap: -0.6,
      globalDemandPct: -1.5,
      importPricePct: 15.0,
      inflationExpectationsPct: 0.40,
      policyRateBp: 25,
    },
  },
  {
    id: 'sc_unanchored_exp',
    name: '通胀预期脱锚：长期通胀预期上行 +1.2%',
    description: '公众与金融市场通胀预期大幅脱锚，名义价格与工资设置形成自我实现循环。',
    input: {
      energyPricePct: 5.0,
      foodPricePct: 4.0,
      fxDepreciationPct: 3.0,
      wageGrowthPct: 2.2,
      productivityGrowthPct: -0.2,
      unemploymentGap: -0.3,
      outputGap: 0.8,
      globalDemandPct: 0.5,
      importPricePct: 4.0,
      inflationExpectationsPct: 1.20,
      policyRateBp: 100,
    },
  },
];

export function runScenarioSimulation(input: ScenarioShockInput, baseHeadline = 2.15, baseCore = 1.85, baseWage = 4.2): ScenarioResult {
  // Direct shock impact coefficients based on central bank structural elasticity
  const energyDirect = input.energyPricePct * 0.085; // 8.5% energy weight
  const foodDirect = input.foodPricePct * 0.185; // 18.5% food weight
  const fxDirect = input.fxDepreciationPct * 0.08; // FX pass through
  const wageDirect = input.wageGrowthPct * 0.25; // Wage to core services elasticity
  const outputGapDirect = input.outputGap * 0.18; // Phillips curve slope
  const expDirect = input.inflationExpectationsPct * 0.60; // Expectation weight
  const policyRateOffset = (input.policyRateBp / 100) * -0.20; // Policy tightening effect

  const totalHeadlineShock = energyDirect + foodDirect + fxDirect + wageDirect + outputGapDirect + expDirect + policyRateOffset;
  const totalCoreShock = fxDirect * 0.5 + wageDirect * 0.8 + outputGapDirect * 0.9 + expDirect * 0.7 + policyRateOffset * 0.8;

  const simHeadline = Math.max(0.2, Number((baseHeadline + totalHeadlineShock).toFixed(2)));
  const simCore = Math.max(0.1, Number((baseCore + totalCoreShock).toFixed(2)));
  const simServices = Number((baseCore + totalCoreShock + wageDirect * 0.5).toFixed(2));
  const simGoods = Number((baseCore + fxDirect * 0.8 + energyDirect * 0.3).toFixed(2));
  const simWage = Number((baseWage + input.wageGrowthPct + outputGapDirect * 0.5).toFixed(2));
  const simGdp = Number((2.0 + input.outputGap * 0.6 + input.globalDemandPct * 0.4 - (input.energyPricePct * 0.04)).toFixed(2));
  const simEmployment = Number((input.outputGap * 0.45 - input.unemploymentGap * 0.8).toFixed(2));

  // Generate 8 quarters dynamic path (T to T+8)
  const timePath = [
    { t: 0, periodStr: '基准期 T', headline: baseHeadline, core: baseCore, wage: baseWage, gdp: 2.0 },
    { t: 1, periodStr: '冲击发生 T+1', headline: Number((baseHeadline + totalHeadlineShock * 0.65).toFixed(2)), core: Number((baseCore + totalCoreShock * 0.40).toFixed(2)), wage: Number((baseWage + input.wageGrowthPct * 0.5).toFixed(2)), gdp: Number((simGdp * 0.8).toFixed(2)) },
    { t: 2, periodStr: '峰值影响 T+2', headline: simHeadline, core: simCore, wage: simWage, gdp: simGdp },
    { t: 3, periodStr: '次级传导 T+3', headline: Number((simHeadline * 0.92).toFixed(2)), core: Number((simCore * 0.96).toFixed(2)), wage: Number((simWage * 0.98).toFixed(2)), gdp: Number((simGdp * 1.05).toFixed(2)) },
    { t: 4, periodStr: '政策收紧效应 T+4', headline: Number((simHeadline * 0.80).toFixed(2)), core: Number((simCore * 0.88).toFixed(2)), wage: Number((simWage * 0.92).toFixed(2)), gdp: Number((simGdp * 0.95).toFixed(2)) },
    { t: 6, periodStr: '中期衰减 T+6', headline: Number((simHeadline * 0.55 + baseHeadline * 0.45).toFixed(2)), core: Number((simCore * 0.65 + baseCore * 0.35).toFixed(2)), wage: Number((simWage * 0.70 + baseWage * 0.30).toFixed(2)), gdp: 2.1 },
    { t: 8, periodStr: '长期收敛 T+8', headline: Number((baseHeadline + 0.1).toFixed(2)), core: Number((baseCore + 0.08).toFixed(2)), wage: Number((baseWage + 0.1).toFixed(2)), gdp: 2.2 },
  ];

  return {
    headlineCpi: simHeadline,
    coreCpi: simCore,
    servicesCpi: simServices,
    goodsCpi: simGoods,
    wageGrowth: simWage,
    gdpGrowth: simGdp,
    employmentChange: simEmployment,
    expectationImpact: Number((expDirect + totalHeadlineShock * 0.15).toFixed(2)),
    timePath,
  };
}
