/**
 * 华盛通胀实验室 - 菲利普斯曲线与宏观计量实验室 (Phillips Curve & Econometric Lab)
 */

export interface NKPCParams {
  alphaLag: number; // \alpha: \pi_{t-1} backward-looking persistence weight (e.g. 0.40)
  betaExp: number; // \beta: E_t[\pi_{t+1}] forward-looking expectation weight (e.g. 0.55)
  kappaSlope: number; // \kappa: output gap elasticity slope (e.g. 0.18)
  shockStd: number; // u_t: supply shock volatility
}

export interface NonLinearRegimeParams {
  lowThreshold: number; // e.g. output gap < -1.0% -> slope = 0.08
  highThreshold: number; // e.g. output gap > +1.0% -> slope = 0.32
  normalSlope: number; // e.g. 0.15
  lowSlope: number;
  highSlope: number;
}

// 1. Compute Hybrid New Keynesian Phillips Curve Inflation
// \pi_t = \alpha \pi_{t-1} + \beta E_t[\pi_{t+1}] + \kappa x_t + u_t
export function computeHybridNKPC(
  pastInflation: number,
  expectedInflation: number,
  outputGap: number,
  supplyShock: number,
  params: NKPCParams
): number {
  const pi =
    params.alphaLag * pastInflation +
    params.betaExp * expectedInflation +
    params.kappaSlope * outputGap +
    supplyShock;
  return Number(pi.toFixed(2));
}

// 2. Non-linear Phillips Curve slope evaluation
export function getNonLinearSlope(outputGap: number, regime: NonLinearRegimeParams): number {
  if (outputGap < regime.lowThreshold) {
    return regime.lowSlope;
  } else if (outputGap > regime.highThreshold) {
    return regime.highSlope;
  } else {
    return regime.normalSlope;
  }
}

// 3. Generate Phillips Curve Scatter & Fitted Curve Points
export function generatePhillipsCurvePoints(type: 'linear' | 'hybrid' | 'nonlinear' | 'threshold', params: NKPCParams, regime: NonLinearRegimeParams) {
  const dataPoints: { x: number; y: number; label: string }[] = [];
  const fittedCurve: { x: number; y: number }[] = [];

  // Generate historical scatter sample points around realistic output gaps (-3% to +3%)
  const historicalGaps = [-2.5, -2.0, -1.6, -1.2, -0.8, -0.4, 0.0, 0.3, 0.6, 1.0, 1.4, 1.8, 2.2, 2.6];
  const periods = ['2023Q1', '2023Q2', '2023Q3', '2023Q4', '2024Q1', '2024Q2', '2024Q3', '2024Q4', '2025Q1', '2025Q2', '2025Q3', '2025Q4', '2026Q1', '2026Q2'];

  historicalGaps.forEach((gap, idx) => {
    let baseInfl = 2.0;
    if (type === 'nonlinear') {
      const slope = getNonLinearSlope(gap, regime);
      baseInfl = 2.0 + slope * gap + (Math.sin(idx) * 0.2);
    } else {
      baseInfl = 2.0 + params.kappaSlope * gap + (Math.cos(idx) * 0.25);
    }

    dataPoints.push({
      x: Number(gap.toFixed(2)),
      y: Number(baseInfl.toFixed(2)),
      label: periods[idx],
    });
  });

  // Generate smooth fitted curve
  for (let x = -3.0; x <= 3.0; x += 0.2) {
    let y = 2.0;
    if (type === 'nonlinear') {
      if (x < regime.lowThreshold) {
        y = 2.0 + regime.lowSlope * x;
      } else if (x > regime.highThreshold) {
        y = 2.0 + regime.normalSlope * regime.highThreshold + regime.highSlope * (x - regime.highThreshold);
      } else {
        y = 2.0 + regime.normalSlope * x;
      }
    } else {
      y = 2.0 + params.kappaSlope * x;
    }
    fittedCurve.push({ x: Number(x.toFixed(1)), y: Number(y.toFixed(2)) });
  }

  return { dataPoints, fittedCurve };
}

// 4. Exchange Rate Pass-Through Model
export function computeExchangeRatePassThrough(fxChangePct: number, elasticityImport = 0.35, elasticityCpi = 0.08) {
  const importPriceEffect = fxChangePct * elasticityImport;
  const headlineCpiEffect = fxChangePct * elasticityCpi;
  const coreCpiEffect = fxChangePct * (elasticityCpi * 0.6);

  return {
    fxChangePct,
    importPriceEffect: Number(importPriceEffect.toFixed(2)),
    headlineCpiEffect: Number(headlineCpiEffect.toFixed(2)),
    coreCpiEffect: Number(coreCpiEffect.toFixed(2)),
  };
}
