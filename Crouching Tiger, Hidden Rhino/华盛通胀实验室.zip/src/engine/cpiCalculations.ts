import { CpiBasketNode, InflationContributionItem, TrimmedMeanResult, DiffusionIndexData } from '../types/inflation';

/**
 * 华盛通胀实验室 - CPI计算与分项贡献算术引擎
 */

// 1. Calculate YoY, MoM, and Annualized Rates
export function calculateInflationRates(
  indexCurrent: number,
  indexPrevMonth: number,
  indexPrevYear: number,
  index3mAgo: number,
  index6mAgo: number
) {
  const mom = ((indexCurrent - indexPrevMonth) / indexPrevMonth) * 100;
  const yoy = ((indexCurrent - indexPrevYear) / indexPrevYear) * 100;
  const ann3m = (Math.pow(indexCurrent / index3mAgo, 4) - 1) * 100;
  const ann6m = (Math.pow(indexCurrent / index6mAgo, 2) - 1) * 100;

  return {
    mom: Number(mom.toFixed(2)),
    yoy: Number(yoy.toFixed(2)),
    ann3m: Number(ann3m.toFixed(2)),
    ann6m: Number(ann6m.toFixed(2)),
  };
}

// 2. Flatten CpiBasketNode to list of item components with weights and price changes
export interface FlatCpiItem {
  id: string;
  name: string;
  weight: number; // percentage (e.g. 18.5)
  yoyChange: number; // percentage
  momChange: number;
}

export function flattenCpiBasket(node: CpiBasketNode): FlatCpiItem[] {
  const items: FlatCpiItem[] = [];

  function traverse(curr: CpiBasketNode) {
    if (!curr.children || curr.children.length === 0) {
      items.push({
        id: curr.id,
        name: curr.name,
        weight: curr.weight,
        yoyChange: curr.yoy,
        momChange: curr.mom,
      });
    } else {
      curr.children.forEach(traverse);
    }
  }

  traverse(node);
  return items;
}

// 3. Trimmed Mean Algorithm (Weighted Trim)
export function computeTrimmedMean(flatItems: FlatCpiItem[], trimPercent: number): number {
  if (!flatItems.length) return 0;

  // Sort items by YoY change ascending
  const sorted = [...flatItems].sort((a, b) => a.yoyChange - b.yoyChange);
  const totalWeight = sorted.reduce((sum, item) => sum + item.weight, 0);

  const trimWeightCut = (totalWeight * trimPercent) / 100;

  let accumWeightLower = 0;
  let accumWeightUpper = 0;
  let weightedSum = 0;
  let effectiveWeightSum = 0;

  for (const item of sorted) {
    const itemWeight = item.weight;
    const startWeight = accumWeightLower;
    const endWeight = accumWeightLower + itemWeight;
    accumWeightLower = endWeight;

    // Check overlap with kept range [trimWeightCut, totalWeight - trimWeightCut]
    const keptStart = Math.max(startWeight, trimWeightCut);
    const keptEnd = Math.min(endWeight, totalWeight - trimWeightCut);

    if (keptEnd > keptStart) {
      const keptWeight = keptEnd - keptStart;
      weightedSum += item.yoyChange * keptWeight;
      effectiveWeightSum += keptWeight;
    }
  }

  return effectiveWeightSum > 0 ? Number((weightedSum / effectiveWeightSum).toFixed(2)) : 0;
}

// 4. Weighted Median Algorithm
export function computeWeightedMedian(flatItems: FlatCpiItem[]): number {
  if (!flatItems.length) return 0;

  const sorted = [...flatItems].sort((a, b) => a.yoyChange - b.yoyChange);
  const totalWeight = sorted.reduce((sum, item) => sum + item.weight, 0);
  const halfWeight = totalWeight / 2;

  let accum = 0;
  for (const item of sorted) {
    accum += item.weight;
    if (accum >= halfWeight) {
      return item.yoyChange;
    }
  }

  return sorted[sorted.length - 1].yoyChange;
}

// 5. Price Change Quantiles (P25, P50, P75, P90)
export function computePriceQuantiles(flatItems: FlatCpiItem[]) {
  if (!flatItems.length) return { p25: 0, p50: 0, p75: 0, p90: 0 };

  const sorted = [...flatItems].sort((a, b) => a.yoyChange - b.yoyChange);
  const totalWeight = sorted.reduce((sum, item) => sum + item.weight, 0);

  const getQuantile = (q: number) => {
    const target = totalWeight * q;
    let accum = 0;
    for (const item of sorted) {
      accum += item.weight;
      if (accum >= target) {
        return item.yoyChange;
      }
    }
    return sorted[sorted.length - 1].yoyChange;
  };

  return {
    p25: Number(getQuantile(0.25).toFixed(2)),
    p50: Number(getQuantile(0.50).toFixed(2)),
    p75: Number(getQuantile(0.75).toFixed(2)),
    p90: Number(getQuantile(0.90).toFixed(2)),
  };
}

// 6. Inflation Contribution Calculation
export function computeContributions(node: CpiBasketNode): InflationContributionItem[] {
  if (!node.children) return [];

  const totalHeadlineYoY = node.yoy;
  const items: InflationContributionItem[] = [];

  const colors = ['#f59e0b', '#ef4444', '#3b82f6', '#10b981', '#8b5cf6', '#06b6d4', '#ec4899'];

  node.children.forEach((child, index) => {
    const contrib = Number(((child.weight / 100) * child.yoy).toFixed(2));
    items.push({
      category: child.name,
      weight: child.weight,
      yoyChange: child.yoy,
      contribution: contrib,
      color: colors[index % colors.length],
    });
  });

  return items;
}

// 7. Custom Core CPI Exclusion Builder
export function computeCustomCoreCpi(flatItems: FlatCpiItem[], excludedIds: string[]): { customCoreYoy: number; keptWeight: number } {
  const kept = flatItems.filter((i) => !excludedIds.includes(i.id));
  const totalKeptWeight = kept.reduce((s, i) => s + i.weight, 0);

  if (totalKeptWeight === 0) return { customCoreYoy: 0, keptWeight: 0 };

  const weightedSum = kept.reduce((s, i) => s + i.yoyChange * i.weight, 0);
  return {
    customCoreYoy: Number((weightedSum / totalKeptWeight).toFixed(2)),
    keptWeight: Number(totalKeptWeight.toFixed(1)),
  };
}
