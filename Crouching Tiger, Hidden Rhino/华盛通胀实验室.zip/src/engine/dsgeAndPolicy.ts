/**
 * 华盛通胀实验室 - DSGE 宏观模型与货币政策传导实验室
 */

export interface TaylorRuleParams {
  neutralRate: number; // r^*: neutral real interest rate (e.g. 1.5%)
  targetInflation: number; // \pi^*: inflation target (e.g. 2.0%)
  phiPi: number; // \phi_\pi: inflation gap sensitivity (e.g. 1.5)
  phiY: number; // \phi_y: output gap sensitivity (e.g. 0.5)
  smoothing: number; // \rho: interest rate smoothing coefficient (e.g. 0.8)
  currentRate: number; // e.g. 2.5%
}

// 1. Taylor Rule Policy Rate Calculator
export function computeTaylorRuleRate(
  currentInflation: number,
  outputGap: number,
  params: TaylorRuleParams
): { targetRate: number; recommendedRate: number; gap: number } {
  const inflGap = currentInflation - params.targetInflation;
  const targetRate =
    params.neutralRate +
    currentInflation +
    params.phiPi * inflGap +
    params.phiY * outputGap;

  const recommendedRate =
    params.smoothing * params.currentRate + (1 - params.smoothing) * targetRate;
  const gap = recommendedRate - params.currentRate;

  return {
    targetRate: Number(targetRate.toFixed(2)),
    recommendedRate: Number(recommendedRate.toFixed(2)),
    gap: Number(gap.toFixed(2)),
  };
}

// 2. Monetary Policy Transmission Impulse Responses
export function simulatePolicyRateShock(rateShockBp: number) {
  // rateShockBp e.g. +25, +50, -25
  const shockPct = rateShockBp / 100; // e.g. +0.25%

  const quarters = ['T+0', 'T+1', 'T+2', 'T+3', 'T+4', 'T+6', 'T+8'];

  return quarters.map((q, idx) => {
    // Dynamic lag transmission
    const lagFactor = Math.sin((idx / 6) * Math.PI); // peak around T+3
    const gdpImpact = - shockPct * 0.40 * lagFactor;
    const wageImpact = - shockPct * 0.25 * lagFactor;
    const cpiImpact = - shockPct * 0.35 * Math.sin(((idx + 1) / 7) * Math.PI); // peak around T+4
    const fxImpact = shockPct * 0.60 * Math.exp(-idx * 0.3); // immediate FX appreciation

    return {
      quarter: q,
      policyRateDelta: Number((shockPct * Math.exp(-idx * 0.2)).toFixed(2)),
      gdpGrowthDelta: Number(gdpImpact.toFixed(2)),
      wageGrowthDelta: Number(wageImpact.toFixed(2)),
      headlineCpiDelta: Number(cpiImpact.toFixed(2)),
      fxRateDelta: Number(fxImpact.toFixed(2)),
    };
  });
}
