/**
 * 华盛通胀实验室 - 机器学习通胀实验室 (Machine Learning Inflation Engine)
 */

export interface MLFeatureImportance {
  feature: string;
  category: string;
  importance: number; // percentage e.g. 24.5%
  shapValue: number; // e.g. +0.12%
}

export interface MLModelPerformance {
  modelName: string;
  algorithm: 'LightGBM' | 'XGBoost' | 'Random Forest' | 'Elastic Net' | 'Neural Network';
  mae: number;
  rmse: number;
  bias: number;
  r2Score: number;
  outOfSampleError: number;
}

export const mockMLFeatures: MLFeatureImportance[] = [
  { feature: '国际原油现货价 (Brent Spot)', category: '能源', importance: 24.5, shapValue: 0.14 },
  { feature: '名义工资与ULC增速', category: '工资', importance: 20.2, shapValue: 0.11 },
  { feature: '农产品批发价格200指数', category: '食品', importance: 18.0, shapValue: 0.08 },
  { feature: '通胀预期Swaps (1Y Breakeven)', category: '预期', importance: 12.8, shapValue: 0.05 },
  { feature: '产出缺口 (HP Filter Output Gap)', category: '需求', importance: 10.5, shapValue: 0.04 },
  { feature: '人民币兑美元即期汇率 (CNY/USD)', category: '汇率', importance: 8.0, shapValue: 0.02 },
  { feature: '全球公路与海运货运运价', category: '供给', importance: 6.0, shapValue: 0.01 }
];

export const mockMLPerformances: MLModelPerformance[] = [
  { modelName: 'LightGBM-SHAP 梯度提升模型', algorithm: 'LightGBM', mae: 0.16, rmse: 0.19, bias: 0.02, r2Score: 0.91, outOfSampleError: 0.18 },
  { modelName: 'XGBoost 极端梯度提升模型', algorithm: 'XGBoost', mae: 0.17, rmse: 0.20, bias: 0.03, r2Score: 0.89, outOfSampleError: 0.19 },
  { modelName: '随机森林 (Random Forest Regressor)', algorithm: 'Random Forest', mae: 0.21, rmse: 0.25, bias: -0.01, r2Score: 0.84, outOfSampleError: 0.24 },
  { modelName: '弹性网络 (Elastic Net Shrinkage)', algorithm: 'Elastic Net', mae: 0.24, rmse: 0.29, bias: -0.04, r2Score: 0.79, outOfSampleError: 0.27 },
  { modelName: '深度LSTM时序神经网络', algorithm: 'Neural Network', mae: 0.18, rmse: 0.22, bias: 0.01, r2Score: 0.88, outOfSampleError: 0.21 }
];
