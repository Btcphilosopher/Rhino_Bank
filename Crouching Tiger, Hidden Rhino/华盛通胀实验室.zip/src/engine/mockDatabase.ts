import {
  CpiMetric,
  CpiBasketNode,
  InflationContributionItem,
  TrimmedMeanResult,
  DiffusionIndexData,
  WageUlcData,
  ExpectationPoint,
  NowcastIndicator,
  NowcastVintage,
  ModelForecast,
  ShockDecomposition,
  HistoricalEpisode,
  ResearchNote
} from '../types/inflation';

// 1. Core Summary Metrics
export const mockCpiMetrics: CpiMetric[] = [
  {
    id: 'headline_cpi',
    name: '总体CPI同比',
    category: 'headline',
    currentVal: 2.15,
    prevVal: 2.05,
    change3m: 2.30,
    change6m: 2.10,
    change12m: 2.15,
    mom: 0.22,
    momSa: 0.18,
    histMean: 2.02,
    histPercentile: 58,
    unit: '%'
  },
  {
    id: 'core_cpi',
    name: '核心CPI同比',
    category: 'core',
    currentVal: 1.85,
    prevVal: 1.80,
    change3m: 1.90,
    change6m: 1.82,
    change12m: 1.85,
    mom: 0.15,
    momSa: 0.14,
    histMean: 1.75,
    histPercentile: 52,
    unit: '%'
  },
  {
    id: 'services_cpi',
    name: '服务通胀同比',
    category: 'services',
    currentVal: 2.45,
    prevVal: 2.40,
    change3m: 2.52,
    change6m: 2.38,
    change12m: 2.45,
    mom: 0.25,
    momSa: 0.22,
    histMean: 2.10,
    histPercentile: 66,
    unit: '%'
  },
  {
    id: 'goods_cpi',
    name: '商品通胀同比',
    category: 'goods',
    currentVal: 1.42,
    prevVal: 1.35,
    change3m: 1.55,
    change6m: 1.30,
    change12m: 1.42,
    mom: 0.12,
    momSa: 0.10,
    histMean: 1.60,
    histPercentile: 42,
    unit: '%'
  },
  {
    id: 'food_cpi',
    name: '食品通胀同比',
    category: 'food',
    currentVal: 2.80,
    prevVal: 2.60,
    change3m: 3.10,
    change6m: 2.50,
    change12m: 2.80,
    mom: 0.38,
    momSa: 0.30,
    histMean: 2.40,
    histPercentile: 62,
    unit: '%'
  },
  {
    id: 'energy_cpi',
    name: '能源通胀同比',
    category: 'energy',
    currentVal: 3.50,
    prevVal: 3.10,
    change3m: 4.20,
    change6m: 2.90,
    change12m: 3.50,
    mom: 0.65,
    momSa: 0.50,
    histMean: 3.20,
    histPercentile: 55,
    unit: '%'
  },
  {
    id: 'wage_growth',
    name: '名义工资增速',
    category: 'wage',
    currentVal: 4.20,
    prevVal: 4.10,
    change3m: 4.35,
    change6m: 4.05,
    change12m: 4.20,
    mom: 0.35,
    momSa: 0.32,
    histMean: 3.80,
    histPercentile: 71,
    unit: '%'
  },
  {
    id: 'ulc_growth',
    name: '单位劳动成本(ULC)',
    category: 'wage',
    currentVal: 2.60,
    prevVal: 2.50,
    change3m: 2.75,
    change6m: 2.45,
    change12m: 2.60,
    mom: 0.22,
    momSa: 0.20,
    histMean: 2.10,
    histPercentile: 68,
    unit: '%'
  },
  {
    id: 'inflation_exp_1y',
    name: '1年期通胀预期',
    category: 'expectations',
    currentVal: 2.25,
    prevVal: 2.20,
    change3m: 2.30,
    change6m: 2.22,
    change12m: 2.25,
    mom: 0.05,
    momSa: 0.05,
    histMean: 2.15,
    histPercentile: 59,
    unit: '%'
  },
  {
    id: 'output_gap',
    name: '产出缺口',
    category: 'headline',
    currentVal: 0.45,
    prevVal: 0.38,
    change3m: 0.52,
    change6m: 0.30,
    change12m: 0.45,
    mom: 0.07,
    momSa: 0.07,
    histMean: 0.10,
    histPercentile: 64,
    unit: '%'
  }
];

// 2. Hierarchical CPI Basket taxonomy
export const mockCpiBasketTree: CpiBasketNode = {
  id: 'cpi_all',
  name: '总体CPI (Headline CPI)',
  code: 'CPI.ALL',
  weight: 100.0,
  cpiIndex: 105.8,
  yoy: 2.15,
  mom: 0.22,
  contribution: 2.15,
  children: [
    {
      id: 'food',
      name: '食品与非酒精饮料',
      code: 'CPI.FOOD',
      weight: 18.5,
      cpiIndex: 107.2,
      yoy: 2.80,
      mom: 0.38,
      contribution: 0.52,
      children: [
        { id: 'grain', name: '谷物与粮食', code: 'CPI.FOOD.GRAIN', weight: 4.2, cpiIndex: 104.1, yoy: 1.2, mom: 0.1, contribution: 0.05 },
        { id: 'meat', name: '肉类与禽蛋', code: 'CPI.FOOD.MEAT', weight: 5.8, cpiIndex: 108.9, yoy: 3.6, mom: 0.5, contribution: 0.21 },
        { id: 'veg', name: '蔬菜与鲜果', code: 'CPI.FOOD.VEG', weight: 4.5, cpiIndex: 110.3, yoy: 4.2, mom: 0.8, contribution: 0.19 },
        { id: 'processed_food', name: '加工食品', code: 'CPI.FOOD.PROC', weight: 4.0, cpiIndex: 105.0, yoy: 1.8, mom: 0.2, contribution: 0.07 }
      ]
    },
    {
      id: 'energy',
      name: '能源',
      code: 'CPI.ENERGY',
      weight: 8.5,
      cpiIndex: 109.5,
      yoy: 3.50,
      mom: 0.65,
      contribution: 0.30,
      children: [
        { id: 'gasoline', name: '车用汽油与柴油', code: 'CPI.NRG.GAS', weight: 4.0, cpiIndex: 112.0, yoy: 4.8, mom: 0.9, contribution: 0.19 },
        { id: 'natgas', name: '家用天然气', code: 'CPI.NRG.NATGAS', weight: 2.2, cpiIndex: 107.5, yoy: 2.5, mom: 0.4, contribution: 0.05 },
        { id: 'electricity', name: '电力', code: 'CPI.NRG.ELEC', weight: 2.3, cpiIndex: 106.8, yoy: 2.1, mom: 0.3, contribution: 0.05 }
      ]
    },
    {
      id: 'goods',
      name: '核心商品 (Ex-Food/Energy Goods)',
      code: 'CPI.GOODS',
      weight: 35.0,
      cpiIndex: 103.5,
      yoy: 1.42,
      mom: 0.12,
      contribution: 0.50,
      children: [
        { id: 'durable', name: '耐用品 (汽车、家电、家具)', code: 'CPI.GOODS.DUR', weight: 15.0, cpiIndex: 101.8, yoy: 0.6, mom: 0.05, contribution: 0.09 },
        { id: 'nondurable', name: '非耐用品 (服装、药品、日用品)', code: 'CPI.GOODS.NONDUR', weight: 12.0, cpiIndex: 104.6, yoy: 1.9, mom: 0.15, contribution: 0.23 },
        { id: 'imported_goods', name: '进口消费品', code: 'CPI.GOODS.IMP', weight: 8.0, cpiIndex: 105.2, yoy: 2.2, mom: 0.20, contribution: 0.18 }
      ]
    },
    {
      id: 'services',
      name: '核心服务 (Ex-Energy Services)',
      code: 'CPI.SERVICES',
      weight: 38.0,
      cpiIndex: 106.8,
      yoy: 2.45,
      mom: 0.25,
      contribution: 0.93,
      children: [
        { id: 'housing_rent', name: '住房与主要租金', code: 'CPI.SERV.RENT', weight: 16.0, cpiIndex: 107.5, yoy: 2.6, mom: 0.22, contribution: 0.42 },
        { id: 'dining_out', name: '餐饮与住宿服务', code: 'CPI.SERV.DINING', weight: 7.5, cpiIndex: 108.2, yoy: 3.1, mom: 0.30, contribution: 0.23 },
        { id: 'medical_serv', name: '医疗服务', code: 'CPI.SERV.MED', weight: 5.0, cpiIndex: 105.1, yoy: 1.8, mom: 0.15, contribution: 0.09 },
        { id: 'edu_serv', name: '教育与文娱服务', code: 'CPI.SERV.EDU', weight: 5.5, cpiIndex: 105.8, yoy: 2.0, mom: 0.18, contribution: 0.11 },
        { id: 'trans_serv', name: '交通与通信服务', code: 'CPI.SERV.TRANS', weight: 4.0, cpiIndex: 104.9, yoy: 1.7, mom: 0.12, contribution: 0.07 }
      ]
    }
  ]
};

export const mockCpiTree = mockCpiBasketTree;

export const mockMlFeatureImportances = [
  { featureName: '核心服务通胀 (Services CPI)', importanceScore: 28.5 },
  { featureName: '布伦特原油现货价 (Brent Crude)', importanceScore: 21.0 },
  { featureName: '单位劳动成本 (ULC Growth)', importanceScore: 16.4 },
  { featureName: '1年期通胀Swaps预期', importanceScore: 12.8 },
  { featureName: '公路货运周频指数', importanceScore: 11.2 },
  { featureName: 'CNY/USD 汇率变动', importanceScore: 10.1 }
];

export const mockScenarioPresets = [
  { id: 'energy_shock', name: '中东地缘冲击：原油价格暴涨25%', parameters: { energyPricePct: 25, foodPricePct: 5, fxDepreciationPct: 2, wageGrowthPct: 0.8 } },
  { id: 'wage_spiral', name: '劳动力市场过热：工资-物价螺旋 (+3% 工资)', parameters: { energyPricePct: 0, foodPricePct: 1, fxDepreciationPct: 0, wageGrowthPct: 3 } },
  { id: 'fx_depreciation', name: '汇率贬值冲击：人民币汇率贬值 8%', parameters: { energyPricePct: 6, foodPricePct: 4, fxDepreciationPct: 8, wageGrowthPct: 0.5 } },
  { id: 'demand_boom', name: '总需求扩张：财政与信贷宽松 (+2.0% 产出缺口)', parameters: { energyPricePct: 8, foodPricePct: 3, fxDepreciationPct: -1, wageGrowthPct: 1.8 } },
  { id: 'food_supply_shock', name: '极端天气：农产品与食品价格冲击 (+15%)', parameters: { energyPricePct: 2, foodPricePct: 15, fxDepreciationPct: 1, wageGrowthPct: 0.2 } },
];

// 3. Waterfall Contribution Breakdown
export const mockContributionWaterfall: InflationContributionItem[] = [
  { category: '食品', weight: 18.5, yoyChange: 2.80, contribution: 0.52, color: '#f59e0b' },
  { category: '能源', weight: 8.5, yoyChange: 3.50, contribution: 0.30, color: '#ef4444' },
  { category: '住房租金', weight: 16.0, yoyChange: 2.60, contribution: 0.42, color: '#3b82f6' },
  { category: '核心商品', weight: 35.0, yoyChange: 1.42, contribution: 0.50, color: '#10b981' },
  { category: '核心服务(不含住房)', weight: 22.0, yoyChange: 2.32, contribution: 0.51, color: '#8b5cf6' },
  { category: '总体CPI', weight: 100.0, yoyChange: 2.15, contribution: 2.25, color: '#f43f5e' }
];

// 4. Trimmed Mean Comparisons
export const mockTrimmedMeans: TrimmedMeanResult[] = [
  { trimPct: 5, value: 2.02, headlineDiff: -0.13, coreDiff: 0.17 },
  { trimPct: 10, value: 1.94, headlineDiff: -0.21, coreDiff: 0.09 },
  { trimPct: 15, value: 1.88, headlineDiff: -0.27, coreDiff: 0.03 },
  { trimPct: 20, value: 1.82, headlineDiff: -0.33, coreDiff: -0.03 }
];

// 5. Diffusion Index Time Series
export const mockDiffusionSeries: DiffusionIndexData[] = [
  { period: '2025M09', diffusion3m: 54.2, diffusion6m: 52.1, diffusion12m: 55.0, pctIncreasing: 58.0, pctDecreasing: 32.0, pctHighInflation: 18.5, pctLowInflation: 28.0 },
  { period: '2025M10', diffusion3m: 56.1, diffusion6m: 53.4, diffusion12m: 56.2, pctIncreasing: 60.5, pctDecreasing: 30.1, pctHighInflation: 19.2, pctLowInflation: 26.5 },
  { period: '2025M11', diffusion3m: 57.5, diffusion6m: 55.0, diffusion12m: 57.1, pctIncreasing: 62.0, pctDecreasing: 28.5, pctHighInflation: 21.0, pctLowInflation: 25.0 },
  { period: '2025M12', diffusion3m: 58.8, diffusion6m: 56.8, diffusion12m: 58.0, pctIncreasing: 63.8, pctDecreasing: 26.9, pctHighInflation: 22.4, pctLowInflation: 23.8 },
  { period: '2026M01', diffusion3m: 60.2, diffusion6m: 58.1, diffusion12m: 59.2, pctIncreasing: 65.1, pctDecreasing: 25.0, pctHighInflation: 23.8, pctLowInflation: 22.1 },
  { period: '2026M02', diffusion3m: 61.5, diffusion6m: 59.5, diffusion12m: 60.8, pctIncreasing: 66.8, pctDecreasing: 23.8, pctHighInflation: 25.0, pctLowInflation: 20.8 },
  { period: '2026M03', diffusion3m: 62.1, diffusion6m: 60.4, diffusion12m: 61.5, pctIncreasing: 67.5, pctDecreasing: 23.0, pctHighInflation: 26.2, pctLowInflation: 19.5 },
  { period: '2026M04', diffusion3m: 61.8, diffusion6m: 61.0, diffusion12m: 61.8, pctIncreasing: 67.0, pctDecreasing: 23.5, pctHighInflation: 25.8, pctLowInflation: 20.0 },
  { period: '2026M05', diffusion3m: 60.9, diffusion6m: 61.2, diffusion12m: 61.2, pctIncreasing: 66.2, pctDecreasing: 24.1, pctHighInflation: 24.9, pctLowInflation: 21.0 },
  { period: '2026M06', diffusion3m: 59.8, diffusion6m: 60.5, diffusion12m: 60.5, pctIncreasing: 65.0, pctDecreasing: 25.2, pctHighInflation: 23.5, pctLowInflation: 22.5 },
  { period: '2026M07', diffusion3m: 58.9, diffusion6m: 59.8, diffusion12m: 59.8, pctIncreasing: 63.8, pctDecreasing: 26.5, pctHighInflation: 22.1, pctLowInflation: 24.0 },
  { period: '2026M08', diffusion3m: 58.2, diffusion6m: 59.0, diffusion12m: 59.1, pctIncreasing: 63.0, pctDecreasing: 27.2, pctHighInflation: 21.5, pctLowInflation: 25.2 }
];

// 6. Wage and ULC Data
export const mockWageUlcSeries: WageUlcData[] = [
  { period: '2025Q1', nominalWageGrowth: 3.8, realWageGrowth: 1.9, productivityGrowth: 1.5, unitLaborCostGrowth: 2.3, servicesInflation: 2.2, profitMarginGrowth: 1.1 },
  { period: '2025Q2', nominalWageGrowth: 3.9, realWageGrowth: 2.0, productivityGrowth: 1.6, unitLaborCostGrowth: 2.3, servicesInflation: 2.3, profitMarginGrowth: 1.2 },
  { period: '2025Q3', nominalWageGrowth: 4.0, realWageGrowth: 2.1, productivityGrowth: 1.5, unitLaborCostGrowth: 2.5, servicesInflation: 2.35, profitMarginGrowth: 1.0 },
  { period: '2025Q4', nominalWageGrowth: 4.1, realWageGrowth: 2.1, productivityGrowth: 1.6, unitLaborCostGrowth: 2.5, servicesInflation: 2.4, profitMarginGrowth: 0.9 },
  { period: '2026Q1', nominalWageGrowth: 4.2, realWageGrowth: 2.15, productivityGrowth: 1.6, unitLaborCostGrowth: 2.6, servicesInflation: 2.42, profitMarginGrowth: 0.85 },
  { period: '2026Q2', nominalWageGrowth: 4.2, realWageGrowth: 2.05, productivityGrowth: 1.6, unitLaborCostGrowth: 2.6, servicesInflation: 2.45, profitMarginGrowth: 0.8 }
];

// 7. Expectations
export const mockExpectations: ExpectationPoint[] = [
  { period: '2026M08', horizon: '1Y', householdSurvey: 2.65, corporateSurvey: 2.35, professionalForecasters: 2.15, inflationSwaps: 2.10, breakevenInflation: 2.08, mean: 2.26, median: 2.20, p25: 1.95, p75: 2.55, disagreementIndex: 0.42 },
  { period: '2026M08', horizon: '2Y', householdSurvey: 2.50, corporateSurvey: 2.25, professionalForecasters: 2.08, inflationSwaps: 2.05, breakevenInflation: 2.04, mean: 2.18, median: 2.12, p25: 1.90, p75: 2.42, disagreementIndex: 0.38 },
  { period: '2026M08', horizon: '5Y', householdSurvey: 2.40, corporateSurvey: 2.15, professionalForecasters: 2.02, inflationSwaps: 2.02, breakevenInflation: 2.01, mean: 2.12, median: 2.05, p25: 1.88, p75: 2.30, disagreementIndex: 0.31 },
  { period: '2026M08', horizon: '10Y', householdSurvey: 2.35, corporateSurvey: 2.10, professionalForecasters: 2.00, inflationSwaps: 2.00, breakevenInflation: 1.99, mean: 2.09, median: 2.02, p25: 1.85, p75: 2.25, disagreementIndex: 0.28 }
];

// 8. Nowcasting Indicators
export const mockNowcastIndicators: NowcastIndicator[] = [
  { id: 'ind_1', name: '国际布伦特原油现货价', frequency: '日频', category: '能源', latestValue: 78.4, releaseDate: '2026-09-16', referencePeriod: '2026M09', firstReleaseVal: 76.5, revisedVal: 78.4, marketConsensus: 77.0, modelExpectation: 76.8, surpriseVal: 1.6, impactOnNowcast: 0.05 },
  { id: 'ind_2', name: '全国公路货物运输指数', frequency: '周频', category: '运费', latestValue: 104.8, releaseDate: '2026-09-15', referencePeriod: '2026M09W2', firstReleaseVal: 103.5, revisedVal: 104.8, marketConsensus: 104.0, modelExpectation: 103.8, surpriseVal: 0.8, impactOnNowcast: 0.02 },
  { id: 'ind_3', name: '人民币兑美元即期汇率', frequency: '日频', category: '汇率', latestValue: 7.18, releaseDate: '2026-09-16', referencePeriod: '2026M09', firstReleaseVal: 7.20, revisedVal: 7.18, marketConsensus: 7.21, modelExpectation: 7.20, surpriseVal: -0.02, impactOnNowcast: -0.01 },
  { id: 'ind_4', name: '农产品批发价格200指数', frequency: '日频', category: '食品', latestValue: 124.5, releaseDate: '2026-09-16', referencePeriod: '2026M09', firstReleaseVal: 122.1, revisedVal: 124.5, marketConsensus: 123.0, modelExpectation: 122.8, surpriseVal: 1.5, impactOnNowcast: 0.06 },
  { id: 'ind_5', name: '企业招聘名义薪资指数', frequency: '周频', category: '工资', latestValue: 108.2, releaseDate: '2026-09-12', referencePeriod: '2026M09W1', firstReleaseVal: 107.8, revisedVal: 108.2, marketConsensus: 107.9, modelExpectation: 107.8, surpriseVal: 0.3, impactOnNowcast: 0.02 },
  { id: 'ind_6', name: '央行金融条件指数 (FCI)', frequency: '月频', category: '信用', latestValue: -0.35, releaseDate: '2026-09-10', referencePeriod: '2026M08', firstReleaseVal: -0.40, revisedVal: -0.35, marketConsensus: -0.38, modelExpectation: -0.38, surpriseVal: 0.03, impactOnNowcast: 0.01 }
];

export const mockNowcastVintages: NowcastVintage[] = [
  { vintageDate: '2026-08-01', nowcastValue: 2.05, headlineObserved: null, bridgeModel: 2.02, midasModel: 2.08, dynamicFactorModel: 2.05, bayesianVar: 2.04 },
  { vintageDate: '2026-08-15', nowcastValue: 2.10, headlineObserved: null, bridgeModel: 2.07, midasModel: 2.12, dynamicFactorModel: 2.11, bayesianVar: 2.09 },
  { vintageDate: '2026-09-01', nowcastValue: 2.14, headlineObserved: null, bridgeModel: 2.11, midasModel: 2.16, dynamicFactorModel: 2.15, bayesianVar: 2.13 },
  { vintageDate: '2026-09-15', nowcastValue: 2.15, headlineObserved: 2.15, bridgeModel: 2.12, midasModel: 2.18, dynamicFactorModel: 2.15, bayesianVar: 2.14 }
];

// 9. Model Forecasting Suite
export const mockModelForecasts: ModelForecast[] = [
  { modelId: 'm_dfm', modelName: '动态因子模型 (Dynamic Factor Model)', modelType: 'Dynamic Factor', forecastHorizon: '2026Q4', pointForecast: 2.12, ci50Lower: 1.95, ci50Upper: 2.29, ci70Lower: 1.82, ci70Upper: 2.42, ci90Lower: 1.62, ci90Upper: 2.62, mae12m: 0.18, rmse12m: 0.22, bias: -0.02 },
  { modelId: 'm_bvar', modelName: '贝叶斯向量自回归 (BVAR v2.0)', modelType: 'BVAR', forecastHorizon: '2026Q4', pointForecast: 2.18, ci50Lower: 1.98, ci50Upper: 2.38, ci70Lower: 1.85, ci70Upper: 2.51, ci90Lower: 1.60, ci90Upper: 2.76, mae12m: 0.20, rmse12m: 0.25, bias: 0.04 },
  { modelId: 'm_nkp', modelName: '混合新凯恩斯菲利普斯曲线 (Hybrid NKPC)', modelType: 'Hybrid NK', forecastHorizon: '2026Q4', pointForecast: 2.08, ci50Lower: 1.90, ci50Upper: 2.26, ci70Lower: 1.78, ci70Upper: 2.38, ci90Lower: 1.55, ci90Upper: 2.61, mae12m: 0.22, rmse12m: 0.28, bias: -0.05 },
  { modelId: 'm_dsge', modelName: '中度规模DSGE宏观模型 (DSGE v1.4)', modelType: 'DSGE', forecastHorizon: '2026Q4', pointForecast: 2.05, ci50Lower: 1.88, ci50Upper: 2.22, ci70Lower: 1.75, ci70Upper: 2.35, ci90Lower: 1.50, ci90Upper: 2.60, mae12m: 0.25, rmse12m: 0.31, bias: -0.08 },
  { modelId: 'm_ml', modelName: 'LightGBM-SHAP 机器学习通胀模型', modelType: 'ML XGBoost', forecastHorizon: '2026Q4', pointForecast: 2.22, ci50Lower: 2.05, ci50Upper: 2.39, ci70Lower: 1.92, ci70Upper: 2.52, ci90Lower: 1.70, ci90Upper: 2.74, mae12m: 0.16, rmse12m: 0.19, bias: 0.03 }
];

// 10. Shock Decomposition
export const mockShockDecompositions: ShockDecomposition[] = [
  { period: '2025M09', headlineDeviation: 0.10, demandShock: 0.08, energyShock: -0.12, foodShock: 0.05, importShock: 0.02, wageShock: 0.04, expectationShock: 0.02, policyShock: -0.01, otherShock: 0.02 },
  { period: '2025M12', headlineDeviation: 0.12, demandShock: 0.10, energyShock: -0.08, foodShock: 0.04, importShock: 0.01, wageShock: 0.05, expectationShock: 0.01, policyShock: -0.02, otherShock: 0.01 },
  { period: '2026M03', headlineDeviation: 0.18, demandShock: 0.12, energyShock: 0.02, foodShock: 0.03, importShock: 0.02, wageShock: 0.06, expectationShock: 0.02, policyShock: -0.02, otherShock: 0.03 },
  { period: '2026M06', headlineDeviation: 0.16, demandShock: 0.11, energyShock: 0.05, foodShock: 0.02, importShock: 0.03, wageShock: 0.05, expectationShock: 0.01, policyShock: -0.03, otherShock: 0.02 },
  { period: '2026M08', headlineDeviation: 0.15, demandShock: 0.09, energyShock: 0.06, foodShock: 0.04, importShock: 0.02, wageShock: 0.05, expectationShock: 0.01, policyShock: -0.03, otherShock: 0.01 }
];

// 11. Historical Episodes
export const mockHistoricalEpisodes: HistoricalEpisode[] = [
  {
    id: 'ep_2008',
    name: '2008年全球大宗商品与输入性通胀',
    periodRange: '2007Q3 - 2008Q4',
    period: '2007Q3 - 2008Q4',
    primaryDriver: '油价破140美元 + 农产品暴涨 + 全球需求过热',
    peakCpi: 8.7,
    description: '2008年国际原油现货突破 $140/桶，全球农产品暴涨，经由进口大宗价格引发大幅输入性通胀。',
    keyDrivers: '油价破140美元 + 农产品暴涨 + 全球需求过热',
    headlinePeak: 8.7,
    corePeak: 4.2,
    trajectory: [
      { month: 'T-12', actual: 2.7, forecast: 2.5 },
      { month: 'T-6', actual: 4.1, forecast: 3.8 },
      { month: 'T-3', actual: 6.5, forecast: 6.0 },
      { month: 'T (峰值)', actual: 8.7, forecast: 8.2 },
      { month: 'T+3', actual: 7.1, forecast: 7.0 },
      { month: 'T+6', actual: 4.6, forecast: 4.8 },
      { month: 'T+12', actual: -1.2, forecast: -0.8 },
    ],
    timeline: [
      { tOffset: 'T-12', date: '2007Q1', headline: 2.7, core: 1.8, energy: 3.5, wage: 4.5, outputGap: 0.8 },
      { tOffset: 'T-6', date: '2007Q3', headline: 4.1, core: 2.2, energy: 8.2, wage: 5.2, outputGap: 1.4 },
      { tOffset: 'T-3', date: '2007Q4', headline: 6.5, core: 2.8, energy: 14.5, wage: 5.8, outputGap: 1.9 },
      { tOffset: 'T', date: '2008Q1', headline: 8.7, core: 4.2, energy: 24.8, wage: 6.8, outputGap: 2.4 },
      { tOffset: 'T+3', date: '2008Q2', headline: 7.1, core: 3.8, energy: 18.2, wage: 6.2, outputGap: 1.2 },
      { tOffset: 'T+6', date: '2008Q3', headline: 4.6, core: 2.9, energy: 5.1, wage: 5.0, outputGap: -0.5 },
      { tOffset: 'T+12', date: '2009Q1', headline: -1.2, core: 0.8, energy: -18.5, wage: 3.1, outputGap: -3.2 }
    ]
  },
  {
    id: 'ep_2022',
    name: '2022年地缘冲突与后疫情供应链通胀',
    periodRange: '2021Q3 - 2022Q4',
    period: '2021Q3 - 2022Q4',
    primaryDriver: '欧洲天然气危机 + 供应链瓶颈 + 劳动参与率下降',
    peakCpi: 9.1,
    description: '地缘政治危机推高天然气与粮价，海运港口拥堵与劳动力缺口引发供给侧高度挤压。',
    keyDrivers: '欧洲天然气危机 + 供应链瓶颈 + 劳动参与率下降引起的工资-物价螺旋',
    headlinePeak: 9.1,
    corePeak: 6.6,
    trajectory: [
      { month: 'T-12', actual: 2.5, forecast: 2.3 },
      { month: 'T-6', actual: 5.4, forecast: 5.0 },
      { month: 'T-3', actual: 7.9, forecast: 7.5 },
      { month: 'T (峰值)', actual: 9.1, forecast: 8.8 },
      { month: 'T+3', actual: 8.2, forecast: 8.0 },
      { month: 'T+6', actual: 7.1, forecast: 6.9 },
      { month: 'T+12', actual: 3.2, forecast: 3.5 },
    ],
    timeline: [
      { tOffset: 'T-12', date: '2021Q2', headline: 2.5, core: 1.9, energy: 6.2, wage: 3.8, outputGap: -0.5 },
      { tOffset: 'T-6', date: '2021Q4', headline: 5.4, core: 3.8, energy: 18.5, wage: 4.8, outputGap: 0.5 },
      { tOffset: 'T-3', date: '2022Q1', headline: 7.9, core: 5.2, energy: 32.1, wage: 5.6, outputGap: 1.2 },
      { tOffset: 'T', date: '2022Q2', headline: 9.1, core: 6.6, energy: 41.5, wage: 6.2, outputGap: 1.8 },
      { tOffset: 'T+3', date: '2022Q3', headline: 8.2, core: 6.3, energy: 31.2, wage: 6.0, outputGap: 1.4 },
      { tOffset: 'T+6', date: '2022Q4', headline: 7.1, core: 5.7, energy: 19.8, wage: 5.5, outputGap: 0.8 },
      { tOffset: 'T+12', date: '2023Q2', headline: 3.2, core: 4.1, energy: -4.5, wage: 4.5, outputGap: 0.1 }
    ]
  }
];

// 12. Research Notes
export const mockResearchNotes: ResearchNote[] = [
  {
    id: 'rn_1',
    title: '2026年三季度服务通胀持久性与单位劳动成本(ULC)传导评估',
    author: '华盛高级宏观研究员 李华博士',
    date: '2026-09-15',
    summary: '利用 Hybrid NKPC 与 向量自回归模型 (VAR) 评估服务通胀对工资增速的滞后响应（1-2个季度），指出ULC保持在2.6%是当前服务通胀粘性的主要来源。',
    tags: ['服务通胀', '工资ULC', 'Hybrid NKPC', '持久性'],
    content: `一、核心发现：
1. 2026M08 服务通胀同比保持在 2.45%，贡献了总体CPI涨幅的 43.2%。
2. 计量回归显示，名义工资对服务通胀的传导弹性为 0.42，滞后期为 2 个季度。当前单位劳动成本(ULC)增长2.6%，尚未完全转化为服务终端售价。
3. 菲利普斯曲线斜率在高需求机制下由 0.12 陡峭化至 0.28，表明劳动力市场紧张对核心通胀的溢出效应增强。`
  },
  {
    id: 'rn_2',
    title: '通胀Nowcasting模型集合在2026年中期数据修订中的表现评价',
    author: '华盛计量模型组',
    date: '2026-09-10',
    summary: '分析高频公路货运与农产品价格对月度CPI Nowcast的修正幅度，MIDAS模型在处理混频数据时MAE为0.14%，显著优于传统Bridge Model。',
    tags: ['Nowcasting', 'MIDAS', '混频数据', '数据修订'],
    content: `一、混频Nowcast评估：
1. 2026M08 官方CPI数据公布前，MIDAS模型利用周频货运指数与日频原油即期价，成功将Nowcast精准收敛至 2.15%（实际公布 2.15%）。
2. 数据意外 (Data Surprise) 分析表明，8月上旬农产品批发价格的上行超出市场共识0.06个百分点，为 Nowcast 提供了最早的前瞻修正信号。`
  }
];
