import React from 'react';
import { Database, X, ArrowRight, ShieldCheck, CheckCircle2 } from 'lucide-react';

interface DataLineageModalProps {
  isOpen: boolean;
  onClose: () => void;
  metricName: string;
}

export const DataLineageModal: React.FC<DataLineageModalProps> = ({
  isOpen,
  onClose,
  metricName
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-2xl rounded-xl shadow-2xl overflow-hidden flex flex-col">
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Database className="w-5 h-5 text-blue-400" />
            <h3 className="font-bold text-white text-sm">宏观数据血缘追溯 (Macro Data Lineage Tree)</h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6 font-sans">
          <div className="bg-slate-950 p-3.5 rounded-lg border border-slate-800 flex items-center justify-between text-xs">
            <div>
              <span className="text-slate-400">追溯指标: </span>
              <strong className="text-white font-bold">{metricName || '总体CPI同比'}</strong>
            </div>
            <div className="flex items-center gap-1.5 text-emerald-400 font-mono text-[11px]">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>数据校验与重构审计通过 (100% Retraceable)</span>
            </div>
          </div>

          {/* Visual Lineage Flow */}
          <div className="space-y-4 text-xs">
            <div className="p-3 bg-slate-800/80 rounded-lg border border-slate-700 flex items-center gap-3">
              <div className="w-8 h-8 rounded bg-blue-900/60 text-blue-300 flex items-center justify-center font-bold">1</div>
              <div className="flex-1">
                <div className="font-semibold text-white">顶层指数 (Headline Index)</div>
                <div className="text-slate-400 text-[11px]">总体CPI指数 = Σ (分项指数_i × 可配置权重_i) = 105.8</div>
              </div>
            </div>

            <div className="flex justify-center text-slate-500">
              <ArrowRight className="w-4 h-4 rotate-90" />
            </div>

            <div className="p-3 bg-slate-800/80 rounded-lg border border-slate-700 flex items-center gap-3">
              <div className="w-8 h-8 rounded bg-amber-900/60 text-amber-300 flex items-center justify-center font-bold">2</div>
              <div className="flex-1">
                <div className="font-semibold text-white">4大一级分类与12大篮子细项</div>
                <div className="text-slate-400 text-[11px]">食品(18.5%), 能源(8.5%), 核心商品(35.0%), 核心服务(38.0%)</div>
              </div>
            </div>

            <div className="flex justify-center text-slate-500">
              <ArrowRight className="w-4 h-4 rotate-90" />
            </div>

            <div className="p-3 bg-slate-800/80 rounded-lg border border-slate-700 flex items-center gap-3">
              <div className="w-8 h-8 rounded bg-indigo-900/60 text-indigo-300 flex items-center justify-center font-bold">3</div>
              <div className="flex-1">
                <div className="font-semibold text-white">基层价格采样点 (Price Observation)</div>
                <div className="text-slate-400 text-[11px]">包含500+城市与规格品高频采集价格，经X-13ARIMA-SEATS季节调整</div>
              </div>
            </div>

            <div className="flex justify-center text-slate-500">
              <ArrowRight className="w-4 h-4 rotate-90" />
            </div>

            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-between text-[11px] font-mono">
              <div>
                <span className="text-slate-400">数据源: </span>
                <span className="text-slate-200">华盛 MacroDataProvider (中央银行与统计局模拟规范)</span>
              </div>
              <div>
                <span className="text-slate-400">Vintage时间戳: </span>
                <span className="text-blue-400">2026-09-15 08:00:00</span>
              </div>
            </div>
          </div>
        </div>

        <div className="p-4 bg-slate-950 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold"
          >
            关闭追溯
          </button>
        </div>
      </div>
    </div>
  );
};
