import React from 'react';
import {
  LayoutDashboard,
  TrendingUp,
  PieChart,
  Target,
  Briefcase,
  Zap,
  Globe,
  DollarSign,
  LineChart,
  Users,
  Radio,
  Cpu,
  Sliders,
  Sparkles,
  GitCommit,
  BookOpen,
  BarChart2,
  Database,
  Layers
} from 'lucide-react';

export type TabId =
  | 'overview'
  | 'cpi_basket'
  | 'contribution'
  | 'core'
  | 'services_goods'
  | 'energy_food'
  | 'import_fx'
  | 'wage_ulc'
  | 'phillips'
  | 'expectations'
  | 'nowcast'
  | 'models'
  | 'dsge'
  | 'scenarios'
  | 'ml_lab'
  | 'econometrics'
  | 'episodes'
  | 'data_quality'
  | 'research';

interface NavTabsProps {
  activeTab: TabId;
  onTabChange: (tab: TabId) => void;
}

export const NavTabs: React.FC<NavTabsProps> = ({ activeTab, onTabChange }) => {
  const navItems: { id: TabId; label: string; icon: React.FC<{ className?: string }> }[] = [
    { id: 'overview', label: '通胀监测中心', icon: LayoutDashboard },
    { id: 'cpi_basket', label: 'CPI指数与篮子', icon: PieChart },
    { id: 'contribution', label: '通胀贡献分解', icon: BarChart2 },
    { id: 'core', label: '核心通胀', icon: Target },
    { id: 'services_goods', label: '服务与商品', icon: Briefcase },
    { id: 'energy_food', label: '能源与食品', icon: Zap },
    { id: 'import_fx', label: '进口与汇率', icon: Globe },
    { id: 'wage_ulc', label: '工资与ULC', icon: DollarSign },
    { id: 'phillips', label: '菲利普斯曲线', icon: LineChart },
    { id: 'expectations', label: '通胀预期', icon: Users },
    { id: 'nowcast', label: 'Nowcasting中心', icon: Radio },
    { id: 'models', label: '模型与Fan Chart', icon: Cpu },
    { id: 'dsge', label: '宏观DSGE与政策', icon: Layers },
    { id: 'scenarios', label: '情景分析实验室', icon: Sliders },
    { id: 'ml_lab', label: '机器学习', icon: Sparkles },
    { id: 'econometrics', label: '计量与结构变化', icon: GitCommit },
    { id: 'episodes', label: '评估与历史事件', icon: TrendingUp },
    { id: 'data_quality', label: '数据质量与血缘', icon: Database },
    { id: 'research', label: '研究工作区', icon: BookOpen },
  ];

  return (
    <nav className="bg-slate-900/95 backdrop-blur border-b border-slate-800 px-4 py-2 overflow-x-auto scrollbar-thin scrollbar-thumb-slate-700">
      <div className="flex items-center gap-1 min-w-max">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`px-3 py-2 rounded-md text-xs font-medium flex items-center gap-1.5 transition-all ${
                isActive
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-900/50 font-semibold border border-blue-400/40'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-slate-100 border border-transparent'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-white' : 'text-slate-400'}`} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
