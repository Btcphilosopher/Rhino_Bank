import React from 'react';
import ReactECharts from 'echarts-for-react';
import { InflationContributionItem } from '../types/inflation';

interface WaterfallChartProps {
  items: InflationContributionItem[];
  headlineTotal: number;
  height?: string;
}

export const WaterfallChart: React.FC<WaterfallChartProps> = ({
  items,
  headlineTotal,
  height = '360px',
}) => {
  // Compute Waterfall cumulative positions
  const categories: string[] = ['基准 (0.00%)'];
  const helpData: number[] = [0];
  const contribData: number[] = [0];

  let accum = 0;
  items.forEach((item) => {
    categories.push(`${item.category} (+${item.contribution.toFixed(2)}%)`);
    helpData.push(accum);
    contribData.push(item.contribution);
    accum += item.contribution;
  });

  categories.push(`总体CPI同比 (${headlineTotal.toFixed(2)}%)`);
  helpData.push(0);
  contribData.push(headlineTotal);

  const option = {
    backgroundColor: '#0f172a',
    title: {
      text: 'CPI 分项拉动与贡献瀑布图 (Inflation Contribution Waterfall)',
      textStyle: { color: '#f8fafc', fontSize: 13, fontWeight: 'bold' },
      left: 15,
      top: 10,
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'shadow' },
      formatter: (params: any) => {
        const tar = params[1];
        return `${tar.name}<br/>拉动百分点: <strong>+${tar.value.toFixed(2)}%</strong>`;
      },
      backgroundColor: '#1e293b',
      borderColor: '#475569',
      textStyle: { color: '#f8fafc', fontSize: 12 },
    },
    grid: { left: '3%', right: '4%', bottom: '12%', top: '20%', containLabel: true },
    xAxis: {
      type: 'category',
      data: categories,
      axisLabel: { color: '#94a3b8', fontSize: 11, rotate: 20 },
      axisLine: { lineStyle: { color: '#475569' } },
    },
    yAxis: {
      type: 'value',
      name: '百分点 (%)',
      nameTextStyle: { color: '#94a3b8', fontSize: 11 },
      splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
      axisLabel: { color: '#94a3b8', formatter: '+{value}%' },
    },
    series: [
      {
        name: '辅助底座',
        type: 'bar',
        stack: '总量',
        itemStyle: { barBorderColor: 'rgba(0,0,0,0)', color: 'rgba(0,0,0,0)' },
        data: helpData,
      },
      {
        name: '拉动贡献',
        type: 'bar',
        stack: '总量',
        label: {
          show: true,
          position: 'top',
          color: '#f8fafc',
          formatter: (p: any) => (p.value > 0 ? `+${p.value.toFixed(2)}%` : ''),
        },
        itemStyle: {
          color: (params: any) => {
            if (params.dataIndex === 0) return '#64748b';
            if (params.dataIndex === categories.length - 1) return '#f43f5e';
            const colors = ['#f59e0b', '#ef4444', '#3b82f6', '#10b981', '#8b5cf6', '#06b6d4'];
            return colors[(params.dataIndex - 1) % colors.length];
          },
          borderRadius: [4, 4, 0, 0],
        },
        data: contribData,
      },
    ],
  };

  return (
    <div className="bg-slate-900 rounded-xl border border-slate-800 p-2 shadow-2xl">
      <ReactECharts option={option} style={{ height, width: '100%' }} />
    </div>
  );
};
