import React from 'react';
import ReactECharts from 'echarts-for-react';

interface FanChartProps {
  title?: string;
  subtitle?: string;
  targetLevel?: number;
  height?: string;
}

export const FanChart: React.FC<FanChartProps> = ({
  title = '华盛通胀预测概率 Fan Chart (Inflation Forecast Fan Chart)',
  subtitle = '置信区间: 50% (暗蓝), 70% (中蓝), 90% (淡蓝) · 中央银行标准预测分布',
  targetLevel = 2.0,
  height = '420px',
}) => {
  // Timeline: 2024Q1 to 2027Q2
  const timeCategories = [
    '2024Q1', '2024Q2', '2024Q3', '2024Q4',
    '2025Q1', '2025Q2', '2025Q3', '2025Q4',
    '2026Q1', '2026Q2', '2026Q3 (Nowcast)', '2026Q4',
    '2027Q1', '2027Q2', '2027Q3', '2027Q4'
  ];

  // Historical Actuals (up to 2026Q2)
  const actuals = [1.5, 1.6, 1.8, 1.7, 1.8, 1.9, 2.0, 2.05, 2.10, 2.12, null, null, null, null, null, null];

  // Nowcast point (2026Q3)
  const nowcastPoint = [null, null, null, null, null, null, null, null, null, null, 2.15, null, null, null, null, null];

  // Forecast Baseline Path
  const baseline = [null, null, null, null, null, null, null, null, null, null, 2.15, 2.12, 2.08, 2.04, 2.02, 2.00];

  // Band 90% (outermost: 1.50% to 2.74%)
  const ci90Lower = [null, null, null, null, null, null, null, null, null, null, 2.15, 1.70, 1.55, 1.45, 1.40, 1.35];
  const ci90Width = [null, null, null, null, null, null, null, null, null, null, 0.00, 0.84, 1.06, 1.18, 1.24, 1.30];

  // Band 70% (middle: 1.82% to 2.42%)
  const ci70Lower = [null, null, null, null, null, null, null, null, null, null, 2.15, 1.82, 1.72, 1.65, 1.62, 1.60];
  const ci70Width = [null, null, null, null, null, null, null, null, null, null, 0.00, 0.60, 0.72, 0.78, 0.80, 0.80];

  // Band 50% (inner: 1.95% to 2.29%)
  const ci50Lower = [null, null, null, null, null, null, null, null, null, null, 2.15, 1.95, 1.88, 1.84, 1.82, 1.80];
  const ci50Width = [null, null, null, null, null, null, null, null, null, null, 0.00, 0.34, 0.40, 0.40, 0.40, 0.40];

  const option = {
    backgroundColor: '#0f172a',
    title: {
      text: title,
      subtext: subtitle,
      textStyle: { color: '#f8fafc', fontSize: 14, fontWeight: 'bold' },
      subtextStyle: { color: '#94a3b8', fontSize: 11 },
      top: 10,
      left: 15,
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'cross', label: { backgroundColor: '#334155' } },
      backgroundColor: '#1e293b',
      borderColor: '#475569',
      textStyle: { color: '#f8fafc', fontSize: 12 },
    },
    legend: {
      data: ['历史观测值', '实时Nowcast', '基准预测路径', '50%置信区间', '70%置信区间', '90%置信区间', '央行2.0%目标'],
      textStyle: { color: '#cbd5e1', fontSize: 11 },
      top: 15,
      right: 20,
    },
    grid: { left: '4%', right: '4%', bottom: '10%', top: '22%', containLabel: true },
    xAxis: {
      type: 'category',
      boundaryGap: false,
      data: timeCategories,
      axisLine: { lineStyle: { color: '#475569' } },
      axisLabel: { color: '#94a3b8', fontSize: 11, rotate: 15 },
    },
    yAxis: {
      type: 'value',
      name: '通胀率 (%)',
      nameTextStyle: { color: '#94a3b8', fontSize: 11 },
      min: 1.0,
      max: 3.2,
      splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
      axisLabel: { color: '#94a3b8', formatter: '{value}%' },
    },
    series: [
      // 2.0% Target Line
      {
        name: '央行2.0%目标',
        type: 'line',
        data: timeCategories.map(() => targetLevel),
        symbol: 'none',
        lineStyle: { color: '#ef4444', width: 2, type: 'dashed' },
      },
      // 90% Band Lower
      {
        name: '90% Band Lower',
        type: 'line',
        data: ci90Lower,
        lineStyle: { opacity: 0 },
        stack: 'confidence-90',
        symbol: 'none',
      },
      // 90% Band Area
      {
        name: '90%置信区间',
        type: 'line',
        data: ci90Width,
        lineStyle: { opacity: 0 },
        areaStyle: { color: 'rgba(56, 189, 248, 0.15)' },
        stack: 'confidence-90',
        symbol: 'none',
      },
      // 70% Band Lower
      {
        name: '70% Band Lower',
        type: 'line',
        data: ci70Lower,
        lineStyle: { opacity: 0 },
        stack: 'confidence-70',
        symbol: 'none',
      },
      // 70% Band Area
      {
        name: '70%置信区间',
        type: 'line',
        data: ci70Width,
        lineStyle: { opacity: 0 },
        areaStyle: { color: 'rgba(56, 189, 248, 0.25)' },
        stack: 'confidence-70',
        symbol: 'none',
      },
      // 50% Band Lower
      {
        name: '50% Band Lower',
        type: 'line',
        data: ci50Lower,
        lineStyle: { opacity: 0 },
        stack: 'confidence-50',
        symbol: 'none',
      },
      // 50% Band Area
      {
        name: '50%置信区间',
        type: 'line',
        data: ci50Width,
        lineStyle: { opacity: 0 },
        areaStyle: { color: 'rgba(56, 189, 248, 0.40)' },
        stack: 'confidence-50',
        symbol: 'none',
      },
      // Historical Actuals
      {
        name: '历史观测值',
        type: 'line',
        data: actuals,
        symbol: 'circle',
        symbolSize: 6,
        itemStyle: { color: '#38bdf8' },
        lineStyle: { color: '#38bdf8', width: 3 },
      },
      // Nowcast Point
      {
        name: '实时Nowcast',
        type: 'effectScatter',
        data: nowcastPoint,
        symbolSize: 12,
        showEffectOn: 'render',
        rippleEffect: { brushType: 'stroke', scale: 3 },
        itemStyle: { color: '#f59e0b' },
      },
      // Forecast Baseline Path
      {
        name: '基准预测路径',
        type: 'line',
        data: baseline,
        symbol: 'circle',
        symbolSize: 6,
        itemStyle: { color: '#6366f1' },
        lineStyle: { color: '#818cf8', width: 3, type: 'dashed' },
      },
    ],
  };

  return (
    <div className="bg-slate-900 rounded-xl border border-slate-800 p-2 shadow-2xl overflow-hidden">
      <ReactECharts option={option} style={{ height, width: '100%' }} />
    </div>
  );
};
