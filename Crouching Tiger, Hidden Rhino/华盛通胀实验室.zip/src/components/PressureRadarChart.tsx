import React from 'react';
import ReactECharts from 'echarts-for-react';

interface PressureRadarChartProps {
  height?: string;
}

export const PressureRadarChart: React.FC<PressureRadarChartProps> = ({ height = '320px' }) => {
  const option = {
    backgroundColor: '#0f172a',
    title: {
      text: '通胀压力雷达 (Inflation Pressure Radar - 6D)',
      textStyle: { color: '#f8fafc', fontSize: 13, fontWeight: 'bold' },
      left: 15,
      top: 10,
    },
    tooltip: {
      trigger: 'item',
      backgroundColor: '#1e293b',
      borderColor: '#475569',
      textStyle: { color: '#f8fafc', fontSize: 12 },
    },
    legend: {
      data: ['当前状态 (2026M08)', '1年前状态 (2025M08)', '历史均值'],
      textStyle: { color: '#cbd5e1', fontSize: 11 },
      bottom: 10,
    },
    radar: {
      indicator: [
        { name: '需求压力 (产出缺口)', max: 100 },
        { name: '工资-ULC压力', max: 100 },
        { name: '服务通胀粘性', max: 100 },
        { name: '输入与汇率传导', max: 100 },
        { name: '能源冲击', max: 100 },
        { name: '通胀预期脱锚度', max: 100 },
      ],
      shape: 'polygon',
      splitNumber: 4,
      axisName: { color: '#94a3b8', fontSize: 11 },
      splitLine: { lineStyle: { color: ['#1e293b', '#334155', '#475569'] } },
      splitArea: { areaStyle: { color: ['#0f172a', '#1e293b'] } },
      axisLine: { lineStyle: { color: '#334155' } },
    },
    series: [
      {
        type: 'radar',
        data: [
          {
            value: [64, 71, 66, 48, 55, 59],
            name: '当前状态 (2026M08)',
            itemStyle: { color: '#f43f5e' },
            areaStyle: { color: 'rgba(244, 63, 94, 0.30)' },
            lineStyle: { width: 2 },
          },
          {
            value: [52, 62, 58, 42, 45, 50],
            name: '1年前状态 (2025M08)',
            itemStyle: { color: '#38bdf8' },
            areaStyle: { color: 'rgba(56, 189, 248, 0.15)' },
            lineStyle: { width: 1.5, type: 'dashed' },
          },
          {
            value: [50, 50, 50, 50, 50, 50],
            name: '历史均值',
            itemStyle: { color: '#64748b' },
            lineStyle: { width: 1, type: 'dotted' },
          },
        ],
      },
    ],
  };

  return (
    <div className="bg-slate-900 rounded-xl border border-slate-800 p-2 shadow-2xl">
      <ReactECharts option={option} style={{ height, width: '100%' }} />
    </div>
  );
};
