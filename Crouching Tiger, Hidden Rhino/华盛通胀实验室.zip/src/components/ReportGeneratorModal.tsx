import React, { useState } from 'react';
import { FileText, Download, X, CheckCircle, Printer, FileSpreadsheet, Share2 } from 'lucide-react';

interface ReportGeneratorModalProps {
  isOpen: boolean;
  onClose: () => void;
  vintageDate: string;
}

export const ReportGeneratorModal: React.FC<ReportGeneratorModalProps> = ({
  isOpen,
  onClose,
  vintageDate
}) => {
  const [format, setFormat] = useState<'HTML' | 'Markdown' | 'CSV' | 'JSON'>('HTML');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const sampleReportText = `================================================================================
【华盛通胀实验室】中央银行级通胀监测与分析报告
HUASHENG INFLATION LAB - INFLATION INTELLIGENCE REPORT
数据Vintage版本: ${vintageDate} | 报告时间: 2026-09-17
================================================================================

一、总体结论 (Executive Summary)
1. 2026M08 总体CPI同比报 2.15% (上期 2.05%)，环比增长 0.22% (季调环比 0.18%)。
2. 核心CPI同比报 1.85%，处于历史 52% 分位数，表明需求拉动型通胀温和。
3. 实时 Nowcast 显示 2026M09 CPI估值为 2.15% (90%置信区间 1.60% ~ 2.62%)。
4. 风险研判：服务通胀 (2.45%) 与单位劳动成本 (ULC 2.60%) 构成通胀粘性的主要边际来源。

二、分项拉动与贡献分解 (Inflation Contributions)
• 食品与非酒精饮料 (权重 18.5%): 同比 2.80% | 拉动总体CPI +0.52 个百分点
• 能源价格 (权重 8.5%): 同比 3.50% | 拉动总体CPI +0.30 个百分点
• 住房与租金 (权重 16.0%): 同比 2.60% | 拉动总体CPI +0.42 个百分点
• 核心商品 (权重 35.0%): 同比 1.42% | 拉动总体CPI +0.50 个百分点
• 核心服务 (不含住房) (权重 22.0%): 同比 2.32% | 拉动总体CPI +0.51 个百分点

三、核心通胀与截尾均值 (Core & Trimmed Mean)
• Trimmed Mean 5%: 2.02%
• Trimmed Mean 10%: 1.94%
• Trimmed Mean 20%: 1.82%
• 加权中位数通胀 (Weighted Median): 1.88%

四、通胀预期与 Phillips Curve
• 1年期市场通胀预期 (Swaps): 2.10% | 10年期Breakeven: 1.99%
• 混合 NKPC 估算参数: α(滞后)=0.40, β(预期)=0.55, κ(产出缺口斜率)=0.18

五、模型与 Fan Chart 预测
• 动态因子模型 (DFM): 2026Q4 预测 2.12%
• BVAR v2.0: 2026Q4 预测 2.18%
• 机器学习 LightGBM: 2026Q4 预测 2.22%

================================================================================
华盛通胀实验室 · 宏观计量与央行研究团队
`;

  const handleDownload = () => {
    const blob = new Blob([sampleReportText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `华盛通胀实验室_通胀分析报告_${vintageDate}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(sampleReportText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-2xl rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <FileText className="w-5 h-5 text-amber-400" />
            <h3 className="font-bold text-white text-sm">自动生成央行级通胀分析报告 (Inflation Report Generator)</h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/50">
          <div className="flex items-center gap-2 text-xs text-slate-300">
            <span>选择导出格式:</span>
            {(['HTML', 'Markdown', 'CSV', 'JSON'] as const).map((f) => (
              <button
                key={f}
                onClick={() => setFormat(f)}
                className={`px-2.5 py-1 rounded text-xs font-mono font-medium transition-colors ${
                  format === f ? 'bg-amber-500 text-slate-950 font-bold' : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                {f}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 flex items-center gap-1.5"
            >
              {copied ? <CheckCircle className="w-3.5 h-3.5 text-emerald-400" /> : <Share2 className="w-3.5 h-3.5" />}
              <span>{copied ? '已复制到剪贴板' : '复制文本'}</span>
            </button>
            <button
              onClick={handleDownload}
              className="px-3.5 py-1.5 rounded bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold flex items-center gap-1.5 shadow"
            >
              <Download className="w-3.5 h-3.5" />
              <span>下载完整报告</span>
            </button>
          </div>
        </div>

        <div className="flex-1 p-4 overflow-y-auto bg-slate-950 font-mono text-xs text-slate-300 whitespace-pre-wrap leading-relaxed border-inner">
          {sampleReportText}
        </div>
      </div>
    </div>
  );
};
