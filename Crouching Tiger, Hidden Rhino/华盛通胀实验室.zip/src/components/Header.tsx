import React, { useState } from 'react';
import {
  Activity,
  Database,
  Search,
  Bot,
  FileText,
  Calendar,
  Layers,
  ChevronDown,
  Clock,
  ShieldCheck,
  TrendingUp,
  Share2
} from 'lucide-react';

interface HeaderProps {
  currentVintage: string;
  onSelectVintage: (vintage: string) => void;
  onOpenAIAssistant: () => void;
  onOpenReportGenerator: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentVintage,
  onSelectVintage,
  onOpenAIAssistant,
  onOpenReportGenerator
}) => {
  const [showVintageDropdown, setShowVintageDropdown] = useState(false);

  const vintages = [
    { label: '最新信息集 (2026M08)', value: '2026M08', date: '2026-09-15' },
    { label: '二季度快报集 (2026M05)', value: '2026M05', date: '2026-06-10' },
    { label: '年初基准集 (2026M01)', value: '2026M01', date: '2026-02-01' },
    { label: '历史对比集 (2025M06)', value: '2025M06', date: '2025-07-01' },
  ];

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-slate-100 sticky top-0 z-40 shadow-xl">
      {/* Top Banner Ticker */}
      <div className="bg-slate-950 px-4 py-1 text-xs border-b border-slate-800/80 flex flex-wrap items-center justify-between gap-2 text-slate-400 font-mono">
        <div className="flex items-center gap-4 overflow-x-auto py-0.5">
          <span className="flex items-center gap-1.5 text-emerald-400 font-semibold">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            系统状态: 央行研究计算引擎就绪
          </span>
          <span className="text-slate-600">|</span>
          <span>最新 Nowcast (2026M09): <strong className="text-slate-200">2.15%</strong> (±0.04)</span>
          <span className="text-slate-600">|</span>
          <span>核心CPI同比: <strong className="text-slate-200">1.85%</strong></span>
          <span className="text-slate-600">|</span>
          <span>服务通胀: <strong className="text-amber-400">2.45%</strong></span>
          <span className="text-slate-600">|</span>
          <span>通胀预期(1Y): <strong className="text-slate-200">2.25%</strong></span>
        </div>

        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1 text-slate-400">
            <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
            企业级数据安全审计 (Audit Log Active)
          </span>
          <span className="text-slate-600">|</span>
          <span className="text-blue-400">HUASHENG INFLATION LAB v3.6</span>
        </div>
      </div>

      {/* Main Header Container */}
      <div className="px-6 py-3.5 flex flex-wrap items-center justify-between gap-4">
        {/* Brand & Platform Identity */}
        <div className="flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-700 via-indigo-800 to-slate-950 flex items-center justify-center border border-blue-500/40 shadow-lg shadow-blue-900/30">
            <Activity className="w-6 h-6 text-blue-300" />
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-bold tracking-tight text-white font-sans">华盛通胀实验室</h1>
              <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-blue-950 text-blue-300 border border-blue-800/80 tracking-wide uppercase">
                Central-Bank-Grade
              </span>
            </div>
            <p className="text-xs text-slate-400 font-mono">HUASHENG INFLATION LAB · 央行级通胀分析、监测与预测系统</p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-3">
          {/* Data Vintage Selector */}
          <div className="relative">
            <button
              onClick={() => setShowVintageDropdown(!showVintageDropdown)}
              className="px-3 py-1.5 rounded-md bg-slate-800/90 hover:bg-slate-700/90 text-xs font-medium text-slate-200 border border-slate-700 flex items-center gap-2 transition-all shadow-inner"
            >
              <Clock className="w-3.5 h-3.5 text-blue-400" />
              <span>数据Vintage: <strong className="text-white font-mono">{currentVintage}</strong></span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>

            {showVintageDropdown && (
              <div className="absolute right-0 mt-1.5 w-64 rounded-lg bg-slate-900 border border-slate-700 shadow-2xl p-2 z-50">
                <div className="text-[11px] font-semibold text-slate-400 px-2 py-1 uppercase tracking-wider font-mono">
                  选择历史信息集 (Real-Time Vintage)
                </div>
                {vintages.map((v) => (
                  <button
                    key={v.value}
                    onClick={() => {
                      onSelectVintage(v.value);
                      setShowVintageDropdown(false);
                    }}
                    className={`w-full text-left px-2.5 py-2 rounded-md text-xs flex items-center justify-between transition-colors ${
                      currentVintage === v.value
                        ? 'bg-blue-900/50 text-blue-200 border border-blue-700/50 font-medium'
                        : 'text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <div>
                      <div className="font-semibold">{v.label}</div>
                      <div className="text-[10px] text-slate-400 font-mono">数据截至: {v.date}</div>
                    </div>
                    {currentVintage === v.value && <span className="w-2 h-2 rounded-full bg-blue-400"></span>}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* AI Macro Assistant Trigger */}
          <button
            onClick={onOpenAIAssistant}
            className="px-3.5 py-1.5 rounded-md bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-semibold flex items-center gap-2 shadow-lg shadow-blue-900/40 border border-blue-400/30 transition-all active:scale-95"
          >
            <Bot className="w-4 h-4 text-blue-200 animate-pulse" />
            <span>华盛宏观助手 (AI)</span>
          </button>

          {/* Report Generator Trigger */}
          <button
            onClick={onOpenReportGenerator}
            className="px-3 py-1.5 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 flex items-center gap-2 transition-all"
          >
            <FileText className="w-3.5 h-3.5 text-amber-400" />
            <span>生成通胀报告</span>
          </button>
        </div>
      </div>
    </header>
  );
};
