import React, { useState } from 'react';
import { Bot, X, Send, Sparkles, AlertCircle, RefreshCw, Layers } from 'lucide-react';

interface AIAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  contextData: any;
  onRunScenarioPreset?: (presetId: string) => void;
}

export const AIAssistantModal: React.FC<AIAssistantModalProps> = ({
  isOpen,
  onClose,
  contextData,
  onRunScenarioPreset
}) => {
  const [messages, setMessages] = useState<
    { sender: 'user' | 'ai'; text: string; timestamp: string; isAI?: boolean }[]
  >([
    {
      sender: 'ai',
      text: '您好！我是「华盛宏观助手」。我可以为您解析当前通胀分解、估算冲击传导路径、对比历史事件，并调用平台 Scenario 引擎执行情景模拟。请问您需要分析什么？',
      timestamp: '04:02',
      isAI: true
    }
  ]);

  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const presetQuestions = [
    '为什么本月核心通胀上升？分项拉动是多少？',
    '如果国际原油与能源价格上涨 20%，总体与核心 CPI 会如何变化？',
    '工资增速 (ULC) 保持在 2.6% 对服务通胀粘性有什么长期影响？',
    '评估当前菲利普斯曲线斜率与产出缺口对 CPI 的传导强度。'
  ];

  const handleSend = async (questionText?: string) => {
    const textToSend = questionText || input;
    if (!textToSend.trim()) return;

    const userMsg = {
      sender: 'user' as const,
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!questionText) setInput('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: textToSend,
          context: contextData
        })
      });

      const data = await res.json();

      if (data.error) {
        setMessages((prev) => [
          ...prev,
          {
            sender: 'ai',
            text: `⚠️ 系统提示: ${data.error}`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            isAI: true
          }
        ]);
      } else {
        setMessages((prev) => [
          ...prev,
          {
            sender: 'ai',
            text: data.reply,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            isAI: true
          }
        ]);
      }
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        {
          sender: 'ai',
          text: '网络连接异常，未能完成央行 AI 模型调用。',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          isAI: true
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex justify-end">
      <div className="w-full max-w-lg bg-slate-900 border-l border-slate-800 h-full flex flex-col shadow-2xl animate-in slide-in-from-right duration-200">
        {/* Modal Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-blue-600/30 border border-blue-500/40 flex items-center justify-center">
              <Bot className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-white text-sm">华盛宏观助手 (AI Assistant)</h3>
                <span className="px-1.5 py-0.5 rounded text-[10px] bg-blue-900/60 text-blue-300 font-mono border border-blue-700/50">
                  Gemini 3.6
                </span>
              </div>
              <p className="text-xs text-slate-400 font-mono">中央银行级宏观研判与情景推演引擎</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Safety Disclaimer Banner */}
        <div className="bg-amber-950/40 border-b border-amber-900/50 px-4 py-2 text-[11px] text-amber-200 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
          <span>AI 生成分析结论仅供宏观研究参考，不构成官方统计结论或货币政策政策声明。</span>
        </div>

        {/* Chat Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 font-sans text-xs">
          {messages.map((msg, idx) => (
            <div
              key={idx}
              className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div className="flex items-center gap-1.5 mb-1 text-[10px] text-slate-400 font-mono">
                <span>{msg.sender === 'user' ? '研究员' : '华盛宏观助手'}</span>
                <span>·</span>
                <span>{msg.timestamp}</span>
                {msg.isAI && (
                  <span className="px-1 py-0.2 bg-emerald-950 text-emerald-300 border border-emerald-800 rounded text-[9px] font-sans">
                    AI生成分析
                  </span>
                )}
              </div>

              <div
                className={`max-w-[90%] p-3.5 rounded-xl text-slate-100 whitespace-pre-wrap leading-relaxed shadow-md ${
                  msg.sender === 'user'
                    ? 'bg-blue-600 text-white rounded-br-none font-medium'
                    : 'bg-slate-800/90 border border-slate-700/80 rounded-bl-none text-slate-200'
                }`}
              >
                {msg.text}
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex items-center gap-2 text-slate-400 text-xs py-2">
              <RefreshCw className="w-4 h-4 animate-spin text-blue-400" />
              <span>宏观助手正在计算模型传导路径并生成深度研判...</span>
            </div>
          )}
        </div>

        {/* Preset Prompt Shortcuts */}
        <div className="p-3 bg-slate-950/80 border-t border-slate-800 space-y-1.5">
          <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider font-mono flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-amber-400" />
            央行研究预设问题 (Preset Queries)
          </div>
          <div className="flex flex-col gap-1 max-h-28 overflow-y-auto pr-1">
            {presetQuestions.map((q, i) => (
              <button
                key={i}
                onClick={() => handleSend(q)}
                disabled={isLoading}
                className="text-left px-2.5 py-1.5 rounded bg-slate-800/70 hover:bg-slate-800 text-slate-300 text-[11px] border border-slate-700/50 hover:text-white transition-colors truncate"
              >
                • {q}
              </button>
            ))}
          </div>
        </div>

        {/* Input Area */}
        <div className="p-3 bg-slate-950 border-t border-slate-800 flex items-center gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="输入通胀问题或情景假设 (如: 能源价格上涨20%会怎样)..."
            disabled={isLoading}
            className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
          />
          <button
            onClick={() => handleSend()}
            disabled={isLoading || !input.trim()}
            className="px-3.5 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-xs font-semibold flex items-center gap-1 transition-all"
          >
            <Send className="w-3.5 h-3.5" />
            <span>发送</span>
          </button>
        </div>
      </div>
    </div>
  );
};
