import React from 'react';
import { WaterfallChart } from '../components/WaterfallChart';
import { mockContributionWaterfall } from '../engine/mockDatabase';
import { BarChart3, PieChart, Layers } from 'lucide-react';

export const ContributionView: React.FC = () => {
  return (
    <div className="p-6 space-y-6 bg-slate-950 text-slate-100 min-h-screen">
      <div className="border-b border-slate-800 pb-3">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <BarChart3 className="w-5 h-5 text-amber-400" />
          通胀贡献分解引擎 (Inflation Contribution Engine & Waterfall)
        </h2>
        <p className="text-xs text-slate-400 font-mono mt-0.5">
          计算每个分项对总体通胀的边际拉动 (拉动百分点 = 权重 × 同比增速)
        </p>
      </div>

      <WaterfallChart items={mockContributionWaterfall.slice(0, 5)} headlineTotal={2.15} height="420px" />

      {/* Contribution Table */}
      <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 shadow-xl">
        <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono mb-3">
          分项贡献详细表 (Contribution Breakdown Table)
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="py-2.5">分项名称</th>
                <th className="py-2.5">CPI权重 (%)</th>
                <th className="py-2.5">同比增速 (%)</th>
                <th className="py-2.5">拉动贡献 (个百分点)</th>
                <th className="py-2.5">贡献占比 (%)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {mockContributionWaterfall.map((item, idx) => {
                const ratio = ((item.contribution / 2.15) * 100).toFixed(1);
                return (
                  <tr key={idx} className="hover:bg-slate-800/40">
                    <td className="py-2.5 font-sans font-semibold text-white flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                      {item.category}
                    </td>
                    <td className="py-2.5">{item.weight.toFixed(1)}%</td>
                    <td className="py-2.5 text-rose-400 font-bold">+{item.yoyChange.toFixed(2)}%</td>
                    <td className="py-2.5 text-amber-400 font-bold">+{item.contribution.toFixed(2)}%</td>
                    <td className="py-2.5 text-blue-300 font-bold">{ratio}%</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
