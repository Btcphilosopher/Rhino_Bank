import React, { useState } from 'react';
import { Zap, Sliders, RefreshCw, AlertTriangle } from 'lucide-react';
import { runScenarioSimulation } from '../engine/scenariosEngine';

export const EnergyFoodView: React.FC = () => {
  const [energyShockPct, setEnergyShockPct] = useState(25);

  const simResult = runScenarioSimulation({
    energyPricePct: energyShockPct,
    foodPricePct: 0,
    fxDepreciationPct: 0,
    wageGrowthPct: 0,
    productivityGrowthPct: 0,
    unemploymentGap: 0,
    outputGap: 0,
    globalDemandPct: 0,
    importPricePct: 0,
    inflationExpectationsPct: 0,
    policyRateBp: 0,
  });

  return (
    <div className="p-6 space-y-6 bg-slate-950 text-slate-100 min-h-screen">
      <div className="border-b border-slate-800 pb-3">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <Zap className="w-5 h-5 text-amber-400" />
          能源与食品通胀实验室 (Energy & Food Lab & Shock Simulator)
        </h2>
        <p className="text-xs text-slate-400 font-mono mt-0.5">
          直接贡献、二阶通胀传导与能源大宗冲击模拟 (Energy Shock Simulator)
        </p>
      </div>

      {/* Energy Shock Simulator */}
      <div className="bg-slate-900 rounded-xl border border-slate-800 p-5 shadow-2xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-400" />
            能源冲击模拟器 (Energy Shock Simulator)
          </h3>
          <span className="text-xs font-mono text-amber-400">假设能源价格变动: <strong>+{energyShockPct}%</strong></span>
        </div>

        <div className="flex gap-3">
          {[10, 25, 50].map((val) => (
            <button
              key={val}
              onClick={() => setEnergyShockPct(val)}
              className={`px-4 py-2 rounded-lg text-xs font-bold font-mono border transition-all ${
                energyShockPct === val
                  ? 'bg-amber-500 text-slate-950 border-amber-400 shadow'
                  : 'bg-slate-800 border-slate-700 text-slate-300 hover:text-white'
              }`}
            >
              能源价格 +{val}%
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 pt-2">
          <div className="bg-slate-950 p-3.5 rounded-lg border border-slate-800">
            <span className="text-slate-400 text-[11px] block font-mono">能源CPI受冲击后</span>
            <strong className="text-xl font-bold font-mono text-rose-400">
              +{(3.5 + energyShockPct * 0.85).toFixed(2)}%
            </strong>
          </div>

          <div className="bg-slate-950 p-3.5 rounded-lg border border-slate-800">
            <span className="text-slate-400 text-[11px] block font-mono">总体CPI (Headline) 模拟</span>
            <strong className="text-xl font-bold font-mono text-amber-400">
              +{simResult.headlineCpi.toFixed(2)}%
            </strong>
          </div>

          <div className="bg-slate-950 p-3.5 rounded-lg border border-slate-800">
            <span className="text-slate-400 text-[11px] block font-mono">核心CPI (Core) 二阶溢出</span>
            <strong className="text-xl font-bold font-mono text-blue-400">
              +{simResult.coreCpi.toFixed(2)}%
            </strong>
          </div>

          <div className="bg-slate-950 p-3.5 rounded-lg border border-slate-800">
            <span className="text-slate-400 text-[11px] block font-mono">1年期通胀预期响应</span>
            <strong className="text-xl font-bold font-mono text-purple-400">
              +{(2.25 + energyShockPct * 0.015).toFixed(2)}%
            </strong>
          </div>
        </div>
      </div>
    </div>
  );
};
