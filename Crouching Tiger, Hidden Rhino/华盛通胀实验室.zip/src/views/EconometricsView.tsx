import React from 'react';
import { Activity, ShieldCheck, FileSpreadsheet } from 'lucide-react';

export const EconometricsView: React.FC = () => {
  return (
    <div className="p-6 space-y-6 bg-slate-950 text-slate-100 min-h-screen">
      <div className="border-b border-slate-800 pb-3">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <Activity className="w-5 h-5 text-indigo-400" />
          高级计量经济学与结构变动诊断 (Econometrics & Structural Break Lab)
        </h2>
        <p className="text-xs text-slate-400 font-mono mt-0.5">
          Chow Test, Bai-Perron 结构断点检验、ADF平稳性检验与协整回归 (Cointegration)
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 font-mono text-xs">
        <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-2 shadow-xl">
          <span className="text-slate-400 block font-bold">Bai-Perron 结构断点检测</span>
          <div className="p-2.5 bg-slate-950 rounded border border-slate-800 space-y-1">
            <div>断点1: <strong className="text-amber-400">2015Q4 (供给侧改革)</strong></div>
            <div>断点2: <strong className="text-rose-400">2020Q1 (疫情大冲击)</strong></div>
            <div className="text-[10px] text-slate-500">F-Stat: 28.4 (p-val &lt; 0.001)</div>
          </div>
        </div>

        <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-2 shadow-xl">
          <span className="text-slate-400 block font-bold">ADF 平稳性检验 (Unit Root)</span>
          <div className="p-2.5 bg-slate-950 rounded border border-slate-800 space-y-1">
            <div>CPI同比 Level: <strong className="text-rose-400">非平稳 (p=0.42)</strong></div>
            <div>CPI同比 1st Diff: <strong className="text-emerald-400">一阶平稳 I(1) (p&lt;0.01)</strong></div>
            <div className="text-[10px] text-slate-500">满足 VAR/BVAR 建模条件</div>
          </div>
        </div>

        <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-2 shadow-xl">
          <span className="text-slate-400 block font-bold">Johansen 协整检验</span>
          <div className="p-2.5 bg-slate-950 rounded border border-slate-800 space-y-1">
            <div>变量组: <strong className="text-blue-300">工资, 生产率, 服务通胀</strong></div>
            <div>协整向量数 r: <strong className="text-emerald-400 font-bold">r = 1 (存在长期均衡)</strong></div>
            <div className="text-[10px] text-slate-500">Trace Stat: 35.2 &gt; Critical (29.8)</div>
          </div>
        </div>
      </div>
    </div>
  );
};
