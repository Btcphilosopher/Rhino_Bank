import React from 'react';
import { Briefcase, ShoppingBag, ArrowUpRight, Percent, DollarSign } from 'lucide-react';

export const ServicesGoodsView: React.FC = () => {
  return (
    <div className="p-6 space-y-6 bg-slate-950 text-slate-100 min-h-screen">
      <div className="border-b border-slate-800 pb-3">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <Briefcase className="w-5 h-5 text-blue-400" />
          服务与商品通胀中心 (Services & Goods Inflation Center)
        </h2>
        <p className="text-xs text-slate-400 font-mono mt-0.5">
          服务价格粘性、租金传导与耐用/非耐用商品生产运输成本分解
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Services Inflation Deep Dive */}
        <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono flex items-center gap-2">
              <Briefcase className="w-4 h-4 text-blue-400" />
              核心服务通胀 (Services CPI: 2.45% YoY)
            </h3>
            <span className="text-[11px] text-amber-400 font-mono font-bold">高粘性 (High Persistence)</span>
          </div>

          <div className="space-y-2 text-xs font-mono">
            <div className="flex justify-between p-2.5 bg-slate-950 rounded border border-slate-800">
              <span className="font-sans font-semibold text-slate-200">主要住房与主要租金</span>
              <span className="text-rose-400 font-bold">+2.60% (贡献 +0.42%)</span>
            </div>
            <div className="flex justify-between p-2.5 bg-slate-950 rounded border border-slate-800">
              <span className="font-sans font-semibold text-slate-200">餐饮与住宿服务</span>
              <span className="text-rose-400 font-bold">+3.10% (贡献 +0.23%)</span>
            </div>
            <div className="flex justify-between p-2.5 bg-slate-950 rounded border border-slate-800">
              <span className="font-sans font-semibold text-slate-200">医疗与健康服务</span>
              <span className="text-emerald-400 font-bold">+1.80% (贡献 +0.09%)</span>
            </div>
            <div className="flex justify-between p-2.5 bg-slate-950 rounded border border-slate-800">
              <span className="font-sans font-semibold text-slate-200">教育与休闲服务</span>
              <span className="text-emerald-400 font-bold">+2.00% (贡献 +0.11%)</span>
            </div>
          </div>

          <div className="p-3 bg-blue-950/40 rounded-lg border border-blue-800/50 text-[11px] text-blue-200">
            <strong>央行研判:</strong> 服务通胀受工资-单位劳动成本 (ULC) 支配。当前名义工资增速 4.2%，劳动生产率增速 1.6%，导致 ULC 上行 2.6%，支撑核心服务通胀维持在 2.4%~2.5% 区间。
          </div>
        </div>

        {/* Goods Inflation Deep Dive */}
        <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono flex items-center gap-2">
              <ShoppingBag className="w-4 h-4 text-emerald-400" />
              核心商品通胀 (Goods CPI: 1.42% YoY)
            </h3>
            <span className="text-[11px] text-emerald-400 font-mono font-bold">低粘性 (Low Persistence)</span>
          </div>

          <div className="space-y-2 text-xs font-mono">
            <div className="flex justify-between p-2.5 bg-slate-950 rounded border border-slate-800">
              <span className="font-sans font-semibold text-slate-200">耐用品 (汽车、家电、家具)</span>
              <span className="text-emerald-400 font-bold">+0.60% (贡献 +0.09%)</span>
            </div>
            <div className="flex justify-between p-2.5 bg-slate-950 rounded border border-slate-800">
              <span className="font-sans font-semibold text-slate-200">非耐用品 (服装、日用品)</span>
              <span className="text-blue-400 font-bold">+1.90% (贡献 +0.23%)</span>
            </div>
            <div className="flex justify-between p-2.5 bg-slate-950 rounded border border-slate-800">
              <span className="font-sans font-semibold text-slate-200">进口消费品</span>
              <span className="text-amber-400 font-bold">+2.20% (贡献 +0.18%)</span>
            </div>
          </div>

          <div className="p-3 bg-emerald-950/40 rounded-lg border border-emerald-800/50 text-[11px] text-emerald-200">
            <strong>央行研判:</strong> 供应链改善与全球生产成本平稳使得耐用品通胀极低 (+0.6%)，但海运运费与进口原材料成本微升对非耐用品存在通胀压力。
          </div>
        </div>
      </div>
    </div>
  );
};
