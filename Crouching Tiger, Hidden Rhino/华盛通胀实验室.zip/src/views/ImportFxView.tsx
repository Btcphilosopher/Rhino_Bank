import React, { useState } from 'react';
import { Globe, Sliders, ArrowRight } from 'lucide-react';
import { computeExchangeRatePassThrough } from '../engine/phillipsCurve';

export const ImportFxView: React.FC = () => {
  const [fxDepreciationPct, setFxDepreciationPct] = useState(5.0);

  const passThrough = computeExchangeRatePassThrough(fxDepreciationPct);

  return (
    <div className="p-6 space-y-6 bg-slate-950 text-slate-100 min-h-screen">
      <div className="border-b border-slate-800 pb-3">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <Globe className="w-5 h-5 text-indigo-400" />
          进口通胀与汇率传导实验室 (Imported Inflation & Exchange Rate Pass-Through)
        </h2>
        <p className="text-xs text-slate-400 font-mono mt-0.5">
          汇率 Pass-Through 弹性模型：汇率变动 → 进口价格 → 核心商品 → 总体CPI
        </p>
      </div>

      {/* Interactive FX Pass Through Controls */}
      <div className="bg-slate-900 rounded-xl border border-slate-800 p-5 shadow-2xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
            本币汇率贬值幅度设算 (Exchange Rate Depreciation Shock)
          </h3>
          <span className="text-xs font-mono text-indigo-300">贬值假设: <strong>+{fxDepreciationPct}%</strong></span>
        </div>

        <div className="flex gap-3">
          {[1.0, 5.0, 10.0].map((val) => (
            <button
              key={val}
              onClick={() => setFxDepreciationPct(val)}
              className={`px-4 py-2 rounded-lg text-xs font-bold font-mono border transition-all ${
                fxDepreciationPct === val
                  ? 'bg-indigo-600 text-white border-indigo-400 shadow'
                  : 'bg-slate-800 border-slate-700 text-slate-300 hover:text-white'
              }`}
            >
              汇率贬值 +{val}%
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
          <div className="bg-slate-950 p-4 rounded-lg border border-slate-800">
            <span className="text-slate-400 text-[11px] block font-mono">1. 进口商品价格影响 (弹性 0.35)</span>
            <strong className="text-xl font-bold font-mono text-indigo-300">
              +{passThrough.importPriceEffect}%
            </strong>
          </div>

          <div className="bg-slate-950 p-4 rounded-lg border border-slate-800">
            <span className="text-slate-400 text-[11px] block font-mono">2. 总体CPI终值拉动 (弹性 0.08)</span>
            <strong className="text-xl font-bold font-mono text-amber-400">
              +{passThrough.headlineCpiEffect}%
            </strong>
          </div>

          <div className="bg-slate-950 p-4 rounded-lg border border-slate-800">
            <span className="text-slate-400 text-[11px] block font-mono">3. 核心CPI终值拉动 (弹性 0.05)</span>
            <strong className="text-xl font-bold font-mono text-blue-400">
              +{passThrough.coreCpiEffect}%
            </strong>
          </div>
        </div>
      </div>
    </div>
  );
};
