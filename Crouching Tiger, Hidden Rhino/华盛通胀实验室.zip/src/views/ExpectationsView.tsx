import React from 'react';
import { Users, Anchor, Activity, TrendingUp } from 'lucide-react';
import { mockExpectations } from '../engine/mockDatabase';

export const ExpectationsView: React.FC = () => {
  return (
    <div className="p-6 space-y-6 bg-slate-950 text-slate-100 min-h-screen">
      <div className="border-b border-slate-800 pb-3">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <Users className="w-5 h-5 text-purple-400" />
          通胀预期中心 (Inflation Expectations Center)
        </h2>
        <p className="text-xs text-slate-400 font-mono mt-0.5">
          调查型 (家庭、企业、专业预测者) 与 市场型 (通胀Swaps、Breakeven) 预期锚定监测 (Expectation Anchoring)
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-xl">
          <span className="text-xs text-slate-400 block font-mono">1年期通胀Swaps (Market)</span>
          <strong className="text-2xl font-bold font-mono text-purple-400">2.10%</strong>
          <span className="text-[10px] text-slate-500 block mt-1">市场高频隐含预期</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-xl">
          <span className="text-xs text-slate-400 block font-mono">1年期专业预测者均值 (SPF)</span>
          <strong className="text-2xl font-bold font-mono text-blue-400">2.15%</strong>
          <span className="text-[10px] text-slate-500 block mt-1">学术与金融机构经济学家</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-xl">
          <span className="text-xs text-slate-400 block font-mono">1年期家庭调查 (Household)</span>
          <strong className="text-2xl font-bold font-mono text-amber-400">2.65%</strong>
          <span className="text-[10px] text-slate-500 block mt-1">存在感知向上偏误 (Upward Bias)</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-xl">
          <span className="text-xs text-slate-400 block font-mono">10年期Breakeven (长期锚定)</span>
          <strong className="text-2xl font-bold font-mono text-emerald-400">1.99%</strong>
          <span className="text-[10px] text-emerald-400 block mt-1">✓ 稳固锚定于2.0%目标</span>
        </div>
      </div>

      <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 shadow-xl">
        <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono mb-3">
          多期限预期结构与分歧度 (Expectation Horizon Structure & Disagreement)
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="py-2.5">期限</th>
                <th className="py-2.5">家庭调查 (%)</th>
                <th className="py-2.5">企业调查 (%)</th>
                <th className="py-2.5">专业预测者 (%)</th>
                <th className="py-2.5">Swaps (%)</th>
                <th className="py-2.5">Breakeven (%)</th>
                <th className="py-2.5">分歧标准差 (Disagreement)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {mockExpectations.map((row, idx) => (
                <tr key={idx} className="hover:bg-slate-800/40">
                  <td className="py-2.5 font-bold text-white">{row.horizon}</td>
                  <td className="py-2.5 text-amber-400">{row.householdSurvey.toFixed(2)}%</td>
                  <td className="py-2.5 text-blue-300">{row.corporateSurvey.toFixed(2)}%</td>
                  <td className="py-2.5 text-blue-400 font-bold">{row.professionalForecasters.toFixed(2)}%</td>
                  <td className="py-2.5 text-purple-400 font-bold">{row.inflationSwaps.toFixed(2)}%</td>
                  <td className="py-2.5 text-emerald-400 font-bold">{row.breakevenInflation.toFixed(2)}%</td>
                  <td className="py-2.5 text-slate-400">{row.disagreementIndex.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
