import React, { useState } from 'react';
import { BookOpen, FileText, Plus, Share2, Sparkles, Download } from 'lucide-react';

interface ResearchNotebookViewProps {
  onOpenReportGenerator: () => void;
}

export const ResearchNotebookView: React.FC<ResearchNotebookViewProps> = ({
  onOpenReportGenerator,
}) => {
  const [notes, setNotes] = useState([
    {
      id: '1',
      title: '关于 2026M08 服务通胀粘性与工资-ULC传导路径的研判笔记',
      author: '高级宏观经济学家',
      date: '2026-09-16',
      content:
        '本月核心服务通胀为2.45%，主要由名义工资增速 (4.2%) 与单位劳动成本 (ULC 2.6%) 支撑。建议在下一期货币政策例会中提示服务通胀二次溢出风险。',
    },
    {
      id: '2',
      title: '关于输入原油冲击与二次通胀情景推演结论',
      author: '定量研究员',
      date: '2026-09-15',
      content:
        '若布伦特原油持续运行于 $85/桶 以上，模拟显示总体 CPI 将在 Q4 升至 2.45%，触及央行关注上限。应当关注1年期通胀Swaps脱锚风险。',
    },
  ]);

  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');

  const handleAddNote = () => {
    if (!newTitle.trim() || !newContent.trim()) return;
    setNotes([
      {
        id: Date.now().toString(),
        title: newTitle,
        author: '央行研究员',
        date: new Date().toISOString().slice(0, 10),
        content: newContent,
      },
      ...notes,
    ]);
    setNewTitle('');
    setNewContent('');
  };

  return (
    <div className="p-6 space-y-6 bg-slate-950 text-slate-100 min-h-screen">
      <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-amber-400" />
            宏观研究工作区与分析报告生成器 (Research Notebook & Report Generator)
          </h2>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            记录研究笔记、保存团队讨论与一键一键导出央行标准通胀报告
          </p>
        </div>

        <button
          onClick={onOpenReportGenerator}
          className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-lg flex items-center gap-2 shadow-lg"
        >
          <FileText className="w-4 h-4" />
          <span>生成完整央行通胀报告</span>
        </button>
      </div>

      {/* Note Creation Form */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl space-y-3 font-sans">
        <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
          新建研究备忘录 (Create Research Memorandum)
        </h3>

        <input
          type="text"
          value={newTitle}
          onChange={(e) => setNewTitle(e.target.value)}
          placeholder="输入笔记标题 (如: 2026Q4 核心通胀路径研判)..."
          className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
        />

        <textarea
          value={newContent}
          onChange={(e) => setNewContent(e.target.value)}
          placeholder="输入研判分析逻辑、模型参数与论证过程..."
          rows={3}
          className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
        />

        <div className="flex justify-end">
          <button
            onClick={handleAddNote}
            className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-semibold flex items-center gap-1"
          >
            <Plus className="w-4 h-4" />
            <span>添加研究笔记</span>
          </button>
        </div>
      </div>

      {/* Saved Notes List */}
      <div className="space-y-4">
        {notes.map((note) => (
          <div key={note.id} className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-lg space-y-2 font-sans">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h4 className="font-bold text-white text-sm">{note.title}</h4>
              <div className="text-xs text-slate-400 font-mono">
                <span>{note.author}</span> · <span>{note.date}</span>
              </div>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed font-mono whitespace-pre-wrap">
              {note.content}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};
