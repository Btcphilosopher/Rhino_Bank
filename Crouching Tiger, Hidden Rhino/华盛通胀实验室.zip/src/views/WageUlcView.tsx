import React from 'react';
import { DollarSign, TrendingUp, Cpu, Percent } from 'lucide-react';
import { mockWageUlcSeries } from '../engine/mockDatabase';

export const WageUlcView: React.FC = () => {
  return (
    <div className="p-6 space-y-6 bg-slate-950 text-slate-100 min-h-screen">
      <div className="border-b border-slate-800 pb-3">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <DollarSign className="w-5 h-5 text-emerald-400" />
          工资与单位劳动成本分析 (Wage & Unit Labor Cost Engine)
        </h2>
        <p className="text-xs text-slate-400 font-mono mt-0.5">
          单位劳动成本 (ULC = 名义工资增速 - 劳动生产率增速) 与服务通胀传导机制
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-xl">
          <span className="text-xs text-slate-400 block font-mono">名义工资增速 (Nominal Wage)</span>
          <strong className="text-2xl font-bold font-mono text-white">4.20%</strong>
          <span className="text-[10px] text-emerald-400 block mt-1">+0.10% 上行趋势</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-xl">
          <span className="text-xs text-slate-400 block font-mono">劳动生产率增速 (Productivity)</span>
          <strong className="text-2xl font-bold font-mono text-blue-400">1.60%</strong>
          <span className="text-[10px] text-slate-400 block mt-1">维持技术红利支撑</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-xl">
          <span className="text-xs text-slate-400 block font-mono">单位劳动成本 (ULC)</span>
          <strong className="text-2xl font-bold font-mono text-amber-400">2.60%</strong>
          <span className="text-[10px] text-slate-400 block mt-1">ULC = 4.2% - 1.6%</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-xl">
          <span className="text-xs text-slate-400 block font-mono">服务通胀传导弹性</span>
          <strong className="text-2xl font-bold font-mono text-rose-400">0.42</strong>
          <span className="text-[10px] text-slate-400 block mt-1">滞后2个季度充分体现</span>
        </div>
      </div>

      {/* Wage & ULC Time Series Table */}
      <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 shadow-xl">
        <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono mb-3">
          工资-生产率-ULC 季度数据序列 (Wage-Productivity-ULC Series)
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="py-2.5">参考季度</th>
                <th className="py-2.5">名义工资增速 (%)</th>
                <th className="py-2.5">实际工资增速 (%)</th>
                <th className="py-2.5">劳动生产率增速 (%)</th>
                <th className="py-2.5">单位劳动成本 (ULC %)</th>
                <th className="py-2.5">服务通胀 (%)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {mockWageUlcSeries.map((row, idx) => (
                <tr key={idx} className="hover:bg-slate-800/40">
                  <td className="py-2.5 font-bold text-white">{row.period}</td>
                  <td className="py-2.5 text-rose-400 font-bold">+{row.nominalWageGrowth.toFixed(2)}%</td>
                  <td className="py-2.5 text-emerald-400">+{row.realWageGrowth.toFixed(2)}%</td>
                  <td className="py-2.5 text-blue-300">+{row.productivityGrowth.toFixed(2)}%</td>
                  <td className="py-2.5 text-amber-400 font-bold">+{row.unitLaborCostGrowth.toFixed(2)}%</td>
                  <td className="py-2.5 text-purple-400 font-bold">+{row.servicesInflation.toFixed(2)}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
