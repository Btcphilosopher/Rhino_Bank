import React from 'react';
import {
  TrendingUp,
  TrendingDown,
  Activity,
  AlertTriangle,
  ArrowUpRight,
  ArrowDownRight,
  HelpCircle,
  BarChart3,
  Calendar,
  Layers,
  Sparkles
} from 'lucide-react';
import { CpiMetric } from '../types/inflation';
import { FanChart } from '../components/FanChart';
import { PressureRadarChart } from '../components/PressureRadarChart';

interface ExecutiveDashboardViewProps {
  metrics: CpiMetric[];
  onOpenLineage: (metricName: string) => void;
  onOpenAIAssistant: () => void;
}

export const ExecutiveDashboardView: React.FC<ExecutiveDashboardViewProps> = ({
  metrics,
  onOpenLineage,
  onOpenAIAssistant,
}) => {
  return (
    <div className="p-6 space-y-6 bg-slate-950 text-slate-100 min-h-screen">
      {/* 30-Second Central Bank Executive Q&A Bar */}
      <div className="bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 border border-blue-900/60 rounded-xl p-4 shadow-xl">
        <div className="flex items-center justify-between mb-3 border-b border-slate-800/80 pb-2">
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-blue-400" />
            <h2 className="text-sm font-bold text-white tracking-wide">
              中央银行30秒通胀研判摘要 (Central Bank 30-Sec Inflation Brief)
            </h2>
          </div>
          <span className="text-xs text-slate-400 font-mono">基准数据Vintage: 2026M08</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-3 text-xs">
          <div className="p-2.5 bg-slate-900/80 rounded-lg border border-slate-800">
            <span className="text-slate-400 block text-[11px]">总体通胀状态</span>
            <strong className="text-emerald-400 text-sm font-mono font-bold">2.15% (同比增长)</strong>
            <p className="text-[10px] text-slate-400 mt-0.5">接近2.0%目标，处于58%分位数</p>
          </div>

          <div className="p-2.5 bg-slate-900/80 rounded-lg border border-slate-800">
            <span className="text-slate-400 block text-[11px]">主要推动力</span>
            <strong className="text-amber-400 text-sm font-bold">服务通胀 + 食品价格</strong>
            <p className="text-[10px] text-slate-400 mt-0.5">服务(2.45%), 食品(2.80%)</p>
          </div>

          <div className="p-2.5 bg-slate-900/80 rounded-lg border border-slate-800">
            <span className="text-slate-400 block text-[11px]">工资与ULC粘性</span>
            <strong className="text-blue-400 text-sm font-mono font-bold">4.20% (ULC 2.60%)</strong>
            <p className="text-[10px] text-slate-400 mt-0.5">对核心服务构成次级传导</p>
          </div>

          <div className="p-2.5 bg-slate-900/80 rounded-lg border border-slate-800">
            <span className="text-slate-400 block text-[11px]">实时 Nowcast (2026M09)</span>
            <strong className="text-amber-400 text-sm font-mono font-bold">2.15% (±0.04)</strong>
            <p className="text-[10px] text-slate-400 mt-0.5">高频大宗与运价微幅上修</p>
          </div>

          <div className="p-2.5 bg-slate-900/80 rounded-lg border border-slate-800">
            <span className="text-slate-400 block text-[11px]">模型离散度 (Disagreement)</span>
            <strong className="text-purple-400 text-sm font-mono font-bold">0.17 个百分点</strong>
            <p className="text-[10px] text-slate-400 mt-0.5">DFM (2.12%) vs ML (2.22%)</p>
          </div>
        </div>
      </div>

      {/* Top Core Metrics Grid - High Density Central Bank Cards */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono">
            核心通胀监测指标卡 (10 Core Inflation Indicators)
          </h3>
          <span className="text-[11px] text-slate-500 font-mono">点击任意指标可追溯宏观数据血缘 (Data Lineage)</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
          {metrics.map((m) => {
            const isUp = m.currentVal > m.prevVal;
            return (
              <div
                key={m.id}
                onClick={() => onOpenLineage(m.name)}
                className="bg-slate-900 border border-slate-800 hover:border-blue-700/60 rounded-xl p-3.5 shadow-lg transition-all cursor-pointer group hover:bg-slate-900/90"
              >
                <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                  <span className="font-semibold text-slate-300 group-hover:text-blue-300 transition-colors">
                    {m.name}
                  </span>
                  <span className="text-[10px] font-mono text-slate-500">P{m.histPercentile}</span>
                </div>

                <div className="flex items-baseline gap-2 my-1">
                  <span className="text-xl font-bold font-mono text-white tracking-tight">
                    {m.currentVal.toFixed(2)}{m.unit}
                  </span>
                  <span className={`text-xs font-mono font-semibold flex items-center ${isUp ? 'text-rose-400' : 'text-emerald-400'}`}>
                    {isUp ? <ArrowUpRight className="w-3.5 h-3.5" /> : <ArrowDownRight className="w-3.5 h-3.5" />}
                    {isUp ? '+' : ''}{(m.currentVal - m.prevVal).toFixed(2)}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-1 pt-2 border-t border-slate-800/80 text-[10px] text-slate-400 font-mono">
                  <div>
                    <span className="text-slate-500 block">3M年化</span>
                    <span className="text-slate-200 font-medium">{m.change3m.toFixed(2)}%</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">6M年化</span>
                    <span className="text-slate-200 font-medium">{m.change6m.toFixed(2)}%</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">10Y均值</span>
                    <span className="text-slate-200 font-medium">{m.histMean.toFixed(2)}%</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Main Charts Row: Fan Chart & Inflation Pressure Radar */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <FanChart />
        </div>

        <div>
          <PressureRadarChart />
        </div>
      </div>

      {/* Forecast Revisions & Data Surprise Tracker */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Forecast Revision Monitor */}
        <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 shadow-xl">
          <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono flex items-center gap-2">
              <Layers className="w-4 h-4 text-blue-400" />
              预测修订追踪器 (Forecast Revision Monitor)
            </h3>
            <span className="text-[10px] text-slate-400 font-mono">旧预测 vs 新预测变动分解</span>
          </div>

          <div className="space-y-2.5 text-xs">
            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-slate-400 block font-mono text-[11px]">8月上旬 Nowcast 估值</span>
                <span className="text-slate-200 font-bold font-mono text-sm">2.05%</span>
              </div>
              <div className="text-right">
                <span className="text-slate-400 block font-mono text-[11px]">最新 Nowcast 估值 (2026M09)</span>
                <span className="text-amber-400 font-bold font-mono text-sm">2.15% (+0.10%)</span>
              </div>
            </div>

            <div className="text-slate-300 space-y-1.5 pt-1 text-[11px]">
              <div className="flex items-center justify-between p-2 bg-slate-800/60 rounded">
                <span>• 农产品批发价格超预期上涨 (+1.5%)</span>
                <span className="text-amber-400 font-mono">+0.06 个百分点</span>
              </div>
              <div className="flex items-center justify-between p-2 bg-slate-800/60 rounded">
                <span>• 原油现货即期价格小幅反弹 (Brent $78.4)</span>
                <span className="text-rose-400 font-mono">+0.05 个百分点</span>
              </div>
              <div className="flex items-center justify-between p-2 bg-slate-800/60 rounded">
                <span>• 汇率升值微幅对冲 (CNY/USD 7.18)</span>
                <span className="text-emerald-400 font-mono">-0.01 个百分点</span>
              </div>
            </div>
          </div>
        </div>

        {/* Data Release Surprise Table */}
        <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 shadow-xl">
          <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono flex items-center gap-2">
              <Calendar className="w-4 h-4 text-amber-400" />
              高频数据意外监测 (Data Surprise Tracker)
            </h3>
            <span className="text-[10px] text-slate-400 font-mono">实际值 vs 市场共识</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs font-mono">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                  <th className="py-2">指标名称</th>
                  <th className="py-2">实际值</th>
                  <th className="py-2">市场预期</th>
                  <th className="py-2">数据意外</th>
                  <th className="py-2">Nowcast影响</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                <tr>
                  <td className="py-2 font-sans font-semibold text-white">布伦特原油现货价</td>
                  <td className="py-2">$78.4</td>
                  <td className="py-2">$77.0</td>
                  <td className="py-2 text-rose-400 font-bold">+1.6</td>
                  <td className="py-2 text-rose-400">+0.05%</td>
                </tr>
                <tr>
                  <td className="py-2 font-sans font-semibold text-white">农产品200指数</td>
                  <td className="py-2">124.5</td>
                  <td className="py-2">123.0</td>
                  <td className="py-2 text-amber-400 font-bold">+1.5</td>
                  <td className="py-2 text-amber-400">+0.06%</td>
                </tr>
                <tr>
                  <td className="py-2 font-sans font-semibold text-white">CNY/USD即期汇率</td>
                  <td className="py-2">7.18</td>
                  <td className="py-2">7.21</td>
                  <td className="py-2 text-emerald-400 font-bold">-0.03</td>
                  <td className="py-2 text-emerald-400">-0.01%</td>
                </tr>
                <tr>
                  <td className="py-2 font-sans font-semibold text-white">公路货运指数</td>
                  <td className="py-2">104.8</td>
                  <td className="py-2">104.0</td>
                  <td className="py-2 text-blue-400">+0.8</td>
                  <td className="py-2 text-blue-400">+0.02%</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
