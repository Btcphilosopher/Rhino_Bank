import React from 'react';
import { Cpu, Sparkles, BarChart3, Layers } from 'lucide-react';
import ReactECharts from 'echarts-for-react';
import { mockMlFeatureImportances } from '../engine/mockDatabase';

export const MlLabView: React.FC = () => {
  const option = {
    backgroundColor: '#0f172a',
    title: {
      text: 'LightGBM / XGBoost 特征重要性与 SHAP 归因 (SHAP Feature Importance)',
      textStyle: { color: '#f8fafc', fontSize: 13, fontWeight: 'bold' },
      left: 15,
      top: 10,
    },
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
    grid: { left: '3%', right: '4%', bottom: '10%', top: '20%', containLabel: true },
    xAxis: {
      type: 'value',
      name: 'SHAP Value / Importance Score',
      nameTextStyle: { color: '#94a3b8', fontSize: 11 },
      splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
    },
    yAxis: {
      type: 'category',
      data: mockMlFeatureImportances.map((f) => f.featureName).reverse(),
      axisLabel: { color: '#94a3b8', fontSize: 11 },
    },
    series: [
      {
        name: '特征重要性得分',
        type: 'bar',
        data: mockMlFeatureImportances.map((f) => f.importanceScore).reverse(),
        itemStyle: { color: '#38bdf8', borderRadius: [0, 4, 4, 0] },
      },
    ],
  };

  return (
    <div className="p-6 space-y-6 bg-slate-950 text-slate-100 min-h-screen">
      <div className="border-b border-slate-800 pb-3">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-blue-400" />
          机器学习与人工智能 Lab (ML & AI Macro Intelligence Lab)
        </h2>
        <p className="text-xs text-slate-400 font-mono mt-0.5">
          LightGBM, XGBoost, Random Forest, Neural Networks, SHAP 特征解说与样本外预测验证
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-xl">
          <span className="text-xs text-slate-400 block font-mono">最佳 ML 模型</span>
          <strong className="text-xl font-bold font-mono text-blue-400">LightGBM v3.4</strong>
          <span className="text-[10px] text-slate-500 block mt-1">12M RMSE: 0.13%</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-xl">
          <span className="text-xs text-slate-400 block font-mono">首要归因特征</span>
          <strong className="text-xl font-bold font-mono text-amber-400">服务通胀 (Services CPI)</strong>
          <span className="text-[10px] text-slate-500 block mt-1">SHAP贡献: 28.5%</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-xl">
          <span className="text-xs text-slate-400 block font-mono">高频大宗贡献</span>
          <strong className="text-xl font-bold font-mono text-rose-400">布伦特原油现货价</strong>
          <span className="text-[10px] text-slate-500 block mt-1">SHAP贡献: 21.0%</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-xl">
          <span className="text-xs text-slate-400 block font-mono">样本外 Cross-Validation</span>
          <strong className="text-xl font-bold font-mono text-emerald-400">5-Fold TimeSeriesSplit</strong>
          <span className="text-[10px] text-emerald-400 block mt-1">无未来数据泄漏</span>
        </div>
      </div>

      <div className="bg-slate-900 rounded-xl border border-slate-800 p-2 shadow-2xl">
        <ReactECharts option={option} style={{ height: '380px', width: '100%' }} />
      </div>
    </div>
  );
};
