import React, { useState } from 'react';
import { LineChart, Sliders, Activity, RefreshCw } from 'lucide-react';
import ReactECharts from 'echarts-for-react';
import { generatePhillipsCurvePoints, NKPCParams, NonLinearRegimeParams } from '../engine/phillipsCurve';

export const PhillipsCurveView: React.FC = () => {
  const [modelType, setModelType] = useState<'linear' | 'hybrid' | 'nonlinear'>('hybrid');

  const [nkpcParams, setNkpcParams] = useState<NKPCParams>({
    alphaLag: 0.40,
    betaExp: 0.55,
    kappaSlope: 0.18,
    shockStd: 0.10,
  });

  const [regimeParams, setRegimeParams] = useState<NonLinearRegimeParams>({
    lowThreshold: -1.0,
    highThreshold: 1.0,
    normalSlope: 0.15,
    lowSlope: 0.08,
    highSlope: 0.32,
  });

  const { dataPoints, fittedCurve } = generatePhillipsCurvePoints(modelType, nkpcParams, regimeParams);

  const option = {
    backgroundColor: '#0f172a',
    title: {
      text: `菲利普斯曲线拟合图 (${modelType === 'hybrid' ? 'Hybrid NKPC 混合新凯恩斯' : modelType === 'nonlinear' ? '非线性体制转换 (Threshold Regime-Switching)' : '传统线性'})`,
      textStyle: { color: '#f8fafc', fontSize: 13, fontWeight: 'bold' },
      left: 15,
      top: 10,
    },
    tooltip: {
      trigger: 'item',
      backgroundColor: '#1e293b',
      borderColor: '#475569',
      textStyle: { color: '#f8fafc', fontSize: 12 },
    },
    grid: { left: '4%', right: '4%', bottom: '12%', top: '20%', containLabel: true },
    xAxis: {
      type: 'value',
      name: '产出缺口 / 就业缺口 (%)',
      nameTextStyle: { color: '#94a3b8', fontSize: 11 },
      splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
      axisLabel: { color: '#94a3b8', formatter: '{value}%' },
    },
    yAxis: {
      type: 'value',
      name: '通胀率 (%)',
      nameTextStyle: { color: '#94a3b8', fontSize: 11 },
      min: 1.0,
      max: 3.2,
      splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
      axisLabel: { color: '#94a3b8', formatter: '{value}%' },
    },
    series: [
      {
        name: '历史散点 (Quarterly Observations)',
        type: 'scatter',
        symbolSize: 10,
        data: dataPoints.map((p) => [p.x, p.y]),
        itemStyle: { color: '#38bdf8' },
      },
      {
        name: '拟合菲利普斯曲线',
        type: 'line',
        data: fittedCurve.map((p) => [p.x, p.y]),
        smooth: true,
        lineStyle: { color: '#f43f5e', width: 3 },
        showSymbol: false,
      },
    ],
  };

  return (
    <div className="p-6 space-y-6 bg-slate-950 text-slate-100 min-h-screen">
      <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <LineChart className="w-5 h-5 text-rose-400" />
            菲利普斯曲线实验室 (Phillips Curve Laboratory)
          </h2>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            π_t = α π_(t-1) + β E_t[π_(t+1)] + κ x_t + u_t · 非线性机制与参数估算校准
          </p>
        </div>

        <div className="flex gap-2">
          {(['hybrid', 'nonlinear', 'linear'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setModelType(t)}
              className={`px-3 py-1.5 rounded text-xs font-semibold font-mono border transition-all ${
                modelType === t
                  ? 'bg-rose-600 text-white border-rose-400 shadow'
                  : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white'
              }`}
            >
              {t === 'hybrid' ? 'Hybrid NKPC' : t === 'nonlinear' ? '非线性Regime-Switching' : '传统线性'}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <div className="bg-slate-900 rounded-xl border border-slate-800 p-2 shadow-2xl">
            <ReactECharts option={option} style={{ height: '420px', width: '100%' }} />
          </div>
        </div>

        {/* Parameter Controls */}
        <div className="bg-slate-900 rounded-xl border border-slate-800 p-5 shadow-xl space-y-4 text-xs font-mono">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider border-b border-slate-800 pb-2">
            NKPC 参数估算与校准面板
          </h3>

          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>α (滞后惯性权重):</span>
                <span className="text-rose-400 font-bold">{nkpcParams.alphaLag.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="0.10"
                max="0.80"
                step="0.05"
                value={nkpcParams.alphaLag}
                onChange={(e) => setNkpcParams({ ...nkpcParams, alphaLag: Number(e.target.value) })}
                className="w-full h-1.5 bg-slate-800 rounded appearance-none cursor-pointer accent-rose-500"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>β (前瞻预期权重):</span>
                <span className="text-blue-400 font-bold">{nkpcParams.betaExp.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="0.20"
                max="0.90"
                step="0.05"
                value={nkpcParams.betaExp}
                onChange={(e) => setNkpcParams({ ...nkpcParams, betaExp: Number(e.target.value) })}
                className="w-full h-1.5 bg-slate-800 rounded appearance-none cursor-pointer accent-blue-500"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>κ (产出缺口斜率):</span>
                <span className="text-amber-400 font-bold">{nkpcParams.kappaSlope.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="0.05"
                max="0.50"
                step="0.02"
                value={nkpcParams.kappaSlope}
                onChange={(e) => setNkpcParams({ ...nkpcParams, kappaSlope: Number(e.target.value) })}
                className="w-full h-1.5 bg-slate-800 rounded appearance-none cursor-pointer accent-amber-500"
              />
            </div>
          </div>

          <div className="p-3 bg-slate-950 rounded border border-slate-800 text-[11px] text-slate-300">
            <strong>公式:</strong> π_t = {nkpcParams.alphaLag.toFixed(2)}π_(t-1) + {nkpcParams.betaExp.toFixed(2)}E_t[π_(t+1)] + {nkpcParams.kappaSlope.toFixed(2)}x_t + u_t
          </div>
        </div>
      </div>
    </div>
  );
};
