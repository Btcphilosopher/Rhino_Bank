import React, { useState } from 'react';
import { Target, Sliders, Layers, Bookmark } from 'lucide-react';
import { mockTrimmedMeans } from '../engine/mockDatabase';

export const CoreInflationView: React.FC = () => {
  const [trimPct, setTrimPct] = useState(10);
  const [excludedIds, setExcludedIds] = useState<string[]>(['food', 'energy']);

  const availableExclusions = [
    { id: 'food', name: '剔除食品' },
    { id: 'energy', name: '剔除能源' },
    { id: 'used_cars', name: '剔除二手车与耐用品' },
    { id: 'housing', name: '剔除住房租金' },
  ];

  const toggleExclusion = (id: string) => {
    setExcludedIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  return (
    <div className="p-6 space-y-6 bg-slate-950 text-slate-100 min-h-screen">
      <div className="border-b border-slate-800 pb-3">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <Target className="w-5 h-5 text-blue-400" />
          核心通胀分析器 (Core Inflation & Trimmed Mean Engine)
        </h2>
        <p className="text-xs text-slate-400 font-mono mt-0.5">
          截尾均值 (Trimmed Mean)、加权中位数 (Weighted Median) 与自定义剔除指标构建
        </p>
      </div>

      {/* Comparison Cards Row */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-xl">
          <span className="text-xs text-slate-400 block font-mono">总体CPI (Headline)</span>
          <strong className="text-2xl font-bold font-mono text-white">2.15%</strong>
          <span className="text-[10px] text-slate-500 block mt-1">包含所有篮子细项</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-xl">
          <span className="text-xs text-slate-400 block font-mono">传统核心CPI (Ex-Food/Energy)</span>
          <strong className="text-2xl font-bold font-mono text-blue-400">1.85%</strong>
          <span className="text-[10px] text-slate-500 block mt-1">剔除食品 (18.5%) & 能源 (8.5%)</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-xl">
          <span className="text-xs text-slate-400 block font-mono">10% 加权截尾均值 (Trimmed Mean)</span>
          <strong className="text-2xl font-bold font-mono text-amber-400">1.94%</strong>
          <span className="text-[10px] text-slate-500 block mt-1">剔除两端各10% 极端价格变动</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-xl">
          <span className="text-xs text-slate-400 block font-mono">加权中位数通胀 (Weighted Median)</span>
          <strong className="text-2xl font-bold font-mono text-purple-400">1.88%</strong>
          <span className="text-[10px] text-slate-500 block mt-1">权重分布中位数项目</span>
        </div>
      </div>

      {/* Interactive Trimmed Mean Slider */}
      <div className="bg-slate-900 rounded-xl border border-slate-800 p-5 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono flex items-center gap-2">
            <Sliders className="w-4 h-4 text-blue-400" />
            截尾均值参数校准 (Trimmed Mean Calculator)
          </h3>
          <span className="text-xs font-mono text-blue-300">当前截尾比例: <strong>{trimPct}%</strong></span>
        </div>

        <div className="space-y-2">
          <input
            type="range"
            min="2"
            max="25"
            step="1"
            value={trimPct}
            onChange={(e) => setTrimPct(Number(e.target.value))}
            className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
          />
          <div className="flex justify-between text-[11px] font-mono text-slate-400">
            <span>2% (轻微截尾)</span>
            <span>10% (标准央行截尾)</span>
            <span>25% (强截尾)</span>
          </div>
        </div>

        <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-between text-xs font-mono">
          <div>
            <span className="text-slate-400">当前设定 ({trimPct}% Trimmed Mean): </span>
            <strong className="text-amber-400 font-bold text-sm">{(1.85 + (15 - trimPct) * 0.012).toFixed(2)}%</strong>
          </div>
          <div className="text-slate-400">
            与总体CPI偏离: <span className="text-rose-400 font-bold">-{(0.30 - (15 - trimPct) * 0.012).toFixed(2)}%</span>
          </div>
        </div>
      </div>

      {/* Custom Exclusions Builder */}
      <div className="bg-slate-900 rounded-xl border border-slate-800 p-5 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono flex items-center gap-2">
            <Bookmark className="w-4 h-4 text-purple-400" />
            自定义核心通胀指标构建器 (Custom Core Inflation Indicator Builder)
          </h3>
          <button className="px-3 py-1 bg-purple-600 hover:bg-purple-500 text-white rounded text-xs font-semibold shadow">
            保存该指标版本 (v1.2)
          </button>
        </div>

        <div className="flex flex-wrap gap-2">
          {availableExclusions.map((item) => {
            const active = excludedIds.includes(item.id);
            return (
              <button
                key={item.id}
                onClick={() => toggleExclusion(item.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                  active
                    ? 'bg-purple-900/60 border-purple-500 text-purple-200 font-semibold'
                    : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white'
                }`}
              >
                {active ? '✓ ' : '+ '} {item.name}
              </button>
            );
          })}
        </div>

        <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 text-xs font-mono flex items-center justify-between">
          <span>自定义核心CPI估算 (已剔除 {excludedIds.length} 项):</span>
          <span className="text-emerald-400 font-bold text-base">
            {(2.15 - excludedIds.length * 0.15).toFixed(2)}%
          </span>
        </div>
      </div>
    </div>
  );
};
