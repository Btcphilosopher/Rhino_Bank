import React from 'react';
import { Cpu, Layers, BarChart2 } from 'lucide-react';
import { FanChart } from '../components/FanChart';
import { mockModelForecasts } from '../engine/mockDatabase';

export const ModelSuiteView: React.FC = () => {
  return (
    <div className="p-6 space-y-6 bg-slate-950 text-slate-100 min-h-screen">
      <div className="border-b border-slate-800 pb-3">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <Cpu className="w-5 h-5 text-blue-400" />
          通胀模型集合与预测 Fan Chart (Model Suite & Ensemble)
        </h2>
        <p className="text-xs text-slate-400 font-mono mt-0.5">
          ARIMA, VAR, BVAR, Dynamic Factor, Hybrid NKPC, DSGE, ML 多模型预测与置信区间离散度
        </p>
      </div>

      <FanChart />

      <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 shadow-xl">
        <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono mb-3">
          模型委员会预测差异与误差矩阵 (Model Ensemble Matrix)
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="py-2.5">模型名称</th>
                <th className="py-2.5">模型类型</th>
                <th className="py-2.5">2026Q4 点预测</th>
                <th className="py-2.5">50% 置信区间</th>
                <th className="py-2.5">90% 置信区间</th>
                <th className="py-2.5">12M MAE</th>
                <th className="py-2.5">12M RMSE</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {mockModelForecasts.map((m) => (
                <tr key={m.modelId} className="hover:bg-slate-800/40">
                  <td className="py-2.5 font-sans font-semibold text-white">{m.modelName}</td>
                  <td className="py-2.5 text-blue-300">{m.modelType}</td>
                  <td className="py-2.5 text-amber-400 font-bold">{m.pointForecast.toFixed(2)}%</td>
                  <td className="py-2.5 text-slate-300">[{m.ci50Lower.toFixed(2)}%, {m.ci50Upper.toFixed(2)}%]</td>
                  <td className="py-2.5 text-slate-400">[{m.ci90Lower.toFixed(2)}%, {m.ci90Upper.toFixed(2)}%]</td>
                  <td className="py-2.5 text-emerald-400">{m.mae12m.toFixed(2)}%</td>
                  <td className="py-2.5 text-emerald-400">{m.rmse12m.toFixed(2)}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
