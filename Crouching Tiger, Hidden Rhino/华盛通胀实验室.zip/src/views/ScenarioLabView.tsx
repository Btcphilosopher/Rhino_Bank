import React, { useState } from 'react';
import { Sliders, Play, Sparkles, RefreshCw, AlertTriangle, Layers } from 'lucide-react';
import { runScenarioSimulation } from '../engine/scenariosEngine';
import { mockScenarioPresets } from '../engine/mockDatabase';

export const ScenarioLabView: React.FC = () => {
  const [selectedPresetId, setSelectedPresetId] = useState<string>('energy_shock');

  const [energyPricePct, setEnergyPricePct] = useState(25);
  const [foodPricePct, setFoodPricePct] = useState(10);
  const [fxDepreciationPct, setFxDepreciationPct] = useState(5);
  const [wageGrowthPct, setWageGrowthPct] = useState(0);

  const applyPreset = (presetId: string) => {
    setSelectedPresetId(presetId);
    const preset = mockScenarioPresets.find((p) => p.id === presetId);
    if (preset) {
      setEnergyPricePct(preset.parameters.energyPricePct || 0);
      setFoodPricePct(preset.parameters.foodPricePct || 0);
      setFxDepreciationPct(preset.parameters.fxDepreciationPct || 0);
      setWageGrowthPct(preset.parameters.wageGrowthPct || 0);
    }
  };

  const simResult = runScenarioSimulation({
    energyPricePct,
    foodPricePct,
    fxDepreciationPct,
    wageGrowthPct,
    productivityGrowthPct: 0,
    unemploymentGap: 0,
    outputGap: 0,
    globalDemandPct: 0,
    importPricePct: 0,
    inflationExpectationsPct: 0,
    policyRateBp: 0,
  });

  return (
    <div className="p-6 space-y-6 bg-slate-950 text-slate-100 min-h-screen">
      <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Sliders className="w-5 h-5 text-purple-400" />
            情景模拟与压力测试实验室 (Scenario Simulation & Stress Testing Engine)
          </h2>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            10 大预设央行情景 (中东局势、地缘冲突、工资-物价螺旋、汇率贬值等) + 多维参数组合仿真
          </p>
        </div>

        <button className="px-3.5 py-1.5 bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 shadow">
          <Play className="w-3.5 h-3.5 fill-current" />
          <span>运行全路径情景推演</span>
        </button>
      </div>

      {/* 10 Preset Scenarios Bar */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-xl space-y-3">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono">
          预设央行压力情景 (10 Pre-set Macro Scenarios)
        </h3>
        <div className="flex flex-wrap gap-2">
          {mockScenarioPresets.map((preset) => {
            const active = selectedPresetId === preset.id;
            return (
              <button
                key={preset.id}
                onClick={() => applyPreset(preset.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                  active
                    ? 'bg-purple-600 text-white border-purple-400 font-bold shadow'
                    : 'bg-slate-800 border-slate-700 text-slate-300 hover:text-white'
                }`}
              >
                {preset.name}
              </button>
            );
          })}
        </div>
      </div>

      {/* Parameter Sliders Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-xl space-y-2 font-mono text-xs">
          <div className="flex justify-between text-slate-300">
            <span>能源价格冲击 (%)</span>
            <strong className="text-amber-400 font-bold">+{energyPricePct}%</strong>
          </div>
          <input
            type="range"
            min="-20"
            max="100"
            value={energyPricePct}
            onChange={(e) => setEnergyPricePct(Number(e.target.value))}
            className="w-full h-1.5 bg-slate-800 rounded appearance-none cursor-pointer accent-amber-500"
          />
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-xl space-y-2 font-mono text-xs">
          <div className="flex justify-between text-slate-300">
            <span>食品价格冲击 (%)</span>
            <strong className="text-rose-400 font-bold">+{foodPricePct}%</strong>
          </div>
          <input
            type="range"
            min="-10"
            max="50"
            value={foodPricePct}
            onChange={(e) => setFoodPricePct(Number(e.target.value))}
            className="w-full h-1.5 bg-slate-800 rounded appearance-none cursor-pointer accent-rose-500"
          />
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-xl space-y-2 font-mono text-xs">
          <div className="flex justify-between text-slate-300">
            <span>汇率贬值冲击 (%)</span>
            <strong className="text-indigo-400 font-bold">+{fxDepreciationPct}%</strong>
          </div>
          <input
            type="range"
            min="-10"
            max="30"
            value={fxDepreciationPct}
            onChange={(e) => setFxDepreciationPct(Number(e.target.value))}
            className="w-full h-1.5 bg-slate-800 rounded appearance-none cursor-pointer accent-indigo-500"
          />
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-xl space-y-2 font-mono text-xs">
          <div className="flex justify-between text-slate-300">
            <span>名义工资加速 (%)</span>
            <strong className="text-blue-400 font-bold">+{wageGrowthPct}%</strong>
          </div>
          <input
            type="range"
            min="0"
            max="10"
            value={wageGrowthPct}
            onChange={(e) => setWageGrowthPct(Number(e.target.value))}
            className="w-full h-1.5 bg-slate-800 rounded appearance-none cursor-pointer accent-blue-500"
          />
        </div>
      </div>

      {/* Simulation Output Cards */}
      <div className="bg-slate-900 rounded-xl border border-slate-800 p-5 shadow-2xl space-y-4">
        <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono border-b border-slate-800 pb-2">
          情景仿真结果输出 (Simulation Output Summary)
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-slate-950 p-4 rounded-lg border border-slate-800">
            <span className="text-slate-400 text-[11px] block font-mono">总体CPI模拟终值</span>
            <strong className="text-2xl font-bold font-mono text-rose-400">
              +{simResult.headlineCpi.toFixed(2)}%
            </strong>
          </div>

          <div className="bg-slate-950 p-4 rounded-lg border border-slate-800">
            <span className="text-slate-400 text-[11px] block font-mono">核心CPI模拟终值</span>
            <strong className="text-2xl font-bold font-mono text-blue-400">
              +{simResult.coreCpi.toFixed(2)}%
            </strong>
          </div>

          <div className="bg-slate-950 p-4 rounded-lg border border-slate-800">
            <span className="text-slate-400 text-[11px] block font-mono">1年期通胀预期响应</span>
            <strong className="text-2xl font-bold font-mono text-purple-400">
              +{simResult.expectationImpact.toFixed(2)}%
            </strong>
          </div>

          <div className="bg-slate-950 p-4 rounded-lg border border-slate-800">
            <span className="text-slate-400 text-[11px] block font-mono">央行目标偏离 (target=2.0%)</span>
            <strong className="text-2xl font-bold font-mono text-amber-400">
              +{(simResult.headlineCpi - 2.0).toFixed(2)}%
            </strong>
          </div>
        </div>
      </div>
    </div>
  );
};
