import React from 'react';
import { Database, ShieldCheck, CheckCircle2, AlertCircle } from 'lucide-react';

interface DataQualityLineageViewProps {
  onOpenLineage: (metricName: string) => void;
}

export const DataQualityLineageView: React.FC<DataQualityLineageViewProps> = ({ onOpenLineage }) => {
  return (
    <div className="p-6 space-y-6 bg-slate-950 text-slate-100 min-h-screen">
      <div className="border-b border-slate-800 pb-3">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <Database className="w-5 h-5 text-emerald-400" />
          数据质量审计与全链条血缘追溯 (Data Quality & Lineage Center)
        </h2>
        <p className="text-xs text-slate-400 font-mono mt-0.5">
          异常值清洗 (3-Sigma/MAD Filter)、Revision 修正审计轨迹与数据源 100% 溯源
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 font-mono text-xs">
        <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-2 shadow-xl">
          <div className="flex items-center gap-2 text-emerald-400 font-bold">
            <ShieldCheck className="w-4 h-4" />
            数据完整性检查 (Integrity)
          </div>
          <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-1">
            <div>缺失值比例: <strong className="text-emerald-400">0.00% (已补全)</strong></div>
            <div>数据源覆盖: <strong className="text-blue-300">500+ 价格点采样</strong></div>
            <div>更新延迟: <strong className="text-emerald-400">实时 (&lt; 100ms)</strong></div>
          </div>
        </div>

        <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-2 shadow-xl">
          <div className="flex items-center gap-2 text-blue-400 font-bold">
            <CheckCircle2 className="w-4 h-4" />
            异常值与极端波动检测 (MAD Filter)
          </div>
          <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-1">
            <div>检测到异常跳变: <strong className="text-amber-400">2 项 (鲜菜、液化气)</strong></div>
            <div>处理策略: <strong className="text-blue-300">自动中位数温和平滑</strong></div>
            <div>标准: <strong className="text-slate-400">MAD &gt; 3.5</strong></div>
          </div>
        </div>

        <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-2 shadow-xl">
          <div className="flex items-center gap-2 text-purple-400 font-bold">
            <Database className="w-4 h-4" />
            快速数据血缘追溯
          </div>
          <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-2">
            <p className="text-slate-300 text-[11px]">点击下方按钮测试总体CPI数据链条：</p>
            <button
              onClick={() => onOpenLineage('总体CPI (Headline CPI)')}
              className="w-full py-2 bg-blue-600 hover:bg-blue-500 text-white rounded font-semibold text-xs transition-colors"
            >
              打开数据血缘追溯树 (Data Lineage)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
