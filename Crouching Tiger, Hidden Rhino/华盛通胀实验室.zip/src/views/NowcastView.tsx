import React from 'react';
import { Radio, RefreshCw, Calendar, Zap, Activity } from 'lucide-react';
import { mockNowcastIndicators, mockNowcastVintages } from '../engine/mockDatabase';

export const NowcastView: React.FC = () => {
  return (
    <div className="p-6 space-y-6 bg-slate-950 text-slate-100 min-h-screen">
      <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Radio className="w-5 h-5 text-amber-400" />
            通胀 Nowcasting 实时监测中心 (Mixed-Frequency Nowcasting Engine)
          </h2>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            日频/周频/月频混频数据流 (Bridge Model, MIDAS, Dynamic Factor Model, Bayesian VAR)
          </p>
        </div>

        <button className="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-lg flex items-center gap-1.5 shadow">
          <RefreshCw className="w-3.5 h-3.5" />
          <span>触发混频 Nowcast 模型重算</span>
        </button>
      </div>

      {/* Model Ensemble Comparison Row */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-xl">
          <span className="text-xs text-slate-400 block font-mono">动态因子模型 (DFM)</span>
          <strong className="text-2xl font-bold font-mono text-amber-400">2.15%</strong>
          <span className="text-[10px] text-slate-500 block mt-1">主导模型权重 40%</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-xl">
          <span className="text-xs text-slate-400 block font-mono">MIDAS 混频混频模型</span>
          <strong className="text-2xl font-bold font-mono text-blue-400">2.18%</strong>
          <span className="text-[10px] text-slate-500 block mt-1">高频原油与运价抓取</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-xl">
          <span className="text-xs text-slate-400 block font-mono">Bridge Model (桥梁模型)</span>
          <strong className="text-2xl font-bold font-mono text-emerald-400">2.12%</strong>
          <span className="text-[10px] text-slate-500 block mt-1">基准回归加权</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-xl">
          <span className="text-xs text-slate-400 block font-mono">Bayesian VAR (BVAR)</span>
          <strong className="text-2xl font-bold font-mono text-purple-400">2.14%</strong>
          <span className="text-[10px] text-slate-500 block mt-1">宏观先验概率估计</span>
        </div>
      </div>

      {/* High-frequency Indicator Stream Table */}
      <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 shadow-xl">
        <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono mb-3">
          实时高频数据发布流 (High-Frequency Indicator Stream)
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="py-2.5">指标名称</th>
                <th className="py-2.5">频率</th>
                <th className="py-2.5">类别</th>
                <th className="py-2.5">最新观测值</th>
                <th className="py-2.5">数据意外 (Surprise)</th>
                <th className="py-2.5">Nowcast 边际影响</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {mockNowcastIndicators.map((ind) => (
                <tr key={ind.id} className="hover:bg-slate-800/40">
                  <td className="py-2.5 font-sans font-semibold text-white">{ind.name}</td>
                  <td className="py-2.5 text-slate-400">{ind.frequency}</td>
                  <td className="py-2.5 text-blue-300">{ind.category}</td>
                  <td className="py-2.5 font-bold text-white">{ind.latestValue}</td>
                  <td className="py-2.5 text-amber-400 font-bold">+{ind.surpriseVal}</td>
                  <td className="py-2.5 text-rose-400 font-bold">+{ind.impactOnNowcast}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
