import React, { useState } from 'react';
import { CpiBasketNode } from '../types/inflation';
import { ChevronRight, ChevronDown, PieChart, Sliders, RefreshCw } from 'lucide-react';

interface CpiEngineViewProps {
  cpiTree: CpiBasketNode;
}

export const CpiEngineView: React.FC<CpiEngineViewProps> = ({ cpiTree }) => {
  const [expandedNodes, setExpandedNodes] = useState<Record<string, boolean>>({
    cpi_all: true,
    food: true,
    energy: true,
    goods: true,
    services: true,
  });

  const [customWeights, setCustomWeights] = useState<Record<string, number>>({
    food: 18.5,
    energy: 8.5,
    goods: 35.0,
    services: 38.0,
  });

  const toggleExpand = (id: string) => {
    setExpandedNodes((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const renderTreeNode = (node: CpiBasketNode, depth = 0) => {
    const isExpanded = !!expandedNodes[node.id];
    const hasChildren = node.children && node.children.length > 0;

    return (
      <div key={node.id} className="font-sans">
        <div
          onClick={() => hasChildren && toggleExpand(node.id)}
          className={`flex items-center justify-between p-3 border-b border-slate-800/80 hover:bg-slate-800/60 transition-colors ${
            depth === 0 ? 'bg-slate-900 font-bold text-white' : depth === 1 ? 'bg-slate-900/60 text-slate-200' : 'text-slate-300'
          } ${hasChildren ? 'cursor-pointer' : ''}`}
          style={{ paddingLeft: `${depth * 1.5 + 0.75}rem` }}
        >
          <div className="flex items-center gap-2">
            {hasChildren ? (
              isExpanded ? (
                <ChevronDown className="w-4 h-4 text-blue-400 shrink-0" />
              ) : (
                <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
              )
            ) : (
              <span className="w-4 h-4 shrink-0" />
            )}
            <span className="text-xs">{node.name}</span>
            <span className="text-[10px] text-slate-500 font-mono">({node.code})</span>
          </div>

          <div className="flex items-center gap-6 font-mono text-xs">
            <div className="w-20 text-right">
              <span className="text-slate-400 text-[10px] block">基准权重</span>
              <span className="text-blue-300 font-semibold">{node.weight.toFixed(1)}%</span>
            </div>
            <div className="w-20 text-right">
              <span className="text-slate-400 text-[10px] block">CPI指数</span>
              <span className="text-slate-200">{node.cpiIndex.toFixed(1)}</span>
            </div>
            <div className="w-20 text-right">
              <span className="text-slate-400 text-[10px] block">同比 (YoY)</span>
              <span className="text-rose-400 font-bold">+{node.yoy.toFixed(2)}%</span>
            </div>
            <div className="w-24 text-right">
              <span className="text-slate-400 text-[10px] block">拉动贡献</span>
              <span className="text-amber-400 font-bold">+{node.contribution.toFixed(2)}%</span>
            </div>
          </div>
        </div>

        {hasChildren && isExpanded && (
          <div>{node.children!.map((child) => renderTreeNode(child, depth + 1))}</div>
        )}
      </div>
    );
  };

  return (
    <div className="p-6 space-y-6 bg-slate-950 text-slate-100 min-h-screen">
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <PieChart className="w-5 h-5 text-blue-400" />
            CPI 商品与服务篮子引擎 (CPI Basket Taxonomy & Weights)
          </h2>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            无限层级分项分解、基期重构与可配置权重重算
          </p>
        </div>

        <button className="px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow">
          <RefreshCw className="w-3.5 h-3.5" />
          <span>重算CPI总体指数</span>
        </button>
      </div>

      {/* Main Hierarchy Tree */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-2xl">
        <div className="p-3 bg-slate-950 border-b border-slate-800 flex items-center justify-between text-xs font-mono text-slate-400">
          <span>分类结构树 (Taxonomy Hierarchy)</span>
          <span>按可配置权重与基期 CPI 指数加权</span>
        </div>
        {renderTreeNode(cpiTree)}
      </div>
    </div>
  );
};
