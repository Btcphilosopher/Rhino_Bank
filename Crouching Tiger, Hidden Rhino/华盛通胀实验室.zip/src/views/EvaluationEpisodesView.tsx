import React, { useState } from 'react';
import { History, Award, CheckCircle, ArrowRight } from 'lucide-react';
import { mockHistoricalEpisodes } from '../engine/mockDatabase';

export const EvaluationEpisodesView: React.FC = () => {
  const [selectedEpisodeId, setSelectedEpisodeId] = useState<string>('cpi_2022_supply');

  const episode = mockHistoricalEpisodes.find((e) => e.id === selectedEpisodeId) || mockHistoricalEpisodes[0];

  return (
    <div className="p-6 space-y-6 bg-slate-950 text-slate-100 min-h-screen">
      <div className="border-b border-slate-800 pb-3">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <History className="w-5 h-5 text-amber-400" />
          历史通胀情景回溯与模型评估 (Historical Inflation Episodes & Backtesting)
        </h2>
        <p className="text-xs text-slate-400 font-mono mt-0.5">
          对比 2008全球金融危机、2011输入通胀、2020疫情冲击、2022大宗冲击 等历史通胀周期的 T-12 到 T+12 演变轨迹
        </p>
      </div>

      {/* Episode Selector Bar */}
      <div className="flex flex-wrap gap-2">
        {mockHistoricalEpisodes.map((ep) => (
          <button
            key={ep.id}
            onClick={() => setSelectedEpisodeId(ep.id)}
            className={`px-4 py-2 rounded-lg text-xs font-bold font-mono border transition-all ${
              selectedEpisodeId === ep.id
                ? 'bg-amber-500 text-slate-950 border-amber-400 shadow'
                : 'bg-slate-900 border-slate-800 text-slate-300 hover:text-white'
            }`}
          >
            {ep.name}
          </button>
        ))}
      </div>

      {/* Episode Detail Card */}
      <div className="bg-slate-900 rounded-xl border border-slate-800 p-5 shadow-2xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div>
            <h3 className="text-sm font-bold text-white">{episode.name}</h3>
            <span className="text-xs text-slate-400 font-mono">{episode.period} · 主导驱动: {episode.primaryDriver}</span>
          </div>
          <div className="text-right font-mono">
            <span className="text-xs text-slate-400 block">峰值 CPI 同比</span>
            <strong className="text-xl font-bold text-rose-400">+{episode.peakCpi.toFixed(2)}%</strong>
          </div>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed bg-slate-950 p-3 rounded-lg border border-slate-800/80">
          <strong>央行研判复盘:</strong> {episode.description}
        </p>

        {/* Path Comparison Table */}
        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono pt-2">
          历史 T-12 至 T+12 CPI 轨迹对比 (Time Horizon Path)
        </h4>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="py-2">相对月份</th>
                {episode.trajectory.map((t) => (
                  <th key={t.month} className="py-2 text-center">{t.month}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              <tr>
                <td className="py-2.5 font-bold text-white">历史实际值 (%)</td>
                {episode.trajectory.map((t) => (
                  <td key={t.month} className="py-2.5 text-center font-bold text-amber-400">
                    {t.actual.toFixed(2)}%
                  </td>
                ))}
              </tr>
              <tr>
                <td className="py-2.5 font-bold text-slate-400">央行模型回测估值 (%)</td>
                {episode.trajectory.map((t) => (
                  <td key={t.month} className="py-2.5 text-center text-blue-300">
                    {t.forecast.toFixed(2)}%
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
