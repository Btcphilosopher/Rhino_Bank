import React, { useState } from 'react';
import { Layers, Sliders, Activity, AlertTriangle } from 'lucide-react';
import ReactECharts from 'echarts-for-react';
import { computeTaylorRuleRate, simulatePolicyRateShock, TaylorRuleParams } from '../engine/dsgeAndPolicy';
import { mockShockDecompositions } from '../engine/mockDatabase';

export const DsgePolicyView: React.FC = () => {
  const [taylorParams, setTaylorParams] = useState<TaylorRuleParams>({
    neutralRate: 1.5,
    targetInflation: 2.0,
    phiPi: 1.5,
    phiY: 0.5,
    smoothing: 0.8,
    currentRate: 2.5,
  });

  const [policyShockBp, setPolicyShockBp] = useState(50);

  const taylorRes = computeTaylorRuleRate(2.15, 0.45, taylorParams);
  const shockResponses = simulatePolicyRateShock(policyShockBp);

  // Shock Decomposition Chart Option
  const shockOption = {
    backgroundColor: '#0f172a',
    title: {
      text: '通胀偏离目标之结构性冲击动态分解 (Structural Shock Decomposition)',
      textStyle: { color: '#f8fafc', fontSize: 13, fontWeight: 'bold' },
      left: 15,
      top: 10,
    },
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
    legend: {
      data: ['需求冲击', '能源冲击', '食品冲击', '进口冲击', '工资冲击', '预期冲击', '政策冲击'],
      textStyle: { color: '#cbd5e1', fontSize: 11 },
      top: 15,
      right: 20,
    },
    grid: { left: '3%', right: '4%', bottom: '12%', top: '22%', containLabel: true },
    xAxis: {
      type: 'category',
      data: mockShockDecompositions.map((s) => s.period),
      axisLabel: { color: '#94a3b8', fontSize: 11 },
    },
    yAxis: {
      type: 'value',
      name: '百分点偏离 (%)',
      nameTextStyle: { color: '#94a3b8', fontSize: 11 },
      splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
      axisLabel: { color: '#94a3b8' },
    },
    series: [
      { name: '需求冲击', type: 'bar', stack: 'total', data: mockShockDecompositions.map((s) => s.demandShock), itemStyle: { color: '#38bdf8' } },
      { name: '能源冲击', type: 'bar', stack: 'total', data: mockShockDecompositions.map((s) => s.energyShock), itemStyle: { color: '#ef4444' } },
      { name: '食品冲击', type: 'bar', stack: 'total', data: mockShockDecompositions.map((s) => s.foodShock), itemStyle: { color: '#f59e0b' } },
      { name: '进口冲击', type: 'bar', stack: 'total', data: mockShockDecompositions.map((s) => s.importShock), itemStyle: { color: '#10b981' } },
      { name: '工资冲击', type: 'bar', stack: 'total', data: mockShockDecompositions.map((s) => s.wageShock), itemStyle: { color: '#8b5cf6' } },
      { name: '预期冲击', type: 'bar', stack: 'total', data: mockShockDecompositions.map((s) => s.expectationShock), itemStyle: { color: '#ec4899' } },
      { name: '政策冲击', type: 'bar', stack: 'total', data: mockShockDecompositions.map((s) => s.policyShock), itemStyle: { color: '#64748b' } },
    ],
  };

  return (
    <div className="p-6 space-y-6 bg-slate-950 text-slate-100 min-h-screen">
      <div className="border-b border-slate-800 pb-3">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <Layers className="w-5 h-5 text-indigo-400" />
          宏观 DSGE 模型、泰勒规则与政策传导 (DSGE & Policy Transmission Lab)
        </h2>
        <p className="text-xs text-slate-400 font-mono mt-0.5">
          泰勒规则参数校准 (Taylor Rule: i_t = r^* + π_t + φ_π(π_t - π^*) + φ_y x_t) & 货币政策冲击脉冲响应 (Impulse Response)
        </p>
      </div>

      {/* Taylor Rule Simulator */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-slate-900 rounded-xl border border-slate-800 p-5 shadow-2xl space-y-4 font-mono text-xs">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider border-b border-slate-800 pb-2">
            泰勒规则 (Taylor Rule) 模拟面板
          </h3>

          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>φ_π (通胀偏离反应系数):</span>
                <span className="text-rose-400 font-bold">{taylorParams.phiPi.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="1.0"
                max="3.0"
                step="0.1"
                value={taylorParams.phiPi}
                onChange={(e) => setTaylorParams({ ...taylorParams, phiPi: Number(e.target.value) })}
                className="w-full h-1.5 bg-slate-800 rounded appearance-none cursor-pointer accent-rose-500"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>φ_y (产出缺口反应系数):</span>
                <span className="text-blue-400 font-bold">{taylorParams.phiY.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="0.1"
                max="1.5"
                step="0.1"
                value={taylorParams.phiY}
                onChange={(e) => setTaylorParams({ ...taylorParams, phiY: Number(e.target.value) })}
                className="w-full h-1.5 bg-slate-800 rounded appearance-none cursor-pointer accent-blue-500"
              />
            </div>
          </div>

          <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-1">
            <div className="flex justify-between">
              <span className="text-slate-400">泰勒规则目标利率:</span>
              <strong className="text-amber-400 font-bold">{taylorRes.targetRate}%</strong>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">平滑后建议利率:</span>
              <strong className="text-blue-400 font-bold">{taylorRes.recommendedRate}%</strong>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">与现行利率 (2.5%) 缺口:</span>
              <strong className="text-rose-400 font-bold">+{taylorRes.gap}%</strong>
            </div>
          </div>
        </div>

        {/* Policy Shock Simulator Output */}
        <div className="lg:col-span-2 bg-slate-900 rounded-xl border border-slate-800 p-5 shadow-2xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
              货币政策利率冲击脉冲响应 (Policy Shock Impulse Response)
            </h3>
            <div className="flex gap-2 font-mono text-xs">
              {[25, 50, -25].map((bp) => (
                <button
                  key={bp}
                  onClick={() => setPolicyShockBp(bp)}
                  className={`px-2.5 py-1 rounded border font-semibold ${
                    policyShockBp === bp ? 'bg-blue-600 text-white border-blue-400' : 'bg-slate-800 border-slate-700 text-slate-400'
                  }`}
                >
                  {bp > 0 ? `+${bp}bp` : `${bp}bp`}
                </button>
              ))}
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs font-mono">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="py-2">冲击路径</th>
                  <th className="py-2">利率变动 (%)</th>
                  <th className="py-2">GDP增速响应 (%)</th>
                  <th className="py-2">工资增速响应 (%)</th>
                  <th className="py-2">总体CPI响应 (%)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-200">
                {shockResponses.map((r, idx) => (
                  <tr key={idx} className="hover:bg-slate-800/40">
                    <td className="py-2 font-bold text-white">{r.quarter}</td>
                    <td className="py-2 text-blue-300">+{r.policyRateDelta}%</td>
                    <td className="py-2 text-rose-400">{r.gdpGrowthDelta}%</td>
                    <td className="py-2 text-amber-400">{r.wageGrowthDelta}%</td>
                    <td className="py-2 text-emerald-400 font-bold">{r.headlineCpiDelta}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Structural Shock Decomposition Chart */}
      <div className="bg-slate-900 rounded-xl border border-slate-800 p-2 shadow-2xl">
        <ReactECharts option={shockOption} style={{ height: '360px', width: '100%' }} />
      </div>
    </div>
  );
};
