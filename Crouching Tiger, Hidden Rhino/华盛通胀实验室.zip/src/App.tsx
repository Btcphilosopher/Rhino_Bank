import React, { useState } from 'react';
import { Header } from './components/Header';
import { NavTabs } from './components/NavTabs';
import { ExecutiveDashboardView } from './views/ExecutiveDashboardView';
import { CpiEngineView } from './views/CpiEngineView';
import { ContributionView } from './views/ContributionView';
import { CoreInflationView } from './views/CoreInflationView';
import { ServicesGoodsView } from './views/ServicesGoodsView';
import { EnergyFoodView } from './views/EnergyFoodView';
import { ImportFxView } from './views/ImportFxView';
import { WageUlcView } from './views/WageUlcView';
import { PhillipsCurveView } from './views/PhillipsCurveView';
import { ExpectationsView } from './views/ExpectationsView';
import { NowcastView } from './views/NowcastView';
import { ModelSuiteView } from './views/ModelSuiteView';
import { DsgePolicyView } from './views/DsgePolicyView';
import { ScenarioLabView } from './views/ScenarioLabView';
import { MlLabView } from './views/MlLabView';
import { EconometricsView } from './views/EconometricsView';
import { EvaluationEpisodesView } from './views/EvaluationEpisodesView';
import { DataQualityLineageView } from './views/DataQualityLineageView';
import { ResearchNotebookView } from './views/ResearchNotebookView';

import { AIAssistantModal } from './components/AIAssistantModal';
import { ReportGeneratorModal } from './components/ReportGeneratorModal';
import { DataLineageModal } from './components/DataLineageModal';

import { mockCpiMetrics, mockCpiTree } from './engine/mockDatabase';

export function App() {
  const [activeTab, setActiveTab] = useState('overview');
  const [vintageDate, setVintageDate] = useState('2026M08 (最新公布)');

  // Modals state
  const [isAIOpen, setIsAIOpen] = useState(false);
  const [isReportOpen, setIsReportOpen] = useState(false);
  const [isLineageOpen, setIsLineageOpen] = useState(false);
  const [selectedLineageMetric, setSelectedLineageMetric] = useState('总体CPI');

  const handleOpenLineage = (metricName: string) => {
    setSelectedLineageMetric(metricName);
    setIsLineageOpen(true);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-blue-500 selection:text-white">
      {/* Top Fixed Header */}
      <Header
        vintageDate={vintageDate}
        onVintageChange={setVintageDate}
        onOpenAIAssistant={() => setIsAIOpen(true)}
      />

      {/* Navigation Tabs Bar */}
      <NavTabs activeTab={activeTab} onTabChange={setActiveTab} />

      {/* Main Analytical View Content */}
      <main className="flex-1 overflow-x-hidden">
        {activeTab === 'overview' && (
          <ExecutiveDashboardView
            metrics={mockCpiMetrics}
            onOpenLineage={handleOpenLineage}
            onOpenAIAssistant={() => setIsAIOpen(true)}
          />
        )}

        {activeTab === 'cpi_engine' && <CpiEngineView cpiTree={mockCpiTree} />}

        {activeTab === 'contributions' && <ContributionView />}

        {activeTab === 'core' && <CoreInflationView />}

        {activeTab === 'services_goods' && <ServicesGoodsView />}

        {activeTab === 'energy_food' && <EnergyFoodView />}

        {activeTab === 'import_fx' && <ImportFxView />}

        {activeTab === 'wage_ulc' && <WageUlcView />}

        {activeTab === 'phillips' && <PhillipsCurveView />}

        {activeTab === 'expectations' && <ExpectationsView />}

        {activeTab === 'nowcast' && <NowcastView />}

        {activeTab === 'models' && <ModelSuiteView />}

        {activeTab === 'dsge' && <DsgePolicyView />}

        {activeTab === 'scenario' && <ScenarioLabView />}

        {activeTab === 'ml' && <MlLabView />}

        {activeTab === 'econometrics' && <EconometricsView />}

        {activeTab === 'eval_episodes' && <EvaluationEpisodesView />}

        {activeTab === 'quality_lineage' && (
          <DataQualityLineageView onOpenLineage={handleOpenLineage} />
        )}

        {activeTab === 'notebook' && (
          <ResearchNotebookView onOpenReportGenerator={() => setIsReportOpen(true)} />
        )}
      </main>

      {/* Modals & Slide-overs */}
      <AIAssistantModal
        isOpen={isAIOpen}
        onClose={() => setIsAIOpen(false)}
        contextData={{
          activeTab,
          vintageDate,
          cpiHeadline: 2.15,
          cpiCore: 1.85,
          servicesCpi: 2.45,
          ulcGrowth: 2.60,
        }}
      />

      <ReportGeneratorModal
        isOpen={isReportOpen}
        onClose={() => setIsReportOpen(false)}
        vintageDate={vintageDate}
      />

      <DataLineageModal
        isOpen={isLineageOpen}
        onClose={() => setIsLineageOpen(false)}
        metricName={selectedLineageMetric}
      />
    </div>
  );
}

export default App;
