/**
 * 华盛通胀实验室 (HUASHENG INFLATION LAB)
 * Data Models and Types
 */

export interface CpiMetric {
  id: string;
  name: string; // e.g., 总体CPI, 核心CPI, 服务通胀
  category: 'headline' | 'core' | 'goods' | 'services' | 'food' | 'energy' | 'imported' | 'domestic' | 'wage' | 'expectations';
  currentVal: number; // e.g. 2.15%
  prevVal: number; // e.g. 2.05%
  change3m: number; // 3-month annualized
  change6m: number; // 6-month annualized
  change12m: number; // 12-month change (YoY)
  mom: number; // Month-over-Month
  momSa: number; // Seasonally adjusted MoM
  histMean: number; // Historical mean (10y)
  histPercentile: number; // Historical percentile (0-100)
  unit: string;
}

export interface CpiBasketNode {
  id: string;
  name: string;
  code: string;
  weight: number; // e.g. 28.5%
  cpiIndex: number; // e.g. 104.2
  yoy: number; // % YoY
  mom: number; // % MoM
  contribution: number; // percentage points contribution to headline CPI
  children?: CpiBasketNode[];
}

export interface InflationContributionItem {
  category: string;
  weight: number;
  yoyChange: number;
  contribution: number; // pct points
  color: string;
}

export interface TrimmedMeanResult {
  trimPct: number; // e.g. 5, 10, 15, 20
  value: number; // %
  headlineDiff: number;
  coreDiff: number;
}

export interface PriceDistributionBin {
  binRange: string;
  minVal: number;
  maxVal: number;
  itemCount: number;
  totalWeight: number;
  itemNames: string[];
}

export interface DiffusionIndexData {
  period: string;
  diffusion3m: number; // 0 - 100
  diffusion6m: number;
  diffusion12m: number;
  pctIncreasing: number;
  pctDecreasing: number;
  pctHighInflation: number; // >3%
  pctLowInflation: number; // <1%
}

export interface WageUlcData {
  period: string;
  nominalWageGrowth: number;
  realWageGrowth: number;
  productivityGrowth: number;
  unitLaborCostGrowth: number; // ULC = Wage - Productivity
  servicesInflation: number;
  profitMarginGrowth: number;
}

export interface ExpectationPoint {
  period: string;
  horizon: '1Y' | '2Y' | '3Y' | '5Y' | '10Y';
  householdSurvey: number;
  corporateSurvey: number;
  professionalForecasters: number;
  inflationSwaps: number;
  breakevenInflation: number;
  mean: number;
  median: number;
  p25: number;
  p75: number;
  disagreementIndex: number; // standard deviation
}

export interface NowcastIndicator {
  id: string;
  name: string;
  frequency: '日频' | '周频' | '月频';
  category: '能源' | '商品' | '汇率' | '工资' | '调查' | '信用' | '消费' | '价格' | '运费' | '食品';
  latestValue: number;
  releaseDate: string;
  referencePeriod: string;
  firstReleaseVal: number;
  revisedVal: number;
  marketConsensus: number;
  modelExpectation: number;
  surpriseVal: number;
  impactOnNowcast: number; // e.g. +0.04%
}

export interface NowcastVintage {
  vintageDate: string;
  nowcastValue: number;
  headlineObserved: number | null;
  bridgeModel: number;
  midasModel: number;
  dynamicFactorModel: number;
  bayesianVar: number;
}

export interface ModelForecast {
  modelId: string;
  modelName: string;
  modelType: 'ARIMA' | 'VAR' | 'BVAR' | 'Dynamic Factor' | 'Phillips Curve' | 'Hybrid NK' | 'DSGE' | 'ML XGBoost' | 'State Space';
  forecastHorizon: string; // e.g. '2026Q3' or '2027M08'
  pointForecast: number;
  ci50Lower: number;
  ci50Upper: number;
  ci70Lower: number;
  ci70Upper: number;
  ci90Lower: number;
  ci90Upper: number;
  mae12m: number;
  rmse12m: number;
  bias: number;
}

export interface ScenarioShockInput {
  energyPricePct: number; // e.g. +20%
  foodPricePct: number; // e.g. +10%
  fxDepreciationPct: number; // e.g. +5%
  wageGrowthPct: number; // e.g. +3%
  productivityGrowthPct: number; // e.g. -1%
  unemploymentGap: number; // e.g. -0.5%
  outputGap: number; // e.g. +1.2%
  globalDemandPct: number; // e.g. +2%
  importPricePct: number; // e.g. +4%
  inflationExpectationsPct: number; // e.g. +0.5%
  policyRateBp: number; // e.g. +50bp
}

export interface ScenarioResult {
  headlineCpi: number;
  coreCpi: number;
  servicesCpi: number;
  goodsCpi: number;
  wageGrowth: number;
  gdpGrowth: number;
  employmentChange: number;
  expectationImpact: number;
  timePath: {
    t: number;
    periodStr: string;
    headline: number;
    core: number;
    wage: number;
    gdp: number;
  }[];
}

export interface ShockDecomposition {
  period: string;
  headlineDeviation: number; // deviation from 2.0% target
  demandShock: number;
  energyShock: number;
  foodShock: number;
  importShock: number;
  wageShock: number;
  expectationShock: number;
  policyShock: number;
  otherShock: number;
}

export interface HistoricalEpisode {
  id: string;
  name: string; // e.g. "2008年全球输入性高通胀", "2022年能源与供应链冲击"
  periodRange: string;
  period?: string;
  primaryDriver?: string;
  peakCpi?: number;
  description?: string;
  keyDrivers: string;
  headlinePeak: number;
  corePeak: number;
  trajectory?: { month: string; actual: number; forecast: number }[];
  timeline: {
    tOffset: string; // T-12, T-6, T-3, T, T+3, T+6, T+12;
    date: string;
    headline: number;
    core: number;
    energy: number;
    wage: number;
    outputGap: number;
  }[];
}

export interface ResearchNote {
  id: string;
  title: string;
  author: string;
  date: string;
  summary: string;
  tags: string[];
  content: string;
}
