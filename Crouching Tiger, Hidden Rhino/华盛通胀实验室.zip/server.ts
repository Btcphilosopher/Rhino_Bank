import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy Google GenAI Client
let aiClient: GoogleGenAI | null = null;
function getAIClient(): GoogleGenAI | null {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (key) {
      aiClient = new GoogleGenAI({ apiKey: key });
    }
  }
  return aiClient;
}

// API Routes
app.get("/api/health", (_req, res) => {
  res.json({
    status: "ok",
    app: "华盛通胀实验室",
    version: "1.0.0",
    engine: "Central-Bank-Grade Inflation Intelligence Platform",
  });
});

// AI Macro Assistant Route
app.post("/api/ai/chat", async (req, res) => {
  try {
    const { message, context } = req.body;
    const ai = getAIClient();

    if (!ai) {
      return res.status(500).json({
        error: "GEMINI_API_KEY 未配置，请在 AI Studio 密钥设置中配置 GEMINI_API_KEY。",
      });
    }

    const systemInstruction = `你现在是「华盛通胀实验室」(HUASHENG INFLATION LAB) 的中文央行级宏观经济助手——“华盛宏观助手”。
你代表中央银行研究部门的专业经济学家与计量模型专家。

严格规则：
1. 100% 使用专业、严谨、客观的简体中文回答。
2. 解释通胀数据变化时，严格基于 CPI 权重、分项贡献（食品、能源、商品、服务）、工资-ULC 传导、需求与供给冲击、通胀预期脱锚风险等结构机制。
3. 当用户询问情景假设（如“如果能源上涨20%会怎样”），请给出基于模型计算的定量传导路径（包括直接贡献、二阶通胀传导、工资响应与 Core CPI 变动），并标注“模型模拟结果，具有预测不确定性”。
4. 禁止伪造官方统计数据或央行货币政策决策声明。
5. 所有输出保持央行研究报告的高信息密度与严肃严谨风格。

当前系统数据上下文:
${JSON.stringify(context || {}, null, 2)}`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [
        { role: "user", parts: [{ text: `${systemInstruction}\n\n用户提问：${message}` }] }
      ]
    });

    const replyText = response.text || "未能生成回答，请稍后再试。";
    res.json({ reply: replyText, isAIGenerated: true });
  } catch (err: any) {
    console.error("AI Assistant error:", err);
    res.status(500).json({
      error: "华盛宏观助手服务异常: " + (err?.message || String(err)),
    });
  }
});

async function startServer() {
  // Vite middleware for dev
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[HUASHENG INFLATION LAB] Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
