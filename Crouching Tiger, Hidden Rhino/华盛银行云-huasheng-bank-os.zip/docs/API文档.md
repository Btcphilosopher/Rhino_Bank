# 华盛银行云 (HUASHENG BANK OS) - OpenAPI API 规范

所有 API 返回统一格式：
```json
{
  "code": 200,
  "message": "操作成功",
  "data": { ... },
  "timestamp": "2026-09-17T10:00:00Z"
}
```

## 核心接口列表
- `/api/v1/auth/login` - 银行员工/客户身份认证
- `/api/v1/customers` - 客户360°档案检索与创建
- `/api/v1/accounts` - 账户开立、状态变更与实时余额查询
- `/api/v1/transactions` - 存款、取款、转账交易提交
- `/api/v1/payments` - 跨行/行内支付编排与审核
- `/api/v1/loans` - 贷款申请、信贷审批、还款计划生成与扣款
- `/api/v1/cards` - 借记卡/信用卡卡片管理与账单生成
- `/api/v1/corporate` - 企业现金池、归集与贸易融资
- `/api/v1/treasury` - 资金头寸、外汇买卖与ALM
- `/api/v1/risk` - 风控预警、AML监测与压力测试
- `/api/v1/accounting` - 科目总账、日终EOD批处理与试算平衡
- `/api/v1/ai/query` - 「华盛智行」AI 智能问答与数据分析
