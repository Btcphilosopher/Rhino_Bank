import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// 实例化 Server-Side Gemini AI 客户端 (遵守 aistudio-build 请求头要求)
let genAIClient: GoogleGenAI | null = null;
function getGenAI(): GoogleGenAI {
  if (!genAIClient) {
    const key = process.env.GEMINI_API_KEY;
    genAIClient = new GoogleGenAI({
      apiKey: key || 'MOCK_KEY_DEVELOPMENT',
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return genAIClient;
}

// ------------------------------------------------------------------
// RESTful API 接口层 (/api/v1/*)
// ------------------------------------------------------------------

// 健康检查
app.get('/api/v1/health', (req, res) => {
  res.json({
    status: 'ONLINE',
    system: '华盛银行云 HUASHENG BANK OS',
    version: 'v3.6.0-ENTERPRISE',
    ledgerStatus: 'DEBIT_CREDIT_BALANCED',
    timestamp: new Date().toISOString(),
  });
});

// 系统核心指标
app.get('/api/v1/metrics', (req, res) => {
  res.json({
    code: 200,
    message: '核心指标查询成功',
    data: {
      totalCustomers: 104280,
      totalAccounts: 215900,
      totalDepositCNY: 21500000000,
      totalLoanCNY: 14700000000,
      dailyTxnAmountCNY: 4850000000,
      dailyTxnVolume: 128900,
      systemTPS: 1248,
      avgLatencyMs: 3.2,
      databaseHealth: 'OPTIMAL',
      rustLedgerStatus: 'ONLINE',
    },
  });
});

// 「华盛智行」AI Banking Assistant 智能服务端接口
app.post('/api/v1/ai/query', async (req, res) => {
  try {
    const { prompt, context } = req.body;
    if (!prompt) {
      return res.status(400).json({ code: 400, message: '请输入查询内容' });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      // 模拟优雅智能回答 (当无API Key时)
      return res.json({
        code: 200,
        message: 'AI分析完成',
        answer: `【华盛智行 AI 智能分析】\n基于系统授权数据分析结果：\n- 分析对象：${context?.targetName || '华盛银行核心系统'}\n- 业务要点：根据最近90天流水，客户资金流入结构稳定，日均存款余额达 ¥320,000,000，经营性现金流健康，建议可提高综合授信额度。\n- 风险提示：无洗钱或异常大额转账告警，风险等级维持为 R1 (低风险)。\n\n数据来源：华盛核心账本 1001/2001/1301 科目明细 (未修改任何实际财务状态)。`,
        sources: ['核心账本实时明细', '信贷五级分类数据库', 'AML合规监控库'],
      });
    }

    const ai = getGenAI();
    const systemPrompt = `你现在是「华盛银行云」(HUASHENG BANK OS) 的首席AI金融助手「华盛智行」。
请以极高专业度、合规严谨且精炼的中文回答银行内部管理人员或客户的提问。
规章原则：
1. 始终明确指出数据来源与分析凭据。
2. 绝对不编造虚假交易或账户，不改动任何核心账本与利息算式。
3. 任何敏感资金调拨或贷款发放均强调需要“人工二次复核与授权”。
4. 使用标准银行术语（如：借贷平平衡、试算平衡、可用余额、授信额度、NPL不良率、ALM久期）。`;

    const fullPrompt = `${systemPrompt}\n\n当前上下文数据: ${JSON.stringify(context || {})}\n用户提问: ${prompt}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: fullPrompt,
    });

    const answerText = response.text || '暂无返回内容';

    res.json({
      code: 200,
      message: 'AI分析完成',
      answer: answerText,
      sources: ['华盛核心账本数据库', '信贷与风控引擎', '合规监控平台'],
    });
  } catch (error: any) {
    console.error('Gemini API Error:', error);
    res.status(500).json({
      code: 500,
      message: 'AI 服务响应异常，已退回安全模式',
      answer: '【华盛智行 - 备用模式】由于网络或响应超时，目前为您展现本地账本的规则化分析摘要。请稍后重试。',
    });
  }
});

// ------------------------------------------------------------------
// Vite & Express 启动整合
// ------------------------------------------------------------------
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[HUASHENG BANK OS] 银行核心系统已就绪: http://0.0.0.0:${PORT}`);
  });
}

startServer();
