// 华盛银行云 (HUASHENG BANK OS) - 核心领域数据类型定义

export enum CustomerType {
  INDIVIDUAL = 'INDIVIDUAL',      // 个人客户
  CORPORATE = 'CORPORATE',        // 企业客户
  INSTITUTIONAL = 'INSTITUTIONAL',// 机构客户
  INTERBANK = 'INTERBANK',        // 同业银行
  GROUP = 'GROUP'                 // 集团客户
}

export enum CustomerRiskLevel {
  LOW = 'LOW',         // 低风险 (R1)
  MEDIUM_LOW = 'MEDIUM_LOW', // 中低风险 (R2)
  MEDIUM = 'MEDIUM',   // 中风险 (R3)
  HIGH = 'HIGH',       // 高风险 (R4)
  VERY_HIGH = 'VERY_HIGH' // 极高风险 (R5)
}

export interface Customer {
  id: string;
  customerNo: string;        // CUST-2026-XXXX
  name: string;              // 姓名/企业名称
  idType: string;            // 身份证/统一社会信用代码
  idNoMasked: string;        // 脱敏证件号
  type: CustomerType;
  phoneMasked: string;
  email: string;
  address: string;
  level: 'VIP_GOLD' | 'VIP_PLATINUM' | 'STANDARD' | 'DIAMOND';
  riskLevel: CustomerRiskLevel;
  relationshipManager: string;// 客户经理姓名
  branchName: string;         // 开户机构
  createdDate: string;
  accountCount: number;
  totalDeposit: number;       // 存款总额 (RMB)
  totalLoan: number;          // 贷款余额 (RMB)
  totalCreditLimit: number;   // 综合授信额度 (RMB)
  usedCreditLimit: number;    // 已用授信额度 (RMB)
  cardCount: number;
  status: 'ACTIVE' | 'FROZEN' | 'UNDER_REVIEW' | 'INACTIVE';
}

export enum AccountType {
  CURRENT = 'CURRENT',            // 活期结算账户
  SAVINGS = 'SAVINGS',            // 储蓄账户
  TERM_DEPOSIT = 'TERM_DEPOSIT',  // 定期存款账户
  CORPORATE_SETTLEMENT = 'CORPORATE_SETTLEMENT', // 企业结算账户
  LOAN_ACCOUNT = 'LOAN_ACCOUNT',  // 贷款专户
  INTERNAL_CLEARING = 'INTERNAL_CLEARING', // 内部清算账户
  INTERBANK_DEPOSIT = 'INTERBANK_DEPOSIT'  // 同业存放账户
}

export interface Account {
  id: string;
  accountNo: string;         // 6222XXXXXX
  customerId: string;
  customerName: string;
  type: AccountType;
  currency: 'CNY' | 'USD' | 'EUR' | 'HKD' | 'GBP' | 'JPY';
  bookBalance: number;       // 账面余额
  frozenAmount: number;      // 冻结金额
  pendingAmount: number;     // 待处理金额
  availableBalance: number;  // 可用余额 = bookBalance - frozenAmount - pendingAmount
  interestRate: number;      // 年利率 (%)
  status: 'NORMAL' | 'FROZEN' | 'SUSPENDED' | 'CLOSED';
  openDate: string;
  branchName: string;
}

export enum TransactionType {
  DEPOSIT = 'DEPOSIT',              // 存款入账
  WITHDRAWAL = 'WITHDRAWAL',        // 取款扣账
  TRANSFER_IN = 'TRANSFER_IN',      // 转账收入
  TRANSFER_OUT = 'TRANSFER_OUT',    // 转账支出
  LOAN_DISBURSEMENT = 'LOAN_DISBURSEMENT', // 贷款发放
  LOAN_REPAYMENT = 'LOAN_REPAYMENT',// 贷款还款
  INTEREST_POSTING = 'INTEREST_POSTING', // 利息结息
  FEE_DEDUCTION = 'FEE_DEDUCTION',  // 手续费扣收
  TRADE_FINANCE_DISBURSE = 'TRADE_FINANCE_DISBURSE' // 贸易融资放款
}

export interface LedgerEntry {
  id: string;
  txnId: string;
  accountNo: string;
  accountName: string;
  direction: 'DEBIT' | 'CREDIT'; // 借方 / 贷方
  amount: number;
  currency: string;
  subjectCode: string;           // 科目代码 (如: 1001 现金, 2001 吸收存款)
  postTimestamp: string;
}

export interface Transaction {
  id: string;
  txnNo: string;             // TXN2026XXXXXX
  timestamp: string;
  sourceAccountNo: string;
  sourceAccountName: string;
  targetAccountNo: string;
  targetAccountName: string;
  amount: number;
  currency: string;
  type: TransactionType;
  channel: 'TELLER' | 'ONLINE_BANK' | 'MOBILE_BANK' | 'BATCH_PAYMENT' | 'AUTO_SETTLEMENT';
  status: 'SUCCESS' | 'PENDING' | 'REJECTED' | 'REVERSED';
  idempotencyKey?: string;
  riskCheckPassed: boolean;
  operator: string;          // 操作员 / 柜员
  remark: string;
  ledgerEntries: LedgerEntry[];
}

export interface DepositProduct {
  id: string;
  productCode: string;
  productName: string;
  termMonths: number;        // 0为活期，3/6/12/36/60
  annualRate: number;        // %
  minAmount: number;
  earlyWithdrawalRule: string;
  interestCalculationMethod: 'DAY_BASIS' | 'MATURITY' | 'MONTHLY';
}

export interface DepositAccount {
  id: string;
  accountNo: string;
  productName: string;
  principalAmount: number;   // 本金
  accumulatedInterest: number;// 累计利息
  startDate: string;
  dueDate: string;
  termMonths: number;
  annualRate: number;
  status: 'ACTIVE' | 'MATURED' | 'EARLY_WITHDRAWN';
}

export interface PaymentOrder {
  id: string;
  orderNo: string;
  payerName: string;
  payerAccountNo: string;
  payeeName: string;
  payeeAccountNo: string;
  payeeBankName: string;
  amount: number;
  currency: string;
  paymentType: 'INTRA_BANK' | 'INTER_BANK_EXPRESS' | 'BATCH_PAYROLL' | 'TRADE_PAYMENT';
  status: 'DRAFT' | 'PENDING_MAKER' | 'PENDING_CHECKER' | 'PROCESSING' | 'SUCCESS' | 'FAILED';
  approvalChain: {
    maker: string;
    checker?: string;
    approver?: string;
    approvedAt?: string;
  };
  riskScore: number;         // 0-100
  createdAt: string;
}

export interface Card {
  id: string;
  cardNoMasked: string;      // 6228 **** **** 8888
  cardType: 'DEBIT' | 'CREDIT' | 'CORPORATE_PURCHASING' | 'VIRTUAL';
  customerName: string;
  accountNo: string;
  creditLimit: number;       // 授信总额度
  availableLimit: number;    // 可用额度
  dailyTxnLimit: number;     // 单日交易限额
  status: 'NORMAL' | 'FROZEN' | 'LOST' | 'CANCELLED' | 'PENDING_ACTIVATION';
  expiryDate: string;        // MM/YY
  billingCycleDay: number;   // 账单日
}

export enum LoanStatus {
  APPLIED = 'APPLIED',          // 申请中
  CREDIT_EVAL = 'CREDIT_EVAL',  // 授信评估中
  APPROVED = 'APPROVED',        // 已批准
  DISBURSED = 'DISBURSED',      // 已放款/履约中
  REPAYING = 'REPAYING',        // 正常还款
  OVERDUE = 'OVERDUE',          // 逾期中
  CLEARED = 'CLEARED'           // 已结清
}

export interface RepaymentPlanItem {
  periodNo: number;
  dueDate: string;
  principalAmount: number;  // 应还本金
  interestAmount: number;   // 应还利息
  totalDue: number;         // 当期合计数
  remainingPrincipal: number; // 剩余本金
  status: 'PENDING' | 'PAID' | 'OVERDUE';
}

export interface Loan {
  id: string;
  loanNo: string;            // LOAN2026XXXX
  customerName: string;
  productType: 'PERSONAL_MORTGAGE' | 'CONSUMER_CREDIT' | 'CORPORATE_WORKING_CAPITAL' | 'TRADE_FINANCE_LOAN';
  approvedAmount: number;
  balanceAmount: number;     // 剩余未还本金
  interestRate: number;      // 年利率 %
  termMonths: number;
  repaymentMethod: 'EQUAL_PAYMENT' | 'EQUAL_PRINCIPAL' | 'LUMP_SUM'; // 等额本息 / 等额本金 / 到期还本付息
  disbursementDate: string;
  riskClass: 'NORMAL' | 'ATTENTION' | 'SECONDARY' | 'SUSPICIOUS' | 'LOSS'; // 五级分类
  status: LoanStatus;
  collateralDescription?: string;
  collateralValue?: number;
  schedules: RepaymentPlanItem[];
}

export interface Collateral {
  id: string;
  collateralNo: string;
  ownerName: string;
  assetType: 'REAL_ESTATE' | 'VEHICLE' | 'EQUIPMENT' | 'RECEIVABLES' | 'SECURITIES';
  description: string;
  evaluatedValue: number;    // 评估价值
  mortgageRate: number;      // 抵押率 (%)
  maxMortgageAmount: number; // 最高可贷额度
  status: 'MORTGAGED' | 'RELEASED' | 'IN_AUCTION';
  evalDate: string;
}

export interface CorporateCustomer {
  id: string;
  companyName: string;
  orgCode: string;          // 统一社会信用代码
  legalPerson: string;      // 法人代表
  registeredCapital: number;
  industry: string;         // 行业分类
  groupName?: string;       // 所属集团
  creditRating: 'AAA' | 'AA+' | 'AA' | 'A' | 'BBB';
  totalCashPoolBalance: number;
  activeLCSCount: number;   // 活跃信用证笔数
}

export interface TradeFinanceLC {
  id: string;
  lcNo: string;              // LC2026XXXXXX
  applicantName: string;     // 开证申请人
  beneficiaryName: string;   // 受益人
  amount: number;
  currency: string;
  lcType: 'SIGHT_LC' | 'USANCE_LC' | 'STANDBY_LC'; // 即期 / 远期 / 备用信用证
  issueDate: string;
  expiryDate: string;
  status: 'ISSUED' | 'DOCS_PRESENTED' | 'PAID' | 'CLOSED';
}

export interface FXTrade {
  id: string;
  tradeNo: string;
  pair: 'USD/CNY' | 'EUR/CNY' | 'HKD/CNY' | 'GBP/CNY' | 'JPY/CNY';
  direction: 'BUY' | 'SELL';
  amountBase: number;
  exchangeRate: number;
  counterValueCNY: number;
  tradeTime: string;
  operator: string;
  pnlCNY: number;
}

export interface RiskAlert {
  id: string;
  alertNo: string;
  category: 'CREDIT_CONCENTRATION' | 'AML_SUSPICIOUS' | 'LIQUIDITY_SHORTAGE' | 'FRAUD_TAKEOVER';
  severity: 'HIGH' | 'MEDIUM' | 'LOW';
  targetName: string;
  description: string;
  triggeredAt: string;
  status: 'PENDING_INVESTIGATION' | 'INVESTIGATING' | 'DISMISSED' | 'REPORTED';
  suggestedAction: string;
}

export interface GeneralLedgerAccount {
  code: string;               // 1001, 1002, 2001, 2002, 4001, 5001
  name: string;               // 现金, 存放中央银行, 吸收存款, 存放同业, 利息收入, 利息支出
  category: 'ASSET' | 'LIABILITY' | 'EQUITY' | 'REVENUE' | 'EXPENSE';
  debitBalance: number;       // 借方余额
  creditBalance: number;      // 贷方余额
  netBalance: number;
}

export interface ReconciliationSummary {
  systemName: string;
  totalTxnCount: number;
  matchedCount: number;
  discrepancyCount: number;
  status: 'MATCHED' | 'HAS_DIFF' | 'PROCESSING';
  lastReconciledAt: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  username: string;
  role: string;
  action: string;
  targetObject: string;
  beforeValue?: string;
  afterValue?: string;
  ipAddress: string;
  result: 'SUCCESS' | 'FAILED' | 'BLOCKED';
}

export interface BankUser {
  id: string;
  username: string;
  fullName: string;
  role: 'SUPER_ADMIN' | 'TELLER' | 'BRANCH_MANAGER' | 'CREDIT_OFFICER' | 'RISK_ANALYST' | 'AUDITOR' | 'CORPORATE_USER';
  branchName: string;
  department: string;
}
