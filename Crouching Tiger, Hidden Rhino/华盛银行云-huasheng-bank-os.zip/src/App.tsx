import React, { useState } from 'react';
import { HeaderNavbar } from './components/HeaderNavbar';
import { DashboardCockpit } from './components/DashboardCockpit';
import { CustomerCenter } from './components/CustomerCenter';
import { AccountCoreView } from './components/AccountCoreView';
import { RealTimeLedgerView } from './components/RealTimeLedgerView';
import { TransactionEngineView } from './components/TransactionEngineView';
import { DepositsView } from './components/DepositsView';
import { PaymentsView } from './components/PaymentsView';
import { CardsView } from './components/CardsView';
import { LoansView } from './components/LoansView';
import { CorporateView } from './components/CorporateView';
import { TreasuryView } from './components/TreasuryView';
import { RiskComplianceView } from './components/RiskComplianceView';
import { AccountingGLView } from './components/AccountingGLView';
import { BranchAndDigitalView } from './components/BranchAndDigitalView';
import { ScenarioTwinView } from './components/ScenarioTwinView';
import { OperationsControlCenter } from './components/OperationsControlCenter';
import { AIAssistantDrawer } from './components/AIAssistantDrawer';
import { DemoFlowModal } from './components/DemoFlowModal';

export function App() {
  const [activeTab, setActiveTab] = useState('cockpit');
  const [showAIAssistant, setShowAIAssistant] = useState(false);
  const [showDemoFlow, setShowDemoFlow] = useState(false);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-blue-600 selection:text-white antialiased">
      {/* 顶部企业级银行主导航 */}
      <HeaderNavbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenAIAssistant={() => setShowAIAssistant(true)}
        onRunDemoFlow={() => setShowDemoFlow(true)}
      />

      {/* 主工作区视图 */}
      <main className="max-w-[1700px] mx-auto px-4 py-6">
        {activeTab === 'cockpit' && (
          <DashboardCockpit
            onNavigate={(tab) => setActiveTab(tab)}
            onRunDemoFlow={() => setShowDemoFlow(true)}
          />
        )}
        {activeTab === 'customers' && <CustomerCenter />}
        {activeTab === 'accounts' && <AccountCoreView />}
        {activeTab === 'ledger' && <RealTimeLedgerView />}
        {activeTab === 'transactions' && (
          <TransactionEngineView onRunDemoFlow={() => setShowDemoFlow(true)} />
        )}
        {activeTab === 'deposits' && <DepositsView />}
        {activeTab === 'payments' && <PaymentsView />}
        {activeTab === 'cards' && <CardsView />}
        {activeTab === 'loans' && <LoansView />}
        {activeTab === 'corporate' && <CorporateView />}
        {activeTab === 'treasury' && <TreasuryView />}
        {activeTab === 'risk' && <RiskComplianceView />}
        {activeTab === 'accounting' && <AccountingGLView />}
        {activeTab === 'teller' && <BranchAndDigitalView />}
        {activeTab === 'twin' && <ScenarioTwinView />}
        {activeTab === 'bocc' && <OperationsControlCenter />}
      </main>

      {/* 「华盛智行」 AI Assistant Drawer */}
      <AIAssistantDrawer isOpen={showAIAssistant} onClose={() => setShowAIAssistant(false)} />

      {/* 第一阶段 MVP 核心流程全套演示对话框 */}
      <DemoFlowModal isOpen={showDemoFlow} onClose={() => setShowDemoFlow(false)} />
    </div>
  );
}

export default App;
