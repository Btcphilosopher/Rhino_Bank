import { create } from 'zustand';
import { CoreLedgerEngine } from '../core/ledger';
import {
  INITIAL_ACCOUNTS,
  INITIAL_AUDIT_LOGS,
  INITIAL_CARDS,
  INITIAL_CUSTOMERS,
  INITIAL_GENERAL_LEDGER,
  INITIAL_LOANS,
  INITIAL_RISK_ALERTS,
  INITIAL_TRANSACTIONS,
} from '../data/mockData';
import {
  Account,
  AccountType,
  AuditLog,
  BankUser,
  Card,
  Customer,
  CustomerRiskLevel,
  CustomerType,
  GeneralLedgerAccount,
  Loan,
  LoanStatus,
  PaymentOrder,
  RepaymentPlanItem,
  RiskAlert,
  Transaction,
  TransactionType,
} from '../types';

export interface BankState {
  currentUser: BankUser;
  customers: Customer[];
  accounts: Account[];
  transactions: Transaction[];
  loans: Loan[];
  cards: Card[];
  generalLedger: GeneralLedgerAccount[];
  riskAlerts: RiskAlert[];
  auditLogs: AuditLog[];
  paymentOrders: PaymentOrder[];

  // 运营与性能指标
  systemMetrics: {
    tps: number;
    qps: number;
    avgLatencyMs: number;
    activeConnections: number;
    databaseHealth: 'OPTIMAL' | 'DEGRADED' | 'MAINTENANCE';
    rustLedgerStatus: 'ONLINE' | 'BUSY' | 'OFFLINE';
    eodStatus: 'READY' | 'PROCESSING' | 'COMPLETED';
    eodProgressPercent: number;
  };

  // Actions
  setCurrentRole: (role: BankUser['role']) => void;
  createCustomer: (data: {
    name: string;
    type: CustomerType;
    idNo: string;
    phone: string;
    email: string;
    address: string;
    relationshipManager: string;
    branchName: string;
  }) => Customer;

  openAccount: (data: {
    customerId: string;
    type: AccountType;
    currency: 'CNY' | 'USD' | 'EUR' | 'HKD';
    initialDeposit: number;
  }) => Account;

  depositMoney: (accountNo: string, amount: number, remark?: string) => { success: boolean; message: string; txn?: Transaction };

  transferMoney: (req: {
    sourceAccountNo: string;
    targetAccountNo: string;
    amount: number;
    remark: string;
    idempotencyKey?: string;
  }) => { success: boolean; message: string; txn?: Transaction };

  applyAndApproveLoan: (req: {
    customerName: string;
    productType: Loan['productType'];
    approvedAmount: number;
    termMonths: number;
    interestRate: number;
    repaymentMethod: Loan['repaymentMethod'];
    collateralDescription?: string;
    collateralValue?: number;
    disburseToAccountNo?: string;
  }) => Loan;

  repayLoanPeriod: (loanId: string, accountNo: string) => { success: boolean; message: string };

  triggerEODProcessing: () => Promise<void>;
  addAuditLog: (action: string, targetObject: string, result?: 'SUCCESS' | 'FAILED' | 'BLOCKED') => void;
}

export const useBankStore = create<BankState>((set, get) => ({
  currentUser: {
    id: 'usr-001',
    username: 'admin_master',
    fullName: '高远（核心系统高级专员）',
    role: 'SUPER_ADMIN',
    branchName: '华盛银行总行营运部',
    department: '金融科技与信息技术部',
  },
  customers: INITIAL_CUSTOMERS,
  accounts: INITIAL_ACCOUNTS,
  transactions: INITIAL_TRANSACTIONS,
  loans: INITIAL_LOANS,
  cards: INITIAL_CARDS,
  generalLedger: INITIAL_GENERAL_LEDGER,
  riskAlerts: INITIAL_RISK_ALERTS,
  auditLogs: INITIAL_AUDIT_LOGS,
  paymentOrders: [],

  systemMetrics: {
    tps: 1248,
    qps: 4890,
    avgLatencyMs: 3.2,
    activeConnections: 3420,
    databaseHealth: 'OPTIMAL',
    rustLedgerStatus: 'ONLINE',
    eodStatus: 'READY',
    eodProgressPercent: 0,
  },

  setCurrentRole: (role) => {
    set((state) => ({
      currentUser: { ...state.currentUser, role },
    }));
    get().addAuditLog(`切换系统操作权限为 [${role}]`, '系统权限模块');
  },

  createCustomer: (data) => {
    const newCust: Customer = {
      id: `cust-${Date.now()}`,
      customerNo: `CUST-2026-${Math.floor(1000 + Math.random() * 9000)}`,
      name: data.name,
      idType: data.type === CustomerType.CORPORATE ? '统一社会信用代码' : '居民身份证',
      idNoMasked: data.idNo.length > 8 ? `${data.idNo.slice(0, 4)}****${data.idNo.slice(-4)}` : data.idNo,
      type: data.type,
      phoneMasked: data.phone.length === 11 ? `${data.phone.slice(0, 3)}****${data.phone.slice(-4)}` : data.phone,
      email: data.email,
      address: data.address,
      level: 'STANDARD',
      riskLevel: CustomerRiskLevel.LOW,
      relationshipManager: data.relationshipManager || '未指定',
      branchName: data.branchName || '华盛银行总行营业部',
      createdDate: new Date().toISOString().split('T')[0],
      accountCount: 0,
      totalDeposit: 0,
      totalLoan: 0,
      totalCreditLimit: 500000,
      usedCreditLimit: 0,
      cardCount: 0,
      status: 'ACTIVE',
    };

    set((state) => ({
      customers: [newCust, ...state.customers],
    }));

    get().addAuditLog(`建档新客户 [${newCust.name}] 编号: ${newCust.customerNo}`, '客户360°中心');
    return newCust;
  },

  openAccount: (data) => {
    const cust = get().customers.find((c) => c.id === data.customerId);
    const customerName = cust ? cust.name : '未知客户';
    const accNo = `622848${Math.floor(10000000 + Math.random() * 90000000)}`;

    const rate = data.type === AccountType.TERM_DEPOSIT ? 2.35 : data.type === AccountType.CORPORATE_SETTLEMENT ? 1.35 : 0.25;

    const newAcc: Account = {
      id: `acc-${Date.now()}`,
      accountNo: accNo,
      customerId: data.customerId,
      customerName,
      type: data.type,
      currency: data.currency,
      bookBalance: data.initialDeposit,
      frozenAmount: 0,
      pendingAmount: 0,
      availableBalance: data.initialDeposit,
      interestRate: rate,
      status: 'NORMAL',
      openDate: new Date().toISOString().split('T')[0],
      branchName: cust?.branchName || '华盛银行总行营业部',
    };

    set((state) => ({
      accounts: [newAcc, ...state.accounts],
      customers: state.customers.map((c) =>
        c.id === data.customerId
          ? { ...c, accountCount: c.accountCount + 1, totalDeposit: c.totalDeposit + data.initialDeposit }
          : c
      ),
    }));

    get().addAuditLog(`开立新账户 [${accNo}] 初始金额: ¥${data.initialDeposit.toLocaleString()}`, '账户核心');

    if (data.initialDeposit > 0) {
      get().depositMoney(accNo, data.initialDeposit, '账户开户初始开户存入');
    }

    return newAcc;
  },

  depositMoney: (accountNo, amount, remark = '存款入账') => {
    const acc = get().accounts.find((a) => a.accountNo === accountNo);
    if (!acc) return { success: false, message: '找不到了指定的账户号码' };

    const txnNo = `TXN2026${Date.now().toString().slice(-7)}`;
    const ledgerRes = CoreLedgerEngine.postTransaction({
      txnNo,
      sourceAccountNo: '1001001',
      sourceAccountName: '华盛银行现金库存',
      targetAccountNo: acc.accountNo,
      targetAccountName: acc.customerName,
      amount,
      currency: acc.currency,
      txnType: TransactionType.DEPOSIT,
      operator: get().currentUser.fullName,
      remark,
    });

    if (!ledgerRes.success) return { success: false, message: ledgerRes.message };

    const newTxn: Transaction = {
      id: `txn-${Date.now()}`,
      txnNo,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
      sourceAccountNo: '1001001',
      sourceAccountName: '华盛银行现金库存',
      targetAccountNo: acc.accountNo,
      targetAccountName: acc.customerName,
      amount,
      currency: acc.currency,
      type: TransactionType.DEPOSIT,
      channel: 'TELLER',
      status: 'SUCCESS',
      riskCheckPassed: true,
      operator: get().currentUser.fullName,
      remark,
      ledgerEntries: ledgerRes.entries,
    };

    set((state) => ({
      accounts: state.accounts.map((a) =>
        a.accountNo === accountNo
          ? {
              ...a,
              bookBalance: Math.round((a.bookBalance + amount) * 100) / 100,
              availableBalance: Math.round((a.availableBalance + amount) * 100) / 100,
            }
          : a
      ),
      transactions: [newTxn, ...state.transactions],
      generalLedger: state.generalLedger.map((gl) => {
        if (gl.code === '1001') return { ...gl, debitBalance: gl.debitBalance + amount };
        if (gl.code === '2001') return { ...gl, creditBalance: gl.creditBalance + amount };
        return gl;
      }),
    }));

    get().addAuditLog(`账户 [${accountNo}] 成功存入 ¥${amount.toLocaleString()}`, '交易引擎');
    return { success: true, message: '存款入账成功', txn: newTxn };
  },

  transferMoney: ({ sourceAccountNo, targetAccountNo, amount, remark, idempotencyKey }) => {
    const sourceAcc = get().accounts.find((a) => a.accountNo === sourceAccountNo);
    const targetAcc = get().accounts.find((a) => a.accountNo === targetAccountNo);

    if (!sourceAcc) return { success: false, message: '出账账户不存在' };
    if (!targetAcc) return { success: false, message: '入账账户不存在' };
    if (sourceAcc.accountNo === targetAcc.accountNo) return { success: false, message: '出账与入账账户不能相同' };

    if (sourceAcc.availableBalance < amount) {
      return { success: false, message: `余额不足！可用余额 ¥${sourceAcc.availableBalance.toLocaleString()} < 汇款金额 ¥${amount.toLocaleString()}` };
    }

    // 额度与风控检查
    if (amount > 5000000) {
      get().addAuditLog(`大额转账触发合规预警 ¥${amount.toLocaleString()}`, '风控引擎', 'BLOCKED');
      set((state) => ({
        riskAlerts: [
          {
            id: `risk-${Date.now()}`,
            alertNo: `ALERT-${Date.now()}`,
            category: 'AML_SUSPICIOUS',
            severity: 'HIGH',
            targetName: sourceAcc.customerName,
            description: `账户 [${sourceAccountNo}] 发起超大额汇款 ¥${amount.toLocaleString()}，暂扣并进入人工二次审核。`,
            triggeredAt: new Date().toISOString().replace('T', ' ').slice(0, 19),
            status: 'PENDING_INVESTIGATION',
            suggestedAction: '核验汇款事由及受款人资质。',
          },
          ...state.riskAlerts,
        ],
      }));
    }

    const txnNo = `TXN2026${Date.now().toString().slice(-7)}`;
    const ledgerRes = CoreLedgerEngine.postTransaction({
      txnNo,
      sourceAccountNo: sourceAcc.accountNo,
      sourceAccountName: sourceAcc.customerName,
      targetAccountNo: targetAcc.accountNo,
      targetAccountName: targetAcc.customerName,
      amount,
      currency: sourceAcc.currency,
      txnType: TransactionType.TRANSFER_OUT,
      operator: get().currentUser.fullName,
      idempotencyKey,
      remark,
    });

    if (!ledgerRes.success) return { success: false, message: ledgerRes.message };

    const newTxn: Transaction = {
      id: `txn-${Date.now()}`,
      txnNo,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
      sourceAccountNo: sourceAcc.accountNo,
      sourceAccountName: sourceAcc.customerName,
      targetAccountNo: targetAcc.accountNo,
      targetAccountName: targetAcc.customerName,
      amount,
      currency: sourceAcc.currency,
      type: TransactionType.TRANSFER_OUT,
      channel: 'ONLINE_BANK',
      status: 'SUCCESS',
      idempotencyKey,
      riskCheckPassed: true,
      operator: get().currentUser.fullName,
      remark,
      ledgerEntries: ledgerRes.entries,
    };

    set((state) => ({
      accounts: state.accounts.map((a) => {
        if (a.accountNo === sourceAccountNo) {
          return {
            ...a,
            bookBalance: Math.round((a.bookBalance - amount) * 100) / 100,
            availableBalance: Math.round((a.availableBalance - amount) * 100) / 100,
          };
        }
        if (a.accountNo === targetAccountNo) {
          return {
            ...a,
            bookBalance: Math.round((a.bookBalance + amount) * 100) / 100,
            availableBalance: Math.round((a.availableBalance + amount) * 100) / 100,
          };
        }
        return a;
      }),
      transactions: [newTxn, ...state.transactions],
    }));

    get().addAuditLog(`转账成功: [${sourceAccountNo}] -> [${targetAccountNo}] 金额: ¥${amount.toLocaleString()}`, '核心账本');
    return { success: true, message: '转账成功，双方实时账本与余额更新完成', txn: newTxn };
  },

  applyAndApproveLoan: (req) => {
    const loanNo = `LOAN2026${Math.floor(10000 + Math.random() * 90000)}`;

    // 生成还款计划表 (以等额本息/等额本金计算)
    const schedules: RepaymentPlanItem[] = [];
    const monthlyRate = req.interestRate / 100 / 12;
    let remainingPrincipal = req.approvedAmount;

    // 简单计算第一期
    const monthlyPrincipal = Math.round((req.approvedAmount / req.termMonths) * 100) / 100;
    for (let i = 1; i <= Math.min(req.termMonths, 12); i++) {
      const interest = Math.round(remainingPrincipal * monthlyRate * 100) / 100;
      const totalDue = Math.round((monthlyPrincipal + interest) * 100) / 100;
      remainingPrincipal = Math.max(0, Math.round((remainingPrincipal - monthlyPrincipal) * 100) / 100);

      const dueDate = new Date();
      dueDate.setMonth(dueDate.getMonth() + i);

      schedules.push({
        periodNo: i,
        dueDate: dueDate.toISOString().split('T')[0],
        principalAmount: monthlyPrincipal,
        interestAmount: interest,
        totalDue,
        remainingPrincipal,
        status: i === 1 ? 'PENDING' : 'PENDING',
      });
    }

    const newLoan: Loan = {
      id: `loan-${Date.now()}`,
      loanNo,
      customerName: req.customerName,
      productType: req.productType,
      approvedAmount: req.approvedAmount,
      balanceAmount: req.approvedAmount,
      interestRate: req.interestRate,
      termMonths: req.termMonths,
      repaymentMethod: req.repaymentMethod,
      disbursementDate: new Date().toISOString().split('T')[0],
      riskClass: 'NORMAL',
      status: LoanStatus.DISBURSED,
      collateralDescription: req.collateralDescription || '信用/保证',
      collateralValue: req.collateralValue || 0,
      schedules,
    };

    set((state) => ({
      loans: [newLoan, ...state.loans],
      generalLedger: state.generalLedger.map((gl) => (gl.code === '1301' ? { ...gl, debitBalance: gl.debitBalance + req.approvedAmount } : gl)),
    }));

    // 若指定发放账户，打款入账
    if (req.disburseToAccountNo) {
      get().depositMoney(req.disburseToAccountNo, req.approvedAmount, `贷款发放入账 (${loanNo})`);
    }

    get().addAuditLog(`信贷审批放款 [${loanNo}] 客户: ${req.customerName} 金额: ¥${req.approvedAmount.toLocaleString()}`, '贷款核心系统');
    return newLoan;
  },

  repayLoanPeriod: (loanId, accountNo) => {
    const loan = get().loans.find((l) => l.id === loanId);
    const acc = get().accounts.find((a) => a.accountNo === accountNo);

    if (!loan) return { success: false, message: '贷款记录不存在' };
    if (!acc) return { success: false, message: '扣款账户不存在' };

    const firstPending = loan.schedules.find((s) => s.status === 'PENDING');
    if (!firstPending) return { success: false, message: '当前贷款无待还款期次' };

    if (acc.availableBalance < firstPending.totalDue) {
      return { success: false, message: `账户余额不足！需要 ¥${firstPending.totalDue.toLocaleString()}，可用 ¥${acc.availableBalance.toLocaleString()}` };
    }

    // 执行扣款
    set((state) => ({
      accounts: state.accounts.map((a) =>
        a.accountNo === accountNo
          ? {
              ...a,
              bookBalance: Math.round((a.bookBalance - firstPending.totalDue) * 100) / 100,
              availableBalance: Math.round((a.availableBalance - firstPending.totalDue) * 100) / 100,
            }
          : a
      ),
      loans: state.loans.map((l) => {
        if (l.id === loanId) {
          const newBal = Math.max(0, Math.round((l.balanceAmount - firstPending.principalAmount) * 100) / 100);
          return {
            ...l,
            balanceAmount: newBal,
            status: newBal === 0 ? LoanStatus.CLEARED : l.status,
            schedules: l.schedules.map((s) => (s.periodNo === firstPending.periodNo ? { ...s, status: 'PAID' } : s)),
          };
        }
        return l;
      }),
      generalLedger: state.generalLedger.map((gl) => {
        if (gl.code === '1301') return { ...gl, debitBalance: gl.debitBalance - firstPending.principalAmount };
        if (gl.code === '4001') return { ...gl, creditBalance: gl.creditBalance + firstPending.interestAmount };
        return gl;
      }),
    }));

    get().addAuditLog(`贷款还款扣款成功 [${loan.loanNo}] 第 ${firstPending.periodNo} 期 金额: ¥${firstPending.totalDue.toLocaleString()}`, '贷款核心系统');
    return { success: true, message: `第 ${firstPending.periodNo} 期贷款还款成功，还款金额 ¥${firstPending.totalDue.toLocaleString()}` };
  },

  triggerEODProcessing: async () => {
    set((state) => ({
      systemMetrics: { ...state.systemMetrics, eodStatus: 'PROCESSING', eodProgressPercent: 10 },
    }));

    get().addAuditLog('启动核心银行日终批处理 (End-Of-Day)', '日终系统');

    await new Promise((r) => setTimeout(r, 600));
    set((state) => ({ systemMetrics: { ...state.systemMetrics, eodProgressPercent: 40 } }));

    // 每日计息与总账平账计算
    await new Promise((r) => setTimeout(r, 600));
    set((state) => ({ systemMetrics: { ...state.systemMetrics, eodProgressPercent: 80 } }));

    await new Promise((r) => setTimeout(r, 600));
    set((state) => ({
      systemMetrics: { ...state.systemMetrics, eodStatus: 'COMPLETED', eodProgressPercent: 100 },
    }));

    get().addAuditLog('日终批处理顺利完成：利息结转、试算平衡及监管日报生成完毕', '日终系统');
  },

  addAuditLog: (action, targetObject, result = 'SUCCESS') => {
    const newLog: AuditLog = {
      id: `audit-${Date.now()}`,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
      username: get().currentUser.username,
      role: get().currentUser.role,
      action,
      targetObject,
      ipAddress: '10.200.8.88',
      result,
    };

    set((state) => ({
      auditLogs: [newLog, ...state.auditLogs.slice(0, 100)],
    }));
  },
}));
