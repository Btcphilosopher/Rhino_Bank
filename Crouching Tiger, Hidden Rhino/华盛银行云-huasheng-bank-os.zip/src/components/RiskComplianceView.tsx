import React, { useState } from 'react';
import { ShieldAlert, Lock, AlertTriangle, CheckCircle2, Play, Activity } from 'lucide-react';
import { useBankStore } from '../services/bankStore';

export const RiskComplianceView: React.FC = () => {
  const { riskAlerts, addAuditLog } = useBankStore();

  const [stressRate, setStressRate] = useState(10);
  const [stressResult, setStressResult] = useState<{ car: number; lcr: number; msg: string } | null>(null);

  const runStressTest = () => {
    // 简单模拟压力测试模型
    const newCar = Math.round((14.8 - stressRate * 0.25) * 100) / 100;
    const newLcr = Math.round((148.5 - stressRate * 2.8) * 100) / 100;
    setStressResult({
      car: newCar,
      lcr: newLcr,
      msg: `情景假设：全行客户存款发生 ${stressRate}% 极端流失。测算资本充足率 (CAR) 为 ${newCar}%，流动性覆盖率 (LCR) 为 ${newLcr}%。系统满足巴塞尔协议 III 缓冲标准。`,
    });
    addAuditLog(`运行资本与流动性压力测试 (${stressRate}% 存款流失)`, '风险与合规引擎');
  };

  return (
    <div className="space-y-6">
      {/* 页头 */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 text-white flex flex-wrap items-center justify-between shadow">
        <div>
          <h1 className="text-xl font-bold flex items-center space-x-2">
            <Lock className="w-5 h-5 text-rose-400" />
            <span>风险、合规与反洗钱 (AML & Risk Engine)</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            大额交易监测、异常频繁划转预警、巴塞尔协议 III 资本充足率与流动性压力测试
          </p>
        </div>
      </div>

      {/* 风险预警列表 */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 text-white shadow space-y-4">
        <h3 className="font-bold text-sm text-slate-100 border-b border-slate-800 pb-2 flex items-center space-x-2">
          <ShieldAlert className="w-4 h-4 text-rose-400" />
          <span>实时反洗钱与交易合规预警事件列 (Live AML & Fraud Alerts)</span>
        </h3>

        <div className="space-y-3">
          {riskAlerts.map((alert) => (
            <div key={alert.id} className="p-4 rounded-lg bg-slate-950 border border-rose-900/60 text-xs space-y-2">
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                <div className="flex items-center space-x-2">
                  <span className="font-mono text-rose-400 font-bold">{alert.alertNo}</span>
                  <span className="px-2 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800 text-[10px]">
                    {alert.category}
                  </span>
                  <span className="text-slate-400">{alert.triggeredAt}</span>
                </div>
                <span className="px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800 text-[10px]">
                  {alert.status}
                </span>
              </div>

              <div className="font-bold text-slate-200">预警对象: {alert.targetName}</div>
              <p className="text-slate-300 leading-relaxed">{alert.description}</p>
              <div className="p-2 rounded bg-slate-900 text-amber-300 text-[11px] font-mono">
                处置建议: {alert.suggestedAction}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 情景压力测试模拟器 (Stress Test) */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 text-white shadow space-y-4">
        <h3 className="font-bold text-sm text-slate-100 border-b border-slate-800 pb-2 flex items-center space-x-2">
          <Activity className="w-4 h-4 text-cyan-400" />
          <span>全行流动性与资本充足率极端压力测试实验室 (Scenario Stress Testing)</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div>
            <label className="block text-slate-400 mb-1">假定全行存款瞬间流失比例 (%)</label>
            <input
              type="number"
              min="1"
              max="50"
              value={stressRate}
              onChange={(e) => setStressRate(parseFloat(e.target.value) || 0)}
              className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-slate-100 font-mono font-bold"
            />
          </div>

          <div className="md:col-span-2 flex items-end">
            <button
              onClick={runStressTest}
              className="w-full py-2.5 rounded bg-rose-600 hover:bg-rose-500 text-white font-bold flex items-center justify-center space-x-2"
            >
              <Play className="w-4 h-4" />
              <span>运行资产负债极端情景压力测试</span>
            </button>
          </div>
        </div>

        {stressResult && (
          <div className="p-4 rounded-lg bg-slate-950 border border-cyan-800 text-xs text-cyan-200 space-y-2">
            <div className="font-bold text-slate-100">压力测试演算结果:</div>
            <p className="text-slate-300">{stressResult.msg}</p>
            <div className="flex space-x-6 font-mono font-bold pt-1 text-sm">
              <span>资本充足率 CAR: <strong className="text-emerald-400">{stressResult.car}%</strong> (监管≥10.5%)</span>
              <span>流动性覆盖率 LCR: <strong className="text-cyan-300">{stressResult.lcr}%</strong> (监管≥100%)</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
