import React from 'react';
import {
  Building2,
  ShieldCheck,
  Cpu,
  Bot,
  PlayCircle,
  Activity,
  UserCheck,
  Lock,
  Layers,
  ChevronRight,
} from 'lucide-react';
import { useBankStore } from '../services/bankStore';
import { BankUser } from '../types';

interface HeaderNavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenAIAssistant: () => void;
  onRunDemoFlow: () => void;
}

export const NAV_ITEMS = [
  { id: 'cockpit', label: '运营驾驶舱', icon: Activity },
  { id: 'customers', label: '客户360°', icon: UserCheck },
  { id: 'accounts', label: '账户中心', icon: Building2 },
  { id: 'ledger', label: '核心账本', icon: Layers },
  { id: 'transactions', label: '交易引擎', icon: PlayCircle },
  { id: 'deposits', label: '存款利息', icon: Building2 },
  { id: 'payments', label: '支付编排', icon: ShieldCheck },
  { id: 'cards', label: '银行卡', icon: Building2 },
  { id: 'loans', label: '贷款授信', icon: ShieldCheck },
  { id: 'corporate', label: '企业银行', icon: Building2 },
  { id: 'treasury', label: '资金外汇', icon: Cpu },
  { id: 'risk', label: '风控合规', icon: Lock },
  { id: 'accounting', label: '总账财务', icon: Layers },
  { id: 'teller', label: '网点柜面', icon: Building2 },
  { id: 'twin', label: '孪生模拟', icon: Cpu },
  { id: 'bocc', label: '运营控制台', icon: Activity },
];

export const HeaderNavbar: React.FC<HeaderNavbarProps> = ({
  activeTab,
  setActiveTab,
  onOpenAIAssistant,
  onRunDemoFlow,
}) => {
  const { currentUser, setCurrentRole, systemMetrics } = useBankStore();

  const handleRoleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setCurrentRole(e.target.value as BankUser['role']);
  };

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-40 shadow-xl select-none">
      {/* 顶部主状态条 */}
      <div className="max-w-[1700px] mx-auto px-4 py-2.5 flex flex-wrap items-center justify-between border-b border-slate-800/80 text-xs">
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded bg-blue-600 flex items-center justify-center font-bold text-white text-base shadow-inner border border-blue-400/40">
              华
            </div>
            <div>
              <div className="font-bold text-sm text-slate-100 tracking-wide flex items-center space-x-2">
                <span>华盛银行云</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-blue-900/60 border border-blue-500/40 text-blue-300 font-mono">
                  HUASHENG BANK OS
                </span>
              </div>
              <p className="text-[11px] text-slate-400">企业级银行核心业务与数字金融操作平台</p>
            </div>
          </div>

          <div className="hidden lg:flex items-center space-x-4 pl-6 border-l border-slate-800 text-slate-300">
            <div className="flex items-center space-x-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span>核心状态: <strong className="text-emerald-400">运行正常</strong></span>
            </div>
            <div className="flex items-center space-x-1.5">
              <span>双重记账: <strong className="text-blue-400">借贷平平衡</strong></span>
            </div>
            <div className="flex items-center space-x-1.5 font-mono">
              <span>TPS: <strong className="text-amber-400">{systemMetrics.tps}</strong></span>
            </div>
          </div>
        </div>

        {/* 右侧快捷操作与角色切换 */}
        <div className="flex items-center space-x-3">
          <button
            onClick={onRunDemoFlow}
            className="px-3 py-1.5 rounded bg-amber-600 hover:bg-amber-500 text-white font-medium flex items-center space-x-1.5 shadow-md transition-all border border-amber-400/30 text-xs"
            title="一键演示开户、存款、转账、风控、记账全流程"
          >
            <PlayCircle className="w-4 h-4" />
            <span>执行完整业务流程</span>
          </button>

          <button
            onClick={onOpenAIAssistant}
            className="px-3 py-1.5 rounded bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-medium flex items-center space-x-1.5 shadow-md border border-indigo-400/30 text-xs"
          >
            <Bot className="w-4 h-4 text-cyan-300" />
            <span>华盛智行 AI 助手</span>
          </button>

          <div className="flex items-center space-x-2 pl-3 border-l border-slate-800">
            <span className="text-slate-400 text-[11px]">当前岗位:</span>
            <select
              value={currentUser.role}
              onChange={handleRoleChange}
              className="bg-slate-800 border border-slate-700 text-slate-200 text-xs rounded px-2 py-1 focus:outline-none focus:border-blue-500"
            >
              <option value="SUPER_ADMIN">超级管理员 (行长控制台)</option>
              <option value="TELLER">柜面柜员 (营业部终端)</option>
              <option value="BRANCH_MANAGER">网点主管</option>
              <option value="CREDIT_OFFICER">信贷审批官</option>
              <option value="RISK_ANALYST">风控合规专员</option>
              <option value="AUDITOR">内部审计人员</option>
              <option value="CORPORATE_USER">企业网银用户</option>
            </select>
          </div>
        </div>
      </div>

      {/* 模块导航栏 */}
      <div className="max-w-[1700px] mx-auto px-4 overflow-x-auto scrollbar-none flex items-center space-x-1 py-1.5 text-xs font-medium">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`px-3 py-2 rounded-md flex items-center space-x-1.5 whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-blue-600 text-white font-bold shadow-md'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-white' : 'text-slate-400'}`} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};
