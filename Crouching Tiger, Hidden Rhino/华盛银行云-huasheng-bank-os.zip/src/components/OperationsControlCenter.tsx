import React from 'react';
import { Activity, ShieldCheck, Server, Database, Cpu, Clock } from 'lucide-react';
import { useBankStore } from '../services/bankStore';

export const OperationsControlCenter: React.FC = () => {
  const { systemMetrics, auditLogs } = useBankStore();

  return (
    <div className="space-y-6">
      {/* 页头 */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 text-white flex flex-wrap items-center justify-between shadow">
        <div>
          <h1 className="text-xl font-bold flex items-center space-x-2">
            <Activity className="w-5 h-5 text-emerald-400" />
            <span>银行运营控制中心 (Bank Operations Control Center - BOCC)</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            全行核心网络、分布式数据库、Rust 账本节点与高可靠中间件运维健康大盘
          </p>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs font-mono text-white">
        <div className="p-4 rounded-lg bg-slate-900 border border-slate-800 space-y-1 shadow">
          <div className="text-slate-400 font-sans">全行并发连接数</div>
          <div className="text-xl font-bold text-blue-400">{systemMetrics.activeConnections}</div>
          <div className="text-[10px] text-emerald-400 font-sans">网关负载 24%</div>
        </div>

        <div className="p-4 rounded-lg bg-slate-900 border border-slate-800 space-y-1 shadow">
          <div className="text-slate-400 font-sans">PostgreSQL 核心数据库</div>
          <div className="text-xl font-bold text-emerald-400">{systemMetrics.databaseHealth}</div>
          <div className="text-[10px] text-slate-400 font-sans">读写分离集群稳定</div>
        </div>

        <div className="p-4 rounded-lg bg-slate-900 border border-slate-800 space-y-1 shadow">
          <div className="text-slate-400 font-sans">Rust 双重记账引擎</div>
          <div className="text-xl font-bold text-cyan-300">{systemMetrics.rustLedgerStatus}</div>
          <div className="text-[10px] text-emerald-400 font-sans">零死锁/零漏记</div>
        </div>

        <div className="p-4 rounded-lg bg-slate-900 border border-slate-800 space-y-1 shadow">
          <div className="text-slate-400 font-sans">日终批处理 (EOD) 状态</div>
          <div className="text-xl font-bold text-amber-300">{systemMetrics.eodStatus}</div>
          <div className="text-[10px] text-slate-400 font-sans">准备就绪</div>
        </div>
      </div>
    </div>
  );
};
