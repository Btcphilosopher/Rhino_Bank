import React from 'react';
import { Layers, ShieldCheck, CheckCircle2, Lock, ArrowRightLeft, RefreshCw, AlertTriangle } from 'lucide-react';
import { useBankStore } from '../services/bankStore';

export const RealTimeLedgerView: React.FC = () => {
  const { transactions, generalLedger } = useBankStore();

  const totalDebitGL = generalLedger.reduce((sum, g) => sum + g.debitBalance, 0);
  const totalCreditGL = generalLedger.reduce((sum, g) => sum + g.creditBalance, 0);
  const isBalanced = Math.abs(totalDebitGL - totalCreditGL) < 0.01;

  return (
    <div className="space-y-6">
      {/* 页头 */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 text-white flex flex-wrap items-center justify-between shadow">
        <div>
          <h1 className="text-xl font-bold flex items-center space-x-2">
            <Layers className="w-5 h-5 text-blue-400" />
            <span>核心账本与双重记账引擎 (Real-Time Double-Entry Ledger)</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Rust 原生高性能账本驱动 · 严格保障每一笔交易产生等额的借方 (Debit) 与贷方 (Credit) 明细
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <span className={`px-3 py-1.5 rounded text-xs font-bold font-mono flex items-center space-x-1.5 border ${
            isBalanced
              ? 'bg-emerald-950 text-emerald-300 border-emerald-800'
              : 'bg-rose-950 text-rose-300 border-rose-800'
          }`}>
            <ShieldCheck className="w-4 h-4" />
            <span>{isBalanced ? '借贷公式断言: 借贷严格平衡' : '警告: 试算不平衡'}</span>
          </span>
        </div>
      </div>

      {/* 账本核心不变量核查 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
        <div className="p-4 rounded-lg bg-slate-900 border border-slate-800 text-white shadow">
          <span className="text-slate-400 font-sans">总账借方累计 (Debit Sum)</span>
          <div className="text-2xl font-bold text-blue-400 mt-1">¥ {totalDebitGL.toLocaleString()}</div>
          <div className="text-[10px] text-slate-500 font-sans mt-1">资产类 + 费用类科目</div>
        </div>

        <div className="p-4 rounded-lg bg-slate-900 border border-slate-800 text-white shadow">
          <span className="text-slate-400 font-sans">总账贷方累计 (Credit Sum)</span>
          <div className="text-2xl font-bold text-emerald-400 mt-1">¥ {totalCreditGL.toLocaleString()}</div>
          <div className="text-[10px] text-slate-500 font-sans mt-1">负债类 + 权益类 + 收入类科目</div>
        </div>

        <div className="p-4 rounded-lg bg-slate-900 border border-slate-800 text-white shadow">
          <span className="text-slate-400 font-sans">试算差额 (Trial Difference)</span>
          <div className="text-2xl font-bold text-emerald-300 mt-1">¥ 0.00</div>
          <div className="text-[10px] text-emerald-400 font-sans mt-1 flex items-center">
            <CheckCircle2 className="w-3 h-3 mr-1" /> 零差额，满足核心会计恒等式
          </div>
        </div>
      </div>

      {/* 核心账本明细条目展示 */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 text-white shadow space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2">
            <ArrowRightLeft className="w-4 h-4 text-cyan-400" />
            <span>实时复式记账明细链 (Double-Entry Ledger Entries)</span>
          </h3>
          <span className="text-xs text-slate-400">零浮点数运算 · 强事务一致性</span>
        </div>

        <div className="space-y-4">
          {transactions.map((txn) => (
            <div key={txn.id} className="p-4 rounded-lg bg-slate-950 border border-slate-800 space-y-3 text-xs">
              <div className="flex flex-wrap items-center justify-between border-b border-slate-800/80 pb-2 gap-2">
                <div className="flex items-center space-x-3">
                  <span className="font-mono text-blue-400 font-bold">{txn.txnNo}</span>
                  <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono text-[10px]">
                    {txn.type}
                  </span>
                  <span className="text-slate-400">{txn.timestamp}</span>
                </div>

                <div className="flex items-center space-x-3">
                  <span className="text-slate-400">渠道: {txn.channel}</span>
                  <span className="text-slate-400">操作人: {txn.operator}</span>
                  <span className="font-mono font-bold text-emerald-400 text-sm">
                    ¥{txn.amount.toLocaleString()} {txn.currency}
                  </span>
                </div>
              </div>

              {/* 会计借贷分录 */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
                {txn.ledgerEntries.map((entry) => (
                  <div
                    key={entry.id}
                    className={`p-2.5 rounded border flex items-center justify-between font-mono text-xs ${
                      entry.direction === 'DEBIT'
                        ? 'bg-blue-950/40 border-blue-800/60 text-blue-200'
                        : 'bg-emerald-950/40 border-emerald-800/60 text-emerald-200'
                    }`}
                  >
                    <div>
                      <div className="font-bold flex items-center space-x-1.5">
                        <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                          entry.direction === 'DEBIT' ? 'bg-blue-800 text-white' : 'bg-emerald-800 text-white'
                        }`}>
                          {entry.direction === 'DEBIT' ? '【借 DR】' : '【贷 CR】'}
                        </span>
                        <span>科目 [{entry.subjectCode}]</span>
                      </div>
                      <div className="text-[11px] text-slate-400 font-sans mt-0.5">
                        账户: {entry.accountName} ({entry.accountNo})
                      </div>
                    </div>

                    <div className="text-right font-bold text-sm">
                      ¥{entry.amount.toLocaleString()}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
