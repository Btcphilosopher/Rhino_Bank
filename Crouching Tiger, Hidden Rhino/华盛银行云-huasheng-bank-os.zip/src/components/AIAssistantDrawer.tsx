import React, { useState } from 'react';
import { Bot, Send, X, Sparkles, ShieldCheck, Loader2 } from 'lucide-react';
import { useBankStore } from '../services/bankStore';

interface AIAssistantProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AIAssistantDrawer: React.FC<AIAssistantProps> = ({ isOpen, onClose }) => {
  const { customers, accounts, loans } = useBankStore();

  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<Array<{ role: 'user' | 'assistant'; content: string; sources?: string[] }>>([
    {
      role: 'assistant',
      content:
        '您好！我是「华盛智行」— 华盛银行核心系统 AI 金融助手。我可以帮助您快速分析客户资金链、检索账本科目平衡性、评估授信风险或协助撰写反洗钱排查报告。请问需要处理什么事项？',
    },
  ]);

  if (!isOpen) return null;

  const handleSend = async (customPrompt?: string) => {
    const textToSend = customPrompt || prompt;
    if (!textToSend.trim() || loading) return;

    const userMsg = { role: 'user' as const, content: textToSend };
    setMessages((prev) => [...prev, userMsg]);
    if (!customPrompt) setPrompt('');
    setLoading(true);

    try {
      const response = await fetch('/api/v1/ai/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: textToSend,
          context: {
            customersCount: customers.length,
            accountsCount: accounts.length,
            loansCount: loans.length,
            sampleCustomer: customers[0]?.name,
          },
        }),
      });

      const data = await response.json();
      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          content: data.answer || '未能从 AI 服务获取分析结果。',
          sources: data.sources,
        },
      ]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          content: '请求处理出现异常，请检查网络或配置。',
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex justify-end">
      <div className="bg-slate-900 border-l border-slate-800 max-w-xl w-full h-full text-white flex flex-col shadow-2xl">
        {/* Drawer 标题 */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center">
              <Bot className="w-4 h-4 text-cyan-300" />
            </div>
            <div>
              <h2 className="font-bold text-sm text-slate-100 flex items-center space-x-2">
                <span>华盛智行 AI 助手</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 font-mono">
                  GEMINI 3.8 FLASH
                </span>
              </h2>
              <p className="text-[11px] text-slate-400">银行级智能诊断 · 核心数据合规脱敏</p>
            </div>
          </div>

          <button onClick={onClose} className="p-1 rounded text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 快捷问答提示词 */}
        <div className="p-3 bg-slate-900/90 border-b border-slate-800 flex flex-wrap gap-2 text-xs">
          {[
            '分析华为公司现金流',
            '检查核心账本试算平衡',
            '测算存款流失 20% LCR',
            '生成 AML 反洗钱排查报告',
          ].map((chip) => (
            <button
              key={chip}
              onClick={() => handleSend(chip)}
              className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] border border-slate-700 transition"
            >
              {chip}
            </button>
          ))}
        </div>

        {/* 消息历史列表 */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs">
          {messages.map((m, index) => (
            <div
              key={index}
              className={`flex items-start space-x-3 ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {m.role === 'assistant' && (
                <div className="w-7 h-7 rounded bg-blue-600 flex items-center justify-center shrink-0 mt-0.5">
                  <Bot className="w-3.5 h-3.5 text-white" />
                </div>
              )}

              <div
                className={`p-3.5 rounded-xl max-w-[85%] whitespace-pre-wrap leading-relaxed ${
                  m.role === 'user'
                    ? 'bg-blue-600 text-white font-medium rounded-tr-none shadow'
                    : 'bg-slate-950 border border-slate-800 text-slate-200 rounded-tl-none shadow'
                }`}
              >
                {m.content}
                {m.sources && (
                  <div className="mt-2 pt-2 border-t border-slate-800 text-[10px] text-slate-400 flex flex-wrap gap-1">
                    <span>数据依据:</span>
                    {m.sources.map((s) => (
                      <span key={s} className="px-1.5 py-0.5 bg-slate-800 rounded font-mono">
                        {s}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex items-center space-x-2 text-slate-400 text-xs">
              <Loader2 className="w-4 h-4 animate-spin text-blue-400" />
              <span>华盛智行正在调取核心账本与风控模型进行深度分析...</span>
            </div>
          )}
        </div>

        {/* 输入框 */}
        <div className="p-3 bg-slate-950 border-t border-slate-800">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex items-center space-x-2"
          >
            <input
              type="text"
              placeholder="请输入您对核心账本、客户授信或风险合规的提问..."
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              className="flex-1 bg-slate-900 border border-slate-800 rounded-lg px-3.5 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
            <button
              type="submit"
              disabled={loading || !prompt.trim()}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded-lg font-bold text-xs flex items-center space-x-1"
            >
              <Send className="w-3.5 h-3.5" />
              <span>发送</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
