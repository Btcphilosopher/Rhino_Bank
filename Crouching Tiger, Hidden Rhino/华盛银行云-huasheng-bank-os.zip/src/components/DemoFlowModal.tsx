import React, { useState } from 'react';
import { PlayCircle, CheckCircle2, ArrowRight, Loader2, X, Sparkles, Layers, ShieldCheck } from 'lucide-react';
import { useBankStore } from '../services/bankStore';
import { CustomerType, AccountType } from '../types';

interface DemoFlowModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DemoFlowModal: React.FC<DemoFlowModalProps> = ({ isOpen, onClose }) => {
  const { createCustomer, openAccount, depositMoney, transferMoney, accounts } = useBankStore();

  const [currentStep, setCurrentStep] = useState<number>(0);
  const [running, setRunning] = useState<boolean>(false);
  const [logs, setLogs] = useState<string[]>([]);

  if (!isOpen) return null;

  const STEPS = [
    { title: '1. 登录与身份鉴权', desc: '管理员超级权限控制台进入' },
    { title: '2. 客户 KYC 档案建档', desc: '创建企业客户【华盛科创集团有限公司】' },
    { title: '3. 核心开户与账号生成', desc: '开立企业活期结算账户，绑定利息规则' },
    { title: '4. 柜面现金/资本金存入', desc: '入账存入 ¥50,000,000.00 初始注册资金' },
    { title: '5. 复式记账科目挂账', desc: '触发 Rust 核心账本，产生 DR 1001 / CR 2001' },
    { title: '6. 发起供应链跨行划转', desc: '汇划转账 ¥10,000,000.00 至华为技术有限公司' },
    { title: '7. 额度与 AML 反洗钱风控', desc: '实时校验可用余额与大额转账黑名单规避' },
    { title: '8. 支付编排与央行清算', desc: '通过央行大额 HVPS 完成全额实时扎差清算' },
    { title: '9. 不可篡改审计链入库', desc: '记录加密审计日志，提供全局穿透追溯' },
    { title: '10. 全行驾驶舱大盘刷新', desc: '资产负债与试算平衡表实时秒级更新完成' },
  ];

  const runFullPipeline = async () => {
    setRunning(true);
    setLogs([]);
    setCurrentStep(1);

    // Step 1: Login
    setLogs((p) => [...p, '【步骤 1/10】登录成功: 用户 [admin_master] 超级管理员权限激活']);
    await new Promise((r) => setTimeout(r, 600));

    // Step 2: Customer
    setCurrentStep(2);
    const newCust = createCustomer({
      name: '华盛科创集团有限公司',
      type: CustomerType.CORPORATE,
      idNo: '91440300MA5FB12345',
      phone: '13800009999',
      email: 'finance@huasheng-tech.com',
      address: '深圳市南山区科技园华盛金融大厦A座',
      relationshipManager: '王行长',
      branchName: '华盛银行总行营业部',
    });
    setLogs((p) => [...p, `【步骤 2/10】客户建档完成: [${newCust.name}] 编号: ${newCust.customerNo}`]);
    await new Promise((r) => setTimeout(r, 600));

    // Step 3: Account
    setCurrentStep(3);
    const newAcc = openAccount({
      customerId: newCust.id,
      type: AccountType.CORPORATE_SETTLEMENT,
      currency: 'CNY',
      initialDeposit: 0,
    });
    setLogs((p) => [...p, `【步骤 3/10】核心开户成功: 账号 [${newAcc.accountNo}] 利息率: 1.35%`]);
    await new Promise((r) => setTimeout(r, 600));

    // Step 4 & 5: Deposit & Ledger
    setCurrentStep(4);
    depositMoney(newAcc.accountNo, 50000000, '资本金注入存入');
    setLogs((p) => [...p, `【步骤 4/10】存入资金成功: ¥50,000,000.00`]);
    setCurrentStep(5);
    setLogs((p) => [...p, `【步骤 5/10】复式记账完成: 借:1001库存现金 ¥50M | 贷:2001吸收存款 ¥50M`]);
    await new Promise((r) => setTimeout(r, 600));

    // Step 6, 7, 8: Transfer & Risk & Clearing
    setCurrentStep(6);
    const targetAccNo = accounts[0]?.accountNo || '622848001001';
    setCurrentStep(7);
    const transferRes = transferMoney({
      sourceAccountNo: newAcc.accountNo,
      targetAccountNo: targetAccNo,
      amount: 10000000,
      remark: '供应链货款划拨',
      idempotencyKey: `IDEM-DEMO-${Date.now()}`,
    });
    setCurrentStep(8);
    setLogs((p) => [...p, `【步骤 6-8/10】跨行转账划拨成功: ¥10,000,000.00 -> 华为技术有限公司 (${transferRes.message})`]);
    await new Promise((r) => setTimeout(r, 600));

    // Step 9 & 10: Audit & Refresh
    setCurrentStep(9);
    setLogs((p) => [...p, `【步骤 9/10】不可篡改审计流水日志落盘 (Audit Trail Written)`]);
    setCurrentStep(10);
    setLogs((p) => [...p, `【步骤 10/10】全行试算平衡校验: 借贷差额 = 0.00，全行驾驶舱与资产负债表已刷新!`]);

    setRunning(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-xl max-w-3xl w-full text-white p-6 space-y-6 shadow-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded bg-amber-600 flex items-center justify-center font-bold">
              <PlayCircle className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="font-bold text-base text-slate-100">第一阶段 MVP 核心流程连贯演示</h2>
              <p className="text-xs text-slate-400">登录 → 建档 → 开户 → 存款 → 记账 → 转账 → 风控 → 支付 → 审计 → 分析</p>
            </div>
          </div>

          <button onClick={onClose} className="p-1 rounded text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 步骤图卡 */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs font-mono">
          {STEPS.map((step, idx) => {
            const stepNum = idx + 1;
            const isDone = currentStep > stepNum;
            const isCurrent = currentStep === stepNum;
            return (
              <div
                key={step.title}
                className={`p-2.5 rounded border flex flex-col justify-between transition ${
                  isDone
                    ? 'bg-emerald-950/60 border-emerald-800 text-emerald-300'
                    : isCurrent
                    ? 'bg-amber-950/80 border-amber-500 text-amber-200 animate-pulse'
                    : 'bg-slate-950 border-slate-800 text-slate-500'
                }`}
              >
                <div className="font-bold text-[11px] truncate">{step.title}</div>
                <div className="text-[9px] mt-1 text-slate-400 truncate">{step.desc}</div>
              </div>
            );
          })}
        </div>

        {/* 交互按钮 */}
        <div className="flex justify-center">
          <button
            onClick={runFullPipeline}
            disabled={running}
            className="px-6 py-3 rounded-lg bg-amber-600 hover:bg-amber-500 text-white font-bold text-sm shadow-xl flex items-center space-x-2 disabled:opacity-50 transition"
          >
            {running ? <Loader2 className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5" />}
            <span>{running ? '连贯业务全流程自动跑通中...' : '点击启动全流程连贯演示 (Execute Full Flow)'}</span>
          </button>
        </div>

        {/* 日志输出区 */}
        <div className="p-4 rounded-lg bg-slate-950 border border-slate-800 font-mono text-xs space-y-1.5 max-h-48 overflow-y-auto">
          <div className="text-slate-400 text-[10px] border-b border-slate-800/80 pb-1 flex justify-between">
            <span>核心运行控制台日志 (Core Terminal Output)</span>
            <span>STATUS: {currentStep === 10 ? 'COMPLETED' : running ? 'RUNNING' : 'READY'}</span>
          </div>
          {logs.length === 0 ? (
            <p className="text-slate-600 italic">点击上方按钮，即可一键连贯体验创建客户、开户存入、5000万记账与1000万转账等完整流程。</p>
          ) : (
            logs.map((log, i) => (
              <div key={i} className="text-emerald-400 text-[11px]">
                {log}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
