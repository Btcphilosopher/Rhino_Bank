import React, { useState } from 'react';
import { Building2, Smartphone, Monitor, CheckCircle2, PlayCircle, DollarSign, Send } from 'lucide-react';
import { useBankStore } from '../services/bankStore';

export const BranchAndDigitalView: React.FC = () => {
  const { accounts, depositMoney } = useBankStore();

  const [channel, setChannel] = useState<'TELLER' | 'MOBILE'>('TELLER');
  const [selectedAcc, setSelectedAcc] = useState(accounts[0]?.accountNo || '');
  const [amount, setAmount] = useState(10000);
  const [msg, setMsg] = useState('');

  const handleTellerDeposit = (e: React.FormEvent) => {
    e.preventDefault();
    const res = depositMoney(selectedAcc, amount, '柜面存入现金');
    setMsg(res.message);
  };

  return (
    <div className="space-y-6">
      {/* 页头 */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 text-white flex flex-wrap items-center justify-between shadow">
        <div>
          <h1 className="text-xl font-bold flex items-center space-x-2">
            <Building2 className="w-5 h-5 text-blue-400" />
            <span>网点柜面终端与数字/手机银行 preview</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            提供标准柜面高拍仪与身份证验真集成模拟，以及个人/企业手机银行极简响应式终端
          </p>
        </div>

        <div className="flex border border-slate-800 rounded bg-slate-950 p-1 text-xs">
          <button
            onClick={() => setChannel('TELLER')}
            className={`px-3 py-1 rounded flex items-center space-x-1.5 transition ${
              channel === 'TELLER' ? 'bg-blue-600 text-white font-bold' : 'text-slate-400'
            }`}
          >
            <Monitor className="w-3.5 h-3.5" />
            <span>网点柜面终端 (Teller)</span>
          </button>

          <button
            onClick={() => setChannel('MOBILE')}
            className={`px-3 py-1 rounded flex items-center space-x-1.5 transition ${
              channel === 'MOBILE' ? 'bg-blue-600 text-white font-bold' : 'text-slate-400'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>手机银行 Preview</span>
          </button>
        </div>
      </div>

      {channel === 'TELLER' ? (
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-6 text-white shadow space-y-4 max-w-2xl">
          <h3 className="font-bold text-sm text-slate-100 border-b border-slate-800 pb-2">
            柜员008号操作终端 - 现金存入
          </h3>

          <form onSubmit={handleTellerDeposit} className="space-y-4 text-xs">
            <div>
              <label className="block text-slate-400 mb-1">存款账户号</label>
              <select
                value={selectedAcc}
                onChange={(e) => setSelectedAcc(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-slate-200 font-mono"
              >
                {accounts.map((a) => (
                  <option key={a.id} value={a.accountNo}>
                    {a.customerName} - {a.accountNo}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-400 mb-1">点钞面额现金（RMB）</label>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(parseFloat(e.target.value) || 0)}
                className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-slate-100 font-mono font-bold"
              />
            </div>

            <button type="submit" className="w-full py-2.5 rounded bg-blue-600 hover:bg-blue-500 font-bold text-xs">
              柜面记账并打理小票打印
            </button>
          </form>

          {msg && (
            <div className="p-3 rounded bg-emerald-950 border border-emerald-800 text-emerald-200 text-xs flex items-center space-x-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>{msg}</span>
            </div>
          )}
        </div>
      ) : (
        <div className="max-w-sm mx-auto bg-slate-950 border-4 border-slate-800 rounded-3xl p-4 text-white shadow-2xl space-y-4">
          <div className="w-20 h-4 bg-slate-800 rounded-full mx-auto"></div>
          <div className="text-center font-bold text-sm text-slate-200 border-b border-slate-800 pb-2">
            华盛银行 手机 App
          </div>

          <div className="p-4 rounded-xl bg-gradient-to-r from-blue-700 to-indigo-700 space-y-1">
            <span className="text-[10px] text-blue-200">总资产 (元)</span>
            <div className="text-2xl font-bold font-mono">¥ 850,000.00</div>
            <div className="text-[10px] text-blue-200">活期 / 定期组合存储</div>
          </div>

          <div className="grid grid-cols-3 gap-2 text-center text-xs">
            <div className="p-3 rounded bg-slate-900 border border-slate-800">
              <Send className="w-4 h-4 text-blue-400 mx-auto mb-1" />
              <span>转账</span>
            </div>
            <div className="p-3 rounded bg-slate-900 border border-slate-800">
              <DollarSign className="w-4 h-4 text-emerald-400 mx-auto mb-1" />
              <span>理财</span>
            </div>
            <div className="p-3 rounded bg-slate-900 border border-slate-800">
              <Building2 className="w-4 h-4 text-purple-400 mx-auto mb-1" />
              <span>贷款</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
