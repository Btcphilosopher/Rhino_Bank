import React, { useState } from 'react';
import { ShieldCheck, Network, Send, CheckCircle2, RefreshCw, ArrowUpRight, Lock } from 'lucide-react';
import { useBankStore } from '../services/bankStore';

export const PaymentsView: React.FC = () => {
  const { accounts, addAuditLog } = useBankStore();

  const [paymentRail, setPaymentRail] = useState<'HVPS' | 'BEPS' | 'IBPS' | 'CIPS' | 'SWIFT'>('HVPS');
  const [recipientBank, setRecipientBank] = useState('中国工商银行股份有限公司');
  const [recipientAccount, setRecipientAccount] = useState('6222021001008888999');
  const [recipientName, setRecipientName] = useState('中铁建设集团有限公司');
  const [amount, setAmount] = useState(2500000);
  const [submitted, setSubmitted] = useState(false);

  const handleSendPayment = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    addAuditLog(`发起跨行清算支付单 [${paymentRail}] 金额: ¥${amount.toLocaleString()} 接收行: ${recipientBank}`, '支付编排中心');
  };

  return (
    <div className="space-y-6">
      {/* 页头 */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 text-white flex flex-wrap items-center justify-between shadow">
        <div>
          <h1 className="text-xl font-bold flex items-center space-x-2">
            <Network className="w-5 h-5 text-cyan-400" />
            <span>支付清算编排与跨行路由中心 (Payment Routing Hub)</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            连接中国人民银行大额(HVPS)、小额(BEPS)、超级网银(IBPS)、CIPS跨境人民币与SWIFT ISO 20022
          </p>
        </div>
      </div>

      {/* 支付通道状态格 */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 text-xs text-white">
        <div className="p-3.5 rounded bg-slate-900 border border-slate-800 space-y-1 shadow">
          <div className="font-bold text-slate-200">央行大额 HVPS</div>
          <p className="text-[10px] text-emerald-400 font-mono">通道开放 (实时逐笔清算)</p>
        </div>

        <div className="p-3.5 rounded bg-slate-900 border border-slate-800 space-y-1 shadow">
          <div className="font-bold text-slate-200">央行小额 BEPS</div>
          <p className="text-[10px] text-emerald-400 font-mono">通道开放 (批量打包清算)</p>
        </div>

        <div className="p-3.5 rounded bg-slate-900 border border-slate-800 space-y-1 shadow">
          <div className="font-bold text-slate-200">超级网银 IBPS</div>
          <p className="text-[10px] text-emerald-400 font-mono">7x24小时 5万元以下秒到</p>
        </div>

        <div className="p-3.5 rounded bg-slate-900 border border-slate-800 space-y-1 shadow">
          <div className="font-bold text-slate-200">跨境人民币 CIPS</div>
          <p className="text-[10px] text-blue-400 font-mono">直连全额清算</p>
        </div>

        <div className="p-3.5 rounded bg-slate-900 border border-slate-800 space-y-1 shadow">
          <div className="font-bold text-slate-200">SWIFT ISO 20022</div>
          <p className="text-[10px] text-cyan-400 font-mono">pacs.008 报文就续</p>
        </div>
      </div>

      {/* 跨行支付汇划表单 */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-6 text-white shadow space-y-5">
        <h3 className="font-bold text-sm text-slate-100 border-b border-slate-800 pb-3 flex items-center justify-between">
          <span>发起跨行资金汇划订单</span>
          <span className="text-xs text-cyan-300 font-mono">智能最佳清算路由算法激活</span>
        </h3>

        <form onSubmit={handleSendPayment} className="space-y-4 text-xs">
          <div>
            <label className="block text-slate-400 mb-1">清算通道 (Clearing Rail) *</label>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {[
                { id: 'HVPS', name: '大额HVPS' },
                { id: 'BEPS', name: '小额BEPS' },
                { id: 'IBPS', name: '超级网银IBPS' },
                { id: 'CIPS', name: 'CIPS跨境' },
                { id: 'SWIFT', name: 'SWIFT电汇' },
              ].map((rail) => (
                <button
                  type="button"
                  key={rail.id}
                  onClick={() => setPaymentRail(rail.id as any)}
                  className={`p-2.5 rounded border font-medium text-xs transition ${
                    paymentRail === rail.id
                      ? 'bg-cyan-600 border-cyan-400 text-white font-bold shadow'
                      : 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  {rail.name}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-slate-400 mb-1">收款人开户银行 *</label>
              <input
                type="text"
                required
                value={recipientBank}
                onChange={(e) => setRecipientBank(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-slate-200"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1">收款人名称 *</label>
              <input
                type="text"
                required
                value={recipientName}
                onChange={(e) => setRecipientName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-slate-200"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1">收款人账号 *</label>
              <input
                type="text"
                required
                value={recipientAccount}
                onChange={(e) => setRecipientAccount(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-slate-200 font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-400 mb-1">清算汇划金额 (RMB) *</label>
            <input
              type="number"
              required
              value={amount}
              onChange={(e) => setAmount(parseFloat(e.target.value) || 0)}
              className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-slate-100 font-mono font-bold text-base"
            />
          </div>

          <button
            type="submit"
            className="w-full py-3 rounded bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-sm shadow transition flex items-center justify-center space-x-2"
          >
            <Send className="w-4 h-4" />
            <span>提交跨行清算指令至央行网关</span>
          </button>
        </form>

        {submitted && (
          <div className="p-4 rounded-lg bg-emerald-950/60 border border-emerald-800 text-xs text-emerald-200 space-y-2">
            <div className="font-bold flex items-center space-x-2 text-emerald-300">
              <CheckCircle2 className="w-4 h-4" />
              <span>支付清算指令已成功下发 (Clearing Order Dispatched)</span>
            </div>
            <p className="font-mono text-[11px] text-slate-300">
              支付单号: PMT20260917{Math.floor(10000 + Math.random() * 90000)} | 通道: {paymentRail} | 状态: 央行已确认结算
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
