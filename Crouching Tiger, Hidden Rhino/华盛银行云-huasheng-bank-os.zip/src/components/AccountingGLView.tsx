import React from 'react';
import { Layers, ShieldCheck, RefreshCw, CheckCircle2 } from 'lucide-react';
import { useBankStore } from '../services/bankStore';

export const AccountingGLView: React.FC = () => {
  const { generalLedger, systemMetrics, triggerEODProcessing } = useBankStore();

  const totalDebit = generalLedger.reduce((sum, g) => sum + g.debitBalance, 0);
  const totalCredit = generalLedger.reduce((sum, g) => sum + g.creditBalance, 0);

  return (
    <div className="space-y-6">
      {/* 页头 */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 text-white flex flex-wrap items-center justify-between shadow">
        <div>
          <h1 className="text-xl font-bold flex items-center space-x-2">
            <Layers className="w-5 h-5 text-cyan-400" />
            <span>会计总账与试算平衡 (General Ledger & Trial Balance)</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            实时按科目代码汇总资产、负债、权益、收入与费用类账户，自动化日终批处理 (EOD)
          </p>
        </div>

        <button
          onClick={() => triggerEODProcessing()}
          disabled={systemMetrics.eodStatus === 'PROCESSING'}
          className="px-4 py-2 rounded bg-cyan-600 hover:bg-cyan-500 text-white font-medium text-xs flex items-center space-x-2 shadow disabled:opacity-50"
        >
          <RefreshCw className={`w-4 h-4 ${systemMetrics.eodStatus === 'PROCESSING' ? 'animate-spin' : ''}`} />
          <span>{systemMetrics.eodStatus === 'PROCESSING' ? '日终结账计算中...' : '触发核心日终批处理 (EOD)'}</span>
        </button>
      </div>

      {/* 试算平衡表 */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden text-white shadow space-y-4 p-5">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>全行一级会计科目试算平衡表 (General Ledger Trial Balance)</span>
          </h3>
          <span className="text-xs font-mono px-2.5 py-1 bg-emerald-950 text-emerald-300 border border-emerald-800 rounded">
            借贷试算恒等: 0.00 偏差
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono text-slate-300">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
              <tr>
                <th className="p-3">科目代码</th>
                <th className="p-3">科目名称</th>
                <th className="p-3">科目类别</th>
                <th className="p-3">借方发生/余额 (DR)</th>
                <th className="p-3">贷方发生/余额 (CR)</th>
                <th className="p-3 text-right">净余额</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {generalLedger.map((gl) => (
                <tr key={gl.code} className="hover:bg-slate-800/50">
                  <td className="p-3 font-bold text-blue-400">{gl.code}</td>
                  <td className="p-3 font-sans text-slate-100 font-bold">{gl.name}</td>
                  <td className="p-3 font-sans">
                    <span className="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-slate-300">
                      {gl.category}
                    </span>
                  </td>
                  <td className="p-3 font-bold text-blue-400">
                    {gl.debitBalance > 0 ? `¥${gl.debitBalance.toLocaleString()}` : '-'}
                  </td>
                  <td className="p-3 font-bold text-emerald-400">
                    {gl.creditBalance > 0 ? `¥${gl.creditBalance.toLocaleString()}` : '-'}
                  </td>
                  <td className="p-3 text-right text-slate-300 font-bold">
                    ¥{gl.netBalance.toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot className="bg-slate-950 font-bold text-sm border-t border-slate-700">
              <tr>
                <td colSpan={3} className="p-3 text-slate-200 font-sans">合计 (TOTAL TRIAL BALANCE)</td>
                <td className="p-3 text-blue-400">¥{totalDebit.toLocaleString()}</td>
                <td className="p-3 text-emerald-400">¥{totalCredit.toLocaleString()}</td>
                <td className="p-3 text-right text-emerald-300">完全平平衡</td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
  );
};
