import React, { useState } from 'react';
import {
  PlayCircle,
  ArrowRightLeft,
  DollarSign,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Zap,
} from 'lucide-react';
import { useBankStore } from '../services/bankStore';

interface TransactionEngineProps {
  onRunDemoFlow: () => void;
}

export const TransactionEngineView: React.FC<TransactionEngineProps> = ({ onRunDemoFlow }) => {
  const { accounts, depositMoney, transferMoney, transactions } = useBankStore();

  const [activeTab, setActiveTab] = useState<'DEPOSIT' | 'TRANSFER'>('TRANSFER');

  // 存款表单
  const [depositAccNo, setDepositAccNo] = useState(accounts[0]?.accountNo || '');
  const [depositAmount, setDepositAmount] = useState(50000);
  const [depositRemark, setDepositRemark] = useState('柜面现金存入');
  const [depositMessage, setDepositMessage] = useState<{ success: boolean; msg: string } | null>(null);

  // 转账表单
  const [sourceAccNo, setSourceAccNo] = useState(accounts[0]?.accountNo || '');
  const [targetAccNo, setTargetAccNo] = useState(accounts[1]?.accountNo || '');
  const [transferAmount, setTransferAmount] = useState(100000);
  const [transferRemark, setTransferRemark] = useState('供应商货款转账结算');
  const [idempotencyKey, setIdempotencyKey] = useState(`IDEM-${Date.now()}`);
  const [transferResult, setTransferResult] = useState<{ success: boolean; msg: string } | null>(null);

  const handleDepositSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const res = depositMoney(depositAccNo, depositAmount, depositRemark);
    setDepositMessage({ success: res.success, msg: res.message });
  };

  const handleTransferSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const res = transferMoney({
      sourceAccountNo: sourceAccNo,
      targetAccountNo: targetAccNo,
      amount: transferAmount,
      remark: transferRemark,
      idempotencyKey,
    });
    setTransferResult({ success: res.success, msg: res.message });
  };

  const regenerateIdempotencyKey = () => {
    setIdempotencyKey(`IDEM-${Date.now()}`);
  };

  return (
    <div className="space-y-6">
      {/* 页头 */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 text-white flex flex-wrap items-center justify-between shadow">
        <div>
          <h1 className="text-xl font-bold flex items-center space-x-2">
            <PlayCircle className="w-5 h-5 text-amber-400" />
            <span>核心交易引擎与柜面清算</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            强幂等性防重复扣款、高并发强一致性事务锁、大额转账风控实时挂钩
          </p>
        </div>

        <button
          onClick={onRunDemoFlow}
          className="px-4 py-2 rounded bg-amber-600 hover:bg-amber-500 text-white font-medium text-xs flex items-center space-x-2 shadow animate-bounce"
        >
          <Zap className="w-4 h-4" />
          <span>一键演示「第一阶段 MVP 核心流程」</span>
        </button>
      </div>

      {/* 交易类型切换 */}
      <div className="flex border-b border-slate-800 space-x-4 text-xs font-bold">
        <button
          onClick={() => setActiveTab('TRANSFER')}
          className={`pb-3 px-2 flex items-center space-x-2 transition border-b-2 ${
            activeTab === 'TRANSFER'
              ? 'border-blue-500 text-blue-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <ArrowRightLeft className="w-4 h-4" />
          <span>账户转账/汇划 (Transfer)</span>
        </button>

        <button
          onClick={() => setActiveTab('DEPOSIT')}
          className={`pb-3 px-2 flex items-center space-x-2 transition border-b-2 ${
            activeTab === 'DEPOSIT'
              ? 'border-emerald-500 text-emerald-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <DollarSign className="w-4 h-4" />
          <span>柜面存款存入 (Deposit)</span>
        </button>
      </div>

      {/* 转账表单 */}
      {activeTab === 'TRANSFER' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-6 text-white shadow space-y-5">
            <h3 className="font-bold text-sm text-slate-100 border-b border-slate-800 pb-3 flex items-center justify-between">
              <span>发起实时资金转账交易</span>
              <span className="text-xs text-slate-400 font-mono">IDEMPOTENCY ENABLED</span>
            </h3>

            <form onSubmit={handleTransferSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-400 mb-1">付款出账账户 (Source Account) *</label>
                  <select
                    value={sourceAccNo}
                    onChange={(e) => setSourceAccNo(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-slate-200 font-mono"
                  >
                    {accounts.map((a) => (
                      <option key={a.id} value={a.accountNo}>
                        {a.customerName} - {a.accountNo} (可用: ¥{a.availableBalance.toLocaleString()})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">收款入账账户 (Target Account) *</label>
                  <select
                    value={targetAccNo}
                    onChange={(e) => setTargetAccNo(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-slate-200 font-mono"
                  >
                    {accounts.map((a) => (
                      <option key={a.id} value={a.accountNo}>
                        {a.customerName} - {a.accountNo} (账面: ¥{a.bookBalance.toLocaleString()})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-400 mb-1">转账金额 (RMB) *</label>
                  <input
                    type="number"
                    min="1"
                    step="1000"
                    required
                    value={transferAmount}
                    onChange={(e) => setTransferAmount(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-slate-100 font-mono font-bold text-base"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">交易附言 / 事由</label>
                  <input
                    type="text"
                    value={transferRemark}
                    onChange={(e) => setTransferRemark(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-slate-200"
                  />
                </div>
              </div>

              {/* 幂等性 Key 演示控制 */}
              <div className="p-3 rounded bg-slate-950 border border-slate-800 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 font-mono text-[11px]">防重复划款幂等键 (Idempotency Key):</span>
                  <button
                    type="button"
                    onClick={regenerateIdempotencyKey}
                    className="text-[10px] text-blue-400 hover:underline flex items-center space-x-1"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>生成新键</span>
                  </button>
                </div>
                <input
                  type="text"
                  readOnly
                  value={idempotencyKey}
                  className="w-full bg-slate-900 border border-slate-800 text-amber-400 font-mono text-xs rounded p-1.5"
                />
                <p className="text-[10px] text-slate-500">
                  连续点击提交时，相同幂等键将命中核心防重缓存，绝不发生二次扣款。
                </p>
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm shadow transition"
              >
                确认提交核心记账并划拨资金
              </button>
            </form>

            {transferResult && (
              <div className={`p-4 rounded-lg border text-xs flex items-start space-x-3 ${
                transferResult.success
                  ? 'bg-emerald-950/60 border-emerald-800 text-emerald-200'
                  : 'bg-rose-950/60 border-rose-800 text-rose-200'
              }`}>
                {transferResult.success ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                ) : (
                  <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0" />
                )}
                <div>
                  <div className="font-bold">{transferResult.success ? '交易完成 (Posted)' : '交易失败/被拦截'}</div>
                  <p className="mt-1">{transferResult.msg}</p>
                </div>
              </div>
            )}
          </div>

          {/* 右侧：交易规则面板 */}
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 text-white shadow space-y-4">
            <h3 className="font-bold text-sm text-slate-100 border-b border-slate-800 pb-2 flex items-center space-x-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>交易安全与控制准则</span>
            </h3>
            <ul className="space-y-2.5 text-xs text-slate-300">
              <li className="flex items-start space-x-2">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-400 mt-1.5 shrink-0"></span>
                <span><strong>借贷平衡校验:</strong> 实时产出 DEBIT (2001) 与 CREDIT (2001) 分录，总额必相等。</span>
              </li>
              <li className="flex items-start space-x-2">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 shrink-0"></span>
                <span><strong>可用余额锁:</strong> 扣款时自动检验 Available Balance ≥ Amount。</span>
              </li>
              <li className="flex items-start space-x-2">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-1.5 shrink-0"></span>
                <span><strong>大额反洗钱:</strong> 单笔转账大于 5,000,000 元自动触感 AML 审核。</span>
              </li>
            </ul>
          </div>
        </div>
      )}

      {/* 存款表单 */}
      {activeTab === 'DEPOSIT' && (
        <div className="max-w-2xl bg-slate-900 border border-slate-800 rounded-lg p-6 text-white shadow space-y-5">
          <h3 className="font-bold text-sm text-slate-100 border-b border-slate-800 pb-3">
            柜面现金存入记账
          </h3>

          <form onSubmit={handleDepositSubmit} className="space-y-4 text-xs">
            <div>
              <label className="block text-slate-400 mb-1">入账账户 *</label>
              <select
                value={depositAccNo}
                onChange={(e) => setDepositAccNo(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-slate-200 font-mono"
              >
                {accounts.map((a) => (
                  <option key={a.id} value={a.accountNo}>
                    {a.customerName} - {a.accountNo} (当前余额: ¥{a.bookBalance.toLocaleString()})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-400 mb-1">存入现金金额 (RMB) *</label>
              <input
                type="number"
                min="100"
                step="100"
                required
                value={depositAmount}
                onChange={(e) => setDepositAmount(parseFloat(e.target.value) || 0)}
                className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-slate-100 font-mono font-bold text-base"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1">摘要</label>
              <input
                type="text"
                value={depositRemark}
                onChange={(e) => setDepositRemark(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-slate-200"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow transition"
            >
              提交柜面现金存款并完成记账
            </button>
          </form>

          {depositMessage && (
            <div className={`p-4 rounded-lg border text-xs flex items-center space-x-2 ${
              depositMessage.success ? 'bg-emerald-950/60 border-emerald-800 text-emerald-200' : 'bg-rose-950/60 border-rose-800 text-rose-200'
            }`}>
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              <span>{depositMessage.msg}</span>
            </div>
          )}
        </div>
      )}

      {/* 最近交易列表 */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 text-white shadow space-y-4">
        <h3 className="font-bold text-sm text-slate-100 border-b border-slate-800 pb-2">
          最近全行交易流水记录
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[11px] border-b border-slate-800 font-medium">
              <tr>
                <th className="p-3">交易流水号</th>
                <th className="p-3">时间</th>
                <th className="p-3">付款账号/来源</th>
                <th className="p-3">收款账号/去向</th>
                <th className="p-3">金额</th>
                <th className="p-3">类型</th>
                <th className="p-3">渠道</th>
                <th className="p-3 text-right">状态</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {transactions.slice(0, 8).map((txn) => (
                <tr key={txn.id} className="hover:bg-slate-800/50 transition font-mono">
                  <td className="p-3 text-blue-400 font-bold">{txn.txnNo}</td>
                  <td className="p-3 text-slate-400 font-sans">{txn.timestamp}</td>
                  <td className="p-3 font-sans text-slate-200">{txn.sourceAccountName}</td>
                  <td className="p-3 font-sans text-slate-200">{txn.targetAccountName}</td>
                  <td className="p-3 font-bold text-emerald-400">¥{txn.amount.toLocaleString()}</td>
                  <td className="p-3">
                    <span className="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-slate-300 font-sans">
                      {txn.type}
                    </span>
                  </td>
                  <td className="p-3 font-sans text-slate-400">{txn.channel}</td>
                  <td className="p-3 text-right">
                    <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-800">
                      {txn.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
