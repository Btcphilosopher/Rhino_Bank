import React from 'react';
import { CreditCard, ShieldAlert, Lock, Unlock, CheckCircle2 } from 'lucide-react';
import { useBankStore } from '../services/bankStore';

export const CardsView: React.FC = () => {
  const { cards } = useBankStore();

  return (
    <div className="space-y-6">
      {/* 页头 */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 text-white flex flex-wrap items-center justify-between shadow">
        <div>
          <h1 className="text-xl font-bold flex items-center space-x-2">
            <CreditCard className="w-5 h-5 text-indigo-400" />
            <span>银行卡与信用卡中心 (Cards & Credit Line)</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            涵盖个人借记卡、双币种信用卡与企业高管公务采购卡，集成交易限额锁与防刷卡风控
          </p>
        </div>
      </div>

      {/* 卡片卡片列表 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {cards.map((card) => (
          <div key={card.id} className="bg-gradient-to-br from-slate-900 via-slate-900 to-slate-950 border border-slate-800 rounded-xl p-6 text-white shadow-xl space-y-4 relative overflow-hidden">
            {/* 卡面背景装饰 */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-blue-600/10 rounded-full blur-2xl pointer-events-none"></div>

            <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
              <span className="font-bold text-xs tracking-wider text-slate-300">
                HUASHENG BANK · 华盛银行
              </span>
              <span className="px-2 py-0.5 rounded bg-blue-950 text-blue-400 border border-blue-800 font-mono text-[10px]">
                {card.cardType}
              </span>
            </div>

            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 uppercase tracking-widest">Card Number</span>
              <div className="text-lg font-mono font-bold tracking-wider text-slate-100">
                {card.cardNoMasked}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>
                <span className="text-slate-400 text-[10px]">持卡人/企业</span>
                <div className="font-bold text-slate-200">{card.customerName}</div>
              </div>
              <div>
                <span className="text-slate-400 text-[10px]">有效期至</span>
                <div className="font-mono text-slate-200">{card.expiryDate}</div>
              </div>
            </div>

            <div className="p-3 rounded bg-slate-950/80 border border-slate-800/80 space-y-1 text-xs">
              <div className="flex justify-between text-slate-400">
                <span>授信额度: ¥{card.creditLimit.toLocaleString()}</span>
                <span>日限额: ¥{card.dailyTxnLimit.toLocaleString()}</span>
              </div>
              <div className="flex justify-between font-bold">
                <span className="text-slate-300">可用信用额度:</span>
                <span className="text-emerald-400 font-mono">¥{card.availableLimit.toLocaleString()}</span>
              </div>
            </div>

            <div className="flex items-center justify-between text-xs pt-1">
              <span className="text-slate-400 text-[11px]">绑卡账户: {card.accountNo}</span>
              <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 text-[10px]">
                {card.status}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
