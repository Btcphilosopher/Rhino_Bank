import React from 'react';
import {
  Users,
  CreditCard,
  TrendingUp,
  ShieldAlert,
  ArrowUpRight,
  ArrowDownRight,
  Activity,
  DollarSign,
  Briefcase,
  PlayCircle,
  RefreshCw,
  CheckCircle2,
  Clock,
  Layers,
} from 'lucide-react';
import { useBankStore } from '../services/bankStore';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, BarChart, Bar, CartesianGrid } from 'recharts';

const HOURLY_TPS_DATA = [
  { time: '08:00', tps: 420, amount: 1.2 },
  { time: '09:00', tps: 980, amount: 3.5 },
  { time: '10:00', tps: 1450, amount: 5.8 },
  { time: '11:00', tps: 1620, amount: 6.4 },
  { time: '12:00', tps: 890, amount: 2.9 },
  { time: '13:00', tps: 1100, amount: 4.1 },
  { time: '14:00', tps: 1580, amount: 6.9 },
  { time: '15:00', tps: 1820, amount: 8.2 },
  { time: '16:00', tps: 1340, amount: 5.1 },
  { time: '17:00', tps: 760, amount: 2.3 },
];

const ASSET_LIABILITY_DATA = [
  { category: '公司存款', amount: 125.4 },
  { category: '个人存款', amount: 65.8 },
  { category: '同业存放', amount: 23.8 },
  { category: '公司贷款', amount: 98.2 },
  { category: '个人按揭', amount: 32.5 },
  { category: '消费信用贷', amount: 16.3 },
];

interface CockpitProps {
  onNavigate: (tab: string) => void;
  onRunDemoFlow: () => void;
}

export const DashboardCockpit: React.FC<CockpitProps> = ({ onNavigate, onRunDemoFlow }) => {
  const { customers, accounts, loans, riskAlerts, auditLogs, systemMetrics, triggerEODProcessing } = useBankStore();

  const totalDeposit = accounts.reduce((sum, a) => sum + (a.bookBalance > 0 ? a.bookBalance : 0), 0);
  const totalLoan = loans.reduce((sum, l) => sum + l.balanceAmount, 0);

  return (
    <div className="space-y-6">
      {/* 顶部运营驾驶舱标题条 */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 text-white flex flex-wrap items-center justify-between shadow-lg">
        <div>
          <div className="flex items-center space-x-3">
            <h1 className="text-xl font-bold tracking-tight text-white">全行数字运营驾驶舱</h1>
            <span className="px-2.5 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 text-xs font-mono">
              REAL-TIME CORE STATUS
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            华盛银行总行实时监控 · 账本核算模式：双重记账实时平衡 · 数据切片时间: {new Date().toLocaleDateString('zh-CN')}
          </p>
        </div>

        <div className="flex items-center space-x-3 mt-3 sm:mt-0">
          <button
            onClick={onRunDemoFlow}
            className="px-4 py-2 rounded bg-amber-600 hover:bg-amber-500 text-white font-medium text-xs flex items-center space-x-2 shadow"
          >
            <PlayCircle className="w-4 h-4" />
            <span>执行第一条完整运行流程</span>
          </button>
          <button
            onClick={() => triggerEODProcessing()}
            disabled={systemMetrics.eodStatus === 'PROCESSING'}
            className="px-4 py-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-medium text-xs flex items-center space-x-2 shadow disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${systemMetrics.eodStatus === 'PROCESSING' ? 'animate-spin text-amber-400' : ''}`} />
            <span>{systemMetrics.eodStatus === 'PROCESSING' ? `日终处理中 (${systemMetrics.eodProgressPercent}%)` : '启动日终EOD结算'}</span>
          </button>
        </div>
      </div>

      {/* 第一排：核心指标卡片群 (根据Section VII规定) */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 text-white shadow">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>总客户数</span>
            <Users className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white mt-2">104,280 <span className="text-xs text-slate-400 font-sans">位</span></div>
          <div className="text-[11px] text-emerald-400 mt-1 flex items-center">
            <ArrowUpRight className="w-3 h-3 mr-0.5" /> 今日新增 +342
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 text-white shadow">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>总账户数</span>
            <CreditCard className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white mt-2">215,900 <span className="text-xs text-slate-400 font-sans">户</span></div>
          <div className="text-[11px] text-emerald-400 mt-1 flex items-center">
            <ArrowUpRight className="w-3 h-3 mr-0.5" /> 今日开户 +518
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 text-white shadow">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>存款余额 (RMB)</span>
            <DollarSign className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-xl font-bold font-mono text-emerald-400 mt-2">¥{(totalDeposit / 100000000 + 215.0).toFixed(2)} <span className="text-xs text-slate-400 font-sans">亿元</span></div>
          <div className="text-[11px] text-slate-400 mt-1">其中活期存款占比 58.2%</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 text-white shadow">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>贷款余额 (RMB)</span>
            <Briefcase className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-xl font-bold font-mono text-amber-300 mt-2">¥{(totalLoan / 100000000 + 147.0).toFixed(2)} <span className="text-xs text-slate-400 font-sans">亿元</span></div>
          <div className="text-[11px] text-slate-400 mt-1">不良贷款率 NPL 0.82%</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 text-white shadow">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>今日交易额</span>
            <TrendingUp className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-xl font-bold font-mono text-cyan-300 mt-2">¥48.5 <span className="text-xs text-slate-400 font-sans">亿元</span></div>
          <div className="text-[11px] text-slate-400 mt-1">累计 128,900 笔支付</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 text-white shadow">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>待处理风险事件</span>
            <ShieldAlert className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-rose-400 mt-2">{riskAlerts.length} <span className="text-xs text-slate-400 font-sans">起</span></div>
          <div className="text-[11px] text-slate-400 mt-1">待合规审查介入</div>
        </div>
      </div>

      {/* 第二排：核心图表与实时交易TPS */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 左侧：实时交易TPS与并发趋势 */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-5 text-white shadow space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2">
                <Activity className="w-4 h-4 text-blue-400" />
                <span>核心账本实时处理吞吐量 (TPS & 清算金额)</span>
              </h3>
              <p className="text-xs text-slate-400">分布式核心账本引擎实时每秒交易数 (TPS) 与每小时资金清算规模</p>
            </div>
            <span className="text-xs font-mono px-2 py-1 bg-blue-950 text-blue-400 border border-blue-800 rounded">
              核心延迟: {systemMetrics.avgLatencyMs} ms
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={HOURLY_TPS_DATA}>
                <defs>
                  <linearGradient id="colorTps" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0.0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="time" stroke="#94a3b8" fontSize={11} />
                <YAxis stroke="#94a3b8" fontSize={11} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#fff' }} />
                <Area type="monotone" dataKey="tps" stroke="#3b82f6" fillOpacity={1} fill="url(#colorTps)" name="实时TPS" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* 右侧：资产负债结构 */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 text-white shadow space-y-4">
          <div className="border-b border-slate-800 pb-3">
            <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2">
              <Layers className="w-4 h-4 text-emerald-400" />
              <span>资产负债结构分布 (亿元)</span>
            </h3>
            <p className="text-xs text-slate-400">存款吸收与信贷投放分类大盘</p>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={ASSET_LIABILITY_DATA} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis type="number" stroke="#94a3b8" fontSize={11} />
                <YAxis dataKey="category" type="category" stroke="#94a3b8" fontSize={11} width={80} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#fff' }} />
                <Bar dataKey="amount" fill="#10b981" radius={[0, 4, 4, 0]} name="金额 (亿元)" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* 第三排：快捷控制与最新实时审计 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 快捷业务入口 */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 text-white shadow space-y-4">
          <h3 className="font-bold text-sm text-slate-100 border-b border-slate-800 pb-2">核心业务快捷入口</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <button
              onClick={() => onNavigate('customers')}
              className="p-3 rounded bg-slate-800 hover:bg-slate-700 border border-slate-700 text-left transition"
            >
              <Users className="w-5 h-5 text-blue-400 mb-1" />
              <div className="font-bold text-xs text-slate-200">客户360°中心</div>
              <p className="text-[11px] text-slate-400">查看/新建个人与企业客户</p>
            </button>

            <button
              onClick={() => onNavigate('accounts')}
              className="p-3 rounded bg-slate-800 hover:bg-slate-700 border border-slate-700 text-left transition"
            >
              <CreditCard className="w-5 h-5 text-emerald-400 mb-1" />
              <div className="font-bold text-xs text-slate-200">账户与余额</div>
              <p className="text-[11px] text-slate-400">开户/账面与可用余额</p>
            </button>

            <button
              onClick={() => onNavigate('transactions')}
              className="p-3 rounded bg-slate-800 hover:bg-slate-700 border border-slate-700 text-left transition"
            >
              <PlayCircle className="w-5 h-5 text-amber-400 mb-1" />
              <div className="font-bold text-xs text-slate-200">存取款与转账</div>
              <p className="text-[11px] text-slate-400">实时记账与幂等控制</p>
            </button>

            <button
              onClick={() => onNavigate('loans')}
              className="p-3 rounded bg-slate-800 hover:bg-slate-700 border border-slate-700 text-left transition"
            >
              <Briefcase className="w-5 h-5 text-purple-400 mb-1" />
              <div className="font-bold text-xs text-slate-200">信贷审批工作台</div>
              <p className="text-[11px] text-slate-400">放款/还款计划表生成</p>
            </button>

            <button
              onClick={() => onNavigate('risk')}
              className="p-3 rounded bg-slate-800 hover:bg-slate-700 border border-slate-700 text-left transition"
            >
              <ShieldAlert className="w-5 h-5 text-rose-400 mb-1" />
              <div className="font-bold text-xs text-slate-200">AML反洗钱风控</div>
              <p className="text-[11px] text-slate-400">风险预警与调查任务</p>
            </button>

            <button
              onClick={() => onNavigate('accounting')}
              className="p-3 rounded bg-slate-800 hover:bg-slate-700 border border-slate-700 text-left transition"
            >
              <Layers className="w-5 h-5 text-cyan-400 mb-1" />
              <div className="font-bold text-xs text-slate-200">总账科目与EOD</div>
              <p className="text-[11px] text-slate-400">试算平衡与日终批处理</p>
            </button>
          </div>
        </div>

        {/* 实时审计日志流水 */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 text-white shadow space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2">
              <Clock className="w-4 h-4 text-blue-400" />
              <span>核心不可篡改审计流水 (Immutable Audit Trail)</span>
            </h3>
            <span className="text-xs text-slate-400">已成功记录 {auditLogs.length} 条</span>
          </div>

          <div className="space-y-2.5 max-h-60 overflow-y-auto pr-1">
            {auditLogs.slice(0, 5).map((log) => (
              <div key={log.id} className="p-2.5 rounded bg-slate-950 border border-slate-800 text-xs flex items-start justify-between">
                <div className="space-y-1">
                  <div className="font-medium text-slate-200 flex items-center space-x-2">
                    <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 font-mono text-[10px]">
                      {log.username}
                    </span>
                    <span>{log.action}</span>
                  </div>
                  <div className="text-[11px] text-slate-400">对象: {log.targetObject} | IP: {log.ipAddress}</div>
                </div>
                <div className="text-right">
                  <span className="px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 text-[10px]">
                    {log.result}
                  </span>
                  <div className="text-[10px] text-slate-500 font-mono mt-1">{log.timestamp.slice(11)}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
