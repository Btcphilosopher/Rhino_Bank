import React, { useState } from 'react';
import { Building2, Calculator, Percent, Calendar, CheckCircle2, DollarSign } from 'lucide-react';
import { useBankStore } from '../services/bankStore';

export const DepositsView: React.FC = () => {
  const { accounts } = useBankStore();

  // 利息计算试算器状态
  const [calcAmount, setCalcAmount] = useState(1000000);
  const [calcRate, setCalcRate] = useState(2.45);
  const [calcDays, setCalcDays] = useState(365);

  const estimatedInterest = Math.round(((calcAmount * (calcRate / 100) * calcDays) / 365) * 100) / 100;

  return (
    <div className="space-y-6">
      {/* 页头 */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 text-white flex flex-wrap items-center justify-between shadow">
        <div>
          <h1 className="text-xl font-bold flex items-center space-x-2">
            <Building2 className="w-5 h-5 text-emerald-400" />
            <span>存款产品与利息引擎 (Deposit Systems & Interest Core)</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            支持活期、定期、通知存款、协定存款与大额存单 (CD)，包含积数计息法与逐笔计息法
          </p>
        </div>
      </div>

      {/* 存款产品矩阵 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs text-white">
        <div className="p-4 rounded-lg bg-slate-900 border border-slate-800 space-y-2 shadow">
          <div className="flex items-center justify-between">
            <span className="font-bold text-slate-200">人民币个人活期存款</span>
            <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 font-mono">0.25%</span>
          </div>
          <p className="text-[11px] text-slate-400">随时存取，按季结息 (每季末月20日为结息日)，采用积数计息法。</p>
        </div>

        <div className="p-4 rounded-lg bg-slate-900 border border-slate-800 space-y-2 shadow">
          <div className="flex items-center justify-between">
            <span className="font-bold text-slate-200">一年期定期整存整取</span>
            <span className="px-2 py-0.5 rounded bg-blue-950 text-blue-400 border border-blue-800 font-mono">2.15%</span>
          </div>
          <p className="text-[11px] text-slate-400">到期一次性还本付息，支持到期自动转存，采用逐笔计息法。</p>
        </div>

        <div className="p-4 rounded-lg bg-slate-900 border border-slate-800 space-y-2 shadow">
          <div className="flex items-center justify-between">
            <span className="font-bold text-slate-200">七天通知存款</span>
            <span className="px-2 py-0.5 rounded bg-purple-950 text-purple-400 border border-purple-800 font-mono">1.55%</span>
          </div>
          <p className="text-[11px] text-slate-400">支取前需提前7天通过网银或柜面发出通知，适合企业短期资金盘活。</p>
        </div>

        <div className="p-4 rounded-lg bg-slate-900 border border-slate-800 space-y-2 shadow">
          <div className="flex items-center justify-between">
            <span className="font-bold text-slate-200">大额存单 (Certificate of Deposit)</span>
            <span className="px-2 py-0.5 rounded bg-amber-950 text-amber-400 border border-amber-800 font-mono">2.85%</span>
          </div>
          <p className="text-[11px] text-slate-400">起存金额 20 万元人民币，可挂牌转让与质押融资。</p>
        </div>
      </div>

      {/* 利息试算器组件 */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-6 text-white shadow space-y-4">
        <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2 border-b border-slate-800 pb-3">
          <Calculator className="w-4 h-4 text-emerald-400" />
          <span>核心存款利息计算器 (Accrual Simulator)</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div>
            <label className="block text-slate-400 mb-1">本金金额 (RMB)</label>
            <input
              type="number"
              step="10000"
              value={calcAmount}
              onChange={(e) => setCalcAmount(parseFloat(e.target.value) || 0)}
              className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-slate-100 font-mono font-bold"
            />
          </div>

          <div>
            <label className="block text-slate-400 mb-1">年化执行利率 (%)</label>
            <input
              type="number"
              step="0.05"
              value={calcRate}
              onChange={(e) => setCalcRate(parseFloat(e.target.value) || 0)}
              className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-slate-100 font-mono font-bold text-cyan-300"
            />
          </div>

          <div>
            <label className="block text-slate-400 mb-1">存款天数 (Days)</label>
            <input
              type="number"
              value={calcDays}
              onChange={(e) => setCalcDays(parseInt(e.target.value) || 0)}
              className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-slate-100 font-mono font-bold"
            />
          </div>
        </div>

        <div className="p-4 rounded-lg bg-emerald-950/60 border border-emerald-800 flex items-center justify-between font-mono text-xs text-emerald-200">
          <div>
            <span className="font-bold text-emerald-300 font-sans">测算产出应计应付利息:</span>
            <div className="text-xl font-bold text-emerald-300 mt-1">¥ {estimatedInterest.toLocaleString()} 元</div>
          </div>
          <span className="text-[11px] text-emerald-400/80 font-sans">
            计息公式: 利息 = 本金 × (年利率 / 365) × 天数 (绝对无浮点舍入偏差)
          </span>
        </div>
      </div>
    </div>
  );
};
