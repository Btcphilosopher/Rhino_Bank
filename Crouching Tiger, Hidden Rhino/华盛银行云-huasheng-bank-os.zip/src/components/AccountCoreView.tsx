import React, { useState } from 'react';
import {
  CreditCard,
  Plus,
  Lock,
  Unlock,
  Building2,
  DollarSign,
  Search,
  CheckCircle2,
  AlertCircle,
  X,
} from 'lucide-react';
import { useBankStore } from '../services/bankStore';
import { Account, AccountType } from '../types';

export const AccountCoreView: React.FC = () => {
  const { accounts, customers, openAccount } = useBankStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState<string>('ALL');
  const [showOpenModal, setShowOpenModal] = useState(false);

  // 开户表单
  const [openFormData, setOpenFormData] = useState({
    customerId: customers[0]?.id || '',
    type: AccountType.CURRENT,
    currency: 'CNY' as 'CNY' | 'USD' | 'EUR' | 'HKD',
    initialDeposit: 100000,
  });

  const filteredAccounts = accounts.filter((acc) => {
    const matchesSearch = acc.accountNo.includes(searchTerm) || acc.customerName.includes(searchTerm);
    const matchesType = selectedType === 'ALL' || acc.type === selectedType;
    return matchesSearch && matchesType;
  });

  const handleOpenAccountSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    openAccount(openFormData);
    setShowOpenModal(false);
  };

  return (
    <div className="space-y-6">
      {/* 账户中心页头 */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 text-white flex flex-wrap items-center justify-between shadow">
        <div>
          <h1 className="text-xl font-bold flex items-center space-x-2">
            <CreditCard className="w-5 h-5 text-emerald-400" />
            <span>账户中心与实时余额分层体系</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            严密区分 账面余额、冻结金额、待处理金额 与 实时可用余额 (可用余额 = 账面余额 - 冻结 - 待处理)
          </p>
        </div>

        <button
          onClick={() => setShowOpenModal(true)}
          className="px-4 py-2 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs flex items-center space-x-2 shadow"
        >
          <Plus className="w-4 h-4" />
          <span>开立新账户 (Open Account)</span>
        </button>
      </div>

      {/* 区分实时余额计算示例卡 (Section XI 规范要求) */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 text-white shadow space-y-3">
        <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
          核心账本余额拆分模型 (Real-Time Balance Split Rule)
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs font-mono">
          <div className="p-3 rounded bg-slate-950 border border-slate-800">
            <span className="text-slate-400 font-sans">账面余额 (Book Balance)</span>
            <div className="text-lg font-bold text-slate-100 mt-1">¥ 100,000.00</div>
            <div className="text-[10px] text-slate-500 font-sans mt-0.5">总账记载物理金额</div>
          </div>

          <div className="p-3 rounded bg-slate-950 border border-amber-900/60">
            <span className="text-amber-400 font-sans">(-) 冻结金额 (Frozen)</span>
            <div className="text-lg font-bold text-amber-400 mt-1">¥ 10,000.00</div>
            <div className="text-[10px] text-slate-500 font-sans mt-0.5">司法/风控/质押止付</div>
          </div>

          <div className="p-3 rounded bg-slate-950 border border-blue-900/60">
            <span className="text-blue-400 font-sans">(-) 待处理金额 (Pending)</span>
            <div className="text-lg font-bold text-blue-400 mt-1">¥ 2,000.00</div>
            <div className="text-[10px] text-slate-500 font-sans mt-0.5">清算未挂账扣款</div>
          </div>

          <div className="p-3 rounded bg-emerald-950/60 border border-emerald-700">
            <span className="text-emerald-300 font-sans">(=) 可用余额 (Available)</span>
            <div className="text-xl font-bold text-emerald-300 mt-1">¥ 88,000.00</div>
            <div className="text-[10px] text-emerald-400 font-sans mt-0.5">客户可自由支配划拨上限</div>
          </div>
        </div>
      </div>

      {/* 搜索过滤栏 */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 text-white flex flex-wrap items-center justify-between gap-4">
        <div className="relative flex-1 min-w-[280px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="搜索账号或客户名称..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-md pl-9 pr-4 py-1.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-emerald-500"
          />
        </div>

        <div className="flex items-center space-x-2 text-xs">
          <span className="text-slate-400">账户类型:</span>
          {['ALL', AccountType.CORPORATE_SETTLEMENT, AccountType.SAVINGS, AccountType.TERM_DEPOSIT, AccountType.LOAN_ACCOUNT].map((t) => (
            <button
              key={t}
              onClick={() => setSelectedType(t)}
              className={`px-3 py-1 rounded text-xs transition ${
                selectedType === t
                  ? 'bg-emerald-600 text-white font-bold'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              {t === 'ALL' ? '全部账户' : t === AccountType.CORPORATE_SETTLEMENT ? '企业结算' : t === AccountType.SAVINGS ? '储蓄户' : t === AccountType.TERM_DEPOSIT ? '定期户' : '贷款户'}
            </button>
          ))}
        </div>
      </div>

      {/* 账户列表 */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden text-white shadow">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[11px] border-b border-slate-800 font-medium">
              <tr>
                <th className="p-3.5">账户编号</th>
                <th className="p-3.5">户名</th>
                <th className="p-3.5">类型</th>
                <th className="p-3.5">币种</th>
                <th className="p-3.5">账面余额</th>
                <th className="p-3.5">冻结金额</th>
                <th className="p-3.5">可用余额</th>
                <th className="p-3.5">执行年利率</th>
                <th className="p-3.5">开户日期</th>
                <th className="p-3.5 text-right">状态</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredAccounts.map((acc) => (
                <tr key={acc.id} className="hover:bg-slate-800/50 transition">
                  <td className="p-3.5 font-mono text-emerald-400 font-bold">{acc.accountNo}</td>
                  <td className="p-3.5 font-bold text-slate-100">{acc.customerName}</td>
                  <td className="p-3.5">
                    <span className="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-slate-300 border border-slate-700">
                      {acc.type}
                    </span>
                  </td>
                  <td className="p-3.5 font-mono text-slate-400">{acc.currency}</td>
                  <td className="p-3.5 font-mono text-slate-100 font-medium">¥{acc.bookBalance.toLocaleString()}</td>
                  <td className="p-3.5 font-mono text-amber-400">¥{acc.frozenAmount.toLocaleString()}</td>
                  <td className="p-3.5 font-mono font-bold text-emerald-400 text-sm">¥{acc.availableBalance.toLocaleString()}</td>
                  <td className="p-3.5 font-mono text-cyan-300">{acc.interestRate}%</td>
                  <td className="p-3.5 font-mono text-slate-400">{acc.openDate}</td>
                  <td className="p-3.5 text-right">
                    <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-800 font-medium">
                      {acc.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* 开立新账户 Modal */}
      {showOpenModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-xl max-w-lg w-full text-white p-6 space-y-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-base text-slate-100">核心账户开立 (Open Core Account)</h3>
              <button onClick={() => setShowOpenModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleOpenAccountSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">所属客户 *</label>
                <select
                  value={openFormData.customerId}
                  onChange={(e) => setOpenFormData({ ...openFormData, customerId: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200"
                >
                  {customers.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.customerNo})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">账户类型 *</label>
                <select
                  value={openFormData.type}
                  onChange={(e) => setOpenFormData({ ...openFormData, type: e.target.value as AccountType })}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200"
                >
                  <option value={AccountType.CURRENT}>活期结算账户 (Current)</option>
                  <option value={AccountType.SAVINGS}>储蓄账户 (Savings)</option>
                  <option value={AccountType.TERM_DEPOSIT}>定期存款账户 (Term Deposit)</option>
                  <option value={AccountType.CORPORATE_SETTLEMENT}>企业结算账户 (Corporate Settlement)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">初始首存金额 (RMB) *</label>
                <input
                  type="number"
                  min="0"
                  step="1000"
                  required
                  value={openFormData.initialDeposit}
                  onChange={(e) => setOpenFormData({ ...openFormData, initialDeposit: parseFloat(e.target.value) || 0 })}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200 font-mono"
                />
              </div>

              <div className="pt-3 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setShowOpenModal(false)}
                  className="px-4 py-2 rounded bg-slate-800 text-slate-300 hover:bg-slate-700"
                >
                  取消
                </button>
                <button type="submit" className="px-4 py-2 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-bold">
                  确认开户并入账
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
