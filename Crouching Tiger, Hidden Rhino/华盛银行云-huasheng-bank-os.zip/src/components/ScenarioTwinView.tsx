import React from 'react';
import { Cpu, Activity, RefreshCw, ShieldAlert, CheckCircle2 } from 'lucide-react';

export const ScenarioTwinView: React.FC = () => {
  return (
    <div className="space-y-6">
      {/* 页头 */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 text-white flex flex-wrap items-center justify-between shadow">
        <div>
          <h1 className="text-xl font-bold flex items-center space-x-2">
            <Cpu className="w-5 h-5 text-indigo-400" />
            <span>银行数字孪生与灾备实验室 (Banking Digital Twin & Lab)</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            双中心同城双活与异地灾备 (RPO=0, RTO&lt;30s) 镜像模拟，支持全行高并发压力演练
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs text-white">
        <div className="p-5 rounded-lg bg-slate-900 border border-slate-800 space-y-3 shadow">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="font-bold text-slate-100">生产主中心 (Active Site 1 - 深圳)</span>
            <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 font-mono">PRIMARY ONLINE</span>
          </div>
          <p className="text-slate-400">承载全行 100% 实时高并发交易请求，Rust 账本微服务集群运行良好。</p>
        </div>

        <div className="p-5 rounded-lg bg-slate-900 border border-slate-800 space-y-3 shadow">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="font-bold text-slate-100">同城灾备中心 (Active Site 2 - 广州)</span>
            <span className="px-2 py-0.5 rounded bg-blue-950 text-blue-400 border border-blue-800 font-mono">STANDBY SYNC</span>
          </div>
          <p className="text-slate-400">Raft/Kafka 强一致流水实时同步，数据零丢失 (RPO=0)。</p>
        </div>
      </div>
    </div>
  );
};
