import React from 'react';
import { Cpu, DollarSign, TrendingUp, ShieldCheck } from 'lucide-react';

export const TreasuryView: React.FC = () => {
  return (
    <div className="space-y-6">
      {/* 页头 */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 text-white flex flex-wrap items-center justify-between shadow">
        <div>
          <h1 className="text-xl font-bold flex items-center space-x-2">
            <Cpu className="w-5 h-5 text-cyan-400" />
            <span>资金交易、外汇与同业拆借 (Treasury & Interbank)</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            银行间同业拆借(Shibor)、即期/远期外汇买卖(FX Spot/Forward)与流动性覆盖率(LCR)
          </p>
        </div>
      </div>

      {/* 外汇实时挂牌价 */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs font-mono text-white">
        <div className="p-4 rounded-lg bg-slate-900 border border-slate-800 space-y-1 shadow">
          <span className="text-slate-400 font-sans">USD/CNY (美元/人民币)</span>
          <div className="text-xl font-bold text-cyan-300">7.2345</div>
          <div className="text-[10px] text-emerald-400 font-sans">基准汇率实时同步</div>
        </div>

        <div className="p-4 rounded-lg bg-slate-900 border border-slate-800 space-y-1 shadow">
          <span className="text-slate-400 font-sans">EUR/CNY (欧元/人民币)</span>
          <div className="text-xl font-bold text-blue-300">7.8420</div>
          <div className="text-[10px] text-emerald-400 font-sans">即期交易活跃</div>
        </div>

        <div className="p-4 rounded-lg bg-slate-900 border border-slate-800 space-y-1 shadow">
          <span className="text-slate-400 font-sans">Shibor 隔夜拆借利率</span>
          <div className="text-xl font-bold text-amber-300">1.6850%</div>
          <div className="text-[10px] text-slate-400 font-sans">全行头寸平稳</div>
        </div>

        <div className="p-4 rounded-lg bg-slate-900 border border-slate-800 space-y-1 shadow">
          <span className="text-slate-400 font-sans">流动性覆盖率 LCR</span>
          <div className="text-xl font-bold text-emerald-400">148.5%</div>
          <div className="text-[10px] text-emerald-400 font-sans">高于法定监管红线 (100%)</div>
        </div>
      </div>
    </div>
  );
};
