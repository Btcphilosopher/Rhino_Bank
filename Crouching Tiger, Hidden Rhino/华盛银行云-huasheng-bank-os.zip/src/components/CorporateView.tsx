import React from 'react';
import { Building2, Layers, ShieldCheck, RefreshCw, FileText, ArrowUpRight } from 'lucide-react';

export const CorporateView: React.FC = () => {
  return (
    <div className="space-y-6">
      {/* 页头 */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 text-white flex flex-wrap items-center justify-between shadow">
        <div>
          <h1 className="text-xl font-bold flex items-center space-x-2">
            <Building2 className="w-5 h-5 text-purple-400" />
            <span>企业银行、现金池与贸易金融 (Corporate & Trade Finance)</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            集团多级资金池归集(Zero-Balancing)、跟单信用证(LC)、银行保函与银企直连API
          </p>
        </div>
      </div>

      {/* 集团现金池图示与状态 */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 text-white shadow space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2">
            <Layers className="w-4 h-4 text-purple-400" />
            <span>华为集团跨境全归集现金池 (Corporate Cash Sweep Engine)</span>
          </h3>
          <span className="text-xs font-mono px-2 py-1 bg-purple-950 text-purple-300 border border-purple-800 rounded">
            归集规则: 每日17:00 自动零余额划转 (Zero Balance Sweep)
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
          <div className="p-4 rounded-lg bg-slate-950 border border-slate-800 space-y-2">
            <div className="text-slate-400 font-sans">集团主资金池账户</div>
            <div className="text-lg font-bold text-purple-400">622848001001</div>
            <div className="text-slate-300 font-bold font-sans">当前资金归集余额: ¥320,000,000.00</div>
          </div>

          <div className="p-4 rounded-lg bg-slate-950 border border-slate-800 space-y-2">
            <div className="text-slate-400 font-sans">下属终端子账户数</div>
            <div className="text-lg font-bold text-slate-100">12 个虚拟子账户</div>
            <div className="text-emerald-400 font-sans">自动下拨内部借贷计息</div>
          </div>

          <div className="p-4 rounded-lg bg-slate-950 border border-slate-800 space-y-2">
            <div className="text-slate-400 font-sans">今日已完成划拨</div>
            <div className="text-lg font-bold text-cyan-300">¥ 45,000,000.00</div>
            <div className="text-slate-400 font-sans">触发交易 18 笔零偏差</div>
          </div>
        </div>
      </div>

      {/* 贸易金融信用证与保函 */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 text-white shadow space-y-4">
        <h3 className="font-bold text-sm text-slate-100 border-b border-slate-800 pb-3">
          国际跟单信用证 (Irrevocable Letter of Credit - LC) 挂牌台账
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300 font-mono">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
              <tr>
                <th className="p-3">信用证编码</th>
                <th className="p-3">申请人 (买方)</th>
                <th className="p-3">受益人 (卖方)</th>
                <th className="p-3">币种及金额</th>
                <th className="p-3">开证日期</th>
                <th className="p-3">效期</th>
                <th className="p-3 text-right">状态</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              <tr className="hover:bg-slate-800/50">
                <td className="p-3 text-purple-400 font-bold">LC202609100881</td>
                <td className="p-3 font-sans text-slate-200">比亚迪新能源海外部</td>
                <td className="p-3 font-sans text-slate-200">Siemens AG Germany</td>
                <td className="p-3 font-bold text-emerald-400">USD $12,500,000.00</td>
                <td className="p-3 text-slate-400">2026-09-10</td>
                <td className="p-3 text-slate-400">2026-12-31</td>
                <td className="p-3 text-right font-sans">
                  <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-800">
                    已开立承兑 (ISSUED)
                  </span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
