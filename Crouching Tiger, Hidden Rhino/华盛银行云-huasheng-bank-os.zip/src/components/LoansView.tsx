import React, { useState } from 'react';
import { Briefcase, ShieldCheck, Plus, CheckCircle2, AlertTriangle, Calendar, FileText, X } from 'lucide-react';
import { useBankStore } from '../services/bankStore';
import { Loan, LoanStatus } from '../types';

export const LoansView: React.FC = () => {
  const { loans, accounts, applyAndApproveLoan, repayLoanPeriod } = useBankStore();

  const [selectedLoan, setSelectedLoan] = useState<Loan | null>(null);
  const [showApplyModal, setShowApplyModal] = useState(false);
  const [repayMessage, setRepayMessage] = useState<{ success: boolean; msg: string } | null>(null);

  // 贷款申请表单
  const [loanForm, setLoanForm] = useState({
    customerName: '华为技术有限公司（华盛专属户）',
    productType: 'CORPORATE_WORKING_CAPITAL' as Loan['productType'],
    approvedAmount: 50000000,
    termMonths: 12,
    interestRate: 3.25,
    repaymentMethod: 'EQUAL_PRINCIPAL' as Loan['repaymentMethod'],
    collateralDescription: '深圳市龙岗区园区不动产质押及集团保证担保',
    collateralValue: 80000000,
    disburseToAccountNo: accounts[0]?.accountNo || '',
  });

  const handleApplyLoanSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newLoan = applyAndApproveLoan(loanForm);
    setShowApplyModal(false);
    setSelectedLoan(newLoan);
  };

  const handleRepayPeriod = (loanId: string, accountNo: string) => {
    const res = repayLoanPeriod(loanId, accountNo);
    setRepayMessage({ success: res.success, msg: res.message });
  };

  return (
    <div className="space-y-6">
      {/* 页头 */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 text-white flex flex-wrap items-center justify-between shadow">
        <div>
          <h1 className="text-xl font-bold flex items-center space-x-2">
            <Briefcase className="w-5 h-5 text-amber-400" />
            <span>信贷审批、放款与还款引擎 (Loans & Credit Engine)</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            涵盖个人住房按揭、企业流动资金贷款与供应链融资，内置等额本息/等额本金还款计划计算
          </p>
        </div>

        <button
          onClick={() => setShowApplyModal(true)}
          className="px-4 py-2 rounded bg-amber-600 hover:bg-amber-500 text-white font-medium text-xs flex items-center space-x-2 shadow"
        >
          <Plus className="w-4 h-4" />
          <span>新发起信贷审议与放款 (New Loan)</span>
        </button>
      </div>

      {/* 贷款合同列表 */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden text-white shadow">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[11px] border-b border-slate-800 font-medium">
              <tr>
                <th className="p-3.5">贷款借据号</th>
                <th className="p-3.5">借款人名称</th>
                <th className="p-3.5">产品类型</th>
                <th className="p-3.5">核准发放金额</th>
                <th className="p-3.5">剩余贷款本金</th>
                <th className="p-3.5">年利率</th>
                <th className="p-3.5">期限</th>
                <th className="p-3.5">还款方式</th>
                <th className="p-3.5">风险分类</th>
                <th className="p-3.5 text-right">操作</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {loans.map((loan) => (
                <tr key={loan.id} className="hover:bg-slate-800/50 transition">
                  <td className="p-3.5 font-mono text-amber-400 font-bold">{loan.loanNo}</td>
                  <td className="p-3.5 font-bold text-slate-100">{loan.customerName}</td>
                  <td className="p-3.5 font-sans text-slate-300">{loan.productType}</td>
                  <td className="p-3.5 font-mono text-slate-100 font-medium">¥{loan.approvedAmount.toLocaleString()}</td>
                  <td className="p-3.5 font-mono font-bold text-amber-300 text-sm">¥{loan.balanceAmount.toLocaleString()}</td>
                  <td className="p-3.5 font-mono text-cyan-300">{loan.interestRate}%</td>
                  <td className="p-3.5 font-mono text-slate-300">{loan.termMonths} 个月</td>
                  <td className="p-3.5 font-sans text-slate-400">
                    {loan.repaymentMethod === 'EQUAL_PAYMENT' ? '等额本息' : '等额本金'}
                  </td>
                  <td className="p-3.5">
                    <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-800">
                      {loan.riskClass}
                    </span>
                  </td>
                  <td className="p-3.5 text-right">
                    <button
                      onClick={() => setSelectedLoan(loan)}
                      className="px-2.5 py-1 rounded bg-amber-600 hover:bg-amber-500 text-white text-[11px] font-medium shadow"
                    >
                      查看还款计划表
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* 还款计划表 Modal */}
      {selectedLoan && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-xl max-w-4xl w-full text-white p-6 space-y-5 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="font-bold text-base text-slate-100 flex items-center space-x-2">
                  <span>信贷借据还款计划表 ({selectedLoan.loanNo})</span>
                  <span className="text-xs px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800">
                    {selectedLoan.customerName}
                  </span>
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  贷款本金: ¥{selectedLoan.approvedAmount.toLocaleString()} · 当前剩余本金: ¥{selectedLoan.balanceAmount.toLocaleString()} · 利率: {selectedLoan.interestRate}%
                </p>
              </div>

              <button onClick={() => setSelectedLoan(null)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            {repayMessage && (
              <div className={`p-3 rounded border text-xs flex items-center space-x-2 ${
                repayMessage.success ? 'bg-emerald-950 border-emerald-800 text-emerald-200' : 'bg-rose-950 border-rose-800 text-rose-200'
              }`}>
                <CheckCircle2 className="w-4 h-4" />
                <span>{repayMessage.msg}</span>
              </div>
            )}

            {/* 还款扣款操作条 */}
            <div className="p-4 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between text-xs">
              <div>
                <div className="font-bold text-slate-200">执行当期还款扣款</div>
                <p className="text-slate-400 text-[11px]">扣除第一期待还金额，更新借据剩余本金与会计总账</p>
              </div>

              <button
                onClick={() => handleRepayPeriod(selectedLoan.id, accounts[0]?.accountNo || '')}
                className="px-4 py-2 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-bold"
              >
                从主账户 ({accounts[0]?.accountNo}) 扣款还款
              </button>
            </div>

            {/* 期次表格 */}
            <div className="overflow-x-auto border border-slate-800 rounded-lg">
              <table className="w-full text-left text-xs font-mono text-slate-300">
                <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
                  <tr>
                    <th className="p-2.5">期次</th>
                    <th className="p-2.5">应还日期</th>
                    <th className="p-2.5">应还本金</th>
                    <th className="p-2.5">应还利息</th>
                    <th className="p-2.5">本息合计</th>
                    <th className="p-2.5">剩余本金</th>
                    <th className="p-2.5 text-right">状态</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {selectedLoan.schedules.map((s) => (
                    <tr key={s.periodNo} className="hover:bg-slate-800/40">
                      <td className="p-2.5 font-bold">第 {s.periodNo} 期</td>
                      <td className="p-2.5 text-slate-400">{s.dueDate}</td>
                      <td className="p-2.5 font-bold text-slate-200">¥{s.principalAmount.toLocaleString()}</td>
                      <td className="p-2.5 text-cyan-300">¥{s.interestAmount.toLocaleString()}</td>
                      <td className="p-2.5 font-bold text-amber-300">¥{s.totalDue.toLocaleString()}</td>
                      <td className="p-2.5 text-slate-400">¥{s.remainingPrincipal.toLocaleString()}</td>
                      <td className="p-2.5 text-right font-sans">
                        <span className={`px-2 py-0.5 rounded text-[10px] ${
                          s.status === 'PAID'
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                            : 'bg-amber-950 text-amber-400 border border-amber-800'
                        }`}>
                          {s.status === 'PAID' ? '已结清' : '待还款'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 新申请放款 Modal */}
      {showApplyModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-xl max-w-lg w-full text-white p-6 space-y-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-base text-slate-100">信贷审议与放款审批 (Credit Approval)</h3>
              <button onClick={() => setShowApplyModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleApplyLoanSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">借款企业 / 客户 *</label>
                <input
                  type="text"
                  required
                  value={loanForm.customerName}
                  onChange={(e) => setLoanForm({ ...loanForm, customerName: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">核准放款金额 (RMB) *</label>
                <input
                  type="number"
                  step="1000000"
                  required
                  value={loanForm.approvedAmount}
                  onChange={(e) => setLoanForm({ ...loanForm, approvedAmount: parseFloat(e.target.value) || 0 })}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200 font-mono font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">执行年利率 (%)</label>
                  <input
                    type="number"
                    step="0.05"
                    value={loanForm.interestRate}
                    onChange={(e) => setLoanForm({ ...loanForm, interestRate: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">贷款期限 (月)</label>
                  <input
                    type="number"
                    value={loanForm.termMonths}
                    onChange={(e) => setLoanForm({ ...loanForm, termMonths: parseInt(e.target.value) || 1 })}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">担保抵押物描述</label>
                <input
                  type="text"
                  value={loanForm.collateralDescription}
                  onChange={(e) => setLoanForm({ ...loanForm, collateralDescription: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200"
                />
              </div>

              <div className="pt-3 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setShowApplyModal(false)}
                  className="px-4 py-2 rounded bg-slate-800 text-slate-300 hover:bg-slate-700"
                >
                  取消
                </button>
                <button type="submit" className="px-4 py-2 rounded bg-amber-600 hover:bg-amber-500 text-white font-bold">
                  审议通过并完成资金发放
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
