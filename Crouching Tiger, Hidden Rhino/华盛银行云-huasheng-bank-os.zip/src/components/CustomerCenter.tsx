import React, { useState } from 'react';
import {
  Users,
  Building2,
  Search,
  Plus,
  Shield,
  CreditCard,
  Briefcase,
  FileText,
  Clock,
  Phone,
  Mail,
  MapPin,
  X,
  Check,
  AlertTriangle,
} from 'lucide-react';
import { useBankStore } from '../services/bankStore';
import { Customer, CustomerType, CustomerRiskLevel } from '../types';

export const CustomerCenter: React.FC = () => {
  const { customers, accounts, loans, cards, transactions, createCustomer } = useBankStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState<string>('ALL');
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);

  // 新增客户表单
  const [formData, setFormData] = useState({
    name: '',
    type: CustomerType.INDIVIDUAL,
    idNo: '',
    phone: '',
    email: '',
    address: '',
    relationshipManager: '张经理',
    branchName: '华盛银行总行营业部',
  });

  const filteredCustomers = customers.filter((c) => {
    const matchesSearch = c.name.includes(searchTerm) || c.customerNo.includes(searchTerm);
    const matchesType = selectedType === 'ALL' || c.type === selectedType;
    return matchesSearch && matchesType;
  });

  const handleCreateCustomerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.idNo) return;
    createCustomer(formData);
    setShowAddModal(false);
    setFormData({
      name: '',
      type: CustomerType.INDIVIDUAL,
      idNo: '',
      phone: '',
      email: '',
      address: '',
      relationshipManager: '张经理',
      branchName: '华盛银行总行营业部',
    });
  };

  return (
    <div className="space-y-6">
      {/* 客户中心页头 */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 text-white flex flex-wrap items-center justify-between shadow">
        <div>
          <h1 className="text-xl font-bold flex items-center space-x-2">
            <Users className="w-5 h-5 text-blue-400" />
            <span>客户中心与 360° 全景视图</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            涵盖个人客户、企业客户、机构客户、同业银行与集团客户的高级档案与全流程金融画像
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="px-4 py-2 rounded bg-blue-600 hover:bg-blue-500 text-white font-medium text-xs flex items-center space-x-2 shadow"
        >
          <Plus className="w-4 h-4" />
          <span>登记新客户档案</span>
        </button>
      </div>

      {/* 搜索与过滤栏 */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 text-white flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center space-x-3 flex-1 min-w-[280px]">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="搜索客户姓名、企业名称或客户编号 (如 CUST-2026-XXXX)..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-md pl-9 pr-4 py-1.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
          </div>
        </div>

        <div className="flex items-center space-x-2 text-xs">
          <span className="text-slate-400">客户类型:</span>
          {['ALL', CustomerType.INDIVIDUAL, CustomerType.CORPORATE, CustomerType.INTERBANK].map((type) => (
            <button
              key={type}
              onClick={() => setSelectedType(type)}
              className={`px-3 py-1 rounded text-xs transition ${
                selectedType === type
                  ? 'bg-blue-600 text-white font-bold'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              {type === 'ALL' ? '全部客户' : type === CustomerType.INDIVIDUAL ? '个人客户' : type === CustomerType.CORPORATE ? '企业客户' : '同业/机构'}
            </button>
          ))}
        </div>
      </div>

      {/* 客户列表表格 */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden text-white shadow">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[11px] border-b border-slate-800 font-medium">
              <tr>
                <th className="p-3.5">客户编号</th>
                <th className="p-3.5">客户姓名/企业名称</th>
                <th className="p-3.5">类型</th>
                <th className="p-3.5">证件号码</th>
                <th className="p-3.5">存款总额</th>
                <th className="p-3.5">贷款余额</th>
                <th className="p-3.5">授信额度</th>
                <th className="p-3.5">风险等级</th>
                <th className="p-3.5">客户经理</th>
                <th className="p-3.5 text-right">操作</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredCustomers.map((cust) => (
                <tr key={cust.id} className="hover:bg-slate-800/50 transition">
                  <td className="p-3.5 font-mono text-blue-400 font-medium">{cust.customerNo}</td>
                  <td className="p-3.5 font-bold text-slate-100 flex items-center space-x-2">
                    {cust.type === CustomerType.CORPORATE ? (
                      <Building2 className="w-4 h-4 text-purple-400" />
                    ) : (
                      <Users className="w-4 h-4 text-emerald-400" />
                    )}
                    <span>{cust.name}</span>
                  </td>
                  <td className="p-3.5">
                    <span className="px-2 py-0.5 rounded text-[10px] font-medium bg-slate-800 text-slate-300 border border-slate-700">
                      {cust.type === CustomerType.INDIVIDUAL ? '个人客户' : cust.type === CustomerType.CORPORATE ? '企业客户' : '同业/机构'}
                    </span>
                  </td>
                  <td className="p-3.5 font-mono text-slate-400">{cust.idNoMasked}</td>
                  <td className="p-3.5 font-mono font-bold text-emerald-400">¥{cust.totalDeposit.toLocaleString()}</td>
                  <td className="p-3.5 font-mono text-amber-300">¥{cust.totalLoan.toLocaleString()}</td>
                  <td className="p-3.5 font-mono text-cyan-300">¥{cust.totalCreditLimit.toLocaleString()}</td>
                  <td className="p-3.5">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-medium ${
                      cust.riskLevel === CustomerRiskLevel.LOW
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                        : 'bg-amber-950 text-amber-400 border border-amber-800'
                    }`}>
                      {cust.riskLevel}
                    </span>
                  </td>
                  <td className="p-3.5 text-slate-300">{cust.relationshipManager}</td>
                  <td className="p-3.5 text-right">
                    <button
                      onClick={() => setSelectedCustomer(cust)}
                      className="px-2.5 py-1 rounded bg-blue-600 hover:bg-blue-500 text-white text-[11px] font-medium shadow transition"
                    >
                      查看 Customer 360°
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* 客户 360° 全景弹窗 (Section IX要求) */}
      {selectedCustomer && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-xl max-w-5xl w-full max-h-[90vh] overflow-y-auto text-white shadow-2xl space-y-6 p-6">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center font-bold text-white text-lg">
                  {selectedCustomer.name.slice(0, 1)}
                </div>
                <div>
                  <h2 className="text-lg font-bold text-slate-100 flex items-center space-x-2">
                    <span>{selectedCustomer.name}</span>
                    <span className="text-xs px-2 py-0.5 rounded bg-blue-950 text-blue-300 border border-blue-800 font-mono">
                      {selectedCustomer.customerNo}
                    </span>
                  </h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    客户360°全景归集 · 机构: {selectedCustomer.branchName} · 客户经理: {selectedCustomer.relationshipManager}
                  </p>
                </div>
              </div>

              <button
                onClick={() => setSelectedCustomer(null)}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* 统计指标面板 */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 bg-slate-950 p-4 rounded-lg border border-slate-800 text-xs">
              <div>
                <span className="text-slate-400">名下账户数</span>
                <div className="text-lg font-bold font-mono text-slate-100 mt-1">{selectedCustomer.accountCount} 个账户</div>
              </div>
              <div>
                <span className="text-slate-400">总存款余额</span>
                <div className="text-lg font-bold font-mono text-emerald-400 mt-1">¥{selectedCustomer.totalDeposit.toLocaleString()}</div>
              </div>
              <div>
                <span className="text-slate-400">总贷款余额</span>
                <div className="text-lg font-bold font-mono text-amber-300 mt-1">¥{selectedCustomer.totalLoan.toLocaleString()}</div>
              </div>
              <div>
                <span className="text-slate-400">综合授信额度</span>
                <div className="text-lg font-bold font-mono text-cyan-300 mt-1">¥{selectedCustomer.totalCreditLimit.toLocaleString()}</div>
              </div>
            </div>

            {/* 名下账户 */}
            <div className="space-y-3">
              <h3 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-1 flex items-center space-x-2">
                <CreditCard className="w-4 h-4 text-blue-400" />
                <span>关联核心账户 (Accounts)</span>
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {accounts
                  .filter((a) => a.customerId === selectedCustomer.id)
                  .map((acc) => (
                    <div key={acc.id} className="p-3 rounded bg-slate-950 border border-slate-800 text-xs space-y-1">
                      <div className="flex justify-between font-mono font-bold text-slate-200">
                        <span>{acc.accountNo}</span>
                        <span className="text-blue-400">{acc.type}</span>
                      </div>
                      <div className="flex justify-between text-slate-400">
                        <span>账面余额: ¥{acc.bookBalance.toLocaleString()}</span>
                        <span>可用: <strong className="text-emerald-400">¥{acc.availableBalance.toLocaleString()}</strong></span>
                      </div>
                      <div className="text-[11px] text-slate-500">冻结金额: ¥{acc.frozenAmount.toLocaleString()} | 年利率: {acc.interestRate}%</div>
                    </div>
                  ))}
              </div>
            </div>

            {/* 关联系数与风险提示 */}
            <div className="p-4 rounded-lg bg-amber-950/40 border border-amber-800/60 text-xs text-amber-200 flex items-start space-x-3">
              <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <div className="font-bold text-amber-300">客户 360° 综合风险提示</div>
                <p className="mt-1 text-slate-300">
                  客户评级维持为 {selectedCustomer.level}，历史还款履约良好，未发现高风险涉诉及反洗钱黑名单重合。建议维持现有授信限额。
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 登记新客户 Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-xl max-w-lg w-full text-white p-6 space-y-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-base text-slate-100">登记新客户档案 (KYC 建档)</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateCustomerSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">客户类型</label>
                <select
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value as CustomerType })}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200"
                >
                  <option value={CustomerType.INDIVIDUAL}>个人客户 (Individual)</option>
                  <option value={CustomerType.CORPORATE}>企业客户 (Corporate)</option>
                  <option value={CustomerType.INSTITUTIONAL}>机构客户 (Institutional)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">客户姓名 / 企业名称 *</label>
                <input
                  type="text"
                  required
                  placeholder="例如: 腾讯科技（深圳）有限公司 或 魏明"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">证件号码 (身份证 / 统一社会信用代码) *</label>
                <input
                  type="text"
                  required
                  placeholder="请输入证件号码..."
                  value={formData.idNo}
                  onChange={(e) => setFormData({ ...formData, idNo: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200 font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">联系电话</label>
                  <input
                    type="text"
                    placeholder="138XXXX8888"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">邮箱地址</label>
                  <input
                    type="email"
                    placeholder="contact@company.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">联系地址</label>
                <input
                  type="text"
                  placeholder="请输入常住地址或注册地址..."
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200"
                />
              </div>

              <div className="pt-3 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded bg-slate-800 text-slate-300 hover:bg-slate-700"
                >
                  取消
                </button>
                <button type="submit" className="px-4 py-2 rounded bg-blue-600 hover:bg-blue-500 text-white font-bold">
                  确认登记开户
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
