package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.FlightSearchTimeline
import com.example.ui.components.FuturisticTopBar
import com.example.ui.theme.*
import com.example.viewmodel.MainUiState
import com.example.viewmodel.MainViewModel

@Composable
fun NetworkScreen(
    uiState: MainUiState,
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CafBlackDeep)
            .verticalScroll(scrollState)
            .padding(bottom = 90.dp)
            .testTag("network_screen_content")
    ) {
        FuturisticTopBar(
            journeyState = uiState.journeyState,
            onOpenAiAssistant = { viewModel.setAiAssistantOpen(true) },
            onOpenDemoControl = { viewModel.setDemoControlOpen(true) }
        )

        Spacer(modifier = Modifier.height(6.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Flight Search & Timeline booking
            FlightSearchTimeline(
                origin = uiState.searchOrigin,
                destination = uiState.searchDestination,
                date = uiState.searchDate,
                onSelectFlight = { viewModel.selectFlightToBook(it) }
            )

            // High Frequency Express Network Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(CafBlackCard)
                    .border(1.dp, CafBlackBorder, RoundedCornerShape(20.dp))
                    .padding(18.dp)
            ) {
                Column {
                    Text(
                        text = "EXPRESS SHUTTLE NETWORK · 华航空中快线",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = CafRedChina,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "高频次 · 随到随走 · 专属极速安检通道",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = CafWarmWhite
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    RouteItem(name = "京沪空中快线 (SHA ⇄ PEK/PKX)", freq = "半小时一班", punct = "98.5% 准点率")
                    Spacer(modifier = Modifier.height(8.dp))
                    RouteItem(name = "沪深/粤港澳快线 (SHA ⇄ SZX/HKG)", freq = "45 分钟一班", punct = "97.8% 准点率")
                    Spacer(modifier = Modifier.height(8.dp))
                    RouteItem(name = "成渝经济圈快线 (SHA ⇄ TFU/CKG)", freq = "1 小时一班", punct = "99.1% 准点率")
                }
            }

            // Fleet Specs
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(CafBlackCard)
                    .border(1.dp, CafBlackBorder, RoundedCornerShape(20.dp))
                    .padding(18.dp)
            ) {
                Column {
                    Text(
                        text = "SMART FLEET · 华航智慧机队",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = CafRedChina,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "全机队搭载国产化星地宽带与数字座舱",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = CafWarmWhite
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    FleetItem(model = "A321-Neo Future", role = "干线旗舰 · 198 座 · 全平躺商务舱")
                    Spacer(modifier = Modifier.height(6.dp))
                    FleetItem(model = "C919 Future", role = "新一代国产大飞机 · 168 座 · 静音客舱")
                    Spacer(modifier = Modifier.height(6.dp))
                    FleetItem(model = "A350-1000", role = "远程宽体客机 · 320 座 · 领航头等舱")
                }
            }
        }
    }
}

@Composable
private fun RouteItem(name: String, freq: String, punct: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(CafBlackSurface)
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(imageVector = Icons.Default.FlightTakeoff, contentDescription = null, tint = CafRedChina, modifier = Modifier.size(16.dp))
            Column {
                Text(text = name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CafWarmWhite)
                Text(text = freq, fontSize = 10.sp, color = CafTitaniumGrey)
            }
        }
        Text(text = punct, fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = CafStatusGreen)
    }
}

@Composable
private fun FleetItem(model: String, role: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(CafBlackSurface)
            .padding(10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = model, fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = CafWarmWhite)
        Text(text = role, fontSize = 10.sp, color = CafTitaniumLight)
    }
}
