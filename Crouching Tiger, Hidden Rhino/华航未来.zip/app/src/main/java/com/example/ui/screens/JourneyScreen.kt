package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.components.*
import com.example.ui.theme.CafBlackDeep
import com.example.viewmodel.MainUiState
import com.example.viewmodel.MainViewModel

@Composable
fun JourneyScreen(
    uiState: MainUiState,
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CafBlackDeep)
            .verticalScroll(scrollState)
            .padding(bottom = 90.dp)
            .testTag("journey_screen_content")
    ) {
        FuturisticTopBar(
            journeyState = uiState.journeyState,
            onOpenAiAssistant = { viewModel.setAiAssistantOpen(true) },
            onOpenDemoControl = { viewModel.setDemoControlOpen(true) }
        )

        JourneyStateScrubber(
            currentState = uiState.journeyState,
            onSelectState = { viewModel.setJourneyState(it) }
        )

        Spacer(modifier = Modifier.height(10.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Live Route Canvas
            FlightMapCanvas(telemetry = uiState.telemetry)

            // Aircraft Spatial Twin
            AircraftDigitalTwinView(
                seatInfo = uiState.seatInfo,
                selectedPart = uiState.selectedAircraftPart,
                onSelectPart = { viewModel.selectAircraftPart(it) }
            )

            // Baggage Status
            BaggageTrackerCard(baggage = uiState.baggage)
        }
    }
}
