package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.DirectionsWalk
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.LoungeInfo
import com.example.ui.theme.*

@Composable
fun AirportDigitalTwinView(
    is3DMode: Boolean,
    onToggle3D: () -> Unit,
    selectedNode: String,
    onSelectNode: (String) -> Unit,
    loungeInfo: LoungeInfo,
    onOpenBoardingPass: () -> Unit,
    modifier: Modifier = Modifier
) {
    val poiList = listOf(
        Pair("K01", "华航专属值机"),
        Pair("SEC", "智能无感安检"),
        Pair("LNG", "CAF 领航贵宾厅"),
        Pair("C42", "C42 登机口"),
        Pair("BAG", "行李托运处"),
        Pair("HSR", "高铁换乘中心")
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(CafBlackCard)
            .border(1.dp, CafBlackBorder, RoundedCornerShape(20.dp))
            .padding(18.dp)
            .testTag("airport_digital_twin_container")
    ) {
        // Airport Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "AIRPORT DIGITAL TWIN · 机场立体空间",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = CafRedChina,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "上海虹桥国际机场 · T2 航站楼",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = CafWarmWhite
                )
            }

            // 2D / 3D Isometric Switcher
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(CafBlackSurface)
                    .border(1.dp, CafBlackBorder, RoundedCornerShape(20.dp))
                    .padding(2.dp)
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (!is3DMode) CafRedChina else Color.Transparent)
                        .clickable { if (is3DMode) onToggle3D() }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "平面",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (!is3DMode) CafWarmWhite else CafTitaniumGrey
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (is3DMode) CafRedChina else Color.Transparent)
                        .clickable { if (!is3DMode) onToggle3D() }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "3D 立体",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (is3DMode) CafWarmWhite else CafTitaniumGrey
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Personal Route Navigation HUD Card
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(CafBlackSurface)
                .border(1.dp, CafRedChina.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(CafRedChina.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.DirectionsWalk,
                        contentDescription = "步行路线",
                        tint = CafRedChina,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Column {
                    Text(
                        text = "专属最优路径 · 当前位置 → C42 登机口",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = CafWarmWhite
                    )
                    Text(
                        text = "途经安检 02 通道 · 人流指数 [通畅]",
                        fontSize = 10.sp,
                        color = CafStatusGreen
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "4 min",
                    fontSize = 16.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = CafRedBright
                )
                Text(
                    text = "280 m",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = CafTitaniumGrey
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Architectural Terminal Blueprint Canvas with Red Path
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(CafBlackDeep)
                .border(1.dp, CafBlackBorder, RoundedCornerShape(14.dp))
                .padding(10.dp)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height

                // Terminal Concourse Pier geometry
                val concoursePath = Path().apply {
                    moveTo(w * 0.10f, h * 0.78f)
                    lineTo(w * 0.90f, h * 0.78f)
                    lineTo(w * 0.85f, h * 0.35f)
                    lineTo(w * 0.65f, h * 0.20f)
                    lineTo(w * 0.35f, h * 0.20f)
                    lineTo(w * 0.15f, h * 0.35f)
                    close()
                }
                drawPath(concoursePath, color = CafBlackSurface)
                drawPath(concoursePath, color = CafBlackBorder, style = Stroke(width = 1.5f))

                // Security Check Area
                drawRect(
                    color = CafBlackCardElevated,
                    topLeft = Offset(w * 0.38f, h * 0.55f),
                    size = androidx.compose.ui.geometry.Size(w * 0.24f, h * 0.15f)
                )

                // Navigation Red Line Path (You -> Security -> Lounge -> Gate C42)
                val navPath = Path().apply {
                    moveTo(w * 0.22f, h * 0.70f) // Current Location
                    lineTo(w * 0.45f, h * 0.62f) // Security Check
                    lineTo(w * 0.50f, h * 0.38f) // Lounge
                    lineTo(w * 0.78f, h * 0.28f) // Gate C42
                }
                drawPath(
                    path = navPath,
                    color = CafRedChina,
                    style = Stroke(
                        width = 3.5f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 6f), 0f)
                    )
                )

                // Location Points
                // 1. Current Location (You)
                drawCircle(color = CafWarmWhite, radius = 6f, center = Offset(w * 0.22f, h * 0.70f))
                drawCircle(color = CafRedChina, radius = 3f, center = Offset(w * 0.22f, h * 0.70f))

                // 2. Lounge (CAF)
                drawCircle(color = CafGold, radius = 5f, center = Offset(w * 0.50f, h * 0.38f))

                // 3. Gate C42 (Destination)
                drawCircle(color = CafRedChina.copy(alpha = 0.4f), radius = 14f, center = Offset(w * 0.78f, h * 0.28f))
                drawCircle(color = CafRedChina, radius = 6f, center = Offset(w * 0.78f, h * 0.28f))
                drawCircle(color = CafWarmWhite, radius = 2.5f, center = Offset(w * 0.78f, h * 0.28f))
            }

            // Map Overlays
            Box(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .clip(RoundedCornerShape(4.dp))
                    .background(CafBlackCardElevated)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "● 您当前位于 K01 值机岛附近",
                    fontSize = 9.sp,
                    color = CafWarmWhite
                )
            }

            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .clip(RoundedCornerShape(4.dp))
                    .background(CafRedChina)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "C42 登机口 · 09:05 开放",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = CafWarmWhite
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // POI Selectors
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(poiList) { (code, name) ->
                val isSelected = selectedNode == code
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) CafRedChina else CafBlackSurface)
                        .border(1.dp, if (isSelected) CafRedBright else CafBlackBorder, RoundedCornerShape(8.dp))
                        .clickable { onSelectNode(code) }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag("poi_button_$code")
                ) {
                    Text(
                        text = name,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) CafWarmWhite else CafTitaniumLight
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Lounge / Gate Detail Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(CafBlackSurface)
                .border(1.dp, CafBlackBorder, RoundedCornerShape(12.dp))
                .padding(12.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = loungeInfo.name,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = CafWarmWhite
                    )
                    Text(
                        text = loungeInfo.hours,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = CafGold
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "● ${loungeInfo.crowdStatus} · ${loungeInfo.diningStatus}",
                    fontSize = 10.sp,
                    color = CafTitaniumLight
                )
            }
        }
    }
}
