package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Nfc
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.DigitalBoardingPass
import com.example.ui.theme.*

@Composable
fun DigitalBoardingPassModal(
    pass: DigitalBoardingPass,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(CafBlackDeep.copy(alpha = 0.92f))
                .padding(20.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .wrapContentHeight()
            ) {
                // Top Close Action
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "DIGITAL AVIATION IDENTITY",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = CafTitaniumLight,
                        letterSpacing = 1.2.sp
                    )
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(CafBlackCardElevated)
                            .testTag("close_boarding_pass_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "关闭",
                            tint = CafWarmWhite,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Pass Container Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(CafBlackCard)
                        .border(1.dp, CafRedChina.copy(alpha = 0.6f), RoundedCornerShape(20.dp))
                        .testTag("digital_boarding_pass_card")
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // Header Ribbon
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(CafRedChina)
                                .padding(horizontal = 20.dp, vertical = 14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "CHINA AIR FUTURE",
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = CafWarmWhite,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = "华航未来 · 电子登机通行证",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = CafWarmWhite
                                )
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Nfc,
                                    contentDescription = "NFC Enabled",
                                    tint = CafWarmWhite,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = "NFC READY",
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = CafWarmWhite
                                )
                            }
                        }

                        // Passenger & Flight Info Body
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp)
                        ) {
                            // Passenger Name & Cabin Class
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "PASSENGER 乘客",
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = CafTitaniumGrey
                                    )
                                    Text(
                                        text = pass.passengerName,
                                        fontSize = 18.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = CafWarmWhite
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(CafBlackSurface)
                                        .border(1.dp, CafGold.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = pass.cabinClass,
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = CafGold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(18.dp))

                            // Route: SHA -> PEK
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = pass.fromIata,
                                        fontSize = 32.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Black,
                                        color = CafWarmWhite
                                    )
                                    Text(
                                        text = "上海虹桥 SHA",
                                        fontSize = 11.sp,
                                        color = CafTitaniumLight
                                    )
                                }

                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = pass.flightNumber,
                                        fontSize = 13.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = CafRedBright
                                    )
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                        contentDescription = null,
                                        tint = CafRedChina,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = pass.toIata,
                                        fontSize = 32.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Black,
                                        color = CafWarmWhite
                                    )
                                    Text(
                                        text = "北京首都 PEK",
                                        fontSize = 11.sp,
                                        color = CafTitaniumLight
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(20.dp))

                            // Gate, Boarding Time, Seat, Group Matrix
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(CafBlackSurface)
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                PassSpecColumn(title = "GATE 登机口", value = pass.gate, isRed = true)
                                PassSpecColumn(title = "BOARDING 登机", value = pass.boardingTime)
                                PassSpecColumn(title = "SEAT 座位", value = pass.seat, isRed = true)
                                PassSpecColumn(title = "GROUP 组别", value = pass.boardingGroup)
                            }
                        }

                        // Dashed Cut Divider
                        Canvas(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(1.dp)
                        ) {
                            drawLine(
                                color = CafBlackBorder,
                                start = Offset(0f, 0f),
                                end = Offset(size.width, 0f),
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 10f), 0f),
                                strokeWidth = 2f
                            )
                        }

                        // Barcode & QR Code Section
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(CafBlackSurface)
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            // Realistic Simulated Barcode Canvas
                            Canvas(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(54.dp)
                            ) {
                                val barWidth = size.width / 68
                                val pattern = listOf(
                                    3,1,2,1,4,1,2,3,1,2,1,4,2,1,3,1,2,2,4,1,1,3,2,1,4,1,2,1,3,2,
                                    1,4,2,1,1,3,2,1,4,1,2,3,1,2,1,4,2,1,3,1,2,2,4,1,1,3,2,1,4,1
                                )
                                var curX = 0f
                                pattern.forEachIndexed { i, widthMultiplier ->
                                    if (i % 2 == 0) {
                                        drawRect(
                                            color = CafWarmWhite,
                                            topLeft = Offset(curX, 0f),
                                            size = androidx.compose.ui.geometry.Size(barWidth * widthMultiplier, size.height)
                                        )
                                    }
                                    curX += barWidth * widthMultiplier
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = "ETKT ${pass.eTicketNumber} · SEQ ${pass.sequenceNumber}",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = CafTitaniumGrey,
                                letterSpacing = 1.sp
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = "● 人脸识别闸机已就绪 · 可直接刷脸或贴近 NFC 登机",
                                fontSize = 10.sp,
                                color = CafStatusGreen
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PassSpecColumn(
    title: String,
    value: String,
    isRed: Boolean = false
) {
    Column {
        Text(
            text = title,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            color = CafTitaniumGrey
        )
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = value,
            fontSize = 16.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = if (isRed) CafRedBright else CafWarmWhite
        )
    }
}
