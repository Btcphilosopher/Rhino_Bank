package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Flight
import com.example.model.PassengerJourneyState
import com.example.ui.theme.*

@Composable
fun LiveTravelObjectCard(
    flight: Flight,
    journeyState: PassengerJourneyState,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    onOpenBoardingPass: () -> Unit,
    onOpenSeatMap: () -> Unit,
    onNavigateAirport: () -> Unit,
    onOpenBaggage: () -> Unit,
    onAdvanceJourney: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        CafBlackCardElevated,
                        CafBlackCard,
                        CafBlackSurface
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        CafRedChina.copy(alpha = 0.6f),
                        CafBlackBorder,
                        CafBlackBorder.copy(alpha = 0.2f)
                    )
                ),
                shape = RoundedCornerShape(20.dp)
            )
            .clickable { onToggleExpand() }
            .padding(20.dp)
            .testTag("live_travel_object_card")
    ) {
        Column(
            modifier = Modifier.fillMaxWidth()
        ) {
            // Top Badge & Subtitle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(CafRedChina)
                    )
                    Text(
                        text = "下一段旅程 · NEXT JOURNEY",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold,
                        color = CafRedBright,
                        letterSpacing = 1.sp
                    )
                }

                Text(
                    text = flight.aircraftModel,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = CafTitaniumLight
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Main Route: 上海 → 北京
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = flight.originCity,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = CafWarmWhite
                    )
                    Text(
                        text = "${flight.originIata} · ${flight.originTerminal}",
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace,
                        color = CafTitaniumLight
                    )
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = flight.durationText,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = CafTitaniumGrey
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .width(28.dp)
                                .height(1.dp)
                                .background(CafTitaniumGrey)
                        )
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "航向",
                            tint = CafRedChina,
                            modifier = Modifier.size(16.dp)
                        )
                        Box(
                            modifier = Modifier
                                .width(28.dp)
                                .height(1.dp)
                                .background(CafTitaniumGrey)
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = flight.flightStatus,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium,
                        color = CafStatusGreen
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = flight.destinationCity,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = CafWarmWhite
                    )
                    Text(
                        text = "${flight.destinationIata} · ${flight.destinationTerminal}",
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace,
                        color = CafTitaniumLight
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Aviation Specs Grid: Flight, Dep Time, Gate, Seat
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(CafBlackSurface)
                    .border(1.dp, CafBlackBorder, RoundedCornerShape(12.dp))
                    .padding(vertical = 12.dp, horizontal = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                AviationSpecItem(label = "航班", value = flight.flightNumber, isHighlight = true)
                AviationSpecItem(label = "起飞时间", value = flight.scheduledDeparture)
                AviationSpecItem(label = "登机口", value = flight.gate, isHighlight = true)
                AviationSpecItem(label = "座位", value = "12A")
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Journey State Progress Scrubber Overview
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                val stages = listOf("值机", "安检", "登机", "起飞", "抵达")
                val activeStep = when (journeyState) {
                    PassengerJourneyState.BOOKED -> 0
                    PassengerJourneyState.CHECKED_IN -> 0
                    PassengerJourneyState.AT_AIRPORT, PassengerJourneyState.SECURITY -> 1
                    PassengerJourneyState.AT_GATE, PassengerJourneyState.BOARDING -> 2
                    PassengerJourneyState.TAXI, PassengerJourneyState.TAKEOFF, PassengerJourneyState.CRUISE, PassengerJourneyState.DESCENT -> 3
                    else -> 4
                }

                stages.forEachIndexed { idx, stageName ->
                    val isDone = idx <= activeStep
                    val isCurrent = idx == activeStep
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(if (isCurrent) 8.dp else 6.dp)
                                .clip(CircleShape)
                                .background(
                                    if (isCurrent) CafRedBright
                                    else if (isDone) CafWarmWhite
                                    else CafMutedText
                                )
                        )
                        Text(
                            text = stageName,
                            fontSize = 11.sp,
                            fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                            color = if (isCurrent) CafRedBright else if (isDone) CafWarmWhite else CafMutedText
                        )
                    }
                }
            }

            // Expandable Journey Mode Details & One-Touch Actions
            AnimatedVisibility(
                visible = isExpanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(CafBlackBorder)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "JOURNEY MODE · 行程全景指令",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold,
                        color = CafTitaniumLight,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // 4 Quick Action Cards
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ActionCard(
                            title = "电子登机牌",
                            sub = "QR / NFC",
                            icon = Icons.Default.QrCode2,
                            onClick = onOpenBoardingPass,
                            modifier = Modifier.weight(1f)
                        )
                        ActionCard(
                            title = "我的座位",
                            sub = "12A 商务舱",
                            icon = Icons.Default.AirlineSeatReclineExtra,
                            onClick = onOpenSeatMap,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ActionCard(
                            title = "机场导航",
                            sub = "步行 4 分钟",
                            icon = Icons.Default.Navigation,
                            onClick = onNavigateAirport,
                            modifier = Modifier.weight(1f)
                        )
                        ActionCard(
                            title = "行李追踪",
                            sub = "BAG 01 已装机",
                            icon = Icons.Default.Luggage,
                            onClick = onOpenBaggage,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Next CTA Button based on State
                    Button(
                        onClick = onAdvanceJourney,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("journey_advance_cta_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CafRedChina,
                            contentColor = CafWarmWhite
                        )
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = journeyState.nextActionTitle,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AviationSpecItem(
    label: String,
    value: String,
    isHighlight: Boolean = false
) {
    Column {
        Text(
            text = label,
            fontSize = 10.sp,
            color = CafTitaniumGrey,
            fontFamily = FontFamily.SansSerif
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            fontSize = 14.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = if (isHighlight) CafRedBright else CafWarmWhite
        )
    }
}

@Composable
private fun ActionCard(
    title: String,
    sub: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(CafBlackSurface)
            .border(1.dp, CafBlackBorder, RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = CafRedChina,
            modifier = Modifier.size(20.dp)
        )
        Column {
            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = CafWarmWhite
            )
            Text(
                text = sub,
                fontSize = 10.sp,
                color = CafTitaniumGrey
            )
        }
    }
}
