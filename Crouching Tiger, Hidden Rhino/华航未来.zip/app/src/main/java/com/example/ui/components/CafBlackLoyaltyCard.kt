package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PassengerProfile
import com.example.model.WalletInfo
import com.example.ui.theme.*

@Composable
fun CafBlackLoyaltyCard(
    profile: PassengerProfile,
    wallet: WalletInfo,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(CafBlackCard)
            .border(1.dp, CafBlackBorder, RoundedCornerShape(20.dp))
            .padding(18.dp)
            .testTag("caf_black_loyalty_card_container")
    ) {
        // CAF BLACK Metallic Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            CafBlackCardElevated,
                            Color(0xFF161616),
                            Color(0xFF0A0A0A)
                        )
                    )
                )
                .border(
                    width = 1.dp,
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            CafRedChina,
                            CafBlackBorder,
                            CafGold.copy(alpha = 0.6f)
                        )
                    ),
                    shape = RoundedCornerShape(16.dp)
                )
                .padding(18.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Top Row: Brand & Black Tier Badge
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "CHINA AIR FUTURE",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = CafWarmWhite,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "领航黑卡 · CAF BLACK",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = CafRedBright
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(CafRedChina),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "CAF",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = CafWarmWhite
                        )
                    }
                }

                // Center: Card Number & Passenger Name
                Column {
                    Text(
                        text = profile.memberId,
                        fontSize = 17.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = CafWarmWhite,
                        letterSpacing = 2.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${profile.nameZh} · ${profile.nameEn}",
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        color = CafTitaniumLight
                    )
                }

                // Bottom: Mileage Points & Lifetime status
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "可用里程: ${wallet.points} PTS",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = CafGold
                    )
                    Text(
                        text = "LIFETIME VIP · 终身贵宾",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = CafTitaniumGrey
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Digital Travel Passport Specs
        Text(
            text = "DIGITAL TRAVEL PASSPORT · 数字航行护照",
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = CafRedChina,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(CafBlackSurface)
                .border(1.dp, CafBlackBorder, RoundedCornerShape(12.dp))
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            PassportSpec(title = "执飞航段", value = "48 次")
            PassportSpec(title = "点亮城市", value = "12 座")
            PassportSpec(title = "飞行总里程", value = "126,800 km")
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Black Tier Privileges List
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            PrivilegeItem(icon = Icons.Default.Shield, title = "极速安检通道", desc = "全球华航主要枢纽专属绿色通道")
            PrivilegeItem(icon = Icons.Default.Weekend, title = "领航贵宾厅无限次", desc = "尊享私人休憩套房、主厨现做热食")
            PrivilegeItem(icon = Icons.Default.PriorityHigh, title = "行李极速直挂", desc = "全程专人优先卸机与转盘即送")
        }
    }
}

@Composable
private fun PassportSpec(title: String, value: String) {
    Column {
        Text(text = title, fontSize = 10.sp, color = CafTitaniumGrey)
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = value,
            fontSize = 15.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = CafWarmWhite
        )
    }
}

@Composable
private fun PrivilegeItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    desc: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(CafBlackSurface)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = CafRedChina, modifier = Modifier.size(18.dp))
        Column {
            Text(text = title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CafWarmWhite)
            Text(text = desc, fontSize = 10.sp, color = CafTitaniumGrey)
        }
    }
}
