package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.viewmodel.AppNavTab
import com.example.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ChinaAirFutureApp(viewModel = viewModel)
        }
    }
}

@Composable
fun ChinaAirFutureApp(viewModel: MainViewModel) {
    ChinaAirFutureTheme {
        val uiState by viewModel.uiState.collectAsState()

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(CafBlackDeep)
        ) {
            Scaffold(
                modifier = Modifier.fillMaxSize(),
                containerColor = CafBlackDeep,
                bottomBar = {
                    FuturisticBottomBar(
                        currentTab = uiState.currentTab,
                        onSelectTab = { viewModel.setTab(it) }
                    )
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    when (uiState.currentTab) {
                        AppNavTab.HOME -> HomeScreen(
                            uiState = uiState,
                            viewModel = viewModel
                        )
                        AppNavTab.JOURNEY -> JourneyScreen(
                            uiState = uiState,
                            viewModel = viewModel
                        )
                        AppNavTab.NETWORK -> NetworkScreen(
                            uiState = uiState,
                            viewModel = viewModel
                        )
                        AppNavTab.AIRPORT -> AirportScreen(
                            uiState = uiState,
                            viewModel = viewModel
                        )
                        AppNavTab.MINE -> ProfileScreen(
                            uiState = uiState,
                            viewModel = viewModel
                        )
                    }
                }
            }

            // Modals and Overlays

            // 1. Digital Boarding Pass Modal
            if (uiState.isBoardingPassModalOpen) {
                DigitalBoardingPassModal(
                    pass = uiState.boardingPass,
                    onDismiss = { viewModel.setBoardingPassModal(false) }
                )
            }

            // 2. Futuristic Seat Map Modal
            if (uiState.isSeatMapModalOpen) {
                FuturisticSeatMapModal(
                    currentSeat = uiState.selectedSeatNumber,
                    onSelectSeat = { seat, cabinClass ->
                        viewModel.selectSeat(seat, cabinClass)
                    },
                    onConfirmCheckIn = {
                        viewModel.confirmCheckIn()
                    },
                    onDismiss = { viewModel.setSeatMapModal(false) }
                )
            }

            // 3. AI "航智" Assistant Dialog
            if (uiState.isAiAssistantOpen) {
                AiTravelAssistantDialog(
                    messages = uiState.chatMessages,
                    isTyping = uiState.isAiTyping,
                    onSendMessage = { viewModel.sendAiQuestion(it) },
                    onDismiss = { viewModel.setAiAssistantOpen(false) }
                )
            }

            // 4. Payment Sheet Modal
            if (uiState.isPaymentSheetOpen) {
                PaymentSheetModal(
                    flight = uiState.pendingBookingFlight,
                    walletBalance = uiState.wallet.balanceRmb,
                    onConfirmPayment = { method ->
                        viewModel.confirmPaymentAndBooking(method)
                    },
                    onDismiss = { viewModel.setPaymentSheetOpen(false) }
                )
            }

            // 5. Simulation Journey State Controller Dialog
            if (uiState.isDemoControlOpen) {
                DemoControlDialog(
                    currentState = uiState.journeyState,
                    onSelectState = { viewModel.setJourneyState(it) },
                    onDismiss = { viewModel.setDemoControlOpen(false) }
                )
            }

            // 6. Booking Success Dialog
            if (uiState.isBookingSuccessDialogOpen) {
                AlertDialog(
                    onDismissRequest = { viewModel.dismissBookingSuccess() },
                    containerColor = CafBlackCard,
                    shape = RoundedCornerShape(20.dp),
                    title = {
                        Text(
                            text = "航班出票成功",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = CafWarmWhite
                        )
                    },
                    text = {
                        Text(
                            text = "您已成功预订 ${uiState.activeFlight.flightNumber} (${uiState.activeFlight.originCity} → ${uiState.activeFlight.destinationCity})。航程数据已同步至您的全景行程中心及「航智」随行助理。",
                            fontSize = 13.sp,
                            color = CafTitaniumLight,
                            lineHeight = 18.sp
                        )
                    },
                    confirmButton = {
                        Button(
                            onClick = { viewModel.dismissBookingSuccess() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CafRedChina,
                                contentColor = CafWarmWhite
                            ),
                            modifier = Modifier.testTag("dismiss_booking_success_button")
                        ) {
                            Text("进入行程")
                        }
                    }
                )
            }

            // 7. Check-in Success Dialog
            if (uiState.isCheckInSuccessDialogOpen) {
                AlertDialog(
                    onDismissRequest = { viewModel.dismissCheckInSuccess() },
                    containerColor = CafBlackCard,
                    shape = RoundedCornerShape(20.dp),
                    title = {
                        Text(
                            text = "值机与选座成功",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = CafWarmWhite
                        )
                    },
                    text = {
                        Text(
                            text = "您已成功选定座位 ${uiState.selectedSeatNumber} (${uiState.seatInfo.positionType})。电子登机牌及智能行李标签已生成，您可随时通过 NFC 或人脸识别便捷登机。",
                            fontSize = 13.sp,
                            color = CafTitaniumLight,
                            lineHeight = 18.sp
                        )
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                viewModel.dismissCheckInSuccess()
                                viewModel.setBoardingPassModal(true)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CafRedChina,
                                contentColor = CafWarmWhite
                            ),
                            modifier = Modifier.testTag("view_boarding_pass_after_checkin_button")
                        ) {
                            Text("查看电子登机牌")
                        }
                    }
                )
            }
        }
    }
}
