package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Chinese Futurism / 中国未来主义 Core Palette

// 墨黑 / 深黑 (Blacks & Deep Space)
val CafBlackDeep = Color(0xFF090A0D)
val CafBlackInk = Color(0xFF0F1117)
val CafBlackSurface = Color(0xFF151820)
val CafBlackCard = Color(0xFF1B1F2A)
val CafBlackCardElevated = Color(0xFF242938)
val CafBlackBorder = Color(0xFF2C3242)
val CafBlackDivider = Color(0xFF1E2330)

// 中国红 / 深朱红 (China Red & Vermilion)
val CafRedChina = Color(0xFFE52B2B)
val CafRedVermilion = Color(0xFFD32020)
val CafRedBright = Color(0xFFFF3B30)
val CafRedCrimson = Color(0xFF9E1515)
val CafRedGlow = Color(0x33E52B2B)
val CafRedGlowStrong = Color(0x66E52B2B)

// 暗银 / 钛灰 / 铂金 (Silver & Titanium)
val CafTitaniumGrey = Color(0xFF8E95A5)
val CafTitaniumLight = Color(0xFFB0B8C8)
val CafPlatinum = Color(0xFFD8DDE6)
val CafSilverDark = Color(0xFF5A6170)

// 暖白 (Warm White)
val CafWarmWhite = Color(0xFFF6F7FA)
val CafWhiteSubtle = Color(0xFFE2E4EB)
val CafMutedText = Color(0xFF6B7280)

// 少量金属金 (Metallic Gold - CAF Black Loyalty)
val CafGold = Color(0xFFD4AF37)
val CafGoldDark = Color(0xFF8C7322)
val CafGoldSubtle = Color(0x22D4AF37)

// 状态指示色 (Functional Status)
val CafStatusGreen = Color(0xFF10B981)
val CafStatusAmber = Color(0xFFF59E0B)
val CafStatusBlue = Color(0xFF38BDF8)
