package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FlightTelemetry
import com.example.ui.theme.*

data class EntertainmentItem(
    val title: String,
    val duration: String,
    val genre: String,
    val rating: String
)

@Composable
fun CabinEntertainmentView(
    telemetry: FlightTelemetry,
    isPlayingAudio: Boolean,
    onToggleAudio: () -> Unit,
    selectedCategory: String,
    onSelectCategory: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val categories = listOf("精选电影", "高解析音乐", "空中播客", "人文纪录片", "机上点餐")
    val movies = listOf(
        EntertainmentItem("《流浪地球 3：天际领航》", "148 min", "科幻 / 未来航天", "9.4"),
        EntertainmentItem("《中国商飞：C919 之翼》", "92 min", "工程纪录片", "9.6"),
        EntertainmentItem("《上海 2040：未来纪元》", "115 min", "城市建筑与人文", "9.1"),
        EntertainmentItem("《大国重器：空天互联》", "85 min", "科技前沿", "9.3")
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(CafBlackCard)
            .border(1.dp, CafBlackBorder, RoundedCornerShape(20.dp))
            .padding(18.dp)
            .testTag("cabin_entertainment_view")
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "CAF SCREEN · 机上数字视界",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = CafRedChina,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "客舱伴侣 · 4K 极清娱乐与服务",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = CafWarmWhite
                )
            }

            // In-flight Ambient Audio Synthesizer toggle
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(if (isPlayingAudio) CafRedChina else CafBlackSurface)
                    .border(1.dp, if (isPlayingAudio) CafRedBright else CafBlackBorder, RoundedCornerShape(20.dp))
                    .clickable { onToggleAudio() }
                    .padding(horizontal = 10.dp, vertical = 5.dp)
                    .testTag("cabin_audio_toggle_button"),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = if (isPlayingAudio) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                    contentDescription = null,
                    tint = CafWarmWhite,
                    modifier = Modifier.size(14.dp)
                )
                Text(
                    text = if (isPlayingAudio) "白噪音播放中" else "降噪白噪音",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = CafWarmWhite
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Categories Chips
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(categories) { cat ->
                val isSelected = cat == selectedCategory
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) CafRedChina else CafBlackSurface)
                        .border(1.dp, if (isSelected) CafRedBright else CafBlackBorder, RoundedCornerShape(8.dp))
                        .clickable { onSelectCategory(cat) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .testTag("entertainment_cat_$cat")
                ) {
                    Text(
                        text = cat,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) CafWarmWhite else CafTitaniumLight
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // In-flight Media list
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            movies.forEach { movie ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(CafBlackSurface)
                        .border(1.dp, CafBlackBorder, RoundedCornerShape(10.dp))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(CafRedChina.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "播放",
                                tint = CafRedChina,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Column {
                            Text(text = movie.title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CafWarmWhite)
                            Text(text = "${movie.genre} · ${movie.duration}", fontSize = 10.sp, color = CafTitaniumGrey)
                        }
                    }

                    Text(
                        text = "★ ${movie.rating}",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = CafGold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // In-flight Service Calling buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { /* Call Attendant */ },
                modifier = Modifier.weight(1f).height(40.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CafBlackSurface, contentColor = CafWarmWhite),
                border = androidx.compose.foundation.BorderStroke(1.dp, CafBlackBorder)
            ) {
                Icon(imageVector = Icons.Default.NotificationsActive, contentDescription = null, tint = CafRedBright, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "呼叫乘务员", fontSize = 11.sp)
            }

            Button(
                onClick = { /* Order Water */ },
                modifier = Modifier.weight(1f).height(40.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CafBlackSurface, contentColor = CafWarmWhite),
                border = androidx.compose.foundation.BorderStroke(1.dp, CafBlackBorder)
            ) {
                Icon(imageVector = Icons.Default.LocalCafe, contentDescription = null, tint = CafGold, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "点特调茶饮", fontSize = 11.sp)
            }
        }
    }
}
