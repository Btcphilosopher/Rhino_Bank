package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.PassengerJourneyState
import com.example.ui.theme.*

@Composable
fun DemoControlDialog(
    currentState: PassengerJourneyState,
    onSelectState: (PassengerJourneyState) -> Unit,
    onDismiss: () -> Unit
) {
    val allStates = PassengerJourneyState.entries

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(CafBlackDeep.copy(alpha = 0.95f))
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "JOURNEY STATE SIMULATOR · 航程状态模拟器",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = CafRedChina,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "15 阶段旅程全景快进切换",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = CafWarmWhite
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(CafBlackCardElevated)
                            .testTag("close_demo_control_dialog")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "关闭",
                            tint = CafWarmWhite,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(allStates) { state ->
                        val isSelected = state == currentState
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) CafBlackCardElevated else CafBlackSurface)
                                .border(
                                    1.dp,
                                    if (isSelected) CafRedChina else CafBlackBorder,
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable {
                                    onSelectState(state)
                                    onDismiss()
                                }
                                .padding(14.dp)
                                .testTag("sim_state_item_${state.name}"),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(if (isSelected) CafRedChina else CafBlackBorder),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "${allStates.indexOf(state) + 1}",
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = CafWarmWhite
                                    )
                                }
                                Column {
                                    Text(
                                        text = "${state.labelZh} · ${state.shortName}",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) CafRedBright else CafWarmWhite
                                    )
                                    Text(
                                        text = state.description,
                                        fontSize = 10.sp,
                                        color = CafTitaniumGrey
                                    )
                                }
                            }

                            if (isSelected) {
                                Text(
                                    text = "当前激活",
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = CafRedBright
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
