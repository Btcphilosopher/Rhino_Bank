package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.components.AirportDigitalTwinView
import com.example.ui.components.FuturisticTopBar
import com.example.ui.components.JourneyStateScrubber
import com.example.ui.theme.CafBlackDeep
import com.example.viewmodel.MainUiState
import com.example.viewmodel.MainViewModel

@Composable
fun AirportScreen(
    uiState: MainUiState,
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CafBlackDeep)
            .verticalScroll(scrollState)
            .padding(bottom = 90.dp)
            .testTag("airport_screen_content")
    ) {
        FuturisticTopBar(
            journeyState = uiState.journeyState,
            onOpenAiAssistant = { viewModel.setAiAssistantOpen(true) },
            onOpenDemoControl = { viewModel.setDemoControlOpen(true) }
        )

        JourneyStateScrubber(
            currentState = uiState.journeyState,
            onSelectState = { viewModel.setJourneyState(it) }
        )

        Spacer(modifier = Modifier.height(10.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            AirportDigitalTwinView(
                is3DMode = uiState.airportMapMode3D,
                onToggle3D = { viewModel.toggleAirportMap3D() },
                selectedNode = uiState.selectedAirportNode,
                onSelectNode = { viewModel.selectAirportNode(it) },
                loungeInfo = uiState.lounge,
                onOpenBoardingPass = { viewModel.setBoardingPassModal(true) }
            )
        }
    }
}
