package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FlightTelemetry
import com.example.ui.theme.*

@Composable
fun FlightMapCanvas(
    telemetry: FlightTelemetry,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(CafBlackCard)
            .border(1.dp, CafBlackBorder, RoundedCornerShape(20.dp))
            .padding(18.dp)
            .testTag("flight_map_canvas_container")
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "LIVE ROUTE TRAJECTORY · 实时航线轨迹",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = CafRedChina,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "上海虹桥 SHA ✈ 北京首都 PEK",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = CafWarmWhite
                )
            }
            Text(
                text = "FL350 / 880 KM/H",
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                color = CafTitaniumLight
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Futuristic Route Canvas
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(190.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(CafBlackDeep)
                .border(1.dp, CafBlackBorder, RoundedCornerShape(14.dp))
                .padding(12.dp)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height

                // Background City Grid Nodes (Network context)
                val cities = listOf(
                    Triple("北京", w * 0.40f, h * 0.22f),
                    Triple("上海", w * 0.78f, h * 0.75f),
                    Triple("深圳", w * 0.65f, h * 0.90f),
                    Triple("香港", w * 0.68f, h * 0.96f),
                    Triple("东京", w * 0.94f, h * 0.45f),
                    Triple("首尔", w * 0.72f, h * 0.28f)
                )

                // Secondary subtle network routes
                cities.forEach { (_, cx, cy) ->
                    drawCircle(color = CafBlackBorder, radius = 4f, center = Offset(cx, cy))
                }

                // Active Flight Route Arc (Shanghai -> Beijing)
                val sha = Offset(w * 0.78f, h * 0.75f)
                val pek = Offset(w * 0.40f, h * 0.22f)
                val ctrlPoint = Offset(w * 0.48f, h * 0.60f)

                val routePath = Path().apply {
                    moveTo(sha.x, sha.y)
                    quadraticTo(ctrlPoint.x, ctrlPoint.y, pek.x, pek.y)
                }

                // Route trajectory line
                drawPath(
                    path = routePath,
                    color = CafRedChina,
                    style = Stroke(width = 3.5f)
                )

                // Current Plane Position interpolated by telemetry.progressPercent
                val t = telemetry.progressPercent
                // Quadratic bezier formula: B(t) = (1-t)^2 * P0 + 2(1-t)t * P1 + t^2 * P2
                val curX = (1 - t) * (1 - t) * sha.x + 2 * (1 - t) * t * ctrlPoint.x + t * t * pek.x
                val curY = (1 - t) * (1 - t) * sha.y + 2 * (1 - t) * t * ctrlPoint.y + t * t * pek.y

                // Plane Glow & Ping
                drawCircle(color = CafRedChina.copy(alpha = 0.35f), radius = 16f, center = Offset(curX, curY))
                drawCircle(color = CafRedBright, radius = 6f, center = Offset(curX, curY))
                drawCircle(color = CafWarmWhite, radius = 2.5f, center = Offset(curX, curY))

                // Endpoint Airport Rings
                drawCircle(color = CafWarmWhite, radius = 6f, center = sha)
                drawCircle(color = CafRedChina, radius = 3f, center = sha)

                drawCircle(color = CafWarmWhite, radius = 6f, center = pek)
                drawCircle(color = CafRedChina, radius = 3f, center = pek)
            }

            // Route End City Labels
            Text(
                text = "北京 PEK",
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = CafWarmWhite,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(start = 28.dp, top = 20.dp)
            )

            Text(
                text = "上海 SHA",
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = CafWarmWhite,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 28.dp, bottom = 22.dp)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Live Flight Telemetry Specs Grid
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(CafBlackSurface)
                .border(1.dp, CafBlackBorder, RoundedCornerShape(12.dp))
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            TelemetryItem(title = "飞行高度", value = "${telemetry.altitudeFt} ft", sub = "10,668 m")
            TelemetryItem(title = "真空地速", value = "${telemetry.groundSpeedKmh} km/h", sub = "Mach 0.78")
            TelemetryItem(title = "剩余时间", value = telemetry.timeRemainingText, sub = "预计准点", isRed = true)
        }
    }
}

@Composable
private fun TelemetryItem(
    title: String,
    value: String,
    sub: String,
    isRed: Boolean = false
) {
    Column {
        Text(text = title, fontSize = 10.sp, color = CafTitaniumGrey)
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            fontSize = 14.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = if (isRed) CafRedBright else CafWarmWhite
        )
        Text(text = sub, fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = CafTitaniumLight)
    }
}
