package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.SeatInfo
import com.example.ui.theme.*

data class AircraftComponentInfo(
    val id: String,
    val nameZh: String,
    val nameEn: String,
    val specTitle: String,
    val description: String,
    val status: String,
    val isHighlighted: Boolean = false
)

@Composable
fun AircraftDigitalTwinView(
    seatInfo: SeatInfo,
    selectedPart: String,
    onSelectPart: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val components = listOf(
        AircraftComponentInfo("cockpit", "驾驶舱", "COCKPIT", "双人数字航电", "搭载双冗余光传线控及星地数字链路", "工作正常 · 自动巡航中"),
        AircraftComponentInfo("business", "商务舱", "BUSINESS CABIN", "1-2-1 错位全平躺", "您的专属座位 12A 位于此处，配备独立降噪空间", "已分配 · 12A 靠窗", isHighlighted = true),
        AircraftComponentInfo("economy", "经济舱", "ECONOMY CABIN", "3-3 人体工学座椅", "全舱配备 4K OLED 娱乐屏及 65W USB-C 接口", "满载 88%"),
        AircraftComponentInfo("galley", "厨房", "GALLEY", "微波/蒸烤双系统", "全天候提供手冲咖啡、苏式点心与冷热饮品", "服务备餐中"),
        AircraftComponentInfo("lavatory", "洗手间", "LAVATORY", "非接触式感应除菌", "前舱与中舱共设 4 处智能清洁洗手间", "绿灯空闲"),
        AircraftComponentInfo("cargo", "货舱", "CARGO HOLD", "恒温智能分拣舱", "您的托运行李 BAG 01 已安全锁固于 2B 货舱区", "温度 18°C 正常"),
        AircraftComponentInfo("wing", "超临界机翼", "SUPERCRITICAL WING", "复合碳纤维翼尖", "高效升阻比气动布局，提升颠簸平稳度", "气动状态优"),
        AircraftComponentInfo("engine", "先进发动机", "GEAP-1A ENGINES", "超高涵道比涡扇", "静音降噪巡航，低碳排放", "转速 N1 86% 正常")
    )

    val currentComponent = components.find { it.nameZh == selectedPart } ?: components[1]

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(CafBlackCard)
            .border(1.dp, CafBlackBorder, RoundedCornerShape(20.dp))
            .padding(18.dp)
            .testTag("aircraft_digital_twin_container")
    ) {
        // Section Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "AIRCRAFT DIGITAL TWIN · 客机数字孪生",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = CafRedChina,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "A321-Neo Future / C919 智能客舱系统",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = CafWarmWhite
                )
            }
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(CafBlackSurface)
                    .border(1.dp, CafBlackBorder, RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "B-8802 · ONLINE",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = CafStatusGreen
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Custom Architectural Aircraft Blueprint Canvas
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(150.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(CafBlackSurface)
                .border(1.dp, CafBlackBorder, RoundedCornerShape(14.dp))
                .padding(8.dp)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val centerY = h / 2f

                // Fuselage Outline
                val fuselagePath = Path().apply {
                    moveTo(w * 0.92f, centerY) // Nose
                    cubicTo(w * 0.88f, centerY - 28f, w * 0.78f, centerY - 28f, w * 0.70f, centerY - 28f)
                    lineTo(w * 0.20f, centerY - 28f)
                    cubicTo(w * 0.12f, centerY - 28f, w * 0.08f, centerY - 14f, w * 0.06f, centerY)
                    cubicTo(w * 0.08f, centerY + 14f, w * 0.12f, centerY + 28f, w * 0.20f, centerY + 28f)
                    lineTo(w * 0.70f, centerY + 28f)
                    cubicTo(w * 0.78f, centerY + 28f, w * 0.88f, centerY + 28f, w * 0.92f, centerY)
                    close()
                }
                drawPath(fuselagePath, color = CafBlackBorder, style = Stroke(width = 2f))

                // Delta Wings
                val leftWing = Path().apply {
                    moveTo(w * 0.58f, centerY - 28f)
                    lineTo(w * 0.36f, centerY - 68f)
                    lineTo(w * 0.30f, centerY - 66f)
                    lineTo(w * 0.42f, centerY - 28f)
                    close()
                }
                val rightWing = Path().apply {
                    moveTo(w * 0.58f, centerY + 28f)
                    lineTo(w * 0.36f, centerY + 68f)
                    lineTo(w * 0.30f, centerY + 66f)
                    lineTo(w * 0.42f, centerY + 28f)
                    close()
                }
                drawPath(leftWing, color = CafBlackBorder.copy(alpha = 0.8f), style = Stroke(width = 1.5f))
                drawPath(rightWing, color = CafBlackBorder.copy(alpha = 0.8f), style = Stroke(width = 1.5f))

                // Engine Nacelles
                drawCircle(color = CafTitaniumGrey, radius = 6f, center = Offset(w * 0.45f, centerY - 48f))
                drawCircle(color = CafTitaniumGrey, radius = 6f, center = Offset(w * 0.45f, centerY + 48f))

                // Seat 12A Glowing Red Coordinate Locator
                val seatX = w * 0.65f
                val seatY = centerY - 14f
                drawCircle(color = CafRedChina.copy(alpha = 0.3f), radius = 14f, center = Offset(seatX, seatY))
                drawCircle(color = CafRedChina, radius = 6f, center = Offset(seatX, seatY))
                drawCircle(color = CafWarmWhite, radius = 2.5f, center = Offset(seatX, seatY))

                // Cargo Hold Indicator
                val cargoX = w * 0.40f
                val cargoY = centerY + 12f
                drawRect(
                    color = CafGold.copy(alpha = 0.4f),
                    topLeft = Offset(cargoX - 16f, cargoY - 6f),
                    size = Size(32f, 12f),
                    style = Stroke(width = 1.5f)
                )
            }

            // Seat Overlay Label
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .clip(RoundedCornerShape(6.dp))
                    .background(CafRedChina.copy(alpha = 0.9f))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "12A 座位位置",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = CafWarmWhite
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Component Category Selector Chips
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(components) { item ->
                val isSelected = item.nameZh == selectedPart
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) CafRedChina else CafBlackSurface)
                        .border(
                            1.dp,
                            if (isSelected) CafRedBright else CafBlackBorder,
                            RoundedCornerShape(8.dp)
                        )
                        .clickable { onSelectPart(item.nameZh) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .testTag("aircraft_part_${item.id}")
                ) {
                    Text(
                        text = item.nameZh,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) CafWarmWhite else CafTitaniumLight
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Selected Component Specs Inspector
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(CafBlackSurface)
                .border(1.dp, CafBlackBorder, RoundedCornerShape(12.dp))
                .padding(12.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = currentComponent.nameZh,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = CafWarmWhite
                        )
                        Text(
                            text = currentComponent.nameEn,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = CafTitaniumGrey
                        )
                    }

                    Text(
                        text = currentComponent.status,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (currentComponent.isHighlighted) CafRedBright else CafStatusGreen
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = currentComponent.specTitle,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = CafTitaniumLight
                )

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = currentComponent.description,
                    fontSize = 11.sp,
                    color = CafTitaniumGrey,
                    lineHeight = 16.sp
                )
            }
        }
    }
}
