package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.model.PassengerJourneyState
import com.example.ui.components.*
import com.example.ui.theme.CafBlackDeep
import com.example.viewmodel.MainUiState
import com.example.viewmodel.MainViewModel

@Composable
fun HomeScreen(
    uiState: MainUiState,
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CafBlackDeep)
            .verticalScroll(scrollState)
            .padding(bottom = 90.dp)
            .testTag("home_screen_content")
    ) {
        // Top Bar
        FuturisticTopBar(
            journeyState = uiState.journeyState,
            onOpenAiAssistant = { viewModel.setAiAssistantOpen(true) },
            onOpenDemoControl = { viewModel.setDemoControlOpen(true) }
        )

        // Journey 15-State Horizontal Scrubber
        JourneyStateScrubber(
            currentState = uiState.journeyState,
            onSelectState = { viewModel.setJourneyState(it) }
        )

        Spacer(modifier = Modifier.height(10.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Hero Interactive Live Travel Object
            LiveTravelObjectCard(
                flight = uiState.activeFlight,
                journeyState = uiState.journeyState,
                isExpanded = uiState.isJourneyExpanded,
                onToggleExpand = { viewModel.toggleJourneyExpanded() },
                onOpenBoardingPass = { viewModel.setBoardingPassModal(true) },
                onOpenSeatMap = { viewModel.setSeatMapModal(true) },
                onNavigateAirport = { viewModel.setTab(com.example.viewmodel.AppNavTab.AIRPORT) },
                onOpenBaggage = { /* scrolled or focus */ },
                onAdvanceJourney = { viewModel.nextJourneyState() }
            )

            // Dynamic Contextual Section depending on Active Journey State
            when (uiState.journeyState) {
                PassengerJourneyState.BOOKED,
                PassengerJourneyState.CHECKED_IN -> {
                    // Aircraft Digital Twin & Baggage
                    AircraftDigitalTwinView(
                        seatInfo = uiState.seatInfo,
                        selectedPart = uiState.selectedAircraftPart,
                        onSelectPart = { viewModel.selectAircraftPart(it) }
                    )
                    BaggageTrackerCard(baggage = uiState.baggage)
                }

                PassengerJourneyState.AT_AIRPORT,
                PassengerJourneyState.SECURITY,
                PassengerJourneyState.AT_GATE,
                PassengerJourneyState.BOARDING -> {
                    // Airport Digital Twin & Route Guide
                    AirportDigitalTwinView(
                        is3DMode = uiState.airportMapMode3D,
                        onToggle3D = { viewModel.toggleAirportMap3D() },
                        selectedNode = uiState.selectedAirportNode,
                        onSelectNode = { viewModel.selectAirportNode(it) },
                        loungeInfo = uiState.lounge,
                        onOpenBoardingPass = { viewModel.setBoardingPassModal(true) }
                    )
                    BaggageTrackerCard(baggage = uiState.baggage)
                }

                PassengerJourneyState.TAXI,
                PassengerJourneyState.TAKEOFF,
                PassengerJourneyState.CRUISE,
                PassengerJourneyState.DESCENT -> {
                    // Flight Route Map & In-Flight Screen
                    FlightMapCanvas(telemetry = uiState.telemetry)
                    CabinEntertainmentView(
                        telemetry = uiState.telemetry,
                        isPlayingAudio = uiState.cabinAudioPlaying,
                        onToggleAudio = { viewModel.toggleCabinAudio() },
                        selectedCategory = uiState.selectedEntertainmentCategory,
                        onSelectCategory = { viewModel.setEntertainmentCategory(it) }
                    )
                }

                PassengerJourneyState.LANDED,
                PassengerJourneyState.BAGGAGE,
                PassengerJourneyState.ARRIVED,
                PassengerJourneyState.CITY_MODE,
                PassengerJourneyState.NO_TRIP -> {
                    // City Arrival Mode & Luggage belt
                    CityArrivalView(
                        cityInfo = uiState.cityArrival,
                        onOpenBaggage = { /* focus baggage */ }
                    )
                    BaggageTrackerCard(baggage = uiState.baggage)
                }
            }
        }
    }
}
