package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CityDestinationInfo
import com.example.ui.theme.*

@Composable
fun CityArrivalView(
    cityInfo: CityDestinationInfo,
    onOpenBaggage: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(CafBlackCard)
            .border(1.dp, CafBlackBorder, RoundedCornerShape(20.dp))
            .padding(18.dp)
            .testTag("city_arrival_view")
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "CITY MODE · 目的地城市操作系统",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = CafRedChina,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "${cityInfo.cityNameZh} · 欢迎抵达首都",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = CafWarmWhite
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(CafBlackSurface)
                    .border(1.dp, CafBlackBorder, RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "${cityInfo.temperature} ${cityInfo.weatherCondition}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = CafGold
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Baggage Belt Prompt Card
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(CafBlackSurface)
                .border(1.dp, CafRedChina.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                .clickable { onOpenBaggage() }
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(CafRedChina.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = Icons.Default.Luggage, contentDescription = null, tint = CafRedBright, modifier = Modifier.size(20.dp))
                }
                Column {
                    Text(text = "行李转盘提取提示", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CafWarmWhite)
                    Text(text = "北京首都 T3 · 1层大厅 Belt 17", fontSize = 10.sp, color = CafTitaniumLight)
                }
            }

            Text(
                text = "正在送达",
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = CafStatusGreen
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Urban Ground Transport Connections Grid
        Text(
            text = "地面交通接驳 · 智能调度",
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = CafTitaniumLight
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TransportCard(
                title = "大兴/首都机场快线",
                sub = "约 26 分钟直达市区",
                icon = Icons.Default.DirectionsSubway,
                modifier = Modifier.weight(1f)
            )
            TransportCard(
                title = "华航专属专车",
                sub = "候客区 3 分钟到达",
                icon = Icons.Default.DirectionsCar,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Hotel Reservation Integration
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(CafBlackSurface)
                .border(1.dp, CafBlackBorder, RoundedCornerShape(10.dp))
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.Hotel, contentDescription = null, tint = CafGold, modifier = Modifier.size(18.dp))
                    Column {
                        Text(text = "酒店房态已同步", fontSize = 11.sp, color = CafTitaniumGrey)
                        Text(text = cityInfo.hotelReservation, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CafWarmWhite)
                    }
                }
                Text(text = "免押金入住", fontSize = 10.sp, color = CafGold)
            }
        }
    }
}

@Composable
private fun TransportCard(
    title: String,
    sub: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(CafBlackSurface)
            .border(1.dp, CafBlackBorder, RoundedCornerShape(10.dp))
            .padding(10.dp)
    ) {
        Column {
            Icon(imageVector = icon, contentDescription = title, tint = CafTitaniumLight, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = title, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CafWarmWhite)
            Text(text = sub, fontSize = 9.sp, color = CafTitaniumGrey)
        }
    }
}
