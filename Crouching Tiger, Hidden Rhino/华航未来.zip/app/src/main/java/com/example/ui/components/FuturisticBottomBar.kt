package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.AppNavTab

@Composable
fun FuturisticBottomBar(
    currentTab: AppNavTab,
    onSelectTab: (AppNavTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .clip(RoundedCornerShape(26.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        CafBlackCardElevated,
                        CafBlackDeep
                    )
                )
            )
            .border(
                1.dp,
                Brush.horizontalGradient(
                    colors = listOf(
                        CafRedChina.copy(alpha = 0.5f),
                        CafBlackBorder,
                        CafRedChina.copy(alpha = 0.3f)
                    )
                ),
                RoundedCornerShape(26.dp)
            )
            .padding(horizontal = 10.dp, vertical = 8.dp)
            .testTag("futuristic_bottom_bar")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val tabs = listOf(
                Triple(AppNavTab.HOME, Icons.Default.Dashboard, "OS"),
                Triple(AppNavTab.JOURNEY, Icons.Default.FlightTakeoff, "JOURNEY"),
                Triple(AppNavTab.NETWORK, Icons.Default.Language, "NETWORK"),
                Triple(AppNavTab.AIRPORT, Icons.Default.Apartment, "AIRPORT"),
                Triple(AppNavTab.MINE, Icons.Default.Person, "PROFILE")
            )

            tabs.forEach { (tab, icon, _) ->
                val isSelected = currentTab == tab
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onSelectTab(tab) }
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                        .testTag("nav_tab_${tab.name}")
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = tab.labelZh,
                        tint = if (isSelected) CafRedBright else CafTitaniumGrey,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = tab.labelZh,
                        fontSize = 10.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) CafWarmWhite else CafTitaniumGrey
                    )
                    if (isSelected) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Box(
                            modifier = Modifier
                                .size(4.dp)
                                .clip(CircleShape)
                                .background(CafRedChina)
                        )
                    }
                }
            }
        }
    }
}
