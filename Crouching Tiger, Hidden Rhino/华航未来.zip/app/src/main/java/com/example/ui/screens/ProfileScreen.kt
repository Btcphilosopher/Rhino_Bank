package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CafBlackLoyaltyCard
import com.example.ui.components.FuturisticTopBar
import com.example.ui.theme.*
import com.example.viewmodel.MainUiState
import com.example.viewmodel.MainViewModel

@Composable
fun ProfileScreen(
    uiState: MainUiState,
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CafBlackDeep)
            .verticalScroll(scrollState)
            .padding(bottom = 90.dp)
            .testTag("profile_screen_content")
    ) {
        FuturisticTopBar(
            journeyState = uiState.journeyState,
            onOpenAiAssistant = { viewModel.setAiAssistantOpen(true) },
            onOpenDemoControl = { viewModel.setDemoControlOpen(true) }
        )

        Spacer(modifier = Modifier.height(6.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // CAF Black Card & Travel Passport
            CafBlackLoyaltyCard(
                profile = uiState.profile,
                wallet = uiState.wallet
            )

            // Wallet & Financial Asset Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(CafBlackCard)
                    .border(1.dp, CafBlackBorder, RoundedCornerShape(20.dp))
                    .padding(18.dp)
            ) {
                Column {
                    Text(
                        text = "CAF WALLET · 数字资产中心",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = CafRedChina,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "快捷退改签 · 极速赔付 · 里程商城",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = CafWarmWhite
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(CafBlackSurface)
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "账户余额", fontSize = 10.sp, color = CafTitaniumGrey)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "¥ ${uiState.wallet.balanceRmb.toInt()}",
                                fontSize = 20.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = CafWarmWhite
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "可用优惠券", fontSize = 10.sp, color = CafTitaniumGrey)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "${uiState.wallet.couponsCount} 张",
                                fontSize = 18.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = CafGold
                            )
                        }
                    }
                }
            }
        }
    }
}
