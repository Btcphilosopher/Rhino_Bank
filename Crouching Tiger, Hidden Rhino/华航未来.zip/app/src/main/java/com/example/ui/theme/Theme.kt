package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val CafDarkColorScheme = darkColorScheme(
    primary = CafRedChina,
    onPrimary = CafWarmWhite,
    primaryContainer = CafRedCrimson,
    onPrimaryContainer = CafWarmWhite,
    secondary = CafTitaniumLight,
    onSecondary = CafBlackDeep,
    secondaryContainer = CafBlackCardElevated,
    onSecondaryContainer = CafWarmWhite,
    tertiary = CafGold,
    onTertiary = CafBlackDeep,
    background = CafBlackDeep,
    onBackground = CafWarmWhite,
    surface = CafBlackInk,
    onSurface = CafWarmWhite,
    surfaceVariant = CafBlackCard,
    onSurfaceVariant = CafTitaniumLight,
    outline = CafBlackBorder,
    outlineVariant = CafBlackDivider
)

@Composable
fun ChinaAirFutureTheme(
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = CafBlackDeep.toArgb()
            window.navigationBarColor = CafBlackDeep.toArgb()
            val insetsController = WindowCompat.getInsetsController(window, view)
            insetsController.isAppearanceLightStatusBars = false
            insetsController.isAppearanceLightNavigationBars = false
        }
    }

    MaterialTheme(
        colorScheme = CafDarkColorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    ChinaAirFutureTheme(content = content)
}
