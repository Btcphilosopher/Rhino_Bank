package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.CabinClass
import com.example.model.SeatInfo
import com.example.ui.theme.*

@Composable
fun FuturisticSeatMapModal(
    currentSeat: String,
    onSelectSeat: (String, CabinClass) -> Unit,
    onConfirmCheckIn: () -> Unit,
    onDismiss: () -> Unit
) {
    var activeSeat by remember { mutableStateOf(currentSeat) }
    var activeClass by remember { mutableStateOf(CabinClass.BUSINESS) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(CafBlackDeep.copy(alpha = 0.95f))
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                // Top Action Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "AIRCRAFT SPATIAL SEAT MAP",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = CafTitaniumLight,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "A321-Neo · 客舱空间选座",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = CafWarmWhite
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(CafBlackCardElevated)
                            .testTag("close_seat_map_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "关闭",
                            tint = CafWarmWhite,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Legend row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(CafBlackCard)
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LegendItem(color = CafRedChina, label = "我的座位")
                    LegendItem(color = CafBlackBorder, label = "可选")
                    LegendItem(color = CafBlackSurface, label = "已占用", isOccupied = true)
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Seat Map Fuselage View
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(CafBlackSurface)
                        .border(1.dp, CafBlackBorder, RoundedCornerShape(16.dp))
                        .padding(12.dp)
                ) {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Cockpit / Nose Silhouette
                        item {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(vertical = 10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(width = 90.dp, height = 24.dp)
                                        .clip(RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp))
                                        .background(CafBlackBorder),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "驾驶舱 NOSE",
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = CafTitaniumLight
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .width(160.dp)
                                        .height(1.dp)
                                        .background(CafBlackBorder)
                                )
                            }
                        }

                        // Business Class Section (Rows 10 - 14)
                        item {
                            SectionHeader(title = "商务舱 · BUSINESS CLASS (1-2-1)")
                        }

                        val businessRows = listOf(10, 11, 12, 14)
                        items(businessRows.size) { rIdx ->
                            val rowNum = businessRows[rIdx]
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                SeatItem(
                                    seatCode = "${rowNum}A",
                                    isSelected = activeSeat == "${rowNum}A",
                                    isOccupied = rowNum == 11,
                                    onSelect = {
                                        activeSeat = "${rowNum}A"
                                        activeClass = CabinClass.BUSINESS
                                        onSelectSeat(activeSeat, activeClass)
                                    }
                                )
                                Spacer(modifier = Modifier.width(18.dp))
                                Text(
                                    text = "$rowNum",
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = CafTitaniumGrey,
                                    modifier = Modifier.width(24.dp)
                                )
                                Spacer(modifier = Modifier.width(18.dp))
                                SeatItem(
                                    seatCode = "${rowNum}C",
                                    isSelected = activeSeat == "${rowNum}C",
                                    isOccupied = rowNum == 14,
                                    onSelect = {
                                        activeSeat = "${rowNum}C"
                                        activeClass = CabinClass.BUSINESS
                                        onSelectSeat(activeSeat, activeClass)
                                    }
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                SeatItem(
                                    seatCode = "${rowNum}D",
                                    isSelected = activeSeat == "${rowNum}D",
                                    isOccupied = rowNum == 10,
                                    onSelect = {
                                        activeSeat = "${rowNum}D"
                                        activeClass = CabinClass.BUSINESS
                                        onSelectSeat(activeSeat, activeClass)
                                    }
                                )
                                Spacer(modifier = Modifier.width(18.dp))
                                Text(
                                    text = "$rowNum",
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = CafTitaniumGrey,
                                    modifier = Modifier.width(24.dp)
                                )
                                Spacer(modifier = Modifier.width(18.dp))
                                SeatItem(
                                    seatCode = "${rowNum}F",
                                    isSelected = activeSeat == "${rowNum}F",
                                    isOccupied = false,
                                    onSelect = {
                                        activeSeat = "${rowNum}F"
                                        activeClass = CabinClass.BUSINESS
                                        onSelectSeat(activeSeat, activeClass)
                                    }
                                )
                            }
                        }

                        // Wings / Emergency Exit
                        item {
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = "◄ 应急出口 WING", fontSize = 9.sp, color = CafGold, fontFamily = FontFamily.Monospace)
                                Text(text = "WING 应急出口 ►", fontSize = 9.sp, color = CafGold, fontFamily = FontFamily.Monospace)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                        }

                        // Economy Class Section
                        item {
                            SectionHeader(title = "经济舱 · ECONOMY CLASS (3-3)")
                        }

                        val economyRows = listOf(20, 21, 22, 23, 24, 25)
                        items(economyRows.size) { rIdx ->
                            val rowNum = economyRows[rIdx]
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                listOf("A", "B", "C").forEach { col ->
                                    val seatCode = "$rowNum$col"
                                    SeatItem(
                                        seatCode = seatCode,
                                        isSelected = activeSeat == seatCode,
                                        isOccupied = (rowNum + col.hashCode()) % 3 == 0,
                                        onSelect = {
                                            activeSeat = seatCode
                                            activeClass = CabinClass.ECONOMY
                                            onSelectSeat(activeSeat, activeClass)
                                        }
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                }
                                Text(
                                    text = "$rowNum",
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = CafTitaniumGrey,
                                    modifier = Modifier.padding(horizontal = 8.dp)
                                )
                                listOf("D", "E", "F").forEach { col ->
                                    val seatCode = "$rowNum$col"
                                    SeatItem(
                                        seatCode = seatCode,
                                        isSelected = activeSeat == seatCode,
                                        isOccupied = (rowNum + col.hashCode()) % 4 == 0,
                                        onSelect = {
                                            activeSeat = seatCode
                                            activeClass = CabinClass.ECONOMY
                                            onSelectSeat(activeSeat, activeClass)
                                        }
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Bottom Seat Spec Details Card & Check-in CTA
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(CafBlackCard)
                        .border(1.dp, CafRedChina.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                        .padding(14.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(CafRedChina)
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = activeSeat,
                                        fontSize = 18.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = CafWarmWhite
                                    )
                                }
                                Column {
                                    Text(
                                        text = if (activeSeat.startsWith("1")) "商务舱 · 全平躺座椅" else "经济舱 · 舒适标准座",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = CafWarmWhite
                                    )
                                    Text(
                                        text = if (activeSeat.endsWith("A") || activeSeat.endsWith("F")) "靠窗 · 独立视野 · 65W USB-C · 千兆Wi-Fi" else "标准通道 · 220V电源 · 千兆Wi-Fi",
                                        fontSize = 10.sp,
                                        color = CafTitaniumLight
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Button(
                            onClick = {
                                onConfirmCheckIn()
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("confirm_seat_and_checkin_button"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CafRedChina,
                                contentColor = CafWarmWhite
                            )
                        ) {
                            Text(
                                text = "确认选择并完成值机 ($activeSeat)",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SeatItem(
    seatCode: String,
    isSelected: Boolean,
    isOccupied: Boolean,
    onSelect: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(32.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(
                when {
                    isSelected -> CafRedChina
                    isOccupied -> CafBlackSurface
                    else -> CafBlackCardElevated
                }
            )
            .border(
                1.dp,
                when {
                    isSelected -> CafWarmWhite
                    isOccupied -> CafBlackBorder.copy(alpha = 0.3f)
                    else -> CafBlackBorder
                },
                RoundedCornerShape(6.dp)
            )
            .clickable(enabled = !isOccupied) { onSelect() }
            .testTag("seat_node_$seatCode"),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = seatCode.takeLast(1),
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = when {
                isSelected -> CafWarmWhite
                isOccupied -> CafTitaniumGrey.copy(alpha = 0.3f)
                else -> CafTitaniumLight
            }
        )
    }
}

@Composable
private fun SectionHeader(title: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(CafBlackCardElevated)
            .padding(vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = title,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            color = CafTitaniumLight,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
private fun LegendItem(
    color: Color,
    label: String,
    isOccupied: Boolean = false
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(12.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(color)
                .border(1.dp, if (isOccupied) CafBlackBorder else CafTitaniumGrey, RoundedCornerShape(3.dp))
        )
        Text(
            text = label,
            fontSize = 11.sp,
            color = CafTitaniumLight
        )
    }
}
