package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.SearchFlightItem

@Composable
fun FlightSearchTimeline(
    origin: String,
    destination: String,
    date: String,
    onSelectFlight: (SearchFlightItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val flights = listOf(
        SearchFlightItem("CAF 7812", "09:35", "11:42", "SHA", "PEK", "上海虹桥 T2", "北京首都 T3", "2h 07m", 1240, "98% 准点", "A321-Neo Future"),
        SearchFlightItem("CAF 7834", "11:20", "13:28", "SHA", "PEK", "上海虹桥 T2", "北京首都 T3", "2h 08m", 1080, "96% 准点", "C919 Future"),
        SearchFlightItem("CAF 7856", "14:05", "16:15", "SHA", "PEK", "上海虹桥 T2", "北京首都 T3", "2h 10m", 1160, "99% 准点", "A350-1000"),
        SearchFlightItem("CAF 7890", "18:30", "20:38", "SHA", "PEK", "上海虹桥 T2", "北京首都 T3", "2h 08m", 1390, "97% 准点", "C919 Future")
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(CafBlackCard)
            .border(1.dp, CafBlackBorder, RoundedCornerShape(20.dp))
            .padding(18.dp)
            .testTag("flight_search_timeline_container")
    ) {
        // Minimalist Search Route Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(CafBlackSurface)
                .border(1.dp, CafBlackBorder, RoundedCornerShape(12.dp))
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(text = "从哪里 出发", fontSize = 10.sp, color = CafTitaniumGrey)
                Text(text = origin, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = CafWarmWhite)
            }

            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(CafBlackCardElevated),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.SwapHoriz,
                    contentDescription = "互换",
                    tint = CafRedChina,
                    modifier = Modifier.size(16.dp)
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(text = "到哪里 目的", fontSize = 10.sp, color = CafTitaniumGrey)
                Text(text = destination, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = CafWarmWhite)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Date selection chip
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "TIMELINE FLIGHTS · $date 航班时刻轴",
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = CafTitaniumLight,
                letterSpacing = 1.sp
            )
            Text(
                text = "4 趟直飞可选",
                fontSize = 10.sp,
                color = CafGold
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Flight Results List as Journey Timelines
        Column(
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            flights.forEach { flight ->
                FlightTimelineCard(flight = flight, onSelect = { onSelectFlight(flight) })
            }
        }
    }
}

@Composable
private fun FlightTimelineCard(
    flight: SearchFlightItem,
    onSelect: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(CafBlackSurface)
            .border(1.dp, CafBlackBorder, RoundedCornerShape(12.dp))
            .clickable { onSelect() }
            .padding(14.dp)
            .testTag("flight_search_item_${flight.flightNo}")
    ) {
        Column {
            // Top Row: Flight Code, Aircraft, Price
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = flight.flightNo,
                        fontSize = 14.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = CafRedBright
                    )
                    Text(
                        text = flight.aircraft,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = CafTitaniumGrey
                    )
                }

                Text(
                    text = "¥ ${flight.price}",
                    fontSize = 16.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = CafWarmWhite
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Time Timeline Graphic
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = flight.depTime,
                        fontSize = 18.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = CafWarmWhite
                    )
                    Text(text = flight.originAirport, fontSize = 10.sp, color = CafTitaniumGrey)
                }

                // Center Timeline Graphic Bar
                Column(
                    modifier = Modifier.weight(1f).padding(horizontal = 14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = flight.duration,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = CafTitaniumLight
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                    ) {
                        val midY = size.height / 2f
                        drawLine(
                            color = CafBlackBorder,
                            start = Offset(0f, midY),
                            end = Offset(size.width, midY),
                            strokeWidth = 2f
                        )
                        drawCircle(color = CafWarmWhite, radius = 3f, center = Offset(0f, midY))
                        drawCircle(color = CafRedChina, radius = 5f, center = Offset(size.width * 0.45f, midY))
                        drawCircle(color = CafWarmWhite, radius = 3f, center = Offset(size.width, midY))
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = flight.punctualityRate,
                        fontSize = 9.sp,
                        color = CafStatusGreen
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = flight.arrTime,
                        fontSize = 18.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = CafWarmWhite
                    )
                    Text(text = flight.destAirport, fontSize = 10.sp, color = CafTitaniumGrey)
                }
            }
        }
    }
}
