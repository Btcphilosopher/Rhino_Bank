package com.example.model

/**
 * Passenger domain models & aviation entities
 */

data class PassengerProfile(
    val id: String = "USR-2026-0918",
    val name: String = "Tom Loveitt",
    val nameZh: String = "汤姆 · 洛维特",
    val cafId: String = "CAF-00192",
    val tier: LoyaltyTier = LoyaltyTier.BLACK,
    val points: Int = 24820,
    val nextTierPoints: Int = 18400,
    val totalFlights: Int = 42,
    val totalDistanceKm: Int = 98450,
    val phoneMasked: String = "+86 138 **** 8820",
    val idCardMasked: String = "310104********201X"
) {
    val memberId: String get() = cafId
    val nameEn: String get() = name
}

enum class LoyaltyTier(
    val title: String,
    val badgeColorHex: Long,
    val multiplier: Double,
    val description: String
) {
    STANDARD("STANDARD", 0xFF8E95A5, 1.0, "基础航行会员"),
    SILVER("SILVER", 0xFFB0B8C8, 1.2, "银卡尊享"),
    GOLD("GOLD", 0xFFD4AF37, 1.5, "金卡优先礼遇"),
    PLATINUM("PLATINUM", 0xFFE5E7EB, 1.8, "白金全舱尊崇"),
    BLACK("CAF BLACK", 0xFF111318, 2.5, "华航黑卡最高领航")
}

data class Flight(
    val id: String = "FL-7812",
    val flightNumber: String = "CAF 7812",
    val aircraftModel: String = "A321-Neo Future / C919",
    val registration: String = "B-8802",
    val originCity: String = "上海",
    val originCityEn: String = "Shanghai",
    val originIata: String = "SHA",
    val originAirport: String = "上海虹桥国际机场",
    val originTerminal: String = "T2",
    val destinationCity: String = "北京",
    val destinationCityEn: String = "Beijing",
    val destinationIata: String = "PEK",
    val destinationAirport: String = "北京首都国际机场",
    val destinationTerminal: String = "T3",
    val scheduledDeparture: String = "09:35",
    val estimatedDeparture: String = "09:35",
    val scheduledArrival: String = "11:42",
    val estimatedArrival: String = "11:42",
    val durationText: String = "2h 07m",
    val distanceKm: Int = 1088,
    val gate: String = "C42",
    val boardingTime: String = "09:05",
    val checkInCounter: String = "K01-K08 (CAF VIP)",
    val securityChannel: String = "智能无感通道 02",
    val baggageCarousel: String = "Belt 17",
    val priceRmb: Int = 1240,
    val flightStatus: String = "预计准点",
    val distanceToGateMeters: Int = 280,
    val walkTimeToGateMinutes: Int = 4
)

data class SeatInfo(
    val seatNumber: String = "12A",
    val cabinClass: CabinClass = CabinClass.BUSINESS,
    val positionType: String = "靠窗 / 景观位",
    val features: List<String> = listOf("全平躺", "高速USB-C (65W)", "220V电源", "千兆Wi-Fi", "4K OLED屏"),
    val legroomCm: Int = 112,
    val isReclineFlat: Boolean = true
)

enum class CabinClass(val labelZh: String, val labelEn: String, val multiplier: Double) {
    FIRST("头等舱", "FIRST", 2.2),
    BUSINESS("商务舱", "BUSINESS", 1.6),
    PREMIUM("超级经济舱", "PREMIUM", 1.2),
    ECONOMY("经济舱", "ECONOMY", 1.0)
}

data class BaggageItem(
    val bagId: String = "BAG 01",
    val tagNumber: String = "CAF-9921-SHA-PEK",
    val weightKg: Double = 23.4,
    val statusStage: BaggageStage = BaggageStage.LOADED,
    val carousel: String = "Belt 17",
    val estimatedTimeMinutes: Int = 12
)

enum class BaggageStage(val titleZh: String, val titleEn: String, val progress: Float) {
    CHECKED_IN("已托运", "CHECKED IN", 0.15f),
    SECURITY_CHECK("安全检查", "SECURITY SCAN", 0.35f),
    LOADED("已装机", "LOADED ON AIRCRAFT", 0.60f),
    IN_TRANSIT("运输中", "IN TRANSIT", 0.80f),
    ARRIVED_CAROUSEL("已送达转盘", "ARRIVED BELT", 0.95f),
    CLAIMED("已提取", "CLAIMED", 1.0f)
}

data class DigitalBoardingPass(
    val id: String = "BP-7812-12A",
    val passengerName: String = "LOVEITT / TOM",
    val flightNumber: String = "CAF 7812",
    val fromIata: String = "SHA",
    val toIata: String = "PEK",
    val terminal: String = "T2",
    val gate: String = "C42",
    val boardingTime: String = "09:05",
    val departureTime: String = "09:35",
    val seat: String = "12A",
    val boardingGroup: String = "GROUP 02",
    val sequenceNumber: String = "018",
    val cabinClass: String = "BUSINESS",
    val qrDemoData: String = "CAF://PASS/7812/SHA-PEK/12A/TOM_LOVEITT/20260918",
    val eTicketNumber: String = "781-9902817291"
)

data class AirportTwinNode(
    val id: String,
    val nameZh: String,
    val nameEn: String,
    val category: String,
    val level: String,
    val x: Float, // Normalized 0..1 coordinates
    val y: Float,
    val walkMinutesFromCurrent: Int,
    val congestionLevel: String
)

data class LoungeInfo(
    val name: String = "CAF 华航领航贵宾厅",
    val airport: String = "上海虹桥 T2",
    val location: String = "安检后 3层 北侧",
    val hours: String = "06:00 — 22:30",
    val crowdStatus: String = "舒适安静 (占用率 32%)",
    val diningStatus: String = "现磨手冲 / 精品苏式面点全天供应",
    val showerStatus: String = "淋浴间免预约可用"
)

data class FlightTelemetry(
    val altitudeFt: Int = 35000,
    val altitudeMeters: Int = 10668,
    val groundSpeedKmh: Int = 880,
    val headwindKmh: Int = 24,
    val outsideTempC: Int = -52,
    val distanceRemainingKm: Int = 460,
    val timeRemainingText: String = "01:06",
    val progressPercent: Float = 0.58f
)

data class WalletInfo(
    val balanceRmb: Double = 2840.0,
    val points: Int = 24820,
    val couponsCount: Int = 7,
    val travelVouchersRmb: Double = 1500.0
)

data class CityDestinationInfo(
    val cityNameZh: String = "北京",
    val cityNameEn: String = "Beijing",
    val temperature: String = "22°C",
    val weatherCondition: String = "晴朗",
    val aqiStatus: String = "优 (AQI 28)",
    val metroToDowntownMinutes: Int = 26,
    val taxiWaitMinutes: Int = 3,
    val hotelReservation: String = "王府井文华东方酒店 (豪华客房)"
)

data class AssistantChatMessage(
    val id: String,
    val isUser: Boolean,
    val text: String,
    val timestamp: String,
    val contextualData: String? = null,
    val quickChips: List<String> = emptyList()
)
