package com.example.model

/**
 * Passenger Journey State Machine
 * Represents the 15 continuous stages of modern travel
 */
enum class PassengerJourneyState(
    val labelZh: String,
    val labelEn: String,
    val shortName: String,
    val descriptionZh: String,
    val nextActionTitle: String
) {
    NO_TRIP(
        labelZh = "无活动行程",
        labelEn = "NO ACTIVE TRIP",
        shortName = "空闲",
        descriptionZh = "探索华航未来航线网络",
        nextActionTitle = "搜索航班"
    ),
    BOOKED(
        labelZh = "已预订",
        labelEn = "BOOKED",
        shortName = "预订",
        descriptionZh = "已出票，等待在线值机开放",
        nextActionTitle = "办理值机"
    ),
    CHECKED_IN(
        labelZh = "已值机",
        labelEn = "CHECKED IN",
        shortName = "值机",
        descriptionZh = "已分配座位 12A，电子登机牌已生成",
        nextActionTitle = "前往机场"
    ),
    AT_AIRPORT(
        labelZh = "抵达机场",
        labelEn = "AT AIRPORT",
        shortName = "机场",
        descriptionZh = "上海虹桥 T2，已托运行李 BAG 01",
        nextActionTitle = "前往安检"
    ),
    SECURITY(
        labelZh = "通过安检",
        labelEn = "SECURITY CLEAR",
        shortName = "安检",
        descriptionZh = "已完成智能人脸安检，建议前往休息室或登机口",
        nextActionTitle = "前往 C42 登机口"
    ),
    AT_GATE(
        labelZh = "候机中",
        labelEn = "AT GATE",
        shortName = "候机",
        descriptionZh = "C42 登机口，预计 09:05 开始登机",
        nextActionTitle = "准备登机"
    ),
    BOARDING(
        labelZh = "正在登机",
        labelEn = "BOARDING",
        shortName = "登机",
        descriptionZh = "GROUP 02 开始登机，请出示电子通行证",
        nextActionTitle = "确认登机"
    ),
    TAXI(
        labelZh = "滑行起飞",
        labelEn = "TAXIING",
        shortName = "滑行",
        descriptionZh = "机舱舱门已关闭，跑道滑行中",
        nextActionTitle = "进入客舱模式"
    ),
    TAKEOFF(
        labelZh = "起飞爬升",
        labelEn = "TAKEOFF",
        shortName = "起飞",
        descriptionZh = "爬升至巡航高度 10,600米 (35,000 ft)",
        nextActionTitle = "查看飞行数据"
    ),
    CRUISE(
        labelZh = "高空巡航",
        labelEn = "CRUISING",
        shortName = "巡航",
        descriptionZh = "巡航速度 880 km/h，机上高速千兆 Wi-Fi 已连接",
        nextActionTitle = "机上娱乐与服务"
    ),
    DESCENT(
        labelZh = "下降进近",
        labelEn = "DESCENT",
        shortName = "下降",
        descriptionZh = "预计 18 分钟后降落北京首都国际机场 T3",
        nextActionTitle = "准备降落"
    ),
    LANDED(
        labelZh = "已降落",
        labelEn = "LANDED",
        shortName = "降落",
        descriptionZh = "已滑入廊桥，请带好随身物品",
        nextActionTitle = "前往行李转盘"
    ),
    BAGGAGE(
        labelZh = "提取行李",
        labelEn = "BAGGAGE CLAIM",
        shortName = "行李",
        descriptionZh = "行李已送达 Belt 17 转盘，预计 3 分钟到达",
        nextActionTitle = "确认取件"
    ),
    ARRIVED(
        labelZh = "行程完成",
        labelEn = "ARRIVED",
        shortName = "到达",
        descriptionZh = "已成功提取行李，准备离开航站楼",
        nextActionTitle = "进入城市接驳"
    ),
    CITY_MODE(
        labelZh = "城市模式",
        labelEn = "CITY MODE",
        shortName = "城市",
        descriptionZh = "北京 · 22°C 晴 · 机场快轨与网约车已就绪",
        nextActionTitle = "查看城市向导"
    );

    val description: String get() = descriptionZh
}
