package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PassengerJourneyState
import com.example.ui.theme.*

@Composable
fun JourneyStateScrubber(
    currentState: PassengerJourneyState,
    onSelectState: (PassengerJourneyState) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val allStates = PassengerJourneyState.entries
    val currentIndex = allStates.indexOf(currentState)

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            allStates.forEachIndexed { index, state ->
                val isActive = index == currentIndex
                val isPast = index < currentIndex
                val nodeColor by animateColorAsState(
                    targetValue = when {
                        isActive -> CafRedChina
                        isPast -> CafTitaniumLight
                        else -> CafBlackBorder
                    },
                    label = "nodeColor"
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Stage Node Item
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onSelectState(state) }
                            .padding(horizontal = 6.dp, vertical = 4.dp)
                            .testTag("scrubber_node_${state.name}")
                    ) {
                        Box(
                            modifier = Modifier
                                .size(if (isActive) 12.dp else 8.dp)
                                .clip(CircleShape)
                                .background(nodeColor)
                                .then(
                                    if (isActive) Modifier.border(2.dp, CafWarmWhite, CircleShape)
                                    else Modifier
                                )
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = state.shortName,
                            fontSize = if (isActive) 11.sp else 10.sp,
                            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                            color = if (isActive) CafRedBright else if (isPast) CafTitaniumLight else CafMutedText,
                            fontFamily = FontFamily.SansSerif
                        )
                    }

                    // Connector line between stages
                    if (index < allStates.size - 1) {
                        Box(
                            modifier = Modifier
                                .width(16.dp)
                                .height(1.5.dp)
                                .background(
                                    if (isPast) CafTitaniumLight.copy(alpha = 0.7f)
                                    else CafBlackBorder
                                )
                        )
                    }
                }
            }
        }
    }
}
