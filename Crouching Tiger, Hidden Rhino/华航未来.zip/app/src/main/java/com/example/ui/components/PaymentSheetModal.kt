package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.*
import com.example.viewmodel.SearchFlightItem

@Composable
fun PaymentSheetModal(
    flight: SearchFlightItem?,
    walletBalance: Double,
    onConfirmPayment: (String) -> Unit,
    onDismiss: () -> Unit
) {
    if (flight == null) return
    var selectedMethod by remember { mutableStateOf("CAF 钱包") }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(CafBlackDeep.copy(alpha = 0.90f))
                .padding(20.dp),
            contentAlignment = Alignment.BottomCenter
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(CafBlackCard)
                    .border(1.dp, CafBlackBorder, RoundedCornerShape(24.dp))
                    .padding(20.dp)
                    .testTag("payment_sheet_dialog")
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    // Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "CHECKOUT · 华航安全收银台",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = CafRedChina,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "确认预订 · ${flight.flightNo}",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = CafWarmWhite
                            )
                        }
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .size(30.dp)
                                .clip(CircleShape)
                                .background(CafBlackSurface)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "关闭",
                                tint = CafWarmWhite,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Amount box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(CafBlackSurface)
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "应付总金额", fontSize = 11.sp, color = CafTitaniumGrey)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "¥ ${flight.price}",
                                fontSize = 30.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Black,
                                color = CafWarmWhite
                            )
                            Text(text = "已含民航发展基金及燃油附加费 · 模拟支付环境", fontSize = 10.sp, color = CafStatusGreen)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "选择支付方式",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = CafTitaniumLight
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Payment Options
                    PaymentMethodOption(
                        title = "CAF 华航数字钱包",
                        sub = "可用余额 ¥ ${walletBalance.toInt()} · 实时扣减",
                        icon = Icons.Default.AccountBalanceWallet,
                        isSelected = selectedMethod == "CAF 钱包",
                        onSelect = { selectedMethod = "CAF 钱包" }
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    PaymentMethodOption(
                        title = "移动快捷支付",
                        sub = "支持免密极速扣款",
                        icon = Icons.Default.QrCode,
                        isSelected = selectedMethod == "移动支付",
                        onSelect = { selectedMethod = "移动支付" }
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    PaymentMethodOption(
                        title = "中国银联 / 银行卡",
                        sub = "工商银行 (尾号 9012)",
                        icon = Icons.Default.CreditCard,
                        isSelected = selectedMethod == "银行卡",
                        onSelect = { selectedMethod = "银行卡" }
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // Pay Button
                    Button(
                        onClick = { onConfirmPayment(selectedMethod) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("confirm_payment_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CafRedChina,
                            contentColor = CafWarmWhite
                        )
                    ) {
                        Text(
                            text = "立即支付 ¥ ${flight.price} ($selectedMethod)",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PaymentMethodOption(
    title: String,
    sub: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onSelect: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(if (isSelected) CafBlackCardElevated else CafBlackSurface)
            .border(
                1.dp,
                if (isSelected) CafRedChina else CafBlackBorder,
                RoundedCornerShape(10.dp)
            )
            .clickable { onSelect() }
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) CafRedBright else CafTitaniumLight,
                modifier = Modifier.size(20.dp)
            )
            Column {
                Text(
                    text = title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = CafWarmWhite
                )
                Text(text = sub, fontSize = 10.sp, color = CafTitaniumGrey)
            }
        }

        if (isSelected) {
            Box(
                modifier = Modifier
                    .size(20.dp)
                    .clip(CircleShape)
                    .background(CafRedChina),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    tint = CafWarmWhite,
                    modifier = Modifier.size(12.dp)
                )
            }
        }
    }
}
