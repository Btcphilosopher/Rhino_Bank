package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class AppNavTab(val labelZh: String, val labelEn: String) {
    HOME("首页", "OS"),
    JOURNEY("行程", "JOURNEY"),
    NETWORK("航空网络", "NETWORK"),
    AIRPORT("机场", "AIRPORT"),
    MINE("我的", "PROFILE")
}

data class SearchFlightItem(
    val flightNo: String,
    val depTime: String,
    val arrTime: String,
    val originIata: String,
    val destIata: String,
    val originAirport: String,
    val destAirport: String,
    val duration: String,
    val price: Int,
    val punctualityRate: String,
    val aircraft: String
)

data class MainUiState(
    val currentTab: AppNavTab = AppNavTab.HOME,
    val journeyState: PassengerJourneyState = PassengerJourneyState.BOOKED,
    val profile: PassengerProfile = PassengerProfile(),
    val activeFlight: Flight = Flight(),
    val seatInfo: SeatInfo = SeatInfo(),
    val boardingPass: DigitalBoardingPass = DigitalBoardingPass(),
    val baggage: BaggageItem = BaggageItem(),
    val lounge: LoungeInfo = LoungeInfo(),
    val telemetry: FlightTelemetry = FlightTelemetry(),
    val wallet: WalletInfo = WalletInfo(),
    val cityArrival: CityDestinationInfo = CityDestinationInfo(),
    
    // UI Dialogs & Expansion states
    val isJourneyExpanded: Boolean = false,
    val isBoardingPassModalOpen: Boolean = false,
    val isSeatMapModalOpen: Boolean = false,
    val isAiAssistantOpen: Boolean = false,
    val isPaymentSheetOpen: Boolean = false,
    val isDemoControlOpen: Boolean = false,
    val isBookingSuccessDialogOpen: Boolean = false,
    val isCheckInSuccessDialogOpen: Boolean = false,
    
    // Aircraft Digital Twin state
    val selectedAircraftPart: String = "商务舱",
    val selectedSeatNumber: String = "12A",
    val selectedSeatClass: CabinClass = CabinClass.BUSINESS,
    
    // Airport Twin
    val airportMapMode3D: Boolean = true,
    val selectedAirportNode: String = "C42",
    
    // Search & Booking
    val searchOrigin: String = "上海 (SHA)",
    val searchDestination: String = "北京 (PEK)",
    val searchDate: String = "9月18日",
    val selectedCabinClass: CabinClass = CabinClass.BUSINESS,
    val pendingBookingFlight: SearchFlightItem? = null,
    
    // In-Flight Mode state
    val inFlightModeActive: Boolean = false,
    val cabinAudioPlaying: Boolean = false,
    val selectedEntertainmentCategory: String = "精选电影",
    
    // AI Assistant Chat Messages
    val chatMessages: List<AssistantChatMessage> = emptyList(),
    val isAiTyping: Boolean = false
)

class MainViewModel : ViewModel() {
    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    init {
        setupInitialChat()
    }

    private fun setupInitialChat() {
        val initialMessages = listOf(
            AssistantChatMessage(
                id = "init_1",
                isUser = false,
                text = "您好，汤姆先生。我是您的个人航行助理「航智」。我已同步您今日 CAF 7812 (上海虹桥 → 北京首都) 的全流程航程数据。请问需要为您提供哪项协助？",
                timestamp = "08:15",
                contextualData = "CAF 7812 · 09:35 出发 · T2 航站楼",
                quickChips = listOf(
                    "我现在应该去哪里？",
                    "我的登机口在哪里？",
                    "还有多久登机？",
                    "我的行李到了吗？",
                    "北京天气如何？"
                )
            )
        )
        _uiState.update { it.copy(chatMessages = initialMessages) }
    }

    fun setTab(tab: AppNavTab) {
        _uiState.update { it.copy(currentTab = tab) }
    }

    fun setJourneyState(state: PassengerJourneyState) {
        _uiState.update { stateBefore ->
            val isFlightActive = state in listOf(
                PassengerJourneyState.TAXI,
                PassengerJourneyState.TAKEOFF,
                PassengerJourneyState.CRUISE,
                PassengerJourneyState.DESCENT
            )
            val updatedBaggage = when (state) {
                PassengerJourneyState.BOOKED, PassengerJourneyState.CHECKED_IN -> stateBefore.baggage.copy(statusStage = BaggageStage.CHECKED_IN)
                PassengerJourneyState.AT_AIRPORT, PassengerJourneyState.SECURITY -> stateBefore.baggage.copy(statusStage = BaggageStage.SECURITY_CHECK)
                PassengerJourneyState.AT_GATE, PassengerJourneyState.BOARDING, PassengerJourneyState.TAXI -> stateBefore.baggage.copy(statusStage = BaggageStage.LOADED)
                PassengerJourneyState.TAKEOFF, PassengerJourneyState.CRUISE, PassengerJourneyState.DESCENT -> stateBefore.baggage.copy(statusStage = BaggageStage.IN_TRANSIT)
                PassengerJourneyState.LANDED, PassengerJourneyState.BAGGAGE -> stateBefore.baggage.copy(statusStage = BaggageStage.ARRIVED_CAROUSEL)
                PassengerJourneyState.ARRIVED, PassengerJourneyState.CITY_MODE -> stateBefore.baggage.copy(statusStage = BaggageStage.CLAIMED)
                else -> stateBefore.baggage
            }
            stateBefore.copy(
                journeyState = state,
                inFlightModeActive = isFlightActive,
                baggage = updatedBaggage
            )
        }
    }

    fun nextJourneyState() {
        val states = PassengerJourneyState.entries
        val currentIndex = states.indexOf(_uiState.value.journeyState)
        if (currentIndex < states.size - 1) {
            setJourneyState(states[currentIndex + 1])
        }
    }

    fun prevJourneyState() {
        val states = PassengerJourneyState.entries
        val currentIndex = states.indexOf(_uiState.value.journeyState)
        if (currentIndex > 0) {
            setJourneyState(states[currentIndex - 1])
        }
    }

    fun toggleJourneyExpanded() {
        _uiState.update { it.copy(isJourneyExpanded = !it.isJourneyExpanded) }
    }

    fun setBoardingPassModal(open: Boolean) {
        _uiState.update { it.copy(isBoardingPassModalOpen = open) }
    }

    fun setSeatMapModal(open: Boolean) {
        _uiState.update { it.copy(isSeatMapModalOpen = open) }
    }

    fun setAiAssistantOpen(open: Boolean) {
        _uiState.update { it.copy(isAiAssistantOpen = open) }
    }

    fun setPaymentSheetOpen(open: Boolean) {
        _uiState.update { it.copy(isPaymentSheetOpen = open) }
    }

    fun setDemoControlOpen(open: Boolean) {
        _uiState.update { it.copy(isDemoControlOpen = open) }
    }

    fun selectAircraftPart(partName: String) {
        _uiState.update { it.copy(selectedAircraftPart = partName) }
    }

    fun selectSeat(seatNo: String, cabinClass: CabinClass) {
        _uiState.update {
            it.copy(
                selectedSeatNumber = seatNo,
                selectedSeatClass = cabinClass,
                seatInfo = it.seatInfo.copy(
                    seatNumber = seatNo,
                    cabinClass = cabinClass,
                    positionType = if (seatNo.endsWith("A") || seatNo.endsWith("F")) "靠窗 / 视野位" else if (seatNo.endsWith("C") || seatNo.endsWith("D")) "靠过道 / 出入便捷" else "居中位"
                ),
                boardingPass = it.boardingPass.copy(seat = seatNo)
            )
        }
    }

    fun confirmCheckIn() {
        setJourneyState(PassengerJourneyState.CHECKED_IN)
        _uiState.update {
            it.copy(
                isSeatMapModalOpen = false,
                isCheckInSuccessDialogOpen = true
            )
        }
    }

    fun dismissCheckInSuccess() {
        _uiState.update { it.copy(isCheckInSuccessDialogOpen = false) }
    }

    fun toggleAirportMap3D() {
        _uiState.update { it.copy(airportMapMode3D = !it.airportMapMode3D) }
    }

    fun selectAirportNode(nodeId: String) {
        _uiState.update { it.copy(selectedAirportNode = nodeId) }
    }

    fun selectFlightToBook(flight: SearchFlightItem) {
        _uiState.update {
            it.copy(
                pendingBookingFlight = flight,
                isPaymentSheetOpen = true
            )
        }
    }

    fun confirmPaymentAndBooking(paymentMethod: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isPaymentSheetOpen = false) }
            val booked = _uiState.value.pendingBookingFlight
            if (booked != null) {
                val newFlight = Flight(
                    flightNumber = booked.flightNo,
                    originCity = "上海",
                    originIata = booked.originIata,
                    originAirport = booked.originAirport,
                    destinationCity = "北京",
                    destinationIata = booked.destIata,
                    destinationAirport = booked.destAirport,
                    scheduledDeparture = booked.depTime,
                    scheduledArrival = booked.arrTime,
                    durationText = booked.duration,
                    priceRmb = booked.price,
                    aircraftModel = booked.aircraft
                )
                _uiState.update {
                    it.copy(
                        activeFlight = newFlight,
                        journeyState = PassengerJourneyState.BOOKED,
                        isBookingSuccessDialogOpen = true,
                        wallet = it.wallet.copy(
                            balanceRmb = if (paymentMethod == "CAF 钱包") it.wallet.balanceRmb - booked.price else it.wallet.balanceRmb,
                            points = it.wallet.points + (booked.price * 1.5).toInt()
                        )
                    )
                }
            }
        }
    }

    fun dismissBookingSuccess() {
        _uiState.update { it.copy(isBookingSuccessDialogOpen = false) }
    }

    fun toggleCabinAudio() {
        _uiState.update { it.copy(cabinAudioPlaying = !it.cabinAudioPlaying) }
    }

    fun setEntertainmentCategory(cat: String) {
        _uiState.update { it.copy(selectedEntertainmentCategory = cat) }
    }

    fun sendAiQuestion(question: String) {
        val userMsg = AssistantChatMessage(
            id = "user_${System.currentTimeMillis()}",
            isUser = true,
            text = question,
            timestamp = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        )
        
        _uiState.update {
            it.copy(
                chatMessages = it.chatMessages + userMsg,
                isAiTyping = true
            )
        }

        viewModelScope.launch {
            delay(900) // Realistic thoughtful AI latency
            val responseText = generateContextualAiResponse(question, _uiState.value)
            val aiMsg = AssistantChatMessage(
                id = "ai_${System.currentTimeMillis()}",
                isUser = false,
                text = responseText,
                timestamp = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()),
                contextualData = "基于当前模拟航程状态 [${_uiState.value.journeyState.labelZh}]",
                quickChips = listOf("下一步是什么？", "查看登机牌", "我的行李在哪？", "机上有什么餐食？")
            )
            _uiState.update {
                it.copy(
                    chatMessages = it.chatMessages + aiMsg,
                    isAiTyping = false
                )
            }
        }
    }

    private fun generateContextualAiResponse(query: String, state: MainUiState): String {
        val flight = state.activeFlight
        val journey = state.journeyState
        
        return when {
            query.contains("去哪里") || query.contains("下一步") -> {
                when (journey) {
                    PassengerJourneyState.BOOKED -> "您当前已出票。下一步请完成在线值机，选定您的专属座位（推荐 12A 商务靠窗）。"
                    PassengerJourneyState.CHECKED_IN -> "您已完成值机！请于 08:30 前前往上海虹桥国际机场 T2 航站楼。"
                    PassengerJourneyState.AT_AIRPORT -> "您已在虹桥 T2。请前往 K01 华航专属值机岛托运行李，随后通过智能无感安检通道 02。"
                    PassengerJourneyState.SECURITY -> "安检已完成！您的登机口为 C42，预计步行 4 分钟 (280m)。登机前您可前往 3F 北侧的 CAF 领航贵宾厅稍作休憩。"
                    PassengerJourneyState.AT_GATE -> "您已抵达 C42 登机口。航班将于 09:05 开放登机，您的登机组为 GROUP 02。"
                    PassengerJourneyState.BOARDING -> "目前正在进行登机！请出示您的电子登机牌，通过 C42 智能人脸闸机。"
                    PassengerJourneyState.TAXI, PassengerJourneyState.TAKEOFF, PassengerJourneyState.CRUISE, PassengerJourneyState.DESCENT -> "飞机正在高空巡航（高度 35,000 ft）。您可以通过「客舱模式」使用千兆 Wi-Fi、点播 4K 电影或呼叫乘务组。"
                    PassengerJourneyState.LANDED, PassengerJourneyState.BAGGAGE -> "已降落北京首都 T3！请前往 1 层行李提取大厅 Belt 17 提取您的 BAG 01 行李。"
                    PassengerJourneyState.ARRIVED, PassengerJourneyState.CITY_MODE -> "您已进入北京城市模式。机场快轨 2 号线及网约车专车已在 B2 交通枢纽就绪。"
                    else -> "您当前处于空闲状态，您可以随时搜索订购华航全新智能航线。"
                }
            }
            query.contains("登机口") || query.contains("Gate") -> {
                "您的航班 ${flight.flightNumber} 登机口为「${flight.gate}」（${flight.originTerminal}），距离您当前位置约 ${flight.distanceToGateMeters} 米，步行约 ${flight.walkTimeToGateMinutes} 分钟，当前通道人流平稳。"
            }
            query.contains("多久") || query.contains("时间") -> {
                when (journey) {
                    PassengerJourneyState.BOARDING -> "距离登机截止仅剩 14 分钟，请尽快前往 C42 登机口。"
                    PassengerJourneyState.CRUISE -> "预计抵达北京时间为 ${flight.estimatedArrival}，剩余飞行时间约 ${state.telemetry.timeRemainingText}。"
                    else -> "距离航班起飞 (09:35) 还有约 1 小时 20 分钟，登机时间为 09:05。"
                }
            }
            query.contains("行李") || query.contains("BAG") -> {
                "您的行李编号为 ${state.baggage.bagId}（重量 ${state.baggage.weightKg} kg），当前状态为「${state.baggage.statusStage.titleZh}」。到达北京后将在「${state.baggage.carousel}」转盘领取。"
            }
            query.contains("北京") || query.contains("天气") || query.contains("城市") -> {
                "北京今日天气：${state.cityArrival.temperature}，${state.cityArrival.weatherCondition}，空气质量：${state.cityArrival.aqiStatus}。您预订的「${state.cityArrival.hotelReservation}」已完成房型升级。"
            }
            query.contains("延误") || query.contains("准点") -> {
                "航班 ${flight.flightNumber} 目前状态为「${flight.flightStatus}」，前序航班已准时进港，暂无任何延误预警。"
            }
            query.contains("餐食") || query.contains("菜单") -> {
                "今日商务舱提供：主厨定制炙烤银鳕鱼配藜麦饭、经典苏式三虾面、江南特调龙井冷萃茶及现磨危地马拉手冲咖啡。"
            }
            else -> {
                "已收到您的提问：「$query」。基于华航未来智能航行系统分析，当前航班 ${flight.flightNumber} 运行平稳，如有值机、选座、登机口指引或接驳需求，我将即刻为您办理。"
            }
        }
    }
}
