package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PassengerJourneyState
import com.example.ui.theme.*

@Composable
fun FuturisticTopBar(
    journeyState: PassengerJourneyState,
    onOpenAiAssistant: () -> Unit,
    onOpenDemoControl: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Brand Title & Aviation Logo
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(CafRedChina)
                    .border(1.dp, CafRedBright.copy(alpha = 0.6f), RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "CAF",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    fontSize = 13.sp,
                    color = CafWarmWhite,
                    letterSpacing = 0.5.sp
                )
            }
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "华航未来",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = CafWarmWhite,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(CafStatusGreen)
                    )
                }
                Text(
                    text = "CHINA AIR FUTURE",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = CafTitaniumGrey,
                    letterSpacing = 1.2.sp
                )
            }
        }

        // Actions: AI Travel Assistant & Simulation State Controller
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Live State Chip (Tap to open simulation switcher)
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(CafBlackCardElevated)
                    .border(1.dp, CafRedChina.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
                    .clickable { onOpenDemoControl() }
                    .padding(horizontal = 10.dp, vertical = 5.dp)
                    .testTag("journey_state_control_button"),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(CafRedBright)
                )
                Text(
                    text = journeyState.shortName,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = CafWarmWhite
                )
                Icon(
                    imageVector = Icons.Default.Tune,
                    contentDescription = "模拟控制",
                    tint = CafTitaniumLight,
                    modifier = Modifier.size(12.dp)
                )
            }

            // AI "航智" Assistant Button
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(CafBlackCardElevated)
                    .border(1.dp, CafBlackBorder, CircleShape)
                    .clickable { onOpenAiAssistant() }
                    .testTag("ai_assistant_top_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "航智 AI",
                    tint = CafRedChina,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
