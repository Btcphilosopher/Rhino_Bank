import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { HomeView } from './components/Views/HomeView';
import { TalentsView } from './components/Views/TalentsView';
import { ProjectsView } from './components/Views/ProjectsView';
import { ServicesView } from './components/Views/ServicesView';
import { PortfolioView } from './components/Views/PortfolioView';
import { AboutView } from './components/Views/AboutView';

import { FreelancerDetailModal } from './components/Modals/FreelancerDetailModal';
import { ProjectPostModal } from './components/Modals/ProjectPostModal';
import { AuthModal } from './components/Modals/AuthModal';
import { JoinFreelancerModal } from './components/Modals/JoinFreelancerModal';
import { AssuranceDetailModal } from './components/Modals/AssuranceDetailModal';
import { SearchModal } from './components/Modals/SearchModal';

import { INITIAL_FREELANCERS, INITIAL_PROJECTS, INITIAL_SERVICES } from './data/initialData';
import { ActiveTab, Freelancer, Project, ServicePackage } from './types';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

export default function App() {
  // Navigation & View State
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  // Core Data State (in-memory persistent state)
  const [freelancers, setFreelancers] = useState<Freelancer[]>(INITIAL_FREELANCERS);
  const [projects, setProjects] = useState<Project[]>(INITIAL_PROJECTS);
  const [services, setServices] = useState<ServicePackage[]>(INITIAL_SERVICES);

  // User Authentication State
  const [currentUser, setCurrentUser] = useState<{
    name: string;
    role: 'client' | 'freelancer';
  } | null>(null);

  // Modals Visibility State
  const [selectedFreelancer, setSelectedFreelancer] = useState<Freelancer | null>(null);
  const [isProjectPostOpen, setIsProjectPostOpen] = useState(false);
  const [isJoinModalOpen, setIsJoinModalOpen] = useState(false);
  const [selectedAssuranceItem, setSelectedAssuranceItem] = useState<string | null>(null);
  const [authModalConfig, setAuthModalConfig] = useState<{
    isOpen: boolean;
    mode: 'login' | 'register';
  }>({ isOpen: false, mode: 'login' });
  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false);
  const [isDisclaimerOpen, setIsDisclaimerOpen] = useState(false);

  // Toast Notification State
  const [toast, setToast] = useState<{
    message: string;
    type: 'success' | 'info' | 'warning';
  } | null>(null);

  const showToast = (message: string, type: 'success' | 'info' | 'warning' = 'success') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast(null);
    }, 3500);
  };

  // Handlers
  const handleTabChange = (tab: ActiveTab) => {
    setActiveTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectHotCategory = (catName: string) => {
    setSelectedCategory(catName);
    setActiveTab('talents');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAddNewProject = (newProjectData: Omit<Project, 'id' | 'createdAt' | 'bidsCount' | 'status'>) => {
    const newProject: Project = {
      ...newProjectData,
      id: `proj-${Date.now()}`,
      createdAt: '刚刚',
      bidsCount: 0,
      status: 'open',
      isFeatured: true,
    };
    setProjects([newProject, ...projects]);
    showToast(`项目《${newProject.title}》已成功发布至市场！`);
  };

  const handleBidProject = (projectId: string) => {
    setProjects(
      projects.map((p) =>
        p.id === projectId ? { ...p, bidsCount: p.bidsCount + 1 } : p
      )
    );
    showToast('投标方案已递交，雇主将收到即时通知。');
  };

  const handleHireFreelancer = (freelancer: Freelancer, serviceTitle?: string) => {
    setSelectedFreelancer(null);
    showToast(
      `已向 ${freelancer.name} 发起委托请求${
        serviceTitle ? `【${serviceTitle}】` : ''
      }，专属项目顾问稍后将协助建立托管契约。`
    );
  };

  const handleOrderService = (service: ServicePackage) => {
    showToast(
      `已成功锁定服务《${service.title}》，总金额 ¥${service.price}。正在为您生成资金托管协议。`
    );
  };

  const handleLoginSuccess = (name: string, role: 'client' | 'freelancer') => {
    setCurrentUser({ name, role });
    showToast(`欢迎回来，${name}！已切换至${role === 'client' ? '雇主' : '自由职业者'}工作台。`);
  };

  const handleGlobalSearch = (query: string) => {
    if (query.trim()) {
      setIsSearchModalOpen(true);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#f5f2eb] text-[#102f32] selection:bg-[#668c87]/30">
      {/* Toast Notification Alert Banner */}
      {toast && (
        <div className="fixed top-5 right-5 z-[100] max-w-md bg-[#163b3d] text-white px-4 py-3 rounded-[10px] shadow-xl border border-white/20 flex items-center justify-between space-x-3 animate-in fade-in slide-in-from-top-4 duration-200">
          <div className="flex items-center space-x-2.5">
            {toast.type === 'success' && <CheckCircle2 className="w-5 h-5 text-[#668c87] shrink-0" />}
            {toast.type === 'info' && <Info className="w-5 h-5 text-[#dce5df] shrink-0" />}
            {toast.type === 'warning' && <AlertCircle className="w-5 h-5 text-[#b9513c] shrink-0" />}
            <span className="text-[13px] font-sans-sc font-medium">{toast.message}</span>
          </div>
          <button
            onClick={() => setToast(null)}
            className="text-white/60 hover:text-white cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Global Navbar */}
      <Navbar
        activeTab={activeTab}
        onTabChange={handleTabChange}
        onOpenPostModal={() => setIsProjectPostOpen(true)}
        onOpenAuthModal={(mode) => setAuthModalConfig({ isOpen: true, mode })}
        currentUser={currentUser}
        onLogout={() => {
          setCurrentUser(null);
          showToast('已退出登录。', 'info');
        }}
      />

      {/* Main Content Router / Views */}
      <main className="flex-1 w-full">
        {activeTab === 'home' && (
          <HomeView
            freelancers={freelancers}
            onSelectCategory={handleSelectHotCategory}
            onSelectFreelancer={(f) => setSelectedFreelancer(f)}
            onViewMoreFreelancers={() => handleTabChange('talents')}
            onPostProject={() => setIsProjectPostOpen(true)}
            onJoinFreelancer={() => setIsJoinModalOpen(true)}
            onOpenAssuranceDetails={(item) => setSelectedAssuranceItem(item)}
            onSearchSubmit={handleGlobalSearch}
          />
        )}

        {activeTab === 'talents' && (
          <TalentsView
            freelancers={freelancers}
            initialCategory={selectedCategory}
            onSelectFreelancer={(f) => setSelectedFreelancer(f)}
            onPostProject={() => setIsProjectPostOpen(true)}
          />
        )}

        {activeTab === 'projects' && (
          <ProjectsView
            projects={projects}
            initialCategory={selectedCategory}
            onPostProject={() => setIsProjectPostOpen(true)}
            onBidProject={handleBidProject}
          />
        )}

        {activeTab === 'services' && (
          <ServicesView
            services={services}
            freelancers={freelancers}
            onSelectFreelancer={(f) => setSelectedFreelancer(f)}
            onOrderService={handleOrderService}
          />
        )}

        {activeTab === 'portfolio' && (
          <PortfolioView
            freelancers={freelancers}
            onSelectFreelancer={(f) => setSelectedFreelancer(f)}
          />
        )}

        {activeTab === 'about' && (
          <AboutView
            onJoinFreelancer={() => setIsJoinModalOpen(true)}
            onPostProject={() => setIsProjectPostOpen(true)}
          />
        )}
      </main>

      {/* Global Footer */}
      <Footer
        onTabChange={handleTabChange}
        onOpenDisclaimer={() => setIsDisclaimerOpen(true)}
      />

      {/* 1. Freelancer Detail Modal Drawer */}
      <FreelancerDetailModal
        freelancer={selectedFreelancer}
        onClose={() => setSelectedFreelancer(null)}
        onHire={handleHireFreelancer}
      />

      {/* 2. Project Posting Modal */}
      <ProjectPostModal
        isOpen={isProjectPostOpen}
        onClose={() => setIsProjectPostOpen(false)}
        onSubmitProject={handleAddNewProject}
      />

      {/* 3. Join as Freelancer Application Modal */}
      <JoinFreelancerModal
        isOpen={isJoinModalOpen}
        onClose={() => setIsJoinModalOpen(false)}
      />

      {/* 4. Platform Assurance Guarantee Details Modal */}
      <AssuranceDetailModal
        selectedItem={selectedAssuranceItem}
        onClose={() => setSelectedAssuranceItem(null)}
      />

      {/* 5. User Auth (Login/Register) Modal */}
      <AuthModal
        isOpen={authModalConfig.isOpen}
        initialMode={authModalConfig.mode}
        onClose={() => setAuthModalConfig({ isOpen: false, mode: 'login' })}
        onSuccess={handleLoginSuccess}
      />

      {/* 6. Global Search Modal */}
      <SearchModal
        isOpen={isSearchModalOpen}
        onClose={() => setIsSearchModalOpen(false)}
        freelancers={freelancers}
        projects={projects}
        services={services}
        onSelectFreelancer={(f) => setSelectedFreelancer(f)}
        onSelectProject={(p) => {
          handleTabChange('projects');
        }}
      />

      {/* 7. Disclaimer & Service Terms Modal */}
      {isDisclaimerOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in">
          <div className="relative max-w-lg bg-[#fbfaf6] rounded-[16px] p-6 border border-[#e0e3dc] shadow-2xl font-sans-sc space-y-4">
            <div className="flex items-center justify-between border-b border-[#e0e3dc] pb-3">
              <h4 className="font-serif-sc text-xl font-bold text-[#102f32]">
                才云平台服务协议与隐私说明
              </h4>
              <button
                onClick={() => setIsDisclaimerOpen(false)}
                className="p-1 text-[#718080] hover:text-[#102f32]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="text-[13px] text-[#506161] space-y-2 leading-relaxed">
              <p>
                <strong>1. 演示环境说明：</strong> 本网站为高保真数字设计原型展示，所涉及之人物、头像、作品集、服务定价及项目需求均为演示示例。
              </p>
              <p>
                <strong>2. 资金安全体系：</strong> 在实际生产部署中，平台通过银行三方存管专户实行“阶段确认、分批打款”机制，保障雇主与自由工作者双方资金安全。
              </p>
              <p>
                <strong>3. 知识产权与法务支持：</strong> 所有通过才云签约的项目成果著作权在验收结算后默认 100% 转移至委托方，并受区块链存证保护。
              </p>
            </div>
            <div className="pt-2 text-right">
              <button
                onClick={() => setIsDisclaimerOpen(false)}
                className="px-5 py-2 bg-[#163b3d] text-white text-[13px] rounded-full font-medium hover:bg-[#102f32]"
              >
                我知道了
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
