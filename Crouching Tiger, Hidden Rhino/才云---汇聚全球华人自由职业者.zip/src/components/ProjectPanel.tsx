import React from 'react';
import { ArrowRight } from 'lucide-react';
import { ASSET_IMAGES } from '../data/initialData';

interface ProjectPanelProps {
  onPostProject: () => void;
}

export const ProjectPanel: React.FC<ProjectPanelProps> = ({ onPostProject }) => {
  return (
    <div
      id="project-posting-panel"
      className="relative overflow-hidden rounded-[12px] bg-white border border-[#e0e3dc] p-5 sm:p-6 shadow-2xs group flex flex-col justify-between min-h-[170px]"
    >
      {/* Background Pale Landscape Image */}
      <div className="absolute right-0 top-0 bottom-0 w-full pointer-events-none overflow-hidden z-0">
        <img
          src={ASSET_IMAGES.projectPanelBg}
          alt="Chinese Ink Landscape"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-right opacity-35 group-hover:scale-105 transition-transform duration-500 ease-out"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-white via-white/80 to-transparent" />
      </div>

      {/* Content */}
      <div className="relative z-10 space-y-1">
        <h4 className="font-sans-sc text-[16px] font-bold text-[#102f32]">
          发布你的项目
        </h4>
        <p className="text-[12px] sm:text-[13px] text-[#718080] font-sans-sc">
          让合适的人主动找上你
        </p>
      </div>

      <div className="relative z-10 pt-4">
        <button
          id="panel-post-project-btn"
          onClick={onPostProject}
          className="inline-flex items-center space-x-1.5 bg-[#173a3b] hover:bg-[#102f32] text-white font-sans-sc text-[13px] font-medium px-4 py-2 rounded-full transition-all duration-200 shadow-sm active:scale-[0.98] cursor-pointer group/btn"
        >
          <span>发布项目</span>
          <ArrowRight className="w-3.5 h-3.5 transition-transform duration-200 group-hover/btn:translate-x-0.5" />
        </button>
      </div>
    </div>
  );
};
