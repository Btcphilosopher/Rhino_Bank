import React from 'react';
import { UserCheck, ShieldCheck, CheckCircle2, Headphones } from 'lucide-react';

interface AssurancePanelProps {
  onOpenAssuranceDetails: (item: string) => void;
}

export const AssurancePanel: React.FC<AssurancePanelProps> = ({
  onOpenAssuranceDetails,
}) => {
  const assurances = [
    {
      id: 'auth',
      label: '实名认证',
      desc: '100% 官方资质与实名多维审核',
      icon: <UserCheck className="w-4 h-4 stroke-[1.8] text-[#163b3d]" />,
    },
    {
      id: 'escrow',
      label: '资金托管',
      desc: '平台担保分段支付，验收无忧',
      icon: <ShieldCheck className="w-4 h-4 stroke-[1.8] text-[#163b3d]" />,
    },
    {
      id: 'guarantee',
      label: '项目保障',
      desc: '签署标准电子协议，权益有法可依',
      icon: <CheckCircle2 className="w-4 h-4 stroke-[1.8] text-[#163b3d]" />,
    },
    {
      id: 'support',
      label: '售后支持',
      desc: '专业仲裁顾问与7×24小时专属客服',
      icon: <Headphones className="w-4 h-4 stroke-[1.8] text-[#163b3d]" />,
    },
  ];

  return (
    <div
      id="platform-assurance-panel"
      className="bg-white rounded-[12px] border border-[#e0e3dc] p-5 shadow-2xs space-y-3.5"
    >
      <h4 className="font-sans-sc text-[15px] font-bold text-[#102f32] tracking-tight border-b border-[#f0ede6] pb-2.5">
        平台保障
      </h4>

      <div className="space-y-2.5">
        {assurances.map((item) => (
          <button
            key={item.id}
            id={`assurance-item-${item.id}`}
            onClick={() => onOpenAssuranceDetails(item.label)}
            className="w-full flex items-center justify-between p-1.5 rounded-[6px] hover:bg-[#f5f2eb]/70 transition-colors text-left group cursor-pointer"
            title={`${item.label} - ${item.desc}`}
          >
            <div className="flex items-center space-x-2.5">
              <div className="p-1 rounded bg-[#dce5df]/40 group-hover:bg-[#dce5df] transition-colors">
                {item.icon}
              </div>
              <span className="font-sans-sc text-[13px] font-medium text-[#29494a] group-hover:text-[#102f32]">
                {item.label}
              </span>
            </div>
            <span className="text-[11px] text-[#8c9c99] group-hover:text-[#668c87] transition-colors font-sans-sc">
              详情
            </span>
          </button>
        ))}
      </div>
    </div>
  );
};
