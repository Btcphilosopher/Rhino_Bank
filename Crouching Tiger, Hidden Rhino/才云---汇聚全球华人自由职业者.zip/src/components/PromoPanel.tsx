import React from 'react';
import { ArrowRight } from 'lucide-react';
import { ASSET_IMAGES } from '../data/initialData';

interface PromoPanelProps {
  onJoinClick: () => void;
}

export const PromoPanel: React.FC<PromoPanelProps> = ({ onJoinClick }) => {
  return (
    <div
      id="promo-panel-banner"
      className="relative overflow-hidden rounded-[14px] bg-[#163b3d] text-white p-6 sm:p-7 flex flex-col justify-between min-h-[360px] lg:min-h-[400px] shadow-sm group border border-[#102f32]/20"
    >
      {/* Background Architectural Courtyard Image */}
      <div className="absolute right-0 top-0 bottom-0 w-full sm:w-[65%] pointer-events-none overflow-hidden z-0">
        <img
          src={ASSET_IMAGES.promoCourtyard}
          alt="Classical Chinese Garden Architecture"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-right opacity-45 group-hover:scale-105 group-hover:opacity-55 transition-all duration-700 ease-out"
        />
        {/* Deep Ink Gradient Overlay to keep text perfectly legible */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#163b3d] via-[#163b3d]/85 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 h-16 bg-gradient-to-t from-[#163b3d] to-transparent" />
      </div>

      {/* Content Top */}
      <div className="relative z-10 space-y-3">
        {/* Tag Badge */}
        <div className="inline-block px-2.5 py-1 rounded-[4px] bg-white/10 backdrop-blur-xs text-[#dce5df] text-[12px] font-sans-sc font-medium tracking-wide border border-white/10">
          自由职业者专属
        </div>

        {/* Big Heading */}
        <h3 className="font-serif-sc text-[26px] sm:text-[30px] font-bold text-white leading-snug tracking-tight">
          开启你的
          <br />
          自由职业之旅
        </h3>

        {/* Subtitle */}
        <p className="text-[13px] sm:text-[14px] text-[#dce5df]/90 font-sans-sc font-normal pt-1">
          灵活接单 · 自主定价 · 全球机会
        </p>
      </div>

      {/* Content Bottom: CTA Button */}
      <div className="relative z-10 pt-6">
        <button
          id="promo-join-btn"
          onClick={onJoinClick}
          className="inline-flex items-center space-x-2 bg-white hover:bg-[#fbfaf6] text-[#102f32] font-sans-sc text-[14px] font-semibold px-5 py-2.5 rounded-full transition-all duration-200 shadow-md hover:shadow-lg active:scale-[0.98] cursor-pointer group/btn"
        >
          <span>立即加入</span>
          <ArrowRight className="w-4 h-4 transition-transform duration-200 group-hover/btn:translate-x-1" />
        </button>
      </div>
    </div>
  );
};
