import React from 'react';
import { ActiveTab } from '../types';

interface FooterProps {
  onTabChange: (tab: ActiveTab) => void;
  onOpenDisclaimer: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onTabChange, onOpenDisclaimer }) => {
  return (
    <footer id="global-footer" className="w-full bg-[#f5f2eb] border-t border-[#e0e3dc] py-10 font-sans-sc">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 pb-6 border-b border-[#e0e3dc]/70">
          {/* Brand info */}
          <div className="flex items-center space-x-4">
            <div className="w-7 h-7 rounded-full border border-[#102f32] flex items-center justify-center">
              <span className="font-serif-sc text-xs font-bold text-[#102f32]">才</span>
            </div>
            <span className="font-serif-sc text-lg font-bold text-[#102f32]">才云</span>
            <span className="text-[13px] text-[#718080] border-l border-[#dce5df] pl-3">
              连接人才 · 成就项目
            </span>
          </div>

          {/* Links */}
          <div className="flex flex-wrap items-center justify-center gap-6 text-[13px] text-[#506161]">
            <button
              onClick={() => onTabChange('about')}
              className="hover:text-[#102f32] transition-colors cursor-pointer"
            >
              关于才云
            </button>
            <button
              onClick={onOpenDisclaimer}
              className="hover:text-[#102f32] transition-colors cursor-pointer"
            >
              服务协议
            </button>
            <button
              onClick={onOpenDisclaimer}
              className="hover:text-[#102f32] transition-colors cursor-pointer"
            >
              隐私政策
            </button>
            <button
              onClick={() => onTabChange('about')}
              className="hover:text-[#102f32] transition-colors cursor-pointer"
            >
              帮助中心
            </button>
            <button
              onClick={() => onTabChange('about')}
              className="hover:text-[#102f32] transition-colors cursor-pointer"
            >
              联系我们
            </button>
          </div>
        </div>

        {/* Copyright and Demo Prototype Notice */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-[12px] text-[#8c9c99]">
          <p>© {new Date().getFullYear()} 才云 CaiYun. 保留所有权利。</p>
          <div className="flex items-center space-x-2 bg-[#e8e5dc]/50 px-3 py-1 rounded-full">
            <span className="w-1.5 h-1.5 rounded-full bg-[#668c87]" />
            <span>演示环境 · 本网站为产品原型，页面数据与人物均为虚构示例</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
