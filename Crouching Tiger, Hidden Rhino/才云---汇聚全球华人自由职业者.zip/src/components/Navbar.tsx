import React, { useState, useEffect } from 'react';
import { Search, Menu, X, Plus, User, LogOut } from 'lucide-react';
import { ActiveTab } from '../types';

interface NavbarProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  onOpenPostModal: () => void;
  onOpenAuthModal: (mode: 'login' | 'register') => void;
  onOpenSearch?: () => void;
  currentUser?: { name: string; role: 'client' | 'freelancer' } | null;
  onLogout?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  onTabChange,
  onOpenPostModal,
  onOpenAuthModal,
  onOpenSearch,
  currentUser,
  onLogout,
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems: { label: string; tab: ActiveTab }[] = [
    { label: '首页', tab: 'home' },
    { label: '找人才', tab: 'talents' },
    { label: '找项目', tab: 'projects' },
    { label: '服务市场', tab: 'services' },
    { label: '作品集', tab: 'portfolio' },
    { label: '关于我们', tab: 'about' },
  ];

  return (
    <header
      id="global-header"
      className={`sticky top-0 z-40 w-full transition-all duration-300 ${
        isScrolled
          ? 'bg-[#f5f2eb]/95 backdrop-blur-md shadow-sm border-b border-[#e0e3dc]'
          : 'bg-[#f5f2eb] border-b border-transparent'
      }`}
    >
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 h-[64px] flex items-center justify-between">
        {/* Left: Brand Logo & Tagline */}
        <div className="flex items-center space-x-6">
          <button
            id="brand-logo-btn"
            onClick={() => onTabChange('home')}
            className="flex items-center space-x-3 text-left focus:outline-none group cursor-pointer"
          >
            {/* Circular Abstract Brand Emblem */}
            <div className="relative w-8 h-8 rounded-full border border-[#102f32] flex items-center justify-center bg-transparent group-hover:bg-[#102f32]/5 transition-colors">
              <span className="font-serif-sc text-sm font-bold text-[#102f32] leading-none">
                才
              </span>
            </div>
            {/* Brand Name */}
            <span className="font-serif-sc text-xl font-bold tracking-tight text-[#102f32]">
              才云
            </span>
          </button>

          {/* Slogan with vertical divider */}
          <div className="hidden md:flex items-center space-x-3 text-[13px] text-[#718080] border-l border-[#dce5df] pl-4 font-sans-sc">
            <span>连接人才 · 成就项目</span>
          </div>
        </div>

        {/* Center: Navigation Items (Desktop) */}
        <nav className="hidden lg:flex items-center space-x-8 font-sans-sc text-[15px]">
          {navItems.map((item) => {
            const isActive = activeTab === item.tab;
            return (
              <button
                key={item.tab}
                id={`nav-item-${item.tab}`}
                onClick={() => onTabChange(item.tab)}
                className={`relative py-2 font-medium transition-colors cursor-pointer ${
                  isActive
                    ? 'text-[#102f32] font-semibold'
                    : 'text-[#506161] hover:text-[#102f32]'
                }`}
              >
                <span>{item.label}</span>
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-[2.5px] bg-[#102f32] rounded-full" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Right: Actions */}
        <div className="hidden sm:flex items-center space-x-4 font-sans-sc">
          {/* Post Project Button */}
          <button
            id="nav-post-project-btn"
            onClick={onOpenPostModal}
            className="flex items-center space-x-1.5 text-[13px] font-medium text-[#163b3d] hover:bg-[#dce5df]/50 border border-[#163b3d]/30 px-3.5 py-1.5 rounded-full transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>发布需求</span>
          </button>

          {/* User Logged In state OR Login/Register */}
          {currentUser ? (
            <div className="flex items-center space-x-3 bg-white px-3 py-1.5 rounded-full border border-[#e0e3dc]">
              <div className="w-6 h-6 rounded-full bg-[#163b3d] text-white flex items-center justify-center text-[11px] font-bold">
                {currentUser.name.slice(0, 1)}
              </div>
              <span className="text-[13px] font-medium text-[#102f32]">
                {currentUser.name}
              </span>
              <button
                onClick={onLogout}
                className="text-[#718080] hover:text-[#b9513c] p-1 cursor-pointer"
                title="退出登录"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <div className="flex items-center space-x-3">
              <button
                id="nav-login-btn"
                onClick={() => onOpenAuthModal('login')}
                className="text-[14px] font-medium text-[#29494a] hover:text-[#102f32] px-2 py-1 transition-colors cursor-pointer"
              >
                登录
              </button>

              <button
                id="nav-register-btn"
                onClick={() => onOpenAuthModal('register')}
                className="bg-[#163b3d] hover:bg-[#102f32] text-white text-[14px] font-medium px-4 py-1.5 rounded-full transition-all duration-200 shadow-sm hover:shadow active:scale-[0.98] cursor-pointer"
              >
                注册
              </button>
            </div>
          )}
        </div>

        {/* Mobile Hamburger Button */}
        <div className="flex sm:hidden items-center space-x-2">
          <button
            id="mobile-post-btn"
            onClick={onOpenPostModal}
            className="p-1.5 text-[#163b3d] bg-[#dce5df]/50 rounded-full"
            aria-label="发布项目"
          >
            <Plus className="w-5 h-5" />
          </button>
          <button
            id="mobile-menu-toggle-btn"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-[#102f32] rounded-md hover:bg-[#dce5df]/40"
            aria-label="切换菜单"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="sm:hidden bg-[#f5f2eb] border-b border-[#e0e3dc] px-4 pt-2 pb-6 space-y-3 font-sans-sc animate-in slide-in-from-top-2 duration-200">
          <div className="grid grid-cols-2 gap-2 pt-2 pb-3 border-b border-[#e0e3dc]">
            {navItems.map((item) => {
              const isActive = activeTab === item.tab;
              return (
                <button
                  key={item.tab}
                  onClick={() => {
                    onTabChange(item.tab);
                    setMobileMenuOpen(false);
                  }}
                  className={`text-left px-3 py-2.5 rounded-lg text-[15px] font-medium transition-colors ${
                    isActive
                      ? 'bg-[#102f32] text-white'
                      : 'text-[#29494a] hover:bg-[#dce5df]/50'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </div>

          <div className="flex items-center space-x-3 pt-2">
            {currentUser ? (
              <div className="w-full flex items-center justify-between p-2.5 bg-white rounded-lg border border-[#e0e3dc]">
                <span className="text-[14px] font-medium text-[#102f32]">
                  当前登录：{currentUser.name}
                </span>
                <button
                  onClick={() => {
                    onLogout?.();
                    setMobileMenuOpen(false);
                  }}
                  className="text-[13px] text-[#b9513c]"
                >
                  退出
                </button>
              </div>
            ) : (
              <>
                <button
                  onClick={() => {
                    onOpenAuthModal('login');
                    setMobileMenuOpen(false);
                  }}
                  className="flex-1 py-2.5 text-center text-[14px] font-medium border border-[#102f32] text-[#102f32] rounded-full"
                >
                  登录
                </button>
                <button
                  onClick={() => {
                    onOpenAuthModal('register');
                    setMobileMenuOpen(false);
                  }}
                  className="flex-1 py-2.5 text-center text-[14px] font-medium bg-[#163b3d] text-white rounded-full"
                >
                  注册
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
