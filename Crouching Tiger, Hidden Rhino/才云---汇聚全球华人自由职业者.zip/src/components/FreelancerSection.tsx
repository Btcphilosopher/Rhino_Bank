import React from 'react';
import { ArrowRight } from 'lucide-react';
import { Freelancer } from '../types';
import { FreelancerCard } from './FreelancerCard';

interface FreelancerSectionProps {
  freelancers: Freelancer[];
  onSelectFreelancer: (freelancer: Freelancer) => void;
  onViewMore: () => void;
}

export const FreelancerSection: React.FC<FreelancerSectionProps> = ({
  freelancers,
  onSelectFreelancer,
  onViewMore,
}) => {
  return (
    <div id="freelancer-section-container" className="flex flex-col justify-between h-full">
      {/* Header with Title and "查看更多 →" */}
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-sans-sc text-[17px] sm:text-[18px] font-bold text-[#102f32] tracking-tight">
          优秀自由职业者
        </h3>
        <button
          id="view-more-freelancers-btn"
          onClick={onViewMore}
          className="group flex items-center space-x-1 text-[13px] font-medium text-[#718080] hover:text-[#102f32] transition-colors cursor-pointer"
        >
          <span>查看更多</span>
          <ArrowRight className="w-3.5 h-3.5 transition-transform duration-200 group-hover:translate-x-0.5" />
        </button>
      </div>

      {/* 4 Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        {freelancers.slice(0, 4).map((f) => (
          <FreelancerCard
            key={f.id}
            freelancer={f}
            onSelect={onSelectFreelancer}
          />
        ))}
      </div>
    </div>
  );
};
