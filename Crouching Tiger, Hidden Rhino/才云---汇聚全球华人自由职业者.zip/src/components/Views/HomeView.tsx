import React from 'react';
import { Hero } from '../Hero';
import { HotCategories } from '../HotCategories';
import { PromoPanel } from '../PromoPanel';
import { FreelancerSection } from '../FreelancerSection';
import { ProjectPanel } from '../ProjectPanel';
import { AssurancePanel } from '../AssurancePanel';
import { StatisticsStrip } from '../StatisticsStrip';
import { Freelancer, Project } from '../../types';

interface HomeViewProps {
  freelancers: Freelancer[];
  onSelectCategory: (categoryName: string) => void;
  onSelectFreelancer: (freelancer: Freelancer) => void;
  onViewMoreFreelancers: () => void;
  onPostProject: () => void;
  onJoinFreelancer: () => void;
  onOpenAssuranceDetails: (item: string) => void;
  onSearchSubmit: (query: string) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  freelancers,
  onSelectCategory,
  onSelectFreelancer,
  onViewMoreFreelancers,
  onPostProject,
  onJoinFreelancer,
  onOpenAssuranceDetails,
  onSearchSubmit,
}) => {
  return (
    <div className="w-full bg-[#f5f2eb]">
      {/* 1. Hero Section */}
      <Hero
        onSearchSubmit={onSearchSubmit}
        onTagClick={(tag) => onSearchSubmit(tag)}
      />

      {/* 2. Hot Categories Section */}
      <HotCategories onSelectCategory={onSelectCategory} />

      {/* 3. Main Content Grid (Matches reference composition faithfully) */}
      <section className="w-full py-8 sm:py-10">
        <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
          {/* Responsive Layout Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 lg:gap-6 items-stretch">
            {/* Left: Large Recruitment / Promotional Banner Card (3.5 / 12 on desktop) */}
            <div className="lg:col-span-4 xl:col-span-4 flex flex-col">
              <PromoPanel onJoinClick={onJoinFreelancer} />
            </div>

            {/* Middle: Featured Freelancers (5.5 / 12 on desktop or combined) */}
            <div className="lg:col-span-8 xl:col-span-8 flex flex-col justify-between">
              {/* Top Row: 4 Freelancers */}
              <FreelancerSection
                freelancers={freelancers}
                onSelectFreelancer={onSelectFreelancer}
                onViewMore={onViewMoreFreelancers}
              />
            </div>
          </div>

          {/* Secondary Row: Project Posting Panel + Assurance Panel */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-5 lg:gap-6 mt-6">
            {/* Left filler or wide project panel */}
            <div className="lg:col-span-7 xl:col-span-8">
              <ProjectPanel onPostProject={onPostProject} />
            </div>

            {/* Right platform assurance panel */}
            <div className="lg:col-span-5 xl:col-span-4">
              <AssurancePanel onOpenAssuranceDetails={onOpenAssuranceDetails} />
            </div>
          </div>
        </div>
      </section>

      {/* 4. Statistics Strip */}
      <StatisticsStrip />
    </div>
  );
};
