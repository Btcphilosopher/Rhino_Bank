import React, { useState, useMemo } from 'react';
import { Search, Filter, SlidersHorizontal, Star, Award, Check } from 'lucide-react';
import { Freelancer, Category } from '../../types';
import { CATEGORIES } from '../../data/initialData';
import { FreelancerCard } from '../FreelancerCard';

interface TalentsViewProps {
  freelancers: Freelancer[];
  initialCategory?: string | null;
  onSelectFreelancer: (freelancer: Freelancer) => void;
  onPostProject: () => void;
}

export const TalentsView: React.FC<TalentsViewProps> = ({
  freelancers,
  initialCategory,
  onSelectFreelancer,
  onPostProject,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>(initialCategory || '全部');
  const [searchQuery, setSearchQuery] = useState('');
  const [minRating, setMinRating] = useState<number>(0);
  const [maxPrice, setMaxPrice] = useState<number>(1000);
  const [sortBy, setSortBy] = useState<'default' | 'rating' | 'orders' | 'price_asc' | 'price_desc'>('default');

  const filteredTalents = useMemo(() => {
    return freelancers
      .filter((f) => {
        const matchesCategory = selectedCategory === '全部' || f.category === selectedCategory;
        const matchesSearch =
          !searchQuery.trim() ||
          f.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          f.profession.toLowerCase().includes(searchQuery.toLowerCase()) ||
          f.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase())) ||
          f.skills.some((s) => s.toLowerCase().includes(searchQuery.toLowerCase()));
        const matchesRating = f.rating >= minRating;
        const matchesPrice = f.hourlyRate <= maxPrice;
        return matchesCategory && matchesSearch && matchesRating && matchesPrice;
      })
      .sort((a, b) => {
        if (sortBy === 'rating') return b.rating - a.rating;
        if (sortBy === 'orders') return b.completedCount - a.completedCount;
        if (sortBy === 'price_asc') return a.hourlyRate - b.hourlyRate;
        if (sortBy === 'price_desc') return b.hourlyRate - a.hourlyRate;
        return 0;
      });
  }, [freelancers, selectedCategory, searchQuery, minRating, maxPrice, sortBy]);

  return (
    <div className="w-full min-h-screen bg-[#f5f2eb] py-8 font-sans-sc">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        {/* Page Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-[14px] border border-[#e0e3dc] shadow-2xs">
          <div>
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 rounded-full bg-[#668c87]" />
              <h1 className="font-serif-sc text-2xl sm:text-3xl font-bold text-[#102f32]">
                找人才 · 汇聚全球华人顶尖专业力量
              </h1>
            </div>
            <p className="text-[14px] text-[#718080] mt-1">
              严格实名认证与作品盲审，为您匹配最契合的高水准自由职业专家
            </p>
          </div>

          <button
            onClick={onPostProject}
            className="px-5 py-2.5 bg-[#163b3d] hover:bg-[#102f32] text-white text-[14px] font-medium rounded-full shadow-sm active:scale-98 transition-all cursor-pointer whitespace-nowrap"
          >
            直接发布需求匹配 →
          </button>
        </div>

        {/* Category Pills Bar */}
        <div className="flex items-center space-x-2 overflow-x-auto pb-2 scrollbar-none">
          <button
            onClick={() => setSelectedCategory('全部')}
            className={`px-4 py-2 rounded-full text-[13px] font-medium whitespace-nowrap transition-all cursor-pointer ${
              selectedCategory === '全部'
                ? 'bg-[#102f32] text-white shadow-xs'
                : 'bg-white text-[#506161] hover:bg-[#dce5df]/60 border border-[#e0e3dc]'
            }`}
          >
            全部专业领域
          </button>
          {CATEGORIES.map((c) => (
            <button
              key={c.id}
              onClick={() => setSelectedCategory(c.name)}
              className={`px-4 py-2 rounded-full text-[13px] font-medium whitespace-nowrap transition-all cursor-pointer ${
                selectedCategory === catName(c.name)
                  ? 'bg-[#102f32] text-white shadow-xs'
                  : 'bg-white text-[#506161] hover:bg-[#dce5df]/60 border border-[#e0e3dc]'
              }`}
            >
              {c.name}
            </button>
          ))}
        </div>

        {/* Filter Controls & Search */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 bg-white p-4 sm:p-5 rounded-[12px] border border-[#e0e3dc]">
          {/* Search box */}
          <div className="md:col-span-4 relative flex items-center bg-[#f5f2eb] rounded-[8px] px-3 py-1.5 border border-[#e0e3dc]">
            <Search className="w-4 h-4 text-[#718080] mr-2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="按姓名、职业或技能关键词检索..."
              className="w-full bg-transparent text-[13px] text-[#102f32] placeholder-[#8c9c99] focus:outline-none"
            />
          </div>

          {/* Rating filter */}
          <div className="md:col-span-3 flex items-center space-x-2">
            <span className="text-[13px] text-[#718080] shrink-0">评分要求：</span>
            <select
              value={minRating}
              onChange={(e) => setMinRating(Number(e.target.value))}
              className="w-full p-2 bg-[#f5f2eb] border border-[#e0e3dc] rounded-[8px] text-[13px] text-[#102f32] focus:outline-none"
            >
              <option value="0">全部评分</option>
              <option value="4.8">4.8 分及以上</option>
              <option value="4.9">4.9 分及以上 (超优)</option>
              <option value="5.0">5.0 满分口碑</option>
            </select>
          </div>

          {/* Max Price filter */}
          <div className="md:col-span-3 flex items-center space-x-2">
            <span className="text-[13px] text-[#718080] shrink-0">最高时薪：</span>
            <select
              value={maxPrice}
              onChange={(e) => setMaxPrice(Number(e.target.value))}
              className="w-full p-2 bg-[#f5f2eb] border border-[#e0e3dc] rounded-[8px] text-[13px] text-[#102f32] focus:outline-none"
            >
              <option value="1000">不限预算</option>
              <option value="400">¥ 400 / 小时以内</option>
              <option value="500">¥ 500 / 小时以内</option>
              <option value="600">¥ 600 / 小时以内</option>
            </select>
          </div>

          {/* Sorting */}
          <div className="md:col-span-2 flex items-center space-x-2">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="w-full p-2 bg-[#f5f2eb] border border-[#e0e3dc] rounded-[8px] text-[13px] text-[#102f32] font-medium focus:outline-none"
            >
              <option value="default">综合排序</option>
              <option value="rating">评分最高</option>
              <option value="orders">成交量最多</option>
              <option value="price_asc">价格从低到高</option>
              <option value="price_desc">价格从高到低</option>
            </select>
          </div>
        </div>

        {/* Talents Results Grid */}
        <div className="space-y-4">
          <div className="flex items-center justify-between text-[13px] text-[#718080]">
            <span>共找到 <strong className="text-[#102f32]">{filteredTalents.length}</strong> 位符合条件的认证自由职业者</span>
            <span>当前领域：{selectedCategory}</span>
          </div>

          {filteredTalents.length === 0 ? (
            <div className="bg-white rounded-[14px] p-12 text-center border border-[#e0e3dc] space-y-3">
              <p className="text-[15px] text-[#718080]">未检索到符合当前筛选条件的自由职业者</p>
              <button
                onClick={() => {
                  setSelectedCategory('全部');
                  setSearchQuery('');
                  setMinRating(0);
                  setMaxPrice(1000);
                }}
                className="px-4 py-2 bg-[#dce5df] text-[#163b3d] text-[13px] font-medium rounded-full cursor-pointer hover:bg-[#668c87] hover:text-white transition-colors"
              >
                重置所有筛选
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-5">
              {filteredTalents.map((f) => (
                <FreelancerCard
                  key={f.id}
                  freelancer={f}
                  onSelect={onSelectFreelancer}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

function catName(name: string) {
  return name;
}
