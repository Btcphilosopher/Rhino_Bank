import React from 'react';
import { ShieldCheck, HeartHandshake, Compass, Sparkles, Award } from 'lucide-react';
import { ASSET_IMAGES } from '../../data/initialData';

interface AboutViewProps {
  onJoinFreelancer: () => void;
  onPostProject: () => void;
}

export const AboutView: React.FC<AboutViewProps> = ({
  onJoinFreelancer,
  onPostProject,
}) => {
  return (
    <div className="w-full min-h-screen bg-[#f5f2eb] py-12 font-sans-sc">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        {/* Brand Banner */}
        <div className="relative overflow-hidden rounded-[20px] bg-[#163b3d] text-white p-8 sm:p-12 text-center space-y-4 shadow-md">
          <div className="w-14 h-14 rounded-full border border-white/30 flex items-center justify-center mx-auto bg-white/10 backdrop-blur-xs">
            <span className="font-serif-sc text-2xl font-bold text-white">才</span>
          </div>

          <h1 className="font-serif-sc text-3xl sm:text-4xl font-bold tracking-tight">
            才聚云端 · 共创未来
          </h1>

          <p className="text-[#dce5df] text-[15px] sm:text-[16px] max-w-xl mx-auto leading-relaxed">
            才云（CaiYun）是专为顶尖华人独立创作者、数字工程师、商业顾问与文创工作室打造的高端自由职业协作殿堂。
          </p>
        </div>

        {/* Brand Philosophy */}
        <div className="bg-white rounded-[16px] p-6 sm:p-10 border border-[#e0e3dc] space-y-6 shadow-2xs">
          <div className="border-b border-[#e0e3dc] pb-4">
            <span className="text-[12px] font-semibold text-[#668c87] tracking-wider uppercase">
              Brand Philosophy
            </span>
            <h2 className="font-serif-sc text-2xl font-bold text-[#102f32] mt-1">
              立足东方文脉，重塑自由协作新典范
            </h2>
          </div>

          <div className="space-y-4 text-[14px] sm:text-[15px] text-[#29494a] leading-relaxed">
            <p>
              在数字化与知识工作全球化的今天，我们告别拥挤同质的劳动力市场模式，汲取宋代文人书院与风雅雅集的协作智慧——让专业的人，在松弛、从容、受尊重的土壤中完成非凡的创作。
            </p>
            <p>
              “才云”象征着才思如云霞汇聚，亦寄托着基于云端无界协同的美好愿景。我们坚持以<strong>实名严选、资金托管、版权保护、透明结算</strong>为基石，消除自由职业者与企业之间的信息壁垒与履约顾虑。
            </p>
          </div>

          {/* 3 Pillars */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4">
            <div className="p-5 rounded-[12px] bg-[#fbfaf6] border border-[#e0e3dc] space-y-2 text-center">
              <Compass className="w-6 h-6 text-[#163b3d] mx-auto" />
              <h3 className="font-bold text-[15px] text-[#102f32]">求真严谨</h3>
              <p className="text-[12px] text-[#718080]">全维实名认证，同行盲审代表作品</p>
            </div>

            <div className="p-5 rounded-[12px] bg-[#fbfaf6] border border-[#e0e3dc] space-y-2 text-center">
              <ShieldCheck className="w-6 h-6 text-[#163b3d] mx-auto" />
              <h3 className="font-bold text-[15px] text-[#102f32]">资金守信</h3>
              <p className="text-[12px] text-[#718080]">阶段验收分段放款，银行专户安全托管</p>
            </div>

            <div className="p-5 rounded-[12px] bg-[#fbfaf6] border border-[#e0e3dc] space-y-2 text-center">
              <Sparkles className="w-6 h-6 text-[#163b3d] mx-auto" />
              <h3 className="font-bold text-[15px] text-[#102f32]">东方雅致</h3>
              <p className="text-[12px] text-[#718080]">温润纸墨视觉语言，尊享优雅创作心境</p>
            </div>
          </div>
        </div>

        {/* CTA Footer in About */}
        <div className="bg-[#fbfaf6] rounded-[16px] p-8 border border-[#e0e3dc] flex flex-col sm:flex-row items-center justify-between gap-6">
          <div>
            <h3 className="font-serif-sc text-xl font-bold text-[#102f32]">
              准备好开启下一次卓越合作了吗？
            </h3>
            <p className="text-[13px] text-[#718080] mt-1">
              无论是寻找专属创作者，还是作为专家申请入驻，才云皆为您敞开大门。
            </p>
          </div>

          <div className="flex items-center space-x-3 shrink-0">
            <button
              onClick={onJoinFreelancer}
              className="px-5 py-2.5 bg-white border border-[#163b3d] text-[#163b3d] hover:bg-[#dce5df]/40 text-[14px] font-medium rounded-full cursor-pointer transition-colors"
            >
              入驻才云
            </button>
            <button
              onClick={onPostProject}
              className="px-5 py-2.5 bg-[#163b3d] hover:bg-[#102f32] text-white text-[14px] font-medium rounded-full cursor-pointer transition-colors shadow-sm"
            >
              发布项目
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
