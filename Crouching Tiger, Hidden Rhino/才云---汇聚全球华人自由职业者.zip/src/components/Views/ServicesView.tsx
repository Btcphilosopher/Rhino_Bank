import React, { useState } from 'react';
import { Clock, ShieldCheck, CheckCircle2, Search } from 'lucide-react';
import { ServicePackage, Freelancer } from '../../types';
import { CATEGORIES } from '../../data/initialData';

interface ServicesViewProps {
  services: ServicePackage[];
  freelancers: Freelancer[];
  onSelectFreelancer: (freelancer: Freelancer) => void;
  onOrderService: (service: ServicePackage) => void;
}

export const ServicesView: React.FC<ServicesViewProps> = ({
  services,
  freelancers,
  onSelectFreelancer,
  onOrderService,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('全部');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredServices = services.filter((s) => {
    const matchCat = selectedCategory === '全部' || s.category === selectedCategory;
    const matchQuery =
      !searchQuery.trim() ||
      s.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (s.description && s.description.toLowerCase().includes(searchQuery.toLowerCase())) ||
      s.freelancerName.toLowerCase().includes(searchQuery.toLowerCase());
    return matchCat && matchQuery;
  });

  return (
    <div className="w-full min-h-screen bg-[#f5f2eb] py-8 font-sans-sc">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        {/* Header */}
        <div className="bg-white p-6 rounded-[14px] border border-[#e0e3dc] shadow-2xs">
          <div className="flex items-center space-x-2">
            <span className="w-2 h-2 rounded-full bg-[#668c87]" />
            <h1 className="font-serif-sc text-2xl sm:text-3xl font-bold text-[#102f32]">
              服务市场 · 明码实价 标准化专业交付
            </h1>
          </div>
          <p className="text-[14px] text-[#718080] mt-1">
            清晰的交付成果与周期约定，省去反复询价流程，支持平台资金托管担保
          </p>
        </div>

        {/* Categories Bar */}
        <div className="flex items-center space-x-2 overflow-x-auto pb-2 scrollbar-none">
          <button
            onClick={() => setSelectedCategory('全部')}
            className={`px-4 py-2 rounded-full text-[13px] font-medium whitespace-nowrap transition-all cursor-pointer ${
              selectedCategory === '全部'
                ? 'bg-[#102f32] text-white shadow-xs'
                : 'bg-white text-[#506161] hover:bg-[#dce5df]/60 border border-[#e0e3dc]'
            }`}
          >
            全部服务 ({services.length})
          </button>
          {CATEGORIES.map((c) => (
            <button
              key={c.id}
              onClick={() => setSelectedCategory(c.name)}
              className={`px-4 py-2 rounded-full text-[13px] font-medium whitespace-nowrap transition-all cursor-pointer ${
                selectedCategory === c.name
                  ? 'bg-[#102f32] text-white shadow-xs'
                  : 'bg-white text-[#506161] hover:bg-[#dce5df]/60 border border-[#e0e3dc]'
              }`}
            >
              {c.name}
            </button>
          ))}
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredServices.map((s) => {
            const author = freelancers.find((f) => f.id === s.freelancerId);
            return (
              <div
                key={s.id}
                className="bg-white rounded-[14px] border border-[#e0e3dc] hover:border-[#668c87] p-5 shadow-2xs hover:shadow-md transition-all flex flex-col justify-between space-y-4"
              >
                <div className="space-y-3">
                  {/* Category & Price */}
                  <div className="flex items-start justify-between">
                    <span className="text-[12px] bg-[#dce5df]/50 text-[#163b3d] px-2.5 py-0.5 rounded-[4px] font-medium">
                      {s.category}
                    </span>
                    <div className="text-right">
                      <span className="text-[20px] font-bold text-[#b9513c]">¥ {s.price}</span>
                      <span className="text-[11px] text-[#718080] block">起 / 套</span>
                    </div>
                  </div>

                  <h3 className="font-serif-sc text-[17px] font-bold text-[#102f32] leading-snug">
                    {s.title}
                  </h3>

                  <p className="text-[13px] text-[#506161] leading-relaxed line-clamp-3">
                    {s.description}
                  </p>
                </div>

                <div className="space-y-3 pt-3 border-t border-[#f0ede6]">
                  {/* Provider Info */}
                  {author && (
                    <div
                      onClick={() => onSelectFreelancer(author)}
                      className="flex items-center space-x-2.5 cursor-pointer hover:opacity-80 transition-opacity"
                    >
                      <img
                        src={author.avatar}
                        alt={author.name}
                        referrerPolicy="no-referrer"
                        className="w-8 h-8 rounded-full object-cover"
                      />
                      <div>
                        <span className="text-[13px] font-bold text-[#102f32]">{author.name}</span>
                        <span className="text-[11px] text-[#718080] block">{author.profession}</span>
                      </div>
                    </div>
                  )}

                  {/* Duration & Order Button */}
                  <div className="flex items-center justify-between text-[12px] pt-1">
                    <span className="text-[#718080] flex items-center space-x-1">
                      <Clock className="w-3.5 h-3.5 text-[#668c87]" />
                      <span>交付周期：{s.duration}</span>
                    </span>

                    <button
                      onClick={() => onOrderService(s)}
                      className="px-4 py-1.5 bg-[#163b3d] hover:bg-[#102f32] text-white rounded-full font-medium transition-colors cursor-pointer"
                    >
                      立即委托服务
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
