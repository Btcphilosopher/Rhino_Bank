import React, { useState } from 'react';
import { ExternalLink, X, Eye } from 'lucide-react';
import { Freelancer } from '../../types';

interface PortfolioViewProps {
  freelancers: Freelancer[];
  onSelectFreelancer: (f: Freelancer) => void;
}

export const PortfolioView: React.FC<PortfolioViewProps> = ({
  freelancers,
  onSelectFreelancer,
}) => {
  const [selectedFilter, setSelectedFilter] = useState('全部');
  const [previewImage, setPreviewImage] = useState<{
    url: string;
    title: string;
    author: Freelancer;
    category: string;
  } | null>(null);

  // Flatten all portfolio items with their author
  const allPortfolios = freelancers.flatMap((f) =>
    f.portfolio.map((p) => ({
      ...p,
      author: f,
    }))
  );

  const categories = ['全部', 'UI/UX设计', '品牌视觉', '前端全栈', '文案营销', '三维渲染'];

  const filteredPortfolios = allPortfolios.filter(
    (item) => selectedFilter === '全部' || item.category.includes(selectedFilter)
  );

  return (
    <div className="w-full min-h-screen bg-[#f5f2eb] py-8 font-sans-sc">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        {/* Header */}
        <div className="bg-white p-6 rounded-[14px] border border-[#e0e3dc] shadow-2xs">
          <div className="flex items-center space-x-2">
            <span className="w-2 h-2 rounded-full bg-[#668c87]" />
            <h1 className="font-serif-sc text-2xl sm:text-3xl font-bold text-[#102f32]">
              作品画卷 · 才云精选实战交付案例
            </h1>
          </div>
          <p className="text-[14px] text-[#718080] mt-1">
            灵感碰撞与东方美学实践，见证数字化创意与技术落地的非凡力量
          </p>
        </div>

        {/* Filter Bar */}
        <div className="flex space-x-2 overflow-x-auto pb-2 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedFilter(cat)}
              className={`px-4 py-2 rounded-full text-[13px] font-medium whitespace-nowrap transition-all cursor-pointer ${
                selectedFilter === cat
                  ? 'bg-[#102f32] text-white shadow-xs'
                  : 'bg-white text-[#506161] hover:bg-[#dce5df]/60 border border-[#e0e3dc]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Portfolio Masonry / Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPortfolios.map((item, idx) => (
            <div
              key={idx}
              className="group bg-white rounded-[14px] overflow-hidden border border-[#e0e3dc] hover:border-[#668c87] shadow-2xs hover:shadow-lg transition-all duration-300 flex flex-col justify-between"
            >
              <div
                className="relative h-56 overflow-hidden cursor-pointer bg-[#e8e5dc]"
                onClick={() =>
                  setPreviewImage({
                    url: item.image,
                    title: item.title,
                    author: item.author,
                    category: item.category,
                  })
                }
              >
                <img
                  src={item.image}
                  alt={item.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
                />
                <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white space-x-2">
                  <Eye className="w-5 h-5" />
                  <span className="text-[13px] font-medium">查看大图</span>
                </div>
              </div>

              <div className="p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-medium text-[#668c87] bg-[#dce5df]/40 px-2 py-0.5 rounded">
                    {item.category}
                  </span>
                </div>

                <h3 className="font-serif-sc text-[16px] font-bold text-[#102f32] line-clamp-1">
                  {item.title}
                </h3>

                {/* Author row */}
                <div className="pt-2 border-t border-[#f0ede6] flex items-center justify-between">
                  <button
                    onClick={() => onSelectFreelancer(item.author)}
                    className="flex items-center space-x-2 hover:opacity-80 transition-opacity text-left cursor-pointer"
                  >
                    <img
                      src={item.author.avatar}
                      alt={item.author.name}
                      referrerPolicy="no-referrer"
                      className="w-6 h-6 rounded-full object-cover"
                    />
                    <span className="text-[12px] font-semibold text-[#102f32]">
                      {item.author.name}
                    </span>
                  </button>

                  <button
                    onClick={() => onSelectFreelancer(item.author)}
                    className="text-[12px] text-[#163b3d] hover:text-[#b9513c] font-medium"
                  >
                    委托合作 →
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Image Preview Modal */}
      {previewImage && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs animate-in fade-in"
          onClick={() => setPreviewImage(null)}
        >
          <div
            className="relative max-w-4xl max-h-[90vh] bg-white rounded-[14px] overflow-hidden shadow-2xl flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setPreviewImage(null)}
              className="absolute top-3 right-3 z-10 p-2 rounded-full bg-black/60 hover:bg-black text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
            <img
              src={previewImage.url}
              alt={previewImage.title}
              referrerPolicy="no-referrer"
              className="max-h-[70vh] object-contain bg-[#102f32]"
            />
            <div className="p-4 bg-[#fbfaf6] flex items-center justify-between border-t border-[#e0e3dc]">
              <div>
                <h4 className="font-serif-sc text-lg font-bold text-[#102f32]">
                  {previewImage.title}
                </h4>
                <p className="text-[12px] text-[#718080]">
                  作者：{previewImage.author.name} ({previewImage.author.profession})
                </p>
              </div>
              <button
                onClick={() => {
                  const author = previewImage.author;
                  setPreviewImage(null);
                  onSelectFreelancer(author);
                }}
                className="px-4 py-2 bg-[#163b3d] text-white text-[13px] rounded-full font-medium hover:bg-[#102f32]"
              >
                查看作者完整履历
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
