import React, { useState, useMemo } from 'react';
import { Search, Clock, DollarSign, Users, Briefcase, Plus, CheckCircle, Send, X } from 'lucide-react';
import { Project, Category } from '../../types';
import { CATEGORIES } from '../../data/initialData';

interface ProjectsViewProps {
  projects: Project[];
  initialCategory?: string | null;
  onPostProject: () => void;
  onBidProject: (projectId: string) => void;
}

export const ProjectsView: React.FC<ProjectsViewProps> = ({
  projects,
  initialCategory,
  onPostProject,
  onBidProject,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>(initialCategory || '全部');
  const [searchQuery, setSearchQuery] = useState('');
  const [biddingProjectId, setBiddingProjectId] = useState<string | null>(null);
  const [bidProposal, setBidProposal] = useState('');
  const [bidAmount, setBidAmount] = useState<number>(5000);
  const [bidSubmitted, setBidSubmitted] = useState(false);

  const filteredProjects = useMemo(() => {
    return projects.filter((p) => {
      const matchCat = selectedCategory === '全部' || p.category === selectedCategory;
      const matchQuery =
        !searchQuery.trim() ||
        p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.skills.some((s) => s.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchCat && matchQuery;
    });
  }, [projects, selectedCategory, searchQuery]);

  const handleSendBid = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bidProposal.trim()) return;
    setBidSubmitted(true);
    if (biddingProjectId) {
      onBidProject(biddingProjectId);
    }
    setTimeout(() => {
      setBidSubmitted(false);
      setBiddingProjectId(null);
      setBidProposal('');
    }, 2000);
  };

  const selectedProj = projects.find((p) => p.id === biddingProjectId);

  return (
    <div className="w-full min-h-screen bg-[#f5f2eb] py-8 font-sans-sc">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-[14px] border border-[#e0e3dc] shadow-2xs">
          <div>
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 rounded-full bg-[#668c87]" />
              <h1 className="font-serif-sc text-2xl sm:text-3xl font-bold text-[#102f32]">
                找项目 · 探索海量高价值委托机遇
              </h1>
            </div>
            <p className="text-[14px] text-[#718080] mt-1">
              企业直签 · 平台托管资金先行垫付 · 100% 拒绝恶意拖欠与无度改稿
            </p>
          </div>

          <button
            onClick={onPostProject}
            className="flex items-center space-x-2 px-5 py-2.5 bg-[#163b3d] hover:bg-[#102f32] text-white text-[14px] font-medium rounded-full shadow-sm active:scale-98 transition-all cursor-pointer whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            <span>发布项目需求</span>
          </button>
        </div>

        {/* Categories Bar */}
        <div className="flex items-center space-x-2 overflow-x-auto pb-2 scrollbar-none">
          <button
            onClick={() => setSelectedCategory('全部')}
            className={`px-4 py-2 rounded-full text-[13px] font-medium whitespace-nowrap transition-all cursor-pointer ${
              selectedCategory === '全部'
                ? 'bg-[#102f32] text-white shadow-xs'
                : 'bg-white text-[#506161] hover:bg-[#dce5df]/60 border border-[#e0e3dc]'
            }`}
          >
            全部项目 ({projects.length})
          </button>
          {CATEGORIES.map((c) => (
            <button
              key={c.id}
              onClick={() => setSelectedCategory(c.name)}
              className={`px-4 py-2 rounded-full text-[13px] font-medium whitespace-nowrap transition-all cursor-pointer ${
                selectedCategory === c.name
                  ? 'bg-[#102f32] text-white shadow-xs'
                  : 'bg-white text-[#506161] hover:bg-[#dce5df]/60 border border-[#e0e3dc]'
              }`}
            >
              {c.name}
            </button>
          ))}
        </div>

        {/* Search & Filter */}
        <div className="relative flex items-center bg-white rounded-[10px] p-2 border border-[#e0e3dc] shadow-2xs">
          <Search className="w-4 h-4 text-[#718080] ml-2 mr-2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="搜索项目需求关键词、技术栈标签..."
            className="w-full bg-transparent text-[14px] text-[#102f32] placeholder-[#8c9c99] focus:outline-none"
          />
        </div>

        {/* Projects List */}
        <div className="space-y-4">
          {filteredProjects.map((p) => (
            <div
              key={p.id}
              className="bg-white rounded-[12px] border border-[#e0e3dc] hover:border-[#668c87] p-5 sm:p-6 shadow-2xs hover:shadow-md transition-all space-y-4"
            >
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                <div className="space-y-2 max-w-3xl">
                  <div className="flex items-center space-x-2">
                    <span className="text-[12px] font-medium px-2.5 py-0.5 rounded bg-[#dce5df]/60 text-[#163b3d]">
                      {p.category}
                    </span>
                    <span className="text-[12px] text-[#8c9c99]">发布于 {p.createdAt}</span>
                    {p.isFeatured && (
                      <span className="text-[11px] bg-[#b9513c] text-white px-2 py-0.5 rounded-[4px] font-medium">
                        推荐项目
                      </span>
                    )}
                  </div>

                  <h3 className="font-serif-sc text-[18px] sm:text-[20px] font-bold text-[#102f32] leading-snug">
                    {p.title}
                  </h3>

                  <p className="text-[13px] sm:text-[14px] text-[#506161] leading-relaxed line-clamp-2">
                    {p.description}
                  </p>
                </div>

                {/* Budget Column */}
                <div className="sm:text-right shrink-0">
                  <span className="text-[12px] text-[#718080]">项目预算</span>
                  <div className="text-[20px] sm:text-[22px] font-bold text-[#b9513c]">
                    ¥ {p.budgetMin.toLocaleString()} - {p.budgetMax.toLocaleString()}
                  </div>
                  <span className="text-[12px] text-[#8c9c99]">固定总包预算</span>
                </div>
              </div>

              {/* Skills Tags */}
              <div className="flex flex-wrap gap-1.5 pt-1">
                {p.skills.map((skill) => (
                  <span
                    key={skill}
                    className="text-[12px] bg-[#f5f2eb] text-[#29494a] px-2.5 py-1 rounded-[4px] border border-[#e8e5dc]"
                  >
                    {skill}
                  </span>
                ))}
              </div>

              {/* Footer row */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-3 border-t border-[#f0ede6] text-[13px]">
                <div className="flex items-center space-x-3 text-[#718080]">
                  <span className="font-medium text-[#29494a]">{p.clientName}</span>
                  <span>·</span>
                  <span className="flex items-center space-x-1">
                    <Users className="w-3.5 h-3.5 text-[#668c87]" />
                    <span>已有 {p.bidsCount} 人参与投标</span>
                  </span>
                  <span>·</span>
                  <span className="flex items-center space-x-1">
                    <Clock className="w-3.5 h-3.5 text-[#668c87]" />
                    <span>交付期至 {p.deadline}</span>
                  </span>
                </div>

                <button
                  onClick={() => {
                    setBiddingProjectId(p.id);
                    setBidAmount(p.budgetMin);
                  }}
                  className="px-4 py-1.5 bg-[#163b3d] hover:bg-[#102f32] text-white rounded-full text-[13px] font-medium transition-colors cursor-pointer self-start sm:self-auto"
                >
                  投递方案 / 竞标 →
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Bid Proposal Modal */}
      {biddingProjectId && selectedProj && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-200">
          <div
            className="relative w-full max-w-lg bg-[#fbfaf6] rounded-[16px] shadow-2xl border border-[#e0e3dc] p-6 sm:p-8 font-sans-sc animate-in zoom-in-95 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setBiddingProjectId(null)}
              className="absolute top-4 right-4 p-2 rounded-full bg-white/80 hover:bg-white text-[#718080] hover:text-[#102f32] shadow-2xs transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="border-b border-[#e0e3dc] pb-4 mb-4">
              <span className="text-[12px] text-[#668c87] font-semibold">项目投标</span>
              <h3 className="font-serif-sc text-xl font-bold text-[#102f32] mt-1 line-clamp-1">
                {selectedProj.title}
              </h3>
              <p className="text-[12px] text-[#718080] mt-0.5">
                雇主预算：¥ {selectedProj.budgetMin} - ¥ {selectedProj.budgetMax}
              </p>
            </div>

            {bidSubmitted ? (
              <div className="py-8 text-center space-y-2">
                <CheckCircle className="w-12 h-12 text-[#668c87] mx-auto" />
                <h4 className="font-serif-sc text-lg font-bold text-[#102f32]">
                  竞标方案已成功投递！
                </h4>
                <p className="text-[13px] text-[#718080]">
                  雇主将在接收提醒后审阅您的履历与报价。
                </p>
              </div>
            ) : (
              <form onSubmit={handleSendBid} className="space-y-4">
                <div>
                  <label className="block text-[13px] font-bold text-[#102f32] mb-1.5">
                    您的竞标报价 (¥ 人民币)
                  </label>
                  <input
                    type="number"
                    value={bidAmount}
                    onChange={(e) => setBidAmount(Number(e.target.value))}
                    className="w-full p-2.5 bg-white border border-[#e0e3dc] rounded-[8px] text-[14px] font-semibold text-[#b9513c] focus:outline-none focus:border-[#668c87]"
                    required
                  />
                </div>

                <div>
                  <label className="block text-[13px] font-bold text-[#102f32] mb-1.5">
                    方案概述与过往类似经验阐述
                  </label>
                  <textarea
                    rows={4}
                    value={bidProposal}
                    onChange={(e) => setBidProposal(e.target.value)}
                    placeholder="向雇主阐述您的技术方案、交付时间表及为何您是最合适人选..."
                    className="w-full p-3 bg-white border border-[#e0e3dc] rounded-[8px] text-[13px] focus:outline-none focus:border-[#668c87]"
                    required
                  />
                </div>

                <div className="flex items-center justify-end space-x-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setBiddingProjectId(null)}
                    className="px-4 py-2 text-[13px] text-[#718080] hover:text-[#102f32]"
                  >
                    取消
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-[#163b3d] hover:bg-[#102f32] text-white text-[13px] font-medium rounded-full cursor-pointer transition-colors shadow-sm"
                  >
                    确认提交竞标
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
