import React from 'react';
import {
  PenTool,
  Code,
  FileText,
  Video,
  Languages,
  TrendingUp,
  Box,
  HeartHandshake,
} from 'lucide-react';
import { CATEGORIES } from '../data/initialData';
import { Category } from '../types';

interface HotCategoriesProps {
  onSelectCategory: (categoryName: string) => void;
  selectedCategory?: string | null;
}

export const HotCategories: React.FC<HotCategoriesProps> = ({
  onSelectCategory,
  selectedCategory,
}) => {
  const getIcon = (iconName: string) => {
    const iconProps = { className: 'w-5 h-5 stroke-[1.8] text-[#102f32]' };
    switch (iconName) {
      case 'PenTool':
        return <PenTool {...iconProps} />;
      case 'Code':
        return <Code {...iconProps} />;
      case 'FileText':
        return <FileText {...iconProps} />;
      case 'Video':
        return <Video {...iconProps} />;
      case 'Languages':
        return <Languages {...iconProps} />;
      case 'TrendingUp':
        return <TrendingUp {...iconProps} />;
      case 'Box':
        return <Box {...iconProps} />;
      case 'HeartHandshake':
        return <HeartHandshake {...iconProps} />;
      default:
        return <PenTool {...iconProps} />;
    }
  };

  return (
    <section id="categories-section" className="w-full bg-[#f5f2eb] pt-6 pb-8 border-b border-[#e0e3dc]">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Title */}
        <h2 className="font-sans-sc text-[16px] sm:text-[17px] font-bold text-[#102f32] mb-5 tracking-tight">
          热门分类
        </h2>

        {/* 8 Categories Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2.5 sm:gap-3">
          {CATEGORIES.map((cat: Category) => {
            const isSelected = selectedCategory === cat.name;
            return (
              <button
                key={cat.id}
                id={`category-btn-${cat.id}`}
                onClick={() => onSelectCategory(cat.name)}
                className={`group flex flex-col items-center justify-center p-3.5 sm:p-4 rounded-[10px] bg-transparent hover:bg-white/70 transition-all duration-200 text-center cursor-pointer border ${
                  isSelected
                    ? 'bg-white border-[#668c87] shadow-xs'
                    : 'border-transparent hover:border-[#e0e3dc]'
                }`}
              >
                {/* Icon with subtle hover lift */}
                <div className="mb-2.5 p-1.5 transition-transform duration-200 group-hover:-translate-y-0.5">
                  {getIcon(cat.iconName)}
                </div>

                {/* Main Category Title */}
                <span className="font-sans-sc text-[14px] sm:text-[15px] font-semibold text-[#102f32] group-hover:text-[#163b3d]">
                  {cat.name}
                </span>

                {/* Subtext description */}
                <span className="mt-1 font-sans-sc text-[11px] sm:text-[12px] text-[#718080] line-clamp-1 group-hover:text-[#506161]">
                  {cat.subText}
                </span>

                {/* Subtle bottom indicator */}
                <span
                  className={`mt-2.5 h-[2px] w-0 group-hover:w-6 transition-all duration-200 rounded-full ${
                    isSelected ? 'w-8 bg-[#668c87]' : 'bg-[#668c87]/60'
                  }`}
                />
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
};
