import React, { useState } from 'react';
import { Search } from 'lucide-react';
import { ASSET_IMAGES } from '../data/initialData';

interface HeroProps {
  onSearchSubmit: (query: string) => void;
  onTagClick: (tag: string) => void;
}

export const Hero: React.FC<HeroProps> = ({ onSearchSubmit, onTagClick }) => {
  const [searchValue, setSearchValue] = useState('');

  const hotTags = ['UI设计', '前端开发', '文案写作', '翻译', '视频剪辑', '3D建模'];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchValue.trim()) {
      onSearchSubmit(searchValue.trim());
    }
  };

  return (
    <section id="hero-section" className="relative w-full overflow-hidden bg-[#f5f2eb]">
      {/* Background Container with Landscape Image */}
      <div className="relative max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 pt-8 pb-10 sm:py-12 lg:pt-14 lg:pb-16 min-h-[380px] sm:min-h-[420px] lg:min-h-[440px] flex items-center">
        {/* Landscape Image Layer */}
        <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden">
          <img
            src={ASSET_IMAGES.heroLandscape}
            alt="Song Dynasty Landscape Art"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-right lg:object-center opacity-85 select-none"
          />
          {/* Subtle soft gradients to blend seamlessly into warm paper background */}
          <div className="absolute inset-0 bg-gradient-to-r from-[#f5f2eb] via-[#f5f2eb]/60 to-transparent w-full md:w-[65%] pointer-events-none" />
          <div className="absolute inset-x-0 bottom-0 h-16 bg-gradient-to-t from-[#f5f2eb] to-transparent pointer-events-none" />
          <div className="absolute inset-x-0 top-0 h-8 bg-gradient-to-b from-[#f5f2eb] to-transparent pointer-events-none" />
        </div>

        {/* Right Calligraphy Poetry + Seal Stamp (matches visual reference) */}
        <div className="hidden xl:flex absolute right-16 top-12 z-10 flex-row-reverse items-start space-x-reverse space-x-3 pointer-events-none select-none">
          {/* Vertical Poem Column 1 */}
          <div className="flex flex-col items-center">
            <span className="font-serif-sc text-[18px] text-[#163b3d] font-semibold tracking-[0.3em] writing-vertical-rl drop-shadow-sm">
              才聚云端
            </span>
            {/* Vermilion Red Seal Stamp */}
            <div className="mt-3 w-5 h-5 bg-[#b9513c] text-white flex items-center justify-center rounded-[2px] shadow-sm">
              <span className="font-serif-sc text-[10px] font-bold leading-none transform scale-90">
                才云
              </span>
            </div>
          </div>
          {/* Vertical Poem Column 2 */}
          <div className="flex flex-col items-center pt-5">
            <span className="font-serif-sc text-[18px] text-[#29494a] font-medium tracking-[0.3em] writing-vertical-rl drop-shadow-sm">
              共创未来
            </span>
          </div>
        </div>

        {/* Hero Left Content */}
        <div className="relative z-10 max-w-2xl">
          {/* Main Editorial Headline */}
          <h1 className="font-serif-sc text-[36px] sm:text-[44px] lg:text-[52px] font-bold text-[#102f32] leading-[1.18] tracking-tight">
            让专业的人
            <br />
            做专业的事
          </h1>

          {/* Subtitle */}
          <p className="mt-4 sm:mt-5 text-[15px] sm:text-[17px] text-[#29494a] font-normal leading-relaxed font-sans-sc">
            汇聚全球华人自由职业者 <span className="mx-1 text-[#668c87]">·</span> 为你的项目找到最合适的伙伴
          </p>

          {/* Search Bar Form */}
          <form
            onSubmit={handleSubmit}
            className="mt-6 sm:mt-7 relative flex items-center bg-white/95 rounded-[12px] p-1.5 shadow-[0_2px_12px_rgba(16,47,50,0.06)] border border-[#e0e3dc] focus-within:border-[#668c87] focus-within:ring-2 focus-within:ring-[#668c87]/20 transition-all max-w-[560px]"
          >
            <div className="pl-3 pr-2 text-[#718080] flex items-center justify-center">
              <Search className="w-[18px] h-[18px] stroke-[2.2]" />
            </div>

            <input
              type="text"
              id="hero-search-input"
              value={searchValue}
              onChange={(e) => setSearchValue(e.target.value)}
              placeholder="搜索你需要的技能、人才或项目..."
              className="w-full bg-transparent py-2.5 text-[14px] sm:text-[15px] text-[#102f32] placeholder-[#8c9c99] focus:outline-none font-sans-sc"
            />

            <button
              type="submit"
              id="hero-search-submit-btn"
              className="bg-[#173a3b] hover:bg-[#102f32] text-white text-[14px] sm:text-[15px] font-medium px-6 py-2.5 rounded-[8px] transition-all duration-200 shadow-sm active:scale-[0.98] cursor-pointer whitespace-nowrap"
            >
              搜索
            </button>
          </form>

          {/* Popular Search Tags */}
          <div className="mt-4 sm:mt-5 flex flex-wrap items-center gap-2 sm:gap-2.5 text-[13px] font-sans-sc">
            <span className="text-[#718080] mr-0.5">热门搜索：</span>
            {hotTags.map((tag) => (
              <button
                key={tag}
                type="button"
                onClick={() => onTagClick(tag)}
                className="bg-white/80 hover:bg-white text-[#29494a] hover:text-[#102f32] px-3 py-1 rounded-full border border-[#e0e3dc] hover:border-[#668c87] transition-all duration-150 cursor-pointer shadow-2xs hover:shadow-xs"
              >
                {tag}
              </button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
