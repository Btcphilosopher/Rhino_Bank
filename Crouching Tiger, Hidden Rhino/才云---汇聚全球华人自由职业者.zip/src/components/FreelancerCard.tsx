import React from 'react';
import { Star } from 'lucide-react';
import { Freelancer } from '../types';

interface FreelancerCardProps {
  freelancer: Freelancer;
  onSelect: (freelancer: Freelancer) => void;
}

export const FreelancerCard: React.FC<FreelancerCardProps> = ({
  freelancer,
  onSelect,
}) => {
  return (
    <div
      id={`freelancer-card-${freelancer.id}`}
      onClick={() => onSelect(freelancer)}
      className="group bg-white rounded-[12px] border border-[#e0e3dc] hover:border-[#668c87] overflow-hidden shadow-2xs hover:shadow-md transition-all duration-300 flex flex-col justify-between cursor-pointer transform hover:-translate-y-1"
    >
      <div>
        {/* Top Portrait & Badge Container */}
        <div className="relative w-full h-[150px] overflow-hidden bg-[#f0ede6]">
          <img
            src={freelancer.avatar}
            alt={freelancer.name}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500 ease-out"
          />

          {/* Top-right "优质" Quality Badge */}
          {freelancer.isTopQuality && (
            <div className="absolute top-2.5 right-2.5 bg-[#173a3b]/85 backdrop-blur-xs text-white text-[11px] font-sans-sc font-medium px-2 py-0.5 rounded-[4px] shadow-xs">
              优质
            </div>
          )}
        </div>

        {/* Card Body */}
        <div className="p-3.5 sm:p-4 space-y-2">
          {/* Name & Title */}
          <div>
            <h4 className="font-sans-sc text-[15px] font-bold text-[#102f32] group-hover:text-[#163b3d] transition-colors leading-tight">
              {freelancer.name}
            </h4>
            <p className="text-[12px] text-[#718080] font-sans-sc mt-0.5">
              {freelancer.profession}
            </p>
          </div>

          {/* Rating & Completed Orders */}
          <div className="flex items-center space-x-2 text-[12px] font-sans-sc">
            <div className="flex items-center space-x-1 text-[#d97706]">
              <Star className="w-3.5 h-3.5 fill-[#d97706] stroke-none" />
              <span className="font-semibold text-[#102f32]">{freelancer.rating.toFixed(1)}</span>
            </div>
            <span className="text-[#8c9c99]">{freelancer.completedCount}单</span>
          </div>

          {/* Price */}
          <div className="text-[13px] font-sans-sc pt-0.5">
            <span className="text-[#b9513c] font-bold text-[14px]">¥ {freelancer.hourlyRate}</span>
            <span className="text-[#718080] text-[12px]">/小时</span>
          </div>
        </div>
      </div>

      {/* Compact Skill Tags */}
      <div className="px-3.5 sm:px-4 pb-3.5 pt-0 flex flex-wrap gap-1.5 border-t border-[#f0ede6]/60 mt-1">
        {freelancer.tags.map((tag) => (
          <span
            key={tag}
            className="text-[11px] bg-[#f5f2eb] text-[#506161] px-2 py-0.5 rounded-[4px] border border-[#e8e5dc] font-sans-sc"
          >
            {tag}
          </span>
        ))}
      </div>
    </div>
  );
};
