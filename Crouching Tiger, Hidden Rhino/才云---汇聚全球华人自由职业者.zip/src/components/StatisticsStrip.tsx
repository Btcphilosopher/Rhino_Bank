import React, { useEffect, useState, useRef } from 'react';
import { ASSET_IMAGES } from '../data/initialData';

export const StatisticsStrip: React.FC = () => {
  const [inView, setInView] = useState(false);
  const [counts, setCounts] = useState({ freelancers: 0, projects: 0, satisfaction: 0 });
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setInView(true);
        }
      },
      { threshold: 0.2 }
    );

    if (containerRef.current) {
      observer.observe(containerRef.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!inView) return;

    let start = 0;
    const duration = 1600;
    const startTime = performance.now();

    const animate = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      // Ease out cubic
      const ease = 1 - Math.pow(1 - progress, 3);

      setCounts({
        freelancers: Math.floor(ease * 100000),
        projects: Math.floor(ease * 50000),
        satisfaction: Math.floor(ease * 98),
      });

      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }, [inView]);

  return (
    <section className="w-full bg-[#f5f2eb] py-8 sm:py-10">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
        <div
          ref={containerRef}
          id="statistics-strip-container"
          className="relative overflow-hidden rounded-[14px] bg-[#fbfaf6] border border-[#e0e3dc] p-6 sm:p-8 shadow-2xs flex flex-col lg:flex-row items-center justify-between gap-6"
        >
          {/* Background Soft Mountain Image Layer */}
          <div className="absolute inset-y-0 left-0 w-full sm:w-[45%] pointer-events-none overflow-hidden z-0">
            <img
              src={ASSET_IMAGES.statsStripBg}
              alt="Misty Mountains Ink Art"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-left opacity-30 select-none"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[#fbfaf6]/70 to-[#fbfaf6]" />
          </div>

          {/* Left/Center 3 Key Metrics */}
          <div className="relative z-10 grid grid-cols-1 sm:grid-cols-3 gap-6 sm:gap-12 w-full lg:w-auto text-center sm:text-left">
            {/* Metric 1 */}
            <div className="space-y-1">
              <div className="font-sans-sc text-[28px] sm:text-[32px] font-extrabold text-[#102f32] tracking-tight">
                {counts.freelancers >= 100000 ? '100,000+' : `${counts.freelancers.toLocaleString()}+`}
              </div>
              <div className="font-sans-sc text-[13px] sm:text-[14px] text-[#718080]">
                注册自由职业者
              </div>
            </div>

            {/* Metric 2 */}
            <div className="space-y-1">
              <div className="font-sans-sc text-[28px] sm:text-[32px] font-extrabold text-[#102f32] tracking-tight">
                {counts.projects >= 50000 ? '50,000+' : `${counts.projects.toLocaleString()}+`}
              </div>
              <div className="font-sans-sc text-[13px] sm:text-[14px] text-[#718080]">
                已完成项目
              </div>
            </div>

            {/* Metric 3 */}
            <div className="space-y-1">
              <div className="font-sans-sc text-[28px] sm:text-[32px] font-extrabold text-[#102f32] tracking-tight">
                {counts.satisfaction}%
              </div>
              <div className="font-sans-sc text-[13px] sm:text-[14px] text-[#718080]">
                客户满意度
              </div>
            </div>
          </div>

          {/* Right Literary Closing Statement + Seal Stamp (exact match to visual reference) */}
          <div className="relative z-10 flex items-center space-x-3 text-right">
            <div className="space-y-1">
              <div className="font-serif-sc text-[16px] sm:text-[18px] text-[#163b3d] font-semibold tracking-wide">
                以专业连接价值
              </div>
              <div className="font-serif-sc text-[16px] sm:text-[18px] text-[#29494a] font-normal tracking-wide">
                让创意成就未来
              </div>
            </div>

            {/* Vermilion Red Seal Stamp */}
            <div className="w-6 h-6 bg-[#b9513c] text-white flex items-center justify-center rounded-[2px] shadow-xs select-none">
              <span className="font-serif-sc text-[11px] font-bold leading-none transform scale-90">
                才云
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
