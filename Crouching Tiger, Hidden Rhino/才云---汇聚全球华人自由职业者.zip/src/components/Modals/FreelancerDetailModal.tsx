import React, { useState } from 'react';
import {
  X,
  Star,
  MapPin,
  Clock,
  CheckCircle,
  Briefcase,
  Layers,
  MessageSquare,
  ShieldCheck,
  Send,
  Calendar,
} from 'lucide-react';
import { Freelancer } from '../../types';

interface FreelancerDetailModalProps {
  freelancer: Freelancer | null;
  onClose: () => void;
  onHire: (freelancer: Freelancer, serviceTitle?: string) => void;
}

export const FreelancerDetailModal: React.FC<FreelancerDetailModalProps> = ({
  freelancer,
  onClose,
  onHire,
}) => {
  const [activeTab, setActiveTab] = useState<'services' | 'portfolio' | 'reviews' | 'about'>('services');
  const [contactMessage, setContactMessage] = useState('');
  const [messageSent, setMessageSent] = useState(false);

  if (!freelancer) return null;

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactMessage.trim()) return;
    setMessageSent(true);
    setTimeout(() => {
      setMessageSent(false);
      setContactMessage('');
    }, 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-4xl max-h-[90vh] overflow-y-auto bg-[#fbfaf6] rounded-[16px] shadow-2xl border border-[#e0e3dc] flex flex-col font-sans-sc animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-white/80 hover:bg-white text-[#718080] hover:text-[#102f32] shadow-xs transition-colors cursor-pointer"
          aria-label="关闭"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Top Header / Profile Banner */}
        <div className="relative p-6 sm:p-8 bg-[#163b3d] text-white overflow-hidden rounded-t-[16px]">
          {/* Subtle decorative background */}
          <div className="absolute inset-0 bg-gradient-to-r from-[#163b3d] via-[#102f32] to-[#163b3d] opacity-95" />

          <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
            <div className="flex items-center space-x-5">
              {/* Avatar */}
              <div className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-full overflow-hidden border-2 border-[#dce5df]/60 shadow-md shrink-0">
                <img
                  src={freelancer.avatar}
                  alt={freelancer.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Name & Basic Info */}
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <h3 className="font-serif-sc text-2xl font-bold text-white">
                    {freelancer.name}
                  </h3>
                  {freelancer.isTopQuality && (
                    <span className="bg-[#668c87] text-white text-[11px] font-medium px-2 py-0.5 rounded-[4px]">
                      优质认证
                    </span>
                  )}
                </div>
                <p className="text-[#dce5df] text-[14px]">
                  {freelancer.profession} · {freelancer.category}
                </p>
                <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[12px] text-[#dce5df]/80 pt-1">
                  <span className="flex items-center space-x-1">
                    <MapPin className="w-3.5 h-3.5 text-[#668c87]" />
                    <span>{freelancer.location}</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <Briefcase className="w-3.5 h-3.5 text-[#668c87]" />
                    <span>{freelancer.experienceYears} 年从业经验</span>
                  </span>
                  <span className="flex items-center space-x-1 text-[#fbbf24]">
                    <Star className="w-3.5 h-3.5 fill-[#fbbf24]" />
                    <span className="font-bold text-white">{freelancer.rating.toFixed(1)}</span>
                    <span className="text-[#dce5df]/80">({freelancer.completedCount}单)</span>
                  </span>
                </div>
              </div>
            </div>

            {/* Quick Pricing & Hire CTA */}
            <div className="flex flex-col items-start sm:items-end space-y-2 shrink-0">
              <div className="text-left sm:text-right">
                <span className="text-[12px] text-[#dce5df]">标准参考费率</span>
                <div className="text-2xl font-bold text-[#fbfaf6]">
                  ¥ {freelancer.hourlyRate} <span className="text-[13px] font-normal text-[#dce5df]">/ 小时</span>
                </div>
              </div>
              <button
                onClick={() => onHire(freelancer)}
                className="bg-[#b9513c] hover:bg-[#a34431] text-white text-[14px] font-medium px-5 py-2 rounded-full transition-all shadow-md active:scale-95 cursor-pointer"
              >
                立即发起委托
              </button>
            </div>
          </div>
        </div>

        {/* Modal Navigation Tabs */}
        <div className="flex border-b border-[#e0e3dc] bg-white px-6 sm:px-8 space-x-6">
          <button
            onClick={() => setActiveTab('services')}
            className={`py-3.5 text-[14px] font-medium border-b-2 transition-colors cursor-pointer ${
              activeTab === 'services'
                ? 'border-[#102f32] text-[#102f32] font-semibold'
                : 'border-transparent text-[#718080] hover:text-[#102f32]'
            }`}
          >
            服务项目 ({freelancer.services.length})
          </button>
          <button
            onClick={() => setActiveTab('portfolio')}
            className={`py-3.5 text-[14px] font-medium border-b-2 transition-colors cursor-pointer ${
              activeTab === 'portfolio'
                ? 'border-[#102f32] text-[#102f32] font-semibold'
                : 'border-transparent text-[#718080] hover:text-[#102f32]'
            }`}
          >
            精选作品 ({freelancer.portfolio.length})
          </button>
          <button
            onClick={() => setActiveTab('about')}
            className={`py-3.5 text-[14px] font-medium border-b-2 transition-colors cursor-pointer ${
              activeTab === 'about'
                ? 'border-[#102f32] text-[#102f32] font-semibold'
                : 'border-transparent text-[#718080] hover:text-[#102f32]'
            }`}
          >
            个人简介 & 技能
          </button>
          <button
            onClick={() => setActiveTab('reviews')}
            className={`py-3.5 text-[14px] font-medium border-b-2 transition-colors cursor-pointer ${
              activeTab === 'reviews'
                ? 'border-[#102f32] text-[#102f32] font-semibold'
                : 'border-transparent text-[#718080] hover:text-[#102f32]'
            }`}
          >
            客户评价 ({freelancer.reviews.length})
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="p-6 sm:p-8 space-y-6">
          {/* Services Tab */}
          {activeTab === 'services' && (
            <div className="space-y-4">
              <h4 className="text-[15px] font-bold text-[#102f32]">提供的标准化服务</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {freelancer.services.map((svc, idx) => (
                  <div
                    key={idx}
                    className="p-5 rounded-[12px] bg-white border border-[#e0e3dc] hover:border-[#668c87] transition-all shadow-2xs space-y-3 flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-start justify-between">
                        <h5 className="font-bold text-[15px] text-[#102f32]">{svc.title}</h5>
                        <span className="text-[#b9513c] font-bold text-[16px]">
                          ¥ {svc.price}
                        </span>
                      </div>
                      <p className="text-[13px] text-[#506161] mt-2 leading-relaxed">
                        {svc.description}
                      </p>
                    </div>

                    <div className="flex items-center justify-between pt-3 border-t border-[#f0ede6] text-[12px]">
                      <span className="text-[#718080] flex items-center space-x-1">
                        <Clock className="w-3.5 h-3.5 text-[#668c87]" />
                        <span>交付周期：{svc.duration}</span>
                      </span>
                      <button
                        onClick={() => onHire(freelancer, svc.title)}
                        className="text-[#163b3d] hover:text-[#b9513c] font-medium hover:underline cursor-pointer"
                      >
                        选择此服务 →
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Portfolio Tab */}
          {activeTab === 'portfolio' && (
            <div className="space-y-4">
              <h4 className="text-[15px] font-bold text-[#102f32]">精选代表作品集</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {freelancer.portfolio.map((p, idx) => (
                  <div
                    key={idx}
                    className="group rounded-[10px] overflow-hidden border border-[#e0e3dc] bg-white shadow-2xs hover:shadow-md transition-all"
                  >
                    <div className="h-40 overflow-hidden bg-[#e8e5dc]">
                      <img
                        src={p.image}
                        alt={p.title}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <div className="p-3.5 space-y-1">
                      <span className="text-[11px] text-[#668c87] font-medium">{p.category}</span>
                      <h5 className="font-semibold text-[13px] text-[#102f32] line-clamp-2">
                        {p.title}
                      </h5>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* About Tab */}
          {activeTab === 'about' && (
            <div className="space-y-6">
              <div>
                <h4 className="text-[15px] font-bold text-[#102f32] mb-2">关于我</h4>
                <p className="text-[14px] text-[#29494a] leading-relaxed bg-white p-4 rounded-[10px] border border-[#e0e3dc]">
                  {freelancer.bio}
                </p>
              </div>

              <div>
                <h4 className="text-[15px] font-bold text-[#102f32] mb-2.5">专业技能库</h4>
                <div className="flex flex-wrap gap-2">
                  {freelancer.skills.map((s) => (
                    <span
                      key={s}
                      className="px-3 py-1 bg-white border border-[#dce5df] text-[#29494a] text-[13px] rounded-full shadow-2xs font-medium"
                    >
                      {s}
                    </span>
                  ))}
                </div>
              </div>

              {/* Quick Contact Form */}
              <div className="bg-white p-5 rounded-[12px] border border-[#e0e3dc] space-y-3">
                <h4 className="text-[15px] font-bold text-[#102f32] flex items-center space-x-2">
                  <MessageSquare className="w-4 h-4 text-[#668c87]" />
                  <span>向 {freelancer.name} 发送即时咨询</span>
                </h4>
                {messageSent ? (
                  <div className="p-3 bg-[#dce5df]/60 text-[#163b3d] text-[13px] rounded-[8px] flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-[#668c87]" />
                    <span>咨询已发送！自由职业者将通过平台私信及时与您取得联系。</span>
                  </div>
                ) : (
                  <form onSubmit={handleSendMessage} className="space-y-3">
                    <textarea
                      rows={3}
                      value={contactMessage}
                      onChange={(e) => setContactMessage(e.target.value)}
                      placeholder={`简要描述你的项目需求与工期设想...`}
                      className="w-full p-3 text-[13px] border border-[#e0e3dc] rounded-[8px] focus:outline-none focus:border-[#668c87]"
                      required
                    />
                    <button
                      type="submit"
                      className="inline-flex items-center space-x-1.5 bg-[#163b3d] hover:bg-[#102f32] text-white text-[13px] font-medium px-4 py-2 rounded-full cursor-pointer transition-colors"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>发送咨询消息</span>
                    </button>
                  </form>
                )}
              </div>
            </div>
          )}

          {/* Reviews Tab */}
          {activeTab === 'reviews' && (
            <div className="space-y-4">
              <h4 className="text-[15px] font-bold text-[#102f32]">真实客户成交评价</h4>
              <div className="space-y-3">
                {freelancer.reviews.map((r, idx) => (
                  <div
                    key={idx}
                    className="p-4 rounded-[10px] bg-white border border-[#e0e3dc] space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2.5">
                        <img
                          src={r.avatar}
                          alt={r.author}
                          referrerPolicy="no-referrer"
                          className="w-7 h-7 rounded-full object-cover"
                        />
                        <span className="font-semibold text-[13px] text-[#102f32]">
                          {r.author}
                        </span>
                      </div>
                      <div className="flex items-center space-x-1 text-[#fbbf24] text-[12px]">
                        <Star className="w-3.5 h-3.5 fill-[#fbbf24]" />
                        <span className="font-bold text-[#102f32]">{r.rating.toFixed(1)}</span>
                      </div>
                    </div>
                    <p className="text-[13px] text-[#506161] leading-relaxed">{r.comment}</p>
                    <div className="flex items-center justify-between text-[11px] text-[#8c9c99] pt-1">
                      <span>委托项目：{r.project}</span>
                      <span>{r.date}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
