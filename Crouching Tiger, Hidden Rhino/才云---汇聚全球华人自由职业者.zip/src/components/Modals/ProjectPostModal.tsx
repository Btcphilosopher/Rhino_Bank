import React, { useState } from 'react';
import { X, CheckCircle, AlertCircle, Plus, Tag } from 'lucide-react';
import { CATEGORIES } from '../../data/initialData';
import { Project } from '../../types';

interface ProjectPostModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmitProject: (newProject: Omit<Project, 'id' | 'createdAt' | 'bidsCount' | 'status'>) => void;
}

export const ProjectPostModal: React.FC<ProjectPostModalProps> = ({
  isOpen,
  onClose,
  onSubmitProject,
}) => {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('设计创意');
  const [subCategory, setSubCategory] = useState('UI/UX设计');
  const [budgetMin, setBudgetMin] = useState<number>(3000);
  const [budgetMax, setBudgetMax] = useState<number>(8000);
  const [deadline, setDeadline] = useState('2026-05-15');
  const [description, setDescription] = useState('');
  const [skillInput, setSkillInput] = useState('');
  const [skills, setSkills] = useState<string[]>(['Figma', 'UI设计', '交互原型']);
  const [clientName, setClientName] = useState('创意工作室');
  const [clientCompany, setClientCompany] = useState('');
  const [contactPreference, setContactPreference] = useState('wechat');
  const [contactInfo, setContactInfo] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  if (!isOpen) return null;

  const handleAddSkill = () => {
    if (skillInput.trim() && !skills.includes(skillInput.trim())) {
      setSkills([...skills, skillInput.trim()]);
      setSkillInput('');
    }
  };

  const handleRemoveSkill = (sToRemove: string) => {
    setSkills(skills.filter((s) => s !== sToRemove));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim()) {
      setErrorMessage('请完整填写项目名称与详细需求描述');
      return;
    }
    if (budgetMin <= 0 || budgetMax < budgetMin) {
      setErrorMessage('请输入合理有效的预算范围');
      return;
    }

    onSubmitProject({
      title,
      category,
      subCategory,
      budgetMin,
      budgetMax,
      budgetType: 'fixed',
      deadline,
      skills,
      description,
      clientName: clientName || '匿名企业雇主',
      clientAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80',
      clientCompany: clientCompany || undefined,
    });

    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
      onClose();
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-[#fbfaf6] rounded-[16px] shadow-2xl border border-[#e0e3dc] p-6 sm:p-8 font-sans-sc animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-white/80 hover:bg-white text-[#718080] hover:text-[#102f32] shadow-2xs transition-colors cursor-pointer"
          aria-label="关闭"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="border-b border-[#e0e3dc] pb-4 mb-6">
          <div className="flex items-center space-x-2">
            <span className="w-2 h-2 rounded-full bg-[#668c87]" />
            <h3 className="font-serif-sc text-2xl font-bold text-[#102f32]">
              发布你的项目需求
            </h3>
          </div>
          <p className="text-[13px] text-[#718080] mt-1 font-sans-sc">
            详细清晰的描述有助于吸引顶级自由职业者主动竞标与方案提案
          </p>
        </div>

        {isSuccess ? (
          <div className="py-12 text-center space-y-3">
            <div className="w-16 h-16 bg-[#dce5df] text-[#163b3d] rounded-full flex items-center justify-center mx-auto">
              <CheckCircle className="w-9 h-9 text-[#163b3d]" />
            </div>
            <h4 className="font-serif-sc text-xl font-bold text-[#102f32]">
              项目发布成功！
            </h4>
            <p className="text-[14px] text-[#506161]">
              已将您的需求同步至“找项目”市场，平台专业顾问将在15分钟内完成合规审核。
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-5">
            {errorMessage && (
              <div className="p-3 bg-[#b9513c]/10 text-[#b9513c] rounded-[8px] text-[13px] flex items-center space-x-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Project Title */}
            <div>
              <label className="block text-[13px] font-bold text-[#102f32] mb-1.5">
                项目标题 <span className="text-[#b9513c]">*</span>
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="例如：高端东方文创品牌全套 UI/UX 界面设计与交互原型"
                className="w-full p-2.5 bg-white border border-[#e0e3dc] rounded-[8px] text-[14px] focus:outline-none focus:border-[#668c87]"
                required
              />
            </div>

            {/* Category & SubCategory */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[13px] font-bold text-[#102f32] mb-1.5">
                  专业分类 <span className="text-[#b9513c]">*</span>
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full p-2.5 bg-white border border-[#e0e3dc] rounded-[8px] text-[14px] focus:outline-none focus:border-[#668c87]"
                >
                  {CATEGORIES.map((c) => (
                    <option key={c.id} value={c.name}>
                      {c.name} ({c.subText})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[13px] font-bold text-[#102f32] mb-1.5">
                  期望交付日期 <span className="text-[#b9513c]">*</span>
                </label>
                <input
                  type="date"
                  value={deadline}
                  onChange={(e) => setDeadline(e.target.value)}
                  className="w-full p-2.5 bg-white border border-[#e0e3dc] rounded-[8px] text-[14px] focus:outline-none focus:border-[#668c87]"
                />
              </div>
            </div>

            {/* Budget Range */}
            <div>
              <label className="block text-[13px] font-bold text-[#102f32] mb-1.5">
                项目预算范围 (¥ 人民币) <span className="text-[#b9513c]">*</span>
              </label>
              <div className="flex items-center space-x-3">
                <div className="relative flex-1">
                  <span className="absolute left-3 top-2.5 text-[#718080] text-[14px]">¥</span>
                  <input
                    type="number"
                    min="500"
                    step="500"
                    value={budgetMin}
                    onChange={(e) => setBudgetMin(Number(e.target.value))}
                    className="w-full pl-7 pr-3 py-2 bg-white border border-[#e0e3dc] rounded-[8px] text-[14px] focus:outline-none focus:border-[#668c87]"
                    placeholder="最低预算"
                  />
                </div>
                <span className="text-[#718080]">—</span>
                <div className="relative flex-1">
                  <span className="absolute left-3 top-2.5 text-[#718080] text-[14px]">¥</span>
                  <input
                    type="number"
                    min="500"
                    step="500"
                    value={budgetMax}
                    onChange={(e) => setBudgetMax(Number(e.target.value))}
                    className="w-full pl-7 pr-3 py-2 bg-white border border-[#e0e3dc] rounded-[8px] text-[14px] focus:outline-none focus:border-[#668c87]"
                    placeholder="最高预算"
                  />
                </div>
              </div>
            </div>

            {/* Project Description */}
            <div>
              <label className="block text-[13px] font-bold text-[#102f32] mb-1.5">
                需求详细说明 <span className="text-[#b9513c]">*</span>
              </label>
              <textarea
                rows={4}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="请详述您的项目背景、具体交付物要求、技术选型或视觉风格期望..."
                className="w-full p-3 bg-white border border-[#e0e3dc] rounded-[8px] text-[14px] focus:outline-none focus:border-[#668c87] leading-relaxed"
                required
              />
            </div>

            {/* Skill Tags */}
            <div>
              <label className="block text-[13px] font-bold text-[#102f32] mb-1.5">
                所需专业技能标签
              </label>
              <div className="flex items-center space-x-2 mb-2">
                <input
                  type="text"
                  value={skillInput}
                  onChange={(e) => setSkillInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddSkill())}
                  placeholder="输入技能按回车或点击添加，如 React, Figma"
                  className="flex-1 p-2 bg-white border border-[#e0e3dc] rounded-[8px] text-[13px] focus:outline-none focus:border-[#668c87]"
                />
                <button
                  type="button"
                  onClick={handleAddSkill}
                  className="px-3 py-2 bg-[#dce5df] hover:bg-[#668c87] hover:text-white text-[#163b3d] text-[13px] font-medium rounded-[8px] transition-colors cursor-pointer flex items-center space-x-1"
                >
                  <Plus className="w-4 h-4" />
                  <span>添加</span>
                </button>
              </div>

              <div className="flex flex-wrap gap-1.5">
                {skills.map((s) => (
                  <span
                    key={s}
                    className="inline-flex items-center space-x-1 px-2.5 py-1 bg-white border border-[#dce5df] text-[#102f32] text-[12px] rounded-full"
                  >
                    <span>{s}</span>
                    <button
                      type="button"
                      onClick={() => handleRemoveSkill(s)}
                      className="hover:text-[#b9513c] ml-1 cursor-pointer"
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
            </div>

            {/* Client Info */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-[#f0ede6]">
              <div>
                <label className="block text-[13px] font-bold text-[#102f32] mb-1.5">
                  发布者称呼 / 公司
                </label>
                <input
                  type="text"
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  placeholder="例如：墨韵东方艺术工作室"
                  className="w-full p-2 bg-white border border-[#e0e3dc] rounded-[8px] text-[13px] focus:outline-none focus:border-[#668c87]"
                />
              </div>

              <div>
                <label className="block text-[13px] font-bold text-[#102f32] mb-1.5">
                  联系方式 (微信 / 手机)
                </label>
                <input
                  type="text"
                  value={contactInfo}
                  onChange={(e) => setContactInfo(e.target.value)}
                  placeholder="对接人员联系方式 (仅平台中标者可见)"
                  className="w-full p-2 bg-white border border-[#e0e3dc] rounded-[8px] text-[13px] focus:outline-none focus:border-[#668c87]"
                />
              </div>
            </div>

            {/* Notice */}
            <div className="p-3 bg-[#e8e5dc]/40 rounded-[8px] text-[12px] text-[#718080] leading-normal">
              💡 演示环境说明：提交后将实时发布至演示项目列表中，不产生真实支付与法律责任。平台提供免费资金托管与电子合同存证。
            </div>

            {/* Submit Button */}
            <div className="flex items-center justify-end space-x-3 pt-3">
              <button
                type="button"
                onClick={onClose}
                className="px-5 py-2.5 text-[14px] text-[#718080] hover:text-[#102f32] font-medium transition-colors cursor-pointer"
              >
                取消
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 bg-[#163b3d] hover:bg-[#102f32] text-white text-[14px] font-medium rounded-full shadow-sm hover:shadow active:scale-98 transition-all cursor-pointer"
              >
                立即发布项目
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
