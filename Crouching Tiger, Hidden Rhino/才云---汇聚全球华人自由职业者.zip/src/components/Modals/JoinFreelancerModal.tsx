import React, { useState } from 'react';
import { X, CheckCircle, Sparkles, Star, Compass, Award } from 'lucide-react';
import { CATEGORIES } from '../../data/initialData';

interface JoinFreelancerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const JoinFreelancerModal: React.FC<JoinFreelancerModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [name, setName] = useState('');
  const [profession, setProfession] = useState('');
  const [category, setCategory] = useState('设计创意');
  const [hourlyRate, setHourlyRate] = useState(500);
  const [bio, setBio] = useState('');
  const [portfolioLink, setPortfolioLink] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
      onClose();
    }, 2200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-xl max-h-[90vh] overflow-y-auto bg-[#fbfaf6] rounded-[16px] shadow-2xl border border-[#e0e3dc] p-6 sm:p-8 font-sans-sc animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-white/80 hover:bg-white text-[#718080] hover:text-[#102f32] shadow-2xs transition-colors cursor-pointer"
          aria-label="关闭"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="border-b border-[#e0e3dc] pb-4 mb-6">
          <div className="inline-block px-2.5 py-0.5 rounded bg-[#163b3d]/10 text-[#163b3d] text-[12px] font-medium mb-1.5">
            自由职业者入驻通道
          </div>
          <h3 className="font-serif-sc text-2xl font-bold text-[#102f32]">
            加入才云 · 开启自由职业之旅
          </h3>
          <p className="text-[13px] text-[#718080] mt-1">
            自主定价、灵活接单、获得高净值企业雇主直接委托与长期合约
          </p>
        </div>

        {isSuccess ? (
          <div className="py-12 text-center space-y-3">
            <CheckCircle className="w-14 h-14 text-[#668c87] mx-auto" />
            <h4 className="font-serif-sc text-xl font-bold text-[#102f32]">
              入驻申请已提交！
            </h4>
            <p className="text-[14px] text-[#506161]">
              才云专家评审团将在 24 小时内完成作品集与资质核验，结果将短信发送给您。
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[13px] font-bold text-[#102f32] mb-1.5">
                  专业称呼 / 工作室名 <span className="text-[#b9513c]">*</span>
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="例如：木石空间设计"
                  className="w-full p-2.5 bg-white border border-[#e0e3dc] rounded-[8px] text-[13px] focus:outline-none focus:border-[#668c87]"
                  required
                />
              </div>

              <div>
                <label className="block text-[13px] font-bold text-[#102f32] mb-1.5">
                  专业领域分类 <span className="text-[#b9513c]">*</span>
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full p-2.5 bg-white border border-[#e0e3dc] rounded-[8px] text-[13px] focus:outline-none focus:border-[#668c87]"
                >
                  {CATEGORIES.map((c) => (
                    <option key={c.id} value={c.name}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[13px] font-bold text-[#102f32] mb-1.5">
                  个人头衔 / 职业角色 <span className="text-[#b9513c]">*</span>
                </label>
                <input
                  type="text"
                  value={profession}
                  onChange={(e) => setProfession(e.target.value)}
                  placeholder="例如：资深 UI/UX 设计师 / 架构师"
                  className="w-full p-2.5 bg-white border border-[#e0e3dc] rounded-[8px] text-[13px] focus:outline-none focus:border-[#668c87]"
                  required
                />
              </div>

              <div>
                <label className="block text-[13px] font-bold text-[#102f32] mb-1.5">
                  期望参考时薪 (¥ / 小时)
                </label>
                <input
                  type="number"
                  value={hourlyRate}
                  onChange={(e) => setHourlyRate(Number(e.target.value))}
                  className="w-full p-2.5 bg-white border border-[#e0e3dc] rounded-[8px] text-[13px] focus:outline-none focus:border-[#668c87]"
                />
              </div>
            </div>

            <div>
              <label className="block text-[13px] font-bold text-[#102f32] mb-1.5">
                作品集链接 / GitHub / 线上个人主页
              </label>
              <input
                type="text"
                value={portfolioLink}
                onChange={(e) => setPortfolioLink(e.target.value)}
                placeholder="https://..."
                className="w-full p-2.5 bg-white border border-[#e0e3dc] rounded-[8px] text-[13px] focus:outline-none focus:border-[#668c87]"
              />
            </div>

            <div>
              <label className="block text-[13px] font-bold text-[#102f32] mb-1.5">
                个人履历与代表作简介 <span className="text-[#b9513c]">*</span>
              </label>
              <textarea
                rows={3}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                placeholder="请简述您的从业经历、过往服务客户及核心专业优势..."
                className="w-full p-3 bg-white border border-[#e0e3dc] rounded-[8px] text-[13px] focus:outline-none focus:border-[#668c87]"
                required
              />
            </div>

            <div className="grid grid-cols-3 gap-3 p-3 bg-white rounded-[10px] border border-[#e0e3dc] text-center text-[12px] text-[#506161]">
              <div>
                <Award className="w-4 h-4 text-[#668c87] mx-auto mb-1" />
                <span>0 入驻费用</span>
              </div>
              <div>
                <Star className="w-4 h-4 text-[#668c87] mx-auto mb-1" />
                <span>专属大客户推荐</span>
              </div>
              <div>
                <Compass className="w-4 h-4 text-[#668c87] mx-auto mb-1" />
                <span>全天候合约保障</span>
              </div>
            </div>

            <div className="flex items-center justify-end space-x-3 pt-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-[14px] text-[#718080] hover:text-[#102f32] font-medium"
              >
                取消
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 bg-[#163b3d] hover:bg-[#102f32] text-white text-[14px] font-medium rounded-full shadow-sm hover:shadow transition-all cursor-pointer"
              >
                提交入驻申请
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
