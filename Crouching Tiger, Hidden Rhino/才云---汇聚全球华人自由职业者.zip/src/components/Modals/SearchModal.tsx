import React, { useState, useMemo } from 'react';
import { Search, X, User, Briefcase, Box, ArrowRight } from 'lucide-react';
import { Freelancer, Project, ServicePackage } from '../../types';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  freelancers: Freelancer[];
  projects: Project[];
  services: ServicePackage[];
  onSelectFreelancer: (f: Freelancer) => void;
  onSelectProject: (p: Project) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  freelancers,
  projects,
  services,
  onSelectFreelancer,
  onSelectProject,
}) => {
  const [query, setQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'talents' | 'projects' | 'services'>('all');

  const hotTerms = ['UI设计', 'React', '全栈开发', '文案策划', '3D建模', '同声传译', '小程序'];

  const results = useMemo(() => {
    if (!query.trim()) return { talents: [], projects: [], services: [] };
    const q = query.toLowerCase();

    const matchedTalents = freelancers.filter(
      (f) =>
        f.name.toLowerCase().includes(q) ||
        f.profession.toLowerCase().includes(q) ||
        f.category.toLowerCase().includes(q) ||
        f.tags.some((t) => t.toLowerCase().includes(q)) ||
        f.skills.some((s) => s.toLowerCase().includes(q))
    );

    const matchedProjects = projects.filter(
      (p) =>
        p.title.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.skills.some((s) => s.toLowerCase().includes(q))
    );

    const matchedServices = services.filter(
      (s) =>
        s.title.toLowerCase().includes(q) ||
        s.category.toLowerCase().includes(q) ||
        s.freelancerName.toLowerCase().includes(q)
    );

    return {
      talents: matchedTalents,
      projects: matchedProjects,
      services: matchedServices,
    };
  }, [query, freelancers, projects, services]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-20 p-3 sm:p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-2xl bg-[#fbfaf6] rounded-[16px] shadow-2xl border border-[#e0e3dc] p-5 sm:p-6 font-sans-sc animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-white/80 hover:bg-white text-[#718080] hover:text-[#102f32] shadow-2xs transition-colors cursor-pointer"
          aria-label="关闭"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Search Bar Input */}
        <div className="relative flex items-center bg-white rounded-[10px] p-2 border border-[#e0e3dc] focus-within:border-[#668c87] focus-within:ring-2 focus-within:ring-[#668c87]/20 shadow-xs mb-4">
          <Search className="w-5 h-5 text-[#718080] ml-2 mr-2" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="搜索人才名称、专业技能、项目需求或服务..."
            className="w-full bg-transparent text-[15px] text-[#102f32] placeholder-[#8c9c99] focus:outline-none"
            autoFocus
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 text-[#718080] hover:text-[#102f32] mr-1 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Hot Terms if no query */}
        {!query.trim() ? (
          <div className="space-y-4 py-3">
            <div className="text-[13px] font-medium text-[#718080]">热门搜索关键词：</div>
            <div className="flex flex-wrap gap-2">
              {hotTerms.map((term) => (
                <button
                  key={term}
                  onClick={() => setQuery(term)}
                  className="px-3 py-1.5 bg-white border border-[#e0e3dc] hover:border-[#668c87] text-[13px] text-[#29494a] rounded-full transition-colors cursor-pointer"
                >
                  {term}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-1">
            {/* Filter Tabs */}
            <div className="flex space-x-2 border-b border-[#e0e3dc] pb-2 text-[13px]">
              <button
                onClick={() => setFilterType('all')}
                className={`px-3 py-1 rounded-full cursor-pointer ${
                  filterType === 'all'
                    ? 'bg-[#163b3d] text-white font-medium'
                    : 'text-[#718080] hover:text-[#102f32]'
                }`}
              >
                全部 ({results.talents.length + results.projects.length + results.services.length})
              </button>
              <button
                onClick={() => setFilterType('talents')}
                className={`px-3 py-1 rounded-full cursor-pointer ${
                  filterType === 'talents'
                    ? 'bg-[#163b3d] text-white font-medium'
                    : 'text-[#718080] hover:text-[#102f32]'
                }`}
              >
                人才 ({results.talents.length})
              </button>
              <button
                onClick={() => setFilterType('projects')}
                className={`px-3 py-1 rounded-full cursor-pointer ${
                  filterType === 'projects'
                    ? 'bg-[#163b3d] text-white font-medium'
                    : 'text-[#718080] hover:text-[#102f32]'
                }`}
              >
                项目 ({results.projects.length})
              </button>
              <button
                onClick={() => setFilterType('services')}
                className={`px-3 py-1 rounded-full cursor-pointer ${
                  filterType === 'services'
                    ? 'bg-[#163b3d] text-white font-medium'
                    : 'text-[#718080] hover:text-[#102f32]'
                }`}
              >
                服务 ({results.services.length})
              </button>
            </div>

            {/* Results List */}
            {results.talents.length === 0 &&
            results.projects.length === 0 &&
            results.services.length === 0 ? (
              <div className="py-12 text-center text-[#718080] text-[14px]">
                未搜索到匹配“{query}”的内容，请尝试其他关键词
              </div>
            ) : (
              <div className="space-y-4">
                {/* Talents */}
                {(filterType === 'all' || filterType === 'talents') &&
                  results.talents.length > 0 && (
                    <div>
                      <div className="text-[12px] font-bold text-[#8c9c99] uppercase tracking-wider mb-2">
                        匹配人才
                      </div>
                      <div className="space-y-2">
                        {results.talents.map((f) => (
                          <div
                            key={f.id}
                            onClick={() => {
                              onSelectFreelancer(f);
                              onClose();
                            }}
                            className="flex items-center justify-between p-3 rounded-[10px] bg-white border border-[#e0e3dc] hover:border-[#668c87] cursor-pointer transition-all shadow-2xs group"
                          >
                            <div className="flex items-center space-x-3">
                              <img
                                src={f.avatar}
                                alt={f.name}
                                referrerPolicy="no-referrer"
                                className="w-10 h-10 rounded-full object-cover"
                              />
                              <div>
                                <div className="font-bold text-[14px] text-[#102f32] group-hover:text-[#163b3d]">
                                  {f.name} · <span className="font-normal text-[13px] text-[#718080]">{f.profession}</span>
                                </div>
                                <div className="text-[12px] text-[#8c9c99]">
                                  ¥ {f.hourlyRate}/小时 · ⭐ {f.rating.toFixed(1)} · {f.completedCount}单
                                </div>
                              </div>
                            </div>
                            <ArrowRight className="w-4 h-4 text-[#8c9c99] group-hover:text-[#102f32] group-hover:translate-x-0.5 transition-all" />
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                {/* Projects */}
                {(filterType === 'all' || filterType === 'projects') &&
                  results.projects.length > 0 && (
                    <div>
                      <div className="text-[12px] font-bold text-[#8c9c99] uppercase tracking-wider mb-2">
                        匹配项目需求
                      </div>
                      <div className="space-y-2">
                        {results.projects.map((p) => (
                          <div
                            key={p.id}
                            onClick={() => {
                              onSelectProject(p);
                              onClose();
                            }}
                            className="p-3 rounded-[10px] bg-white border border-[#e0e3dc] hover:border-[#668c87] cursor-pointer transition-all shadow-2xs group space-y-1"
                          >
                            <div className="flex items-center justify-between">
                              <span className="font-bold text-[14px] text-[#102f32] group-hover:text-[#163b3d] line-clamp-1">
                                {p.title}
                              </span>
                              <span className="text-[#b9513c] font-bold text-[13px] shrink-0 ml-2">
                                ¥{p.budgetMin} - ¥{p.budgetMax}
                              </span>
                            </div>
                            <p className="text-[12px] text-[#718080] line-clamp-1">{p.description}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
