import React from 'react';
import { X, UserCheck, ShieldCheck, CheckCircle2, Headphones, FileText, Lock, Award } from 'lucide-react';

interface AssuranceDetailModalProps {
  selectedItem: string | null;
  onClose: () => void;
}

export const AssuranceDetailModal: React.FC<AssuranceDetailModalProps> = ({
  selectedItem,
  onClose,
}) => {
  if (!selectedItem) return null;

  const items = [
    {
      title: '实名认证',
      icon: <UserCheck className="w-6 h-6 text-[#163b3d]" />,
      summary: '双重实名与专业资质严格核验，杜绝虚假与中介转包',
      details: [
        '所有自由职业者均需提供公安实名认证与银行卡四要素核验',
        '专业技能通过代表作品审查与平台专家委员会盲审评定',
        '企业雇主通过国家企业信用信息公示系统进行工商资质备案',
      ],
    },
    {
      title: '资金托管',
      icon: <ShieldCheck className="w-6 h-6 text-[#163b3d]" />,
      summary: '项目款项由银行监管专用账户托管，阶段验收后分批放款',
      details: [
        '签约后客户将阶段费用充值至独立资金托管账户',
        '自由职业者按约交付阶段成果，经客户确认无误后系统自动划转',
        '若产生需求变更或中止，未执行阶段款项支持极速原路退回',
      ],
    },
    {
      title: '项目保障',
      icon: <CheckCircle2 className="w-6 h-6 text-[#163b3d]" />,
      summary: '签署具有法律效力的电子合同，明确交付物标准与知识产权归属',
      details: [
        '内置标准电子合同模板，覆盖保密协议（NDA）与著作权转让条款',
        '全流程交付物与沟通记录区块链存证，保障双方合法权益',
        '延期交付与质量违约提供阶梯式补偿保障金机制',
      ],
    },
    {
      title: '售后支持',
      icon: <Headphones className="w-6 h-6 text-[#163b3d]" />,
      summary: '7×24小时专属项目管家与专业技术仲裁委员会保驾护航',
      details: [
        '每个商业委托均配备专属项目协调员，协助沟通与进度跟进',
        '若发生交付争议，由行业资深专家组成独立仲裁小组进行客观裁决',
        '交付完成后提供至少 30-90 天系统维保与质保期售后响应',
      ],
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-2xl bg-[#fbfaf6] rounded-[16px] shadow-2xl border border-[#e0e3dc] p-6 sm:p-8 font-sans-sc animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-white/80 hover:bg-white text-[#718080] hover:text-[#102f32] shadow-2xs transition-colors cursor-pointer"
          aria-label="关闭"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="border-b border-[#e0e3dc] pb-4 mb-6">
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#668c87]" />
            <h3 className="font-serif-sc text-2xl font-bold text-[#102f32]">
              才云 · 四重全方位平台保障体系
            </h3>
          </div>
          <p className="text-[13px] text-[#718080] mt-1">
            让合作透明安全，让每一次专业托付都从容安心
          </p>
        </div>

        <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-1">
          {items.map((item) => {
            const isHighlight = item.title === selectedItem;
            return (
              <div
                key={item.title}
                className={`p-4 rounded-[12px] border transition-all ${
                  isHighlight
                    ? 'bg-white border-[#668c87] ring-2 ring-[#668c87]/15 shadow-xs'
                    : 'bg-white/60 border-[#e0e3dc]'
                }`}
              >
                <div className="flex items-center space-x-3 mb-2">
                  <div className="p-2 rounded-lg bg-[#dce5df]/50">{item.icon}</div>
                  <div>
                    <h4 className="font-bold text-[15px] text-[#102f32] flex items-center space-x-2">
                      <span>{item.title}</span>
                      {isHighlight && (
                        <span className="text-[11px] bg-[#668c87] text-white px-2 py-0.2 rounded font-normal">
                          当前选择
                        </span>
                      )}
                    </h4>
                    <p className="text-[12px] text-[#718080]">{item.summary}</p>
                  </div>
                </div>

                <ul className="mt-3 pl-4 space-y-1.5 text-[13px] text-[#506161] list-disc border-t border-[#f0ede6] pt-2.5">
                  {item.details.map((d, idx) => (
                    <li key={idx} className="leading-relaxed">
                      {d}
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>

        <div className="pt-5 border-t border-[#e0e3dc] flex items-center justify-between text-[12px] text-[#8c9c99]">
          <span>💡 演示环境说明：所有保障流程与电子签约机制为产品模型演示。</span>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-[#163b3d] text-white rounded-full font-medium cursor-pointer hover:bg-[#102f32] transition-colors"
          >
            我已了解
          </button>
        </div>
      </div>
    </div>
  );
};
