import React, { useState } from 'react';
import { X, CheckCircle, ShieldCheck, User, Briefcase } from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  initialMode: 'login' | 'register';
  onClose: () => void;
  onSuccess: (userName: string, role: 'client' | 'freelancer') => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  initialMode,
  onClose,
  onSuccess,
}) => {
  const [mode, setMode] = useState<'login' | 'register'>(initialMode);
  const [role, setRole] = useState<'client' | 'freelancer'>('client');
  const [account, setAccount] = useState('demo@caiyun.art');
  const [password, setPassword] = useState('******');
  const [name, setName] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
      onSuccess(name || (role === 'client' ? '才云特邀雇主' : '认证自由职业者'), role);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-md bg-[#fbfaf6] rounded-[16px] shadow-2xl border border-[#e0e3dc] p-6 sm:p-8 font-sans-sc animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-white/80 hover:bg-white text-[#718080] hover:text-[#102f32] shadow-2xs transition-colors cursor-pointer"
          aria-label="关闭"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Brand Header */}
        <div className="text-center pb-5 mb-5 border-b border-[#e0e3dc]">
          <div className="w-10 h-10 rounded-full border border-[#102f32] flex items-center justify-center mx-auto mb-2 bg-[#f5f2eb]">
            <span className="font-serif-sc text-base font-bold text-[#102f32]">才</span>
          </div>
          <h3 className="font-serif-sc text-2xl font-bold text-[#102f32]">
            {mode === 'login' ? '登录才云' : '开启才云之旅'}
          </h3>
          <p className="text-[13px] text-[#718080] mt-1">
            才聚云端 · 连接人才 · 成就项目
          </p>
        </div>

        {isSuccess ? (
          <div className="py-8 text-center space-y-2">
            <CheckCircle className="w-12 h-12 text-[#668c87] mx-auto" />
            <h4 className="font-serif-sc text-lg font-bold text-[#102f32]">
              {mode === 'login' ? '登录成功' : '注册完成'}
            </h4>
            <p className="text-[13px] text-[#718080]">正在进入工作台...</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Mode Switcher Tabs */}
            <div className="flex bg-[#e8e5dc]/60 p-1 rounded-full text-[13px] font-medium">
              <button
                type="button"
                onClick={() => setMode('login')}
                className={`flex-1 py-1.5 rounded-full transition-all cursor-pointer ${
                  mode === 'login'
                    ? 'bg-white text-[#102f32] shadow-2xs font-semibold'
                    : 'text-[#718080] hover:text-[#102f32]'
                }`}
              >
                账号登录
              </button>
              <button
                type="button"
                onClick={() => setMode('register')}
                className={`flex-1 py-1.5 rounded-full transition-all cursor-pointer ${
                  mode === 'register'
                    ? 'bg-white text-[#102f32] shadow-2xs font-semibold'
                    : 'text-[#718080] hover:text-[#102f32]'
                }`}
              >
                免费注册
              </button>
            </div>

            {/* Role Selection when Registering */}
            {mode === 'register' && (
              <div className="space-y-1.5 pt-1">
                <label className="block text-[12px] font-semibold text-[#102f32]">
                  您的身份意向
                </label>
                <div className="grid grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={() => setRole('client')}
                    className={`p-2.5 rounded-[8px] border text-left flex items-center space-x-2 transition-all cursor-pointer ${
                      role === 'client'
                        ? 'border-[#163b3d] bg-[#163b3d]/5 text-[#102f32] font-semibold'
                        : 'border-[#e0e3dc] bg-white text-[#718080]'
                    }`}
                  >
                    <User className="w-4 h-4 text-[#668c87]" />
                    <span className="text-[13px]">我需要找人才</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setRole('freelancer')}
                    className={`p-2.5 rounded-[8px] border text-left flex items-center space-x-2 transition-all cursor-pointer ${
                      role === 'freelancer'
                        ? 'border-[#163b3d] bg-[#163b3d]/5 text-[#102f32] font-semibold'
                        : 'border-[#e0e3dc] bg-white text-[#718080]'
                    }`}
                  >
                    <Briefcase className="w-4 h-4 text-[#668c87]" />
                    <span className="text-[13px]">我是自由职业者</span>
                  </button>
                </div>
              </div>
            )}

            {mode === 'register' && (
              <div>
                <label className="block text-[12px] font-semibold text-[#102f32] mb-1">
                  您的姓名 / 团队称呼
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="例如：林清轩 / 墨白工作室"
                  className="w-full p-2.5 bg-white border border-[#e0e3dc] rounded-[8px] text-[13px] focus:outline-none focus:border-[#668c87]"
                  required
                />
              </div>
            )}

            <div>
              <label className="block text-[12px] font-semibold text-[#102f32] mb-1">
                手机号码 / 电子邮箱
              </label>
              <input
                type="text"
                value={account}
                onChange={(e) => setAccount(e.target.value)}
                placeholder="请输入手机号或邮箱"
                className="w-full p-2.5 bg-white border border-[#e0e3dc] rounded-[8px] text-[13px] focus:outline-none focus:border-[#668c87]"
                required
              />
            </div>

            <div>
              <label className="block text-[12px] font-semibold text-[#102f32] mb-1">
                登录密码
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="请输入密码"
                className="w-full p-2.5 bg-white border border-[#e0e3dc] rounded-[8px] text-[13px] focus:outline-none focus:border-[#668c87]"
                required
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 mt-2 bg-[#163b3d] hover:bg-[#102f32] text-white font-medium text-[14px] rounded-full shadow-sm hover:shadow transition-all cursor-pointer"
            >
              {mode === 'login' ? '立即登录' : '同意协议并完成注册'}
            </button>

            <div className="text-center pt-2 text-[12px] text-[#8c9c99]">
              💡 演示环境支持任意账号直接登录体验全部功能
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
