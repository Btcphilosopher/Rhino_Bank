export interface Freelancer {
  id: string;
  name: string;
  avatar: string;
  profession: string;
  category: string;
  rating: number;
  completedCount: number;
  hourlyRate: number;
  tags: string[];
  isTopQuality?: boolean;
  bio: string;
  location: string;
  experienceYears: number;
  responseRate: string;
  skills: string[];
  portfolio: {
    title: string;
    image: string;
    category: string;
  }[];
  services: {
    title: string;
    price: number;
    duration: string;
    description: string;
  }[];
  reviews: {
    author: string;
    avatar: string;
    date: string;
    rating: number;
    comment: string;
    project: string;
  }[];
}

export interface Category {
  id: string;
  name: string;
  subText: string;
  iconName: string;
  slug: string;
  projectCount: number;
  freelancerCount: number;
}

export interface Project {
  id: string;
  title: string;
  category: string;
  subCategory: string;
  budgetMin: number;
  budgetMax: number;
  budgetType: 'hourly' | 'fixed';
  deadline: string;
  skills: string[];
  description: string;
  clientName: string;
  clientAvatar: string;
  clientCompany?: string;
  bidsCount: number;
  createdAt: string;
  status: 'recruiting' | 'in_progress' | 'completed' | 'open';
  isFeatured?: boolean;
}

export interface ServicePackage {
  id: string;
  title: string;
  category: string;
  freelancerId?: string;
  freelancerName: string;
  freelancerAvatar: string;
  freelancerRating: number;
  price: number;
  unit: string;
  salesCount: number;
  coverImage?: string;
  deliveryDays?: number;
  duration?: string;
  description?: string;
  features: string[];
}

export interface PortfolioWork {
  id: string;
  title: string;
  category: string;
  authorName: string;
  authorAvatar: string;
  likes: number;
  views: number;
  image: string;
  description: string;
}

export type ActiveTab = 'home' | 'talents' | 'projects' | 'services' | 'portfolio' | 'about';
