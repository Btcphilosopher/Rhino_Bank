package com.example.feature.camera

import android.widget.Toast
import androidx.camera.core.ImageCapture
import androidx.camera.view.PreviewView
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.core.camera.CameraController
import com.example.core.sensors.OrientationLevelSensor
import com.example.domain.camera.CameraMode
import com.example.domain.camera.CameraState
import com.example.feature.pro.ProConsoleOverlay
import com.example.ui.components.*
import com.example.ui.theme.CameraAmber
import com.example.ui.theme.CameraRed

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CameraMainScreen(
    controller: CameraController,
    onOpenGallery: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val context = LocalContext.current
    val settings by controller.settings.collectAsState()
    val capabilities by controller.capabilities.collectAsState()
    val cameraState by controller.cameraState.collectAsState()
    val histogramData by controller.histogramData.collectAsState()
    val aiResult by controller.aiResult.collectAsState()
    val ocrResult by controller.ocrResult.collectAsState()
    val recordingDurationSec by controller.recordingDurationSec.collectAsState()

    // Level Sensor
    val sensor = remember { OrientationLevelSensor(context) }
    val rollDegrees by sensor.rollDegrees.collectAsState()

    var showOcrDialog by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        sensor.startListening()
        onDispose { sensor.stopListening() }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // 1. Camera Viewfinder Preview Surface
        AndroidView(
            factory = { ctx ->
                PreviewView(ctx).also { previewView ->
                    controller.initialize(previewView)
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        // Simulated Badge if in Emulator/Non-camera test container
        if (capabilities.isSimulated) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.Black.copy(alpha = 0.75f))
                    .padding(horizontal = 12.dp, vertical = 4.dp)
            ) {
                Text("模拟相机 (开发与测试环境)", color = CameraAmber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        // 2. Viewfinder Overlays (Grid, Level, Histogram, Focus Peaking)
        if (settings.gridType != "关闭") {
            CameraGridOverlay(gridType = settings.gridType)
        }

        if (settings.showLevel) {
            DigitalLevelGauge(
                rollDegrees = rollDegrees,
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(horizontal = 32.dp)
            )
        }

        if (settings.showHistogram) {
            HistogramView(
                histogramData = histogramData,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(top = 90.dp, start = 16.dp)
            )
        }

        // AI Advice Tooltip Overlay
        if (settings.isAiEnabled && aiResult.sceneLabel.isNotEmpty()) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 85.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.Black.copy(alpha = 0.8f))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("检测到: ${aiResult.sceneLabel}", color = CameraAmber, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    aiResult.adviceList.firstOrNull()?.let { advice ->
                        Text("建议: $advice", color = Color.White, fontSize = 11.sp)
                    }
                }
            }
        }

        // Live OCR Detected Text Trigger Badge
        if (settings.mode == CameraMode.PHOTO && ocrResult.detectedText.isNotEmpty()) {
            Box(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 16.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(CameraAmber)
                    .clickable { showOcrDialog = true }
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.DocumentScanner, contentDescription = "文字扫描", tint = Color.Black, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("提取文字", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // 3. Top Action Bar (RAW, HDR, AI, Flash, Settings)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TopToggleChip(
                    text = "RAW",
                    isActive = settings.isRawEnabled,
                    isSupported = capabilities.supportsRaw
                ) {
                    if (capabilities.supportsRaw) {
                        controller.updateSettings(settings.copy(isRawEnabled = !settings.isRawEnabled))
                    } else {
                        Toast.makeText(context, "当前设备不支持硬件 RAW 格式", Toast.LENGTH_SHORT).show()
                    }
                }

                TopToggleChip(
                    text = "HDR",
                    isActive = settings.isHdrEnabled,
                    isSupported = capabilities.supportsHdr
                ) {
                    controller.updateSettings(settings.copy(isHdrEnabled = !settings.isHdrEnabled))
                }

                TopToggleChip(
                    text = "AI",
                    isActive = settings.isAiEnabled,
                    isSupported = true
                ) {
                    controller.updateSettings(settings.copy(isAiEnabled = !settings.isAiEnabled))
                }
            }

            IconButton(onClick = onOpenSettings) {
                Icon(Icons.Default.Settings, contentDescription = "设置", tint = Color.White)
            }
        }

        // Video Recording Timer Banner
        if (cameraState == CameraState.RECORDING_VIDEO) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 90.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(CameraRed)
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color.White))
                    Spacer(modifier = Modifier.width(8.dp))
                    val mins = recordingDurationSec / 60
                    val secs = recordingDurationSec % 60
                    Text(
                        String.format("%02d:%02d", mins, secs),
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // 4. Pro Console Panel (Shown if PRO or PRO_VIDEO mode active)
        if (settings.mode == CameraMode.PRO || settings.mode == CameraMode.PRO_VIDEO) {
            ProConsoleOverlay(
                settings = settings,
                capabilities = capabilities,
                onSettingsChanged = { controller.updateSettings(it) },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 190.dp)
            )
        }

        // Portrait Depth Simulation Aperture Bar
        if (settings.mode == CameraMode.PORTRAIT) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 190.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.Black.copy(alpha = 0.75f))
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("模拟景深:", color = Color.Gray, fontSize = 12.sp)
                    val apertures = listOf(1.4f, 2.0f, 2.8f, 4.0f, 5.6f)
                    apertures.forEach { fVal ->
                        val isSelected = settings.portraitAperture == fVal
                        Text(
                            "f/$fVal",
                            color = if (isSelected) CameraAmber else Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable {
                                controller.updateSettings(settings.copy(portraitAperture = fVal))
                            }
                        )
                    }
                }
            }
        }

        // Long Exposure Duration Bar
        if (settings.mode == CameraMode.LONG_EXPOSURE) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 190.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.Black.copy(alpha = 0.75f))
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("曝光时长:", color = Color.Gray, fontSize = 12.sp)
                    val durList = listOf(2, 4, 8, 15, 30)
                    durList.forEach { dur ->
                        val isSelected = settings.longExposureSec == dur
                        Text(
                            "${dur}s",
                            color = if (isSelected) CameraAmber else Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable {
                                controller.updateSettings(settings.copy(longExposureSec = dur))
                            }
                        )
                    }
                }
            }
        }

        // 5. Bottom Control Cluster (Lens Selector, Shutter Button, Mode Selector)
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(bottom = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Lens selector
            LensSelectorBar(
                availableLenses = capabilities.availableLenses,
                selectedLens = settings.selectedLens,
                onLensSelected = { lens ->
                    controller.updateSettings(settings.copy(selectedLens = lens, zoomRatio = lens.zoomRatio))
                }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Main Shutter Area
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 32.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Gallery Thumbnail Button
                Box(
                    modifier = Modifier
                        .size(50.dp)
                        .clip(CircleShape)
                        .background(Color.DarkGray)
                        .clickable { onOpenGallery() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.PhotoLibrary, contentDescription = "相册", tint = Color.White)
                }

                // Shutter Button
                ShutterButton(
                    isRecording = cameraState == CameraState.RECORDING_VIDEO,
                    onClick = {
                        if (settings.mode == CameraMode.VIDEO || settings.mode == CameraMode.PRO_VIDEO) {
                            controller.startRecording { msg ->
                                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            controller.takePhoto { msg ->
                                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                )

                // Front/Back Camera Switch
                Box(
                    modifier = Modifier
                        .size(50.dp)
                        .clip(CircleShape)
                        .background(Color.DarkGray)
                        .clickable {
                            val previewView = PreviewView(context)
                            controller.switchCamera(previewView)
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Cameraswitch, contentDescription = "切换摄像头", tint = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Mode Selector Bar (照片, 人像, 夜景, 专业, 视频, 慢动作, 延时, 长曝光, 微距)
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                contentPadding = PaddingValues(horizontal = 32.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(CameraMode.entries) { mode ->
                    val isSelected = settings.mode == mode
                    Text(
                        text = mode.title,
                        color = if (isSelected) CameraAmber else Color.Gray,
                        fontSize = 14.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.clickable {
                            controller.updateSettings(settings.copy(mode = mode))
                        }
                    )
                }
            }
        }
    }

    // Live OCR Extract Text Modal Dialog
    if (showOcrDialog) {
        AlertDialog(
            onDismissRequest = { showOcrDialog = false },
            containerColor = Color(0xFF1E212A),
            title = {
                Text("实时提取的文本内容", color = CameraAmber, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            },
            text = {
                Column {
                    Text(
                        ocrResult.detectedText,
                        color = Color.White,
                        fontSize = 14.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    Toast.makeText(context, "文本已成功复制到剪贴板", Toast.LENGTH_SHORT).show()
                    showOcrDialog = false
                }) {
                    Text("复制文本", color = CameraAmber)
                }
            },
            dismissButton = {
                TextButton(onClick = { showOcrDialog = false }) {
                    Text("取消", color = Color.Gray)
                }
            }
        )
    }
}

@Composable
private fun TopToggleChip(
    text: String,
    isActive: Boolean,
    isSupported: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(
                if (isActive) CameraAmber
                else if (isSupported) Color.Black.copy(alpha = 0.5f)
                else Color.DarkGray.copy(alpha = 0.3f)
            )
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(
            text = text,
            color = if (isActive) Color.Black else if (isSupported) Color.White else Color.Gray,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
