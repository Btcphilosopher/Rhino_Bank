package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF090A0E)
val DarkSurface = Color(0xFF13151B)
val DarkSurfaceVariant = Color(0xFF1E212A)
val CameraAmber = Color(0xFFFFB800)
val CameraRed = Color(0xFFE53935)
val CameraGreen = Color(0xFF00E676)
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFF9E9E9E)
val TextDisabled = Color(0xFF555555)
val CameraBorder = Color(0xFF2C2F3A)
val CameraOverlay = Color(0x99000000)

