package com.example.feature.gallery

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.db.PhotoEntity
import com.example.ui.theme.CameraAmber
import com.example.ui.theme.CameraRed
import com.example.ui.theme.DarkBackground
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GalleryScreen(
    photos: List<PhotoEntity>,
    onBack: () -> Unit,
    onEditPhoto: (PhotoEntity) -> Unit,
    onDeletePhoto: (PhotoEntity) -> Unit,
    onToggleFavorite: (PhotoEntity) -> Unit
) {
    var selectedPhoto by remember { mutableStateOf<PhotoEntity?>(null) }
    var showExifDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("相册与媒体库", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBackground)
            )
        },
        containerColor = DarkBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (photos.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("相册为空", color = Color.Gray, fontSize = 16.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("点击快门按钮拍摄您的第一张作品", color = Color.DarkGray, fontSize = 12.sp)
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(4.dp)
                ) {
                    items(photos) { photo ->
                        Box(
                            modifier = Modifier
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(4.dp))
                                .clickable { selectedPhoto = photo }
                        ) {
                            AsyncImage(
                                model = photo.filePath,
                                contentDescription = photo.fileName,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )

                            if (photo.isRaw) {
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.TopStart)
                                        .padding(4.dp)
                                        .clip(RoundedCornerShape(2.dp))
                                        .background(CameraAmber)
                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                ) {
                                    Text("RAW", color = Color.Black, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Detail Modal Dialog
    selectedPhoto?.let { photo ->
        AlertDialog(
            onDismissRequest = { selectedPhoto = null },
            containerColor = Color(0xFF1E212A),
            title = {
                Text(photo.fileName, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .height(200.dp)
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                    ) {
                        AsyncImage(
                            model = photo.filePath,
                            contentDescription = "照片详情",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        IconButton(onClick = { showExifDialog = true }) {
                            Icon(Icons.Default.Info, contentDescription = "EXIF", tint = CameraAmber)
                        }
                        IconButton(onClick = { onEditPhoto(photo); selectedPhoto = null }) {
                            Icon(Icons.Default.Edit, contentDescription = "编辑", tint = Color.White)
                        }
                        IconButton(onClick = { onToggleFavorite(photo) }) {
                            Icon(
                                Icons.Default.Favorite,
                                contentDescription = "收藏",
                                tint = if (photo.isFavorite) CameraAmber else Color.Gray
                            )
                        }
                        IconButton(onClick = { onDeletePhoto(photo); selectedPhoto = null }) {
                            Icon(Icons.Default.Delete, contentDescription = "删除", tint = CameraRed)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { selectedPhoto = null }) {
                    Text("关闭", color = CameraAmber)
                }
            }
        )
    }

    // EXIF Metadata Sheet
    if (showExifDialog && selectedPhoto != null) {
        val photo = selectedPhoto!!
        val dateStr = SimpleDateFormat("yyyy年M月d日 HH:mm", Locale.getDefault()).format(Date(photo.timestamp))

        AlertDialog(
            onDismissRequest = { showExifDialog = false },
            containerColor = Color(0xFF13151B),
            title = { Text("照片 EXIF 信息", color = CameraAmber, fontSize = 16.sp, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    ExifRow("拍摄时间", dateStr)
                    ExifRow("分辨率", "${photo.width} × ${photo.height} (${if (photo.isRaw) "RAW + JPEG" else "JPEG"})")
                    ExifRow("感光度", "ISO ${photo.iso}")
                    ExifRow("快门速度", photo.shutterSpeed)
                    ExifRow("光圈", photo.aperture)
                    ExifRow("等效焦距", photo.focalLength)
                    ExifRow("GPS", if (photo.latitude != null) "${photo.latitude}, ${photo.longitude}" else "关闭")
                }
            },
            confirmButton = {
                TextButton(onClick = { showExifDialog = false }) {
                    Text("确定", color = CameraAmber)
                }
            }
        )
    }
}

@Composable
private fun ExifRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = Color.Gray, fontSize = 12.sp)
        Text(value, color = Color.White, fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
    }
}
