package com.example.feature.pro

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.camera.CameraCapabilities
import com.example.domain.camera.CaptureSettings
import com.example.ui.theme.CameraAmber
import java.util.Locale

@Composable
fun ProConsoleOverlay(
    settings: CaptureSettings,
    capabilities: CameraCapabilities,
    onSettingsChanged: (CaptureSettings) -> Unit,
    modifier: Modifier = Modifier
) {
    var activeTab by remember { mutableStateOf("ISO") } // "ISO", "快门", "EV", "白平衡", "对焦", "测光"

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
            .background(Color.Black.copy(alpha = 0.85f))
            .padding(12.dp)
    ) {
        // Top status indicators bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ProMetricChip("ISO", if (settings.iso == 0) "AUTO" else "${settings.iso}", activeTab == "ISO") { activeTab = "ISO" }
            ProMetricChip("快门", formatShutterNs(settings.shutterNs), activeTab == "快门") { activeTab = "快门" }
            ProMetricChip("EV", String.format(Locale.getDefault(), "%+.1f", settings.ev * capabilities.exposureCompStep), activeTab == "EV") { activeTab = "EV" }
            ProMetricChip("白平衡", if (settings.whiteBalanceK == 0) "自动" else "${settings.whiteBalanceK}K", activeTab == "白平衡") { activeTab = "白平衡" }
            ProMetricChip("对焦", if (settings.focusDistance == 0f) "自动" else "MF", activeTab == "对焦") { activeTab = "对焦" }
            ProMetricChip("测光", settings.meteringMode, activeTab == "测光") { activeTab = "测光" }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Dynamic parameter selection control bar
        when (activeTab) {
            "ISO" -> {
                val isoList = listOf(0, 50, 100, 200, 400, 800, 1600, 3200, 6400).filter {
                    it == 0 || it in capabilities.isoRange
                }
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(isoList) { isoVal ->
                        val label = if (isoVal == 0) "AUTO" else "$isoVal"
                        val isSelected = settings.iso == isoVal
                        ProChoicePill(label, isSelected) {
                            onSettingsChanged(settings.copy(iso = isoVal))
                        }
                    }
                }
            }

            "快门" -> {
                val shutterOptions = listOf(
                    0L to "AUTO",
                    125_000L to "1/8000",
                    250_000L to "1/4000",
                    500_000L to "1/2000",
                    1_000_000L to "1/1000",
                    2_000_000L to "1/500",
                    4_000_000L to "1/250",
                    8_000_000L to "1/125",
                    16_666_666L to "1/60",
                    33_333_333L to "1/30",
                    66_666_666L to "1/15",
                    125_000_000L to "1/8",
                    250_000_000L to "1/4",
                    500_000_000L to "1/2",
                    1_000_000_000L to "1s",
                    2_000_000_000L to "2s",
                    4_000_000_000L to "4s",
                    8_000_000_000L to "8s"
                )
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(shutterOptions) { (nsVal, label) ->
                        val isSelected = settings.shutterNs == nsVal
                        ProChoicePill(label, isSelected) {
                            onSettingsChanged(settings.copy(shutterNs = nsVal))
                        }
                    }
                }
            }

            "EV" -> {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "曝光补偿: ${String.format(Locale.getDefault(), "%+.1f EV", settings.ev * capabilities.exposureCompStep)}",
                        color = Color.White,
                        fontSize = 12.sp
                    )
                    Slider(
                        value = settings.ev.toFloat(),
                        onValueChange = { onSettingsChanged(settings.copy(ev = it.toInt())) },
                        valueRange = capabilities.exposureCompRange.first.toFloat()..capabilities.exposureCompRange.last.toFloat(),
                        steps = capabilities.exposureCompRange.last - capabilities.exposureCompRange.first - 1,
                        colors = SliderDefaults.colors(
                            thumbColor = CameraAmber,
                            activeTrackColor = CameraAmber
                        )
                    )
                }
            }

            "白平衡" -> {
                val wbValues = listOf(0 to "自动", 2800 to "2800K", 3200 to "3200K", 4000 to "4000K", 5200 to "5200K", 6500 to "6500K", 8000 to "8000K")
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(wbValues) { (kVal, label) ->
                        val isSelected = settings.whiteBalanceK == kVal
                        ProChoicePill(label, isSelected) {
                            onSettingsChanged(settings.copy(whiteBalanceK = kVal))
                        }
                    }
                }
            }

            "对焦" -> {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("近 ← 手动对焦 MF → 远", color = Color.White, fontSize = 12.sp)
                        Text(if (settings.focusDistance == 0f) "自动" else "MF", color = CameraAmber, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = settings.focusDistance,
                        onValueChange = { onSettingsChanged(settings.copy(focusDistance = it)) },
                        valueRange = 0f..1f,
                        colors = SliderDefaults.colors(thumbColor = CameraAmber, activeTrackColor = CameraAmber)
                    )
                }
            }

            "测光" -> {
                val modes = listOf("矩阵", "中央重点", "点测光")
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    modes.forEach { mode ->
                        val isSelected = settings.meteringMode == mode
                        ProChoicePill(mode, isSelected) {
                            onSettingsChanged(settings.copy(meteringMode = mode))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProMetricChip(
    title: String,
    value: String,
    isActive: Boolean,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (isActive) CameraAmber.copy(alpha = 0.2f) else Color.Transparent)
            .border(1.dp, if (isActive) CameraAmber else Color.Transparent, RoundedCornerShape(6.dp))
            .clickable { onClick() }
            .padding(horizontal = 6.dp, vertical = 4.dp)
    ) {
        Text(title, color = Color.Gray, fontSize = 10.sp)
        Text(
            value,
            color = if (isActive) CameraAmber else Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
private fun ProChoicePill(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (isSelected) CameraAmber else Color.DarkGray.copy(alpha = 0.6f))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            color = if (isSelected) Color.Black else Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}

private fun formatShutterNs(ns: Long): String {
    if (ns == 0L) return "AUTO"
    val secFraction = 1_000_000_000L / ns
    return if (secFraction >= 1) "1/$secFraction" else "${ns / 1_000_000_000L}s"
}
