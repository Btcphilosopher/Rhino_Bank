package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.example.domain.camera.HistogramData

@Composable
fun HistogramView(
    histogramData: HistogramData,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .width(120.dp)
            .height(60.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(Color.Black.copy(alpha = 0.65f))
    ) {
        Canvas(modifier = Modifier.matchParentSize()) {
            val width = size.width
            val height = size.height

            // Draw RGB channel paths
            fun drawChannel(data: FloatArray, color: Color) {
                if (data.isEmpty()) return
                val path = Path()
                val stepX = width / (data.size - 1)

                path.moveTo(0f, height)
                for (i in data.indices) {
                    val x = i * stepX
                    val y = height - (data[i] * height)
                    path.lineTo(x, y)
                }
                path.lineTo(width, height)
                path.close()

                drawPath(
                    path = path,
                    color = color.copy(alpha = 0.4f),
                    style = Stroke(width = 1.5f)
                )
            }

            drawChannel(histogramData.redChannel, Color(0xFFFF5252))
            drawChannel(histogramData.greenChannel, Color(0xFF66BB6A))
            drawChannel(histogramData.blueChannel, Color(0xFF42A5F5))
            drawChannel(histogramData.luminanceChannel, Color.White)
        }
    }
}
