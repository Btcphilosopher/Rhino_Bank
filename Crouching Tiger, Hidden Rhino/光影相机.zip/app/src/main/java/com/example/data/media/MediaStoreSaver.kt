package com.example.data.media

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.example.data.db.AppDatabase
import com.example.data.db.PhotoEntity
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MediaStoreSaver(private val context: Context) {
    private val db = AppDatabase.getDatabase(context)

    fun generateFileName(prefix: String = "GY", extension: String = "jpg"): String {
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val counter = String.format(Locale.getDefault(), "%03d", (1..999).random())
        return "${prefix}_${timestamp}_${counter}.${extension}"
    }

    suspend fun savePhotoToMediaStore(
        imageBytes: ByteArray,
        isRaw: Boolean = false,
        iso: Int = 100,
        shutterSpeedStr: String = "1/250",
        focalLengthStr: String = "24mm"
    ): Uri? {
        val extension = if (isRaw) "dng" else "jpg"
        val mimeType = if (isRaw) "image/x-adobe-dng" else "image/jpeg"
        val fileName = generateFileName("GY", extension)
        val timestamp = System.currentTimeMillis()

        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Images.Media.MIME_TYPE, mimeType)
            put(MediaStore.Images.Media.DATE_ADDED, timestamp / 1000)
            put(MediaStore.Images.Media.DATE_TAKEN, timestamp)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_DCIM + "/GuangYingCamera")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
        }

        val resolver = context.contentResolver
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        }

        val itemUri = resolver.insert(collection, values) ?: return null

        try {
            resolver.openOutputStream(itemUri)?.use { stream ->
                stream.write(imageBytes)
                stream.flush()
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(itemUri, values, null, null)
            }

            // Save metadata to Room database
            db.photoDao().insertPhoto(
                PhotoEntity(
                    filePath = itemUri.toString(),
                    fileName = fileName,
                    mimeType = mimeType,
                    timestamp = timestamp,
                    width = 4000,
                    height = 3000,
                    iso = iso,
                    shutterSpeed = shutterSpeedStr,
                    aperture = "f/1.8",
                    focalLength = focalLengthStr,
                    isRaw = isRaw
                )
            )

            return itemUri
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    fun prepareVideoContentValues(): ContentValues {
        val fileName = generateFileName("GY", "mp4")
        return ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.DATE_ADDED, System.currentTimeMillis() / 1000)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_DCIM + "/GuangYingCamera")
            }
        }
    }
}
