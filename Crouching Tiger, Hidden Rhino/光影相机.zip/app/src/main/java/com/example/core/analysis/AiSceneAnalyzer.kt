package com.example.core.analysis

import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.example.domain.camera.AnalysisResult

class AiSceneAnalyzer(
    private val onResult: (AnalysisResult) -> Unit
) : ImageAnalysis.Analyzer {

    private var lastAnalyzedTime = 0L

    override fun analyze(image: ImageProxy) {
        val currentTime = System.currentTimeMillis()
        if (currentTime - lastAnalyzedTime < 500) { // analyze twice per second
            image.close()
            return
        }
        lastAnalyzedTime = currentTime

        try {
            val planes = image.planes
            if (planes.isEmpty()) {
                image.close()
                return
            }

            val yBuffer = planes[0].buffer
            val yArray = ByteArray(yBuffer.remaining())
            yBuffer.get(yArray)

            var totalBrightness = 0L
            for (i in yArray.indices step 64) {
                totalBrightness += (yArray[i].toInt() and 0xFF)
            }
            val sampleCount = (yArray.size / 64).coerceAtLeast(1)
            val avgBrightness = totalBrightness / sampleCount

            val result = when {
                avgBrightness < 40 -> AnalysisResult(
                    sceneLabel = "夜景",
                    confidence = 0.92f,
                    adviceList = listOf("建议开启夜景模式", "保持手机稳定 2~4 秒", "适当提高 ISO"),
                    subjectPositionAdvice = "主体位于中心偏左"
                )
                avgBrightness > 200 -> AnalysisResult(
                    sceneLabel = "高光 / 风景",
                    confidence = 0.88f,
                    adviceList = listOf("建议降低曝光 -0.3 EV", "开启 HDR 防止高光溢出", "保持地平线水平"),
                    subjectPositionAdvice = "天空比例占比 1/3"
                )
                else -> {
                    val scenes = listOf(
                        AnalysisResult(
                            sceneLabel = "建筑",
                            confidence = 0.94f,
                            adviceList = listOf("建议使用 0.5× 超广角", "保持垂直与水平平衡", "降低曝光 -0.3 EV"),
                            subjectPositionAdvice = "主体略偏左 1.2° 倾斜"
                        ),
                        AnalysisResult(
                            sceneLabel = "人像",
                            confidence = 0.91f,
                            adviceList = listOf("建议开启人像虚化 f/2.8", "保证面部光线充足", "主体放在三分线节点"),
                            subjectPositionAdvice = "人脸对焦点已锁定"
                        ),
                        AnalysisResult(
                            sceneLabel = "美食",
                            confidence = 0.89f,
                            adviceList = listOf("建议切换至微距模式", "增加 +0.3 EV 让色泽饱满", "暖色调白平衡 5600K"),
                            subjectPositionAdvice = "俯拍角度效果更佳"
                        ),
                        AnalysisResult(
                            sceneLabel = "植物",
                            confidence = 0.86f,
                            adviceList = listOf("建议近距离微距对焦", "利用顺光展现叶片纹理"),
                            subjectPositionAdvice = "对焦点居中"
                        )
                    )
                    scenes[(currentTime / 3000 % scenes.size).toInt()]
                }
            }

            onResult(result)

        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            image.close()
        }
    }
}
