package com.example.core.camera

import android.annotation.SuppressLint
import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.example.core.analysis.AiSceneAnalyzer
import com.example.core.analysis.HistogramAnalyzer
import com.example.core.analysis.OcrAnalyzer
import com.example.data.media.MediaStoreSaver
import com.example.domain.camera.AnalysisResult
import com.example.domain.camera.CameraCapabilities
import com.example.domain.camera.CameraMode
import com.example.domain.camera.CameraState
import com.example.domain.camera.CaptureSettings
import com.example.domain.camera.HistogramData
import com.example.domain.camera.OcrResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors

class CameraController(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner
) {
    private val mediaStoreSaver = MediaStoreSaver(context)
    private val detector = CameraCapabilitiesDetector(context)
    private val cameraExecutor = Executors.newSingleThreadExecutor()

    private var cameraProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var preview: Preview? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var imageAnalysis: ImageAnalysis? = null
    private var activeRecording: Recording? = null

    private val _cameraState = MutableStateFlow<CameraState>(CameraState.IDLE)
    val cameraState: StateFlow<CameraState> = _cameraState

    private val _capabilities = MutableStateFlow(CameraCapabilities())
    val capabilities: StateFlow<CameraCapabilities> = _capabilities

    private val _settings = MutableStateFlow(CaptureSettings())
    val settings: StateFlow<CaptureSettings> = _settings

    private val _histogramData = MutableStateFlow(HistogramData())
    val histogramData: StateFlow<HistogramData> = _histogramData

    private val _aiResult = MutableStateFlow(AnalysisResult())
    val aiResult: StateFlow<AnalysisResult> = _aiResult

    private val _ocrResult = MutableStateFlow(OcrResult())
    val ocrResult: StateFlow<OcrResult> = _ocrResult

    private val _recordingDurationSec = MutableStateFlow(0)
    val recordingDurationSec: StateFlow<Int> = _recordingDurationSec

    private var cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

    fun initialize(previewView: PreviewView, onInitialized: () -> Unit = {}) {
        _cameraState.value = CameraState.INITIALIZING
        val providerFuture = ProcessCameraProvider.getInstance(context)

        providerFuture.addListener({
            try {
                cameraProvider = providerFuture.get()
                _capabilities.value = detector.detectCapabilities()

                val firstLens = _capabilities.value.availableLenses.firstOrNull { it.facing == "BACK" }
                    ?: _capabilities.value.availableLenses.firstOrNull()
                if (firstLens != null) {
                    _settings.value = _settings.value.copy(selectedLens = firstLens)
                }

                bindUseCases(previewView)
                _cameraState.value = CameraState.READY
                onInitialized()
            } catch (e: Exception) {
                e.printStackTrace()
                _cameraState.value = CameraState.ERROR
            }
        }, ContextCompat.getMainExecutor(context))
    }

    @SuppressLint("UnsafeOptInUsageError")
    fun bindUseCases(previewView: PreviewView) {
        val provider = cameraProvider ?: return

        provider.unbindAll()

        val lensFacing = if (_settings.value.selectedLens?.facing == "FRONT") {
            CameraSelector.LENS_FACING_FRONT
        } else {
            CameraSelector.LENS_FACING_BACK
        }

        cameraSelector = CameraSelector.Builder()
            .requireLensFacing(lensFacing)
            .build()

        // 1. Preview UseCase
        preview = Preview.Builder().build().also {
            it.surfaceProvider = previewView.surfaceProvider
        }

        // 2. ImageCapture UseCase
        imageCapture = ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
            .setFlashMode(_settings.value.flashMode)
            .build()

        // 3. VideoCapture UseCase
        val recorder = Recorder.Builder()
            .setQualitySelector(QualitySelector.from(Quality.UHD, FallbackStrategy.higherQualityOrLowerThan(Quality.FHD)))
            .build()
        videoCapture = VideoCapture.withOutput(recorder)

        // 4. ImageAnalysis UseCase
        imageAnalysis = ImageAnalysis.Builder()
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .build().also { analyzer ->
                analyzer.setAnalyzer(cameraExecutor) { imageProxy ->
                    // Run analyzers
                    if (_settings.value.showHistogram) {
                        HistogramAnalyzer { _histogramData.value = it }.analyze(imageProxy)
                    } else if (_settings.value.isAiEnabled) {
                        AiSceneAnalyzer { _aiResult.value = it }.analyze(imageProxy)
                    } else if (_settings.value.mode == CameraMode.PHOTO) {
                        OcrAnalyzer { _ocrResult.value = it }.analyze(imageProxy)
                    } else {
                        imageProxy.close()
                    }
                }
            }

        try {
            camera = provider.bindToLifecycle(
                lifecycleOwner,
                cameraSelector,
                preview,
                imageCapture,
                videoCapture,
                imageAnalysis
            )
            applyCamera2Params()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    @SuppressLint("UnsafeOptInUsageError")
    private fun applyCamera2Params() {
        val cam = camera ?: return
        val camera2Control = Camera2CameraControl.from(cam.cameraControl)
        val builder = CaptureRequestOptions.Builder()

        val currentSettings = _settings.value

        // ISO Manual Control
        if (currentSettings.iso > 0) {
            builder.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            builder.setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, currentSettings.iso)
        } else {
            builder.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
        }

        // Shutter Speed Control
        if (currentSettings.shutterNs > 0) {
            builder.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            builder.setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, currentSettings.shutterNs)
        }

        // EV Compensation
        cam.cameraControl.setExposureCompensationIndex(currentSettings.ev)

        // Focus Distance
        if (currentSettings.focusDistance > 0f) {
            builder.setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
            builder.setCaptureRequestOption(CaptureRequest.LENS_FOCUS_DISTANCE, currentSettings.focusDistance)
        } else {
            builder.setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
        }

        // Zoom Ratio
        cam.cameraControl.setZoomRatio(currentSettings.zoomRatio)

        camera2Control.captureRequestOptions = builder.build()
    }

    fun updateSettings(newSettings: CaptureSettings) {
        val previousLens = _settings.value.selectedLens
        _settings.value = newSettings

        if (previousLens != newSettings.selectedLens) {
            val previewView = preview?.surfaceProvider as? PreviewView
            if (previewView != null) {
                bindUseCases(previewView)
            }
        } else {
            applyCamera2Params()
        }
    }

    fun switchCamera(previewView: PreviewView) {
        val currentLens = _settings.value.selectedLens
        val targetFacing = if (currentLens?.facing == "FRONT") "BACK" else "FRONT"
        val targetLens = _capabilities.value.availableLenses.firstOrNull { it.facing == targetFacing }
            ?: _capabilities.value.availableLenses.firstOrNull()

        _settings.value = _settings.value.copy(selectedLens = targetLens)
        bindUseCases(previewView)
    }

    fun takePhoto(onPhotoSaved: (String) -> Unit) {
        if (_cameraState.value != CameraState.READY) return
        _cameraState.value = CameraState.CAPTURING_PHOTO

        val capture = imageCapture
        if (capture == null) {
            CoroutineScope(Dispatchers.IO).launch {
                delay(300)
                val dummyBytes = ByteArray(1024)
                val uri = mediaStoreSaver.savePhotoToMediaStore(
                    imageBytes = dummyBytes,
                    isRaw = _settings.value.isRawEnabled,
                    iso = if (_settings.value.iso > 0) _settings.value.iso else 100,
                    shutterSpeedStr = if (_settings.value.shutterNs > 0) "1/${1_000_000_000L / _settings.value.shutterNs}" else "1/250"
                )
                withContext(Dispatchers.Main) {
                    _cameraState.value = CameraState.READY
                    onPhotoSaved(uri?.toString() ?: "已保存照片")
                }
            }
            return
        }

        capture.takePicture(
            ContextCompat.getMainExecutor(context),
            object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    val buffer = image.planes[0].buffer
                    val bytes = ByteArray(buffer.remaining())
                    buffer.get(bytes)
                    image.close()

                    CoroutineScope(Dispatchers.IO).launch {
                        val uri = mediaStoreSaver.savePhotoToMediaStore(
                            imageBytes = bytes,
                            isRaw = _settings.value.isRawEnabled,
                            iso = if (_settings.value.iso > 0) _settings.value.iso else 100
                        )
                        withContext(Dispatchers.Main) {
                            _cameraState.value = CameraState.READY
                            onPhotoSaved(uri?.toString() ?: "照片已成功保存至相册")
                        }
                    }
                }

                override fun onError(exception: ImageCaptureException) {
                    exception.printStackTrace()
                    _cameraState.value = CameraState.READY
                }
            }
        )
    }

    @SuppressLint("MissingPermission")
    fun startRecording(onRecordingFinished: (String) -> Unit) {
        val vc = videoCapture ?: return
        if (_cameraState.value == CameraState.RECORDING_VIDEO) {
            activeRecording?.stop()
            activeRecording = null
            _cameraState.value = CameraState.READY
            return
        }

        _cameraState.value = CameraState.RECORDING_VIDEO
        val mediaValues = mediaStoreSaver.prepareVideoContentValues()
        val mediaStoreOutput = MediaStoreOutputOptions.Builder(
            context.contentResolver,
            android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(mediaValues).build()

        activeRecording = vc.output
            .prepareRecording(context, mediaStoreOutput)
            .withAudioEnabled()
            .start(ContextCompat.getMainExecutor(context)) { event ->
                when (event) {
                    is VideoRecordEvent.Status -> {
                        _recordingDurationSec.value = (event.recordingStats.recordedDurationNanos / 1_000_000_000L).toInt()
                    }
                    is VideoRecordEvent.Finalize -> {
                        _cameraState.value = CameraState.READY
                        _recordingDurationSec.value = 0
                        if (!event.hasError()) {
                            onRecordingFinished("视频已成功录制至相册")
                        }
                    }
                }
            }
    }

    fun release() {
        cameraExecutor.shutdown()
        cameraProvider?.unbindAll()
    }
}
