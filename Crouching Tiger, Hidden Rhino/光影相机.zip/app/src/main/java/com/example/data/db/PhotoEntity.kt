package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "photos")
data class PhotoEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val filePath: String,
    val fileName: String,
    val mimeType: String,
    val timestamp: Long,
    val width: Int,
    val height: Int,
    val iso: Int,
    val shutterSpeed: String,
    val aperture: String,
    val focalLength: String,
    val isRaw: Boolean,
    val isFavorite: Boolean = false,
    val latitude: Double? = null,
    val longitude: Double? = null
)

@Entity(tableName = "camera_settings")
data class SettingEntity(
    @PrimaryKey val key: String,
    val value: String
)
