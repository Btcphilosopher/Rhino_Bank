package com.example.feature.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.camera.CameraCapabilities
import com.example.domain.camera.CaptureSettings
import com.example.ui.theme.CameraAmber
import com.example.ui.theme.DarkBackground

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CameraSettingsScreen(
    settings: CaptureSettings,
    capabilities: CameraCapabilities,
    onSettingsChanged: (CaptureSettings) -> Unit,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("相机与高级摄影设置", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBackground)
            )
        },
        containerColor = DarkBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            SettingHeader("辅助工具与取景器")
            SwitchRow("RGB 直方图", settings.showHistogram) {
                onSettingsChanged(settings.copy(showHistogram = it))
            }
            SwitchRow("电子水平仪", settings.showLevel) {
                onSettingsChanged(settings.copy(showLevel = it))
            }
            SwitchRow("峰值对焦 Focus Peaking", settings.showPeaking) {
                onSettingsChanged(settings.copy(showPeaking = it))
            }
            SwitchRow("斑马纹 Zebra", settings.showZebra) {
                onSettingsChanged(settings.copy(showZebra = it))
            }
            SwitchRow("AI 构图与场景助手", settings.isAiEnabled) {
                onSettingsChanged(settings.copy(isAiEnabled = it))
            }

            SettingHeader("存储与格式")
            SwitchRow("RAW / DNG 格式 (设备支持)", settings.isRawEnabled && capabilities.supportsRaw) {
                if (capabilities.supportsRaw) {
                    onSettingsChanged(settings.copy(isRawEnabled = it))
                }
            }
            if (!capabilities.supportsRaw) {
                Text("当前设备不支持硬件 RAW 输出", color = Color.Gray, fontSize = 11.sp)
            }

            Column {
                Text("文件命名规则示例", color = Color.Gray, fontSize = 12.sp)
                Text(
                    "GY_20260918_014238_001.jpg",
                    color = CameraAmber,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }

            SettingHeader("设备硬件能力信息")
            InfoRow("摄像头数量", "${capabilities.cameraCount} 个")
            InfoRow("硬件等级", capabilities.hardwareLevel)
            InfoRow("RAW 摄影", if (capabilities.supportsRaw) "支持" else "当前设备不支持")
            InfoRow("光学防抖 OIS", if (capabilities.supportsOis) "支持" else "当前设备不支持")
            InfoRow("4K 视频录制", if (capabilities.supportsVideo4K) "支持" else "当前设备不支持")
            InfoRow("模式类型", if (capabilities.isSimulated) "开发环境模拟模式" else "真实硬件驱动")

            Spacer(modifier = Modifier.height(24.dp))
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("光影相机 GuangYingCamera v3.7 • 专业级 Android 计算摄影", color = Color.Gray, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun SettingHeader(title: String) {
    Text(title, color = CameraAmber, fontSize = 13.sp, fontWeight = FontWeight.Bold)
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Color.White, fontSize = 14.sp)
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = CameraAmber,
                checkedTrackColor = CameraAmber.copy(alpha = 0.3f)
            )
        )
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = Color.Gray, fontSize = 13.sp)
        Text(value, color = Color.White, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
    }
}
