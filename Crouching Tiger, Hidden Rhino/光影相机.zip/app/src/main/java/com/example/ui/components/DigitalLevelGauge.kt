package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CameraAmber
import com.example.ui.theme.CameraGreen
import java.util.Locale
import kotlin.math.abs

@Composable
fun DigitalLevelGauge(
    rollDegrees: Float,
    modifier: Modifier = Modifier
) {
    val normalizedRoll = ((rollDegrees + 180) % 360) - 180
    val isLevel = abs(normalizedRoll) < 0.8f
    val lineColor = if (isLevel) CameraGreen else CameraAmber

    Box(
        modifier = modifier.fillMaxWidth(),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Canvas(modifier = Modifier.width(60.dp).height(2.dp)) {
                drawLine(
                    color = lineColor,
                    start = Offset(0f, size.height / 2),
                    end = Offset(size.width, size.height / 2),
                    strokeWidth = 3f
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Text(
                text = String.format(Locale.getDefault(), "%.1f°", abs(normalizedRoll)),
                color = lineColor,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )

            Spacer(modifier = Modifier.width(12.dp))

            Canvas(modifier = Modifier.width(60.dp).height(2.dp)) {
                drawLine(
                    color = lineColor,
                    start = Offset(0f, size.height / 2),
                    end = Offset(size.width, size.height / 2),
                    strokeWidth = 3f
                )
            }
        }
    }
}
