package com.example.core.analysis

import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.example.domain.camera.OcrResult

class OcrAnalyzer(
    private val onTextDetected: (OcrResult) -> Unit
) : ImageAnalysis.Analyzer {

    private var lastAnalyzedTime = 0L

    override fun analyze(image: ImageProxy) {
        val currentTime = System.currentTimeMillis()
        if (currentTime - lastAnalyzedTime < 800) {
            image.close()
            return
        }
        lastAnalyzedTime = currentTime

        try {
            // Live text recognition simulation from ImageAnalysis stream
            val detectedSampleTexts = listOf(
                "光影相机专业摄影工程系统\nPRO CAMERA SYSTEM v3.7\nISO 100 1/250s RAW",
                "合同协议书\n甲方：光影科技股份有限公司\n乙方：高级计算摄影开发者",
                "精选咖啡菜单\n美式咖啡 ¥28\n拿铁咖啡 ¥32\n燕麦拿铁 ¥36",
                "发票代码：1100204130\n发票号码：09823412\n金额：￥1,280.00"
            )

            val sample = detectedSampleTexts[(currentTime / 4000 % detectedSampleTexts.size).toInt()]
            val blocks = sample.split("\n")

            onTextDetected(
                OcrResult(
                    detectedText = sample,
                    textBlocks = blocks
                )
            )

        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            image.close()
        }
    }
}
