package com.example.feature.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.db.PhotoEntity
import com.example.ui.theme.CameraAmber
import com.example.ui.theme.DarkBackground
import java.util.Locale

data class EditParameters(
    val exposure: Float = 0f,
    val contrast: Float = 0f,
    val highlights: Float = 0f,
    val shadows: Float = 0f,
    val saturation: Float = 0f,
    val temperature: Float = 0f,
    val sharpness: Float = 0f,
    val vignette: Float = 0f
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProImageEditorScreen(
    photo: PhotoEntity,
    onBack: () -> Unit,
    onSave: (EditParameters) -> Unit
) {
    var params by remember { mutableStateOf(EditParameters()) }
    var activeTool by remember { mutableStateOf("曝光") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("专业非破坏性图像编辑器", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回")
                    }
                },
                actions = {
                    IconButton(onClick = { onSave(params) }) {
                        Icon(Icons.Default.Check, contentDescription = "保存", tint = CameraAmber)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBackground)
            )
        },
        containerColor = DarkBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Preview Image Display
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                AsyncImage(
                    model = photo.filePath,
                    contentDescription = "编辑预览",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )

                // Rendered Output Tag
                Box(
                    modifier = Modifier
                        .padding(12.dp)
                        .align(Alignment.TopEnd)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.Black.copy(alpha = 0.7f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text("实时渲染 (RAW Pipeline)", color = CameraAmber, fontSize = 10.sp)
                }
            }

            // Adjustment Tool Value Slider
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.9f))
                    .padding(16.dp)
            ) {
                val currentValue = when (activeTool) {
                    "曝光" -> params.exposure
                    "对比度" -> params.contrast
                    "高光" -> params.highlights
                    "阴影" -> params.shadows
                    "饱和度" -> params.saturation
                    "色温" -> params.temperature
                    "锐度" -> params.sharpness
                    else -> params.vignette
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(activeTool, color = Color.White, fontSize = 14.sp)
                    Text(
                        String.format(Locale.getDefault(), "%+.1f", currentValue),
                        color = CameraAmber,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Slider(
                    value = currentValue,
                    onValueChange = { newValue ->
                        params = when (activeTool) {
                            "曝光" -> params.copy(exposure = newValue)
                            "对比度" -> params.copy(contrast = newValue)
                            "高光" -> params.copy(highlights = newValue)
                            "阴影" -> params.copy(shadows = newValue)
                            "饱和度" -> params.copy(saturation = newValue)
                            "色温" -> params.copy(temperature = newValue)
                            "锐度" -> params.copy(sharpness = newValue)
                            else -> params.copy(vignette = newValue)
                        }
                    },
                    valueRange = -100f..100f,
                    colors = SliderDefaults.colors(
                        thumbColor = CameraAmber,
                        activeTrackColor = CameraAmber
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Adjustment Tools List
                val tools = listOf("曝光", "对比度", "高光", "阴影", "饱和度", "色温", "锐度", "暗角")
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(tools.size) { index ->
                        val tool = tools[index]
                        val isSelected = activeTool == tool
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) CameraAmber else Color.DarkGray.copy(alpha = 0.5f))
                                .clickable { activeTool = tool }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Text(
                                tool,
                                color = if (isSelected) Color.Black else Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
