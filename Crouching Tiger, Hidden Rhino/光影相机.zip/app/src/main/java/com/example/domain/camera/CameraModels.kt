package com.example.domain.camera

import androidx.camera.core.ImageCapture

enum class CameraMode(val title: String) {
    PHOTO("照片"),
    PORTRAIT("人像"),
    NIGHT("夜景"),
    PRO("专业"),
    VIDEO("视频"),
    PRO_VIDEO("专业视频"),
    SLOW_MOTION("慢动作"),
    TIMELAPSE("延时摄影"),
    LONG_EXPOSURE("长曝光"),
    MACRO("微距")
}

enum class CameraState {
    IDLE,
    INITIALIZING,
    READY,
    CAPTURING_PHOTO,
    RECORDING_VIDEO,
    PAUSED,
    ERROR,
    RELEASING
}

data class Lens(
    val id: String,
    val name: String,
    val facing: String, // "BACK" or "FRONT"
    val focalLengthMm: Float,
    val aperture: Float,
    val zoomRatio: Float,
    val isPhysical: Boolean,
    val typeName: String // "超广角", "主摄", "长焦", "前置", "数字变焦"
)

data class CameraCapabilities(
    val cameraCount: Int = 1,
    val hasBackCamera: Boolean = true,
    val hasFrontCamera: Boolean = true,
    val availableLenses: List<Lens> = emptyList(),
    val isoRange: ClosedRange<Int> = 50..6400,
    val shutterRangeNs: ClosedRange<Long> = 125_000L..8_000_000_000L, // 1/8000s ~ 8s
    val exposureCompRange: IntRange = -3..3,
    val exposureCompStep: Float = 0.33f,
    val supportedAfModes: List<String> = listOf("自动", "单次", "连续", "手动"),
    val supportedAwbModes: List<String> = listOf("自动", "日光", "阴天", "荧光灯", "白炽灯", "手动"),
    val supportsRaw: Boolean = true,
    val supportsHdr: Boolean = true,
    val supportsVideo4K: Boolean = true,
    val supportsSlowMotion: Boolean = false,
    val supportsOis: Boolean = false,
    val hardwareLevel: String = "FULL",
    val isSimulated: Boolean = false
)

data class CaptureSettings(
    val mode: CameraMode = CameraMode.PHOTO,
    val iso: Int = 0, // 0 means AUTO
    val shutterNs: Long = 0L, // 0 means AUTO
    val ev: Int = 0,
    val whiteBalanceK: Int = 0, // 0 means AUTO (e.g. 2000K ~ 10000K)
    val focusDistance: Float = 0f, // 0.0f = Auto / Infinity, 1.0f = Close
    val meteringMode: String = "矩阵", // "矩阵", "中央重点", "点测光"
    val isRawEnabled: Boolean = false,
    val isHdrEnabled: Boolean = false,
    val isAiEnabled: Boolean = false,
    val flashMode: Int = ImageCapture.FLASH_MODE_OFF,
    val zoomRatio: Float = 1.0f,
    val selectedLens: Lens? = null,
    val aspectRatio: String = "4:3", // "4:3", "16:9", "1:1"
    val gridType: String = "三分法", // "关闭", "三分法", "中心", "对角线", "黄金分割"
    val showHistogram: Boolean = true,
    val showZebra: Boolean = false,
    val zebraThreshold: Int = 80, // 70%, 80%, 90%, 95%, 100%
    val showPeaking: Boolean = false,
    val peakingSensitivity: Float = 0.5f,
    val showLevel: Boolean = true,
    val portraitAperture: Float = 2.8f, // f/1.4 ~ f/16
    val longExposureSec: Int = 4, // 2s, 4s, 8s, 15s, 30s
    val timelapseIntervalSec: Int = 2, // 1s, 2s, 5s, 10s
    val slowMotionFps: Int = 120
)

data class AnalysisResult(
    val sceneLabel: String = "",
    val confidence: Float = 0f,
    val adviceList: List<String> = emptyList(),
    val horizonTiltDegrees: Float = 0f,
    val subjectPositionAdvice: String = ""
)

data class OcrResult(
    val detectedText: String = "",
    val textBlocks: List<String> = emptyList()
)

data class HistogramData(
    val redChannel: FloatArray = FloatArray(256),
    val greenChannel: FloatArray = FloatArray(256),
    val blueChannel: FloatArray = FloatArray(256),
    val luminanceChannel: FloatArray = FloatArray(256)
)
