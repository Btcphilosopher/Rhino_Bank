package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect

@Composable
fun CameraGridOverlay(
    gridType: String,
    modifier: Modifier = Modifier
) {
    if (gridType == "关闭") return

    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val gridColor = Color.White.copy(alpha = 0.35f)
        val strokeWidth = 1.5f

        when (gridType) {
            "三分法" -> {
                // Vertical lines
                drawLine(gridColor, Offset(w / 3, 0f), Offset(w / 3, h), strokeWidth)
                drawLine(gridColor, Offset(w * 2 / 3, 0f), Offset(w * 2 / 3, h), strokeWidth)
                // Horizontal lines
                drawLine(gridColor, Offset(0f, h / 3), Offset(w, h / 3), strokeWidth)
                drawLine(gridColor, Offset(0f, h * 2 / 3), Offset(w, h * 2 / 3), strokeWidth)
            }
            "中心" -> {
                // Center crosshair
                drawLine(gridColor, Offset(w / 2, 0f), Offset(w / 2, h), strokeWidth)
                drawLine(gridColor, Offset(0f, h / 2), Offset(w, h / 2), strokeWidth)
                drawCircle(gridColor, radius = 24f, center = Offset(w / 2, h / 2), style = androidx.compose.ui.graphics.drawscope.Stroke(strokeWidth))
            }
            "对角线" -> {
                drawLine(gridColor, Offset(0f, 0f), Offset(w, h), strokeWidth)
                drawLine(gridColor, Offset(w, 0f), Offset(0f, h), strokeWidth)
            }
            "黄金分割" -> {
                val phi = 0.618f
                val invPhi = 1f - phi
                drawLine(gridColor, Offset(w * invPhi, 0f), Offset(w * invPhi, h), strokeWidth)
                drawLine(gridColor, Offset(w * phi, 0f), Offset(w * phi, h), strokeWidth)
                drawLine(gridColor, Offset(0f, h * invPhi), Offset(w, h * invPhi), strokeWidth)
                drawLine(gridColor, Offset(0f, h * phi), Offset(w, h * phi), strokeWidth)
            }
        }
    }
}
