package com.example.core.camera

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.os.Build
import android.util.Range
import com.example.domain.camera.CameraCapabilities
import com.example.domain.camera.Lens

class CameraCapabilitiesDetector(private val context: Context) {

    fun detectCapabilities(): CameraCapabilities {
        val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
            ?: return createFallbackCapabilities(isSimulated = true)

        try {
            val cameraIds = cameraManager.cameraIdList
            if (cameraIds.isEmpty()) {
                return createFallbackCapabilities(isSimulated = true)
            }

            var hasBack = false
            var hasFront = false
            val lenses = mutableListOf<Lens>()
            var minIso = 50
            var maxIso = 6400
            var minShutterNs = 125_000L // 1/8000s
            var maxShutterNs = 8_000_000_000L // 8s
            var minEv = -3
            var maxEv = 3
            var evStep = 0.33f
            var supportsRaw = false
            var supportsHdr = false
            var supportsOis = false
            var hwLevelStr = "LIMITED"

            for (id in cameraIds) {
                val chars = cameraManager.getCameraCharacteristics(id)
                val facing = chars.get(CameraCharacteristics.LENS_FACING)

                val hwLevel = chars.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)
                hwLevelStr = when (hwLevel) {
                    CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_3 -> "HARDWARE_LEVEL_3"
                    CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_FULL -> "FULL"
                    CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED -> "LIMITED"
                    else -> "LEGACY"
                }

                // Check ISO range
                val isoRange = chars.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
                if (isoRange != null) {
                    minIso = minOf(minIso, isoRange.lower)
                    maxIso = maxOf(maxIso, isoRange.upper)
                }

                // Check Shutter speed range
                val shutterRange = chars.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
                if (shutterRange != null) {
                    minShutterNs = minOf(minShutterNs, shutterRange.lower)
                    maxShutterNs = maxOf(maxShutterNs, shutterRange.upper)
                }

                // Exposure compensation
                val evRange = chars.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE)
                if (evRange != null) {
                    minEv = evRange.lower
                    maxEv = evRange.upper
                }
                val evStepRational = chars.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)
                if (evStepRational != null) {
                    evStep = evStepRational.toFloat()
                }

                // Capabilities
                val caps = chars.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: intArrayOf()
                if (caps.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_RAW)) {
                    supportsRaw = true
                }

                // Focal lengths & Lenses
                val focalLengths = chars.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS) ?: floatArrayOf(4.5f)
                val aperture = chars.get(CameraCharacteristics.LENS_INFO_AVAILABLE_APERTURES)?.firstOrNull() ?: 1.8f
                val primaryFocal = focalLengths.firstOrNull() ?: 4.5f

                if (facing == CameraCharacteristics.LENS_FACING_BACK) {
                    hasBack = true
                    if (lenses.none { it.typeName == "主摄" }) {
                        lenses.add(
                            Lens(
                                id = id,
                                name = "主摄 (1×)",
                                facing = "BACK",
                                focalLengthMm = primaryFocal,
                                aperture = aperture,
                                zoomRatio = 1.0f,
                                isPhysical = true,
                                typeName = "主摄"
                            )
                        )
                    }
                    // Check if physical focal length suggests ultra-wide or telephoto
                    if (focalLengths.size > 1) {
                        for (f in focalLengths) {
                            val ratio = f / primaryFocal
                            if (ratio < 0.8f && lenses.none { it.typeName == "超广角" }) {
                                lenses.add(
                                    Lens(
                                        id = id,
                                        name = "超广角 (0.5×)",
                                        facing = "BACK",
                                        focalLengthMm = f,
                                        aperture = aperture,
                                        zoomRatio = 0.5f,
                                        isPhysical = true,
                                        typeName = "超广角"
                                    )
                                )
                            } else if (ratio > 1.8f && lenses.none { it.typeName == "长焦" }) {
                                lenses.add(
                                    Lens(
                                        id = id,
                                        name = "长焦 (3×)",
                                        facing = "BACK",
                                        focalLengthMm = f,
                                        aperture = aperture,
                                        zoomRatio = 3.0f,
                                        isPhysical = true,
                                        typeName = "长焦"
                                    )
                                )
                            }
                        }
                    }
                } else if (facing == CameraCharacteristics.LENS_FACING_FRONT) {
                    hasFront = true
                    lenses.add(
                        Lens(
                            id = id,
                            name = "前置镜头 (1×)",
                            facing = "FRONT",
                            focalLengthMm = primaryFocal,
                            aperture = aperture,
                            zoomRatio = 1.0f,
                            isPhysical = true,
                            typeName = "前置"
                        )
                    )
                }
            }

            // Always add digital zoom options if only primary main camera exists
            if (lenses.none { it.zoomRatio == 2.0f }) {
                lenses.add(
                    Lens(
                        id = "digital_2x",
                        name = "混合变焦 (2×)",
                        facing = "BACK",
                        focalLengthMm = 52f,
                        aperture = 1.8f,
                        zoomRatio = 2.0f,
                        isPhysical = false,
                        typeName = "数字变焦"
                    )
                )
            }

            // OIS check
            val opticalStabilization = cameraManager.cameraIdList.any { id ->
                val c = cameraManager.getCameraCharacteristics(id)
                val oisModes = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)
                oisModes?.contains(CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON) == true
            }
            supportsOis = opticalStabilization

            return CameraCapabilities(
                cameraCount = cameraIds.size,
                hasBackCamera = hasBack,
                hasFrontCamera = hasFront,
                availableLenses = lenses.sortedBy { it.zoomRatio },
                isoRange = minIso..maxIso,
                shutterRangeNs = minShutterNs..maxShutterNs,
                exposureCompRange = minEv..maxEv,
                exposureCompStep = evStep,
                supportsRaw = supportsRaw,
                supportsHdr = true,
                supportsVideo4K = true,
                supportsSlowMotion = true,
                supportsOis = supportsOis,
                hardwareLevel = hwLevelStr,
                isSimulated = false
            )

        } catch (e: Exception) {
            return createFallbackCapabilities(isSimulated = true)
        }
    }

    private fun createFallbackCapabilities(isSimulated: Boolean): CameraCapabilities {
        val lenses = listOf(
            Lens("0", "超广角 (0.5×)", "BACK", 13f, 2.2f, 0.5f, true, "超广角"),
            Lens("1", "主摄 (1×)", "BACK", 24f, 1.8f, 1.0f, true, "主摄"),
            Lens("2", "长焦 (2×)", "BACK", 50f, 2.0f, 2.0f, true, "长焦"),
            Lens("3", "前置镜头 (1×)", "FRONT", 22f, 2.0f, 1.0f, true, "前置")
        )

        return CameraCapabilities(
            cameraCount = 2,
            hasBackCamera = true,
            hasFrontCamera = true,
            availableLenses = lenses,
            isoRange = 50..6400,
            shutterRangeNs = 125_000L..8_000_000_000L,
            exposureCompRange = -3..3,
            exposureCompStep = 0.33f,
            supportsRaw = true,
            supportsHdr = true,
            supportsVideo4K = true,
            supportsSlowMotion = true,
            supportsOis = true,
            hardwareLevel = "FULL",
            isSimulated = isSimulated
        )
    }
}
