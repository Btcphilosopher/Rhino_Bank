package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.core.camera.CameraController
import com.example.data.db.AppDatabase
import com.example.feature.camera.CameraMainScreen
import com.example.feature.editor.ProImageEditorScreen
import com.example.feature.gallery.GalleryScreen
import com.example.feature.permissions.PermissionFlowScreen
import com.example.feature.settings.CameraSettingsScreen
import com.example.ui.theme.GuangYingCameraTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var cameraController: CameraController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        cameraController = CameraController(this, this)
        val db = AppDatabase.getDatabase(this)

        setContent {
            GuangYingCameraTheme {
                val navController = rememberNavController()
                val photos by db.photoDao().getAllPhotos().collectAsState(initial = emptyList())
                val settings by cameraController.settings.collectAsState()
                val capabilities by cameraController.capabilities.collectAsState()

                val hasCameraPermission = ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.CAMERA
                ) == PackageManager.PERMISSION_GRANTED

                val startDestination = if (hasCameraPermission) "camera" else "permissions"

                NavHost(
                    navController = navController,
                    startDestination = startDestination,
                    modifier = Modifier.fillMaxSize()
                ) {
                    composable("permissions") {
                        PermissionFlowScreen(
                            onPermissionsGranted = {
                                navController.navigate("camera") {
                                    popUpTo("permissions") { inclusive = true }
                                }
                            }
                        )
                    }

                    composable("camera") {
                        CameraMainScreen(
                            controller = cameraController,
                            onOpenGallery = { navController.navigate("gallery") },
                            onOpenSettings = { navController.navigate("settings") }
                        )
                    }

                    composable("gallery") {
                        GalleryScreen(
                            photos = photos,
                            onBack = { navController.popBackStack() },
                            onEditPhoto = { photo ->
                                navController.navigate("editor/${photo.id}")
                            },
                            onDeletePhoto = { photo ->
                                lifecycleScope.launch {
                                    db.photoDao().deletePhotoById(photo.id)
                                }
                            },
                            onToggleFavorite = { photo ->
                                lifecycleScope.launch {
                                    db.photoDao().setFavorite(photo.id, !photo.isFavorite)
                                }
                            }
                        )
                    }

                    composable("editor/{photoId}") { backStackEntry ->
                        val photoId = backStackEntry.arguments?.getString("photoId")?.toLongOrNull() ?: 0L
                        val photo = photos.firstOrNull { it.id == photoId }

                        if (photo != null) {
                            ProImageEditorScreen(
                                photo = photo,
                                onBack = { navController.popBackStack() },
                                onSave = { editParams ->
                                    navController.popBackStack()
                                }
                            )
                        }
                    }

                    composable("settings") {
                        CameraSettingsScreen(
                            settings = settings,
                            capabilities = capabilities,
                            onSettingsChanged = { cameraController.updateSettings(it) },
                            onBack = { navController.popBackStack() }
                        )
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraController.release()
    }
}
