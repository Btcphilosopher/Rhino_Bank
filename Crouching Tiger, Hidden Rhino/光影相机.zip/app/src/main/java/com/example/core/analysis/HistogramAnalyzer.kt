package com.example.core.analysis

import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.example.domain.camera.HistogramData

class HistogramAnalyzer(private val onHistogramUpdated: (HistogramData) -> Unit) : ImageAnalysis.Analyzer {

    private var lastAnalyzedTime = 0L

    override fun analyze(image: ImageProxy) {
        val currentTime = System.currentTimeMillis()
        // Limit to 10 FPS to save CPU/GPU cycles
        if (currentTime - lastAnalyzedTime < 100) {
            image.close()
            return
        }
        lastAnalyzedTime = currentTime

        try {
            val planes = image.planes
            if (planes.isEmpty()) {
                image.close()
                return
            }

            val yBuffer = planes[0].buffer
            val yArray = ByteArray(yBuffer.remaining())
            yBuffer.get(yArray)

            val luminance = IntArray(256)
            val red = IntArray(256)
            val green = IntArray(256)
            val blue = IntArray(256)

            // Subsample pixels for speed (step = 16)
            val step = 16
            for (i in yArray.indices step step) {
                val y = yArray[i].toInt() and 0xFF
                luminance[y]++
                // Approximate RGB distribution from YUV plane
                red[y]++
                green[(y * 0.95f).toInt().coerceIn(0, 255)]++
                blue[(y * 1.05f).toInt().coerceIn(0, 255)]++
            }

            // Normalize counts to max 1.0f
            val maxL = (luminance.maxOrNull() ?: 1).toFloat().coerceAtLeast(1f)
            val maxR = (red.maxOrNull() ?: 1).toFloat().coerceAtLeast(1f)
            val maxG = (green.maxOrNull() ?: 1).toFloat().coerceAtLeast(1f)
            val maxB = (blue.maxOrNull() ?: 1).toFloat().coerceAtLeast(1f)

            val normL = FloatArray(256) { luminance[it] / maxL }
            val normR = FloatArray(256) { red[it] / maxR }
            val normG = FloatArray(256) { green[it] / maxG }
            val normB = FloatArray(256) { blue[it] / maxB }

            onHistogramUpdated(HistogramData(normR, normG, normB, normL))
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            image.close()
        }
    }
}
