package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.camera.Lens
import com.example.ui.theme.CameraAmber

@Composable
fun LensSelectorBar(
    availableLenses: List<Lens>,
    selectedLens: Lens?,
    onLensSelected: (Lens) -> Unit,
    modifier: Modifier = Modifier
) {
    if (availableLenses.isEmpty()) return

    Row(
        modifier = modifier
            .clip(CircleShape)
            .background(Color.Black.copy(alpha = 0.5f))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        availableLenses.forEach { lens ->
            val isSelected = selectedLens?.zoomRatio == lens.zoomRatio
            val zoomText = if (lens.zoomRatio < 1.0f) "0.5×" else "${lens.zoomRatio.toInt()}×"

            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(if (isSelected) CameraAmber else Color.Transparent)
                    .clickable { onLensSelected(lens) },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = zoomText,
                    color = if (isSelected) Color.Black else Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
