package com.example.ui.operations

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiAnalyticsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    var selectedPeriod by remember { mutableStateOf("7DAYS") } // "1DAY", "3DAYS", "7DAYS"
    
    // NLP Assistant States
    var selectedCopilotQuery by remember { mutableStateOf("") }
    var copilotResponse by remember { mutableStateOf("") }
    var isCopilotThinking by remember { mutableStateOf(false) }

    val scope = rememberCoroutineScope()

    val suggestedQuestions = listOf(
        "分析本周生鲜类目的销售异动情况",
        "预测明天台风暴雨天气哪些SKU会发生爆单",
        "自动生成明天上海浦东旗舰店的采购补货方案"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("🤖 AI 零售智能分析与预测决策", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = MaterialTheme.colorScheme.primary)
        Text("融合大语言模型 & 机器学习时间序列销量智能预测系统", fontSize = 11.sp, color = Color.Gray)

        Spacer(modifier = Modifier.height(16.dp))

        // 1. Demand Forecasting Block
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("📈 机器学习销量时间序列预测 (SARIMA)", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.Black)
                    Row {
                        TextButton(onClick = { selectedPeriod = "1DAY" }) { Text("1天", fontSize = 11.sp, color = if (selectedPeriod == "1DAY") MaterialTheme.colorScheme.primary else Color.Gray) }
                        TextButton(onClick = { selectedPeriod = "3DAYS" }) { Text("3天", fontSize = 11.sp, color = if (selectedPeriod == "3DAYS") MaterialTheme.colorScheme.primary else Color.Gray) }
                        TextButton(onClick = { selectedPeriod = "7DAYS" }) { Text("7天", fontSize = 11.sp, color = if (selectedPeriod == "7DAYS") MaterialTheme.colorScheme.primary else Color.Gray) }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Forecast parameters display
                val forecastData = when (selectedPeriod) {
                    "1DAY" -> listOf("伊利高钙纯牛奶" to "预测明天售出: 128件 (置信区间: 110-145)", "大别山走地土鸡蛋" to "预测明天售出: 85件 (置信区间: 75-95)", "波士顿大龙虾" to "预测明天售出: 24件 (置信区间: 18-30)")
                    "3DAYS" -> listOf("伊利高钙纯牛奶" to "预测3日内售出: 395件 (置信区间: 360-425)", "大别山走地土鸡蛋" to "预测3日内售出: 270件 (置信区间: 240-300)", "波士顿大龙虾" to "预测3日内售出: 78件 (置信区间: 65-90)")
                    else -> listOf("伊利高钙纯牛奶" to "预测7日内售出: 920件 (置信区间: 850-990)", "大别山走地土鸡蛋" to "预测7日内售出: 640件 (置信区间: 590-690)", "波士顿大龙虾" to "预测7日内售出: 190件 (置信区间: 160-220)")
                }

                forecastData.forEach { (sku, textVal) ->
                    Column(modifier = Modifier.padding(vertical = 6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(sku, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                            Text("置信度: 95 %", fontSize = 10.sp, color = Color(0xFF385723))
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(textVal, fontSize = 12.sp, color = Color.Gray)
                        Spacer(modifier = Modifier.height(6.dp))
                        HorizontalDivider(color = Color.LightGray.copy(alpha = 0.3f))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 2. Automated replenishment decisions based on forecasted shortages
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("🧠 智能供应链补货自动决策 (Replenishment Optimizer)", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.Black)
                Text("算法根据最近销量弹性及安全库存量自动测算采购批量", fontSize = 11.sp, color = Color.Gray)

                Spacer(modifier = Modifier.height(10.dp))

                val decisions = listOf(
                    Triple("MILK_001", "伊利纯牛奶 (当前库存: 48件)", "下周缺货预测: 126件 | 自动决策建议: 采购补货 150件 (入上海一号仓)"),
                    Triple("EGG_001", "走地土鸡蛋 (当前库存: 14件)", "下周缺货预测: 85件 | 自动决策建议: 采购补货 100件 (入张江高科店)")
                )

                decisions.forEach { (sku, current, suggest) ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .background(Color(0xFFFAF9F6), RoundedCornerShape(4.dp))
                            .border(1.dp, Color.LightGray.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                            .padding(10.dp)
                    ) {
                        Text("SKU编码: $sku | $current", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(suggest, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 3. Natural Language Retail Assistant (NLP Copilot)
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.SmartButton, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("💬 智脑大零售 AI 运营助手 NLP Copilot", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.Black)
                }
                Text("点击下方常见运营大盘分析问题，立即运行大模型检索回复", fontSize = 11.sp, color = Color.Gray)

                Spacer(modifier = Modifier.height(12.dp))

                // Suggestion chips
                suggestedQuestions.forEach { question ->
                    val isSelected = selectedCopilotQuery == question
                    Surface(
                        color = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.1f) else Color(0xFFF1F3F5),
                        shape = RoundedCornerShape(16.dp),
                        border = if (isSelected) BorderStroke(1.dp, MaterialTheme.colorScheme.primary) else null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable {
                                selectedCopilotQuery = question
                                isCopilotThinking = true
                                // Query MainViewModel.askNlpCopilot logic
                                val answer = viewModel.askNlpCopilot(question)
                                copilotResponse = answer
                                isCopilotThinking = false
                            }
                    ) {
                        Text(
                            text = question,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (isSelected) MaterialTheme.colorScheme.primary else Color.DarkGray,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }

                if (isCopilotThinking) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("AI 正在关联全渠道库内与大宗气象模型数据分析中...", fontSize = 12.sp, color = Color.Gray)
                    }
                } else if (copilotResponse.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Surface(
                        color = Color(0xFFE8F5E9),
                        shape = RoundedCornerShape(6.dp),
                        border = BorderStroke(1.dp, Color(0xFF8CD898))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("云市 AI 运营助理决策报告", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = copilotResponse,
                                fontSize = 12.sp,
                                color = Color.Black,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(24.dp))
    }
}
