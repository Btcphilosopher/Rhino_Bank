package com.example.ui.consumer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Product
import com.example.data.Store
import com.example.ui.MainViewModel
import kotlinx.coroutines.flow.firstOrNull

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductDetailScreen(
    productId: String,
    viewModel: MainViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val productsList by viewModel.allProducts.collectAsState(initial = emptyList())
    val selectedStore by viewModel.selectedStore.collectAsState()
    val storesList by viewModel.stores.collectAsState(initial = emptyList())
    
    val product = productsList.find { it.productId == productId }
    var currentStoreStock by remember { mutableStateOf<Int?>(null) }
    
    // Store-by-store inventory mapping
    var allStoreStocks by remember { mutableStateOf<Map<String, Int>>(emptyMap()) }

    LaunchedEffect(productId, selectedStore, storesList) {
        if (product != null) {
            val inv = viewModel.repository.getInventory(selectedStore?.storeId ?: "", product.productId)
            currentStoreStock = inv?.getAvailable()

            val stocksMap = mutableMapOf<String, Int>()
            storesList.forEach { s ->
                val sInv = viewModel.repository.getInventory(s.storeId, product.productId)
                stocksMap[s.storeId] = sInv?.getAvailable() ?: 0
            }
            allStoreStocks = stocksMap
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("商品详情", fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("detail_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        },
        bottomBar = {
            if (product != null) {
                Surface(
                    tonalElevation = 8.dp,
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .navigationBarsPadding()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Current store stock display
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "当前门店: " + (selectedStore?.name?.replace("云市", "") ?: ""),
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                            val stock = currentStoreStock ?: 0
                            Text(
                                text = if (stock > 0) "库存充足 (余 ${stock} 件)" else "当前门店暂无库存",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (stock > 0) MaterialTheme.colorScheme.primary else Color.Red
                            )
                        }

                        // Add to cart main CTA
                        val stock = currentStoreStock ?: 0
                        Button(
                            onClick = { viewModel.addToCart(product.productId) },
                            enabled = stock > 0,
                            shape = RoundedCornerShape(24.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = Color.White
                            ),
                            modifier = Modifier
                                .height(48.dp)
                                .weight(1.2f)
                                .testTag("detail_add_to_cart")
                        ) {
                            Icon(Icons.Default.AddShoppingCart, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("加入购物车", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        if (product == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background)
                    .verticalScroll(rememberScrollState())
            ) {
                // 1. High contrast product photo mockup container
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(260.dp)
                        .background(Color(0xFFF0F2F5))
                ) {
                    Icon(
                        imageVector = when (product.category) {
                            "肉禽蛋奶" -> Icons.Default.Favorite
                            "生鲜水果" -> Icons.Default.Star
                            "粮油调味" -> Icons.Default.Home
                            "零食饮料" -> Icons.Default.Info
                            "酒水" -> Icons.Default.Star
                            "家清" -> Icons.Default.Check
                            "个护" -> Icons.Default.Face
                            "母婴" -> Icons.Default.Person
                            "宠物" -> Icons.Default.Favorite
                            else -> Icons.Default.ShoppingCart
                        },
                        contentDescription = null,
                        modifier = Modifier
                            .size(100.dp)
                            .align(Alignment.Center),
                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                    )

                    // Origin Badge
                    Surface(
                        color = Color.Black.copy(alpha = 0.6f),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "✈️ 源头直采: " + product.origin,
                            color = Color.White,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                // 2. Main details card
                Card(
                    shape = RoundedCornerShape(0.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "【${product.brand}】",
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Text(
                                text = product.name,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 18.sp,
                                color = Color.Black
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "规格规格: ${product.specification} / ${product.unit}",
                            fontSize = 13.sp,
                            color = Color.Gray
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Price Row
                        Row(
                            verticalAlignment = Alignment.Bottom,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                Text("会员价", fontSize = 11.sp, color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.Bold)
                                Text(
                                    text = "¥" + product.memberPrice,
                                    fontSize = 26.sp,
                                    fontWeight = FontWeight.Black,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }

                            Column(modifier = Modifier.padding(bottom = 2.dp)) {
                                Text("原价", fontSize = 11.sp, color = Color.Gray)
                                Text(
                                    text = "¥" + product.price,
                                    fontSize = 14.sp,
                                    color = Color.Gray,
                                    style = androidx.compose.ui.text.TextStyle(
                                        textDecoration = androidx.compose.ui.text.style.TextDecoration.LineThrough
                                    )
                                )
                            }

                            // Difference savings badge
                            Surface(
                                color = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier.padding(bottom = 4.dp)
                            ) {
                                Text(
                                    text = "省 ¥" + String.format("%.2f", product.price - product.memberPrice),
                                    color = MaterialTheme.colorScheme.tertiary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        HorizontalDivider(color = Color.LightGray.copy(alpha = 0.5f))
                        Spacer(modifier = Modifier.height(12.dp))

                        // Delivery features row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.ElectricBolt, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("最快30分钟送达", fontSize = 12.sp, color = Color.Black)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("支持到店自提", fontSize = 12.sp, color = Color.Black)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.AcUnit, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(product.storageCondition, fontSize = 12.sp, color = Color.Black)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // 3. Chain Stores Inventory Check (No random numbers, fully fetched from InventoryEngine!)
                Card(
                    shape = RoundedCornerShape(0.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "🏬 连锁门店实时库存",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color.Black
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        // Highlight three specific mock scenarios
                        // 1. 上海浦东店: 充足
                        // 2. 上海陆家嘴店: 12
                        // 3. 上海世纪大道店: 0
                        storesList.take(4).forEach { store ->
                            val stock = allStoreStocks[store.storeId] ?: 0
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = store.name.replace("云市", ""),
                                    fontSize = 13.sp,
                                    color = Color.Black
                                )
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "最快 ${store.deliveryTimeMinutes} 分钟",
                                        fontSize = 11.sp,
                                        color = Color.Gray
                                    )
                                    Surface(
                                        color = when {
                                            stock == 0 -> Color(0xFFFCE4E4)
                                            stock < 15 -> Color(0xFFFFF2CC)
                                            else -> Color(0xFFE2F0D9)
                                        },
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = when {
                                                stock == 0 -> "无货"
                                                stock < 15 -> "${stock} 件"
                                                else -> "充足"
                                            },
                                            color = when {
                                                stock == 0 -> Color(0xFFC00000)
                                                stock < 15 -> Color(0xFF7F6000)
                                                else -> Color(0xFF385723)
                                            },
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                            HorizontalDivider(color = Color.LightGray.copy(alpha = 0.3f))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // 4. Product Spec Specification Chart
                Card(
                    shape = RoundedCornerShape(0.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "📝 商品参数说明",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color.Black
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        val specRows = listOf(
                            "商品条码" to product.barcode,
                            "生产厂商" to product.supplier,
                            "保质期" to "${product.shelfLifeDays} 天",
                            "存储要求" to product.storageCondition,
                            "发货基地" to product.origin,
                            "品类类别" to "${product.category} > ${product.subCategory}"
                        )

                        specRows.forEach { (label, valText) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp)
                            ) {
                                Text(
                                    text = label,
                                    fontSize = 12.sp,
                                    color = Color.Gray,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = valText,
                                    fontSize = 12.sp,
                                    color = Color.Black,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.weight(2f)
                                )
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}
