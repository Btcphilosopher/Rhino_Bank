package com.example.data

import android.content.Context
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Repository(private val db: AppDatabase) {

    val stores: Flow<List<Store>> = db.storeDao().getAllStores()
    val products: Flow<List<Product>> = db.productDao().getAllProducts()
    val coupons: Flow<List<Coupon>> = db.couponDao().getAllCoupons()
    val memberProfile: Flow<MemberProfile?> = db.memberDao().getMemberProfile()
    val pointsLedger: Flow<List<PointsLedger>> = db.pointsLedgerDao().getPointsLedger()
    val orders: Flow<List<Order>> = db.orderDao().getAllOrders()
    val cartItems: Flow<List<CartItem>> = db.cartDao().getCartItems()
    val purchaseOrders: Flow<List<PurchaseOrder>> = db.purchaseOrderDao().getAllPurchaseOrders()
    val coldChainTelemetry: Flow<List<ColdChainTelemetry>> = db.coldChainDao().getColdChainTelemetry()
    val batchTraceability: Flow<List<BatchTraceability>> = db.batchTraceabilityDao().getAllBatches()
    val inventoryMovements: Flow<List<InventoryMovement>> = db.inventoryMovementDao().getAllMovements()

    suspend fun getStoreById(id: String): Store? = db.storeDao().getStoreById(id)
    suspend fun getProductById(id: String): Product? = db.productDao().getProductById(id)
    fun searchProducts(query: String): Flow<List<Product>> = db.productDao().searchProducts(query)
    fun getProductsByCategory(category: String): Flow<List<Product>> = db.productDao().getProductsByCategory(category)

    fun getInventoryForStore(storeId: String): Flow<List<Inventory>> = db.inventoryDao().getInventoryForStore(storeId)
    suspend fun getInventory(storeId: String, productId: String): Inventory? = db.inventoryDao().getInventory(storeId, productId)
    fun getInventoryFlow(storeId: String, productId: String): Flow<Inventory?> = db.inventoryDao().getInventoryFlow(storeId, productId)

    suspend fun updateInventory(inventory: Inventory) = db.inventoryDao().updateInventory(inventory)
    suspend fun insertMovement(movement: InventoryMovement) = db.inventoryMovementDao().insertMovement(movement)

    // Ledger-based inventory adjustment
    suspend fun adjustInventory(storeId: String, productId: String, type: String, qtyChange: Int, remark: String) {
        val inv = db.inventoryDao().getInventory(storeId, productId)
        if (inv != null) {
            val updatedOnHand = (inv.onHand + qtyChange).coerceAtLeast(0)
            db.inventoryDao().updateInventory(inv.copy(onHand = updatedOnHand))
            db.inventoryMovementDao().insertMovement(
                InventoryMovement(
                    storeId = storeId,
                    productId = productId,
                    type = type,
                    quantity = qtyChange,
                    timestamp = System.currentTimeMillis(),
                    remarks = remark
                )
            )
        }
    }

    suspend fun reserveInventory(storeId: String, productId: String, qty: Int): Boolean {
        val inv = db.inventoryDao().getInventory(storeId, productId) ?: return false
        if (inv.getAvailable() >= qty) {
            db.inventoryDao().updateInventory(inv.copy(reserved = inv.reserved + qty))
            return true
        }
        return false
    }

    suspend fun releaseReservedInventory(storeId: String, productId: String, qty: Int) {
        val inv = db.inventoryDao().getInventory(storeId, productId) ?: return
        val updatedReserved = (inv.reserved - qty).coerceAtLeast(0)
        db.inventoryDao().updateInventory(inv.copy(reserved = updatedReserved))
    }

    suspend fun deductInventory(storeId: String, productId: String, qty: Int, type: String = "线上销售") {
        val inv = db.inventoryDao().getInventory(storeId, productId) ?: return
        val updatedReserved = (inv.reserved - qty).coerceAtLeast(0)
        val updatedOnHand = (inv.onHand - qty).coerceAtLeast(0)
        db.inventoryDao().updateInventory(inv.copy(onHand = updatedOnHand, reserved = updatedReserved))
        db.inventoryMovementDao().insertMovement(
            InventoryMovement(
                storeId = storeId,
                productId = productId,
                type = type,
                quantity = -qty,
                timestamp = System.currentTimeMillis(),
                remarks = "订单出库"
            )
        )
    }

    // Points Ledger update
    suspend fun adjustPoints(memberId: String, orderId: String, type: String, amount: Int, reason: String) {
        val profile = db.memberDao().getMemberProfile().firstOrNull() ?: return
        val newPoints = if (type == "获取") profile.points + amount else (profile.points - amount).coerceAtLeast(0)
        val newGrowth = if (type == "获取") profile.growthValue + (amount / 10) else profile.growthValue
        
        val newTier = when {
            newGrowth >= 5000 -> "钻石会员"
            newGrowth >= 2000 -> "黄金会员"
            else -> "普通会员"
        }

        db.memberDao().updateMemberProfile(profile.copy(points = newPoints, growthValue = newGrowth, tier = newTier))
        db.pointsLedgerDao().insertLedger(
            PointsLedger(
                memberId = memberId,
                orderId = orderId,
                type = type,
                amount = amount,
                timestamp = System.currentTimeMillis(),
                balance = newPoints,
                reason = reason
            )
        )
    }

    suspend fun getMemberByPhone(phone: String): MemberProfile? {
        return db.memberDao().getMemberProfile().firstOrNull()
    }

    suspend fun updateMemberPoints(memberId: String, newPoints: Int) {
        val profile = db.memberDao().getMemberProfile().firstOrNull() ?: return
        db.memberDao().updateMemberProfile(profile.copy(points = newPoints))
    }

    // Cart operations
    suspend fun addCartItem(productId: String, storeId: String, qty: Int) {
        db.cartDao().insertCartItem(CartItem(productId, storeId, qty))
    }

    suspend fun removeCartItem(productId: String) {
        db.cartDao().deleteCartItem(productId)
    }

    suspend fun clearCart() {
        db.cartDao().clearCart()
    }

    // Order operations
    suspend fun createOrder(order: Order, items: List<OrderItem>) {
        db.orderDao().insertOrder(order)
        db.orderDao().insertOrderItems(items)
    }

    suspend fun updateOrderStatus(orderId: String, status: String) {
        db.orderDao().updateOrderStatus(orderId, status)
    }

    suspend fun getOrderById(orderId: String): Order? = db.orderDao().getOrderById(orderId)
    suspend fun getOrderItems(orderId: String): List<OrderItem> = db.orderDao().getOrderItems(orderId)
    fun getOrderItemsFlow(orderId: String): Flow<List<OrderItem>> = db.orderDao().getOrderItemsFlow(orderId)

    suspend fun getSafetyStockBreaches(storeId: String, limit: Int): List<Inventory> {
        val list = db.inventoryDao().getInventoryForStore(storeId).firstOrNull() ?: emptyList()
        return list.filter { it.getAvailable() < it.safetyStock }.take(limit)
    }

    suspend fun replenishInventory(storeId: String, productId: String, quantity: Int) {
        val inv = db.inventoryDao().getInventory(storeId, productId)
        if (inv != null) {
            val updatedOnHand = inv.onHand + quantity
            db.inventoryDao().updateInventory(inv.copy(onHand = updatedOnHand))
            db.inventoryMovementDao().insertMovement(
                InventoryMovement(
                    storeId = storeId,
                    productId = productId,
                    type = "采购入库",
                    quantity = quantity,
                    timestamp = System.currentTimeMillis(),
                    remarks = "一键自动补仓"
                )
            )
        }
    }

    // Supplier & Purchase
    suspend fun updatePurchaseOrderStatus(poId: String, status: String) {
        val pos = db.purchaseOrderDao().getAllPurchaseOrders().firstOrNull() ?: return
        val target = pos.find { it.poId == poId } ?: return
        db.purchaseOrderDao().updatePurchaseOrder(target.copy(status = status))
    }

    suspend fun addColdChainLog(telemetry: ColdChainTelemetry) {
        db.coldChainDao().insertTelemetry(telemetry)
    }

    // Initialize mock data (Seeding)
    suspend fun seedMockData() {
        // Only seed if empty
        val existingStores = db.storeDao().getAllStores().firstOrNull()
        if (existingStores != null && existingStores.isNotEmpty()) return

        // 1. Seed 20 Stores (Shanghai location mapping)
        val mockStores = listOf(
            Store("STORE_SH_PD", "云市上海浦东店", "上海市浦东新区张杨路3611号", 31.2397, 121.5476, true, true, 30, "车位500个，凭消费小票免费停车2小时", "08:00-22:00", "消费满38元免费停车"),
            Store("STORE_SH_LJZ", "云市上海陆家嘴店", "上海市浦东新区世纪大道8号", 31.2358, 121.5012, true, true, 30, "车位300个，停车15元/小时", "09:00-22:30", "消费满199元免1小时"),
            Store("STORE_SH_SJD", "云市上海世纪大道店", "上海市浦东新区世纪大道1192号", 31.2294, 121.5255, true, true, 35, "车位800个，停车10元/小时", "08:00-22:00", "消费满88元免1小时"),
            Store("STORE_SH_ZJ", "云市上海张江店", "上海市浦东新区祖冲之路1239号", 31.2035, 121.5985, true, true, 35, "车位400个，免费停车", "08:00-21:30", "全天免费"),
            Store("STORE_SH_XJH", "云市上海徐家汇店", "上海市徐汇区虹桥路1号", 31.1942, 121.4367, true, true, 40, "车位600个", "08:00-22:00", "消费满100免2小时"),
            Store("STORE_SH_HP", "云市上海黄浦店", "上海市黄浦区南京东路300号", 31.2415, 121.4839, true, true, 45, "极度紧张", "09:00-22:00", "无免费"),
            Store("STORE_SH_JA", "云市上海静安店", "上海市静安区南京西路1618号", 31.2246, 121.4468, true, true, 40, "车位200个", "08:00-22:00", "无免费"),
            Store("STORE_SH_YP", "云市上海杨浦店", "上海市杨浦区控江路1628号", 31.2718, 121.5262, true, true, 35, "车位400个", "08:00-22:00", "消费满50元免2小时"),
            Store("STORE_SH_PT", "云市上海普陀店", "上海市普陀区长寿路189号", 31.2428, 121.4348, true, true, 35, "车位350个", "08:00-22:00", "消费满58元免2小时"),
            Store("STORE_SH_HK", "云市上海虹口店", "上海市虹口区西江湾路388号", 31.2689, 121.4795, true, true, 30, "车位500个", "08:00-22:00", "消费满88元免2小时"),
            Store("STORE_SH_MH", "云市上海闵行店", "上海市闵行区沪闵路6088号", 31.1118, 121.3814, true, true, 40, "车位1000个", "08:00-22:00", "停车5元/小时"),
            Store("STORE_SH_BS", "云市上海宝山店", "上海市宝山区同济路999号", 31.3912, 121.4812, true, true, 45, "车位800个", "08:00-21:30", "消费满30元免2小时"),
            Store("STORE_SH_JD", "云市上海嘉定店", "上海市嘉定区墨玉南路1000号", 31.2825, 121.1614, true, true, 50, "车位1200个", "08:00-21:30", "免费停车"),
            Store("STORE_SH_PD_WD", "云市上海川沙店", "上海市浦东新区川沙路5555号", 31.1895, 121.6985, true, true, 35, "车位600个", "08:00-22:00", "消费满50元免3小时"),
            Store("STORE_SH_SJ", "云市上海松江店", "上海市松江区新松江路927号", 31.0375, 121.2295, true, true, 45, "车位900个", "08:00-22:00", "免费停车"),
            Store("STORE_SH_QP", "云市上海青浦店", "上海市青浦区公园路100号", 31.1495, 121.1214, true, true, 45, "车位700个", "08:00-22:00", "免费停车"),
            Store("STORE_SH_FX", "云市上海奉贤店", "上海市奉贤区百齐路588号", 30.9168, 121.4595, true, true, 50, "车位1000个", "08:00-21:30", "免费停车"),
            Store("STORE_SH_JS", "云市上海金山店", "上海市金山区龙皓路1088号", 30.7412, 121.3395, true, true, 50, "车位800个", "08:00-21:30", "免费停车"),
            Store("STORE_SH_CM", "云市上海崇明店", "上海市崇明区城桥镇崇明大道8388号", 31.6212, 121.4012, true, true, 55, "车位500个", "08:00-21:30", "免费停车"),
            Store("STORE_SH_NH", "云市上海南汇店", "上海市浦东新区惠南镇人民东路1号", 31.0512, 121.7585, true, true, 40, "车位400个", "08:00-21:30", "消费满38免2小时")
        )
        db.storeDao().insertStores(mockStores)

        // 2. Seed 30+ Products (representing 10 categories)
        val mockProducts = listOf(
            // 肉禽蛋奶
            Product("MILK_001", "6901021300018", "伊利纯牛奶 250ml × 24", "伊利", "肉禽蛋奶", "纯牛奶", "250ml × 24", "箱", "内蒙古呼和浩特", "内蒙古伊利实业集团", 180, "常温", 69.90, 62.90, "https://api.dujin.org/bing/1366.php"),
            Product("MILK_002", "6901021300025", "蒙牛特仑苏纯牛奶 250ml × 12", "蒙牛", "肉禽蛋奶", "纯牛奶", "250ml × 12", "箱", "内蒙古呼和浩特", "内蒙古蒙牛乳业集团", 180, "常温", 55.00, 49.90, "https://api.dujin.org/bing/1366.php"),
            Product("MILK_003", "6901021300032", "光明优倍鲜牛奶 950ml", "光明", "肉禽蛋奶", "低温奶", "950ml", "瓶", "上海", "光明乳业股份有限公司", 7, "冷藏 2-6℃", 15.90, 13.90, "https://api.dujin.org/bing/1366.php"),
            Product("EGG_001", "6901021300049", "农家土鸡蛋 30枚盒装", "云市精选", "肉禽蛋奶", "蛋品", "30枚装 约1.5kg", "盒", "山东德州", "山东益生源生态农业", 30, "常温或冷藏", 29.90, 24.90, "https://api.dujin.org/bing/1366.php"),
            Product("MEAT_001", "6901021300056", "冷鲜五花肉 500g", "壹号土猪", "肉禽蛋奶", "猪肉", "500g", "包", "广东湛江", "广东壹号食品股份有限公司", 3, "冷藏 0-4℃", 28.80, 25.80, "https://api.dujin.org/bing/1366.php"),
            
            // 生鲜水果
            Product("FRUIT_001", "6902021300017", "阿克苏红富士苹果 1.5kg", "云市农场", "生鲜水果", "苹果", "1.5kg/箱", "箱", "新疆阿克苏", "新疆果业集团", 15, "常温", 22.90, 18.90, "https://api.dujin.org/bing/1366.php"),
            Product("FRUIT_002", "6902021300024", "佳沛新西兰金奇异果 6粒装", "Zespri", "生鲜水果", "奇异果", "6粒装 (单果约100g)", "盒", "新西兰", "佳沛新西兰奇异果国际", 14, "冷藏 2-6℃", 39.90, 34.90, "https://api.dujin.org/bing/1366.php"),
            Product("VEG_001", "6902021300031", "精选高山娃娃菜 3棵装", "源头直采", "生鲜水果", "叶菜", "3棵 约600g", "包", "云南昆明", "云南惠农蔬菜基地", 5, "冷藏 2-6℃", 5.90, 4.90, "https://api.dujin.org/bing/1366.php"),
            Product("SEAFOOD_001", "6902021300048", "鲜活阳澄湖大闸蟹 4只礼盒", "云市渔场", "生鲜水果", "水产", "公蟹150g*2/母蟹120g*2", "盒", "江苏苏州", "苏州蟹王阁水产养殖", 7, "冷藏或充氧", 138.00, 118.00, "https://api.dujin.org/bing/1366.php"),
            
            // 粮油调味
            Product("OIL_001", "6903021300016", "金龙鱼特香纯花生油 5L", "金龙鱼", "粮油调味", "食用油", "5L/瓶", "瓶", "山东青岛", "益海嘉里粮油食品", 540, "阴凉干燥", 139.90, 129.90, "https://api.dujin.org/bing/1366.php"),
            Product("RICE_001", "6903021300023", "柴火大院五常大米 5kg", "柴火大院", "粮油调味", "大米", "5kg/袋", "袋", "黑龙江五常", "黑龙江五常市大米集团", 365, "干燥防潮", 79.90, 69.90, "https://api.dujin.org/bing/1366.php"),
            Product("SAUCE_001", "6903021300030", "海天味极鲜特级生抽 1.9L", "海天", "粮油调味", "调味品", "1.9L/瓶", "瓶", "广东佛山", "佛山海天调味食品", 540, "常温", 19.90, 17.50, "https://api.dujin.org/bing/1366.php"),
            
            // 零食饮料
            Product("SNACK_001", "6904021300015", "乐事薯片无限组合装 104g*3", "乐事", "零食饮料", "薯片", "312g (104g*3罐)", "组", "上海", "百事食品(中国)有限公司", 300, "常温", 24.90, 21.90, "https://api.dujin.org/bing/1366.php"),
            Product("DRINK_001", "6904021300022", "农夫山泉饮用天然水 550ml*24", "农夫山泉", "零食饮料", "水", "550ml × 24", "箱", "浙江千岛湖", "农夫山泉股份有限公司", 720, "常温防晒", 33.60, 28.80, "https://api.dujin.org/bing/1366.php"),
            Product("DRINK_002", "6904021300039", "可口可乐汽水 330ml × 24", "可口可乐", "零食饮料", "碳酸饮料", "330ml × 24", "箱", "上海", "上海申美饮料食品", 365, "常温避免冷冻", 45.00, 39.90, "https://api.dujin.org/bing/1366.php"),
            
            // 酒水
            Product("WINE_001", "6905021300014", "青岛啤酒经典拉格 500ml*12听", "青岛啤酒", "酒水", "啤酒", "500ml × 12", "箱", "山东青岛", "青岛啤酒股份有限公司", 365, "常温防暴晒", 65.00, 59.90, "https://api.dujin.org/bing/1366.php"),
            Product("WINE_002", "6905021300021", "53度飞天茅台 500ml 单瓶装", "茅台", "酒水", "白酒", "500ml", "瓶", "贵州遵义", "贵州茅台酒股份有限公司", 9999, "避光阴凉", 2999.00, 2899.00, "https://api.dujin.org/bing/1366.php"),
            
            // 家清纸品
            Product("CLEAN_001", "6906021300013", "威露士除菌洗衣液 4kg", "威露士", "家清", "衣物洗护", "3kg装+1kg补充袋", "组", "广东广州", "威莱(广州)日化有限公司", 1095, "避光常温", 69.90, 55.90, "https://api.dujin.org/bing/1366.php"),
            Product("CLEAN_002", "6906021300020", "清风卷纸原木纯品三层 10卷", "清风", "家清", "生活用纸", "3层*10卷/提", "提", "江苏苏州", "金红叶纸业集团", 1095, "干燥防潮", 19.90, 16.90, "https://api.dujin.org/bing/1366.php"),
            
            // 个人护理
            Product("CARE_001", "6907021300012", "海飞丝去屑洗发露 750ml", "海飞丝", "个护", "洗发沐浴", "750ml", "瓶", "广州", "宝洁(中国)有限公司", 1095, "常温", 54.90, 48.90, "https://api.dujin.org/bing/1366.php"),
            Product("CARE_002", "6907021300029", "黑人双重薄荷牙膏 140g*2", "DARLIE", "个护", "口腔护理", "140g × 2双支装", "盒", "广东中山", "好来化工(中山)有限公司", 1095, "常温", 22.90, 19.90, "https://api.dujin.org/bing/1366.php"),
            
            // 母婴
            Product("BABY_001", "6908021300011", "帮宝适一级帮纸尿裤 L52片", "Pampers", "母婴", "婴童用品", "L码 52片", "包", "广州", "宝洁(中国)有限公司", 1095, "干燥防潮", 119.00, 99.00, "https://api.dujin.org/bing/1366.php"),
            Product("BABY_002", "6908021300028", "飞鹤星飞帆三段幼儿奶粉 900g", "飞鹤", "母婴", "婴童食品", "900g", "罐", "黑龙江齐齐哈尔", "黑龙江飞鹤乳业有限公司", 730, "阴凉干燥", 328.00, 298.00, "https://api.dujin.org/bing/1366.php"),
            
            // 家居
            Product("HOME_001", "6909021300010", "云市超柔全棉情侣毛巾 2条装", "无印良品", "家居", "针织家纺", "2条 70cm*34cm", "包", "山东潍坊", "潍坊棉业纺织集团", 1095, "干燥通风", 29.90, 25.90, "https://api.dujin.org/bing/1366.php"),
            Product("HOME_002", "6909021300027", "双枪天然防霉无漆整竹砧板", "双枪", "家居", "厨房用具", "40cm*30cm*2cm", "个", "浙江丽水", "双枪科技股份有限公司", 1095, "常温悬挂", 49.00, 39.90, "https://api.dujin.org/bing/1366.php"),
            
            // 宠物
            Product("PET_001", "6910021300019", "皇家成犬期全价粮 2kg", "Royal Canin", "宠物", "宠物主粮", "2kg/袋", "袋", "上海", "皇誉宠物食品(上海)", 540, "密封阴凉", 139.00, 129.00, "https://api.dujin.org/bing/1366.php"),
            Product("PET_002", "6910021300026", "麦富迪猫用冻干鸡肉粒零食 100g", "麦富迪", "宠物", "宠物零食", "100g/罐", "罐", "山东聊城", "乖宝宠物食品集团", 540, "常温", 19.90, 16.90, "https://api.dujin.org/bing/1366.php")
        )
        db.productDao().insertProducts(mockProducts)

        // 3. Seed Inventory for ALL 20 stores and ALL Products
        val inventories = mutableListOf<Inventory>()
        mockStores.forEach { store ->
            mockProducts.forEach { product ->
                // Create unique behavior for special cases mentioned in prompt:
                // 上海浦东店: MILK_003 (光明鲜牛奶) -> 充足 (e.g. 150)
                // 上海陆家嘴店: MILK_003 (光明鲜牛奶) -> 12
                // 上海世纪大道店: MILK_003 (光明鲜牛奶) -> 0
                val onHand = when {
                    store.storeId == "STORE_SH_SJD" && product.productId == "MILK_003" -> 0
                    store.storeId == "STORE_SH_LJZ" && product.productId == "MILK_003" -> 12
                    store.storeId == "STORE_SH_PD" && product.productId == "MILK_003" -> 180
                    store.storeId == "STORE_SH_PD" -> (100..400).random()
                    else -> (0..200).random() // generic random inventory for other stores to look extremely realistic
                }
                
                inventories.add(
                    Inventory(
                        key = "${store.storeId}_${product.productId}",
                        storeId = store.storeId,
                        productId = product.productId,
                        onHand = onHand,
                        reserved = 0,
                        damaged = if (onHand > 10 && (1..100).random() > 95) (1..3).random() else 0,
                        safetyStock = 15
                    )
                )
            }
        }
        db.inventoryDao().insertInventory(inventories)

        // 4. Seed Member Profile
        db.memberDao().insertMemberProfile(
            MemberProfile("M_001", "云市会员", "普通会员", 2840, 1820)
        )

        // 5. Points Ledger history
        val sf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.SIMPLIFIED_CHINESE)
        db.pointsLedgerDao().insertLedger(PointsLedger(memberId = "M_001", orderId = "CM00001", type = "获取", amount = 300, timestamp = System.currentTimeMillis() - 86400000, balance = 2840, reason = "线上超市消费赠送"))
        db.pointsLedgerDao().insertLedger(PointsLedger(memberId = "M_001", orderId = "CM00002", type = "获取", amount = 150, timestamp = System.currentTimeMillis() - 172800000, balance = 2540, reason = "门店扫码消费赠送"))
        db.pointsLedgerDao().insertLedger(PointsLedger(memberId = "M_001", orderId = "CM00003", type = "获取", amount = 500, timestamp = System.currentTimeMillis() - 360000000, balance = 2390, reason = "会员注册赠送"))

        // 6. Seed Coupons (满减券, 折扣券, 新人券, 配送券, 会员券)
        val initialCoupons = listOf(
            Coupon("CPN_59_10", "满59减10 专享券", "满减券", 10.0, 59.0, "适用于本门店所有常规商品（满59元可用）", false),
            Coupon("CPN_99_15", "满99减15 超级优惠", "满减券", 15.0, 99.0, "适用于生鲜、零食全品类满99元可用", false),
            Coupon("CPN_199_30", "满199减30 囤货券", "满减券", 30.0, 199.0, "满199元大额囤货专属满减券", false),
            Coupon("CPN_DISC_9", "云市全品九折券", "折扣券", 0.9, 0.0, "全场品类享9折优惠（封顶优惠20元）", false),
            Coupon("CPN_DELI", "首单免运费券", "配送券", 5.0, 0.0, "即时配送订单免运费专属券", false),
            Coupon("CPN_NEW", "新人专享券 满30减5", "满减券", 5.0, 30.0, "云市新注册用户专享（满30元可用）", false),
            Coupon("CPN_MEMBER", "会员日专享 85折券", "折扣券", 0.85, 0.0, "钻石/黄金会员专享日85折券", false)
        )
        db.couponDao().insertCoupons(initialCoupons)

        // 7. Seed Supply Chain & Purchase Orders
        val poList = listOf(
            PurchaseOrder("PO_2026_0901", "上海食品供应有限公司", "伊利纯牛奶 250ml × 24", 5000, "已下单", "明天 08:00", "2026-09-17"),
            PurchaseOrder("PO_2026_0902", "新疆果业直供基地", "阿克苏红富士苹果 1.5kg", 2000, "运输中", "明天 10:00", "2026-09-18"),
            PurchaseOrder("PO_2026_0903", "江苏苏州阳澄湖水产基地", "鲜活阳澄湖大闸蟹 4只礼盒", 500, "已送达", "今天 06:00", "2026-09-18"),
            PurchaseOrder("PO_2026_0904", "益海嘉里粮油青岛加工厂", "金龙鱼特香纯花生油 5L", 1500, "已入库", "已完成", "2026-09-16")
        )
        db.purchaseOrderDao().insertPurchaseOrders(poList)

        // 8. Seed Batch Traceability for低温冷链
        val batchList = listOf(
            BatchTraceability("BATCH_20260918_MILK", "6901021300032", "光明优倍鲜牛奶 950ml", "光明乳业金山牧场", "上海1号冷链中转仓", "云市上海浦东店", "2026-09-17"),
            BatchTraceability("BATCH_20260918_CRAB", "6902021300048", "鲜活阳澄湖大闸蟹 4只礼盒", "江苏阳澄湖5号生态网箱", "昆山分拣仓", "云市上海浦东店", "2026-09-18"),
            BatchTraceability("BATCH_20260918_EGG", "6901021300049", "农家土鸡蛋 30枚盒装", "山东德州恒温育蛋园", "南京区域配送中心", "云市上海浦东店", "2026-09-15")
        )
        db.batchTraceabilityDao().insertBatches(batchList)

        // 9. Seed Cold Chain Telemetry
        val timeNow = System.currentTimeMillis()
        db.coldChainDao().insertTelemetry(ColdChainTelemetry(orderId = "MOCK_ORDER_01", temperature = 3.6, humidity = 65.0, timestamp = timeNow - 300000, isAlert = false))
        db.coldChainDao().insertTelemetry(ColdChainTelemetry(orderId = "MOCK_ORDER_01", temperature = 4.2, humidity = 68.0, timestamp = timeNow - 150000, isAlert = false))
        db.coldChainDao().insertTelemetry(ColdChainTelemetry(orderId = "MOCK_ORDER_01", temperature = 7.1, humidity = 72.0, timestamp = timeNow - 50000, isAlert = true)) // Temperature anomaly warning

        // 10. Seed completed historical orders to populate operations KPI charts on load
        val order1Id = "CM" + System.currentTimeMillis().toString().takeLast(8) + "1"
        val order2Id = "CM" + System.currentTimeMillis().toString().takeLast(8) + "2"
        db.orderDao().insertOrder(
            Order(
                orderId = order1Id,
                storeId = "STORE_SH_PD",
                storeName = "云市上海浦东店",
                status = "COMPLETED",
                orderType = "DELIVERY",
                deliveryAddress = "上海市浦东新区张江高科中科路128号",
                originalAmount = 111.70,
                discountAmount = 10.00,
                couponAmount = 10.00,
                pointsDiscountAmount = 0.00,
                finalPayable = 91.70,
                paymentMethod = "微信支付",
                timestamp = System.currentTimeMillis() - 7200000,
                riderName = "王小哥",
                riderPhone = "13812345678"
            )
        )
        db.orderDao().insertOrderItems(
            listOf(
                OrderItem(orderId = order1Id, productId = "MILK_003", name = "光明优倍鲜牛奶 950ml", price = 15.90, quantity = 2, imageUrl = "https://api.dujin.org/bing/1366.php"),
                OrderItem(orderId = order1Id, productId = "FRUIT_002", name = "佳沛新西兰金奇异果 6粒装", price = 39.90, quantity = 2, imageUrl = "https://api.dujin.org/bing/1366.php")
            )
        )

        db.orderDao().insertOrder(
            Order(
                orderId = order2Id,
                storeId = "STORE_SH_PD",
                storeName = "云市上海浦东店",
                status = "COMPLETED",
                orderType = "PICKUP",
                deliveryAddress = "到店自提",
                originalAmount = 45.00,
                discountAmount = 5.10,
                couponAmount = 0.00,
                pointsDiscountAmount = 0.00,
                finalPayable = 39.90,
                paymentMethod = "云市余额",
                timestamp = System.currentTimeMillis() - 3600000,
                riderName = "自提备货员",
                riderPhone = "店内自提"
            )
        )
        db.orderDao().insertOrderItems(
            listOf(
                OrderItem(orderId = order2Id, productId = "DRINK_002", name = "可口可乐汽水 330ml × 24", price = 45.00, quantity = 1, imageUrl = "https://api.dujin.org/bing/1366.php")
            )
        )
    }
}
