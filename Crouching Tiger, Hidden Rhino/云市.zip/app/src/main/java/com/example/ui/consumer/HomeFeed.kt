package com.example.ui.consumer

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Product
import com.example.data.Store
import com.example.ui.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeFeedScreen(
    viewModel: MainViewModel,
    onNavigateToProduct: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val selectedStore by viewModel.selectedStore.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val productsList by viewModel.allProducts.collectAsState(initial = emptyList())
    val storesList by viewModel.stores.collectAsState(initial = emptyList())
    
    val weather by viewModel.mockWeather.collectAsState()
    val timeOfDay by viewModel.mockTimeOfDay.collectAsState()

    var showStoreSelector by remember { mutableStateOf(false) }

    val categories = listOf("全部", "生鲜水果", "肉禽蛋奶", "粮油调味", "零食饮料", "酒水", "家清", "个护", "母婴", "家居", "宠物")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // 1. Top Location Header & Weather Indicator
        Surface(
            tonalElevation = 4.dp,
            color = MaterialTheme.colorScheme.primary,
            contentColor = Color.White,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clickable { showStoreSelector = true }
                            .testTag("store_selector")
                    ) {
                        Icon(
                            Icons.Default.Storefront,
                            contentDescription = "门店选择",
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text(
                                text = selectedStore?.name ?: "选择门店",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.widthIn(max = 200.dp)
                            )
                            Text(
                                text = "📍 " + (selectedStore?.address?.substringBefore("号") ?: "正在定位...") + "号",
                                fontSize = 11.sp,
                                color = Color.White.copy(alpha = 0.8f)
                            )
                        }
                        Icon(
                            Icons.Default.ArrowDropDown,
                            contentDescription = "下拉",
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    // Weather Indicator
                    Surface(
                        color = Color.White.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.clickable {
                            // Toggle weather simulator for interactive feel!
                            viewModel.mockWeather.value = if (weather.contains("晴朗")) "台风大暴雨 22℃" else "晴朗 26℃"
                        }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                if (weather.contains("大雨")) Icons.Default.Cloud else Icons.Default.Star,
                                contentDescription = "天气",
                                modifier = Modifier.size(14.dp),
                                tint = Color.White
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = weather,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color.White
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Search Bar with test tags
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.updateSearchQuery(it) },
                    placeholder = { Text("搜索商品、品牌、分类或拼音...", color = Color.Gray, fontSize = 14.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "搜索", tint = Color.Gray) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                                Icon(Icons.Default.Close, contentDescription = "清除", tint = Color.Gray)
                            }
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent,
                        focusedTextColor = Color.Black,
                        unfocusedTextColor = Color.Black
                    ),
                    shape = RoundedCornerShape(24.dp),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("search_input")
                )
            }
        }

        // 2. Category LazyRow Selection Bar
        Surface(
            tonalElevation = 2.dp,
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(categories) { cat ->
                    val isSelected = cat == selectedCategory
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.selectCategory(cat) },
                        label = { Text(cat) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }
        }

        // 3. Main Scrollable Products Feed Grid
        val processedProducts = viewModel.getFilteredProducts(productsList)
        val homeFeedProducts = if (searchQuery.isEmpty() && selectedCategory == "全部") {
            viewModel.getDynamicHomeFeed(processedProducts)
        } else {
            processedProducts
        }

        Box(modifier = Modifier.weight(1.0f)) {
            if (homeFeedProducts.isEmpty()) {
                // Empty state
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        Icons.Default.ProductionQuantityLimits,
                        contentDescription = "暂无商品",
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "未找到符合条件的商品",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "支持拼音模糊搜索 (如 niunai -> 牛奶) 且当前所选门店必须有货",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    // Flash Promotion Card (Only when no search/filter)
                    if (searchQuery.isEmpty() && selectedCategory == "全部") {
                        item(span = { GridItemSpan(2) }) {
                            PromoFlashBanner(weather, timeOfDay)
                        }
                        item(span = { GridItemSpan(2) }) {
                            Text(
                                text = "今日精选特惠",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(start = 4.dp, top = 8.dp, bottom = 4.dp)
                            )
                        }
                    }

                    items(homeFeedProducts) { product ->
                        ProductGridItem(
                            product = product,
                            viewModel = viewModel,
                            onItemClick = { onNavigateToProduct(product.productId) }
                        )
                    }
                }
            }

            // Store selection popup sheet
            if (showStoreSelector) {
                StoreSelectionDialog(
                    stores = storesList,
                    currentStore = selectedStore,
                    onSelect = {
                        viewModel.selectStore(it)
                        showStoreSelector = false
                    },
                    onDismiss = { showStoreSelector = false }
                )
            }
        }
    }
}

@Composable
fun PromoFlashBanner(weather: String, time: String) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondary),
        modifier = Modifier
            .fillMaxWidth()
            .height(110.dp)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .align(Alignment.CenterStart)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "⚡ 限时特惠秒杀",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.tertiary,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = if (weather.contains("大雨")) "暴雨即时达" else "30分钟达",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (weather.contains("大雨")) "☔ 外出不便？云市专属冷链配送，风雨无阻！" else "新鲜直达：伊利纯牛奶/土鸡蛋满59元立减10元",
                    color = Color.White.copy(alpha = 0.9f),
                    fontSize = 12.sp
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductGridItem(
    product: Product,
    viewModel: MainViewModel,
    onItemClick: () -> Unit
) {
    val selectedStore by viewModel.selectedStore.collectAsState()
    var storeInventory by remember { mutableStateOf<Int?>(null) }

    // Query inventory reactively
    LaunchedEffect(selectedStore, product) {
        val inv = viewModel.repository.getInventory(selectedStore?.storeId ?: "", product.productId)
        storeInventory = inv?.getAvailable()
    }

    Card(
        onClick = onItemClick,
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("product_item_${product.productId}")
    ) {
        Column {
            // Placeholder Image using compose drawBehind for consistent, high-contrast supermarket mockup
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .background(Color(0xFFF0F2F5))
            ) {
                // Category icon overlay
                Icon(
                    imageVector = when (product.category) {
                        "肉禽蛋奶" -> Icons.Default.Favorite
                        "生鲜水果" -> Icons.Default.Star
                        "粮油调味" -> Icons.Default.Home
                        "零食饮料" -> Icons.Default.Info
                        "酒水" -> Icons.Default.Star
                        "家清" -> Icons.Default.Check
                        "个护" -> Icons.Default.Face
                        "母婴" -> Icons.Default.Person
                        "宠物" -> Icons.Default.Favorite
                        else -> Icons.Default.ShoppingCart
                    },
                    contentDescription = null,
                    modifier = Modifier
                        .size(48.dp)
                        .align(Alignment.Center),
                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)
                )

                // High member discount tag
                if (product.price - product.memberPrice >= 5.0) {
                    Surface(
                        color = MaterialTheme.colorScheme.tertiary,
                        shape = RoundedCornerShape(topStart = 8.dp, bottomEnd = 8.dp),
                        modifier = Modifier.align(Alignment.TopStart)
                    ) {
                        Text(
                            text = "会员特惠",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            Column(modifier = Modifier.padding(8.dp)) {
                Text(
                    text = product.name,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = Color.Black
                )
                Text(
                    text = "规格: ${product.specification}",
                    fontSize = 11.sp,
                    color = Color.Gray,
                    modifier = Modifier.padding(top = 2.dp)
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Price display (Member vs Original)
                Row(
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "¥${product.memberPrice}",
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "原价 ¥${product.price}",
                        color = Color.Gray,
                        fontSize = 11.sp,
                        style = androidx.compose.ui.text.TextStyle(
                            textDecoration = androidx.compose.ui.text.style.TextDecoration.LineThrough
                        )
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Stock indicator
                    val stock = storeInventory ?: 0
                    Surface(
                        color = when {
                            stock == 0 -> Color(0xFFFCE4E4)
                            stock < 15 -> Color(0xFFFFF2CC)
                            else -> Color(0xFFE2F0D9)
                        },
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = when {
                                stock == 0 -> "无货"
                                stock < 15 -> "仅剩 ${stock} 件"
                                else -> "库存充足"
                            },
                            color = when {
                                stock == 0 -> Color(0xFFC00000)
                                stock < 15 -> Color(0xFF7F6000)
                                else -> Color(0xFF385723)
                            },
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    // Add to cart button
                    IconButton(
                        onClick = { viewModel.addToCart(product.productId) },
                        enabled = stock > 0,
                        colors = IconButtonDefaults.iconButtonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = Color.White,
                            disabledContainerColor = Color.LightGray,
                            disabledContentColor = Color.White
                        ),
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("add_to_cart_btn_${product.productId}")
                    ) {
                        Icon(
                            Icons.Default.AddShoppingCart,
                            contentDescription = "加入购物车",
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun StoreSelectionDialog(
    stores: List<Store>,
    currentStore: Store?,
    onSelect: (Store) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("选择服务门店", fontWeight = FontWeight.Bold, fontSize = 18.sp) },
        text = {
            Column(modifier = Modifier.heightIn(max = 350.dp).verticalScroll(rememberScrollState())) {
                stores.forEach { store ->
                    val isSelected = store.storeId == currentStore?.storeId
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelect(store) }
                            .padding(vertical = 12.dp, horizontal = 4.dp)
                            .background(if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else Color.Transparent)
                    ) {
                        RadioButton(
                            selected = isSelected,
                            onClick = { onSelect(store) }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = store.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Black
                            )
                            Text(
                                text = store.address,
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                            Row(
                                modifier = Modifier.padding(top = 2.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "⚡ 最快 ${store.deliveryTimeMinutes} 分钟送达",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = "🚗 停车: " + store.parkingFree,
                                    fontSize = 10.sp,
                                    color = Color.Gray
                                )
                            }
                        }
                    }
                    HorizontalDivider(color = Color.LightGray.copy(alpha = 0.3f))
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("关闭")
            }
        }
    )
}
