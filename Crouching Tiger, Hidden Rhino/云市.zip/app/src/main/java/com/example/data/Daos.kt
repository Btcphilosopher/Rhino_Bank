package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface StoreDao {
    @Query("SELECT * FROM stores")
    fun getAllStores(): Flow<List<Store>>

    @Query("SELECT * FROM stores WHERE storeId = :storeId")
    suspend fun getStoreById(storeId: String): Store?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStores(stores: List<Store>)
}

@Dao
interface ProductDao {
    @Query("SELECT * FROM products")
    fun getAllProducts(): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE productId = :productId")
    suspend fun getProductById(productId: String): Product?

    @Query("SELECT * FROM products WHERE name LIKE '%' || :query || '%' OR brand LIKE '%' || :query || '%' OR category LIKE '%' || :query || '%' OR barcode = :query")
    fun searchProducts(query: String): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE category = :category")
    fun getProductsByCategory(category: String): Flow<List<Product>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProducts(products: List<Product>)
}

@Dao
interface InventoryDao {
    @Query("SELECT * FROM inventory WHERE storeId = :storeId")
    fun getInventoryForStore(storeId: String): Flow<List<Inventory>>

    @Query("SELECT * FROM inventory WHERE storeId = :storeId AND productId = :productId")
    suspend fun getInventory(storeId: String, productId: String): Inventory?

    @Query("SELECT * FROM inventory WHERE storeId = :storeId AND productId = :productId")
    fun getInventoryFlow(storeId: String, productId: String): Flow<Inventory?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInventory(inventories: List<Inventory>)

    @Update
    suspend fun updateInventory(inventory: Inventory)
}

@Dao
interface InventoryMovementDao {
    @Query("SELECT * FROM inventory_movements ORDER BY timestamp DESC")
    fun getAllMovements(): Flow<List<InventoryMovement>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMovement(movement: InventoryMovement)
}

@Dao
interface CouponDao {
    @Query("SELECT * FROM coupons")
    fun getAllCoupons(): Flow<List<Coupon>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCoupons(coupons: List<Coupon>)

    @Update
    suspend fun updateCoupon(coupon: Coupon)
}

@Dao
interface MemberDao {
    @Query("SELECT * FROM member_profile LIMIT 1")
    fun getMemberProfile(): Flow<MemberProfile?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemberProfile(profile: MemberProfile)

    @Update
    suspend fun updateMemberProfile(profile: MemberProfile)
}

@Dao
interface PointsLedgerDao {
    @Query("SELECT * FROM points_ledger ORDER BY timestamp DESC")
    fun getPointsLedger(): Flow<List<PointsLedger>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLedger(ledger: PointsLedger)
}

@Dao
interface OrderDao {
    @Query("SELECT * FROM orders ORDER BY timestamp DESC")
    fun getAllOrders(): Flow<List<Order>>

    @Query("SELECT * FROM orders WHERE orderId = :orderId")
    suspend fun getOrderById(orderId: String): Order?

    @Query("SELECT * FROM order_items WHERE orderId = :orderId")
    suspend fun getOrderItems(orderId: String): List<OrderItem>

    @Query("SELECT * FROM order_items WHERE orderId = :orderId")
    fun getOrderItemsFlow(orderId: String): Flow<List<OrderItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: Order)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrderItems(items: List<OrderItem>)

    @Query("UPDATE orders SET status = :status WHERE orderId = :orderId")
    suspend fun updateOrderStatus(orderId: String, status: String)
}

@Dao
interface CartDao {
    @Query("SELECT * FROM cart_items")
    fun getCartItems(): Flow<List<CartItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCartItem(cartItem: CartItem)

    @Query("DELETE FROM cart_items WHERE productId = :productId")
    suspend fun deleteCartItem(productId: String)

    @Query("DELETE FROM cart_items")
    suspend fun clearCart()
}

@Dao
interface PurchaseOrderDao {
    @Query("SELECT * FROM purchase_orders ORDER BY date DESC")
    fun getAllPurchaseOrders(): Flow<List<PurchaseOrder>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPurchaseOrders(pos: List<PurchaseOrder>)

    @Update
    suspend fun updatePurchaseOrder(po: PurchaseOrder)
}

@Dao
interface ColdChainDao {
    @Query("SELECT * FROM cold_chain_telemetry ORDER BY timestamp DESC")
    fun getColdChainTelemetry(): Flow<List<ColdChainTelemetry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTelemetry(telemetry: ColdChainTelemetry)
}

@Dao
interface BatchTraceabilityDao {
    @Query("SELECT * FROM batch_traceability")
    fun getAllBatches(): Flow<List<BatchTraceability>>

    @Query("SELECT * FROM batch_traceability WHERE barcode = :barcode LIMIT 1")
    suspend fun getBatchByBarcode(barcode: String): BatchTraceability?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBatches(batches: List<BatchTraceability>)
}
