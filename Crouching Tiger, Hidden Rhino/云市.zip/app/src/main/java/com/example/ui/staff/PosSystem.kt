package com.example.ui.staff

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MemberProfile
import com.example.data.Order
import com.example.data.OrderItem
import com.example.data.Product
import com.example.ui.MainViewModel
import com.example.ui.consumer.ReceiptDialog
import androidx.compose.foundation.BorderStroke
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun PosSystemScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val productsList by viewModel.allProducts.collectAsState(initial = emptyList())
    val selectedStore by viewModel.selectedStore.collectAsState()

    var scanBarcodeQuery by remember { mutableStateOf("") }
    var memberPhoneQuery by remember { mutableStateOf("") }
    var activeMember by remember { mutableStateOf<MemberProfile?>(null) }
    
    val scope = rememberCoroutineScope()
    
    var posItemsList by remember { mutableStateOf<List<com.example.ui.PosItem>>(emptyList()) }
    var suspendedBillItems by remember { mutableStateOf<List<com.example.ui.PosItem>?>(null) } // Bill Suspend (挂单/取单)

    val billTotal = posItemsList.sumOf {
        val price = if (activeMember != null) it.product.memberPrice else it.product.price
        price * it.qty
    }
    
    var showPosReceipt by remember { mutableStateOf(false) }
    var createdReceiptOrder by remember { mutableStateOf<Order?>(null) }
    var createdReceiptItems by remember { mutableStateOf<List<OrderItem>>(emptyList()) }

    Row(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF4F6F9))
    ) {
        // LEFT PANE: Cashier Operations Input Panel (60% width)
        Column(
            modifier = Modifier
                .weight(1.2f)
                .fillMaxHeight()
                .border(border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f)))
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text("⌨️ 物理收银员 POS 输入控制终端", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.secondary)
            Spacer(modifier = Modifier.height(12.dp))

            // 1. Member Lookup Box
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("🔍 顾客数字化会员卡检索", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Black)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = memberPhoneQuery,
                            onValueChange = { memberPhoneQuery = it },
                            placeholder = { Text("输入会员手机号 (如 13800001111)", fontSize = 12.sp) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(focusedContainerColor = Color.White),
                            modifier = Modifier.weight(1.5f).height(48.dp)
                        )

                        Button(
                            onClick = {
                                scope.launch {
                                    val member = viewModel.repository.getMemberByPhone(memberPhoneQuery)
                                    activeMember = member
                                }
                            },
                            modifier = Modifier.weight(0.7f).height(40.dp)
                        ) {
                            Text("查询会员", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (activeMember != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(8.dp).fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("会员姓名: " + activeMember!!.name + " | 级别: " + activeMember!!.tier, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                    Text("当前账户积数: " + activeMember!!.points + " 积分", fontSize = 11.sp, color = Color.Gray)
                                }
                                IconButton(
                                    onClick = {
                                        activeMember = null
                                        memberPhoneQuery = ""
                                    },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = "注销会员", tint = Color.Red, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 2. Barcode Scanning Panel
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("🏷️ 商品条形码红外录入 (模拟键盘)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Black)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = scanBarcodeQuery,
                            onValueChange = { scanBarcodeQuery = it },
                            placeholder = { Text("输入 SKU 编码 (如 MILK_001)", fontSize = 12.sp) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(focusedContainerColor = Color.White),
                            modifier = Modifier.weight(1.5f).height(48.dp)
                        )

                        Button(
                            onClick = {
                                val product = productsList.find { it.productId == scanBarcodeQuery.trim() }
                                if (product != null) {
                                    val current = posItemsList.toMutableList()
                                    val existing = current.find { it.product.productId == product.productId }
                                    if (existing != null) {
                                        posItemsList = current.map { if (it.product.productId == product.productId) it.copy(qty = it.qty + 1) else it }
                                    } else {
                                        current.add(com.example.ui.PosItem(product, 1))
                                        posItemsList = current
                                    }
                                    scanBarcodeQuery = ""
                                }
                            },
                            modifier = Modifier.weight(0.7f).height(40.dp)
                        ) {
                            Text("扫码录入", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 3. Quick Tap Categorized SKU Grid
            Text("⌨️ 快餐/散装商品一键录入键盘", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Black)
            Spacer(modifier = Modifier.height(6.dp))
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                maxItemsInEachRow = 3,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                productsList.take(6).forEach { product ->
                    Surface(
                        color = Color.White,
                        shape = RoundedCornerShape(4.dp),
                        border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f)),
                        modifier = Modifier
                            .padding(bottom = 6.dp)
                            .width(105.dp)
                            .clickable {
                                val current = posItemsList.toMutableList()
                                val existing = current.find { it.product.productId == product.productId }
                                if (existing != null) {
                                    posItemsList = current.map { if (it.product.productId == product.productId) it.copy(qty = it.qty + 1) else it }
                                } else {
                                    current.add(com.example.ui.PosItem(product, 1))
                                    posItemsList = current
                                }
                            }
                    ) {
                        Column(
                            modifier = Modifier.padding(6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(product.name, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color.Black)
                            Text("¥" + product.price, fontSize = 9.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 4. Suspend/Resume Bill buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        if (posItemsList.isNotEmpty()) {
                            suspendedBillItems = posItemsList
                            posItemsList = emptyList()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("暂挂账单 (挂单)", fontSize = 11.sp)
                }

                Button(
                    onClick = {
                        if (suspendedBillItems != null) {
                            posItemsList = suspendedBillItems!!
                            suspendedBillItems = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                    enabled = suspendedBillItems != null,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("恢复账单 (取单)", fontSize = 11.sp)
                }
            }
        }

        // RIGHT PANE: Registered Cart Grid & Settlement (40% width)
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .background(Color.White)
                .padding(16.dp)
        ) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("🛒 结账商品栏 (共 ${posItemsList.sumOf { it.qty }} 件)", fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, color = Color.Black)
                TextButton(onClick = { posItemsList = emptyList() }) {
                    Text("整单清", color = Color.Red, fontSize = 12.sp)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Cart Table Viewport
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .border(1.dp, Color.LightGray.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                    .verticalScroll(rememberScrollState())
            ) {
                if (posItemsList.isEmpty()) {
                    Text(
                        "无扫描商品，请从左侧录入。",
                        fontSize = 12.sp,
                        color = Color.LightGray,
                        modifier = Modifier
                            .align(Alignment.Center)
                            .padding(16.dp),
                        textAlign = TextAlign.Center
                    )
                } else {
                    Column {
                        posItemsList.forEachIndexed { i, item ->
                            val activePrice = if (activeMember != null) item.product.memberPrice else item.product.price
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 10.dp, horizontal = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1.2f)) {
                                    Text(item.product.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                                    Text("SKU: " + item.product.productId, fontSize = 10.sp, color = Color.Gray, fontFamily = FontFamily.Monospace)
                                }
                                Row(
                                    modifier = Modifier.weight(1f),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("x${item.qty}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                                    Text("¥" + String.format("%.2f", activePrice), fontSize = 11.sp, color = Color.Gray)
                                    Text("¥" + String.format("%.2f", activePrice * item.qty), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                }
                                IconButton(
                                    onClick = { posItemsList = posItemsList.filter { it.product.productId != item.product.productId } },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Default.DeleteOutline, contentDescription = "删", tint = Color.Red, modifier = Modifier.size(16.dp))
                                }
                            }
                            HorizontalDivider(color = Color.LightGray.copy(alpha = 0.2f))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // POS Bill calculation summary
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("账单总额:", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                Text("¥" + String.format("%.2f", billTotal), fontSize = 24.sp, fontWeight = FontWeight.Black, color = Color.Red)
            }

            if (activeMember != null) {
                val normalTotal = posItemsList.sumOf { it.product.price * it.qty }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("会员已省:", fontSize = 11.sp, color = MaterialTheme.colorScheme.tertiary)
                    Text("¥" + String.format("%.2f", normalTotal - billTotal), fontSize = 11.sp, color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Print Receipt settlement action
            Button(
                onClick = {
                    if (posItemsList.isNotEmpty()) {
                        scope.launch {
                            val store = selectedStore ?: return@launch
                            val orderId = "POS" + System.currentTimeMillis().toString().takeLast(6)
                            val order = Order(
                                orderId = orderId,
                                storeId = store.storeId,
                                storeName = store.name,
                                status = "COMPLETED",
                                orderType = "PICKUP",
                                deliveryAddress = "线下门店15号收银柜台",
                                originalAmount = billTotal,
                                discountAmount = 0.0,
                                couponAmount = 0.0,
                                pointsDiscountAmount = 0.0,
                                finalPayable = billTotal,
                                paymentMethod = "现金/刷脸POS",
                                timestamp = System.currentTimeMillis(),
                                riderName = "物理收银台",
                                riderPhone = "收银工号#992"
                            )
                            val orderItems = posItemsList.map {
                                OrderItem(orderId = orderId, productId = it.product.productId, name = it.product.name, price = if (activeMember != null) it.product.memberPrice else it.product.price, quantity = it.qty, imageUrl = it.product.imageUrl)
                            }
                            viewModel.repository.createOrder(order, orderItems)

                            // Deduct inventory
                            for (item in posItemsList) {
                                viewModel.repository.deductInventory(store.storeId, item.product.productId, item.qty)
                            }

                            // Accumulate points if member exists
                            if (activeMember != null) {
                                val gainedPoints = (billTotal * 1.0).toInt()
                                viewModel.repository.updateMemberPoints(activeMember!!.memberId, activeMember!!.points + gainedPoints)
                            }

                            createdReceiptOrder = order
                            createdReceiptItems = orderItems
                            showPosReceipt = true
                            
                            // Reset POS state
                            posItemsList = emptyList()
                            activeMember = null
                            memberPhoneQuery = ""
                        }
                    }
                },
                enabled = posItemsList.isNotEmpty(),
                shape = RoundedCornerShape(24.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                Icon(Icons.Default.Print, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("确认付款并打印小票", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        }
    }

    if (showPosReceipt && createdReceiptOrder != null) {
        ReceiptDialog(
            order = createdReceiptOrder!!,
            items = createdReceiptItems,
            onDismiss = { showPosReceipt = false }
        )
    }
}
