package com.example.ui.staff

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Order
import com.example.data.OrderItem
import com.example.ui.MainViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StaffConsoleScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    var selectedStaffTab by remember { mutableStateOf("PICKER") } // "PICKER", "RIDER", "SELF_CHECKOUT"
    val ordersList by viewModel.orders.collectAsState(initial = emptyList())

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top role selection tab
        TabRow(
            selectedTabIndex = when (selectedStaffTab) {
                "PICKER" -> 0
                "RIDER" -> 1
                else -> 2
            },
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.primary
        ) {
            Tab(
                selected = selectedStaffTab == "PICKER",
                onClick = { selectedStaffTab = "PICKER" },
                text = { Text("拣货专员", fontSize = 13.sp, fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.Inventory, contentDescription = null) }
            )
            Tab(
                selected = selectedStaffTab == "RIDER",
                onClick = { selectedStaffTab = "RIDER" },
                text = { Text("派送骑手", fontSize = 13.sp, fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.Moped, contentDescription = null) }
            )
            Tab(
                selected = selectedStaffTab == "SELF_CHECKOUT",
                onClick = { selectedStaffTab = "SELF_CHECKOUT" },
                text = { Text("自助收银", fontSize = 13.sp, fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.QrCodeScanner, contentDescription = null) }
            )
        }

        Box(modifier = Modifier.weight(1f)) {
            when (selectedStaffTab) {
                "PICKER" -> PickerWorkspace(ordersList, viewModel)
                "RIDER" -> RiderWorkspace(ordersList, viewModel)
                "SELF_CHECKOUT" -> SelfCheckoutWorkspace(viewModel)
            }
        }
    }
}

@Composable
fun PickerWorkspace(orders: List<Order>, viewModel: MainViewModel) {
    val pickingOrder = orders.find { it.status == "PAID" || it.status == "PICKING" || it.status == "CONFIRMED" }
    var orderItems by remember { mutableStateOf<List<OrderItem>>(emptyList()) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(pickingOrder) {
        if (pickingOrder != null) {
            orderItems = viewModel.repository.getOrderItems(pickingOrder.orderId)
        }
    }

    if (pickingOrder == null) {
        Column(
            modifier = Modifier.fillMaxSize().padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(Icons.Default.CheckCircleOutline, contentDescription = null, modifier = Modifier.size(64.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(16.dp))
            Text("当前暂无待拣货订单", fontWeight = FontWeight.Bold, color = Color.Gray)
            Text("系统正处于待命状态...", fontSize = 12.sp, color = Color.LightGray)
        }
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Task info card
            Card(
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("📦 新任务待拣货", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("订单号: ${pickingOrder.orderId}", fontSize = 11.sp, color = Color.Gray, fontFamily = FontFamily.Monospace)
                    Text("拣选策略: 【最优拣货动线优化已启用】", fontSize = 12.sp, color = Color(0xFF385723), fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // AI optimized picking routing diagram
            Text("🧭 系统规划拣货线路图", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Black)
            Card(
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFAF9F6)),
                border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("1. 乳品冷藏区 (Aisle A)", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = Color.Black)
                        Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(12.dp))
                        Text("2. 保鲜生鲜区 (Aisle B)", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = Color.Black)
                        Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(12.dp))
                        Text("3. 出货复核台 (Aisle Z)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Picking Items Checklist
            Text("🛒 拣货清单 (共 ${orderItems.sumOf { it.quantity }} 件)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Black)
            Spacer(modifier = Modifier.height(6.dp))

            orderItems.forEach { item ->
                var isChecked by remember { mutableStateOf(false) }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                        .background(if (isChecked) Color(0xFFE2F0D9) else Color.White, RoundedCornerShape(4.dp))
                        .border(1.dp, Color.LightGray.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                        .clickable { isChecked = !isChecked }
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = isChecked, onCheckedChange = { isChecked = it })
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(item.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Black)
                            Text("货架位: " + when {
                                item.name.contains("奶") -> "A区-冷柜03"
                                item.name.contains("果") || item.name.contains("蟹") -> "B区-生鲜岛08"
                                else -> "C区-干货架12"
                            }, fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                    Text("x ${item.quantity}", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = {
                        scope.launch {
                            viewModel.repository.updateOrderStatus(pickingOrder.orderId, "PICKING")
                        }
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                ) {
                    Text("开始拣货", fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        scope.launch {
                            viewModel.repository.updateOrderStatus(pickingOrder.orderId, "PACKED")
                        }
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text("拣货完毕并打包", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun RiderWorkspace(orders: List<Order>, viewModel: MainViewModel) {
    val deliveryOrder = orders.find { it.status == "PACKED" || it.status == "ASSIGNED_TO_RIDER" || it.status == "OUT_FOR_DELIVERY" }
    var orderItems by remember { mutableStateOf<List<OrderItem>>(emptyList()) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(deliveryOrder) {
        if (deliveryOrder != null) {
            orderItems = viewModel.repository.getOrderItems(deliveryOrder.orderId)
        }
    }

    if (deliveryOrder == null) {
        Column(
            modifier = Modifier.fillMaxSize().padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(Icons.Default.Moped, contentDescription = null, modifier = Modifier.size(64.dp), tint = Color.LightGray)
            Spacer(modifier = Modifier.height(16.dp))
            Text("当前暂无待派送订单", fontWeight = FontWeight.Bold, color = Color.Gray)
            Text("等待拣货专员打包完毕...", fontSize = 12.sp, color = Color.LightGray)
        }
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Card(
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("🛵 待抢/指派配送订单", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.tertiary)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("订单号: ${deliveryOrder.orderId}", fontSize = 11.sp, color = Color.Gray, fontFamily = FontFamily.Monospace)
                    Text("配送费收益: ¥5.00", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Shipping Address details
            Card(
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("🏠 收货人信息", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Black)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("送达地址: " + deliveryOrder.deliveryAddress, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color.Black)
                    Text("派送备注: 请放保温箱。冷链生鲜乳制品怕热，请配送及时！", fontSize = 11.sp, color = Color.Red)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Item brief specs
            Text("📦 配送包裹内容", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Black)
            Column(modifier = Modifier.padding(vertical = 4.dp)) {
                orderItems.forEach { item ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(item.name, fontSize = 12.sp, color = Color.Black)
                        Text("x ${item.quantity}", fontSize = 12.sp, color = Color.Gray)
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = {
                        scope.launch {
                            viewModel.repository.updateOrderStatus(deliveryOrder.orderId, "OUT_FOR_DELIVERY")
                        }
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                ) {
                    Text("装箱并出发", fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        scope.launch {
                            viewModel.repository.updateOrderStatus(deliveryOrder.orderId, "COMPLETED")
                        }
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text("确认送达", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun SelfCheckoutWorkspace(viewModel: MainViewModel) {
    val productsList by viewModel.allProducts.collectAsState(initial = emptyList())
    val selectedStore by viewModel.selectedStore.collectAsState()

    var scannedList by remember { mutableStateOf<List<com.example.ui.PosItem>>(emptyList()) }
    var weightAnomalyDetected by remember { mutableStateOf(false) }
    var showCheckoutReceipt by remember { mutableStateOf(false) }

    val sumTotal = scannedList.sumOf { it.product.price * it.qty }
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // Scanner mockup card
        Card(
            shape = RoundedCornerShape(8.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Black),
            modifier = Modifier.fillMaxWidth().height(140.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Default.CameraAlt, contentDescription = null, tint = Color.Green, modifier = Modifier.size(32.dp))
                Spacer(modifier = Modifier.height(8.dp))
                Text("自助红外激光扫描机模组已就绪", color = Color.Green, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text("请点击下方虚拟扫码键进行商品添加模拟", color = Color.Gray, fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Weight anomaly safety checker simulator
        Surface(
            color = if (weightAnomalyDetected) Color(0xFFFCE4E4) else Color(0xFFE2F0D9),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    if (weightAnomalyDetected) Icons.Default.Warning else Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = if (weightAnomalyDetected) Color.Red else Color(0xFF385723)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = if (weightAnomalyDetected) "⚠️ 称重防损器异常报警！" else "🛡️ 称重防损监测仪处于安全监控区",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (weightAnomalyDetected) Color.Red else Color(0xFF385723)
                    )
                    Text(
                        text = if (weightAnomalyDetected) "称重感应传感器重量与已扫条码不匹配！可能购物袋有额外重物，请呼叫客服复核！" else "袋区感应称重传感器重量校准无温飘异常。",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Quick mock buttons representing standard products to scan
        Text("模拟红外激光扫描 (Barcode SKU Scan)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.Black)
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = {
                    val milk = productsList.find { it.productId == "MILK_003" } // Guming
                    if (milk != null) {
                        val current = scannedList.toMutableList()
                        val existing = current.find { it.product.productId == milk.productId }
                        if (existing != null) {
                            scannedList = current.map { if (it.product.productId == milk.productId) it.copy(qty = it.qty + 1) else it }
                        } else {
                            current.add(com.example.ui.PosItem(milk, 1))
                            scannedList = current
                        }
                    }
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
            ) {
                Text("扫鲜牛奶", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = {
                    val egg = productsList.find { it.productId == "EGG_001" } // Egg
                    if (egg != null) {
                        val current = scannedList.toMutableList()
                        val existing = current.find { it.product.productId == egg.productId }
                        if (existing != null) {
                            scannedList = current.map { if (it.product.productId == egg.productId) it.copy(qty = it.qty + 1) else it }
                        } else {
                            current.add(com.example.ui.PosItem(egg, 1))
                            scannedList = current
                        }
                    }
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
            ) {
                Text("扫土鸡蛋", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = {
                    // Trigger simulated basket weight safety mismatch
                    weightAnomalyDetected = !weightAnomalyDetected
                },
                modifier = Modifier.weight(1.2f),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary)
            ) {
                Text("模拟防损报警", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Scanned checkout items preview list
        Text("自助购物篮明细", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Black)
        Spacer(modifier = Modifier.height(6.dp))
        Card(
            shape = RoundedCornerShape(8.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                if (scannedList.isEmpty()) {
                    Text("空购物车...请点击上方按键模拟扫描条码", fontSize = 12.sp, color = Color.Gray, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                } else {
                    scannedList.forEach { item ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(item.product.name + " x${item.qty}", fontSize = 12.sp, color = Color.Black)
                            Text("¥" + String.format("%.2f", item.product.price * item.qty), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("合计小计: ", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Black)
                        Text("¥" + String.format("%.2f", sumTotal), fontWeight = FontWeight.Black, fontSize = 15.sp, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }

        if (scannedList.isNotEmpty()) {
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = {
                    scope.launch {
                        val store = selectedStore ?: return@launch
                        val orderId = "SELF" + System.currentTimeMillis().toString().takeLast(6)
                        val order = Order(
                            orderId = orderId,
                            storeId = store.storeId,
                            storeName = store.name,
                            status = "COMPLETED",
                            orderType = "PICKUP",
                            deliveryAddress = "客户自助收银终端",
                            originalAmount = sumTotal,
                            discountAmount = 0.0,
                            couponAmount = 0.0,
                            pointsDiscountAmount = 0.0,
                            finalPayable = sumTotal,
                            paymentMethod = "自助云市闪付",
                            timestamp = System.currentTimeMillis(),
                            riderName = "自助结账机台",
                            riderPhone = "机器编码#05"
                        )
                        val orderItems = scannedList.map {
                            OrderItem(orderId = orderId, productId = it.product.productId, name = it.product.name, price = it.product.price, quantity = it.qty, imageUrl = it.product.imageUrl)
                        }
                        viewModel.repository.createOrder(order, orderItems)

                        // Deduct inventory
                        for (item in scannedList) {
                            viewModel.repository.deductInventory(store.storeId, item.product.productId, item.qty)
                        }

                        scannedList = emptyList()
                        weightAnomalyDetected = false
                        showCheckoutReceipt = true
                    }
                },
                shape = RoundedCornerShape(24.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
                Text("一键刷脸/微信安全支付", fontWeight = FontWeight.Bold)
            }
        }

        // Quick success alert
        if (showCheckoutReceipt) {
            AlertDialog(
                onDismissRequest = { showCheckoutReceipt = false },
                title = { Text("自助结账已成功", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
                text = { Text("支付成功！小票已成功打印并在手机端同步，安全出站二维码已生成，感谢您的光临！") },
                confirmButton = {
                    Button(onClick = { showCheckoutReceipt = false }) {
                        Text("好")
                    }
                }
            )
        }
    }
}
