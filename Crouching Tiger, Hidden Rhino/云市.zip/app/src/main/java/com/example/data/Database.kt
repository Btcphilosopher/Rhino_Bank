package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "stores")
data class Store(
    @PrimaryKey val storeId: String,
    val name: String,
    val address: String,
    val latitude: Double,
    val longitude: Double,
    val isSelfPickup: Boolean,
    val isDelivery: Boolean,
    val deliveryTimeMinutes: Int,
    val parkingInfo: String,
    val businessHours: String,
    val parkingFree: String
)

@Entity(tableName = "products")
data class Product(
    @PrimaryKey val productId: String,
    val barcode: String,
    val name: String,
    val brand: String,
    val category: String,
    val subCategory: String,
    val specification: String,
    val unit: String,
    val origin: String,
    val supplier: String,
    val shelfLifeDays: Int,
    val storageCondition: String,
    val price: Double,
    val memberPrice: Double,
    val imageUrl: String
)

@Entity(tableName = "inventory")
data class Inventory(
    @PrimaryKey val key: String, // storeId_productId
    val storeId: String,
    val productId: String,
    val onHand: Int,
    val reserved: Int,
    val damaged: Int,
    val safetyStock: Int
) {
    fun getAvailable(): Int {
        return (onHand - reserved - damaged).coerceAtLeast(0)
    }
}

@Entity(tableName = "inventory_movements")
data class InventoryMovement(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val storeId: String,
    val productId: String,
    val type: String, // e.g., "采购入库", "线上销售", "线下销售", "损耗报损", "退货入库"
    val quantity: Int,
    val timestamp: Long,
    val remarks: String
)

@Entity(tableName = "coupons")
data class Coupon(
    @PrimaryKey val couponId: String,
    val name: String,
    val type: String, // e.g., "满减券", "折扣券", "配送券"
    val discountValue: Double,
    val minOrderAmount: Double,
    val description: String,
    val isUsed: Boolean = false
)

@Entity(tableName = "member_profile")
data class MemberProfile(
    @PrimaryKey val memberId: String,
    val name: String,
    val tier: String, // "普通会员", "黄金会员", "钻石会员"
    val points: Int,
    val growthValue: Int
)

@Entity(tableName = "points_ledger")
data class PointsLedger(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val memberId: String,
    val orderId: String,
    val type: String, // "获取", "扣减"
    val amount: Int,
    val timestamp: Long,
    val balance: Int,
    val reason: String
)

@Entity(tableName = "orders")
data class Order(
    @PrimaryKey val orderId: String,
    val storeId: String,
    val storeName: String,
    val status: String, // "CREATED", "PAID", "CONFIRMED", "PICKING", "PACKED", "READY_FOR_PICKUP", "ASSIGNED_TO_RIDER", "OUT_FOR_DELIVERY", "DELIVERED", "COMPLETED", "CANCELLED", "REFUNDED"
    val orderType: String, // "DELIVERY", "PICKUP"
    val deliveryAddress: String,
    val originalAmount: Double,
    val discountAmount: Double,
    val couponAmount: Double,
    val pointsDiscountAmount: Double,
    val finalPayable: Double,
    val paymentMethod: String,
    val timestamp: Long,
    val riderName: String,
    val riderPhone: String
)

@Entity(tableName = "order_items")
data class OrderItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val orderId: String,
    val productId: String,
    val name: String,
    val price: Double,
    val quantity: Int,
    val imageUrl: String
)

@Entity(tableName = "cart_items")
data class CartItem(
    @PrimaryKey val productId: String,
    val storeId: String,
    val quantity: Int
)

@Entity(tableName = "purchase_orders")
data class PurchaseOrder(
    @PrimaryKey val poId: String,
    val supplierName: String,
    val productName: String,
    val quantity: Int,
    val status: String, // "已下单", "运输中", "已送达", "已入库"
    val eta: String,
    val date: String
)

@Entity(tableName = "cold_chain_telemetry")
data class ColdChainTelemetry(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val orderId: String,
    val temperature: Double,
    val humidity: Double,
    val timestamp: Long,
    val isAlert: Boolean
)

@Entity(tableName = "batch_traceability")
data class BatchTraceability(
    @PrimaryKey val batchNo: String,
    val barcode: String,
    val productName: String,
    val supplier: String,
    val warehouse: String,
    val store: String,
    val produceDate: String
)
