package com.example.ui.consumer

import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Order
import com.example.data.OrderItem
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.text.style.TextOverflow
import com.example.ui.MainViewModel
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderTrackingScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val trackingOrder by viewModel.trackingOrder.collectAsState()
    val ordersList by viewModel.orders.collectAsState(initial = emptyList())
    val activeOrder = trackingOrder ?: ordersList.firstOrNull()

    var showReceipt by remember { mutableStateOf(false) }
    var orderItemsList by remember { mutableStateOf<List<OrderItem>>(emptyList()) }

    LaunchedEffect(activeOrder) {
        if (activeOrder != null) {
            val items = viewModel.repository.getOrderItems(activeOrder.orderId)
            orderItemsList = items
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("即时订单追踪", fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        if (activeOrder == null) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    Icons.Default.Moped,
                    contentDescription = "暂无订单",
                    modifier = Modifier.size(72.dp),
                    tint = Color.LightGray
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text("暂无可追踪的即时配送订单", fontWeight = FontWeight.Bold, color = Color.Gray)
                Text("请先挑选商品并在购物车进行结算支付！", fontSize = 13.sp, color = Color.Gray.copy(alpha = 0.8f))
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background)
                    .verticalScroll(rememberScrollState())
            ) {
                // 1. Order Status Header Card
                Card(
                    shape = RoundedCornerShape(0.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                Text(
                                    text = "订单号: " + activeOrder.orderId,
                                    fontSize = 12.sp,
                                    color = Color.Gray,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "配送方式: " + if (activeOrder.orderType == "DELIVERY") "30分钟冷链急送" else "到店自提",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black
                                )
                            }
                            // Status tag
                            Surface(
                                color = when (activeOrder.status) {
                                    "PAID" -> Color(0xFFE8F5E9)
                                    "PICKING" -> Color(0xFFFFF3E0)
                                    "PACKED" -> Color(0xFFE3F2FD)
                                    "OUT_FOR_DELIVERY" -> Color(0xFFEDE7F6)
                                    "COMPLETED" -> Color(0xFFE8F5E9)
                                    else -> Color(0xFFF5F5F5)
                                },
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = when (activeOrder.status) {
                                        "CREATED" -> "已创建"
                                        "PAID" -> "已付款"
                                        "CONFIRMED" -> "系统已确认"
                                        "PICKING" -> "专员拣货中"
                                        "PACKED" -> "拣货已打包"
                                        "ASSIGNED_TO_RIDER" -> "骑手已接单"
                                        "OUT_FOR_DELIVERY" -> "骑手配送中"
                                        "DELIVERED" -> "已妥投"
                                        "COMPLETED" -> "订单已完成"
                                        else -> activeOrder.status
                                    },
                                    color = when (activeOrder.status) {
                                        "PAID", "COMPLETED" -> MaterialTheme.colorScheme.primary
                                        "PICKING" -> Color(0xFFE65100)
                                        "PACKED" -> MaterialTheme.colorScheme.secondary
                                        "OUT_FOR_DELIVERY" -> Color(0xFF512DA8)
                                        else -> Color.Gray
                                    },
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Stepper timeline progress
                        LogisticsTimeline(status = activeOrder.status)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // 2. High-Tech BIM/GIS Dotted Transit Tracker Map
                Card(
                    shape = RoundedCornerShape(0.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("📍 即时配送 GIS 轨迹追踪", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.Black)
                        Spacer(modifier = Modifier.height(10.dp))

                        // Animating map visualizer inside Canvas!
                        GisTransitCanvas(status = activeOrder.status)

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(text = "配送小哥: " + activeOrder.riderName, fontSize = 12.sp, color = Color.Black)
                            Text(text = "联系电话: " + activeOrder.riderPhone, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Medium)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // 3. Cold Chain Telemetry Sensor Panel
                if (activeOrder.orderType == "DELIVERY") {
                    Card(
                        shape = RoundedCornerShape(0.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.AcUnit, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("❄️ 冷链物联网实时遥测", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.Black)
                            }
                            Spacer(modifier = Modifier.height(12.dp))

                            // Temperature simulation details
                            val isHighTempAlert = activeOrder.status == "OUT_FOR_DELIVERY" && System.currentTimeMillis() % 2 == 0L
                            val tempVal = if (isHighTempAlert) 7.3 else 3.8
                            val humVal = 67.5

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Surface(
                                    color = if (isHighTempAlert) Color(0xFFFCE4E4) else Color(0xFFE2F0D9),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text("保温箱温度", fontSize = 11.sp, color = Color.Gray)
                                        Text(
                                            text = "$tempVal ℃",
                                            fontSize = 20.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = if (isHighTempAlert) Color.Red else Color(0xFF385723)
                                        )
                                        Text(text = if (isHighTempAlert) "⚠️ 温度偏高警告" else "正常冷链 (2-6℃)", fontSize = 10.sp, color = if (isHighTempAlert) Color.Red else Color.Gray)
                                    }
                                }

                                Surface(
                                    color = Color(0xFFE3F2FD),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text("箱内湿度", fontSize = 11.sp, color = Color.Gray)
                                        Text(
                                            text = "$humVal %",
                                            fontSize = 20.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = MaterialTheme.colorScheme.secondary
                                        )
                                        Text("正常湿度控制区", fontSize = 10.sp, color = Color.Gray)
                                    }
                                }
                            }

                            if (isHighTempAlert) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Surface(
                                    color = Color(0xFFFFF2CC),
                                    shape = RoundedCornerShape(4.dp),
                                    border = BorderStroke(1.dp, Color(0xFFD4A017))
                                ) {
                                    Text(
                                        text = "⚠️ 传感器告警：检测到当前配送箱温度达到 7.3℃，偏离乳制品安全储存冷链温度 (2-6℃)。系统已向配送骑手王小哥发送冰袋复温指令！",
                                        fontSize = 11.sp,
                                        color = Color(0xFF7F6000),
                                        modifier = Modifier.padding(8.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // 4. View Electronic Receipt CTA Button
                Button(
                    onClick = { showReceipt = true },
                    shape = RoundedCornerShape(24.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .height(48.dp)
                        .testTag("view_receipt_btn")
                ) {
                    Icon(Icons.Default.ReceiptLong, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("查看购物电子小票", fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(30.dp))
            }
        }

        // Receipt Print Dialog modal
        if (showReceipt && activeOrder != null) {
            ReceiptDialog(
                order = activeOrder,
                items = orderItemsList,
                onDismiss = { showReceipt = false }
            )
        }
    }
}

@Composable
fun LogisticsTimeline(status: String) {
    val steps = listOf("付款完成", "订单拣货中", "拣货已打包", "骑手配送中", "送达完成")
    val currentStepIndex = when (status) {
        "CREATED" -> -1
        "PAID" -> 0
        "CONFIRMED" -> 0
        "PICKING" -> 1
        "PACKED" -> 2
        "ASSIGNED_TO_RIDER" -> 2
        "OUT_FOR_DELIVERY" -> 3
        "DELIVERED", "COMPLETED" -> 4
        else -> 4
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
    ) {
        steps.forEachIndexed { index, stepName ->
            val isActive = index <= currentStepIndex
            val isCurrent = index == currentStepIndex
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.weight(1f)
            ) {
                // Dot indicator
                Surface(
                    color = if (isActive) MaterialTheme.colorScheme.primary else Color.LightGray,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.size(20.dp),
                    border = if (isCurrent) BorderStroke(3.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)) else null
                ) {
                    if (isActive && index < currentStepIndex) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.padding(3.dp))
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = stepName,
                    fontSize = 10.sp,
                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                    color = if (isActive) MaterialTheme.colorScheme.primary else Color.Gray,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    lineHeight = 12.sp
                )
            }
        }
    }
}

@Composable
fun GisTransitCanvas(status: String) {
    // Canvas mapping O2O routing progress dynamically
    val stepIndex = when (status) {
        "PAID", "CONFIRMED" -> 0.1f
        "PICKING" -> 0.25f
        "PACKED" -> 0.4f
        "ASSIGNED_TO_RIDER" -> 0.5f
        "OUT_FOR_DELIVERY" -> 0.75f
        "DELIVERED", "COMPLETED" -> 1.0f
        else -> 1.0f
    }

    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(130.dp)
            .border(1.dp, Color.LightGray.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
            .background(Color(0xFFF8F9FA))
    ) {
        val width = size.width
        val height = size.height

        val startX = 60f
        val startY = height / 2f
        val endX = width - 60f
        val endY = height / 2f

        // Draw dotted path line
        drawPath(
            path = androidx.compose.ui.graphics.Path().apply {
                moveTo(startX, startY)
                quadraticTo(width / 2f, startY - 50f, endX, endY)
            },
            color = Color.LightGray,
            style = androidx.compose.ui.graphics.drawscope.Stroke(
                width = 3f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
            )
        )

        // Draw active route highlight in green
        val currentX = startX + (endX - startX) * stepIndex
        val currentY = startY - 25f * (1f - (1f - stepIndex * 2f).let { it * it }.coerceIn(-1.0f, 1.0f)) // simplified parabola

        drawPath(
            path = androidx.compose.ui.graphics.Path().apply {
                moveTo(startX, startY)
                quadraticTo(width / 2f, startY - 50f, currentX, currentY)
            },
            color = Color(0xFF2E6F40),
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 4f)
        )

        // Draw Store Node
        drawCircle(
            color = Color(0xFF1B3B6F),
            radius = 16f,
            center = Offset(startX, startY)
        )

        // Draw Home Node
        drawCircle(
            color = Color(0xFFE07A5F),
            radius = 16f,
            center = Offset(endX, endY)
        )

        // Draw Rider Node
        drawCircle(
            color = Color(0xFF2E6F40),
            radius = 12f,
            center = Offset(currentX, currentY)
        )
    }
}

@Composable
fun ReceiptDialog(
    order: Order,
    items: List<OrderItem>,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "云市电子购物小票",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .border(1.dp, Color.LightGray, RoundedCornerShape(4.dp))
                    .background(Color(0xFFFCFCFC))
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "◆ 云市 ${order.storeName.replace("云市", "")} ◆",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = "顾客线上自助下单结账存根",
                    fontSize = 11.sp,
                    color = Color.Gray,
                    modifier = Modifier.padding(top = 2.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "------------------------------------------",
                    color = Color.LightGray,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp
                )

                items.forEach { item ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${item.name} x${item.quantity}",
                            fontSize = 12.sp,
                            fontFamily = FontFamily.SansSerif,
                            modifier = Modifier.weight(1.5f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "¥" + String.format("%.2f", item.price * item.quantity),
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.weight(0.5f),
                            textAlign = TextAlign.End
                        )
                    }
                }

                Text(
                    text = "------------------------------------------",
                    color = Color.LightGray,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp
                )

                // Prices
                val prices = listOf(
                    "商品总计" to "¥" + String.format("%.2f", order.originalAmount),
                    "满减促销" to "-¥" + String.format("%.2f", order.discountAmount),
                    "优惠券折扣" to "-¥" + String.format("%.2f", order.couponAmount),
                    "积分抵扣" to "-¥" + String.format("%.2f", order.pointsDiscountAmount)
                )

                prices.forEach { (lbl, prc) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(lbl, fontSize = 11.sp, color = Color.Gray)
                        Text(prc, fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = Color.Gray)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("实付金额", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.Black)
                    Text(
                        text = "¥" + String.format("%.2f", order.finalPayable),
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color.Red,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "------------------------------------------",
                    color = Color.LightGray,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp
                )

                // Timestamps & Order metadata
                val sf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.SIMPLIFIED_CHINESE)
                val infoList = listOf(
                    "收银方式" to order.paymentMethod,
                    "结账时间" to sf.format(Date(order.timestamp)),
                    "小票编码" to order.orderId
                )

                infoList.forEach { (k, v) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(k, fontSize = 10.sp, color = Color.Gray)
                        Text(v, fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = Color.Gray)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Simulated Barcode
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(45.dp)
                ) {
                    val w = size.width
                    val h = size.height
                    var currX = 20f
                    while (currX < w - 20f) {
                        val barW = if ((1..100).random() > 60) 8f else 3f
                        val spaceW = if ((1..100).random() > 50) 6f else 2f
                        drawRect(
                            color = Color.Black,
                            topLeft = Offset(currX, 0f),
                            size = androidx.compose.ui.geometry.Size(barW, h)
                        )
                        currX += barW + spaceW
                    }
                }

                Text(
                    text = "* 感谢您光临云市，请保留此小票作为退换货凭证 *",
                    fontSize = 9.sp,
                    color = Color.Gray,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 10.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Text("关闭小票")
            }
        }
    )
}
