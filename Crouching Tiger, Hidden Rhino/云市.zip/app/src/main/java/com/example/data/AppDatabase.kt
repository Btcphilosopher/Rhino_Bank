package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        Store::class,
        Product::class,
        Inventory::class,
        InventoryMovement::class,
        Coupon::class,
        MemberProfile::class,
        PointsLedger::class,
        Order::class,
        OrderItem::class,
        CartItem::class,
        PurchaseOrder::class,
        ColdChainTelemetry::class,
        BatchTraceability::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun storeDao(): StoreDao
    abstract fun productDao(): ProductDao
    abstract fun inventoryDao(): InventoryDao
    abstract fun inventoryMovementDao(): InventoryMovementDao
    abstract fun couponDao(): CouponDao
    abstract fun memberDao(): MemberDao
    abstract fun pointsLedgerDao(): PointsLedgerDao
    abstract fun orderDao(): OrderDao
    abstract fun cartDao(): CartDao
    abstract fun purchaseOrderDao(): PurchaseOrderDao
    abstract fun coldChainDao(): ColdChainDao
    abstract fun batchTraceabilityDao(): BatchTraceabilityDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "cloudmarket_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
