package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.MainViewModel
import com.example.ui.consumer.CartScreen
import com.example.ui.consumer.HomeFeedScreen
import com.example.ui.consumer.OrderTrackingScreen
import com.example.ui.consumer.ProductDetailScreen
import com.example.ui.operations.AiAnalyticsScreen
import com.example.ui.operations.DigitalTwinScreen
import com.example.ui.operations.OperationsCenterScreen
import com.example.ui.staff.PosSystemScreen
import com.example.ui.staff.StaffConsoleScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppContent()
            }
        }
    }
}

@Composable
fun MainAppContent() {
    val viewModel: MainViewModel = viewModel()
    
    // Bottom navigation tabs: "HOME" (Store / Details), "CART" (Cart / Optimizer), "TRACKING" (Logistics Tracking / Receipt), "CONSOLE" (Staff / Operations / BIM / AI)
    var activeTab by remember { mutableStateOf("HOME") }
    
    // Internal sub-screen stack for HOME tab
    var selectedProductId by remember { mutableStateOf<String?>(null) }
    
    // Sub-modules for the CONSOLE tab: "POS", "STAFF", "OPERATIONS", "BIM", "AI"
    var activeConsoleModule by remember { mutableStateOf("OPERATIONS") }

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                NavigationBarItem(
                    selected = activeTab == "HOME",
                    onClick = {
                        activeTab = "HOME"
                        selectedProductId = null // reset stack
                    },
                    icon = { Icon(Icons.Default.Storefront, contentDescription = "云市超市") },
                    label = { Text("云市超市", fontSize = 11.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) },
                    modifier = Modifier.testTag("nav_home")
                )

                NavigationBarItem(
                    selected = activeTab == "CART",
                    onClick = { activeTab = "CART" },
                    icon = { Icon(Icons.Default.ShoppingCart, contentDescription = "购物车") },
                    label = { Text("购物车", fontSize = 11.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) },
                    modifier = Modifier.testTag("nav_cart")
                )

                NavigationBarItem(
                    selected = activeTab == "TRACKING",
                    onClick = { activeTab = "TRACKING" },
                    icon = { Icon(Icons.Default.Moped, contentDescription = "配送追踪") },
                    label = { Text("即时配送", fontSize = 11.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) },
                    modifier = Modifier.testTag("nav_tracking")
                )

                NavigationBarItem(
                    selected = activeTab == "CONSOLE",
                    onClick = { activeTab = "CONSOLE" },
                    icon = { Icon(Icons.Default.Terminal, contentDescription = "管理后台") },
                    label = { Text("工作台", fontSize = 11.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) },
                    modifier = Modifier.testTag("nav_console")
                )
            }
        },
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (activeTab) {
                "HOME" -> {
                    if (selectedProductId == null) {
                        HomeFeedScreen(
                            viewModel = viewModel,
                            onNavigateToProduct = { selectedProductId = it }
                        )
                    } else {
                        ProductDetailScreen(
                            productId = selectedProductId!!,
                            viewModel = viewModel,
                            onBack = { selectedProductId = null }
                        )
                    }
                }
                "CART" -> {
                    CartScreen(
                        viewModel = viewModel,
                        onNavigateToOrderTracking = { activeTab = "TRACKING" }
                    )
                }
                "TRACKING" -> {
                    OrderTrackingScreen(viewModel = viewModel)
                }
                "CONSOLE" -> {
                    Column(modifier = Modifier.fillMaxSize()) {
                        // Horizontal scrollable module switcher for staff & ops roles
                        ScrollableTabRow(
                            selectedTabIndex = when (activeConsoleModule) {
                                "OPERATIONS" -> 0
                                "BIM" -> 1
                                "AI" -> 2
                                "POS" -> 3
                                else -> 4
                            },
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = MaterialTheme.colorScheme.primary,
                            edgePadding = 12.dp,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Tab(
                                selected = activeConsoleModule == "OPERATIONS",
                                onClick = { activeConsoleModule = "OPERATIONS" },
                                text = { Text("运营控制台", fontSize = 11.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) }
                            )
                            Tab(
                                selected = activeConsoleModule == "BIM",
                                onClick = { activeConsoleModule = "BIM" },
                                text = { Text("BIM数字孪生", fontSize = 11.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) }
                            )
                            Tab(
                                selected = activeConsoleModule == "AI",
                                onClick = { activeConsoleModule = "AI" },
                                text = { Text("AI零售分析", fontSize = 11.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) }
                            )
                            Tab(
                                selected = activeConsoleModule == "POS",
                                onClick = { activeConsoleModule = "POS" },
                                text = { Text("物理收银POS", fontSize = 11.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) }
                            )
                            Tab(
                                selected = activeConsoleModule == "STAFF",
                                onClick = { activeConsoleModule = "STAFF" },
                                text = { Text("拣货/配送专区", fontSize = 11.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) }
                            )
                        }

                        Box(modifier = Modifier.weight(1f)) {
                            when (activeConsoleModule) {
                                "OPERATIONS" -> OperationsCenterScreen(viewModel = viewModel)
                                "BIM" -> DigitalTwinScreen(viewModel = viewModel)
                                "AI" -> AiAnalyticsScreen(viewModel = viewModel)
                                "POS" -> PosSystemScreen(viewModel = viewModel)
                                "STAFF" -> StaffConsoleScreen(viewModel = viewModel)
                            }
                        }
                    }
                }
            }
        }
    }
}
