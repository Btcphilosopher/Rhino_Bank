package com.example.ui.operations

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import androidx.compose.ui.graphics.PathEffect

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DigitalTwinScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    var selectedZone by remember { mutableStateOf("FRUIT") } // "FRUIT", "DAIRY", "GRAIN", "CASHIER", "WAREHOUSE"
    var showHeatmap by remember { mutableStateOf(false) }
    var showOutofStockOverlay by remember { mutableStateOf(false) }
    var showColdChainOverlay by remember { mutableStateOf(true) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Text("📐 门店数字孪生 BIM 仿真系统", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = MaterialTheme.colorScheme.primary)
        Text("上海浦东旗舰店实体门店 3D/2D 空间传感器自动校准对账", fontSize = 11.sp, color = Color.Gray)

        Spacer(modifier = Modifier.height(16.dp))

        // Toggle switches toolbar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = showHeatmap,
                onClick = { showHeatmap = !showHeatmap },
                label = { Text("客流热力图", fontSize = 11.sp) },
                leadingIcon = if (showHeatmap) { { Icon(Icons.Default.Star, contentDescription = null, modifier = Modifier.size(12.dp)) } } else null
            )

            FilterChip(
                selected = showOutofStockOverlay,
                onClick = { showOutofStockOverlay = !showOutofStockOverlay },
                label = { Text("缺货货架闪烁", fontSize = 11.sp) },
                leadingIcon = if (showOutofStockOverlay) { { Icon(Icons.Default.Warning, contentDescription = null, modifier = Modifier.size(12.dp)) } } else null
            )

            FilterChip(
                selected = showColdChainOverlay,
                onClick = { showColdChainOverlay = !showColdChainOverlay },
                label = { Text("温控探测叠加", fontSize = 11.sp) },
                leadingIcon = if (showColdChainOverlay) { { Icon(Icons.Default.Info, contentDescription = null, modifier = Modifier.size(12.dp)) } } else null
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Interactive Store Plan Map Canvas (Tappable zones)
        Box(
            modifier = Modifier
                .weight(1.3f)
                .fillMaxWidth()
                .border(1.dp, Color.LightGray.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                .background(Color(0xFFF1F3F5))
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .clickable {
                        // Rough coordinate clicking logic to match corresponding zones
                        // For simpler robust web view we can also provide explicit text buttons on the side,
                        // But we will make this click region robust!
                    }
            ) {
                val w = size.width
                val h = size.height

                // Draw outer store frame boundary
                drawRoundRect(
                    color = Color(0xFF1B3B6F),
                    topLeft = Offset(30f, 30f),
                    size = androidx.compose.ui.geometry.Size(w - 60f, h - 60f),
                    cornerRadius = CornerRadius(12f, 12f),
                    style = Stroke(width = 4f)
                )

                // 1. Fruit Zone Rectangle (Top Left)
                drawRoundRect(
                    color = if (selectedZone == "FRUIT") Color(0xFF2E6F40) else Color.White,
                    topLeft = Offset(50f, 50f),
                    size = androidx.compose.ui.geometry.Size(w * 0.4f, h * 0.35f),
                    cornerRadius = CornerRadius(6f, 6f)
                )
                // Border for Fruit Zone
                drawRoundRect(
                    color = if (selectedZone == "FRUIT") Color.Black else Color.Gray.copy(alpha = 0.5f),
                    topLeft = Offset(50f, 50f),
                    size = androidx.compose.ui.geometry.Size(w * 0.4f, h * 0.35f),
                    cornerRadius = CornerRadius(6f, 6f),
                    style = Stroke(width = 2f)
                )

                // 2. Dairy & Cold Aisle (Top Right)
                drawRoundRect(
                    color = if (selectedZone == "DAIRY") Color(0xFF98B9EB) else Color.White,
                    topLeft = Offset(w * 0.52f, 50f),
                    size = androidx.compose.ui.geometry.Size(w * 0.4f, h * 0.35f),
                    cornerRadius = CornerRadius(6f, 6f)
                )
                drawRoundRect(
                    color = if (selectedZone == "DAIRY") Color.Black else Color.Gray.copy(alpha = 0.5f),
                    topLeft = Offset(w * 0.52f, 50f),
                    size = androidx.compose.ui.geometry.Size(w * 0.4f, h * 0.35f),
                    cornerRadius = CornerRadius(6f, 6f),
                    style = Stroke(width = 2f)
                )

                // 3. Grain & Oil shelf (Bottom Left)
                drawRoundRect(
                    color = if (selectedZone == "GRAIN") Color(0xFFE07A5F).copy(alpha = 0.3f) else Color.White,
                    topLeft = Offset(50f, h * 0.5f),
                    size = androidx.compose.ui.geometry.Size(w * 0.4f, h * 0.35f),
                    cornerRadius = CornerRadius(6f, 6f)
                )
                drawRoundRect(
                    color = if (selectedZone == "GRAIN") Color.Black else Color.Gray.copy(alpha = 0.5f),
                    topLeft = Offset(50f, h * 0.5f),
                    size = androidx.compose.ui.geometry.Size(w * 0.4f, h * 0.35f),
                    cornerRadius = CornerRadius(6f, 6f),
                    style = Stroke(width = 2f)
                )

                // 4. Warehouse后仓 (Bottom Right)
                drawRoundRect(
                    color = if (selectedZone == "WAREHOUSE") Color.LightGray else Color.White,
                    topLeft = Offset(w * 0.52f, h * 0.5f),
                    size = androidx.compose.ui.geometry.Size(w * 0.4f, h * 0.35f),
                    cornerRadius = CornerRadius(6f, 6f)
                )
                drawRoundRect(
                    color = if (selectedZone == "WAREHOUSE") Color.Black else Color.Gray.copy(alpha = 0.5f),
                    topLeft = Offset(w * 0.52f, h * 0.5f),
                    size = androidx.compose.ui.geometry.Size(w * 0.4f, h * 0.35f),
                    cornerRadius = CornerRadius(6f, 6f),
                    style = Stroke(width = 2f)
                )

                // Heatmap dots rendering
                if (showHeatmap) {
                    drawCircle(Color.Red.copy(alpha = 0.45f), radius = 60f, center = Offset(w * 0.25f, h * 0.2f))
                    drawCircle(Color.Yellow.copy(alpha = 0.5f), radius = 45f, center = Offset(w * 0.72f, h * 0.65f))
                    drawCircle(Color.Red.copy(alpha = 0.3f), radius = 75f, center = Offset(w * 0.3f, h * 0.7f))
                }

                // Out of stock shelf flash overlay (Draw red dash borders)
                if (showOutofStockOverlay) {
                    drawRoundRect(
                        color = Color.Red,
                        topLeft = Offset(50f, h * 0.5f),
                        size = androidx.compose.ui.geometry.Size(w * 0.4f, h * 0.35f),
                        cornerRadius = CornerRadius(6f, 6f),
                        style = Stroke(width = 5f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 15f), 0f))
                    )
                }
            }

            // Quick zone clicking layer overlay
            Column(modifier = Modifier.fillMaxSize()) {
                Row(modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxSize()
                            .clickable { selectedZone = "FRUIT" }
                    ) {
                        Text("生鲜水果区", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.DarkGray, modifier = Modifier.align(Alignment.Center))
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxSize()
                            .clickable { selectedZone = "DAIRY" }
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.align(Alignment.Center)) {
                            Text("乳品冷冻区", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.DarkGray)
                            if (showColdChainOverlay) {
                                Text("❄️ 3.2℃", fontSize = 9.sp, color = Color(0xFF1B3B6F), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                Row(modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxSize()
                            .clickable { selectedZone = "GRAIN" }
                    ) {
                        Text("粮油干货区", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.DarkGray, modifier = Modifier.align(Alignment.Center))
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxSize()
                            .clickable { selectedZone = "WAREHOUSE" }
                    ) {
                        Text("前置仓/仓库后场", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.DarkGray, modifier = Modifier.align(Alignment.Center))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 5. Selected zone telemetry details Card
        Text("📊 选定货架传感器物联网反馈 (Telemetry)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Black)
        Spacer(modifier = Modifier.height(6.dp))

        Card(
            shape = RoundedCornerShape(8.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.8f)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = when (selectedZone) {
                        "FRUIT" -> "生鲜岛 (Zone Fruit-08)"
                        "DAIRY" -> "卧式风冷柜 (Zone Dairy-03)"
                        "GRAIN" -> "常温货架B排 (Zone Grain-12)"
                        else -> "自动化理货后场仓 (Zone WH-A)"
                    },
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.primary
                )

                Spacer(modifier = Modifier.height(10.dp))

                val zoneRows = when (selectedZone) {
                    "FRUIT" -> listOf(
                        "货柜在架率" to "92.0 %",
                        "常客驻留率" to "128人次/小时 (高客流)",
                        "平均补货频次" to "1.2小时",
                        "安全隐患排查" to "合格"
                    )
                    "DAIRY" -> listOf(
                        "温度计检测" to "3.2 ℃ (正常)",
                        "风机运行噪音" to "38 dB",
                        "货架在架率" to "74.0 %",
                        "异常报警器" to "暂无报警"
                    )
                    "GRAIN" -> listOf(
                        "货架在架率" to "48.0 % (偏低)",
                        "主营品类数" to "32 SKUs",
                        "缺货严重度" to "中度 (建议补货)",
                        "除湿器状态" to "适中 (52%湿度)"
                    )
                    else -> listOf(
                        "待出库运力" to "2 笔",
                        "在手库存容量" to "1,380 SKUs",
                        "安全负荷" to "38.5 %",
                        "冷链打包区温度" to "11.2 ℃"
                    )
                }

                zoneRows.forEach { (lbl, prc) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(lbl, fontSize = 12.sp, color = Color.Gray)
                        Text(prc, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                    }
                }
            }
        }
    }
}
