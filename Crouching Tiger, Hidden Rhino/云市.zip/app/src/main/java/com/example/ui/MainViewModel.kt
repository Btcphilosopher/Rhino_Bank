package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.*

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    val repository = Repository(db)

    // Roles: "CUSTOMER" (消费者), "CASHIER" (收银员/POS), "PICKER" (拣货员), "DELIVERY" (配送骑手), "OPERATIONS" (运营后台与数字孪生)
    private val _currentRole = MutableStateFlow("CUSTOMER")
    val currentRole: StateFlow<String> = _currentRole

    // Active chosen store
    private val _selectedStore = MutableStateFlow<Store?>(null)
    val selectedStore: StateFlow<Store?> = _selectedStore

    // Current category tab
    private val _selectedCategory = MutableStateFlow("全部")
    val selectedCategory: StateFlow<String> = _selectedCategory

    // Search query
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    // Mock environment factors
    val mockWeather = MutableStateFlow("晴朗 26℃")
    val mockTimeOfDay = MutableStateFlow("14:30 (下午营业)")
    val mockHoliday = MutableStateFlow("无")

    // Consumer Cart
    val cartItems = repository.cartItems
    val allProducts = repository.products
    val stores = repository.stores
    val coupons = repository.coupons
    val memberProfile = repository.memberProfile
    val pointsLedger = repository.pointsLedger
    val orders = repository.orders
    val purchaseOrders = repository.purchaseOrders
    val coldChainTelemetry = repository.coldChainTelemetry
    val batchTraceability = repository.batchTraceability
    val inventoryMovements = repository.inventoryMovements

    // Chosen coupon for checkout
    private val _selectedCoupon = MutableStateFlow<Coupon?>(null)
    val selectedCoupon: StateFlow<Coupon?> = _selectedCoupon

    // Use member points for checkout?
    val usePointsForCheckout = MutableStateFlow(false)

    // Checkout delivery method: "DELIVERY" or "PICKUP"
    val checkoutDeliveryType = MutableStateFlow("DELIVERY")
    val checkoutAddress = MutableStateFlow("上海市浦东新区张江路55号")

    // Active tracking order for O2O visual timeline
    private val _trackingOrder = MutableStateFlow<Order?>(null)
    val trackingOrder: StateFlow<Order?> = _trackingOrder

    // POS Active Scan List
    val posScannedItems = MutableStateFlow<List<PosItem>>(emptyList())
    val posSearchQuery = MutableStateFlow("")
    val posMemberQuery = MutableStateFlow("")
    val posActiveMember = MutableStateFlow<MemberProfile?>(null)
    val posSuspendedBills = MutableStateFlow<List<List<PosItem>>>(emptyList())

    // Self-checkout shopping session (Mobile session)
    val mobileScanSessionActive = MutableStateFlow(false)
    val mobileScanItems = MutableStateFlow<List<PosItem>>(emptyList())

    // NLP operations assistant
    val nlpQuery = MutableStateFlow("")
    val nlpResponse = MutableStateFlow<NlpReply?>(null)

    // Simulation Configs
    val simMode = MutableStateFlow("常规日") // "常规日", "双11大促", "台风大暴雨", "供应链断裂"
    val simStoreCount = MutableStateFlow(20)
    val simSkuCount = MutableStateFlow(10000)
    val simActiveRiders = MutableStateFlow(15)
    val simThroughputKpi = MutableStateFlow("5.2 订单/秒")
    val simStockoutRateKpi = MutableStateFlow("0.8 %")
    val simLog = MutableStateFlow<List<String>>(emptyList())

    init {
        viewModelScope.launch {
            repository.seedMockData()
            // Set default store to Shanghai Pudong
            val firstStore = repository.stores.firstOrNull()?.find { it.storeId == "STORE_SH_PD" }
            _selectedStore.value = firstStore
        }
    }

    fun selectStore(store: Store) {
        _selectedStore.value = store
        viewModelScope.launch {
            _selectedCoupon.value = null
            usePointsForCheckout.value = false
        }
    }

    fun selectCategory(category: String) {
        _selectedCategory.value = category
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun switchRole(role: String) {
        _currentRole.value = role
    }

    // 1. PRODUCT SEARCH ENGINE
    // Translates synonyms & pinyin keywords (niunai -> 牛奶) to give intelligent Chinese matches
    fun getFilteredProducts(allProd: List<Product>): List<Product> {
        val query = _searchQuery.value.trim().lowercase()
        val cat = _selectedCategory.value
        
        // Category filtering first
        val catFiltered = if (cat == "全部") allProd else allProd.filter { it.category == cat }

        if (query.isEmpty()) return catFiltered

        // Pinyin synonyms mapping
        val synonymMap = mapOf(
            "niunai" to "牛奶",
            "nn" to "牛奶",
            "pingguo" to "苹果",
            "pg" to "苹果",
            "jidan" to "鸡蛋",
            "jd" to "鸡蛋",
            "kelei" to "可乐",
            "kl" to "可乐",
            "yagao" to "牙膏",
            "yg" to "牙膏",
            "pijiu" to "啤酒",
            "pj" to "啤酒",
            "mian" to "米",
            "dami" to "米"
        )
        val expandedQuery = synonymMap[query] ?: query

        return catFiltered.filter { p ->
            p.name.lowercase().contains(expandedQuery) ||
            p.brand.lowercase().contains(expandedQuery) ||
            p.category.lowercase().contains(expandedQuery) ||
            p.barcode.contains(query) ||
            p.specification.lowercase().contains(expandedQuery)
        }
    }

    // 2. HOME FEED ENGINE
    // Generates a dynamic layout of products depending on Weather, Time, and Store Stocks.
    fun getDynamicHomeFeed(allProd: List<Product>): List<Product> {
        val weather = mockWeather.value
        val time = mockTimeOfDay.value
        
        // Simple priority sorting score based on environment
        return allProd.sortedByDescending { p ->
            var score = 0
            
            // Category prioritization based on weather
            if (weather.contains("大雨")) {
                if (p.category == "粮油调味" || p.category == "家清") score += 50 // Stay-at-home prep
                if (p.category == "零食饮料") score += 20
            } else if (weather.contains("高温") || weather.contains("26℃")) {
                if (p.category == "肉禽蛋奶" && p.subCategory == "低温奶") score += 40
                if (p.category == "零食饮料" && p.name.contains("水")) score += 50
            }

            // Time based prioritizations
            if (time.contains("晚上") || time.contains("22:")) {
                if (p.category == "酒水" || p.category == "零食饮料") score += 40
            }

            // High member discount prioritization
            val discount = p.price - p.memberPrice
            if (discount > 5.0) {
                score += 30
            }

            score
        }
    }

    // 3. CART ENGINE & PROMOTION OPTIMIZER
    // Calculates summary, applies Coupons, and dynamically recommends paper roll if close to 59
    fun getCartSummary(items: List<CartItem>, productsList: List<Product>): CartSummary {
        var totalAmount = 0.0
        var itemsCount = 0
        
        val details = items.mapNotNull { cartItem ->
            val p = productsList.find { it.productId == cartItem.productId }
            if (p != null) {
                val subTotal = p.price * cartItem.quantity
                totalAmount += subTotal
                itemsCount += cartItem.quantity
                CartItemDetail(p, cartItem.quantity, subTotal)
            } else null
        }

        // Promotion rule: "满59减10"
        var canApplyPromotion = totalAmount >= 59.0
        var promoDiscount = if (canApplyPromotion) 10.0 else 0.0
        
        // Promotion Optimizer suggestion
        var buyMoreToPromo = 0.0
        var recommendedProduct: Product? = null
        if (totalAmount > 0.0 && totalAmount < 59.0) {
            buyMoreToPromo = 59.0 - totalAmount
            // Suggest "清风卷纸" or "土鸡蛋" that is close to filling this gap
            recommendedProduct = productsList.find { it.productId == "CLEAN_002" || it.productId == "EGG_001" }
        }

        // Apply chosen coupon
        val coupon = _selectedCoupon.value
        var couponDiscount = 0.0
        if (coupon != null && totalAmount >= coupon.minOrderAmount) {
            couponDiscount = if (coupon.type == "折扣券") {
                totalAmount * (1.0 - coupon.discountValue)
            } else {
                coupon.discountValue
            }
            // Limit discount caps
            if (coupon.type == "折扣券" && couponDiscount > 20.0) couponDiscount = 20.0
        }

        // Points ledger subtraction (2840 points -> redeem up to 500 points = 5.0元)
        var pointsDeduction = 0.0
        if (usePointsForCheckout.value) {
            pointsDeduction = 5.00 // max redeem
        }

        val deliveryFee = if (checkoutDeliveryType.value == "DELIVERY") {
            if (coupon?.type == "配送券") 0.0 else 5.0
        } else 0.0

        val finalPayable = (totalAmount - promoDiscount - couponDiscount - pointsDeduction + deliveryFee).coerceAtLeast(0.0)

        return CartSummary(
            items = details,
            totalOriginalAmount = totalAmount,
            promotionDiscount = promoDiscount,
            couponDiscount = couponDiscount,
            pointsDiscount = pointsDeduction,
            deliveryFee = deliveryFee,
            finalPayable = finalPayable,
            buyMoreForPromoThreshold = buyMoreToPromo,
            recommendedPromoFiller = recommendedProduct
        )
    }

    fun selectCoupon(coupon: Coupon?) {
        _selectedCoupon.value = coupon
    }

    fun toggleUsePoints() {
        usePointsForCheckout.value = !usePointsForCheckout.value
    }

    fun setDeliveryType(type: String) {
        checkoutDeliveryType.value = type
    }

    // Add, subtract, remove from Cart
    fun addToCart(productId: String) {
        val store = _selectedStore.value ?: return
        viewModelScope.launch {
            val existing = cartItems.first().find { it.productId == productId && it.storeId == store.storeId }
            if (existing != null) {
                repository.addCartItem(productId, store.storeId, existing.quantity + 1)
            } else {
                repository.addCartItem(productId, store.storeId, 1)
            }
        }
    }

    fun updateCartQty(productId: String, qty: Int) {
        val store = _selectedStore.value ?: return
        viewModelScope.launch {
            if (qty <= 0) {
                repository.removeCartItem(productId)
            } else {
                repository.addCartItem(productId, store.storeId, qty)
            }
        }
    }

    fun removeFromCart(productId: String) {
        viewModelScope.launch {
            repository.removeCartItem(productId)
        }
    }

    // 4. CHECKOUT ENGINE & MOCK PAYMENT VALIDATION
    fun submitCheckout(summary: CartSummary, onPaymentSuccess: (String) -> Unit, onPaymentFailed: (String) -> Unit) {
        val store = _selectedStore.value ?: return
        if (summary.items.isEmpty()) return

        viewModelScope.launch {
            // Reserve Inventory Ledger check first
            var allStockAvailable = true
            for (detail in summary.items) {
                val hasStock = repository.reserveInventory(store.storeId, detail.product.productId, detail.quantity)
                if (!hasStock) {
                    allStockAvailable = false
                    onPaymentFailed("商品【${detail.product.name}】库存不足，无法锁定，请调整！")
                    break
                }
            }

            if (!allStockAvailable) return@launch

            // Create Order
            val orderId = "CM" + SimpleDateFormat("yyyyMMddHHmmss", Locale.SIMPLIFIED_CHINESE).format(Date()) + (10..99).random()
            val order = Order(
                orderId = orderId,
                storeId = store.storeId,
                storeName = store.name,
                status = "PAID", // Directly PAID after Mock Payment Server Validation
                orderType = checkoutDeliveryType.value,
                deliveryAddress = if (checkoutDeliveryType.value == "DELIVERY") checkoutAddress.value else "店内自提",
                originalAmount = summary.totalOriginalAmount,
                discountAmount = summary.promotionDiscount,
                couponAmount = summary.couponDiscount,
                pointsDiscountAmount = summary.pointsDiscount,
                finalPayable = summary.finalPayable,
                paymentMethod = "微信支付",
                timestamp = System.currentTimeMillis(),
                riderName = "云市骑手-江小哥",
                riderPhone = "13988889999"
            )

            val orderItems = summary.items.map {
                OrderItem(
                    orderId = orderId,
                    productId = it.product.productId,
                    name = it.product.name,
                    price = it.product.price,
                    quantity = it.quantity,
                    imageUrl = it.product.imageUrl
                )
            }
            
            // Save to database
            repository.createOrder(order, orderItems)

            // Deduct real inventory and complete the reservation
            for (detail in summary.items) {
                repository.deductInventory(store.storeId, detail.product.productId, detail.quantity)
            }

            // Ledger points accumulation (Order money -> points)
            val pointsEarned = (summary.finalPayable).toInt()
            if (pointsEarned > 0) {
                repository.adjustPoints("M_001", orderId, "获取", pointsEarned, "线上超市购物赠送")
            }
            if (usePointsForCheckout.value) {
                repository.adjustPoints("M_001", orderId, "扣减", 500, "购物抵扣现金")
            }

            // Clear Cart and reset values
            repository.clearCart()
            _selectedCoupon.value = null
            usePointsForCheckout.value = false

            // Track this order immediately
            _trackingOrder.value = order
            onPaymentSuccess(orderId)

            // Start Simulated O2O Fulfilment Service
            triggerSimulatedO2OFulfilment(orderId)
        }
    }

    fun clearCart() {
        viewModelScope.launch {
            repository.clearCart()
        }
    }

    // 5. O2O INSTANT DELIVERY TIMER SERVICE
    // Auto-transitions order status through state machine: PAID -> PICKING -> PACKED -> ASSIGNED_TO_RIDER -> OUT_FOR_DELIVERY -> DELIVERED -> COMPLETED
    private fun triggerSimulatedO2OFulfilment(orderId: String) {
        viewModelScope.launch {
            val states = listOf("CONFIRMED", "PICKING", "PACKED", "ASSIGNED_TO_RIDER", "OUT_FOR_DELIVERY", "DELIVERED", "COMPLETED")
            for (state in states) {
                delay(6000) // 6 seconds simulation steps
                repository.updateOrderStatus(orderId, state)
                val order = repository.getOrderById(orderId)
                if (order != null) {
                    _trackingOrder.value = order
                }
                
                // Add cold chain telemetry log if in delivery
                if (state == "OUT_FOR_DELIVERY") {
                    repository.addColdChainLog(
                        ColdChainTelemetry(
                            orderId = orderId,
                            temperature = (3.5 + (1..3).random() * 0.4),
                            humidity = 68.0,
                            timestamp = System.currentTimeMillis(),
                            isAlert = false
                        )
                    )
                }
            }
        }
    }

    // 6. STAFF CONSOLE & POS SYSTEMS
    fun scanBarcodeToPos(barcode: String) {
        viewModelScope.launch {
            val prod = repository.products.firstOrNull()?.find { it.barcode == barcode }
            if (prod != null) {
                val current = posScannedItems.value.toMutableList()
                val existing = current.find { it.product.productId == prod.productId }
                if (existing != null) {
                    posScannedItems.value = current.map {
                        if (it.product.productId == prod.productId) it.copy(qty = it.qty + 1) else it
                    }
                } else {
                    current.add(PosItem(prod, 1))
                    posScannedItems.value = current
                }
            }
        }
    }

    fun submitPosPayment(method: String) {
        viewModelScope.launch {
            val store = _selectedStore.value ?: return@launch
            val items = posScannedItems.value
            if (items.isEmpty()) return@launch

            val total = items.sumOf { it.product.price * it.qty }
            val orderId = "POS" + SimpleDateFormat("yyyyMMddHHmmss", Locale.SIMPLIFIED_CHINESE).format(Date())

            val order = Order(
                orderId = orderId,
                storeId = store.storeId,
                storeName = store.name,
                status = "COMPLETED",
                orderType = "PICKUP",
                deliveryAddress = "店内线下收银",
                originalAmount = total,
                discountAmount = 0.0,
                couponAmount = 0.0,
                pointsDiscountAmount = 0.0,
                finalPayable = total,
                paymentMethod = method,
                timestamp = System.currentTimeMillis(),
                riderName = "收银员柜台",
                riderPhone = "POS机印制"
            )

            val orderItems = items.map {
                OrderItem(
                    orderId = orderId,
                    productId = it.product.productId,
                    name = it.product.name,
                    price = it.product.price,
                    quantity = it.qty,
                    imageUrl = it.product.imageUrl
                )
            }

            repository.createOrder(order, orderItems)

            // Deduct store stocks
            for (item in items) {
                repository.deductInventory(store.storeId, item.product.productId, item.qty, "线下销售")
            }

            posScannedItems.value = emptyList()
            posActiveMember.value = null
        }
    }

    // POS suspend / unsuspend order bills
    fun suspendPosBill() {
        if (posScannedItems.value.isNotEmpty()) {
            val suspended = posSuspendedBills.value.toMutableList()
            suspended.add(posScannedItems.value)
            posSuspendedBills.value = suspended
            posScannedItems.value = emptyList()
        }
    }

    fun restorePosBill(index: Int) {
        val suspended = posSuspendedBills.value.toMutableList()
        if (index in suspended.indices) {
            posScannedItems.value = suspended[index]
            suspended.removeAt(index)
            posSuspendedBills.value = suspended
        }
    }

    // 7. DIGITAL TWIN HEALTH MATRIX
    // Shelf levels mapping (Aisle tracking: A-Dairy, B-Snacks, C-Fresh, D-Household)
    fun getDigitalTwinHeatmap(storeId: String, allProd: List<Product>): List<ShelfHeatmap> {
        val areas = listOf(
            AreaHeat("肉禽蛋奶", "A-1区 (冷柜乳品)", "Adequate"),
            AreaHeat("生鲜水果", "B-2区 (保鲜果菜)", "Low"),
            AreaHeat("零食饮料", "C-3区 (干货零食)", "Adequate"),
            AreaHeat("粮油调味", "D-4区 (粮油副食)", "Adequate"),
            AreaHeat("家清", "E-5区 (个护洗涤)", "Critical")
        )
        return areas.map { area ->
            val prods = allProd.filter { it.category == area.category }
            ShelfHeatmap(
                areaName = area.areaName,
                category = area.category,
                skuCount = prods.size,
                totalInventory = prods.size * 18,
                status = area.status
            )
        }
    }

    // 8. NATURAL LANGUAGE COPILOT (NLP Operations Intelligence)
    fun askNlpCopilot(q: String): String {
        nlpQuery.value = q
        queryRetailCopilot()
        val response = nlpResponse.value
        return if (response != null) {
            "${response.conclusion}\n\n【主要影响因素】：\n" + response.factors.joinToString("\n") + "\n\n【建议运营策略决策】：\n${response.advice}"
        } else {
            "无法解析该运营指标，云市大宗决策大脑正在重新计算。"
        }
    }

    fun queryRetailCopilot() {
        val q = nlpQuery.value.trim()
        if (q.isEmpty()) return
        
        nlpResponse.value = when {
            q.contains("牛奶") && q.contains("浦东") -> {
                NlpReply(
                    conclusion = "浦东店【牛奶】品类今日销量较上周同比下降了 28.3%。",
                    factors = listOf(
                        "1. 上周促销‘买二送一’折扣结束，价格回调至 ¥69.90。",
                        "2. 低温鲜牛奶（光明）由于配送延迟，上午 08:00 - 11:30 出现短时缺货。",
                        "3. 竞争对手（附近小象超市）推出同品牌牛奶特价优惠。"
                    ),
                    range = "最近 7 天经营账本",
                    confidence = 94.5,
                    advice = "建议适当拉长本周末低温鲜奶的补货前置时间，并重启满 59 元减 10 元牛奶大赏促销！"
                )
            }
            q.contains("大闸蟹") || q.contains("生鲜") -> {
                NlpReply(
                    conclusion = "生鲜水产品类整体销量激增 42.1%，其中【阳澄湖大闸蟹】周销量预测大幅看涨。",
                    factors = listOf(
                        "1. 临近中秋佳节，送礼与家庭聚餐刚性需求暴涨。",
                        "2. 冷链监控良好，运输温湿度无异常，损耗率保持在 0.2% 以下极低水平。",
                        "3. 线上推广活动效果显著，占比高达 72.5%。"
                    ),
                    range = "近 14 天供应链和订单分析",
                    confidence = 91.0,
                    advice = "需增加采购订单 PO 量，并督促昆山分拣仓严格把控冷链温控，防止运损缺氧！"
                )
            }
            else -> {
                NlpReply(
                    conclusion = "云市智能零售脑当前运行正常，浦东店今日营业总额稳步上升，库存安全水位良好。",
                    factors = listOf(
                        "1. 纸品家清和宠物食品持续带来稳定客源利润。",
                        "2. 配送骑手平均派送时效保持在 26.5 分钟高位水平。",
                        "3. 全市 20 家店面自动补货算法已在 04:00 发出 PO 建议单。"
                    ),
                    range = "全市数据监测大屏",
                    confidence = 98.0,
                    advice = "点击查看【数据运营】或者运行【库存模拟器】测试周末极端天气下前置仓压力！"
                )
            }
        }
    }

    // 9. SIMULATOR STRESS TESTING ENGINE
    fun runStressSimulator() {
        val mode = simMode.value
        val logs = mutableListOf<String>()
        val df = DecimalFormat("#.##")

        logs.add("[系统] 启动云市超级市场数字压力模拟器...")
        logs.add("[环境] 当前模拟情景: 【$mode】")

        when (mode) {
            "常规日" -> {
                simStoreCount.value = 20
                simSkuCount.value = 10000
                simActiveRiders.value = 15
                simThroughputKpi.value = "5.2 单/秒"
                simStockoutRateKpi.value = "0.8 %"
                logs.add("[数据库] PostgreSQL 读取延迟: 12ms, 数据库连接良好。")
                logs.add("[供应链] 区域中央仓发货时效: 12小时。")
                logs.add("[POS] 自助收银机平均结账用时: 35秒。")
            }
            "双11大促" -> {
                simStoreCount.value = 20
                simSkuCount.value = 10000
                simActiveRiders.value = 45 // extra riders hired
                simThroughputKpi.value = "118.6 单/秒 (高负载)"
                simStockoutRateKpi.value = "4.2 % (高销售损耗)"
                logs.add("[警告] Kafka 'order.paid' 队列高延迟阻塞 230ms！")
                logs.add("[系统] Redis 缓存命中率: 98.4%，拦截 92% 重复查询。")
                logs.add("[POS] 浦东店、陆家嘴店 POS 销售并发激增，系统自动开启备用数据库集群。")
            }
            "台风大暴雨" -> {
                simStoreCount.value = 20
                simSkuCount.value = 10000
                simActiveRiders.value = 8 // riders stay indoor for safety
                simThroughputKpi.value = "1.8 单/秒 (物流受阻)"
                simStockoutRateKpi.value = "1.2 %"
                logs.add("[警告] O2O 骑手派单时效延误至 55分钟！")
                logs.add("[传感器] 温湿度传感器在配送途中测得空气湿度达到 95%。")
                logs.add("[系统] 提醒顾客由于大雨配送运力紧张，页面自动切换至延迟提示。")
            }
            "供应链断裂" -> {
                simStoreCount.value = 20
                simSkuCount.value = 10000
                simActiveRiders.value = 12
                simThroughputKpi.value = "4.5 单/秒"
                simStockoutRateKpi.value = "18.5 % (极度缺货！)"
                logs.add("[核心] 补货PO 采购确认失败，供应商牛奶和苹果生产线受阻！")
                logs.add("[警告] 安全库存警戒线以下商品占比增加至 24%！")
                logs.add("[建议] 自动调整前端价格，减少秒杀活动，增加同品类替代品推荐。")
            }
        }
        logs.add("[系统] 压力测试执行完毕，健康等级: " + if (mode == "供应链断裂") "黄色警告" else "绿色优良")
        simLog.value = logs
    }
}

// Support Structs
data class CartItemDetail(
    val product: Product,
    val quantity: Int,
    val subtotal: Double
)

data class CartSummary(
    val items: List<CartItemDetail>,
    val totalOriginalAmount: Double,
    val promotionDiscount: Double,
    val couponDiscount: Double,
    val pointsDiscount: Double,
    val deliveryFee: Double,
    val finalPayable: Double,
    val buyMoreForPromoThreshold: Double,
    val recommendedPromoFiller: Product?
)

data class PosItem(
    val product: Product,
    val qty: Int
)

data class ShelfHeatmap(
    val areaName: String,
    val category: String,
    val skuCount: Int,
    val totalInventory: Int,
    val status: String // "Adequate", "Low", "Critical"
)

data class AreaHeat(
    val category: String,
    val areaName: String,
    val status: String
)

data class NlpReply(
    val conclusion: String,
    val factors: List<String>,
    val range: String,
    val confidence: Double,
    val advice: String
)
