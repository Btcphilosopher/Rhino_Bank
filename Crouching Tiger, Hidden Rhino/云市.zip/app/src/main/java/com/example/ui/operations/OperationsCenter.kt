package com.example.ui.operations

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Inventory
import com.example.ui.MainViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OperationsCenterScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val ordersList by viewModel.orders.collectAsState(initial = emptyList())
    val selectedStore by viewModel.selectedStore.collectAsState()
    
    val totalGmv = ordersList.sumOf { it.finalPayable }
    val onlineOrdersCount = ordersList.count { it.deliveryAddress != "线下销售" && it.deliveryAddress != "线下POS销售" && it.deliveryAddress != "客户自助收银终端" }
    val offlineOrdersCount = ordersList.size - onlineOrdersCount

    var isStressTesting by remember { mutableStateOf(false) }
    var stressTestScenario by remember { mutableStateOf("NORMAL") } // "WEEKEND", "TYPHOON", "PROMOTION"
    val systemLogsList = remember { mutableStateListOf("系统健康状况良好。DB 延迟: 1.2ms", "Kafka 消息中间件已连接...", "区域温控节点检测正常：16/16") }
    
    var lowStocksList by remember { mutableStateOf<List<Inventory>>(emptyList()) }
    val scope = rememberCoroutineScope()

    // Query out-of-stock items
    LaunchedEffect(selectedStore) {
        if (selectedStore != null) {
            val alerts = viewModel.repository.getSafetyStockBreaches(selectedStore!!.storeId, 20)
            lowStocksList = alerts
        }
    }

    // Stress testing simulation logs logic
    LaunchedEffect(isStressTesting, stressTestScenario) {
        if (isStressTesting) {
            while (isStressTesting) {
                delay(1200)
                val newLog = when (stressTestScenario) {
                    "WEEKEND" -> listOf(
                        "⚠️ 突发高频流量! POS 并发连接数上涨 230% [IP: 192.168.12.82]",
                        "🛡️ 会员积分账本分布式事务锁正常加锁，无行锁重试冲突",
                        "📊 离线库存扣减与实物称重传感器进行自动对账...",
                        "🟢 Redis 集群缓存命中率 94.6%，JVM 堆内存运行良好"
                    ).random()
                    "TYPHOON" -> listOf(
                        "🌧️ 外部气候预警：台风大雨，配送运力临时拉紧！",
                        "🛵 系统已自动将运力溢价补给提高 3.0元/单，保障江哥派送！",
                        "🔒 前置仓安全库存保护锁定启动，防止爆单超卖！",
                        "⚡ 订单延迟提醒已自动下发至 22 名客户 App 页面..."
                    ).random()
                    else -> listOf(
                        "🚀 秒杀大促爆发！并发写单达到 1,280 QPS！",
                        "🔥 自动降级非核心服务 (AI商品推荐模块已临时切换至本底静态队列)",
                        "🟢 Room/SQLite 线程池连接分配正常，未见死锁情况",
                        "📦 拣货专员库内指派线路已更新：乳制品一键合批处理完毕"
                    ).random()
                }
                systemLogsList.add(0, newLog)
                if (systemLogsList.size > 20) systemLogsList.removeAt(systemLogsList.lastIndex)
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("🏢 数字化超市运营大脑 Operations Tower", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = MaterialTheme.colorScheme.primary)
        Text("云市连锁大中华区 O2O 混合云中心调度台", fontSize = 11.sp, color = Color.Gray)

        Spacer(modifier = Modifier.height(16.dp))

        // 1. Double KPI Row Cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("💰 平台当日成交额 (GMV)", fontSize = 11.sp, color = Color.Gray)
                    Text(
                        text = "¥" + String.format("%.2f", totalGmv),
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text("订单总量: ${ordersList.size} 笔", fontSize = 10.sp, color = Color.Gray)
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("🌐 O2O 线上线下比率", fontSize = 11.sp, color = Color.Gray)
                    Text(
                        text = "${onlineOrdersCount}单 / ${offlineOrdersCount}单",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    // Linear ratio visualizer
                    Spacer(modifier = Modifier.height(6.dp))
                    val ratio = if (ordersList.isEmpty()) 0.5f else onlineOrdersCount.toFloat() / ordersList.size
                    LinearProgressIndicator(
                        progress = { ratio },
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 2. Supply Chain: Procurement & Out of Stock Alerts
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("🚨 安全库存不足告警 (${lowStocksList.size}件)", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.Red)
                    Button(
                        onClick = {
                            scope.launch {
                                if (selectedStore != null) {
                                    lowStocksList.forEach { inv ->
                                        viewModel.repository.replenishInventory(selectedStore!!.storeId, inv.productId, 150)
                                    }
                                    val alerts = viewModel.repository.getSafetyStockBreaches(selectedStore!!.storeId, 20)
                                    lowStocksList = alerts
                                    systemLogsList.add(0, "✅ 自动供应链补货单已批复：已向下游发货区域补齐安全库存！")
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        contentPadding = PaddingValues(horizontal = 10.dp),
                        modifier = Modifier.height(28.dp)
                    ) {
                        Text("一键自动补仓", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                if (lowStocksList.isEmpty()) {
                    Text("🟩 全店 SKU 库存充足，未发生安全库存水位线报警 (20件以下)", fontSize = 12.sp, color = Color(0xFF385723))
                } else {
                    lowStocksList.take(3).forEach { inv ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "商品ID: ${inv.productId} (前置仓)", fontSize = 12.sp, color = Color.Black)
                            Text(text = "当前可用: ${inv.getAvailable()} 件 | 安全水位: 20件", fontSize = 11.sp, color = Color.Red, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 3. Stress Simulator Panel (Highly requested by user!)
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("⚡ 系统极端大促/天气压力模拟器", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.Black)
                Text("模拟现实高并发业务场景，压力测试分布式事务锁并发安全性", fontSize = 11.sp, color = Color.Gray)

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ElevatedFilterChip(
                        selected = stressTestScenario == "WEEKEND",
                        onClick = {
                            stressTestScenario = "WEEKEND"
                            isStressTesting = true
                            systemLogsList.add(0, "🚀 【压力启动】模拟周末大采购高流量，开始观测锁竞争。")
                        },
                        label = { Text("周末高峰", fontSize = 11.sp) }
                    )

                    ElevatedFilterChip(
                        selected = stressTestScenario == "TYPHOON",
                        onClick = {
                            stressTestScenario = "TYPHOON"
                            isStressTesting = true
                            viewModel.mockWeather.value = "台风暴雨大风 21℃"
                            systemLogsList.add(0, "🌧️ 【压力启动】模拟台风大雨，配送订单急增 400% 遥测启动。")
                        },
                        label = { Text("台风突袭", fontSize = 11.sp) }
                    )

                    ElevatedFilterChip(
                        selected = stressTestScenario == "PROMOTION",
                        onClick = {
                            stressTestScenario = "PROMOTION"
                            isStressTesting = true
                            systemLogsList.add(0, "🔥 【压力启动】模拟全场秒杀抢购大促，QPS 峰值上升！")
                        },
                        label = { Text("整点秒杀", fontSize = 11.sp) }
                    )
                }

                if (isStressTesting) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = {
                            isStressTesting = false
                            stressTestScenario = "NORMAL"
                            systemLogsList.add(0, "⏹️ 【测试结束】压力仿真模型关闭，系统回归稳态。")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("关闭压力模拟", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 4. Live Log console scroll pane
        Text("🖥️ 平台核心高并发监控日志 (Reactive Streams)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Black)
        Spacer(modifier = Modifier.height(6.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .background(Color.Black, RoundedCornerShape(4.dp))
                .border(1.dp, Color.LightGray.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                .padding(12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
            ) {
                systemLogsList.forEach { log ->
                    Text(
                        text = ">>> $log",
                        color = if (log.contains("⚠️") || log.contains("突发")) Color.Yellow else if (log.contains("✅") || log.contains("🟢")) Color.Green else Color.White,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        lineHeight = 13.sp,
                        modifier = Modifier.padding(vertical = 2.dp)
                    )
                }
            }
        }
    }
}
