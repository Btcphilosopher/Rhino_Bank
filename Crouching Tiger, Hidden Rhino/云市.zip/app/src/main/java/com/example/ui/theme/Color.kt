package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Color Palette: 云市 CloudMarket
val BrandGreen = Color(0xFF2E6F40)       // Primary: Fresh organic supermarket green
val BrandBlue = Color(0xFF1B3B6F)        // Secondary: High-tech digital logistics deep blue
val BrandOrange = Color(0xFFE07A5F)      // Tertiary: Rapid instant delivery warm orange

val OffWhite = Color(0xFFFAF9F6)         // Background: Warm spacious rice-white
val White = Color(0xFFFFFFFF)            // Surface: Pure crisp modern shelf white
val DarkGrey = Color(0xFF1A1C1E)         // Text Primary: Modern elegant dark grey
val LightGrey = Color(0xFFE1E2E5)        // Borders & Dividers

val Green80 = Color(0xFF8CD898)
val Blue80 = Color(0xFF98B9EB)
val Orange80 = Color(0xFFF0AFA1)

val Green40 = Color(0xFF2E6F40)
val Blue40 = Color(0xFF1B3B6F)
val Orange40 = Color(0xFFE07A5F)
