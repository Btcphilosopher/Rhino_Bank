package com.example.ui.consumer

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Coupon
import com.example.data.Product
import androidx.compose.foundation.BorderStroke
import kotlinx.coroutines.launch
import com.example.ui.CartSummary
import com.example.ui.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CartScreen(
    viewModel: MainViewModel,
    onNavigateToOrderTracking: () -> Unit,
    modifier: Modifier = Modifier
) {
    val cartItemsList by viewModel.cartItems.collectAsState(initial = emptyList())
    val productsList by viewModel.allProducts.collectAsState(initial = emptyList())
    val selectedStore by viewModel.selectedStore.collectAsState()
    val selectedCoupon by viewModel.selectedCoupon.collectAsState()
    val usePoints by viewModel.usePointsForCheckout.collectAsState()
    val deliveryType by viewModel.checkoutDeliveryType.collectAsState()
    val couponsList by viewModel.coupons.collectAsState(initial = emptyList())

    val cartSummary = viewModel.getCartSummary(cartItemsList, productsList)

    var showCouponSelector by remember { mutableStateOf(false) }
    var showCheckoutSheet by remember { mutableStateOf(false) }
    var checkoutAddress by remember { mutableStateOf("上海市浦东新区张江高科中科路128号") }
    var selectedPaymentMethod by remember { mutableStateOf("MockPayment") }

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text("购物车", fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                actions = {
                    if (cartItemsList.isNotEmpty()) {
                        TextButton(
                            onClick = { scope.launch { viewModel.clearCart() } },
                            modifier = Modifier.testTag("clear_cart_btn")
                        ) {
                            Text("清空", color = MaterialTheme.colorScheme.primary)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        bottomBar = {
            if (cartItemsList.isNotEmpty()) {
                Surface(
                    tonalElevation = 8.dp,
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .navigationBarsPadding()
                            .padding(16.dp)
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("应付金额: ", fontSize = 13.sp, color = Color.Gray)
                                    if (cartSummary.promotionDiscount + cartSummary.couponDiscount > 0) {
                                        Text(
                                            text = "¥" + String.format("%.2f", cartSummary.totalOriginalAmount),
                                            fontSize = 11.sp,
                                            color = Color.Gray,
                                            style = androidx.compose.ui.text.TextStyle(textDecoration = TextDecoration.LineThrough),
                                            modifier = Modifier.padding(horizontal = 4.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = "¥" + String.format("%.2f", cartSummary.finalPayable),
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.testTag("cart_payable_price")
                                )
                            }

                            Button(
                                onClick = { showCheckoutSheet = true },
                                shape = RoundedCornerShape(24.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                modifier = Modifier
                                    .height(48.dp)
                                    .widthIn(min = 150.dp)
                                    .testTag("checkout_btn")
                            ) {
                                Text("立即结算", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        if (cartItemsList.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    Icons.Default.RemoveShoppingCart,
                    contentDescription = "购物车为空",
                    modifier = Modifier.size(72.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "您的购物车还是空的",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "快去首页挑选新鲜的食材吧！",
                    fontSize = 13.sp,
                    color = Color.Gray
                )
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background)
                    .verticalScroll(rememberScrollState())
            ) {
                // 1. Store Header Label
                Surface(
                    color = Color.White,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Storefront, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = selectedStore?.name ?: "云市超市",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color.Black
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "配送服务已开启",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // 2. Promotion Optimizer Banner (满59减10)
                PromotionOptimizerBanner(
                    summary = cartSummary,
                    onAddFiller = { filler ->
                        viewModel.addToCart(filler.productId)
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))

                // 3. Cart Items list
                Card(
                    shape = RoundedCornerShape(0.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                        cartSummary.items.forEachIndexed { index, item ->
                            CartProductRow(
                                item = item,
                                onAdd = { viewModel.updateCartQty(item.product.productId, item.quantity + 1) },
                                onMinus = { viewModel.updateCartQty(item.product.productId, item.quantity - 1) },
                                onDelete = { viewModel.removeFromCart(item.product.productId) }
                            )
                            if (index < cartSummary.items.lastIndex) {
                                HorizontalDivider(color = Color.LightGray.copy(alpha = 0.3f))
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // 4. Coupons Selection Row
                Card(
                    shape = RoundedCornerShape(0.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .clickable { showCouponSelector = true }
                            .padding(16.dp)
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CardMembership, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("使用店铺优惠券", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Color.Black)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = selectedCoupon?.name ?: "查看可用优惠券 (${couponsList.size}张)",
                                fontSize = 13.sp,
                                color = if (selectedCoupon != null) MaterialTheme.colorScheme.primary else Color.Gray,
                                fontWeight = if (selectedCoupon != null) FontWeight.Bold else FontWeight.Normal
                            )
                            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.Gray)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // 5. Member Points Deduction Row (Redeem 500 pts for 5 yuan)
                Card(
                    shape = RoundedCornerShape(0.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.GeneratingTokens, contentDescription = null, tint = Color(0xFFFFB900))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("积分抵扣现金", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Color.Black)
                                Text("可用 2840 积分，消耗 500 积分抵扣 5.00 元", fontSize = 11.sp, color = Color.Gray)
                            }
                        }
                        Switch(
                            checked = usePoints,
                            onCheckedChange = { viewModel.toggleUsePoints() },
                            modifier = Modifier.testTag("points_switch")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // 6. Comprehensive Bill Breakdown
                Card(
                    shape = RoundedCornerShape(0.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("费用明细", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.Black)
                        Spacer(modifier = Modifier.height(10.dp))

                        val summaryRows = listOf(
                            "商品小计" to "¥" + String.format("%.2f", cartSummary.totalOriginalAmount),
                            "店铺满减折扣 (满59减10)" to "-¥" + String.format("%.2f", cartSummary.promotionDiscount),
                            "优惠券抵扣" to "-¥" + String.format("%.2f", cartSummary.couponDiscount),
                            "积分抵扣金额" to "-¥" + String.format("%.2f", cartSummary.pointsDiscount),
                            "即时冷链运费" to "+¥" + String.format("%.2f", cartSummary.deliveryFee)
                        )

                        summaryRows.forEach { (label, valText) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 5.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(label, fontSize = 12.sp, color = Color.Gray)
                                Text(
                                    valText,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = if (valText.startsWith("-")) MaterialTheme.colorScheme.primary else Color.Black
                                )
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(30.dp))
            }
        }

        // Coupon selection sheets
        if (showCouponSelector) {
            CouponSelectorDialog(
                coupons = couponsList,
                selectedCoupon = selectedCoupon,
                onSelect = {
                    viewModel.selectCoupon(it)
                    showCouponSelector = false
                },
                onDismiss = { showCouponSelector = false }
            )
        }

        // Checkout Dialog modal Sheet
        if (showCheckoutSheet) {
            CheckoutSetupDialog(
                payable = cartSummary.finalPayable,
                address = checkoutAddress,
                onAddressChange = { checkoutAddress = it },
                deliveryType = deliveryType,
                onDeliveryTypeSelect = { viewModel.setDeliveryType(it) },
                paymentMethod = selectedPaymentMethod,
                onPaymentSelect = { selectedPaymentMethod = it },
                onConfirm = {
                    viewModel.submitCheckout(
                        summary = cartSummary,
                        onPaymentSuccess = { orderId ->
                            showCheckoutSheet = false
                            onNavigateToOrderTracking()
                        },
                        onPaymentFailed = { error ->
                            scope.launch {
                                snackbarHostState.showSnackbar(error)
                            }
                        }
                    )
                },
                onDismiss = { showCheckoutSheet = false }
            )
        }
    }
}

@Composable
fun PromotionOptimizerBanner(
    summary: CartSummary,
    onAddFiller: (Product) -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.08f),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary.copy(alpha = 0.3f)),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "🏷️ 云市满减特惠",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.tertiary
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "全场满 ¥59 立减 ¥10",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }

                Text(
                    text = if (summary.totalOriginalAmount >= 59.0) "已享【减10元】" else "还差 ¥" + String.format("%.2f", summary.buyMoreForPromoThreshold),
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = if (summary.totalOriginalAmount >= 59.0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.tertiary
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Progress bar
            LinearProgressIndicator(
                progress = { (summary.totalOriginalAmount / 59.0).coerceAtMost(1.0).toFloat() },
                color = if (summary.totalOriginalAmount >= 59.0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.tertiary,
                trackColor = Color.LightGray.copy(alpha = 0.3f),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
            )

            // Recommed filler items if close to goal
            if (summary.totalOriginalAmount > 0.0 && summary.totalOriginalAmount < 59.0 && summary.recommendedPromoFiller != null) {
                val filler = summary.recommendedPromoFiller
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White.copy(alpha = 0.8f), RoundedCornerShape(6.dp))
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Column {
                            Text(
                                text = "建议凑单：${filler.name}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Black,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(text = "规格: ${filler.specification} | ¥${filler.price}", fontSize = 10.sp, color = Color.Gray)
                        }
                    }

                    Button(
                        onClick = { onAddFiller(filler) },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary),
                        contentPadding = PaddingValues(horizontal = 10.dp),
                        modifier = Modifier
                            .height(28.dp)
                            .testTag("filler_add_btn")
                    ) {
                        Text("一键凑单", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun CartProductRow(
    item: com.example.ui.CartItemDetail,
    onAdd: () -> Unit,
    onMinus: () -> Unit,
    onDelete: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Thumbnail mock
        Box(
            modifier = Modifier
                .size(60.dp)
                .background(Color(0xFFF0F2F5), RoundedCornerShape(4.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = when (item.product.category) {
                    "肉禽蛋奶" -> Icons.Default.Favorite
                    "生鲜水果" -> Icons.Default.Star
                    "粮油调味" -> Icons.Default.Home
                    "零食饮料" -> Icons.Default.Info
                    "酒水" -> Icons.Default.Star
                    "家清" -> Icons.Default.Check
                    "个护" -> Icons.Default.Face
                    "母婴" -> Icons.Default.Person
                    "宠物" -> Icons.Default.Favorite
                    else -> Icons.Default.ShoppingCart
                },
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
                modifier = Modifier.size(24.dp)
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        // Product text & Price
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = item.product.name,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = Color.Black,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(text = "规格: ${item.product.specification}", fontSize = 11.sp, color = Color.Gray)
            
            Row(
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.padding(top = 4.dp)
            ) {
                Text(
                    text = "¥" + item.product.memberPrice,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "原价 ¥" + item.product.price,
                    fontSize = 11.sp,
                    color = Color.Gray,
                    style = androidx.compose.ui.text.TextStyle(textDecoration = TextDecoration.LineThrough)
                )
            }
        }

        // Qty adjust controls
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            IconButton(
                onClick = onMinus,
                colors = IconButtonDefaults.iconButtonColors(containerColor = Color.LightGray.copy(alpha = 0.2f)),
                modifier = Modifier.size(28.dp)
            ) {
                Icon(Icons.Default.Remove, contentDescription = "减一", modifier = Modifier.size(14.dp))
            }

            Text(
                text = "${item.quantity}",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = Color.Black,
                modifier = Modifier.padding(horizontal = 6.dp)
            )

            IconButton(
                onClick = onAdd,
                colors = IconButtonDefaults.iconButtonColors(containerColor = Color.LightGray.copy(alpha = 0.2f)),
                modifier = Modifier.size(28.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = "加一", modifier = Modifier.size(14.dp))
            }

            Spacer(modifier = Modifier.width(4.dp))

            IconButton(
                onClick = onDelete,
                colors = IconButtonDefaults.iconButtonColors(contentColor = Color.Red.copy(alpha = 0.6f)),
                modifier = Modifier.size(28.dp)
            ) {
                Icon(Icons.Default.DeleteOutline, contentDescription = "删除", modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
fun CouponSelectorDialog(
    coupons: List<Coupon>,
    selectedCoupon: Coupon?,
    onSelect: (Coupon?) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("选择可用优惠券", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
        text = {
            Column(modifier = Modifier.heightIn(max = 300.dp).verticalScroll(rememberScrollState())) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelect(null) }
                        .padding(vertical = 12.dp, horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = selectedCoupon == null, onClick = { onSelect(null) })
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("不使用优惠券", fontSize = 14.sp, color = Color.Black)
                }
                HorizontalDivider(color = Color.LightGray.copy(alpha = 0.3f))

                coupons.forEach { coupon ->
                    val isSelected = coupon.couponId == selectedCoupon?.couponId
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelect(coupon) }
                            .padding(vertical = 12.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = isSelected, onClick = { onSelect(coupon) })
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    color = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = coupon.type,
                                        color = MaterialTheme.colorScheme.tertiary,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(coupon.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Black)
                            }
                            Text(coupon.description, fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                    HorizontalDivider(color = Color.LightGray.copy(alpha = 0.3f))
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("取消")
            }
        }
    )
}

@Composable
fun CheckoutSetupDialog(
    payable: Double,
    address: String,
    onAddressChange: (String) -> Unit,
    deliveryType: String,
    onDeliveryTypeSelect: (String) -> Unit,
    paymentMethod: String,
    onPaymentSelect: (String) -> Unit,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("确认订单信息", fontWeight = FontWeight.Bold, fontSize = 18.sp) },
        text = {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .fillMaxWidth()
            ) {
                // 1. Delivery Option
                Text("配送方式", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Black)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ElevatedFilterChip(
                        selected = deliveryType == "DELIVERY",
                        onClick = { onDeliveryTypeSelect("DELIVERY") },
                        label = { Text("即时冷链配送") }
                    )
                    ElevatedFilterChip(
                        selected = deliveryType == "PICKUP",
                        onClick = { onDeliveryTypeSelect("PICKUP") },
                        label = { Text("到店自提") }
                    )
                }

                if (deliveryType == "DELIVERY") {
                    Text("收货地址", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Black)
                    OutlinedTextField(
                        value = address,
                        onValueChange = onAddressChange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        singleLine = true,
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp)
                    )
                } else {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.LightGray.copy(alpha = 0.15f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                    ) {
                        Text(
                            text = "🏬 自提地址：云市上海浦东店柜台（备货完成将发送取货小票至您的订单列表）",
                            fontSize = 11.sp,
                            modifier = Modifier.padding(10.dp),
                            color = Color.Black
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // 2. Payment Selector
                Text("支付渠道 (Mock验证)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Black)
                val paymentChannels = listOf(
                    "MockPayment" to "云市安全付 (推荐)",
                    "微信支付" to "微信支付",
                    "支付宝" to "支付宝",
                    "云市余额" to "账户钱包余额"
                )

                paymentChannels.forEach { (code, name) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onPaymentSelect(code) }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = paymentMethod == code, onClick = { onPaymentSelect(code) })
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(name, fontSize = 13.sp, color = Color.Black)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier.testTag("confirm_pay_btn")
            ) {
                Text("确认支付 ¥" + String.format("%.2f", payable))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("返回")
            }
        }
    )
}
