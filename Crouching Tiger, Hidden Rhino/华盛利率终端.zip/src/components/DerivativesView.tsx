/**
 * 华盛利率终端 - 利率衍生品分析中心 (IRS, 国债期货, 利率期权)
 * HUASHENG RATES - Derivatives Engine (IRS, Treasury Futures CTD/IRR/Basis & Black-76 Rate Options)
 */

import React, { useState } from 'react';
import { useRatesStore } from '../stores/useRatesStore';
import { analyzeTreasuryFutures, calculateBlack76RateOption, calculateIRSPricing } from '../quant/swapsAndFutures';
import { Repeat, Sliders, DollarSign, Activity, FileSpreadsheet } from 'lucide-react';

export const DerivativesView: React.FC = () => {
  const { swapCurve } = useRatesStore();

  const [activeSubTab, setActiveSubTab] = useState<'IRS' | 'FUTURES' | 'OPTIONS'>('IRS');

  // IRS 选定合约
  const [irsFixedRate, setIrsFixedRate] = useState<number>(2.20);
  const [irsNotional, setIrsNotional] = useState<number>(1000); // 万元

  // 国债期货价格
  const [tPrice, setTPrice] = useState<number>(104.85);

  // 期权输入
  const [optType, setOptType] = useState<'CAP' | 'FLOOR' | 'SWAPTION'>('SWAPTION');
  const [underlyingRate, setUnderlyingRate] = useState<number>(2.20);
  const [strikeRate, setStrikeRate] = useState<number>(2.25);
  const [volatility, setVolatility] = useState<number>(25.0); // %
  const [notionalOpt, setNotionalOpt] = useState<number>(1000); // 万元

  // 计算 IRS
  const swapCurveRatesMap: Record<string, number> = {};
  swapCurve.points.forEach((p) => {
    swapCurveRatesMap[p.tenor] = p.yield;
  });

  const irsResult = calculateIRSPricing(
    {
      id: 'irs-1',
      contractCode: 'FR007_IRS_5Y',
      notional: irsNotional,
      fixedRate: irsFixedRate,
      floatingIndex: 'FR007',
      paymentFrequency: 1,
      tenor: '5Y',
      pv: 0,
      dv01: 0,
      duration: 0
    },
    swapCurveRatesMap
  );

  // 计算国债期货 CTD
  const futuresResult = analyzeTreasuryFutures('T2409', tPrice, [
    { code: '240010.IB', cleanPrice: 100.18, coupon: 2.18, cf: 0.9525 },
    { code: '240004.IB', cleanPrice: 100.48, coupon: 2.05, cf: 0.9560 },
    { code: '230026.IB', cleanPrice: 101.20, coupon: 2.65, cf: 0.9610 }
  ]);

  // 计算 Black-76 利率期权
  const optionResult = calculateBlack76RateOption({
    type: optType,
    underlyingRate,
    strikeRate,
    timeToMaturityYears: 1.0,
    volatility,
    notional: notionalOpt,
    modelUsed: 'Black-76'
  });

  return (
    <div className="p-4 space-y-4 font-mono text-slate-100 select-none">
      {/* 顶部标签切换 */}
      <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg flex items-center justify-between text-xs">
        <div className="flex items-center space-x-3">
          <div className="flex space-x-1">
            {[
              { id: 'IRS', label: '利率互换 (IRS)' },
              { id: 'FUTURES', label: '国债期货 (Treasury Futures)' },
              { id: 'OPTIONS', label: '利率期权 (Cap/Floor/Swaption)' }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveSubTab(tab.id as any)}
                className={`px-3 py-1.5 rounded font-bold transition-colors ${
                  activeSubTab === tab.id
                    ? 'bg-amber-500 text-slate-950 shadow-sm'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
        <span className="text-slate-400">华盛衍生品定价与风险引擎 v1.0</span>
      </div>

      {/* 1. IRS 利率互换分析 */}
      {activeSubTab === 'IRS' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-3">
            <h2 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-2">
              IRS 掉期合约参数
            </h2>
            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">名义本金 (万元):</label>
                <input
                  type="number"
                  value={irsNotional}
                  onChange={(e) => setIrsNotional(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-700 text-amber-400 font-bold px-2 py-1.5 rounded outline-none"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">固定端利率 (Fixed Rate) %:</label>
                <input
                  type="number"
                  step="0.01"
                  value={irsFixedRate}
                  onChange={(e) => setIrsFixedRate(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-700 text-slate-100 font-bold px-2 py-1.5 rounded outline-none"
                />
              </div>

              <div className="text-[11px] text-slate-400 space-y-1 pt-2 border-t border-slate-800">
                <p>浮动端基准: FR007 (7天回购定盘利率)</p>
                <p>期限: 5年 (5Y)</p>
                <p>当前市场互换率: {swapCurveRatesMap['5Y'] || 2.20}%</p>
              </div>
            </div>
          </div>

          <div className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-3">
            <h2 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-2">
              IRS 定价与 DV01 风险分析结果
            </h2>

            <div className="grid grid-cols-3 gap-3 text-xs font-mono">
              <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
                <span className="text-slate-400 text-[11px] block">净现值 (PV):</span>
                <span
                  className={`text-xl font-bold ${
                    irsResult.pv >= 0 ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {irsResult.pv >= 0 ? `+¥${irsResult.pv.toLocaleString()}` : `-¥${Math.abs(irsResult.pv).toLocaleString()}`}
                </span>
              </div>

              <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
                <span className="text-slate-400 text-[11px] block">DV01 (每 1bp 变动):</span>
                <span className="text-amber-400 text-xl font-bold">¥{irsResult.dv01}</span>
              </div>

              <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
                <span className="text-slate-400 text-[11px] block">久期 (Duration):</span>
                <span className="text-cyan-400 text-xl font-bold">{irsResult.duration} 年</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. 国债期货 CTD 分析 */}
      {activeSubTab === 'FUTURES' && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-3 font-mono">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h2 className="text-sm font-bold text-slate-200 font-sans">
              10年国债期货主连 (T2409) CTD 与 IRR 分析
            </h2>
            <div className="flex items-center space-x-2 text-xs">
              <span className="text-slate-400">期货最新价:</span>
              <input
                type="number"
                step="0.01"
                value={tPrice}
                onChange={(e) => setTPrice(Number(e.target.value))}
                className="w-24 bg-slate-950 border border-slate-700 text-amber-400 font-bold px-2 py-0.5 rounded outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-4 gap-3 text-xs">
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
              <span className="text-slate-400 block text-[11px]">最便宜可交割债 (CTD):</span>
              <span className="text-amber-400 text-base font-bold">{futuresResult.ctdBondCode}</span>
            </div>
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
              <span className="text-slate-400 block text-[11px]">隐含回购利率 (IRR):</span>
              <span className="text-emerald-400 text-base font-bold">{futuresResult.impliedRepoRate}%</span>
            </div>
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
              <span className="text-slate-400 block text-[11px]">毛基差 (Gross Basis):</span>
              <span className="text-slate-100 text-base font-bold">{futuresResult.grossBasis} 元</span>
            </div>
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
              <span className="text-slate-400 block text-[11px]">转换因子 (CF):</span>
              <span className="text-cyan-400 text-base font-bold">{futuresResult.conversionFactor}</span>
            </div>
          </div>
        </div>
      )}

      {/* 3. Black-76 利率期权定价 */}
      {activeSubTab === 'OPTIONS' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 font-mono">
          <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-3">
            <h2 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-2">
              Black-76 利率期权参数
            </h2>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">期权类型:</label>
                <select
                  value={optType}
                  onChange={(e) => setOptType(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-700 text-amber-400 font-bold px-2 py-1 rounded outline-none"
                >
                  <option value="SWAPTION">Swaption (利率掉期期权)</option>
                  <option value="CAP">Cap (利率上限)</option>
                  <option value="FLOOR">Floor (利率下限)</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">标的远期利率 %:</label>
                <input
                  type="number"
                  step="0.01"
                  value={underlyingRate}
                  onChange={(e) => setUnderlyingRate(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-700 text-slate-100 px-2 py-1 rounded outline-none"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">执行利率 (Strike Rate) %:</label>
                <input
                  type="number"
                  step="0.01"
                  value={strikeRate}
                  onChange={(e) => setStrikeRate(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-700 text-slate-100 px-2 py-1 rounded outline-none"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">隐含波动率 (Implied Vol) %:</label>
                <input
                  type="number"
                  step="0.5"
                  value={volatility}
                  onChange={(e) => setVolatility(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-700 text-amber-400 px-2 py-1 rounded outline-none"
                />
              </div>
            </div>
          </div>

          <div className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-3">
            <h2 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-2">
              Black-76 理论权价与希腊字母 (Greeks)
            </h2>

            <div className="grid grid-cols-3 gap-3 text-xs">
              <div className="bg-slate-950 p-3 rounded border border-slate-800 col-span-3">
                <span className="text-slate-400 block text-[11px]">期权理论权利金 (Option Price):</span>
                <span className="text-amber-400 text-2xl font-bold">¥{optionResult.price.toLocaleString()}</span>
              </div>

              <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                <span className="text-slate-400 block text-[11px]">Delta (Δ):</span>
                <span className="text-slate-100 font-bold text-base">{optionResult.delta}</span>
              </div>

              <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                <span className="text-slate-400 block text-[11px]">Gamma (Γ):</span>
                <span className="text-slate-100 font-bold text-base">{optionResult.gamma}</span>
              </div>

              <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                <span className="text-slate-400 block text-[11px]">Vega (ν):</span>
                <span className="text-cyan-400 font-bold text-base">¥{optionResult.vega}</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
