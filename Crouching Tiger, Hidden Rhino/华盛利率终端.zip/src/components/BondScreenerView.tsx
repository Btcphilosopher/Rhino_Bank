/**
 * 华盛利率终端 - 债券筛选器中心
 * HUASHENG RATES - Bond Screener & Filtering System
 */

import React, { useState } from 'react';
import { useRatesStore } from '../stores/useRatesStore';
import { Filter, Search, Download, FileSpreadsheet } from 'lucide-react';

export const BondScreenerView: React.FC = () => {
  const { bondsList, setSelectedBond, setActiveTab } = useRatesStore();

  const [sectorFilter, setSectorFilter] = useState<string>('ALL');
  const [minYield, setMinYield] = useState<number>(1.5);
  const [maxYield, setMaxYield] = useState<number>(4.0);
  const [searchTerm, setSearchTerm] = useState<string>('');

  const filteredBonds = bondsList.filter((b) => {
    if (sectorFilter !== 'ALL' && b.sector !== sectorFilter) return false;
    if (b.yield < minYield || b.yield > maxYield) return false;
    if (searchTerm && !b.name.includes(searchTerm) && !b.code.toLowerCase().includes(searchTerm.toLowerCase())) return false;
    return true;
  });

  return (
    <div className="p-4 space-y-4 font-mono text-slate-100 select-none">
      <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg flex items-center justify-between text-xs">
        <div className="flex items-center space-x-2">
          <Filter className="w-4 h-4 text-amber-500" />
          <h2 className="text-sm font-bold text-slate-200 font-sans">多维度全量债券筛选器</h2>
        </div>
        <span className="text-slate-400">符合筛选条件的债券: <strong className="text-amber-400">{filteredBonds.length}</strong> 只</span>
      </div>

      {/* 筛选条 */}
      <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-lg grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
        <div>
          <label className="text-slate-400 block mb-1">债券板块 (Sector):</label>
          <select
            value={sectorFilter}
            onChange={(e) => setSectorFilter(e.target.value)}
            className="w-full bg-slate-950 border border-slate-700 text-amber-400 font-bold px-2 py-1.5 rounded outline-none"
          >
            <option value="ALL">全部板块</option>
            <option value="国债">国债 (CGB)</option>
            <option value="政金债">政金债 (Policy Bank)</option>
            <option value="地方政府债">地方政府债</option>
            <option value="产业债">产业企债</option>
            <option value="同业存单">同业存单 (NCD)</option>
          </select>
        </div>

        <div>
          <label className="text-slate-400 block mb-1">YTM 收益率范围 (%): {minYield}% ~ {maxYield}%</label>
          <div className="flex space-x-2 items-center">
            <input
              type="number"
              step="0.1"
              value={minYield}
              onChange={(e) => setMinYield(Number(e.target.value))}
              className="w-20 bg-slate-950 border border-slate-700 text-slate-100 px-1 py-1 rounded text-center outline-none"
            />
            <span className="text-slate-500">-</span>
            <input
              type="number"
              step="0.1"
              value={maxYield}
              onChange={(e) => setMaxYield(Number(e.target.value))}
              className="w-20 bg-slate-950 border border-slate-700 text-slate-100 px-1 py-1 rounded text-center outline-none"
            />
          </div>
        </div>

        <div>
          <label className="text-slate-400 block mb-1">代码/名称快速搜索:</label>
          <div className="flex items-center bg-slate-950 border border-slate-700 rounded px-2 py-1">
            <Search className="w-3.5 h-3.5 text-slate-500 mr-2" />
            <input
              type="text"
              placeholder="搜索..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-transparent text-slate-100 text-xs outline-none w-full"
            />
          </div>
        </div>

        <div className="flex items-end">
          <button
            onClick={() => {
              const csvContent = "data:text/csv;charset=utf-8," + "代码,名称,板块,到期收益率,票面利率,发行人\n" + filteredBonds.map(b => `${b.code},${b.name},${b.sector},${b.yield},${b.couponRate},${b.issuer}`).join("\n");
              const encodedUri = encodeURI(csvContent);
              const link = document.createElement("a");
              link.setAttribute("href", encodedUri);
              link.setAttribute("download", "huasheng_bonds_export.csv");
              document.body.appendChild(link);
              link.click();
              document.body.removeChild(link);
            }}
            className="w-full bg-slate-800 hover:bg-slate-700 text-amber-400 font-bold py-1.5 rounded flex items-center justify-center space-x-1.5 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>导出 CSV 数据表</span>
          </button>
        </div>
      </div>

      {/* 结果表格 */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-950">
                <th className="p-2">代码 / 名称</th>
                <th className="p-2">板块</th>
                <th className="p-2">发行人</th>
                <th className="p-2">评级</th>
                <th className="p-2 text-right">票面 (%)</th>
                <th className="p-2 text-right">最新 YTM (%)</th>
                <th className="p-2 text-right">最新净价 (元)</th>
                <th className="p-2 text-right">到期日</th>
                <th className="p-2 text-center">操作</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/40 font-mono">
              {filteredBonds.map((bond) => (
                <tr key={bond.id} className="hover:bg-slate-800/50">
                  <td className="p-2 font-bold text-amber-400">
                    {bond.code} <span className="text-slate-200 font-sans font-normal">{bond.name}</span>
                  </td>
                  <td className="p-2 text-slate-300 font-sans">{bond.sector}</td>
                  <td className="p-2 text-slate-400 font-sans">{bond.issuer}</td>
                  <td className="p-2 text-emerald-400 font-bold">{bond.rating}</td>
                  <td className="p-2 text-right text-slate-300">{bond.couponRate.toFixed(2)}%</td>
                  <td className="p-2 text-right text-amber-400 font-bold">{bond.yield.toFixed(2)}%</td>
                  <td className="p-2 text-right text-slate-200">¥{bond.price.toFixed(2)}</td>
                  <td className="p-2 text-right text-slate-400">{bond.maturityDate}</td>
                  <td className="p-2 text-center">
                    <button
                      onClick={() => {
                        setSelectedBond(bond);
                        setActiveTab(2); // 单券分析
                      }}
                      className="bg-slate-800 hover:bg-amber-500 hover:text-slate-950 text-slate-300 px-2 py-0.5 rounded text-[10px] transition-colors"
                    >
                      深度分析
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
