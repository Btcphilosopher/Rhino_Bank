/**
 * 华盛利率终端 - 主菜单导航栏
 * HUASHENG RATES - Terminal Main Navigation Bar
 */

import React from 'react';
import { useRatesStore } from '../stores/useRatesStore';
import {
  BarChart3,
  TrendingUp,
  FileSpreadsheet,
  PieChart,
  Layers,
  Zap,
  History,
  Repeat,
  Cpu,
  ShieldCheck,
  Scale,
  Filter,
  BookOpen,
  Bot
} from 'lucide-react';

export const NAV_ITEMS = [
  { id: 0, label: '市场总览', icon: BarChart3 },
  { id: 1, label: '收益率曲线', icon: TrendingUp },
  { id: 2, label: '单券分析', icon: FileSpreadsheet },
  { id: 3, label: '组合分析', icon: PieChart },
  { id: 4, label: '关键期限久期', icon: Layers },
  { id: 5, label: '情景实验室', icon: Zap },
  { id: 6, label: '历史与PCA', icon: History },
  { id: 7, label: '衍生品分析', icon: Repeat },
  { id: 8, label: '利率模型', icon: Cpu },
  { id: 9, label: '风险VaR', icon: ShieldCheck },
  { id: 10, label: '相对价值', icon: Scale },
  { id: 11, label: '债券筛选器', icon: Filter },
  { id: 12, label: '研究工作台', icon: BookOpen },
  { id: 13, label: '华盛利率助手', icon: Bot, isAi: true }
];

export const Navbar: React.FC = () => {
  const { activeTab, setActiveTab } = useRatesStore();

  return (
    <nav className="bg-slate-900/90 border-b border-slate-800 text-slate-300 px-2 flex items-center overflow-x-auto scrollbar-none select-none">
      <div className="flex space-x-1 py-1">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded text-xs font-medium transition-all whitespace-nowrap ${
                isActive
                  ? item.isAi
                    ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/10'
                    : 'bg-slate-800 text-amber-400 font-semibold border-b-2 border-amber-400'
                  : item.isAi
                  ? 'bg-amber-500/10 text-amber-400 hover:bg-amber-500/20 border border-amber-500/30 font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${item.isAi && !isActive ? 'animate-pulse text-amber-400' : ''}`} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
