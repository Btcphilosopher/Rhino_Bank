/**
 * 华盛利率终端 - 利率模型与蒙特卡洛模拟实验室
 * HUASHENG RATES - Interest Rate Models & Monte Carlo Simulation Lab (Vasicek, CIR, Hull-White)
 */

import React, { useState } from 'react';
import ReactECharts from 'echarts-for-react';
import { runMonteCarloRateSimulation } from '../quant/rateModels';
import { ShortRateModelType } from '../types';
import { Cpu, Sliders, Activity, Play } from 'lucide-react';

export const RateModelsLabView: React.FC = () => {
  const [modelType, setModelType] = useState<ShortRateModelType>('Vasicek');
  const [meanReversionSpeed, setMeanReversionSpeed] = useState<number>(0.15);
  const [longTermRate, setLongTermRate] = useState<number>(2.50);
  const [volatility, setVolatility] = useState<number>(0.80); // %
  const [initialShortRate, setInitialShortRate] = useState<number>(1.80);
  const [pathsCount, setPathsCount] = useState<number>(500);

  // 100% 由量化引擎计算
  const mcResult = runMonteCarloRateSimulation(
    {
      modelType,
      meanReversionSpeed,
      longTermRate,
      volatility,
      initialShortRate
    },
    pathsCount,
    365
  );

  const getEChartsOption = () => {
    const seriesList: any[] = [];

    // 绘制 10 条样本路径
    mcResult.samplePaths.slice(0, 10).forEach((p, idx) => {
      seriesList.push({
        name: `Path ${idx + 1}`,
        type: 'line',
        smooth: true,
        showSymbol: false,
        data: p,
        lineStyle: { width: 1, color: '#334155', opacity: 0.6 }
      });
    });

    // 绘制均值与置信区间
    seriesList.push({
      name: '均值路径 (Mean Path)',
      type: 'line',
      smooth: true,
      data: mcResult.meanPath,
      lineStyle: { width: 3, color: '#f59e0b' },
      itemStyle: { color: '#f59e0b' }
    });

    seriesList.push({
      name: '95% 分位数 (Upper Bound)',
      type: 'line',
      smooth: true,
      data: mcResult.percentile95,
      lineStyle: { width: 1.5, type: 'dashed', color: '#10b981' },
      itemStyle: { color: '#10b981' }
    });

    seriesList.push({
      name: '5% 分位数 (Lower Bound)',
      type: 'line',
      smooth: true,
      data: mcResult.percentile05,
      lineStyle: { width: 1.5, type: 'dashed', color: '#f43f5e' },
      itemStyle: { color: '#f43f5e' }
    });

    return {
      backgroundColor: 'transparent',
      tooltip: { trigger: 'axis' },
      legend: { textStyle: { color: '#94a3b8' }, top: 5 },
      grid: { left: '3%', right: '4%', bottom: '10%', top: '15%', containLabel: true },
      xAxis: {
        type: 'category',
        data: mcResult.timeSteps.map((d) => `D${d}`),
        axisLine: { lineStyle: { color: '#334155' } },
        axisLabel: { color: '#94a3b8' }
      },
      yAxis: {
        type: 'value',
        name: 'Short Rate (%)',
        scale: true,
        axisLine: { lineStyle: { color: '#334155' } },
        splitLine: { lineStyle: { color: '#1e293b' } },
        axisLabel: { color: '#94a3b8', formatter: '{value}%' }
      },
      series: seriesList
    };
  };

  return (
    <div className="p-4 space-y-4 font-mono text-slate-100 select-none">
      <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg flex items-center justify-between text-xs">
        <div className="flex items-center space-x-2">
          <Cpu className="w-4 h-4 text-amber-500" />
          <h2 className="text-sm font-bold text-slate-200 font-sans">
            短期利率随机模型与蒙特卡洛路径模拟实验室
          </h2>
        </div>
        <span className="text-slate-400">
          已成功生成 <strong className="text-amber-400">{mcResult.pathsCount}</strong> 条随机利率路径 (365天)
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* 模型参数配置 (1 Col) */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-4">
          <div className="flex items-center space-x-2 border-b border-slate-800 pb-2">
            <Sliders className="w-4 h-4 text-amber-500" />
            <h2 className="text-sm font-bold text-slate-200 font-sans">模型与随机过程参数</h2>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <label className="text-slate-400 block mb-1">随机利率模型选择:</label>
              <select
                value={modelType}
                onChange={(e) => setModelType(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-700 text-amber-400 font-bold px-2 py-1.5 rounded outline-none"
              >
                <option value="Vasicek">Vasicek 模型 (均值回归)</option>
                <option value="CIR">CIR 模型 (Cox-Ingersoll-Ross 非负)</option>
                <option value="Hull-White">Hull-White 模型 (时变拟合)</option>
              </select>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">均值回归速度 (a): {meanReversionSpeed}</label>
              <input
                type="range"
                min="0.01"
                max="0.5"
                step="0.01"
                value={meanReversionSpeed}
                onChange={(e) => setMeanReversionSpeed(Number(e.target.value))}
                className="w-full accent-amber-500"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">长期均值利率 (b) %: {longTermRate}%</label>
              <input
                type="range"
                min="0.5"
                max="5.0"
                step="0.1"
                value={longTermRate}
                onChange={(e) => setLongTermRate(Number(e.target.value))}
                className="w-full accent-amber-500"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">波动率 (σ) %: {volatility}%</label>
              <input
                type="range"
                min="0.1"
                max="2.0"
                step="0.05"
                value={volatility}
                onChange={(e) => setVolatility(Number(e.target.value))}
                className="w-full accent-amber-500"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">初始短期利率 (r0) %:</label>
              <input
                type="number"
                step="0.05"
                value={initialShortRate}
                onChange={(e) => setInitialShortRate(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 text-slate-100 font-bold px-2 py-1.5 rounded outline-none"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">蒙特卡洛模拟路径数:</label>
              <select
                value={pathsCount}
                onChange={(e) => setPathsCount(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 text-slate-200 px-2 py-1.5 rounded outline-none"
              >
                <option value={100}>100 条路径</option>
                <option value={500}>500 条路径</option>
                <option value={1000}>1000 条路径</option>
                <option value={2000}>2000 条路径</option>
              </select>
            </div>
          </div>
        </div>

        {/* 模拟路径绘制 (2 Cols) */}
        <div className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-3">
          <div className="text-xs font-bold text-slate-200 border-b border-slate-800 pb-2 flex justify-between">
            <span>蒙特卡洛随机利率路径模拟图谱</span>
            <span className="text-[11px] text-slate-400">时间跨度: 365天</span>
          </div>

          <div className="h-80 w-full">
            <ReactECharts option={getEChartsOption()} style={{ height: '100%', width: '100%' }} />
          </div>

          {/* 终点分布统计 */}
          <div className="grid grid-cols-3 gap-2 text-xs pt-2 border-t border-slate-800">
            <div className="bg-slate-950 p-2 rounded border border-slate-800">
              <span className="text-slate-400 block">一年后均值利率:</span>
              <span className="text-amber-400 font-bold text-sm">
                {mcResult.meanPath[mcResult.meanPath.length - 1]}%
              </span>
            </div>
            <div className="bg-slate-950 p-2 rounded border border-slate-800">
              <span className="text-slate-400 block">95% 置信上限:</span>
              <span className="text-emerald-400 font-bold text-sm">
                {mcResult.percentile95[mcResult.percentile95.length - 1]}%
              </span>
            </div>
            <div className="bg-slate-950 p-2 rounded border border-slate-800">
              <span className="text-slate-400 block">5% 置信下限:</span>
              <span className="text-rose-400 font-bold text-sm">
                {mcResult.percentile05[mcResult.percentile05.length - 1]}%
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
