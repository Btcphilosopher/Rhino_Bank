/**
 * 华盛利率终端 - 顶部导航与行情报跑马灯
 * HUASHENG RATES - Terminal Header & Top Bar
 */

import React, { useEffect } from 'react';
import { useRatesStore } from '../stores/useRatesStore';
import {
  Activity,
  Play,
  Pause,
  RotateCcw,
  Search,
  SlidersHorizontal,
  Clock,
  ShieldAlert,
  TrendingDown,
  TrendingUp,
  Database
} from 'lucide-react';
import { calculatePortfolioAnalytics } from '../quant/portfolio';

export const Header: React.FC = () => {
  const {
    quotes,
    cgbCurve,
    isSimulatorRunning,
    toggleSimulator,
    resetSimulator,
    updateTickCount,
    setSearchModalOpen,
    portfolioPositions
  } = useRatesStore();

  const cgb10Y = cgbCurve.points.find((p) => p.tenor === '10Y')?.yield || 2.16;
  const cgb2Y = cgbCurve.points.find((p) => p.tenor === '2Y')?.yield || 1.76;
  const slope10Y2Y = cgbCurve.slope10Y2Y;

  const portfolioAnalytics = calculatePortfolioAnalytics(portfolioPositions);

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-slate-200 select-none">
      {/* 顶栏第一层: 品牌标题、快捷搜索、系统状态与模拟控制 */}
      <div className="px-4 py-2.5 flex items-center justify-between border-b border-slate-800/80">
        {/* 左侧 Terminal 名称 */}
        <div className="flex items-center space-x-3">
          <div className="bg-amber-500 text-slate-950 font-black tracking-widest px-2.5 py-1 rounded text-xs shadow-sm flex items-center space-x-1">
            <Activity className="w-3.5 h-3.5" />
            <span>HUASHENG RATES</span>
          </div>
          <div className="flex flex-col">
            <h1 className="text-sm font-bold text-slate-100 tracking-wide flex items-center space-x-2">
              <span>华盛利率终端</span>
              <span className="text-[10px] text-slate-400 font-mono font-normal border border-slate-700 px-1.5 py-0.5 rounded">
                v1.0 Institutional
              </span>
            </h1>
            <span className="text-[10px] text-slate-400">
              企业级固定收益与利率分析平台
            </span>
          </div>
        </div>

        {/* 中间快捷全局搜索框 (Ctrl+K) */}
        <button
          onClick={() => setSearchModalOpen(true)}
          className="flex items-center justify-between space-x-3 bg-slate-950/80 hover:bg-slate-800/80 border border-slate-700/80 text-slate-400 hover:text-slate-200 px-3 py-1.5 rounded-md text-xs transition-colors w-72"
        >
          <div className="flex items-center space-x-2">
            <Search className="w-3.5 h-3.5 text-amber-500" />
            <span>搜索债券/曲线/函数 (输入 10年国债...)</span>
          </div>
          <kbd className="bg-slate-800 text-slate-400 text-[10px] font-mono px-1.5 py-0.5 rounded border border-slate-700">
            Ctrl+K
          </kbd>
        </button>

        {/* 右侧系统状态、实时模拟器控制器 */}
        <div className="flex items-center space-x-4 text-xs font-mono">
          {/* 数据源说明标识 */}
          <div className="flex items-center space-x-1.5 text-slate-400 bg-slate-950 px-2.5 py-1 rounded border border-slate-800">
            <Database className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-[11px]">数据: 模拟行情引擎</span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
          </div>

          {/* 模拟器播放/暂停 */}
          <div className="flex items-center bg-slate-950 border border-slate-800 rounded p-0.5 space-x-1">
            <button
              onClick={toggleSimulator}
              className={`flex items-center space-x-1 px-2 py-0.5 rounded text-[11px] transition-colors ${
                isSimulatorRunning
                  ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
              title={isSimulatorRunning ? '暂停实时模拟' : '开启实时模拟'}
            >
              {isSimulatorRunning ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
              <span>{isSimulatorRunning ? '模拟中' : '已暂停'}</span>
            </button>
            <button
              onClick={resetSimulator}
              className="p-1 hover:bg-slate-800 text-slate-400 hover:text-slate-200 rounded"
              title="重置实时行情"
            >
              <RotateCcw className="w-3 h-3" />
            </button>
          </div>

          {/* 日期时间 */}
          <div className="text-slate-400 flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-800">
            <Clock className="w-3.5 h-3.5 text-slate-500" />
            <span>2026-09-17 10:45</span>
          </div>
        </div>
      </div>

      {/* 顶栏第二层: 核心基准与组合风险摘要卡片 */}
      <div className="bg-slate-950/90 px-4 py-1.5 flex items-center justify-between text-xs border-b border-slate-800 overflow-x-auto">
        <div className="flex items-center space-x-6 font-mono whitespace-nowrap">
          {/* 国债 10Y */}
          <div className="flex items-center space-x-2">
            <span className="text-slate-400">国债10Y收益率:</span>
            <span className="text-amber-400 font-bold">{cgb10Y.toFixed(2)}%</span>
            <span className="text-emerald-400 flex items-center text-[10px]">
              <TrendingDown className="w-3 h-3 mr-0.5" /> -1.2bp
            </span>
          </div>

          {/* 10Y - 2Y 期限利差 */}
          <div className="flex items-center space-x-2 border-l border-slate-800 pl-4">
            <span className="text-slate-400">10Y-2Y 利差:</span>
            <span className="text-slate-200 font-bold">{slope10Y2Y.toFixed(1)} bp</span>
            <span className="text-[10px] text-amber-400/90 bg-amber-500/10 border border-amber-500/20 px-1 rounded">
              陡峭化
            </span>
          </div>

          {/* 组合总市值 */}
          <div className="flex items-center space-x-2 border-l border-slate-800 pl-4">
            <span className="text-slate-400">组合市值:</span>
            <span className="text-slate-100 font-bold">
              ¥{(portfolioAnalytics.totalMarketValue / 10000).toLocaleString('zh-CN', { maximumFractionDigits: 1 })}万
            </span>
          </div>

          {/* 组合久期 */}
          <div className="flex items-center space-x-2 border-l border-slate-800 pl-4">
            <span className="text-slate-400">组合修正久期:</span>
            <span className="text-cyan-400 font-bold">{portfolioAnalytics.weightedModDuration.toFixed(2)} 年</span>
          </div>

          {/* 组合总 DV01 */}
          <div className="flex items-center space-x-2 border-l border-slate-800 pl-4">
            <span className="text-slate-400">组合总 DV01:</span>
            <span className="text-emerald-400 font-bold">
              ¥{(portfolioAnalytics.totalDv01).toLocaleString('zh-CN', { maximumFractionDigits: 0 })} / 1bp
            </span>
          </div>
        </div>

        {/* 右侧系统风险级别标示 */}
        <div className="flex items-center space-x-2 text-[11px]">
          <ShieldAlert className="w-3.5 h-3.5 text-amber-500" />
          <span className="text-slate-400">利率敏感情景:</span>
          <span className="text-amber-400 font-semibold bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
            中等偏高 (+25bp 估算损益 -¥35.2万)
          </span>
        </div>
      </div>
    </header>
  );
};
