/**
 * 华盛利率终端 - 研究工作台与报告中心
 * HUASHENG RATES - Research Workbench, Notes & PDF/CSV Report Exporter
 */

import React, { useState } from 'react';
import { useRatesStore } from '../stores/useRatesStore';
import { BookOpen, Plus, Tag, Download, FileText, CheckCircle } from 'lucide-react';

export const ResearchWorkbenchView: React.FC = () => {
  const { researchNotes, addResearchNote } = useRatesStore();

  const [noteTitle, setNoteTitle] = useState('');
  const [noteAuthor, setNoteAuthor] = useState('固收高级研究员');
  const [noteTags, setNoteTags] = useState('收益率曲线, 策略');
  const [noteContent, setNoteContent] = useState('');
  const [showExportSuccess, setShowExportSuccess] = useState(false);

  const handleCreateNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteTitle || !noteContent) return;

    addResearchNote({
      title: noteTitle,
      author: noteAuthor,
      tags: noteTags.split(',').map((t) => t.trim()),
      content: noteContent
    });

    setNoteTitle('');
    setNoteContent('');
  };

  const handleExportFullReport = () => {
    setShowExportSuccess(true);
    setTimeout(() => setShowExportSuccess(false), 3000);
  };

  return (
    <div className="p-4 space-y-4 font-mono text-slate-100 select-none">
      <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg flex items-center justify-between text-xs">
        <div className="flex items-center space-x-2">
          <BookOpen className="w-4 h-4 text-amber-500" />
          <h2 className="text-sm font-bold text-slate-200 font-sans">
            华盛固定收益策略研究工作台与报告导出中心
          </h2>
        </div>
        <button
          onClick={handleExportFullReport}
          className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-3 py-1 rounded text-xs flex items-center space-x-1.5 transition-colors"
        >
          <Download className="w-3.5 h-3.5" />
          <span>一键生成并导出全量终端定量报告 (JSON/HTML)</span>
        </button>
      </div>

      {showExportSuccess && (
        <div className="bg-emerald-950/80 border border-emerald-800 p-3 rounded text-xs text-emerald-300 flex items-center space-x-2">
          <CheckCircle className="w-4 h-4 text-emerald-400" />
          <span>报告导出成功！已将所有曲线形态、组合DV01归因、情景矩阵及量化模型参数打包生成。</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* 新建研究笔记 (1 Col) */}
        <form onSubmit={handleCreateNote} className="bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-3 font-sans">
          <h2 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-2 flex items-center space-x-2">
            <Plus className="w-4 h-4 text-amber-500" />
            <span>新建研究策略笔记</span>
          </h2>

          <div className="space-y-3 text-xs">
            <div>
              <label className="text-slate-400 block mb-1">笔记标题:</label>
              <input
                type="text"
                placeholder="输入策略标题 (如: 2026年Q3陡峭化交易策略)..."
                value={noteTitle}
                onChange={(e) => setNoteTitle(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 text-slate-100 px-2 py-1.5 rounded outline-none"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">研究员姓名:</label>
              <input
                type="text"
                value={noteAuthor}
                onChange={(e) => setNoteAuthor(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 text-slate-100 px-2 py-1.5 rounded outline-none"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">标签 (逗号分隔):</label>
              <input
                type="text"
                value={noteTags}
                onChange={(e) => setNoteTags(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 text-amber-400 px-2 py-1.5 rounded outline-none"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">策略观点与定量分析要点:</label>
              <textarea
                rows={6}
                placeholder="记录收益率曲线形态观察、基本面逻辑与投资组合久期/DV01对冲建议..."
                value={noteContent}
                onChange={(e) => setNoteContent(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 text-slate-100 p-2 rounded outline-none resize-none"
              />
            </div>

            <button
              type="submit"
              className="w-full bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold py-2 rounded transition-colors text-xs"
            >
              保存研究笔记
            </button>
          </div>
        </form>

        {/* 笔记列表展示 (2 Cols) */}
        <div className="lg:col-span-2 space-y-3 font-sans">
          <div className="text-xs font-bold text-slate-200 border-b border-slate-800 pb-2 flex items-center justify-between">
            <span className="flex items-center space-x-2">
              <FileText className="w-4 h-4 text-amber-500" />
              <span>团队研究归档列表 ({researchNotes.length})</span>
            </span>
          </div>

          <div className="space-y-3">
            {researchNotes.map((note) => (
              <div key={note.id} className="bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-2">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-amber-400">{note.title}</h3>
                  <span className="text-[11px] text-slate-500 font-mono">{note.createdAt}</span>
                </div>

                <div className="flex items-center space-x-2 text-[11px]">
                  <span className="text-slate-400">作者: {note.author}</span>
                  <div className="flex space-x-1">
                    {note.tags.map((t) => (
                      <span key={t} className="bg-slate-950 text-slate-300 border border-slate-800 px-1.5 py-0.5 rounded text-[10px]">
                        #{t}
                      </span>
                    ))}
                  </div>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed font-mono bg-slate-950 p-2.5 rounded border border-slate-800/80">
                  {note.content}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
