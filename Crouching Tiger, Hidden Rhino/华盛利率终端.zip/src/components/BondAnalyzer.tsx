/**
 * 华盛利率终端 - 单券深度定价与风险分析引擎
 * HUASHENG RATES - Single Bond Pricing, Cashflow, Duration, Convexity & Sensitivity Grid
 */

import React, { useState } from 'react';
import { useRatesStore } from '../stores/useRatesStore';
import { calculateFullBondPricing } from '../quant/pricing';
import { Bond, DayCountConvention } from '../types';
import {
  FileText,
  Calculator,
  Sliders,
  DollarSign,
  TrendingUp,
  Table,
  Layers,
  ChevronDown,
  ChevronUp
} from 'lucide-react';

export const BondAnalyzer: React.FC = () => {
  const { selectedBond, setSelectedBond, bondsList, addPosition } = useRatesStore();

  // 当前分析参数可自定义调整
  const [couponRate, setCouponRate] = useState<number>(selectedBond.couponRate);
  const [priceInput, setPriceInput] = useState<number>(selectedBond.price);
  const [dayCount, setDayCount] = useState<DayCountConvention>(selectedBond.dayCount || 'ACT/ACT');
  const [frequency, setFrequency] = useState<number>(selectedBond.frequency || 2);
  const [quantityInput, setQuantityInput] = useState<number>(1000); // 手/万元

  // 根据当前输入的参数重新构造 Bond 对象送入量化引擎计算
  const activeBond: Bond = {
    ...selectedBond,
    couponRate,
    price: priceInput,
    dayCount,
    frequency
  };

  // 100% 由量化引擎计算
  const pricing = calculateFullBondPricing(activeBond);

  const [isCashflowExpanded, setCashflowExpanded] = useState<boolean>(false);

  return (
    <div className="p-4 space-y-4 font-mono text-slate-100 select-none">
      {/* 顶部债券选择器与基础属性卡片 */}
      <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg flex flex-wrap items-center justify-between gap-4">
        {/* 选择现有债券 */}
        <div className="flex items-center space-x-3">
          <label className="text-xs text-slate-400 font-semibold">选择债券:</label>
          <select
            value={selectedBond.id}
            onChange={(e) => {
              const b = bondsList.find((x) => x.id === e.target.value);
              if (b) {
                setSelectedBond(b);
                setCouponRate(b.couponRate);
                setPriceInput(b.price);
                if (b.dayCount) setDayCount(b.dayCount);
                if (b.frequency) setFrequency(b.frequency);
              }
            }}
            className="bg-slate-950 border border-slate-700 text-amber-400 font-bold px-3 py-1.5 rounded text-xs outline-none"
          >
            {bondsList.map((b) => (
              <option key={b.id} value={b.id}>
                {b.code} - {b.name} ({b.sector})
              </option>
            ))}
          </select>
        </div>

        {/* 快捷按钮: 加入组合 */}
        <div className="flex items-center space-x-2">
          <input
            type="number"
            value={quantityInput}
            onChange={(e) => setQuantityInput(Number(e.target.value))}
            className="w-24 bg-slate-950 border border-slate-700 text-slate-200 px-2 py-1 rounded text-xs text-right outline-none"
            placeholder="面值(万元)"
          />
          <span className="text-xs text-slate-400">万元面值</span>
          <button
            onClick={() => {
              addPosition(activeBond, quantityInput, pricing.dirtyPrice);
              alert(`已成功将 [${activeBond.name}] (${quantityInput}万元面值) 加入投资组合`);
            }}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-3 py-1 rounded text-xs transition-colors"
          >
            + 加入当前组合
          </button>
        </div>
      </div>

      {/* 参数微调与定价结果 */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {/* 左侧定价输入参数控制面板 (1 Col) */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-4">
          <div className="flex items-center space-x-2 border-b border-slate-800 pb-2">
            <Sliders className="w-4 h-4 text-amber-500" />
            <h2 className="text-sm font-bold text-slate-200 font-sans">定价算子与参数调整</h2>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <label className="text-slate-400 block mb-1">净价 (Clean Price) 元:</label>
              <input
                type="number"
                step="0.01"
                value={priceInput}
                onChange={(e) => setPriceInput(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 text-amber-400 font-bold px-2 py-1.5 rounded outline-none"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">票面利率 (Coupon Rate) %:</label>
              <input
                type="number"
                step="0.01"
                value={couponRate}
                onChange={(e) => setCouponRate(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 text-slate-100 font-bold px-2 py-1.5 rounded outline-none"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">计息付息频率 (Frequency):</label>
              <select
                value={frequency}
                onChange={(e) => setFrequency(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 text-slate-200 px-2 py-1.5 rounded outline-none"
              >
                <option value={1}>每年付息 1 次</option>
                <option value={2}>每半年付息 2 次</option>
                <option value={4}>按季付息 4 次</option>
                <option value={12}>按月付息 12 次</option>
              </select>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">日计数惯例 (Day Count Convention):</label>
              <select
                value={dayCount}
                onChange={(e) => setDayCount(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-700 text-slate-200 px-2 py-1.5 rounded outline-none"
              >
                <option value="ACT/ACT">ACT/ACT (实际/实际 - 国债标准)</option>
                <option value="ACT/365">ACT/365 (实际/365 - 企业债)</option>
                <option value="ACT/360">ACT/360 (实际/360 - 货币市场)</option>
                <option value="30/360">30/360 (约定30/360)</option>
              </select>
            </div>

            <div className="pt-2 border-t border-slate-800 space-y-1 text-[11px] text-slate-400 font-sans">
              <p>发行人: {activeBond.issuer}</p>
              <p>发行日期: {activeBond.issueDate}</p>
              <p>到期日期: {activeBond.maturityDate}</p>
              <p>信用评级: {activeBond.rating}</p>
            </div>
          </div>
        </div>

        {/* 右侧量化引擎计算核心输出卡片 (3 Cols) */}
        <div className="lg:col-span-3 space-y-4">
          {/* 核心三组卡片: 价格与收益率 / 久期与凸性 / 风险与DV01 */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {/* 卡片 1: 收益率指标 */}
            <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-lg space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400 border-b border-slate-800 pb-1">
                <span>到期收益率与价格</span>
                <Calculator className="w-3.5 h-3.5 text-amber-500" />
              </div>
              <div>
                <span className="text-slate-400 text-[11px] block">YTM (到期收益率 - Newton-Raphson):</span>
                <span className="text-amber-400 text-2xl font-bold font-mono">{pricing.ytm}%</span>
              </div>
              <div className="grid grid-cols-2 gap-1 text-[11px] pt-1 border-t border-slate-800/60">
                <div>
                  <span className="text-slate-500 block">全价 (Dirty):</span>
                  <span className="text-slate-200 font-bold">¥{pricing.dirtyPrice}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">应计利息:</span>
                  <span className="text-slate-200 font-bold">¥{pricing.accruedInterest}</span>
                </div>
              </div>
            </div>

            {/* 卡片 2: 久期指标 */}
            <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-lg space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400 border-b border-slate-800 pb-1">
                <span>久期 (Duration)</span>
                <TrendingUp className="w-3.5 h-3.5 text-cyan-400" />
              </div>
              <div>
                <span className="text-slate-400 text-[11px] block">修正久期 (Modified Duration):</span>
                <span className="text-cyan-400 text-2xl font-bold font-mono">{pricing.modifiedDuration} 年</span>
              </div>
              <div className="grid grid-cols-2 gap-1 text-[11px] pt-1 border-t border-slate-800/60">
                <div>
                  <span className="text-slate-500 block">麦考利久期:</span>
                  <span className="text-slate-200 font-bold">{pricing.macaulayDuration} 年</span>
                </div>
                <div>
                  <span className="text-slate-500 block">有效久期 (10bp):</span>
                  <span className="text-slate-200 font-bold">{pricing.effectiveDuration} 年</span>
                </div>
              </div>
            </div>

            {/* 卡片 3: 凸性与 DV01 */}
            <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-lg space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400 border-b border-slate-800 pb-1">
                <span>凸性与基点价值</span>
                <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
              </div>
              <div>
                <span className="text-slate-400 text-[11px] block">DV01 (每 1bp 价格变动):</span>
                <span className="text-emerald-400 text-2xl font-bold font-mono">¥{pricing.dv01}</span>
              </div>
              <div className="grid grid-cols-2 gap-1 text-[11px] pt-1 border-t border-slate-800/60">
                <div>
                  <span className="text-slate-500 block">凸性 (Convexity):</span>
                  <span className="text-slate-200 font-bold">{pricing.convexity}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">最差收益率 (YTW):</span>
                  <span className="text-slate-200 font-bold">{pricing.ytw}%</span>
                </div>
              </div>
            </div>
          </div>

          {/* 关键期限久期 (KRD) 向量拆解 */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-2">
            <div className="flex items-center justify-between text-xs border-b border-slate-800 pb-1.5">
              <span className="font-bold text-slate-200 flex items-center space-x-1.5">
                <Layers className="w-4 h-4 text-amber-500" />
                <span>关键期限久期拆解 (Key Rate Duration - KRD)</span>
              </span>
              <span className="text-[11px] text-slate-400">总久期和: {pricing.modifiedDuration} 年</span>
            </div>

            <div className="grid grid-cols-6 md:grid-cols-12 gap-1 text-center text-xs">
              {Object.keys(pricing.krd).map((k) => {
                const val = pricing.krd[k as keyof typeof pricing.krd];
                return (
                  <div key={k} className="bg-slate-950 p-1.5 rounded border border-slate-800">
                    <span className="text-slate-500 text-[10px] block font-bold">{k}</span>
                    <span className={`font-mono text-xs font-bold ${val > 0 ? 'text-amber-400' : 'text-slate-600'}`}>
                      {val.toFixed(2)}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 重估敏感性网格 Repricing Sensitivity Grid */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-2">
            <div className="text-xs font-bold text-slate-200 border-b border-slate-800 pb-1.5">
              收益率位移重估敏感性矩阵 (Repricing Grid)
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-center text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 bg-slate-950">
                    <th className="p-1.5 text-left">收益率冲击 (bp)</th>
                    <th className="p-1.5">重估 YTM (%)</th>
                    <th className="p-1.5">估计净价 (元)</th>
                    <th className="p-1.5">估计变动金额 (元)</th>
                    <th className="p-1.5">估计变动比例 (%)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/40 font-mono">
                  {pricing.repricingGrid.map((row) => {
                    const isLoss = row.actualPriceChange < 0;
                    const newYieldVal = (selectedBond.yield + row.yieldShiftBp / 100).toFixed(2);
                    const pctChangeVal = ((row.actualPriceChange / pricing.cleanPrice) * 100).toFixed(2);
                    return (
                      <tr key={row.yieldShiftBp} className={row.yieldShiftBp === 0 ? 'bg-amber-500/10 font-bold' : ''}>
                        <td className="p-1.5 text-left font-bold text-slate-300">
                          {row.yieldShiftBp > 0 ? `+${row.yieldShiftBp} bp` : `${row.yieldShiftBp} bp`}
                        </td>
                        <td className="p-1.5 text-slate-200">{newYieldVal}%</td>
                        <td className="p-1.5 text-amber-400">¥{row.actualPrice.toFixed(2)}</td>
                        <td className={`p-1.5 font-bold ${isLoss ? 'text-rose-400' : row.actualPriceChange === 0 ? 'text-slate-400' : 'text-emerald-400'}`}>
                          {row.actualPriceChange > 0 ? `+¥${row.actualPriceChange.toFixed(2)}` : `¥${row.actualPriceChange.toFixed(2)}`}
                        </td>
                        <td className={`p-1.5 ${isLoss ? 'text-rose-400' : row.actualPriceChange === 0 ? 'text-slate-400' : 'text-emerald-400'}`}>
                          {Number(pctChangeVal) > 0 ? `+${pctChangeVal}%` : `${pctChangeVal}%`}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* 现金流明细表 (Cashflow Schedule) */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-2">
            <div className="flex items-center justify-between text-xs border-b border-slate-800 pb-1.5">
              <span className="font-bold text-slate-200 flex items-center space-x-1.5">
                <Table className="w-4 h-4 text-emerald-400" />
                <span>现金流明细表 (Cashflow Schedule) - 共 {pricing.cashflows.length} 期</span>
              </span>
              <button
                onClick={() => setCashflowExpanded(!isCashflowExpanded)}
                className="text-amber-400 hover:text-amber-300 flex items-center space-x-1"
              >
                <span>{isCashflowExpanded ? '收起列表' : '展开全量现金流'}</span>
                {isCashflowExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 bg-slate-950">
                    <th className="p-1.5">期数</th>
                    <th className="p-1.5">支付日期</th>
                    <th className="p-1.5 text-right">时间 (年)</th>
                    <th className="p-1.5 text-right">现金流 (元)</th>
                    <th className="p-1.5 text-right">折现因子</th>
                    <th className="p-1.5 text-right">现值 PV (元)</th>
                    <th className="p-1.5 text-right">现值占比 (%)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/40 font-mono">
                  {(isCashflowExpanded ? pricing.cashflows : pricing.cashflows.slice(0, 5)).map((cf) => (
                    <tr key={cf.period} className="hover:bg-slate-800/40">
                      <td className="p-1.5 text-slate-400">第 {cf.period} 期</td>
                      <td className="p-1.5 text-slate-200">{cf.date}</td>
                      <td className="p-1.5 text-right text-slate-400">{cf.tenorYears.toFixed(2)}</td>
                      <td className="p-1.5 text-right text-slate-100 font-bold">¥{cf.totalCashFlow.toFixed(2)}</td>
                      <td className="p-1.5 text-right text-cyan-400">{cf.discountFactor.toFixed(4)}</td>
                      <td className="p-1.5 text-right text-emerald-400 font-bold">¥{cf.pv.toFixed(2)}</td>
                      <td className="p-1.5 text-right text-amber-400">{cf.pvContributionPct.toFixed(2)}%</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
