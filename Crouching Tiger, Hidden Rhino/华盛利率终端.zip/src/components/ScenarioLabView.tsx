/**
 * 华盛利率终端 - 情景实验室与压力测试中心
 * HUASHENG RATES - Scenario Analytics, Curve Shock Engine & 2D Matrix
 */

import React, { useState } from 'react';
import { useRatesStore } from '../stores/useRatesStore';
import { generate2DScenarioMatrix, runScenarioPricing } from '../quant/shockEngine';
import { CurveShockType, KeyTenor } from '../types';
import { Zap, Sliders, Activity, ShieldAlert, BarChart3 } from 'lucide-react';

export const ScenarioLabView: React.FC = () => {
  const { portfolioPositions } = useRatesStore();

  const [shockType, setShockType] = useState<CurveShockType>('PARALLEL');
  const [parallelShiftBp, setParallelShiftBp] = useState<number>(25);
  const [shortEndShiftBp, setShortEndShiftBp] = useState<number>(-10);
  const [longEndShiftBp, setLongEndShiftBp] = useState<number>(20);
  const [midEndShiftBp, setMidEndShiftBp] = useState<number>(-15);

  const [customShocks, setCustomShocks] = useState<Record<KeyTenor, number>>({
    '1M': 0, '3M': 0, '6M': 0,
    '1Y': 10, '2Y': 15, '3Y': 20,
    '5Y': 25, '7Y': 30, '10Y': 35,
    '15Y': 40, '20Y': 45, '30Y': 50
  });

  const bondsForPricing = portfolioPositions.map((p) => ({
    bond: p.bond,
    quantity: p.quantity
  }));

  // 100% 由量化引擎算子计算
  const scenarioResult = runScenarioPricing(bondsForPricing, {
    type: shockType,
    parallelShiftBp,
    shortEndShiftBp,
    longEndShiftBp,
    midEndShiftBp,
    customKeyRateShocks: customShocks
  });

  // 2D 二维情景矩阵
  const matrix = generate2DScenarioMatrix(bondsForPricing);

  return (
    <div className="p-4 space-y-4 font-mono text-slate-100 select-none">
      {/* 顶部标题栏 */}
      <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg flex items-center justify-between text-xs">
        <div className="flex items-center space-x-2">
          <Zap className="w-4 h-4 text-amber-500" />
          <h2 className="text-sm font-bold text-slate-200 font-sans">情景实验室与收益率曲线冲击引擎</h2>
        </div>
        <span className="text-slate-400">
          受测组合总市值: <strong className="text-amber-400">¥{(scenarioResult.originalValue / 10000).toFixed(1)}万元</strong>
        </span>
      </div>

      {/* 冲击类型与参数控制面板 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* 左侧控制区 (1 Col) */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-4">
          <div className="flex items-center space-x-2 border-b border-slate-800 pb-2">
            <Sliders className="w-4 h-4 text-amber-500" />
            <h2 className="text-sm font-bold text-slate-200 font-sans">冲击模式与形变预设</h2>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <label className="text-slate-400 block mb-1">冲击模式选择:</label>
              <div className="grid grid-cols-2 gap-1.5">
                {[
                  { id: 'PARALLEL', label: '平行位移 (Parallel)' },
                  { id: 'STEEPEN', label: '陡峭化 (Steepening)' },
                  { id: 'FLATTEN', label: '平坦化 (Flattening)' },
                  { id: 'TWIST', label: '扭曲 (Twist)' },
                  { id: 'BUTTERFLY', label: '蝶式 (Butterfly)' },
                  { id: 'CUSTOM', label: '自定义关键期限' }
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setShockType(item.id as any)}
                    className={`p-2 rounded text-left transition-colors font-sans text-[11px] ${
                      shockType === item.id
                        ? 'bg-amber-500 text-slate-950 font-bold'
                        : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            {/* 参数滑动与微调 */}
            {shockType === 'PARALLEL' && (
              <div className="bg-slate-950 p-2.5 rounded border border-slate-800 space-y-2">
                <label className="text-slate-300 block font-bold">平行平移幅值 (bp): {parallelShiftBp} bp</label>
                <input
                  type="range"
                  min="-100"
                  max="100"
                  value={parallelShiftBp}
                  onChange={(e) => setParallelShiftBp(Number(e.target.value))}
                  className="w-full accent-amber-500"
                />
                <div className="flex justify-between text-[10px] text-slate-500">
                  <span>-100bp (大牛市)</span>
                  <span>0bp</span>
                  <span>+100bp (大熊市)</span>
                </div>
              </div>
            )}

            {(shockType === 'STEEPEN' || shockType === 'FLATTEN' || shockType === 'TWIST') && (
              <div className="bg-slate-950 p-2.5 rounded border border-slate-800 space-y-2">
                <div>
                  <label className="text-slate-400 block">短端位移 (≤3Y) bp:</label>
                  <input
                    type="number"
                    value={shortEndShiftBp}
                    onChange={(e) => setShortEndShiftBp(Number(e.target.value))}
                    className="w-full bg-slate-900 border border-slate-700 text-amber-400 px-2 py-1 rounded mt-1"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block">长端位移 (≥10Y) bp:</label>
                  <input
                    type="number"
                    value={longEndShiftBp}
                    onChange={(e) => setLongEndShiftBp(Number(e.target.value))}
                    className="w-full bg-slate-900 border border-slate-700 text-amber-400 px-2 py-1 rounded mt-1"
                  />
                </div>
              </div>
            )}
          </div>
        </div>

        {/* 右侧重估计算结果 (2 Cols) */}
        <div className="lg:col-span-2 space-y-4">
          {/* 核心重估结果卡片 */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="font-bold text-slate-200 text-xs font-sans">
                {scenarioResult.scenarioName} 重估评估结果
              </span>
              <span className="text-[11px] text-slate-400">100% Quant Engine 精确全量重估</span>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
              <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                <span className="text-slate-400 block text-[11px]">组合重估 P&L 变动:</span>
                <span
                  className={`text-xl font-bold font-mono ${
                    scenarioResult.pnl >= 0 ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {scenarioResult.pnl >= 0
                    ? `+¥${scenarioResult.pnl.toLocaleString()}`
                    : `-¥${Math.abs(scenarioResult.pnl).toLocaleString()}`}
                </span>
              </div>

              <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                <span className="text-slate-400 block text-[11px]">变动比例 (%):</span>
                <span
                  className={`text-xl font-bold font-mono ${
                    scenarioResult.pnlPct >= 0 ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {scenarioResult.pnlPct >= 0 ? `+${scenarioResult.pnlPct}%` : `${scenarioResult.pnlPct}%`}
                </span>
              </div>

              <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                <span className="text-slate-400 block text-[11px]">重估后总 DV01:</span>
                <span className="text-amber-400 text-xl font-bold font-mono">
                  ¥{scenarioResult.shockedDv01.toLocaleString()}
                </span>
              </div>

              <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                <span className="text-slate-400 block text-[11px]">重估后修正久期:</span>
                <span className="text-cyan-400 text-xl font-bold font-mono">
                  {scenarioResult.shockedDuration} 年
                </span>
              </div>
            </div>
          </div>

          {/* 2D 二维情景矩阵 (利率位移 x 利差位移) */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div className="flex items-center space-x-2">
                <BarChart3 className="w-4 h-4 text-amber-500" />
                <h2 className="text-sm font-bold text-slate-200 font-sans">
                  2D 二维情景分析矩阵 (利率平移 bp × 信用利差 bp)
                </h2>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-center text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 bg-slate-950">
                    <th className="p-2 text-left">基准利率变动 \ 利差变动</th>
                    <th className="p-2 text-emerald-400">-20 bp (收窄)</th>
                    <th className="p-2 text-slate-200">0 bp (不变)</th>
                    <th className="p-2 text-rose-400">+20 bp (走阔)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/40 font-mono">
                  {[-50, -25, 0, 25, 50].map((yShift) => {
                    return (
                      <tr key={yShift} className={yShift === 0 ? 'bg-slate-950 font-bold' : ''}>
                        <td className="p-2 text-left font-bold text-slate-300">
                          {yShift > 0 ? `+${yShift} bp` : `${yShift} bp`}
                        </td>
                        {[-20, 0, 20].map((sShift) => {
                          const item = matrix.find(
                            (m) => m.yieldShiftBp === yShift && m.spreadShiftBp === sShift
                          );
                          const pnl = item ? item.pnl : 0;
                          const isLoss = pnl < 0;
                          return (
                            <td
                              key={sShift}
                              className={`p-2 font-bold ${
                                isLoss
                                  ? 'bg-rose-950/30 text-rose-400 border border-rose-900/40'
                                  : pnl === 0
                                  ? 'bg-slate-900 text-slate-400'
                                  : 'bg-emerald-950/30 text-emerald-400 border border-emerald-900/40'
                              }`}
                            >
                              {pnl >= 0 ? `+¥${pnl.toLocaleString()}` : `-¥${Math.abs(pnl).toLocaleString()}`}
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
