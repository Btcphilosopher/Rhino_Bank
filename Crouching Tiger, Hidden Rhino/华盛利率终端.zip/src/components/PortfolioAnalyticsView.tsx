/**
 * 华盛利率终端 - 组合风险与损益归因视图
 * HUASHENG RATES - Portfolio Overview, Carry & Roll-Down, Risk Decomposition & P&L Attribution
 */

import React, { useState } from 'react';
import { useRatesStore } from '../stores/useRatesStore';
import { calculateCarryRollDown, calculatePortfolioAnalytics, calculatePnLAttribution } from '../quant/portfolio';
import { PieChart, TrendingUp, DollarSign, Layers, Shield, Trash2, Plus, Sliders } from 'lucide-react';

export const PortfolioAnalyticsView: React.FC = () => {
  const { portfolioPositions, removePosition, updatePositionQuantity, bondsList, addPosition } = useRatesStore();

  const [holdingDays, setHoldingDays] = useState<number>(30);
  const [financingRate, setFinancingRate] = useState<number>(1.80);

  const [selectedBondIdToAdd, setSelectedBondIdToAdd] = useState<string>(bondsList[0].id);
  const [addQty, setAddQty] = useState<number>(1000);

  // 100% 由量化引擎计算
  const analytics = calculatePortfolioAnalytics(portfolioPositions);
  const carryRes = calculateCarryRollDown(analytics, holdingDays, financingRate);

  // 模拟一个月的微小变动计算 PnL Attribution
  const pnlAttribution = calculatePnLAttribution(analytics, { ...analytics, totalMarketValue: analytics.totalMarketValue + 125000 }, holdingDays, financingRate);

  return (
    <div className="p-4 space-y-4 font-mono text-slate-100 select-none">
      {/* 核心组合风险指标卡片栏 */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2">
        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg">
          <span className="text-[11px] text-slate-400 block">组合总市值</span>
          <span className="text-amber-400 font-bold text-base">
            ¥{(analytics.totalMarketValue / 10000).toLocaleString('zh-CN', { maximumFractionDigits: 1 })}万
          </span>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg">
          <span className="text-[11px] text-slate-400 block">加权到期收益率</span>
          <span className="text-slate-100 font-bold text-base">{analytics.weightedYield.toFixed(2)}%</span>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg">
          <span className="text-[11px] text-slate-400 block">加权修正久期</span>
          <span className="text-cyan-400 font-bold text-base">{analytics.weightedModDuration.toFixed(2)} 年</span>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg">
          <span className="text-[11px] text-slate-400 block">加权麦考利久期</span>
          <span className="text-slate-200 font-bold text-base">{analytics.weightedMacDuration.toFixed(2)} 年</span>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg">
          <span className="text-[11px] text-slate-400 block">加权凸性</span>
          <span className="text-slate-200 font-bold text-base">{analytics.weightedConvexity.toFixed(2)}</span>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg">
          <span className="text-[11px] text-slate-400 block">组合总 DV01</span>
          <span className="text-emerald-400 font-bold text-base">¥{analytics.totalDv01.toLocaleString('zh-CN', { maximumFractionDigits: 0 })}</span>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg">
          <span className="text-[11px] text-slate-400 block">预计年票息收入</span>
          <span className="text-slate-100 font-bold text-base">
            ¥{(analytics.totalCouponIncome / 10000).toLocaleString('zh-CN', { maximumFractionDigits: 1 })}万
          </span>
        </div>
      </div>

      {/* 持仓列表与添加持仓 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* 左侧持仓列表 (2 Cols) */}
        <div className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center space-x-2">
              <PieChart className="w-4 h-4 text-amber-500" />
              <h2 className="text-sm font-bold text-slate-200 font-sans">组合明细持仓</h2>
            </div>
            {/* 新增持仓按钮 */}
            <div className="flex items-center space-x-2 text-xs">
              <select
                value={selectedBondIdToAdd}
                onChange={(e) => setSelectedBondIdToAdd(e.target.value)}
                className="bg-slate-950 border border-slate-700 text-slate-200 px-2 py-1 rounded outline-none"
              >
                {bondsList.map((b) => (
                  <option key={b.id} value={b.id}>{b.code} {b.name}</option>
                ))}
              </select>
              <input
                type="number"
                value={addQty}
                onChange={(e) => setAddQty(Number(e.target.value))}
                className="w-20 bg-slate-950 border border-slate-700 text-slate-200 px-2 py-1 rounded outline-none text-right"
                placeholder="面值"
              />
              <span className="text-slate-400 text-[11px]">万</span>
              <button
                onClick={() => {
                  const b = bondsList.find((x) => x.id === selectedBondIdToAdd);
                  if (b) addPosition(b, addQty, b.price);
                }}
                className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-2 py-1 rounded flex items-center space-x-1"
              >
                <Plus className="w-3 h-3" />
                <span>添加</span>
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 bg-slate-950">
                  <th className="p-2">代码 / 名称</th>
                  <th className="p-2 text-right">面值 (万元)</th>
                  <th className="p-2 text-right">成本价 (元)</th>
                  <th className="p-2 text-right">最新价 (元)</th>
                  <th className="p-2 text-right">市值 (万元)</th>
                  <th className="p-2 text-right">权重 (%)</th>
                  <th className="p-2 text-center">操作</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/40">
                {portfolioPositions.map((pos) => (
                  <tr key={pos.id} className="hover:bg-slate-800/50">
                    <td className="p-2 font-bold text-amber-400">
                      {pos.bond.code} <span className="text-slate-200 font-sans font-normal">{pos.bond.name}</span>
                    </td>
                    <td className="p-2 text-right">
                      <input
                        type="number"
                        value={pos.quantity}
                        onChange={(e) => updatePositionQuantity(pos.id, Number(e.target.value))}
                        className="w-20 bg-slate-950 border border-slate-700 text-slate-100 text-right px-1 py-0.5 rounded outline-none"
                      />
                    </td>
                    <td className="p-2 text-right text-slate-400">¥{pos.costPrice.toFixed(2)}</td>
                    <td className="p-2 text-right text-slate-200">¥{pos.currentPrice.toFixed(2)}</td>
                    <td className="p-2 text-right text-emerald-400 font-bold">
                      ¥{(pos.marketValue / 10000).toFixed(1)}
                    </td>
                    <td className="p-2 text-right text-amber-400 font-bold">{pos.weightPct.toFixed(1)}%</td>
                    <td className="p-2 text-center">
                      <button
                        onClick={() => removePosition(pos.id)}
                        className="text-slate-500 hover:text-rose-400 p-1 rounded"
                        title="删除持仓"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* 右侧维度拆解占比 (1 Col) */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center space-x-2">
              <Layers className="w-4 h-4 text-amber-500" />
              <h2 className="text-sm font-bold text-slate-200 font-sans">风险维度拆解 (按期限)</h2>
            </div>
          </div>

          <div className="space-y-2 text-xs">
            {Object.keys(analytics.riskBreakdown.byTenor).map((k) => {
              const item = analytics.riskBreakdown.byTenor[k];
              return (
                <div key={k} className="bg-slate-950 p-2 rounded border border-slate-800 space-y-1">
                  <div className="flex justify-between font-bold">
                    <span className="text-slate-200">{k}</span>
                    <span className="text-amber-400">{item.pct}%</span>
                  </div>
                  <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-amber-500 h-full rounded-full" style={{ width: `${item.pct}%` }}></div>
                  </div>
                  <div className="flex justify-between text-[11px] text-slate-400">
                    <span>市值: ¥{(item.marketValue / 10000).toFixed(1)}万</span>
                    <span>DV01: ¥{item.dv01}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* 下半部分: Carry & Roll-Down 算子 + 利率 P&L 归因 */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Carry & Roll-Down 分析面板 */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center space-x-2">
              <Sliders className="w-4 h-4 text-amber-500" />
              <h2 className="text-sm font-bold text-slate-200 font-sans">Carry & Roll-Down 持有收益分析</h2>
            </div>
          </div>

          {/* 交互控件 */}
          <div className="grid grid-cols-2 gap-3 text-xs bg-slate-950 p-2.5 rounded border border-slate-800">
            <div>
              <label className="text-slate-400 block mb-1">预估持有天数 (Holding Days):</label>
              <div className="flex space-x-1">
                {[7, 30, 90, 180, 365].map((d) => (
                  <button
                    key={d}
                    onClick={() => setHoldingDays(d)}
                    className={`px-2 py-0.5 rounded text-[11px] ${
                      holdingDays === d ? 'bg-amber-500 text-slate-950 font-bold' : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {d}天
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="text-slate-400 block mb-1">回购融资成本率 (%):</label>
              <input
                type="number"
                step="0.05"
                value={financingRate}
                onChange={(e) => setFinancingRate(Number(e.target.value))}
                className="w-full bg-slate-900 border border-slate-700 text-slate-100 px-2 py-0.5 rounded outline-none"
              />
            </div>
          </div>

          {/* 计算结果 */}
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="bg-slate-950 p-2 rounded border border-slate-800">
              <span className="text-slate-400 block">票息收益 (Coupon Carry):</span>
              <span className="text-slate-100 font-bold">¥{carryRes.couponCarry.toLocaleString()}</span>
            </div>
            <div className="bg-slate-950 p-2 rounded border border-slate-800">
              <span className="text-slate-400 block">融资成本 (Financing Cost):</span>
              <span className="text-rose-400 font-bold">-¥{carryRes.financingCost.toLocaleString()}</span>
            </div>
            <div className="bg-slate-950 p-2 rounded border border-slate-800">
              <span className="text-slate-400 block">净 Carry (Net Carry):</span>
              <span className="text-emerald-400 font-bold">¥{carryRes.netCarry.toLocaleString()}</span>
            </div>
            <div className="bg-slate-950 p-2 rounded border border-slate-800">
              <span className="text-slate-400 block">滚动下滑收益 (Roll-Down):</span>
              <span className="text-cyan-400 font-bold">¥{carryRes.rollDownGain.toLocaleString()}</span>
            </div>
          </div>

          <div className="bg-slate-950 p-2 rounded border border-slate-800 flex justify-between items-center text-xs">
            <span className="text-slate-300 font-bold">总预期持有期收益 (Total Return):</span>
            <span className="text-amber-400 font-bold text-sm">
              ¥{carryRes.totalExpectedReturn.toLocaleString()} (年化 {carryRes.totalReturnPct}%)
            </span>
          </div>
        </div>

        {/* P&L 归因拆解面板 */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center space-x-2">
              <DollarSign className="w-4 h-4 text-emerald-400" />
              <h2 className="text-sm font-bold text-slate-200 font-sans">利率 P&L 损益归因拆解 (Attribution)</h2>
            </div>
          </div>

          <div className="space-y-2 text-xs font-mono">
            {[
              { label: '1. 票息利息收入 (Coupon Income)', value: pnlAttribution.couponIncome, color: 'text-slate-100' },
              { label: '2. 曲线下滑收益 (Roll-Down Return)', value: pnlAttribution.rollDownReturn, color: 'text-cyan-400' },
              { label: '3. 曲线平移/平行变动效应 (Curve Shift)', value: pnlAttribution.curveShiftReturn, color: 'text-amber-400' },
              { label: '4. 信用利差变动效应 (Spread Shift)', value: pnlAttribution.spreadShiftReturn, color: 'text-purple-400' },
              { label: '5. 凸性与价格残差 (Price Residual)', value: pnlAttribution.priceEffect, color: 'text-slate-400' }
            ].map((item) => (
              <div key={item.label} className="flex justify-between items-center bg-slate-950 p-2 rounded border border-slate-800">
                <span className="text-slate-300">{item.label}</span>
                <span className={`font-bold ${item.color}`}>
                  {item.value >= 0 ? `+¥${item.value.toLocaleString()}` : `-¥${Math.abs(item.value).toLocaleString()}`}
                </span>
              </div>
            ))}

            <div className="flex justify-between items-center bg-emerald-950/40 border border-emerald-800/80 p-2 rounded font-bold text-sm text-emerald-300">
              <span>合计已实现/浮动 P&L:</span>
              <span>+¥{pnlAttribution.totalPnL.toLocaleString()}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
