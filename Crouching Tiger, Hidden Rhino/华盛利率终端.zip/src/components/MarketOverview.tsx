/**
 * 华盛利率终端 - 市场总览模块
 * HUASHENG RATES - Market Overview, Heatmap & Live Stream Ticker
 */

import React, { useState } from 'react';
import { useRatesStore } from '../stores/useRatesStore';
import {
  TrendingUp,
  TrendingDown,
  Info,
  Radio,
  Flame,
  Filter,
  BarChart2,
  ArrowUpDown,
  RefreshCw
} from 'lucide-react';

export const MarketOverview: React.FC = () => {
  const { quotes, cgbCurve, setActiveTab, setSelectedBond, bondsList } = useRatesStore();
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');

  const filteredQuotes = categoryFilter === 'ALL'
    ? quotes
    : quotes.filter((q) => q.category === categoryFilter);

  // 热力图数据行 (1Y - 30Y) 与列 (今日, 1日, 5日, 1月, 3月, 1年)
  const heatmapTenors = ['1Y', '2Y', '3Y', '5Y', '7Y', '10Y', '15Y', '20Y', '30Y'];
  const heatmapHorizons = ['今日', '1日', '5日', '1月', '3月', '1年'];

  // 热力图颜色逻辑: 收益率下降为绿 (利好债券价格)，上升为红
  const getHeatmapBg = (valBp: number) => {
    if (valBp < -5) return 'bg-emerald-950/80 text-emerald-300 font-bold border border-emerald-800/80';
    if (valBp < 0) return 'bg-emerald-900/40 text-emerald-400 border border-emerald-900/60';
    if (valBp === 0) return 'bg-slate-900 text-slate-400 border border-slate-800';
    if (valBp < 5) return 'bg-rose-900/40 text-rose-400 border border-rose-900/60';
    return 'bg-rose-950/80 text-rose-300 font-bold border border-rose-800/80';
  };

  return (
    <div className="p-4 space-y-4 font-mono text-slate-100 select-none">
      {/* 顶部行情提示 Banner */}
      <div className="bg-slate-900/80 border border-slate-800 p-3 rounded-lg flex items-center justify-between text-xs">
        <div className="flex items-center space-x-2">
          <Radio className="w-4 h-4 text-amber-500 animate-pulse" />
          <span className="text-slate-300 font-semibold">固定收益实时模拟行情流:</span>
          <span className="text-slate-400">
            国债10Y主力做市报 2.16% (-1.2bp) | 国开10Y报 2.35% (-1.5bp) | FR007 IRS 5Y报 2.20%
          </span>
        </div>
        <div className="flex items-center space-x-2 text-[11px] text-amber-400/90 bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded">
          <Info className="w-3.5 h-3.5" />
          <span>免责提示: 页面显示均为模拟 / 示例数据</span>
        </div>
      </div>

      {/* 主工作区: 行情列表 (2/3) + 热力图 (1/3) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* 左侧主要做市报价表 (2 Cols) */}
        <div className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center space-x-2">
              <BarChart2 className="w-4 h-4 text-amber-500" />
              <h2 className="text-sm font-bold text-slate-200 font-sans">
                利率市场核心做市行行情
              </h2>
            </div>

            {/* 类别分类筛选器 */}
            <div className="flex items-center space-x-1 text-[11px]">
              {[
                { id: 'ALL', label: '全部品种' },
                { id: 'CGB', label: '中国国债' },
                { id: 'POLICY_BANK', label: '政金债' },
                { id: 'CORP', label: '企业债' },
                { id: 'FUTURES', label: '国债期货' },
                { id: 'SWAP', label: '利率互换' }
              ].map((f) => (
                <button
                  key={f.id}
                  onClick={() => setCategoryFilter(f.id)}
                  className={`px-2 py-1 rounded transition-colors ${
                    categoryFilter === f.id
                      ? 'bg-amber-500 text-slate-950 font-bold'
                      : 'bg-slate-800/80 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          {/* 表格 */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 bg-slate-950/60">
                  <th className="p-2">代码 / 名称</th>
                  <th className="p-2 text-right">最新收益率 (%)</th>
                  <th className="p-2 text-right">日变动 (bp)</th>
                  <th className="p-2 text-right">周变动</th>
                  <th className="p-2 text-right">月变动</th>
                  <th className="p-2 text-right">成交量 (亿元)</th>
                  <th className="p-2 text-right">久期 (年)</th>
                  <th className="p-2 text-right">DV01 (元)</th>
                  <th className="p-2 text-center">快捷分析</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredQuotes.map((q) => {
                  const isUp = q.change1D > 0;
                  return (
                    <tr
                      key={q.code}
                      className="hover:bg-slate-800/50 transition-colors group cursor-pointer"
                    >
                      <td className="p-2 font-semibold text-slate-200 flex items-center space-x-2">
                        <span className="text-amber-400">{q.code}</span>
                        <span className="text-slate-300 font-sans">{q.name}</span>
                      </td>
                      <td className="p-2 text-right text-slate-100 font-bold text-sm">
                        {q.latestYield.toFixed(2)}%
                      </td>
                      <td
                        className={`p-2 text-right font-bold ${
                          isUp ? 'text-rose-400' : 'text-emerald-400'
                        }`}
                      >
                        <span className="flex items-center justify-end">
                          {isUp ? (
                            <TrendingUp className="w-3 h-3 mr-0.5" />
                          ) : (
                            <TrendingDown className="w-3 h-3 mr-0.5" />
                          )}
                          {isUp ? `+${q.change1D.toFixed(1)}` : `${q.change1D.toFixed(1)}`}
                        </span>
                      </td>
                      <td className="p-2 text-right text-slate-400">
                        {q.change1W > 0 ? `+${q.change1W.toFixed(1)}` : q.change1W.toFixed(1)}
                      </td>
                      <td className="p-2 text-right text-slate-400">
                        {q.change1M > 0 ? `+${q.change1M.toFixed(1)}` : q.change1M.toFixed(1)}
                      </td>
                      <td className="p-2 text-right text-slate-300">
                        {q.volumeAmount.toFixed(1)}
                      </td>
                      <td className="p-2 text-right text-cyan-400">{q.duration.toFixed(2)}</td>
                      <td className="p-2 text-right text-emerald-400 font-semibold">
                        ¥{q.dv01.toFixed(2)}
                      </td>
                      <td className="p-2 text-center">
                        <button
                          onClick={() => {
                            const foundBond = bondsList.find((b) => b.code.includes(q.code)) || bondsList[0];
                            setSelectedBond(foundBond);
                            setActiveTab(2); // 跳转至单券分析
                          }}
                          className="bg-slate-800 hover:bg-amber-500 hover:text-slate-950 text-slate-300 px-2 py-0.5 rounded text-[10px] transition-colors"
                        >
                          深度分析
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* 右侧利率变动热力图 (1 Col) */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center space-x-2">
              <Flame className="w-4 h-4 text-amber-500" />
              <h2 className="text-sm font-bold text-slate-200 font-sans">
                国债收益率变动热力图
              </h2>
            </div>
            <span className="text-[10px] text-slate-500">基准: 中国国债曲线</span>
          </div>

          <p className="text-[11px] text-slate-400 font-sans">
            展示不同期限在各个历史窗口期下的收益率变动幅值 (单位: bp，绿色代表收益率下行/价格上涨):
          </p>

          {/* 热力图 Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-center text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 bg-slate-950">
                  <th className="p-1.5 text-left">期限</th>
                  {heatmapHorizons.map((h) => (
                    <th key={h} className="p-1.5">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/40">
                {heatmapTenors.map((tenor, tIdx) => {
                  return (
                    <tr key={tenor}>
                      <td className="p-1.5 font-bold text-slate-300 text-left bg-slate-950/40">
                        {tenor}
                      </td>
                      {heatmapHorizons.map((h, hIdx) => {
                        // 估算热力图 BP
                        const baseBp = (tIdx - 4) * 0.8 - (hIdx + 1) * 2.2;
                        const bpVal = Number(baseBp.toFixed(1));
                        return (
                          <td key={h} className={`p-1.5 font-mono text-[11px] ${getHeatmapBg(bpVal)}`}>
                            {bpVal > 0 ? `+${bpVal}` : bpVal}
                          </td>
                        );
                      })}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* 图例 */}
          <div className="flex items-center justify-between text-[10px] text-slate-400 pt-2 border-t border-slate-800">
            <span className="flex items-center space-x-1">
              <span className="w-3 h-3 bg-emerald-900 border border-emerald-600 rounded-xs"></span>
              <span>大幅下行 (&lt;-5bp)</span>
            </span>
            <span className="flex items-center space-x-1">
              <span className="w-3 h-3 bg-slate-900 border border-slate-700 rounded-xs"></span>
              <span>持平 (0bp)</span>
            </span>
            <span className="flex items-center space-x-1">
              <span className="w-3 h-3 bg-rose-900 border border-rose-600 rounded-xs"></span>
              <span>大幅上行 (&gt;+5bp)</span>
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
