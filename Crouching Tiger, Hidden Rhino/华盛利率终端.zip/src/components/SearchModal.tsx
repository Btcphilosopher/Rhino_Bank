/**
 * 华盛利率终端 - 全局 Ctrl+K 命令搜索 Modal
 * HUASHENG RATES - Global Command Search Palette Modal
 */

import React, { useEffect, useState } from 'react';
import { useRatesStore } from '../stores/useRatesStore';
import { Search, X, ArrowRight, FileText, TrendingUp, Layers, Cpu } from 'lucide-react';
import { NAV_ITEMS } from './Navbar';

export const SearchModal: React.FC = () => {
  const {
    isSearchModalOpen,
    setSearchModalOpen,
    bondsList,
    setSelectedBond,
    setActiveTab
  } = useRatesStore();

  const [filterText, setFilterText] = useState('');

  // 监听键盘 Ctrl+K / Command+K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setSearchModalOpen(true);
      } else if (e.key === 'Escape' && isSearchModalOpen) {
        setSearchModalOpen(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isSearchModalOpen, setSearchModalOpen]);

  if (!isSearchModalOpen) return null;

  const matchedBonds = bondsList.filter(
    (b) =>
      b.name.includes(filterText) ||
      b.code.toLowerCase().includes(filterText.toLowerCase()) ||
      b.issuer.includes(filterText) ||
      b.sector.includes(filterText)
  );

  const matchedTabs = NAV_ITEMS.filter((t) => t.label.includes(filterText));

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-start justify-center pt-20 p-4">
      <div className="bg-slate-900 border border-slate-700/80 rounded-lg shadow-2xl w-full max-w-2xl overflow-hidden font-mono">
        {/* 搜索输入框 */}
        <div className="p-3 border-b border-slate-800 flex items-center space-x-3 bg-slate-950/80">
          <Search className="w-5 h-5 text-amber-500" />
          <input
            type="text"
            autoFocus
            placeholder="输入搜索关键字 (例: 10年国债 / 收益率曲线 / 240010)..."
            value={filterText}
            onChange={(e) => setFilterText(e.target.value)}
            className="bg-transparent text-slate-100 placeholder-slate-500 text-sm w-full outline-none"
          />
          <button
            onClick={() => setSearchModalOpen(false)}
            className="text-slate-400 hover:text-slate-200 p-1 rounded"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* 搜索结果分类 */}
        <div className="p-3 max-h-96 overflow-y-auto space-y-4 text-xs">
          {/* 功能模块跳转 */}
          {matchedTabs.length > 0 && (
            <div>
              <div className="text-slate-500 text-[11px] font-semibold mb-1.5 flex items-center space-x-1">
                <TrendingUp className="w-3 h-3 text-amber-500" />
                <span>终端分析模块</span>
              </div>
              <div className="grid grid-cols-2 gap-1.5">
                {matchedTabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => {
                      setActiveTab(tab.id);
                      setSearchModalOpen(false);
                    }}
                    className="flex items-center justify-between p-2 rounded bg-slate-800/50 hover:bg-slate-800 text-slate-200 hover:text-amber-400 border border-slate-800 transition-colors text-left"
                  >
                    <span className="font-sans font-medium">{tab.label}</span>
                    <ArrowRight className="w-3.5 h-3.5 text-slate-500" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* 债券列表精准搜索 */}
          <div>
            <div className="text-slate-500 text-[11px] font-semibold mb-1.5 flex items-center space-x-1">
              <FileText className="w-3 h-3 text-cyan-500" />
              <span>债券列表 ({matchedBonds.length})</span>
            </div>
            {matchedBonds.length === 0 ? (
              <div className="text-slate-500 text-center py-4">未找到匹配的债券</div>
            ) : (
              <div className="space-y-1">
                {matchedBonds.map((bond) => (
                  <button
                    key={bond.id}
                    onClick={() => {
                      setSelectedBond(bond);
                      setActiveTab(2); // 跳转至单券分析
                      setSearchModalOpen(false);
                    }}
                    className="w-full flex items-center justify-between p-2 rounded bg-slate-800/30 hover:bg-slate-800 text-slate-200 border border-slate-800/60 hover:border-amber-500/40 transition-colors text-left"
                  >
                    <div className="flex items-center space-x-3">
                      <span className="text-amber-400 font-bold">{bond.code}</span>
                      <span className="font-sans font-medium">{bond.name}</span>
                      <span className="text-slate-500 text-[10px] bg-slate-950 px-1.5 py-0.5 rounded">
                        {bond.sector}
                      </span>
                    </div>
                    <div className="flex items-center space-x-4">
                      <span className="text-slate-400">票面: {bond.couponRate}%</span>
                      <span className="text-emerald-400 font-bold">YTM: {bond.yield}%</span>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Modal 底部操作提示 */}
        <div className="px-3 py-2 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-500">
          <span>选择项直接进入分析工具，Esc 关闭</span>
          <span>华盛利率终端 (HUASHENG RATES)</span>
        </div>
      </div>
    </div>
  );
};
