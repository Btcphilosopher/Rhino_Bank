/**
 * 华盛利率终端 - 历史分析与 PCA 主成分分解中心
 * HUASHENG RATES - Yield Curve PCA (Level, Slope, Curvature) & Time Machine (2015-2026)
 */

import React, { useState } from 'react';
import ReactECharts from 'echarts-for-react';
import { runYieldCurvePCA } from '../quant/varAndPca';
import { TIME_MACHINE_HISTORICAL_CURVES } from '../data/mockMarketData';
import { History, Sliders, Cpu, Activity, Play, Pause } from 'lucide-react';

export const HistoricalAndPCAView: React.FC = () => {
  const pcaResult = runYieldCurvePCA();
  const [selectedYear, setSelectedYear] = useState<number>(2026);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);

  const availableYears = [2015, 2017, 2020, 2022, 2024, 2026];
  const activeHistoricalCurve = TIME_MACHINE_HISTORICAL_CURVES[selectedYear] || TIME_MACHINE_HISTORICAL_CURVES[2026];

  // 1. PCA 因子 Loading ECharts 配置
  const getPcaChartOption = () => {
    return {
      backgroundColor: 'transparent',
      tooltip: { trigger: 'axis' },
      legend: { textStyle: { color: '#94a3b8' }, top: 5 },
      grid: { left: '3%', right: '4%', bottom: '10%', top: '18%', containLabel: true },
      xAxis: {
        type: 'category',
        data: pcaResult.tenors,
        axisLine: { lineStyle: { color: '#334155' } },
        axisLabel: { color: '#94a3b8' }
      },
      yAxis: {
        type: 'value',
        name: 'Factor Loadings',
        nameTextStyle: { color: '#94a3b8' },
        axisLine: { lineStyle: { color: '#334155' } },
        splitLine: { lineStyle: { color: '#1e293b' } },
        axisLabel: { color: '#94a3b8' }
      },
      series: [
        {
          name: `PC1 水平因子 (${pcaResult.factors.level.varianceSharePct}%)`,
          type: 'line',
          smooth: true,
          data: pcaResult.factors.level.loadings,
          lineStyle: { width: 3, color: '#f59e0b' },
          itemStyle: { color: '#f59e0b' }
        },
        {
          name: `PC2 斜率因子 (${pcaResult.factors.slope.varianceSharePct}%)`,
          type: 'line',
          smooth: true,
          data: pcaResult.factors.slope.loadings,
          lineStyle: { width: 2.5, color: '#38bdf8' },
          itemStyle: { color: '#38bdf8' }
        },
        {
          name: `PC3 曲率因子 (${pcaResult.factors.curvature.varianceSharePct}%)`,
          type: 'line',
          smooth: true,
          data: pcaResult.factors.curvature.loadings,
          lineStyle: { width: 2, color: '#10b981' },
          itemStyle: { color: '#10b981' }
        }
      ]
    };
  };

  // 2. 历史时光机 ECharts 配置
  const getTimeMachineChartOption = () => {
    const points = activeHistoricalCurve.points;
    return {
      backgroundColor: 'transparent',
      tooltip: { trigger: 'axis' },
      grid: { left: '3%', right: '4%', bottom: '10%', top: '15%', containLabel: true },
      xAxis: {
        type: 'category',
        data: points.map((p) => p.tenor),
        axisLine: { lineStyle: { color: '#334155' } },
        axisLabel: { color: '#94a3b8' }
      },
      yAxis: {
        type: 'value',
        name: 'Yield (%)',
        scale: true,
        nameTextStyle: { color: '#94a3b8' },
        axisLine: { lineStyle: { color: '#334155' } },
        splitLine: { lineStyle: { color: '#1e293b' } },
        axisLabel: { color: '#94a3b8', formatter: '{value}%' }
      },
      series: [
        {
          name: `${selectedYear}年 国债收益率曲线`,
          type: 'line',
          smooth: true,
          data: points.map((p) => p.yield),
          lineStyle: { width: 3.5, color: '#f59e0b' },
          itemStyle: { color: '#f59e0b' },
          areaStyle: { color: 'rgba(245, 158, 11, 0.1)' }
        }
      ]
    };
  };

  return (
    <div className="p-4 space-y-4 font-mono text-slate-100 select-none">
      {/* 顶部标题栏 */}
      <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg flex items-center justify-between text-xs">
        <div className="flex items-center space-x-2">
          <History className="w-4 h-4 text-amber-500" />
          <h2 className="text-sm font-bold text-slate-200 font-sans">
            收益率曲线 PCA 主成分分解与历史时光机 (2015-2026)
          </h2>
        </div>
        <span className="text-slate-400">
          前三大主成分累计解释度: <strong className="text-emerald-400">99.6%</strong>
        </span>
      </div>

      {/* 1. PCA 因子分解 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* PCA 图表 (2 Cols) */}
        <div className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-3">
          <div className="text-xs font-bold text-slate-200 border-b border-slate-800 pb-2 flex items-center justify-between">
            <span>收益率曲线 PCA 主成分因子 Loadings 提取</span>
            <span className="text-[11px] text-slate-400 font-normal">三因子: Level, Slope, Curvature</span>
          </div>

          <div className="h-64 w-full">
            <ReactECharts option={getPcaChartOption()} style={{ height: '100%', width: '100%' }} />
          </div>
        </div>

        {/* PCA 解释度面板 (1 Col) */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-3">
          <div className="text-xs font-bold text-slate-200 border-b border-slate-800 pb-2">
            主成分解释度 (Variance Explained)
          </div>

          <div className="space-y-2 text-xs">
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800 space-y-1">
              <div className="flex justify-between font-bold">
                <span className="text-amber-400">PC1: 水平因子 (Level)</span>
                <span className="text-slate-100">{pcaResult.factors.level.varianceSharePct}%</span>
              </div>
              <p className="text-[11px] text-slate-400 font-sans">
                反映收益率曲线的整体上下平行移动，为最主要的风险来源。
              </p>
            </div>

            <div className="bg-slate-950 p-2.5 rounded border border-slate-800 space-y-1">
              <div className="flex justify-between font-bold">
                <span className="text-cyan-400">PC2: 斜率因子 (Slope)</span>
                <span className="text-slate-100">{pcaResult.factors.slope.varianceSharePct}%</span>
              </div>
              <p className="text-[11px] text-slate-400 font-sans">
                反映长短端利差变化 (陡峭化/平坦化)。
              </p>
            </div>

            <div className="bg-slate-950 p-2.5 rounded border border-slate-800 space-y-1">
              <div className="flex justify-between font-bold">
                <span className="text-emerald-400">PC3: 曲率因子 (Curvature)</span>
                <span className="text-slate-100">{pcaResult.factors.curvature.varianceSharePct}%</span>
              </div>
              <p className="text-[11px] text-slate-400 font-sans">
                反映中端相对于两端的凹凸形变 (蝶式变形)。
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* 2. 历史时光机 Time Machine */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-3">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="flex items-center space-x-2">
            <Sliders className="w-4 h-4 text-amber-500" />
            <h2 className="text-sm font-bold text-slate-200 font-sans">
              历史收益率时光机 ({selectedYear}年)
            </h2>
          </div>

          {/* 年份选择器 */}
          <div className="flex items-center space-x-1">
            {availableYears.map((yr) => (
              <button
                key={yr}
                onClick={() => setSelectedYear(yr)}
                className={`px-2.5 py-1 rounded text-xs transition-colors ${
                  selectedYear === yr
                    ? 'bg-amber-500 text-slate-950 font-bold'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {yr}年
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 h-64 w-full">
            <ReactECharts option={getTimeMachineChartOption()} style={{ height: '100%', width: '100%' }} />
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-2 text-xs">
            <h3 className="font-bold text-amber-400 text-sm">{activeHistoricalCurve.name}</h3>
            <p className="text-slate-300 font-sans text-xs leading-relaxed">
              {selectedYear === 2015 && '2015年: 供给侧结构性改革推进，货币政策保持宽松，债市迎来显著大牛市，收益率中枢逐级下移。'}
              {selectedYear === 2017 && '2017年: 金融严监管与去杠杆政策密集出台，“钱荒”再现，国债收益率快速拉升突破3.95%，曲线呈现严重倒挂。'}
              {selectedYear === 2020 && '2020年: 疫情初期央行大幅降准降息，收益率创历史低位；随后经济强劲复苏与供给增加，收益率快速大幅反弹。'}
              {selectedYear === 2022 && '2022年: 年底理财净值化后迎来历史性赎回潮，债券市场剧烈震荡，收益率短期大幅上行。'}
              {selectedYear === 2024 && '2024年: “资产荒”格局持续，长期与超长期国债受到大力追捧，30Y国债收益率跌破2.5%。'}
              {selectedYear === 2026 && '2026年: 利率处于历史低位区间，机构注重久期控制与曲线陡峭化对冲管理。'}
            </p>

            <div className="pt-2 border-t border-slate-800 font-mono text-[11px] space-y-1">
              <p className="text-slate-400">10Y 收益率: <strong className="text-slate-100">{activeHistoricalCurve.points.find(p => p.tenor === '10Y')?.yield}%</strong></p>
              <p className="text-slate-400">10Y-2Y 利差: <strong className="text-amber-400">{activeHistoricalCurve.slope10Y2Y} bp</strong></p>
              <p className="text-slate-400">曲线形态: <strong className="text-emerald-400">{activeHistoricalCurve.morphology}</strong></p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
