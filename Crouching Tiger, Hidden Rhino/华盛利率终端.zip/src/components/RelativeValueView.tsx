/**
 * 华盛利率终端 - 相对价值与利差分析中心
 * HUASHENG RATES - Relative Value (RV) Z-Score & Spread Analytics (G, I, Z-Spread, OAS)
 */

import React from 'react';
import { useRatesStore } from '../stores/useRatesStore';
import { analyzeBondSpreads, analyzeRelativeValuePairs } from '../quant/spreadsAndRV';
import { Scale, TrendingUp, Layers, Sliders } from 'lucide-react';

export const RelativeValueView: React.FC = () => {
  const { bondsList, cgbCurve, swapCurve } = useRatesStore();

  const spreadsList = analyzeBondSpreads(bondsList, cgbCurve, swapCurve);
  const rvPairs = analyzeRelativeValuePairs(cgbCurve);

  return (
    <div className="p-4 space-y-4 font-mono text-slate-100 select-none">
      {/* 顶部说明 */}
      <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg flex items-center justify-between text-xs">
        <div className="flex items-center space-x-2">
          <Scale className="w-4 h-4 text-amber-500" />
          <h2 className="text-sm font-bold text-slate-200 font-sans">
            相对价值 (Relative Value - RV) 与利差结构 (G, I, Z-Spread & OAS)
          </h2>
        </div>
        <span className="text-slate-400">基于近 5 年历史均值与 Z-Score 衡量极值回归概率</span>
      </div>

      {/* 1. 曲线期限利差对相对价值 Z-Score 矩阵 */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-3">
        <div className="text-xs font-bold text-slate-200 border-b border-slate-800 pb-2">
          国债曲线期限利差 5 年 Z-Score 相对价值分析
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
          {rvPairs.map((pair) => {
            const isHigh = pair.zScore > 1.0;
            const isLow = pair.zScore < -1.0;
            return (
              <div key={pair.pairName} className="bg-slate-950 p-3 rounded border border-slate-800 space-y-2">
                <div className="flex justify-between font-bold">
                  <span className="text-slate-200">{pair.pairName}</span>
                  <span
                    className={`px-1.5 py-0.5 rounded text-[10px] ${
                      isHigh
                        ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                        : isLow
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {isHigh ? '高位偏陡' : isLow ? '低位偏平' : '中性区间'}
                  </span>
                </div>

                <div className="flex justify-between items-baseline font-mono">
                  <span className="text-slate-400 text-[11px]">当前利差:</span>
                  <span className="text-amber-400 font-bold text-lg">{pair.spreadBp} bp</span>
                </div>

                <div className="grid grid-cols-2 gap-1 text-[11px] text-slate-400 pt-1 border-t border-slate-800">
                  <div>
                    <span>5年均值: </span>
                    <strong className="text-slate-200">{pair.mean5Y} bp</strong>
                  </div>
                  <div>
                    <span>Z-Score: </span>
                    <strong className="text-cyan-400">{pair.zScore}</strong>
                  </div>
                </div>

                <div className="space-y-1 pt-1">
                  <div className="flex justify-between text-[10px] text-slate-400">
                    <span>5年历史分位数</span>
                    <span className="text-amber-400 font-bold">{pair.percentile5Y}%</span>
                  </div>
                  <div className="w-full bg-slate-800 h-1 rounded overflow-hidden">
                    <div
                      className="bg-amber-500 h-full rounded"
                      style={{ width: `${pair.percentile5Y}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 2. 债券利差分解表 (G, I, Z-Spread, OAS) */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-3">
        <div className="text-xs font-bold text-slate-200 border-b border-slate-800 pb-2">
          债券全量利差结构分解表 (Spread Breakdown)
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-950">
                <th className="p-2">代码 / 名称</th>
                <th className="p-2 text-right">债券 YTM (%)</th>
                <th className="p-2 text-right">匹配基准国债 (%)</th>
                <th className="p-2 text-right">G-Spread (bp)</th>
                <th className="p-2 text-right">I-Spread vs Swap (bp)</th>
                <th className="p-2 text-right">Z-Spread (bp)</th>
                <th className="p-2 text-right">OAS (bp)</th>
                <th className="p-2 text-right">Asset Swap (bp)</th>
                <th className="p-2 text-right">5年分位数 (%)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/40 font-mono">
              {spreadsList.map((item) => (
                <tr key={item.bondCode} className="hover:bg-slate-800/50">
                  <td className="p-2 font-bold text-amber-400">
                    {item.bondCode} <span className="text-slate-200 font-sans font-normal">{item.bondName}</span>
                  </td>
                  <td className="p-2 text-right font-bold text-slate-100">{item.bondYield.toFixed(2)}%</td>
                  <td className="p-2 text-right text-slate-400">{item.benchmarkYield.toFixed(2)}%</td>
                  <td className="p-2 text-right text-amber-400 font-bold">{item.gSpread} bp</td>
                  <td className="p-2 text-right text-cyan-400">{item.iSpread} bp</td>
                  <td className="p-2 text-right text-emerald-400 font-bold">{item.zSpread} bp</td>
                  <td className="p-2 text-right text-purple-400">{item.oas} bp</td>
                  <td className="p-2 text-right text-slate-300">{item.assetSwapSpread} bp</td>
                  <td className="p-2 text-right text-slate-400">{item.percentile5Y}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
