/**
 * 华盛利率终端 - 组合 VaR 风险与尾部损失度量
 * HUASHENG RATES - Portfolio VaR (Historical, Parametric, Monte Carlo) & CVaR Analytics
 */

import React, { useState } from 'react';
import ReactECharts from 'echarts-for-react';
import { useRatesStore } from '../stores/useRatesStore';
import { calculatePortfolioAnalytics } from '../quant/portfolio';
import { calculatePortfolioVaR } from '../quant/varAndPca';
import { ShieldCheck, ShieldAlert, Sliders, DollarSign, Activity } from 'lucide-react';

export const RiskVaRView: React.FC = () => {
  const { portfolioPositions } = useRatesStore();
  const analytics = calculatePortfolioAnalytics(portfolioPositions);

  const [confidenceLevel, setConfidenceLevel] = useState<0.95 | 0.99>(0.95);
  const [horizonDays, setHorizonDays] = useState<1 | 5 | 10>(1);

  // 100% 由量化引擎计算
  const varResult = calculatePortfolioVaR(analytics, confidenceLevel, horizonDays);

  const getChartOption = () => {
    return {
      backgroundColor: 'transparent',
      tooltip: { trigger: 'axis' },
      grid: { left: '3%', right: '4%', bottom: '10%', top: '15%', containLabel: true },
      xAxis: {
        type: 'category',
        data: varResult.lossDistributionHistogram.map((h) => h.bin),
        axisLine: { lineStyle: { color: '#334155' } },
        axisLabel: { color: '#94a3b8' }
      },
      yAxis: {
        type: 'value',
        name: '频率 (Frequency)',
        axisLine: { lineStyle: { color: '#334155' } },
        splitLine: { lineStyle: { color: '#1e293b' } },
        axisLabel: { color: '#94a3b8' }
      },
      series: [
        {
          name: '损益分布频率',
          type: 'bar',
          data: varResult.lossDistributionHistogram.map((h) => h.frequency),
          itemStyle: {
            color: '#38bdf8'
          }
        }
      ]
    };
  };

  return (
    <div className="p-4 space-y-4 font-mono text-slate-100 select-none">
      <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg flex items-center justify-between text-xs">
        <div className="flex items-center space-x-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <h2 className="text-sm font-bold text-slate-200 font-sans">
            组合在价风险 (Value at Risk - VaR) 与 CVaR 尾部损失计算器
          </h2>
        </div>
        <span className="text-slate-400">
          基准评估组合市值: <strong className="text-amber-400">¥{(analytics.totalMarketValue / 10000).toFixed(1)}万元</strong>
        </span>
      </div>

      {/* 参数选择与指标面板 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* 控制面板 (1 Col) */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-4">
          <div className="flex items-center space-x-2 border-b border-slate-800 pb-2">
            <Sliders className="w-4 h-4 text-amber-500" />
            <h2 className="text-sm font-bold text-slate-200 font-sans">VaR 计算模型参数</h2>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <label className="text-slate-400 block mb-1">置信水平 (Confidence Level):</label>
              <div className="flex space-x-2">
                {[0.95, 0.99].map((cl) => (
                  <button
                    key={cl}
                    onClick={() => setConfidenceLevel(cl as any)}
                    className={`flex-1 py-1.5 rounded font-bold transition-colors ${
                      confidenceLevel === cl
                        ? 'bg-amber-500 text-slate-950 font-bold'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    {(cl * 100).toFixed(0)}% 置信水平
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">风险持有期限 (Horizon):</label>
              <div className="flex space-x-2">
                {[1, 5, 10].map((h) => (
                  <button
                    key={h}
                    onClick={() => setHorizonDays(h as any)}
                    className={`flex-1 py-1.5 rounded font-bold transition-colors ${
                      horizonDays === h
                        ? 'bg-amber-500 text-slate-950 font-bold'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    {h} 天 (D)
                  </button>
                ))}
              </div>
            </div>

            <div className="text-[11px] text-slate-400 space-y-1 pt-2 border-t border-slate-800 font-sans">
              <p>波动率假设: 基于近 250 日国债收益率历史重尾分布</p>
              <p>组合修正久期: {analytics.weightedModDuration.toFixed(2)} 年</p>
            </div>
          </div>
        </div>

        {/* 核心 VaR 结果卡片 (2 Cols) */}
        <div className="lg:col-span-2 space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
            <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg space-y-1">
              <span className="text-slate-400 text-[11px] block">历史模拟法 VaR:</span>
              <span className="text-rose-400 font-bold text-xl font-mono">
                -¥{varResult.historicalVaR.toLocaleString()}
              </span>
            </div>

            <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg space-y-1">
              <span className="text-slate-400 text-[11px] block">参数法 (Parametric) VaR:</span>
              <span className="text-rose-400 font-bold text-xl font-mono">
                -¥{varResult.parametricVaR.toLocaleString()}
              </span>
            </div>

            <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg space-y-1">
              <span className="text-slate-400 text-[11px] block">蒙特卡洛法 VaR:</span>
              <span className="text-rose-400 font-bold text-xl font-mono">
                -¥{varResult.monteCarloVaR.toLocaleString()}
              </span>
            </div>

            <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg space-y-1">
              <span className="text-slate-400 text-[11px] block">CVaR (预期条件尾部损失):</span>
              <span className="text-rose-500 font-bold text-xl font-mono">
                -¥{varResult.cvar.toLocaleString()}
              </span>
            </div>
          </div>

          <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-3">
            <div className="text-xs font-bold text-slate-200 border-b border-slate-800 pb-2">
              组合模拟损益分布 (PnL Distribution Histogram)
            </div>
            <div className="h-60 w-full">
              <ReactECharts option={getChartOption()} style={{ height: '100%', width: '100%' }} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
