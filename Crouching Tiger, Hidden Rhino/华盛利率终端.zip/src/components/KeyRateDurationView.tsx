/**
 * 华盛利率终端 - 关键期限久期 (KRD) 分析中心
 * HUASHENG RATES - Key Rate Duration (KRD) Vector Matrix & Shock Simulator
 */

import React, { useState } from 'react';
import ReactECharts from 'echarts-for-react';
import { useRatesStore } from '../stores/useRatesStore';
import { calculatePortfolioAnalytics } from '../quant/portfolio';
import { KeyTenor } from '../types';
import { Layers, Sliders, Info, Zap } from 'lucide-react';

export const KeyRateDurationView: React.FC = () => {
  const { portfolioPositions } = useRatesStore();
  const analytics = calculatePortfolioAnalytics(portfolioPositions);

  const keyTenors: KeyTenor[] = ['1Y', '2Y', '3Y', '5Y', '7Y', '10Y', '15Y', '20Y', '30Y'];

  // 自定义关键期限变动 (bp) 模拟
  const [customKeyShocks, setCustomKeyShocks] = useState<Record<KeyTenor, number>>({
    '1M': 0, '3M': 0, '6M': 0,
    '1Y': -10, '2Y': -15, '3Y': -5,
    '5Y': 10, '7Y': 20, '10Y': 25,
    '15Y': 15, '20Y': 10, '30Y': 5
  });

  // 根据 KRD 向量与 Key Rate Shock 估算 PnL 损失
  let estimatedPnL = 0;
  keyTenors.forEach((tenor) => {
    const krd = analytics.krdSummary[tenor] || 0;
    const shockBp = customKeyShocks[tenor] || 0;
    // PnL ≈ - Portfolio MV * KRD_i * Shift_i
    estimatedPnL += -1 * (analytics.totalMarketValue) * (krd * shockBp / 10000);
  });

  const getEChartsOption = () => {
    const krdValues = keyTenors.map((t) => analytics.krdSummary[t] || 0);

    return {
      backgroundColor: 'transparent',
      tooltip: {
        trigger: 'axis',
        axisPointer: { type: 'shadow' }
      },
      grid: { left: '3%', right: '4%', bottom: '10%', top: '15%', containLabel: true },
      xAxis: {
        type: 'category',
        data: keyTenors,
        axisLine: { lineStyle: { color: '#334155' } },
        axisLabel: { color: '#94a3b8' }
      },
      yAxis: {
        type: 'value',
        name: 'KRD (年)',
        nameTextStyle: { color: '#94a3b8' },
        axisLine: { lineStyle: { color: '#334155' } },
        splitLine: { lineStyle: { color: '#1e293b' } },
        axisLabel: { color: '#94a3b8' }
      },
      series: [
        {
          name: '关键期限久期 (KRD)',
          type: 'bar',
          data: krdValues,
          itemStyle: {
            color: '#f59e0b'
          },
          barWidth: '40%'
        }
      ]
    };
  };

  return (
    <div className="p-4 space-y-4 font-mono text-slate-100 select-none">
      {/* 顶部标题与说明 */}
      <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg flex items-center justify-between text-xs">
        <div className="flex items-center space-x-2">
          <Layers className="w-4 h-4 text-amber-500" />
          <h2 className="text-sm font-bold text-slate-200 font-sans">关键期限久期 (Key Rate Duration - KRD)</h2>
        </div>
        <span className="text-slate-400">
          组合总修正久期: <strong className="text-amber-400">{analytics.weightedModDuration.toFixed(2)} 年</strong> (各 KRD 向量之和)
        </span>
      </div>

      {/* 图表与模拟器 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* 左侧柱状图 (2 Cols) */}
        <div className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-3">
          <div className="text-xs font-bold text-slate-300 border-b border-slate-800 pb-2">
            组合 Key Rate Duration (KRD) 向量暴露分布
          </div>
          <div className="h-72 w-full">
            <ReactECharts option={getEChartsOption()} style={{ height: '100%', width: '100%' }} />
          </div>

          <div className="overflow-x-auto pt-2 border-t border-slate-800">
            <table className="w-full text-center text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 bg-slate-950">
                  <th className="p-1.5 text-left">关键期限 (Tenor)</th>
                  {keyTenors.map((t) => (
                    <th key={t} className="p-1.5 text-amber-400 font-bold">{t}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="p-1.5 text-left text-slate-400">KRD 贡献 (年)</td>
                  {keyTenors.map((t) => (
                    <td key={t} className="p-1.5 text-slate-100 font-bold font-mono">
                      {(analytics.krdSummary[t] || 0).toFixed(2)}
                    </td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* 右侧关键期限非平行冲击模拟器 (1 Col) */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center space-x-2">
              <Zap className="w-4 h-4 text-amber-500" />
              <h2 className="text-sm font-bold text-slate-200 font-sans">关键期限非平行位移模拟</h2>
            </div>
          </div>

          <p className="text-[11px] text-slate-400 font-sans">
            微调各个关键期限节点的收益率变动 (bp)，定量评估非平行扭曲 (Twist / Butterfly) 对组合的 PnL 影响:
          </p>

          <div className="grid grid-cols-3 gap-2 text-xs">
            {keyTenors.map((t) => (
              <div key={t} className="bg-slate-950 p-2 rounded border border-slate-800 space-y-1">
                <span className="text-slate-400 block font-bold text-[10px]">{t} 节点 (bp):</span>
                <input
                  type="number"
                  value={customKeyShocks[t] || 0}
                  onChange={(e) =>
                    setCustomKeyShocks({ ...customKeyShocks, [t]: Number(e.target.value) })
                  }
                  className="w-full bg-slate-900 border border-slate-700 text-amber-400 text-center font-bold px-1 py-0.5 rounded outline-none"
                />
              </div>
            ))}
          </div>

          {/* 重估估计 PnL 结果 */}
          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
            <span className="text-slate-400 text-xs block">关键期限重估估计 PnL:</span>
            <span
              className={`text-lg font-bold font-mono ${
                estimatedPnL >= 0 ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {estimatedPnL >= 0
                ? `+¥${estimatedPnL.toLocaleString('zh-CN', { maximumFractionDigits: 0 })}`
                : `-¥${Math.abs(estimatedPnL).toLocaleString('zh-CN', { maximumFractionDigits: 0 })}`}
            </span>
            <span className="text-[10px] text-slate-500 block font-sans">
              公式: PnL ≈ - ∑ (MV × KRD_i × Δy_i)
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
