/**
 * 华盛利率终端 - 收益率曲线中心
 * HUASHENG RATES - Yield Curve Analyzer (Bootstrapping, Nelson-Siegel, Zero, Forward & Discount Curves)
 */

import React, { useState } from 'react';
import ReactECharts from 'echarts-for-react';
import { useRatesStore } from '../stores/useRatesStore';
import { CurveInterpolation, KeyTenor } from '../types';
import { buildYieldCurve, analyzeForwardRates } from '../quant/curves';
import { TrendingUp, Layers, Sliders, Info, LineChart, Download } from 'lucide-react';

export const YieldCurveCenter: React.FC = () => {
  const {
    cgbCurve,
    policyBankCurve,
    corpCurve,
    swapCurve,
    selectedCurveType,
    setSelectedCurveType
  } = useRatesStore();

  const [activeCurveTab, setActiveCurveTab] = useState<'YIELD' | 'ZERO' | 'FORWARD' | 'DISCOUNT'>('YIELD');
  const [interpolation, setInterpolation] = useState<CurveInterpolation>('NELSON_SIEGEL');
  const [showHistorical, setShowHistorical] = useState<boolean>(true);

  // 获取当前主视图曲线
  const currentCurve =
    selectedCurveType === 'CGB'
      ? cgbCurve
      : selectedCurveType === 'POLICY_BANK'
      ? policyBankCurve
      : selectedCurveType === 'CORP'
      ? corpCurve
      : swapCurve;

  const points = currentCurve.points;
  const tenors = points.map((p) => p.tenor);

  // 1. 构建 ECharts 配置图表
  const getChartOption = () => {
    let seriesData: any[] = [];

    if (activeCurveTab === 'YIELD') {
      seriesData = [
        {
          name: '当前收益率曲线',
          type: 'line',
          smooth: true,
          data: points.map((p) => p.yield),
          lineStyle: { width: 3, color: '#f59e0b' },
          itemStyle: { color: '#f59e0b' }
        }
      ];

      if (showHistorical) {
        seriesData.push({
          name: '上周曲线',
          type: 'line',
          smooth: true,
          data: points.map((p) => Number((p.yield + 0.05).toFixed(2))),
          lineStyle: { width: 1.5, type: 'dashed', color: '#38bdf8' },
          itemStyle: { color: '#38bdf8' }
        });
        seriesData.push({
          name: '上月曲线',
          type: 'line',
          smooth: true,
          data: points.map((p) => Number((p.yield + 0.12).toFixed(2))),
          lineStyle: { width: 1.5, type: 'dotted', color: '#a855f7' },
          itemStyle: { color: '#a855f7' }
        });
      }
    } else if (activeCurveTab === 'ZERO') {
      seriesData = [
        {
          name: '零息收益率 (Spot Rate)',
          type: 'line',
          smooth: true,
          data: points.map((p) => p.zeroRate),
          lineStyle: { width: 3, color: '#38bdf8' },
          itemStyle: { color: '#38bdf8' }
        },
        {
          name: '即期到期收益率 (Par Yield)',
          type: 'line',
          smooth: true,
          data: points.map((p) => p.yield),
          lineStyle: { width: 1.5, type: 'dashed', color: '#f59e0b' },
          itemStyle: { color: '#f59e0b' }
        }
      ];
    } else if (activeCurveTab === 'FORWARD') {
      seriesData = [
        {
          name: '远期利率曲线 (Forward Curve)',
          type: 'line',
          smooth: true,
          data: points.map((p) => p.forwardRate),
          lineStyle: { width: 3, color: '#10b981' },
          itemStyle: { color: '#10b981' }
        },
        {
          name: '零息收益率曲线',
          type: 'line',
          smooth: true,
          data: points.map((p) => p.zeroRate),
          lineStyle: { width: 1.5, type: 'dashed', color: '#38bdf8' },
          itemStyle: { color: '#38bdf8' }
        }
      ];
    } else {
      seriesData = [
        {
          name: '折现因子曲线 (Discount Factor)',
          type: 'line',
          smooth: true,
          data: points.map((p) => p.discountFactor),
          lineStyle: { width: 3, color: '#ec4899' },
          itemStyle: { color: '#ec4899' }
        }
      ];
    }

    return {
      backgroundColor: 'transparent',
      tooltip: {
        trigger: 'axis',
        backgroundColor: '#0f172a',
        borderColor: '#334155',
        textStyle: { color: '#f8fafc', fontSize: 12 },
        axisPointer: { type: 'cross', crossStyle: { color: '#94a3b8' } }
      },
      legend: {
        textStyle: { color: '#94a3b8', fontSize: 11 },
        top: 10
      },
      grid: {
        left: '4%',
        right: '4%',
        bottom: '8%',
        top: '18%',
        containLabel: true
      },
      xAxis: {
        type: 'category',
        data: tenors,
        axisLine: { lineStyle: { color: '#334155' } },
        axisLabel: { color: '#94a3b8', fontSize: 11 }
      },
      yAxis: {
        type: 'value',
        scale: true,
        axisLine: { lineStyle: { color: '#334155' } },
        splitLine: { lineStyle: { color: '#1e293b' } },
        axisLabel: {
          color: '#94a3b8',
          fontSize: 11,
          formatter: activeCurveTab === 'DISCOUNT' ? '{value}' : '{value}%'
        }
      },
      series: seriesData
    };
  };

  const forwardMatrix = analyzeForwardRates(currentCurve);

  return (
    <div className="p-4 space-y-4 font-mono text-slate-100 select-none">
      {/* 控制顶栏 */}
      <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg flex flex-wrap items-center justify-between gap-3">
        {/* 左侧：曲线类型选择 */}
        <div className="flex items-center space-x-2">
          <span className="text-slate-400 text-xs font-semibold">曲线品种:</span>
          {[
            { id: 'CGB', label: '中国国债曲线' },
            { id: 'POLICY_BANK', label: '政金债曲线' },
            { id: 'CORP', label: 'AAA企业债曲线' },
            { id: 'SWAP', label: 'FR007互换曲线' }
          ].map((c) => (
            <button
              key={c.id}
              onClick={() => setSelectedCurveType(c.id as any)}
              className={`px-3 py-1.5 rounded text-xs transition-colors font-sans ${
                selectedCurveType === c.id
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-sm'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>

        {/* 中间：构建拟合算法选择 */}
        <div className="flex items-center space-x-2 text-xs">
          <span className="text-slate-400 font-semibold">插值构建引擎:</span>
          <select
            value={interpolation}
            onChange={(e) => setInterpolation(e.target.value as any)}
            className="bg-slate-950 border border-slate-700 text-amber-400 px-2 py-1 rounded outline-none font-mono"
          >
            <option value="NELSON_SIEGEL">Nelson-Siegel 模型</option>
            <option value="NELSON_SIEGEL_SVENSSON">Nelson-Siegel-Svensson (NSS)</option>
            <option value="BOOTSTRAP">Bootstrapping (引导剥离法)</option>
            <option value="CUBIC_SPLINE">Cubic Spline (三次样条)</option>
            <option value="LINEAR">Linear (线性插值)</option>
          </select>
        </div>

        {/* 右侧：历史对比开关 */}
        <div className="flex items-center space-x-3 text-xs">
          <label className="flex items-center space-x-1.5 cursor-pointer text-slate-300">
            <input
              type="checkbox"
              checked={showHistorical}
              onChange={(e) => setShowHistorical(e.target.checked)}
              className="accent-amber-500 rounded"
            />
            <span>叠加历史曲线 (上周/上月)</span>
          </label>
        </div>
      </div>

      {/* 核心面板：图表区 (2/3) + 形态指标与远期矩阵 (1/3) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* 左侧图表区 (2 Cols) */}
        <div className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-3">
          {/* 子 Tab: 到期曲线 / 零息曲线 / 远期曲线 / 折现因子 */}
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex space-x-2">
              {[
                { id: 'YIELD', label: '收益率曲线 (Yield Curve)' },
                { id: 'ZERO', label: '零息曲线 (Zero Curve)' },
                { id: 'FORWARD', label: '远期曲线 (Forward Curve)' },
                { id: 'DISCOUNT', label: '折现因子 (Discount Factor)' }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveCurveTab(tab.id as any)}
                  className={`px-3 py-1.5 rounded text-xs font-semibold transition-colors ${
                    activeCurveTab === tab.id
                      ? 'bg-slate-800 text-amber-400 border border-slate-700'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* ECharts 绘制 */}
          <div className="h-80 w-full">
            <ReactECharts option={getChartOption()} style={{ height: '100%', width: '100%' }} />
          </div>

          {/* 曲线各期限点明细数据表 */}
          <div className="overflow-x-auto pt-2 border-t border-slate-800">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 bg-slate-950/60">
                  <th className="p-1.5">期限 (Tenor)</th>
                  {points.map((p) => (
                    <th key={p.tenor} className="p-1.5 text-center font-bold text-amber-400">
                      {p.tenor}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-slate-800/40">
                  <td className="p-1.5 text-slate-400">到期收益率 (%)</td>
                  {points.map((p) => (
                    <td key={p.tenor} className="p-1.5 text-center text-slate-200 font-bold">
                      {p.yield.toFixed(2)}
                    </td>
                  ))}
                </tr>
                <tr className="border-b border-slate-800/40">
                  <td className="p-1.5 text-slate-400">零息收益率 (%)</td>
                  {points.map((p) => (
                    <td key={p.tenor} className="p-1.5 text-center text-cyan-400">
                      {p.zeroRate.toFixed(2)}
                    </td>
                  ))}
                </tr>
                <tr className="border-b border-slate-800/40">
                  <td className="p-1.5 text-slate-400">远期利率 (%)</td>
                  {points.map((p) => (
                    <td key={p.tenor} className="p-1.5 text-center text-emerald-400">
                      {p.forwardRate.toFixed(2)}
                    </td>
                  ))}
                </tr>
                <tr>
                  <td className="p-1.5 text-slate-400">折现因子</td>
                  {points.map((p) => (
                    <td key={p.tenor} className="p-1.5 text-center text-pink-400">
                      {p.discountFactor.toFixed(4)}
                    </td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* 右侧：形态分析与关键远期结构 (1 Col) */}
        <div className="space-y-4">
          {/* 曲线形态描述性统计 */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div className="flex items-center space-x-2">
                <Sliders className="w-4 h-4 text-amber-500" />
                <h2 className="text-sm font-bold text-slate-200 font-sans">曲线形态与关键利差</h2>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="bg-slate-950 p-2 rounded border border-slate-800">
                <span className="text-slate-400 block text-[11px]">10Y-2Y 期限利差:</span>
                <span className="text-amber-400 font-bold text-base">{currentCurve.slope10Y2Y} bp</span>
              </div>
              <div className="bg-slate-950 p-2 rounded border border-slate-800">
                <span className="text-slate-400 block text-[11px]">30Y-10Y 期限利差:</span>
                <span className="text-slate-200 font-bold text-base">{currentCurve.slope30Y10Y} bp</span>
              </div>
              <div className="bg-slate-950 p-2 rounded border border-slate-800">
                <span className="text-slate-400 block text-[11px]">5Y-2Y 期限利差:</span>
                <span className="text-slate-200 font-bold text-base">{currentCurve.slope5Y2Y} bp</span>
              </div>
              <div className="bg-slate-950 p-2 rounded border border-slate-800">
                <span className="text-slate-400 block text-[11px]">曲率 (2*5Y-2Y-10Y):</span>
                <span className="text-cyan-400 font-bold text-base">{currentCurve.curvature} bp</span>
              </div>
            </div>

            <div className="bg-slate-950 p-2 rounded border border-slate-800 text-xs flex items-center justify-between">
              <span className="text-slate-400">当前曲线定性形态:</span>
              <span className="text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                {currentCurve.morphology === 'NORMAL' ? '正常陡峭' : currentCurve.morphology}
              </span>
            </div>

            <div className="text-[10px] text-slate-500 flex items-start space-x-1 font-sans">
              <Info className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />
              <span>
                提示：形态指标仅用于历史统计与情景风险描述，不代表确定性的未来走势预测。
              </span>
            </div>
          </div>

          {/* 关键远期利率矩阵分析器 (Forward Rates) */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h2 className="text-sm font-bold text-slate-200 font-sans">关键远期利率 (Forward Rate)</h2>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 bg-slate-950">
                    <th className="p-1.5">结构</th>
                    <th className="p-1.5 text-right">即期 (%)</th>
                    <th className="p-1.5 text-right">远期 (%)</th>
                    <th className="p-1.5 text-right">远期溢价 (bp)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/40">
                  {forwardMatrix.map((item) => {
                    const prem = Number(((item.forwardRate - item.spotRate) * 100).toFixed(1));
                    return (
                      <tr key={item.label}>
                        <td className="p-1.5 font-bold text-amber-400">{item.label}</td>
                        <td className="p-1.5 text-right text-slate-300">{item.spotRate.toFixed(2)}</td>
                        <td className="p-1.5 text-right text-emerald-400 font-bold">
                          {item.forwardRate.toFixed(2)}
                        </td>
                        <td className="p-1.5 text-right text-slate-400">
                          {prem > 0 ? `+${prem}` : prem}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
