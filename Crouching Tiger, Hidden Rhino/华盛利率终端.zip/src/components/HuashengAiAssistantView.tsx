/**
 * 华盛利率终端 - 华盛利率助手 (智能量化与策略问答中心)
 * HUASHENG RATES - Chinese Natural Language Rates Assistant powered by Gemini
 */

import React, { useState, useRef, useEffect } from 'react';
import { useRatesStore } from '../stores/useRatesStore';
import { Bot, Send, Sparkles, User, FileText, CheckCircle, HelpCircle } from 'lucide-react';

export const HuashengAiAssistantView: React.FC = () => {
  const { chatMessages, sendAiMessage, isAiLoading } = useRatesStore();
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages, isAiLoading]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isAiLoading) return;
    const text = inputText;
    setInputText('');
    sendAiMessage(text);
  };

  const quickPrompts = [
    '分析当前国债收益率曲线形态与 10Y-2Y 期限利差',
    '解构当前投资组合的 DV01 风险与 KRD 关键期限久期暴露',
    '基准利率平移 +25bp 条件下，组合损益估算与敏感性推导',
    '解释 Newton-Raphson 求解债券到期收益率 (YTM) 的数学公式',
    '阐述 Nelson-Siegel 模型的 β0, β1, β2, τ 拟合含义'
  ];

  return (
    <div className="p-4 space-y-4 font-mono text-slate-100 select-none max-w-5xl mx-auto">
      {/* 顶部助手 Header Banner */}
      <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="bg-amber-500 text-slate-950 p-2 rounded-lg font-bold">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-100 font-sans flex items-center space-x-2">
              <span>华盛利率助手 (HUASHENG RATES AI)</span>
              <span className="bg-amber-500/10 text-amber-400 border border-amber-500/30 text-[10px] px-1.5 py-0.5 rounded font-mono">
                Gemini 3.8 Flash Powered
              </span>
            </h2>
            <p className="text-xs text-slate-400 font-sans">
              面向机构用户的固定收益量化、曲线诊断、衍生品定价与公式推演智能助手
            </p>
          </div>
        </div>
      </div>

      {/* 快捷问题选项 */}
      <div className="flex flex-wrap gap-2 text-xs">
        {quickPrompts.map((p) => (
          <button
            key={p}
            onClick={() => {
              if (!isAiLoading) sendAiMessage(p);
            }}
            className="bg-slate-900 hover:bg-slate-800 text-amber-400 border border-slate-800 hover:border-amber-500/40 px-2.5 py-1.5 rounded transition-colors text-left flex items-center space-x-1 font-sans text-[11px]"
          >
            <Sparkles className="w-3 h-3 text-amber-500" />
            <span>{p}</span>
          </button>
        ))}
      </div>

      {/* 聊天对话区域 */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 space-y-4 min-h-[400px] max-h-[550px] overflow-y-auto">
        {chatMessages.map((msg) => {
          const isAssistant = msg.sender === 'ASSISTANT';
          return (
            <div
              key={msg.id}
              className={`flex items-start space-x-3 ${isAssistant ? '' : 'flex-row-reverse space-x-reverse'}`}
            >
              <div
                className={`p-2 rounded-full shrink-0 ${
                  isAssistant ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-200'
                }`}
              >
                {isAssistant ? <Bot className="w-4 h-4" /> : <User className="w-4 h-4" />}
              </div>

              <div
                className={`max-w-3xl space-y-1.5 text-xs font-sans p-3 rounded-lg border ${
                  isAssistant
                    ? 'bg-slate-950 border-slate-800 text-slate-200'
                    : 'bg-amber-500/10 border-amber-500/30 text-amber-200 font-mono'
                }`}
              >
                <div className="flex items-center justify-between text-[10px] text-slate-500 border-b border-slate-800/80 pb-1 font-mono">
                  <span>{isAssistant ? '华盛利率助手' : '研究员/交易员'}</span>
                  <span>{msg.timestamp}</span>
                </div>

                <div className="whitespace-pre-wrap leading-relaxed font-sans">{msg.text}</div>

                {msg.citation && (
                  <div className="pt-2 border-t border-slate-800/80 text-[10px] text-slate-500 font-mono flex items-center space-x-1">
                    <FileText className="w-3 h-3 text-amber-500" />
                    <span>{msg.citation}</span>
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {isAiLoading && (
          <div className="flex items-center space-x-2 text-xs text-amber-400 font-mono py-2">
            <Bot className="w-4 h-4 animate-spin text-amber-500" />
            <span>华盛量化引擎正在实时计算、拟合曲线并生成定量解释...</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* 底部输入框 */}
      <form onSubmit={handleSend} className="bg-slate-900 border border-slate-800 p-2 rounded-lg flex items-center space-x-2">
        <input
          type="text"
          placeholder="请输入固定收益与利率相关问答 (例: 帮我推导有效久期和修正久期的差异)..."
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          disabled={isAiLoading}
          className="flex-1 bg-slate-950 text-slate-100 placeholder-slate-500 px-3 py-2 rounded text-xs outline-none border border-slate-800 focus:border-amber-500 font-sans"
        />
        <button
          type="submit"
          disabled={isAiLoading || !inputText.trim()}
          className="bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-slate-950 font-bold px-4 py-2 rounded text-xs flex items-center space-x-1 transition-colors shrink-0 font-mono"
        >
          <Send className="w-3.5 h-3.5" />
          <span>发送查询</span>
        </button>
      </form>
    </div>
  );
};
