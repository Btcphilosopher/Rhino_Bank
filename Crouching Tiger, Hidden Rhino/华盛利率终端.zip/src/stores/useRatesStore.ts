/**
 * 华盛利率终端 - 终端全局状态管理器
 * HUASHENG RATES - Zustand Terminal Global State Manager
 */

import { create } from 'zustand';
import {
  Bond,
  CurveShockParameters,
  KeyTenor,
  MarketTickerQuote,
  PortfolioPosition,
  ResearchNote,
  YieldCurveData
} from '../types';
import {
  INITIAL_CGB_RATES,
  INITIAL_CORP_AAA_RATES,
  INITIAL_POLICY_BANK_RATES,
  INITIAL_SWAP_RATES,
  MOCK_BONDS,
  MOCK_MARKET_QUOTES,
  MOCK_PORTFOLIO_POSITIONS
} from '../data/mockMarketData';
import { buildYieldCurve } from '../quant/curves';
import { calculatePortfolioAnalytics } from '../quant/portfolio';

export interface ChatMessage {
  id: string;
  sender: 'USER' | 'ASSISTANT';
  text: string;
  timestamp: string;
  citation?: string;
  structuredData?: any;
}

interface RatesState {
  // 1. 界面导航状态
  activeTab: number;
  setActiveTab: (tab: number) => void;
  isSearchModalOpen: boolean;
  setSearchModalOpen: (open: boolean) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;

  // 2. 市场数据与曲线
  quotes: MarketTickerQuote[];
  cgbCurve: YieldCurveData;
  policyBankCurve: YieldCurveData;
  corpCurve: YieldCurveData;
  swapCurve: YieldCurveData;
  selectedCurveType: 'CGB' | 'POLICY_BANK' | 'CORP' | 'SWAP';
  setSelectedCurveType: (type: 'CGB' | 'POLICY_BANK' | 'CORP' | 'SWAP') => void;

  // 3. 市场模拟器状态
  isSimulatorRunning: boolean;
  toggleSimulator: () => void;
  resetSimulator: () => void;
  updateTickCount: number;

  // 4. 债券与组合
  bondsList: Bond[];
  selectedBond: Bond;
  setSelectedBond: (bond: Bond) => void;
  portfolioPositions: PortfolioPosition[];
  addPosition: (bond: Bond, quantity: number, costPrice: number) => void;
  removePosition: (posId: string) => void;
  updatePositionQuantity: (posId: string, quantity: number) => void;

  // 5. 冲击与情景参数
  shockParams: CurveShockParameters;
  setShockParams: (params: CurveShockParameters) => void;

  // 6. 研究笔记
  researchNotes: ResearchNote[];
  addResearchNote: (note: Omit<ResearchNote, 'id' | 'createdAt'>) => void;

  // 7. 华盛利率助手 AI 问答
  chatMessages: ChatMessage[];
  isAiLoading: boolean;
  sendAiMessage: (promptText: string) => Promise<void>;
}

export const useRatesStore = create<RatesState>((set, get) => {
  // 初始构造曲线
  const cgbCurve = buildYieldCurve('CGB', '中国国债收益率曲线', INITIAL_CGB_RATES);
  const policyBankCurve = buildYieldCurve('POLICY_BANK', '政策性金融债收益率曲线', INITIAL_POLICY_BANK_RATES);
  const corpCurve = buildYieldCurve('CORP', 'AAA企业债收益率曲线', INITIAL_CORP_AAA_RATES);
  const swapCurve = buildYieldCurve('SWAP', 'FR007利率互换曲线', INITIAL_SWAP_RATES);

  return {
    activeTab: 0,
    setActiveTab: (tab) => set({ activeTab: tab }),
    isSearchModalOpen: false,
    setSearchModalOpen: (open) => set({ isSearchModalOpen: open }),
    searchQuery: '',
    setSearchQuery: (query) => set({ searchQuery: query }),

    quotes: MOCK_MARKET_QUOTES,
    cgbCurve,
    policyBankCurve,
    corpCurve,
    swapCurve,
    selectedCurveType: 'CGB',
    setSelectedCurveType: (type) => set({ selectedCurveType: type }),

    isSimulatorRunning: true,
    updateTickCount: 0,
    toggleSimulator: () => set((state) => ({ isSimulatorRunning: !state.isSimulatorRunning })),
    resetSimulator: () => {
      set({
        cgbCurve: buildYieldCurve('CGB', '中国国债收益率曲线', INITIAL_CGB_RATES),
        policyBankCurve: buildYieldCurve('POLICY_BANK', '政策性金融债收益率曲线', INITIAL_POLICY_BANK_RATES),
        corpCurve: buildYieldCurve('CORP', 'AAA企业债收益率曲线', INITIAL_CORP_AAA_RATES),
        swapCurve: buildYieldCurve('SWAP', 'FR007利率互换曲线', INITIAL_SWAP_RATES),
        quotes: MOCK_MARKET_QUOTES,
        updateTickCount: 0
      });
    },

    bondsList: MOCK_BONDS,
    selectedBond: MOCK_BONDS[0],
    setSelectedBond: (bond) => set({ selectedBond: bond }),
    portfolioPositions: MOCK_PORTFOLIO_POSITIONS,

    addPosition: (bond, quantity, costPrice) => {
      const newPos: PortfolioPosition = {
        id: `pos-${Date.now()}`,
        bond,
        quantity,
        costPrice,
        currentPrice: bond.price,
        marketValue: bond.price * quantity * 100,
        weightPct: 0
      };
      set((state) => ({
        portfolioPositions: [...state.portfolioPositions, newPos]
      }));
    },

    removePosition: (posId) => {
      set((state) => ({
        portfolioPositions: state.portfolioPositions.filter((p) => p.id !== posId)
      }));
    },

    updatePositionQuantity: (posId, quantity) => {
      set((state) => ({
        portfolioPositions: state.portfolioPositions.map((p) =>
          p.id === posId ? { ...p, quantity } : p
        )
      }));
    },

    shockParams: {
      type: 'PARALLEL',
      parallelShiftBp: 25
    },
    setShockParams: (params) => set({ shockParams: params }),

    researchNotes: [
      {
        id: 'note-1',
        title: '关于2026年Q3收益率曲线陡峭化策略的定量分析',
        author: '高级研究员01',
        createdAt: '2026-09-15 14:30',
        tags: ['收益率曲线', '陡峭化', '久期控制'],
        content: '定量显示10Y-2Y利差处于历史35%分位数，随着短期流动性维持宽松，长端供给压力增加，建议构建短端多头与长端空头的曲线陡峭化对冲组合。'
      }
    ],

    addResearchNote: (note) =>
      set((state) => ({
        researchNotes: [
          {
            ...note,
            id: `note-${Date.now()}`,
            createdAt: new Date().toLocaleString('zh-CN')
          },
          ...state.researchNotes
        ]
      })),

    chatMessages: [
      {
        id: 'welcome-msg',
        sender: 'ASSISTANT',
        text: '您好，我是「华盛利率助手」——您的智能固定收益与量化分析助手。我可以帮助您进行收益率曲线分析、债券定价诊断、组合DV01归因、曲线冲击模拟及VaR风险解释。请告诉我您想分析什么？',
        timestamp: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })
      }
    ],
    isAiLoading: false,

    sendAiMessage: async (promptText) => {
      const userMsg: ChatMessage = {
        id: `msg-user-${Date.now()}`,
        sender: 'USER',
        text: promptText,
        timestamp: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })
      };

      set((state) => ({
        chatMessages: [...state.chatMessages, userMsg],
        isAiLoading: true
      }));

      try {
        const response = await fetch('/api/assistant', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            prompt: promptText,
            context: {
              cgbYield10Y: get().cgbCurve.points.find(p => p.tenor === '10Y')?.yield,
              cgbYield2Y: get().cgbCurve.points.find(p => p.tenor === '2Y')?.yield,
              slope10Y2Y: get().cgbCurve.slope10Y2Y,
              selectedBond: get().selectedBond.name,
              selectedBondYtm: get().selectedBond.yield
            }
          })
        });

        const data = await response.json();

        const assistantMsg: ChatMessage = {
          id: `msg-assistant-${Date.now()}`,
          sender: 'ASSISTANT',
          text: data.reply || '分析完成。已为您整理数据与公式引用。',
          timestamp: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' }),
          citation: data.citation || '数据来源: 华盛利率终端量化引擎 v1.0 | 算法: Newton-Raphson & Nelson-Siegel',
          structuredData: data.structuredData
        };

        set((state) => ({
          chatMessages: [...state.chatMessages, assistantMsg],
          isAiLoading: false
        }));
      } catch (err) {
        const errorMsg: ChatMessage = {
          id: `msg-error-${Date.now()}`,
          sender: 'ASSISTANT',
          text: '系统处理请求时发生错误，请稍后重试或检查接口服务。',
          timestamp: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })
        };
        set((state) => ({
          chatMessages: [...state.chatMessages, errorMsg],
          isAiLoading: false
        }));
      }
    }
  };
});
