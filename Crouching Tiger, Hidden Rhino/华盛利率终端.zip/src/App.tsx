/**
 * 华盛利率终端 - 应用程序主视图
 * HUASHENG RATES - Terminal Main Application Core
 */

import React, { useEffect } from 'react';
import { useRatesStore } from './stores/useRatesStore';
import { Header } from './components/Header';
import { Navbar } from './components/Navbar';
import { SearchModal } from './components/SearchModal';

// 14 个核心功能视图模块
import { MarketOverview } from './components/MarketOverview';
import { YieldCurveCenter } from './components/YieldCurveCenter';
import { BondAnalyzer } from './components/BondAnalyzer';
import { PortfolioAnalyticsView } from './components/PortfolioAnalyticsView';
import { KeyRateDurationView } from './components/KeyRateDurationView';
import { ScenarioLabView } from './components/ScenarioLabView';
import { HistoricalAndPCAView } from './components/HistoricalAndPCAView';
import { DerivativesView } from './components/DerivativesView';
import { RateModelsLabView } from './components/RateModelsLabView';
import { RiskVaRView } from './components/RiskVaRView';
import { RelativeValueView } from './components/RelativeValueView';
import { BondScreenerView } from './components/BondScreenerView';
import { ResearchWorkbenchView } from './components/ResearchWorkbenchView';
import { HuashengAiAssistantView } from './components/HuashengAiAssistantView';

export function App() {
  const { activeTab, isSimulatorRunning } = useRatesStore();

  // 定时刷新触发模拟行情脉冲 (若运行中)
  useEffect(() => {
    if (!isSimulatorRunning) return;

    const interval = setInterval(() => {
      // 触发展示更新脉冲
      useRatesStore.setState((state) => ({
        updateTickCount: state.updateTickCount + 1
      }));
    }, 3000);

    return () => clearInterval(interval);
  }, [isSimulatorRunning]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans antialiased selection:bg-amber-500 selection:text-slate-950">
      {/* 终端顶部 Header */}
      <Header />

      {/* 终端主导航 Navbar */}
      <Navbar />

      {/* 终端主内容区域 */}
      <main className="flex-1 overflow-y-auto bg-slate-950">
        {activeTab === 0 && <MarketOverview />}
        {activeTab === 1 && <YieldCurveCenter />}
        {activeTab === 2 && <BondAnalyzer />}
        {activeTab === 3 && <PortfolioAnalyticsView />}
        {activeTab === 4 && <KeyRateDurationView />}
        {activeTab === 5 && <ScenarioLabView />}
        {activeTab === 6 && <HistoricalAndPCAView />}
        {activeTab === 7 && <DerivativesView />}
        {activeTab === 8 && <RateModelsLabView />}
        {activeTab === 9 && <RiskVaRView />}
        {activeTab === 10 && <RelativeValueView />}
        {activeTab === 11 && <BondScreenerView />}
        {activeTab === 12 && <ResearchWorkbenchView />}
        {activeTab === 13 && <HuashengAiAssistantView />}
      </main>

      {/* 全局键盘 Command Palette Search Modal */}
      <SearchModal />
    </div>
  );
}

export default App;
