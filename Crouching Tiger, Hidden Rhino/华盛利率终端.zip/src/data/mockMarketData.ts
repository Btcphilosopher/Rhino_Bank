/**
 * 华盛利率终端 - 模拟市场数据库与历史数据源
 * HUASHENG RATES - Mock Institutional Chinese Market Dataset (Bonds, Curves, Futures, Historicals)
 */

import { Bond, KeyTenor, MarketTickerQuote, PortfolioPosition, YieldCurveData } from '../types';
import { buildYieldCurve } from '../quant/curves';

// 基础利率曲线基准点 (%)
export const INITIAL_CGB_RATES: Record<KeyTenor, number> = {
  '1M': 1.45,
  '3M': 1.52,
  '6M': 1.60,
  '1Y': 1.68,
  '2Y': 1.76,
  '3Y': 1.84,
  '5Y': 1.95,
  '7Y': 2.08,
  '10Y': 2.16,
  '15Y': 2.32,
  '20Y': 2.42,
  '30Y': 2.48,
};

export const INITIAL_POLICY_BANK_RATES: Record<KeyTenor, number> = {
  '1M': 1.62,
  '3M': 1.70,
  '6M': 1.78,
  '1Y': 1.86,
  '2Y': 1.96,
  '3Y': 2.05,
  '5Y': 2.18,
  '7Y': 2.29,
  '10Y': 2.35,
  '15Y': 2.50,
  '20Y': 2.62,
  '30Y': 2.70,
};

export const INITIAL_CORP_AAA_RATES: Record<KeyTenor, number> = {
  '1M': 1.95,
  '3M': 2.05,
  '6M': 2.15,
  '1Y': 2.25,
  '2Y': 2.40,
  '3Y': 2.52,
  '5Y': 2.72,
  '7Y': 2.88,
  '10Y': 2.98,
  '15Y': 3.18,
  '20Y': 3.30,
  '30Y': 3.42,
};

export const INITIAL_SWAP_RATES: Record<KeyTenor, number> = {
  '1M': 1.72,
  '3M': 1.80,
  '6M': 1.88,
  '1Y': 1.95,
  '2Y': 2.02,
  '3Y': 2.10,
  '5Y': 2.20,
  '7Y': 2.30,
  '10Y': 2.38,
  '15Y': 2.52,
  '20Y': 2.65,
  '30Y': 2.75,
};

// 预置机构债券列表
export const MOCK_BONDS: Bond[] = [
  {
    id: 'bond-240010',
    code: '240010.IB',
    name: '24附息国债10',
    type: 'FIXED',
    issuer: '中华人民共和国财政部',
    issuerType: 'CGB',
    rating: 'AAA',
    sector: '国债',
    issueDate: '2024-05-20',
    maturityDate: '2034-05-20',
    couponRate: 2.18,
    faceValue: 100,
    frequency: 2,
    dayCount: 'ACT/ACT',
    price: 100.18,
    yield: 2.16,
    outstandingAmount: 1350
  },
  {
    id: 'bond-240004',
    code: '240004.IB',
    name: '24附息国债04',
    type: 'FIXED',
    issuer: '中华人民共和国财政部',
    issuerType: 'CGB',
    rating: 'AAA',
    sector: '国债',
    issueDate: '2024-02-25',
    maturityDate: '2029-02-25',
    couponRate: 2.05,
    faceValue: 100,
    price: 100.48,
    yield: 1.95,
    frequency: 2,
    dayCount: 'ACT/ACT',
    outstandingAmount: 1200
  },
  {
    id: 'bond-2400001',
    code: '2400001.IB',
    name: '24特国01 (超长期)',
    type: 'FIXED',
    issuer: '中华人民共和国财政部',
    issuerType: 'CGB',
    rating: 'AAA',
    sector: '国债',
    issueDate: '2024-05-17',
    maturityDate: '2054-05-17',
    couponRate: 2.57,
    faceValue: 100,
    price: 101.85,
    yield: 2.48,
    frequency: 2,
    dayCount: 'ACT/ACT',
    outstandingAmount: 2000
  },
  {
    id: 'bond-240210',
    code: '240210.IB',
    name: '24国开10',
    type: 'FIXED',
    issuer: '国家开发银行',
    issuerType: 'POLICY_BANK',
    rating: 'AAA',
    sector: '政金债',
    issueDate: '2024-04-12',
    maturityDate: '2034-04-12',
    couponRate: 2.38,
    faceValue: 100,
    price: 100.25,
    yield: 2.35,
    frequency: 2,
    dayCount: 'ACT/ACT',
    outstandingAmount: 1800
  },
  {
    id: 'bond-240305',
    code: '240305.IB',
    name: '24进出05',
    type: 'FIXED',
    issuer: '中国进出口银行',
    issuerType: 'POLICY_BANK',
    rating: 'AAA',
    sector: '政金债',
    issueDate: '2024-03-08',
    maturityDate: '2029-03-08',
    couponRate: 2.25,
    faceValue: 100,
    price: 100.32,
    yield: 2.18,
    frequency: 2,
    dayCount: 'ACT/ACT',
    outstandingAmount: 950
  },
  {
    id: 'bond-2428001',
    code: '2428001.IB',
    name: '24地方债(广东省01)',
    type: 'FIXED',
    issuer: '广东省人民政府',
    issuerType: 'LOCAL_GOVT',
    rating: 'AAA',
    sector: '地方政府债',
    issueDate: '2024-01-15',
    maturityDate: '2031-01-15',
    couponRate: 2.32,
    faceValue: 100,
    price: 100.12,
    yield: 2.30,
    frequency: 1,
    dayCount: 'ACT/365',
    outstandingAmount: 300
  },
  {
    id: 'bond-2400018',
    code: '2400018.IB',
    name: '24电网MTN001',
    type: 'FIXED',
    issuer: '国家电网有限公司',
    issuerType: 'CORP',
    rating: 'AAA',
    sector: '产业债',
    issueDate: '2024-02-10',
    maturityDate: '2027-02-10',
    couponRate: 2.65,
    faceValue: 100,
    price: 100.38,
    yield: 2.52,
    frequency: 1,
    dayCount: 'ACT/365',
    outstandingAmount: 500
  },
  {
    id: 'bond-2409012',
    code: '2409012.IB',
    name: '24招商银行NCD012',
    type: 'ZERO',
    issuer: '招商银行股份有限公司',
    issuerType: 'NCD',
    rating: 'AAA',
    sector: '同业存单',
    issueDate: '2024-06-01',
    maturityDate: '2025-06-01',
    couponRate: 0,
    faceValue: 100,
    price: 98.15,
    yield: 1.88,
    frequency: 1,
    dayCount: 'ACT/360',
    outstandingAmount: 800
  }
];

// 预置投资组合初始持仓
export const MOCK_PORTFOLIO_POSITIONS: PortfolioPosition[] = [
  {
    id: 'pos-1',
    bond: MOCK_BONDS[0], // 24附息国债10
    quantity: 5000,      // 5000万元面值
    costPrice: 99.85,
    currentPrice: 100.18,
    marketValue: 50090000,
    weightPct: 35.2
  },
  {
    id: 'pos-2',
    bond: MOCK_BONDS[2], // 24特国01 (30Y)
    quantity: 2000,      // 2000万元面值
    costPrice: 100.50,
    currentPrice: 101.85,
    marketValue: 20370000,
    weightPct: 14.3
  },
  {
    id: 'pos-3',
    bond: MOCK_BONDS[3], // 24国开10
    quantity: 4000,      // 4000万元面值
    costPrice: 100.10,
    currentPrice: 100.25,
    marketValue: 40100000,
    weightPct: 28.2
  },
  {
    id: 'pos-4',
    bond: MOCK_BONDS[6], // 24电网MTN001
    quantity: 3000,      // 3000万元面值
    costPrice: 100.20,
    currentPrice: 100.38,
    marketValue: 30114000,
    weightPct: 21.2
  }
];

// 实时行流行行情跑马灯与数据表
export const MOCK_MARKET_QUOTES: MarketTickerQuote[] = [
  { code: 'CGB_10Y', name: '中国国债 10年', category: 'CGB', latestYield: 2.16, change1D: -1.2, change1W: -3.5, change1M: -8.2, changeYTD: -28.5, volumeAmount: 485.2, duration: 8.45, dv01: 8.46, status: 'SIMULATED' },
  { code: 'CGB_30Y', name: '中国国债 30年', category: 'CGB', latestYield: 2.48, change1D: -2.1, change1W: -5.1, change1M: -12.4, changeYTD: -35.0, volumeAmount: 320.8, duration: 19.82, dv01: 20.18, status: 'SIMULATED' },
  { code: 'CGB_2Y', name: '中国国债 2年', category: 'CGB', latestYield: 1.76, change1D: +0.5, change1W: -1.0, change1M: -4.0, changeYTD: -18.2, volumeAmount: 210.5, duration: 1.92, dv01: 1.92, status: 'SIMULATED' },
  { code: 'PDB_10Y', name: '国开债 10年', category: 'POLICY_BANK', latestYield: 2.35, change1D: -1.5, change1W: -4.0, change1M: -9.0, changeYTD: -32.0, volumeAmount: 612.0, duration: 8.28, dv01: 8.30, status: 'SIMULATED' },
  { code: 'CORP_AAA_5Y', name: 'AAA企业债 5年', category: 'CORP', latestYield: 2.72, change1D: -0.8, change1W: -2.8, change1M: -6.5, changeYTD: -22.4, volumeAmount: 185.0, duration: 4.42, dv01: 4.43, status: 'SIMULATED' },
  { code: 'NCD_1Y', name: 'AAA同业存单 1年', category: 'NCD', latestYield: 1.88, change1D: +0.2, change1W: -0.5, change1M: -3.2, changeYTD: -15.5, volumeAmount: 890.0, duration: 0.98, dv01: 0.98, status: 'SIMULATED' },
  { code: 'T2409', name: '10年国债期货 (T2409)', category: 'FUTURES', latestYield: 104.85, change1D: +0.15, change1W: +0.42, change1M: +1.15, changeYTD: +3.20, volumeAmount: 78500, duration: 8.20, dv01: 8.65, status: 'SIMULATED' },
  { code: 'FR007_IRS_5Y', name: 'FR007 互换 5年', category: 'SWAP', latestYield: 2.20, change1D: -1.0, change1W: -2.5, change1M: -7.0, changeYTD: -25.0, volumeAmount: 420.0, duration: 4.65, dv01: 4.66, status: 'SIMULATED' }
];

// 历史收益率时光机数据 (2015 - 2026)
export const TIME_MACHINE_HISTORICAL_CURVES: Record<number, YieldCurveData> = {
  2015: buildYieldCurve('CGB', '2015年国债收益率曲线', { '1M': 3.10, '3M': 3.22, '6M': 3.35, '1Y': 3.42, '2Y': 3.48, '3Y': 3.52, '5Y': 3.58, '7Y': 3.65, '10Y': 3.68, '15Y': 3.82, '20Y': 3.92, '30Y': 4.05 }, 'NELSON_SIEGEL', '2015-12-31'),
  2017: buildYieldCurve('CGB', '2017年国债收益率曲线 (倒挂高位)', { '1M': 3.85, '3M': 3.92, '6M': 3.98, '1Y': 3.95, '2Y': 3.92, '3Y': 3.90, '5Y': 3.91, '7Y': 3.92, '10Y': 3.95, '15Y': 4.10, '20Y': 4.22, '30Y': 4.35 }, 'NELSON_SIEGEL', '2017-12-31'),
  2020: buildYieldCurve('CGB', '2020年国债收益率曲线 (疫情探底与反弹)', { '1M': 1.25, '3M': 1.40, '6M': 1.65, '1Y': 1.85, '2Y': 2.20, '3Y': 2.45, '5Y': 2.70, '7Y': 2.95, '10Y': 3.15, '15Y': 3.45, '20Y': 3.65, '30Y': 3.80 }, 'NELSON_SIEGEL', '2020-12-31'),
  2022: buildYieldCurve('CGB', '2022年国债收益率曲线', { '1M': 1.85, '3M': 1.95, '6M': 2.05, '1Y': 2.15, '2Y': 2.30, '3Y': 2.42, '5Y': 2.58, '7Y': 2.75, '10Y': 2.82, '15Y': 3.05, '20Y': 3.18, '30Y': 3.28 }, 'NELSON_SIEGEL', '2022-12-31'),
  2024: buildYieldCurve('CGB', '2024年国债收益率曲线', { '1M': 1.65, '3M': 1.72, '6M': 1.80, '1Y': 1.88, '2Y': 1.98, '3Y': 2.08, '5Y': 2.22, '7Y': 2.35, '10Y': 2.42, '15Y': 2.58, '20Y': 2.68, '30Y': 2.75 }, 'NELSON_SIEGEL', '2024-12-31'),
  2026: buildYieldCurve('CGB', '2026年最新国债收益率曲线', INITIAL_CGB_RATES, 'NELSON_SIEGEL', '2026-09-17')
};
