/**
 * 华盛利率终端 - 收益率曲线冲击与情景重估引擎
 * HUASHENG RATES - Curve Shock & Scenario Analysis Engine
 */

import { Bond, CurveShockParameters, KeyTenor, ScenarioMatrixItem, ScenarioResult, YieldCurveData } from '../types';
import { calculateFullBondPricing } from './pricing';
import { KEY_TENOR_MAP } from './curves';

/**
 * 对收益率曲线应用冲击参数
 */
export function applyCurveShock(
  curve: YieldCurveData,
  params: CurveShockParameters
): YieldCurveData {
  const shockedPoints = curve.points.map(point => {
    let shiftBp = 0;

    switch (params.type) {
      case 'PARALLEL':
        shiftBp = params.parallelShiftBp || 0;
        break;

      case 'TWIST':
        // 短端与长端反向
        if (point.tenorYears <= 3) shiftBp = params.shortEndShiftBp || 25;
        else if (point.tenorYears >= 10) shiftBp = params.longEndShiftBp || -10;
        else shiftBp = 0;
        break;

      case 'STEEPEN':
        // 熊陡/牛陡: 短端下降或不动，长端上升
        shiftBp = (params.shortEndShiftBp || -10) + (point.tenorYears / 30) * ((params.longEndShiftBp || 20) - (params.shortEndShiftBp || -10));
        break;

      case 'FLATTEN':
        // 熊平/牛平: 短端上升，长端下降
        shiftBp = (params.shortEndShiftBp || 20) + (point.tenorYears / 30) * ((params.longEndShiftBp || -10) - (params.shortEndShiftBp || 20));
        break;

      case 'BUTTERFLY':
        // 蝶式: 中端上升/下降，两端反向
        if (point.tenorYears <= 2) shiftBp = params.shortEndShiftBp || 10;
        else if (point.tenorYears >= 5 && point.tenorYears <= 10) shiftBp = params.midEndShiftBp || -20;
        else shiftBp = params.longEndShiftBp || 10;
        break;

      case 'CUSTOM':
        if (params.customKeyRateShocks && params.customKeyRateShocks[point.tenor]) {
          shiftBp = params.customKeyRateShocks[point.tenor];
        } else {
          shiftBp = params.parallelShiftBp || 0;
        }
        break;
    }

    const newYield = Math.max(0.01, point.yield + shiftBp / 100);
    const newZero = Math.max(0.01, point.zeroRate + shiftBp / 100);
    const newForward = Math.max(0.01, point.forwardRate + shiftBp / 100);
    const newDF = Math.exp((-newZero / 100) * point.tenorYears);

    return {
      ...point,
      yield: Number(newYield.toFixed(4)),
      zeroRate: Number(newZero.toFixed(4)),
      forwardRate: Number(newForward.toFixed(4)),
      discountFactor: Number(newDF.toFixed(6))
    };
  });

  return {
    ...curve,
    id: `${curve.id}-shocked-${Date.now()}`,
    name: `${curve.name} [冲击: ${params.type}]`,
    points: shockedPoints
  };
}

/**
 * 针对持仓组合在收益率曲线冲击下的全量重新定价与 PnL 分析
 */
export function runScenarioPricing(
  bonds: Array<{ bond: Bond; quantity: number }>,
  shockParams: CurveShockParameters,
  settlementDateStr: string = new Date().toISOString().split('T')[0]
): ScenarioResult {
  let originalValue = 0;
  let shockedValue = 0;
  let originalDv01 = 0;
  let shockedDv01 = 0;
  let weightedDurationOriginal = 0;
  let weightedDurationShocked = 0;

  bonds.forEach(({ bond, quantity }) => {
    // 初始定价
    const origPricing = calculateFullBondPricing(bond, settlementDateStr);
    const bondOrigMV = origPricing.dirtyPrice * (quantity * 100); // 面值与张数换算
    originalValue += bondOrigMV;
    originalDv01 += origPricing.dv01 * (quantity * 100);
    weightedDurationOriginal += origPricing.effectiveDuration * bondOrigMV;

    // 冲击后的收益率变动
    let yieldShiftBp = shockParams.parallelShiftBp || 0;
    if (shockParams.type === 'CUSTOM' && shockParams.customKeyRateShocks) {
      // 按近邻关键期限内插 shift bp
      const t = Math.max(1, Math.min(30, (new Date(bond.maturityDate).getFullYear() - new Date().getFullYear())));
      const tenorKey = t <= 1 ? '1Y' : t <= 2 ? '2Y' : t <= 3 ? '3Y' : t <= 5 ? '5Y' : t <= 7 ? '7Y' : t <= 10 ? '10Y' : '30Y';
      yieldShiftBp = shockParams.customKeyRateShocks[tenorKey as KeyTenor] || 0;
    }

    const shockedBond = {
      ...bond,
      yield: Math.max(0.01, bond.yield + yieldShiftBp / 100)
    };

    const shockedPricing = calculateFullBondPricing(shockedBond, settlementDateStr);
    const bondShockedMV = shockedPricing.dirtyPrice * (quantity * 100);
    shockedValue += bondShockedMV;
    shockedDv01 += shockedPricing.dv01 * (quantity * 100);
    weightedDurationShocked += shockedPricing.effectiveDuration * bondShockedMV;
  });

  const pnl = shockedValue - originalValue;
  const pnlPct = originalValue > 0 ? (pnl / originalValue) * 100 : 0;

  return {
    scenarioName: `情景 [${shockParams.type} ${shockParams.parallelShiftBp ? shockParams.parallelShiftBp + 'bp' : ''}]`,
    originalValue: Number(originalValue.toFixed(2)),
    shockedValue: Number(shockedValue.toFixed(2)),
    pnl: Number(pnl.toFixed(2)),
    pnlPct: Number(pnlPct.toFixed(2)),
    originalDv01: Number(originalDv01.toFixed(2)),
    shockedDv01: Number(shockedDv01.toFixed(2)),
    originalDuration: originalValue > 0 ? Number((weightedDurationOriginal / originalValue).toFixed(2)) : 0,
    shockedDuration: shockedValue > 0 ? Number((weightedDurationShocked / shockedValue).toFixed(2)) : 0
  };
}

/**
 * 2D 二维情景分析矩阵 (利率变动 bp x 信用利差变动 bp)
 */
export function generate2DScenarioMatrix(
  bonds: Array<{ bond: Bond; quantity: number }>,
  yieldShiftsBp: number[] = [-50, -25, 0, 25, 50],
  spreadShiftsBp: number[] = [-20, 0, 20]
): ScenarioMatrixItem[] {
  const matrix: ScenarioMatrixItem[] = [];

  let baseMV = 0;
  bonds.forEach(({ bond, quantity }) => {
    const orig = calculateFullBondPricing(bond);
    baseMV += orig.dirtyPrice * (quantity * 100);
  });

  yieldShiftsBp.forEach(yShift => {
    spreadShiftsBp.forEach(sShift => {
      let currentTotalMV = 0;

      bonds.forEach(({ bond, quantity }) => {
        const totalYieldShift = (yShift + sShift) / 100;
        const shockedBond = {
          ...bond,
          yield: Math.max(0.01, bond.yield + totalYieldShift)
        };
        const res = calculateFullBondPricing(shockedBond);
        currentTotalMV += res.dirtyPrice * (quantity * 100);
      });

      const pnl = currentTotalMV - baseMV;
      const pnlPct = baseMV > 0 ? (pnl / baseMV) * 100 : 0;

      matrix.push({
        yieldShiftBp: yShift,
        spreadShiftBp: sShift,
        pnl: Number(pnl.toFixed(2)),
        pnlPct: Number(pnlPct.toFixed(2))
      });
    });
  });

  return matrix;
}
