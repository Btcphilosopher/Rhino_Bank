/**
 * 华盛利率终端 - 衍生品引擎 (利率互换 IRS, 国债期货, 利率期权)
 * HUASHENG RATES - Swaps, Treasury Futures & Options Analytics Engine
 */

import { IRSContract, RateOption, TreasuryFutures } from '../types';

/**
 * 利率互换 (IRS) 定价与风险计算
 */
export function calculateIRSPricing(contract: IRSContract, swapCurveRates: Record<string, number>): IRSContract {
  const currentSwapRate = swapCurveRates[contract.tenor] || contract.fixedRate;
  const notionalAmount = contract.notional * 10000; // 万元 -> 元

  // 定价估算: PV = Notional * (CurrentSwapRate - FixedRate) * ModDuration
  const tenorYears = contract.tenor === '1Y' ? 1 : contract.tenor === '5Y' ? 5 : contract.tenor === '10Y' ? 10 : 3;
  const duration = (1 - Math.exp(-0.02 * tenorYears)) / 0.02;

  const rateDiff = (currentSwapRate - contract.fixedRate) / 100;
  const pv = notionalAmount * rateDiff * duration;
  const dv01 = notionalAmount * duration * 0.0001;

  return {
    ...contract,
    pv: Number(pv.toFixed(2)),
    dv01: Number(dv01.toFixed(2)),
    duration: Number(duration.toFixed(2))
  };
}

/**
 * 国债期货 CTD (Cheapest-to-Deliver) 与基差分析
 */
export function analyzeTreasuryFutures(
  code: string,
  futuresPrice: number,
  deliverableBonds: Array<{ code: string; cleanPrice: number; coupon: number; cf: number }>
): TreasuryFutures {
  let ctd = deliverableBonds[0];
  let minGrossBasis = 999;
  let maxIRR = -999;

  // 计算每一个可交割债的转换因子 (CF), 基差 (Gross Basis) 与 隐含回购利率 (IRR)
  deliverableBonds.forEach(bond => {
    // 毛基差 = 现货净价 - 期货价格 * 转换因子
    const grossBasis = bond.cleanPrice - futuresPrice * bond.cf;
    // 隐含回购利率 (IRR) = (交割价格 + 票息 - 买入全价) / 买入全价 * (365 / 天数)
    const irr = ((futuresPrice * bond.cf - bond.cleanPrice) / bond.cleanPrice) * 100 + bond.coupon;

    if (grossBasis < minGrossBasis) {
      minGrossBasis = grossBasis;
      maxIRR = irr;
      ctd = bond;
    }
  });

  const netBasis = minGrossBasis - 0.12; // 除去持有收益后的净基差
  const dv01 = (futuresPrice * ctd.cf * 0.08) / 100;

  return {
    code,
    name: code.startsWith('T') ? '10年期国债期货主连' : code.startsWith('TF') ? '5年期国债期货主连' : '2年期国债期货主连',
    underlyingMaturity: code.startsWith('T') ? '10Y' : code.startsWith('TF') ? '5Y' : '2Y',
    futuresPrice,
    ctdBondCode: ctd.code,
    conversionFactor: Number(ctd.cf.toFixed(4)),
    impliedRepoRate: Number(maxIRR.toFixed(2)),
    grossBasis: Number(minGrossBasis.toFixed(4)),
    netBasis: Number(netBasis.toFixed(4)),
    dv01: Number(dv01.toFixed(4))
  };
}

/**
 * Black-76 利率期权 (Cap/Floor/Swaption) 定价模型
 */
function erf(x: number): number {
  const a1 = 0.254829592, a2 = -0.284496736, a3 = 1.421413741, a4 = -1.453152027, a5 = 1.061405429, p = 0.3275911;
  const sign = x < 0 ? -1 : 1;
  const absX = Math.abs(x);
  const t = 1.0 / (1.0 + p * absX);
  const y = 1.0 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * Math.exp(-absX * absX);
  return sign * y;
}

export function calculateBlack76RateOption(
  option: Omit<RateOption, 'price' | 'delta' | 'gamma' | 'vega' | 'theta' | 'dv01'>
): RateOption {
  const F = option.underlyingRate / 100; // 标的远期利率
  const K = option.strikeRate / 100;     // 执行利率
  const sigma = option.volatility / 100; // 波动率
  const T = option.timeToMaturityYears;  // 期限
  const N = option.notional * 10000;

  const d1 = (Math.log(F / K) + 0.5 * Math.pow(sigma, 2) * T) / (sigma * Math.sqrt(T));
  const d2 = d1 - sigma * Math.sqrt(T);

  // 标准正态分布累积与密度
  const cdf = (x: number) => 0.5 * (1 + erf(x / Math.sqrt(2)));
  const pdf = (x: number) => (1 / Math.sqrt(2 * Math.PI)) * Math.exp(-0.5 * Math.pow(x, 2));

  let price = 0;
  let delta = 0;

  if (option.type === 'CAP' || option.type === 'SWAPTION') {
    price = N * (F * cdf(d1) - K * cdf(d2));
    delta = cdf(d1);
  } else {
    price = N * (K * cdf(-d2) - F * cdf(-d1));
    delta = -cdf(-d1);
  }

  const gamma = pdf(d1) / (F * sigma * Math.sqrt(T));
  const vega = N * F * pdf(d1) * Math.sqrt(T) / 100;
  const theta = -1 * (N * F * pdf(d1) * sigma) / (2 * Math.sqrt(T));
  const dv01 = delta * N * 0.0001;

  return {
    ...option,
    price: Number(price.toFixed(2)),
    delta: Number(delta.toFixed(4)),
    gamma: Number(gamma.toFixed(6)),
    vega: Number(vega.toFixed(2)),
    theta: Number(theta.toFixed(2)),
    dv01: Number(dv01.toFixed(2)),
    modelUsed: 'Black-76'
  };
}
