/**
 * 华盛利率终端 - 日计数与利息计息规则引擎
 * HUASHENG RATES - Day Count Conventions & Accrual Engine
 */

import { DayCountConvention, PaymentFrequency } from '../types';

/**
 * 计算两个日期之间的天数差与年化比率 (Year Fraction)
 */
export function getYearFraction(
  startDateStr: string,
  endDateStr: string,
  convention: DayCountConvention = 'ACT/365'
): number {
  const start = new Date(startDateStr);
  const end = new Date(endDateStr);

  if (isNaN(start.getTime()) || isNaN(end.getTime())) {
    return 1.0;
  }

  const timeDiffMs = Math.max(0, end.getTime() - start.getTime());
  const actualDays = timeDiffMs / (1000 * 3600 * 24);

  switch (convention) {
    case 'ACT/360':
      return actualDays / 360;
    case '30/360': {
      const d1 = Math.min(start.getDate(), 30);
      const d2 = d1 === 30 ? Math.min(end.getDate(), 30) : end.getDate();
      const m1 = start.getMonth() + 1;
      const m2 = end.getMonth() + 1;
      const y1 = start.getFullYear();
      const y2 = end.getFullYear();
      const days30 = (y2 - y1) * 360 + (m2 - m1) * 30 + (d2 - d1);
      return Math.max(0, days30) / 360;
    }
    case 'ACT/ACT':
    case 'ACT/365':
    default:
      return actualDays / 365.25;
  }
}

/**
 * 计算两个 YYYY-MM-DD 日期之间的实际天数
 */
export function getActualDaysBetween(startDateStr: string, endDateStr: string): number {
  const start = new Date(startDateStr);
  const end = new Date(endDateStr);
  if (isNaN(start.getTime()) || isNaN(end.getTime())) return 0;
  return Math.round(Math.abs(end.getTime() - start.getTime()) / (1000 * 3600 * 24));
}

/**
 * 计算债券应计利息 (Accrued Interest per Face Value)
 */
export function calculateAccruedInterest(
  couponRatePct: number,
  faceValue: number,
  lastCouponDate: string,
  settlementDate: string,
  frequency: PaymentFrequency,
  convention: DayCountConvention
): number {
  const yearFraction = getYearFraction(lastCouponDate, settlementDate, convention);
  const annualCouponAmount = (couponRatePct / 100) * faceValue;
  // 应计利息 = 年票息 * 计息期间年化比例
  return Number((annualCouponAmount * yearFraction).toFixed(4));
}
