/**
 * 华盛利率终端 - 利率模型与蒙特卡洛模拟实验室
 * HUASHENG RATES - Interest Rate Models & Monte Carlo Simulation Engine
 */

import { MonteCarloSimulationResult, ShortRateModelParams } from '../types';

/**
 * 蒙特卡洛利率路径生成器 (Vasicek / CIR / Hull-White)
 */
export function runMonteCarloRateSimulation(
  params: ShortRateModelParams,
  pathsCount: number = 1000,
  horizonDays: number = 365
): MonteCarloSimulationResult {
  const dt = 1 / 365; // 每日步长
  const a = params.meanReversionSpeed;
  const b = params.longTermRate / 100;
  const sigma = params.volatility / 100;
  const r0 = params.initialShortRate / 100;

  const timeSteps: number[] = [];
  for (let day = 0; day <= horizonDays; day += 5) {
    timeSteps.push(day);
  }

  const allPaths: number[][] = [];

  // 伪随机 Box-Muller 正态分布
  const getRandomNormal = () => {
    let u = 0, v = 0;
    while (u === 0) u = Math.random();
    while (v === 0) v = Math.random();
    return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
  };

  // 限制计算上限保障流畅度
  const safePathsCount = Math.min(pathsCount, 5000);

  for (let p = 0; p < safePathsCount; p++) {
    const path: number[] = [r0 * 100];
    let r = r0;

    for (let day = 1; day <= horizonDays; day++) {
      const dW = getRandomNormal() * Math.sqrt(dt);
      let dr = 0;

      if (params.modelType === 'Vasicek') {
        // dr = a*(b - r)*dt + sigma*dW
        dr = a * (b - r) * dt + sigma * dW;
      } else if (params.modelType === 'CIR') {
        // dr = a*(b - r)*dt + sigma*sqrt(r)*dW
        dr = a * (b - r) * dt + sigma * Math.sqrt(Math.max(0.001, r)) * dW;
      } else {
        // Hull-White 随时间变化的漂移项
        dr = a * (b - r) * dt + sigma * dW;
      }

      r = Math.max(0.001, r + dr);

      if (day % 5 === 0) {
        path.push(Number((r * 100).toFixed(4)));
      }
    }
    allPaths.push(path);
  }

  // 统计每个时间步的分位数
  const stepsCount = timeSteps.length;
  const meanPath: number[] = [];
  const medianPath: number[] = [];
  const percentile05: number[] = [];
  const percentile95: number[] = [];

  for (let step = 0; step < stepsCount; step++) {
    const stepValues = allPaths.map(p => p[step]).sort((x, y) => x - y);
    const sum = stepValues.reduce((acc, v) => acc + v, 0);

    meanPath.push(Number((sum / stepValues.length).toFixed(4)));
    medianPath.push(stepValues[Math.floor(stepValues.length * 0.5)]);
    percentile05.push(stepValues[Math.floor(stepValues.length * 0.05)]);
    percentile95.push(stepValues[Math.floor(stepValues.length * 0.95)]);
  }

  // 终点分布 histogram
  const terminalYields = allPaths.map(p => p[p.length - 1]);

  return {
    pathsCount: safePathsCount,
    horizonDays,
    timeSteps,
    meanPath,
    medianPath,
    percentile05,
    percentile95,
    samplePaths: allPaths.slice(0, 15), // 展现15条样本路径
    terminalYieldDistribution: terminalYields
  };
}
