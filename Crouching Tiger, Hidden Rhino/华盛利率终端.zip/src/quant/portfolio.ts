/**
 * 华盛利率终端 - 组合风险与损益归因引擎
 * HUASHENG RATES - Portfolio Analytics, Risk Breakdown, Carry & Roll-Down, P&L Attribution
 */

import { Bond, CarryRollDownResult, KeyTenor, PortfolioAnalytics, PortfolioPosition, PnLAttribution } from '../types';
import { calculateFullBondPricing } from './pricing';

/**
 * 汇总计算组合风险指标与维度拆解
 */
export function calculatePortfolioAnalytics(positions: PortfolioPosition[]): PortfolioAnalytics {
  let totalMarketValue = 0;
  let totalCouponIncome = 0;
  let weightedYield = 0;
  let weightedMacDuration = 0;
  let weightedModDuration = 0;
  let weightedConvexity = 0;
  let totalDv01 = 0;

  const krdSummary: Record<KeyTenor, number> = {
    '1M': 0, '3M': 0, '6M': 0, '1Y': 0, '2Y': 0, '3Y': 0,
    '5Y': 0, '7Y': 0, '10Y': 0, '15Y': 0, '20Y': 0, '30Y': 0
  };

  const byTenorMap: Record<string, { marketValue: number; dv01: number }> = {};
  const bySectorMap: Record<string, { marketValue: number; dv01: number }> = {};
  const byRatingMap: Record<string, { marketValue: number; dv01: number }> = {};
  const byIssuerMap: Record<string, { marketValue: number; dv01: number }> = {};

  // 1. 计算个券定价与聚合
  const posPricingResults = positions.map(pos => {
    const res = calculateFullBondPricing(pos.bond);
    const parAmount = pos.quantity * 10000; // 张数(万元) -> 面值
    const dirtyPrice = res.dirtyPrice;
    const mv = (dirtyPrice / 100) * parAmount;
    const bondDv01 = res.dv01 * (parAmount / 100);

    totalMarketValue += mv;
    totalCouponIncome += (pos.bond.couponRate / 100) * parAmount;
    totalDv01 += bondDv01;

    return { pos, res, mv, bondDv01 };
  });

  // 2. 加权与维度拆解
  posPricingResults.forEach(({ pos, res, mv, bondDv01 }) => {
    const w = totalMarketValue > 0 ? mv / totalMarketValue : 0;
    pos.weightPct = Number((w * 100).toFixed(2));
    pos.marketValue = Number(mv.toFixed(2));

    weightedYield += res.ytm * w;
    weightedMacDuration += res.macaulayDuration * w;
    weightedModDuration += res.modifiedDuration * w;
    weightedConvexity += res.convexity * w;

    // KRD 组合加权
    Object.keys(res.krd).forEach(key => {
      const tenor = key as KeyTenor;
      krdSummary[tenor] += res.krd[tenor] * w;
    });

    // 维度归类
    const tYears = res.macaulayDuration;
    const tenorLabel = tYears <= 3 ? '短端 (0-3Y)' : tYears <= 7 ? '中端 (3-7Y)' : '长端 (7Y+)';

    const sector = pos.bond.sector || '利率债';
    const rating = pos.bond.rating || 'AAA';
    const issuer = pos.bond.issuer || '财政部';

    [
      { map: byTenorMap, key: tenorLabel },
      { map: bySectorMap, key: sector },
      { map: byRatingMap, key: rating },
      { map: byIssuerMap, key: issuer }
    ].forEach(({ map, key }) => {
      if (!map[key]) map[key] = { marketValue: 0, dv01: 0 };
      map[key].marketValue += mv;
      map[key].dv01 += bondDv01;
    });
  });

  // 构建占比字典
  const buildBreakdown = (map: Record<string, { marketValue: number; dv01: number }>) => {
    const result: Record<string, { marketValue: number; dv01: number; pct: number }> = {};
    Object.keys(map).forEach(k => {
      const mv = map[k].marketValue;
      result[k] = {
        marketValue: Number(mv.toFixed(2)),
        dv01: Number(map[k].dv01.toFixed(2)),
        pct: totalMarketValue > 0 ? Number(((mv / totalMarketValue) * 100).toFixed(2)) : 0
      };
    });
    return result;
  };

  return {
    totalMarketValue: Number(totalMarketValue.toFixed(2)),
    totalCouponIncome: Number(totalCouponIncome.toFixed(2)),
    weightedYield: Number(weightedYield.toFixed(4)),
    weightedMacDuration: Number(weightedMacDuration.toFixed(2)),
    weightedModDuration: Number(weightedModDuration.toFixed(2)),
    weightedConvexity: Number(weightedConvexity.toFixed(2)),
    totalDv01: Number(totalDv01.toFixed(2)),
    krdSummary,
    riskBreakdown: {
      byTenor: buildBreakdown(byTenorMap),
      bySector: buildBreakdown(bySectorMap),
      byRating: buildBreakdown(byRatingMap),
      byIssuer: buildBreakdown(byIssuerMap)
    }
  };
}

/**
 * Carry & Roll-Down 分析器
 */
export function calculateCarryRollDown(
  analytics: PortfolioAnalytics,
  holdingDays: number = 30,
  financingRate: number = 1.80 // 跨季/回购融资利率 %
): CarryRollDownResult {
  const mv = analytics.totalMarketValue;
  const holdingYearFrac = holdingDays / 365;

  // 1. 票息 Carry = 预计年票息收入 * (天数 / 365)
  const couponCarry = analytics.totalCouponIncome * holdingYearFrac;

  // 2. 融资成本 = 市值 * 融资利率 * (天数 / 365)
  const financingCost = mv * (financingRate / 100) * holdingYearFrac;

  // 3. 净 Carry = 票息收益 - 融资成本
  const netCarry = couponCarry - financingCost;

  // 4. 滚动下滑收益 (Roll-Down): 债券随着期限变短，收益率下降带来的价格上涨估算
  // RollDown Gain ≈ Portfolio MV * ModDuration * (RollDown Slope ~ 3bp/月)
  const estimatedMonthlySlopeDownBp = 3.5;
  const rollDownGain = mv * (analytics.weightedModDuration) * ((estimatedMonthlySlopeDownBp * (holdingDays / 30)) / 10000);

  // 5. 总预期持有期收益
  const totalExpectedReturn = netCarry + rollDownGain;
  const totalReturnPct = mv > 0 ? (totalExpectedReturn / mv) * (365 / holdingDays) * 100 : 0;

  return {
    holdingDays,
    financingRate,
    couponCarry: Number(couponCarry.toFixed(2)),
    financingCost: Number(financingCost.toFixed(2)),
    netCarry: Number(netCarry.toFixed(2)),
    rollDownGain: Number(rollDownGain.toFixed(2)),
    totalExpectedReturn: Number(totalExpectedReturn.toFixed(2)),
    totalReturnPct: Number(totalReturnPct.toFixed(2))
  };
}

/**
 * 利率 P&L 损益归因分解
 */
export function calculatePnLAttribution(
  initialAnalytics: PortfolioAnalytics,
  currentAnalytics: PortfolioAnalytics,
  holdingDays: number = 30,
  financingRate: number = 1.80
): PnLAttribution {
  const carryRes = calculateCarryRollDown(initialAnalytics, holdingDays, financingRate);

  const couponIncome = carryRes.couponCarry;
  const rollDownReturn = carryRes.rollDownGain;

  // 曲线变动收益 (Yield Curve Movement)
  const yieldShiftBp = (currentAnalytics.weightedYield - initialAnalytics.weightedYield) * 100;
  const curveShiftReturn = -1 * initialAnalytics.totalDv01 * yieldShiftBp;

  // 利差变动收益
  const spreadShiftReturn = -1 * (initialAnalytics.totalDv01 * 0.15) * 5; // 估算 5bp 利差收窄

  // 净价效应残差
  const totalPnL = currentAnalytics.totalMarketValue - initialAnalytics.totalMarketValue + couponIncome;
  const priceEffect = totalPnL - (couponIncome + rollDownReturn + curveShiftReturn + spreadShiftReturn);

  return {
    couponIncome: Number(couponIncome.toFixed(2)),
    rollDownReturn: Number(rollDownReturn.toFixed(2)),
    curveShiftReturn: Number(curveShiftReturn.toFixed(2)),
    spreadShiftReturn: Number(spreadShiftReturn.toFixed(2)),
    priceEffect: Number(priceEffect.toFixed(2)),
    totalPnL: Number(totalPnL.toFixed(2))
  };
}
