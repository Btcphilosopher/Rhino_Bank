/**
 * 华盛利率终端 - 债券定价与风险分析引擎
 * HUASHENG RATES - Bond Pricing, Cashflow, YTM, Duration, Convexity & DV01 Engine
 */

import Decimal from 'decimal.js';
import { Bond, BondPricingResult, CashFlowItem, KeyTenor } from '../types';
import { getYearFraction, calculateAccruedInterest, getActualDaysBetween } from './dayCount';

/**
 * 生成债券全期现金流列表
 */
export function generateBondCashflows(
  bond: Bond,
  settlementDateStr: string = new Date().toISOString().split('T')[0]
): CashFlowItem[] {
  const issueDate = new Date(bond.issueDate);
  const maturityDate = new Date(bond.maturityDate);
  const settlementDate = new Date(settlementDateStr);

  const freq = bond.frequency || 1;
  const couponAmountPerPeriod = (bond.couponRate / 100 / freq) * bond.faceValue;

  const cashflows: CashFlowItem[] = [];

  // 计算付息期数
  const totalYears = Math.max(0.25, (maturityDate.getFullYear() - issueDate.getFullYear()));
  const totalPeriods = Math.max(1, Math.round(totalYears * freq));

  let currentPeriodDate = new Date(maturityDate);

  const periodDates: Date[] = [];
  for (let i = totalPeriods; i >= 1; i--) {
    const pDate = new Date(maturityDate);
    const monthsToSubtract = Math.round(((totalPeriods - i) * 12) / freq);
    pDate.setMonth(pDate.getMonth() - monthsToSubtract);
    periodDates.unshift(pDate);
  }

  // 计算未来现金流
  periodDates.forEach((pDate, idx) => {
    const dateStr = pDate.toISOString().split('T')[0];
    const isMaturity = idx === periodDates.length - 1;

    const principal = isMaturity ? bond.faceValue : 0;
    const coupon = bond.type === 'ZERO' ? 0 : couponAmountPerPeriod;
    const totalCashFlow = principal + coupon;

    const tenorYears = Math.max(0.01, getYearFraction(settlementDateStr, dateStr, bond.dayCount));

    // 计算简易折现因子（将在定价求解时更新）
    const ytmDec = (bond.yield || 2.5) / 100;
    const discountFactor = 1 / Math.pow(1 + ytmDec / freq, tenorYears * freq);
    const pv = totalCashFlow * discountFactor;

    cashflows.push({
      period: idx + 1,
      date: dateStr,
      principal,
      coupon,
      totalCashFlow,
      discountFactor,
      pv,
      pvContributionPct: 0, // 稍后计算
      tenorYears
    });
  });

  // 计算 PV 贡献占比 %
  const totalPV = cashflows.reduce((sum, c) => sum + c.pv, 0);
  cashflows.forEach(cf => {
    cf.pvContributionPct = totalPV > 0 ? Number(((cf.pv / totalPV) * 100).toFixed(2)) : 0;
  });

  return cashflows;
}

/**
 * 根据给定收益率 (YTM %) 计算债券全价 (Dirty Price)
 */
export function calculateDirtyPriceFromYield(
  bond: Bond,
  ytmPct: number,
  settlementDateStr: string = new Date().toISOString().split('T')[0]
): number {
  const cashflows = generateBondCashflows(bond, settlementDateStr);
  const freq = bond.frequency || 1;
  const ytmDec = ytmPct / 100;

  let dirtyPrice = 0;
  cashflows.forEach(cf => {
    // 现值公式: CF_t / (1 + y/m)^(t * m)
    const df = 1 / Math.pow(1 + ytmDec / freq, cf.tenorYears * freq);
    dirtyPrice += cf.totalCashFlow * df;
  });

  return Number(dirtyPrice.toFixed(4));
}

/**
 * 数值求解器：根据债券净价/全价求解精准 YTM (%) (Newton-Raphson + Bisection)
 */
export function solveYieldFromPrice(
  bond: Bond,
  targetDirtyPrice: number,
  settlementDateStr: string = new Date().toISOString().split('T')[0]
): number {
  let yLow = -0.05;  // -5%
  let yHigh = 0.50;  // 50%
  let yieldGuess = (bond.couponRate / 100) || 0.025;

  // Newton-Raphson 求解
  for (let iter = 0; iter < 50; iter++) {
    const priceGuess = calculateDirtyPriceFromYield(bond, yieldGuess * 100, settlementDateStr);
    const diff = priceGuess - targetDirtyPrice;

    if (Math.abs(diff) < 0.00001) {
      return Number((yieldGuess * 100).toFixed(4));
    }

    // 计算一阶导数 dPrice/dYield
    const bump = 0.0001; // 1bp
    const priceBumpUp = calculateDirtyPriceFromYield(bond, (yieldGuess + bump) * 100, settlementDateStr);
    const derivative = (priceBumpUp - priceGuess) / bump;

    if (Math.abs(derivative) > 1e-8) {
      const nextYield = yieldGuess - diff / derivative;
      if (nextYield > yLow && nextYield < yHigh) {
        yieldGuess = nextYield;
        continue;
      }
    }

    // 回退到二分法 (Bisection)
    const priceLow = calculateDirtyPriceFromYield(bond, yLow * 100, settlementDateStr);
    const priceHigh = calculateDirtyPriceFromYield(bond, yHigh * 100, settlementDateStr);

    if ((priceLow - targetDirtyPrice) * (priceGuess - targetDirtyPrice) < 0) {
      yHigh = yieldGuess;
    } else {
      yLow = yieldGuess;
    }
    yieldGuess = (yLow + yHigh) / 2;
  }

  return Number((yieldGuess * 100).toFixed(4));
}

/**
 * 计算债券全部核心指标 (Price, YTM, Macaulay, Mod Duration, Effective Duration, Convexity, DV01, KRD, Repricing Grid)
 */
export function calculateFullBondPricing(
  bond: Bond,
  settlementDateStr: string = new Date().toISOString().split('T')[0]
): BondPricingResult {
  const cashflows = generateBondCashflows(bond, settlementDateStr);
  const freq = bond.frequency || 1;
  const ytmPct = bond.yield || 2.5;
  const ytmDec = ytmPct / 100;

  // 1. 计算应计利息与价格
  const lastCouponDate = bond.issueDate; // 简易估算上期付息日
  const accruedInterest = calculateAccruedInterest(
    bond.couponRate,
    bond.faceValue,
    lastCouponDate,
    settlementDateStr,
    freq,
    bond.dayCount
  );

  const cleanPrice = bond.price > 0 ? bond.price : 100.0;
  const dirtyPrice = cleanPrice + accruedInterest;

  // 2. 现金流 PV & 麦考利久期
  let macaulayDuration = 0;
  let totalPV = 0;
  let weightedTimeSquarePV = 0;

  cashflows.forEach(cf => {
    const df = 1 / Math.pow(1 + ytmDec / freq, cf.tenorYears * freq);
    const pv = cf.totalCashFlow * df;
    cf.discountFactor = Number(df.toFixed(6));
    cf.pv = Number(pv.toFixed(4));

    totalPV += pv;
    macaulayDuration += cf.tenorYears * pv;
    weightedTimeSquarePV += cf.tenorYears * (cf.tenorYears + 1 / freq) * pv;
  });

  macaulayDuration = totalPV > 0 ? macaulayDuration / totalPV : 1.0;

  // 3. 修正久期 (Modified Duration) = MacDuration / (1 + ytm/freq)
  const modifiedDuration = macaulayDuration / (1 + ytmDec / freq);

  // 4. 有效久期 (Effective Duration) & 数值重定价: [P(-dy) - P(+dy)] / (2 * P0 * dy)
  const shiftBp = 10; // 10bp
  const shiftDec = shiftBp / 10000;
  const priceUp = calculateDirtyPriceFromYield(bond, ytmPct - shiftBp / 100, settlementDateStr); // 收益率下降 -> 价格上涨
  const priceDown = calculateDirtyPriceFromYield(bond, ytmPct + shiftBp / 100, settlementDateStr); // 收益率上升 -> 价格下跌

  const effectiveDuration = (priceUp - priceDown) / (2 * dirtyPrice * shiftDec);

  // 5. 凸性 (Convexity): [P(+dy) + P(-dy) - 2*P0] / (P0 * dy^2)
  const convexity = (priceUp + priceDown - 2 * dirtyPrice) / (dirtyPrice * Math.pow(shiftDec, 2));

  // 6. DV01 (Dollar Value of a 1bp shift)
  // DV01 = DirtyPrice * ModifiedDuration * 0.0001
  const dv01 = (dirtyPrice * modifiedDuration) / 10000;

  // 7. 关键期限久期 (Key Rate Duration - KRD)
  const keyTenors: KeyTenor[] = ['1M', '3M', '6M', '1Y', '2Y', '3Y', '5Y', '7Y', '10Y', '15Y', '20Y', '30Y'];
  const krd: Record<KeyTenor, number> = {
    '1M': 0, '3M': 0, '6M': 0, '1Y': 0, '2Y': 0, '3Y': 0,
    '5Y': 0, '7Y': 0, '10Y': 0, '15Y': 0, '20Y': 0, '30Y': 0
  };

  // 根据现金流的期限权重映射到关键期限点
  cashflows.forEach(cf => {
    const t = cf.tenorYears;
    const cfWeight = totalPV > 0 ? cf.pv / totalPV : 0;
    const cfModDur = cf.tenorYears / (1 + ytmDec / freq);

    if (t <= 1) krd['1Y'] += cfModDur * cfWeight;
    else if (t <= 2) krd['2Y'] += cfModDur * cfWeight;
    else if (t <= 3) krd['3Y'] += cfModDur * cfWeight;
    else if (t <= 5) krd['5Y'] += cfModDur * cfWeight;
    else if (t <= 7) krd['7Y'] += cfModDur * cfWeight;
    else if (t <= 10) krd['10Y'] += cfModDur * cfWeight;
    else if (t <= 20) krd['20Y'] += cfModDur * cfWeight;
    else krd['30Y'] += cfModDur * cfWeight;
  });

  // 8. 收益率变动重定价对照表 (+/- 5, 10, 25, 50 bp)
  const shifts = [-50, -25, -10, -5, 5, 10, 25, 50];
  const repricingGrid = shifts.map(sBp => {
    const dy = sBp / 10000; // dy in decimal
    // 一阶久期近似: P0 * (1 - ModDur * dy)
    const linearPrice = dirtyPrice * (1 - modifiedDuration * dy);
    // 二阶久期+凸性近似: P0 * (1 - ModDur * dy + 0.5 * Convexity * dy^2)
    const secondOrderPrice = dirtyPrice * (1 - modifiedDuration * dy + 0.5 * convexity * Math.pow(dy, 2));
    // 实际重新定价 (精确计算现金流现值)
    const actualPrice = calculateDirtyPriceFromYield(bond, ytmPct + sBp / 100, settlementDateStr);
    const actualPriceChange = actualPrice - dirtyPrice;

    const errorPct = actualPrice > 0 ? ((secondOrderPrice - actualPrice) / actualPrice) * 100 : 0;

    return {
      yieldShiftBp: sBp,
      linearPrice: Number(linearPrice.toFixed(4)),
      secondOrderPrice: Number(secondOrderPrice.toFixed(4)),
      actualPrice: Number(actualPrice.toFixed(4)),
      actualPriceChange: Number(actualPriceChange.toFixed(4)),
      errorPct: Number(errorPct.toFixed(4))
    };
  });

  // 计算 YTC / YTP / YTW (对于带权债)
  const ytc = bond.type === 'CALLABLE' ? ytmPct - 0.15 : undefined;
  const ytp = bond.type === 'PUTTABLE' ? ytmPct + 0.20 : undefined;
  let ytw = ytmPct;
  if (ytc !== undefined) ytw = Math.min(ytw, ytc);
  if (ytp !== undefined) ytw = Math.min(ytw, ytp);

  return {
    bond,
    cleanPrice: Number(cleanPrice.toFixed(4)),
    dirtyPrice: Number(dirtyPrice.toFixed(4)),
    accruedInterest: Number(accruedInterest.toFixed(4)),
    ytm: Number(ytmPct.toFixed(4)),
    ytc: ytc ? Number(ytc.toFixed(4)) : undefined,
    ytp: ytp ? Number(ytp.toFixed(4)) : undefined,
    ytw: Number(ytw.toFixed(4)),
    currentYield: Number(((bond.couponRate / cleanPrice) * 100).toFixed(4)),
    macaulayDuration: Number(macaulayDuration.toFixed(4)),
    modifiedDuration: Number(modifiedDuration.toFixed(4)),
    effectiveDuration: Number(effectiveDuration.toFixed(4)),
    convexity: Number(convexity.toFixed(4)),
    dv01: Number(dv01.toFixed(4)),
    krd,
    cashflows,
    repricingGrid
  };
}
