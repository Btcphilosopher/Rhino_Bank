/**
 * 华盛利率终端 - 核心数据结构定义
 * HUASHENG RATES - Core Data Structures & Types
 */

export type DayCountConvention = 'ACT/365' | 'ACT/360' | '30/360' | 'ACT/ACT';

export type PaymentFrequency = 1 | 2 | 4 | 12; // 1=年付, 2=半年付, 4=季付, 12=月付

export type BondType = 'FIXED' | 'ZERO' | 'FLOATING' | 'CALLABLE' | 'PUTTABLE' | 'AMORTIZING';

export type CurveInterpolation = 'BOOTSTRAP' | 'NELSON_SIEGEL' | 'NELSON_SIEGEL_SVENSSON' | 'CUBIC_SPLINE' | 'LINEAR' | 'LOG_LINEAR';

export type KeyTenor = '1M' | '3M' | '6M' | '1Y' | '2Y' | '3Y' | '5Y' | '7Y' | '10Y' | '15Y' | '20Y' | '30Y';

export interface CashFlowItem {
  period: number;
  date: string; // YYYY-MM-DD
  principal: number;
  coupon: number;
  totalCashFlow: number;
  discountFactor: number;
  pv: number;
  pvContributionPct: number; // 现值占比%
  tenorYears: number;
}

export interface Bond {
  id: string;
  code: string;               // e.g., "240010.IB"
  name: string;               // e.g., "24附息国债10"
  type: BondType;             // 债券类型
  issuer: string;             // 发行人 e.g., "中华人民共和国财政部"
  issuerType: 'CGB' | 'POLICY_BANK' | 'LOCAL_GOVT' | 'CORP' | 'NCD'; // 国债/政金债/地方债/企业债/同业存单
  rating: string;             // 评级 e.g., "AAA"
  sector: string;             // 行业/类别 e.g., "利率债" | "金融债" | "产业债"
  issueDate: string;          // 发行日 YYYY-MM-DD
  maturityDate: string;       // 到期日 YYYY-MM-DD
  couponRate: number;         // 票面利率 (%) e.g. 2.15
  faceValue: number;          // 面值 e.g. 100
  frequency: PaymentFrequency;// 付息频率
  dayCount: DayCountConvention;// 计息规则
  price: number;              // 净价
  dirtyPrice?: number;        // 全价
  yield: number;              // 到期收益率 YTM (%)
  accruedInterest?: number;   // 应计利息
  outstandingAmount?: number; // 发行量 (亿元)
  // 衍生期权结构 (若为含权债)
  optionType?: 'CALL' | 'PUT' | 'NONE';
  optionDate?: string;
  optionStrike?: number;
}

export interface BondPricingResult {
  bond: Bond;
  cleanPrice: number;        // 净价
  dirtyPrice: number;        // 全价
  accruedInterest: number;   // 应计利息
  ytm: number;               // 到期收益率 YTM (%)
  ytc?: number;              // 赎回收益率 YTC (%)
  ytp?: number;              // 回售收益率 YTP (%)
  ytw?: number;              // 最差收益率 YTW (%)
  currentYield: number;      // 当前收益率 (%)
  macaulayDuration: number;  // 麦考利久期 (年)
  modifiedDuration: number;  // 修正久期 (年)
  effectiveDuration: number; // 有效久期 (年)
  convexity: number;         // 凸性
  dv01: number;              // DV01 (元/1bp/百元面值)
  krd: Record<KeyTenor, number>; // 关键期限久期 (KRD)
  cashflows: CashFlowItem[]; // 现金流列表
  repricingGrid: Array<{     // 收益率变动重定价对照
    yieldShiftBp: number;
    linearPrice: number;     // 一阶久期近似价
    secondOrderPrice: number;// 二阶久期+凸性近似价
    actualPrice: number;     // 完整重估价
    actualPriceChange: number;
    errorPct: number;
  }>;
}

export interface YieldCurvePoint {
  tenor: KeyTenor;
  tenorYears: number;
  yield: number;            // 收益率 (%)
  zeroRate: number;         // 零息收益率 (%)
  forwardRate: number;      // 远期利率 (%)
  discountFactor: number;   // 折现因子
}

export interface YieldCurveData {
  id: string;
  curveType: 'CGB' | 'POLICY_BANK' | 'CORP' | 'SWAP'; // 国债/政金债/企业债/互换
  name: string;             // 曲线名称
  date: string;             // 曲线日期
  interpolation: CurveInterpolation;
  points: YieldCurvePoint[];
  // 曲线形态参数
  slope10Y2Y: number;       // 10Y - 2Y (bp)
  slope30Y10Y: number;      // 30Y - 10Y (bp)
  slope5Y2Y: number;        // 5Y - 2Y (bp)
  curvature: number;        // 2*5Y - (2Y + 10Y) (bp)
  morphology: 'NORMAL' | 'STEEPENING' | 'FLATTENING' | 'INVERTED' | 'BUTTERFLY'; // 曲线形态
  // Nelson-Siegel 拟合参数 (若适用)
  nsParams?: {
    beta0: number;
    beta1: number;
    beta2: number;
    tau: number;
  };
}

export interface ForwardRateAnalysis {
  label: string;            // e.g. "1Y1Y", "2Y1Y", "5Y5Y", "10Y10Y"
  startYears: number;
  lengthYears: number;
  spotRate: number;
  forwardRate: number;
  historicalChanges: Array<{ date: string; rate: number }>;
}

export interface CurveDecompositionResult {
  levelFactor: number;      // 水平因子 (PC1)
  slopeFactor: number;      // 斜率因子 (PC2)
  curvatureFactor: number;  // 曲率因子 (PC3)
  varianceExplained: {
    pc1Pct: number;
    pc2Pct: number;
    pc3Pct: number;
  };
}

export interface PortfolioPosition {
  id: string;
  bond: Bond;
  quantity: number;         // 张数/持仓面值 (万元)
  costPrice: number;        // 买入成本净价
  currentPrice: number;     // 当前净价
  marketValue: number;      // 市场价值 (元)
  weightPct: number;        // 占组合权重 %
}

export interface PortfolioAnalytics {
  totalMarketValue: number; // 组合总市值 (元)
  totalCouponIncome: number;// 预计年票息收入 (元)
  weightedYield: number;    // 加权收益率 (%)
  weightedMacDuration: number; // 加权麦考利久期
  weightedModDuration: number; // 加权修正久期
  weightedConvexity: number;   // 加权凸性
  totalDv01: number;        // 组合总 DV01 (元/1bp)
  krdSummary: Record<KeyTenor, number>; // 组合 KRD 分布
  riskBreakdown: {
    byTenor: Record<string, { marketValue: number; dv01: number; pct: number }>;
    bySector: Record<string, { marketValue: number; dv01: number; pct: number }>;
    byRating: Record<string, { marketValue: number; dv01: number; pct: number }>;
    byIssuer: Record<string, { marketValue: number; dv01: number; pct: number }>;
  };
}

export interface CarryRollDownResult {
  holdingDays: number;      // 持有期 (天)
  financingRate: number;    // 融资成本率 (%)
  couponCarry: number;      // 票息收益 (元)
  financingCost: number;    // 融资利息支出 (元)
  netCarry: number;         // 净 Carry 收益 (元)
  rollDownGain: number;     // 滚动下滑收益 (元)
  totalExpectedReturn: number; // 总预期收益 (元)
  totalReturnPct: number;   // 预期年化收益率 (%)
}

export interface PnLAttribution {
  couponIncome: number;     // 票息收益
  rollDownReturn: number;   // 滚动收益
  curveShiftReturn: number; // 曲线变化收益
  spreadShiftReturn: number;// 利差变化收益
  priceEffect: number;      // 净价变动收益
  totalPnL: number;         // 总损益
}

export interface CurveShockParameters {
  type: 'PARALLEL' | 'TWIST' | 'STEEPEN' | 'FLATTEN' | 'BUTTERFLY' | 'CUSTOM';
  parallelShiftBp: number;  // 平行移动 bp
  shortEndShiftBp?: number; // 短端移动 bp
  longEndShiftBp?: number;  // 长端移动 bp
  midEndShiftBp?: number;   // 中端移动 bp
  customKeyRateShocks?: Record<KeyTenor, number>; // 各期限自定 shift bp
}

export interface ScenarioResult {
  scenarioName: string;
  originalValue: number;
  shockedValue: number;
  pnl: number;              // 模拟 PnL (元)
  pnlPct: number;           // 变动 %
  originalDv01: number;
  shockedDv01: number;
  originalDuration: number;
  shockedDuration: number;
}

export interface ScenarioMatrixItem {
  yieldShiftBp: number;     // 横轴: 利率变动 bp
  spreadShiftBp: number;    // 纵轴: 利差变动 bp
  pnl: number;              // 组合 PnL
  pnlPct: number;           // 组合 PnL %
}

export interface IRSContract {
  id: string;
  contractCode: string;
  notional: number;         // 名义本金 (万元)
  tenor: KeyTenor;
  fixedRate: number;        // 固定端利率 (%)
  floatingIndex: string;    // 浮动参考利率 (e.g. "FR007", "Shibor_3M")
  paymentFrequency: PaymentFrequency;
  pv: number;               // 现值
  dv01: number;             // DV01
  duration: number;         // 久期
}

export interface TreasuryFutures {
  code: string;             // e.g., "T2409" (10年国债期货), "TF2409" (5年)
  name: string;
  underlyingMaturity: string;
  futuresPrice: number;     // 期货价格
  ctdBondCode: string;      // 最便宜可交割债 (CTD)
  conversionFactor: number; // 转换因子 (CF)
  impliedRepoRate: number;  // 隐含回购利率 IRR (%)
  grossBasis: number;       // 基差
  netBasis: number;         // 净基差
  dv01: number;             // 期货 DV01
}

export interface RateOption {
  type: 'CAP' | 'FLOOR' | 'SWAPTION';
  notional: number;
  strikeRate: number;
  underlyingRate: number;
  volatility: number;       // 隐含波动率 (%)
  timeToMaturityYears: number;
  price: number;
  delta: number;
  gamma: number;
  vega: number;
  theta: number;
  dv01: number;
  modelUsed: 'Black-76' | 'Hull-White';
}

export type ShortRateModelType = 'Vasicek' | 'CIR' | 'Hull-White' | 'Nelson-Siegel';

export type CurveShockType = 'PARALLEL' | 'TWIST' | 'STEEPEN' | 'FLATTEN' | 'BUTTERFLY' | 'CUSTOM';

export interface ShortRateModelParams {
  modelType: ShortRateModelType;
  meanReversionSpeed: number; // a (均值回归速度)
  longTermRate: number;      // b (长期均值利率 %)
  volatility: number;        // sigma (波动率 %)
  initialShortRate: number;  // r0 (初始短端利率 %)
}

export interface MonteCarloSimulationResult {
  pathsCount: number;
  horizonDays: number;
  timeSteps: number[];       // 天数/时间序列
  meanPath: number[];        // 均值路径
  medianPath: number[];      // 中位数路径
  percentile05: number[];    // 5% 分位数 (下尾)
  percentile95: number[];    // 95% 分位数 (上尾)
  samplePaths: number[][];   // 采样展现路径 (前20条)
  terminalYieldDistribution: number[]; // 终点收益率分布
}

export interface VaRResult {
  confidenceLevel: 0.95 | 0.99;
  horizonDays: 1 | 5 | 10;
  historicalVaR: number;    // 历史模拟法 VaR (元)
  parametricVaR: number;    // 参数法 (方差-协方差) VaR (元)
  monteCarloVaR: number;    // 蒙特卡洛法 VaR (元)
  cvar: number;             // 条件 VaR (CVaR / Expected Shortfall) (元)
  maxLoss: number;          // 最大单日极值损失 (元)
  lossDistributionHistogram: Array<{ bin: string; frequency: number }>;
}

export interface PCAResult {
  factors: {
    level: { name: '水平因子 (Level)'; varianceSharePct: number; loadings: number[] };
    slope: { name: '斜率因子 (Slope)'; varianceSharePct: number; loadings: number[] };
    curvature: { name: '曲率因子 (Curvature)'; varianceSharePct: number; loadings: number[] };
  };
  tenors: KeyTenor[];
  historicalFactorSeries: Array<{ date: string; pc1: number; pc2: number; pc3: number }>;
}

export interface SpreadAnalysisItem {
  bondCode: string;
  bondName: string;
  bondYield: number;
  benchmarkYield: number;   // 对标国债收益率
  gSpread: number;          // G-Spread (bp)
  iSpread: number;          // I-Spread (bp) vs Swap
  zSpread: number;          // Z-Spread (bp)
  oas: number;              // OAS (bp)
  assetSwapSpread: number;  // 资产互换利差 (bp)
  percentile5Y: number;     // 5年历史利差分位数 (%)
}

export interface RelativeValueItem {
  pairName: string;         // e.g., "10Y vs 2Y 国债", "5Y vs 2Y"
  spreadBp: number;         // 当前利差 (bp)
  mean5Y: number;           // 5年均值 (bp)
  std5Y: number;            // 5年标准差 (bp)
  zScore: number;           // Z-score
  percentile5Y: number;     // 分位数 (%)
}

export interface MarketTickerQuote {
  code: string;
  name: string;
  category: 'CGB' | 'POLICY_BANK' | 'LOCAL' | 'CORP' | 'NCD' | 'FUTURES' | 'SWAP';
  latestYield: number;      // 最新收益率/价格 (%)
  change1D: number;         // 日变动 (bp)
  change1W: number;         // 周变动 (bp)
  change1M: number;         // 月变动 (bp)
  changeYTD: number;        // 年初至今 (bp)
  volumeAmount: number;     // 成交量 (亿元)
  duration: number;         // 久期
  dv01: number;             // DV01
  status: 'SIMULATED';
}

export interface ResearchNote {
  id: string;
  title: string;
  author: string;
  createdAt: string;
  tags: string[];
  content: string;
  attachments?: {
    curveData?: YieldCurveData;
    bondCode?: string;
    scenarioName?: string;
  };
}

export interface AuditLog {
  id: string;
  timestamp: string;
  user: string;
  role: string;
  action: string;
  module: string;
  params: Record<string, any>;
  status: 'SUCCESS' | 'FAILED';
}
