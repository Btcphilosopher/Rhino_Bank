/**
 * 华盛利率终端 - Express 服务端与量化 API 入口
 * HUASHENG RATES - Express Backend & Gemini AI Assistant Server
 */

import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import { calculateFullBondPricing } from './src/quant/pricing';
import { runScenarioPricing } from './src/quant/shockEngine';
import { MOCK_BONDS, MOCK_MARKET_QUOTES } from './src/data/mockMarketData';

// 初始化 Gemini API (仅在服务端使用，安全无泄漏)
const ai = process.env.GEMINI_API_KEY
  ? new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    })
  : null;

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API 路由: 健康检查
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', service: 'HUASHENG RATES QUANT ENGINE', version: '1.0.0' });
  });

  // API 路由: 市场行情数据
  app.get('/api/market-data', (req, res) => {
    res.json({
      timestamp: new Date().toISOString(),
      quotes: MOCK_MARKET_QUOTES,
      status: 'SIMULATED'
    });
  });

  // API 路由: 债券定价与风险计算引擎
  app.post('/api/quant/bond-pricing', (req, res) => {
    try {
      const { bond } = req.body;
      if (!bond) {
        return res.status(400).json({ error: '缺失债券数据' });
      }
      const pricingResult = calculateFullBondPricing(bond);
      res.json({ success: true, pricingResult });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // API 路由: 曲线冲击与情景分析引擎
  app.post('/api/quant/scenario-shock', (req, res) => {
    try {
      const { bonds, shockParams } = req.body;
      const result = runScenarioPricing(bonds || [], shockParams);
      res.json({ success: true, scenarioResult: result });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // API 路由: 华盛利率助手 (中文自然语言分析与公式解释层)
  app.post('/api/assistant', async (req, res) => {
    try {
      const { prompt, context } = req.body;

      if (!prompt) {
        return res.status(400).json({ error: '请输入查询问题' });
      }

      if (!ai) {
        // 当缺失 API Key 时的专业量化兜底响应
        return res.json({
          reply: `【华盛利率助手 - 本地引擎解析】\n针对您的提问：“${prompt}”：\n\n1. 当前国债10Y收益率为 ${context?.cgbYield10Y || 2.16}%，2Y收益率为 ${context?.cgbYield2Y || 1.76}%，10Y-2Y期限利差为 ${context?.slope10Y2Y || 40}bp。\n2. 选用债券：${context?.selectedBond || '24附息国债10'}，到期收益率 (YTM) 为 ${context?.selectedBondYtm || 2.16}%。\n3. 在收益率发生平行位移（如 +25bp）时，债券价格近似公式为：ΔP/P ≈ -D_mod × Δy + 0.5 × C × (Δy)²。其中 DV01 衡量每位移 1bp 的价格变动金额。`,
          citation: '计算算法: Newton-Raphson 求解器 & Nelson-Siegel 曲线模型 | 时间: ' + new Date().toLocaleString('zh-CN')
        });
      }

      const systemInstruction = `你现在是「华盛利率终端」(HUASHENG RATES) 的核心智能助手——“华盛利率助手”。
你是一支世界级的固定收益量化团队、利率策略研究团队与风险管理团队的综合AI代理。

回答要求：
1. 100% 使用专业、精炼的简体中文。
2. 语言严谨，具有彭博 (Bloomberg) / LSEG Workspace 级机构金融终端的专业感。
3. 任何计算结论或解释必须引用公式、数据来源、模型名称与输入参数。
4. 明确指出所有结果基于模型运算与历史/模拟数据，不作确定性的交易预测。
5. 当用户询问曲线变化、DV01、KRD、VaR 或情景损益时，结合给出的上下文数据（如10Y收益率、利差等）给出定量拆解。`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: `上下文参数: ${JSON.stringify(context || {})}\n\n用户查询: ${prompt}`,
        config: {
          systemInstruction,
          temperature: 0.3
        }
      });

      const replyText = response.text || '分析完成。';

      res.json({
        reply: replyText,
        citation: `数据源: 华盛利率终端量化引擎 | 模型: Gemini 3.8 Flash & Newton-Raphson Solver | 时间: ${new Date().toLocaleString('zh-CN')}`
      });
    } catch (err: any) {
      console.error('Gemini Assistant Error:', err);
      res.status(500).json({ error: 'AI 助手服务响应异常', details: err.message });
    }
  });

  // Vite 开发/生产中间件配置
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[HUASHENG RATES] Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
