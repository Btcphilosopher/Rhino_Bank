package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.MetroSimulationEngine
import com.example.model.*
import com.example.ui.theme.*

data class TwinPlatformItem(
    val id: String,
    val name: String,
    val icon: ImageVector,
    val isCctv: Boolean
)


@Composable
fun DigitalTwinScreen(
    engine: MetroSimulationEngine,
    stationId: String,
    isChinese: Boolean,
    onBack: () -> Unit
) {
    val station = engine.stations[stationId] ?: engine.stations["PEOPLES_SQUARE"]!!
    var selectedLevel by remember { mutableStateOf("CONCOURSE") } // "ENTRANCE", "CONCOURSE", "FARE_GATES", "PLATFORM", "TRAIN"
    var selectedAssetId by remember { mutableStateOf<String?>(null) }
    var selectedCctvId by remember { mutableStateOf<String?>(null) }

    // Twin mock energy values
    var lightsKwh by remember { mutableStateOf(14.5) }
    var hvacKwh by remember { mutableStateOf(84.2) }

    LaunchedEffect(Unit) {
        while (true) {
            lightsKwh += (Math.random() * 0.4 - 0.2)
            hvacKwh += (Math.random() * 1.5 - 0.7)
            kotlinx.coroutines.delay(4000)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBg)
            .padding(12.dp)
    ) {
        // Top breadcrumbs / back header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.background(DarkSurface, RoundedCornerShape(4.dp))
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = "${station.nameZh} 智能数字孪生舱",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = Color.White
                )
                Text(
                    text = "CITY ➔ STATION ➔ ${selectedLevel} MODE",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = CoolGrey
                )
            }
        }

        // Hierarchy Navigation breadcrumbs (16 — Hierarchy)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            val levels = listOf(
                Pair("ENTRANCE", if (isChinese) "出入口" else "ENTRANCE"),
                Pair("CONCOURSE", if (isChinese) "站厅层" else "CONCOURSE"),
                Pair("FARE_GATES", if (isChinese) "闸机区" else "GATES"),
                Pair("PLATFORM", if (isChinese) "站台层" else "PLATFORM"),
                Pair("TRAIN", if (isChinese) "列车舱" else "TRAIN")
            )
            levels.forEach { (lvlId, lvlLabel) ->
                val selected = selectedLevel == lvlId
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 1.dp)
                        .background(
                            if (selected) MetroBlue else DarkSurface,
                            RoundedCornerShape(4.dp)
                        )
                        .clickable {
                            selectedLevel = lvlId
                            selectedAssetId = null
                            selectedCctvId = null
                        }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = lvlLabel,
                        color = Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        // Layout Split (Left panel: 2D Interactive schematic Grid; Right Panel: Telemetry display)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            // Left Interactive Schematic Panel
            Card(
                modifier = Modifier
                    .weight(1.3f)
                    .fillMaxHeight(),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = BorderStroke(1.dp, CoolGrey.copy(alpha = 0.2f))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = if (isChinese) "📍 物理实体拓扑图" else "📍 Spatial Entity Layout",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    // Render mock items for each selected hierarchical level
                    when (selectedLevel) {
                        "ENTRANCE" -> EntranceTwinLayout(station, isChinese) { selectedAssetId = it }
                        "CONCOURSE" -> ConcourseTwinLayout(station, isChinese, lightsKwh, hvacKwh) { selectedAssetId = it }
                        "FARE_GATES" -> GatesTwinLayout(isChinese) { selectedAssetId = it }
                        "PLATFORM" -> PlatformTwinLayout(station, isChinese) { id, cctv ->
                            if (cctv) selectedCctvId = id else selectedAssetId = id
                        }
                        "TRAIN" -> TrainCabinTwinLayout(engine, isChinese) { selectedAssetId = it }
                    }
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Right Telemetry Panel
            Card(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = BorderStroke(1.dp, CoolGrey.copy(alpha = 0.2f))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    if (selectedCctvId != null) {
                        CctvVideoTwinFeed(selectedCctvId!!, isChinese)
                    } else if (selectedAssetId != null) {
                        AssetTwinTelemetryDetail(selectedAssetId!!, engine, isChinese)
                    } else {
                        // Default state: Energy and environment monitor
                        StaticStationDiagnostics(station, lightsKwh, hvacKwh, isChinese)
                    }
                }
            }
        }
    }
}

// ==========================================
// SECTOR A: LEVEL LAYOUT COMPONENT DRAWERS
// ==========================================

@Composable
fun EntranceTwinLayout(station: Station, isChinese: Boolean, onSelect: (String) -> Unit) {
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(station.exits) { exit ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .background(DarkBg, RoundedCornerShape(4.dp))
                    .clickable { onSelect("AST-ES044") } // Map to escalator
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.ExitToApp, contentDescription = "Exit", tint = MetroBlue)
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text("出口 Exit ${exit.name}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("可达 Nearby: ${if (isChinese) exit.nearbyZh else exit.nearbyEn}", color = CoolGrey, fontSize = 10.sp)
                    Text("直升梯 Lift: ${if (exit.hasLift) "✓" else "✕"}", color = if (exit.hasLift) MetroGreen else MetroOrange, fontSize = 9.sp)
                }
            }
        }
    }
}

@Composable
fun ConcourseTwinLayout(station: Station, isChinese: Boolean, lightsKwh: Double, hvacKwh: Double, onSelect: (String) -> Unit) {
    val items = listOf(
        Triple("AST-LF109", if (isChinese) "无障碍直升梯 LF-109" else "Elevator LF-109", Icons.Default.Elevator),
        Triple("AST-ES044", if (isChinese) "上行自动扶梯 ES-044" else "Escalator ES-044", Icons.Default.SwapVert),
        Triple("RETAIL-01", if (isChinese) "华润万家便利店 Concourse Retail" else "CR Vanguard Express", Icons.Default.Storefront),
        Triple("WC-01", if (isChinese) "公共卫生间 Public Toilet" else "Public Restrooms", Icons.Default.Wc),
        Triple("INFO-01", if (isChinese) "智能客服中心 Info Hub" else "Information Center", Icons.Default.Info)
    )

    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(items) { item ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .background(DarkBg, RoundedCornerShape(4.dp))
                    .clickable { onSelect(item.first) }
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(item.third, contentDescription = item.second, tint = MetroBlue, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(item.second, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    Text("STATUS: OPERATIONAL", color = MetroGreen, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
fun GatesTwinLayout(isChinese: Boolean, onSelect: (String) -> Unit) {
    val gates = listOf(
        Pair("AST-TK002", "INBOUND GATE 01"),
        Pair("AST-TK002", "INBOUND GATE 02"),
        Pair("AST-TK002", "OUTBOUND GATE 03"),
        Pair("AST-TK002", "ACCESSIBLE GATE 04")
    )

    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(gates) { gate ->
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkBg),
                modifier = Modifier
                    .clickable { onSelect(gate.first) }
                    .padding(4.dp)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.QrCodeScanner, contentDescription = "Gate", tint = MetroBlue, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(gate.second, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("LOAD: NORMAL", color = MetroGreen, fontSize = 8.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
fun PlatformTwinLayout(station: Station, isChinese: Boolean, onSelect: (String, Boolean) -> Unit) {
    val platformItems = listOf(
        TwinPlatformItem("CCTV-P2-01", if (isChinese) "监控摄像头 P2-01" else "CCTV #P2-01", Icons.Default.Videocam, true),
        TwinPlatformItem("CCTV-P2-02", if (isChinese) "监控摄像头 P2-02" else "CCTV #P2-02", Icons.Default.Videocam, true),
        TwinPlatformItem("AST-LF109", if (isChinese) "1号站台直升电梯" else "Platform 1 Elevator", Icons.Default.Elevator, false),
        TwinPlatformItem("AST-SG302", if (isChinese) "进站端信号器 SG-302" else "Signal Light SG-302", Icons.Default.Traffic, false)
    )

    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(platformItems) { item ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .background(DarkBg, RoundedCornerShape(4.dp))
                    .clickable { onSelect(item.id, item.isCctv) }
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(item.icon, contentDescription = item.name, tint = if (item.isCctv) MetroOrange else MetroBlue, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(item.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    Text("SYSTEM: ONLINE", color = MetroGreen, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
fun TrainCabinTwinLayout(engine: MetroSimulationEngine, isChinese: Boolean, onSelect: (String) -> Unit) {
    val list = engine.liveTrains.collectAsState().value.filter { it.lineId == "Line2" }
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(list) { t ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .background(DarkBg, RoundedCornerShape(4.dp))
                    .clickable { onSelect("AST-02047") }
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Train, contentDescription = "Train Cabin", tint = MetroGreen)
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("列车卡舱 TRAIN ${t.id}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    Text("方向 bound: ${t.directionZh}", color = CoolGrey, fontSize = 9.sp)
                }
            }
        }
    }
}

// ==========================================
// SECTOR B: DIAGNOSTIC & DETAILED TELEMETRY
// ==========================================

@Composable
fun StaticStationDiagnostics(station: Station, lightsKwh: Double, hvacKwh: Double, isChinese: Boolean) {
    Text(
        text = if (isChinese) "📊 车站综合能源环控双生舱" else "📊 Integrated Energy Twin",
        color = Color.White,
        fontWeight = FontWeight.Bold,
        fontSize = 12.sp,
        modifier = Modifier.padding(bottom = 8.dp)
    )

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = DarkBg)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(if (isChinese) "照明耗能 LIGHTING" else "LIGHTING LOAD", fontSize = 8.sp, color = CoolGrey)
            Text("${String.format("%.2f", lightsKwh)} KW", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)

            Spacer(modifier = Modifier.height(10.dp))

            Text(if (isChinese) "暖通空调 HVAC LOAD" else "HVAC DYNAMICS", fontSize = 8.sp, color = CoolGrey)
            Text("${String.format("%.2f", hvacKwh)} KW", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)

            Spacer(modifier = Modifier.height(10.dp))

            Text(if (isChinese) "环境温度 AMBIENT TEMP" else "AMBIENT TEMP", fontSize = 8.sp, color = CoolGrey)
            Text("23.4 °C", color = MetroGreen, fontSize = 16.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }
    }

    Spacer(modifier = Modifier.height(12.dp))
    Text(
        text = if (isChinese) "提示：点击左侧具体机电设备实体可调取实时遥测频谱详情" else "Tip: Tap any layout node to load real-time telemetry metrics.",
        color = CoolGrey,
        fontSize = 9.sp,
        textAlign = TextAlign.Center
    )
}

@Composable
fun AssetTwinTelemetryDetail(assetId: String, engine: MetroSimulationEngine, isChinese: Boolean) {
    val asset = engine.assets.collectAsState().value.find { it.id == assetId }
        ?: engine.assets.collectAsState().value.first()

    Text(
        text = "⚙️ TELEMETRY ${asset.id}",
        color = Color.White,
        fontWeight = FontWeight.Bold,
        fontSize = 12.sp,
        modifier = Modifier.padding(bottom = 8.dp)
    )

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = DarkBg)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text("ENTITY TYPE: ${asset.type.name}", color = MetroBlue, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            Text(if (isChinese) asset.locationZh else asset.locationEn, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)

            Divider(color = Color.DarkGray, modifier = Modifier.padding(vertical = 8.dp))

            // Diagnostic indicators
            val scoreColor = if (asset.healthScore >= 90) MetroGreen else MetroOrange
            Text("HEALTH INDEX: ${asset.healthScore}%", color = scoreColor, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("VIBRATION: ${String.format("%.1f", asset.vibrationMmS)} mm/s", color = Color.White, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            Text("HEAT LOAD: ${String.format("%.1f", asset.temperatureC)} °C", color = Color.White, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            Text("RUN TIME: ${asset.runtimeHours} hrs", color = Color.White, fontSize = 11.sp, fontFamily = FontFamily.Monospace)

            Spacer(modifier = Modifier.height(10.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Yellow.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                    .padding(6.dp)
            ) {
                Text(
                    text = if (isChinese) "【预测维护】根据振动分析，暂无突发故障风险。预计下次检修：${asset.nextInspectionDate}" else "[Predictive] Vibration stable. No failure risk predicted. Next check: ${asset.nextInspectionDate}",
                    color = Color.White,
                    fontSize = 8.sp
                )
            }
        }
    }
}

@Composable
fun CctvVideoTwinFeed(cctvId: String, isChinese: Boolean) {
    Text(
        text = "📹 FEED: $cctvId",
        color = Color.White,
        fontWeight = FontWeight.Bold,
        fontSize = 12.sp,
        modifier = Modifier.padding(bottom = 8.dp)
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(150.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Black),
        border = BorderStroke(1.dp, MetroOrange)
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            // Render a simulated flashing green/red reticle scanline CCTV
            Canvas(modifier = Modifier.fillMaxSize()) {
                // Outer scan lines
                drawLine(Color.White.copy(alpha = 0.2f), Offset(0f, this.size.height * 0.3f), Offset(this.size.width, this.size.height * 0.3f), strokeWidth = 1f)
                drawLine(Color.White.copy(alpha = 0.2f), Offset(0f, this.size.height * 0.7f), Offset(this.size.width, this.size.height * 0.7f), strokeWidth = 1f)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.Videocam, contentDescription = "Cam", tint = MetroRed, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.height(6.dp))
                Text("LIVE STREAM", color = MetroRed, fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                Text("PASGR DENSITY: 1.2 pax/㎡ (LOW)", color = MetroGreen, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}
