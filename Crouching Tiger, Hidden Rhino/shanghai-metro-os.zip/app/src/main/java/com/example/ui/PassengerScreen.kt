package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.MetroSimulationEngine
import com.example.engine.RouteResult
import com.example.model.*
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun PassengerScreen(
    engine: MetroSimulationEngine,
    isChinese: Boolean,
    onNavigateToTwin: (String) -> Unit
) {
    var selectedTab by remember { mutableStateOf("HOME") }
    var startStationId by remember { mutableStateOf("PEOPLES_SQUARE") }
    var endStationId by remember { mutableStateOf("PVG_AIRPORT") }
    var activeRouteResult by remember { mutableStateOf<RouteResult?>(null) }
    var activeRouteMode by remember { mutableStateOf("FASTEST") }
    var passengerType by remember { mutableStateOf(PassengerType.COMMUTER) }

    // Active Ticket / QR State
    var simulatedTicket by remember { mutableStateOf<Ticket?>(null) }
    var showQrDialog by remember { mutableStateOf(false) }
    var simulatedRideStep by remember { mutableStateOf("NOT_STARTED") } // "NOT_STARTED", "SWIPED_IN", "ARRIVED", "SWIPED_OUT"

    // Search query for global search
    var searchQuery by remember { mutableStateOf("") }
    var searchResults by remember { mutableStateOf<List<Station>>(emptyList()) }

    // Update route calculation when endpoints or parameters change
    LaunchedEffect(startStationId, endStationId, activeRouteMode, passengerType, engine.isDisruptionActive.collectAsState().value) {
        if (startStationId != endStationId) {
            activeRouteResult = engine.calculateRoute(startStationId, endStationId, activeRouteMode, passengerType)
        } else {
            activeRouteResult = null
        }
    }

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = LightSurface,
                modifier = Modifier.testTag("passenger_bottom_navigation")
            ) {
                val tabs = listOf(
                    Triple("HOME", Icons.Default.Home, if (isChinese) "首页" else "HOME"),
                    Triple("JOURNEY", Icons.Default.Directions, if (isChinese) "出行" else "JOURNEY"),
                    Triple("MAP", Icons.Default.Map, if (isChinese) "地图" else "MAP"),
                    Triple("STATIONS", Icons.Default.LocationCity, if (isChinese) "车站" else "STATIONS"),
                    Triple("TICKETS", Icons.Default.QrCode, if (isChinese) "票卡" else "TICKETS")
                )
                tabs.forEach { (tabId, icon, label) ->
                    NavigationBarItem(
                        selected = selectedTab == tabId,
                        onClick = { selectedTab = tabId },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MetroBlue,
                            selectedTextColor = MetroBlue,
                            unselectedIconColor = CoolGrey,
                            unselectedTextColor = CoolGrey,
                            indicatorColor = MetroBlue.copy(alpha = 0.12f)
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(LightBg)
                .padding(innerPadding)
        ) {
            // Smart alert ticker
            val activeDisruptionList = engine.disruptions.collectAsState().value
            if (activeDisruptionList.isNotEmpty()) {
                val d = activeDisruptionList.first()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MetroRed)
                        .padding(vertical = 6.dp, horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Warning, contentDescription = "Alert", tint = Color.White, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isChinese) {
                            "【延误预警】${d.lineId} ${d.scopeZh}：${d.reasonZh}"
                        } else {
                            "[Alert] ${d.lineId} ${d.scopeEn}: ${d.reasonEn}"
                        },
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            when (selectedTab) {
                "HOME" -> HomeScreenView(
                    engine = engine,
                    isChinese = isChinese,
                    onSelectStations = { start, end ->
                        startStationId = start
                        endStationId = end
                        selectedTab = "JOURNEY"
                    },
                    onTriggerDemo = { demoId ->
                        when (demoId) {
                            1 -> {
                                startStationId = "PEOPLES_SQUARE"
                                endStationId = "LUJIAZUI"
                            }
                            2 -> {
                                startStationId = "PEOPLES_SQUARE"
                                endStationId = "PVG_AIRPORT"
                            }
                            3 -> {
                                startStationId = "HQ_RAIL_STN"
                                endStationId = "NANJING_WEST"
                            }
                        }
                        selectedTab = "JOURNEY"
                    }
                )
                "JOURNEY" -> JourneyPlannerView(
                    engine = engine,
                    isChinese = isChinese,
                    startId = startStationId,
                    endId = endStationId,
                    onSwap = {
                        val temp = startStationId
                        startStationId = endStationId
                        endStationId = temp
                    },
                    onStartChange = { startStationId = it },
                    onEndChange = { endStationId = it },
                    routeResult = activeRouteResult,
                    routeMode = activeRouteMode,
                    onModeChange = { activeRouteMode = it },
                    passengerType = passengerType,
                    onPassengerTypeChange = { passengerType = it },
                    onGenerateTicket = { route ->
                        val code = "METROOS_TKT_${UUID.randomUUID().toString().take(8).uppercase()}"
                        val p = FareProduct(
                            id = "SGL_JNY",
                            nameZh = "单程票",
                            nameEn = "Single Ticket",
                            type = FareType.SINGLE_JOURNEY,
                            basePrice = 3.0,
                            perKmPrice = 0.1
                        )
                        simulatedTicket = Ticket(
                            id = code,
                            product = p,
                            passengerType = passengerType,
                            qrCodePayload = code,
                            status = TicketStatus.ACTIVE_READY_TO_ENTER,
                            startStationId = route.startStationId,
                            endStationId = route.endStationId,
                            actualFare = route.estimatedFare
                        )
                        simulatedRideStep = "ACTIVE_READY_TO_ENTER"
                        showQrDialog = true
                    }
                )
                "MAP" -> NetworkMapView(
                    engine = engine,
                    isChinese = isChinese
                )
                "STATIONS" -> StationsView(
                    engine = engine,
                    isChinese = isChinese,
                    onNavigateToTwin = onNavigateToTwin
                )
                "TICKETS" -> TicketsAndCardView(
                    engine = engine,
                    isChinese = isChinese,
                    simulatedTicket = simulatedTicket,
                    simulatedRideStep = simulatedRideStep,
                    onProgressRide = { nextStep ->
                        simulatedRideStep = nextStep
                        if (nextStep == "SWIPED_OUT" && simulatedTicket != null) {
                            // Deduct simulated balance!
                            val card = engine.digitalCard.value
                            val updatedBalance = (card.balance - simulatedTicket!!.actualFare).coerceAtLeast(0.0)
                            val txList = card.transactions.toMutableList()
                            txList.add(
                                0,
                                PaymentTransaction(
                                    id = "TX-${(10000..99999).random()}",
                                    timestamp = System.currentTimeMillis(),
                                    amount = simulatedTicket!!.actualFare,
                                    startStationZh = engine.stations[simulatedTicket!!.startStationId]?.nameZh ?: "未知",
                                    endStationZh = engine.stations[simulatedTicket!!.endStationId]?.nameZh ?: "未知",
                                    status = "SUCCESS"
                                )
                            )
                            engine.digitalCard.value = card.copy(balance = updatedBalance, transactions = txList)
                            engine.addEvent(
                                "payment.completed",
                                card.cardNumber,
                                "Settled Fare ¥${simulatedTicket!!.actualFare} from ${engine.stations[simulatedTicket!!.startStationId]?.nameZh} to ${engine.stations[simulatedTicket!!.endStationId]?.nameZh}"
                            )
                        }
                    }
                )
            }
        }
    }

    // QR Ticket Scanner Simulation Dialog
    if (showQrDialog && simulatedTicket != null) {
        val ticket = simulatedTicket!!
        val startStation = engine.stations[ticket.startStationId]
        val endStation = engine.stations[ticket.endStationId]

        AlertDialog(
            onDismissRequest = { showQrDialog = false },
            confirmButton = {
                Button(
                    onClick = {
                        showQrDialog = false
                        selectedTab = "TICKETS"
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MetroBlue)
                ) {
                    Text(if (isChinese) "前往乘车" else "Go to Ride")
                }
            },
            title = {
                Text(
                    text = if (isChinese) "电子乘车闸机二维码" else "Electronic Ride QR Code",
                    fontWeight = FontWeight.Bold,
                    color = TextDark,
                    fontSize = 18.sp
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (isChinese) "上海都市轨道交通智能票卡" else "Shanghai Metro OS Smart Pass",
                        fontWeight = FontWeight.Medium,
                        fontSize = 14.sp,
                        color = CoolGrey
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    // Representing QR schematic
                    Box(
                        modifier = Modifier
                            .size(180.dp)
                            .border(2.dp, MetroBlue, RoundedCornerShape(8.dp))
                            .background(Color.White)
                            .padding(12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.size(140.dp)) {
                            // Render a simulated procedural matrix QR grid with line color in center
                            val size = this.size.width
                            val steps = 14
                            val stepSize = size / steps
                            for (r in 0 until steps) {
                                for (c in 0 until steps) {
                                    // Make some fixed corners and random blocks
                                    val isCorner = (r < 4 && c < 4) || (r < 4 && c >= steps - 4) || (r >= steps - 4 && c < 4)
                                    val randomFill = (r + c * r) % 3 == 0 || (r + c) % 5 == 0
                                    if (isCorner || randomFill) {
                                        drawRect(
                                            color = if (isCorner) MetroBlue else Graphite,
                                            topLeft = Offset(c * stepSize, r * stepSize),
                                            size = androidx.compose.ui.geometry.Size(stepSize, stepSize)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "${startStation?.nameZh ?: ""} ➔ ${endStation?.nameZh ?: ""}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = TextDark
                    )
                    Text(
                        text = "${startStation?.nameEn ?: ""} ➔ ${endStation?.nameEn ?: ""}",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (isChinese) "预计票价: ¥${ticket.actualFare}" else "Fare: ¥${ticket.actualFare}",
                        fontWeight = FontWeight.Bold,
                        color = MetroGreen,
                        fontSize = 15.sp
                    )
                    Text(
                        text = "ID: ${ticket.qrCodePayload} | 优惠: ${ticket.passengerType.labelZh}",
                        fontSize = 10.sp,
                        color = CoolGrey
                    )
                }
            }
        )
    }
}

// ==========================================
// 1. HOME SCREEN TAB VIEW
// ==========================================
@Composable
fun HomeScreenView(
    engine: MetroSimulationEngine,
    isChinese: Boolean,
    onSelectStations: (String, String) -> Unit,
    onTriggerDemo: (Int) -> Unit
) {
    var searchStart by remember { mutableStateOf("") }
    var searchEnd by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("home_screen_column")
    ) {
        // Welcome Header
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                colors = CardDefaults.cardColors(containerColor = MetroBlue),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (isChinese) "上海" else "SHANGHAI",
                                color = Color.White,
                                fontSize = 28.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(
                                text = if (isChinese) "轨道交通智慧大脑 OS" else "METRO INTELLIGENT OS",
                                color = Color.White.copy(alpha = 0.8f),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Box(
                            modifier = Modifier
                                .background(Color.White.copy(alpha = 0.15f), CircleShape)
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            val timeFormat = SimpleDateFormat("HH:mm", Locale.CHINA)
                            var curTime by remember { mutableStateOf(timeFormat.format(Date())) }
                            LaunchedEffect(Unit) {
                                while (true) {
                                    curTime = timeFormat.format(Date())
                                    delay(10000)
                                }
                            }
                            Text(
                                text = curTime,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }
                    }
                }
            }
        }

        // Search inputs
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                colors = CardDefaults.cardColors(containerColor = LightSurface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isChinese) "智能路网向导" else "METRO NAVIGATION",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MetroBlue
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // FROM FIELD
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(LightBg, RoundedCornerShape(8.dp))
                            .clickable {
                                onSelectStations("PEOPLES_SQUARE", "PVG_AIRPORT")
                            }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.MyLocation, contentDescription = "From", tint = MetroGreen, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = if (isChinese) "从哪里出发？" else "FROM WHERE?",
                                fontSize = 10.sp,
                                color = CoolGrey
                            )
                            Text(
                                text = if (isChinese) "人民广场 People's Square" else "People's Square",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextDark
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // TO FIELD
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(LightBg, RoundedCornerShape(8.dp))
                            .clickable {
                                onSelectStations("PEOPLES_SQUARE", "PVG_AIRPORT")
                            }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Place, contentDescription = "To", tint = MetroRed, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = if (isChinese) "到哪里？" else "TO WHERE?",
                                fontSize = 10.sp,
                                color = CoolGrey
                            )
                            Text(
                                text = if (isChinese) "浦东国际机场 Pudong Airport" else "Pudong Airport",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextDark
                            )
                        }
                    }
                }
            }
        }

        // Quick Shortcuts
        item {
            Text(
                text = if (isChinese) "常用目的地" else "FAVORITE DESTINATIONS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = CoolGrey,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 20.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                val shortcuts = listOf(
                    Quad("HOME", if (isChinese) "家" else "HOME", Icons.Default.Home, "PEOPLES_SQUARE", "LUJIAZUI"),
                    Quad("WORK", if (isChinese) "公司" else "WORK", Icons.Default.Work, "NANJING_WEST", "CENTURY_AVE"),
                    Quad("RAIL", if (isChinese) "虹桥站" else "HQ RAIL", Icons.Default.DirectionsRailway, "PEOPLES_SQUARE", "HQ_RAIL_STN"),
                    Quad("AIRPORT", if (isChinese) "浦东机场" else "PVG APT", Icons.Default.FlightTakeoff, "PEOPLES_SQUARE", "PVG_AIRPORT")
                )

                shortcuts.forEach { item ->
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 4.dp)
                            .clickable {
                                onSelectStations(item.four, item.five)
                            },
                        colors = CardDefaults.cardColors(containerColor = LightSurface)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .background(MetroBlue.copy(alpha = 0.1f), CircleShape)
                                    .padding(8.dp)
                            ) {
                                Icon(item.three, contentDescription = item.two, tint = MetroBlue, modifier = Modifier.size(20.dp))
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = item.two,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextDark,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }

        // CUJ VERTICAL SLICE DEMONSTRATIONS
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 20.dp),
                colors = CardDefaults.cardColors(containerColor = LightSurface),
                border = BorderStroke(1.dp, MetroBlue.copy(alpha = 0.3f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isChinese) "🚇 演示通道: 三大核心验证行程" else "🚇 Demo: Core Verification Journeys",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MetroBlue
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isChinese) {
                            "计算真实上海级别拥挤度、数字孪生站台、票价引擎"
                        } else {
                            "Calculates dynamic congestion, step-free access, real-time fare rules."
                        },
                        fontSize = 11.sp,
                        color = CoolGrey
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Demo 1
                    Button(
                        onClick = { onTriggerDemo(1) },
                        colors = ButtonDefaults.buttonColors(containerColor = Graphite),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                            .testTag("demo_1_button"),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isChinese) "验证 [DEMO 1]: 人民广场 ➔ 陆家嘴" else "[DEMO 1]: People's Square ➔ Lujiazui",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Icon(Icons.Default.ArrowForward, contentDescription = "Run", modifier = Modifier.size(16.dp))
                        }
                    }

                    // Demo 2
                    Button(
                        onClick = { onTriggerDemo(2) },
                        colors = ButtonDefaults.buttonColors(containerColor = MetroBlue),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                            .testTag("demo_2_button"),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isChinese) "验证 [DEMO 2]: 人民广场 ➔ 浦东国际机场" else "[DEMO 2]: People's Square ➔ Pudong Airport",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Icon(Icons.Default.ArrowForward, contentDescription = "Run", modifier = Modifier.size(16.dp))
                        }
                    }

                    // Demo 3
                    Button(
                        onClick = { onTriggerDemo(3) },
                        colors = ButtonDefaults.buttonColors(containerColor = MetroGreen),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("demo_3_button"),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isChinese) "验证 [DEMO 3]: 虹桥火车站 ➔ 南京西路" else "[DEMO 3]: Hongqiao Railway ➔ Nanjing West",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Icon(Icons.Default.ArrowForward, contentDescription = "Run", modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}

data class Quad<A, B, C, D, E>(val one: A, val two: B, val three: C, val four: D, val five: E)

// ==========================================
// 2. JOURNEY PLANNER TAB VIEW
// ==========================================
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun JourneyPlannerView(
    engine: MetroSimulationEngine,
    isChinese: Boolean,
    startId: String,
    endId: String,
    onSwap: () -> Unit,
    onStartChange: (String) -> Unit,
    onEndChange: (String) -> Unit,
    routeResult: RouteResult?,
    routeMode: String,
    onModeChange: (String) -> Unit,
    passengerType: PassengerType,
    onPassengerTypeChange: (PassengerType) -> Unit,
    onGenerateTicket: (RouteResult) -> Unit
) {
    var expandedStart by remember { mutableStateOf(false) }
    var expandedEnd by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Core station fields
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = LightSurface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        // Departure dropdown selector
                        Box {
                            Text(
                                text = (if (isChinese) "起点 " else "START: ") + (engine.stations[startId]?.nameZh ?: ""),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(LightBg, RoundedCornerShape(6.dp))
                                    .clickable { expandedStart = true }
                                    .padding(10.dp),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextDark
                            )
                            DropdownMenu(expanded = expandedStart, onDismissRequest = { expandedStart = false }) {
                                engine.stations.values.forEach { station ->
                                    DropdownMenuItem(
                                        text = { Text("${station.nameZh} / ${station.nameEn}") },
                                        onClick = {
                                            onStartChange(station.id)
                                            expandedStart = false
                                        }
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Destination dropdown selector
                        Box {
                            Text(
                                text = (if (isChinese) "终点 " else "TO: ") + (engine.stations[endId]?.nameZh ?: ""),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(LightBg, RoundedCornerShape(6.dp))
                                    .clickable { expandedEnd = true }
                                    .padding(10.dp),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextDark
                            )
                            DropdownMenu(expanded = expandedEnd, onDismissRequest = { expandedEnd = false }) {
                                engine.stations.values.forEach { station ->
                                    DropdownMenuItem(
                                        text = { Text("${station.nameZh} / ${station.nameEn}") },
                                        onClick = {
                                            onEndChange(station.id)
                                            expandedEnd = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    IconButton(
                        onClick = onSwap,
                        modifier = Modifier
                            .background(MetroBlue.copy(alpha = 0.1f), CircleShape)
                            .size(44.dp)
                    ) {
                        Icon(Icons.Default.SwapVert, contentDescription = "Swap", tint = MetroBlue)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Preference Selectors
        Text(
            text = if (isChinese) "路线偏好" else "ROUTE MODE",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = CoolGrey,
            modifier = Modifier.padding(bottom = 6.dp)
        )

        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            maxItemsInEachRow = 3
        ) {
            val modes = listOf(
                Pair("FASTEST", if (isChinese) "最快" else "Fastest"),
                Pair("FEWEST_TRANSFERS", if (isChinese) "最少换乘" else "Min Transfers"),
                Pair("LEAST_WALKING", if (isChinese) "最少步行" else "Min Walk"),
                Pair("ACCESSIBLE", if (isChinese) "无障碍♿" else "Accessible♿")
            )
            modes.forEach { (mCode, mLabel) ->
                val selected = routeMode == mCode
                Box(
                    modifier = Modifier
                        .padding(end = 6.dp, bottom = 6.dp)
                        .background(
                            if (selected) MetroBlue else LightSurface,
                            RoundedCornerShape(16.dp)
                        )
                        .clickable { onModeChange(mCode) }
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = mLabel,
                        color = if (selected) Color.White else TextDark,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Discount Passenger Type
        Text(
            text = if (isChinese) "乘客群体与优惠" else "PASSENGER TYPE",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = CoolGrey,
            modifier = Modifier.padding(bottom = 6.dp)
        )

        Row(modifier = Modifier.fillMaxWidth()) {
            PassengerType.values().forEach { type ->
                val selected = passengerType == type
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 2.dp)
                        .background(
                            if (selected) MetroBlue.copy(alpha = 0.15f) else LightSurface,
                            RoundedCornerShape(8.dp)
                        )
                        .border(
                            if (selected) BorderStroke(1.5.dp, MetroBlue) else BorderStroke(0.dp, Color.Transparent),
                            RoundedCornerShape(8.dp)
                        )
                        .clickable { onPassengerTypeChange(type) }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isChinese) type.labelZh.substringBefore(" ") else type.name.take(6),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (selected) MetroBlue else TextDark
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Route Calculation Results Display
        if (routeResult != null) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                colors = CardDefaults.cardColors(containerColor = LightSurface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Summary Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (isChinese) {
                                    "预计 ${routeResult.totalMinutes} 分钟"
                                } else {
                                    "Est. ${routeResult.totalMinutes} mins"
                                },
                                fontSize = 18.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = TextDark
                            )
                            Text(
                                text = if (isChinese) {
                                    "${routeResult.transfersCount} 次换乘 | 步行约 ${routeResult.walkingMinutes} 分钟"
                                } else {
                                    "${routeResult.transfersCount} transfers | Walk ~${routeResult.walkingMinutes} mins"
                                },
                                fontSize = 12.sp,
                                color = CoolGrey
                            )
                        }

                        // Price and QR generate action
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "¥${String.format("%.2f", routeResult.estimatedFare)}",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                color = MetroGreen
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Box(
                                modifier = Modifier
                                    .background(MetroBlue, RoundedCornerShape(4.dp))
                                    .clickable { onGenerateTicket(routeResult) }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = if (isChinese) "申领票券" else "GET QR",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Divider(modifier = Modifier.padding(vertical = 12.dp))

                    // Best Carriage (19 — BEST CARRIAGE recommendation based on system variables)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MetroBlue.copy(alpha = 0.08f), RoundedCornerShape(6.dp))
                            .padding(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Train, contentDescription = "Carriage", tint = MetroBlue, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isChinese) {
                                    "【智能车厢建议】请乘坐：第 4 节车厢 / 靠近 A2 门。下车后：向前步行10米即可直达换乘梯。"
                                } else {
                                    "[Carriage Tip] Board Carriage #4 / Door A2. Upon arrival, walk forward 10m directly to transfer escalators."
                                },
                                fontSize = 11.sp,
                                color = MetroBlue,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Timeline steps
                    LazyColumn(modifier = Modifier.weight(1f)) {
                        items(routeResult.timelineSteps) { step ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Text(
                                    text = step.timeString,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = CoolGrey,
                                    modifier = Modifier.width(55.dp)
                                )
                                Box(
                                    modifier = Modifier
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                        .size(8.dp)
                                        .background(MetroBlue, CircleShape)
                                )
                                Text(
                                    text = if (isChinese) step.textZh else step.textEn,
                                    fontSize = 12.sp,
                                    color = TextDark,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }
        } else {
            // No selection prompt
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isChinese) "请选择上方不同的起点与终点开始计算路线" else "Select a starting station and destination to compute route",
                    fontSize = 13.sp,
                    color = CoolGrey,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

// ==========================================
// 3. SCHEMATIC METRO MAP VIEW
// ==========================================
@Composable
fun NetworkMapView(
    engine: MetroSimulationEngine,
    isChinese: Boolean
) {
    var mapLayer by remember { mutableStateOf("SYSTEM") } // "SYSTEM", "GEOGRAPHIC", "LIVE"
    val liveTrainsState = engine.liveTrains.collectAsState().value

    Column(modifier = Modifier.fillMaxSize()) {
        // Toggle Map mode layers
        TabRow(
            selectedTabIndex = when (mapLayer) {
                "SYSTEM" -> 0
                "GEOGRAPHIC" -> 1
                "LIVE" -> 2
                else -> 0
            },
            containerColor = LightSurface
        ) {
            Tab(selected = mapLayer == "SYSTEM", onClick = { mapLayer = "SYSTEM" }) {
                Text(if (isChinese) "原理拓扑" else "SYSTEM MAP", modifier = Modifier.padding(10.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Tab(selected = mapLayer == "GEOGRAPHIC", onClick = { mapLayer = "GEOGRAPHIC" }) {
                Text(if (isChinese) "地理江河" else "GEOGRAPHIC", modifier = Modifier.padding(10.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Tab(selected = mapLayer == "LIVE", onClick = { mapLayer = "LIVE" }) {
                Text(if (isChinese) "实时客列" else "LIVE TRAINS", modifier = Modifier.padding(10.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(if (mapLayer == "GEOGRAPHIC") Color(0xFFE3E9F0) else Color.White)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height

                // Draw Huangpu River in GEOGRAPHIC and LIVE mode
                if (mapLayer != "SYSTEM") {
                    val riverColor = Color(0xFFADC4DC)
                    // Draw a curving line representing Shanghai's iconic Huangpu River
                    val path = androidx.compose.ui.graphics.Path().apply {
                        moveTo(w * 0.1f, h * 0.9f)
                        cubicTo(w * 0.35f, h * 0.8f, w * 0.35f, h * 0.45f, w * 0.48f, h * 0.45f)
                        cubicTo(w * 0.6f, h * 0.45f, w * 0.7f, h * 0.25f, w * 0.9f, h * 0.1f)
                    }
                    drawPath(path, color = riverColor, style = Stroke(width = 30.dp.toPx()))

                    // Draw geographical labels
                    // Puxi
                    val nativeCanvas = drawContext.canvas.nativeCanvas as android.graphics.Canvas
                    nativeCanvas.apply {
                        val textPaint = android.graphics.Paint().apply {
                            color = android.graphics.Color.GRAY
                            textSize = 34f
                            isFakeBoldText = true
                        }
                        drawText(if (isChinese) "浦西 Puxi" else "Puxi", w * 0.25f, h * 0.35f, textPaint)
                        drawText(if (isChinese) "浦东新区 Pudong" else "Pudong", w * 0.65f, h * 0.60f, textPaint)
                    }
                }

                // 1. Draw Metro lines (Line 1 Red, Line 2 Green, Line 10 Purple)
                // We'll draw them as solid polyline colors
                val l2Color = Color(0xFF009639)
                val l1Color = Color(0xFFC8102E)
                val l10Color = Color(0xFF512888)

                // Define station coord scaling
                fun getCoords(stationId: String): Offset {
                    val st = engine.stations[stationId] ?: return Offset(0f, 0f)
                    return Offset(st.coordX * w, st.coordY * h)
                }

                // Draw Line 1 tracks
                val l1Stations = engine.lines["Line1"]?.stations ?: emptyList()
                for (i in 0 until l1Stations.size - 1) {
                    drawLine(
                        color = l1Color,
                        start = getCoords(l1Stations[i]),
                        end = getCoords(l1Stations[i+1]),
                        strokeWidth = 6.dp.toPx()
                    )
                }

                // Draw Line 2 tracks
                val l2Stations = engine.lines["Line2"]?.stations ?: emptyList()
                for (i in 0 until l2Stations.size - 1) {
                    drawLine(
                        color = l2Color,
                        start = getCoords(l2Stations[i]),
                        end = getCoords(l2Stations[i+1]),
                        strokeWidth = 6.dp.toPx()
                    )
                }

                // Draw Line 10 tracks
                val l10Stations = engine.lines["Line10"]?.stations ?: emptyList()
                for (i in 0 until l10Stations.size - 1) {
                    drawLine(
                        color = l10Color,
                        start = getCoords(l10Stations[i]),
                        end = getCoords(l10Stations[i+1]),
                        strokeWidth = 6.dp.toPx()
                    )
                }

                // 2. Draw Station Nodes
                engine.stations.values.forEach { station ->
                    val offset = Offset(station.coordX * w, station.coordY * h)

                    // Draw interchange outer ring
                    if (station.isInterchange) {
                        drawCircle(
                            color = Color.Black,
                            radius = 10.dp.toPx(),
                            center = offset
                        )
                        drawCircle(
                            color = Color.White,
                            radius = 7.dp.toPx(),
                            center = offset
                        )
                    } else {
                        // Single station
                        val lineId = station.lines.firstOrNull() ?: "Line2"
                        val nodeColor = if (lineId == "Line2") l2Color else if (lineId == "Line1") l1Color else l10Color
                        drawCircle(
                            color = nodeColor,
                            radius = 6.dp.toPx(),
                            center = offset
                        )
                        drawCircle(
                            color = Color.White,
                            radius = 3.dp.toPx(),
                            center = offset
                        )
                    }

                    // Labels
                    val nativeCanvas = drawContext.canvas.nativeCanvas as android.graphics.Canvas
                    nativeCanvas.apply {
                        val paint = android.graphics.Paint().apply {
                            color = android.graphics.Color.BLACK
                            textSize = 28f
                            textAlign = android.graphics.Paint.Align.CENTER
                        }
                        drawText(station.nameZh, offset.x, offset.y - 14.dp.toPx(), paint)
                    }
                }

                // 3. Draw live simulated trains in LIVE mode (Animate points!)
                if (mapLayer == "LIVE") {
                    liveTrainsState.forEach { train ->
                        val curSt = engine.stations[train.currentStationId]
                        val nextSt = engine.stations[train.nextStationId ?: ""]
                        if (curSt != null) {
                            val trainPos = if (nextSt != null) {
                                val cx = curSt.coordX + (nextSt.coordX - curSt.coordX) * train.positionRatio
                                val cy = curSt.coordY + (nextSt.coordY - curSt.coordY) * train.positionRatio
                                Offset(cx * w, cy * h)
                            } else {
                                Offset(curSt.coordX * w, curSt.coordY * h)
                            }

                            // Pulsing indicator for train
                            drawCircle(
                                color = Color.Yellow,
                                radius = 9.dp.toPx(),
                                center = trainPos
                            )
                            drawCircle(
                                color = if (train.lineId == "Line2") l2Color else l1Color,
                                radius = 6.dp.toPx(),
                                center = trainPos
                            )

                            // Render little train indicator label
                            val nativeCanvas = drawContext.canvas.nativeCanvas as android.graphics.Canvas
                            nativeCanvas.apply {
                                val labelPaint = android.graphics.Paint().apply {
                                    color = android.graphics.Color.parseColor("#0A2540")
                                    textSize = 24f
                                    isFakeBoldText = true
                                }
                                drawText("ID:${train.id.substringAfter("-")}", trainPos.x, trainPos.y + 16.dp.toPx() + 6f, labelPaint)
                            }
                        }
                    }
                }
            }

            // Floating Legends Overlay
            Card(
                modifier = Modifier
                    .padding(12.dp)
                    .align(Alignment.BottomStart)
                    .width(200.dp),
                colors = CardDefaults.cardColors(containerColor = LightSurface.copy(alpha = 0.9f))
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(if (isChinese) "上海地铁线路网" else "Lines Legend", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextDark)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(12.dp, 4.dp).background(Color(0xFFC8102E)))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("1号线 (上海南站 - 上海站)", fontSize = 9.sp)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(12.dp, 4.dp).background(Color(0xFF009639)))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("2号线 (虹桥 - 浦东机场)", fontSize = 9.sp)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(12.dp, 4.dp).background(Color(0xFF512888)))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("10号线 (虹桥 - 南京东路)", fontSize = 9.sp)
                    }

                    if (mapLayer == "LIVE") {
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(8.dp).background(Color.Yellow, CircleShape))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (isChinese) "模拟实时移动列车" else "Simulated live trains", fontSize = 9.sp, color = MetroBlue, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 4. STATIONS TAB VIEW
// ==========================================
@Composable
fun StationsView(
    engine: MetroSimulationEngine,
    isChinese: Boolean,
    onNavigateToTwin: (String) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val filteredStations = if (query.isEmpty()) {
        engine.stations.values.toList()
    } else {
        engine.stations.values.filter {
            it.nameZh.contains(query) || it.nameEn.contains(query, ignoreCase = true)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().testTag("station_search_field"),
            placeholder = { Text(if (isChinese) "全局路网搜索 (车站、车次、出口)" else "Search metro network...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
            shape = RoundedCornerShape(8.dp),
            colors = TextFieldDefaults.colors(focusedContainerColor = LightSurface, unfocusedContainerColor = LightSurface)
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = if (isChinese) "全线站点数: ${filteredStations.size}" else "Stations Listed: ${filteredStations.size}",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = CoolGrey,
            modifier = Modifier.padding(bottom = 6.dp)
        )

        LazyColumn(modifier = Modifier.weight(1f)) {
            items(filteredStations) { station ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = LightSurface)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(station.nameZh, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = TextDark)
                                Text(station.nameEn, fontSize = 11.sp, color = CoolGrey)
                            }

                            // Twin Button
                            Box(
                                modifier = Modifier
                                    .background(MetroBlue.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                                    .clickable { onNavigateToTwin(station.id) }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = if (isChinese) "车站数字孪生 ➔" else "Digital Twin ➔",
                                    color = MetroBlue,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Routes connected
                        Row {
                            station.lines.forEach { lineId ->
                                val label = if (lineId == "Line2") "2号线" else if (lineId == "Line1") "1号线" else "10号线"
                                val color = if (lineId == "Line2") MetroGreen else if (lineId == "Line1") MetroRed else MetroPurple
                                Box(
                                    modifier = Modifier
                                        .padding(end = 4.dp)
                                        .background(color, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(label, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        // Exit guides summary
                        if (station.exits.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (isChinese) {
                                    "常用出口：出入口A可达 ${station.exits.first().nearbyZh}"
                                } else {
                                    "Main Exit A leads to: ${station.exits.first().nearbyEn}"
                                },
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 5. TICKETS, CARDS & ACCOUNT TAB VIEW
// ==========================================
@Composable
fun TicketsAndCardView(
    engine: MetroSimulationEngine,
    isChinese: Boolean,
    simulatedTicket: Ticket?,
    simulatedRideStep: String,
    onProgressRide: (String) -> Unit
) {
    val cardState = engine.digitalCard.collectAsState().value

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Electronic Transport Card Face
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                colors = CardDefaults.cardColors(containerColor = Graphite),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = if (isChinese) "上海公共交通卡" else "Shanghai Public Transport Card",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "MetroOS Digital Token Card",
                                color = CoolGrey,
                                fontSize = 10.sp
                            )
                        }
                        Icon(Icons.Default.Nfc, contentDescription = "NFC", tint = Color.White, modifier = Modifier.size(24.dp))
                    }

                    Spacer(modifier = Modifier.height(30.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Column {
                            Text(
                                text = if (isChinese) "余额 BALANCE" else "BALANCE",
                                color = CoolGrey,
                                fontSize = 10.sp
                            )
                            Text(
                                text = "¥${String.format("%.2f", cardState.balance)}",
                                color = Color.White,
                                fontSize = 32.sp,
                                fontWeight = FontWeight.Black
                            )
                        }

                        // Top-up buttons (33 — top-up, 30 — payments)
                        Button(
                            onClick = {
                                engine.digitalCard.value = cardState.copy(balance = cardState.balance + 20.0)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MetroBlue),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("+¥20", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(cardState.cardNumber, color = CoolGrey, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Active Ticket Simulation Controller (32 — JOURNEY PAYMENT: Swipe in, Ride, Swipe out, receipt!)
        if (simulatedTicket != null) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = LightSurface),
                    border = BorderStroke(1.5.dp, MetroBlue)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = if (isChinese) "🎟️ 正在进行的行程" else "🎟️ Active Journey Simulation",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MetroBlue
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (isChinese) {
                                "起点：${engine.stations[simulatedTicket.startStationId]?.nameZh} ➔ 终点：${engine.stations[simulatedTicket.endStationId]?.nameZh}"
                            } else {
                                "Route: ${engine.stations[simulatedTicket.startStationId]?.nameEn} ➔ ${engine.stations[simulatedTicket.endStationId]?.nameEn}"
                            },
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Ticket ID: ${simulatedTicket.id} | Status: $simulatedRideStep",
                            fontSize = 11.sp,
                            color = CoolGrey
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Simulation Step Actions
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            when (simulatedRideStep) {
                                "ACTIVE_READY_TO_ENTER" -> {
                                    Button(
                                        onClick = { onProgressRide("SWIPED_IN") },
                                        colors = ButtonDefaults.buttonColors(containerColor = MetroGreen),
                                        modifier = Modifier.fillMaxWidth().testTag("swipe_in_button")
                                    ) {
                                        Text(if (isChinese) "1. 扫码进站 [人民广场]" else "1. Tap In [People's Square]")
                                    }
                                }
                                "SWIPED_IN" -> {
                                    Button(
                                        onClick = { onProgressRide("ARRIVED") },
                                        colors = ButtonDefaults.buttonColors(containerColor = MetroBlue),
                                        modifier = Modifier.fillMaxWidth().testTag("board_train_button")
                                    ) {
                                        Text(if (isChinese) "2. 乘车并到达目的站" else "2. Ride & Arrive at Destination")
                                    }
                                }
                                "ARRIVED" -> {
                                    Button(
                                        onClick = { onProgressRide("SWIPED_OUT") },
                                        colors = ButtonDefaults.buttonColors(containerColor = MetroRed),
                                        modifier = Modifier.fillMaxWidth().testTag("swipe_out_button")
                                    ) {
                                        Text(if (isChinese) "3. 扫码出站结算" else "3. Tap Out & Pay Fare")
                                    }
                                }
                                "SWIPED_OUT" -> {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(MetroGreen.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                                            .padding(10.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = if (isChinese) "✓ 行程完成并成功扣款 ¥${simulatedTicket.actualFare}！" else "✓ Journey settled successfully. Paid ¥${simulatedTicket.actualFare}!",
                                            color = MetroGreen,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Historic Ledger
        item {
            Text(
                text = if (isChinese) "近期出行账单" else "RECENT TRANSACTIONS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = CoolGrey,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        items(cardState.transactions) { tx ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = LightSurface)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "${tx.startStationZh} ➔ ${tx.endStationZh}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = TextDark
                        )
                        val date = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.CHINA).format(Date(tx.timestamp))
                        Text(date, fontSize = 10.sp, color = CoolGrey)
                    }

                    Text(
                        "-¥${String.format("%.2f", tx.amount)}",
                        fontWeight = FontWeight.Black,
                        color = MetroRed,
                        fontSize = 15.sp
                    )
                }
            }
        }
    }
}
