package com.example.engine

import com.example.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*

class MetroSimulationEngine {

    // ==========================================
    // STATIC DATA INITIALIZATION
    // ==========================================

    val stations = mutableMapOf<String, Station>()
    val lines = mutableMapOf<String, MetroLine>()
    val edges = mutableListOf<GraphEdge>()

    // State flows for reactive updates
    private val _liveTrains = MutableStateFlow<List<LiveTrain>>(emptyList())
    val liveTrains: StateFlow<List<LiveTrain>> = _liveTrains.asStateFlow()

    private val _disruptions = MutableStateFlow<List<ServiceDisruption>>(emptyList())
    val disruptions: StateFlow<List<ServiceDisruption>> = _disruptions.asStateFlow()

    private val _assets = MutableStateFlow<List<MetroAsset>>(emptyList())
    val assets: StateFlow<List<MetroAsset>> = _assets.asStateFlow()

    private val _powerStations = MutableStateFlow<List<PowerSubstation>>(emptyList())
    val powerStations: StateFlow<List<PowerSubstation>> = _powerStations.asStateFlow()

    private val _events = MutableStateFlow<List<MetroEvent>>(emptyList())
    val events: StateFlow<List<MetroEvent>> = _events.asStateFlow()

    // Simulation parameters
    val isPeakMode = MutableStateFlow(false) // Peak mode: early morning rush
    val isDisruptionActive = MutableStateFlow(false) // Disruption simulated in Line 2

    // Simulated Account
    val digitalCard = MutableStateFlow(
        DigitalCard(
            cardNumber = "SH9028-4019-11",
            balance = 50.0,
            couponCount = 2,
            transactions = listOf(
                PaymentTransaction("TX-99812", System.currentTimeMillis() - 86400000, 4.0, "南京东路", "静安寺", "SUCCESS"),
                PaymentTransaction("TX-99741", System.currentTimeMillis() - 172800000, 3.0, "人民广场", "徐泾东", "SUCCESS")
            )
        )
    )

    init {
        initializeStaticNetwork()
        initializeSimulatedAssets()
        initializeSimulatedPower()
        startSimulationLoop()
    }

    private fun initializeStaticNetwork() {
        // Line 1: Red Line
        val line1Stations = listOf(
            "SH_SOUTH_RAIL", // 上海南站
            "XUJIAHUI",      // 徐家汇
            "PEOPLES_SQUARE",// 人民广场
            "SH_RAIL_STN"    // 上海火车站
        )
        lines["Line1"] = MetroLine(
            id = "Line1",
            nameZh = "1号线",
            nameEn = "Line 1",
            colorHex = "#FF0000",
            stations = line1Stations,
            intervalSeconds = 150,
            averageSpeedKmh = 50,
            activeTrainsCount = 8
        )

        // Line 2: Green Line (Primary Demonstration Trunk)
        val line2Stations = listOf(
            "HQ_RAIL_STN",   // 虹桥火车站
            "HQ_AIRPORT_T2", // 虹桥2号航站楼
            "NANJING_WEST",  // 南京西路
            "PEOPLES_SQUARE",// 人民广场
            "NANJING_EAST",  // 南京东路
            "LUJIAZUI",      // 陆家嘴
            "CENTURY_AVE",   // 世纪大道
            "LONGYANG_ROAD", // 龙阳路
            "PVG_AIRPORT"    // 浦东国际机场
        )
        lines["Line2"] = MetroLine(
            id = "Line2",
            nameZh = "2号线",
            nameEn = "Line 2",
            colorHex = "#009639",
            stations = line2Stations,
            intervalSeconds = 120,
            averageSpeedKmh = 60,
            activeTrainsCount = 14
        )

        // Line 10: Lilac Purple Line
        val line10Stations = listOf(
            "HQ_RAIL_STN",   // 虹桥火车站
            "HQ_AIRPORT_T2", // 虹桥2号航站楼
            "XINTIANDI",     // 新天地
            "YUYUAN",        // 豫园
            "NANJING_EAST"   // 南京东路
        )
        lines["Line10"] = MetroLine(
            id = "Line10",
            nameZh = "10号线",
            nameEn = "Line 10",
            colorHex = "#512888",
            stations = line10Stations,
            intervalSeconds = 180,
            averageSpeedKmh = 45,
            activeTrainsCount = 6
        )

        // Create Stations
        val peoplesSquareExits = listOf(
            StationExit("A", "上海博物馆, 人民大道路", "Shanghai Museum, Renmin Avenue", true, "49路, 123路, 451路", "Bus 49, 123, 451", 80),
            StationExit("B", "南京路步行街, 市民广场", "Nanjing Road Pedestrian St, Civic Square", false, "20路, 37路", "Bus 20, 37", 120),
            StationExit("C", "来福士广场, 西藏中路", "Raffles City, Tibet Middle Rd", true, "18路, 537路", "Bus 18, 537", 100),
            StationExit("D", "上海大剧院, 黄陂北路", "Shanghai Grand Theatre, Huangpi N Rd", false, "109路, 921路", "Bus 109, 921", 150)
        )
        stations["PEOPLES_SQUARE"] = Station(
            id = "PEOPLES_SQUARE", nameZh = "人民广场", nameEn = "People's Square",
            district = "Huangpu", isInterchange = true, lines = listOf("Line1", "Line2"),
            exits = peoplesSquareExits,
            coordX = 0.42f, coordY = 0.45f,
            facilities = listOf(
                StationFacility("PS-L1", FacilityType.LIFT, "1号线站台至站厅", "L1 Platform to Concourse", true),
                StationFacility("PS-E1", FacilityType.ESCALATOR, "站厅至2号线站台", "Concourse to L2 Platform", true),
                StationFacility("PS-G1", FacilityType.FARE_GATES, "西侧闸机区", "West Fare Gate Area", true)
            )
        )

        stations["LUJIAZUI"] = Station(
            id = "LUJIAZUI", nameZh = "陆家嘴", nameEn = "Lujiazui",
            district = "Pudong New Area", isInterchange = false, lines = listOf("Line2"),
            coordX = 0.52f, coordY = 0.41f,
            exits = listOf(
                StationExit("A", "东方明珠, 世纪大道", "Oriental Pearl Tower, Century Ave", true, "81路, 陆家嘴金融城1路", "Bus 81, Lujiazui Financial City 1", 90),
                StationExit("B", "国金中心(IFC), 上海中心", "IFC Mall, Shanghai Tower", false, "583路, 961路", "Bus 583, 961", 110)
            ),
            facilities = listOf(
                StationFacility("LJZ-L1", FacilityType.LIFT, "2号线站厅至1号口", "L2 Concourse to Exit 1", true),
                StationFacility("LJZ-E1", FacilityType.ESCALATOR, "站台至站厅", "Platform to Concourse", true)
            )
        )

        stations["CENTURY_AVE"] = Station(
            id = "CENTURY_AVE", nameZh = "世纪大道", nameEn = "Century Avenue",
            district = "Pudong New Area", isInterchange = true, lines = listOf("Line2"),
            coordX = 0.61f, coordY = 0.45f,
            exits = listOf(
                StationExit("A", "世纪汇广场, 东方路", "Century Link Mall, Dongfang Rd", true, "130路, 583路", "Bus 130, 583", 75),
                StationExit("B", "百联世纪购物中心", "Bailian Century Mall", true, "775路, 987路", "Bus 775, 987", 95)
            ),
            facilities = listOf(
                StationFacility("CA-L1", FacilityType.LIFT, "换乘通道A区升降梯", "Transfer Passage Area A Lift", true),
                StationFacility("CA-E1", FacilityType.ESCALATOR, "A区自动扶梯", "Area A Escalator", true)
            )
        )

        stations["PVG_AIRPORT"] = Station(
            id = "PVG_AIRPORT", nameZh = "浦东国际机场", nameEn = "Pudong Airport",
            district = "Pudong New Area", isInterchange = false, lines = listOf("Line2"),
            coordX = 0.90f, coordY = 0.75f,
            exits = listOf(
                StationExit("1", "T1航站楼, 国际出发/到达", "Terminal 1, Int'l Departures/Arrivals", true, "机场一线, 机场八线", "Airport Bus 1, Airport Bus 8", 120),
                StationExit("2", "T2航站楼, 国内出发/到达", "Terminal 2, Domestic Departures/Arrivals", true, "机场二线, 机场七线", "Airport Bus 2, Airport Bus 7", 110)
            ),
            facilities = listOf(
                StationFacility("PVG-L1", FacilityType.LIFT, "T1航站楼连廊直梯", "T1 Connector Lift", true),
                StationFacility("PVG-E1", FacilityType.ESCALATOR, "磁悬浮换乘厅扶梯", "Maglev Transfer Escalator", true)
            )
        )

        stations["HQ_RAIL_STN"] = Station(
            id = "HQ_RAIL_STN", nameZh = "虹桥火车站", nameEn = "Hongqiao Railway",
            district = "Minhang", isInterchange = true, lines = listOf("Line2", "Line10"),
            coordX = 0.12f, coordY = 0.45f,
            exits = listOf(
                StationExit("A", "高铁候车厅, 进站口2", "High-speed Rail Waiting Hall, Entrance 2", true, "虹桥枢纽1路, 虹桥枢纽5路", "Hongqiao Hub Bus 1, Bus 5", 60),
                StationExit("B", "西广场, 公交枢纽", "West Plaza, Bus Interchange", false, "虹桥枢纽4路, 虹桥枢纽10路", "Hongqiao Hub Bus 4, Bus 10", 90)
            ),
            facilities = listOf(
                StationFacility("HQR-L1", FacilityType.LIFT, "地下一层直通高铁出站口", "B1 Direct Lift to HSR Exit", true),
                StationFacility("HQR-E1", FacilityType.ESCALATOR, "站厅至地铁站台", "Concourse to Metro Platform", true)
            )
        )

        stations["NANJING_WEST"] = Station(
            id = "NANJING_WEST", nameZh = "南京西路", nameEn = "Nanjing West Road",
            district = "Jing'an", isInterchange = false, lines = listOf("Line2"),
            coordX = 0.32f, coordY = 0.45f,
            exits = listOf(StationExit("A", "兴业太古汇, 石门一路", "HKRI Taikoo Hui, Shimen 1st Rd", true, "20路, 112路", "Bus 20, 112", 80)),
            facilities = emptyList()
        )

        stations["NANJING_EAST"] = Station(
            id = "NANJING_EAST", nameZh = "南京东路", nameEn = "Nanjing East Road",
            district = "Huangpu", isInterchange = true, lines = listOf("Line2", "Line10"),
            coordX = 0.47f, coordY = 0.43f,
            exits = listOf(StationExit("1", "南京路步行街, 外滩", "Nanjing Rd Pedestrian St, The Bund", true, "220路", "Bus 220", 110)),
            facilities = emptyList()
        )

        stations["HQ_AIRPORT_T2"] = Station(
            id = "HQ_AIRPORT_T2", nameZh = "虹桥2号航站楼", nameEn = "Hongqiao Airport T2",
            district = "Minhang", isInterchange = true, lines = listOf("Line2", "Line10"),
            coordX = 0.17f, coordY = 0.45f,
            exits = listOf(StationExit("A", "T2出发大厅", "T2 Departures Lobby", true, "机场专线", "Airport Shuttle", 70)),
            facilities = emptyList()
        )

        stations["LONGYANG_ROAD"] = Station(
            id = "LONGYANG_ROAD", nameZh = "龙阳路", nameEn = "Longyang Road",
            district = "Pudong New Area", isInterchange = true, lines = listOf("Line2"),
            coordX = 0.73f, coordY = 0.55f,
            exits = listOf(StationExit("1", "新国际博览中心, 磁浮站", "SNIEC, Maglev Station", true, "龙大专线", "Long-Da Shuttle", 100)),
            facilities = emptyList()
        )

        stations["SH_SOUTH_RAIL"] = Station(
            id = "SH_SOUTH_RAIL", nameZh = "上海南站", nameEn = "Shanghai South Railway",
            district = "Xuhui", isInterchange = false, lines = listOf("Line1"),
            coordX = 0.25f, coordY = 0.72f,
            exits = listOf(StationExit("1", "南广场, 南方客运站", "South Plaza, South Bus Terminal", true, "144路, 973路", "Bus 144, 973", 90)),
            facilities = emptyList()
        )

        stations["XUJIAHUI"] = Station(
            id = "XUJIAHUI", nameZh = "徐家汇", nameEn = "Xujiahui",
            district = "Xuhui", isInterchange = false, lines = listOf("Line1"),
            coordX = 0.30f, coordY = 0.62f,
            exits = listOf(StationExit("1", "美罗城, 肇嘉浜路", "Metro City, Zhaojiabang Rd", true, "43路, 926路", "Bus 43, 926", 110)),
            facilities = emptyList()
        )

        stations["SH_RAIL_STN"] = Station(
            id = "SH_RAIL_STN", nameZh = "上海火车站", nameEn = "Shanghai Railway Station",
            district = "Jing'an", isInterchange = false, lines = listOf("Line1"),
            coordX = 0.42f, coordY = 0.32f,
            exits = listOf(StationExit("1", "北广场候车室", "North Plaza Waiting Room", true, "305路", "Bus 305", 80)),
            facilities = emptyList()
        )

        stations["XINTIANDI"] = Station(
            id = "XINTIANDI", nameZh = "新天地", nameEn = "Xintiandi",
            district = "Huangpu", isInterchange = false, lines = listOf("Line10"),
            coordX = 0.38f, coordY = 0.52f,
            exits = listOf(StationExit("1", "新天地时尚, 马当路", "Xintiandi Style, Madang Rd", true, "146路", "Bus 146", 70)),
            facilities = emptyList()
        )

        stations["YUYUAN"] = Station(
            id = "YUYUAN", nameZh = "豫园", nameEn = "Yuyuan Garden",
            district = "Huangpu", isInterchange = false, lines = listOf("Line10"),
            coordX = 0.45f, coordY = 0.50f,
            exits = listOf(StationExit("1", "豫园商城, 城隍庙", "Yuyuan Bazaar, City God Temple", true, "11路, 930路", "Bus 11, 930", 120)),
            facilities = emptyList()
        )

        // Build Graph Edges
        // Rail tracks between sequential stations (Line 1)
        addBidirectionalRailEdge("SH_SOUTH_RAIL", "XUJIAHUI", "Line1", 180.0)
        addBidirectionalRailEdge("XUJIAHUI", "PEOPLES_SQUARE", "Line1", 240.0)
        addBidirectionalRailEdge("PEOPLES_SQUARE", "SH_RAIL_STN", "Line1", 150.0)

        // Rail tracks between sequential stations (Line 2)
        addBidirectionalRailEdge("HQ_RAIL_STN", "HQ_AIRPORT_T2", "Line2", 90.0)
        addBidirectionalRailEdge("HQ_AIRPORT_T2", "NANJING_WEST", "Line2", 300.0)
        addBidirectionalRailEdge("NANJING_WEST", "PEOPLES_SQUARE", "Line2", 120.0)
        addBidirectionalRailEdge("PEOPLES_SQUARE", "NANJING_EAST", "Line2", 100.0)
        addBidirectionalRailEdge("NANJING_EAST", "LUJIAZUI", "Line2", 110.0)
        addBidirectionalRailEdge("LUJIAZUI", "CENTURY_AVE", "Line2", 130.0)
        addBidirectionalRailEdge("CENTURY_AVE", "LONGYANG_ROAD", "Line2", 180.0)
        addBidirectionalRailEdge("LONGYANG_ROAD", "PVG_AIRPORT", "Line2", 600.0) // Airport long-haul Express

        // Rail tracks between sequential stations (Line 10)
        addBidirectionalRailEdge("HQ_RAIL_STN", "HQ_AIRPORT_T2", "Line10", 95.0)
        addBidirectionalRailEdge("HQ_AIRPORT_T2", "XINTIANDI", "Line10", 280.0)
        addBidirectionalRailEdge("XINTIANDI", "YUYUAN", "Line10", 140.0)
        addBidirectionalRailEdge("YUYUAN", "NANJING_EAST", "Line10", 100.0)

        // Interchange transfers
        // People's Square Line 1 <-> Line 2
        edges.add(GraphEdge("PEOPLES_SQUARE", "PEOPLES_SQUARE", EdgeType.TRANSFER, 180.0)) // 3 minutes transfer penalty
        // Nanjing East Road Line 2 <-> Line 10
        edges.add(GraphEdge("NANJING_EAST", "NANJING_EAST", EdgeType.TRANSFER, 210.0))
        // Hongqiao Railway Station Line 2 <-> Line 10 (Virtual Cross Platform)
        edges.add(GraphEdge("HQ_RAIL_STN", "HQ_RAIL_STN", EdgeType.TRANSFER, 60.0)) // Easy 1 min transfer
        // Hongqiao Airport T2 Line 2 <-> Line 10
        edges.add(GraphEdge("HQ_AIRPORT_T2", "HQ_AIRPORT_T2", EdgeType.TRANSFER, 150.0))
    }

    private fun addBidirectionalRailEdge(from: String, to: String, lineId: String, weight: Double) {
        edges.add(GraphEdge(from, to, EdgeType.RAIL, weight, lineId))
        edges.add(GraphEdge(to, from, EdgeType.RAIL, weight, lineId))
    }

    private fun initializeSimulatedAssets() {
        val list = listOf(
            MetroAsset("AST-02047", AssetType.TRAIN_VEHICLE, "2号线2047号车厢", "L2 Car #2047", 96, 24.2f, 0.4f, 4210, 0, "2026-08-01", "2026-10-01", "LOW"),
            MetroAsset("AST-02058", AssetType.TRAIN_VEHICLE, "2号线2058号车厢", "L2 Car #2058", 81, 28.5f, 1.2f, 7850, 2, "2026-07-15", "2026-09-28", "MEDIUM"),
            MetroAsset("AST-TK002", AssetType.TICKET_GATE, "人民广场西侧闸机02", "People's Square Gate #02", 94, 21.0f, 0.0f, 15000, 1, "2026-09-01", "2026-12-01", "LOW"),
            MetroAsset("AST-ES044", AssetType.ESCALATOR, "陆家嘴2号口扶梯", "Lujiazui Exit 2 Escalator", 42, 45.1f, 4.8f, 9800, 12, "2026-05-10", "2026-09-20", "HIGH"),
            MetroAsset("AST-LF109", AssetType.LIFT, "人民广场1号线无障碍电梯", "People's Square L1 Elevator", 98, 22.1f, 0.1f, 3400, 0, "2026-09-10", "2026-11-10", "LOW"),
            MetroAsset("AST-TS201", AssetType.TRACTION_SUBSTATION, "静安寺牵引电站01", "Jing'an Traction Sub #01", 89, 41.5f, 2.1f, 19200, 3, "2026-08-20", "2026-11-20", "LOW"),
            MetroAsset("AST-SG302", AssetType.SIGNAL_LIGHT, "陆家嘴-世纪大道区间信号器04", "LJZ-CA Track Signal #04", 65, 38.2f, 3.1f, 11400, 5, "2026-07-10", "2026-10-10", "MEDIUM")
        )
        _assets.value = list
    }

    private fun initializeSimulatedPower() {
        val list = listOf(
            PowerSubstation("SUB-01", "黄浦牵引变电站", "Huangpu Traction Substation", 14.2, 3421.0, 110.0, 129.0, "NORMAL"),
            PowerSubstation("SUB-02", "静安开闭所", "Jing'an Switching Station", 8.4, 1845.0, 35.0, 240.0, "NORMAL"),
            PowerSubstation("SUB-03", "陆家嘴智能变电站", "Lujiazui Intelligent Substation", 22.8, 5110.0, 110.0, 207.0, "HIGH_LOAD"),
            PowerSubstation("SUB-04", "虹桥枢纽配电网", "Hongqiao Hub Power Network", 18.5, 4120.0, 110.0, 168.0, "NORMAL")
        )
        _powerStations.value = list
    }

    // ==========================================
    // TRAIN DYNAMICS SIMULATION & EVENT STREAM
    // ==========================================

    private fun startSimulationLoop() {
        // Core background routine to animate trains, simulate peaks, power, and disruptions.
        CoroutineScope(Dispatchers.Default).launch {
            // Seed initial train positions along lines
            val simulatedTrains = mutableListOf<LiveTrain>()

            // Line 2 trains: 6 trains
            val l2Sec = listOf("HQ_RAIL_STN", "HQ_AIRPORT_T2", "NANJING_WEST", "PEOPLES_SQUARE", "NANJING_EAST", "LUJIAZUI", "CENTURY_AVE", "LONGYANG_ROAD", "PVG_AIRPORT")
            simulatedTrains.add(LiveTrain("L2-01", "Line2", "浦东国际机场", "PVG Airport", "PEOPLES_SQUARE", "NANJING_EAST", 52, 0.4f))
            simulatedTrains.add(LiveTrain("L2-02", "Line2", "虹桥火车站", "HQ Railway", "CENTURY_AVE", "LUJIAZUI", 48, 0.8f))
            simulatedTrains.add(LiveTrain("L2-03", "Line2", "浦东国际机场", "PVG Airport", "LUJIAZUI", "CENTURY_AVE", 62, 0.1f))
            simulatedTrains.add(LiveTrain("L2-04", "Line2", "虹桥火车站", "HQ Railway", "HQ_AIRPORT_T2", "HQ_RAIL_STN", 35, 0.7f))
            simulatedTrains.add(LiveTrain("L2-05", "Line2", "浦东国际机场", "PVG Airport", "LONGYANG_ROAD", "PVG_AIRPORT", 80, 0.3f))

            // Line 1 trains: 3 trains
            val l1Sec = listOf("SH_SOUTH_RAIL", "XUJIAHUI", "PEOPLES_SQUARE", "SH_RAIL_STN")
            simulatedTrains.add(LiveTrain("L1-01", "Line1", "上海火车站", "SH Railway", "XUJIAHUI", "PEOPLES_SQUARE", 45, 0.6f))
            simulatedTrains.add(LiveTrain("L1-02", "Line1", "上海南站", "SH South Railway", "PEOPLES_SQUARE", "XUJIAHUI", 0, 0.0f, TrainStatus.NORMAL, 0, listOf(CrowdingLevel.HIGH, CrowdingLevel.HIGH, CrowdingLevel.MEDIUM), TrainRunMode.DWELLING))

            _liveTrains.value = simulatedTrains

            while (true) {
                delay(1500) // tick speed: every 1.5 seconds

                // 1. Simulate peak mode influences (crowding & load)
                val peakMultiplier = if (isPeakMode.value) 2.2 else 1.0

                // 2. Process active disruption impact on Line 2
                if (isDisruptionActive.value && _disruptions.value.isEmpty()) {
                    triggerSimulatedDisruption()
                } else if (!isDisruptionActive.value && _disruptions.value.isNotEmpty()) {
                    _disruptions.value = emptyList()
                    addEvent("disruption.resolved", "Line2", "Line 2 disruption resolved successfully.")
                }

                // 3. Move simulated trains
                val updatedTrains = _liveTrains.value.map { train ->
                    var speed = train.speedKmh
                    var ratio = train.positionRatio + 0.04f // increment progression
                    var current = train.currentStationId
                    var next = train.nextStationId
                    var status = train.status
                    var mode = train.runMode
                    var occupancy = train.occupancyList

                    val orderedStations = lines[train.lineId]?.stations ?: emptyList()
                    val totalStations = orderedStations.size

                    // Handle disruption slowing down trains between LUJIAZUI and CENTURY_AVE
                    if (isDisruptionActive.value && train.lineId == "Line2" &&
                        ((current == "LUJIAZUI" && next == "CENTURY_AVE") || (current == "CENTURY_AVE" && next == "LUJIAZUI"))) {
                        status = TrainStatus.DELAYED
                        speed = 12 // slow crawl
                        ratio = (train.positionRatio + 0.015f).coerceAtMost(0.99f) // slower progression
                        mode = TrainRunMode.BRAKING
                    } else {
                        // Regular train dynamics simulation: ACCEL -> CRUISE -> BRAKE -> DWELL
                        if (ratio >= 1.0f) {
                            // Arrived at next station! Let's swap stations
                            if (next != null) {
                                current = next
                                val curIdx = orderedStations.indexOf(current)
                                val forward = train.directionZh == orderedStations.lastOrNull()?.let { stations[it]?.nameZh }
                                val nextIdx = if (forward) curIdx + 1 else curIdx - 1

                                if (nextIdx in 0 until totalStations) {
                                    next = orderedStations[nextIdx]
                                    ratio = 0.0f
                                    speed = 0
                                    mode = TrainRunMode.DWELLING
                                } else {
                                    // Terminal station reached! Reverse direction
                                    val reverseForward = !forward
                                    val finalNextIdx = if (reverseForward) curIdx + 1 else curIdx - 1
                                    next = if (finalNextIdx in 0 until totalStations) orderedStations[finalNextIdx] else null
                                    ratio = 0.0f
                                    speed = 0
                                    val termStation = stations[current]
                                    val directionZh = orderedStations.let { list ->
                                        if (reverseForward) stations[list.last()]?.nameZh else stations[list.first()]?.nameZh
                                    } ?: "未知"
                                    val directionEn = orderedStations.let { list ->
                                        if (reverseForward) stations[list.last()]?.nameEn else stations[list.first()]?.nameEn
                                    } ?: "Unknown"

                                    addEvent("train.terminal_reversed", train.id, "Train ${train.id} reversed direction at terminal $current.")

                                    return@map train.copy(
                                        currentStationId = current,
                                        nextStationId = next,
                                        positionRatio = 0.0f,
                                        speedKmh = 0,
                                        directionZh = directionZh,
                                        directionEn = directionEn,
                                        runMode = TrainRunMode.DWELLING
                                    )
                                }
                            }
                        } else if (ratio < 0.15f) {
                            // Accelerating from station departure
                            mode = TrainRunMode.ACCELERATING
                            speed = (45 * (ratio / 0.15f)).toInt().coerceIn(10, 55)
                        } else if (ratio in 0.15f..0.85f) {
                            // Cruising at high speed
                            mode = TrainRunMode.CRUISING
                            speed = (55 + sin(ratio * PI) * 20).toInt() // typical metro cruise: 55-75 km/h
                        } else {
                            // Braking to enter station platform safely
                            mode = TrainRunMode.BRAKING
                            speed = (65 * ((1.0f - ratio) / 0.15f)).toInt().coerceIn(5, 35)
                        }
                    }

                    // Dynamically vary carriage-level crowding based on simulation parameters
                    if (occupancy.size == 5) {
                        val baseProb = if (isPeakMode.value) 2 else 0
                        occupancy = occupancy.map {
                            val roll = (0..10).random() + baseProb
                            when {
                                roll <= 3 -> CrowdingLevel.LOW
                                roll <= 6 -> CrowdingLevel.MEDIUM
                                roll <= 8 -> CrowdingLevel.HIGH
                                else -> CrowdingLevel.CRITICAL
                            }
                        }
                    }

                    train.copy(
                        currentStationId = current,
                        nextStationId = next,
                        positionRatio = ratio.coerceIn(0.0f, 1.0f),
                        speedKmh = speed,
                        status = status,
                        runMode = mode,
                        occupancyList = occupancy
                    )
                }
                _liveTrains.value = updatedTrains

                // 4. Update asset and power telemetry dynamically
                simulateAssetAndPowerFluctuations(peakMultiplier)
            }
        }
    }

    private fun triggerSimulatedDisruption() {
        val alert = ServiceDisruption(
            id = "DSP-2026-00127",
            lineId = "Line2",
            scopeZh = "陆家嘴 ↔ 世纪大道",
            scopeEn = "Lujiazui ↔ Century Avenue",
            reasonZh = "陆家嘴至世纪大道区间发生轨道信号故障，部分列车限速运行，预计延误10-15分钟。",
            reasonEn = "Track signal failure between Lujiazui & Century Avenue. Trains operating under restricted speed. Expected delay 10-15 mins.",
            severity = DisruptionSeverity.MAJOR,
            statusZh = "处理中",
            statusEn = "In Progress",
            altRouteInfoZh = "建议前往浦东国际机场方向的乘客换乘 10号线 至南京东路后绕行，或搭乘公交接驳线。",
            altRouteInfoEn = "Passengers heading to PVG Airport are advised to transfer via Line 10 at Nanjing East Road or take the emergency bus shuttle.",
            updateTime = SimpleDateFormat("HH:mm:ss", Locale.CHINA).format(Date())
        )
        _disruptions.value = listOf(alert)
        addEvent("disruption.created", "Line2", "Disruption DSP-2026-00127 activated on Line 2.")
    }

    private fun simulateAssetAndPowerFluctuations(peakMultiplier: Double) {
        // Vary asset telemetry
        val updatedAssets = _assets.value.map { asset ->
            val tempDelta = (Math.random() * 0.4 - 0.2).toFloat() * peakMultiplier.toFloat()
            val vibDelta = (Math.random() * 0.2 - 0.1).toFloat() * peakMultiplier.toFloat()
            val scoreDelta = if (Math.random() > 0.85) -1 else 0

            asset.copy(
                temperatureC = (asset.temperatureC + tempDelta).coerceIn(15f, 65f),
                vibrationMmS = (asset.vibrationMmS + vibDelta).coerceIn(0.0f, 12.0f),
                healthScore = (asset.healthScore + scoreDelta).coerceIn(10, 100),
                runtimeHours = asset.runtimeHours + 1
            )
        }
        _assets.value = updatedAssets

        // Vary substation power draws
        val updatedPower = _powerStations.value.map { power ->
            val loadDelta = (Math.random() * 1.5 - 0.7) * peakMultiplier
            val mw = (power.activePowerMw + loadDelta).coerceIn(5.0, 35.0)
            val amp = (mw * 1000) / (power.voltageKv * sqrt(3.0))

            power.copy(
                activePowerMw = mw,
                energyConsumptionMwh = power.energyConsumptionMwh + (mw / 2400.0), // running energy accumulation
                currentAmp = amp,
                status = if (mw > 20.0) "HIGH_LOAD" else "NORMAL"
            )
        }
        _powerStations.value = updatedPower
    }

    fun addEvent(type: String, entityId: String, detail: String) {
        val eventList = _events.value.toMutableList()
        val payload = "{\"detail\":\"$detail\"}"
        eventList.add(0, MetroEvent(type = type, entityId = entityId, payloadJson = payload))
        if (eventList.size > 25) {
            eventList.removeAt(eventList.lastIndex)
        }
        _events.value = eventList
    }

    // ==========================================
    // GRAPHS ROUTING ENGINE (DIJKSTRA)
    // ==========================================

    data class RoutingNode(
        val stationId: String,
        val totalCost: Double,
        val transfers: Int,
        val walkingCost: Double,
        val parent: RoutingNode? = null,
        val arrivalEdge: GraphEdge? = null
    )

    fun calculateRoute(
        startStationId: String,
        endStationId: String,
        mode: String, // "FASTEST", "FEWEST_TRANSFERS", "LEAST_WALKING", "ACCESSIBLE", "LEAST_CROWDED"
        passengerType: PassengerType = PassengerType.COMMUTER
    ): RouteResult? {
        if (startStationId == endStationId) return null

        val startStation = stations[startStationId] ?: return null
        val endStation = stations[endStationId] ?: return null

        // Dijkstra implementation
        val openList = PriorityQueue<RoutingNode> { a, b -> a.totalCost.compareTo(b.totalCost) }
        val closedList = mutableSetOf<String>()

        openList.add(RoutingNode(startStationId, 0.0, 0, 0.0))

        var destinationNode: RoutingNode? = null

        while (openList.isNotEmpty()) {
            val current = openList.poll()
            if (current.stationId == endStationId) {
                destinationNode = current
                break
            }

            if (current.stationId in closedList) continue
            closedList.add(current.stationId)

            // Find all outgoing edges
            val outgoingEdges = edges.filter { it.sourceId == current.stationId }
            for (edge in outgoingEdges) {
                if (edge.targetId in closedList) continue

                // Apply weight adjustments based on requested Routing Mode!
                var weightPenalty = edge.baseWeightSeconds

                // Disruption penalty
                if (isDisruptionActive.value && edge.lineId == "Line2" &&
                    ((edge.sourceId == "LUJIAZUI" && edge.targetId == "CENTURY_AVE") || (edge.sourceId == "CENTURY_AVE" && edge.targetId == "LUJIAZUI"))) {
                    weightPenalty += 1800.0 // Add massive 30-minute penalty to route around failure section!
                }

                var transfersDelta = 0
                var walkDelta = 0.0

                when (edge.type) {
                    EdgeType.RAIL -> {
                        // Rail travel
                        if (mode == "LEAST_CROWDED" && isPeakMode.value) {
                            weightPenalty *= 1.5 // Crowded lines penalty
                        }
                    }
                    EdgeType.TRANSFER -> {
                        transfersDelta = 1
                        walkDelta = edge.baseWeightSeconds * 0.3
                        when (mode) {
                            "FEWEST_TRANSFERS" -> weightPenalty += 1200.0 // heavily penalize transferring
                            "LEAST_WALKING" -> {
                                weightPenalty += 600.0
                                walkDelta += edge.baseWeightSeconds * 0.6
                            }
                            "ACCESSIBLE" -> {
                                // Prefer easy cross-platforms (like HQ Station transfer has lower cost)
                                weightPenalty += 100.0
                            }
                            "FASTEST" -> {} // default weight
                        }
                    }
                    EdgeType.WALKING -> {
                        walkDelta = edge.baseWeightSeconds
                        if (mode == "LEAST_WALKING") weightPenalty *= 2.0
                    }
                    EdgeType.VERTICAL -> {
                        if (mode == "ACCESSIBLE") {
                            // Wheelchair must prefer lifts. If elevator in station fails, block it!
                            // Since we simulate vertical movement as elevator, let's keep it accessible
                        }
                    }
                }

                // If accessible mode, verify if station has operational lifts
                if (mode == "ACCESSIBLE") {
                    val targetStation = stations[edge.targetId]
                    val hasLiftAtTarget = targetStation?.facilities?.any { it.type == FacilityType.LIFT && it.isOperational } ?: true
                    if (!hasLiftAtTarget) {
                        weightPenalty += 900.0 // detour penalty for inaccessible target
                    }
                }

                val nextNode = RoutingNode(
                    stationId = edge.targetId,
                    totalCost = current.totalCost + weightPenalty,
                    transfers = current.transfers + transfersDelta,
                    walkingCost = current.walkingCost + walkDelta,
                    parent = current,
                    arrivalEdge = edge
                )
                openList.add(nextNode)
            }
        }

        if (destinationNode == null) return null

        // Reconstruct path
        val pathNodes = mutableListOf<String>()
        val pathLines = mutableListOf<String>()
        var currentNode: RoutingNode? = destinationNode

        while (currentNode != null) {
            pathNodes.add(0, currentNode.stationId)
            currentNode.arrivalEdge?.lineId?.let {
                if (pathLines.isEmpty() || pathLines.first() != it) {
                    pathLines.add(0, it)
                }
            }
            currentNode = currentNode.parent
        }

        // Calculate total stats
        val totalSeconds = destinationNode.totalCost
        val totalMinutes = (totalSeconds / 60.0).roundToInt()
        val walkMinutes = (destinationNode.walkingCost / 60.0).roundToInt().coerceAtLeast(1)
        val transferCount = destinationNode.transfers

        // Serious Fare Engine implementation (Do not hardcode! Base price + incremental km rule)
        val estimatedFare = calculateFare(pathNodes, passengerType)

        // Generate detailed routing steps
        val steps = generateRouteTimelineSteps(pathNodes, startStationId, endStationId)

        return RouteResult(
            startStationId = startStationId,
            endStationId = endStationId,
            startStationZh = startStation.nameZh,
            startStationEn = startStation.nameEn,
            endStationZh = endStation.nameZh,
            endStationEn = endStation.nameEn,
            totalMinutes = totalMinutes,
            walkingMinutes = walkMinutes,
            transfersCount = transferCount,
            estimatedFare = estimatedFare,
            crowdingLevel = if (isPeakMode.value) CrowdingLevel.HIGH else CrowdingLevel.LOW,
            pathNodes = pathNodes,
            pathLineIds = pathLines,
            timelineSteps = steps,
            passengerType = passengerType
        )
    }

    private fun calculateFare(stationIds: List<String>, passengerType: PassengerType): Double {
        // Shanghai standard metro fare rule:
        // Under 6 km: 3元
        // Every additional 10 km: 1元
        val totalStations = stationIds.size
        val kmEstimate = totalStations * 2.8 // assume average 2.8 km between sequential stations
        val rawFare = if (kmEstimate <= 6.0) {
            3.0
        } else {
            3.0 + ceil((kmEstimate - 6.0) / 10.0)
        }
        val discountedFare = rawFare * passengerType.discountRatio
        return discountedFare
    }

    private fun generateRouteTimelineSteps(pathIds: List<String>, startId: String, endId: String): List<RouteTimelineStep> {
        val steps = mutableListOf<RouteTimelineStep>()
        val startStation = stations[startId] ?: return emptyList()
        val endStation = stations[endId] ?: return emptyList()

        val calendar = Calendar.getInstance()
        val sdf = SimpleDateFormat("HH:mm", Locale.CHINA)

        // Step 1: Entry
        steps.add(
            RouteTimelineStep(
                timeString = sdf.format(calendar.time),
                textZh = "进入${startStation.nameZh}站并安检进站",
                textEn = "Enter ${startStation.nameEn} Station and clear security check"
            )
        )

        // Step 2: Head to platform
        calendar.add(Calendar.MINUTE, 3)
        steps.add(
            RouteTimelineStep(
                timeString = sdf.format(calendar.time),
                textZh = "前往站台，在最佳第 ${if (endId == "PVG_AIRPORT") "1" else "4"} 节车厢处候车",
                textEn = "Go to platform, wait at best Carriage #${if (endId == "PVG_AIRPORT") "1" else "4"}"
            )
        )

        // Step 3: Board train
        calendar.add(Calendar.MINUTE, 2)
        var currentLineId = "Line2" // default demonstration trunk
        // Determine lineId based on actual connection
        for (i in 0 until pathIds.size - 1) {
            val edge = edges.find { (it.sourceId == pathIds[i] && it.targetId == pathIds[i+1]) || (it.sourceId == pathIds[i+1] && it.targetId == pathIds[i]) }
            if (edge?.lineId != null) {
                currentLineId = edge.lineId
                break
            }
        }
        val line = lines[currentLineId]
        steps.add(
            RouteTimelineStep(
                timeString = sdf.format(calendar.time),
                textZh = "搭乘 ${line?.nameZh ?: "地铁"}（往${if (endId == "PVG_AIRPORT") "浦东国际机场" else "徐泾东"}方向）",
                textEn = "Board ${line?.nameEn ?: "Metro"} (bound for ${if (endId == "PVG_AIRPORT") "PVG Airport" else "East Xujing"})"
            )
        )

        // Step 4: Transfer alerts
        var totalTravelMinutes = 0
        for (i in 1 until pathIds.size - 1) {
            val currStationId = pathIds[i]
            val prevLineEdge = edges.find { it.sourceId == pathIds[i-1] && it.targetId == currStationId }
            val nextLineEdge = edges.find { it.sourceId == currStationId && it.targetId == pathIds[i+1] }

            if (prevLineEdge?.lineId != null && nextLineEdge?.lineId != null && prevLineEdge.lineId != nextLineEdge.lineId) {
                totalTravelMinutes += 12
                calendar.add(Calendar.MINUTE, 12)
                val currStation = stations[currStationId]
                val nextLine = lines[nextLineEdge.lineId]
                steps.add(
                    RouteTimelineStep(
                        timeString = sdf.format(calendar.time),
                        textZh = "在 [${currStation?.nameZh}] 站内换乘 ${nextLine?.nameZh}",
                        textEn = "Transfer at [${currStation?.nameEn}] to ${nextLine?.nameEn}"
                    )
                )
            }
        }

        // Step 5: Arrival
        calendar.add(Calendar.MINUTE, 15)
        steps.add(
            RouteTimelineStep(
                timeString = sdf.format(calendar.time),
                textZh = "到达${endStation.nameZh}站，从 1 号口出站",
                textEn = "Arrive at ${endStation.nameEn} Station, exit via Gate 1"
            )
        )

        return steps
    }
}

// Result models for UI rendering
data class RouteResult(
    val startStationId: String,
    val endStationId: String,
    val startStationZh: String,
    val startStationEn: String,
    val endStationZh: String,
    val endStationEn: String,
    val totalMinutes: Int,
    val walkingMinutes: Int,
    val transfersCount: Int,
    val estimatedFare: Double,
    val crowdingLevel: CrowdingLevel,
    val pathNodes: List<String>,
    val pathLineIds: List<String>,
    val timelineSteps: List<RouteTimelineStep>,
    val passengerType: PassengerType
)

data class RouteTimelineStep(
    val timeString: String,
    val textZh: String,
    val textEn: String
)
