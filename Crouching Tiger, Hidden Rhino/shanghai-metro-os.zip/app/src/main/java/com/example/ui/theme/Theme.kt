package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = MetroBlue,
    secondary = CoolGrey,
    tertiary = MetroGreen,
    background = DarkBg,
    surface = DarkSurface,
    onPrimary = TextLight,
    onSecondary = TextLight,
    onBackground = TextLight,
    onSurface = TextLight,
    error = MetroRed
  )

private val LightColorScheme =
  lightColorScheme(
    primary = MetroBlue,
    secondary = Graphite,
    tertiary = MetroGreen,
    background = LightBg,
    surface = LightSurface,
    onPrimary = LightSurface,
    onSecondary = TextDark,
    onBackground = TextDark,
    onSurface = TextDark,
    error = MetroRed
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Disable dynamic colors to enforce the strict institutional transport palette
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
