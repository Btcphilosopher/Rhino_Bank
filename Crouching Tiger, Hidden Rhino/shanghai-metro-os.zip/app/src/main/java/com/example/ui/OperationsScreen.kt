package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.MetroSimulationEngine
import com.example.model.*
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun OperationsScreen(
    engine: MetroSimulationEngine,
    isChinese: Boolean
) {
    var opsSection by remember { mutableStateOf("TRAINS") } // "TRAINS", "INCIDENTS", "POWER", "ASSETS", "EVENTS"

    val liveTrains = engine.liveTrains.collectAsState().value
    val activeDisruptions = engine.disruptions.collectAsState().value
    val powerStations = engine.powerStations.collectAsState().value
    val assets = engine.assets.collectAsState().value
    val events = engine.events.collectAsState().value
    val isPeak = engine.isPeakMode.collectAsState().value
    val isDisrupt = engine.isDisruptionActive.collectAsState().value

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBg)
            .padding(12.dp)
    ) {
        // OCC Dashboard Top Statistics Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            val stats = listOf(
                Pair(if (isChinese) "行车总数" else "TRAINS", liveTrains.size.toString()),
                Pair(if (isChinese) "牵引负荷" else "POWER", "${powerStations.sumOf { it.activePowerMw }.toInt()} MW"),
                Pair(if (isChinese) "报警总数" else "ALARMS", (activeDisruptions.size + assets.count { it.healthScore < 50 }).toString()),
                Pair(if (isChinese) "客运负荷" else "FLOW RATE", if (isPeak) "1840 p/m" else "590 p/m")
            )
            stats.forEach { (label, value) ->
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 2.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    border = BorderStroke(1.dp, CoolGrey.copy(alpha = 0.2f))
                ) {
                    Column(
                        modifier = Modifier.padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(label, fontSize = 9.sp, color = CoolGrey, fontWeight = FontWeight.Bold)
                        Text(value, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                    }
                }
            }
        }

        // Sub Navigation Panel Toggles
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
        ) {
            val subTabs = listOf(
                Pair("TRAINS", if (isChinese) "列车调度" else "TRAINS"),
                Pair("INCIDENTS", if (isChinese) "突发应急" else "INCIDENTS"),
                Pair("POWER", if (isChinese) "动力电网" else "POWER GRID"),
                Pair("ASSETS", if (isChinese) "设备资产" else "ASSETS"),
                Pair("EVENTS", if (isChinese) "系统日志" else "LOG FEED")
            )
            subTabs.forEach { (secId, secLabel) ->
                val selected = opsSection == secId
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 2.dp)
                        .background(
                            if (selected) MetroBlue else DarkSurface,
                            RoundedCornerShape(4.dp)
                        )
                        .clickable { opsSection = secId }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = secLabel,
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Selected Subpanel Section
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = BorderStroke(1.dp, CoolGrey.copy(alpha = 0.2f))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                when (opsSection) {
                    "TRAINS" -> LiveTrainsOpsView(liveTrains, engine, isChinese)
                    "INCIDENTS" -> IncidentsOpsView(engine, activeDisruptions, isPeak, isDisrupt, isChinese)
                    "POWER" -> PowerGridOpsView(powerStations, isChinese)
                    "ASSETS" -> AssetsOpsView(assets, isChinese)
                    "EVENTS" -> EventsLogOpsView(events, isChinese)
                }
            }
        }
    }
}

// ==========================================
// A. TRAINS SCHEDULER MONITOR
// ==========================================
@Composable
fun LiveTrainsOpsView(
    liveTrains: List<LiveTrain>,
    engine: MetroSimulationEngine,
    isChinese: Boolean
) {
    Text(
        text = if (isChinese) "📡 实时行车班次监控面板" else "📡 Real-time Train Spacing Controller",
        color = Color.White,
        fontWeight = FontWeight.Bold,
        fontSize = 13.sp,
        modifier = Modifier.padding(bottom = 8.dp)
    )

    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(liveTrains) { train ->
            val curSt = engine.stations[train.currentStationId]?.nameZh ?: ""
            val nextSt = engine.stations[train.nextStationId ?: ""]?.nameZh ?: "终点"

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = DarkBg)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            val lineLabel = if (train.lineId == "Line2") "2号线" else "1号线"
                            val lineColor = if (train.lineId == "Line2") MetroGreen else MetroRed
                            Box(
                                modifier = Modifier
                                    .background(lineColor, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(lineLabel, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "TRAIN ${train.id}",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        // Run Mode badge
                        Box(
                            modifier = Modifier
                                .background(
                                    when (train.runMode) {
                                        TrainRunMode.DWELLING -> MetroOrange.copy(alpha = 0.2f)
                                        TrainRunMode.CRUISING -> MetroGreen.copy(alpha = 0.2f)
                                        else -> MetroBlue.copy(alpha = 0.2f)
                                    },
                                    RoundedCornerShape(4.dp)
                                )
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = train.runMode.name,
                                color = when (train.runMode) {
                                    TrainRunMode.DWELLING -> MetroOrange
                                    TrainRunMode.CRUISING -> MetroGreen
                                    else -> Color.White
                                },
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (isChinese) {
                                "区间：$curSt ➔ $nextSt (${(train.positionRatio * 100).toInt()}%)"
                            } else {
                                "Track: $curSt ➔ $nextSt (${(train.positionRatio * 100).toInt()}%)"
                            },
                            color = CoolGrey,
                            fontSize = 11.sp
                        )

                        Text(
                            text = "${train.speedKmh} km/h",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Carriage occupancy breakdown
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(if (isChinese) "厢级拥挤: " else "Carriages: ", color = CoolGrey, fontSize = 10.sp)
                        train.occupancyList.forEachIndexed { index, crowd ->
                            val carriageColor = when (crowd) {
                                CrowdingLevel.LOW -> MetroGreen
                                CrowdingLevel.MEDIUM -> MetroYellow
                                CrowdingLevel.HIGH -> MetroOrange
                                CrowdingLevel.CRITICAL -> MetroRed
                            }
                            Box(
                                modifier = Modifier
                                    .padding(horizontal = 2.dp)
                                    .weight(1f)
                                    .height(14.dp)
                                    .background(carriageColor.copy(alpha = 0.3f), RoundedCornerShape(2.dp))
                                    .border(1.dp, carriageColor, RoundedCornerShape(2.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${index + 1}号",
                                    fontSize = 8.sp,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// B. INCIDENTS / SIMULATION CONTROLLER
// ==========================================
@Composable
fun IncidentsOpsView(
    engine: MetroSimulationEngine,
    activeDisruptions: List<ServiceDisruption>,
    isPeak: Boolean,
    isDisrupt: Boolean,
    isChinese: Boolean
) {
    Text(
        text = if (isChinese) "🚨 线路突发故障与流控仿真控制台" else "🚨 Incident Dispatcher & Peak simulation Console",
        color = Color.White,
        fontWeight = FontWeight.Bold,
        fontSize = 13.sp,
        modifier = Modifier.padding(bottom = 8.dp)
    )

    Column(modifier = Modifier.fillMaxSize()) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = DarkBg)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = if (isChinese) "核心注入参数" else "CORE SIMULATION TRIGGERS",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = CoolGrey,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                // Peak Hour Switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (isChinese) "早/晚高峰期流量仿真" else "Peak Hour Crowds Simulator",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isChinese) "激活2.2倍客流及站点换乘等候负荷" else "Spikes boarding delays & power grids",
                            color = CoolGrey,
                            fontSize = 10.sp
                        )
                    }
                    Switch(
                        checked = isPeak,
                        onCheckedChange = {
                            engine.isPeakMode.value = it
                            engine.addEvent("sim.peak_changed", "SYSTEM", "Peak simulation set to: $it")
                        },
                        colors = SwitchDefaults.colors(checkedThumbColor = MetroBlue)
                    )
                }

                Divider(modifier = Modifier.padding(vertical = 10.dp), color = CoolGrey.copy(alpha = 0.2f))

                // Track Obstruction / Disruption Switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (isChinese) "2号线信号故障 (区间限速阻断)" else "Line 2 Signal Failure Disruption",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isChinese) "限速陆家嘴至世纪大道，路由引擎重计算" else "Slows trains, triggers alternate path calculations",
                            color = CoolGrey,
                            fontSize = 10.sp
                        )
                    }
                    Switch(
                        checked = isDisrupt,
                        onCheckedChange = {
                            engine.isDisruptionActive.value = it
                        },
                        colors = SwitchDefaults.colors(checkedThumbColor = MetroRed)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Active logs
        Text(
            text = if (isChinese) "当前激活的调度事件警告" else "ACTIVE RUNTIME DISPATCH ALERTS",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = CoolGrey,
            modifier = Modifier.padding(bottom = 6.dp)
        )

        if (activeDisruptions.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(DarkBg, RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isChinese) "✓ 路网状态良好。目前没有任何激活的限速或中止故障。" else "✓ Normal Status. No track interruptions detected.",
                    fontSize = 11.sp,
                    color = MetroGreen,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(activeDisruptions) { d ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MetroRed.copy(alpha = 0.15f)),
                        border = BorderStroke(1.dp, MetroRed)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    "INCIDENT #${d.id.substringAfter("-")}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = MetroRed,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    if (isChinese) d.statusZh else d.statusEn,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp,
                                    color = Color.White
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (isChinese) "${d.lineId} (${d.scopeZh})：${d.reasonZh}" else "${d.lineId} (${d.scopeEn}): ${d.reasonEn}",
                                color = Color.White,
                                fontSize = 11.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = if (isChinese) "绕行预案：${d.altRouteInfoZh}" else " detour: ${d.altRouteInfoEn}",
                                color = CoolGrey,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// C. POWER SUBSTATIONS MONITOR
// ==========================================
@Composable
fun PowerGridOpsView(
    powerStations: List<PowerSubstation>,
    isChinese: Boolean
) {
    Text(
        text = if (isChinese) "⚡ 智能高压供电网负载监测" else "⚡ Intelligent Power Grid Load Telemetry",
        color = Color.White,
        fontWeight = FontWeight.Bold,
        fontSize = 13.sp,
        modifier = Modifier.padding(bottom = 8.dp)
    )

    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(powerStations) { sub ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = DarkBg)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isChinese) sub.nameZh else sub.nameEn,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )

                        Box(
                            modifier = Modifier
                                .background(
                                    if (sub.status == "NORMAL") MetroGreen.copy(alpha = 0.2f) else MetroRed.copy(alpha = 0.2f),
                                    RoundedCornerShape(4.dp)
                                )
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = sub.status,
                                color = if (sub.status == "NORMAL") MetroGreen else MetroRed,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(if (isChinese) "有功负荷 LOAD" else "ACTIVE LOAD", fontSize = 8.sp, color = CoolGrey)
                            Text("${String.format("%.1f", sub.activePowerMw)} MW", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                        Column {
                            Text(if (isChinese) "电能消耗 ENERGY" else "ENERGY CONS", fontSize = 8.sp, color = CoolGrey)
                            Text("${String.format("%.2f", sub.energyConsumptionMwh)} MWh", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                        Column {
                            Text(if (isChinese) "总线电压 VOLTS" else "VOLTAGE", fontSize = 8.sp, color = CoolGrey)
                            Text("${sub.voltageKv} KV", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                        Column {
                            Text(if (isChinese) "额定电流 AMPS" else "CURRENT", fontSize = 8.sp, color = CoolGrey)
                            Text("${sub.currentAmp.toInt()} A", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// D. ASSETS PREDICTIVE MAINTENANCE
// ==========================================
@Composable
fun AssetsOpsView(
    assets: List<MetroAsset>,
    isChinese: Boolean
) {
    Text(
        text = if (isChinese) "🛠️ 机电基础设施健康预诊断 (模拟)" else "🛠️ Mechanical & Electrical Assets Health",
        color = Color.White,
        fontWeight = FontWeight.Bold,
        fontSize = 13.sp,
        modifier = Modifier.padding(bottom = 8.dp)
    )

    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(assets) { asset ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = DarkBg)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (isChinese) asset.locationZh else asset.locationEn,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                            Text(
                                "ID: ${asset.id} | ${asset.type.labelZh}",
                                color = CoolGrey,
                                fontSize = 9.sp
                            )
                        }

                        // Health score index
                        val hColor = when {
                            asset.healthScore >= 90 -> MetroGreen
                            asset.healthScore >= 70 -> MetroYellow
                            else -> MetroRed
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "Health: ${asset.healthScore}%",
                                color = hColor,
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Box(
                                modifier = Modifier
                                    .background(
                                        if (asset.maintenancePriority == "HIGH") MetroRed.copy(alpha = 0.2f) else CoolGrey.copy(alpha = 0.2f),
                                        RoundedCornerShape(4.dp)
                                    )
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                Text("Maint: ${asset.maintenancePriority}", fontSize = 8.sp, color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Sensor telemetry fluctuations
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(
                            text = "Temp: ${String.format("%.1f", asset.temperatureC)} °C",
                            fontSize = 10.sp,
                            color = CoolGrey,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Vib: ${String.format("%.1f", asset.vibrationMmS)} mm/s",
                            fontSize = 10.sp,
                            color = CoolGrey,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Runtime: ${asset.runtimeHours} hrs",
                            fontSize = 10.sp,
                            color = CoolGrey,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Faults: ${asset.faultCount}",
                            fontSize = 10.sp,
                            color = CoolGrey,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// E. LIVE METRO telemetry STREAM LOGS
// ==========================================
@Composable
fun EventsLogOpsView(
    events: List<MetroEvent>,
    isChinese: Boolean
) {
    Text(
        text = if (isChinese) "📋 分布式高频遥测事件流日志 (JSON)" else "📋 Telemetry Event-driven Broker Log Feed (JSON)",
        color = Color.White,
        fontWeight = FontWeight.Bold,
        fontSize = 13.sp,
        modifier = Modifier.padding(bottom = 8.dp)
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black, RoundedCornerShape(8.dp))
            .padding(8.dp)
    ) {
        items(events) { ev ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        ev.type.uppercase(),
                        fontWeight = FontWeight.Bold,
                        color = when {
                            ev.type.contains("disruption") -> MetroRed
                            ev.type.contains("payment") -> MetroGreen
                            else -> Color.Cyan
                        },
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        SimpleDateFormat("HH:mm:ss.SSS", Locale.CHINA).format(Date(ev.timestamp)),
                        color = CoolGrey,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Text(
                    text = "{ \"eventId\": \"${ev.eventId.take(12)}\", \"entity\": \"${ev.entityId}\", \"payload\": ${ev.payloadJson} }",
                    color = Color.LightGray,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(top = 2.dp)
                )
                Divider(color = Color.DarkGray.copy(alpha = 0.5f), modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
}
