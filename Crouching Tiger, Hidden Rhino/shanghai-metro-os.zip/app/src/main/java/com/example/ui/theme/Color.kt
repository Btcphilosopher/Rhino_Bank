package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Shanghai Metro OS Core Palette
val MetroBlue = Color(0xFF003F8A)       // Deep Metropolitan Blue
val MetroRed = Color(0xFFC8102E)        // Railway Red (Line 1/Disruption Alert)
val MetroOrange = Color(0xFFE87722)     // Restrained Orange (Line 3/Warning)
val MetroGreen = Color(0xFF009639)      // Controlled Green (Line 2/Success Status)
val MetroLightGreen = Color(0xFF78BE20) // Line 4 / Light Green
val MetroPurple = Color(0xFF512888)     // Line 10 / Purple
val MetroYellow = Color(0xFFF1C40F)     // Line 7 / Yellow

val Graphite = Color(0xFF2B2E33)        // Solid Slate Graphite
val CoolGrey = Color(0xFF8E9CA6)        // Metallic Cool Grey
val DarkBg = Color(0xFF11141A)          // Cyberpunk/OCC Dark Background
val DarkSurface = Color(0xFF1C222E)     // OCC Panel Surface
val LightBg = Color(0xFFF4F6F9)         // Light Gray Passenger Background
val LightSurface = Color(0xFFFFFFFF)    // Passenger UI Surface White
val TextDark = Color(0xFF1E2124)        // Primary text
val TextLight = Color(0xFFECEFF1)       // OCC contrast text
val TextSecondary = Color(0xFF5E646C)   // Secondary info label
