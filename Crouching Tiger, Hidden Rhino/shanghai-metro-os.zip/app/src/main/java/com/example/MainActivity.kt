package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.MetroSimulationEngine
import com.example.ui.DigitalTwinScreen
import com.example.ui.OperationsScreen
import com.example.ui.PassengerScreen
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {

  // Fictional Late-2020s Metro operating system state engine
  private val simulationEngine = MetroSimulationEngine()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        MetroShellContainer(simulationEngine)
      }
    }
  }
}

@Composable
fun MetroShellContainer(engine: MetroSimulationEngine) {
  var isChinese by remember { mutableStateOf(true) }
  var currentSystemMode by remember { mutableStateOf("PASSENGER") } // "PASSENGER", "OPERATIONS", "TWIN_EXPLORER"
  var activeTwinStationId by remember { mutableStateOf("PEOPLES_SQUARE") }

  Scaffold(
    topBar = {
      Surface(
        color = Graphite,
        modifier = Modifier.testTag("metro_shell_top_bar")
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 14.dp, vertical = 10.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          // Platform Title Label
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.DirectionsSubway,
              contentDescription = "Metro OS Logo",
              tint = Color.White,
              modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = "SHANGHAI METRO OS",
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = "上海都市轨道交通智慧运营与出行系统",
                color = CoolGrey,
                fontSize = 8.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }

          // Controls Area (Language Toggle + Context Switcher)
          Row(verticalAlignment = Alignment.CenterVertically) {
            // Language Toggle
            Box(
              modifier = Modifier
                .background(Color.White.copy(alpha = 0.12f), RoundedCornerShape(4.dp))
                .clickable { isChinese = !isChinese }
                .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Text(
                text = if (isChinese) "EN" else "中文",
                color = Color.White,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
              )
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Context Switch Button (Passenger View vs Operations Center)
            Button(
              onClick = {
                if (currentSystemMode == "PASSENGER") {
                  currentSystemMode = "OPERATIONS"
                } else {
                  currentSystemMode = "PASSENGER"
                }
              },
              colors = ButtonDefaults.buttonColors(
                containerColor = if (currentSystemMode == "PASSENGER") MetroBlue else MetroRed
              ),
              shape = RoundedCornerShape(4.dp),
              contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
              modifier = Modifier.height(28.dp).testTag("system_context_toggle")
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = if (currentSystemMode == "PASSENGER") Icons.Default.Computer else Icons.Default.Person,
                  contentDescription = "Switch Mode",
                  tint = Color.White,
                  modifier = Modifier.size(12.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = if (currentSystemMode == "PASSENGER") {
                    if (isChinese) "切换控制台 (OCC)" else "OCC Dashboard"
                  } else {
                    if (isChinese) "乘车出行 (APP)" else "Passenger APP"
                  },
                  color = Color.White,
                  fontSize = 9.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }
          }
        }
      }
    }
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
    ) {
      when (currentSystemMode) {
        "PASSENGER" -> PassengerScreen(
          engine = engine,
          isChinese = isChinese,
          onNavigateToTwin = { stationId ->
            activeTwinStationId = stationId
            currentSystemMode = "TWIN_EXPLORER"
          }
        )
        "OPERATIONS" -> OperationsScreen(
          engine = engine,
          isChinese = isChinese
        )
        "TWIN_EXPLORER" -> DigitalTwinScreen(
          engine = engine,
          stationId = activeTwinStationId,
          isChinese = isChinese,
          onBack = { currentSystemMode = "PASSENGER" }
        )
      }
    }
  }
}
