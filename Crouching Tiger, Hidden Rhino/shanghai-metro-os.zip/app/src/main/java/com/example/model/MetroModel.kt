package com.example.model

import java.util.UUID

// ==========================================
// 01 - NETWORK GRAPH MODEL (STATIONS, PLATFORMS, FACILITIES)
// ==========================================

data class Station(
    val id: String,
    val nameZh: String,
    val nameEn: String,
    val district: String,
    val isInterchange: Boolean,
    val lines: List<String>,
    val exits: List<StationExit> = emptyList(),
    val facilities: List<StationFacility> = emptyList(),
    val coordX: Float, // Map alignment coordinates
    val coordY: Float
)

data class Platform(
    val id: String,
    val stationId: String,
    val lineId: String,
    val direction: String,
    val level: Int, // e.g. -2 for B2
    val crowdingLevel: CrowdingLevel = CrowdingLevel.LOW
)

data class StationExit(
    val name: String, // e.g., "A", "B", "Exit 3"
    val nearbyZh: String,
    val nearbyEn: String,
    val hasLift: Boolean,
    val busConnectionsZh: String,
    val busConnectionsEn: String,
    val distanceMeters: Int
)

data class StationFacility(
    val id: String,
    val type: FacilityType,
    val locationZh: String,
    val locationEn: String,
    val isOperational: Boolean = true
)

enum class FacilityType {
    LIFT, ESCALATOR, STAIRS, FARE_GATES, TOILET, SECURITY_CHECK, CUSTOMER_SERVICE
}

data class MetroLine(
    val id: String, // e.g., "Line1", "Line2"
    val nameZh: String,
    val nameEn: String,
    val colorHex: String,
    val stations: List<String>, // ordered list of station IDs
    val intervalSeconds: Int,
    val startHour: String = "05:30",
    val endHour: String = "22:30",
    val averageSpeedKmh: Int = 45,
    val isDisrupted: Boolean = false,
    val activeTrainsCount: Int = 12
)

// Graph edge representing links in routing engine
data class GraphEdge(
    val sourceId: String,
    val targetId: String,
    val type: EdgeType,
    val baseWeightSeconds: Double,
    val lineId: String? = null // if RAIL, which line
)

enum class EdgeType {
    RAIL, TRANSFER, WALKING, VERTICAL
}

// ==========================================
// 02 - REAL-TIME TRAIN & SIMULATION MODELS
// ==========================================

data class LiveTrain(
    val id: String,
    val lineId: String,
    val directionZh: String,
    val directionEn: String,
    val currentStationId: String,
    val nextStationId: String?,
    val speedKmh: Int,
    val positionRatio: Float, // 0.0f (at currentStation) to 1.0f (at nextStation)
    val status: TrainStatus = TrainStatus.NORMAL,
    val delaySeconds: Int = 0,
    val occupancyList: List<CrowdingLevel> = listOf(CrowdingLevel.LOW, CrowdingLevel.LOW, CrowdingLevel.LOW, CrowdingLevel.LOW, CrowdingLevel.LOW),
    val runMode: TrainRunMode = TrainRunMode.CRUISING
) {
    val averageOccupancy: CrowdingLevel
        get() {
            val sum = occupancyList.sumOf { it.ordinal }
            val avg = sum.toFloat() / occupancyList.size
            return CrowdingLevel.values()[avg.toInt().coerceIn(0, 3)]
        }
}

enum class TrainStatus {
    NORMAL, DELAYED, STOPPED, COUPLING_ERROR
}

enum class TrainRunMode {
    ACCELERATING, CRUISING, BRAKING, ARRIVING, DWELLING
}

enum class CrowdingLevel(val labelZh: String, val labelEn: String) {
    LOW("低", "Low"),
    MEDIUM("中", "Medium"),
    HIGH("高", "High"),
    CRITICAL("极高", "Critical")
}

// ==========================================
// 03 - FARE & TICKETING ENGINE MODELS
// ==========================================

data class FareProduct(
    val id: String,
    val nameZh: String,
    val nameEn: String,
    val type: FareType,
    val basePrice: Double,
    val perKmPrice: Double
)

enum class FareType {
    SINGLE_JOURNEY, METRO_PASS_1DAY, METRO_PASS_3DAY, DIGITAL_TRANSPORT_CARD
}

data class Ticket(
    val id: String,
    val product: FareProduct,
    val passengerType: PassengerType = PassengerType.COMMUTER,
    val qrCodePayload: String,
    val status: TicketStatus = TicketStatus.UNUSEABLE,
    val startStationId: String? = null,
    val endStationId: String? = null,
    val actualFare: Double = 0.0,
    val creationTime: Long = System.currentTimeMillis()
)

enum class TicketStatus {
    UNUSEABLE, ACTIVE_READY_TO_ENTER, SWIPED_IN, USED_COMPLETED, EXPIRED
}

enum class PassengerType(val discountRatio: Double, val labelZh: String, val labelEn: String) {
    COMMUTER(1.0, "普通通勤", "Standard Commuter"),
    STUDENT(0.5, "学生 (5折)", "Student (50% Off)"),
    SENIOR(0.0, "敬老 (免费)", "Senior (Free)"),
    ACCESSIBLE_PASSENGER(0.0, "残障人士 (免费)", "Disabled (Free)")
}

data class PaymentTransaction(
    val id: String,
    val timestamp: Long,
    val amount: Double,
    val startStationZh: String,
    val endStationZh: String,
    val status: String // "SUCCESS", "PENDING"
)

data class DigitalCard(
    val cardNumber: String,
    val balance: Double,
    val couponCount: Int = 0,
    val transactions: List<PaymentTransaction> = emptyList()
)

// ==========================================
// 04 - DISRUPTION PROPAGATION ENGINE
// ==========================================

data class ServiceDisruption(
    val id: String,
    val lineId: String,
    val scopeZh: String, // Affected section text
    val scopeEn: String,
    val reasonZh: String,
    val reasonEn: String,
    val severity: DisruptionSeverity,
    val statusZh: String,
    val statusEn: String,
    val altRouteInfoZh: String,
    val altRouteInfoEn: String,
    val updateTime: String
)

enum class DisruptionSeverity {
    MINOR, MAJOR, SUSPENDED
}

// ==========================================
// 05 - ASSETS & METRO OPERATIONS telemetry
// ==========================================

data class MetroAsset(
    val id: String,
    val type: AssetType,
    val locationZh: String,
    val locationEn: String,
    val healthScore: Int, // 0 to 100
    val temperatureC: Float,
    val vibrationMmS: Float,
    val runtimeHours: Int,
    val faultCount: Int,
    val lastInspectionDate: String,
    val nextInspectionDate: String,
    val maintenancePriority: String // "LOW", "MEDIUM", "HIGH"
)

enum class AssetType(val labelZh: String, val labelEn: String) {
    TRAIN_VEHICLE("列车车厢", "Train Car"),
    TRACK_SWITCH("轨道道岔", "Track Switch"),
    SIGNAL_LIGHT("信号系统", "Signal System"),
    TRACTION_SUBSTATION("牵引供电", "Traction Substation"),
    STATION_HVAC("车站暖通", "Station HVAC"),
    ESCALATOR("自动扶梯", "Escalator"),
    LIFT("无障碍垂直电梯", "Station Lift"),
    TICKET_GATE("检票闸机", "Ticket Gate")
}

data class PowerSubstation(
    val id: String,
    val nameZh: String,
    val nameEn: String,
    val activePowerMw: Double,
    val energyConsumptionMwh: Double,
    val voltageKv: Double,
    val currentAmp: Double,
    val status: String // "NORMAL", "HIGH_LOAD", "MAINTENANCE"
)

// ==========================================
// 06 - EVENT-DRIVEN DATA ARCHITECTURE
// ==========================================

data class MetroEvent(
    val eventId: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val type: String, // e.g. "train.position", "disruption.created", "ticket.swiped_in"
    val entityId: String,
    val source: String = "SIM_ENGINE_V1",
    val payloadJson: String
)

// ==========================================
// 07 - USER PREFERENCES & Short Cuts
// ==========================================

data class SavedJourneyShortcut(
    val nameZh: String,
    val nameEn: String,
    val startStationId: String,
    val endStationId: String,
    val iconType: String // "HOME", "WORK", "AIRPORT", "RAIL"
)
