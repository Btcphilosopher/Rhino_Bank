/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";
import { 
  simulateRefineryOperations, 
  simulatePipelineHydraulics, 
  simulateArpsDecline,
  DATA_SOURCE_NOTICE 
} from "./src/data";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Google GenAI
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;

if (apiKey) {
  try {
    ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  } catch (err) {
    console.error("Failed to initialize GoogleGenAI:", err);
  }
} else {
  console.warn("GEMINI_API_KEY is not defined in environment variables. AI operations will use rules-based engine.");
}

// 1. API: 健康检查
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", time: new Date().toISOString(), source: "synthetic" });
});

// 2. API: 工业计算仿真端
app.post("/api/simulation/refinery", (req, res) => {
  const { loadDeltaPercentage, crudeId } = req.body;
  const result = simulateRefineryOperations(
    Number(loadDeltaPercentage || 0),
    String(crudeId || "CRUDE-AL")
  );
  res.json(result);
});

app.post("/api/simulation/pipeline", (req, res) => {
  const { pipelineId, inputFlowRateTonsPerHour, pumpStationActive, demandShiftPercentage } = req.body;
  const result = simulatePipelineHydraulics(
    String(pipelineId || "PIPE-Y01"),
    Number(inputFlowRateTonsPerHour || 1500),
    Boolean(pumpStationActive !== false),
    Number(demandShiftPercentage || 0)
  );
  res.json(result);
});

app.post("/api/simulation/production", (req, res) => {
  const { wellId, declineModel, declineRate, hyperbolicExponent } = req.body;
  const result = simulateArpsDecline(
    String(wellId || "WELL-SB-701"),
    String(declineModel || "Exponential") as "Exponential" | "Hyperbolic" | "Harmonic",
    Number(declineRate || 0.15),
    Number(hyperbolicExponent || 0.5)
  );
  res.json(result);
});

// 3. API: 中石化能源智能助手 (AI Advisor using gemini-3.8-flash for grounded analysis)
app.post("/api/ai/chat", async (req, res) => {
  const { message, contextState } = req.body;

  if (!message) {
    return res.status(400).json({ error: "消息内容不能为空" });
  }

  // Define a professional, expert persona that provides specific mathematical/physical formulas, references specific versions, and is strictly 100% Simplified Chinese.
  const systemInstruction = `你现在是「中石化能源工业操作系统 (SEIOS)」内置的全球资源控制中枢 AI 智能助手。
你的目标是解答用户关于：油气勘探、油田开采、长输管线压力水力流动、炼厂分馏催化加氢、化工平衡、风险敞口、资产可用率、碳减排(CCUS)等方面的专业技术及生产调度决策问题。

【重要规则】：
1. 100% 简体中文回答。不要使用任何英文 UI 名词。
2. 专业性极强。凡是涉及到生产变化的回答，必须明确引用工程计算公式或物理、经济学模型（如：Darcy-Weisbach 压降公式、Arps 产量递减模型、线性规划 LP 常减压收率法、NPV 财务敏感性模型等），并使用 Markdown 格式渲染 LaTeX 公式。
3. 展现数据血缘。每一个计算结果都应指明模拟数据链来源，例如：DCS 传感器（如 PT-102 压力变送器、F-301 电磁流量计）或 MES、ERP。
4. 明确标识。在回答的首部或尾部加粗显示：「【${DATA_SOURCE_NOTICE}】」。
5. 安全边界：强调 AI 仅作为生产“决策辅助分析”，无法直接向现场分布式控制系统(DCS/PLC)发送执行命令，所有调度调整必须由中控操作员在经过多因子身份校验(MFA)和管理层审批后才能发出，物理实现 IT 与 OT 严格隔离！
6. 结合上下文：若用户问题和当前系统的数字孪生交互有关，请直接结合以下当前系统的实时运行状态参数进行定性、定量分析。

当前系统的工业计算孪生上下文数据（可供查询和解答）：
${JSON.stringify(contextState || { note: "当前系统各模块处于标称正常状态" })}
`;

  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: message,
        config: {
          systemInstruction: systemInstruction,
          temperature: 0.3,
        }
      });
      return res.json({ text: response.text });
    } catch (err) {
      console.error("Gemini API call failed, falling back to local industrial expert engine:", err);
    }
  }

  // Local Industrial Rule-based Expert Engine Fallback (if API Key is not set or failed)
  let reply = `【${DATA_SOURCE_NOTICE}】\n\n您好！我是 SEIOS 工业操作系统专家助手（本地备用规则引擎已启动）。\n\n`;

  const lowerMsg = message.toLowerCase();
  if (lowerMsg.includes("油田") || lowerMsg.includes("井") || lowerMsg.includes("产量")) {
    reply += `**关于油气产量递减/单井分析：**
在 SEIOS 生产优化中，我们采用 **Arps 递减模型** 来进行单井可采储量 (EUR) 预测。
计算公式为：
- **指数递减**：$q(t) = q_0 \\cdot e^{-D \\cdot t}$
- **双曲递减**：$q(t) = \\frac{q_0}{(1 + b \\cdot D \\cdot t)^{1/b}}$

**实时诊断**：当前顺北701超深井处于标称开采状态（日产油 45吨，水压 15.0 MPa），根据 SCADA 历史时序压力回传，由于地下渗透率 $K = 18.5 \\text{ mD}$，近期含水率由 15.2% 缓慢攀升，该趋势由 LIMS 计量仪表与数据版本 VER-20260917-0615 交叉校正。
建议：调高注水井压裂段压力以提升油水驱替效率。
*提示：所有工艺调整均需要人工确认与MFA验证，IT与OT控制严格物理隔离。*`;
  } else if (lowerMsg.includes("管线") || lowerMsg.includes("管道") || lowerMsg.includes("压力") || lowerMsg.includes("流量")) {
    reply += `**关于管网流量与水力学仿真分析：**
管网仿真引擎在 Rust 高性能计算层中对长输管线进行压力分布和流量解算，主要基于 **达西-魏斯巴赫 (Darcy-Weisbach) 压降方程**：
$$\\Delta P = \\lambda \\times \\frac{L}{D} \\times \\frac{\\rho v^2}{2}$$
其中 $\\lambda$ 为管线摩阻系数（当前由于微腐蚀标定为 $0.02$），$L$ 为长输里程。

**异常预测**：如果川气东送高压输气干线停运 12 小时，根据网络流仿真：
1. **压力堆积**：起点（普光气田）集气阀口压力将在 3 小时内跃升 24.5%（自 10.0 MPa 接近额定限制 12.0 MPa），触发 SCADA 高压报警。
2. **南京门站供应缺口**：将出现约 $22.4\\%$ 的天然气日配额短缺。
3. **备用调度方案**：仿真已计算出通过青岛董家口 LNG 接收站进行气化反输（金坛盐穴储气库放空阀配额调高 $35\\%$）以弥补此供能漏洞。`;
  } else if (lowerMsg.includes("炼厂") || lowerMsg.includes("常减压") || lowerMsg.includes("催化")) {
    reply += `**关于炼厂工艺及原油品质优化 (Crude Slate Optimization)：**
中石化炼化数字孪生中采用**线性规划多组分LP矩阵**求解最优加工收益。
物料平衡公式（质量守恒）：
$$\\sum Crude_{feed} = Gasoline_{yield} + Diesel_{yield} + Jet_{yield} + Naphtha_{yield} + Loss$$

**组分变化仿真**：若镇海炼化将原油原料中“沙特轻质阿拉伯原油”切换为 30% “俄罗斯乌拉尔高硫原油”：
1. **收率影响**：由于乌拉尔原油 API 较低且硫含量达 1.62%（原沙特为 1.78% 且密度更高），催化裂化及加氢装置开工负荷负荷必须调高 8.5%，柴油收率相比汽油小幅上升 $1.2\\%$。
2. **环保耗能**：脱硫装置能耗吨油单耗由 $2.5 \\text{ GJ}$ 上升至 $2.68 \\text{ GJ}$，二氧化碳排放折算量增加 $7.2\\%$。
3. **经济毛利**：乌拉尔原油到港现货价便宜 5.9 USD/桶，抵扣加工脱硫成本后，加工综合利润（EBITDA）预计增加约 $1.42 \\text{ RMB/吨}$。`;
  } else {
    reply += `当前集团各系统运行参数稳健（系统数据版本: VER-2026.09.17）。
我支持您输入以下方向的深度探询，SEIOS 仿真内核将实时解算：
1. 「如果某条管线停运12小时，会怎样？」
2. 「某炼厂换一种原油以后产品收率会怎样？」
3. 「为什么某区块日产油下降，如何进行 Arps 产量预测？」
4. 「哪些设备当前存在高振动等安全隐患？」
5. 「如何查看某个生产数字的数据血缘来源？」`;
  }

  res.json({ text: reply });
});

// Serve Frontend using Vite in development
async function start() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[SEIOS] Backend and simulation engine successfully running on http://0.0.0.0:${PORT}`);
  });
}

start();
