/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  EnergyUnit,
  DataQuality,
  DataLineage,
  GlobalCountryAsset,
  GroupOverviewMetrics,
  ExplorationBlock,
  OilWell,
  DrillingRealtimeMetrics,
  ReservoirSimulationData,
  HydraulicFracturingMetrics,
  OffshoreAsset,
  GasChainNode,
  PipelineTwin,
  RefineryDevice,
  RefineryProductionMetrics,
  CrudeCargo,
  EnergyStorageTank,
  EnergyVessel,
  RetailFuelStation,
  ChemicalProductNetwork,
  MassEnergyBalanceReport,
  CarbonEmissionTwin,
  CCUSTwin,
  IndustrialDeviceAsset,
  HSEIncidentAlert,
  EnvironmentalEmissionMetrics,
  EnergyIndustrialFinance,
  EnergyProjectInvestment,
  EnergyRiskIndicator,
  AuditLogEntry
} from "./types";

// PROMPT EXPLICIT SYNTHETIC DECLARATION
export const DATA_SOURCE_NOTICE = "合成模拟数据 (Synthetic Data) - 仅限第一阶段系统工程演示。本系统所有数据、运行指标及模型输出均为仿真引擎计算得出，不代表中国石油化工集团有限公司的任何真实生产、财务、储量或设备数据。";

// 10个国家资产
export const countriesAsset: GlobalCountryAsset[] = [
  { id: "CN", name: "中国", oilFieldsCount: 12, refineriesCount: 11, pipelinesCount: 320, stationsCount: 4200, totalOilProduction: 35120, totalGasProduction: 185.4, refiningCapacity: 14200, lngImports: 2400, coordinate: [35.8617, 104.1954] },
  { id: "SA", name: "沙特阿拉伯", oilFieldsCount: 3, refineriesCount: 2, pipelinesCount: 45, stationsCount: 220, totalOilProduction: 48500, totalGasProduction: 12.0, refiningCapacity: 4500, lngImports: 0, coordinate: [23.8859, 45.0792] },
  { id: "KW", name: "科威特", oilFieldsCount: 2, refineriesCount: 1, pipelinesCount: 20, stationsCount: 45, totalOilProduction: 18200, totalGasProduction: 4.5, refiningCapacity: 2000, lngImports: 0, coordinate: [29.3759, 47.9774] },
  { id: "AO", name: "安哥拉", oilFieldsCount: 2, refineriesCount: 1, pipelinesCount: 18, stationsCount: 30, totalOilProduction: 12400, totalGasProduction: 2.1, refiningCapacity: 800, lngImports: 0, coordinate: [-11.2027, 17.8739] },
  { id: "RU", name: "俄罗斯", oilFieldsCount: 3, refineriesCount: 2, pipelinesCount: 40, stationsCount: 180, totalOilProduction: 24500, totalGasProduction: 32.0, refiningCapacity: 3500, lngImports: 0, coordinate: [61.5240, 105.3188] },
  { id: "BR", name: "巴西", oilFieldsCount: 2, refineriesCount: 1, pipelinesCount: 15, stationsCount: 120, totalOilProduction: 15600, totalGasProduction: 6.8, refiningCapacity: 1200, lngImports: 120, coordinate: [-14.2350, -51.9253] },
  { id: "KZ", name: "哈萨克斯坦", oilFieldsCount: 2, refineriesCount: 1, pipelinesCount: 22, stationsCount: 95, totalOilProduction: 9800, totalGasProduction: 5.2, refiningCapacity: 1500, lngImports: 0, coordinate: [48.0196, 66.9237] },
  { id: "AE", name: "阿联酋", oilFieldsCount: 2, refineriesCount: 1, pipelinesCount: 16, stationsCount: 110, totalOilProduction: 11200, totalGasProduction: 3.8, refiningCapacity: 1800, lngImports: 0, coordinate: [23.4241, 53.8478] },
  { id: "VE", name: "委内瑞拉", oilFieldsCount: 1, refineriesCount: 0, pipelinesCount: 3, stationsCount: 0, totalOilProduction: 4500, totalGasProduction: 0.8, refiningCapacity: 0, lngImports: 0, coordinate: [6.4238, -66.5897] },
  { id: "GB", name: "英国", oilFieldsCount: 1, refineriesCount: 0, pipelinesCount: 1, stationsCount: 0, totalOilProduction: 2400, totalGasProduction: 1.1, refiningCapacity: 0, lngImports: 320, coordinate: [55.3781, -3.4360] }
];

// 集团首页指标
export const groupOverview: GroupOverviewMetrics = {
  globalOilGasYield: 248.5, // 万吨油当量/日
  crudeYield: 852.4, // 万桶/日
  naturalGasYield: 1450.8, // 百万标方/日
  refineryProcessingVolume: 115.6, // 万吨/日
  chemicalYield: 48.2, // 万吨/日
  refinedOilSales: 56.4, // 万吨/日
  crudeInventory: 3240.5, // 万吨
  refinedOilInventory: 1420.2, // 万吨
  naturalGasInventory: 4580.0, // 百万标方
  refineryOperatingRate: 86.4, // %
  assetUtilizationRate: 91.2, // %
  energyConsumption: 125.4, // 万吨标准煤当量/日
  carbonEmissions: 43.6, // 万吨CO2e/日
  deviceAvailability: 98.7, // %
  safetyIncidents: 0 // 起/年
};

// 勘探区块
export const explorationBlocks: ExplorationBlock[] = [
  { id: "EXP-CN-01", name: "胜利东部深层区块", country: "中国", basin: "济阳坳陷", areaSqKm: 1420, geologicalAge: "古近系/沙河街组", provenReserves: 2.45, prospectiveReserves: 5.12, wellsCount: 45, productionWellsCount: 22, evaluationWellsCount: 15, explorationWellsCount: 8, developmentStatus: "开发中", economicValueBillionUSD: 14.2 },
  { id: "EXP-CN-02", name: "普光气田高含硫区块", country: "中国", basin: "四川盆地", areaSqKm: 850, geologicalAge: "三叠系/飞仙关组", provenReserves: 3.12, prospectiveReserves: 4.88, wellsCount: 28, productionWellsCount: 18, evaluationWellsCount: 6, explorationWellsCount: 4, developmentStatus: "稳定生产", economicValueBillionUSD: 18.5 },
  { id: "EXP-CN-03", name: "顺北超深层断控碳酸盐岩区块", country: "中国", basin: "塔里木盆地", areaSqKm: 3200, geologicalAge: "奥陶系", provenReserves: 4.8, prospectiveReserves: 12.4, wellsCount: 52, productionWellsCount: 30, evaluationWellsCount: 12, explorationWellsCount: 10, developmentStatus: "开发中", economicValueBillionUSD: 32.8 },
  { id: "EXP-CN-04", name: "涪陵页岩气焦石坝区块", country: "中国", basin: "四川盆地二叠系", areaSqKm: 1100, geologicalAge: "志留系/五峰组-龙马溪组", provenReserves: 3.8, prospectiveReserves: 8.5, wellsCount: 340, productionWellsCount: 310, evaluationWellsCount: 20, explorationWellsCount: 10, developmentStatus: "稳定生产", economicValueBillionUSD: 24.5 },
  { id: "EXP-SA-01", name: "加瓦尔断块南翼", country: "沙特阿拉伯", basin: "波斯湾盆地", areaSqKm: 1200, geologicalAge: "侏罗系/阿拉伯组", provenReserves: 15.4, prospectiveReserves: 24.5, wellsCount: 85, productionWellsCount: 70, evaluationWellsCount: 10, explorationWellsCount: 5, developmentStatus: "稳定生产", economicValueBillionUSD: 98.4 }
];

// 核心大油田 (用于模拟 30个油田、100个区块的基础配置，其余进行数量累加显示)
export interface OilField {
  id: string;
  name: string;
  country: string;
  status: "运行中" | "正常维护" | "应急报警" | "注水驱油阶段";
  dailyOilProductionTon: number;
  dailyGasProductionKcm: number;
  waterCutPercentage: number;
  activeWellsCount: number;
  totalBlocksCount: number;
}

export const coreOilFields: OilField[] = [
  { id: "FIELD-SL", name: "胜利油田", country: "中国", status: "运行中", dailyOilProductionTon: 64200, dailyGasProductionKcm: 3200, waterCutPercentage: 92.4, activeWellsCount: 1240, totalBlocksCount: 25 },
  { id: "FIELD-SB", name: "顺北油气田", country: "中国", status: "运行中", dailyOilProductionTon: 18400, dailyGasProductionKcm: 14500, waterCutPercentage: 15.2, activeWellsCount: 185, totalBlocksCount: 12 },
  { id: "FIELD-FL", name: "涪陵页岩气田", country: "中国", status: "运行中", dailyOilProductionTon: 0, dailyGasProductionKcm: 24500, waterCutPercentage: 2.1, activeWellsCount: 450, totalBlocksCount: 8 },
  { id: "FIELD-PG", name: "普光气田", country: "中国", status: "注水驱油阶段", dailyOilProductionTon: 50, dailyGasProductionKcm: 22000, waterCutPercentage: 45.8, activeWellsCount: 84, totalBlocksCount: 5 },
  { id: "FIELD-GH", name: "沙特加瓦尔海外合作区块", country: "沙特阿拉伯", status: "运行中", dailyOilProductionTon: 125000, dailyGasProductionKcm: 18500, waterCutPercentage: 35.4, activeWellsCount: 320, totalBlocksCount: 15 }
];

// 钻井监控 (钻井数字孪生)
export const drillingMetrics: DrillingRealtimeMetrics[] = [
  { wellId: "WELL-SB-701", wellName: "顺北701超深井", currentDepth: 8452.4, drillingSpeed: 4.8, weightOnBitKn: 120, torqueKnm: 24, mudDensityGcm3: 1.45, mudFlowRateLps: 34, wellheadPressureMpa: 12.4, standpipePressureMpa: 28.5, temperatureCelsius: 165, inclinationDegree: 1.2, azimuthDegree: 235.4, rateOfPenetration: 4.8 },
  { wellId: "WELL-FL-205", wellName: "涪陵页岩气205H水平井", currentDepth: 5120.0, drillingSpeed: 12.5, weightOnBitKn: 85, torqueKnm: 18, mudDensityGcm3: 1.24, mudFlowRateLps: 28, wellheadPressureMpa: 6.8, standpipePressureMpa: 19.4, temperatureCelsius: 110, inclinationDegree: 89.2, azimuthDegree: 90.1, rateOfPenetration: 12.5 },
  { wellId: "WELL-OFF-H1", wellName: "深海一号采气井", currentDepth: 3420.5, drillingSpeed: 0.0, weightOnBitKn: 0, torqueKnm: 0, mudDensityGcm3: 1.15, mudFlowRateLps: 0, wellheadPressureMpa: 24.5, standpipePressureMpa: 0, temperatureCelsius: 85, inclinationDegree: 5.4, azimuthDegree: 42.1, rateOfPenetration: 0.0 }
];

// 非常规压裂数据
export const fracturingMetrics: HydraulicFracturingMetrics[] = [
  { wellId: "WELL-FL-205", wellName: "涪陵页岩气205H水平井", stagesCount: 26, clustersPerStage: 5, sandVolumeTons: 1850, fluidVolumeM3: 45200, maxPressureMpa: 82.4, averageFlowRateM3Min: 14.5, microseismicEventCount: 3240, estimatedEURKcm: 145000 }
];

// 海上采油平台
export const offshoreAssets: OffshoreAsset[] = [
  { id: "PLAT-OFF-01", name: "南海超深水生产平台", type: "FPSO(海上浮式生产储卸油装置)", waveHeightMeters: 2.4, windSpeedMps: 11.2, temperatureCelsius: 28.5, status: "正常运行", dailyProductionEquivalentTon: 4500, pipelinePressureMpa: 14.2 },
  { id: "PLAT-OFF-02", name: "渤海埕岛自升式采油平台", type: "固定采油平台", waveHeightMeters: 1.2, windSpeedMps: 8.5, temperatureCelsius: 22.0, status: "正常运行", dailyProductionEquivalentTon: 2100, pipelinePressureMpa: 6.8 }
];

// 天然气集输链
export const gasChainNodes: GasChainNode[] = [
  { id: "GAS-NODE-1", name: "涪陵焦石坝气田", type: "气田", capacity: 3000, currentFlow: 2450, pressureMpa: 12.5, temperatureCelsius: 24, calorificValueMj: 38.5 },
  { id: "GAS-NODE-2", name: "焦石坝第一集气站", type: "集气站", capacity: 1500, currentFlow: 1200, pressureMpa: 6.4, temperatureCelsius: 22, calorificValueMj: 38.4 },
  { id: "GAS-NODE-3", name: "涪陵天然气净化厂", type: "处理厂", capacity: 4000, currentFlow: 3500, pressureMpa: 5.2, temperatureCelsius: 32, calorificValueMj: 39.1 },
  { id: "GAS-NODE-4", name: "川气东送主干线管道", type: "管道", capacity: 5000, currentFlow: 4200, pressureMpa: 8.5, temperatureCelsius: 18, calorificValueMj: 39.1 },
  { id: "GAS-NODE-5", name: "金坛地下储气库", type: "储气库", capacity: 2000, currentFlow: 450, pressureMpa: 14.2, temperatureCelsius: 15, calorificValueMj: 39.0, inventoryVolumeKcm: 1240000 },
  { id: "GAS-NODE-6", name: "青岛董家口LNG接收站", type: "LNG接收站", capacity: 3500, currentFlow: 2800, pressureMpa: 4.8, temperatureCelsius: -162, calorificValueMj: 40.2, inventoryVolumeKcm: 450000 },
  { id: "GAS-NODE-7", name: "南京城市门站", type: "城市门站", capacity: 1200, currentFlow: 980, pressureMpa: 1.6, temperatureCelsius: 16, calorificValueMj: 39.1 },
  { id: "GAS-NODE-8", name: "扬子石化乙烯化工厂", type: "工业大用户", capacity: 800, currentFlow: 650, pressureMpa: 0.6, temperatureCelsius: 25, calorificValueMj: 39.1 }
];

// 核心长输管道
export const pipelineTwins: PipelineTwin[] = [
  { id: "PIPE-Y01", name: "仪长原油长输管道 (仪征-长沙)", startPoint: "江苏仪征", endPoint: "湖南长沙", lengthKm: 980, diameterMm: 813, pressureMpa: 6.4, material: "X70钢", medium: "原油", designCapacityMillionTonsPerYear: 20, currentFlowTonsPerHour: 2180, temperatureCelsius: 42, corrosionStatus: "良好" },
  { id: "PIPE-G01", name: "川气东送高压输气管道 (普光-上海)", startPoint: "四川达州普光", endPoint: "上海市", lengthKm: 2170, diameterMm: 1016, pressureMpa: 10.0, material: "X80钢", medium: "天然气", designCapacityMillionTonsPerYear: 12, currentFlowTonsPerHour: 1420, temperatureCelsius: 16, corrosionStatus: "良好" },
  { id: "PIPE-C01", name: "鲁皖成品油干线管道", startPoint: "山东临邑", endPoint: "安徽合肥", lengthKm: 650, diameterMm: 508, pressureMpa: 5.2, material: "X65钢", medium: "成品油", designCapacityMillionTonsPerYear: 8, currentFlowTonsPerHour: 850, temperatureCelsius: 20, corrosionStatus: "轻度腐蚀" },
  { id: "PIPE-H01", name: "镇海-扬子化学原料物料输送管线", startPoint: "浙江宁波镇海", endPoint: "江苏南京扬子", lengthKm: 340, diameterMm: 406, pressureMpa: 4.5, material: "双相不锈钢", medium: "化工原料", designCapacityMillionTonsPerYear: 3, currentFlowTonsPerHour: 310, temperatureCelsius: 32, corrosionStatus: "良好" }
];

// 原油仓储罐区
export const energyStorageTanks: EnergyStorageTank[] = [
  { id: "TANK-CR-101", name: "镇海国家储备库 #101 储罐", tankType: "原油储罐", capacityKcm: 100, currentVolumeKcm: 85.4, utilizationRatePercentage: 85.4, feedInRateM3Hour: 2400, dischargeRateM3Hour: 0, estimatedDepletionDays: 45 },
  { id: "TANK-CR-102", name: "舟山原油保税库 #102 储罐", tankType: "原油储罐", capacityKcm: 100, currentVolumeKcm: 91.2, utilizationRatePercentage: 91.2, feedInRateM3Hour: 1200, dischargeRateM3Hour: 1500, estimatedDepletionDays: 32 },
  { id: "TANK-RF-301", name: "茂名石化柴油罐区 #301 储罐", tankType: "成品油罐", capacityKcm: 50, currentVolumeKcm: 32.5, utilizationRatePercentage: 65.0, feedInRateM3Hour: 450, dischargeRateM3Hour: 600, estimatedDepletionDays: 14 },
  { id: "TANK-LNG-01", name: "董家口LNG超低温储罐 #1", tankType: "LNG低温罐", capacityKcm: 160, currentVolumeKcm: 124.5, utilizationRatePercentage: 77.8, feedInRateM3Hour: 3200, dischargeRateM3Hour: 2400, estimatedDepletionDays: 18 },
  { id: "TANK-GAS-KT", name: "金坛地下盐穴储气库 #A2 溶腔", tankType: "地下储气库", capacityKcm: 500000, currentVolumeKcm: 412000, utilizationRatePercentage: 82.4, feedInRateM3Hour: 15000, dischargeRateM3Hour: 22000, estimatedDepletionDays: 60 }
];

// 全球海运油轮
export const energyVessels: EnergyVessel[] = [
  { id: "VESSEL-01", name: "中石化远洋“远盛号” (VLCC)", imoNumber: "IMO 9874526", cargoType: "原油", deadweightTons: 308000, lat: 12.456, lng: 52.876, speedKnots: 14.5, destinationPort: "宁波舟山港", eta: "2026-09-24", currentLoadPercentage: 100 },
  { id: "VESSEL-02", name: "“申能精神”号 LNG运输船", imoNumber: "IMO 9723654", cargoType: "LNG", deadweightTons: 82000, lat: 21.324, lng: 115.452, speedKnots: 16.8, destinationPort: "青岛港", eta: "2026-09-19", currentLoadPercentage: 100 },
  { id: "VESSEL-03", name: "“华川4”号 液体化学品船", imoNumber: "IMO 9456321", cargoType: "化学品", deadweightTons: 25000, lat: 31.205, lng: 122.342, speedKnots: 12.0, destinationPort: "南京扬子石化码头", eta: "2026-09-18", currentLoadPercentage: 45 }
];

// 原油经济核算中心 (Crude Slate Choice)
export const crudeCargos: CrudeCargo[] = [
  { id: "CRUDE-AL", name: "沙特轻质阿拉伯原油", apiGravity: 34.0, sulfurPercentage: 1.78, densityGcm3: 0.855, pricePerBarrelUSD: 78.4, freightCostUSD: 2.1, deliveryPort: "董家口港", inventoryKiloTons: 1250, contractId: "CONT-SINO-SA2026-09", vesselEta: "已入库" },
  { id: "CRUDE-OM", name: "阿曼混合原油", apiGravity: 31.2, sulfurPercentage: 1.45, densityGcm3: 0.869, pricePerBarrelUSD: 76.5, freightCostUSD: 1.8, deliveryPort: "舟山港", inventoryKiloTons: 840, contractId: "CONT-SINO-OM2026-04", vesselEta: "2026-09-21" },
  { id: "CRUDE-DQ", name: "大庆原油", apiGravity: 31.8, sulfurPercentage: 0.11, densityGcm3: 0.866, pricePerBarrelUSD: 82.0, freightCostUSD: 0.3, deliveryPort: "大庆铁路专用库", inventoryKiloTons: 450, contractId: "CONT-SINO-DOMESTIC", vesselEta: "管道输送" },
  { id: "CRUDE-UR", name: "俄罗斯乌拉尔原油", apiGravity: 32.0, sulfurPercentage: 1.62, densityGcm3: 0.865, pricePerBarrelUSD: 72.5, freightCostUSD: 3.5, deliveryPort: "湛江港", inventoryKiloTons: 1600, contractId: "CONT-SINO-RU2026-11", vesselEta: "2026-09-25" }
];

// 中国石化零售加油站 (包含单站数字孪生)
export const retailStations: RetailFuelStation[] = [
  {
    id: "STATION-BJ-01",
    name: "中国石化北京朝阳综合加能站",
    coordinate: [39.9042, 116.4074],
    dailyGasolineSalesLiter: 18500,
    dailyDieselSalesLiter: 6400,
    passengerFlow: 1240,
    priceGasoline92: 7.82,
    priceGasoline95: 8.35,
    priceDiesel0: 7.50,
    tanksStatus: [
      { tankId: "TK-92-1", product: "92号汽油", capacityLiter: 30000, currentLiter: 18450 },
      { tankId: "TK-95-1", product: "95号汽油", capacityLiter: 30000, currentLiter: 22100 },
      { tankId: "TK-00-1", product: "0号柴油", capacityLiter: 40000, currentLiter: 12400 }
    ],
    dispensersCount: 6,
    nozzlesStatus: [
      { nozzleId: "NZ-1", dispenserId: "DSP-1", product: "92号汽油", status: "加油中" },
      { nozzleId: "NZ-2", dispenserId: "DSP-1", product: "95号汽油", status: "空闲" },
      { nozzleId: "NZ-3", dispenserId: "DSP-2", product: "92号汽油", status: "加油中" },
      { nozzleId: "NZ-4", dispenserId: "DSP-2", product: "0号柴油", status: "空闲" }
    ],
    convenienceStoreSalesRMB: 8420,
    evChargingSlots: { total: 12, occupied: 8, powerKw: 120 },
    hydrogenStation: { available: true, hydrogenStorageKg: 1200, dailyRefuelKg: 450 },
    carWashService: true
  },
  {
    id: "STATION-SH-02",
    name: "中国石化上海浦东氢电能合一超极站",
    coordinate: [31.2304, 121.4737],
    dailyGasolineSalesLiter: 22000,
    dailyDieselSalesLiter: 14500,
    passengerFlow: 1850,
    priceGasoline92: 7.80,
    priceGasoline95: 8.33,
    priceDiesel0: 7.48,
    tanksStatus: [
      { tankId: "TK-92-1", product: "92号汽油", capacityLiter: 50000, currentLiter: 34100 },
      { tankId: "TK-95-1", product: "95号汽油", capacityLiter: 50000, currentLiter: 41200 },
      { tankId: "TK-00-1", product: "0号柴油", capacityLiter: 50000, currentLiter: 21800 }
    ],
    dispensersCount: 8,
    nozzlesStatus: [
      { nozzleId: "NZ-1", dispenserId: "DSP-1", product: "92号汽油", status: "加油中" },
      { nozzleId: "NZ-2", dispenserId: "DSP-1", product: "95号汽油", status: "空闲" },
      { nozzleId: "NZ-3", dispenserId: "DSP-3", product: "95号汽油", status: "加油中" },
      { nozzleId: "NZ-4", dispenserId: "DSP-4", product: "0号柴油", status: "加油中" }
    ],
    convenienceStoreSalesRMB: 15600,
    evChargingSlots: { total: 24, occupied: 18, powerKw: 360 },
    hydrogenStation: { available: true, hydrogenStorageKg: 2500, dailyRefuelKg: 1100 },
    carWashService: true
  }
];

// 设备管理 (Pump, Compressor, column)
export const deviceAssets: IndustrialDeviceAsset[] = [
  { id: "DEV-CDU-P101", name: "常减压装置原料泵 #A", type: "离心泵", refineryOrFieldId: "REFINERY-ZH", operatingHours: 18540, maintenanceCount: 8, failureCount: 1, costRMB: 340000, reliabilityPercentage: 99.4, currentVibrationMmS: 2.1, currentTemperatureCelsius: 58.4, currentPressureMpa: 1.6, currentElectricCurrentAmpere: 125, healthScore: 94, anomalyProbabilityPercentage: 1.2, predictedFailureMode: "无", remainingUsefulLifeDays: 320, recommendedMaintenanceWindow: "4个月后" },
  { id: "DEV-FCC-C201", name: "催化裂化富气压缩机组 #1", type: "往复式压缩机", refineryOrFieldId: "REFINERY-ZH", operatingHours: 32400, maintenanceCount: 14, failureCount: 3, costRMB: 4850000, reliabilityPercentage: 97.2, currentVibrationMmS: 5.8, currentTemperatureCelsius: 112.5, currentPressureMpa: 2.4, currentElectricCurrentAmpere: 450, healthScore: 82, anomalyProbabilityPercentage: 18.5, predictedFailureMode: "气阀断裂", remainingUsefulLifeDays: 45, recommendedMaintenanceWindow: "建议45天内预防性维护" },
  { id: "DEV-CDU-T101", name: "常减压主初馏塔", type: "常压蒸馏塔", refineryOrFieldId: "REFINERY-ZH", operatingHours: 85000, maintenanceCount: 4, failureCount: 0, costRMB: 12500000, reliabilityPercentage: 99.9, currentVibrationMmS: 0.2, currentTemperatureCelsius: 320.5, currentPressureMpa: 0.3, currentElectricCurrentAmpere: 0, healthScore: 98, anomalyProbabilityPercentage: 0.1, predictedFailureMode: "无", remainingUsefulLifeDays: 1450, recommendedMaintenanceWindow: "下一大修周期(1.5年后)" }
];

// 安全事件与报警
export const hseIncidentAlerts: HSEIncidentAlert[] = [
  { id: "ALERT-HSE-01", siteName: "镇海炼化原油罐区", dangerLevel: "中", type: "环保排放超标", coordinate: [29.967, 121.633], timestamp: "2026-09-17 08:30:12", personnelInAreaCount: 14, vehicleInAreaCount: 2, responseStatus: "已处置关闭" },
  { id: "ALERT-HSE-02", siteName: "顺北4号集气站", dangerLevel: "高", type: "高压超限", coordinate: [41.288, 82.885], timestamp: "2026-09-17 11:24:55", personnelInAreaCount: 4, vehicleInAreaCount: 1, responseStatus: "应急小组前往" }
];

export const environmentalEmission: EnvironmentalEmissionMetrics = {
  wasteGasFlowKcmHour: 350.4,
  wasteWaterFlowM3Hour: 180.2,
  vocsPpm: 2.1,
  methanePpm: 0.85,
  so2MgM3: 12.4,
  noxMgM3: 38.5,
  codMgL: 42.0,
  heavyMetalLevel: "合格"
};

// 财务分析
export const groupFinance: EnergyIndustrialFinance = {
  revenueBillionRMB: 1452.4,
  costBillionRMB: 1280.8,
  grossProfitMarginPercentage: 11.8,
  ebitdaBillionRMB: 185.4,
  capexBillionRMB: 98.5,
  opexBillionRMB: 142.0,
  inventoryValueBillionRMB: 345.8,
  upstreamProfitBillionRMB: 34.2,
  refiningProfitBillionRMB: 54.8,
  chemicalProfitBillionRMB: 42.1,
  retailProfitBillionRMB: 32.5
};

// 投资项目
export const investmentProjects: EnergyProjectInvestment[] = [
  {
    id: "PRJ-001",
    name: "顺北超深层油气田四期产能建设",
    type: "深海气田开发",
    capexBillionRMB: 14.2,
    opexAnnualBillionRMB: 0.85,
    npvBillionRMB: 4.85,
    irrPercentage: 14.5,
    paybackPeriodYears: 5.2,
    cashFlowSeries: [-14.2, -5.2, 1.2, 2.8, 3.5, 4.2, 4.2, 4.0, 3.8, 3.5],
    sensitivityAnalysis: [
      { variable: "油价上涨10%", resultIRR: 16.8 },
      { variable: "油价下跌10%", resultIRR: 11.2 },
      { variable: "产量下降5%", resultIRR: 13.1 },
      { variable: "CAPEX超支15%", resultIRR: 12.4 }
    ]
  },
  {
    id: "PRJ-002",
    name: "镇海炼化120万吨/年乙烯成套技术升级项目",
    type: "炼厂乙烯升级",
    capexBillionRMB: 8.5,
    opexAnnualBillionRMB: 0.45,
    npvBillionRMB: 2.95,
    irrPercentage: 12.8,
    paybackPeriodYears: 6.0,
    cashFlowSeries: [-8.5, -2.4, 0.8, 1.5, 2.1, 2.5, 2.5, 2.4, 2.2, 2.0],
    sensitivityAnalysis: [
      { variable: "油价上涨10%", resultIRR: 13.4 },
      { variable: "油价下跌10%", resultIRR: 12.1 },
      { variable: "产量下降5%", resultIRR: 11.5 },
      { variable: "CAPEX超支15%", resultIRR: 10.8 }
    ]
  }
];

// 风险指标
export const energyRiskIndicators: EnergyRiskIndicator[] = [
  { type: "供应风险", name: "马六甲海峡航道拥堵导致到港延迟", level: "黄色警告", valueAtRiskBillionRMB: 1.2, stressTestScenario: "航道彻底关闭5天", impactDescription: "原油到货周期增加72小时，触发库存安全警报" },
  { type: "价格波动风险", name: "WTI/Brent价格剧烈震荡", level: "橙色预警", valueAtRiskBillionRMB: 4.5, stressTestScenario: "原油暴跌15美元/桶", impactDescription: "下游炼厂原油库存减值准备计提，库存账面损失" },
  { type: "设备安全风险", name: "超深井水平段高压卡钻风险", level: "正常", valueAtRiskBillionRMB: 0.15, stressTestScenario: "卡钻导致修井周期增加15天", impactDescription: "顺北区块单井钻探成本上升" }
];

// 历史操作与OT隔离日志
export const auditLogs: AuditLogEntry[] = [
  { id: "LOG-10025", operatorName: "张建国", operatorRole: "炼化中控调度员", actionType: "工艺负荷变更", targetEntity: "常减压蒸馏装置(CDU-04)", description: "调节常减压装置负荷从85%提升至95%，以响应下游柴油组分采购合同。", timestamp: "2026-09-17 09:12:44", clientIp: "10.233.12.88", isOTControl: true, mfaVerified: true, supervisorApproved: true, signatureHash: "SHA256:8b4e7e9a2b5d4e1a0c8b..." },
  { id: "LOG-10026", operatorName: "刘志伟", operatorRole: "油田现场总工", actionType: "阀门开启/关闭", targetEntity: "顺北气田4号集气站井口阀", description: "井口立管高压预警，实施远控截断阀关闭测试，隔离A段集气总管。", timestamp: "2026-09-17 11:26:00", clientIp: "10.233.45.12", isOTControl: true, mfaVerified: true, supervisorApproved: true, signatureHash: "SHA256:d4e1a8b7c5e2a3d0f1b2..." }
];

// 工业数据血缘追踪数据字典
export const dataLineageDatabase: Record<string, DataLineage> = {
  "group-operating-rate": {
    id: "LIN-001",
    metricName: "集团炼厂平均开工率",
    value: "86.4%",
    unit: EnergyUnit.TEN_KILO_TON,
    source: "MES",
    equipmentId: "CDU-CDU-CDU",
    equipmentName: "中国石化全国20家代表性常减压装置组群",
    timestamp: "2026-09-17 06:00:00",
    calculationFormula: "∑(各炼厂实际加工量) / ∑(各炼厂设计加工额度)",
    modelType: "线性调控规划模型",
    parametersApplied: "设计最大负荷: 14.2M T/yr, 检修扣除系数: 0.94",
    dataVersion: "VER-20260917-0600",
    quality: DataQuality.EXCELLENT
  },
  "refinery-processing-vol": {
    id: "LIN-002",
    metricName: "炼厂日加工量",
    value: "115.6 万吨/日",
    unit: EnergyUnit.TEN_KILO_TON,
    source: "DCS",
    equipmentId: "REFINERY-ZH",
    equipmentName: "镇海炼化常减压蒸馏塔组",
    timestamp: "2026-09-17 06:15:30",
    calculationFormula: "流量计累计体积流量 * 原油在线密度 (温度、压力补偿修正)",
    modelType: "API MPMS 物理计算规程",
    parametersApplied: "API温压修正因子: 0.9854, 质量标定指数: 0.9995",
    dataVersion: "VER-20260917-0615",
    quality: DataQuality.EXCELLENT
  },
  "pipeline-pressure": {
    id: "LIN-003",
    metricName: "管道起点压力",
    value: "10.0 MPa",
    unit: EnergyUnit.MJ,
    source: "SCADA",
    equipmentId: "PIPE-G01",
    equipmentName: "川气东送主管道起点压力传感器 PT-102",
    timestamp: "2026-09-17 06:29:45",
    calculationFormula: "传感器压电石英敏感元件微电信号变送物理转换",
    modelType: "SCADA实时变送算法",
    parametersApplied: "电信号滤波系数: 0.05, 零点校准偏移: 0.001Mpa",
    dataVersion: "VER-20260917-0629",
    quality: DataQuality.GOOD
  }
};


// 二、物理-数学仿真引擎 (Physics & Optimization Engineering Engines)

// 1. 炼厂生产负荷平衡仿真计算
// 输入: 负荷比例 (+10%, -10%), 原油来源(API, 硫), 输出: 产量, 耗能, 成本, 利润
export interface RefinerySimulationResult {
  crudeFeedrate: number;
  gasolineYield: number;
  dieselYield: number;
  jetFuelYield: number;
  petrochemicalYield: number;
  energyConsumption: number;
  carbonEmissions: number;
  grossRevenue: number;
  netProfit: number;
  formulas: { name: string; math: string }[];
}

export function simulateRefineryOperations(
  loadDeltaPercentage: number, // e.g. -10, 0, +10
  crudeId: string // "CRUDE-AL" | "CRUDE-OM" | "CRUDE-DQ" | "CRUDE-UR"
): RefinerySimulationResult {
  const baseFeedrate = 50000; // 5万吨/日 (大炼厂典型规模)
  const feedrate = baseFeedrate * (1 + loadDeltaPercentage / 100);

  // 原油品质参数对收率的影响
  const crude = crudeCargos.find(c => c.id === crudeId) || crudeCargos[0];
  
  // 收率计算公式 (Simplified active Linear Program matrix for distillation fractions)
  // API高, 汽油石脑油多; 硫高, 环保能耗加重
  const apiFactor = crude.apiGravity / 32; // >1 表示轻质
  const sulfurFactor = crude.sulfurPercentage / 1.5; // >1 表示高硫

  const baseGasolineRate = 0.22 * apiFactor;
  const baseDieselRate = 0.35 * (2 - apiFactor);
  const baseJetRate = 0.12 * apiFactor;
  const basePetroRate = 0.18 * apiFactor;

  // 得到产量
  const gasolineYield = feedrate * baseGasolineRate;
  const dieselYield = feedrate * baseDieselRate;
  const jetFuelYield = feedrate * baseJetRate;
  const petrochemicalYield = feedrate * basePetroRate;

  // 能耗和碳排放
  const baseEnergyGjPerTon = 2.5 * (1 + (sulfurFactor - 1) * 0.15); // 高硫脱硫耗能重
  const totalEnergy = feedrate * baseEnergyGjPerTon;
  const carbonEmissions = totalEnergy * 0.056; // 吨碳/吉焦折算

  // 经济核算
  // 原油价格 + 运费
  const costPerBarrel = crude.pricePerBarrelUSD + crude.freightCostUSD;
  const barrelToTon = 7.3; // 原油桶到吨折算
  const rawMaterialCostRMB = feedrate * costPerBarrel * barrelToTon * 7.15; // 7.15 汇率

  // 能源成本 (1吉焦约80元RMB)
  const energyCostRMB = totalEnergy * 80;
  const totalCostRMB = rawMaterialCostRMB + energyCostRMB + feedrate * 120; // 120元/吨 固定加工折旧

  // 销售收入 (成品油价格)
  const priceGasolineRMB = 8500; // 元/吨
  const priceDieselRMB = 7200;
  const priceJetRMB = 7800;
  const pricePetroRMB = 9200;

  const grossRevenue = 
    gasolineYield * priceGasolineRMB + 
    dieselYield * priceDieselRMB + 
    jetFuelYield * priceJetRMB + 
    petrochemicalYield * pricePetroRMB;

  const netProfit = grossRevenue - totalCostRMB;

  return {
    crudeFeedrate: Math.round(feedrate),
    gasolineYield: Math.round(gasolineYield),
    dieselYield: Math.round(dieselYield),
    jetFuelYield: Math.round(jetFuelYield),
    petrochemicalYield: Math.round(petrochemicalYield),
    energyConsumption: Math.round(totalEnergy),
    carbonEmissions: Math.round(carbonEmissions),
    grossRevenue: Math.round(grossRevenue),
    netProfit: Math.round(netProfit),
    formulas: [
      { name: "原油总处理量 (Crude Throughput)", math: `CDU_{feed} = BaseFeed \\times (1 + \\Delta_{load})` },
      { name: "汽油物料平衡收率 (Gasoline Yield Model)", math: `Yield_{gas} = CDU_{feed} \\times 22\\% \\times (API_{gravity} / 32.0)` },
      { name: "炼厂绿色低碳排放核算 (Carbon Emission Accounting)", math: `CO2_{emissions} = \\sum (Energy_{source} \\times Factor_{IPCC})` },
      { name: "原油桶吨转换核算 (Crude Unit Trans)", math: `Cost_{raw} = Feed \\times (Price_{barrel} + Freight) \\times 7.3 \\times FX_{usd\\_to\\_rmb}` }
    ]
  };
}

// 2. 管网水力流体流动仿真引擎
// 模拟管线在不同流量、泄漏、阀门开启或泵站关闭下的压降和瓶颈
export interface HydraulicSimResult {
  endPressureMpa: number;
  pressureDropMpa: number;
  maxFlowRateTonsPerHour: number;
  bottleneckDetected: boolean;
  bottleneckLocation?: string;
  energyConsumptionKwh: number;
  formulas: { name: string; math: string }[];
}

export function simulatePipelineHydraulics(
  pipelineId: string,
  inputFlowRateTonsPerHour: number,
  pumpStationActive: boolean,
  demandShiftPercentage: number // e.g. +20, 0, -20
): HydraulicSimResult {
  const pipe = pipelineTwins.find(p => p.id === pipelineId) || pipelineTwins[0];
  const flow = inputFlowRateTonsPerHour * (1 + demandShiftPercentage / 100);

  // 采用经典的达西-魏斯巴赫(Darcy-Weisbach)和哈森-威廉斯(Hazen-Williams)公式进行压降模拟
  // 压降正比于长度, 正比于流量的平方, 反比于管径的5次方
  const lengthRatio = pipe.lengthKm / 1000;
  const diameterRatio = Math.pow(800 / pipe.diameterMm, 5);
  const flowRatio = Math.pow(flow / 1500, 2);

  let frictionFactor = 0.02; // 钢管摩阻系数
  if (pipe.corrosionStatus === "需立即维护") frictionFactor = 0.035;
  else if (pipe.corrosionStatus === "中度腐蚀") frictionFactor = 0.028;

  // 理论压降计算 (MPa)
  let pressureDrop = 2.5 * lengthRatio * diameterRatio * flowRatio * (frictionFactor / 0.02);
  
  // 泵站提供的增压作用
  const pumpBoost = pumpStationActive ? 4.5 : 0;
  const sourcePressure = pipe.pressureMpa;
  let endPressure = sourcePressure + pumpBoost - pressureDrop;

  // 管道极限流速瓶颈检测 (若终点压力低于 0.8 MPa 表示汽化或输送动力不足，发生气塞瓶颈)
  let bottleneck = false;
  let loc = "";
  if (endPressure < 0.8) {
    bottleneck = true;
    loc = `${pipe.name}中段 (里程 K${Math.round(pipe.lengthKm * 0.6)}处压力触底 ${endPressure.toFixed(2)} Mpa)`;
    endPressure = 0.8; // 压降钳制
    pressureDrop = sourcePressure + pumpBoost - endPressure;
  }

  // 泵站功耗 (P = Q * H / eta)
  const motorEfficiency = 0.82;
  const powerKw = pumpStationActive ? (flow * (pumpBoost * 100) / (3600 * motorEfficiency)) : 0;

  return {
    endPressureMpa: parseFloat(endPressure.toFixed(2)),
    pressureDropMpa: parseFloat(pressureDrop.toFixed(2)),
    maxFlowRateTonsPerHour: Math.round(pipe.designCapacityMillionTonsPerYear * 1000000 / 8760), // 万吨/年折合小时
    bottleneckDetected: bottleneck,
    bottleneckLocation: loc || undefined,
    energyConsumptionKwh: Math.round(powerKw),
    formulas: [
      { name: "达西-魏斯巴赫压降公式 (Darcy-Weisbach Equation)", math: `\\Delta P = \\lambda \\times \\frac{L}{D} \\times \\frac{\\rho v^2}{2}` },
      { name: "管线流速换算 (Pipeline Velocity)", math: `v = \\frac{4Q}{\\pi D^2 \\rho}` },
      { name: "输油泵站轴功率 (Centrifugal Pump Shaft Power)", math: `P_{pump} = \\frac{Q \\times \\Delta P_{boost}}{3.6 \\times \\eta_{motor}}` }
    ]
  };
}

// 3. 生产产量预测与储层采收率仿真
// 采用 Arps 递减曲线预测未来 30 天日产量
export interface ArpsDeclineResult {
  future30DaysTrend: { day: number; oilProduction: number; waterProduction: number; pressure: number }[];
  initialProduction: number;
  finalProduction: number;
  eurMillionTons: number;
  remainingReserves: number;
  formulas: { name: string; math: string }[];
}

export function simulateArpsDecline(
  wellId: string,
  declineModel: "Exponential" | "Hyperbolic" | "Harmonic",
  declineRate: number, // 0.05 到 0.50
  hyperbolicExponent: number = 0.5 // 双曲指数 0 到 1
): ArpsDeclineResult {
  const baseDailyProduction = 45; // 45 吨/天
  const baseWaterCut = 0.42; // 42% 含水
  const basePressure = 15.0; // 15Mpa

  const trend: { day: number; oilProduction: number; waterProduction: number; pressure: number }[] = [];
  
  // 30天预测
  for (let i = 1; i <= 30; i++) {
    const t = i / 365; // 折算成年
    let q_oil = baseDailyProduction;

    if (declineModel === "Exponential") {
      // q(t) = q0 * e^(-D * t)
      q_oil = baseDailyProduction * Math.exp(-declineRate * t);
    } else if (declineModel === "Hyperbolic") {
      // q(t) = q0 / (1 + b * D0 * t)^(1/b)
      q_oil = baseDailyProduction / Math.pow(1 + hyperbolicExponent * declineRate * t, 1 / hyperbolicExponent);
    } else {
      // Harmonic: q(t) = q0 / (1 + D0 * t)
      q_oil = baseDailyProduction / (1 + declineRate * t);
    }

    const waterCut = Math.min(0.98, baseWaterCut * (1 + 0.12 * Math.sqrt(t)));
    const pressure = Math.max(1.5, basePressure * (1 - 0.05 * Math.sqrt(t)));

    trend.push({
      day: i,
      oilProduction: parseFloat(q_oil.toFixed(2)),
      waterProduction: parseFloat((q_oil * waterCut / (1 - waterCut)).toFixed(2)),
      pressure: parseFloat(pressure.toFixed(2))
    });
  }

  // 长期 EUR 预测 (15年)
  let totalEUR = 0;
  for (let i = 1; i <= 365 * 15; i++) {
    const t = i / 365;
    let q_oil = baseDailyProduction;
    if (declineModel === "Exponential") {
      q_oil = baseDailyProduction * Math.exp(-declineRate * t);
    } else if (declineModel === "Hyperbolic") {
      q_oil = baseDailyProduction / Math.pow(1 + hyperbolicExponent * declineRate * t, 1 / hyperbolicExponent);
    } else {
      q_oil = baseDailyProduction / (1 + declineRate * t);
    }
    totalEUR += q_oil / 10000; // 万吨
  }

  return {
    future30DaysTrend: trend,
    initialProduction: baseDailyProduction,
    finalProduction: trend[29].oilProduction,
    eurMillionTons: parseFloat((totalEUR / 100).toFixed(4)), // 亿吨
    remainingReserves: parseFloat((totalEUR / 100 * 0.85).toFixed(4)),
    formulas: [
      { name: "Exponential (指数递减模型)", math: `q(t) = q_0 \\cdot e^{-D \\cdot t}` },
      { name: "Hyperbolic (双曲递减模型)", math: `q(t) = \\frac{q_0}{(1 + b \\cdot D \\cdot t)^{1/b}}` },
      { name: "Harmonic (调和递减模型)", math: `q(t) = \\frac{q_0}{1 + D \\cdot t}` },
      { name: "油藏可采储量 (EUR - Estimated Ultimate Recovery)", math: `EUR = \\int_{0}^{t_{limit}} q(t) dt` }
    ]
  };
}

// Re-export type definitions
export type { MassEnergyBalanceReport } from "./types";

// Aligned Aliases for Modular Cockpit Components
export const groupOverviewMetrics = {
  dailyTotalRevenueBillionRmb: 3.98, // 约1450亿年营收折算到单日
  dailyCrudeOilProductionKiloTons: 64.2, // 万吨/日
  dailyNaturalGasProductionMillionCbm: 14.5, // 百万标方/日
  refineryOperatingLoadPercentage: 86.4,
  pipelineThroughputKiloTonsDaily: 218.0,
  globalEquityCrudeReservesBillionBarrels: 15.42
};

export const systemStatusIndicators = {
  assetSecurityStatus: "特等甲级稳健",
  environmentalComplianceScore: "环保等级A级",
  carbonIntensityIndex: 42.5,
  systemDataVersion: "VER-20260917-0615"
};

export const groupFinanceData = groupFinance;

export const commoditiesPriceTicker = [
  { name: "布伦特原油", commodityCode: "BRENT", exchange: "ICE", currentPriceUSD: 78.42, changePercentage: 1.25, unit: "/桶" },
  { name: "WTI轻质原油", commodityCode: "WTI", exchange: "NYMEX", currentPriceUSD: 74.15, changePercentage: -0.84, unit: "/桶" },
  { name: "新加坡航煤", commodityCode: "JET-SG", exchange: "SGX", currentPriceUSD: 94.60, changePercentage: 0.45, unit: "/桶" }
];

export const globalCrudeTrades = crudeCargos.map((c, idx) => ({
  id: c.id,
  cargoName: c.name,
  hedgingStatus: idx === 0 ? "已全额对冲" : "部分套保",
  carrierVesselImo: c.id === "CRUDE-AL" ? "IMO 9874526" : "IMO 9723654",
  contractValueMillionUSD: parseFloat((c.inventoryKiloTons * c.pricePerBarrelUSD * 7.3 * 0.001).toFixed(1)),
  crudeGrade: c.name,
  volumeKiloBarrels: parseFloat((c.inventoryKiloTons * 7.3).toFixed(1)),
  loadingPort: "中东拉斯塔努拉",
  loadDate: "2026-09-01",
  dischargePort: c.deliveryPort,
  etaDischargeDate: c.vesselEta,
  derivativeHedgingInstrument: "WTI Crude Futures / SGX Fuel Swap",
  hedgedStrikePricePerBarrelUSD: c.pricePerBarrelUSD - 1.2,
  unhedgedExposureValueMillionUSD: 1.5,
  freightCostMillionUSD: 0.8
}));

export const machineryEquipment = deviceAssets.map(d => ({
  id: d.id,
  name: d.name,
  location: d.refineryOrFieldId === "REFINERY-ZH" ? "镇海炼化 CDU-04" : "茂名石化 FCC-02",
  healthIndexXgboost: d.healthScore,
  runningHours: d.operatingHours,
  vibrationMmPerSecond: d.currentVibrationMmS,
  vibrationSeverity: d.healthScore > 90 ? "良好" : d.healthScore > 80 ? "注意" : "异常",
  diagnoseFaultType: d.predictedFailureMode === "无" ? "健康标称" : d.predictedFailureMode,
  remainingUsefulLifeDays: d.remainingUsefulLifeDays
}));

export const hseAlarms = hseIncidentAlerts.map(a => ({
  id: a.id,
  indicatorName: a.type,
  sensorId: a.id.replace("ALERT", "SNS"),
  hazardLevel: a.dangerLevel,
  location: a.siteName,
  measuredValue: a.personnelInAreaCount > 0 ? `区域发现人员 ${a.personnelInAreaCount} 人` : "探针信号漂移",
  standardLimit: "防爆限制等级-0",
  alarmTimestamp: a.timestamp,
  status: a.responseStatus === "已处置关闭" ? "已闭环" : "未处理"
}));

export const ccusSequestrationPlans = [
  {
    id: "CCUS-JL-01",
    projectName: "吉林咸水层项目",
    sequestrationMedium: "超临界CO₂",
    sequestrationDepthMeter: 2450,
    injectionPressureMpa: 15.4,
    dailyCaptureTons: 1500,
    accumulatedSequestrationKiloTons: 324.5,
    aquiferPorosityRatio: 0.18,
    permeabilityMillidarcy: 25
  },
  {
    id: "CCUS-SH-02",
    projectName: "胜利油田注气项目",
    sequestrationMedium: "超临界CO₂",
    sequestrationDepthMeter: 3120,
    injectionPressureMpa: 18.2,
    dailyCaptureTons: 800,
    accumulatedSequestrationKiloTons: 124.2,
    aquiferPorosityRatio: 0.12,
    permeabilityMillidarcy: 15
  }
];
