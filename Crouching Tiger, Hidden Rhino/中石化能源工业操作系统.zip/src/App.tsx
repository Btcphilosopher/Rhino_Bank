/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { 
  groupOverviewMetrics, 
  countriesAsset, 
  DATA_SOURCE_NOTICE, 
  systemStatusIndicators 
} from "./data";
import { GlobalCountryAsset } from "./types";

// Import Custom Modular Views
import MapControl from "./components/MapControl";
import ExplorationView from "./components/ExplorationView";
import DrillingWellView from "./components/DrillingWellView";
import PipelineView from "./components/PipelineView";
import RefineryView from "./components/RefineryView";
import EquipmentView from "./components/EquipmentView";
import HseCarbonView from "./components/HseCarbonView";
import ScenarioLabView from "./components/ScenarioLabView";
import FinanceTradeView from "./components/FinanceTradeView";
import AiAssistant from "./components/AiAssistant";

// Icons from lucide-react
import { 
  Globe, Compass, Database, Activity, Radio, Sliders, Shield, DollarSign, Bot, ShieldAlert, Cpu 
} from "lucide-react";

type ModuleType = 
  | "global_assets" 
  | "exploration" 
  | "drilling_production" 
  | "pipelines" 
  | "refining" 
  | "machinery" 
  | "hse_carbon" 
  | "finance_trade"
  | "scenario_lab" 
  | "ai_assistant";

export default function App() {
  const [activeModule, setActiveModule] = useState<ModuleType>("global_assets");
  const [selectedCountry, setSelectedCountry] = useState<GlobalCountryAsset>(countriesAsset[0]); // Default to China

  // Sidebar navigation configuration
  const sidebarItems = [
    { id: "global_assets" as ModuleType, label: "全球资源资源勘误", icon: Globe, color: "text-red-500" },
    { id: "exploration" as ModuleType, label: "智能勘探板块", icon: Database, color: "text-yellow-500" },
    { id: "drilling_production" as ModuleType, label: "钻井开采分析", icon: Activity, color: "text-blue-500" },
    { id: "pipelines" as ModuleType, label: "长输管网调度", icon: Radio, color: "text-orange-500" },
    { id: "refining" as ModuleType, label: "炼化联合工艺", icon: Sliders, color: "text-red-400" },
    { id: "machinery" as ModuleType, label: "设备健康预测", icon: Cpu, color: "text-purple-400" },
    { id: "hse_carbon" as ModuleType, label: "安全环保碳控", icon: Shield, color: "text-emerald-400" },
    { id: "finance_trade" as ModuleType, label: "财务套保贸易", icon: DollarSign, color: "text-yellow-400" },
    { id: "scenario_lab" as ModuleType, label: "能源沙盘克隆", icon: Compass, color: "text-cyan-400" },
    { id: "ai_assistant" as ModuleType, label: "中枢智能顾问", icon: Bot, color: "text-red-500 animate-pulse" },
  ];

  const handleSelectCountryFromMap = (country: GlobalCountryAsset) => {
    setSelectedCountry(country);
  };

  return (
    <div className="min-h-screen bg-[#0e1013] text-[#cfd6e0] flex flex-col font-sans select-none overflow-hidden">
      
      {/* ==================== 1. 顶栏 (Professional Industrial Header) ==================== */}
      <header className="h-14 bg-[#14171d] border-b border-[#242931] px-6 flex items-center justify-between shrink-0 z-20">
        <div className="flex items-center gap-3">
          {/* SINOPEC Logo Placeholder */}
          <div className="w-6 h-6 rounded-full bg-red-600 flex items-center justify-center font-bold text-white text-xs tracking-tighter">
            S
          </div>
          <div className="flex flex-col">
            <h1 className="text-[13px] font-bold text-white tracking-widest flex items-center gap-1.5">
              <span>中国石化能源工业操作系统</span>
              <span className="text-[10px] text-red-500 font-extrabold px-1.5 py-0.5 rounded border border-red-900 bg-[#251518]">SEIOS</span>
            </h1>
            <span className="text-[9px] text-[#5c6470] tracking-wider uppercase font-mono">
              SINOPEC ENERGY INDUSTRIAL OPERATING SYSTEM | GLOBAL COCKPIT
            </span>
          </div>
        </div>

        {/* 顶部中央: 生产安全/环保核心运行指标 (OT Status LEDs) */}
        <div className="hidden lg:flex items-center gap-6 text-[10px] font-mono">
          <div className="flex items-center gap-2 bg-[#191d24] border border-[#262c37] px-2.5 py-1 rounded">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-[#8c96a3]">资产安全防护:</span>
            <strong className="text-emerald-400">{systemStatusIndicators.assetSecurityStatus}</strong>
          </div>
          <div className="flex items-center gap-2 bg-[#191d24] border border-[#262c37] px-2.5 py-1 rounded">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span className="text-[#8c96a3]">安全环保评级:</span>
            <strong className="text-emerald-400">{systemStatusIndicators.environmentalComplianceScore}</strong>
          </div>
          <div className="flex items-center gap-2 bg-[#191d24] border border-[#262c37] px-2.5 py-1 rounded">
            <span className="w-2 h-2 rounded-full bg-blue-500" />
            <span className="text-[#8c96a3]">综合碳排强度:</span>
            <strong className="text-blue-400">{systemStatusIndicators.carbonIntensityIndex} kgCO2/t</strong>
          </div>
          <div className="flex items-center gap-2 bg-[#191d24] border border-[#262c37] px-2.5 py-1 rounded">
            <span className="text-[#8c96a3]">系统数据版本:</span>
            <strong className="text-yellow-500">{systemStatusIndicators.systemDataVersion}</strong>
          </div>
        </div>

        {/* 声明 & 安全警告 */}
        <div className="flex items-center gap-2 font-mono text-[10px]">
          <span className="text-[#ea580c] bg-orange-950/40 border border-orange-900 px-2 py-0.5 rounded font-bold flex items-center gap-1">
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>【{DATA_SOURCE_NOTICE}】</span>
          </span>
        </div>
      </header>

      {/* ==================== 2. 全局核心汇总 HUD 条 (Enterprise KPI Bar) ==================== */}
      <section className="h-16 bg-[#111318] border-b border-[#20252e] px-6 flex items-center justify-between shrink-0 font-mono text-xs overflow-x-auto gap-8 z-10">
        <div className="flex items-center gap-3">
          <span className="text-[#5c6470] font-bold">集团昨日营收:</span>
          <span className="text-white font-bold text-sm">￥{(groupOverviewMetrics.dailyTotalRevenueBillionRmb).toFixed(2)} 亿</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-[#5c6470] font-bold">油田开采总量:</span>
          <span className="text-emerald-400 font-bold text-sm">{(groupOverviewMetrics.dailyCrudeOilProductionKiloTons).toFixed(1)} 万吨/日</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-[#5c6470] font-bold">天然气总供量:</span>
          <span className="text-cyan-400 font-bold text-sm">{(groupOverviewMetrics.dailyNaturalGasProductionMillionCbm).toFixed(1)} 百万方/日</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-[#5c6470] font-bold">炼厂联合负荷:</span>
          <span className="text-white font-bold text-sm">{(groupOverviewMetrics.refineryOperatingLoadPercentage).toFixed(1)}% (标称)</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-[#5c6470] font-bold">管网昨日输量:</span>
          <span className="text-orange-400 font-bold text-sm">{(groupOverviewMetrics.pipelineThroughputKiloTonsDaily).toFixed(1)} 万吨</span>
        </div>
        <div className="flex items-center gap-3 border-l border-[#20252e] pl-4">
          <span className="text-[#5c6470] font-bold">海外权益储量:</span>
          <span className="text-yellow-500 font-bold text-sm">{(groupOverviewMetrics.globalEquityCrudeReservesBillionBarrels).toFixed(2)} 亿桶</span>
        </div>
      </section>

      {/* ==================== 3. 主界面布局 (Sidebar + Content Container) ==================== */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* A. 侧边栏菜单 (Sidebar Command Menu) */}
        <aside className="w-56 bg-[#111317] border-r border-[#20252e] flex flex-col justify-between shrink-0 overflow-y-auto">
          <div className="p-3 flex flex-col gap-1">
            <span className="text-[#5c6470] font-bold text-[9px] uppercase px-3.5 py-1 mb-1 tracking-wider block border-b border-[#20252e]">
              工业业务导航中枢
            </span>
            {sidebarItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeModule === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveModule(item.id)}
                  className={`flex items-center gap-3 px-3.5 py-2.5 rounded transition font-bold text-[11px] text-left ${
                    isActive 
                      ? "bg-[#251518] border-l-4 border-red-600 text-white shadow-inner" 
                      : "text-[#8c96a3] hover:bg-[#161a22] hover:text-white"
                  }`}
                >
                  <Icon className={`w-4 h-4 shrink-0 ${item.color}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>

          {/* 侧栏底部: 当前选定的地理空间上下文 (Linked context) */}
          <div className="p-4 border-t border-[#20252e] bg-[#0c0d10] flex flex-col gap-1.5 font-mono text-[10px]">
            <span className="text-[#5c6470] font-bold">数字孪生当前测点：</span>
            <div className="flex items-center gap-1.5 font-bold text-white">
              <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping" />
              <span>{selectedCountry.name} ({selectedCountry.id})</span>
            </div>
            <div className="text-[9px] text-[#5c6470] flex flex-col gap-0.5 mt-1 leading-normal">
              <span>探明油藏: <strong className="text-gray-300">{selectedCountry.oilFieldsCount} 区块</strong></span>
              <span>在役炼厂: <strong className="text-gray-300">{selectedCountry.refineriesCount} 联合体</strong></span>
              <span>年加工力: <strong className="text-gray-300">{selectedCountry.refiningCapacity} 万吨</strong></span>
            </div>
          </div>
        </aside>

        {/* B. 右侧核心展示区 (Dynamic Viewport) */}
        <main className="flex-1 p-6 overflow-y-auto bg-[#0d0e12] relative">
          
          {/* 全球资源地图视图 */}
          {activeModule === "global_assets" && (
            <div className="flex flex-col gap-6 animate-[fadeIn_0.2s_ease-out]">
              <div className="flex justify-between items-center">
                <div className="flex flex-col gap-1">
                  <h2 className="text-base font-bold text-white tracking-wide">全球油气资源与炼化资产调运总图</h2>
                  <p className="text-[11px] text-[#5c6470] leading-normal font-mono">
                    系统实时汇聚了中国本土（胜利油田、江汉油田、顺北超深井群、镇海炼化等）以及海外中东、西非等10国实测SCADA数据版本。
                  </p>
                </div>
              </div>
              
              <MapControl 
                onSelectCountry={handleSelectCountryFromMap} 
                selectedCountryId={selectedCountry.id} 
              />
            </div>
          )}

          {/* 智能物探视图 */}
          {activeModule === "exploration" && (
            <div className="flex flex-col gap-4 animate-[fadeIn_0.2s_ease-out]">
              <div className="flex flex-col gap-1 mb-2">
                <h2 className="text-base font-bold text-white tracking-wide">智能地震物探与深层圈闭AI解释</h2>
                <p className="text-[11px] text-[#5c6470] font-mono leading-normal">
                  对大面积三维地震波反射层序进行深度反演，结合物理约束神经网络对断层、含油气“甜点”进行透明置信识别。
                </p>
              </div>
              <ExplorationView />
            </div>
          )}

          {/* 钻井采油与产量递减 */}
          {activeModule === "drilling_production" && (
            <div className="flex flex-col gap-4 animate-[fadeIn_0.2s_ease-out]">
              <div className="flex flex-col gap-1 mb-2">
                <h2 className="text-base font-bold text-white tracking-wide">钻井遥测遥控与储层递减数值结算</h2>
                <p className="text-[11px] text-[#5c6470] font-mono leading-normal">
                  直连现场大钩载荷、扭矩及泥浆排量SCADA。集成 Arps 物质平衡常微分方程，解算未来单井递减递变趋势。
                </p>
              </div>
              <DrillingWellView />
            </div>
          )}

          {/* 长输管线压降 */}
          {activeModule === "pipelines" && (
            <div className="flex flex-col gap-4 animate-[fadeIn_0.2s_ease-out]">
              <div className="flex flex-col gap-1 mb-2">
                <h2 className="text-base font-bold text-white tracking-wide">长输管线水力摩阻与泵站负荷优化</h2>
                <p className="text-[11px] text-[#5c6470] font-mono leading-normal">
                  运行 Darcy-Weisbach 动量守恒动水流体力学解算器。交互阀门与变频泵站负荷，评估沿程降压梯度和管道气蚀气锁瓶颈。
                </p>
              </div>
              <PipelineView />
            </div>
          )}

          {/* 炼化工艺平衡 */}
          {activeModule === "refining" && (
            <div className="flex flex-col gap-4 animate-[fadeIn_0.2s_ease-out]">
              <div className="flex flex-col gap-1 mb-2">
                <h2 className="text-base font-bold text-white tracking-wide">炼化联合体装置开工负荷与物料能耗衡算</h2>
                <p className="text-[11px] text-[#5c6470] font-mono leading-normal">
                  在线常减压精馏装置物性分馏计算。结合昨日原料进料与实际收率进行全厂吨位级质量与能量守恒审计。
                </p>
              </div>
              <RefineryView />
            </div>
          )}

          {/* 设备振动 FFT 预测性维护 */}
          {activeModule === "machinery" && (
            <div className="flex flex-col gap-4 animate-[fadeIn_0.2s_ease-out]">
              <div className="flex flex-col gap-1 mb-2">
                <h2 className="text-base font-bold text-white tracking-wide">核心旋转机械预测维护与SIS连锁安全防线</h2>
                <p className="text-[11px] text-[#5c6470] font-mono leading-normal">
                  对大型轴流压缩机组、外输泵主轴承温及高频径向振动进行快频傅里叶反演(FFT)。结合XGBoost算法评估RUL剩余寿命。
                </p>
              </div>
              <EquipmentView />
            </div>
          )}

          {/* 安全环保与CCUS碳封存 */}
          {activeModule === "hse_carbon" && (
            <div className="flex flex-col gap-4 animate-[fadeIn_0.2s_ease-out]">
              <div className="flex flex-col gap-1 mb-2">
                <h2 className="text-base font-bold text-white tracking-wide">HSE 传感器监测与 CCUS 高压储层压缩回注</h2>
                <p className="text-[11px] text-[#5c6470] font-mono leading-normal">
                  监测 VOC 气体泄漏溢散。基于温室气体协议(GHG)多因子核算范围一/二/三，跟踪二氧化碳深部咸水层封存状态。
                </p>
              </div>
              <HseCarbonView />
            </div>
          )}

          {/* 财务精算、套保与大宗贸易 */}
          {activeModule === "finance_trade" && (
            <div className="flex flex-col gap-4 animate-[fadeIn_0.2s_ease-out]">
              <div className="flex flex-col gap-1 mb-2">
                <h2 className="text-base font-bold text-white tracking-wide">集团决算资产负债表与实物商品套保结算</h2>
                <p className="text-[11px] text-[#5c6470] font-mono leading-normal">
                  集中展示全集团 Capex / Opex 资本分配。整合境外大宗现货远期对冲、多枪高压加能加氢站数字孪生参数。
                </p>
              </div>
              <FinanceTradeView />
            </div>
          )}

          {/* 能源沙盘克隆实验 */}
          {activeModule === "scenario_lab" && (
            <div className="flex flex-col gap-4 animate-[fadeIn_0.2s_ease-out]">
              <div className="flex flex-col gap-1 mb-2">
                <h2 className="text-base font-bold text-white tracking-wide">能源地缘政治与宏观沙盘克隆模拟实验室</h2>
                <p className="text-[11px] text-[#5c6470] font-mono leading-normal">
                  支持在线变频模拟全球原油供求周期，运用蒙特卡洛模型迭代10,000次测算财务和供应链风险暴露极值。
                </p>
              </div>
              <ScenarioLabView />
            </div>
          )}

          {/* 中枢智能顾问 AI Assistant */}
          {activeModule === "ai_assistant" && (
            <div className="flex flex-col gap-4 animate-[fadeIn_0.2s_ease-out]">
              <div className="flex flex-col gap-1 mb-2">
                <h2 className="text-base font-bold text-white tracking-wide">中枢生产调度智能顾问 (Grounded Advisor)</h2>
                <p className="text-[11px] text-[#5c6470] font-mono leading-normal">
                  调用 Gemini 3.8 Core 智能体直接对整个 SEIOS 实时数据孪生和宏观仿真模型状态进行专家级推演解算，提供工业公式级回答。
                </p>
              </div>
              <AiAssistant systemContext={{
                currentCountry: selectedCountry,
                groupKPIs: groupOverviewMetrics,
                systemIndicators: systemStatusIndicators
              }} />
            </div>
          )}

        </main>
      </div>

      {/* ==================== 4. 底部状态页脚 (Footer with versioning) ==================== */}
      <footer className="h-8 bg-[#0c0d10] border-t border-[#1a1e24] px-6 flex items-center justify-between font-mono text-[9px] text-[#5c6470] shrink-0 z-10">
        <div className="flex items-center gap-4">
          <span>安全等级：国家特等甲级防爆、防入侵 (OT/IT隔离审计已激活)</span>
          <span>DCS 通信频率：10 Hz | RTU：60s心跳</span>
        </div>
        <div>
          <span>系统核心：SEIOS v2.6.17-LTS (基于 Rust 仿真内核) | 100% 简体中文版</span>
        </div>
      </footer>

    </div>
  );
}
