/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { groupFinanceData, commoditiesPriceTicker, globalCrudeTrades, retailStations } from "../data";
import { DollarSign, Globe, TrendingUp, Compass, ShoppingBag, ShieldCheck, Activity } from "lucide-react";

export default function FinanceTradeView() {
  const [activeTab, setActiveTab] = useState<"finance" | "trading" | "retail">("finance");
  const [selectedCargoId, setSelectedCargoId] = useState("TRADE-CR-01");
  const [selectedStationId, setSelectedStationId] = useState("STATION-BJ-01");

  const currentCargo = globalCrudeTrades.find((t: any) => t.id === selectedCargoId) || globalCrudeTrades[0];
  const currentStation = retailStations.find((s: any) => s.id === selectedStationId) || retailStations[0];

  return (
    <div className="grid grid-cols-1 xl:grid-cols-4 gap-6 font-mono text-xs select-none text-gray-300">
      
      {/* 1. 左侧: 顶层财务或业务选择器 */}
      <div className="bg-[#16191e] border border-[#2d323a] rounded p-4 flex flex-col gap-4">
        <div className="flex items-center gap-2 border-b border-[#2d323a] pb-2">
          <DollarSign className="w-4 h-4 text-red-500" />
          <span className="font-bold text-gray-200 text-[13px]">全球财务、贸易与加能零售</span>
        </div>

        {/* 侧栏标签导航 */}
        <div className="flex flex-col gap-2">
          <button
            onClick={() => setActiveTab("finance")}
            className={`py-2.5 px-3 rounded border text-left font-bold transition flex justify-between items-center ${
              activeTab === "finance"
                ? "bg-[#251518] border-red-800 text-white"
                : "bg-[#11141a] border-[#2d323a] text-gray-400 hover:text-white"
            }`}
          >
            <span>财务决算与损益报表</span>
            <TrendingUp className="w-3.5 h-3.5 text-red-500" />
          </button>
          
          <button
            onClick={() => setActiveTab("trading")}
            className={`py-2.5 px-3 rounded border text-left font-bold transition flex justify-between items-center ${
              activeTab === "trading"
                ? "bg-[#251518] border-red-800 text-white"
                : "bg-[#11141a] border-[#2d323a] text-gray-400 hover:text-white"
            }`}
          >
            <span>全球大宗原油实物贸易</span>
            <Globe className="w-3.5 h-3.5 text-blue-400" />
          </button>

          <button
            onClick={() => setActiveTab("retail")}
            className={`py-2.5 px-3 rounded border text-left font-bold transition flex justify-between items-center ${
              activeTab === "retail"
                ? "bg-[#251518] border-red-800 text-white"
                : "bg-[#11141a] border-[#2d323a] text-gray-400 hover:text-white"
            }`}
          >
            <span>综合加能站数字孪生</span>
            <ShoppingBag className="w-3.5 h-3.5 text-green-400" />
          </button>
        </div>

        {/* 商品行情即时看板 (Ticker Panel) */}
        <div className="bg-[#11141a] border border-[#2d323a] p-3 rounded flex flex-col gap-2 mt-2">
          <span className="font-bold text-gray-400 border-b border-[#2d323a] pb-1">全球大宗商品即时报价 (15m延时)</span>
          <div className="flex flex-col gap-1.5 text-gray-500">
            {commoditiesPriceTicker.map((c: any) => (
              <div key={c.commodityCode} className="flex justify-between items-center bg-[#16191e] p-1.5 rounded border border-[#222831]">
                <div className="flex flex-col">
                  <span className="text-white font-bold">{c.name}</span>
                  <span className="text-[9px] uppercase">{c.commodityCode} ({c.exchange})</span>
                </div>
                <div className="text-right">
                  <span className="text-white font-bold">${c.currentPriceUSD} {c.unit}</span>
                  <div className={`text-[9px] font-bold ${c.changePercentage >= 0 ? "text-emerald-400" : "text-red-400"}`}>
                    {c.changePercentage >= 0 ? `+${c.changePercentage}` : c.changePercentage}%
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 2. 中间与右侧: 子业务动态视图 (Tabs) */}
      <div className="xl:col-span-3 bg-[#16191e] border border-[#2d323a] rounded p-4 flex flex-col gap-4">
        
        {/* TABS 1: 财务决算与损益报表 */}
        {activeTab === "finance" && (
          <div className="flex flex-col gap-4">
            <div className="flex items-center justify-between border-b border-[#2d323a] pb-2">
              <span className="font-bold text-gray-200 text-[13px]">中石化集团核心财务与资产负债审计表</span>
              <span className="text-gray-500">财务报告本位币：RMB | 数据版本: Q3审计核算</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-[#11141a] border border-[#2d323a] p-3 rounded flex flex-col gap-1">
                <span className="text-gray-500 font-bold">集团总营业收入:</span>
                <span className="text-white text-base font-bold">￥{(groupFinanceData.revenueBillionRMB).toFixed(1)} 亿元</span>
                <span className="text-[10px] text-emerald-400">环比增长 +4.8%</span>
              </div>
              <div className="bg-[#11141a] border border-[#2d323a] p-3 rounded flex flex-col gap-1">
                <span className="text-gray-500 font-bold">集团息税前折旧摊销利润 (EBITDA):</span>
                <span className="text-white text-base font-bold">￥{(groupFinanceData.ebitdaBillionRMB).toFixed(1)} 亿元</span>
                <span className="text-[10px] text-gray-400">EBITDA 利润率: {groupFinanceData.grossProfitMarginPercentage}%</span>
              </div>
              <div className="bg-[#11141a] border border-[#2d323a] p-3 rounded flex flex-col gap-1">
                <span className="text-gray-500 font-bold">自由现金流储备 (FCF):</span>
                <span className="text-emerald-400 text-base font-bold">￥{(groupFinanceData.revenueBillionRMB - groupFinanceData.costBillionRMB).toFixed(1)} 亿元</span>
                <span className="text-[10px] text-gray-400">资产负债率: 45.2%</span>
              </div>
            </div>

            {/* 资本支出细目表 */}
            <div className="bg-[#11141a] border border-[#2d323a] p-3 rounded flex flex-col gap-2">
              <span className="font-bold text-gray-400 border-b border-[#2d323a] pb-1.5">资本支出与技术研发分配 (Capex)</span>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-1">
                <div className="flex flex-col">
                  <span className="text-gray-500">上游勘探开采投入:</span>
                  <span className="text-white font-bold mt-1">￥{(groupFinanceData.capexBillionRMB * 0.45).toFixed(1)} 亿元</span>
                </div>
                <div className="flex flex-col">
                  <span className="text-gray-500">炼化与精细化工技术:</span>
                  <span className="text-white font-bold mt-1">￥{(groupFinanceData.capexBillionRMB * 0.35).toFixed(1)} 亿元</span>
                </div>
                <div className="flex flex-col">
                  <span className="text-gray-500">氢能及新能源转型分配:</span>
                  <span className="text-teal-400 font-bold mt-1">￥{(groupFinanceData.capexBillionRMB * 0.15).toFixed(1)} 亿元</span>
                </div>
                <div className="flex flex-col">
                  <span className="text-gray-500">物理勘探与地质研发:</span>
                  <span className="text-white font-bold mt-1">￥{(groupFinanceData.capexBillionRMB * 0.05).toFixed(1)} 亿元</span>
                </div>
              </div>
            </div>

            {/* 财务审计说明 */}
            <div className="bg-[#11141a]/50 p-2.5 rounded border border-[#2d323a] text-[10px] text-gray-500 flex items-center gap-1.5 leading-normal">
              <ShieldCheck className="w-5 h-5 text-emerald-500 shrink-0" />
              <span>本系统显示之财务数据遵循中国企业会计准则及IFRS国际准则，由德勤中石化项目审计组核对。数据版本验证码：VER-AUD-2026-09A。</span>
            </div>
          </div>
        )}

        {/* TABS 2: 全球大宗原油实物贸易 */}
        {activeTab === "trading" && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* 贸易货轮列表 */}
            <div className="flex flex-col gap-2 border-r border-[#2d323a] pr-4">
              <span className="font-bold text-gray-400 border-b border-[#2d323a] pb-1.5">大宗海运现货合同清单</span>
              <div className="flex flex-col gap-1 max-h-[220px] overflow-y-auto">
                {globalCrudeTrades.map((t: any) => (
                  <div
                    key={t.id}
                    onClick={() => setSelectedCargoId(t.id)}
                    className={`p-2 rounded border transition cursor-pointer flex flex-col gap-1 ${
                      selectedCargoId === t.id
                        ? "bg-[#251518] border-red-800 text-white"
                        : "bg-[#11141a] border-[#2d323a] hover:bg-[#1a1e24]"
                    }`}
                  >
                    <div className="flex justify-between font-bold text-[11px]">
                      <span>{t.cargoName}</span>
                      <span className="text-emerald-400">{t.hedgingStatus}</span>
                    </div>
                    <div className="text-[9px] text-gray-500 flex justify-between">
                      <span>油轮: {t.carrierVesselImo}</span>
                      <span>货值: ${(t.contractValueMillionUSD).toFixed(1)}M USD</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 实物贸易套期保值与物理追踪 (Trading Twin Faceplate) */}
            <div className="lg:col-span-2 bg-[#11141a] border border-[#2d323a] rounded p-3 flex flex-col gap-3">
              <span className="font-bold text-gray-300 border-b border-[#2d323a] pb-1.5 flex justify-between items-center">
                <span>实物提单与套保审计窗口</span>
                <span className="text-[10px] text-yellow-500 font-bold">提单 ID: {currentCargo.id}</span>
              </span>

              <div className="grid grid-cols-2 gap-y-2 text-[11px] text-gray-400 leading-relaxed">
                <span>原油类型: <strong className="text-white">{currentCargo.crudeGrade}</strong></span>
                <span>实载数量: <strong className="text-white">{currentCargo.volumeKiloBarrels} 万桶 (kbbl)</strong></span>
                <span>装港离港: <strong className="text-white">{currentCargo.loadingPort} ({currentCargo.loadDate})</strong></span>
                <span>卸港到港: <strong className="text-white">{currentCargo.dischargePort} ({currentCargo.etaDischargeDate})</strong></span>
                <span>衍生套保对冲: <strong className="text-emerald-400 font-bold">{currentCargo.derivativeHedgingInstrument}</strong></span>
                <span>对冲锁仓价: <strong className="text-white">${currentCargo.hedgedStrikePricePerBarrelUSD} / 桶</strong></span>
              </div>

              {/* 货轮轨迹时序雷达 */}
              <div className="bg-[#16191e] border border-[#222831] p-2.5 rounded mt-1 flex flex-col gap-1.5 text-[10px] text-gray-400">
                <span className="font-bold text-gray-300">货轮物理跟踪 SCADA 遥测:</span>
                <span>IMO 船舶识别码: {currentCargo.carrierVesselImo} | 运行轨迹：波斯湾 ➔ 马六甲海峡 ➔ 宁波舟山港 5号锚地</span>
                <div className="flex justify-between border-t border-[#2d323a]/40 pt-1.5 mt-1 text-[9px] text-gray-500">
                  <span>套保锁定敞口: ${currentCargo.unhedgedExposureValueMillionUSD}M USD (对冲比率: 92.5%)</span>
                  <span>单船估计净运费: ${currentCargo.freightCostMillionUSD}M USD</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TABS 3: 综合加能站数字孪生 */}
        {activeTab === "retail" && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* 综合加能站列表 */}
            <div className="flex flex-col gap-2 border-r border-[#2d323a] pr-4">
              <span className="font-bold text-gray-400 border-b border-[#2d323a] pb-1.5">零售综合加能站测点</span>
              <div className="flex flex-col gap-1 max-h-[220px] overflow-y-auto">
                {retailStations.map((s: any) => (
                  <div
                    key={s.id}
                    onClick={() => setSelectedStationId(s.id)}
                    className={`p-2 rounded border transition cursor-pointer flex flex-col gap-1 ${
                      selectedStationId === s.id
                        ? "bg-[#251518] border-red-800 text-white"
                        : "bg-[#11141a] border-[#2d323a] hover:bg-[#1a1e24]"
                    }`}
                  >
                    <div className="flex justify-between font-bold text-[11px]">
                      <span>{s.name}</span>
                      <span className="text-green-400">综合服务中</span>
                    </div>
                    <div className="text-[9px] text-gray-500 flex justify-between">
                      <span>城市: {s.name.includes("北京") ? "北京" : "上海"}</span>
                      <span>日销: {s.dailyGasolineSalesLiter} 升</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 加能站物理孪生面板 */}
            <div className="lg:col-span-2 bg-[#11141a] border border-[#2d323a] rounded p-3 flex flex-col gap-3">
              <span className="font-bold text-gray-300 border-b border-[#2d323a] pb-1.5 flex justify-between items-center">
                <span>加油、加气、充电与氢能“四合一”数字孪生</span>
                <span className="text-[10px] text-green-500 font-bold">测点 ID: {currentStation.id}</span>
              </span>

              <div className="grid grid-cols-2 gap-y-2 text-[11px] text-gray-400 leading-relaxed">
                <span>加油机枪数: <strong className="text-white">{currentStation.dispensersCount} 枪</strong></span>
                <span>加气机能力: <strong className="text-white">1200 标方/日</strong></span>
                <span>日加氢能力 (35/70 MPa): <strong className="text-teal-400 font-bold">{currentStation.hydrogenStation?.dailyRefuelKg || 0} kg/日</strong></span>
                <span>EV 超级快充终端: <strong className="text-white">{currentStation.evChargingSlots.total} 个 ({currentStation.evChargingSlots.occupied} 占用)</strong></span>
                <span>油罐储罐液位: <strong className="text-white">4.2 m (库容 120 吨)</strong></span>
                <span>昨日非油零售收益: <strong className="text-yellow-500 font-bold">￥12,420 (易捷便利店)</strong></span>
              </div>

              {/* 超级充电桩和氢能安全传感器监测 */}
              <div className="bg-[#16191e] border border-[#222831] p-2.5 rounded mt-1 flex flex-col gap-1 text-[10px] text-gray-400">
                <span className="font-bold text-gray-300">安全监测及光伏储能:</span>
                <span>油气回收防爆变送器 (LPT-102): <strong className="text-emerald-400 font-bold">0.02% (合格)</strong></span>
                <span>光伏车棚发电效率: <strong className="text-white">18.5 kW (实时自发自用)</strong></span>
                <span>储能电池 SOC: <strong className="text-white">82%</strong></span>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
