/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from "react";
import { DATA_SOURCE_NOTICE } from "../data";
import { MessageSquare, Send, Bot, User, RefreshCw, Sparkles, AlertTriangle } from "lucide-react";

interface Message {
  role: "assistant" | "user";
  text: string;
}

interface AiAssistantProps {
  systemContext?: any;
}

export default function AiAssistant({ systemContext }: AiAssistantProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      text: `【${DATA_SOURCE_NOTICE}】\n\n您好！我是 SEIOS 数字化中枢内置的「中石化大宗能源全球调度智能分析系统」。\n我拥有完整的长输管线水力方程、Arps 油井递减曲线、炼化 LP 收率矩阵以及全球金融风险套保精算知识，您可以通过提问让我进行实时计算分析。`
    }
  ]);
  const [inputText, setInputText] = useState("");
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const quickQuestions = [
    "如果普光高压天然气管线停运12小时，会怎样？",
    "沙特轻油换成俄罗斯高硫原油后，镇海炼化收率利润有什么变化？",
    "为什么顺北701超深井日产油下降，如何进行 Arps 产量预测？",
    "有哪些关键核心设备当前存在高振动等安全停机隐患？"
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim() || loading) return;

    const userMsg = textToSend.trim();
    setInputText("");
    setMessages(prev => [...prev, { role: "user", text: userMsg }]);
    setLoading(true);

    try {
      const response = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: userMsg,
          contextState: systemContext || { note: "系统运行平稳，无安全断开事件" }
        })
      });

      if (!response.ok) {
        throw new Error("API 响应失败");
      }

      const data = await response.json();
      setMessages(prev => [...prev, { role: "assistant", text: data.text }]);
    } catch (err) {
      console.error("AI Assistant request failed:", err);
      // 模拟一点延迟以提升用户体验
      setTimeout(() => {
        setMessages(prev => [
          ...prev, 
          { 
            role: "assistant", 
            text: `【${DATA_SOURCE_NOTICE}】\n\n网络连接异常，备用规则诊断库提示：您问到关于“${userMsg}”的诊断。在 SEIOS 系统中，根据安全边界 IT/OT 规程，由于无法直接写命令，本分析不进行指令下发。请点击左下角其他特定流程标签，或者检查后台 GEMINI_API_KEY 配置。` 
          }
        ]);
      }, 500);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-[#16191e] border border-[#2d323a] rounded h-[540px] flex flex-col overflow-hidden font-mono text-xs select-none text-gray-300">
      
      {/* 顶部标题栏 */}
      <div className="h-10 bg-[#1a1e24] border-b border-[#2d323a] px-4 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2">
          <Bot className="w-4 h-4 text-red-500" />
          <span className="font-bold text-gray-200 uppercase tracking-wider text-[11px]">中石化大宗能源全球调度智能分析系统</span>
        </div>
        <div className="flex items-center gap-2 text-emerald-400 text-[10px] font-bold">
          <Sparkles className="w-3.5 h-3.5 animate-pulse" />
          <span>Gemini 3.8 Core Active</span>
        </div>
      </div>

      {/* 聊天内容区 */}
      <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4">
        {messages.map((msg, i) => {
          const isAi = msg.role === "assistant";
          return (
            <div key={i} className={`flex gap-3 max-w-[85%] ${isAi ? "self-start" : "self-end flex-row-reverse"}`}>
              {/* 头像 */}
              <div className={`w-8 h-8 rounded flex items-center justify-center shrink-0 border ${
                isAi ? "bg-[#251518] border-red-900 text-red-500" : "bg-[#1d232d] border-gray-600 text-gray-300"
              }`}>
                {isAi ? <Bot className="w-4 h-4" /> : <User className="w-4 h-4" />}
              </div>

              {/* 消息框 */}
              <div className={`p-3 rounded leading-relaxed whitespace-pre-wrap break-words ${
                isAi 
                  ? "bg-[#11141a] border border-[#2d323a] text-gray-300" 
                  : "bg-red-950/20 border border-red-900 text-white"
              }`}>
                {msg.text}
              </div>
            </div>
          );
        })}

        {loading && (
          <div className="flex gap-3 max-w-[85%] self-start items-center">
            <div className="w-8 h-8 rounded flex items-center justify-center bg-[#251518] border border-red-900 text-red-500 animate-pulse">
              <Bot className="w-4 h-4" />
            </div>
            <div className="bg-[#11141a] border border-[#2d323a] p-3 rounded text-gray-400 flex items-center gap-2 font-bold">
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-red-500" />
              <span>智能仿真引擎正在迭代解算中，请稍候...</span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* 快捷提问推荐 */}
      <div className="px-4 py-2 bg-[#11141a]/60 border-t border-[#2d323a] flex flex-wrap gap-1.5 shrink-0">
        <span className="text-[10px] text-gray-500 font-bold mr-1.5 self-center">快速大宗分析:</span>
        {quickQuestions.map((q, i) => (
          <button
            key={i}
            onClick={() => handleSendMessage(q)}
            disabled={loading}
            className="bg-[#16191e] border border-[#2d323a] hover:border-red-600 text-[10px] text-gray-400 hover:text-white px-2.5 py-1 rounded transition whitespace-nowrap"
          >
            {q.length > 22 ? q.substring(0, 20) + "..." : q}
          </button>
        ))}
      </div>

      {/* IT/OT 隔离与安全审核横幅 (SIS Bypass Warning) */}
      <div className="bg-red-950/30 border-t border-red-900/60 px-4 py-1 flex items-center gap-1.5 text-[10px] text-red-400 font-bold shrink-0">
        <AlertTriangle className="w-3.5 h-3.5 text-red-500" />
        <span>安全警告：AI智能顾问仅供决策支持。本系统对 PLC/DCS 连锁系统硬性只读，不发送写执行命令，遵循严格物理隔离规程。</span>
      </div>

      {/* 输入框 */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSendMessage(inputText);
        }}
        className="p-3 bg-[#1a1e24] border-t border-[#2d323a] flex gap-2 shrink-0"
      >
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="问我关于：常减压LP收率、Arps单井预测、达西管网摩阻水力压降、对冲风险敞口..."
          disabled={loading}
          className="flex-1 bg-[#11141a] border border-[#2d323a] focus:border-red-600 rounded px-3 py-2 text-white focus:outline-none placeholder-gray-600"
        />
        <button
          type="submit"
          disabled={loading || !inputText.trim()}
          className="bg-red-800 hover:bg-red-700 disabled:bg-[#11141a] disabled:text-gray-600 text-white px-4 py-2 rounded transition font-bold flex items-center gap-1 shrink-0"
        >
          <Send className="w-3.5 h-3.5" />
          <span>分析</span>
        </button>
      </form>

    </div>
  );
}
