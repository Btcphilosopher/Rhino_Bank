/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { drillingMetrics, fracturingMetrics, simulateArpsDecline } from "../data";
import { Activity, Gauge, Sliders, ChevronRight, CheckCircle, TrendingDown, RefreshCw } from "lucide-react";

export default function DrillingWellView() {
  const [selectedWellId, setSelectedWellId] = useState("WELL-SB-701");
  const [declineModel, setDeclineModel] = useState<"Exponential" | "Hyperbolic" | "Harmonic">("Exponential");
  const [declineRate, setDeclineRate] = useState(0.12); // D0: 12%
  const [hyperbolicExponent, setHyperbolicExponent] = useState(0.4); // b

  // 模拟计算结果
  const [simResult, setSimResult] = useState(
    simulateArpsDecline("WELL-SB-701", declineModel, declineRate, hyperbolicExponent)
  );

  // 联动重新计算
  useEffect(() => {
    const res = simulateArpsDecline(selectedWellId, declineModel, declineRate, hyperbolicExponent);
    setSimResult(res);
  }, [selectedWellId, declineModel, declineRate, hyperbolicExponent]);

  // 获得当前井的钻井数据
  const currentDrilling = drillingMetrics.find(m => m.wellId === selectedWellId) || drillingMetrics[0];
  const fracData = fracturingMetrics.find(m => m.wellId === selectedWellId);

  return (
    <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 font-mono text-xs select-none text-gray-300">
      
      {/* 1. 左侧: 井监控列表 & 钻井工程数字孪生 */}
      <div className="bg-[#16191e] border border-[#2d323a] rounded p-4 flex flex-col gap-4">
        <div className="flex items-center gap-2 border-b border-[#2d323a] pb-2">
          <Activity className="w-4 h-4 text-red-500 animate-pulse" />
          <span className="font-bold text-gray-200 text-[13px]">井管理与钻井监控中心</span>
        </div>

        {/* 井选择卡 */}
        <div className="flex flex-col gap-1.5 max-h-[140px] overflow-y-auto">
          {drillingMetrics.map((well) => (
            <div
              key={well.wellId}
              onClick={() => setSelectedWellId(well.wellId)}
              className={`p-2.5 rounded border transition cursor-pointer flex items-center justify-between ${
                selectedWellId === well.wellId
                  ? "bg-[#251518] border-red-800 text-white"
                  : "bg-[#11141a] border-[#2d323a] hover:bg-[#1a1e24] hover:border-gray-500"
              }`}
            >
              <div>
                <span className="font-bold">{well.wellName}</span>
                <div className="text-[10px] text-gray-400 mt-0.5">
                  已钻深度: <span className="text-white font-bold">{well.currentDepth} 米</span>
                </div>
              </div>
              <ChevronRight className={`w-4 h-4 transition ${selectedWellId === well.wellId ? "text-red-500" : "text-gray-500"}`} />
            </div>
          ))}
        </div>

        {/* 实时钻井参数监视 (DCS/PLC级回传) */}
        <div className="bg-[#11141a] border border-[#2d323a] rounded p-3 flex flex-col gap-2">
          <div className="flex items-center justify-between border-b border-[#1d232d] pb-1">
            <span className="font-bold text-gray-400">实时钻探遥测参数 (SCADA)</span>
            <span className="text-[9px] px-1 bg-blue-950 border border-blue-500 text-blue-400 rounded">传感器在线</span>
          </div>
          
          <div className="grid grid-cols-2 gap-x-4 gap-y-2 mt-1">
            <div className="flex justify-between items-center bg-[#16191e] p-1.5 rounded border border-[#222831]">
              <span className="text-gray-400">测点深度 (MD):</span>
              <span className="text-white font-bold">{currentDrilling.currentDepth} m</span>
            </div>
            <div className="flex justify-between items-center bg-[#16191e] p-1.5 rounded border border-[#222831]">
              <span className="text-gray-400">机械钻速 (ROP):</span>
              <span className="text-emerald-400 font-bold">{currentDrilling.drillingSpeed} m/h</span>
            </div>
            <div className="flex justify-between items-center bg-[#16191e] p-1.5 rounded border border-[#222831]">
              <span className="text-gray-400">实测钻压 (WOB):</span>
              <span className="text-yellow-500 font-bold">{currentDrilling.weightOnBitKn} kN</span>
            </div>
            <div className="flex justify-between items-center bg-[#16191e] p-1.5 rounded border border-[#222831]">
              <span className="text-gray-400">顶驱扭矩 (TRQ):</span>
              <span className="text-white font-bold">{currentDrilling.torqueKnm} kNm</span>
            </div>
            <div className="flex justify-between items-center bg-[#16191e] p-1.5 rounded border border-[#222831]">
              <span className="text-gray-400">泥浆排量 (MFL):</span>
              <span className="text-white font-bold">{currentDrilling.mudFlowRateLps} L/s</span>
            </div>
            <div className="flex justify-between items-center bg-[#16191e] p-1.5 rounded border border-[#222831]">
              <span className="text-gray-400">立管压力 (SPP):</span>
              <span className="text-white font-bold">{currentDrilling.standpipePressureMpa} MPa</span>
            </div>
            <div className="flex justify-between items-center bg-[#16191e] p-1.5 rounded border border-[#222831]">
              <span className="text-gray-400">井口井斜 (DEV):</span>
              <span className="text-white font-bold">{currentDrilling.inclinationDegree}°</span>
            </div>
            <div className="flex justify-between items-center bg-[#16191e] p-1.5 rounded border border-[#222831]">
              <span className="text-gray-400">井底温度 (BHT):</span>
              <span className="text-red-400 font-bold">{currentDrilling.temperatureCelsius} ℃</span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. 中间 & 右侧: 生产油藏递减率交互模拟实验室 */}
      <div className="xl:col-span-2 bg-[#16191e] border border-[#2d323a] rounded p-4 flex flex-col gap-4">
        <div className="flex items-center justify-between border-b border-[#2d323a] pb-2">
          <div className="flex items-center gap-2">
            <Gauge className="w-4 h-4 text-blue-500" />
            <span className="font-bold text-gray-200 text-[13px]">Arps 生产递减与油藏预测仿真实验室</span>
          </div>
          <span className="text-[10px] text-gray-500">模拟引擎：Arps ODE Solver (Rust-based kernel)</span>
        </div>

        {/* 产量预测时序波形图 */}
        <div className="h-[200px] bg-[#0c0e12] border border-[#2d323a] rounded relative p-2 flex flex-col justify-end">
          {/* Y轴刻度 */}
          <div className="absolute top-2 left-2 text-[8px] text-gray-600 flex flex-col gap-10">
            <span>50 吨/天</span>
            <span>25 吨/天</span>
            <span>0 吨/天</span>
          </div>
          
          {/* SVG 柱状/折线趋势渲染 */}
          <svg className="w-full h-full absolute inset-0 z-0 px-8 py-4 pointer-events-none">
            {/* 折线图网格 */}
            <g stroke="#1a1e24" strokeWidth="0.5">
              {Array.from({ length: 10 }).map((_, i) => (
                <line key={i} x1={`${(i + 1) * 70}`} y1="0" x2={`${(i + 1) * 70}`} y2="180" />
              ))}
              <line x1="0" y1="90" x2="800" y2="90" />
            </g>

            {/* 绘制油产量递减折线 (绿色) */}
            <path
              d={`M ${simResult.future30DaysTrend.map((pt, idx) => `${idx * 24 + 40} ${180 - (pt.oilProduction / 50) * 140}`).join(" L ")}`}
              fill="none"
              stroke="#22c55e"
              strokeWidth="2"
            />

            {/* 绘制压力递降折线 (蓝色) */}
            <path
              d={`M ${simResult.future30DaysTrend.map((pt, idx) => `${idx * 24 + 40} ${180 - (pt.pressure / 20) * 140}`).join(" L ")}`}
              fill="none"
              stroke="#3b82f6"
              strokeWidth="1.5"
              strokeDasharray="2,2"
            />

            {/* 数据点标签 */}
            <circle cx="40" cy={180 - (simResult.future30DaysTrend[0].oilProduction / 50) * 140} r="3" fill="#22c55e" />
            <circle cx="736" cy={180 - (simResult.future30DaysTrend[29].oilProduction / 50) * 140} r="3" fill="#22c55e" />
            <text x="50" y="35" fill="#22c55e" fontSize="9" className="font-bold">初始产量: {simResult.initialProduction} 吨/日</text>
            <text x="560" y="110" fill="#a855f7" fontSize="9" className="font-bold">30日估算: {simResult.finalProduction} 吨/日</text>
          </svg>

          {/* 图例 */}
          <div className="flex gap-4 items-center justify-center text-[9px] text-gray-500 z-10 select-none pb-1">
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-0.5 bg-[#22c55e]" />
              日产油量 (吨/天)
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-0.5 bg-[#3b82f6] border-dashed border" />
              井底流压 (MPa)
            </span>
          </div>
        </div>

        {/* 3. 互动滑块控制器 */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-[#11141a] p-3 rounded border border-[#2d323a]">
          <div className="flex flex-col gap-2.5">
            <span className="font-bold text-gray-400 border-b border-[#2d323a] pb-1 flex justify-between">
              <span>油藏物理参数调整</span>
              <TrendingDown className="w-3.5 h-3.5 text-blue-400" />
            </span>
            
            <div className="flex flex-col gap-1">
              <div className="flex justify-between text-[10px]">
                <span className="text-gray-400">递减模型公式 (ODE)</span>
                <span className="text-red-400 font-bold">{declineModel}</span>
              </div>
              <div className="flex gap-1.5 mt-0.5">
                {(["Exponential", "Hyperbolic", "Harmonic"] as const).map((model) => (
                  <button
                    key={model}
                    onClick={() => setDeclineModel(model)}
                    className={`flex-1 py-1 rounded transition text-[9px] font-bold ${
                      declineModel === model
                        ? "bg-red-950 border border-red-600 text-red-400"
                        : "bg-[#16191e] border border-[#2d323a] text-gray-400 hover:text-white"
                    }`}
                  >
                    {model === "Exponential" ? "指数递减" : model === "Hyperbolic" ? "双曲递减" : "调和递减"}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex flex-col gap-1.5">
              <div className="flex justify-between text-[10px]">
                <span className="text-gray-400">初始年递减率 (D₀)</span>
                <span className="text-white font-bold">{(declineRate * 100).toFixed(1)}% /年</span>
              </div>
              <input
                type="range"
                min="0.02"
                max="0.40"
                step="0.01"
                value={declineRate}
                onChange={(e) => setDeclineRate(Number(e.target.value))}
                className="w-full h-1 bg-[#20252e] rounded appearance-none cursor-pointer accent-red-500"
              />
            </div>

            {declineModel === "Hyperbolic" && (
              <div className="flex flex-col gap-1.5">
                <div className="flex justify-between text-[10px]">
                  <span className="text-gray-400">双曲递减指数 (b)</span>
                  <span className="text-white font-bold">{hyperbolicExponent.toFixed(2)}</span>
                </div>
                <input
                  type="range"
                  min="0.10"
                  max="0.90"
                  step="0.05"
                  value={hyperbolicExponent}
                  onChange={(e) => setHyperbolicExponent(Number(e.target.value))}
                  className="w-full h-1 bg-[#20252e] rounded appearance-none cursor-pointer accent-red-500"
                />
              </div>
            )}
          </div>

          {/* 右侧: 仿真计算实时解算输出 (具有物理、数学因果关系，不伪造数据) */}
          <div className="bg-[#16191e] border border-[#2b3039] p-3 rounded flex flex-col gap-1.5 leading-relaxed">
            <span className="font-bold text-emerald-400 border-b border-[#2d323a] pb-1 flex items-center gap-1.5">
              <CheckCircle className="w-3.5 h-3.5 text-emerald-500" />
              Arps 储层递减数值结算报告
            </span>
            <div className="flex flex-col gap-1 text-[11px] text-gray-400">
              <div className="flex justify-between">
                <span>估计极限可采储量 (EUR):</span>
                <span className="text-white font-bold">{simResult.eurMillionTons} 亿吨</span>
              </div>
              <div className="flex justify-between">
                <span>剩余可采地质储量:</span>
                <span className="text-white font-bold">{simResult.remainingReserves} 亿吨</span>
              </div>
              <div className="flex justify-between border-t border-[#1d232d] pt-1 mt-1 text-gray-500 text-[10px]">
                <span>数学公式引用:</span>
                <span className="text-blue-400 italic font-bold">
                  {declineModel === "Exponential" 
                    ? "q(t) = q0 * e^(-D*t)" 
                    : declineModel === "Hyperbolic" 
                    ? "q(t) = q0 / (1+b*D*t)^(1/b)" 
                    : "q(t) = q0 / (1+D*t)"}
                </span>
              </div>
            </div>

            {/* 压裂联动详情 */}
            {fracData && (
              <div className="border-t border-[#2d323a] pt-1.5 mt-1 text-[9px] text-gray-500 flex flex-col gap-0.5">
                <span className="font-bold text-gray-400">压裂增产标定(非常规):</span>
                <span>加砂量: {fracData.sandVolumeTons} 吨 | 排量: {fracData.averageFlowRateM3Min} m³/min</span>
                <span>微地震断裂释放事件: <span className="text-emerald-400 font-bold">{fracData.microseismicEventCount} 次</span></span>
              </div>
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
