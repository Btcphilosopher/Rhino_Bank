/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { hseAlarms, ccusSequestrationPlans } from "../data";
import { Shield, Sparkles, AlertTriangle, CheckCircle, Eye, EyeOff, BarChart3, CloudSnow } from "lucide-react";

export default function HseCarbonView() {
  const [selectedPlanId, setSelectedPlanId] = useState("CCUS-JL-01");
  const [showClosedAlarms, setShowClosedAlarms] = useState(false);

  const activePlan = ccusSequestrationPlans.find((p: any) => p.id === selectedPlanId) || ccusSequestrationPlans[0];

  // 过滤报警日志
  const filteredAlarms = hseAlarms.filter((a: any) => showClosedAlarms || a.status === "未处理");

  // 碳排三级范围标定数据 (Scope 1, 2, 3 Greenhouse Gas Protocol)
  const carbonScopeData = {
    scope1: {
      title: "范围一 (Direct Emissions)",
      desc: "常减压加氢加热炉原油燃烧、重油催化裂化再生器烟气、高架火炬应急放散等直接燃烧产生",
      tonsDaily: 8420,
      percentage: 38.5,
      formula: "E_{direct} = \\sum (Fuel_{consumed} \\times EF_{carbon}) + EF_{process_venting}"
    },
    scope2: {
      title: "范围二 (Indirect Purchased)",
      desc: "向国家电网、南方电网外购火电产生的间接电力能源消耗、热力管道蒸汽外购输入折算",
      tonsDaily: 3540,
      percentage: 16.2,
      formula: "E_{electricity} = Electricity_{purchased} \\times EF_{grid_regional}"
    },
    scope3: {
      title: "范围三 (Value Chain)",
      desc: "下游消费者加油站加注成品油燃爆、上游海洋油轮原油外贸长途海运航行燃料油消耗",
      tonsDaily: 9910,
      percentage: 45.3,
      formula: "E_{value_chain} = \\sum (Product_{sold} \\times EF_{combustion_fuel})"
    }
  };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 font-mono text-xs select-none text-gray-300">
      
      {/* 1. 左侧: HSE 安全环境监测与气体逸散传感器网 */}
      <div className="bg-[#16191e] border border-[#2d323a] rounded p-4 flex flex-col gap-4">
        <div className="flex items-center justify-between border-b border-[#2d323a] pb-2">
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-emerald-500" />
            <span className="font-bold text-gray-200 text-[13px]">HSE 工业环境与特种安全监控</span>
          </div>
          <button
            onClick={() => setShowClosedAlarms(!showClosedAlarms)}
            className="text-[10px] text-gray-400 hover:text-white flex items-center gap-1"
          >
            {showClosedAlarms ? <EyeOff className="w-3.5 h-3.5 text-blue-400" /> : <Eye className="w-3.5 h-3.5 text-blue-400" />}
            {showClosedAlarms ? "仅看未结" : "显示已闭环"}
          </button>
        </div>

        {/* 报警时序网格 */}
        <div className="flex-1 overflow-y-auto max-h-[320px] flex flex-col gap-2 pr-1">
          {filteredAlarms.map((a: any) => (
            <div
              key={a.id}
              className={`p-2.5 rounded border transition flex flex-col gap-1.5 ${
                a.status === "未处理"
                  ? "bg-[#251518] border-red-900 text-red-300"
                  : "bg-[#11141a]/60 border-[#222831] text-gray-500"
              }`}
            >
              <div className="flex items-center justify-between font-bold">
                <span className="flex items-center gap-1">
                  {a.status === "未处理" ? <AlertTriangle className="w-3.5 h-3.5 text-red-500 animate-pulse" /> : <CheckCircle className="w-3.5 h-3.5 text-gray-500" />}
                  {a.indicatorName} ({a.sensorId})
                </span>
                <span className="text-[9px] uppercase">{a.hazardLevel}</span>
              </div>
              <div className="text-[10px] flex justify-between leading-relaxed">
                <span>位置: {a.location}</span>
                <span>实测: <strong className="text-white">{a.measuredValue}</strong> (标准 &lt;{a.standardLimit})</span>
              </div>
              <div className="text-[9px] text-gray-400 border-t border-[#2d323a]/40 pt-1 mt-0.5 flex justify-between">
                <span>时间: {a.alarmTimestamp}</span>
                <span className={a.status === "未处理" ? "text-red-500 font-bold" : "text-gray-600"}>{a.status}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 2. 中间: 温室气体 Scope 1, 2, 3 标准能核算 (Greenhouse Footprint) */}
      <div className="bg-[#16191e] border border-[#2d323a] rounded p-4 flex flex-col gap-4">
        <div className="flex items-center gap-2 border-b border-[#2d323a] pb-2">
          <BarChart3 className="w-4 h-4 text-blue-500" />
          <span className="font-bold text-gray-200 text-[13px]">碳足迹三级范围核算 (GHG Protocol)</span>
        </div>

        {/* 范围卡片叠层 */}
        <div className="flex flex-col gap-2.5">
          {Object.entries(carbonScopeData).map(([key, data]) => {
            const isScope1 = key === "scope1";
            const isScope2 = key === "scope2";
            return (
              <div key={key} className="bg-[#11141a] border border-[#2d323a] rounded p-3 flex flex-col gap-1.5">
                <div className="flex items-center justify-between border-b border-[#1d232d] pb-1">
                  <span className="font-bold text-gray-300">{data.title}</span>
                  <span className={`font-bold px-1.5 py-0.5 rounded text-[10px] ${
                    isScope1 ? "bg-red-950 text-red-400" : isScope2 ? "bg-yellow-950 text-yellow-500" : "bg-cyan-950 text-cyan-400"
                  }`}>
                    日排放折算: {data.tonsDaily} tCO₂e ({data.percentage}%)
                  </span>
                </div>
                <p className="text-[10px] text-gray-500 leading-relaxed">{data.desc}</p>
                <div className="text-[9px] bg-[#16191e] p-1.5 rounded text-blue-400 font-bold italic text-right mt-0.5 border border-[#1d232d]">
                  {data.formula}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 3. 右侧: CCUS 碳捕集与高压封存工艺孔 (Carbon Capture Aquifer Storage) */}
      <div className="bg-[#16191e] border border-[#2d323a] rounded p-4 flex flex-col gap-4">
        <div className="flex items-center gap-2 border-b border-[#2d323a] pb-2">
          <CloudSnow className="w-4 h-4 text-teal-400" />
          <span className="font-bold text-gray-200 text-[13px]">CCUS 碳捕集、地质注入与封存孪生</span>
        </div>

        {/* 方案选择 */}
        <div className="flex gap-1.5">
          {ccusSequestrationPlans.map((plan: any) => (
            <button
              key={plan.id}
              onClick={() => setSelectedPlanId(plan.id)}
              className={`flex-1 py-2 px-1 rounded transition text-center border font-bold text-[10px] ${
                selectedPlanId === plan.id
                  ? "bg-teal-950 border-teal-500 text-teal-400"
                  : "bg-[#11141a] border-[#2d323a] text-gray-400 hover:text-white"
              }`}
            >
              {plan.projectName}
            </button>
          ))}
        </div>

        {/* 地质注碳参数 */}
        <div className="bg-[#11141a] border border-[#2d323a] rounded p-3 flex flex-col gap-2 text-[11px] leading-relaxed">
          <div className="flex justify-between border-b border-[#2d323a] pb-1.5">
            <span className="font-bold text-gray-400">捕集压缩与地质回注参数</span>
            <span className="text-teal-400 font-bold">{activePlan.sequestrationMedium}</span>
          </div>
          
          <div className="grid grid-cols-2 gap-y-2 text-gray-500">
            <span>封存层深度: <strong className="text-white">{activePlan.sequestrationDepthMeter} m</strong></span>
            <span>注入井口压力: <strong className="text-white">{activePlan.injectionPressureMpa} MPa</strong></span>
            <span>日捕集压缩量: <strong className="text-white">{activePlan.dailyCaptureTons} t/d</strong></span>
            <span>累计封存量: <strong className="text-teal-400 font-bold">{(activePlan.accumulatedSequestrationKiloTons).toFixed(1)} kt</strong></span>
          </div>

          <div className="border-t border-[#2d323a] pt-2 mt-1.5">
            <span className="text-gray-400 font-bold">封存储层地质学类型:</span>
            <div className="text-gray-300 mt-1 bg-[#16191e] border border-[#222831] p-2 rounded">
              {activePlan.aquiferPorosityRatio ? (
                <>
                  咸水层多孔介质裂隙封存。<br />
                  地质孔隙度: <strong className="text-emerald-400">{(activePlan.aquiferPorosityRatio*100).toFixed(1)}%</strong> | 渗透率: <strong className="text-white">{activePlan.permeabilityMillidarcy} mD</strong>
                </>
              ) : (
                "枯竭油气藏多维重力圈闭气相置换。"
              )}
            </div>
          </div>
        </div>

        {/* 碳捕集能耗与净减碳审计 */}
        <div className="bg-[#11141a]/50 border border-teal-950 p-2.5 rounded text-[10px] flex items-center gap-1 text-teal-400 leading-normal">
          <Sparkles className="w-5 h-5 shrink-0" />
          <span>CCUS物理全流程采用中石化自主研发的高选择性胺基吸附催化剂，单位捕集能耗低至 2.4 GJ/吨CO₂，净减碳效率达 94.2%。</span>
        </div>

      </div>
    </div>
  );
}
