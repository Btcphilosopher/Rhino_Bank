/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { pipelineTwins, simulatePipelineHydraulics } from "../data";
import { Activity, Radio, Sliders, Play, Square, Compass, AlertCircle, Cpu } from "lucide-react";

export default function PipelineView() {
  const [selectedPipeId, setSelectedPipeId] = useState("PIPE-Y01");
  const [flowRate, setFlowRate] = useState(1500); // 吨/小时
  const [pumpActive, setPumpActive] = useState(true);
  const [demandShift, setDemandShift] = useState(0); // -20, 0, 20

  // 模拟计算结果
  const [simResult, setSimResult] = useState(
    simulatePipelineHydraulics(selectedPipeId, flowRate, pumpActive, demandShift)
  );

  useEffect(() => {
    setSimResult(simulatePipelineHydraulics(selectedPipeId, flowRate, pumpActive, demandShift));
  }, [selectedPipeId, flowRate, pumpActive, demandShift]);

  const activePipe = pipelineTwins.find(p => p.id === selectedPipeId) || pipelineTwins[0];

  return (
    <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 font-mono text-xs select-none text-gray-300">
      
      {/* 1. 左侧: 长输管线列表 & 配额设置 */}
      <div className="bg-[#16191e] border border-[#2d323a] rounded p-4 flex flex-col gap-4">
        <div className="flex items-center gap-2 border-b border-[#2d323a] pb-2">
          <Radio className="w-4 h-4 text-orange-500 animate-pulse" />
          <span className="font-bold text-gray-200 text-[13px]">长输管网调度控制中心</span>
        </div>

        {/* 管道选择 */}
        <div className="flex flex-col gap-2 max-h-[160px] overflow-y-auto">
          {pipelineTwins.map((pipe) => (
            <div
              key={pipe.id}
              onClick={() => {
                setSelectedPipeId(pipe.id);
                // 还原初始流量防止超限
                setFlowRate(pipe.id === "PIPE-Y01" ? 1500 : pipe.id === "PIPE-G01" ? 1000 : 600);
              }}
              className={`p-2.5 rounded border transition cursor-pointer flex flex-col gap-1 ${
                selectedPipeId === pipe.id
                  ? "bg-[#251518] border-red-800 text-white"
                  : "bg-[#11141a] border-[#2d323a] hover:bg-[#1a1e24]"
              }`}
            >
              <div className="flex justify-between font-bold">
                <span>{pipe.name}</span>
                <span className={`text-[9px] px-1 rounded uppercase ${
                  pipe.medium === "原油" ? "bg-amber-950 text-amber-400" :
                  pipe.medium === "天然气" ? "bg-cyan-950 text-cyan-400" : "bg-purple-950 text-purple-400"
                }`}>
                  {pipe.medium}
                </span>
              </div>
              <div className="text-[10px] text-gray-400 flex justify-between">
                <span>里程: {pipe.lengthKm} km | 管径: {pipe.diameterMm}mm</span>
                <span>设计能力: {pipe.designCapacityMillionTonsPerYear} 万吨/年</span>
              </div>
            </div>
          ))}
        </div>

        {/* 管道静态物理属性孪生 */}
        <div className="bg-[#11141a] border border-[#2d323a] rounded p-3 flex flex-col gap-1.5">
          <span className="font-bold text-gray-400 border-b border-[#2d323a] pb-1">管线物理标定参数</span>
          <div className="grid grid-cols-2 gap-y-1.5 text-gray-500 text-[11px]">
            <span>起点中枢: <strong className="text-white">{activePipe.startPoint}</strong></span>
            <span>终点接卸: <strong className="text-white">{activePipe.endPoint}</strong></span>
            <span>长输材质: <strong className="text-white">{activePipe.material}</strong></span>
            <span>当前流温: <strong className="text-white">{activePipe.temperatureCelsius} ℃</strong></span>
            <span>腐蚀检测标定: <strong className={`${activePipe.corrosionStatus === "良好" ? "text-emerald-400" : "text-yellow-500"}`}>{activePipe.corrosionStatus}</strong></span>
          </div>
        </div>
      </div>

      {/* 2. 中间: 水力压降与流速孪生曲线 */}
      <div className="bg-[#16191e] border border-[#2d323a] rounded p-4 flex flex-col gap-4">
        <div className="flex items-center justify-between border-b border-[#2d323a] pb-2">
          <div className="flex items-center gap-2">
            <Compass className="w-4 h-4 text-blue-500" />
            <span className="font-bold text-gray-200 text-[13px]">长输管线沿程水力压降梯度曲线</span>
          </div>
          <span className="text-cyan-400 text-[10px]">SCADA 沿程传压测点：12点</span>
        </div>

        {/* 压降曲线 (沿管线里程压力递减示意) */}
        <div className="h-[180px] bg-[#0c0e12] border border-[#2d323a] rounded relative p-4 flex flex-col justify-end">
          {/* Y轴压力刻度 */}
          <div className="absolute top-2 left-2 text-[8px] text-gray-600 flex flex-col gap-8">
            <span>12.0 MPa</span>
            <span>6.0 MPa</span>
            <span>0.0 MPa</span>
          </div>

          <svg className="w-full h-full absolute inset-0 z-0 px-8 py-4 pointer-events-none">
            {/* 虚线网格 */}
            <g stroke="#1a1e24" strokeWidth="0.5">
              <line x1="0" y1="45" x2="800" y2="45" />
              <line x1="0" y1="90" x2="800" y2="90" />
              <line x1="150" y1="0" x2="150" y2="180" />
              <line x1="300" y1="0" x2="300" y2="180" />
            </g>

            {/* 起点压力 -> 沿程摩阻压降 -> 终点压力 (折线描绘) */}
            {/* y = 180 - (Mpa / 12) * 140 */}
            <path
              d={`M 40 ${180 - (activePipe.pressureMpa / 12) * 140} 
                  L 200 ${180 - ((activePipe.pressureMpa + (pumpActive ? 4.5 : 0) - simResult.pressureDropMpa*0.5) / 12) * 140} 
                  L 360 ${180 - (simResult.endPressureMpa / 12) * 140}`}
              fill="none"
              stroke="#f59e0b"
              strokeWidth="2.5"
            />

            {/* 泵站节点 (K300 处增压升幅) */}
            {pumpActive && (
              <g>
                <circle cx="200" cy={180 - ((activePipe.pressureMpa + 4.5 - simResult.pressureDropMpa*0.5) / 12) * 140} r="4" fill="#06b6d4" />
                <text x="180" y="55" fill="#06b6d4" fontSize="9" className="font-bold">K300 增压泵站 (+4.5 MPa)</text>
              </g>
            )}

            {/* 汽化线 / 气蚀红线 0.8 Mpa */}
            <line x1="0" y1={180 - (0.8 / 12) * 140} x2="400" y2={180 - (0.8 / 12) * 140} stroke="#ef4444" strokeWidth="1" strokeDasharray="3,3" />
            <text x="250" y={180 - (0.8 / 12) * 140 - 4} fill="#ef4444" fontSize="8">临界气蚀安全压限 (0.8 MPa)</text>

            <text x="45" y={180 - (activePipe.pressureMpa / 12) * 140 - 8} fill="#f59e0b" fontSize="9" className="font-bold">
              起点: {activePipe.pressureMpa} MPa
            </text>
            <text x="290" y={180 - (simResult.endPressureMpa / 12) * 140 - 8} fill="#f59e0b" fontSize="9" className="font-bold">
              终点: {simResult.endPressureMpa} MPa
            </text>
          </svg>

          <div className="flex gap-4 items-center justify-center text-[9px] text-gray-500 z-10 select-none pb-1">
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-0.5 bg-[#f59e0b]" />
              输油压力沿程梯度 (沿程降幅: {simResult.pressureDropMpa} MPa)
            </span>
          </div>
        </div>

        {/* 物理方程式标注 */}
        <div className="bg-[#11141a] border border-[#2d323a] p-2 rounded text-[10px] leading-relaxed text-gray-500">
          <span>摩阻沿程阻力计算：基于达西-魏斯巴赫(Darcy-Weisbach)及钢管微观绝对粗糙度等效解算。当前雷诺数标定 $Re = 1.25 \\times 10^5$。</span>
        </div>
      </div>

      {/* 3. 右侧: 水力控制器与泵机配额 (Darcy-Weisbach Engine Controls) */}
      <div className="bg-[#16191e] border border-[#2d323a] rounded p-4 flex flex-col gap-3">
        <div className="flex items-center gap-2 border-b border-[#2d323a] pb-2">
          <Sliders className="w-4 h-4 text-emerald-500" />
          <span className="font-bold text-gray-200 text-[13px]">沿线泵站与配额模拟器</span>
        </div>

        {/* 调节阀开度 */}
        <div className="flex flex-col gap-1.5">
          <div className="flex justify-between text-[11px]">
            <span className="text-gray-400">输油流量调整 (Q)</span>
            <span className="text-white font-bold">{flowRate} 吨/小时</span>
          </div>
          <input
            type="range"
            min="500"
            max="3000"
            step="100"
            value={flowRate}
            onChange={(e) => setFlowRate(Number(e.target.value))}
            className="w-full h-1 bg-[#20252e] rounded appearance-none cursor-pointer accent-red-500"
          />
        </div>

        {/* 沿线泵站启动/停止 */}
        <div className="flex flex-col gap-2 bg-[#11141a] border border-[#2d323a] p-3 rounded mt-1">
          <div className="flex items-center justify-between text-[11px]">
            <span className="text-gray-400">K300 离心泵增压站</span>
            <span className={`font-bold px-1.5 py-0.5 rounded text-[10px] ${pumpActive ? "bg-emerald-950 text-emerald-400 border border-emerald-500" : "bg-red-950 text-red-400 border border-red-500"}`}>
              {pumpActive ? "运行中 (RUNNING)" : "停机中 (STOPPED)"}
            </span>
          </div>
          <div className="flex gap-2 mt-1">
            <button
              onClick={() => setPumpActive(true)}
              className={`flex-1 py-1 rounded transition text-[10px] font-bold flex items-center justify-center gap-1 ${
                pumpActive ? "bg-emerald-900 border border-emerald-500 text-white" : "bg-[#16191e] border border-[#2d323a] text-gray-400 hover:text-white"
              }`}
            >
              <Play className="w-3 h-3" />
              开机
            </button>
            <button
              onClick={() => setPumpActive(false)}
              className={`flex-1 py-1 rounded transition text-[10px] font-bold flex items-center justify-center gap-1 ${
                !pumpActive ? "bg-red-900 border border-red-500 text-white" : "bg-[#16191e] border border-[#2d323a] text-gray-400 hover:text-white"
              }`}
            >
              <Square className="w-3 h-3" />
              停机
            </button>
          </div>
        </div>

        {/* 供应中断/下游需求暴增模拟 */}
        <div className="flex flex-col gap-1.5 border-t border-[#2d323a] pt-3">
          <div className="flex justify-between text-[11px]">
            <span className="text-gray-400">下游配能需求调变 (Δ)</span>
            <span className="text-white font-bold">{demandShift >= 0 ? `+${demandShift}` : demandShift}%</span>
          </div>
          <div className="flex gap-1">
            {[-20, 0, 20].map((ds) => (
              <button
                key={ds}
                onClick={() => setDemandShift(ds)}
                className={`flex-1 py-0.5 rounded transition text-[10px] font-bold ${
                  demandShift === ds
                    ? "bg-red-950 border border-red-600 text-red-400"
                    : "bg-[#11141a] border border-[#2d323a] text-gray-400 hover:text-white"
                }`}
              >
                {ds === 0 ? "常态需求" : ds > 0 ? "峰值 +20%" : "避峰 -20%"}
              </button>
            ))}
          </div>
        </div>

        {/* 物理仿真瓶颈提示 */}
        {simResult.bottleneckDetected ? (
          <div className="bg-red-950/40 border border-red-500 text-red-400 rounded p-2.5 flex gap-2 text-[10px] mt-2 animate-pulse leading-relaxed">
            <AlertCircle className="w-5 h-5 text-red-500 shrink-0" />
            <div className="flex flex-col gap-0.5">
              <span className="font-bold">水力汽蚀/气阻瓶颈警报！</span>
              <span>由于流量设配过大，终点压力低于临界安全极限，发生了水击和气阻瓶颈：</span>
              <span className="font-bold border-t border-red-800 pt-1 mt-1">{simResult.bottleneckLocation}</span>
            </div>
          </div>
        ) : (
          <div className="bg-emerald-950/20 border border-emerald-800 text-emerald-400 rounded p-2.5 flex gap-2 text-[10px] mt-2">
            <Cpu className="w-5 h-5 text-emerald-500 shrink-0" />
            <div className="flex flex-col gap-0.5 leading-relaxed">
              <span className="font-bold">管网仿真运行平稳</span>
              <span>沿线压降斜率在标称安全设计区间内。增压泵电机效率 82.0%，单时耗电量为：{simResult.energyConsumptionKwh} kWh。</span>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
