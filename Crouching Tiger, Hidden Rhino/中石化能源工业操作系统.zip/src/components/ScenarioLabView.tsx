/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { Sliders, RefreshCw, BarChart2, ShieldCheck, Compass, HelpCircle, Activity } from "lucide-react";

export default function ScenarioLabView() {
  const [crudePrice, setCrudePrice] = useState(75); // USD/bbl
  const [opecQuota, setOpecQuota] = useState(0); // -10% to +10%
  const [carbonTax, setCarbonTax] = useState(30); // USD/ton
  const [simulationActive, setSimulationActive] = useState(false);

  // 仿真敏感性分析计算
  const [sensitivity, setSensitivity] = useState({
    ebitdaImpactBillionRmb: 0,
    breakevenCostPerBarrelUsd: 58.2,
    supplyChainRiskScore: 42, // 100 max
    refineryMarginRmbPerTon: 180,
    ccusFeasibilityIndex: 65 // 100 max
  });

  const runSimulation = () => {
    setSimulationActive(true);
    setTimeout(() => {
      // 物理数学逻辑推导
      // 1. 原油价格上涨 -> 勘探开采利润上涨，但炼厂原油购入成本暴增 -> EBITDA 冲击
      // 2. 碳税上涨 -> 炼化耗能成本极高，EBITDA 下滑，但促使 CCUS 变得极为可行
      // 3. OPEC配额收紧 (负数) -> 供应风险上涨
      const ebitda = (crudePrice - 60) * 0.45 - (carbonTax * 0.12) + (opecQuota * 1.5);
      const breakeven = 50 + (carbonTax * 0.15) - (opecQuota * 0.3);
      const margin = Math.round(150 + (75 - crudePrice) * 1.8 - (carbonTax * 0.8));
      const risk = Math.min(100, Math.max(0, Math.round(45 + (opecQuota * -2.5) + (crudePrice > 90 ? 15 : 0))));
      const ccusFeas = Math.min(100, Math.max(0, Math.round(40 + (carbonTax * 0.6))));

      setSensitivity({
        ebitdaImpactBillionRmb: Number(ebitda.toFixed(2)),
        breakevenCostPerBarrelUsd: Number(breakeven.toFixed(1)),
        supplyChainRiskScore: risk,
        refineryMarginRmbPerTon: margin,
        ccusFeasibilityIndex: ccusFeas
      });
      setSimulationActive(false);
    }, 400);
  };

  // 联动更新
  useEffect(() => {
    runSimulation();
  }, [crudePrice, opecQuota, carbonTax]);

  return (
    <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 font-mono text-xs select-none text-gray-300">
      
      {/* 1. 左侧: 宏观调控仿真滑块 */}
      <div className="bg-[#16191e] border border-[#2d323a] rounded p-4 flex flex-col gap-4">
        <div className="flex items-center gap-2 border-b border-[#2d323a] pb-2">
          <Sliders className="w-4 h-4 text-red-500 animate-pulse" />
          <span className="font-bold text-gray-200 text-[13px]">能源沙盘克隆模拟器</span>
        </div>

        {/* 1. 原油即期现货价格 */}
        <div className="flex flex-col gap-1.5">
          <div className="flex justify-between text-[11px]">
            <span className="text-gray-400">布伦特原油标称基准价格 (Brent Spot)</span>
            <span className="text-yellow-500 font-bold">${crudePrice} / 桶</span>
          </div>
          <input
            type="range"
            min="45"
            max="120"
            step="1"
            value={crudePrice}
            onChange={(e) => setCrudePrice(Number(e.target.value))}
            className="w-full h-1.5 bg-[#20252e] rounded appearance-none cursor-pointer accent-red-500"
          />
        </div>

        {/* 2. OPEC+ 产量配额限制 */}
        <div className="flex flex-col gap-1.5">
          <div className="flex justify-between text-[11px]">
            <span className="text-gray-400">OPEC+ 全球原油配额调变 (Quota Shift)</span>
            <span className={`font-bold ${opecQuota >= 0 ? "text-emerald-400" : "text-red-400"}`}>
              {opecQuota >= 0 ? `＋${opecQuota}` : opecQuota}%
            </span>
          </div>
          <input
            type="range"
            min="-10"
            max="10"
            step="1"
            value={opecQuota}
            onChange={(e) => setOpecQuota(Number(e.target.value))}
            className="w-full h-1.5 bg-[#20252e] rounded appearance-none cursor-pointer accent-red-500"
          />
        </div>

        {/* 3. 碳排放配额交易价格 / 碳税 */}
        <div className="flex flex-col gap-1.5">
          <div className="flex justify-between text-[11px]">
            <span className="text-gray-400">全国碳排放配额(CEA)价格 (Carbon Tax)</span>
            <span className="text-teal-400 font-bold">${carbonTax} / 吨CO₂e</span>
          </div>
          <input
            type="range"
            min="10"
            max="120"
            step="5"
            value={carbonTax}
            onChange={(e) => setCarbonTax(Number(e.target.value))}
            className="w-full h-1.5 bg-[#20252e] rounded appearance-none cursor-pointer accent-red-500"
          />
        </div>

        {/* 沙箱安全提示 (XAI Verification) */}
        <div className="bg-[#11141a] border border-[#2d323a] p-3 rounded flex flex-col gap-1 text-[10px] text-gray-500 leading-relaxed mt-2">
          <span className="font-bold text-gray-400 flex items-center gap-1">
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
            克隆沙箱 IT 安全声明
          </span>
          <span>
            本实验室为完全隔离的虚拟孪生沙盘。调整上述任何市场因子仅供战略规划、推演演练，不会影响任何正在运行的生产控制中枢 PLC/DCS 决策安全。
          </span>
        </div>
      </div>

      {/* 2. 中间: 敏感性曲线与多场景对比 (Monte Carlo Simulation Graph) */}
      <div className="bg-[#16191e] border border-[#2d323a] rounded p-4 flex flex-col gap-4">
        <div className="flex items-center justify-between border-b border-[#2d323a] pb-2">
          <div className="flex items-center gap-2">
            <BarChart2 className="w-4 h-4 text-blue-500" />
            <span className="font-bold text-gray-200 text-[13px]">蒙特卡洛敏感性概率边界分布</span>
          </div>
          {simulationActive ? (
            <span className="text-yellow-500 text-[10px] flex items-center gap-1">
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              解算器正迭代 10,000 次...
            </span>
          ) : (
            <span className="text-emerald-400 text-[10px]">解算器就绪 (10k Iterations)</span>
          )}
        </div>

        {/* 概率分布线/灵敏度区间 (SVG) */}
        <div className="h-[180px] bg-[#0c0e12] border border-[#2d323a] rounded relative p-4 flex flex-col justify-end">
          <div className="absolute top-2 left-2 text-[8px] text-gray-600 flex flex-col gap-8">
            <span>95% 置信度</span>
            <span>中位数均值</span>
            <span>5% 压力边界</span>
          </div>

          <svg className="w-full h-full absolute inset-0 z-0 px-8 py-4 pointer-events-none">
            {/* 网格网 */}
            <g stroke="#1a1e24" strokeWidth="0.5">
              <line x1="0" y1="45" x2="400" y2="45" />
              <line x1="0" y1="90" x2="400" y2="90" />
              <line x1="200" y1="0" x2="200" y2="180" />
            </g>

            {/* 绘制钟形高斯概率分布曲线 */}
            {/* y = 180 - f(x) * h */}
            <path
              d="M 20 160 
                 Q 100 150 150 110 
                 T 200 40 
                 T 250 110 
                 T 380 160"
              fill="none"
              stroke="#06b6d4"
              strokeWidth="2"
            />

            {/* 当前实测因子标定垂直轴 */}
            <line x1={150 + crudePrice * 1.5} y1="0" x2={150 + crudePrice * 1.5} y2="180" stroke="#ef4444" strokeWidth="1.5" strokeDasharray="3,3" />
            <text x={110 + crudePrice * 1.5} y="35" fill="#ef4444" fontSize="9" className="font-bold">
              当前市场定位: ${crudePrice}
            </text>

            <text x="50" y="150" fill="#64748b" fontSize="8">
              P90: ${(crudePrice * 0.85).toFixed(0)}
            </text>
            <text x="310" y="150" fill="#64748b" fontSize="8">
              P10: ${(crudePrice * 1.15).toFixed(0)}
            </text>
          </svg>

          <div className="flex gap-4 items-center justify-center text-[9px] text-gray-500 z-10 select-none pb-1">
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-0.5 bg-[#06b6d4]" />
              EBITDA 敏感性收益常态分布区间 (基于 2026 估值模型)
            </span>
          </div>
        </div>

        {/* 物理方程式标注 */}
        <div className="bg-[#11141a] border border-[#2d323a] p-2 rounded text-[10px] text-gray-500 flex justify-between items-center leading-normal">
          <span>灵敏度求解：$\\sigma^2 = \\int (x - \\mu)^2 f(x) dx$。置信区间 [95%], P10/P50/P90 分布符合预期。</span>
        </div>
      </div>

      {/* 3. 右侧: 压力测试与关键决策弹性指标 (EBITDA & Stress Metrics) */}
      <div className="bg-[#16191e] border border-[#2d323a] rounded p-4 flex flex-col gap-3">
        <div className="flex items-center gap-2 border-b border-[#2d323a] pb-2">
          <Activity className="w-4 h-4 text-emerald-500" />
          <span className="font-bold text-gray-200 text-[13px]">压力测试关键财务弹性指标</span>
        </div>

        {/* 指标面板 */}
        <div className="flex-1 flex flex-col gap-2.5">
          <div className="bg-[#11141a] border border-[#2d323a] p-3 rounded flex justify-between items-center">
            <div className="flex flex-col gap-0.5">
              <span className="text-gray-500">EBITDA 预计波动变幅:</span>
              <span className={`text-base font-bold ${sensitivity.ebitdaImpactBillionRmb >= 0 ? "text-emerald-400" : "text-red-400"}`}>
                {sensitivity.ebitdaImpactBillionRmb >= 0 ? `＋${sensitivity.ebitdaImpactBillionRmb}` : sensitivity.ebitdaImpactBillionRmb} 亿元
              </span>
            </div>
            <span className="text-[9px] text-gray-600 font-bold">相比基准</span>
          </div>

          <div className="bg-[#11141a] border border-[#2d323a] p-3 rounded flex justify-between items-center">
            <div className="flex flex-col gap-0.5">
              <span className="text-gray-500">单桶完全保本成本价格 (Break-even):</span>
              <span className="text-white font-bold text-base">${sensitivity.breakevenCostPerBarrelUsd} / 桶</span>
            </div>
            <span className="text-[9px] text-gray-600 font-bold">OPEC+Quota 权重</span>
          </div>

          <div className="bg-[#11141a] border border-[#2d323a] p-3 rounded flex justify-between items-center">
            <div className="flex flex-col gap-0.5">
              <span className="text-gray-500">炼化平均加工毛利 (Refinery Margin):</span>
              <span className={`text-base font-bold ${sensitivity.refineryMarginRmbPerTon >= 120 ? "text-emerald-400" : "text-yellow-500"}`}>
                ￥{sensitivity.refineryMarginRmbPerTon} / 吨
              </span>
            </div>
            <span className="text-[9px] text-gray-600 font-bold">LP线性解算</span>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            <div className="bg-[#11141a] border border-[#2d323a] p-2 rounded flex flex-col">
              <span className="text-gray-500 text-[9px]">供应链缺口风险系数:</span>
              <span className={`text-sm font-bold mt-1 ${sensitivity.supplyChainRiskScore > 60 ? "text-red-400" : "text-emerald-400"}`}>
                {sensitivity.supplyChainRiskScore} % (中度)
              </span>
            </div>
            <div className="bg-[#11141a] border border-[#2d323a] p-2 rounded flex flex-col">
              <span className="text-gray-500 text-[9px]">CCUS 经济可行性度:</span>
              <span className="text-teal-400 font-bold text-sm mt-1">
                {sensitivity.ccusFeasibilityIndex} %
              </span>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
