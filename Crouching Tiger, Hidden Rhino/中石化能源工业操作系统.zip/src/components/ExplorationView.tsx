/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { explorationBlocks } from "../data";
import { Database, Compass, CheckCircle2, TrendingUp, Cpu, Eye, Layers } from "lucide-react";

export default function ExplorationView() {
  const [selectedBlockId, setSelectedBlockId] = useState(explorationBlocks[0].id);
  const [sliceType, setSliceType] = useState<"time" | "depth" | "inline" | "crossline">("inline");
  const [sliceValue, setSliceValue] = useState(150); // 米/毫秒
  const [aiAssistEnabled, setAiAssistEnabled] = useState(true);

  const selectedBlock = explorationBlocks.find(b => b.id === selectedBlockId) || explorationBlocks[0];

  // 地震解释AI特征
  const aiModelMeta = {
    model: "SinopecGeoSweeper-v4.2-Pro",
    version: "2026.Q3.0902",
    trainingData: "塔里木&四川盆地 420,000 km³ 三维地震实测剖面",
    confidence: 94.6,
    source: "中国石化石油物探技术研究院 (石油地质大数据中心)"
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-mono text-xs select-none text-gray-300">
      
      {/* 1. 左侧: 勘探区块管理 */}
      <div className="bg-[#16191e] border border-[#2d323a] rounded p-4 flex flex-col gap-4">
        <div className="flex items-center gap-2 border-b border-[#2d323a] pb-2">
          <Database className="w-4 h-4 text-red-500" />
          <span className="font-bold text-gray-200 text-[13px]">勘探区块智能管理</span>
        </div>

        <div className="flex flex-col gap-2 overflow-y-auto max-h-[160px] pr-1">
          {explorationBlocks.map((block) => (
            <div
              key={block.id}
              onClick={() => setSelectedBlockId(block.id)}
              className={`p-2.5 rounded border transition cursor-pointer flex flex-col gap-1 ${
                selectedBlockId === block.id
                  ? "bg-[#251518] border-red-800 text-white"
                  : "bg-[#11141a] border-[#2d323a] hover:bg-[#1a1e24] hover:border-gray-600"
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold">{block.name}</span>
                <span className="text-[10px] text-gray-500 uppercase">{block.id}</span>
              </div>
              <div className="text-[10px] text-gray-400 flex items-center justify-between">
                <span>盆地: {block.basin}</span>
                <span className="text-red-400 font-bold">{block.developmentStatus}</span>
              </div>
            </div>
          ))}
        </div>

        {/* 详细数字孪生参数 */}
        <div className="bg-[#11141a] border border-[#2d323a] rounded p-3 flex flex-col gap-2 text-[11px]">
          <span className="font-bold text-gray-300 border-b border-[#2d323a] pb-1">区块地质孪生详情</span>
          <div className="grid grid-cols-2 gap-2 text-gray-400">
            <span>国家/盆地: <span className="text-white font-bold">{selectedBlock.country} / {selectedBlock.basin}</span></span>
            <span>勘探面积: <span className="text-white font-bold">{selectedBlock.areaSqKm} km²</span></span>
            <span>地质断层: <span className="text-white font-bold">{selectedBlock.geologicalAge}</span></span>
            <span>探明储量: <span className="text-white font-bold">{selectedBlock.provenReserves} 亿吨</span></span>
            <span>概算资源: <span className="text-white font-bold">{selectedBlock.prospectiveReserves} 亿吨</span></span>
            <span>开钻总井: <span className="text-white font-bold">{selectedBlock.wellsCount} 口</span></span>
            <span>生产井数: <span className="text-blue-400 font-bold">{selectedBlock.productionWellsCount} 口</span></span>
            <span>勘探井数: <span className="text-orange-400 font-bold">{selectedBlock.explorationWellsCount} 口</span></span>
          </div>
          <div className="border-t border-[#2d323a] pt-2 mt-1 flex justify-between items-center text-gray-400">
            <span>区块估值估算:</span>
            <span className="text-yellow-500 font-bold text-sm">${selectedBlock.economicValueBillionUSD}B USD</span>
          </div>
        </div>
      </div>

      {/* 2. 中间 & 右侧: 三维/二维地震解释切片实验室 (Interactive Seismic Lab) */}
      <div className="lg:col-span-2 bg-[#16191e] border border-[#2d323a] rounded p-4 flex flex-col gap-4">
        <div className="flex items-center justify-between border-b border-[#2d323a] pb-2">
          <div className="flex items-center gap-2">
            <Compass className="w-4 h-4 text-blue-500" />
            <span className="font-bold text-gray-200 text-[13px]">地震属性与地下构造数字孪生</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-gray-400">AI智能辅助解算:</span>
            <button
              onClick={() => setAiAssistEnabled(!aiAssistEnabled)}
              className={`px-3 py-1 rounded transition text-[10px] font-bold ${
                aiAssistEnabled 
                  ? "bg-emerald-950 border border-emerald-500 text-emerald-400" 
                  : "bg-gray-800 border border-gray-600 text-gray-400"
              }`}
            >
              {aiAssistEnabled ? "开启 (ACTIVE)" : "关闭 (OFF)"}
            </button>
          </div>
        </div>

        {/* 仿真切片展示区 */}
        <div className="relative w-full h-[260px] bg-[#0c0e12] border border-[#2d323a] rounded overflow-hidden flex flex-col items-center justify-center">
          {/* 网格经度波形图 (通过 SVG 拟合地层褶皱与断层、甜点预测) */}
          <svg className="w-full h-full absolute inset-0 z-0 opacity-70">
            <defs>
              <linearGradient id="layerGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#1e3a8a" stopOpacity="0.4" />
                <stop offset="50%" stopColor="#854d0e" stopOpacity="0.3" />
                <stop offset="100%" stopColor="#064e3b" stopOpacity="0.5" />
              </linearGradient>
            </defs>
            {/* 网格线 */}
            <g stroke="#1d232d" strokeWidth="0.5">
              {Array.from({ length: 15 }).map((_, i) => (
                <line key={`v-${i}`} x1={`${(i + 1) * 50}`} y1="0" x2={`${(i + 1) * 50}`} y2="300" />
              ))}
              {Array.from({ length: 10 }).map((_, i) => (
                <line key={`h-${i}`} x1="0" y1={`${(i + 1) * 30}`} x2="800" y2={`${(i + 1) * 30}`} />
              ))}
            </g>

            {/* 地层地层反射弧 */}
            <path d="M 0 100 Q 200 {sliceValue * 0.4 + 40} 400 130 T 800 {sliceValue * 0.2 + 100}" fill="none" stroke="#2d3748" strokeWidth="2" />
            <path d="M 0 150 Q 250 {sliceValue * 0.6 + 80} 500 180 T 800 {sliceValue * 0.3 + 140}" fill="none" stroke="#4a5568" strokeWidth="1.5" />
            {/* 断层线 (斜断裂裂缝面) */}
            <line x1="380" y1="50" x2="430" y2="230" stroke="#f97316" strokeWidth="2.5" strokeDasharray="3,3" />
            <text x="350" y="45" fill="#f97316" fontSize="10" className="font-bold">逆掩断层 F-01</text>

            {/* 甜点靶点 (圈闭 / 烃源岩富集区) */}
            <path d="M 450 140 Q 520 130 580 155 Q 520 180 450 140 Z" fill="url(#layerGrad)" stroke="#3b82f6" strokeWidth="1.5" />
            <text x="500" y="152" fill="#60a5fa" fontSize="10" className="font-bold">圈闭反射体 #A (古近组)</text>

            {/* AI 预测轮廓 */}
            {aiAssistEnabled && (
              <g>
                <path d="M 440 130 L 590 145 L 530 190 Z" fill="rgba(16, 185, 129, 0.15)" stroke="#10b981" strokeWidth="1" strokeDasharray="2,2" />
                <circle cx="510" cy="155" r="4" fill="#10b981" />
                <text x="520" y="175" fill="#34d399" fontSize="9" className="font-bold">AI油气富集“甜点”概率: 94.6%</text>
              </g>
            )}

            {/* 当前切面深度尺 */}
            <line x1="0" y1={sliceValue} x2="800" y2={sliceValue} stroke="#ef4444" strokeWidth="1.5" strokeOpacity="0.8" />
          </svg>

          {/* 指标面板 */}
          <div className="absolute top-2 left-3 bg-[#11141a]/90 border border-[#2d323a] p-2 rounded text-[10px] flex flex-col gap-1 z-10">
            <span className="text-gray-400 font-bold">切片参数控制</span>
            <span>测线位置: Inline {sliceValue * 4}</span>
            <span>地质主频: 32.5 Hz (合成频宽)</span>
            <span>地震波速: 3820 m/s (沙河街组)</span>
          </div>

          <div className="absolute bottom-2 right-3 text-[10px] text-gray-500 font-bold bg-[#11141a]/95 py-1 px-2 rounded border border-[#2d323a]">
            数据源: 齐纳斯三维叠前深度偏移数据 (PSD)
          </div>
        </div>

        {/* 调节滑块与模式 */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t border-[#2d323a] pt-3">
          <div className="flex flex-col gap-2">
            <span className="text-gray-400 font-bold">三维地球物理剖面切取</span>
            <div className="flex gap-2">
              {(["time", "depth", "inline", "crossline"] as const).map((type) => (
                <button
                  key={type}
                  onClick={() => setSliceType(type)}
                  className={`flex-1 py-1 px-2 rounded transition text-[10px] capitalize font-bold border ${
                    sliceType === type
                      ? "bg-[#251518] border-red-800 text-red-400"
                      : "bg-[#11141a] border-[#2d323a] text-gray-400 hover:text-white"
                  }`}
                >
                  {type === "inline" ? "二维测线" : type === "crossline" ? "联络测线" : type === "time" ? "时间切片" : "深度切片"}
                </button>
              ))}
            </div>
            <div className="flex items-center gap-3 mt-1">
              <span className="text-gray-400 whitespace-nowrap">剖面位置:</span>
              <input
                type="range"
                min="30"
                max="230"
                value={sliceValue}
                onChange={(e) => setSliceValue(Number(e.target.value))}
                className="w-full h-1.5 bg-[#1a1e24] rounded-lg appearance-none cursor-pointer accent-red-500"
              />
              <span className="text-white font-bold w-12 text-right">{sliceValue * 4}m</span>
            </div>
          </div>

          {/* 右下: AI 模型可解释性透明声明 (XAI Guidelines) */}
          {aiAssistEnabled ? (
            <div className="bg-[#11141a] border border-[#2d323a] p-3 rounded flex flex-col gap-1 text-[10px] text-emerald-400/90 leading-relaxed">
              <div className="flex items-center gap-1.5 border-b border-[#2d323a] pb-1 mb-1 text-emerald-400 font-bold">
                <Cpu className="w-3.5 h-3.5" />
                <span>智能油藏预测与圈闭识别审计</span>
              </div>
              <div className="grid grid-cols-2 gap-x-3 gap-y-0.5">
                <span>AI推理模型: <span className="text-white font-bold">{aiModelMeta.model}</span></span>
                <span>训练集规模: <span className="text-white font-bold">{aiModelMeta.trainingData}</span></span>
                <span>置信等级: <span className="text-emerald-300 font-bold">{aiModelMeta.confidence}%</span></span>
                <span>模型版本: <span className="text-white font-bold">{aiModelMeta.version}</span></span>
              </div>
              <span className="text-[9px] text-gray-500 border-t border-[#1d232d] pt-1 mt-0.5">
                模型权重来源: {aiModelMeta.source}
              </span>
            </div>
          ) : (
            <div className="bg-[#11141a] border border-[#2d323a] p-3 rounded flex items-center justify-center text-gray-500">
              AI智能油气层自动预测已停用，切换为纯人工地层追踪(HMT)模式。
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
