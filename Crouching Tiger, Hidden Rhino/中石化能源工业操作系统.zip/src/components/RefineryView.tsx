/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { crudeCargos, simulateRefineryOperations, MassEnergyBalanceReport } from "../data";
import { Activity, ShieldAlert, Sliders, ChevronRight, BarChart2, CheckSquare, Zap, Globe } from "lucide-react";

export default function RefineryView() {
  const [loadDelta, setLoadDelta] = useState(0); // -10, 0, 10
  const [selectedCrudeId, setSelectedCrudeId] = useState("CRUDE-AL");
  const [activeDevice, setActiveDevice] = useState("常减压联合装置(CDU-04)");

  // 模拟运行结果
  const [opsResult, setOpsResult] = useState(
    simulateRefineryOperations(loadDelta, selectedCrudeId)
  );

  useEffect(() => {
    setOpsResult(simulateRefineryOperations(loadDelta, selectedCrudeId));
  }, [loadDelta, selectedCrudeId]);

  // 拟合质量平衡模型
  const balanceReport: MassEnergyBalanceReport = {
    entityId: "REFINERY-ZH",
    entityName: "镇海炼化分公司",
    rawInputTons: opsResult.crudeFeedrate,
    byProductsTons: Math.round(opsResult.crudeFeedrate * 0.08),
    mainProductsTons: opsResult.gasolineYield + opsResult.dieselYield + opsResult.jetFuelYield + opsResult.petrochemicalYield,
    processLossTons: Math.round(opsResult.crudeFeedrate * 0.015),
    inventoryDeltaTons: Math.round(opsResult.crudeFeedrate * 0.01),
    massImbalanceErrorPercentage: 0.02, // 0.02%
    energyInputGj: opsResult.energyConsumption,
    energyOutputGj: Math.round(opsResult.energyConsumption * 0.88),
    energyLossGj: Math.round(opsResult.energyConsumption * 0.12),
    energyImbalanceErrorPercentage: 0.14,
    anomalyDetected: loadDelta === 10, // 如果负荷过载，模拟高压仪表标定溢出
    anomalyType: "仪表标定失效"
  };

  const currentCrude = crudeCargos.find(c => c.id === selectedCrudeId) || crudeCargos[0];

  return (
    <div className="grid grid-cols-1 xl:grid-cols-4 gap-6 font-mono text-xs select-none text-gray-300">
      
      {/* 1. 左侧: 原油及负荷参数控制器 */}
      <div className="bg-[#16191e] border border-[#2d323a] rounded p-4 flex flex-col gap-4">
        <div className="flex items-center gap-2 border-b border-[#2d323a] pb-2">
          <Sliders className="w-4 h-4 text-red-500" />
          <span className="font-bold text-gray-200 text-[13px]">炼化负荷与原油组分配比</span>
        </div>

        {/* 原油组分选择 */}
        <div className="flex flex-col gap-1.5">
          <span className="text-gray-400 font-bold">常减压塔底进料原油选择 (Crude Slate)</span>
          <div className="flex flex-col gap-1">
            {crudeCargos.map((c) => (
              <div
                key={c.id}
                onClick={() => setSelectedCrudeId(c.id)}
                className={`p-2 rounded border transition cursor-pointer flex flex-col gap-1 ${
                  selectedCrudeId === c.id
                    ? "bg-[#251518] border-red-800 text-white"
                    : "bg-[#11141a] border-[#2d323a] hover:bg-[#1a1e24]"
                }`}
              >
                <div className="flex justify-between font-bold text-[11px]">
                  <span>{c.name}</span>
                  <span className="text-yellow-500">${c.pricePerBarrelUSD}/bbl</span>
                </div>
                <div className="text-[10px] text-gray-400 flex justify-between">
                  <span>API: {c.apiGravity} | 硫含量: {c.sulfurPercentage}%</span>
                  <span>库存: {c.inventoryKiloTons}kt</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 负荷调节 */}
        <div className="flex flex-col gap-2 border-t border-[#2d323a] pt-3">
          <span className="text-gray-400 font-bold flex justify-between">
            <span>常减压装置负荷系数</span>
            <span className="text-red-400 font-bold">{loadDelta >= 0 ? `+${loadDelta}` : loadDelta}%</span>
          </span>
          <div className="flex gap-2">
            {[-10, 0, 10].map((v) => (
              <button
                key={v}
                onClick={() => setLoadDelta(v)}
                className={`flex-1 py-1 rounded transition text-[10px] font-bold ${
                  loadDelta === v
                    ? "bg-red-950 border border-red-600 text-red-400"
                    : "bg-[#11141a] border border-[#2d323a] text-gray-400 hover:text-white"
                }`}
              >
                {v === 0 ? "基准负荷" : v > 0 ? "超负荷 +10%" : "低负荷 -10%"}
              </button>
            ))}
          </div>
        </div>

        {/* 原理参数血缘血统提示 */}
        <div className="bg-[#11141a] border border-[#2d323a] p-3 rounded text-[10px] leading-relaxed text-gray-500">
          <div className="font-bold text-gray-400 mb-0.5">配煤与原料核算</div>
          <span>当前进料 API {currentCrude.apiGravity} 对应收率因子，模型在 MES 系统标定为 VER-20260917-0615，数据质量等级：A级优秀。</span>
        </div>
      </div>

      {/* 2. 中间: 三维工艺图数字孪生 (WebGL / CSS-grid Schematic with active lines) */}
      <div className="xl:col-span-2 bg-[#16191e] border border-[#2d323a] rounded p-4 flex flex-col gap-4">
        <div className="flex items-center justify-between border-b border-[#2d323a] pb-2">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-blue-500" />
            <span className="font-bold text-gray-200 text-[13px]">炼化联合装置多相流程数字孪生</span>
          </div>
          <span className="text-emerald-400 text-[10px] flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
            分布式DCS状态：正常通信
          </span>
        </div>

        {/* 工艺流网络图 */}
        <div className="h-[240px] bg-[#0c0e12] border border-[#2d323a] rounded relative p-4 flex flex-col justify-between overflow-hidden">
          <div className="grid grid-cols-4 gap-4 h-full relative z-10 items-center">
            {/* 1. 储罐 */}
            <div 
              onClick={() => setActiveDevice("原油储罐(TANK-CR-101)")}
              className={`p-2 border rounded text-center cursor-pointer transition ${
                activeDevice.startsWith("原油") ? "bg-[#251518] border-red-800" : "bg-[#11141a] border-[#2d323a]"
              }`}
            >
              <div className="font-bold text-[11px] text-gray-200">原油储罐</div>
              <div className="text-[10px] text-gray-400 mt-1">{opsResult.crudeFeedrate} 吨/日</div>
              <div className="text-[9px] text-gray-500">API: {currentCrude.apiGravity}</div>
            </div>

            {/* 2. 常减压蒸馏 */}
            <div 
              onClick={() => setActiveDevice("常减压联合装置(CDU-04)")}
              className={`p-2 border rounded text-center cursor-pointer transition ${
                activeDevice.startsWith("常减压") ? "bg-[#251518] border-red-800" : "bg-[#11141a] border-[#2d323a]"
              }`}
            >
              <div className="font-bold text-[11px] text-gray-200">常减压分馏</div>
              <div className="text-[10px] text-emerald-400 mt-1">320 ℃ / 0.3 MPa</div>
              <div className="text-[9px] text-gray-500">负荷: {100 + loadDelta}%</div>
            </div>

            {/* 3. 催化裂化/加氢裂化 */}
            <div className="flex flex-col gap-2">
              <div 
                onClick={() => setActiveDevice("加氢裂化裂解反应器(R-101)")}
                className={`p-1.5 border rounded text-center cursor-pointer text-[10px] transition ${
                  activeDevice.startsWith("加氢") ? "bg-[#251518] border-red-800" : "bg-[#11141a] border-[#2d323a]"
                }`}
              >
                <div className="font-bold text-gray-300">加氢裂化</div>
                <div className="text-gray-400">14.5 MPa</div>
              </div>
              <div 
                onClick={() => setActiveDevice("催化裂化分离塔(T-202)")}
                className={`p-1.5 border rounded text-center cursor-pointer text-[10px] transition ${
                  activeDevice.startsWith("催化") ? "bg-[#251518] border-red-800" : "bg-[#11141a] border-[#2d323a]"
                }`}
              >
                <div className="font-bold text-gray-300">催化裂化</div>
                <div className="text-gray-400">1.8 MPa</div>
              </div>
            </div>

            {/* 4. 成品分馏/库 */}
            <div className="bg-[#11141a] border border-[#2d323a] p-2 rounded flex flex-col gap-1 text-[9px]">
              <span className="font-bold text-gray-400 border-b border-[#2d323a] pb-0.5">产品收率</span>
              <span className="flex justify-between">汽油: <strong className="text-emerald-400">{opsResult.gasolineYield} 吨</strong></span>
              <span className="flex justify-between">柴油: <strong className="text-emerald-400">{opsResult.dieselYield} 吨</strong></span>
              <span className="flex justify-between">航煤: <strong className="text-emerald-400">{opsResult.jetFuelYield} 吨</strong></span>
              <span className="flex justify-between">石脑油: <strong className="text-emerald-400">{opsResult.petrochemicalYield} 吨</strong></span>
            </div>
          </div>

          {/* 三维工艺流连线 (矢量表现) */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none z-0 opacity-40">
            <line x1="120" y1="120" x2="160" y2="120" stroke="#ea580c" strokeWidth="2.5" />
            <path d="M 280 120 L 320 85" stroke="#3b82f6" strokeWidth="2" />
            <path d="M 280 120 L 320 155" stroke="#f59e0b" strokeWidth="2" />
            <path d="M 400 85 L 450 120" stroke="#10b981" strokeWidth="2" />
            <path d="M 400 155 L 450 120" stroke="#10b981" strokeWidth="2" />
          </svg>

          {/* 当前选中的装置中控仪表 (DCS Faceplate) */}
          <div className="bg-[#11141a] border border-[#2d323a] rounded p-2.5 flex items-center justify-between text-[10px] mt-1">
            <div className="flex flex-col">
              <span className="text-gray-400 font-bold">激活控制面板:</span>
              <span className="text-white font-bold">{activeDevice}</span>
            </div>
            <div className="flex gap-4">
              <span>温度: <strong className="text-red-400">324.5 ℃</strong></span>
              <span>压力: <strong className="text-blue-400">0.32 MPa</strong></span>
              <span>电耗: <strong className="text-yellow-500">{Math.round(opsResult.energyConsumption * 0.04)} MWh</strong></span>
              <span>碳排: <strong className="text-gray-200">{opsResult.carbonEmissions} 吨CO2/h</strong></span>
            </div>
          </div>
        </div>

        {/* 线性规划优化结果与能耗核算 */}
        <div className="grid grid-cols-2 gap-4 border-t border-[#2d323a] pt-3 text-[10px]">
          <div className="flex flex-col gap-1 text-gray-400">
            <span className="font-bold text-gray-300">在线多组分 LP 求解方程约束</span>
            <span>{"目标函数：Max 炼化毛利 = $Revenue_{sales} - Cost_{crude} - Cost_{energy}$"}</span>
            <span>{"质量收支约束：$CDU_{feed} = \\sum Product_{yield} + Loss$"}</span>
            <span>当前求解状态：<strong className="text-emerald-400">寻优成功 (Optimal)</strong></span>
          </div>

          <div className="bg-[#11141a] border border-[#2d323a] p-2.5 rounded flex justify-between items-center">
            <div className="flex flex-col">
              <span className="text-gray-500">模拟单日销售收入:</span>
              <span className="text-white font-bold text-sm">￥{(opsResult.grossRevenue / 10000).toFixed(2)} 万元</span>
            </div>
            <div className="flex flex-col text-right">
              <span className="text-emerald-400 font-bold">单日加工净利润:</span>
              <span className="text-emerald-400 font-bold text-sm">＋￥{(opsResult.netProfit / 10000).toFixed(2)} 万元</span>
            </div>
          </div>
        </div>

      </div>

      {/* 3. 右侧: 质量与能量平衡审计报告 (Mass-Energy Balance Engine) */}
      <div className="bg-[#16191e] border border-[#2d323a] rounded p-4 flex flex-col gap-3">
        <div className="flex items-center gap-2 border-b border-[#2d323a] pb-2">
          <Zap className="w-4 h-4 text-emerald-500" />
          <span className="font-bold text-gray-200 text-[13px]">物料与能量守恒审计</span>
        </div>

        {/* 物料衡算单 */}
        <div className="bg-[#11141a] border border-[#2d323a] rounded p-2.5 flex flex-col gap-1.5">
          <span className="font-bold text-gray-300 border-b border-[#2d323a] pb-1">每日质量物料平衡清单 (t/d)</span>
          <div className="flex flex-col gap-1 text-gray-400">
            <div className="flex justify-between">
              <span>原油进料总输入:</span>
              <span className="text-white font-bold">{balanceReport.rawInputTons} 吨</span>
            </div>
            <div className="flex justify-between">
              <span>四类主产出之和:</span>
              <span className="text-white">{balanceReport.mainProductsTons} 吨</span>
            </div>
            <div className="flex justify-between">
              <span>石油液化副产出:</span>
              <span className="text-white">{balanceReport.byProductsTons} 吨</span>
            </div>
            <div className="flex justify-between text-yellow-600">
              <span>工艺损耗/结渣 (1.5%):</span>
              <span>-{balanceReport.processLossTons} 吨</span>
            </div>
            <div className="flex justify-between text-blue-400">
              <span>装置暂存罐差值:</span>
              <span>{balanceReport.inventoryDeltaTons} 吨</span>
            </div>
            <div className="flex justify-between border-t border-[#2d323a] pt-1.5 mt-1 text-[11px] font-bold text-emerald-400">
              <span>质量不平衡率 (误差):</span>
              <span>{balanceReport.massImbalanceErrorPercentage}%</span>
            </div>
          </div>
        </div>

        {/* 能量守恒平衡 */}
        <div className="bg-[#11141a] border border-[#2d323a] rounded p-2.5 flex flex-col gap-1.5">
          <span className="font-bold text-gray-300 border-b border-[#2d323a] pb-1">能量平衡清单 (GJ)</span>
          <div className="flex flex-col gap-1 text-gray-400">
            <div className="flex justify-between">
              <span>工艺总热源能量输入:</span>
              <span className="text-white font-bold">{balanceReport.energyInputGj} GJ</span>
            </div>
            <div className="flex justify-between">
              <span>工艺换热与潜热吸收:</span>
              <span className="text-white">{balanceReport.energyOutputGj} GJ</span>
            </div>
            <div className="flex justify-between text-yellow-600">
              <span>烟气与换热损失:</span>
              <span>-{balanceReport.energyLossGj} GJ</span>
            </div>
            <div className="flex justify-between border-t border-[#2d323a] pt-1 mt-1 text-[11px] text-emerald-400 font-bold">
              <span>热焓能量不平衡率:</span>
              <span>{balanceReport.energyImbalanceErrorPercentage}%</span>
            </div>
          </div>
        </div>

        {/* 异常标定告警 */}
        {balanceReport.anomalyDetected ? (
          <div className="bg-red-950/40 border border-red-500 rounded p-2.5 flex gap-2 text-[10px] text-red-400 animate-pulse">
            <ShieldAlert className="w-5 h-5 text-red-500 shrink-0" />
            <div className="flex flex-col gap-0.5">
              <span className="font-bold">发现仪表不平衡异常！</span>
              <span>常压塔顶高压蒸汽流量计存在 {balanceReport.anomalyType}。高负荷下系统存在 1.8% 计量漂移漏洞，建议重新标定。</span>
            </div>
          </div>
        ) : (
          <div className="bg-emerald-950/20 border border-emerald-800 rounded p-2.5 flex gap-2 text-[10px] text-emerald-400">
            <CheckSquare className="w-5 h-5 text-emerald-500 shrink-0" />
            <div className="flex flex-col gap-0.5">
              <span className="font-bold">物理物料平衡审计过检</span>
              <span>当前全厂传感器质量与能量不平衡误差 &lt; 0.5%，未探测到管阀物料渗漏、仪表异常或虚假计量行为。</span>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
