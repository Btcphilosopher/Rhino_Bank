/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { machineryEquipment } from "../data";
import { Activity, ShieldAlert, Cpu, CheckCircle2, Sliders, Play, RotateCcw } from "lucide-react";

export default function EquipmentView() {
  const [selectedEqId, setSelectedEqId] = useState("DEV-CDU-P101");
  const [showOverrideModal, setShowOverrideModal] = useState(false);
  const [overrideTargetValue, setOverrideTargetValue] = useState("");
  const [overrideLog, setOverrideLog] = useState<string[]>([]);

  const activeEq = machineryEquipment.find((e: any) => e.id === selectedEqId) || machineryEquipment[0];

  const handleApplyOverride = () => {
    if (!overrideTargetValue) return;
    const timestamp = new Date().toLocaleTimeString();
    setOverrideLog(prev => [
      `[${timestamp}] 警告：DCS 安全连锁机制已绕过，IT端重置目标振动阈值为 ${overrideTargetValue} mm/s (需要中控二级鉴权与MFA)`,
      ...prev
    ]);
    setShowOverrideModal(false);
    setOverrideTargetValue("");
  };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 font-mono text-xs select-none text-gray-300">
      
      {/* 1. 左侧: 转动设备及特种设备资产列表 */}
      <div className="bg-[#16191e] border border-[#2d323a] rounded p-4 flex flex-col gap-4">
        <div className="flex items-center gap-2 border-b border-[#2d323a] pb-2">
          <Activity className="w-4 h-4 text-red-500 animate-pulse" />
          <span className="font-bold text-gray-200 text-[13px]">核心旋转机械资产监控</span>
        </div>

        <div className="flex flex-col gap-1.5 overflow-y-auto max-h-[160px] pr-1">
          {machineryEquipment.map((eq: any) => (
            <div
              key={eq.id}
              onClick={() => setSelectedEqId(eq.id)}
              className={`p-2.5 rounded border transition cursor-pointer flex flex-col gap-1 ${
                selectedEqId === eq.id
                  ? "bg-[#251518] border-red-800 text-white"
                  : "bg-[#11141a] border-[#2d323a] hover:bg-[#1a1e24]"
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold">{eq.name}</span>
                <span className={`text-[9px] font-bold px-1 rounded ${
                  eq.healthIndexXgboost > 90 ? "bg-emerald-950 text-emerald-400" :
                  eq.healthIndexXgboost > 80 ? "bg-yellow-950 text-yellow-500" : "bg-red-950 text-red-400 animate-pulse"
                }`}>
                  健康度: {eq.healthIndexXgboost}%
                </span>
              </div>
              <div className="text-[10px] text-gray-400 flex justify-between">
                <span>位置: {eq.location}</span>
                <span>运行: {eq.runningHours}h</span>
              </div>
            </div>
          ))}
        </div>

        {/* XGBoost 模型审计指标 (透明可追溯性) */}
        <div className="bg-[#11141a] border border-[#2d323a] rounded p-3 flex flex-col gap-2">
          <div className="flex items-center gap-1 border-b border-[#2d323a] pb-1 font-bold text-gray-400">
            <Cpu className="w-3.5 h-3.5 text-blue-500" />
            <span>XGBoost 预测维护诊断模型审计</span>
          </div>
          <div className="grid grid-cols-2 gap-y-1.5 text-gray-500 text-[11px]">
            <span>模型架构: <strong className="text-white">XGBoost Classifier v1.2</strong></span>
            <span>特征集规模: <strong className="text-white">52测点时序高频震动</strong></span>
            <span>模型版本: <strong className="text-white">VER-EQ-202609A</strong></span>
            <span>剩余可用寿命(RUL): <strong className="text-emerald-400">{activeEq.remainingUsefulLifeDays} 天</strong></span>
          </div>
        </div>
      </div>

      {/* 2. 中间: 设备振动频谱数字孪生 (FFT Spectrum View) */}
      <div className="bg-[#16191e] border border-[#2d323a] rounded p-4 flex flex-col gap-4">
        <div className="flex items-center justify-between border-b border-[#2d323a] pb-2">
          <span className="font-bold text-gray-200 text-[13px]">轴承高频径向振动波形频谱 (FFT)</span>
          <span className="text-[10px] text-gray-500">测点 ID: VE-Bearing-A01</span>
        </div>

        {/* 震动频谱线模拟 (SVG) */}
        <div className="h-[180px] bg-[#0c0e12] border border-[#2d323a] rounded relative p-2 flex flex-col justify-end">
          <div className="absolute top-2 left-2 text-[8px] text-gray-600 flex flex-col gap-8">
            <span>20.0 mm/s (报警极限)</span>
            <span>10.0 mm/s (警告限)</span>
            <span>0.0 mm/s</span>
          </div>

          <svg className="w-full h-full absolute inset-0 z-0 px-8 py-4 pointer-events-none">
            {/* 警告线与极限线 */}
            <line x1="0" y1="45" x2="400" y2="45" stroke="#ef4444" strokeWidth="1" strokeDasharray="3,3" />
            <line x1="0" y1="90" x2="400" y2="90" stroke="#f59e0b" strokeWidth="1" strokeDasharray="3,3" />

            {/* 根据设备异常状况动态绘制 FFT 频谱波形 ( misalignment or bearing defect ) */}
            <path
              d={`M 40 140 
                  Q 80 ${activeEq.diagnoseFaultType !== "健康标称" ? "50" : "120"} 120 140 
                  T 200 ${activeEq.diagnoseFaultType !== "健康标称" ? "30" : "110"} 
                  T 280 140 
                  T 360 140`}
              fill="none"
              stroke={activeEq.vibrationSeverity === "异常" ? "#ef4444" : activeEq.vibrationSeverity === "注意" ? "#f59e0b" : "#22c55e"}
              strokeWidth="2"
            />

            {/* 标签 */}
            {activeEq.vibrationSeverity !== "良好" && (
              <g>
                <circle cx="120" cy="50" r="4" fill="#ef4444" className="animate-ping" />
                <text x="130" y="55" fill="#ef4444" fontSize="9" className="font-bold">高频异常振动谐波峰值</text>
              </g>
            )}
          </svg>

          <div className="flex gap-4 items-center justify-center text-[9px] text-gray-500 z-10 select-none pb-1">
            <span>水平径向轴承振动值: <strong className="text-white">{activeEq.vibrationMmPerSecond} mm/s</strong></span>
            <span>额定最大转速: <strong className="text-white">2980 rpm</strong></span>
          </div>
        </div>

        {/* 异常诊断描述 */}
        <div className="bg-[#11141a] border border-[#2d323a] p-3 rounded flex justify-between items-center text-[11px]">
          <div>
            <span className="text-gray-500">诊断专家结论:</span>
            <div className={`font-bold mt-0.5 ${
              activeEq.vibrationSeverity === "异常" ? "text-red-500" : activeEq.vibrationSeverity === "注意" ? "text-yellow-500" : "text-emerald-400"
            }`}>
              {activeEq.diagnoseFaultType}
            </div>
          </div>
          <button
            onClick={() => setShowOverrideModal(true)}
            className="bg-red-950 border border-red-600 hover:bg-red-900 text-red-400 px-3 py-1.5 rounded transition font-bold text-[10px]"
          >
            强制干预控制阈值
          </button>
        </div>
      </div>

      {/* 3. 右侧: 安全连锁状态与干预日志 (IT/OT Isolation & Security Overrides Audit) */}
      <div className="bg-[#16191e] border border-[#2d323a] rounded p-4 flex flex-col gap-3">
        <div className="flex items-center gap-2 border-b border-[#2d323a] pb-2">
          <ShieldAlert className="w-4 h-4 text-red-500" />
          <span className="font-bold text-gray-200 text-[13px]">IT/OT 物理隔离与连锁审计</span>
        </div>

        <div className="bg-[#11141a] border border-[#2d323a] p-3 rounded flex flex-col gap-1.5 text-[11px] leading-relaxed">
          <span className="font-bold text-red-400 flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
            连锁旁路(SIS)IT/OT隔离规程：
          </span>
          <span className="text-gray-400">
            SEIOS 操作系统处于生产分析层 (IT)。当前系统没有直接写权限向现场分布式 PLC/DCS 写入转速和电磁阀阀位命令。
          </span>
          <span className="text-yellow-500 font-bold border-t border-[#1d232d] pt-1.5 mt-1">
            IT端发出指令必须经多因子鉴权(MFA)，并由中控室操作员确认后才物理注入 OT 控制系统！
          </span>
        </div>

        {/* 连锁审计干预日志 */}
        <div className="flex-1 bg-[#11141a] border border-[#2d323a] rounded p-2.5 flex flex-col gap-1.5 overflow-hidden min-h-[120px]">
          <span className="font-bold text-gray-400 border-b border-[#2d323a] pb-1">SIS 安全干预审计流水日志</span>
          <div className="flex-1 overflow-y-auto pr-1 flex flex-col gap-1.5 text-[9px] text-gray-500">
            {overrideLog.length === 0 ? (
              <div className="h-full flex items-center justify-center italic">无主动旁路干预记录 (连锁系统稳健运行)</div>
            ) : (
              overrideLog.map((log, i) => (
                <div key={i} className="text-yellow-500/95 leading-normal bg-[#201518] p-1.5 rounded border border-yellow-900">
                  {log}
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* 4. IT/OT 干预二级审批及MFA确认 Modal */}
      {showOverrideModal && (
        <div className="fixed inset-0 bg-black/75 flex items-center justify-center z-50 p-4">
          <div className="bg-[#16191e] border-2 border-red-800 rounded-md max-w-sm w-full p-5 flex flex-col gap-4 font-mono">
            <div className="flex items-center gap-2 text-red-500 font-bold border-b border-[#2d323a] pb-2 text-[13px]">
              <ShieldAlert className="w-5 h-5 animate-bounce" />
              <span>DCS安全旁路紧急解锁授权</span>
            </div>
            
            <p className="text-[11px] text-gray-400 leading-relaxed">
              警告：您正在申请临时修改 <strong className="text-white">{activeEq.name}</strong> 轴承温度及振动停机硬连锁限值。
              此项操作会绕过安全仪表系统(SIS)硬保护，必须经中控二级鉴权、双员在岗确认，并物理拨动现场端拨码开关。
            </p>

            <div className="flex flex-col gap-1.5 text-[11px]">
              <span className="text-gray-400 font-bold">设定目标振动停机阈值 (mm/s):</span>
              <input
                type="number"
                placeholder="例如: 22.5"
                value={overrideTargetValue}
                onChange={(e) => setOverrideTargetValue(e.target.value)}
                className="bg-[#11141a] border border-[#2d323a] p-2 rounded text-white focus:outline-none focus:border-red-600 font-bold text-center"
              />
            </div>

            <div className="grid grid-cols-2 gap-3 mt-2 text-[10px] font-bold">
              <button
                onClick={() => setShowOverrideModal(false)}
                className="bg-[#2d323a] hover:bg-[#3d424c] py-2 rounded text-gray-300 transition text-center"
              >
                取消操作
              </button>
              <button
                onClick={handleApplyOverride}
                className="bg-red-800 hover:bg-red-700 py-2 rounded text-white transition text-center"
              >
                确认IT授权
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
