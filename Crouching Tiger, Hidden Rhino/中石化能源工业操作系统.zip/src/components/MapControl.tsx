/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { countriesAsset, energyVessels, retailStations, coreOilFields, pipelineTwins } from "../data";
import { GlobalCountryAsset, EnergyVessel } from "../types";
import { Map, Layers, Radio, Shield, Globe, Compass, Activity, Navigation, Droplet, Fuel } from "lucide-react";

interface MapControlProps {
  onSelectCountry: (country: GlobalCountryAsset) => void;
  selectedCountryId?: string;
}

export default function MapControl({ onSelectCountry, selectedCountryId }: MapControlProps) {
  // 地图底图模式: "topo" | "satellite" | "schematic"
  const [mapMode, setMapMode] = useState<"topo" | "satellite" | "schematic">("topo");
  
  // 激活图层
  const [layers, setLayers] = useState({
    oilfields: true,
    refineries: true,
    pipelines: true,
    vessels: true,
    retail: false,
    environment: false
  });

  // 当前鼠标悬停坐标
  const [hoverCoord, setHoverCoord] = useState<string>("39.9042° N, 116.4074° E (北京中枢)");

  const toggleLayer = (layer: keyof typeof layers) => {
    setLayers(prev => ({ ...prev, [layer]: !prev[layer] }));
  };

  return (
    <div className="relative w-full h-[540px] bg-[#16191e] border border-[#2d323a] rounded overflow-hidden font-mono text-xs select-none">
      {/* 1. 顶部控制栏 */}
      <div className="absolute top-0 left-0 right-0 h-10 bg-[#1a1e24] border-b border-[#2d323a] px-4 flex items-center justify-between z-10">
        <div className="flex items-center gap-2">
          <Globe className="w-4 h-4 text-red-500 animate-pulse" />
          <span className="font-bold text-gray-200 uppercase tracking-wider text-[11px]">中国石化全球能源与物资调运数字网</span>
        </div>
        
        {/* 底图切换 */}
        <div className="flex bg-[#121417] p-0.5 rounded border border-[#2d323a] gap-1">
          <button
            onClick={() => setMapMode("topo")}
            className={`px-3 py-1 rounded-[2px] transition ${mapMode === "topo" ? "bg-[#20252e] text-white font-bold" : "text-gray-400 hover:text-gray-200"}`}
          >
            地形
          </button>
          <button
            onClick={() => setMapMode("satellite")}
            className={`px-3 py-1 rounded-[2px] transition ${mapMode === "satellite" ? "bg-[#20252e] text-white font-bold" : "text-gray-400 hover:text-gray-200"}`}
          >
            卫星
          </button>
          <button
            onClick={() => setMapMode("schematic")}
            className={`px-3 py-1 rounded-[2px] transition ${mapMode === "schematic" ? "bg-[#20252e] text-white font-bold" : "text-gray-400 hover:text-gray-200"}`}
          >
            拓扑
          </button>
        </div>
      </div>

      {/* 2. 侧边图层控制器 */}
      <div className="absolute top-14 left-4 w-44 bg-[#121417] border border-[#2d323a] p-3 rounded-md z-10 flex flex-col gap-2.5">
        <span className="text-gray-400 font-bold border-b border-[#2d323a] pb-1 flex items-center gap-1">
          <Layers className="w-3.5 h-3.5 text-blue-400" />
          控制图层
        </span>
        
        <label className="flex items-center gap-2 cursor-pointer text-gray-300 hover:text-white">
          <input
            type="checkbox"
            checked={layers.oilfields}
            onChange={() => toggleLayer("oilfields")}
            className="rounded text-red-600 bg-[#20252e] border-[#2d323a] focus:ring-0"
          />
          <Droplet className="w-3.5 h-3.5 text-blue-500" />
          <span>油田/气田</span>
        </label>

        <label className="flex items-center gap-2 cursor-pointer text-gray-300 hover:text-white">
          <input
            type="checkbox"
            checked={layers.refineries}
            onChange={() => toggleLayer("refineries")}
            className="rounded text-red-600 bg-[#20252e] border-[#2d323a] focus:ring-0"
          />
          <Activity className="w-3.5 h-3.5 text-red-500" />
          <span>炼厂/石化</span>
        </label>

        <label className="flex items-center gap-2 cursor-pointer text-gray-300 hover:text-white">
          <input
            type="checkbox"
            checked={layers.pipelines}
            onChange={() => toggleLayer("pipelines")}
            className="rounded text-red-600 bg-[#20252e] border-[#2d323a] focus:ring-0"
          />
          <Radio className="w-3.5 h-3.5 text-orange-500" />
          <span>输油管网</span>
        </label>

        <label className="flex items-center gap-2 cursor-pointer text-gray-300 hover:text-white">
          <input
            type="checkbox"
            checked={layers.vessels}
            onChange={() => toggleLayer("vessels")}
            className="rounded text-red-600 bg-[#20252e] border-[#2d323a] focus:ring-0"
          />
          <Navigation className="w-3.5 h-3.5 text-cyan-400" />
          <span>海运油轮</span>
        </label>

        <label className="flex items-center gap-2 cursor-pointer text-gray-300 hover:text-white">
          <input
            type="checkbox"
            checked={layers.retail}
            onChange={() => toggleLayer("retail")}
            className="rounded text-red-600 bg-[#20252e] border-[#2d323a] focus:ring-0"
          />
          <Fuel className="w-3.5 h-3.5 text-green-400" />
          <span>零售加能站</span>
        </label>

        <label className="flex items-center gap-2 cursor-pointer text-gray-300 hover:text-white border-t border-[#2d323a] pt-1.5">
          <input
            type="checkbox"
            checked={layers.environment}
            onChange={() => toggleLayer("environment")}
            className="rounded text-red-600 bg-[#20252e] border-[#2d323a] focus:ring-0"
          />
          <Shield className="w-3.5 h-3.5 text-teal-400" />
          <span>环保/VOC排放</span>
        </label>
      </div>

      {/* 3. 仿制的高清地图视图网格 */}
      <div 
        className={`w-full h-full relative transition-all duration-300 ${
          mapMode === "satellite" 
            ? "bg-[#0b0f14] [background-image:radial-gradient(#1f2e40_1px,transparent_1px)] [background-size:24px_24px]" 
            : mapMode === "topo" 
            ? "bg-[#11141a] [background-image:linear-gradient(rgba(45,50,58,0.2)_1px,transparent_1px),linear-gradient(90deg,rgba(45,50,58,0.2)_1px,transparent_1px)] [background-size:40px_40px]"
            : "bg-[#0c0d10]"
        }`}
        onMouseMove={(e) => {
          const parentRect = e.currentTarget.getBoundingClientRect();
          const x = e.clientX - parentRect.left;
          const y = e.clientY - parentRect.top;
          // 拟合经纬度
          const lat = (90 - (y / parentRect.height) * 180).toFixed(4);
          const lng = ((x / parentRect.width) * 360 - 180).toFixed(4);
          setHoverCoord(`${lat}° ${Number(lat) >= 0 ? "N" : "S"}, ${lng}° ${Number(lng) >= 0 ? "E" : "W"}`);
        }}
      >
        {/* 地图上的连接管线虚线 (矢量表示) */}
        {layers.pipelines && (
          <svg className="absolute inset-0 w-full h-full pointer-events-none z-0">
            {/* 胜利油田 -> 炼油厂 */}
            <path d="M 680 180 Q 640 220 590 200" fill="none" stroke="#ea580c" strokeWidth="2" strokeDasharray="4,4" className="animate-[dash_20s_linear_infinite]" />
            {/* 顺北油田 -> 管道 */}
            <path d="M 520 160 Q 560 170 590 200" fill="none" stroke="#22c55e" strokeWidth="2" strokeDasharray="4,4" />
            {/* 川气东送管线 (普光 -> 上海) */}
            <path d="M 560 210 Q 620 220 660 230" fill="none" stroke="#06b6d4" strokeWidth="2.5" />
            {/* 海运航线 (波斯湾 -> 舟山) */}
            {layers.vessels && (
              <path d="M 320 320 Q 420 400 680 250" fill="none" stroke="#38bdf8" strokeWidth="1" strokeDasharray="2,5" />
            )}
          </svg>
        )}

        {/* 4. 地图锚点渲染 */}
        {countriesAsset.map((country) => {
          // 屏幕坐标映射计算 (简易球形展宽投影)
          let x = 500;
          let y = 250;
          if (country.id === "CN") { x = 650; y = 180; }
          else if (country.id === "SA") { x = 340; y = 250; }
          else if (country.id === "KW") { x = 360; y = 240; }
          else if (country.id === "AO") { x = 240; y = 380; }
          else if (country.id === "RU") { x = 600; y = 90; }
          else if (country.id === "BR") { x = 180; y = 400; }
          else if (country.id === "KZ") { x = 480; y = 150; }
          else if (country.id === "AE") { x = 370; y = 260; }
          else if (country.id === "VE") { x = 120; y = 320; }
          else if (country.id === "GB") { x = 200; y = 120; }

          const isSelected = selectedCountryId === country.id;

          return (
            <div 
              key={country.id} 
              style={{ left: `${x}px`, top: `${y}px` }}
              className="absolute -translate-x-1/2 -translate-y-1/2 group cursor-pointer z-10"
              onClick={() => onSelectCountry(country)}
            >
              {/* 波动锚圈 */}
              <div className={`w-6 h-6 rounded-full absolute -left-3 -top-3 border flex items-center justify-center transition-all ${
                isSelected 
                  ? "border-red-500 bg-red-950/30 scale-125" 
                  : "border-[#4a5568] group-hover:border-blue-400 group-hover:scale-110"
              }`}>
                <div className={`w-1.5 h-1.5 rounded-full ${isSelected ? "bg-red-500 animate-ping" : "bg-gray-400"}`} />
              </div>

              {/* 信息弹签 */}
              <div className="absolute left-4 -top-3 bg-[#11141a]/95 border border-[#2d323a] rounded py-1 px-2 pointer-events-none opacity-80 group-hover:opacity-100 transition whitespace-nowrap min-w-[100px]">
                <div className="flex items-center justify-between gap-2 border-b border-[#2d323a] pb-0.5 mb-1 font-bold">
                  <span className={`${isSelected ? "text-red-400" : "text-white"}`}>{country.name}</span>
                  <span className="text-[9px] text-gray-500 uppercase">{country.id}</span>
                </div>
                <div className="text-[9px] text-gray-400 flex flex-col gap-0.5">
                  <span className="flex items-center justify-between gap-3">
                    油田: <span className="text-blue-400 font-bold">{country.oilFieldsCount}</span>
                  </span>
                  <span className="flex items-center justify-between gap-3">
                    炼厂: <span className="text-red-400 font-bold">{country.refineriesCount}</span>
                  </span>
                  <span className="flex items-center justify-between gap-3">
                    产能: <span className="text-gray-200 font-bold">{country.refiningCapacity} 万吨/年</span>
                  </span>
                </div>
              </div>
            </div>
          );
        })}

        {/* 5. 渲染油轮实时位置 (Vessels) */}
        {layers.vessels && energyVessels.map((v) => {
          // 根据 IMO 映射经纬度到屏幕
          let x = 450; let y = 300;
          if (v.id === "VESSEL-01") { x = 460; y = 340; }
          else if (v.id === "VESSEL-02") { x = 580; y = 290; }
          else if (v.id === "VESSEL-03") { x = 670; y = 220; }

          return (
            <div 
              key={v.id} 
              style={{ left: `${x}px`, top: `${y}px` }}
              className="absolute -translate-x-1/2 -translate-y-1/2 group cursor-pointer z-10"
            >
              <Navigation className="w-3.5 h-3.5 text-cyan-400 hover:text-white drop-shadow-md animate-pulse transform rotate-45" />
              
              <div className="absolute left-4 -top-1 bg-[#0c0d10] border border-[#22d3ee] rounded py-0.5 px-1.5 opacity-0 group-hover:opacity-100 pointer-events-none transition whitespace-nowrap">
                <div className="font-bold text-cyan-400 text-[10px]">{v.name}</div>
                <div className="text-[8px] text-gray-300 flex flex-col">
                  <span>航速: {v.speedKnots} 节 | IMO: {v.imoNumber}</span>
                  <span>货物: {v.cargoType} ({v.currentLoadPercentage}%)</span>
                  <span>目的港: {v.destinationPort}</span>
                </div>
              </div>
            </div>
          );
        })}

        {/* 6. 零售加能站 (Retail Points) - 只在大比例或勾选时显示 */}
        {layers.retail && retailStations.map((st) => {
          let x = 650; let y = 180;
          if (st.id === "STATION-SH-02") { x = 680; y = 220; }
          return (
            <div 
              key={st.id} 
              style={{ left: `${x}px`, top: `${y}px` }}
              className="absolute -translate-x-1/2 -translate-y-1/2 group z-10"
            >
              <div className="w-2 h-2 rounded-full bg-green-500 border border-white animate-bounce" />
              <div className="absolute left-3 -top-1 bg-[#121417]/95 border border-green-500 rounded p-1 whitespace-nowrap opacity-0 group-hover:opacity-100 transition z-20">
                <span className="font-bold text-green-400">{st.name}</span>
                <div className="text-[8px] text-gray-400">
                  日销汽油: {st.dailyGasolineSalesLiter} 升 | 充电口: {st.evChargingSlots.occupied}/{st.evChargingSlots.total}
                </div>
              </div>
            </div>
          );
        })}

        {/* 地形底图经纬网和比例尺组件 */}
        <div className="absolute bottom-2 left-4 text-[#4a5568] flex flex-col gap-0.5 pointer-events-none font-mono">
          <span>地图比例尺: 1 : 25,000,000</span>
          <span>投影: Web-Mercator WebGL 2D Plane</span>
          <span>测点数量: SCADA synthetic_point [10,000]</span>
        </div>
      </div>

      {/* 5. 底部 HUD 数据面板 */}
      <div className="absolute bottom-0 left-0 right-0 h-8 bg-[#11141a]/95 border-t border-[#2d323a] px-4 flex items-center justify-between text-gray-400 font-bold z-10 text-[10px]">
        <div className="flex items-center gap-2">
          <Compass className="w-3.5 h-3.5 text-red-500 animate-spin" />
          <span>坐标轴: <span className="text-gray-200">{hoverCoord}</span></span>
        </div>
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-500" />
            油田群 [30]
          </span>
          <span className="flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-red-500" />
            炼化企业 [20]
          </span>
          <span className="flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-orange-500" />
            管道网 [500]
          </span>
          <span className="flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
            油轮队 [45]
          </span>
          <span className="flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
            综合加能站 [5,000]
          </span>
        </div>
      </div>
    </div>
  );
}
