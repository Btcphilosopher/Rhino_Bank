/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// 数据单位系统
export enum EnergyUnit {
  BARREL = "桶",
  TON = "吨",
  KILO_TON = "千吨",
  TEN_KILO_TON = "万吨",
  MILLION_TON = "百万吨",
  CUBIC_METER = "立方米",
  STANDARD_CUBIC_METER = "标方",
  MILLION_CUBIC_METER = "百万标方",
  BILLION_CUBIC_METER = "亿标方",
  MMBTU = "MMBtu",
  MJ = "兆焦",
  GJ = "吉焦",
  KWH = "度(kWh)",
  MWH = "兆瓦时(MWh)",
  GWH = "吉瓦时(GWh)",
  RMB = "元(RMB)",
  USD = "美元(USD)",
  EUR = "欧元(EUR)"
}

// 质量等级等级
export enum DataQuality {
  EXCELLENT = "A (高精度/校验过)",
  GOOD = "B (正常/SCADA)",
  FAIR = "C (估算/部分缺失)",
  POOR = "D (不可靠/降级)"
}

// 基础物理与数据元实体
export interface DataLineage {
  id: string;
  metricName: string;
  value: string | number;
  unit: EnergyUnit;
  source: "DCS" | "SCADA" | "PLC" | "ERP" | "LIMS" | "MES" | "CCUS_SENSOR" | "METEOROLOGY";
  equipmentId: string;
  equipmentName: string;
  timestamp: string;
  calculationFormula?: string;
  modelType?: string;
  parametersApplied?: string;
  dataVersion: string;
  quality: DataQuality;
}

// 国家资产
export interface GlobalCountryAsset {
  id: string;
  name: string;
  oilFieldsCount: number;
  refineriesCount: number;
  pipelinesCount: number;
  stationsCount: number;
  totalOilProduction: number; // 万吨/年
  totalGasProduction: number; // 亿立方米/年
  refiningCapacity: number; // 万吨/年
  lngImports: number; // 万吨/年
  coordinate: [number, number]; // [lat, lng]
}

// 1. 集团总览指标
export interface GroupOverviewMetrics {
  globalOilGasYield: number; // 万吨油当量/日
  crudeYield: number; // 万桶/日
  naturalGasYield: number; // 百万标方/日
  refineryProcessingVolume: number; // 万吨/日
  chemicalYield: number; // 万吨/日
  refinedOilSales: number; // 万吨/日
  crudeInventory: number; // 万吨
  refinedOilInventory: number; // 万吨
  naturalGasInventory: number; // 百万标方
  refineryOperatingRate: number; // %
  assetUtilizationRate: number; // %
  energyConsumption: number; // 万吨标准煤当量/日
  carbonEmissions: number; // 万吨二氧化碳当量/日
  deviceAvailability: number; // %
  safetyIncidents: number; // 起/年
}

// 2. 勘探模块
export interface ExplorationBlock {
  id: string;
  name: string;
  country: string;
  basin: string;
  areaSqKm: number;
  geologicalAge: string;
  provenReserves: number; // 亿吨
  prospectiveReserves: number; // 亿吨
  wellsCount: number;
  productionWellsCount: number;
  evaluationWellsCount: number;
  explorationWellsCount: number;
  developmentStatus: "勘探中" | "评价中" | "已发现" | "开发中" | "稳定生产";
  economicValueBillionUSD: number;
}

// 3. 井管理
export interface OilWell {
  id: string;
  name: string;
  wellType: "直井" | "定向井" | "水平井" | "海上井" | "页岩油井" | "页岩气井" | "煤层气井" | "注水井" | "注气井";
  location: string;
  blockId: string;
  drillingDate: string;
  completionDate: string;
  depthMeters: number;
  horizontalLengthMeters: number;
  casingDiameterMm: number;
  tubingDiameterMm: number;
  productionLayer: string;
  status: "生产中" | "停产关井" | "修井中" | "压裂中" | "注水/注气中";
  dailyOilProductionTon: number;
  dailyGasProductionKcm: number;
  dailyWaterProductionTon: number;
  pressureMpa: number;
  temperatureCelsius: number;
  waterCutPercentage: number;
}

// 4. 钻井工程实时监测
export interface DrillingRealtimeMetrics {
  wellId: string;
  wellName: string;
  currentDepth: number; // 米
  drillingSpeed: number; // 米/小时
  weightOnBitKn: number; // 钻压
  torqueKnm: number; // 扭矩
  mudDensityGcm3: number; // 泥浆密度
  mudFlowRateLps: number; // 泥浆流量
  wellheadPressureMpa: number; // 井口压力
  standpipePressureMpa: number; // 立管压力
  temperatureCelsius: number;
  inclinationDegree: number; // 井斜角
  azimuthDegree: number; // 方位角
  rateOfPenetration: number; // 机械钻速 (ROP)
}

// 5. 油藏模拟与预测
export interface ReservoirSimulationData {
  reservesMillionTon: number;
  pressureMpa: number;
  permeabilityMd: number; // 渗透率 (millidarcy)
  porosityPercentage: number; // 孔隙度
  waterSaturationPercentage: number;
  recoveryFactorPercentage: number; // 采收率
  wellPattern: string; // "五点法" | "七点法" | "九点法"
  waterInjectionRateM3Day: number;
  gasInjectionRateM3Day: number;
  declineModel: "Exponential" | "Hyperbolic" | "Harmonic";
  initialDeclineRate: number; // 初始递减率 /年
  hyperbolicExponent?: number; // 双曲递减指数
  calculatedEURMillionTon: number;
  remainingRecoverableReservesMillionTon: number;
}

// 6. 非常规与海上平台
export interface HydraulicFracturingMetrics {
  wellId: string;
  wellName: string;
  stagesCount: number;
  clustersPerStage: number;
  sandVolumeTons: number;
  fluidVolumeM3: number;
  maxPressureMpa: number;
  averageFlowRateM3Min: number;
  microseismicEventCount: number;
  estimatedEURKcm: number;
}

export interface OffshoreAsset {
  id: string;
  name: string;
  type: "海上钻井平台" | "固定采油平台" | "FPSO(海上浮式生产储卸油装置)" | "海底管线";
  waveHeightMeters: number;
  windSpeedMps: number;
  temperatureCelsius: number;
  status: "正常运行" | "恶劣天气减负" | "设备维护" | "应急撤离";
  dailyProductionEquivalentTon: number;
  pipelinePressureMpa: number;
}

// 7. 天然气与管道
export interface GasChainNode {
  id: string;
  name: string;
  type: "气田" | "集气站" | "处理厂" | "管道" | "储气库" | "LNG接收站" | "城市门站" | "工业大用户";
  capacity: number; // 万标方/日
  currentFlow: number; // 万标方/日
  pressureMpa: number;
  temperatureCelsius: number;
  calorificValueMj: number; // 热值
  inventoryVolumeKcm?: number;
}

export interface PipelineTwin {
  id: string;
  name: string;
  startPoint: string;
  endPoint: string;
  lengthKm: number;
  diameterMm: number;
  pressureMpa: number;
  material: string;
  medium: "原油" | "天然气" | "成品油" | "化工原料";
  designCapacityMillionTonsPerYear: number;
  currentFlowTonsPerHour: number;
  temperatureCelsius: number;
  corrosionStatus: "良好" | "轻度腐蚀" | "中度腐蚀" | "需立即维护";
}

// 8. 炼厂数字孪生实体
export interface RefineryDevice {
  id: string;
  name: string;
  type: "常减压" | "催化裂化" | "加氢裂化" | "重整" | "芳烃" | "乙烯联合" | "聚合物";
  capacityTonPerDay: number;
  currentLoadPercentage: number;
  temperatureCelsius: number;
  pressureMpa: number;
  flowRateTonPerHour: number;
  energyConsumptionGjPerTon: number;
  efficiencyPercentage: number;
  status: "运行中" | "超负荷" | "计划停机" | "故障故障报警" | "检修中";
  alertMessage?: string;
  maintenanceWindowDays: number;
}

export interface RefineryProductionMetrics {
  crudeFeedrateTonPerDay: number;
  operatingRatePercentage: number;
  gasolineYieldTonPerDay: number;
  dieselYieldTonPerDay: number;
  jetFuelYieldTonPerDay: number;
  naphthaYieldTonPerDay: number;
  asphaltYieldTonPerDay: number;
  lpgYieldTonPerDay: number;
  sulfurYieldTonPerDay: number;
  chemicalFeedstockYieldTonPerDay: number;
}

// 9. 原油与国际贸易
export interface CrudeCargo {
  id: string;
  name: string; // 例如: "沙特轻质" | "大庆原油" | "阿曼原油"
  apiGravity: number;
  sulfurPercentage: number;
  densityGcm3: number;
  pricePerBarrelUSD: number;
  freightCostUSD: number;
  deliveryPort: string;
  inventoryKiloTons: number;
  contractId: string;
  vesselEta: string;
}

// 10. 全球仓储与库存
export interface EnergyStorageTank {
  id: string;
  name: string;
  tankType: "原油储罐" | "成品油罐" | "LNG低温罐" | "化工压力罐" | "地下储气库" | "战略储备库";
  capacityKcm: number;
  currentVolumeKcm: number;
  utilizationRatePercentage: number;
  feedInRateM3Hour: number;
  dischargeRateM3Hour: number;
  estimatedDepletionDays: number;
}

// 11. 油轮和物流
export interface EnergyVessel {
  id: string;
  name: string;
  imoNumber: string;
  cargoType: "原油" | "LNG" | "化学品" | "成品油";
  deadweightTons: number;
  lat: number;
  lng: number;
  speedKnots: number;
  destinationPort: string;
  eta: string;
  currentLoadPercentage: number;
}

// 12. 零售能源站与单站数字孪生
export interface RetailFuelStation {
  id: string;
  name: string;
  coordinate: [number, number];
  dailyGasolineSalesLiter: number;
  dailyDieselSalesLiter: number;
  passengerFlow: number;
  priceGasoline92: number;
  priceGasoline95: number;
  priceDiesel0: number;
  tanksStatus: {
    tankId: string;
    product: string;
    capacityLiter: number;
    currentLiter: number;
  }[];
  dispensersCount: number;
  nozzlesStatus: {
    nozzleId: string;
    dispenserId: string;
    product: string;
    status: "空闲" | "加油中" | "故障维修";
  }[];
  convenienceStoreSalesRMB: number;
  evChargingSlots: {
    total: number;
    occupied: number;
    powerKw: number;
  };
  hydrogenStation: {
    available: boolean;
    hydrogenStorageKg?: number;
    dailyRefuelKg?: number;
  };
  carWashService: boolean;
}

// 13. 化工与物料平衡
export interface ChemicalProductNetwork {
  feedstockInflowTonPerDay: number;
  ethyleneYield: number;
  propyleneYield: number;
  butadieneYield: number;
  aromaticsYield: number;
  polyethyleneYield: number;
  polypropyleneYield: number;
  syntheticRubberYield: number;
  chemicalFiberYield: number;
  fineChemicalsYield: number;
}

export interface MassEnergyBalanceReport {
  entityId: string;
  entityName: string;
  rawInputTons: number;
  byProductsTons: number;
  mainProductsTons: number;
  processLossTons: number;
  inventoryDeltaTons: number;
  massImbalanceErrorPercentage: number;
  energyInputGj: number;
  energyOutputGj: number;
  energyLossGj: number;
  energyImbalanceErrorPercentage: number;
  anomalyDetected: boolean;
  anomalyType?: "物料平衡异常" | "仪表标定失效" | "数据采集漏损" | "计量系统故障";
}

// 14. 工业碳管理
export interface CarbonEmissionTwin {
  entityId: string;
  entityName: string;
  co2EmissionsTon: number;
  ch4EmissionsTon: number;
  n2oEmissionsTon: number;
  totalCo2EquivalentTon: number;
  scope1Ton: number; // 直接排放
  scope2Ton: number; // 间接电力/蒸汽排放
  scope3Ton: number; // 供应链上下游排放
  emissionFactorsUsed: string; // "IPCC 2006" | "国家温室气体清单指南"
  timeframe: string;
}

// CCUS (二氧化碳捕集、利用与封存) 产业链
export interface CCUSTwin {
  id: string;
  captureSite: string;
  captureTonsPerDay: number;
  capturePurityPercentage: number;
  compressionPressureMpa: number;
  transportMethod: "管道" | "槽车";
  injectionWellId: string;
  dailyInjectionTons: number;
  undergroundStorageVolumeTons: number;
  seismicMonitoringAlert: "安全" | "微震预警" | "地质缝隙警告";
}

// 15. 设备管理与预测性维护
export interface IndustrialDeviceAsset {
  id: string;
  name: string;
  type: "离心泵" | "往复式压缩机" | "高压阀门" | "板式换热器" | "加氢反应器" | "常压蒸馏塔" | "大型储罐" | "燃气发电机" | "主变压器";
  refineryOrFieldId: string;
  operatingHours: number;
  maintenanceCount: number;
  failureCount: number;
  costRMB: number;
  reliabilityPercentage: number;
  currentVibrationMmS: number; // 振动速度
  currentTemperatureCelsius: number;
  currentPressureMpa: number;
  currentElectricCurrentAmpere: number;
  healthScore: number; // 100分制
  anomalyProbabilityPercentage: number;
  predictedFailureMode: string; // "无" | "轴承磨损" | "密封失效" | "气阀断裂" | "管线腐蚀穿孔"
  remainingUsefulLifeDays: number;
  recommendedMaintenanceWindow: string;
}

// 16. HSE安全生产与环保实时监测
export interface HSEIncidentAlert {
  id: string;
  siteName: string;
  dangerLevel: "极高" | "高" | "中" | "低";
  type: "可燃气体泄漏" | "高压超限" | "温升异常" | "雷击火情" | "人员侵入限制区" | "环保排放超标";
  coordinate: [number, number];
  timestamp: string;
  personnelInAreaCount: number;
  vehicleInAreaCount: number;
  responseStatus: "报警触发" | "应急小组前往" | "消防自动喷淋启动" | "已处置关闭";
}

export interface EnvironmentalEmissionMetrics {
  wasteGasFlowKcmHour: number;
  wasteWaterFlowM3Hour: number;
  vocsPpm: number;
  methanePpm: number;
  so2MgM3: number;
  noxMgM3: number;
  codMgL: number; // 污水化学需氧量
  heavyMetalLevel: "合格" | "轻微超标" | "重度超标";
}

// 17. 财务和项目投资
export interface EnergyIndustrialFinance {
  revenueBillionRMB: number;
  costBillionRMB: number;
  grossProfitMarginPercentage: number;
  ebitdaBillionRMB: number;
  capexBillionRMB: number;
  opexBillionRMB: number;
  inventoryValueBillionRMB: number;
  upstreamProfitBillionRMB: number;
  refiningProfitBillionRMB: number;
  chemicalProfitBillionRMB: number;
  retailProfitBillionRMB: number;
}

export interface EnergyProjectInvestment {
  id: string;
  name: string;
  type: "深海气田开发" | "页岩油二期" | "炼厂乙烯升级" | "长输天然气管线" | "加氢充能综合站" | "CCUS十万吨级封存";
  capexBillionRMB: number;
  opexAnnualBillionRMB: number;
  npvBillionRMB: number;
  irrPercentage: number;
  paybackPeriodYears: number;
  cashFlowSeries: number[]; // 10年
  sensitivityAnalysis: {
    variable: "油价上涨10%" | "油价下跌10%" | "产量下降5%" | "CAPEX超支15%";
    resultIRR: number;
  }[];
}

// 风险
export interface EnergyRiskIndicator {
  type: "供应风险" | "价格波动风险" | "地缘政治风险" | "设备安全风险" | "天气灾害风险" | "外汇风险";
  name: string;
  level: "橙色预警" | "黄色警告" | "蓝色警示" | "正常";
  valueAtRiskBillionRMB: number;
  stressTestScenario: string;
  impactDescription: string;
}

// 历史操作日志
export interface AuditLogEntry {
  id: string;
  operatorName: string;
  operatorRole: "集团超级管理员" | "分公司安全总监" | "炼化中控调度员" | "油田现场总工";
  actionType: "工艺负荷变更" | "阀门开启/关闭" | "泵机紧急停机" | "贸易合同核签" | "情景仿真建立";
  targetEntity: string;
  description: string;
  timestamp: string;
  clientIp: string;
  isOTControl: boolean;
  mfaVerified: boolean;
  supervisorApproved: boolean;
  signatureHash: string;
}
