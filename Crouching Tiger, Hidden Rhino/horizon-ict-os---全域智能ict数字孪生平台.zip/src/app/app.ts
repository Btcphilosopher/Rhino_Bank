import { Component, ChangeDetectionStrategy, inject, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DigitalTwin } from './services/digital-twin';
import { HeaderTopBarComponent } from './components/header-top-bar/header-top-bar';
import { LeftNavigatorComponent } from './components/left-navigator/left-navigator';
import { DigitalMap3DComponent } from './components/digital-map-3d/digital-map-3d';
import { TopologyViewComponent } from './components/topology-view/topology-view';
import { Rack3dViewComponent } from './components/rack-3d-view/rack-3d-view';
import { PathTracerViewComponent } from './components/path-tracer-view/path-tracer-view';
import { IntentEngineViewComponent } from './components/intent-engine-view/intent-engine-view';
import { ScenarioSandboxViewComponent } from './components/scenario-sandbox-view/scenario-sandbox-view';
import { EnergySecurityViewComponent } from './components/energy-security-view/energy-security-view';
import { RightInspectorComponent } from './components/right-inspector/right-inspector';
import { AiEngineerDrawerComponent } from './components/ai-engineer-drawer/ai-engineer-drawer';
import { TimeMachineBarComponent } from './components/time-machine-bar/time-machine-bar';

@Component({
  selector: 'app-root',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule,
    HeaderTopBarComponent,
    LeftNavigatorComponent,
    DigitalMap3DComponent,
    TopologyViewComponent,
    Rack3dViewComponent,
    PathTracerViewComponent,
    IntentEngineViewComponent,
    ScenarioSandboxViewComponent,
    EnergySecurityViewComponent,
    RightInspectorComponent,
    AiEngineerDrawerComponent,
    TimeMachineBarComponent
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  public twin = inject(DigitalTwin);

  @ViewChild(AiEngineerDrawerComponent) aiDrawer!: AiEngineerDrawerComponent;

  public toggleAiDrawer() {
    if (this.aiDrawer) {
      this.aiDrawer.openDrawer();
    }
  }
}
