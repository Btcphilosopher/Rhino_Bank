import { Injectable, signal, computed } from '@angular/core';
import {
  EquipmentNode,
  NetworkLink,
  ServiceNode,
  ApplicationNode,
  UserNode,
  BusinessIntentNode,
  RackNode,
  DatacenterNode,
  AlarmItem,
  ScenarioType,
  ScenarioImpactResult,
  LayerType,
  TelemetryPoint
} from '../models/digital-twin.model';

import {
  SIMULATION_DATACENTERS,
  SIMULATION_RACKS,
  SIMULATION_EQUIPMENT,
  SIMULATION_LINKS,
  SIMULATION_SERVICES,
  SIMULATION_APPLICATIONS,
  SIMULATION_USERS,
  SIMULATION_INTENTS,
  INITIAL_ALARMS
} from '../data/ict-simulation-dataset';

@Injectable({
  providedIn: 'root'
})
export class DigitalTwin {
  // Master Signals for 5 Linked Layers
  public readonly datacenters = signal<DatacenterNode[]>(SIMULATION_DATACENTERS);
  public readonly racks = signal<RackNode[]>(SIMULATION_RACKS);
  public readonly equipment = signal<EquipmentNode[]>(SIMULATION_EQUIPMENT);
  public readonly links = signal<NetworkLink[]>(SIMULATION_LINKS);
  public readonly services = signal<ServiceNode[]>(SIMULATION_SERVICES);
  public readonly applications = signal<ApplicationNode[]>(SIMULATION_APPLICATIONS);
  public readonly users = signal<UserNode[]>(SIMULATION_USERS);
  public readonly intents = signal<BusinessIntentNode[]>(SIMULATION_INTENTS);
  public readonly alarms = signal<AlarmItem[]>(INITIAL_ALARMS);

  // Active View State
  public readonly activeView = signal<
    '3d-map' | '2d-gis' | 'topology' | 'dc-twin' | 'service-graph' | 'path-tracer' | 'intent-engine' | 'energy-security' | 'sandbox'
  >('3d-map');

  // Selected & Highlighted Entities
  public readonly selectedEntityId = signal<string | null>('HW-CR-BJ-01');
  public readonly selectedEntityType = signal<LayerType | 'datacenter' | 'rack'>('equipment');

  // Active Scenario
  public readonly activeScenario = signal<ScenarioType>('Normal');
  public readonly lastScenarioResult = signal<ScenarioImpactResult | null>(null);

  // Time Machine scrubbing (HH:MM e.g. "10:30")
  public readonly timeMachineHour = signal<number>(10);
  public readonly timeMachinePlaying = signal<boolean>(false);

  // Live Telemetry history for charts
  public readonly telemetryHistory = signal<TelemetryPoint[]>([
    { timestamp: '09:00', activeAlarmsCount: 0, avgLatencyMs: 14.1, networkThroughputTbps: 1.42, totalPowerKw: 7340, avgPue: 1.17, overallQoe: 99.2 },
    { timestamp: '09:30', activeAlarmsCount: 1, avgLatencyMs: 14.2, networkThroughputTbps: 1.58, totalPowerKw: 7480, avgPue: 1.17, overallQoe: 99.1 },
    { timestamp: '10:00', activeAlarmsCount: 1, avgLatencyMs: 14.3, networkThroughputTbps: 1.75, totalPowerKw: 7620, avgPue: 1.18, overallQoe: 99.0 },
  ]);

  // Computed linked cross-highlighting ids
  public readonly highlightedEntityIds = computed(() => {
    const selId = this.selectedEntityId();
    if (!selId) return new Set<string>();

    const set = new Set<string>([selId]);

    // Check Equipment selection -> find links, services, apps, users, intents
    const eq = this.equipment().find(e => e.id === selId);
    if (eq) {
      if (eq.rackId) set.add(eq.rackId);
      this.links().forEach(l => {
        if (l.sourceDeviceId === eq.id || l.targetDeviceId === eq.id) {
          set.add(l.id);
          set.add(l.sourceDeviceId);
          set.add(l.targetDeviceId);
        }
      });
      this.services().forEach(s => {
        if (s.underlyingDeviceIds.includes(eq.id)) {
          set.add(s.id);
          s.dependentApplicationIds.forEach(appId => set.add(appId));
        }
      });
    }

    // Check Service selection -> find underlying devices, links, apps, users
    const svc = this.services().find(s => s.id === selId);
    if (svc) {
      svc.underlyingDeviceIds.forEach(id => set.add(id));
      svc.underlyingLinkIds.forEach(id => set.add(id));
      svc.dependentApplicationIds.forEach(id => set.add(id));
      this.users().forEach(u => {
        if (u.connectedServiceIds.includes(svc.id)) set.add(u.id);
      });
    }

    // Check User selection -> find connected services & access device
    const usr = this.users().find(u => u.id === selId);
    if (usr) {
      set.add(usr.accessDeviceId);
      usr.connectedServiceIds.forEach(id => set.add(id));
    }

    // Check Application selection -> find servers, services, datacenter
    const app = this.applications().find(a => a.id === selId);
    if (app) {
      app.serverIds.forEach(id => set.add(id));
      app.serviceIds.forEach(id => set.add(id));
      set.add(app.datacenterId);
    }

    // Check Link selection
    const link = this.links().find(l => l.id === selId);
    if (link) {
      set.add(link.sourceDeviceId);
      set.add(link.targetDeviceId);
    }

    return set;
  });

  // Selected Entity Details object getter
  public readonly selectedEntityObject = computed(() => {
    const id = this.selectedEntityId();
    if (!id) return null;

    const eq = this.equipment().find(e => e.id === id);
    if (eq) return { type: 'equipment' as const, data: eq };

    const link = this.links().find(l => l.id === id);
    if (link) return { type: 'network' as const, data: link };

    const svc = this.services().find(s => s.id === id);
    if (svc) return { type: 'service' as const, data: svc };

    const app = this.applications().find(a => a.id === id);
    if (app) return { type: 'application' as const, data: app };

    const usr = this.users().find(u => u.id === id);
    if (usr) return { type: 'user' as const, data: usr };

    const intent = this.intents().find(i => i.id === id);
    if (intent) return { type: 'intent' as const, data: intent };

    const dc = this.datacenters().find(d => d.id === id);
    if (dc) return { type: 'datacenter' as const, data: dc };

    const rack = this.racks().find(r => r.id === id);
    if (rack) return { type: 'rack' as const, data: rack };

    return null;
  });

  constructor() {
    this.startTelemetryTimer();
  }

  public selectEntity(id: string, type?: LayerType | 'datacenter' | 'rack') {
    this.selectedEntityId.set(id);
    if (type) {
      this.selectedEntityType.set(type);
    }
  }

  public triggerScenario(scenario: ScenarioType) {
    this.activeScenario.set(scenario);

    if (scenario === 'Normal') {
      // Reset all states
      this.resetToNormalState();
      this.lastScenarioResult.set(null);
      return;
    }

    if (scenario === 'FiberCut') {
      // Fiber Cut between BJ and SH core routers
      this.links.update(list => list.map(l => {
        if (l.id === 'LINK-BJ-SH-400G-A') {
          return {
            ...l,
            status: 'critical',
            packetLossRate: 1.0,
            currentUtilizationPct: 0
          };
        }
        return l;
      }));

      // Reroute service latency increase
      this.services.update(list => list.map(s => {
        if (s.id === 'SVC-FIN-01') {
          return {
            ...s,
            status: 'warning',
            currentLatencyMs: 39.3,
            underlyingLinkIds: ['LINK-BJ-SZ-400G-A', 'LINK-SH-SZ-400G-A', 'LINK-SH-DC1-INTERNAL']
          };
        }
        return s;
      }));

      this.alarms.update(prev => [
        {
          id: `ALM-${Date.now().toString().slice(-4)}`,
          timestamp: new Date().toLocaleTimeString(),
          severity: 'Critical',
          sourceEntityId: 'LINK-BJ-SH-400G-A',
          sourceEntityName: '京沪400G SRv6主干光缆',
          layer: 'network',
          title: '主干光缆中断告警 (Fiber Optic Line Cut)',
          description: 'LOS (Loss of Signal) detected on BJ-CR01 GE0/1/0 optical transceiver at KM 482.0',
          isRootCauseCandidate: true
        },
        {
          id: `ALM-${(Date.now() + 1).toString().slice(-4)}`,
          timestamp: new Date().toLocaleTimeString(),
          severity: 'Major',
          sourceEntityId: 'SVC-FIN-01',
          sourceEntityName: '跨区域极速金融交易VPN',
          layer: 'service',
          title: '服务时延突增告警 (SLA Latency Spike)',
          description: 'Service latency increased from 14.2ms to 39.3ms due to SRv6 path reroute via Shenzhen Hub'
        },
        ...prev
      ]);

      const result: ScenarioImpactResult = {
        scenario: 'FiberCut',
        rootCauseMessage: '京沪 400G 光缆在 KM 482 发生物理断纤 (Fiber Cut Detected)',
        rootCauseEntityIds: ['LINK-BJ-SH-400G-A'],
        affectedDeviceIds: ['HW-CR-BJ-01', 'HW-CR-SH-01'],
        affectedServiceIds: ['SVC-FIN-01'],
        affectedApplicationIds: ['APP-BANKING-01'],
        affectedUserCount: 3200,
        alternatePathFound: true,
        alternatePathDetails: [
          '原直连路径: 北京 HW-CR-BJ-01 -> (LINK-BJ-SH-400G-A) -> 上海 HW-CR-SH-01 (已中断)',
          '自动重定向倒换路径: 北京 HW-CR-BJ-01 -> 深圳 HW-CR-SZ-01 -> 上海 HW-CR-SH-01',
          '重定向时延: 39.3 ms (增加 +25.1 ms), 业务零中断 (Zero Packet Loss After 12ms Protection Switch)'
        ],
        remediationPlan: [
          '1. 派发 OTDR 光纤定位工单给山东济南光缆巡检抢修队 (Location: KM 482.0)',
          '2. 保持 SRv6 备份路径 (BJ -> SZ -> SH) 800G 容量倒换锁定',
          '3. 自动调整金融交易 QoS 队列优先级至 Level 0 极速通道'
        ]
      };

      this.lastScenarioResult.set(result);
    } else if (scenario === 'DcCongestion') {
      // DC Switch congestion
      this.links.update(list => list.map(l => {
        if (l.id === 'LINK-SH-DC1-INTERNAL') {
          return { ...l, currentUtilizationPct: 99.8, status: 'warning', latencyMs: 12.5 };
        }
        return l;
      }));

      this.alarms.update(prev => [
        {
          id: `ALM-${Date.now().toString().slice(-4)}`,
          timestamp: new Date().toLocaleTimeString(),
          severity: 'Major',
          sourceEntityId: 'HW-CE-SH-01',
          sourceEntityName: '上海金融DC Core Switch',
          layer: 'equipment',
          title: '数据中心核心交换机接口严重拥塞 (DC Fabric Congestion)',
          description: 'Port CE-SH01-P1 queue buffer overflow threshold 99.8% reached',
          isRootCauseCandidate: true
        },
        ...prev
      ]);

      this.lastScenarioResult.set({
        scenario: 'DcCongestion',
        rootCauseMessage: '上海金融 DC 核心交换机 Port CE-SH01-P1 极速结算高频突发流量拥塞',
        rootCauseEntityIds: ['HW-CE-SH-01'],
        affectedDeviceIds: ['HW-CE-SH-01', 'SRV-SH-01'],
        affectedServiceIds: ['SVC-FIN-01'],
        affectedApplicationIds: ['APP-BANKING-01'],
        affectedUserCount: 3200,
        alternatePathFound: true,
        alternatePathDetails: [
          '启用 RoCE v2 PFC 智能无损网络流量控制',
          '动态分流部分高频交易至 DC-SH-02 临港算力备用节点'
        ],
        remediationPlan: [
          '1. 触发 ECMP 多路径负载均衡权重重置',
          '2. 动态拓宽光模块带宽通道至 800G'
        ]
      });
    } else if (scenario === 'RouterCrash') {
      // Core Router HW-CR-BJ-01 Crash
      this.equipment.update(list => list.map(e => {
        if (e.id === 'HW-CR-BJ-01') return { ...e, status: 'critical', cpuUsagePct: 100 };
        return e;
      }));

      this.alarms.update(prev => [
        {
          id: `ALM-${Date.now().toString().slice(-4)}`,
          timestamp: new Date().toLocaleTimeString(),
          severity: 'Critical',
          sourceEntityId: 'HW-CR-BJ-01',
          sourceEntityName: '北京国家骨干核心路由器01',
          layer: 'equipment',
          title: '核心路由器主控板卡硬件宕机 (Core Router Board Crash)',
          description: 'Keepalive missing from HW-NE8000-BJ1 MPUP board',
          isRootCauseCandidate: true
        },
        ...prev
      ]);

      this.lastScenarioResult.set({
        scenario: 'RouterCrash',
        rootCauseMessage: '北京 HW-CR-BJ-01 主控板硬件故障导致节点下线',
        rootCauseEntityIds: ['HW-CR-BJ-01'],
        affectedDeviceIds: ['HW-CR-BJ-01', 'OSN-BJ-01', 'HW-CE-BJ-01'],
        affectedServiceIds: ['SVC-FIN-01', 'SVC-CLOUD-DC-01'],
        affectedApplicationIds: ['APP-BANKING-01', 'APP-SAAS-01'],
        affectedUserCount: 55200,
        alternatePathFound: true,
        alternatePathDetails: [
          '激活北京双主核心备用路由器 HW-CR-BJ-02',
          'BGP / OSPF 拓扑 800ms 内完成热倒换恢复'
        ],
        remediationPlan: [
          '1. 通知现场工程师对 HW-CR-BJ-01 进主控板热插拔替换',
          '2. 确认备份路由器 HW-CR-BJ-02 流量承载正常'
        ]
      });
    } else if (scenario === 'PowerLoss') {
      // Power Loss on Shanghai DC-01
      this.datacenters.update(list => list.map(d => {
        if (d.id === 'DC-SH-01') {
          return { ...d, status: 'warning', batteryBackupMins: 38, pueScore: 1.45 };
        }
        return d;
      }));

      this.racks.update(list => list.map(r => {
        if (r.datacenterId === 'DC-SH-01') {
          return { ...r, status: 'warning', temperatureC: 31.4, coolingStatus: 'High_Temp' };
        }
        return r;
      }));

      this.alarms.update(prev => [
        {
          id: `ALM-${Date.now().toString().slice(-4)}`,
          timestamp: new Date().toLocaleTimeString(),
          severity: 'Critical',
          sourceEntityId: 'DC-SH-01',
          sourceEntityName: '上海浦东金融数据中心',
          layer: 'equipment',
          title: '市电输入中断 & UPS 电池组供电中 (Grid Mains Power Drop)',
          description: 'A路市电中断，UPS 切换运行，剩余供电时长约 38 分钟，机房温度上升至 31.4°C',
          isRootCauseCandidate: true
        },
        ...prev
      ]);

      this.lastScenarioResult.set({
        scenario: 'PowerLoss',
        rootCauseMessage: '上海浦东 DC-01 外部 220kV 变电站高压供电线路跳闸，UPS 应急供电',
        rootCauseEntityIds: ['DC-SH-01'],
        affectedDeviceIds: ['SRV-SH-01', 'HW-CE-SH-01', 'HW-CR-SH-01'],
        affectedServiceIds: ['SVC-FIN-01'],
        affectedApplicationIds: ['APP-BANKING-01'],
        affectedUserCount: 3200,
        alternatePathFound: true,
        alternatePathDetails: [
          '柴油发电机组 Generator #1, #2 启动倒计时 45 秒',
          '应用计算负载开始动态冷迁移至临港 DC-SH-02 枢纽'
        ],
        remediationPlan: [
          '1. 启动二次柴油发电机应急并网供电',
          '2. 调高变频液冷机组功率控制温度',
          '3. 迁移低优先级虚拟机，降低机架总功耗 35%'
        ]
      });
    } else if (scenario === 'TrafficSurge') {
      // Traffic +50%
      this.links.update(list => list.map(l => ({
        ...l,
        currentUtilizationPct: Math.min(99, l.currentUtilizationPct * 1.5)
      })));

      this.lastScenarioResult.set({
        scenario: 'TrafficSurge',
        rootCauseMessage: '全国骨干网业务高峰期流量突增 +50% 预测仿真',
        rootCauseEntityIds: [],
        affectedDeviceIds: ['HW-CR-BJ-01', 'HW-CR-SH-01', 'HW-CR-SZ-01'],
        affectedServiceIds: ['SVC-CLOUD-DC-01', 'SVC-5G-SLICE-01'],
        affectedApplicationIds: ['APP-SAAS-01', 'APP-AUTONOMOUS-01'],
        affectedUserCount: 98000,
        alternatePathFound: true,
        alternatePathDetails: [
          '预计 3 小时内京沪链路利用率将达到 89.2% 瓶颈',
          '容量预警：必须在 5 个月内扩容 DWDM 波道 2x400G'
        ],
        remediationPlan: [
          '1. 激活FlexE 灵活切片带宽按需扩展 (BoD)',
          '2. 启动智能流量整形与 P2P 边缘缓存策略'
        ]
      });
    }
  }

  private resetToNormalState() {
    this.datacenters.set(SIMULATION_DATACENTERS);
    this.racks.set(SIMULATION_RACKS);
    this.equipment.set(SIMULATION_EQUIPMENT);
    this.links.set(SIMULATION_LINKS);
    this.services.set(SIMULATION_SERVICES);
    this.applications.set(SIMULATION_APPLICATIONS);
    this.users.set(SIMULATION_USERS);
    this.intents.set(SIMULATION_INTENTS);
    this.alarms.set(INITIAL_ALARMS);
  }

  private startTelemetryTimer() {
    if (typeof window === 'undefined') return;
    setInterval(() => {
      // Random minor fluctuations to simulate live telemetry stream
      this.equipment.update(list => list.map(e => {
        const deltaCpu = (Math.random() - 0.5) * 2;
        const newCpu = Math.max(10, Math.min(95, e.cpuUsagePct + deltaCpu));
        return { ...e, cpuUsagePct: Number(newCpu.toFixed(1)) };
      }));

      // Update telemetry history
      const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      const currentAlarms = this.alarms().length;
      const curLinks = this.links();
      const avgLat = curLinks.reduce((acc, l) => acc + l.latencyMs, 0) / (curLinks.length || 1);

      this.telemetryHistory.update(hist => {
        const nextHist = [
          ...hist,
          {
            timestamp: now,
            activeAlarmsCount: currentAlarms,
            avgLatencyMs: Number(avgLat.toFixed(1)),
            networkThroughputTbps: Number((1.65 + Math.sin(Date.now() / 5000) * 0.3).toFixed(2)),
            totalPowerKw: 7450 + Math.floor(Math.random() * 50),
            avgPue: 1.17,
            overallQoe: currentAlarms > 2 ? 94.2 : 99.1
          }
        ];
        return nextHist.slice(-20);
      });
    }, 2000);
  }
}
