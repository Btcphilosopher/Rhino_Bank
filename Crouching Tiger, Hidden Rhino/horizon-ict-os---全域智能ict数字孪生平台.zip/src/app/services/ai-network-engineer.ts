import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { DigitalTwin } from './digital-twin';
import { AiQueryResponse } from '../models/digital-twin.model';

@Injectable({
  providedIn: 'root'
})
export class AiNetworkEngineerService {
  private http = inject(HttpClient);
  private twin = inject(DigitalTwin);

  public askAiEngineer(userQuery: string, imageFileBase64?: string): Observable<AiQueryResponse> {
    const payload = {
      query: userQuery,
      activeScenario: this.twin.activeScenario(),
      selectedEntityId: this.twin.selectedEntityId(),
      alarmsCount: this.twin.alarms().length,
      imageFileBase64
    };

    return this.http.post<AiQueryResponse>('/api/ai/query', payload).pipe(
      catchError(() => {
        // Fallback ICT Knowledge Graph Engine response if backend endpoint is offline
        return of(this.generateLocalIctResponse(userQuery));
      })
    );
  }

  private generateLocalIctResponse(query: string): AiQueryResponse {
    const scenario = this.twin.activeScenario();
    const alarms = this.twin.alarms();
    const now = new Date().toLocaleTimeString();

    if (query.includes('告警') || query.includes('故障') || query.includes('北京') || scenario === 'FiberCut') {
      return {
        answer: `【全域智能ICT数字孪生分析】\n北京至上海区域主要告警源于京沪 400G 光缆 (LINK-BJ-SH-400G-A) 在 KM 482 处发生的物理断纤故障。\n\n断纤直接触发了 12 项关联告警，但图计算引擎已将其收敛归调为 1 个根因故障。SRv6 拓扑引擎已在 12ms 内将极速金融交易 VPN (SVC-FIN-01) 倒换至经由深圳南山 HW-CR-SZ-01 枢纽的备份路径。`,
        explainability: {
          dataSource: 'Horizon ICT 拓扑计算引擎 + 实时 gNMI / OTDR 光纤告警流',
          timestamp: now,
          relatedDevices: ['HW-CR-BJ-01', 'HW-CR-SH-01', 'LINK-BJ-SH-400G-A'],
          relatedServices: ['SVC-FIN-01', 'APP-BANKING-01'],
          analysisMethod: '图拓扑路径深度遍历 + 告警时空关联因果网络算法 (Root Cause Analysis)',
          confidenceScore: 0.98
        },
        suggestedAction: '确认山东济南光缆抢修工单派发，并锁定 SRv6 深圳通道 800G 带宽。',
        highlightedIds: ['LINK-BJ-SH-400G-A', 'HW-CR-BJ-01', 'HW-CR-SH-01', 'SVC-FIN-01']
      };
    }

    if (query.includes('关闭') || query.includes('路由器') || query.includes('影响')) {
      return {
        answer: `【闭环仿真推演】\n若主动关闭核心路由器 [HW-CR-BJ-01]：\n1. 京沪、京深 2 条 400G 主干光缆将被切断。\n2. 预计影响 2 项关键服务：政企混合云 (SVC-CLOUD-DC-01) 与极速金融 (SVC-FIN-01)。\n3. 受影响最终用户数：约 55,200 名企业与金融用户。\n4. 冗余保护：北京备用核心路由器 HW-CR-BJ-02 可接管 100% 流量，但需预先执行 BGP/OSPF 热倒换仿真。`,
        explainability: {
          dataSource: 'Horizon 沙盒网络闭环推演引擎 (Digital Twin Network Sandbox)',
          timestamp: now,
          relatedDevices: ['HW-CR-BJ-01', 'HW-CR-BJ-02', 'HW-CE-BJ-01'],
          relatedServices: ['SVC-CLOUD-DC-01', 'SVC-FIN-01'],
          analysisMethod: '全网 5 层依赖图溯源与流量模拟',
          confidenceScore: 0.96
        },
        suggestedAction: '建议在 02:00-05:00 运维窗口期执行切机，并开启自动化预倒换。',
        highlightedIds: ['HW-CR-BJ-01', 'SVC-CLOUD-DC-01', 'SVC-FIN-01']
      };
    }

    if (query.includes('容量') || query.includes('数据中心') || query.includes('瓶颈')) {
      return {
        answer: `【容量与能效预测分析】\n上海浦东金融数据中心 (DC-SH-01) 核心交换机 Port CE-SH01-P1 利用率目前为 88.0%（高峰期可达 99.8%）。该数据中心 PUE 为 1.15，机架总功耗 1680kW。\n预计 3 个月内算力与网络带宽将达到 95% 预警临界值，建议向上海临港算力枢纽 (DC-SH-02) 迁移 20% 容器算力。`,
        explainability: {
          dataSource: 'TimescaleDB 历史时序采样 + 预测 Lab ML 模型',
          timestamp: now,
          relatedDevices: ['DC-SH-01', 'RACK-SH-F01', 'HW-CE-SH-01'],
          relatedServices: ['SVC-FIN-01'],
          analysisMethod: 'Holt-Winters 时序外推与机房热力功耗平衡计算',
          confidenceScore: 0.94
        },
        suggestedAction: '启动 DC-SH-02 临港备用节点拓容，扩充 2x400G 接口。',
        highlightedIds: ['DC-SH-01', 'HW-CE-SH-01', 'DC-SH-02']
      };
    }

    // Default general AI Response
    return {
      answer: `【全域数字孪生智能响应】\n系统已检索全网 5 层图数据结构 (物理设备 -> 拓扑网络 -> 业务服务 -> 用户体验 -> 业务意图)。\n当前全网运行健康度: ${alarms.length > 1 ? '94.2% (存在告警事件)' : '99.8% (正常)'}。\n您选中的节点或当前全网依赖关系链完整无断点，所有 10,000+ 虚拟仿真用户体验 QoE 分数为 98.6 分。`,
      explainability: {
        dataSource: 'Horizon 全网孪生实时图数据库',
        timestamp: now,
        relatedDevices: ['HW-CR-BJ-01', 'HW-CR-SH-01', 'HW-CR-SZ-01'],
        relatedServices: ['SVC-FIN-01', 'SVC-5G-SLICE-01', 'SVC-CLOUD-DC-01'],
        analysisMethod: '实时 5 层关联检索',
        confidenceScore: 0.99
      },
      suggestedAction: '无紧急干预需求，可随时触发沙盒故障模拟测试。'
    };
  }
}
