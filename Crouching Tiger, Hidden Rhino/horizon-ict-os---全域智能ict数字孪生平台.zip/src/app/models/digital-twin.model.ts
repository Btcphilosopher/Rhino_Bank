export type LayerType = 'equipment' | 'network' | 'service' | 'user' | 'intent';

export type DeviceType = 
  | 'router' 
  | 'switch' 
  | 'firewall' 
  | 'base_station' 
  | 'antenna' 
  | 'optical' 
  | 'server' 
  | 'storage' 
  | 'ups' 
  | 'cooling' 
  | 'sensor' 
  | 'gateway';

export type NetworkType = 'IP' | 'MPLS' | 'SRv6' | 'Optical' | '5G' | 'Wi-Fi' | 'WAN' | 'DC_Fabric';

export type ServiceType = 'VPN' | 'Cloud' | 'Video' | 'Voice' | 'Internet' | '5G_Slice' | 'IoT' | 'Data_Pipeline';

export type HealthStatus = 'healthy' | 'warning' | 'critical' | 'maintenance' | 'offline';

export interface Location3D {
  city: 'Beijing' | 'Shanghai' | 'Shenzhen';
  siteName: string;
  lat: number;
  lng: number;
  x: number;
  y: number;
  z: number;
  building?: string;
  floor?: string;
  room?: string;
  rackId?: string;
}

export interface PortInfo {
  id: string;
  name: string;
  speed: string; // e.g. '100G', '400G', '10G'
  type: 'fiber' | 'ethernet' | 'optical';
  status: 'up' | 'down' | 'congested';
  connectedPortId?: string;
  txRateMbps: number;
  rxRateMbps: number;
  packetLossRate: number;
}

export interface EquipmentNode {
  id: string;
  name: string;
  codeName: string;
  type: DeviceType;
  layer: 'equipment';
  location: Location3D;
  model: string;
  vendor: string; // e.g. 'Horizon Tech', 'Huawei Compatible', etc.
  ipAddress: string;
  status: HealthStatus;
  cpuUsagePct: number;
  memoryUsagePct: number;
  temperatureC: number;
  powerKw: number;
  uptimeHours: number;
  ports: PortInfo[];
  rackId?: string;
  rackSlot?: number;
}

export interface NetworkLink {
  id: string;
  name: string;
  type: NetworkType;
  layer: 'network';
  sourceDeviceId: string;
  sourcePortId: string;
  targetDeviceId: string;
  targetPortId: string;
  bandwidthGbps: number;
  currentUtilizationPct: number;
  latencyMs: number;
  packetLossRate: number;
  status: HealthStatus;
  fiberDistanceKm: number;
}

export interface ServiceNode {
  id: string;
  name: string;
  type: ServiceType;
  layer: 'service';
  slaTargetAvailability: number; // e.g., 99.99
  currentAvailability: number;
  latencyTargetMs: number;
  currentLatencyMs: number;
  status: HealthStatus;
  underlyingDeviceIds: string[];
  underlyingLinkIds: string[];
  dependentApplicationIds: string[];
  subscriberCount: number;
}

export interface ApplicationNode {
  id: string;
  name: string;
  codeName: string;
  layer: 'service'; // classified in service/app layer
  category: 'Banking' | 'Video_Conference' | 'Smart_Grid' | 'Autonomous_Driving' | 'Enterprise_SaaS' | 'Telemedicine';
  datacenterId: string;
  serverIds: string[];
  serviceIds: string[];
  status: HealthStatus;
  qoeScore: number; // Quality of Experience 0-100
}

export interface UserNode {
  id: string;
  name: string;
  layer: 'user';
  userGroup: 'Enterprise_Branch' | 'VIP_Customer' | 'IoT_Device_Cluster' | 'Mobile_5G_Users' | 'Employee';
  count: number;
  city: 'Beijing' | 'Shanghai' | 'Shenzhen';
  accessDeviceId: string;
  connectedServiceIds: string[];
  experienceScore: number; // 0-100
  status: HealthStatus;
}

export interface BusinessIntentNode {
  id: string;
  title: string;
  layer: 'intent';
  targetApplicationId: string;
  requiredLatencyMs: number;
  requiredAvailability: number; // 99.99
  priority: 'Critical' | 'High' | 'Medium' | 'Low';
  energySavingMode: boolean;
  translatedPolicy: string;
  status: 'In_Effect' | 'Simulating' | 'Pending_Approval' | 'Violated';
}

export interface RackNode {
  id: string;
  datacenterId: string;
  roomName: string;
  rackName: string; // e.g. RACK-A12
  maxPowerKw: number;
  currentPowerKw: number;
  temperatureC: number;
  status: HealthStatus;
  serversCount: number;
  switchesCount: number;
  coolingStatus: 'Optimal' | 'Warning' | 'High_Temp';
  deviceIds: string[];
}

export interface DatacenterNode {
  id: string;
  name: string;
  city: 'Beijing' | 'Shanghai' | 'Shenzhen';
  building: string;
  racksCount: number;
  pueScore: number; // Power Usage Effectiveness e.g. 1.21
  totalPowerKw: number;
  solarKw: number;
  batteryBackupMins: number;
  status: HealthStatus;
}

export interface TelemetryPoint {
  timestamp: string;
  activeAlarmsCount: number;
  avgLatencyMs: number;
  networkThroughputTbps: number;
  totalPowerKw: number;
  avgPue: number;
  overallQoe: number;
}

export interface AlarmItem {
  id: string;
  timestamp: string;
  severity: 'Critical' | 'Major' | 'Minor' | 'Warning';
  sourceEntityId: string;
  sourceEntityName: string;
  layer: LayerType;
  title: string;
  description: string;
  isRootCauseCandidate?: boolean;
}

export type ScenarioType = 'Normal' | 'FiberCut' | 'DcCongestion' | 'RouterCrash' | 'PowerLoss' | 'TrafficSurge';

export interface ScenarioImpactResult {
  scenario: ScenarioType;
  rootCauseMessage: string;
  rootCauseEntityIds: string[];
  affectedDeviceIds: string[];
  affectedServiceIds: string[];
  affectedApplicationIds: string[];
  affectedUserCount: number;
  alternatePathFound: boolean;
  alternatePathDetails: string[];
  remediationPlan: string[];
}

export interface AiExplainability {
  dataSource: string;
  timestamp: string;
  relatedDevices: string[];
  relatedServices: string[];
  analysisMethod: string;
  confidenceScore: number;
}

export interface AiQueryResponse {
  answer: string;
  explainability: AiExplainability;
  suggestedAction?: string;
  highlightedIds?: string[];
}
