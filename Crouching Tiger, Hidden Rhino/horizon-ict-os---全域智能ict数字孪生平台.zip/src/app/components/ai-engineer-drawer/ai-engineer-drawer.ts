import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { firstValueFrom } from 'rxjs';
import { AiNetworkEngineerService } from '../../services/ai-network-engineer';
import { DigitalTwin } from '../../services/digital-twin';
import { AiExplainability } from '../../models/digital-twin.model';

export interface ChatMessage {
  sender: 'user' | 'ai';
  text: string;
  timestamp: Date;
  explainability?: AiExplainability;
}

@Component({
  selector: 'app-ai-engineer-drawer',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (isOpen()) {
      <div class="fixed inset-0 bg-slate-950/60 backdrop-blur-sm z-50 flex justify-end">
        <div class="w-full max-w-xl bg-slate-950 border-l border-slate-800 h-full flex flex-col shadow-2xl animate-slide-left text-slate-200 select-none">

          <!-- Drawer Header -->
          <div class="p-4 border-b border-slate-800 bg-slate-900/80 flex items-center justify-between">
            <div class="flex items-center space-x-2">
              <div class="w-8 h-8 rounded-lg bg-emerald-600/30 border border-emerald-500/40 flex items-center justify-center">
                <mat-icon class="text-emerald-400 !w-5 !h-5 !text-[20px] animate-pulse">auto_awesome</mat-icon>
              </div>
              <div>
                <h3 class="font-mono font-bold text-white text-sm">AI 网络运维架构师 (AI ICT Engineer)</h3>
                <p class="text-[11px] text-slate-400 font-sans">Gemini 2.5 Flash 驱动的网管运维大模型助手</p>
              </div>
            </div>

            <button
              (click)="closeDrawer()"
              class="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition"
            >
              <mat-icon class="!w-5 !h-5 !text-[20px]">close</mat-icon>
            </button>
          </div>

          <!-- Preset Quick Questions -->
          <div class="p-3 bg-slate-900/40 border-b border-slate-800 space-y-1.5 font-mono text-[11px]">
            <span class="text-slate-400 text-[10px] block font-bold">快速向 AI 询问:</span>
            <div class="flex flex-wrap gap-1.5">
              <button
                (click)="askPreset('为什么当前网络出现告警？请分析根因。')"
                class="px-2 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded text-slate-300 hover:text-white transition"
              >
                为什么网络出现告警？
              </button>
              <button
                (click)="askPreset('若关闭核心路由器 HW-CR-BJ-01，会对业务造成什么影响？')"
                class="px-2 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded text-slate-300 hover:text-white transition"
              >
                关闭核心路由器影响面？
              </button>
              <button
                (click)="askPreset('当前哪个数据中心最接近容量和 PUE 上限？')"
                class="px-2 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded text-slate-300 hover:text-white transition"
              >
                哪个数据中心临近上限？
              </button>
            </div>
          </div>

          <!-- Chat Conversation Stream -->
          <div class="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-4 font-mono text-xs">
            @for (msg of chatMessages(); track $index) {
              <div
                class="p-3.5 rounded-2xl max-w-[90%]"
                [ngClass]="msg.sender === 'user' ? 'bg-emerald-950/80 border border-emerald-500/30 ml-auto text-emerald-100' : 'bg-slate-900/90 border border-slate-800 mr-auto text-slate-200'"
              >
                <div class="flex items-center justify-between text-[10px] text-slate-400 mb-1 border-b border-slate-800/60 pb-1">
                  <span class="font-bold uppercase">{{ msg.sender === 'user' ? '您 (OPERATOR)' : 'HORIZON AI ENGINEER' }}</span>
                  <span>{{ msg.timestamp | date:'HH:mm:ss' }}</span>
                </div>

                <p class="whitespace-pre-line leading-relaxed font-sans text-xs mt-1.5">{{ msg.text }}</p>

                <!-- Explainability Box for AI responses -->
                @if (msg.explainability) {
                  <div class="mt-3 p-2.5 bg-slate-950 rounded-xl border border-slate-800 text-[10px] space-y-1 text-slate-400 font-mono">
                    <div class="text-emerald-400 font-bold mb-1 flex items-center space-x-1">
                      <mat-icon class="!w-3.5 !h-3.5 !text-[14px]">psychology</mat-icon>
                      <span>可解释性声明 (Explainability Provenance)</span>
                    </div>
                    <div>数据来源: <span class="text-slate-200">{{ msg.explainability.dataSource }}</span></div>
                    <div>关联设备: <span class="text-slate-200">{{ msg.explainability.relatedDevices.join(', ') }}</span></div>
                    <div>推理方法: <span class="text-slate-200">{{ msg.explainability.analysisMethod }}</span></div>
                    <div>分析置信度: <span class="text-emerald-400 font-bold">{{ msg.explainability.confidenceScore * 100 }}%</span></div>
                  </div>
                }
              </div>
            }

            @if (isLoading()) {
              <div class="p-3 bg-slate-900 border border-slate-800 rounded-2xl mr-auto text-slate-400 text-xs flex items-center space-x-2">
                <mat-icon class="animate-spin text-emerald-400 !w-4 !h-4 !text-[16px]">sync</mat-icon>
                <span>AI 正在调阅 5 层数字孪生图数据库并推理分析...</span>
              </div>
            }
          </div>

          <!-- Bottom Chat Input Field -->
          <div class="p-3 border-t border-slate-800 bg-slate-900/80">
            <div class="flex items-center space-x-2">
              <input
                type="text"
                [value]="inputQuery()"
                (input)="inputQuery.set($any($event.target).value)"
                (keyup.enter)="sendQuery()"
                placeholder="询问 AI 运维助手（例如：推荐最佳的流量重路由方案）..."
                class="flex-1 bg-slate-950 border border-slate-800 rounded-xl py-2 px-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 font-mono"
              />
              <button
                (click)="sendQuery()"
                [disabled]="isLoading() || !inputQuery().trim()"
                class="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl font-bold font-mono text-xs transition flex items-center space-x-1"
              >
                <mat-icon class="!w-4 !h-4 !text-[16px]">send</mat-icon>
                <span>发送</span>
              </button>
            </div>
          </div>

        </div>
      </div>
    }
  `
})
export class AiEngineerDrawerComponent {
  public aiService = inject(AiNetworkEngineerService);
  public twin = inject(DigitalTwin);

  public isOpen = signal<boolean>(false);
  public inputQuery = signal<string>('');
  public isLoading = signal<boolean>(false);

  public chatMessages = signal<ChatMessage[]>([
    {
      sender: 'ai',
      text: '您好！我是 HORIZON ICT OS 全域智能 AI 运维架构师。我已经实时调阅当前 5 层数字孪生拓扑（10 个数据中心、100 台网元、5 条核心光纤通道及 12 个 5G 切片）。请问有何可以帮您？',
      timestamp: new Date(),
      explainability: {
        dataSource: 'Live Telemetry & Digital Twin Graph',
        timestamp: new Date().toLocaleTimeString(),
        relatedDevices: ['HW-CR-BJ-01', 'LINK-BJ-SH-400G-A'],
        relatedServices: ['SVC-FIN-01'],
        analysisMethod: 'Topological Correlation & Gemini 2.5 Reasoning',
        confidenceScore: 0.99
      }
    }
  ]);

  public openDrawer() {
    this.isOpen.set(true);
  }

  public closeDrawer() {
    this.isOpen.set(false);
  }

  public askPreset(q: string) {
    this.inputQuery.set(q);
    this.sendQuery();
  }

  public async sendQuery() {
    const text = this.inputQuery().trim();
    if (!text || this.isLoading()) return;

    this.chatMessages.update(m => [...m, { sender: 'user', text, timestamp: new Date() }]);
    this.inputQuery.set('');
    this.isLoading.set(true);

    try {
      const resp = await firstValueFrom(this.aiService.askAiEngineer(text));

      this.chatMessages.update(m => [
        ...m,
        {
          sender: 'ai',
          text: resp.answer,
          timestamp: new Date(),
          explainability: resp.explainability
        }
      ]);
    } catch {
      this.chatMessages.update(m => [
        ...m,
        {
          sender: 'ai',
          text: '系统调阅 AI 大模型出错，已自动使用本地 Rule-Engine 备份策略回应。',
          timestamp: new Date()
        }
      ]);
    } finally {
      this.isLoading.set(false);
    }
  }
}
