import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwin } from '../../services/digital-twin';

@Component({
  selector: 'app-path-tracer-view',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full h-full bg-slate-950 p-6 overflow-y-auto text-slate-200 select-none">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
        <div>
          <h2 class="text-lg font-mono font-bold text-white flex items-center space-x-2">
            <mat-icon class="text-emerald-400 !w-6 !h-6 !text-[24px]">route</mat-icon>
            <span>端到端全路径计算引擎 (End-to-End Path Tracer)</span>
          </h2>
          <p class="text-xs text-slate-400 font-sans">从终端用户 &rarr; 接入网 &rarr; WAN骨干 &rarr; 数据中心核心 &rarr; 物理服务器 &rarr; 应用集群</p>
        </div>

        <div class="flex items-center space-x-3">
          <div class="flex items-center space-x-2 text-xs font-mono">
            <span class="text-slate-400">选择起点用户:</span>
            <select
              [value]="selectedUserId()"
              (change)="onUserChange($event)"
              class="bg-slate-900 border border-slate-800 text-white rounded-lg px-3 py-1.5 focus:outline-none"
            >
              @for (usr of twin.users(); track usr.id) {
                <option [value]="usr.id">{{ usr.name }} ({{ usr.city }})</option>
              }
            </select>
          </div>
        </div>
      </div>

      <!-- Path Tracer Visual Flow -->
      <div class="bg-slate-900/60 border border-slate-800 rounded-2xl p-6 space-y-6">
        <div class="flex items-center justify-between font-mono text-xs text-slate-300">
          <span class="font-bold text-emerald-400">端到端总时延: {{ totalLatency() }} ms</span>
          <span>SLA 达成率: 99.999%</span>
          <span>包到达率: 99.9999%</span>
        </div>

        <!-- Horizontal Stepper Flow -->
        <div class="grid grid-cols-1 md:grid-cols-6 gap-3 relative font-mono text-xs">

          <!-- Step 1: User -->
          <div class="bg-slate-950 p-3 rounded-xl border border-violet-500/50 space-y-1">
            <div class="text-[10px] text-violet-400 font-bold uppercase">1. 用户终端</div>
            <p class="font-bold text-white text-xs truncate">陆家嘴金融交易员</p>
            <p class="text-[10px] text-slate-500">3,200 VIP Accounts</p>
          </div>

          <!-- Step 2: Access & Base Station -->
          <div class="bg-slate-950 p-3 rounded-xl border border-blue-500/50 space-y-1">
            <div class="text-[10px] text-blue-400 font-bold uppercase">2. 5G/接入交换</div>
            <p class="font-bold text-white text-xs truncate">HW-CR-SH-01 GE0/2/0</p>
            <p class="text-[10px] text-emerald-400">+0.2 ms Latency</p>
          </div>

          <!-- Step 3: WAN Backbone -->
          <div class="bg-slate-950 p-3 rounded-xl border border-cyan-500/50 space-y-1">
            <div class="text-[10px] text-cyan-400 font-bold uppercase">3. SRv6 骨干网</div>
            <p class="font-bold text-white text-xs truncate">LINK-BJ-SH-400G-A</p>
            <p class="text-[10px] text-cyan-300">+14.2 ms Latency</p>
          </div>

          <!-- Step 4: Core Firewall -->
          <div class="bg-slate-950 p-3 rounded-xl border border-blue-500/50 space-y-1">
            <div class="text-[10px] text-blue-400 font-bold uppercase">4. DC 安全防火墙</div>
            <p class="font-bold text-white text-xs truncate">HW-CE-SH-01 Fabric</p>
            <p class="text-[10px] text-emerald-400">+0.1 ms Latency</p>
          </div>

          <!-- Step 5: DC Server -->
          <div class="bg-slate-950 p-3 rounded-xl border border-emerald-500/50 space-y-1">
            <div class="text-[10px] text-emerald-400 font-bold uppercase">5. 算力服务器</div>
            <p class="font-bold text-white text-xs truncate">SRV-SH-01 Kunpeng</p>
            <p class="text-[10px] text-emerald-400">+0.3 ms Latency</p>
          </div>

          <!-- Step 6: Application -->
          <div class="bg-slate-950 p-3 rounded-xl border border-amber-500/50 space-y-1">
            <div class="text-[10px] text-amber-400 font-bold uppercase">6. 核心应用系统</div>
            <p class="font-bold text-white text-xs truncate">FinCore-v4 结算系统</p>
            <p class="text-[10px] text-emerald-400">QoE 99.4 Score</p>
          </div>

        </div>

        <!-- Detailed Hop-by-Hop Hop Table -->
        <div class="pt-4 border-t border-slate-800">
          <span class="text-xs font-bold text-slate-300 font-mono mb-3 block">逐跳报文转发路由表 (Hop-by-Hop Trace Details)</span>
          <table class="w-full text-left text-xs font-mono border-collapse">
            <thead>
              <tr class="border-b border-slate-800 text-slate-400 text-[11px]">
                <th class="py-2">HOP</th>
                <th class="py-2">设备 / 节点名称</th>
                <th class="py-2">接口 / IP</th>
                <th class="py-2">单跳时延</th>
                <th class="py-2">状态</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60">
              <tr class="text-slate-200">
                <td class="py-2 text-cyan-400 font-bold">1</td>
                <td>陆家嘴金融专线接入终端</td>
                <td>10.240.100.12</td>
                <td>0.1 ms</td>
                <td><span class="text-emerald-400 font-bold">OK</span></td>
              </tr>
              <tr class="text-slate-200">
                <td class="py-2 text-cyan-400 font-bold">2</td>
                <td>上海核心路由器 HW-CR-SH-01</td>
                <td>10.240.0.2 (GE0/2/0)</td>
                <td>0.2 ms</td>
                <td><span class="text-emerald-400 font-bold">OK</span></td>
              </tr>
              <tr class="text-slate-200">
                <td class="py-2 text-cyan-400 font-bold">3</td>
                <td>京沪 400G SRv6 主干光缆</td>
                <td>10.240.0.1 &rarr; 10.240.0.2</td>
                <td>14.2 ms</td>
                <td><span class="text-emerald-400 font-bold">OK</span></td>
              </tr>
              <tr class="text-slate-200">
                <td class="py-2 text-cyan-400 font-bold">4</td>
                <td>上海金融 DC Core Switch HW-CE-SH-01</td>
                <td>10.240.20.2 (400GE1/0/1)</td>
                <td>0.1 ms</td>
                <td><span class="text-emerald-400 font-bold">OK</span></td>
              </tr>
              <tr class="text-slate-200">
                <td class="py-2 text-cyan-400 font-bold">5</td>
                <td>上海金融服务器 SRV-SH-01</td>
                <td>192.168.20.18 (ETH0)</td>
                <td>0.3 ms</td>
                <td><span class="text-emerald-400 font-bold">OK</span></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class PathTracerViewComponent {
  public twin = inject(DigitalTwin);
  public selectedUserId = signal<string>('USR-FIN-INST');

  public totalLatency = () => {
    return this.twin.activeScenario() === 'FiberCut' ? '39.3' : '14.9';
  };

  public onUserChange(e: Event) {
    this.selectedUserId.set((e.target as HTMLSelectElement).value);
  }
}
