import { Component, ChangeDetectionStrategy, inject, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwin } from '../../services/digital-twin';

@Component({
  selector: 'app-header-top-bar',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="h-16 bg-slate-950 border-b border-slate-800/80 px-4 flex items-center justify-between text-slate-200 select-none shadow-md z-30 relative">
      <!-- Left: Logo & Platform Identity -->
      <div class="flex items-center space-x-3">
        <div class="w-9 h-9 rounded-lg bg-gradient-to-br from-emerald-500 via-teal-600 to-cyan-700 flex items-center justify-center shadow-lg shadow-emerald-950/50 border border-emerald-400/30">
          <mat-icon class="text-white !w-6 !h-6 !text-[24px]">hub</mat-icon>
        </div>
        <div>
          <div class="flex items-center space-x-2">
            <span class="font-mono font-black text-lg tracking-wider text-white">HORIZON<span class="text-emerald-400 ml-1">ICT OS</span></span>
            <span class="px-1.5 py-0.5 text-[10px] font-semibold bg-emerald-950/80 text-emerald-300 border border-emerald-500/30 rounded">v3.6 ULTRA</span>
          </div>
          <p class="text-[11px] text-slate-400 font-sans tracking-wide">全域智能ICT数字孪生平台 | Huawei-Grade Engineering Architecture</p>
        </div>
      </div>

      <!-- Center: Key Executive Telemetry Bar -->
      <div class="hidden lg:flex items-center space-x-6 text-xs font-mono bg-slate-900/90 px-4 py-1.5 rounded-xl border border-slate-800/90">
        <!-- Status -->
        <div class="flex items-center space-x-2">
          <div class="w-2 h-2 rounded-full animate-ping" [ngClass]="twin.alarms().length > 1 ? 'bg-amber-400' : 'bg-emerald-400'"></div>
          <span class="text-slate-400">NETWORK:</span>
          <span class="font-bold" [ngClass]="twin.alarms().length > 1 ? 'text-amber-400' : 'text-emerald-400'">
            {{ twin.alarms().length > 1 ? '94.2% DEGRADED' : '99.98% HEALTHY' }}
          </span>
        </div>

        <div class="h-3 w-px bg-slate-800"></div>

        <!-- Alarms -->
        <div class="flex items-center space-x-1.5">
          <mat-icon class="!w-4 !h-4 !text-[16px]" [ngClass]="twin.alarms().length > 0 ? 'text-rose-400' : 'text-slate-400'">
            {{ twin.alarms().length > 0 ? 'warning' : 'check_circle' }}
          </mat-icon>
          <span class="text-slate-400">ALARMS:</span>
          <span class="font-bold text-white">{{ twin.alarms().length }}</span>
        </div>

        <div class="h-3 w-px bg-slate-800"></div>

        <!-- Data Centers & PUE -->
        <div class="flex items-center space-x-1.5">
          <mat-icon class="text-cyan-400 !w-4 !h-4 !text-[16px]">dns</mat-icon>
          <span class="text-slate-400">PUE:</span>
          <span class="font-bold text-cyan-300">1.17</span>
        </div>

        <div class="h-3 w-px bg-slate-800"></div>

        <!-- 5G Slices -->
        <div class="flex items-center space-x-1.5">
          <mat-icon class="text-violet-400 !w-4 !h-4 !text-[16px]">cell_tower</mat-icon>
          <span class="text-slate-400">5G SLICES:</span>
          <span class="font-bold text-violet-300">12 ACTIVE</span>
        </div>

        <div class="h-3 w-px bg-slate-800"></div>

        <!-- Mode Indicator -->
        <div class="flex items-center space-x-1 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
          <span class="text-[10px] text-slate-400">SCENARIO:</span>
          <span class="text-[11px] font-bold" [ngClass]="twin.activeScenario() === 'Normal' ? 'text-emerald-400' : 'text-rose-400'">
            {{ twin.activeScenario() }}
          </span>
        </div>
      </div>

      <!-- Right: Primary View Switcher & AI Toggle -->
      <div class="flex items-center space-x-2">
        <!-- View switch buttons -->
        <div class="flex bg-slate-900 p-1 rounded-xl border border-slate-800/80 text-xs font-medium">
          <button
            (click)="twin.activeView.set('3d-map')"
            [class.bg-emerald-600]="twin.activeView() === '3d-map'"
            [class.text-white]="twin.activeView() === '3d-map'"
            class="px-2.5 py-1 rounded-lg text-slate-400 hover:text-white transition flex items-center space-x-1"
          >
            <mat-icon class="!w-4 !h-4 !text-[16px]">public</mat-icon>
            <span class="hidden md:inline">3D数字地图</span>
          </button>

          <button
            (click)="twin.activeView.set('topology')"
            [class.bg-emerald-600]="twin.activeView() === 'topology'"
            [class.text-white]="twin.activeView() === 'topology'"
            class="px-2.5 py-1 rounded-lg text-slate-400 hover:text-white transition flex items-center space-x-1"
          >
            <mat-icon class="!w-4 !h-4 !text-[16px]">schema</mat-icon>
            <span class="hidden md:inline">端口拓扑</span>
          </button>

          <button
            (click)="twin.activeView.set('dc-twin')"
            [class.bg-emerald-600]="twin.activeView() === 'dc-twin'"
            [class.text-white]="twin.activeView() === 'dc-twin'"
            class="px-2.5 py-1 rounded-lg text-slate-400 hover:text-white transition flex items-center space-x-1"
          >
            <mat-icon class="!w-4 !h-4 !text-[16px]">view_in_ar</mat-icon>
            <span class="hidden md:inline">DC机架</span>
          </button>

          <button
            (click)="twin.activeView.set('sandbox')"
            [class.bg-emerald-600]="twin.activeView() === 'sandbox'"
            [class.text-white]="twin.activeView() === 'sandbox'"
            class="px-2.5 py-1 rounded-lg text-slate-400 hover:text-white transition flex items-center space-x-1"
          >
            <mat-icon class="!w-4 !h-4 !text-[16px]">science</mat-icon>
            <span class="hidden md:inline">沙盒演练</span>
          </button>
        </div>

        <!-- AI Assistant Drawer Button -->
        <button
          (click)="toggleAiDrawer.emit()"
          class="flex items-center space-x-1.5 px-3 py-1.5 bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white rounded-xl text-xs font-semibold shadow-lg shadow-emerald-950/40 border border-emerald-400/30 transition transform active:scale-95"
        >
          <mat-icon class="!w-4 !h-4 !text-[16px] animate-pulse">auto_awesome</mat-icon>
          <span>AI 运维助手</span>
        </button>
      </div>
    </header>
  `
})
export class HeaderTopBarComponent {
  public twin = inject(DigitalTwin);
  public toggleAiDrawer = output<void>();
}
