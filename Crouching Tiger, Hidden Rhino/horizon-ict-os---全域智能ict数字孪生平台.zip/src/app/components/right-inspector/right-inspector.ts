import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwin } from '../../services/digital-twin';

@Component({
  selector: 'app-right-inspector',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <aside class="w-96 bg-slate-950/95 border-l border-slate-800/80 flex flex-col h-full text-slate-200 select-none shadow-2xl backdrop-blur-md z-20">
      @if (twin.selectedEntityObject(); as sel) {
        <!-- Inspector Top Header -->
        <div class="p-4 border-b border-slate-800/80 bg-slate-900/50 space-y-2">
          <div class="flex items-center justify-between">
            <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase tracking-wider"
              [ngClass]="{
                'bg-blue-950 text-blue-300 border border-blue-500/40': sel.type === 'equipment',
                'bg-cyan-950 text-cyan-300 border border-cyan-500/40': sel.type === 'network',
                'bg-emerald-950 text-emerald-300 border border-emerald-500/40': sel.type === 'service',
                'bg-violet-950 text-violet-300 border border-violet-500/40': sel.type === 'user',
                'bg-amber-950 text-amber-300 border border-amber-500/40': sel.type === 'intent',
                'bg-slate-800 text-slate-200': sel.type === 'datacenter' || sel.type === 'rack'
              }"
            >
              {{ sel.type }} TWIN
            </span>
            <span class="text-[10px] font-mono text-slate-500">ID: {{ sel.data.id }}</span>
          </div>

          <h3 class="text-base font-bold text-white leading-tight">
            {{ 'name' in sel.data ? sel.data.name : ('title' in sel.data ? sel.data.title : sel.data.id) }}
          </h3>

          <div class="flex items-center space-x-2 text-xs font-mono text-slate-400">
            @if ('status' in sel.data) {
              <span class="flex items-center space-x-1">
                <span class="w-2 h-2 rounded-full" [ngClass]="sel.data.status === 'healthy' ? 'bg-emerald-400' : 'bg-rose-400'"></span>
                <span [ngClass]="sel.data.status === 'healthy' ? 'text-emerald-400' : 'text-rose-400'" class="font-bold">
                  {{ sel.data.status | uppercase }}
                </span>
              </span>
            }
            @if ('ipAddress' in sel.data) {
              <span>• IP: <span class="text-slate-200">{{ sel.data.ipAddress }}</span></span>
            }
          </div>
        </div>

        <!-- Inspector Scroll Body -->
        <div class="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-5">

          <!-- Telemetry Live Gauges for Equipment -->
          @if (sel.type === 'equipment') {
            <div class="bg-slate-900/60 border border-slate-800 rounded-xl p-3 space-y-3">
              <span class="text-xs font-bold text-slate-300 flex items-center space-x-1">
                <mat-icon class="text-cyan-400 !w-4 !h-4 !text-[16px]">speed</mat-icon>
                <span>设备硬件指标 (Telemetry Gauges)</span>
              </span>

              <div class="grid grid-cols-2 gap-2 text-xs font-mono">
                <div class="bg-slate-950 p-2 rounded border border-slate-800/80">
                  <span class="text-slate-400 text-[10px]">CPU 利用率:</span>
                  <p class="text-base font-bold text-emerald-400 mt-0.5">{{ sel.data.cpuUsagePct }}%</p>
                  <div class="w-full bg-slate-800 h-1 rounded mt-1 overflow-hidden">
                    <div class="bg-emerald-400 h-full" [style.width.%]="sel.data.cpuUsagePct"></div>
                  </div>
                </div>

                <div class="bg-slate-950 p-2 rounded border border-slate-800/80">
                  <span class="text-slate-400 text-[10px]">内存利用率:</span>
                  <p class="text-base font-bold text-cyan-400 mt-0.5">{{ sel.data.memoryUsagePct }}%</p>
                  <div class="w-full bg-slate-800 h-1 rounded mt-1 overflow-hidden">
                    <div class="bg-cyan-400 h-full" [style.width.%]="sel.data.memoryUsagePct"></div>
                  </div>
                </div>

                <div class="bg-slate-950 p-2 rounded border border-slate-800/80">
                  <span class="text-slate-400 text-[10px]">板卡温度:</span>
                  <p class="text-base font-bold text-amber-400 mt-0.5">{{ sel.data.temperatureC }}°C</p>
                </div>

                <div class="bg-slate-950 p-2 rounded border border-slate-800/80">
                  <span class="text-slate-400 text-[10px]">实时功耗:</span>
                  <p class="text-base font-bold text-violet-400 mt-0.5">{{ sel.data.powerKw }} kW</p>
                </div>
              </div>
            </div>

            <!-- Ports List -->
            @if (sel.data.ports && sel.data.ports.length) {
              <div class="bg-slate-900/60 border border-slate-800 rounded-xl p-3 space-y-2">
                <span class="text-xs font-bold text-slate-300 flex items-center space-x-1">
                  <mat-icon class="text-blue-400 !w-4 !h-4 !text-[16px]">settings_ethernet</mat-icon>
                  <span>端口矩阵 (Interfaces & Ports)</span>
                </span>

                <div class="space-y-1.5 font-mono text-[11px]">
                  @for (p of sel.data.ports; track p.id) {
                    <div class="p-2 bg-slate-950 rounded border border-slate-800/80 flex items-center justify-between">
                      <div>
                        <p class="text-slate-200 font-bold">{{ p.name }}</p>
                        <p class="text-[10px] text-slate-500">{{ p.speed }} • {{ p.type }}</p>
                      </div>
                      <div class="text-right">
                        <span class="text-emerald-400 font-bold">{{ (p.txRateMbps/1000).toFixed(1) }} Gbps</span>
                        <p class="text-[9px] text-slate-500">Loss: {{ p.packetLossRate }}%</p>
                      </div>
                    </div>
                  }
                </div>
              </div>
            }
          }

          <!-- Network Link Inspector -->
          @if (sel.type === 'network') {
            <div class="bg-slate-900/60 border border-slate-800 rounded-xl p-3 space-y-3 font-mono text-xs">
              <span class="text-xs font-bold text-cyan-400 flex items-center space-x-1">
                <mat-icon class="!w-4 !h-4 !text-[16px]">cable</mat-icon>
                <span>网络链路指标</span>
              </span>

              <div class="space-y-2 bg-slate-950 p-2.5 rounded border border-slate-800/80">
                <div class="flex justify-between">
                  <span class="text-slate-400">链路类型:</span>
                  <span class="text-white font-bold">{{ sel.data.type }}</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-slate-400">带宽规格:</span>
                  <span class="text-cyan-300 font-bold">{{ sel.data.bandwidthGbps }} Gbps</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-slate-400">当前利用率:</span>
                  <span class="text-emerald-400 font-bold">{{ sel.data.currentUtilizationPct }}%</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-slate-400">光缆物理距离:</span>
                  <span class="text-slate-200">{{ sel.data.fiberDistanceKm }} km</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-slate-400">传输延迟:</span>
                  <span class="text-amber-400 font-bold">{{ sel.data.latencyMs }} ms</span>
                </div>
              </div>
            </div>
          }

          <!-- Upstream / Downstream 5-Layer Dependency Tree -->
          <div class="bg-slate-900/60 border border-slate-800 rounded-xl p-3 space-y-2">
            <span class="text-xs font-bold text-emerald-400 flex items-center space-x-1">
              <mat-icon class="!w-4 !h-4 !text-[16px]">account_tree</mat-icon>
              <span>5层图依赖关联链 (Dependency Chain)</span>
            </span>

            <div class="p-2.5 bg-slate-950 rounded border border-slate-800/80 font-mono text-xs space-y-2">
              <div class="flex items-center space-x-2 text-slate-300">
                <span class="w-2 h-2 rounded-full bg-blue-400"></span>
                <span>核心设备: <strong class="text-white">HW-CR-BJ-01</strong></span>
              </div>
              <div class="pl-3 border-l border-slate-800 space-y-1.5 text-[11px] text-slate-400">
                <div>&darr; 400G 光缆: <span class="text-cyan-300">LINK-BJ-SH-400G-A</span></div>
                <div>&darr; 业务层: <span class="text-emerald-300">极速金融交易 VPN (SVC-FIN-01)</span></div>
                <div>&darr; 应用集群: <span class="text-violet-300">核心高频结算系统 (FinCore-v4)</span></div>
                <div>&darr; 终点用户: <span class="text-amber-300">陆家嘴 3,200 名交易终端</span></div>
              </div>
            </div>
          </div>

          <!-- Quick Actions -->
          <div class="space-y-2 pt-2">
            <button
              (click)="twin.activeView.set('sandbox')"
              class="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold font-mono transition shadow-lg shadow-emerald-950/50 flex items-center justify-center space-x-1"
            >
              <mat-icon class="!w-4 !h-4 !text-[16px]">science</mat-icon>
              <span>在此节点触发闭环演练 (Sandbox)</span>
            </button>
            <button
              (click)="twin.activeView.set('path-tracer')"
              class="w-full py-2 bg-slate-900 border border-slate-700 hover:bg-slate-800 text-slate-200 rounded-xl text-xs font-semibold font-mono transition flex items-center justify-center space-x-1"
            >
              <mat-icon class="!w-4 !h-4 !text-[16px]">route</mat-icon>
              <span>追踪全程端到端路径 (Path Tracer)</span>
            </button>
          </div>

        </div>
      } @else {
        <div class="flex-1 flex flex-col items-center justify-center p-6 text-center text-slate-500 space-y-2">
          <mat-icon class="!w-12 !h-12 !text-[48px] text-slate-700">touch_app</mat-icon>
          <p class="text-xs font-mono">点击 3D 数字地图、拓扑图或树节点查看 5 层数字孪生对象</p>
        </div>
      }
    </aside>
  `
})
export class RightInspectorComponent {
  public twin = inject(DigitalTwin);
}
