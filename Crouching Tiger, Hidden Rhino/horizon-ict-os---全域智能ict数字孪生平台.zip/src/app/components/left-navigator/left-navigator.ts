import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwin } from '../../services/digital-twin';
import { LayerType } from '../../models/digital-twin.model';

@Component({
  selector: 'app-left-navigator',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <aside class="w-80 bg-slate-950/95 border-r border-slate-800/80 flex flex-col h-full text-slate-200 select-none shadow-xl backdrop-blur-md z-20">
      <!-- Search & Quick Navigation Header -->
      <div class="p-3 border-b border-slate-800/80 bg-slate-900/50 space-y-2">
        <div class="flex items-center justify-between text-xs font-semibold text-slate-400">
          <span class="flex items-center space-x-1">
            <mat-icon class="!w-4 !h-4 !text-[16px] text-emerald-400">account_tree</mat-icon>
            <span>五层数字孪生拓扑树</span>
          </span>
          <span class="text-[10px] font-mono text-slate-500">5-LAYER GRAPH</span>
        </div>

        <!-- Search Input -->
        <div class="relative">
          <input
            type="text"
            [value]="searchQuery()"
            (input)="onSearchInput($event)"
            placeholder="搜索设备, IP, 400G光缆, 5G切片..."
            class="w-full bg-slate-900 border border-slate-800 rounded-lg py-1.5 pl-8 pr-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500/80 transition"
          />
          <mat-icon class="absolute left-2 top-2 text-slate-500 !w-4 !h-4 !text-[16px]">search</mat-icon>
        </div>

        <!-- City Quick Filter Tabs -->
        <div class="grid grid-cols-4 gap-1 text-[11px] font-medium pt-1">
          <button
            (click)="selectedCityFilter.set('All')"
            [class.bg-emerald-950]="selectedCityFilter() === 'All'"
            [class.text-emerald-300]="selectedCityFilter() === 'All'"
            [class.border-emerald-500/50]="selectedCityFilter() === 'All'"
            class="py-1 rounded border border-slate-800 text-center text-slate-400 hover:text-white transition"
          >
            全部 (ALL)
          </button>
          <button
            (click)="selectedCityFilter.set('Beijing')"
            [class.bg-emerald-950]="selectedCityFilter() === 'Beijing'"
            [class.text-emerald-300]="selectedCityFilter() === 'Beijing'"
            [class.border-emerald-500/50]="selectedCityFilter() === 'Beijing'"
            class="py-1 rounded border border-slate-800 text-center text-slate-400 hover:text-white transition"
          >
            北京
          </button>
          <button
            (click)="selectedCityFilter.set('Shanghai')"
            [class.bg-emerald-950]="selectedCityFilter() === 'Shanghai'"
            [class.text-emerald-300]="selectedCityFilter() === 'Shanghai'"
            [class.border-emerald-500/50]="selectedCityFilter() === 'Shanghai'"
            class="py-1 rounded border border-slate-800 text-center text-slate-400 hover:text-white transition"
          >
            上海
          </button>
          <button
            (click)="selectedCityFilter.set('Shenzhen')"
            [class.bg-emerald-950]="selectedCityFilter() === 'Shenzhen'"
            [class.text-emerald-300]="selectedCityFilter() === 'Shenzhen'"
            [class.border-emerald-500/50]="selectedCityFilter() === 'Shenzhen'"
            class="py-1 rounded border border-slate-800 text-center text-slate-400 hover:text-white transition"
          >
            深圳
          </button>
        </div>
      </div>

      <!-- 5 Connected Layers Accordion Tree -->
      <div class="flex-1 overflow-y-auto custom-scrollbar p-2 space-y-3">

        <!-- Layer 1: Equipment (物理设备) -->
        <div class="border border-slate-800/80 rounded-xl overflow-hidden bg-slate-900/30">
          <button
            (click)="toggleLayer('equipment')"
            class="w-full px-3 py-2 bg-slate-900/80 hover:bg-slate-800/80 flex items-center justify-between text-xs font-semibold text-slate-200 transition"
          >
            <div class="flex items-center space-x-2">
              <mat-icon class="text-blue-400 !w-4 !h-4 !text-[16px]">router</mat-icon>
              <span>Layer 1 — 物理设备 (Equipment)</span>
            </div>
            <div class="flex items-center space-x-1 font-mono text-[11px] text-slate-400">
              <span class="bg-blue-950 text-blue-300 px-1.5 py-0.2 rounded border border-blue-500/30">{{ twin.equipment().length }}</span>
              <mat-icon class="!w-4 !h-4 !text-[16px]">{{ isExpanded('equipment') ? 'expand_less' : 'expand_more' }}</mat-icon>
            </div>
          </button>

          @if (isExpanded('equipment')) {
            <div class="p-1.5 space-y-1">
              @for (item of filteredEquipment(); track item.id) {
                <button
                  type="button"
                  (click)="twin.selectEntity(item.id, 'equipment')"
                  [class.bg-blue-950/80]="twin.selectedEntityId() === item.id"
                  [class.border-blue-500/50]="twin.selectedEntityId() === item.id"
                  [class.ring-1]="twin.highlightedEntityIds().has(item.id) && twin.selectedEntityId() !== item.id"
                  [class.ring-emerald-500]="twin.highlightedEntityIds().has(item.id)"
                  class="w-full text-left p-2 rounded-lg border border-slate-800/60 hover:border-slate-700 bg-slate-950/60 cursor-pointer transition flex items-center justify-between"
                >
                  <div class="flex items-center space-x-2 min-w-0">
                    <mat-icon class="!w-4 !h-4 !text-[16px]" [ngClass]="item.status === 'healthy' ? 'text-blue-400' : 'text-rose-400'">
                      {{ item.type === 'router' ? 'router' : item.type === 'optical' ? 'memory' : item.type === 'base_station' ? 'cell_tower' : 'dns' }}
                    </mat-icon>
                    <div class="truncate">
                      <p class="text-xs font-semibold text-slate-100 truncate">{{ item.name }}</p>
                      <p class="text-[10px] font-mono text-slate-400">{{ item.ipAddress }} • {{ item.location.city }}</p>
                    </div>
                  </div>
                  <div class="text-right font-mono text-[10px]">
                    <span [ngClass]="item.status === 'healthy' ? 'text-emerald-400' : 'text-rose-400'" class="font-bold">
                      CPU {{ item.cpuUsagePct }}%
                    </span>
                  </div>
                </button>
              }
            </div>
          }
        </div>

        <!-- Layer 2: Network Links (网络链路) -->
        <div class="border border-slate-800/80 rounded-xl overflow-hidden bg-slate-900/30">
          <button
            (click)="toggleLayer('network')"
            class="w-full px-3 py-2 bg-slate-900/80 hover:bg-slate-800/80 flex items-center justify-between text-xs font-semibold text-slate-200 transition"
          >
            <div class="flex items-center space-x-2">
              <mat-icon class="text-cyan-400 !w-4 !h-4 !text-[16px]">cable</mat-icon>
              <span>Layer 2 — 网络拓扑 (Network Links)</span>
            </div>
            <div class="flex items-center space-x-1 font-mono text-[11px] text-slate-400">
              <span class="bg-cyan-950 text-cyan-300 px-1.5 py-0.2 rounded border border-cyan-500/30">{{ twin.links().length }}</span>
              <mat-icon class="!w-4 !h-4 !text-[16px]">{{ isExpanded('network') ? 'expand_less' : 'expand_more' }}</mat-icon>
            </div>
          </button>

          @if (isExpanded('network')) {
            <div class="p-1.5 space-y-1">
              @for (link of filteredLinks(); track link.id) {
                <button
                  type="button"
                  (click)="twin.selectEntity(link.id, 'network')"
                  [class.bg-cyan-950/80]="twin.selectedEntityId() === link.id"
                  [class.border-cyan-500/50]="twin.selectedEntityId() === link.id"
                  [class.ring-1]="twin.highlightedEntityIds().has(link.id) && twin.selectedEntityId() !== link.id"
                  [class.ring-emerald-500]="twin.highlightedEntityIds().has(link.id)"
                  class="w-full text-left p-2 rounded-lg border border-slate-800/60 hover:border-slate-700 bg-slate-950/60 cursor-pointer transition flex items-center justify-between"
                >
                  <div class="flex items-center space-x-2 min-w-0">
                    <mat-icon class="!w-4 !h-4 !text-[16px]" [ngClass]="link.status === 'healthy' ? 'text-cyan-400' : 'text-rose-400'">
                      linear_scale
                    </mat-icon>
                    <div class="truncate">
                      <p class="text-xs font-semibold text-slate-100 truncate">{{ link.name }}</p>
                      <p class="text-[10px] font-mono text-slate-400">{{ link.bandwidthGbps }}G {{ link.type }} • {{ link.latencyMs }}ms</p>
                    </div>
                  </div>
                  <span class="text-[10px] font-mono px-1.5 py-0.5 rounded font-bold" [ngClass]="link.status === 'healthy' ? 'bg-emerald-950 text-emerald-400' : 'bg-rose-950 text-rose-400'">
                    {{ link.currentUtilizationPct }}%
                  </span>
                </button>
              }
            </div>
          }
        </div>

        <!-- Layer 3: Services & Applications (业务与应用) -->
        <div class="border border-slate-800/80 rounded-xl overflow-hidden bg-slate-900/30">
          <button
            (click)="toggleLayer('service')"
            class="w-full px-3 py-2 bg-slate-900/80 hover:bg-slate-800/80 flex items-center justify-between text-xs font-semibold text-slate-200 transition"
          >
            <div class="flex items-center space-x-2">
              <mat-icon class="text-emerald-400 !w-4 !h-4 !text-[16px]">apps</mat-icon>
              <span>Layer 3 — 业务与应用 (Service & App)</span>
            </div>
            <div class="flex items-center space-x-1 font-mono text-[11px] text-slate-400">
              <span class="bg-emerald-950 text-emerald-300 px-1.5 py-0.2 rounded border border-emerald-500/30">{{ twin.services().length }}</span>
              <mat-icon class="!w-4 !h-4 !text-[16px]">{{ isExpanded('service') ? 'expand_less' : 'expand_more' }}</mat-icon>
            </div>
          </button>

          @if (isExpanded('service')) {
            <div class="p-1.5 space-y-1">
              @for (svc of twin.services(); track svc.id) {
                <button
                  type="button"
                  (click)="twin.selectEntity(svc.id, 'service')"
                  [class.bg-emerald-950/80]="twin.selectedEntityId() === svc.id"
                  [class.border-emerald-500/50]="twin.selectedEntityId() === svc.id"
                  [class.ring-1]="twin.highlightedEntityIds().has(svc.id) && twin.selectedEntityId() !== svc.id"
                  [class.ring-emerald-500]="twin.highlightedEntityIds().has(svc.id)"
                  class="w-full text-left p-2 rounded-lg border border-slate-800/60 hover:border-slate-700 bg-slate-950/60 cursor-pointer transition flex items-center justify-between"
                >
                  <div class="flex items-center space-x-2 min-w-0">
                    <mat-icon class="!w-4 !h-4 !text-[16px]" [ngClass]="svc.status === 'healthy' ? 'text-emerald-400' : 'text-amber-400'">
                      cloud_done
                    </mat-icon>
                    <div class="truncate">
                      <p class="text-xs font-semibold text-slate-100 truncate">{{ svc.name }}</p>
                      <p class="text-[10px] font-mono text-slate-400">SLA {{ svc.slaTargetAvailability }}% • {{ svc.currentLatencyMs }}ms</p>
                    </div>
                  </div>
                  <span class="text-[10px] font-mono text-emerald-400 font-bold">
                    {{ svc.subscriberCount }} 用户
                  </span>
                </button>
              }
            </div>
          }
        </div>

        <!-- Layer 4: Users (用户体验) -->
        <div class="border border-slate-800/80 rounded-xl overflow-hidden bg-slate-900/30">
          <button
            (click)="toggleLayer('user')"
            class="w-full px-3 py-2 bg-slate-900/80 hover:bg-slate-800/80 flex items-center justify-between text-xs font-semibold text-slate-200 transition"
          >
            <div class="flex items-center space-x-2">
              <mat-icon class="text-violet-400 !w-4 !h-4 !text-[16px]">groups</mat-icon>
              <span>Layer 4 — 用户视角 (Users & QoE)</span>
            </div>
            <div class="flex items-center space-x-1 font-mono text-[11px] text-slate-400">
              <span class="bg-violet-950 text-violet-300 px-1.5 py-0.2 rounded border border-violet-500/30">{{ twin.users().length }}</span>
              <mat-icon class="!w-4 !h-4 !text-[16px]">{{ isExpanded('user') ? 'expand_less' : 'expand_more' }}</mat-icon>
            </div>
          </button>

          @if (isExpanded('user')) {
            <div class="p-1.5 space-y-1">
              @for (usr of twin.users(); track usr.id) {
                <button
                  type="button"
                  (click)="twin.selectEntity(usr.id, 'user')"
                  [class.bg-violet-950/80]="twin.selectedEntityId() === usr.id"
                  [class.border-violet-500/50]="twin.selectedEntityId() === usr.id"
                  [class.ring-1]="twin.highlightedEntityIds().has(usr.id) && twin.selectedEntityId() !== usr.id"
                  [class.ring-emerald-500]="twin.highlightedEntityIds().has(usr.id)"
                  class="w-full text-left p-2 rounded-lg border border-slate-800/60 hover:border-slate-700 bg-slate-950/60 cursor-pointer transition flex items-center justify-between"
                >
                  <div class="flex items-center space-x-2 min-w-0">
                    <mat-icon class="text-violet-400 !w-4 !h-4 !text-[16px]">person_pin</mat-icon>
                    <div class="truncate">
                      <p class="text-xs font-semibold text-slate-100 truncate">{{ usr.name }}</p>
                      <p class="text-[10px] font-mono text-slate-400">{{ usr.count }} 人 • {{ usr.city }}</p>
                    </div>
                  </div>
                  <span class="text-[10px] font-mono text-violet-300 font-bold bg-violet-950 px-1.5 py-0.5 rounded">
                    QoE {{ usr.experienceScore }}
                  </span>
                </button>
              }
            </div>
          }
        </div>

        <!-- Layer 5: Business Intent (业务意图) -->
        <div class="border border-slate-800/80 rounded-xl overflow-hidden bg-slate-900/30">
          <button
            (click)="toggleLayer('intent')"
            class="w-full px-3 py-2 bg-slate-900/80 hover:bg-slate-800/80 flex items-center justify-between text-xs font-semibold text-slate-200 transition"
          >
            <div class="flex items-center space-x-2">
              <mat-icon class="text-amber-400 !w-4 !h-4 !text-[16px]">flag</mat-icon>
              <span>Layer 5 — 业务意图 (Business Intent)</span>
            </div>
            <div class="flex items-center space-x-1 font-mono text-[11px] text-slate-400">
              <span class="bg-amber-950 text-amber-300 px-1.5 py-0.2 rounded border border-amber-500/30">{{ twin.intents().length }}</span>
              <mat-icon class="!w-4 !h-4 !text-[16px]">{{ isExpanded('intent') ? 'expand_less' : 'expand_more' }}</mat-icon>
            </div>
          </button>

          @if (isExpanded('intent')) {
            <div class="p-1.5 space-y-1">
              @for (intent of twin.intents(); track intent.id) {
                <button
                  type="button"
                  (click)="twin.selectEntity(intent.id, 'intent')"
                  [class.bg-amber-950/80]="twin.selectedEntityId() === intent.id"
                  [class.border-amber-500/50]="twin.selectedEntityId() === intent.id"
                  [class.ring-1]="twin.highlightedEntityIds().has(intent.id) && twin.selectedEntityId() !== intent.id"
                  [class.ring-emerald-500]="twin.highlightedEntityIds().has(intent.id)"
                  class="w-full text-left p-2 rounded-lg border border-slate-800/60 hover:border-slate-700 bg-slate-950/60 cursor-pointer transition"
                >
                  <div class="flex items-center justify-between">
                    <span class="text-xs font-semibold text-amber-200 truncate">{{ intent.title }}</span>
                    <span class="text-[9px] font-mono px-1 rounded bg-amber-950 text-amber-300 border border-amber-500/30">
                      {{ intent.priority }}
                    </span>
                  </div>
                  <p class="text-[10px] text-slate-400 mt-1 truncate font-mono">
                    目标: &lt;{{ intent.requiredLatencyMs }}ms • SLA {{ intent.requiredAvailability }}%
                  </p>
                </button>
              }
            </div>
          }
        </div>

      </div>

      <!-- Quick Data Center Sites Footer -->
      <div class="p-2.5 border-t border-slate-800/80 bg-slate-900/60 text-xs">
        <div class="flex items-center justify-between text-slate-400 mb-1.5">
          <span class="font-semibold text-[11px] flex items-center space-x-1">
            <mat-icon class="text-cyan-400 !w-3.5 !h-3.5 !text-[14px]">location_city</mat-icon>
            <span>数据中心站点 (Datacenters)</span>
          </span>
          <span class="text-[10px] font-mono text-emerald-400">10/10 ONLINE</span>
        </div>
        <div class="grid grid-cols-2 gap-1 font-mono text-[10px]">
          @for (dc of twin.datacenters(); track dc.id) {
            <button
              (click)="twin.selectEntity(dc.id, 'datacenter')"
              class="px-2 py-1 bg-slate-950 border border-slate-800 hover:border-slate-700 rounded text-left truncate text-slate-300 hover:text-white flex items-center justify-between transition"
            >
              <span class="truncate">{{ dc.name.split(' ')[0] }}</span>
              <span class="text-emerald-400 ml-1">PUE {{ dc.pueScore }}</span>
            </button>
          }
        </div>
      </div>
    </aside>
  `
})
export class LeftNavigatorComponent {
  public twin = inject(DigitalTwin);

  public searchQuery = signal<string>('');
  public selectedCityFilter = signal<'All' | 'Beijing' | 'Shanghai' | 'Shenzhen'>('All');

  private expandedLayers = signal<Record<LayerType, boolean>>({
    equipment: true,
    network: true,
    service: true,
    user: false,
    intent: false
  });

  public isExpanded(layer: LayerType): boolean {
    return this.expandedLayers()[layer];
  }

  public toggleLayer(layer: LayerType) {
    this.expandedLayers.update(prev => ({ ...prev, [layer]: !prev[layer] }));
  }

  public onSearchInput(event: Event) {
    const val = (event.target as HTMLInputElement).value;
    this.searchQuery.set(val);
  }

  public filteredEquipment() {
    const q = this.searchQuery().toLowerCase();
    const city = this.selectedCityFilter();
    return this.twin.equipment().filter(e => {
      const matchCity = city === 'All' || e.location.city === city;
      const matchQ = !q || e.name.toLowerCase().includes(q) || e.ipAddress.includes(q) || e.model.toLowerCase().includes(q);
      return matchCity && matchQ;
    });
  }

  public filteredLinks() {
    const q = this.searchQuery().toLowerCase();
    return this.twin.links().filter(l => !q || l.name.toLowerCase().includes(q) || l.type.toLowerCase().includes(q));
  }
}
