import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwin } from '../../services/digital-twin';

@Component({
  selector: 'app-rack-3d-view',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full h-full bg-slate-950 p-6 overflow-y-auto text-slate-200 select-none">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
        <div>
          <h2 class="text-lg font-mono font-bold text-white flex items-center space-x-2">
            <mat-icon class="text-cyan-400 !w-6 !h-6 !text-[24px]">view_in_ar</mat-icon>
            <span>数据中心机架与服务器数字孪生 (Data Center Rack Twin)</span>
          </h2>
          <p class="text-xs text-slate-400 font-sans">精细化 1U - 42U 机架插槽功耗、温度、网络、服务器 VM 级下钻视界</p>
        </div>

        <div class="flex items-center space-x-2">
          @for (rack of twin.racks(); track rack.id) {
            <button
              (click)="selectedRackId.set(rack.id)"
              [class.bg-cyan-600]="selectedRackId() === rack.id"
              [class.text-white]="selectedRackId() === rack.id"
              class="px-3 py-1.5 bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-lg text-xs font-mono font-bold transition"
            >
              {{ rack.rackName }} ({{ rack.roomName }})
            </button>
          }
        </div>
      </div>

      <!-- Active Rack Detail Grid -->
      @if (activeRack(); as rack) {
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

          <!-- Left: 42U Rack Elevation Cabinet Model -->
          <div class="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 space-y-4">
            <div class="flex items-center justify-between border-b border-slate-800 pb-2 font-mono">
              <span class="text-xs font-bold text-cyan-400 flex items-center space-x-1">
                <mat-icon class="!w-4 !h-4 !text-[16px]">inventory_2</mat-icon>
                <span>42U 机架结构图 (RACK-ELEVATION)</span>
              </span>
              <span class="text-[11px] text-slate-400">{{ rack.rackName }}</span>
            </div>

            <!-- 42U Slots Elevation Representation -->
            <div class="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1 font-mono text-[10px]">
              <div class="p-1.5 bg-blue-950/80 border border-blue-500/50 rounded flex justify-between items-center text-blue-300 font-bold">
                <span>[42U - 41U] CloudEngine 16800 Core Switch</span>
                <span>STATUS: UP</span>
              </div>
              <div class="p-1.5 bg-slate-900 border border-slate-800 rounded text-slate-500 text-center">
                [38U - 40U] 冗余线缆理线架 (Cable Organizer)
              </div>
              <button
                type="button"
                (click)="selectedServerId.set('SRV-BJ-01')"
                [class.ring-2]="selectedServerId() === 'SRV-BJ-01'"
                [class.ring-cyan-400]="selectedServerId() === 'SRV-BJ-01'"
                class="w-full text-left p-2 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded flex justify-between items-center text-slate-200 cursor-pointer transition"
              >
                <div class="flex items-center space-x-2">
                  <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
                  <span class="font-bold text-xs text-white">[20U - 22U] SRV-BJ-01 Kunpeng 920 Server</span>
                </div>
                <span class="text-emerald-400 font-bold">45% CPU</span>
              </button>

              @for (u of [18, 16, 14, 12, 10, 8, 6, 4, 2]; track u) {
                <div class="p-1.5 bg-slate-900/50 border border-slate-800/60 rounded text-slate-400 flex justify-between items-center">
                  <span>[{{ u }}U - {{ u+1 }}U] Taishan 2280 Compute Blade</span>
                  <span class="text-emerald-400">NORMAL</span>
                </div>
              }

              <div class="p-1.5 bg-amber-950/80 border border-amber-500/50 rounded flex justify-between items-center text-amber-300 font-bold">
                <span>[1U] 智能智能 PDU 双路配电单元</span>
                <span>8.4 kW</span>
              </div>
            </div>
          </div>

          <!-- Middle: Rack Real-time Telemetry & Power -->
          <div class="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 space-y-4 font-mono">
            <div class="flex items-center justify-between border-b border-slate-800 pb-2">
              <span class="text-xs font-bold text-amber-400 flex items-center space-x-1">
                <mat-icon class="!w-4 !h-4 !text-[16px]">bolt</mat-icon>
                <span>机架配电与温控能效 (Power & Thermal)</span>
              </span>
              <span class="text-[10px] text-slate-400">PUE 1.18</span>
            </div>

            <div class="grid grid-cols-2 gap-3 text-xs">
              <div class="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <span class="text-slate-400 text-[10px]">当前机架功耗:</span>
                <p class="text-xl font-bold text-amber-400 mt-1">{{ rack.currentPowerKw }} kW</p>
                <p class="text-[10px] text-slate-500 mt-0.5">额定上限: {{ rack.maxPowerKw }} kW</p>
              </div>

              <div class="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <span class="text-slate-400 text-[10px]">机柜平均进风温度:</span>
                <p class="text-xl font-bold text-cyan-300 mt-1">{{ rack.temperatureC }} °C</p>
                <p class="text-[10px] text-emerald-400 mt-0.5">温控状态: {{ rack.coolingStatus }}</p>
              </div>

              <div class="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <span class="text-slate-400 text-[10px]">承载服务器:</span>
                <p class="text-xl font-bold text-white mt-1">{{ rack.serversCount }} 台</p>
              </div>

              <div class="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <span class="text-slate-400 text-[10px]">核心交换机:</span>
                <p class="text-xl font-bold text-blue-400 mt-1">{{ rack.switchesCount }} 台</p>
              </div>
            </div>

            <div class="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
              <span class="text-xs font-bold text-slate-300">智能液冷循环参数 (Liquid Cooling)</span>
              <div class="flex justify-between text-xs">
                <span class="text-slate-400">冷水进水温度:</span>
                <span class="text-cyan-300 font-bold">18.2 °C</span>
              </div>
              <div class="flex justify-between text-xs">
                <span class="text-slate-400">出水温度:</span>
                <span class="text-amber-400 font-bold">28.5 °C</span>
              </div>
            </div>
          </div>

          <!-- Right: Selected Server Inspector & Virtual Machines -->
          <div class="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 space-y-4 font-mono">
            <div class="flex items-center justify-between border-b border-slate-800 pb-2">
              <span class="text-xs font-bold text-violet-400 flex items-center space-x-1">
                <mat-icon class="!w-4 !h-4 !text-[16px]">dns</mat-icon>
                <span>服务器与虚拟机 Twins (SRV-BJ-01)</span>
              </span>
              <span class="text-[10px] text-emerald-400">HEALTHY</span>
            </div>

            <div class="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2 text-xs">
              <p class="font-bold text-white text-sm">Kunpeng 920 High Density Node</p>
              <p class="text-[11px] text-slate-400">IP: 192.168.10.12 • OS: EulerOS v2.10</p>

              <div class="pt-2 border-t border-slate-900 space-y-1">
                <div class="flex justify-between">
                  <span class="text-slate-400">物理 Core:</span>
                  <span class="text-white">128 vCPU</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-slate-400">RAM:</span>
                  <span class="text-white">512 GB DDR4</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-slate-400">承载应用:</span>
                  <span class="text-emerald-400 font-bold">全域智能企业协同 SaaS 集群</span>
                </div>
              </div>
            </div>

            <div class="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2 text-xs">
              <span class="text-xs font-bold text-violet-300">关联虚拟机 / 容器 (VMs & Pods)</span>
              <div class="space-y-1 text-[11px]">
                <div class="p-1.5 bg-slate-900 rounded flex justify-between text-slate-200">
                  <span>pod-horizon-saas-01</span>
                  <span class="text-emerald-400">RUNNING (12% CPU)</span>
                </div>
                <div class="p-1.5 bg-slate-900 rounded flex justify-between text-slate-200">
                  <span>vm-fin-settlement-worker</span>
                  <span class="text-emerald-400">RUNNING (28% CPU)</span>
                </div>
              </div>
            </div>
          </div>

        </div>
      }
    </div>
  `
})
export class Rack3dViewComponent {
  public twin = inject(DigitalTwin);
  public selectedRackId = signal<string>('RACK-BJ-A12');
  public selectedServerId = signal<string>('SRV-BJ-01');

  public activeRack = () => {
    return this.twin.racks().find(r => r.id === this.selectedRackId()) || this.twin.racks()[0];
  };
}
