import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwin } from '../../services/digital-twin';

@Component({
  selector: 'app-topology-view',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full h-full bg-slate-950 p-6 overflow-y-auto text-slate-200 select-none">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
        <div>
          <h2 class="text-lg font-mono font-bold text-white flex items-center space-x-2">
            <mat-icon class="text-cyan-400 !w-6 !h-6 !text-[24px]">schema</mat-icon>
            <span>端口级全网拓扑引擎 (Port-Level Topology Engine)</span>
          </h2>
          <p class="text-xs text-slate-400 font-sans">精确映射 Port GE0/1/0 &rarr; 400G 光纤通道 &rarr; Port GE0/1/0，支持 5 层图节点交互高亮</p>
        </div>

        <div class="flex items-center space-x-3 text-xs font-mono">
          <span class="px-3 py-1 bg-slate-900 border border-slate-800 rounded-lg text-emerald-400">
            TOTAL LINKS: {{ twin.links().length }}
          </span>
          <span class="px-3 py-1 bg-slate-900 border border-slate-800 rounded-lg text-cyan-400">
            TOTAL PORTS: 38 ACTIVE
          </span>
        </div>
      </div>

      <!-- Main Topology Port Connection Canvas Matrix -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

        <!-- Column 1: Core Routers & Ports -->
        <div class="bg-slate-900/60 border border-slate-800 rounded-2xl p-4 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2">
            <span class="text-xs font-bold text-blue-400 flex items-center space-x-1">
              <mat-icon class="!w-4 !h-4 !text-[16px]">router</mat-icon>
              <span>骨干核心路由器 (Core Routers)</span>
            </span>
            <span class="text-[10px] font-mono text-slate-500">LAYER 1 & 2</span>
          </div>

          @for (eq of twin.equipment(); track eq.id) {
            @if (eq.type === 'router') {
              <button
                type="button"
                (click)="twin.selectEntity(eq.id, 'equipment')"
                [class.border-blue-500]="twin.selectedEntityId() === eq.id"
                [class.bg-blue-950/40]="twin.selectedEntityId() === eq.id"
                class="w-full text-left bg-slate-950 border border-slate-800 hover:border-blue-500/60 p-3 rounded-xl transition cursor-pointer"
              >
                <div class="flex items-center justify-between">
                  <span class="text-xs font-bold text-white">{{ eq.name }}</span>
                  <span class="text-[10px] font-mono px-1.5 py-0.5 rounded bg-blue-950 text-blue-300 border border-blue-500/30">
                    {{ eq.ipAddress }}
                  </span>
                </div>

                <!-- Ports List -->
                <div class="mt-2.5 space-y-1.5">
                  @for (port of eq.ports; track port.id) {
                    <div class="p-2 bg-slate-900/90 rounded border border-slate-800/80 flex items-center justify-between text-[11px] font-mono">
                      <div class="flex items-center space-x-1.5">
                        <span class="w-2 h-2 rounded-full" [ngClass]="port.status === 'up' ? 'bg-emerald-400' : 'bg-rose-400'"></span>
                        <span class="text-slate-200 font-semibold">{{ port.name }}</span>
                      </div>
                      <div class="text-slate-400 text-[10px]">
                        {{ (port.txRateMbps / 1000).toFixed(1) }}G / {{ port.speed }}
                      </div>
                    </div>
                  }
                </div>
              </button>
            }
          }
        </div>

        <!-- Column 2: Port-to-Port Optical & Fiber Links -->
        <div class="bg-slate-900/60 border border-slate-800 rounded-2xl p-4 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2">
            <span class="text-xs font-bold text-cyan-400 flex items-center space-x-1">
              <mat-icon class="!w-4 !h-4 !text-[16px]">linear_scale</mat-icon>
              <span>光纤通道 (Optical Fiber Mesh)</span>
            </span>
            <span class="text-[10px] font-mono text-slate-500">400G OTN / SRv6</span>
          </div>

          @for (link of twin.links(); track link.id) {
            <button
              type="button"
              (click)="twin.selectEntity(link.id, 'network')"
              [class.border-cyan-500]="twin.selectedEntityId() === link.id"
              [class.bg-cyan-950/40]="twin.selectedEntityId() === link.id"
              class="w-full text-left bg-slate-950 border border-slate-800 hover:border-cyan-500/60 p-3 rounded-xl transition cursor-pointer relative"
            >
              <div class="flex items-center justify-between">
                <span class="text-xs font-bold text-slate-100">{{ link.name }}</span>
                <span
                  class="text-[10px] font-mono px-2 py-0.5 rounded font-bold"
                  [ngClass]="link.status === 'healthy' ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/30' : 'bg-rose-950 text-rose-400 border border-rose-500/30 animate-pulse'"
                >
                  {{ link.status === 'healthy' ? 'ACTIVE' : 'CRITICAL FAULT' }}
                </span>
              </div>

              <!-- Connection Diagram Visual -->
              <div class="my-3 p-2 bg-slate-900 rounded border border-slate-800/80 flex items-center justify-between text-[11px] font-mono">
                <div class="text-center">
                  <p class="text-slate-400 text-[10px]">{{ link.sourceDeviceId }}</p>
                  <p class="text-cyan-300 font-bold">{{ link.sourcePortId }}</p>
                </div>

                <div class="flex-1 px-3 text-center">
                  <div class="h-0.5 w-full bg-gradient-to-r from-blue-500 via-cyan-400 to-emerald-500 relative">
                    <div class="absolute -top-1.5 left-1/2 -translate-x-1/2 text-[9px] bg-slate-950 px-1 text-slate-300 border border-slate-800 rounded">
                      {{ link.bandwidthGbps }}G • {{ link.fiberDistanceKm }}km
                    </div>
                  </div>
                </div>

                <div class="text-center">
                  <p class="text-slate-400 text-[10px]">{{ link.targetDeviceId }}</p>
                  <p class="text-cyan-300 font-bold">{{ link.targetPortId }}</p>
                </div>
              </div>

              <!-- Telemetry metrics -->
              <div class="grid grid-cols-3 gap-2 text-[10px] font-mono text-slate-400 pt-1 border-t border-slate-900">
                <div>时延: <span class="text-slate-200 font-bold">{{ link.latencyMs }} ms</span></div>
                <div>利用率: <span class="text-emerald-400 font-bold">{{ link.currentUtilizationPct }}%</span></div>
                <div>丢包率: <span [ngClass]="link.packetLossRate > 0.01 ? 'text-rose-400 font-bold' : 'text-slate-200'">{{ (link.packetLossRate * 100).toFixed(3) }}%</span></div>
              </div>
            </button>
          }
        </div>

        <!-- Column 3: Linked Services & Impact Correlation -->
        <div class="bg-slate-900/60 border border-slate-800 rounded-2xl p-4 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2">
            <span class="text-xs font-bold text-emerald-400 flex items-center space-x-1">
              <mat-icon class="!w-4 !h-4 !text-[16px]">apps</mat-icon>
              <span>关联业务与最终用户 (Correlated Services & Users)</span>
            </span>
            <span class="text-[10px] font-mono text-slate-500">LAYER 3 & 4</span>
          </div>

          @for (svc of twin.services(); track svc.id) {
            <button
              type="button"
              (click)="twin.selectEntity(svc.id, 'service')"
              [class.border-emerald-500]="twin.selectedEntityId() === svc.id"
              [class.bg-emerald-950/40]="twin.selectedEntityId() === svc.id"
              class="w-full text-left bg-slate-950 border border-slate-800 hover:border-emerald-500/60 p-3 rounded-xl transition cursor-pointer space-y-2"
            >
              <div class="flex items-center justify-between">
                <span class="text-xs font-bold text-white">{{ svc.name }}</span>
                <span class="text-[10px] font-mono text-emerald-400 bg-emerald-950 px-1.5 py-0.5 rounded border border-emerald-500/30">
                  {{ svc.subscriberCount }} 订阅用户
                </span>
              </div>

              <div class="text-[11px] font-mono text-slate-400 space-y-1">
                <p>SLA 目标: <span class="text-slate-200">{{ svc.slaTargetAvailability }}%</span> | 实际: <span class="text-emerald-400 font-bold">{{ svc.currentAvailability }}%</span></p>
                <p>底层依赖链路: <span class="text-cyan-300">{{ svc.underlyingLinkIds.join(', ') }}</span></p>
              </div>
            </button>
          }
        </div>

      </div>
    </div>
  `
})
export class TopologyViewComponent {
  public twin = inject(DigitalTwin);
}
