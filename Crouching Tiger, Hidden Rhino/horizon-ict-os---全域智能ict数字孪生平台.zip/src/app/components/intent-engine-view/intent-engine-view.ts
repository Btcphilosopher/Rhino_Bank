import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwin } from '../../services/digital-twin';

@Component({
  selector: 'app-intent-engine-view',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full h-full bg-slate-950 p-6 overflow-y-auto text-slate-200 select-none">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
        <div>
          <h2 class="text-lg font-mono font-bold text-white flex items-center space-x-2">
            <mat-icon class="text-amber-400 !w-6 !h-6 !text-[24px]">flag</mat-icon>
            <span>意图驱动网络引擎 (Business Intent Engine)</span>
          </h2>
          <p class="text-xs text-slate-400 font-sans">自然语言/业务指标意图 &rarr; 自动化策略翻译 &rarr; 沙盒验证 &rarr; 人工审核 &rarr; 安全加卸载</p>
        </div>

        <span class="px-3 py-1 bg-amber-950 border border-amber-500/40 text-amber-300 text-xs font-mono font-bold rounded-lg">
          INTENT TRANSLATION PIPELINE
        </span>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">

        <!-- Left: Create & Submit New Business Intent Form -->
        <div class="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 space-y-4 font-mono text-xs">
          <span class="text-xs font-bold text-amber-300 flex items-center space-x-1">
            <mat-icon class="!w-4 !h-4 !text-[16px]">tune</mat-icon>
            <span>定义新业务意图 (Define Intent)</span>
          </span>

          <div class="space-y-3">
            <div>
              <span class="text-slate-400 text-[11px] block mb-1">意图名称 / 描述:</span>
              <input
                type="text"
                [value]="intentTitle()"
                (input)="intentTitle.set($any($event.target).value)"
                class="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white text-xs focus:outline-none focus:border-amber-500"
              />
            </div>

            <div class="grid grid-cols-2 gap-3">
              <div>
                <span class="text-slate-400 text-[11px] block mb-1">目标应用类别:</span>
                <select class="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white text-xs focus:outline-none">
                  <option>Banking / 金融结算</option>
                  <option>Autonomous / 智能驾驶</option>
                  <option>Telemedicine / 远程医疗</option>
                  <option>4K Video / 超高清视频</option>
                </select>
              </div>

              <div>
                <span class="text-slate-400 text-[11px] block mb-1">最高容许时延 (Ms):</span>
                <input
                  type="number"
                  [value]="intentLatency()"
                  (input)="intentLatency.set(+$any($event.target).value)"
                  class="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white text-xs focus:outline-none"
                />
              </div>
            </div>

            <div class="grid grid-cols-2 gap-3">
              <div>
                <span class="text-slate-400 text-[11px] block mb-1">要求 SLA 可靠性:</span>
                <select class="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white text-xs focus:outline-none">
                  <option>99.999% (五个九 - 极速通道)</option>
                  <option>99.99% (四个九)</option>
                  <option>99.9% (三个九)</option>
                </select>
              </div>

              <div>
                <span class="text-slate-400 text-[11px] block mb-1">业务优先级:</span>
                <select class="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white text-xs focus:outline-none">
                  <option>Critical (最高关切)</option>
                  <option>High (高优先)</option>
                  <option>Medium (普通)</option>
                </select>
              </div>
            </div>

            <button
              (click)="submitIntent()"
              class="w-full py-2.5 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white rounded-xl font-bold transition shadow-lg shadow-amber-950/50 flex items-center justify-center space-x-1"
            >
              <mat-icon class="!w-4 !h-4 !text-[16px]">play_arrow</mat-icon>
              <span>提交意图翻译并启动拓扑校验</span>
            </button>
          </div>
        </div>

        <!-- Right: Active Intents & Automation Pipeline Status -->
        <div class="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 space-y-4 font-mono text-xs">
          <span class="text-xs font-bold text-amber-300 flex items-center space-x-1">
            <mat-icon class="!w-4 !h-4 !text-[16px]">checklist</mat-icon>
            <span>生效意图与策略流 (Active Intents Pipeline)</span>
          </span>

          <div class="space-y-3">
            @for (intent of twin.intents(); track intent.id) {
              <div class="p-3 bg-slate-950 border border-amber-500/30 rounded-xl space-y-2">
                <div class="flex items-center justify-between">
                  <span class="font-bold text-amber-200 text-xs">{{ intent.title }}</span>
                  <span class="px-2 py-0.5 rounded text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-500/30">
                    {{ intent.status }}
                  </span>
                </div>

                <p class="text-[11px] text-slate-400">
                  翻译策略: <span class="text-slate-200 font-bold">{{ intent.translatedPolicy }}</span>
                </p>

                <div class="p-2 bg-slate-900 rounded border border-slate-800 text-[10px] space-y-1 text-slate-300">
                  <div class="flex justify-between">
                    <span>拓扑验证 (Topology Check):</span>
                    <span class="text-emerald-400 font-bold">PASSED</span>
                  </div>
                  <div class="flex justify-between">
                    <span>沙盒仿真 (Sandbox Sim):</span>
                    <span class="text-emerald-400 font-bold">PASSED (0 Packet Loss)</span>
                  </div>
                  <div class="flex justify-between">
                    <span>人工审批 (Human Approval):</span>
                    <span class="text-cyan-400 font-bold">APPROVED BY CHIEF ARCHITECT</span>
                  </div>
                </div>
              </div>
            }
          </div>
        </div>

      </div>
    </div>
  `
})
export class IntentEngineViewComponent {
  public twin = inject(DigitalTwin);

  public intentTitle = signal<string>('金融高频交易超低时延与零丢包保障');
  public intentLatency = signal<number>(15);

  public submitIntent() {
    alert('意图已翻译成功！已在沙盒环境完成零丢包校验并生成配置草案。');
  }
}
