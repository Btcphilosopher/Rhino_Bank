import {
  Component,
  ElementRef,
  ViewChild,
  AfterViewInit,
  OnDestroy,
  ChangeDetectionStrategy,
  inject,
  effect
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import * as THREE from 'three';
import { DigitalTwin } from '../../services/digital-twin';

@Component({
  selector: 'app-digital-map-3d',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="relative w-full h-full bg-slate-950 overflow-hidden select-none">
      <!-- Three.js Canvas Element -->
      <canvas #canvas3d class="w-full h-full block cursor-grab active:cursor-grabbing"></canvas>

      <!-- 3D HUD Overlays -->
      <div class="absolute top-4 left-4 z-10 flex flex-col space-y-2 pointer-events-none">
        <div class="bg-slate-950/80 backdrop-blur border border-slate-800 p-2.5 rounded-xl text-xs text-slate-200 font-mono shadow-xl pointer-events-auto flex items-center space-x-3">
          <div class="flex items-center space-x-1.5">
            <span class="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></span>
            <span class="font-bold text-white">3D GIS NETWORK MAP</span>
          </div>
          <span class="text-slate-500">|</span>
          <span class="text-slate-400">CITI-HUB: BJ • SH • SZ</span>
          <span class="text-slate-500">|</span>
          <span class="text-cyan-400 font-bold">400G OTN / SRv6 FIBER MESH</span>
        </div>

        <!-- Legend Overlay -->
        <div class="bg-slate-950/80 backdrop-blur border border-slate-800 p-2 rounded-xl text-[11px] text-slate-300 font-mono shadow-xl pointer-events-auto space-y-1">
          <div class="flex items-center space-x-2">
            <span class="w-3 h-3 rounded bg-blue-500 inline-block border border-blue-300"></span>
            <span>核心路由器 / 交换设备</span>
          </div>
          <div class="flex items-center space-x-2">
            <span class="w-3 h-3 rounded bg-cyan-400 inline-block border border-cyan-200"></span>
            <span>数据中心 Hub (3D Rack Stacks)</span>
          </div>
          <div class="flex items-center space-x-2">
            <span class="w-3 h-3 rounded bg-violet-400 inline-block border border-violet-200"></span>
            <span>5G / 5.5G 宏站 (Pulsing RF)</span>
          </div>
          <div class="flex items-center space-x-2">
            <span class="w-3 h-1 bg-cyan-400 inline-block"></span>
            <span>400G 光纤主干 (Traffic Mesh)</span>
          </div>
          @if (twin.activeScenario() === 'FiberCut') {
            <div class="flex items-center space-x-2 text-rose-400 font-bold animate-pulse">
              <span class="w-3 h-1 bg-rose-500 inline-block"></span>
              <span>京沪断纤故障 (FIBER CUT DETECTED)</span>
            </div>
          }
        </div>
      </div>

      <!-- Controls & Reset Camera -->
      <div class="absolute bottom-4 left-4 z-10 flex space-x-2 pointer-events-auto">
        <button
          (click)="resetCameraView()"
          class="px-3 py-1.5 bg-slate-900/90 hover:bg-slate-800 text-xs text-white rounded-lg border border-slate-700 shadow flex items-center space-x-1 font-mono transition"
        >
          <mat-icon class="!w-4 !h-4 !text-[16px]">center_focus_strong</mat-icon>
          <span>重置全景角度</span>
        </button>
        <button
          (click)="flyToCity('Beijing')"
          class="px-2.5 py-1.5 bg-slate-900/90 hover:bg-slate-800 text-xs text-blue-300 rounded-lg border border-slate-700 shadow font-mono transition"
        >
          飞往北京 (BJ)
        </button>
        <button
          (click)="flyToCity('Shanghai')"
          class="px-2.5 py-1.5 bg-slate-900/90 hover:bg-slate-800 text-xs text-cyan-300 rounded-lg border border-slate-700 shadow font-mono transition"
        >
          飞往上海 (SH)
        </button>
        <button
          (click)="flyToCity('Shenzhen')"
          class="px-2.5 py-1.5 bg-slate-900/90 hover:bg-slate-800 text-xs text-violet-300 rounded-lg border border-slate-700 shadow font-mono transition"
        >
          飞往深圳 (SZ)
        </button>
      </div>

      <!-- Selected Object floating toast inside 3D canvas -->
      @if (twin.selectedEntityObject(); as sel) {
        <div class="absolute top-4 right-4 z-10 bg-slate-950/90 border border-slate-800 p-3 rounded-xl text-xs text-white font-mono shadow-2xl backdrop-blur-md max-w-xs animate-fade-in pointer-events-auto">
          <div class="flex items-center justify-between border-b border-slate-800 pb-1.5 mb-2">
            <span class="text-emerald-400 font-bold uppercase">{{ sel.type }} TWIN</span>
            <span class="text-[10px] text-slate-400">ID: {{ sel.data.id }}</span>
          </div>
          <p class="font-bold text-slate-100 text-sm">{{ $any(sel.data).name || $any(sel.data).title }}</p>
          <p class="text-[11px] text-slate-400 mt-0.5">关联 5 层数字孪生节点模型，已完成动态拓扑同步</p>
        </div>
      }
    </div>
  `
})
export class DigitalMap3DComponent implements AfterViewInit, OnDestroy {
  @ViewChild('canvas3d') canvasRef!: ElementRef<HTMLCanvasElement>;
  public twin = inject(DigitalTwin);

  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private animFrameId: number | null = null;

  // Interactive 3D Objects mapping
  private nodeMeshes: Map<string, THREE.Mesh> = new Map<string, THREE.Mesh>();
  private linkLines: Map<string, THREE.Line> = new Map<string, THREE.Line>();
  private particleGroup!: THREE.Group;
  private particles: { mesh: THREE.Mesh; path: THREE.Vector3[]; progress: number; speed: number }[] = [];

  private raycaster = new THREE.Raycaster();
  private mouse = new THREE.Vector2();

  // Simple orbit controls variables
  private isMouseDown = false;
  private mousePrev = { x: 0, y: 0 };
  private cameraTarget = new THREE.Vector3(0, 0, 0);
  private cameraRadius = 450;
  private cameraTheta = Math.PI / 4;
  private cameraPhi = Math.PI / 3.5;

  constructor() {
    // Effect to update line colors when scenario changes
    effect(() => {
      const scenario = this.twin.activeScenario();
      this.updateLinkVisuals(scenario);
    });
  }

  ngAfterViewInit(): void {
    this.init3DScene();
    this.createCityPlatforms();
    this.createNodesAndTowers();
    this.createFiberLinks();
    this.createDataParticles();
    this.setupEventListeners();
    this.animate();
  }

  ngOnDestroy(): void {
    if (this.animFrameId !== null) {
      cancelAnimationFrame(this.animFrameId);
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
  }

  private init3DScene() {
    const canvas = this.canvasRef.nativeElement;
    const width = canvas.parentElement?.clientWidth || window.innerWidth;
    const height = canvas.parentElement?.clientHeight || window.innerHeight;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0a0f1d);
    this.scene.fog = new THREE.FogExp2(0x0a0f1d, 0.0015);

    this.camera = new THREE.PerspectiveCamera(45, width / height, 1, 2000);
    this.updateCameraPosition();

    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

    // Ambient & Directional Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    this.scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0x38bdf8, 1.2);
    dirLight1.position.set(200, 400, 300);
    this.scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0x10b981, 0.8);
    dirLight2.position.set(-200, -200, -300);
    this.scene.add(dirLight2);

    this.particleGroup = new THREE.Group();
    this.scene.add(this.particleGroup);
  }

  private createCityPlatforms() {
    // Ground Grid
    const gridHelper = new THREE.GridHelper(800, 40, 0x1e293b, 0x0f172a);
    gridHelper.position.y = -2;
    this.scene.add(gridHelper);

    // City Hub 1: Beijing (-120, 0, -180)
    this.createCityHubMesh(-120, -180, '北京 (Beijing ICT Hub)', 0x3b82f6);

    // City Hub 2: Shanghai (150, 0, 80)
    this.createCityHubMesh(150, 80, '上海 (Shanghai FinHub)', 0x06b6d4);

    // City Hub 3: Shenzhen (100, 0, 220)
    this.createCityHubMesh(100, 220, '深圳 (Shenzhen TechHub)', 0x8b5cf6);
  }

  private createCityHubMesh(x: number, z: number, name: string, colorHex: number) {
    // Hexagonal Base Platform
    const geo = new THREE.CylinderGeometry(60, 65, 4, 6);
    const mat = new THREE.MeshPhongMaterial({
      color: colorHex,
      transparent: true,
      opacity: 0.25,
      wireframe: false
    });
    const baseMesh = new THREE.Mesh(geo, mat);
    baseMesh.position.set(x, 0, z);
    this.scene.add(baseMesh);

    // Ring Border
    const ringGeo = new THREE.RingGeometry(62, 65, 32);
    const ringMat = new THREE.MeshBasicMaterial({ color: colorHex, side: THREE.DoubleSide });
    const ringMesh = new THREE.Mesh(ringGeo, ringMat);
    ringMesh.rotation.x = Math.PI / 2;
    ringMesh.position.set(x, 2.1, z);
    this.scene.add(ringMesh);

    // Architectural 3D Buildings
    for (let i = 0; i < 8; i++) {
      const bx = x + (Math.sin(i) * 35);
      const bz = z + (Math.cos(i) * 35);
      const bHeight = 15 + Math.random() * 40;
      const bGeo = new THREE.BoxGeometry(10, bHeight, 10);
      const bMat = new THREE.MeshPhongMaterial({ color: 0x1e293b, specular: 0x38bdf8, shininess: 30 });
      const bMesh = new THREE.Mesh(bGeo, bMat);
      bMesh.position.set(bx, bHeight / 2, bz);
      this.scene.add(bMesh);
    }
  }

  private createNodesAndTowers() {
    this.twin.equipment().forEach(eq => {
      const pos = eq.location;
      let mesh: THREE.Mesh;

      if (eq.type === 'router' || eq.type === 'optical') {
        // Router node: Glowing Box
        const geo = new THREE.BoxGeometry(12, 12, 12);
        const mat = new THREE.MeshPhongMaterial({
          color: eq.type === 'router' ? 0x3b82f6 : 0x06b6d4,
          emissive: eq.type === 'router' ? 0x1d4ed8 : 0x0891b2,
          emissiveIntensity: 0.4
        });
        mesh = new THREE.Mesh(geo, mat);
        mesh.position.set(pos.x, pos.y + 10, pos.z);
      } else if (eq.type === 'base_station') {
        // 5G Telecom Tower
        const geo = new THREE.CylinderGeometry(1, 4, 35, 8);
        const mat = new THREE.MeshPhongMaterial({ color: 0x8b5cf6, emissive: 0x6d28d9, emissiveIntensity: 0.5 });
        mesh = new THREE.Mesh(geo, mat);
        mesh.position.set(pos.x, pos.y + 17.5, pos.z);

        // Add 3D RF Coverage Rings
        const ringGeo = new THREE.TorusGeometry(20, 0.8, 8, 32);
        const ringMat = new THREE.MeshBasicMaterial({ color: 0xa855f7, transparent: true, opacity: 0.4 });
        const ringMesh = new THREE.Mesh(ringGeo, ringMat);
        ringMesh.rotation.x = Math.PI / 2;
        ringMesh.position.set(0, 10, 0);
        mesh.add(ringMesh);
      } else {
        // Server / Switch node
        const geo = new THREE.BoxGeometry(10, 16, 10);
        const mat = new THREE.MeshPhongMaterial({ color: 0x10b981 });
        mesh = new THREE.Mesh(geo, mat);
        mesh.position.set(pos.x, pos.y + 8, pos.z);
      }

      mesh.userData = { id: eq.id, name: eq.name, type: eq.layer };
      this.scene.add(mesh);
      this.nodeMeshes.set(eq.id, mesh);
    });

    // Add 3D Data Center Glass Hubs
    this.twin.datacenters().forEach(dc => {
      let x = -120, z = -180;
      if (dc.city === 'Shanghai') { x = 150; z = 80; }
      if (dc.city === 'Shenzhen') { x = 100; z = 220; }

      const dcGeo = new THREE.BoxGeometry(32, 28, 32);
      const dcMat = new THREE.MeshPhongMaterial({
        color: 0x0284c7,
        transparent: true,
        opacity: 0.4,
        wireframe: true
      });
      const dcMesh = new THREE.Mesh(dcGeo, dcMat);
      dcMesh.position.set(x + 10, 14, z - 10);
      dcMesh.userData = { id: dc.id, name: dc.name, type: 'datacenter' };
      this.scene.add(dcMesh);
      this.nodeMeshes.set(dc.id, dcMesh);
    });
  }

  private createFiberLinks() {
    this.twin.links().forEach(link => {
      const srcNode = this.twin.equipment().find(e => e.id === link.sourceDeviceId);
      const tgtNode = this.twin.equipment().find(e => e.id === link.targetDeviceId);

      if (srcNode && tgtNode) {
        const start = new THREE.Vector3(srcNode.location.x, srcNode.location.y + 10, srcNode.location.z);
        const end = new THREE.Vector3(tgtNode.location.x, tgtNode.location.y + 10, tgtNode.location.z);

        // Curved fiber link
        const mid = new THREE.Vector3()
          .addVectors(start, end)
          .multiplyScalar(0.5)
          .add(new THREE.Vector3(0, 40, 0));

        const curve = new THREE.QuadraticBezierCurve3(start, mid, end);
        const points = curve.getPoints(30);
        const geometry = new THREE.BufferGeometry().setFromPoints(points);

        const material = new THREE.LineBasicMaterial({
          color: link.status === 'healthy' ? 0x06b6d4 : 0xf43f5e,
          linewidth: 2
        });

        const line = new THREE.Line(geometry, material);
        line.userData = { id: link.id, curvePoints: points };
        this.scene.add(line);
        this.linkLines.set(link.id, line);
      }
    });
  }

  private updateLinkVisuals(scenario: string) {
    this.linkLines.forEach((line, id) => {
      const mat = line.material as THREE.LineBasicMaterial;
      if (id === 'LINK-BJ-SH-400G-A' && scenario === 'FiberCut') {
        mat.color.setHex(0xf43f5e); // Red for severed
      } else if ((id === 'LINK-BJ-SZ-400G-A' || id === 'LINK-SH-SZ-400G-A') && scenario === 'FiberCut') {
        mat.color.setHex(0xf59e0b); // Amber for active reroute
      } else {
        mat.color.setHex(0x06b6d4); // Cyan normal
      }
    });
  }

  private createDataParticles() {
    this.twin.links().forEach(link => {
      const srcNode = this.twin.equipment().find(e => e.id === link.sourceDeviceId);
      const tgtNode = this.twin.equipment().find(e => e.id === link.targetDeviceId);

      if (srcNode && tgtNode) {
        const start = new THREE.Vector3(srcNode.location.x, srcNode.location.y + 10, srcNode.location.z);
        const end = new THREE.Vector3(tgtNode.location.x, tgtNode.location.y + 10, tgtNode.location.z);
        const mid = new THREE.Vector3().addVectors(start, end).multiplyScalar(0.5).add(new THREE.Vector3(0, 40, 0));

        const curve = new THREE.QuadraticBezierCurve3(start, mid, end);
        const curvePoints = curve.getPoints(50);

        for (let i = 0; i < 3; i++) {
          const pGeo = new THREE.SphereGeometry(2, 8, 8);
          const pMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
          const pMesh = new THREE.Mesh(pGeo, pMat);

          this.particleGroup.add(pMesh);
          this.particles.push({
            mesh: pMesh,
            path: curvePoints,
            progress: Math.random(),
            speed: 0.005 + Math.random() * 0.005
          });
        }
      }
    });
  }

  private setupEventListeners() {
    const canvas = this.canvasRef.nativeElement;

    canvas.addEventListener('mousedown', (e) => {
      this.isMouseDown = true;
      this.mousePrev = { x: e.clientX, y: e.clientY };
    });

    canvas.addEventListener('mousemove', (e) => {
      if (this.isMouseDown) {
        const dx = e.clientX - this.mousePrev.x;
        const dy = e.clientY - this.mousePrev.y;

        this.cameraTheta -= dx * 0.005;
        this.cameraPhi = Math.max(0.1, Math.min(Math.PI / 2 - 0.05, this.cameraPhi - dy * 0.005));

        this.mousePrev = { x: e.clientX, y: e.clientY };
        this.updateCameraPosition();
      }
    });

    window.addEventListener('mouseup', () => {
      this.isMouseDown = false;
    });

    canvas.addEventListener('wheel', (e) => {
      e.preventDefault();
      this.cameraRadius = Math.max(100, Math.min(900, this.cameraRadius + e.deltaY * 0.5));
      this.updateCameraPosition();
    });

    canvas.addEventListener('click', (e) => {
      const rect = canvas.getBoundingClientRect();
      this.mouse.x = ((e.clientX - rect.left) / canvas.clientWidth) * 2 - 1;
      this.mouse.y = -((e.clientY - rect.top) / canvas.clientHeight) * 2 + 1;

      this.raycaster.setFromCamera(this.mouse, this.camera);
      const intersects = this.raycaster.intersectObjects(Array.from(this.nodeMeshes.values()));

      if (intersects.length > 0) {
        const hit = intersects[0].object;
        if (hit.userData['id']) {
          this.twin.selectEntity(hit.userData['id'], hit.userData['type'] || 'equipment');
        }
      }
    });
  }

  private updateCameraPosition() {
    this.camera.position.x = this.cameraTarget.x + this.cameraRadius * Math.sin(this.cameraPhi) * Math.cos(this.cameraTheta);
    this.camera.position.y = this.cameraTarget.y + this.cameraRadius * Math.cos(this.cameraPhi);
    this.camera.position.z = this.cameraTarget.z + this.cameraRadius * Math.sin(this.cameraPhi) * Math.sin(this.cameraTheta);
    this.camera.lookAt(this.cameraTarget);
  }

  public resetCameraView() {
    this.cameraTarget.set(0, 0, 0);
    this.cameraRadius = 450;
    this.cameraTheta = Math.PI / 4;
    this.cameraPhi = Math.PI / 3.5;
    this.updateCameraPosition();
  }

  public flyToCity(city: 'Beijing' | 'Shanghai' | 'Shenzhen') {
    if (city === 'Beijing') {
      this.cameraTarget.set(-120, 10, -180);
      this.cameraRadius = 180;
    } else if (city === 'Shanghai') {
      this.cameraTarget.set(150, 10, 80);
      this.cameraRadius = 180;
    } else {
      this.cameraTarget.set(100, 10, 220);
      this.cameraRadius = 180;
    }
    this.updateCameraPosition();
  }

  private animate = () => {
    this.animFrameId = requestAnimationFrame(this.animate);

    // Animate data flow particles along fiber paths
    this.particles.forEach(p => {
      p.progress += p.speed;
      if (p.progress >= 1) p.progress = 0;

      const idx = Math.floor(p.progress * (p.path.length - 1));
      if (p.path[idx]) {
        p.mesh.position.copy(p.path[idx]);
      }
    });

    // Pulse selected mesh in 3D
    const selectedId = this.twin.selectedEntityId();
    if (selectedId && this.nodeMeshes.has(selectedId)) {
      const selectedMesh = this.nodeMeshes.get(selectedId)!;
      selectedMesh.rotation.y += 0.02;
    }

    this.renderer.render(this.scene, this.camera);
  };
}
