import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwin } from '../../services/digital-twin';

@Component({
  selector: 'app-scenario-sandbox-view',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full h-full bg-slate-950 p-6 overflow-y-auto text-slate-200 select-none">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
        <div>
          <h2 class="text-lg font-mono font-bold text-white flex items-center space-x-2">
            <mat-icon class="text-rose-400 !w-6 !h-6 !text-[24px]">science</mat-icon>
            <span>演练闭环与“What-If”推演沙盒 (Scenario Sandbox)</span>
          </h2>
          <p class="text-xs text-slate-400 font-sans">全真模拟故障注入 &rarr; 根因分析 (RCA) &rarr; 影响面分析 &rarr; 优化方案评估 &rarr; 一键闭环自愈</p>
        </div>

        <button
          (click)="twin.triggerScenario('Normal')"
          class="px-4 py-1.5 bg-emerald-950 border border-emerald-500/40 text-emerald-300 rounded-xl text-xs font-mono font-bold hover:bg-emerald-900 transition flex items-center space-x-1"
        >
          <mat-icon class="!w-4 !h-4 !text-[16px]">restart_alt</mat-icon>
          <span>恢复正常运行状态 (RESET)</span>
        </button>
      </div>

      <!-- 5 Interactive Failure Scenarios Selector -->
      <div class="grid grid-cols-1 md:grid-cols-5 gap-3 mb-6">
        <button
          (click)="twin.triggerScenario('FiberCut')"
          [class.ring-2]="twin.activeScenario() === 'FiberCut'"
          [class.ring-rose-500]="twin.activeScenario() === 'FiberCut'"
          class="p-3 bg-slate-900/90 border border-slate-800 hover:border-slate-700 rounded-xl text-left transition space-y-1"
        >
          <div class="flex items-center justify-between text-xs font-bold text-rose-400">
            <span>京沪断纤</span>
            <mat-icon class="!w-4 !h-4 !text-[16px]">content_cut</mat-icon>
          </div>
          <p class="text-[10px] text-slate-400 font-mono">京沪 400G 光纤管道物理剪断</p>
        </button>

        <button
          (click)="twin.triggerScenario('DcCongestion')"
          [class.ring-2]="twin.activeScenario() === 'DcCongestion'"
          [class.ring-amber-500]="twin.activeScenario() === 'DcCongestion'"
          class="p-3 bg-slate-900/90 border border-slate-800 hover:border-slate-700 rounded-xl text-left transition space-y-1"
        >
          <div class="flex items-center justify-between text-xs font-bold text-amber-400">
            <span>DC 流量拥塞</span>
            <mat-icon class="!w-4 !h-4 !text-[16px]">lan</mat-icon>
          </div>
          <p class="text-[10px] text-slate-400 font-mono">上海金融 DC 端口包挤压 88%</p>
        </button>

        <button
          (click)="twin.triggerScenario('RouterCrash')"
          [class.ring-2]="twin.activeScenario() === 'RouterCrash'"
          [class.ring-rose-500]="twin.activeScenario() === 'RouterCrash'"
          class="p-3 bg-slate-900/90 border border-slate-800 hover:border-slate-700 rounded-xl text-left transition space-y-1"
        >
          <div class="flex items-center justify-between text-xs font-bold text-rose-400">
            <span>核心路由宕机</span>
            <mat-icon class="!w-4 !h-4 !text-[16px]">report_problem</mat-icon>
          </div>
          <p class="text-[10px] text-slate-400 font-mono">北京 HW-CR-BJ-01 主板故障</p>
        </button>

        <button
          (click)="twin.triggerScenario('PowerLoss')"
          [class.ring-2]="twin.activeScenario() === 'PowerLoss'"
          [class.ring-amber-500]="twin.activeScenario() === 'PowerLoss'"
          class="p-3 bg-slate-900/90 border border-slate-800 hover:border-slate-700 rounded-xl text-left transition space-y-1"
        >
          <div class="flex items-center justify-between text-xs font-bold text-amber-400">
            <span>配电与温控中断</span>
            <mat-icon class="!w-4 !h-4 !text-[16px]">ac_unit</mat-icon>
          </div>
          <p class="text-[10px] text-slate-400 font-mono">数据中心 A 市电故障转 UPS</p>
        </button>

        <button
          (click)="twin.triggerScenario('TrafficSurge')"
          [class.ring-2]="twin.activeScenario() === 'TrafficSurge'"
          [class.ring-violet-500]="twin.activeScenario() === 'TrafficSurge'"
          class="p-3 bg-slate-900/90 border border-slate-800 hover:border-slate-700 rounded-xl text-left transition space-y-1"
        >
          <div class="flex items-center justify-between text-xs font-bold text-violet-400">
            <span>+50% 爆发流量</span>
            <mat-icon class="!w-4 !h-4 !text-[16px]">trending_up</mat-icon>
          </div>
          <p class="text-[10px] text-slate-400 font-mono">双十一/金融开盘突发大流量</p>
        </button>
      </div>

      <!-- Active Scenario RCA & Impact Panel -->
      @if (rcaData(); as rca) {
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">

          <!-- RCA Root Cause Analysis Box -->
          <div class="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 space-y-4 font-mono text-xs">
            <div class="flex items-center justify-between border-b border-slate-800 pb-2">
              <span class="text-xs font-bold text-rose-400 flex items-center space-x-1">
                <mat-icon class="!w-4 !h-4 !text-[16px]">bug_report</mat-icon>
                <span>智能根因分析 (AI RCA Engine)</span>
              </span>
              <span class="px-2 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-500/30 text-[10px]">
                CONFIDENCE: 98.4%
              </span>
            </div>

            <div class="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
              <p class="text-slate-400 text-[10px]">根因告警描述:</p>
              <p class="text-white font-bold text-sm">{{ rca.issue }}</p>
            </div>

            <div class="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
              <p class="text-slate-400 text-[10px]">受影响设备与业务统计:</p>
              <div class="grid grid-cols-2 gap-2 text-[11px]">
                <div>告警设备: <strong class="text-rose-400">{{ rca.faultEntity }}</strong></div>
                <div>降级业务: <strong class="text-amber-400">{{ rca.degradedServices }} 项</strong></div>
                <div>受影响用户: <strong class="text-violet-400">{{ rca.affectedUserCount }} 人</strong></div>
                <div>预计损失 SLA: <strong class="text-rose-400">￥ 42,000 / 小时</strong></div>
              </div>
            </div>
          </div>

          <!-- Remediation Proposal & 1-Click Execution -->
          <div class="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 space-y-4 font-mono text-xs">
            <div class="flex items-center justify-between border-b border-slate-800 pb-2">
              <span class="text-xs font-bold text-emerald-400 flex items-center space-x-1">
                <mat-icon class="!w-4 !h-4 !text-[16px]">verified</mat-icon>
                <span>推荐自愈方案与评估 (Remediation Proposal)</span>
              </span>
              <span class="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-500/30 text-[10px]">
                SAFETY CHECK PASSED
              </span>
            </div>

            <div class="p-3 bg-slate-950 rounded-xl border border-emerald-500/30 space-y-2">
              <p class="text-emerald-400 font-bold text-xs">闭环自愈策略:</p>
              <p class="text-slate-200 leading-relaxed text-[11px]">{{ rca.remediationPlan }}</p>
            </div>

            <button
              (click)="executeRemediation()"
              class="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold transition shadow-lg shadow-emerald-950/50 flex items-center justify-center space-x-2 text-sm"
            >
              <mat-icon class="!w-5 !h-5 !text-[20px]">play_circle</mat-icon>
              <span>一键执行闭环优化 (1-CLICK REMEDIATION)</span>
            </button>
          </div>

        </div>
      }
    </div>
  `
})
export class ScenarioSandboxViewComponent {
  public twin = inject(DigitalTwin);

  public rcaData = () => {
    const sc = this.twin.activeScenario();
    if (sc === 'FiberCut') {
      return {
        issue: '京沪主干 400G 光纤受施工损伤断纤，收光信号低于 -40dBm 导致链路 Down。',
        faultEntity: 'LINK-BJ-SH-400G-A',
        degradedServices: 2,
        affectedUserCount: 15200,
        remediationPlan: '动态调整 SRv6 Policy，将京沪流量秒级重路由至“北京 &rarr; 深圳 &rarr; 上海”备份光纤路径，保证 0 丢包。'
      };
    }
    if (sc === 'DcCongestion') {
      return {
        issue: '上海金融 DC 端口链路拥塞，队列缓冲区利用率达到 88.5%。',
        faultEntity: 'HW-CE-SH-01',
        degradedServices: 1,
        affectedUserCount: 3200,
        remediationPlan: '通过 ECN/PFC 流控微调并启动 ECMP 广义负载均衡分流。'
      };
    }
    return {
      issue: '系统运行正常，网络拓扑各项指标处于 Baseline 理想范围。',
      faultEntity: 'NONE',
      degradedServices: 0,
      affectedUserCount: 0,
        remediationPlan: '无须人工干预，系统正以 100% 自动驾驶状态平稳运行。'
    };
  };

  public executeRemediation() {
    this.twin.triggerScenario('Normal');
    alert('闭环优化指令已成功下发至网元设备！流量已平滑切至备份路径，系统恢复 Healthy。');
  }
}
