import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwin } from '../../services/digital-twin';

@Component({
  selector: 'app-energy-security-view',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full h-full bg-slate-950 p-6 overflow-y-auto text-slate-200 select-none">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
        <div>
          <h2 class="text-lg font-mono font-bold text-white flex items-center space-x-2">
            <mat-icon class="text-emerald-400 !w-6 !h-6 !text-[24px]">energy_savings_leaf</mat-icon>
            <span>双碳绿色能源与零信任安全数字孪生 (Energy & Zero-Trust Twin)</span>
          </h2>
          <p class="text-xs text-slate-400 font-sans">数据中心 PUE 优化、光伏新能源调度、零信任网络安全态势感知</p>
        </div>

        <div class="flex items-center space-x-3 text-xs font-mono">
          <span class="px-3 py-1 bg-emerald-950 border border-emerald-500/40 text-emerald-300 rounded-lg">
            AVERAGE PUE: 1.17 (OPTIMAL)
          </span>
          <span class="px-3 py-1 bg-cyan-950 border border-cyan-500/40 text-cyan-300 rounded-lg">
            SOLAR POWER: 18% GREEN MIX
          </span>
        </div>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">

        <!-- Left: Green Energy & PUE Control Panel -->
        <div class="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 space-y-4 font-mono text-xs">
          <span class="text-xs font-bold text-emerald-400 flex items-center space-x-1">
            <mat-icon class="!w-4 !h-4 !text-[16px]">eco</mat-icon>
            <span>数据中心能耗与碳排放孪生 (Green Energy Twin)</span>
          </span>

          <div class="grid grid-cols-2 gap-3">
            <div class="p-3 bg-slate-950 rounded-xl border border-slate-800">
              <span class="text-slate-400 text-[10px]">实时 PUE 指标:</span>
              <p class="text-2xl font-bold text-emerald-400 mt-1">1.17</p>
              <p class="text-[10px] text-slate-500 mt-0.5">较上月降低 0.04</p>
            </div>

            <div class="p-3 bg-slate-950 rounded-xl border border-slate-800">
              <span class="text-slate-400 text-[10px]">绿电混合比例 (Solar/Wind):</span>
              <p class="text-2xl font-bold text-cyan-300 mt-1">18.4%</p>
              <p class="text-[10px] text-emerald-400 mt-0.5">碳减排 142 吨/月</p>
            </div>
          </div>

          <div class="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
            <span class="text-xs font-bold text-white">热感应算力负荷迁移 (Thermal-Aware Migration)</span>
            <p class="text-[11px] text-slate-400 leading-relaxed">
              根据北京、上海、深圳三地白天太阳能光伏出力差异，自动将非时延敏感的 AI 训练与云端算力调度至光伏充沛区。
            </p>
            <button
              class="w-full py-2 bg-emerald-950 border border-emerald-500/40 text-emerald-300 hover:bg-emerald-900 rounded-lg font-bold transition"
            >
              触发智能热感应算力绿电迁移
            </button>
          </div>
        </div>

        <!-- Right: Zero-Trust Security & Threat Intelligence -->
        <div class="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 space-y-4 font-mono text-xs">
          <span class="text-xs font-bold text-cyan-400 flex items-center space-x-1">
            <mat-icon class="!w-4 !h-4 !text-[16px]">security</mat-icon>
            <span>零信任安全与网络防御态势 (Zero-Trust Security)</span>
          </span>

          <div class="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
            <div class="flex justify-between items-center">
              <span class="text-xs font-bold text-white">零信任微隔离策略 (Micro-Segmentation)</span>
              <span class="text-[10px] px-2 py-0.5 bg-emerald-950 text-emerald-400 border border-emerald-500/30 rounded">
                100% ENFORCED
              </span>
            </div>
            <p class="text-[11px] text-slate-400">持续评估终端身份与网元安全度，阻止横向移动威胁。</p>
          </div>

          <div class="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
            <span class="text-xs font-bold text-rose-400">实时网络安全威胁日志</span>
            <div class="space-y-1.5 text-[11px]">
              <div class="p-2 bg-slate-900 rounded flex items-center justify-between text-slate-300">
                <span>[10:14:02] Syn-Flood Attack Blocked on HW-CE-BJ-01</span>
                <span class="text-emerald-400 font-bold">CLEARED</span>
              </div>
              <div class="p-2 bg-slate-900 rounded flex items-center justify-between text-slate-300">
                <span>[09:42:18] VIP FinTech VPN Unauthorized Access Attempt</span>
                <span class="text-rose-400 font-bold">REJECTED</span>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  `
})
export class EnergySecurityViewComponent {
  public twin = inject(DigitalTwin);
}
