import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwin } from '../../services/digital-twin';

@Component({
  selector: 'app-time-machine-bar',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <footer class="h-12 bg-slate-950 border-t border-slate-800/80 px-4 flex items-center justify-between text-slate-200 select-none shadow-2xl z-30 relative">
      <!-- Left Controls: Play/Pause & Speed -->
      <div class="flex items-center space-x-3 text-xs font-mono">
        <button
          (click)="togglePlay()"
          class="p-1.5 bg-slate-900 hover:bg-slate-800 rounded-lg border border-slate-700 text-white transition flex items-center space-x-1"
        >
          <mat-icon class="!w-4 !h-4 !text-[16px] text-emerald-400">
            {{ isPlaying() ? 'pause' : 'play_arrow' }}
          </mat-icon>
          <span>{{ isPlaying() ? '暂停回放' : '历史回放' }}</span>
        </button>

        <span class="text-slate-400 text-[11px]">回放倍速:</span>
        <button
          (click)="cycleSpeed()"
          class="px-2 py-0.5 bg-slate-900 border border-slate-800 rounded text-cyan-300 font-bold"
        >
          {{ playbackSpeed() }}x
        </button>
      </div>

      <!-- Center: Timeline Slider Bar -->
      <div class="flex-1 mx-6 flex items-center space-x-3">
        <span class="text-[10px] font-mono text-slate-400">09:00:00</span>
        <input
          type="range"
          min="0"
          max="100"
          [value]="timeProgress()"
          (input)="onProgressChange($event)"
          class="w-full accent-emerald-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
        />
        <span class="text-[10px] font-mono text-emerald-400 font-bold">
          {{ currentTimeDisplay() }}
        </span>
      </div>

      <!-- Right: Real-time Telemetry Heartbeat Status -->
      <div class="flex items-center space-x-3 text-[11px] font-mono text-slate-400">
        <span class="flex items-center space-x-1">
          <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span class="text-slate-300">TELEMETRY STREAM ACTIVE</span>
        </span>
        <span class="text-slate-600">|</span>
        <span>LATENCY: 0.8ms</span>
      </div>
    </footer>
  `
})
export class TimeMachineBarComponent {
  public twin = inject(DigitalTwin);

  public isPlaying = signal<boolean>(false);
  public playbackSpeed = signal<number>(1);
  public timeProgress = signal<number>(85);

  public currentTimeDisplay = () => {
    const totalSecs = 9 * 3600 + Math.floor((this.timeProgress() / 100) * (9 * 3600));
    const h = String(Math.floor(totalSecs / 3600)).padStart(2, '0');
    const m = String(Math.floor((totalSecs % 3600) / 60)).padStart(2, '0');
    const s = String(totalSecs % 60).padStart(2, '0');
    return `${h}:${m}:${s}`;
  };

  public togglePlay() {
    this.isPlaying.update(p => !p);
  }

  public cycleSpeed() {
    const s = this.playbackSpeed();
    this.playbackSpeed.set(s === 1 ? 5 : s === 5 ? 10 : 1);
  }

  public onProgressChange(e: Event) {
    this.timeProgress.set(+(e.target as HTMLInputElement).value);
  }
}
