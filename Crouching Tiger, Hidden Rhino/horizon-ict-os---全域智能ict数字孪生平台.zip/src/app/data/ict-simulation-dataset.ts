import {
  EquipmentNode,
  NetworkLink,
  ServiceNode,
  ApplicationNode,
  UserNode,
  BusinessIntentNode,
  RackNode,
  DatacenterNode,
  AlarmItem
} from '../models/digital-twin.model';

export const SIMULATION_DATACENTERS: DatacenterNode[] = [
  {
    id: 'DC-BJ-01',
    name: '北京亦庄云计算中心 (Beijing Yizhuang DC)',
    city: 'Beijing',
    building: 'A1 智算楼',
    racksCount: 120,
    pueScore: 1.18,
    totalPowerKw: 1250,
    solarKw: 180,
    batteryBackupMins: 45,
    status: 'healthy'
  },
  {
    id: 'DC-BJ-02',
    name: '北京海淀核心枢纽 (Beijing Haidian Hub)',
    city: 'Beijing',
    building: 'B3 数据大楼',
    racksCount: 80,
    pueScore: 1.22,
    totalPowerKw: 890,
    solarKw: 90,
    batteryBackupMins: 60,
    status: 'healthy'
  },
  {
    id: 'DC-SH-01',
    name: '上海浦东金融数据中心 (Shanghai Pudong FinDC)',
    city: 'Shanghai',
    building: 'F1 极速金融楼',
    racksCount: 150,
    pueScore: 1.15,
    totalPowerKw: 1680,
    solarKw: 240,
    batteryBackupMins: 90,
    status: 'healthy'
  },
  {
    id: 'DC-SH-02',
    name: '上海临港算力枢纽 (Shanghai Lingang Compute)',
    city: 'Shanghai',
    building: 'C2 智能云基地',
    racksCount: 200,
    pueScore: 1.14,
    totalPowerKw: 2100,
    solarKw: 350,
    batteryBackupMins: 60,
    status: 'healthy'
  },
  {
    id: 'DC-SZ-01',
    name: '深圳南山超算中心 (Shenzhen Nanshan DC)',
    city: 'Shenzhen',
    building: 'S5 大湾区计算中心',
    racksCount: 140,
    pueScore: 1.16,
    totalPowerKw: 1420,
    solarKw: 200,
    batteryBackupMins: 60,
    status: 'healthy'
  }
];

export const SIMULATION_RACKS: RackNode[] = [
  {
    id: 'RACK-BJ-A12',
    datacenterId: 'DC-BJ-01',
    roomName: '301 机房',
    rackName: 'RACK-A12',
    maxPowerKw: 12.0,
    currentPowerKw: 8.4,
    temperatureC: 24.8,
    status: 'healthy',
    serversCount: 16,
    switchesCount: 2,
    coolingStatus: 'Optimal',
    deviceIds: ['SRV-BJ-01', 'SRV-BJ-02', 'HW-CE-BJ-01']
  },
  {
    id: 'RACK-SH-F01',
    datacenterId: 'DC-SH-01',
    roomName: '102 极速机房',
    rackName: 'RACK-F01',
    maxPowerKw: 15.0,
    currentPowerKw: 11.2,
    temperatureC: 23.2,
    status: 'healthy',
    serversCount: 20,
    switchesCount: 2,
    coolingStatus: 'Optimal',
    deviceIds: ['SRV-SH-01', 'HW-CE-SH-01']
  },
  {
    id: 'RACK-SZ-S08',
    datacenterId: 'DC-SZ-01',
    roomName: '204 湾区机房',
    rackName: 'RACK-S08',
    maxPowerKw: 10.0,
    currentPowerKw: 7.9,
    temperatureC: 25.1,
    status: 'healthy',
    serversCount: 14,
    switchesCount: 2,
    coolingStatus: 'Optimal',
    deviceIds: ['SRV-SZ-01', 'HW-CE-SZ-01']
  }
];

export const SIMULATION_EQUIPMENT: EquipmentNode[] = [
  // Core Routers
  {
    id: 'HW-CR-BJ-01',
    name: '北京国家骨干核心路由器01 (BJ Core Router 01)',
    codeName: 'HW-NE8000-BJ1',
    type: 'router',
    layer: 'equipment',
    location: {
      city: 'Beijing',
      siteName: '北京亦庄核心枢纽',
      lat: 39.9042,
      lng: 116.4074,
      x: -120,
      y: 15,
      z: -180,
      building: 'A1 智算楼',
      room: '101 核心机房',
      rackId: 'RACK-BJ-A12'
    },
    model: 'NetEngine 8000 X16',
    vendor: 'Horizon ICT Native',
    ipAddress: '10.240.0.1',
    status: 'healthy',
    cpuUsagePct: 28,
    memoryUsagePct: 42,
    temperatureC: 38.5,
    powerKw: 3.2,
    uptimeHours: 8760,
    ports: [
      { id: 'BJ-CR01-P1', name: 'GE0/1/0 (To SH-CR-01)', speed: '400G', type: 'fiber', status: 'up', txRateMbps: 185000, rxRateMbps: 192000, packetLossRate: 0.0001 },
      { id: 'BJ-CR01-P2', name: 'GE0/1/1 (To SZ-CR-01)', speed: '400G', type: 'fiber', status: 'up', txRateMbps: 140000, rxRateMbps: 138000, packetLossRate: 0.0001 },
      { id: 'BJ-CR01-P3', name: 'GE0/2/0 (To BJ-AR-01)', speed: '100G', type: 'fiber', status: 'up', txRateMbps: 45000, rxRateMbps: 42000, packetLossRate: 0.0 },
      { id: 'BJ-CR01-P4', name: 'GE0/3/0 (To OSN-BJ-01)', speed: '400G', type: 'optical', status: 'up', txRateMbps: 310000, rxRateMbps: 305000, packetLossRate: 0.0 }
    ]
  },
  {
    id: 'HW-CR-SH-01',
    name: '上海国家骨干核心路由器01 (SH Core Router 01)',
    codeName: 'HW-NE8000-SH1',
    type: 'router',
    layer: 'equipment',
    location: {
      city: 'Shanghai',
      siteName: '上海浦东金融枢纽',
      lat: 31.2304,
      lng: 121.4737,
      x: 150,
      y: 12,
      z: 80,
      building: 'F1 极速金融楼',
      room: '核心机房',
      rackId: 'RACK-SH-F01'
    },
    model: 'NetEngine 8000 X16',
    vendor: 'Horizon ICT Native',
    ipAddress: '10.240.0.2',
    status: 'healthy',
    cpuUsagePct: 34,
    memoryUsagePct: 48,
    temperatureC: 40.2,
    powerKw: 3.4,
    uptimeHours: 12400,
    ports: [
      { id: 'SH-CR01-P1', name: 'GE0/1/0 (To BJ-CR-01)', speed: '400G', type: 'fiber', status: 'up', txRateMbps: 192000, rxRateMbps: 185000, packetLossRate: 0.0001 },
      { id: 'SH-CR01-P2', name: 'GE0/1/1 (To SZ-CR-01)', speed: '400G', type: 'fiber', status: 'up', txRateMbps: 160000, rxRateMbps: 155000, packetLossRate: 0.0001 },
      { id: 'SH-CR01-P3', name: 'GE0/2/0 (To SH-CE-01 DC)', speed: '100G', type: 'fiber', status: 'up', txRateMbps: 88000, rxRateMbps: 85000, packetLossRate: 0.0 }
    ]
  },
  {
    id: 'HW-CR-SZ-01',
    name: '深圳湾区骨干核心路由器01 (SZ Core Router 01)',
    codeName: 'HW-NE8000-SZ1',
    type: 'router',
    layer: 'equipment',
    location: {
      city: 'Shenzhen',
      siteName: '深圳南山超算中心',
      lat: 22.5431,
      lng: 114.0579,
      x: 100,
      y: 10,
      z: 220,
      building: 'S5 大湾区计算中心',
      rackId: 'RACK-SZ-S08'
    },
    model: 'NetEngine 8000 X16',
    vendor: 'Horizon ICT Native',
    ipAddress: '10.240.0.3',
    status: 'healthy',
    cpuUsagePct: 22,
    memoryUsagePct: 39,
    temperatureC: 37.1,
    powerKw: 3.1,
    uptimeHours: 9800,
    ports: [
      { id: 'SZ-CR01-P1', name: 'GE0/1/0 (To BJ-CR-01)', speed: '400G', type: 'fiber', status: 'up', txRateMbps: 138000, rxRateMbps: 140000, packetLossRate: 0.0001 },
      { id: 'SZ-CR01-P2', name: 'GE0/1/1 (To SH-CR-01)', speed: '400G', type: 'fiber', status: 'up', txRateMbps: 155000, rxRateMbps: 160000, packetLossRate: 0.0001 }
    ]
  },

  // Optical Transport
  {
    id: 'OSN-BJ-01',
    name: '北京OTN全光交叉传输节点 (BJ OSN DWDM ROADM)',
    codeName: 'OSN-9800-BJ',
    type: 'optical',
    layer: 'equipment',
    location: {
      city: 'Beijing',
      siteName: '北京亦庄核心枢纽',
      lat: 39.9042,
      lng: 116.4074,
      x: -110,
      y: 8,
      z: -170
    },
    model: 'OptiX OSN 9800 U64',
    vendor: 'Horizon ICT Native',
    ipAddress: '10.240.10.1',
    status: 'healthy',
    cpuUsagePct: 18,
    memoryUsagePct: 31,
    temperatureC: 34.2,
    powerKw: 2.8,
    uptimeHours: 15000,
    ports: [
      { id: 'OSN-BJ-LAMBDA-1', name: 'C-Band Wavelength 193.1THz', speed: '800G', type: 'optical', status: 'up', txRateMbps: 620000, rxRateMbps: 615000, packetLossRate: 0.0 }
    ]
  },

  // Data Center Fabric Switches
  {
    id: 'HW-CE-BJ-01',
    name: '北京DC-1 Core Switch (BJ Fabric Switch 01)',
    codeName: 'CloudEngine 16800-BJ',
    type: 'switch',
    layer: 'equipment',
    location: {
      city: 'Beijing',
      siteName: '北京亦庄云计算中心',
      lat: 39.9042,
      lng: 116.4074,
      x: -130,
      y: 12,
      z: -190,
      rackId: 'RACK-BJ-A12'
    },
    model: 'CloudEngine 16800-48CQ',
    vendor: 'Horizon ICT Native',
    ipAddress: '10.240.20.1',
    status: 'healthy',
    cpuUsagePct: 41,
    memoryUsagePct: 52,
    temperatureC: 41.0,
    powerKw: 1.8,
    uptimeHours: 6500,
    ports: [
      { id: 'CE-BJ01-P1', name: '400GE1/0/1 (To Server Cluster)', speed: '400G', type: 'fiber', status: 'up', txRateMbps: 210000, rxRateMbps: 205000, packetLossRate: 0.0 }
    ]
  },
  {
    id: 'HW-CE-SH-01',
    name: '上海金融DC Core Switch (SH Fabric Switch 01)',
    codeName: 'CloudEngine 16800-SH',
    type: 'switch',
    layer: 'equipment',
    location: {
      city: 'Shanghai',
      siteName: '上海浦东金融数据中心',
      lat: 31.2304,
      lng: 121.4737,
      x: 160,
      y: 10,
      z: 70,
      rackId: 'RACK-SH-F01'
    },
    model: 'CloudEngine 16800-48CQ',
    vendor: 'Horizon ICT Native',
    ipAddress: '10.240.20.2',
    status: 'healthy',
    cpuUsagePct: 38,
    memoryUsagePct: 49,
    temperatureC: 39.8,
    powerKw: 1.7,
    uptimeHours: 11200,
    ports: [
      { id: 'CE-SH01-P1', name: '400GE1/0/1 (To FinServer Cluster)', speed: '400G', type: 'fiber', status: 'up', txRateMbps: 290000, rxRateMbps: 285000, packetLossRate: 0.0 }
    ]
  },

  // Base Stations (5G / 5.5G)
  {
    id: '5G-BS-BJ-01',
    name: '北京朝阳CBD 5.5G AAUnode 01',
    codeName: 'AAU5613-BJ-CBD',
    type: 'base_station',
    layer: 'equipment',
    location: {
      city: 'Beijing',
      siteName: '北京朝阳CBD 5G宏站',
      lat: 39.9123,
      lng: 116.4589,
      x: -50,
      y: 45,
      z: -120
    },
    model: 'MetaAAU 64T64R 5.5G',
    vendor: 'Horizon ICT Native',
    ipAddress: '10.240.50.1',
    status: 'healthy',
    cpuUsagePct: 33,
    memoryUsagePct: 40,
    temperatureC: 43.1,
    powerKw: 1.2,
    uptimeHours: 4300,
    ports: [
      { id: 'BS-BJ01-RF1', name: 'Sub-6GHz N78 100MHz', speed: '10Gbps', type: 'ethernet', status: 'up', txRateMbps: 8500, rxRateMbps: 2100, packetLossRate: 0.0002 }
    ]
  },
  {
    id: '5G-BS-SZ-01',
    name: '深圳南山高新区 5G AAU 01',
    codeName: 'AAU5613-SZ-NS',
    type: 'base_station',
    layer: 'equipment',
    location: {
      city: 'Shenzhen',
      siteName: '深圳高新技术产业园5G基站',
      lat: 22.5388,
      lng: 113.9452,
      x: 80,
      y: 40,
      z: 200
    },
    model: 'MetaAAU 64T64R 5G',
    vendor: 'Horizon ICT Native',
    ipAddress: '10.240.50.2',
    status: 'healthy',
    cpuUsagePct: 29,
    memoryUsagePct: 37,
    temperatureC: 44.5,
    powerKw: 1.1,
    uptimeHours: 7200,
    ports: [
      { id: 'BS-SZ01-RF1', name: 'Sub-6GHz N79 100MHz', speed: '10Gbps', type: 'ethernet', status: 'up', txRateMbps: 7200, rxRateMbps: 1800, packetLossRate: 0.0001 }
    ]
  },

  // Data Center Servers
  {
    id: 'SRV-BJ-01',
    name: '北京AI算力集群节点 SRV-BJ-01',
    codeName: 'Kunpeng 920-Cluster1',
    type: 'server',
    layer: 'equipment',
    location: {
      city: 'Beijing',
      siteName: '北京亦庄云计算中心',
      lat: 39.9042,
      lng: 116.4074,
      x: -128,
      y: 5,
      z: -188,
      rackId: 'RACK-BJ-A12'
    },
    model: 'Taishan 2020 Server (64 Core x2)',
    vendor: 'Horizon ICT Native',
    ipAddress: '192.168.10.12',
    status: 'healthy',
    cpuUsagePct: 45,
    memoryUsagePct: 62,
    temperatureC: 32.0,
    powerKw: 0.65,
    uptimeHours: 4200,
    ports: [
      { id: 'SRV-BJ01-NIC1', name: 'ETH0 100GE', speed: '100G', type: 'ethernet', status: 'up', txRateMbps: 42000, rxRateMbps: 38000, packetLossRate: 0.0 }
    ]
  },
  {
    id: 'SRV-SH-01',
    name: '上海核心金融高频交易服务器 SRV-SH-01',
    codeName: 'Kunpeng 920-FinCore',
    type: 'server',
    layer: 'equipment',
    location: {
      city: 'Shanghai',
      siteName: '上海浦东金融数据中心',
      lat: 31.2304,
      lng: 121.4737,
      x: 158,
      y: 5,
      z: 78,
      rackId: 'RACK-SH-F01'
    },
    model: 'Taishan 2280 V2 Server',
    vendor: 'Horizon ICT Native',
    ipAddress: '192.168.20.18',
    status: 'healthy',
    cpuUsagePct: 52,
    memoryUsagePct: 71,
    temperatureC: 30.5,
    powerKw: 0.72,
    uptimeHours: 11000,
    ports: [
      { id: 'SRV-SH01-NIC1', name: 'ETH0 100GE', speed: '100G', type: 'ethernet', status: 'up', txRateMbps: 65000, rxRateMbps: 61000, packetLossRate: 0.0 }
    ]
  }
];

export const SIMULATION_LINKS: NetworkLink[] = [
  {
    id: 'LINK-BJ-SH-400G-A',
    name: '京沪400G SRv6主干光缆 (Beijing <-> Shanghai Fiber)',
    type: 'SRv6',
    layer: 'network',
    sourceDeviceId: 'HW-CR-BJ-01',
    sourcePortId: 'BJ-CR01-P1',
    targetDeviceId: 'HW-CR-SH-01',
    targetPortId: 'SH-CR01-P1',
    bandwidthGbps: 400,
    currentUtilizationPct: 47.5,
    latencyMs: 14.2,
    packetLossRate: 0.0001,
    status: 'healthy',
    fiberDistanceKm: 1210
  },
  {
    id: 'LINK-BJ-SZ-400G-A',
    name: '京深400G OTN备用干线 (Beijing <-> Shenzhen Fiber)',
    type: 'Optical',
    layer: 'network',
    sourceDeviceId: 'HW-CR-BJ-01',
    sourcePortId: 'BJ-CR01-P2',
    targetDeviceId: 'HW-CR-SZ-01',
    targetPortId: 'SZ-CR01-P1',
    bandwidthGbps: 400,
    currentUtilizationPct: 35.0,
    latencyMs: 22.8,
    packetLossRate: 0.0001,
    status: 'healthy',
    fiberDistanceKm: 2150
  },
  {
    id: 'LINK-SH-SZ-400G-A',
    name: '沪深400G 高速光缆通道 (Shanghai <-> Shenzhen Fiber)',
    type: 'SRv6',
    layer: 'network',
    sourceDeviceId: 'HW-CR-SH-01',
    sourcePortId: 'SH-CR01-P2',
    targetDeviceId: 'HW-CR-SZ-01',
    targetPortId: 'SZ-CR01-P2',
    bandwidthGbps: 400,
    currentUtilizationPct: 40.0,
    latencyMs: 16.5,
    packetLossRate: 0.0001,
    status: 'healthy',
    fiberDistanceKm: 1480
  },
  {
    id: 'LINK-BJ-DC1-INTERNAL',
    name: '北京亦庄DC核心交换网链 (BJ CR01 <-> Fabric CE01)',
    type: 'DC_Fabric',
    layer: 'network',
    sourceDeviceId: 'HW-CR-BJ-01',
    sourcePortId: 'BJ-CR01-P3',
    targetDeviceId: 'HW-CE-BJ-01',
    targetPortId: 'CE-BJ01-P1',
    bandwidthGbps: 100,
    currentUtilizationPct: 52.0,
    latencyMs: 0.8,
    packetLossRate: 0.0,
    status: 'healthy',
    fiberDistanceKm: 2
  },
  {
    id: 'LINK-SH-DC1-INTERNAL',
    name: '上海金融DC内联100G通道 (SH CR01 <-> Fabric CE01)',
    type: 'DC_Fabric',
    layer: 'network',
    sourceDeviceId: 'HW-CR-SH-01',
    sourcePortId: 'SH-CR01-P3',
    targetDeviceId: 'HW-CE-SH-01',
    targetPortId: 'CE-SH01-P1',
    bandwidthGbps: 100,
    currentUtilizationPct: 88.0,
    latencyMs: 0.5,
    packetLossRate: 0.0,
    status: 'healthy',
    fiberDistanceKm: 1
  }
];

export const SIMULATION_SERVICES: ServiceNode[] = [
  {
    id: 'SVC-FIN-01',
    name: '跨区域极速金融交易VPN (FinTech Ultra-Low Latency VPN)',
    type: 'VPN',
    layer: 'service',
    slaTargetAvailability: 99.999,
    currentAvailability: 99.999,
    latencyTargetMs: 15.0,
    currentLatencyMs: 14.2,
    status: 'healthy',
    underlyingDeviceIds: ['HW-CR-BJ-01', 'HW-CR-SH-01', 'HW-CE-SH-01', 'SRV-SH-01'],
    underlyingLinkIds: ['LINK-BJ-SH-400G-A', 'LINK-SH-DC1-INTERNAL'],
    dependentApplicationIds: ['APP-BANKING-01'],
    subscriberCount: 2400
  },
  {
    id: 'SVC-5G-SLICE-01',
    name: '大湾区低时警智能驾驶 5G 切片 (Bay Area Autonomous 5G Slice)',
    type: '5G_Slice',
    layer: 'service',
    slaTargetAvailability: 99.99,
    currentAvailability: 99.99,
    latencyTargetMs: 20.0,
    currentLatencyMs: 18.5,
    status: 'healthy',
    underlyingDeviceIds: ['5G-BS-SZ-01', 'HW-CR-SZ-01'],
    underlyingLinkIds: ['LINK-SH-SZ-400G-A'],
    dependentApplicationIds: ['APP-AUTONOMOUS-01'],
    subscriberCount: 15000
  },
  {
    id: 'SVC-CLOUD-DC-01',
    name: '政企跨云混合专线通道 (Enterprise Hybrid Cloud Transit)',
    type: 'Cloud',
    layer: 'service',
    slaTargetAvailability: 99.95,
    currentAvailability: 99.98,
    latencyTargetMs: 30.0,
    currentLatencyMs: 22.8,
    status: 'healthy',
    underlyingDeviceIds: ['HW-CR-BJ-01', 'HW-CR-SZ-01', 'SRV-BJ-01'],
    underlyingLinkIds: ['LINK-BJ-SZ-400G-A', 'LINK-BJ-DC1-INTERNAL'],
    dependentApplicationIds: ['APP-SAAS-01'],
    subscriberCount: 82000
  }
];

export const SIMULATION_APPLICATIONS: ApplicationNode[] = [
  {
    id: 'APP-BANKING-01',
    name: '招商与工商核心高频结算系统 (Core Banking Settlement System)',
    codeName: 'FinCore-v4',
    layer: 'service',
    category: 'Banking',
    datacenterId: 'DC-SH-01',
    serverIds: ['SRV-SH-01'],
    serviceIds: ['SVC-FIN-01'],
    status: 'healthy',
    qoeScore: 99.4
  },
  {
    id: 'APP-AUTONOMOUS-01',
    name: '智能网联汽车V2X协同驾驶控制台 (V2X Autonomous Fleet Platform)',
    codeName: 'AutoPilot-Edge',
    layer: 'service',
    category: 'Autonomous_Driving',
    datacenterId: 'DC-SZ-01',
    serverIds: ['SRV-SZ-01'],
    serviceIds: ['SVC-5G-SLICE-01'],
    status: 'healthy',
    qoeScore: 98.8
  },
  {
    id: 'APP-SAAS-01',
    name: '全域智能企业协同SaaS集群 (Enterprise Digital Workspace)',
    codeName: 'Horizon-Workspace',
    layer: 'service',
    category: 'Enterprise_SaaS',
    datacenterId: 'DC-BJ-01',
    serverIds: ['SRV-BJ-01'],
    serviceIds: ['SVC-CLOUD-DC-01'],
    status: 'healthy',
    qoeScore: 97.5
  }
];

export const SIMULATION_USERS: UserNode[] = [
  {
    id: 'USR-FIN-INST',
    name: '陆家嘴金融机构与证券交易终端群 (Lujiazui Financial Traders)',
    layer: 'user',
    userGroup: 'VIP_Customer',
    count: 3200,
    city: 'Shanghai',
    accessDeviceId: 'HW-CR-SH-01',
    connectedServiceIds: ['SVC-FIN-01'],
    experienceScore: 99.8,
    status: 'healthy'
  },
  {
    id: 'USR-5G-VEHICLES',
    name: '广深高速智能网联汽车终端 (Guang-Shen Highway Connected Vehicles)',
    layer: 'user',
    userGroup: 'IoT_Device_Cluster',
    count: 14500,
    city: 'Shenzhen',
    accessDeviceId: '5G-BS-SZ-01',
    connectedServiceIds: ['SVC-5G-SLICE-01'],
    experienceScore: 98.2,
    status: 'healthy'
  },
  {
    id: 'USR-BJ-ENTERPRISE',
    name: '北京朝阳总部与分支机构员工 (Beijing Enterprise Staff)',
    layer: 'user',
    userGroup: 'Enterprise_Branch',
    count: 52000,
    city: 'Beijing',
    accessDeviceId: 'HW-CR-BJ-01',
    connectedServiceIds: ['SVC-CLOUD-DC-01'],
    experienceScore: 97.9,
    status: 'healthy'
  }
];

export const SIMULATION_INTENTS: BusinessIntentNode[] = [
  {
    id: 'INTENT-01',
    title: '金融高频交易超低时延与零丢包保障 (FinTech Ultra-Low Latency & Zero Loss)',
    layer: 'intent',
    targetApplicationId: 'APP-BANKING-01',
    requiredLatencyMs: 15.0,
    requiredAvailability: 99.999,
    priority: 'Critical',
    energySavingMode: false,
    translatedPolicy: 'Policy #402: SRv6 Low Latency Path (BJ-SH Direct) + Redundant FlexE Slicing enabled',
    status: 'In_Effect'
  },
  {
    id: 'INTENT-02',
    title: '5G智能网联汽车高可靠时延切片 (V2X High Reliability Slicing)',
    layer: 'intent',
    targetApplicationId: 'APP-AUTONOMOUS-01',
    requiredLatencyMs: 20.0,
    requiredAvailability: 99.99,
    priority: 'High',
    energySavingMode: false,
    translatedPolicy: 'Policy #108: Dynamic PRB allocation on 5G-BS-SZ-01 + Edge Compute Preemption',
    status: 'In_Effect'
  }
];

export const INITIAL_ALARMS: AlarmItem[] = [
  {
    id: 'ALM-1001',
    timestamp: '09:42:10',
    severity: 'Minor',
    sourceEntityId: 'HW-CE-SH-01',
    sourceEntityName: '上海金融DC Core Switch',
    layer: 'equipment',
    title: '端口利用率上升警告 (Port Utilization High)',
    description: 'Port CE-SH01-P1 tx/rx throughput exceeded 85% threshold'
  }
];
