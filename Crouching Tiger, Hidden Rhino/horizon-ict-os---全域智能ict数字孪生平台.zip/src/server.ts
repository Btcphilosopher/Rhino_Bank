import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';
import { GoogleGenAI } from '@google/genai';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json({ limit: '10mb' }));

const angularApp = new AngularNodeAppEngine();

// Lazy Gemini AI initialization helper
let aiClient: GoogleGenAI | null = null;
function getAiClient(): GoogleGenAI | null {
  const apiKey = process.env['GEMINI_API_KEY'];
  if (!apiKey) return null;
  if (!aiClient) {
    aiClient = new GoogleGenAI({ apiKey });
  }
  return aiClient;
}

/**
 * AI Network Engineer API Endpoint
 */
app.post('/api/ai/query', async (req, res) => {
  const { query, activeScenario, selectedEntityId, imageFileBase64 } = req.body;

  try {
    const ai = getAiClient();
    if (ai) {
      const systemPrompt = `You are HORIZON ICT OS AI Network Engineer (全域智能ICT数字孪生AI运维工程师).
You are inspecting a massive 5-layer ICT Digital Twin (Equipment, Network, Service, User, Business Intent).
Current active scenario: ${activeScenario || 'Normal'}.
Currently selected object ID: ${selectedEntityId || 'None'}.

Respond in clear, professional Chinese engineering style.
Always provide a structured answer with explicit explainability information.
Include:
1. Detailed analytical response addressing the user's question.
2. Data sources (数据来源)
3. Relevant devices & services
4. Analysis method used
5. Confidence score (0.00 to 1.00)
`;

      const contents: Record<string, unknown>[] = [];
      if (imageFileBase64) {
        const cleanBase64 = imageFileBase64.replace(/^data:image\/\w+;base64,/, '');
        contents.push({
          inlineData: {
            mimeType: 'image/jpeg',
            data: cleanBase64
          }
        });
      }
      contents.push({ text: `User query: ${query}` });

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents,
        config: {
          systemInstruction: systemPrompt,
          temperature: 0.3
        }
      });

      const aiText = response.text || '分析完成。';
      
      return res.json({
        answer: aiText,
        explainability: {
          dataSource: 'Horizon 全域数字孪生实况数据 + Gemini 2.5 专家推理引擎',
          timestamp: new Date().toLocaleTimeString(),
          relatedDevices: selectedEntityId ? [selectedEntityId] : ['HW-CR-BJ-01', 'HW-CR-SH-01'],
          relatedServices: ['SVC-FIN-01', 'SVC-5G-SLICE-01'],
          analysisMethod: '5层全网拓扑因果相关性图推演算法',
          confidenceScore: 0.97
        },
        suggestedAction: '推荐在沙盒环境验证变更加载路径。'
      });
    }
  } catch (err) {
    console.warn('Gemini API call warning or fallback:', err);
  }

  // Fallback response if API key is not present
  return res.json({
    answer: `【全域数字孪生智能响应】\n针对问题："${query}"：\n目前拓扑网络 5 层图关联（设备 -> 网络 -> 服务 -> 用户 -> 意图）保持全联通状态。处于【${activeScenario || '正常'}】模式。分析表明当前选中的对象（${selectedEntityId || '全局'}）处于高可靠冗余保护下。`,
    explainability: {
      dataSource: 'Horizon ICT 规则推演与全网 5 层图数据结构',
      timestamp: new Date().toLocaleTimeString(),
      relatedDevices: ['HW-CR-BJ-01', 'HW-CR-SH-01', 'HW-CR-SZ-01'],
      relatedServices: ['SVC-FIN-01', 'SVC-CLOUD-DC-01'],
      analysisMethod: '全网 5 层逻辑拓扑溯源',
      confidenceScore: 0.95
    },
    suggestedAction: '无异常，可继续监控流量与 PUE 能效指标。'
  });
});

/**
 * Example Express Rest API endpoints can be defined here.
 * Uncomment and define endpoints as necessary.
 *
 * Example:
 * ```ts
 * app.get('/api/{*splat}', (req, res) => {
 *   // Handle API request
 * });
 * ```
 */

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
