# RHINOBANK CHINA DATA CENTRE OS (RhinoBank 中国数据中心运营平台)
## 架构总览 Architecture Overview

### 1. 核心定位 Core Mission
RhinoBank 中国数据中心运营平台（RhinoBank China Data Centre OS）是面向中国超大规模绿色算力基地、AI智算中心以及万卡级GPU集群的工业级一体化操作系统。平台将：
**物理基础设施 (Physical Infrastructure) → 遥测数据 (Telemetry) → 工程物理模型 (Engineering Physics) → 运行控制 (Operations) → 算电协同 (Compute-Power Coordination) → 基础设施金融 (Infrastructure Finance)**
贯穿为统一的数字底座。

### 2. 分层架构 Layered Architecture
```
┌─────────────────────────────────────────────────────────────┐
│                 RhinoBank 基础设施金融与决策终端             │
│   (Capex/Opex · DSCR/IRR · 算力远期与互换 · 资产支持证券 ABN) │
├─────────────────────────────────────────────────────────────┤
│                 算电协同智能优化引擎 (Flagship Engine)        │
│   (负荷转移 · 峰谷电价套利 · 检查点续训 · 零SLA违约推理保护) │
├─────────────────────────────────────────────────────────────┤
│                 智算集群与AI算力资源池 (Compute Pool)        │
│   (NVIDIA H800 / 华为昇腾 910B / NVLink / 算力小时 / 任务调度)│
├─────────────────────────────────────────────────────────────┤
│                 高保真工程数字孪生与动环机电 (Engineering)     │
│   (电气单线图 2N · 变压器 · 离心冷机 COP · CDU板换 · 微通道冷板)│
├─────────────────────────────────────────────────────────────┤
│                 OT / IT 网络分界与统一遥测接入网关             │
│   (Modbus · BACnet · SNMP · OPC-UA · 光纤测温网格 · 硬件安全) │
└─────────────────────────────────────────────────────────────┘
```

### 3. 技术栈实现
- **Android Native 端:** Kotlin, Jetpack Compose, Material 3 Industrial Navy Design, Coroutines, StateFlow, MVVM.
- **工程计算引擎:** 严格遵循流体力学、热工定律、电工三相功率平衡方程，杜绝虚假静态常数。
- **全系统双语架构:** 统一 i18n 字典，支持随时一键无缝热切换简体中文与英文。
