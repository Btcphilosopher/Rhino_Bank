# 安全架构与权限模型 (Security & Role-Based Access Control)

## 1. 角色体系 (RBAC)
- **集团总指挥 (Group Administrator):** 全局全域跨中心指挥调度。
- **数据中心总经理 (Data Centre Manager):** 单中心PUE考核、财务与供电指标。
- **电气工程师 (Electrical Engineer):** 110kV/10kV 供配电拓扑、变压器、UPS巡检。
- **制冷暖通工程师 (Cooling Engineer):** 冷机、CDU、水泵、微通道压力流量调控。
- **算力运营专家 (Compute Operator):** GPU集群任务分配、算电协同排期。
- **合规与审计 (Compliance & Audit):** 碳排放认证、GB50174等级保护核验。

## 2. 身份与控制鉴权
- 全链路基于 TLS 1.3 + 国密 SM2/SM3/SM4 加密支持。
- 关键电力倒闸或制冷切泵必须遵循双人复核审批原则。
