# 接口架构规范 (Telemetry & Operations API Specification)

## 1. 核心端点结构
- `GET /api/v1/fleet/overview` - 获取全国6大算力枢纽实时聚合指标
- `GET /api/v1/dc/{dc_id}/sld` - 获取指定数据中心电气主接线图 (单线图) 状态
- `GET /api/v1/dc/{dc_id}/cooling_loop` - 获取冷冻水与CDU芯片二次液冷回路状态
- `GET /api/v1/dc/{dc_id}/racks` - 获取机房机柜矩阵温场与功率遥测
- `GET /api/v1/compute/workloads` - 获取实时GPU算力池任务与优先级
- `POST /api/v1/compute_power/shift/approve` - 批准下发算电协同错峰排期计划
- `GET /api/v1/finance/unit_economics` - 获取单卡度电与合成算力衍生品公允价值
- `POST /api/v1/copilot/query` - 向智能运维助手发起基于物理遥测的工程计算问答
