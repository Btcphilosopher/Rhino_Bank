# 供配电系统模型 (Power Infrastructure & Electrical Single-Line Architecture)

## 1. 单线接线拓扑 (Single-Line Diagram - 2N)
1. **电网引入 (Grid Infeed):** 国家电网 / 南方电网 110kV 双回路专线，双主变互为备用。
2. **总降变电站 (Substation):** 110kV 降压至 10kV 中压配电，容量 160 MVA。
3. **中压发电机并网 (MV Generators):** 10kV 柴油发电机组快速自启动与自动切换 ATS。
4. **大厅降压变压器 (Step-Down Transformers):** 10kV 降至 400V 干式变压器 (2N 冗余)。
5. **不间断供电 (UPS & HVDC):** 模块化高压直流 / 2N UPS 并机系统，配备磷酸铁锂 (LFP) BESS 储能柜。
6. **列头精密配电 (End-of-Row PDU):** 双路精密配电柜，实时监测三相平衡与谐波畸变 (THD)。
7. **机柜母线槽 (Busway & rPDU):** 滑轨母线插接箱，双路 A/B 智能机架配电单元。

## 2. 核心电气计算公式
- **视在功率:** $S = \sqrt{3} \times V \times I$ (kVA)
- **有功功率:** $P = S \times \cos\phi$ (kW)
- **功率因数 (PF):** $\cos\phi = \frac{P}{S} \approx 0.995$
- **负载率 (Loading):** $\eta = \frac{P_{actual}}{P_{rated}} \times 100\%$
