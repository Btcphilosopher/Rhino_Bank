# AI算力池与算电协同模型 (Compute Pool & Coordination)

## 1. 算力节点与硬件规格
- **NVIDIA HGX H800 80GB (SXM5):** 400Gbps NVLink 互联，单卡 TDP 700W，微通道直接液冷。
- **华为昇腾 (Ascend) 910B 64GB:** 392Gbps HCCS 全对等互联，信创大模型全栈推理与微调。

## 2. 算电协同调度策略 (Compute-Power Coordination)
```
电力现货价格信号 (现货价格 / 峰谷时段)
       ↓
识别弹性作业 (LLM预训练 Checkpointing / 图计算)
       ↓
评估时延与SLA敏感度 (在线高频推理严格不可平移)
       ↓
执行负荷时空平移 (峰段削减 53.7MW → 谷段释放 53.7MW)
       ↓
日节省能耗电费 ¥181,056 + 减少碳排放 29,600 kg
```
- **检查点状态保存 (Checkpointing):** 分布式训练状态以秒级刷入本地分布式高性能Ceph/NVMe-oF存储，并在谷电时钟触发时无缝唤醒。
