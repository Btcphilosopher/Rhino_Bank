# OT / IT 网络隔离架构 (OT / IT Physical & Logical Segregation)

## 1. 隔离边界原则
- **动环控制系统 (OT 网络):** 包含 PLC、DDC、SCADA、冷机控制器、变压器综保装置。禁止直接暴露于任何公网或普通办公网。
- **业务智算系统 (IT 网络):** RoCEv2 / InfiniBand 无损无拥塞 AI 集群、高速存储网。
- **单向物理安全网闸 / 工业数据代理 (DMZ Gateway):**
  - OT 端遥测数据经硬件物理隔离单向导入大数据与孪生分析平台。
  - 用户界面默认处于只读遥测模式 (Read-Only Telemetry Mode)。
  - 发送控制指令时必须切换至授权控制模式 (Authorised Control Mode)，并触发双人硬件鉴权。
