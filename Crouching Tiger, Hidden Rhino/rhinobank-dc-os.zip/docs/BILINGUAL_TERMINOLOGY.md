# 中英文专业术语对照规范 (Bilingual Terminology Reference)

| 简体中文 | English | 专业定义与工程范畴 |
|:---|:---|:---|
| 数据中心概览 | Data Centre Overview | 宏观全站机房运行总貌 |
| 实时功率 | Real-Time Power | 瞬时视在/有功功率 (MW / kW) |
| 电能利用效率 | Power Usage Effectiveness (PUE) | 全站总输入电能 / IT设备有效电能 |
| 水资源利用效率 | Water Usage Effectiveness (WUE) | 制冷耗水量 (L) / IT设备电能 (kWh) |
| 碳利用效率 | Carbon Usage Effectiveness (CUE) | 全站碳排放 (kgCO2e) / IT设备电能 (kWh) |
| 算力利用率 | Compute Utilisation | GPU激活核心与显存时间加权占比 |
| 算电协同 | Compute-Power Coordination | 算力负荷与电力市场价格/绿电出力联动机制 |
| 数据大厅 | Data Hall | 封闭式机架高密算力物理分区 |
| 机柜 | Rack | 42U~52U 高密服务器机架 (单柜 20kW~45kW) |
| 单线图 | Single-Line Diagram (SLD) | 电力系统三相供配电主接线拓扑 |
| 冷量分配单元 | Coolant Distribution Unit (CDU) | 隔离一次侧水质、精密调节芯片供液温差的设备 |
| 尖峰电价 | Critical Peak Tariff | 电网重负荷时段的高额惩罚性现货电价 |
| 谷段电价 | Valley Off-Peak Tariff | 夜间电力盈余优惠电价 |
| 绿色电力凭证 | Green Electricity Certificate (GEC) | 可再生能源非电属性环境价值唯一凭证 (绿证) |
| 资产支持票据 | Asset-Backed Note (ABN) | 将算力租赁稳定现金流打包发行的证券化产品 |
| 算力远期 | Compute Forward | 约定未来固定时间以固定单价交割GPU算力时的合约 |
