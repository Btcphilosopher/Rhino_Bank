package com.example.core.model

data class CapexOpexMetrics(
    val initialCapexMillionRmb: Double,
    val monthlyOpexMillionRmb: Double,
    val electricityOpexSharePercent: Double,
    val hardwareDepreciationSharePercent: Double,
    val coolingAndMaintenanceSharePercent: Double,
    val financingCostSharePercent: Double
)

data class UnitEconomics(
    val costPerKwMonthRmb: Double,
    val costPerRackMonthRmb: Double,
    val costPerH800GpuHourRmb: Double,
    val revenuePerH800GpuHourRmb: Double,
    val grossMarginH800Percent: Double,
    val costPerAscendGpuHourRmb: Double,
    val revenuePerAscendGpuHourRmb: Double,
    val grossMarginAscendPercent: Double
)

data class ProjectFinanceReturn(
    val internalRateOfReturnIrrPercent: Double,
    val netPresentValueNpvMillionRmb: Double,
    val debtServiceCoverageRatioDscr: Double,
    val weightedAvgCostOfCapitalWaccPercent: Double,
    val paybackPeriodYears: Double,
    val returnOnInvestedCapitalRoicPercent: Double
)

enum class SyntheticContractType {
    COMPUTE_FORWARD,
    CAPACITY_SWAP,
    GPU_ASSET_BACKED_NOTE,
    TOTAL_RETURN_SWAP
}

data class SyntheticComputeInstrument(
    val contractId: String,
    val type: SyntheticContractType,
    val titleZh: String,
    val titleEn: String,
    val counterpartyZh: String,
    val counterpartyEn: String,
    val notionalMillionRmb: Double,
    val volumeGpuHours: Long,
    val tenorMonths: Int,
    val fixedPriceRmbPerGpuHour: Double,
    val currentMarketSpreadBps: Int,
    val markToMarketGainMillionRmb: Double,
    val status: String = "ACTIVE"
)
