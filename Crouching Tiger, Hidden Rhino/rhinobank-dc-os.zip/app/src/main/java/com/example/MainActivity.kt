package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.data.ChinaDataCentreRepository
import com.example.core.i18n.I18n
import com.example.core.i18n.Language
import com.example.ui.components.TopHeaderBar
import com.example.ui.screens.*
import com.example.ui.theme.*

enum class NavTab(val icon: ImageVector, val titleZh: String, val titleEn: String) {
    COMMAND_CENTER(Icons.Default.Dashboard, "总览指挥", "Overview"),
    DIGITAL_TWIN(Icons.Default.Dns, "数字孪生", "Digital Twin"),
    COMPUTE_POWER(Icons.Default.Bolt, "算电协同", "Coordination"),
    ENERGY_PUE(Icons.Default.Eco, "能源与PUE", "Energy & PUE"),
    FINANCE(Icons.Default.TrendingUp, "基础设施金融", "Finance"),
    ALARMS(Icons.Default.Warning, "运行告警", "Alerts"),
    FIELD_OPS(Icons.Default.QrCodeScanner, "现场巡检", "Field Ops"),
    COPILOT(Icons.Default.SmartToy, "智能运维", "AI Copilot")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppScreen()
            }
        }
    }
}

@Composable
fun MainAppScreen() {
    var language by remember { mutableStateOf(I18n.currentLanguage) }
    var currentTab by remember { mutableStateOf(NavTab.COMMAND_CENTER) }
    val alarms by ChinaDataCentreRepository.alarms.collectAsState()
    val unacknowledgedAlarms = alarms.count { !it.isAcknowledged }

    // Android predictive back navigation: return to Command Center
    BackHandler(enabled = currentTab != NavTab.COMMAND_CENTER) {
        currentTab = NavTab.COMMAND_CENTER
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(Navy900)
            .statusBarsPadding(),
        topBar = {
            TopHeaderBar(
                currentLanguage = language,
                onToggleLanguage = {
                    language = I18n.toggleLanguage()
                },
                activeAlertCount = unacknowledgedAlarms,
                onNavigateToAlerts = {
                    currentTab = NavTab.ALARMS
                }
            )
        },
        bottomBar = {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding(),
                color = Navy900,
                border = androidx.compose.foundation.BorderStroke(1.dp, GridDivider)
            ) {
                val scrollState = rememberScrollState()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(scrollState)
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    NavTab.values().forEach { tab ->
                        val isSelected = tab == currentTab
                        val tabColor = if (isSelected) SteelBlueMuted else Slate800
                        val borderColor = if (isSelected) SteelBlue else BorderMuted
                        val textColor = if (isSelected) Color.White else TextSecondary

                        Button(
                            onClick = { currentTab = tab },
                            modifier = Modifier
                                .height(38.dp)
                                .testTag("nav_tab_${tab.name.lowercase()}"),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                            shape = RoundedCornerShape(3.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = tabColor,
                                contentColor = textColor
                            ),
                            border = androidx.compose.foundation.BorderStroke(1.dp, borderColor)
                        ) {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = null,
                                tint = if (isSelected) CyanTealLight else TextSecondary,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = I18n.t(tab.titleZh, tab.titleEn),
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Navy900)
        ) {
            when (currentTab) {
                NavTab.COMMAND_CENTER -> ExecutiveCommandScreen(
                    onSelectDataCentre = { dc ->
                        ChinaDataCentreRepository.selectDataCentre(dc)
                        currentTab = NavTab.DIGITAL_TWIN
                    },
                    onNavigateToDigitalTwin = { currentTab = NavTab.DIGITAL_TWIN },
                    onNavigateToComputePower = { currentTab = NavTab.COMPUTE_POWER },
                    onNavigateToFinance = { currentTab = NavTab.FINANCE }
                )
                NavTab.DIGITAL_TWIN -> DigitalTwinScreen()
                NavTab.COMPUTE_POWER -> ComputePowerCoordinationScreen()
                NavTab.ENERGY_PUE -> EnergyPueScreen()
                NavTab.FINANCE -> FinancialTerminalScreen()
                NavTab.ALARMS -> AlarmsOperationsScreen()
                NavTab.FIELD_OPS -> TechnicianFieldScreen()
                NavTab.COPILOT -> CopilotScreen()
            }
        }
    }
}
