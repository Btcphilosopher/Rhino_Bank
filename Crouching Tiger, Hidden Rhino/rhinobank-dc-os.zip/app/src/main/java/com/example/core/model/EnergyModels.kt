package com.example.core.model

enum class TariffPeriod {
    CRITICAL_PEAK,
    PEAK,
    SHOULDER,
    VALLEY
}

data class TariffPeriodInfo(
    val hourRange: String,
    val type: TariffPeriod,
    val nameZh: String,
    val nameEn: String,
    val priceRmbPerKwh: Double
)

data class HourlyEnergyTelemetry(
    val hour: Int,
    val tariffType: TariffPeriod,
    val tariffPriceRmb: Double,
    val itLoadMw: Double,
    val totalPowerMw: Double,
    val livePue: Double,
    val renewableGenMw: Double,
    val hourlyCostRmb: Double
)

data class GreenEnergyCertificate(
    val certId: String,
    val projectZh: String,
    val projectEn: String,
    val energyTypeZh: String,
    val energyTypeEn: String,
    val volumeMwh: Double,
    val tradingPriceRmbPerMwh: Double,
    val verificationStandard: String = "中国绿色电力交易凭证 / GEC"
)

data class CarbonEmissionsModel(
    val scope1DirectCo2Tons: Double,
    val scope2PurchasedElectricityCo2Tons: Double,
    val scope3SupplyChainCo2Tons: Double,
    val gridCarbonFactorKgCo2PerKwh: Double, // China Regional Grid e.g. 0.5703
    val kgCo2ePerKwhIt: Double,
    val kgCo2ePerGpuHour: Double,
    val avoidedCo2ViaRenewablesTons: Double
)
