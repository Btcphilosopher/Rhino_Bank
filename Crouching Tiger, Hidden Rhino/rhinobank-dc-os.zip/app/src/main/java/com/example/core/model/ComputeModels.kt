package com.example.core.model

enum class WorkloadPriority {
    CRITICAL_INFERENCE, // Latency sensitive, strictly non-shiftable
    HIGH_TRAINING,      // Standard SLA
    FLEXIBLE_BATCH      // Opportunistic / fault-tolerant batch training, shiftable to valley hours
}

data class AiWorkload(
    val id: String,
    val nameZh: String,
    val nameEn: String,
    val clientZh: String,
    val clientEn: String,
    val modelArchitecture: String,
    val gpuType: String,
    val allocatedGpus: Int,
    val powerDrawMw: Double,
    val priority: WorkloadPriority,
    val progressPercent: Double,
    val canShiftSchedule: Boolean,
    val estimatedHoursRemaining: Double
)

data class ComputePowerShiftProposal(
    val proposalId: String,
    val titleZh: String,
    val titleEn: String,
    val workloadId: String,
    val currentExecutionHour: String,
    val suggestedExecutionHour: String,
    val shiftedPowerMw: Double,
    val priceDiffRmbPerKwh: Double,
    val dailySavingsRmb: Double,
    val carbonReductionKg: Double,
    val slaImpactZh: String,
    val slaImpactEn: String,
    var isApproved: Boolean = false
)

data class ComputePoolStats(
    val totalGpus: Int,
    val activeGpus: Int,
    val reservedGpus: Int,
    val idleGpus: Int,
    val totalComputePflops: Double,
    val activeComputePflops: Double,
    val overallUtilisationPercent: Double,
    val h800GpuCount: Int,
    val ascend910bGpuCount: Int,
    val b200GpuCount: Int
)
