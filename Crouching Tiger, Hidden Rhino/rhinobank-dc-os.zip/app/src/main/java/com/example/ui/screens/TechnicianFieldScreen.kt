package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.data.ChinaDataCentreRepository
import com.example.core.i18n.I18n
import com.example.core.model.RackNode
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*

@Composable
fun TechnicianFieldScreen() {
    val workOrders by ChinaDataCentreRepository.workOrders.collectAsState()
    val racks = ChinaDataCentreRepository.rackList

    var scannedRack by remember { mutableStateOf<RackNode>(racks[6]) } // Default to Rack A07
    var showRackPicker by remember { mutableStateOf(false) }

    var check1Passed by remember { mutableStateOf(true) }
    var check2Passed by remember { mutableStateOf(true) }
    var check3Passed by remember { mutableStateOf(false) } // Cold plate quick disconnect leak check

    var inspectionNote by remember { mutableStateOf("A07出风口41.5℃，已现场微调二次侧流量调节阀，无微渗漏。") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Navy900)
            .padding(horizontal = 12.dp),
        contentPadding = PaddingValues(vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Technician Mode Header
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderMuted, RoundedCornerShape(4.dp)),
                shape = RoundedCornerShape(4.dp),
                colors = CardDefaults.cardColors(containerColor = Slate800)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.QrCodeScanner,
                                contentDescription = null,
                                tint = CyanTealLight,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = I18n.t("现场工程师巡检终端 (离线可用)", "Field Technician Terminal (Offline Ready)"),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(2.dp))
                                .background(GreenIndustrial.copy(alpha = 0.2f))
                                .padding(horizontal = 5.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "NFC/二维码直连",
                                fontSize = 9.sp,
                                color = GreenIndustrial,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = I18n.t(
                            "扫描机柜物理电子铭牌标签 → 自动拉取动环遥测 → 巡检闭环签注与现场拍照记录",
                            "Scan rack e-tag QR code → Pull live telemetry → Inspection checklist sign-off & work orders"
                        ),
                        fontSize = 10.sp,
                        color = TextSecondary
                    )
                }
            }
        }

        // QR Code Scanner Simulation Action Bar
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SteelBlue, RoundedCornerShape(4.dp)),
                shape = RoundedCornerShape(4.dp),
                colors = CardDefaults.cardColors(containerColor = Slate800)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "已扫描机柜: ${scannedRack.rackNumber} (${scannedRack.id})",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "位置: 贵安A1大厅 Row-A | 额定: 45kW",
                                fontSize = 9.5.sp,
                                color = TextSecondary
                            )
                        }

                        Button(
                            onClick = { showRackPicker = !showRackPicker },
                            modifier = Modifier
                                .height(32.dp)
                                .testTag("scan_rack_button"),
                            shape = RoundedCornerShape(3.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = SteelBlueMuted)
                        ) {
                            Icon(imageVector = Icons.Default.QrCode, contentDescription = null, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = I18n.t("扫码切换机柜", "Scan QR Code"),
                                fontSize = 10.5.sp,
                                color = Color.White
                            )
                        }
                    }

                    if (showRackPicker) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = "快捷模拟扫码 (点击目标机柜):", fontSize = 10.sp, color = CyanTealLight)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            racks.take(6).forEach { r ->
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(2.dp))
                                        .background(if (r.id == scannedRack.id) SteelBlue else Navy900)
                                        .clickable {
                                            scannedRack = r
                                            showRackPicker = false
                                        }
                                        .padding(vertical = 4.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = r.rackNumber,
                                        fontSize = 10.sp,
                                        color = Color.White,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Scanned Rack Live Telemetry Box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(3.dp))
                            .background(Navy900)
                            .padding(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(text = "现场实测功率", fontSize = 8.5.sp, color = TextMuted)
                                Text(
                                    text = "${scannedRack.currentKw} kW",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SteelBlue,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Column {
                                Text(text = "冷通道进风", fontSize = 8.5.sp, color = TextMuted)
                                Text(
                                    text = "${scannedRack.inletTempC} ℃",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = CyanTealLight,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Column {
                                Text(text = "热通道出风", fontSize = 8.5.sp, color = TextMuted)
                                Text(
                                    text = "${scannedRack.outletTempC} ℃",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (scannedRack.outletTempC >= 40.0) RedIndustrial else TextPrimary,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Column {
                                Text(text = "U位占用率", fontSize = 8.5.sp, color = TextMuted)
                                Text(
                                    text = "${scannedRack.usedUnitsU} / ${scannedRack.totalUnitsU} U",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }

        // On-Site Inspection Checklist
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderMuted, RoundedCornerShape(4.dp)),
                shape = RoundedCornerShape(4.dp),
                colors = CardDefaults.cardColors(containerColor = Slate800)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    SectionHeader(
                        codePrefix = "CHECKLIST",
                        titleZh = "巡检标准核验项 (现场工程师签核)",
                        titleEn = "Standard Inspection Checklist",
                        badgeText = "国标 GB 50174"
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Item 1
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { check1Passed = !check1Passed }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = check1Passed,
                            onCheckedChange = { check1Passed = it },
                            colors = CheckboxDefaults.colors(checkedColor = GreenIndustrial)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "双路rPDU A/B回路负载平衡，脱扣报警机构完好",
                            fontSize = 10.5.sp,
                            color = TextPrimary
                        )
                    }

                    // Item 2
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { check2Passed = !check2Passed }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = check2Passed,
                            onCheckedChange = { check2Passed = it },
                            colors = CheckboxDefaults.colors(checkedColor = GreenIndustrial)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "机柜前后门密封毛刷完好，冷热通道气流无严重窜流",
                            fontSize = 10.5.sp,
                            color = TextPrimary
                        )
                    }

                    // Item 3
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { check3Passed = !check3Passed }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = check3Passed,
                            onCheckedChange = { check3Passed = it },
                            colors = CheckboxDefaults.colors(checkedColor = GreenIndustrial)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "芯片冷板快速断开接头(QDC)无任何水渍微渗漏",
                            fontSize = 10.5.sp,
                            color = if (!check3Passed) AmberIndustrial else TextPrimary
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedTextField(
                        value = inspectionNote,
                        onValueChange = { inspectionNote = it },
                        label = { Text("巡检工程师现场备注 / 异常记录", fontSize = 10.sp) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("inspection_notes_field"),
                        textStyle = LocalTextStyle.current.copy(fontSize = 10.sp, color = TextPrimary),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SteelBlue,
                            unfocusedBorderColor = BorderMuted
                        )
                    )
                }
            }
        }

        // Field Work Orders (Interactive Toggle)
        item {
            SectionHeader(
                codePrefix = "WORK-ORDERS",
                titleZh = "关联设备维护工单 (点击签认完成)",
                titleEn = "Related Work Orders (Tap to Complete)",
                badgeText = "${workOrders.size} 张工单"
            )
        }

        items(workOrders) { wo ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        if (wo.isCompleted) GreenIndustrial else AmberIndustrial,
                        RoundedCornerShape(4.dp)
                    )
                    .clickable { ChinaDataCentreRepository.toggleWorkOrder(wo.id) }
                    .testTag("wo_card_${wo.id}"),
                shape = RoundedCornerShape(4.dp),
                colors = CardDefaults.cardColors(containerColor = Slate800)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "[${wo.id}] ${wo.titleZh}",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(2.dp))
                                .background(if (wo.isCompleted) GreenIndustrial else AmberIndustrial)
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = I18n.t(wo.statusZh, wo.statusEn),
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Black
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "设备: ${wo.equipmentCode} | 指派人: ${wo.technicianZh} | 创建: ${wo.createdTime}",
                        fontSize = 9.sp,
                        color = TextSecondary,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "作业指导: " + I18n.t(wo.instructionsZh, wo.instructionsEn),
                        fontSize = 9.sp,
                        color = CyanTealLight
                    )
                }
            }
        }
    }
}
