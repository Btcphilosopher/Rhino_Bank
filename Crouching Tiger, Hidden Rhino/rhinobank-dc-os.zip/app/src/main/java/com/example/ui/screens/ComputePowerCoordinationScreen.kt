package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.data.ChinaDataCentreRepository
import com.example.core.i18n.I18n
import com.example.core.model.TariffPeriod
import com.example.core.model.WorkloadPriority
import com.example.ui.components.EngineeringMetricBox
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*

@Composable
fun ComputePowerCoordinationScreen() {
    val shiftProposals by ChinaDataCentreRepository.shiftProposals.collectAsState()
    val activeWorkloads = ChinaDataCentreRepository.activeWorkloads
    val hourlyTrend = ChinaDataCentreRepository.hourlyEnergyTrend

    val totalPotentialSavings = shiftProposals.sumOf { it.dailySavingsRmb }
    val approvedCount = shiftProposals.count { it.isApproved }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Navy900)
            .padding(horizontal = 12.dp),
        contentPadding = PaddingValues(vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Flagship Header Banner
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, AmberIndustrial, RoundedCornerShape(4.dp)),
                shape = RoundedCornerShape(4.dp),
                colors = CardDefaults.cardColors(containerColor = Slate800)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = I18n.t("算电协同智能优化引擎", "Compute-Power Coordination Engine"),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(2.dp))
                                .background(AmberIndustrial.copy(alpha = 0.2f))
                                .border(0.5.dp, AmberIndustrial, RoundedCornerShape(2.dp))
                                .padding(horizontal = 5.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "电力市场价差联动",
                                fontSize = 9.sp,
                                color = AmberIndustrial,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = I18n.t(
                            "算力负荷 ↔ 峰谷电价 ↔ 冷却负荷 ↔ 电网容量。在保证在线推理零延迟的前提下，将弹性训练无缝调度至谷电时段，最大化综合收益并削减碳足迹。",
                            "Connects Compute Load ↔ Power Price ↔ Cooling ↔ Grid Capacity. Automatically shifts elastic pre-training to valley off-peak hours while safeguarding real-time inference SLAs."
                        ),
                        fontSize = 10.sp,
                        color = TextSecondary
                    )
                }
            }
        }

        // Key KPI Strip
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                EngineeringMetricBox(
                    titleZh = "协同调度预估日降本",
                    titleEn = "Est. Daily Savings",
                    value = "¥ 181,056",
                    unit = "",
                    headroomOrSubtitle = "月度预估节约: ¥543万",
                    modifier = Modifier.weight(1f)
                )
                EngineeringMetricBox(
                    titleZh = "峰谷可平移负荷",
                    titleEn = "Shiftable Capacity",
                    value = "53.7",
                    unit = "MW",
                    headroomOrSubtitle = "占IT总功率 54.6%",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // 24-Hour TOU Electricity Price vs Compute Load Curve
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderMuted, RoundedCornerShape(4.dp)),
                shape = RoundedCornerShape(4.dp),
                colors = CardDefaults.cardColors(containerColor = Slate800)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    SectionHeader(
                        codePrefix = "CURVE-24H",
                        titleZh = "24小时峰谷分时电价与算力功率曲线",
                        titleEn = "24H TOU Tariff vs Compute Power Curve",
                        badgeText = "尖峰 ¥1.485 vs 谷段 ¥0.285"
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Miniature 24-bar display of hourly price & load
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(60.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        hourlyTrend.forEach { point ->
                            val barHeightRatio = (point.tariffPriceRmb / 1.5).toFloat().coerceIn(0.15f, 1f)
                            val barColor = when (point.tariffType) {
                                TariffPeriod.CRITICAL_PEAK -> RedIndustrial
                                TariffPeriod.PEAK -> AmberIndustrial
                                TariffPeriod.SHOULDER -> SteelBlue
                                TariffPeriod.VALLEY -> CyanTealLight
                            }

                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth(0.7f)
                                        .fillMaxHeight(barHeightRatio)
                                        .clip(RoundedCornerShape(topStart = 1.dp, topEnd = 1.dp))
                                        .background(barColor)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "00:00 (谷电)", fontSize = 8.sp, color = CyanTealLight, fontFamily = FontFamily.Monospace)
                        Text(text = "10:00 (高峰)", fontSize = 8.sp, color = AmberIndustrial, fontFamily = FontFamily.Monospace)
                        Text(text = "15:00 (尖峰)", fontSize = 8.sp, color = RedIndustrial, fontFamily = FontFamily.Monospace)
                        Text(text = "23:00 (谷电)", fontSize = 8.sp, color = CyanTealLight, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        // Active Load Shift Proposals (Interactive Action)
        item {
            SectionHeader(
                codePrefix = "01/DISPATCH",
                titleZh = "待审批算电错峰调度计划",
                titleEn = "Pending Coordination Shift Proposals",
                badgeText = "已批准: $approvedCount / ${shiftProposals.size}"
            )
        }

        items(shiftProposals) { proposal ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        if (proposal.isApproved) GreenIndustrial else AmberIndustrial,
                        RoundedCornerShape(4.dp)
                    )
                    .testTag("proposal_card_${proposal.proposalId}"),
                shape = RoundedCornerShape(4.dp),
                colors = CardDefaults.cardColors(containerColor = Slate800)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = I18n.t(proposal.titleZh, proposal.titleEn),
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(2.dp))
                                .background(if (proposal.isApproved) GreenIndustrial else AmberIndustrial)
                                .padding(horizontal = 5.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = if (proposal.isApproved) I18n.t("已批准执行", "APPROVED") else I18n.t("待人工核准", "PENDING APPROVAL"),
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Black
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "原计划时段: ${proposal.currentExecutionHour}",
                        fontSize = 9.5.sp,
                        color = Color(0xFFFCA5A5),
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "协同建议时段: ${proposal.suggestedExecutionHour}",
                        fontSize = 9.5.sp,
                        color = CyanTealLight,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "平移功率: ${proposal.shiftedPowerMw} MW | 价差: ¥${proposal.priceDiffRmbPerKwh}/kWh",
                            fontSize = 9.sp,
                            color = TextSecondary,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "单日节约: ¥${proposal.dailySavingsRmb.toInt()}",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = GreenIndustrial,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "SLA保证: " + I18n.t(proposal.slaImpactZh, proposal.slaImpactEn),
                        fontSize = 8.5.sp,
                        color = TextMuted
                    )

                    if (!proposal.isApproved) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = { ChinaDataCentreRepository.approveProposal(proposal.proposalId) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(32.dp)
                                .testTag("approve_btn_${proposal.proposalId}"),
                            shape = RoundedCornerShape(3.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = AmberIndustrial)
                        ) {
                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = I18n.t("授权批准并下发调度指令", "Authorize & Dispatch Schedule"),
                                fontSize = 11.sp,
                                color = Color.Black,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Active Workload Pool Details
        item {
            SectionHeader(
                codePrefix = "02/WORKLOADS",
                titleZh = "实时智算任务池状态与优先级",
                titleEn = "Live AI Workload Pool & Priority Matrix",
                badgeText = "${activeWorkloads.size} 组核心负载"
            )
        }

        items(activeWorkloads) { wl ->
            val isCritical = wl.priority == WorkloadPriority.CRITICAL_INFERENCE
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderMuted, RoundedCornerShape(4.dp)),
                shape = RoundedCornerShape(4.dp),
                colors = CardDefaults.cardColors(containerColor = Slate800)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = I18n.t(wl.nameZh, wl.nameEn),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(2.dp))
                                .background(if (isCritical) RedIndustrial.copy(alpha = 0.2f) else SteelBlueMuted)
                                .border(0.5.dp, if (isCritical) RedIndustrial else SteelBlue, RoundedCornerShape(2.dp))
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = if (isCritical) "严格不可平移 (SLA < 10ms)" else "弹性错峰可平移",
                                fontSize = 8.sp,
                                color = if (isCritical) Color(0xFFFCA5A5) else Color(0xFFBFDBFE),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${wl.clientZh} · ${wl.gpuType} · 功率: ${wl.powerDrawMw} MW",
                        fontSize = 9.5.sp,
                        color = TextSecondary,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "训练进度: ${wl.progressPercent}%",
                            fontSize = 9.sp,
                            color = TextMuted,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = if (wl.estimatedHoursRemaining > 1000) "常驻在线推理" else "剩余约 ${wl.estimatedHoursRemaining.toInt()} 小时",
                            fontSize = 9.sp,
                            color = CyanTealLight,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    // Progress bar
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(3.dp)
                            .clip(RoundedCornerShape(1.dp))
                            .background(Navy900)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth((wl.progressPercent / 100.0).toFloat().coerceIn(0f, 1f))
                                .fillMaxHeight()
                                .background(if (isCritical) GreenIndustrial else SteelBlue)
                        )
                    }
                }
            }
        }
    }
}
