package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.data.ChinaDataCentreRepository
import com.example.core.i18n.I18n
import com.example.core.model.DataHall
import com.example.core.model.RackNode
import com.example.ui.components.RackMatrixGrid
import com.example.ui.components.SectionHeader
import com.example.ui.components.SingleLineDiagramFlow
import com.example.ui.theme.*

@Composable
fun DigitalTwinScreen() {
    var selectedHallIndex by remember { mutableIntStateOf(0) }
    val halls = ChinaDataCentreRepository.dataHalls
    val currentHall = halls[selectedHallIndex]

    var selectedRack by remember { mutableStateOf<RackNode?>(ChinaDataCentreRepository.rackList[6]) } // Default to Rack A07

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Navy900)
            .padding(horizontal = 12.dp),
        contentPadding = PaddingValues(vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Digital Twin Intro Banner
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderMuted, RoundedCornerShape(4.dp)),
                shape = RoundedCornerShape(4.dp),
                colors = CardDefaults.cardColors(containerColor = Slate800)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = I18n.t("物理基础设施数字孪生", "Physical Infrastructure Digital Twin"),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(2.dp))
                                .background(SteelBlueMuted)
                                .padding(horizontal = 5.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "工程级无虚构模型",
                                fontSize = 9.sp,
                                color = Color(0xFF93C5FD),
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = I18n.t(
                            "精确映射供配电拓扑、双回路UPS、冷冻水与芯片冷板二次回路、机房温场及GPU遥测",
                            "High-fidelity mapping of electrical topology, 2N UPS, chilled liquid loops, thermal field & GPU telemetry"
                        ),
                        fontSize = 10.sp,
                        color = TextSecondary
                    )
                }
            }
        }

        // Data Hall Selector Tabs
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                halls.forEachIndexed { index, hall ->
                    val isSelected = index == selectedHallIndex
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(3.dp))
                            .background(if (isSelected) SteelBlueMuted else Slate800)
                            .border(1.dp, if (isSelected) SteelBlue else BorderMuted, RoundedCornerShape(3.dp))
                            .clickable { selectedHallIndex = index }
                            .padding(vertical = 6.dp, horizontal = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = I18n.t(hall.nameZh.substringBefore(" "), hall.nameEn.substringBefore(" ")),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else TextPrimary
                            )
                            Text(
                                text = "${hall.coldAisleTempC}℃ / ${hall.hotAisleTempC}℃",
                                fontSize = 9.sp,
                                color = if (isSelected) Color(0xFFBFDBFE) else TextSecondary,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // Selected Hall Environmental Telemetry Strip
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderMuted, RoundedCornerShape(4.dp)),
                shape = RoundedCornerShape(4.dp),
                colors = CardDefaults.cardColors(containerColor = Slate800)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(text = I18n.t("冷通道平均温", "Cold Aisle Temp"), fontSize = 9.sp, color = TextMuted)
                        Text(
                            text = "${currentHall.coldAisleTempC} ℃",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = CyanTealLight
                        )
                    }
                    Column {
                        Text(text = I18n.t("热通道出风温", "Hot Aisle Temp"), fontSize = 9.sp, color = TextMuted)
                        Text(
                            text = "${currentHall.hotAisleTempC} ℃",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = AmberIndustrial
                        )
                    }
                    Column {
                        Text(text = I18n.t("大厅相对湿度", "Humidity"), fontSize = 9.sp, color = TextMuted)
                        Text(
                            text = "${currentHall.humidityPercent} %",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = TextPrimary
                        )
                    }
                    Column {
                        Text(text = I18n.t("机柜平均功率", "Avg Rack Power"), fontSize = 9.sp, color = TextMuted)
                        Text(
                            text = "${currentHall.avgKwPerRack} kW",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = SteelBlue
                        )
                    }
                }
            }
        }

        // Rack Matrix Grid (Interactive Heatmap)
        item {
            RackMatrixGrid(
                racks = ChinaDataCentreRepository.rackList,
                selectedRackId = selectedRack?.id,
                onSelectRack = { rack -> selectedRack = rack },
                modifier = Modifier.testTag("rack_matrix_grid")
            )
        }

        // Rack & Server Detailed Inspector
        selectedRack?.let { rack ->
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, SteelBlue, RoundedCornerShape(4.dp)),
                    shape = RoundedCornerShape(4.dp),
                    colors = CardDefaults.cardColors(containerColor = Slate800)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${I18n.t("机柜探针", "Rack Inspector")}: ${rack.rackNumber} (${rack.id})",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF93C5FD),
                                fontFamily = FontFamily.Monospace
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(if (rack.status == "WARNING") AmberIndustrial else GreenIndustrial)
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = rack.status,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "实时功率: ${rack.currentKw} kW / 额定: ${rack.ratedKw} kW",
                                fontSize = 10.sp,
                                color = TextPrimary,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "进风/出风: ${rack.inletTempC}℃ / ${rack.outletTempC}℃",
                                fontSize = 10.sp,
                                color = if (rack.outletTempC >= 40.0) RedIndustrial else TextSecondary,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Server Node details
                        val server = ChinaDataCentreRepository.sampleServer
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(3.dp))
                                .background(Navy900)
                                .border(0.5.dp, BorderMuted, RoundedCornerShape(3.dp))
                                .padding(8.dp)
                        ) {
                            Column {
                                Text(
                                    text = "${server.manufacturer} - ${server.model} [${server.unitLocation}]",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "CPU: ${server.cpuModel} | RAM: ${server.ramGb}GB ECC DDR5 | 单机功率: ${server.powerDrawW.toInt()}W",
                                    fontSize = 9.sp,
                                    color = TextSecondary,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "GPU加速卡: 8x ${server.gpuModel} (全直通微通道冷板连接)",
                                    fontSize = 9.sp,
                                    color = CyanTealLight
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // GPU Telemetry Grid (8 Chips)
                        Text(
                            text = I18n.t("8颗GPU加速芯片实时遥测 (SXM5)", "8x GPU Chips Real-Time Telemetry"),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        val gpus = ChinaDataCentreRepository.sampleGpus
                        gpus.chunked(2).forEach { gpuPair ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                gpuPair.forEach { gpu ->
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(2.dp))
                                            .background(Navy900)
                                            .border(0.5.dp, BorderMuted, RoundedCornerShape(2.dp))
                                            .padding(6.dp)
                                    ) {
                                        Column {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text(
                                                    text = "GPU #${gpu.index}",
                                                    fontSize = 9.5.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = SteelBlue,
                                                    fontFamily = FontFamily.Monospace
                                                )
                                                Text(
                                                    text = "%.1f%%".format(gpu.utilPercent),
                                                    fontSize = 9.5.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (gpu.utilPercent > 90.0) AmberIndustrial else GreenIndustrial,
                                                    fontFamily = FontFamily.Monospace
                                                )
                                            }
                                            Text(
                                                text = "显存: ${gpu.vramUsedGb.toInt()} / ${gpu.vramTotalGb.toInt()} GB | 核心温: ${gpu.tempC}℃",
                                                fontSize = 8.sp,
                                                color = TextSecondary,
                                                fontFamily = FontFamily.Monospace
                                            )
                                            Text(
                                                text = "功率: ${gpu.powerDrawW.toInt()}W / NVLink: ${gpu.interconnectBandwidthGbps.toInt()}GB/s",
                                                fontSize = 8.sp,
                                                color = TextMuted,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Single-Line Electrical Diagram (SLD)
        item {
            SingleLineDiagramFlow(nodes = ChinaDataCentreRepository.singleLineDiagramNodes)
        }

        // Liquid Cooling Loop Schematic
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderMuted, RoundedCornerShape(4.dp)),
                shape = RoundedCornerShape(4.dp),
                colors = CardDefaults.cardColors(containerColor = Slate800)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    SectionHeader(
                        codePrefix = "COOL-LOOP",
                        titleZh = "冷水与芯片冷板二次回路运行遥测",
                        titleEn = "Liquid Cooling Primary & Secondary Loop",
                        badgeText = "CDU二次回路 (进32℃ / 出46.2℃)"
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    ChinaDataCentreRepository.coolingLoopNodes.forEach { loop ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(Navy900)
                                .border(0.5.dp, BorderMuted, RoundedCornerShape(3.dp))
                                .padding(8.dp)
                        ) {
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = I18n.t(loop.componentTypeZh, loop.componentTypeEn),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = TextPrimary
                                    )
                                    Text(
                                        text = loop.identifier,
                                        fontSize = 10.sp,
                                        color = CyanTealLight,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }

                                Spacer(modifier = Modifier.height(2.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "供水/回水: ${loop.supplyTempC}℃ / ${loop.returnTempC}℃ | 流量: ${loop.flowRateLpm.toInt()} L/min",
                                        fontSize = 9.sp,
                                        color = TextSecondary,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = "COP: ${loop.cop}",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = GreenIndustrial,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "回路压力: ${loop.pressureKpa.toInt()} kPa | 电耗: ${loop.powerKw.toInt()} kW",
                                        fontSize = 8.5.sp,
                                        color = TextMuted,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = if (loop.leakDetected) "漏液警报" else "绳式光纤漏液无渗漏",
                                        fontSize = 8.5.sp,
                                        color = if (loop.leakDetected) RedIndustrial else GreenIndustrial,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
