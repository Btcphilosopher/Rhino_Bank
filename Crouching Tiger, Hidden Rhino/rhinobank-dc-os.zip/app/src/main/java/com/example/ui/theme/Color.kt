package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Industrial Navy / Graphite Palette
val Navy900 = Color(0xFF090D16) // Deepest backdrop
val Navy800 = Color(0xFF0F172A) // Workspace canvas
val Slate800 = Color(0xFF1E293B) // Card & module surfaces
val Slate700 = Color(0xFF334155) // Elevated panel & border
val SteelBlue = Color(0xFF388BFD) // Engineering Primary blue
val SteelBlueMuted = Color(0xFF1E3A8A)

val CyanTeal = Color(0xFF0D9488) // Secondary / Cold aisle / Liquid loop
val CyanTealLight = Color(0xFF14B8A6)

val AmberIndustrial = Color(0xFFD97706) // Restrained Amber / Warning / Peak tariff
val RedIndustrial = Color(0xFFDC2626) // Restrained Red / Critical Alarm / Hot Aisle
val GreenIndustrial = Color(0xFF059669) // Restrained Green / Normal / Renewable

val TextPrimary = Color(0xFFF1F5F9) // Clean White-Grey
val TextSecondary = Color(0xFF94A3B8) // Cool Grey
val TextMuted = Color(0xFF64748B) // Slate Grey
val BorderMuted = Color(0xFF2E3E58)
val GridDivider = Color(0xFF1F2B3E)
