package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = SteelBlue,
    onPrimary = Color.White,
    primaryContainer = SteelBlueMuted,
    onPrimaryContainer = Color(0xFFDCEBFE),
    secondary = CyanTealLight,
    onSecondary = Color.Black,
    secondaryContainer = CyanTeal,
    onSecondaryContainer = Color.White,
    tertiary = AmberIndustrial,
    onTertiary = Color.White,
    background = Navy900,
    onBackground = TextPrimary,
    surface = Slate800,
    onSurface = TextPrimary,
    surfaceVariant = Slate700,
    onSurfaceVariant = TextSecondary,
    outline = BorderMuted,
    error = RedIndustrial,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Default to deep industrial dark workstation theme
    dynamicColor: Boolean = false, // Keep consistent institutional palette
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
