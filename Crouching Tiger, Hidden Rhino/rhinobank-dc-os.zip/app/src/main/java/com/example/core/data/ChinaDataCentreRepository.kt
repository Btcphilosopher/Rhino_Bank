package com.example.core.data

import com.example.core.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object ChinaDataCentreRepository {

    // 1. National Fleet of Data Centres across China
    val dataCentres = listOf(
        DataCentreNode(
            id = "DC-GZ-01",
            nameZh = "贵州贵安超算与智算枢纽基地",
            nameEn = "Guizhou Gui'an Supercomputing & AI Hub",
            provinceZh = "贵州",
            provinceEn = "Guizhou",
            cityZh = "安顺 / 贵阳",
            cityEn = "Gui'an New Area",
            campusZh = "贵安绿色数据中心产业园 A区",
            campusEn = "Gui'an Green Industrial Campus A",
            designItCapacityMw = 120.0,
            actualItCapacityMw = 98.4,
            totalPowerMw = 112.2,
            designPue = 1.15,
            livePue = 1.140,
            wue = 0.42,
            cue = 0.31,
            renewableRatio = 0.88,
            rackCount = 4800,
            serverCount = 19200,
            gpuCount = 38400,
            computePflops = 1536.0,
            coolingMethodZh = "全浸没+冷板式间接蒸发双循环液冷",
            coolingMethodEn = "Hybrid Immersion & Cold-Plate Direct Liquid",
            status = "OPERATIONAL"
        ),
        DataCentreNode(
            id = "DC-NM-02",
            nameZh = "内蒙古乌兰察布风光绿能算力中心",
            nameEn = "Inner Mongolia Ulanqab Green Energy DC",
            provinceZh = "内蒙古",
            provinceEn = "Inner Mongolia",
            cityZh = "乌兰察布",
            cityEn = "Ulanqab",
            campusZh = "集宁区草原云谷超大规模园区",
            campusEn = "Jining Cloud Valley Hyperscale Campus",
            designItCapacityMw = 160.0,
            actualItCapacityMw = 135.2,
            totalPowerMw = 155.5,
            designPue = 1.18,
            livePue = 1.150,
            wue = 0.35,
            cue = 0.24,
            renewableRatio = 0.94,
            rackCount = 6400,
            serverCount = 25600,
            gpuCount = 51200,
            computePflops = 2048.0,
            coolingMethodZh = "极致自然冷源风侧间接蒸发",
            coolingMethodEn = "Air-side Free Cooling & Indirect Evaporative",
            status = "OPERATIONAL"
        ),
        DataCentreNode(
            id = "DC-BJ-03",
            nameZh = "北京亦庄核心金融低时延智算中心",
            nameEn = "Beijing Yizhuang Core Financial Low-Latency DC",
            provinceZh = "北京",
            provinceEn = "Beijing",
            cityZh = "北京",
            cityEn = "Beijing",
            campusZh = "亦庄经济技术开发区金融科技园区",
            campusEn = "Yizhuang FinTech Compute Campus",
            designItCapacityMw = 60.0,
            actualItCapacityMw = 52.8,
            totalPowerMw = 64.4,
            designPue = 1.25,
            livePue = 1.220,
            wue = 0.85,
            cue = 0.58,
            renewableRatio = 0.52,
            rackCount = 2400,
            serverCount = 9600,
            gpuCount = 19200,
            computePflops = 768.0,
            coolingMethodZh = "磁悬浮冷水机组+封闭冷通道精密空调",
            coolingMethodEn = "Magnetic Bearing Chillers & Enclosed Cold Aisle",
            status = "OPERATIONAL"
        ),
        DataCentreNode(
            id = "DC-SH-04",
            nameZh = "上海临港跨境金融数据港基地",
            nameEn = "Shanghai Lingang FTZ Cross-Border Financial DC",
            provinceZh = "上海",
            provinceEn = "Shanghai",
            cityZh = "上海",
            cityEn = "Shanghai",
            campusZh = "临港自贸区国际数据港示范区",
            campusEn = "Lingang Free Trade Zone Data Port",
            designItCapacityMw = 80.0,
            actualItCapacityMw = 71.2,
            totalPowerMw = 88.3,
            designPue = 1.25,
            livePue = 1.240,
            wue = 0.78,
            cue = 0.55,
            renewableRatio = 0.61,
            rackCount = 3200,
            serverCount = 12800,
            gpuCount = 25600,
            computePflops = 1024.0,
            coolingMethodZh = "高能效变频水冷+板换自然冷却",
            coolingMethodEn = "VFD Chilled Water & Heat Exchanger Free Cooling",
            status = "OPERATIONAL"
        ),
        DataCentreNode(
            id = "DC-NX-05",
            nameZh = "宁夏中卫西部黄河云带绿色智算中心",
            nameEn = "Ningxia Zhongwei Western Cloud Valley DC",
            provinceZh = "宁夏",
            provinceEn = "Ningxia",
            cityZh = "中卫",
            cityEn = "Zhongwei",
            campusZh = "中卫西部云基地一期",
            campusEn = "Zhongwei Western Cloud Base Phase I",
            designItCapacityMw = 100.0,
            actualItCapacityMw = 84.0,
            totalPowerMw = 95.0,
            designPue = 1.15,
            livePue = 1.131,
            wue = 0.38,
            cue = 0.28,
            renewableRatio = 0.91,
            rackCount = 4000,
            serverCount = 16000,
            gpuCount = 32000,
            computePflops = 1280.0,
            coolingMethodZh = "全时段新风自然冷源技术",
            coolingMethodEn = "Direct Fresh Air Economizer Cooling",
            status = "OPERATIONAL"
        ),
        DataCentreNode(
            id = "DC-GD-06",
            nameZh = "广东深圳前海大湾区智算枢纽",
            nameEn = "Guangdong Shenzhen Qianhai GBA Compute Hub",
            provinceZh = "广东",
            provinceEn = "Guangdong",
            cityZh = "深圳",
            cityEn = "Shenzhen",
            campusZh = "前海深港合作区人工智能计算中心",
            campusEn = "Qianhai AI Innovation Campus",
            designItCapacityMw = 50.0,
            actualItCapacityMw = 44.5,
            totalPowerMw = 55.6,
            designPue = 1.26,
            livePue = 1.249,
            wue = 0.90,
            cue = 0.52,
            renewableRatio = 0.58,
            rackCount = 2000,
            serverCount = 8000,
            gpuCount = 16000,
            computePflops = 640.0,
            coolingMethodZh = "芯片级冷板微通道直接液冷",
            coolingMethodEn = "Direct-to-Chip Microchannel Cold Plate Liquid",
            status = "OPERATIONAL"
        )
    )

    private val _selectedDc = MutableStateFlow(dataCentres[0])
    val selectedDc: StateFlow<DataCentreNode> = _selectedDc.asStateFlow()

    fun selectDataCentre(dc: DataCentreNode) {
        _selectedDc.value = dc
    }

    // 2. Data Halls for Selected Data Centre
    val dataHalls = listOf(
        DataHall(
            id = "DH-A1",
            dcId = "DC-GZ-01",
            nameZh = "A1智算大厅 (NVIDIA H800集群)",
            nameEn = "Hall A1 (NVIDIA H800 Cluster)",
            areaM2 = 1850.0,
            rackCount = 120,
            activeRackCount = 118,
            avgKwPerRack = 32.5,
            maxKwPerRack = 45.0,
            coldAisleTempC = 21.2,
            hotAisleTempC = 34.6,
            humidityPercent = 48.5,
            coolingTypeZh = "冷板式微通道液冷 (进水32℃ / 出水46℃)",
            coolingTypeEn = "Cold-Plate Direct Liquid (32°C in / 46°C out)"
        ),
        DataHall(
            id = "DH-A2",
            dcId = "DC-GZ-01",
            nameZh = "A2信创大厅 (华为昇腾910B集群)",
            nameEn = "Hall A2 (Huawei Ascend 910B Cluster)",
            areaM2 = 1850.0,
            rackCount = 120,
            activeRackCount = 115,
            avgKwPerRack = 28.0,
            maxKwPerRack = 38.0,
            coldAisleTempC = 21.8,
            hotAisleTempC = 33.9,
            humidityPercent = 50.2,
            coolingTypeZh = "冷板直接液冷+热通道密封",
            coolingTypeEn = "Direct Liquid Cooling + Hot Aisle Containment"
        ),
        DataHall(
            id = "DH-B1",
            dcId = "DC-GZ-01",
            nameZh = "B1通用计算与PB级存储大厅",
            nameEn = "Hall B1 (General Compute & Distributed Storage)",
            areaM2 = 2400.0,
            rackCount = 240,
            activeRackCount = 230,
            avgKwPerRack = 12.5,
            maxKwPerRack = 16.0,
            coldAisleTempC = 22.5,
            hotAisleTempC = 32.1,
            humidityPercent = 52.0,
            coolingTypeZh = "列间精密风冷空调+间接蒸发",
            coolingTypeEn = "In-Row Precision Air Cooling"
        )
    )

    // 3. Representative Racks for Data Hall A1 (Row A01 - A12)
    val rackList = (1..12).map { index ->
        val rackCode = "A" + index.toString().padStart(2, '0')
        val isHot = index == 7
        val isWarning = index == 4
        RackNode(
            id = "RACK-GZ-$rackCode",
            hallId = "DH-A1",
            rowCode = "Row-A",
            rackNumber = rackCode,
            ratedKw = 45.0,
            currentKw = if (isHot) 42.8 else if (isWarning) 39.4 else 31.5 + (index % 5) * 1.8,
            powerFactor = 0.985,
            inletTempC = if (isHot) 26.2 else 21.0 + (index % 3) * 0.4,
            outletTempC = if (isHot) 41.5 else 34.0 + (index % 4) * 0.8,
            usedUnitsU = 38,
            serverCount = 8,
            gpuNodeCount = 8,
            status = if (isHot) "WARNING" else if (isWarning) "WARNING" else "NORMAL"
        )
    }

    // 4. Sample Server Node & GPUs inside Rack A07
    val sampleServer = ServerNode(
        id = "SRV-A07-U16",
        rackId = "RACK-GZ-A07",
        unitLocation = "U16-U19 (4U 高密智算节点)",
        manufacturer = "浪潮信息 / Inspur Information",
        model = "NF5688M6 AI Server",
        serialNumber = "SN-INSP-2025-88931A",
        cpuModel = "Dual Intel Xeon Platinum 8480+ (112 Cores)",
        ramGb = 2048,
        gpuModel = "NVIDIA HGX H800 80GB SXM5",
        gpuCount = 8,
        powerDrawW = 6850.0,
        inletTempC = 24.8,
        outletTempC = 39.2,
        healthStatus = "HEALTHY"
    )

    val sampleGpus = (0..7).map { idx ->
        val isHeavy = idx < 4
        GpuDevice(
            id = "GPU-A07-0$idx",
            serverId = "SRV-A07-U16",
            index = idx,
            model = "NVIDIA H800 80GB SXM5",
            utilPercent = if (isHeavy) 96.4 + (idx % 3) else 82.0 + (idx % 5),
            vramTotalGb = 80.0,
            vramUsedGb = if (isHeavy) 76.8 else 68.4,
            tempC = if (isHeavy) 68.5 + idx * 0.8 else 62.1 + idx * 0.5,
            powerDrawW = if (isHeavy) 695.0 else 580.0,
            maxPowerW = 700.0,
            isThrottling = false,
            interconnectBandwidthGbps = 400.0
        )
    }

    // 5. Electrical Infrastructure: Single Line Diagram Nodes
    val singleLineDiagramNodes = listOf(
        SingleLineDiagramNode(
            id = "SLD-01",
            stageOrder = 1,
            labelZh = "国家电网 110kV 双回路进线 (南方电网)",
            labelEn = "110 kV Dual-Circuit Main Grid Infeed",
            voltageLevel = "110 kV",
            redundancy = "2N",
            ratedCapacityMva = 160.0,
            currentLoadMw = 112.2,
            loadingPercent = 70.1,
            powerFactor = 0.99,
            status = "ONLINE"
        ),
        SingleLineDiagramNode(
            id = "SLD-02",
            stageOrder = 2,
            labelZh = "园区总降变电站 (110kV / 10kV 主变)",
            labelEn = "Substation 110kV/10kV Transformers",
            voltageLevel = "10 kV",
            redundancy = "2(N+1)",
            ratedCapacityMva = 150.0,
            currentLoadMw = 112.2,
            loadingPercent = 74.8,
            powerFactor = 0.985,
            status = "ONLINE"
        ),
        SingleLineDiagramNode(
            id = "SLD-03",
            stageOrder = 3,
            labelZh = "10kV 中压配电段 (中压发电机应急切换)",
            labelEn = "10 kV Medium Voltage Switchgear & ATS",
            voltageLevel = "10 kV",
            redundancy = "2N",
            ratedCapacityMva = 150.0,
            currentLoadMw = 112.2,
            loadingPercent = 74.8,
            powerFactor = 0.985,
            status = "ONLINE"
        ),
        SingleLineDiagramNode(
            id = "SLD-04",
            stageOrder = 4,
            labelZh = "数据大厅变压器 (10kV / 400V 干式变)",
            labelEn = "Data Hall 10kV/400V Step-down Transformers",
            voltageLevel = "400 V",
            redundancy = "2N",
            ratedCapacityMva = 140.0,
            currentLoadMw = 104.5,
            loadingPercent = 74.6,
            powerFactor = 0.99,
            status = "ONLINE"
        ),
        SingleLineDiagramNode(
            id = "SLD-05",
            stageOrder = 5,
            labelZh = "高压直流 / 模块化UPS系统 (锂电池BESS后备)",
            labelEn = "Modular 2N UPS & HVDC with Lithium BESS",
            voltageLevel = "400 V / 240V HVDC",
            redundancy = "2N",
            ratedCapacityMva = 130.0,
            currentLoadMw = 101.2,
            loadingPercent = 77.8,
            powerFactor = 0.992,
            status = "ONLINE"
        ),
        SingleLineDiagramNode(
            id = "SLD-06",
            stageOrder = 6,
            labelZh = "列头智能精密配电柜 (PDU A路 / B路)",
            labelEn = "End-of-Row Precision Power Distribution Units",
            voltageLevel = "400 V / 230 V",
            redundancy = "2N",
            ratedCapacityMva = 125.0,
            currentLoadMw = 98.4,
            loadingPercent = 78.7,
            powerFactor = 0.995,
            status = "ONLINE"
        ),
        SingleLineDiagramNode(
            id = "SLD-07",
            stageOrder = 7,
            labelZh = "机柜母线槽与高密双路rPDU (IT负载)",
            labelEn = "Busway Tap-off & Dual Rack PDUs (IT Load)",
            voltageLevel = "230 V (三相平衡)",
            redundancy = "2N",
            ratedCapacityMva = 120.0,
            currentLoadMw = 98.4,
            loadingPercent = 82.0,
            powerFactor = 0.998,
            status = "ONLINE"
        )
    )

    // 6. Cooling System Loop Telemetry
    val coolingLoopNodes = listOf(
        CoolingLoopNode(
            id = "COOL-CT-01",
            componentTypeZh = "开式闭路冷却塔组 (6台变频并联)",
            componentTypeEn = "Evaporative Cooling Towers",
            identifier = "CT-01~06",
            supplyTempC = 27.5,
            returnTempC = 33.2,
            flowRateLpm = 4800.0,
            pressureKpa = 320.0,
            cop = 9.8,
            powerKw = 210.0,
            status = "OPTIMAL"
        ),
        CoolingLoopNode(
            id = "COOL-CH-01",
            componentTypeZh = "高压离心变频水冷冷水机组",
            componentTypeEn = "VFD Centrifugal Water Chillers",
            identifier = "CH-01~04 (2000RT)",
            supplyTempC = 14.0,
            returnTempC = 20.5,
            flowRateLpm = 3600.0,
            pressureKpa = 450.0,
            cop = 6.42,
            powerKw = 1420.0,
            status = "OPTIMAL"
        ),
        CoolingLoopNode(
            id = "COOL-CDU-01",
            componentTypeZh = "机房级冷量分配单元 (CDU A1-01)",
            componentTypeEn = "Coolant Distribution Unit CDU-A1",
            identifier = "CDU-1200kW-01",
            supplyTempC = 32.0,
            returnTempC = 46.2,
            flowRateLpm = 850.0,
            pressureKpa = 280.0,
            cop = 14.5,
            powerKw = 45.0,
            leakDetected = false,
            status = "OPTIMAL"
        ),
        CoolingLoopNode(
            id = "COOL-PUMP-01",
            componentTypeZh = "一次侧冷冻水循环变频泵组",
            componentTypeEn = "Primary Chilled Water Circulation Pumps",
            identifier = "PUMP-PRI-01~05",
            supplyTempC = 14.0,
            returnTempC = 20.5,
            flowRateLpm = 3600.0,
            pressureKpa = 520.0,
            cop = 11.2,
            powerKw = 185.0,
            status = "OPTIMAL"
        )
    )

    // 7. PUE Engine Decomposition for Guizhou DC
    val currentPueDecomposition = PueDecomposition(
        itEquipmentLoadMw = 98.4,
        chillersLoadMw = 7.1,
        pumpsAndFansMw = 2.8,
        upsLossesMw = 2.4,
        transformersLossesMw = 1.1,
        lightingAndAuxMw = 0.4
    )

    // 8. 24-Hour TOU Tariff & Energy Curve (Peak, Shoulder, Valley)
    val hourlyTariffs = listOf(
        TariffPeriodInfo("00:00 - 08:00", TariffPeriod.VALLEY, "谷段优惠电价", "Valley Off-Peak Tariff", 0.285),
        TariffPeriodInfo("08:00 - 11:00", TariffPeriod.PEAK, "高峰时段电价", "Peak Tariff", 1.085),
        TariffPeriodInfo("11:00 - 14:00", TariffPeriod.SHOULDER, "平时段电价", "Shoulder Tariff", 0.695),
        TariffPeriodInfo("14:00 - 17:00", TariffPeriod.CRITICAL_PEAK, "夏季尖峰时段电价", "Critical Peak Tariff", 1.485),
        TariffPeriodInfo("17:00 - 19:00", TariffPeriod.SHOULDER, "平时段电价", "Shoulder Tariff", 0.695),
        TariffPeriodInfo("19:00 - 22:00", TariffPeriod.PEAK, "晚高峰时段电价", "Evening Peak Tariff", 1.120),
        TariffPeriodInfo("22:00 - 24:00", TariffPeriod.VALLEY, "谷段时段电价", "Valley Off-Peak Tariff", 0.285)
    )

    val hourlyEnergyTrend: List<HourlyEnergyTelemetry> = (0..23).map { hour ->
        val tariffType = when (hour) {
            in 0..7 -> TariffPeriod.VALLEY
            in 8..10 -> TariffPeriod.PEAK
            in 11..13 -> TariffPeriod.SHOULDER
            in 14..16 -> TariffPeriod.CRITICAL_PEAK
            in 17..18 -> TariffPeriod.SHOULDER
            in 19..21 -> TariffPeriod.PEAK
            else -> TariffPeriod.VALLEY
        }
        val price = when (tariffType) {
            TariffPeriod.VALLEY -> 0.285
            TariffPeriod.SHOULDER -> 0.695
            TariffPeriod.PEAK -> 1.085
            TariffPeriod.CRITICAL_PEAK -> 1.485
        }
        val itLoad = 96.0 + (hour % 6) * 1.2
        val totalPower = itLoad * 1.140
        HourlyEnergyTelemetry(
            hour = hour,
            tariffType = tariffType,
            tariffPriceRmb = price,
            itLoadMw = itLoad,
            totalPowerMw = totalPower,
            livePue = 1.138 + (hour % 4) * 0.002,
            renewableGenMw = 88.0 + (if (hour in 9..16) 18.0 else 0.0),
            hourlyCostRmb = totalPower * 1000 * price
        )
    }

    // 9. Active AI Workloads
    val activeWorkloads = listOf(
        AiWorkload(
            id = "WL-LLM-175B",
            nameZh = "Rhino-Qwen 175B 万亿Tokens预训练 (第4阶段)",
            nameEn = "Rhino-Qwen 175B Pre-training (Phase 4)",
            clientZh = "RhinoBank 金融人工智能研究院",
            clientEn = "RhinoBank AI Research Institute",
            modelArchitecture = "Transformer Dense 175B",
            gpuType = "NVIDIA H800 (16,384卡)",
            allocatedGpus = 16384,
            powerDrawMw = 42.5,
            priority = WorkloadPriority.FLEXIBLE_BATCH,
            progressPercent = 64.2,
            canShiftSchedule = true,
            estimatedHoursRemaining = 142.0
        ),
        AiWorkload(
            id = "WL-RISK-FIN",
            nameZh = "全行实时万亿级市场风险蒙特卡洛引擎",
            nameEn = "Real-Time Trillion-Scale Risk Monte Carlo",
            clientZh = "RhinoBank 集团全球风险管理部",
            clientEn = "RhinoBank Global Risk Management",
            modelArchitecture = "CUDA HPC Parallel Monte Carlo",
            gpuType = "NVIDIA H800 (4,096卡)",
            allocatedGpus = 4096,
            powerDrawMw = 10.8,
            priority = WorkloadPriority.CRITICAL_INFERENCE,
            progressPercent = 89.0,
            canShiftSchedule = false,
            estimatedHoursRemaining = 2.4
        ),
        AiWorkload(
            id = "WL-CHAT-AGENT",
            nameZh = "全国网点智能理财坐席高并发在线推理",
            nameEn = "National Branch Wealth Copilot Online Inference",
            clientZh = "零售银行与私行数字化部",
            clientEn = "Retail & Wealth Digital Division",
            modelArchitecture = "MoE 8x7B Int8 Quantized",
            gpuType = "Huawei Ascend 910B (8,192卡)",
            allocatedGpus = 8192,
            powerDrawMw = 21.0,
            priority = WorkloadPriority.CRITICAL_INFERENCE,
            progressPercent = 100.0,
            canShiftSchedule = false,
            estimatedHoursRemaining = 9999.0
        ),
        AiWorkload(
            id = "WL-VISION-AML",
            nameZh = "反洗钱图神经网络跨行资金链深度分析",
            nameEn = "Anti-Money Laundering Graph Neural Network",
            clientZh = "合规与反洗钱中心",
            clientEn = "Compliance & Anti-Money Laundering Dept",
            modelArchitecture = "GNN Heterogeneous Graph 10B",
            gpuType = "Huawei Ascend 910B (4,096卡)",
            allocatedGpus = 4096,
            powerDrawMw = 11.2,
            priority = WorkloadPriority.FLEXIBLE_BATCH,
            progressPercent = 42.5,
            canShiftSchedule = true,
            estimatedHoursRemaining = 18.0
        )
    )

    // 10. Compute-Power Coordination Shift Proposals (Flagship Feature)
    val _shiftProposals = MutableStateFlow(
        listOf(
            ComputePowerShiftProposal(
                proposalId = "PROP-2026-001",
                titleZh = "算电协同: 175B模型批量预训练削峰填谷调度",
                titleEn = "Coordination: 175B LLM Peak-to-Valley Load Shifting",
                workloadId = "WL-LLM-175B",
                currentExecutionHour = "14:00 - 17:00 (尖峰电价 ¥1.485/kWh)",
                suggestedExecutionHour = "00:00 - 06:00 (谷段电价 ¥0.285/kWh)",
                shiftedPowerMw = 42.5,
                priceDiffRmbPerKwh = 1.200,
                dailySavingsRmb = 153000.0,
                carbonReductionKg = 24200.0,
                slaImpactZh = "无核心业务影响，依托检查点续训机制无缝平移",
                slaImpactEn = "Zero SLA impact; uses seamless checkpoint resumption",
                isApproved = false
            ),
            ComputePowerShiftProposal(
                proposalId = "PROP-2026-002",
                titleZh = "算电协同: 反洗钱图计算夜间错峰运算优化",
                titleEn = "Coordination: Anti-Money Laundering Graph Night Shift",
                workloadId = "WL-VISION-AML",
                currentExecutionHour = "19:00 - 22:00 (晚高峰电价 ¥1.120/kWh)",
                suggestedExecutionHour = "01:00 - 04:00 (谷段电价 ¥0.285/kWh)",
                shiftedPowerMw = 11.2,
                priceDiffRmbPerKwh = 0.835,
                dailySavingsRmb = 28056.0,
                carbonReductionKg = 5400.0,
                slaImpactZh = "合规报送在次日07:00前交付，满足监管时限",
                slaImpactEn = "Delivers before 07:00 next day, fully compliant with CBRC",
                isApproved = true
            )
        )
    )
    val shiftProposals: StateFlow<List<ComputePowerShiftProposal>> = _shiftProposals.asStateFlow()

    fun approveProposal(proposalId: String) {
        _shiftProposals.value = _shiftProposals.value.map {
            if (it.proposalId == proposalId) it.copy(isApproved = true) else it
        }
    }

    // 11. Financial Engine Metrics
    val capexOpex = CapexOpexMetrics(
        initialCapexMillionRmb = 3850.0, // 38.5 亿元
        monthlyOpexMillionRmb = 42.6,    // 4260 万元/月
        electricityOpexSharePercent = 54.2,
        hardwareDepreciationSharePercent = 26.5,
        coolingAndMaintenanceSharePercent = 11.8,
        financingCostSharePercent = 7.5
    )

    val unitEconomics = UnitEconomics(
        costPerKwMonthRmb = 432.0,
        costPerRackMonthRmb = 13800.0,
        costPerH800GpuHourRmb = 13.80,
        revenuePerH800GpuHourRmb = 22.50,
        grossMarginH800Percent = 38.6,
        costPerAscendGpuHourRmb = 8.20,
        revenuePerAscendGpuHourRmb = 14.80,
        grossMarginAscendPercent = 44.5
    )

    val projectFinanceReturn = ProjectFinanceReturn(
        internalRateOfReturnIrrPercent = 14.8,
        netPresentValueNpvMillionRmb = 1280.0,
        debtServiceCoverageRatioDscr = 1.95,
        weightedAvgCostOfCapitalWaccPercent = 5.2,
        paybackPeriodYears = 5.4,
        returnOnInvestedCapitalRoicPercent = 16.2
    )

    // 12. Synthetic Compute Instruments (RhinoBank Engine)
    val syntheticInstruments = listOf(
        SyntheticComputeInstrument(
            contractId = "SYN-FWD-2026Q3",
            type = SyntheticContractType.COMPUTE_FORWARD,
            titleZh = "算力远期合约: 2026Q3 H800峰值算力锁定",
            titleEn = "Compute Forward: 2026Q3 H800 Peak Locking",
            counterpartyZh = "某大型头部云服务商",
            counterpartyEn = "Hyperscale Tier-1 Cloud Operator",
            notionalMillionRmb = 120.0,
            volumeGpuHours = 6000000,
            tenorMonths = 6,
            fixedPriceRmbPerGpuHour = 20.00,
            currentMarketSpreadBps = 145,
            markToMarketGainMillionRmb = 8.7,
            status = "ACTIVE"
        ),
        SyntheticComputeInstrument(
            contractId = "SYN-ABN-2026A",
            type = SyntheticContractType.GPU_ASSET_BACKED_NOTE,
            titleZh = "算力资产支持票据 (ABN): 绿色智算一期现金流证券化",
            titleEn = "GPU Asset-Backed Note: Green Compute Phase 1",
            counterpartyZh = "全国银行间债券市场机构投资者",
            counterpartyEn = "China Interbank Bond Market Investors",
            notionalMillionRmb = 500.0,
            volumeGpuHours = 25000000,
            tenorMonths = 36,
            fixedPriceRmbPerGpuHour = 18.50,
            currentMarketSpreadBps = 85,
            markToMarketGainMillionRmb = 24.5,
            status = "ACTIVE"
        )
    )

    // 13. Alarms Engine
    private val _alarms = MutableStateFlow(
        listOf(
            AlarmItem(
                id = "ALM-2026-089",
                dcId = "DC-GZ-01",
                assetId = "RACK-GZ-A07",
                timestamp = "10:14:22",
                severity = AlarmSeverity.WARNING,
                category = AlarmCategory.TEMPERATURE,
                messageZh = "A07机柜出风口温度偏高 (达到 41.5℃)",
                messageEn = "Rack A07 Outlet Temperature High (41.5°C)",
                measurementVal = "41.5 ℃",
                thresholdVal = "40.0 ℃",
                rootCauseZh = "冷板二次回路阀门开度微调滞后，导致热流积聚",
                rootCauseEn = "Cold plate secondary valve throttle lag causing thermal buildup",
                mitigationZh = "已自动增加该列CDU旁通流量，建议巡检冷水接头密封性",
                mitigationEn = "Auto increased CDU bypass flow; verify quick-disconnect fittings",
                isAcknowledged = false
            ),
            AlarmItem(
                id = "ALM-2026-085",
                dcId = "DC-GZ-01",
                assetId = "CH-03",
                timestamp = "09:42:10",
                severity = AlarmSeverity.NOTICE,
                category = AlarmCategory.COOLING,
                messageZh = "3号离心冷机COP轻度偏离基线 (当前 5.92 vs 基准 6.40)",
                messageEn = "Chiller CH-03 COP Slight Baseline Deviation (5.92 vs 6.40)",
                measurementVal = "COP 5.92",
                thresholdVal = "COP >= 6.10",
                rootCauseZh = "冷凝器铜管侧轻度结垢导致热阻增加 4.8%",
                rootCauseEn = "Condenser tube minor fouling increased thermal resistance 4.8%",
                mitigationZh = "排入本周末预防性反冲洗保养工单，暂不影响整体供冷",
                mitigationEn = "Scheduled for preventive backwash this weekend",
                isAcknowledged = true,
                acknowledgedBy = "张工 (制冷首席)"
            ),
            AlarmItem(
                id = "ALM-2026-072",
                dcId = "DC-GZ-01",
                assetId = "PDU-A-04",
                timestamp = "08:15:33",
                severity = AlarmSeverity.INFO,
                category = AlarmCategory.POWER,
                messageZh = "PDU-A4 三相电流不平衡度 2.4% (处于国标安全裕度内)",
                messageEn = "PDU-A4 3-Phase Current Imbalance 2.4% (Within GB Spec)",
                measurementVal = "2.4 %",
                thresholdVal = "< 5.0 %",
                rootCauseZh = "A大厅高密服务器部分单相刀片电源并机负载微幅漂移",
                rootCauseEn = "Blade PSU slight load shift on phase B",
                mitigationZh = "常规监测，无需人工介入",
                mitigationEn = "Normal monitoring, no intervention needed",
                isAcknowledged = true,
                acknowledgedBy = "系统自动确认"
            )
        )
    )
    val alarms: StateFlow<List<AlarmItem>> = _alarms.asStateFlow()

    fun acknowledgeAlarm(id: String, operatorName: String) {
        _alarms.value = _alarms.value.map {
            if (it.id == id) it.copy(isAcknowledged = true, acknowledgedBy = operatorName) else it
        }
    }

    // 14. Field Work Orders (Mobile Technician Mode)
    val _workOrders = MutableStateFlow(
        listOf(
            WorkOrderTicket(
                id = "WO-2026-104",
                rackId = "RACK-GZ-A07",
                equipmentCode = "A07-CDU-QUICK-CONNECT",
                titleZh = "A07机柜快速接头红外热成像测温与密封性复核",
                titleEn = "Rack A07 Thermal Imaging & Seal Verification",
                priority = AlarmSeverity.WARNING,
                statusZh = "待处理",
                statusEn = "Open",
                technicianZh = "李明 (高级电气巡检员)",
                technicianEn = "Li Ming (Senior Inspector)",
                createdTime = "2026-10-10 10:20",
                instructionsZh = "使用FLUKE红外测温仪复查U16~U20节点冷板接头，确认无微渗漏；核验进出水压差是否稳定在280kPa。",
                instructionsEn = "Use FLUX thermal imager on U16-U20 quick disconnects. Verify pressure delta at 280kPa.",
                isCompleted = false
            ),
            WorkOrderTicket(
                id = "WO-2026-102",
                rackId = "RACK-GZ-A02",
                equipmentCode = "A02-rPDU-METER",
                titleZh = "A02机柜rPDU双回路电能计量表校验与接地电阻测量",
                titleEn = "Rack A02 Dual rPDU Calibration & Ground Resistance",
                priority = AlarmSeverity.NOTICE,
                statusZh = "已完成",
                statusEn = "Completed",
                technicianZh = "王磊 (电气工程师)",
                technicianEn = "Wang Lei (Electrical Engineer)",
                createdTime = "2026-10-10 08:30",
                instructionsZh = "检查A路与B路互锁状态，测试接地电阻小于0.5欧姆，记录电表累计kWh读数。",
                instructionsEn = "Check A/B interlock status. Verify ground resistance < 0.5 ohm.",
                isCompleted = true
            )
        )
    )
    val workOrders: StateFlow<List<WorkOrderTicket>> = _workOrders.asStateFlow()

    fun toggleWorkOrder(id: String) {
        _workOrders.value = _workOrders.value.map {
            if (it.id == id) {
                val nextState = !it.isCompleted
                it.copy(
                    isCompleted = nextState,
                    statusZh = if (nextState) "已完成" else "处理中",
                    statusEn = if (nextState) "Completed" else "In Progress"
                )
            } else it
        }
    }

    // 15. AI Operations Copilot Q&A Repository
    data class CopilotAnswer(
        val questionZh: String,
        val questionEn: String,
        val answerZh: String,
        val answerEn: String,
        val sourceTelemetryZh: String,
        val sourceTelemetryEn: String,
        val calculationMethodZh: String,
        val calculationMethodEn: String,
        val confidencePercent: Double,
        val timestamp: String = "2026-10-10 10:25:00 CST"
    )

    val copilotKnowledgeBase = listOf(
        CopilotAnswer(
            questionZh = "为什么PUE今天上升？",
            questionEn = "Why has PUE increased today?",
            answerZh = "今日 14:00~16:00 期间实时PUE由 1.138 攀升至 1.144 (+0.006)。主要根因：室外湿球温度由 18.2℃ 升高至 23.5℃，冷冻水系统板式换热器自然冷却裕度降低，4号冷电机组加载运行，冷机电耗由 5.8MW 增至 7.1MW。IT总负载保持在 98.4MW 恒定。",
            answerEn = "Live PUE increased from 1.138 to 1.144 (+0.006) between 14:00~16:00. Root cause: Outdoor wet bulb temperature rose from 18.2°C to 23.5°C, reducing plate heat exchanger free cooling capacity. Chiller CH-04 loaded up, increasing chiller power from 5.8MW to 7.1MW while IT load remained steady at 98.4MW.",
            sourceTelemetryZh = "贵安微气象站 (S-MET-01) 及 4号冷机功率传感器 (CH-04-PWR)",
            sourceTelemetryEn = "Gui'an Micro Weather Station (S-MET-01) & Chiller CH-04 Power Meter",
            calculationMethodZh = "PUE = 总耗电 (112.2MW) / IT耗电 (98.4MW) = 1.14028",
            calculationMethodEn = "PUE = Total Facility Power (112.2MW) / IT Power (98.4MW) = 1.14028",
            confidencePercent = 99.4
        ),
        CopilotAnswer(
            questionZh = "哪个机房温度最高？",
            questionEn = "Which data hall has the highest temperature?",
            answerZh = "当前温度最高区域为【A1智算大厅】的【Row-A 第07机柜】(RACK-GZ-A07)。热通道出风口测点达 41.5℃ (基准警戒线 40.0℃)。冷板出水温度 46.2℃。其它机柜平均出风温度为 34.6℃，整体大厅平均冷通道温度 21.2℃ 处于优良受控状态。",
            answerEn = "Highest temperature is in [Hall A1] at [Row-A Rack A07] (RACK-GZ-A07). Hot aisle outlet sensor reads 41.5°C (warning limit 40.0°C). Cold plate return liquid is 46.2°C. Average outlet for other racks is 34.6°C, with cold aisle at 21.2°C well within specifications.",
            sourceTelemetryZh = "A1大厅 480个点位光纤测温网格 (FO-TEMP-A1-07)",
            sourceTelemetryEn = "Hall A1 480-point Distributed Fiber Optic Grid (FO-TEMP-A1-07)",
            calculationMethodZh = "全场极值热点扫描: Max(T_out) = 41.5℃ @ A07",
            calculationMethodEn = "Fleet-wide hotspot scan: Max(T_out) = 41.5°C @ A07",
            confidencePercent = 99.8
        ),
        CopilotAnswer(
            questionZh = "未来七天哪里存在电力容量瓶颈？",
            questionEn = "Where are power-capacity bottlenecks likely over the next seven days?",
            answerZh = "根据电力潮流与负荷预测：【北京亦庄中心】(DC-BJ-03) 存在电力容量受限风险。当前实际IT负载已达 52.8MW (设计容量 60.0MW)，负荷率达 88.0%。若第3季度预定的 1,024卡 B200 算力集群如期上电，总IT功率将新增 4.2MW，导致变压器冗余度低于 N+1 预警红线。建议：将非时延敏感的大模型预训练任务调度至贵安或乌兰察布绿能节点。",
            answerEn = "Power flow forecast identifies [Beijing Yizhuang] (DC-BJ-03) as the key bottleneck. Current IT load is 52.8MW on a 60.0MW design capacity (88.0% utilization). Deploying the planned 1,024 B200 cluster will add 4.2MW, breaching N+1 transformer safety margins. Recommendation: Shift non-latency-sensitive training to Gui'an or Ulanqab.",
            sourceTelemetryZh = "亦庄总降变电站 (TR-10kV-01~04) 及未来负荷规划排期表",
            sourceTelemetryEn = "Yizhuang 10kV Substation (TR-10kV-01~04) & Planned Load Schedule",
            calculationMethodZh = "剩余供电容量 = 60.0MW * 0.90(安全限额) - 52.8MW = 1.20MW < 4.2MW",
            calculationMethodEn = "Available Margin = 60.0MW * 0.90 - 52.8MW = 1.20MW < 4.2MW",
            confidencePercent = 96.8
        ),
        CopilotAnswer(
            questionZh = "如果GPU负载增加20%，需要多少电力？",
            questionEn = "If GPU load increases 20%, how much additional power is required?",
            answerZh = "以贵安基地为例：当前GPU集群总功率约为 74.3MW (占IT总功率 98.4MW 的 75.5%)。若GPU计算利用率整体提升 20%：IT端GPU功率将增加 14.86MW；按当前边际PUE 1.12 计算，需额外配置制冷与配电损耗 1.78MW。全厂总需增加供电功率 = 16.64MW。当前贵安主变压器剩余裕度 47.8MW，具备完全承载能力。",
            answerEn = "For Gui'an Hub: Current GPU power is ~74.3MW (75.5% of 98.4MW IT total). A 20% GPU load expansion adds 14.86MW IT load; applying marginal PUE of 1.12 adds 1.78MW in cooling and losses. Total additional facility power required = 16.64MW. Gui'an substation has 47.8MW spare headroom, easily capable of supporting this load.",
            sourceTelemetryZh = "服务器IPMI芯片功率遥测及总降变电站实时功率遥测",
            sourceTelemetryEn = "Server IPMI telemetry & Main Substation Real-time SCADA",
            calculationMethodZh = "ΔP_total = ΔP_it * PUE_marginal = (74.3MW * 0.20) * 1.12 = 16.64 MW",
            calculationMethodEn = "ΔP_total = ΔP_it * PUE_marginal = (74.3MW * 0.20) * 1.12 = 16.64 MW",
            confidencePercent = 98.5
        ),
        CopilotAnswer(
            questionZh = "哪些冷机效率下降？",
            questionEn = "Which chillers are becoming less efficient?",
            answerZh = "排查全厂4台2000冷吨离心式冷机性能：【3号冷电机组 (CH-03)】COP 当前值为 5.92，较出厂基准 6.40 下降 7.5%，较同批次CH-01(COP 6.45) 明显偏低。冷凝器水阻由 42kPa 上升至 58kPa。建议在周末实施物理反冲洗及冷凝器铜管阻垢清洗，预计可恢复COP至6.35以上，年节约电费约 14.2 万元。",
            answerEn = "Fleet audit of four 2,000RT chillers reveals [Chiller CH-03] current COP is 5.92, a 7.5% degradation vs 6.40 baseline (and vs CH-01 at 6.45). Condenser water resistance has increased from 42kPa to 58kPa. Recommending backwash & descaling this weekend to restore COP > 6.35, saving ~¥142,000 annually.",
            sourceTelemetryZh = "冷水机组动环自控系统 (BAS-CH-01~04)",
            sourceTelemetryEn = "Building Automation System (BAS-CH-01~04)",
            calculationMethodZh = "COP = 产生冷量(kW) / 输入电功率(kW) = 8400kW / 1420kW = 5.915",
            calculationMethodEn = "COP = Cooling Output (kW) / Electrical Input (kW) = 8400kW / 1420kW = 5.915",
            confidencePercent = 97.2
        )
    )
}
