package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.data.ChinaDataCentreRepository
import com.example.core.i18n.I18n
import com.example.core.i18n.Language
import com.example.core.model.DataCentreNode
import com.example.ui.theme.*

@Composable
fun TopHeaderBar(
    currentLanguage: Language,
    onToggleLanguage: () -> Unit,
    activeAlertCount: Int,
    onNavigateToAlerts: () -> Unit
) {
    var showDcMenu by remember { mutableStateOf(false) }
    val selectedDc by ChinaDataCentreRepository.selectedDc.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Navy900)
            .border(width = 1.dp, color = GridDivider)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Brand & Institutional Title
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(SteelBlueMuted)
                        .border(1.dp, SteelBlue, RoundedCornerShape(4.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Dns,
                        contentDescription = "RhinoBank OS",
                        tint = TextPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (currentLanguage == Language.ZH) "RhinoBank 中国数据中心运营平台" else "RHINOBANK CHINA DC OS",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = TextPrimary,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(2.dp))
                                .background(Color(0xFF1E3A8A).copy(alpha = 0.4f))
                                .border(0.5.dp, SteelBlue, RoundedCornerShape(2.dp))
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = "OT/IT 隔离",
                                fontSize = 9.sp,
                                color = Color(0xFF93C5FD),
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    Text(
                        text = if (currentLanguage == Language.ZH)
                            "基础设施 · 能源 · 算力 · 金融 OS"
                        else
                            "Infrastructure · Energy · Compute · Finance OS",
                        fontSize = 10.sp,
                        color = TextSecondary
                    )
                }
            }

            // Right Actions: Language Switch & Alarm Badge
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Language Toggle Button
                OutlinedButton(
                    onClick = onToggleLanguage,
                    modifier = Modifier
                        .height(30.dp)
                        .testTag("language_toggle_button"),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                    shape = RoundedCornerShape(4.dp),
                    border = ButtonDefaults.outlinedButtonBorder.copy(
                        brush = androidx.compose.ui.graphics.SolidColor(BorderMuted)
                    ),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = Slate800,
                        contentColor = TextPrimary
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.Translate,
                        contentDescription = "Switch Language",
                        tint = CyanTealLight,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (currentLanguage == Language.ZH) "中 / EN" else "EN / 中",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                // Active Alert Counter Pill
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (activeAlertCount > 0) RedIndustrial.copy(alpha = 0.2f) else Slate800)
                        .border(
                            1.dp,
                            if (activeAlertCount > 0) RedIndustrial else BorderMuted,
                            RoundedCornerShape(4.dp)
                        )
                        .clickable { onNavigateToAlerts() }
                        .padding(horizontal = 8.dp, vertical = 5.dp)
                        .testTag("active_alerts_badge"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(if (activeAlertCount > 0) RedIndustrial else GreenIndustrial)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${I18n.t("告警", "Alerts")}: $activeAlertCount",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (activeAlertCount > 0) Color(0xFFFCA5A5) else TextSecondary,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Sub-strip: Facility Selector & Telemetry Banner
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Selected DC Pill / Selector
            Box {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .background(Slate800)
                        .border(0.5.dp, BorderMuted, RoundedCornerShape(3.dp))
                        .clickable { showDcMenu = true }
                        .padding(horizontal = 8.dp, vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = "Location",
                        tint = SteelBlue,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (currentLanguage == Language.ZH) selectedDc.nameZh else selectedDc.nameEn,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.Default.ArrowDropDown,
                        contentDescription = "Dropdown",
                        tint = TextSecondary,
                        modifier = Modifier.size(14.dp)
                    )
                }

                DropdownMenu(
                    expanded = showDcMenu,
                    onDismissRequest = { showDcMenu = false },
                    modifier = Modifier.background(Slate800)
                ) {
                    ChinaDataCentreRepository.dataCentres.forEach { dc ->
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(
                                        text = if (currentLanguage == Language.ZH) dc.nameZh else dc.nameEn,
                                        fontSize = 12.sp,
                                        color = TextPrimary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "${dc.cityZh} | IT: ${dc.actualItCapacityMw}MW | PUE: ${dc.livePue}",
                                        fontSize = 10.sp,
                                        color = TextSecondary
                                    )
                                }
                            },
                            onClick = {
                                ChinaDataCentreRepository.selectDataCentre(dc)
                                showDcMenu = false
                            }
                        )
                    }
                }
            }

            // Explicit Synthetic Demo Data Notice as required in prompt
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(GreenIndustrial)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "实时流遥测 / " + I18n.t("模拟数据", "Synthetic Data"),
                    fontSize = 9.sp,
                    color = TextSecondary,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
