package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.data.ChinaDataCentreRepository
import com.example.core.i18n.I18n
import com.example.ui.components.EngineeringMetricBox
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*

@Composable
fun EnergyPueScreen() {
    val pueDec = ChinaDataCentreRepository.currentPueDecomposition
    val tariffs = ChinaDataCentreRepository.hourlyTariffs

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Navy900)
            .padding(horizontal = 12.dp),
        contentPadding = PaddingValues(vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // PUE Header Summary
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderMuted, RoundedCornerShape(4.dp)),
                shape = RoundedCornerShape(4.dp),
                colors = CardDefaults.cardColors(containerColor = Slate800)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = I18n.t("能效与实时 PUE 解构计算引擎", "Energy Efficiency & PUE Decomposition Engine"),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(2.dp))
                                .background(GreenIndustrial.copy(alpha = 0.2f))
                                .border(0.5.dp, GreenIndustrial, RoundedCornerShape(2.dp))
                                .padding(horizontal = 5.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "实时PUE: %.4f".format(pueDec.calculatedPue),
                                fontSize = 9.sp,
                                color = GreenIndustrial,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = I18n.t(
                            "基于传感器遥测真实计算: PUE = 园区总输入功率 (${pueDec.totalFacilityPowerMw} MW) / IT设备功率 (${pueDec.itEquipmentLoadMw} MW)。杜绝静态虚构常数。",
                            "Computed from real telemetry: PUE = Total Facility Power (${pueDec.totalFacilityPowerMw} MW) / IT Equipment Load (${pueDec.itEquipmentLoadMw} MW)."
                        ),
                        fontSize = 10.sp,
                        color = TextSecondary
                    )
                }
            }
        }

        // PUE Decomposition Breakdown (IT, Chillers, Pumps, UPS losses, Transformers, Auxiliary)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderMuted, RoundedCornerShape(4.dp)),
                shape = RoundedCornerShape(4.dp),
                colors = CardDefaults.cardColors(containerColor = Slate800)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    SectionHeader(
                        codePrefix = "PUE-DECOMP",
                        titleZh = "全站各分项功耗解构 (MW)",
                        titleEn = "Facility Sub-system Power Breakdown (MW)",
                        badgeText = "总功率 ${pueDec.totalFacilityPowerMw} MW"
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    val breakdownList = listOf(
                        Triple("IT计算与存储设备 (纯有效算力)", "IT Compute & Storage Load", pueDec.itEquipmentLoadMw),
                        Triple("冷冻水离心冷水机组电耗", "Chillers Electricity Draw", pueDec.chillersLoadMw),
                        Triple("水泵、冷却塔与风机能耗", "Pumps, Cooling Towers & Fans", pueDec.pumpsAndFansMw),
                        Triple("双回路2N UPS整流与逆变损耗", "Dual 2N UPS Conversion Losses", pueDec.upsLossesMw),
                        Triple("主降压变压器励磁与铜损", "Transformer Losses", pueDec.transformersLossesMw),
                        Triple("机房照明、安防与辅控系统", "Lighting, Aux & Security", pueDec.lightingAndAuxMw)
                    )

                    breakdownList.forEach { (zh, en, mw) ->
                        val ratio = (mw / pueDec.totalFacilityPowerMw * 100)
                        Column(modifier = Modifier.padding(vertical = 3.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = I18n.t(zh, en), fontSize = 10.5.sp, color = TextPrimary)
                                Text(
                                    text = "$mw MW (%.1f%%)".format(ratio),
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = if (zh.startsWith("IT")) GreenIndustrial else TextSecondary
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(4.dp)
                                    .clip(RoundedCornerShape(1.dp))
                                    .background(Navy900)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth((ratio / 100f).toFloat().coerceIn(0f, 1f))
                                        .fillMaxHeight()
                                        .background(if (zh.startsWith("IT")) GreenIndustrial else SteelBlue)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Carbon Emissions Management (Scope 1, 2, 3)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderMuted, RoundedCornerShape(4.dp)),
                shape = RoundedCornerShape(4.dp),
                colors = CardDefaults.cardColors(containerColor = Slate800)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    SectionHeader(
                        codePrefix = "CARBON-MRV",
                        titleZh = "碳资产与碳排放核算 (Scope 1 / 2 / 3)",
                        titleEn = "Carbon Accounting & Scope 1/2/3 MRV",
                        badgeText = "全国碳市场对接"
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "范围一 (柴发燃油)", fontSize = 9.sp, color = TextMuted)
                            Text(text = "12.4 tCO2e", fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TextPrimary)
                        }
                        Column {
                            Text(text = "范围二 (外购电网电量)", fontSize = 9.sp, color = TextMuted)
                            Text(text = "4,210.8 tCO2e", fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = AmberIndustrial)
                        }
                        Column {
                            Text(text = "绿电核减与避碳", fontSize = 9.sp, color = TextMuted)
                            Text(text = "-32,450 tCO2e", fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = GreenIndustrial)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "单卡碳排放强度: 0.142 kgCO2e / GPU·小时",
                            fontSize = 9.5.sp,
                            color = CyanTealLight,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "单位有效IT碳排放: 0.285 kg/kWh",
                            fontSize = 9.5.sp,
                            color = TextSecondary,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // Chinese Electricity Tariffs Table
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderMuted, RoundedCornerShape(4.dp)),
                shape = RoundedCornerShape(4.dp),
                colors = CardDefaults.cardColors(containerColor = Slate800)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    SectionHeader(
                        codePrefix = "TARIFF-TOU",
                        titleZh = "省级电力交易现货与峰谷电价结构",
                        titleEn = "Provincial Electricity Spot & TOU Tariffs",
                        badgeText = "南方电网大工业110kV"
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    tariffs.forEach { tariff ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = tariff.hourRange,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = TextSecondary
                            )
                            Text(
                                text = I18n.t(tariff.nameZh, tariff.nameEn),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Medium,
                                color = TextPrimary
                            )
                            Text(
                                text = "¥ %.3f / kWh".format(tariff.priceRmbPerKwh),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = if (tariff.priceRmbPerKwh > 1.0) AmberIndustrial else CyanTealLight
                            )
                        }
                    }
                }
            }
        }
    }
}
