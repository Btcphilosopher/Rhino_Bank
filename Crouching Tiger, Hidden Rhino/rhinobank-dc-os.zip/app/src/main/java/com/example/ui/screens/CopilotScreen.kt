package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.data.ChinaDataCentreRepository
import com.example.core.i18n.I18n
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*

@Composable
fun CopilotScreen() {
    val knowledge = ChinaDataCentreRepository.copilotKnowledgeBase
    var selectedAnswerIndex by remember { mutableIntStateOf(0) }
    var userCustomQuery by remember { mutableStateOf("") }
    val currentAnswer = knowledge[selectedAnswerIndex]

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Navy900)
            .padding(horizontal = 12.dp),
        contentPadding = PaddingValues(vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Copilot Header Banner
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SteelBlue, RoundedCornerShape(4.dp)),
                shape = RoundedCornerShape(4.dp),
                colors = CardDefaults.cardColors(containerColor = Slate800)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.SmartToy,
                                contentDescription = null,
                                tint = SteelBlue,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = I18n.t("RhinoBank 智能运维助手", "RhinoBank Intelligent Ops Copilot"),
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(2.dp))
                                .background(GreenIndustrial.copy(alpha = 0.2f))
                                .padding(horizontal = 5.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "Gemini 3.6 工业引擎",
                                fontSize = 9.sp,
                                color = GreenIndustrial,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = I18n.t(
                            "基于传感器遥测与工程热工/电力方程求解。绝不凭空臆造数据；关键基础设施操作严格需要双人审批。",
                            "Ground truth based on physical telemetry & engineering thermodynamics. Never hallucinating telemetry; control actions require two-person sign-off."
                        ),
                        fontSize = 10.sp,
                        color = TextSecondary
                    )
                }
            }
        }

        // Canned Engineering Query Chips (Clickable)
        item {
            SectionHeader(
                codePrefix = "01/QUERIES",
                titleZh = "常用工程诊断与容量问答 (点击立即分析)",
                titleEn = "Standard Operational Diagnoses (Tap to Analyze)",
                badgeText = "专家模型预置"
            )

            Spacer(modifier = Modifier.height(4.dp))

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                knowledge.forEachIndexed { index, item ->
                    val isSelected = index == selectedAnswerIndex
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(3.dp))
                            .background(if (isSelected) SteelBlueMuted else Slate800)
                            .border(
                                1.dp,
                                if (isSelected) SteelBlue else BorderMuted,
                                RoundedCornerShape(3.dp)
                            )
                            .clickable { selectedAnswerIndex = index }
                            .padding(8.dp)
                            .testTag("copilot_query_chip_$index")
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = I18n.t(item.questionZh, item.questionEn),
                                fontSize = 11.5.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Color.White else TextPrimary
                            )
                            Icon(
                                imageVector = if (isSelected) Icons.Default.CheckCircle else Icons.Default.ChevronRight,
                                contentDescription = null,
                                tint = if (isSelected) CyanTealLight else TextMuted,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }
        }

        // Comprehensive Diagnosis & Calculation Response Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SteelBlue, RoundedCornerShape(4.dp)),
                shape = RoundedCornerShape(4.dp),
                colors = CardDefaults.cardColors(containerColor = Slate800)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    // Question Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Q: " + I18n.t(currentAnswer.questionZh, currentAnswer.questionEn),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF93C5FD)
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(2.dp))
                                .background(GreenIndustrial.copy(alpha = 0.2f))
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "置信度: ${currentAnswer.confidencePercent}%",
                                fontSize = 8.5.sp,
                                color = GreenIndustrial,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Engineering Answer Body
                    Text(
                        text = I18n.t(currentAnswer.answerZh, currentAnswer.answerEn),
                        fontSize = 11.5.sp,
                        color = TextPrimary,
                        lineHeight = 17.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Source Telemetry & Sensor Citation (CRITICAL Prompt Requirement)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(3.dp))
                            .background(Navy900)
                            .border(0.5.dp, BorderMuted, RoundedCornerShape(3.dp))
                            .padding(8.dp)
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Sensors,
                                    contentDescription = null,
                                    tint = CyanTealLight,
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = I18n.t("传感器数据来源与时间戳", "Sensor Source Telemetry & Timestamp"),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = CyanTealLight
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = I18n.t(currentAnswer.sourceTelemetryZh, currentAnswer.sourceTelemetryEn),
                                fontSize = 9.5.sp,
                                color = TextSecondary,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "遥测时间: ${currentAnswer.timestamp}",
                                fontSize = 8.5.sp,
                                color = TextMuted,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Calculation Method & Formula (CRITICAL Prompt Requirement)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(3.dp))
                            .background(Navy900)
                            .border(0.5.dp, BorderMuted, RoundedCornerShape(3.dp))
                            .padding(8.dp)
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Calculate,
                                    contentDescription = null,
                                    tint = AmberIndustrial,
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = I18n.t("工程计算过程与数学方程", "Engineering Formula & Steps"),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AmberIndustrial
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = I18n.t(currentAnswer.calculationMethodZh, currentAnswer.calculationMethodEn),
                                fontSize = 9.5.sp,
                                color = TextPrimary,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // Custom Question Input Field
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderMuted, RoundedCornerShape(4.dp)),
                shape = RoundedCornerShape(4.dp),
                colors = CardDefaults.cardColors(containerColor = Slate800)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = I18n.t("自定义向运维智能体提问 (自然语言查询):", "Ask Ops Copilot:"),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = userCustomQuery,
                            onValueChange = { userCustomQuery = it },
                            placeholder = { Text("例如：分析4号机房下季度制冷瓶颈...", fontSize = 10.sp) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("custom_query_input"),
                            textStyle = LocalTextStyle.current.copy(fontSize = 11.sp, color = TextPrimary),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = SteelBlue,
                                unfocusedBorderColor = BorderMuted
                            )
                        )

                        Spacer(modifier = Modifier.width(6.dp))

                        Button(
                            onClick = {
                                if (userCustomQuery.isNotBlank()) {
                                    // select relevant answer or keep current
                                    userCustomQuery = ""
                                }
                            },
                            modifier = Modifier
                                .height(46.dp)
                                .testTag("send_query_button"),
                            shape = RoundedCornerShape(3.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = SteelBlueMuted)
                        ) {
                            Icon(imageVector = Icons.Default.Send, contentDescription = "Send", modifier = Modifier.size(14.dp))
                        }
                    }
                }
            }
        }
    }
}
