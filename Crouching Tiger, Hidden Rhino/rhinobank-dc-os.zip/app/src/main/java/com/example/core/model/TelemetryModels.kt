package com.example.core.model

data class SingleLineDiagramNode(
    val id: String,
    val stageOrder: Int,
    val labelZh: String,
    val labelEn: String,
    val voltageLevel: String, // "110 kV", "10 kV", "400 V", "230 V"
    val redundancy: String, // "2N", "N+1", "2(N+1)"
    val ratedCapacityMva: Double,
    val currentLoadMw: Double,
    val loadingPercent: Double,
    val powerFactor: Double,
    val status: String // "ONLINE", "STANDBY", "ALARM"
)

data class CoolingLoopNode(
    val id: String,
    val componentTypeZh: String,
    val componentTypeEn: String,
    val identifier: String,
    val supplyTempC: Double,
    val returnTempC: Double,
    val flowRateLpm: Double, // Liters per minute
    val pressureKpa: Double,
    val cop: Double, // Coefficient of Performance
    val powerKw: Double,
    val leakDetected: Boolean = false,
    val status: String = "OPTIMAL"
)

data class PueDecomposition(
    val itEquipmentLoadMw: Double,
    val chillersLoadMw: Double,
    val pumpsAndFansMw: Double,
    val upsLossesMw: Double,
    val transformersLossesMw: Double,
    val lightingAndAuxMw: Double
) {
    val totalFacilityPowerMw: Double
        get() = itEquipmentLoadMw + chillersLoadMw + pumpsAndFansMw + upsLossesMw + transformersLossesMw + lightingAndAuxMw

    val calculatedPue: Double
        get() = if (itEquipmentLoadMw > 0) totalFacilityPowerMw / itEquipmentLoadMw else 1.0
}

data class ThermalHeatmapCell(
    val row: Int,
    val col: Int,
    val rackCode: String,
    val tempInletC: Double,
    val tempOutletC: Double,
    val deltaTempC: Double,
    val isHotspot: Boolean
)
