package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.data.ChinaDataCentreRepository
import com.example.core.i18n.I18n
import com.example.ui.components.EngineeringMetricBox
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*

@Composable
fun FinancialTerminalScreen() {
    val capexOpex = ChinaDataCentreRepository.capexOpex
    val unitEco = ChinaDataCentreRepository.unitEconomics
    val projFinance = ChinaDataCentreRepository.projectFinanceReturn
    val synInstruments = ChinaDataCentreRepository.syntheticInstruments

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Navy900)
            .padding(horizontal = 12.dp),
        contentPadding = PaddingValues(vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Finance Header Banner
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SteelBlue, RoundedCornerShape(4.dp)),
                shape = RoundedCornerShape(4.dp),
                colors = CardDefaults.cardColors(containerColor = Slate800)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = I18n.t("RhinoBank 基础设施金融终端", "RhinoBank Infrastructure Finance Terminal"),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(2.dp))
                                .background(SteelBlueMuted)
                                .padding(horizontal = 5.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "机构级项目融资与合成算力",
                                fontSize = 9.sp,
                                color = Color(0xFF93C5FD),
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = I18n.t(
                            "贯通数据中心项目资本金回报、单卡度电成本模型、现金流偿债覆盖率(DSCR)，以及RhinoBank专属算力远期与资产证券化衍生品。",
                            "Seamlessly bridges project finance IRR/DSCR, unit economics per GPU-hour, and RhinoBank synthetic compute forwards & asset-backed notes."
                        ),
                        fontSize = 10.sp,
                        color = TextSecondary
                    )
                }
            }
        }

        // Project Finance Key Return Multipliers
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    EngineeringMetricBox(
                        titleZh = "项目内部收益率 IRR",
                        titleEn = "Project IRR",
                        value = "%.1f".format(projFinance.internalRateOfReturnIrrPercent),
                        unit = "%",
                        headroomOrSubtitle = "WACC资本成本: ${projFinance.weightedAvgCostOfCapitalWaccPercent}%",
                        modifier = Modifier.weight(1f)
                    )
                    EngineeringMetricBox(
                        titleZh = "净现值 NPV",
                        titleEn = "Net Present Value",
                        value = "¥ %.1f".format(projFinance.netPresentValueNpvMillionRmb / 100),
                        unit = "亿元",
                        headroomOrSubtitle = "折现率: 5.5%",
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    EngineeringMetricBox(
                        titleZh = "偿债备付率 DSCR",
                        titleEn = "Debt Service Coverage",
                        value = "%.2f x".format(projFinance.debtServiceCoverageRatioDscr),
                        unit = "",
                        headroomOrSubtitle = "银行信贷安全线: >1.30x",
                        modifier = Modifier.weight(1f)
                    )
                    EngineeringMetricBox(
                        titleZh = "静态投资回收期",
                        titleEn = "Payback Period",
                        value = "%.1f".format(projFinance.paybackPeriodYears),
                        unit = "年",
                        headroomOrSubtitle = "总投资: ¥38.5亿元",
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Unit Economics: Cost per GPU-hour vs Revenue
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderMuted, RoundedCornerShape(4.dp)),
                shape = RoundedCornerShape(4.dp),
                colors = CardDefaults.cardColors(containerColor = Slate800)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    SectionHeader(
                        codePrefix = "UNIT-ECO",
                        titleZh = "单卡与单机柜单位经济学模型",
                        titleEn = "Unit Economics per GPU-Hour & Rack",
                        badgeText = "毛利率 38% ~ 45%"
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // H800
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(3.dp))
                            .background(Navy900)
                            .padding(8.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = "NVIDIA H800 80GB SXM5 集群", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                                Text(
                                    text = "毛利率: ${unitEco.grossMarginH800Percent}%",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GreenIndustrial,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = "综合成本: ¥${unitEco.costPerH800GpuHourRmb} / 卡·时 (电费占54%)", fontSize = 9.sp, color = TextSecondary, fontFamily = FontFamily.Monospace)
                                Text(text = "市场租金: ¥${unitEco.revenuePerH800GpuHourRmb} / 卡·时", fontSize = 9.sp, color = CyanTealLight, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Ascend 910B
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(3.dp))
                            .background(Navy900)
                            .padding(8.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = "华为昇腾 910B 64GB 信创智算集群", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                                Text(
                                    text = "毛利率: ${unitEco.grossMarginAscendPercent}%",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GreenIndustrial,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = "综合成本: ¥${unitEco.costPerAscendGpuHourRmb} / 卡·时", fontSize = 9.sp, color = TextSecondary, fontFamily = FontFamily.Monospace)
                                Text(text = "市场租金: ¥${unitEco.revenuePerAscendGpuHourRmb} / 卡·时", fontSize = 9.sp, color = CyanTealLight, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "单机柜月度总成本: ¥${unitEco.costPerRackMonthRmb.toInt()} / 机柜·月", fontSize = 9.sp, color = TextMuted, fontFamily = FontFamily.Monospace)
                        Text(text = "度电折合成本: ¥${unitEco.costPerKwMonthRmb.toInt()} / kW·月", fontSize = 9.sp, color = TextMuted, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        // RhinoBank Synthetic Compute Instruments (Compute Forwards & ABN)
        item {
            SectionHeader(
                codePrefix = "SYN-MARKET",
                titleZh = "RhinoBank 合成算力衍生合约与资产支持票据",
                titleEn = "Synthetic Compute Derivatives & ABN Portfolios",
                badgeText = "浮动盯市盈亏 +¥3,320万"
            )
        }

        items(synInstruments) { inst ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderMuted, RoundedCornerShape(4.dp)),
                shape = RoundedCornerShape(4.dp),
                colors = CardDefaults.cardColors(containerColor = Slate800)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = I18n.t(inst.titleZh, inst.titleEn),
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(2.dp))
                                .background(GreenIndustrial.copy(alpha = 0.2f))
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "+¥${inst.markToMarketGainMillionRmb}M MTM",
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = GreenIndustrial,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "合约编号: ${inst.contractId} | 交易对手: ${inst.counterpartyZh}",
                        fontSize = 9.sp,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "名义本金: ¥${inst.notionalMillionRmb}00万元 | 期限: ${inst.tenorMonths}个月",
                            fontSize = 9.sp,
                            color = TextMuted,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "锁定远期价: ¥${inst.fixedPriceRmbPerGpuHour}/卡·时",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = CyanTealLight,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}
