package com.example.core.model

enum class AlarmSeverity {
    EMERGENCY,
    CRITICAL,
    WARNING,
    NOTICE,
    INFO
}

enum class AlarmCategory {
    POWER,
    COOLING,
    GPU,
    SERVER,
    NETWORK,
    TEMPERATURE,
    WATER_LEAK,
    FIRE,
    SECURITY
}

data class AlarmItem(
    val id: String,
    val dcId: String,
    val assetId: String,
    val timestamp: String,
    val severity: AlarmSeverity,
    val category: AlarmCategory,
    val messageZh: String,
    val messageEn: String,
    val measurementVal: String,
    val thresholdVal: String,
    val rootCauseZh: String,
    val rootCauseEn: String,
    val mitigationZh: String,
    val mitigationEn: String,
    var isAcknowledged: Boolean = false,
    var acknowledgedBy: String = ""
)

data class WorkOrderTicket(
    val id: String,
    val rackId: String,
    val equipmentCode: String,
    val titleZh: String,
    val titleEn: String,
    val priority: AlarmSeverity,
    var statusZh: String,
    var statusEn: String,
    val technicianZh: String,
    val technicianEn: String,
    val createdTime: String,
    val instructionsZh: String,
    val instructionsEn: String,
    var isCompleted: Boolean = false
)
