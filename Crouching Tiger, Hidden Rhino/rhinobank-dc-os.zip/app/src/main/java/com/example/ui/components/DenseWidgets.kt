package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.i18n.I18n
import com.example.core.model.AlarmSeverity
import com.example.core.model.RackNode
import com.example.core.model.SingleLineDiagramNode
import com.example.ui.theme.*

@Composable
fun EngineeringMetricBox(
    titleZh: String,
    titleEn: String,
    value: String,
    unit: String,
    headroomOrSubtitle: String? = null,
    isWarning: Boolean = false,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .border(
                1.dp,
                if (isWarning) AmberIndustrial.copy(alpha = 0.8f) else BorderMuted,
                RoundedCornerShape(4.dp)
            ),
        shape = RoundedCornerShape(4.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isWarning) Slate800.copy(alpha = 0.95f) else Slate800
        )
    ) {
        Column(
            modifier = Modifier
                .padding(horizontal = 10.dp, vertical = 8.dp)
                .fillMaxWidth()
        ) {
            Text(
                text = I18n.t(titleZh, titleEn),
                fontSize = 11.sp,
                color = TextSecondary,
                fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.height(2.dp))
            Row(
                verticalAlignment = Alignment.Bottom
            ) {
                Text(
                    text = value,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isWarning) AmberIndustrial else TextPrimary,
                    fontFamily = FontFamily.Monospace
                )
                if (unit.isNotEmpty()) {
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = unit,
                        fontSize = 11.sp,
                        color = TextSecondary,
                        modifier = Modifier.padding(bottom = 2.dp)
                    )
                }
            }
            if (headroomOrSubtitle != null) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = headroomOrSubtitle,
                    fontSize = 9.sp,
                    color = if (isWarning) Color(0xFFFDE68A) else CyanTealLight,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
fun SectionHeader(
    codePrefix: String,
    titleZh: String,
    titleEn: String,
    badgeText: String? = null,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(2.dp))
                    .background(SteelBlueMuted)
                    .padding(horizontal = 4.dp, vertical = 1.dp)
            ) {
                Text(
                    text = codePrefix,
                    fontSize = 9.sp,
                    color = Color(0xFF93C5FD),
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = I18n.t(titleZh, titleEn),
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        if (badgeText != null) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(2.dp))
                    .background(Slate700)
                    .border(0.5.dp, BorderMuted, RoundedCornerShape(2.dp))
                    .padding(horizontal = 5.dp, vertical = 2.dp)
            ) {
                Text(
                    text = badgeText,
                    fontSize = 9.sp,
                    color = TextSecondary,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
fun SeverityBadge(severity: AlarmSeverity) {
    val (bgColor, textColor, label) = when (severity) {
        AlarmSeverity.EMERGENCY -> Triple(RedIndustrial, Color.White, I18n.t("紧急故障", "EMERGENCY"))
        AlarmSeverity.CRITICAL -> Triple(Color(0xFFB91C1C), Color.White, I18n.t("严重告警", "CRITICAL"))
        AlarmSeverity.WARNING -> Triple(AmberIndustrial, Color.Black, I18n.t("异常预警", "WARNING"))
        AlarmSeverity.NOTICE -> Triple(SteelBlueMuted, Color(0xFFBFDBFE), I18n.t("提示注意", "NOTICE"))
        AlarmSeverity.INFO -> Triple(Slate700, TextSecondary, I18n.t("普通信息", "INFO"))
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(2.dp))
            .background(bgColor)
            .padding(horizontal = 5.dp, vertical = 2.dp)
    ) {
        Text(
            text = label,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = textColor,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun SingleLineDiagramFlow(
    nodes: List<SingleLineDiagramNode>,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, BorderMuted, RoundedCornerShape(4.dp)),
        shape = RoundedCornerShape(4.dp),
        colors = CardDefaults.cardColors(containerColor = Slate800)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            SectionHeader(
                codePrefix = "SLD-2N",
                titleZh = "电气主接线图 (双回路单线拓扑)",
                titleEn = "Single-Line Diagram (2N Architecture)",
                badgeText = "南方电网 110kV 进线"
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Sequence of bus stages
            nodes.forEachIndexed { index, node ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Stage number indicator
                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .clip(CircleShape)
                            .background(SteelBlueMuted)
                            .border(1.dp, SteelBlue, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${node.stageOrder}",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = I18n.t(node.labelZh, node.labelEn),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                            Text(
                                text = "${node.currentLoadMw} MW / ${node.ratedCapacityMva} MVA",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = SteelBlue
                            )
                        }

                        Spacer(modifier = Modifier.height(2.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${node.voltageLevel} · 冗余架构: ${node.redundancy} · PF: ${node.powerFactor}",
                                fontSize = 9.sp,
                                color = TextSecondary,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "负载率: ${node.loadingPercent}%",
                                fontSize = 9.sp,
                                color = if (node.loadingPercent > 80.0) AmberIndustrial else GreenIndustrial,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        // Mini Loading bar
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(3.dp)
                                .clip(RoundedCornerShape(1.dp))
                                .background(Navy900)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth((node.loadingPercent / 100.0).toFloat().coerceIn(0f, 1f))
                                    .fillMaxHeight()
                                    .background(if (node.loadingPercent > 80.0) AmberIndustrial else SteelBlue)
                            )
                        }
                    }
                }

                if (index < nodes.size - 1) {
                    // Vertical connector line
                    Box(
                        modifier = Modifier
                            .padding(start = 9.dp)
                            .width(2.dp)
                            .height(6.dp)
                            .background(BorderMuted)
                    )
                }
            }
        }
    }
}

@Composable
fun RackMatrixGrid(
    racks: List<RackNode>,
    onSelectRack: (RackNode) -> Unit,
    selectedRackId: String?,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, BorderMuted, RoundedCornerShape(4.dp)),
        shape = RoundedCornerShape(4.dp),
        colors = CardDefaults.cardColors(containerColor = Slate800)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            SectionHeader(
                codePrefix = "RACK-MAP",
                titleZh = "A1智算大厅 机柜矩阵与热场分布",
                titleEn = "Data Hall A1 Rack Thermal Matrix",
                badgeText = "12高密算力列 (45kW/机柜)"
            )

            Spacer(modifier = Modifier.height(8.dp))

            // 4 columns grid of 12 racks
            val chunked = racks.chunked(4)
            chunked.forEach { rowRacks ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    rowRacks.forEach { rack ->
                        val isSelected = rack.id == selectedRackId
                        val isHot = rack.outletTempC >= 40.0
                        val isWarning = rack.status == "WARNING"

                        val cardBg = when {
                            isHot -> RedIndustrial.copy(alpha = 0.25f)
                            isWarning -> AmberIndustrial.copy(alpha = 0.2f)
                            isSelected -> SteelBlueMuted.copy(alpha = 0.6f)
                            else -> Navy900
                        }

                        val borderColor = when {
                            isHot -> RedIndustrial
                            isWarning -> AmberIndustrial
                            isSelected -> SteelBlue
                            else -> BorderMuted
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(3.dp))
                                .background(cardBg)
                                .border(1.dp, borderColor, RoundedCornerShape(3.dp))
                                .clickable { onSelectRack(rack) }
                                .padding(6.dp)
                        ) {
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = rack.rackNumber,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        color = if (isSelected) Color(0xFF93C5FD) else TextPrimary
                                    )
                                    Box(
                                        modifier = Modifier
                                            .size(5.dp)
                                            .clip(CircleShape)
                                            .background(
                                                if (isHot) RedIndustrial
                                                else if (isWarning) AmberIndustrial
                                                else GreenIndustrial
                                            )
                                    )
                                }

                                Spacer(modifier = Modifier.height(3.dp))

                                Text(
                                    text = "${rack.currentKw} kW",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    fontFamily = FontFamily.Monospace,
                                    color = if (rack.currentKw > 40.0) AmberIndustrial else CyanTealLight
                                )

                                Text(
                                    text = "出风: ${rack.outletTempC}℃",
                                    fontSize = 8.5.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = if (isHot) RedIndustrial else TextSecondary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
