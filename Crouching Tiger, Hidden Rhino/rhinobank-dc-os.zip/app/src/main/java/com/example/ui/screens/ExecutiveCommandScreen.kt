package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.data.ChinaDataCentreRepository
import com.example.core.i18n.I18n
import com.example.core.model.DataCentreNode
import com.example.ui.components.EngineeringMetricBox
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*

@Composable
fun ExecutiveCommandScreen(
    onSelectDataCentre: (DataCentreNode) -> Unit,
    onNavigateToDigitalTwin: () -> Unit,
    onNavigateToComputePower: () -> Unit,
    onNavigateToFinance: () -> Unit
) {
    val selectedDc by ChinaDataCentreRepository.selectedDc.collectAsState()
    val allDcs = ChinaDataCentreRepository.dataCentres

    // Aggregations across China fleet
    val totalItLoad = allDcs.sumOf { it.actualItCapacityMw }
    val totalFacilityPower = allDcs.sumOf { it.totalPowerMw }
    val totalGpus = allDcs.sumOf { it.gpuCount }
    val totalComputePflops = allDcs.sumOf { it.computePflops }
    val avgPue = (totalFacilityPower / totalItLoad)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Navy900)
            .padding(horizontal = 12.dp),
        contentPadding = PaddingValues(vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Group Header Banner
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderMuted, RoundedCornerShape(4.dp)),
                shape = RoundedCornerShape(4.dp),
                colors = CardDefaults.cardColors(containerColor = Slate800)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = I18n.t("集团全国智算枢纽实时看板", "National Hyperscale Fleet Dashboard"),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(2.dp))
                                .background(GreenIndustrial.copy(alpha = 0.2f))
                                .border(0.5.dp, GreenIndustrial, RoundedCornerShape(2.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "东数西算骨干直连 / " + I18n.t("6大基地", "6 Hubs"),
                                fontSize = 9.sp,
                                color = GreenIndustrial,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = I18n.t(
                            "贯通物理基建 → 供配电 → 冷水液冷 → 机柜 → 芯片 → 算力合约 → 绿色电力 → 基础设施金融",
                            "Physical Infrastructure → Power → Cooling → Racks → Chips → Compute → Energy → Finance"
                        ),
                        fontSize = 10.sp,
                        color = TextSecondary
                    )
                }
            }
        }

        // High Density KPI Grid (2x3)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    EngineeringMetricBox(
                        titleZh = "全国总IT负载",
                        titleEn = "Total Fleet IT Load",
                        value = "%.1f".format(totalItLoad),
                        unit = "MW",
                        headroomOrSubtitle = "设计容量: 570.0 MW",
                        modifier = Modifier.weight(1f)
                    )
                    EngineeringMetricBox(
                        titleZh = "全国总输入功率",
                        titleEn = "Total Facility Power",
                        value = "%.1f".format(totalFacilityPower),
                        unit = "MW",
                        headroomOrSubtitle = "供电裕度: +98.5 MW",
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    EngineeringMetricBox(
                        titleZh = "全国智算规模",
                        titleEn = "Total Compute Pool",
                        value = "%.1f".format(totalComputePflops),
                        unit = "PFLOPS",
                        headroomOrSubtitle = "GPU卡数: ${totalGpus.toString().replace(Regex("(\\d)(?=(\\d{3})+$)"), "$1,")} 卡",
                        modifier = Modifier.weight(1f)
                    )
                    EngineeringMetricBox(
                        titleZh = "全国平均PUE",
                        titleEn = "Fleet Average PUE",
                        value = "%.3f".format(avgPue),
                        unit = "",
                        headroomOrSubtitle = "基准考核线: 1.250",
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    EngineeringMetricBox(
                        titleZh = "可再生绿电占比",
                        titleEn = "Renewable Share",
                        value = "78.4",
                        unit = "%",
                        headroomOrSubtitle = "水电/风光直供",
                        modifier = Modifier.weight(1f)
                    )
                    EngineeringMetricBox(
                        titleZh = "今日电能成本",
                        titleEn = "Daily Energy Cost",
                        value = "1,842.6",
                        unit = "千元",
                        headroomOrSubtitle = "算电协同优化中",
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Quick Navigation Shortcuts to Core OS Engines
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OutlinedButton(
                    onClick = onNavigateToDigitalTwin,
                    modifier = Modifier
                        .weight(1f)
                        .height(34.dp)
                        .testTag("nav_quick_twin"),
                    contentPadding = PaddingValues(0.dp),
                    shape = RoundedCornerShape(3.dp),
                    border = ButtonDefaults.outlinedButtonBorder.copy(
                        brush = androidx.compose.ui.graphics.SolidColor(BorderMuted)
                    ),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = Slate800,
                        contentColor = SteelBlue
                    )
                ) {
                    Icon(imageVector = Icons.Default.Dns, contentDescription = null, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = I18n.t("进入数字孪生", "Digital Twin"), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }

                OutlinedButton(
                    onClick = onNavigateToComputePower,
                    modifier = Modifier
                        .weight(1f)
                        .height(34.dp)
                        .testTag("nav_quick_coordination"),
                    contentPadding = PaddingValues(0.dp),
                    shape = RoundedCornerShape(3.dp),
                    border = ButtonDefaults.outlinedButtonBorder.copy(
                        brush = androidx.compose.ui.graphics.SolidColor(BorderMuted)
                    ),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = Slate800,
                        contentColor = AmberIndustrial
                    )
                ) {
                    Icon(imageVector = Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = I18n.t("算电协同调度", "Coordination"), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }

                OutlinedButton(
                    onClick = onNavigateToFinance,
                    modifier = Modifier
                        .weight(1f)
                        .height(34.dp)
                        .testTag("nav_quick_finance"),
                    contentPadding = PaddingValues(0.dp),
                    shape = RoundedCornerShape(3.dp),
                    border = ButtonDefaults.outlinedButtonBorder.copy(
                        brush = androidx.compose.ui.graphics.SolidColor(BorderMuted)
                    ),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = Slate800,
                        contentColor = CyanTealLight
                    )
                ) {
                    Icon(imageVector = Icons.Default.TrendingUp, contentDescription = null, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = I18n.t("金融资产终端", "Finance OS"), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        // Section: Regional Fleet Hubs (Clickable list of Chinese Data Centres)
        item {
            SectionHeader(
                codePrefix = "01/HUBS",
                titleZh = "全国智算枢纽节点明细 (点击切换主控)",
                titleEn = "China Regional Compute Hubs (Select to Inspect)",
                badgeText = "${allDcs.size} 个枢纽在线"
            )
        }

        items(allDcs) { dc ->
            val isCurrent = dc.id == selectedDc.id
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        if (isCurrent) SteelBlue else BorderMuted,
                        RoundedCornerShape(4.dp)
                    )
                    .clickable { onSelectDataCentre(dc) }
                    .testTag("hub_card_${dc.id}"),
                shape = RoundedCornerShape(4.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isCurrent) Slate800.copy(alpha = 0.95f) else Slate800
                )
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = I18n.t(dc.provinceZh, dc.provinceEn),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isCurrent) SteelBlue else TextPrimary,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = I18n.t(dc.nameZh, dc.nameEn),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                        }

                        if (isCurrent) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(SteelBlueMuted)
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = I18n.t("当前主控", "Active Target"),
                                    fontSize = 9.sp,
                                    color = Color(0xFFBFDBFE),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${dc.campusZh} · ${dc.cityZh}",
                        fontSize = 10.sp,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = I18n.t("实时IT负荷", "Live IT Load"), fontSize = 9.sp, color = TextMuted)
                            Text(
                                text = "${dc.actualItCapacityMw} MW",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = TextPrimary
                            )
                        }
                        Column {
                            Text(text = I18n.t("实时PUE", "Live PUE"), fontSize = 9.sp, color = TextMuted)
                            Text(
                                text = "%.3f".format(dc.livePue),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = if (dc.livePue <= 1.15) GreenIndustrial else AmberIndustrial
                            )
                        }
                        Column {
                            Text(text = I18n.t("算力规模", "Compute"), fontSize = 9.sp, color = TextMuted)
                            Text(
                                text = "${dc.computePflops.toInt()} PFLOPS",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = CyanTealLight
                            )
                        }
                        Column {
                            Text(text = I18n.t("绿电比例", "Renewable"), fontSize = 9.sp, color = TextMuted)
                            Text(
                                text = "${(dc.renewableRatio * 100).toInt()}%",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = GreenIndustrial
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "制冷方式: ${dc.coolingMethodZh}",
                        fontSize = 9.5.sp,
                        color = TextSecondary
                    )
                }
            }
        }
    }
}
