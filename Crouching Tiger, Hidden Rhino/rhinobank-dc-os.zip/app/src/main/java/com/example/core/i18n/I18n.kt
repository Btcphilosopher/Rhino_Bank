package com.example.core.i18n

enum class Language(val code: String, val displayName: String) {
    ZH("zh", "简体中文"),
    EN("en", "English")
}

object I18n {
    var currentLanguage: Language = Language.ZH

    fun toggleLanguage(): Language {
        currentLanguage = if (currentLanguage == Language.ZH) Language.EN else Language.ZH
        return currentLanguage
    }

    fun t(zhText: String, enText: String): String {
        return if (currentLanguage == Language.ZH) zhText else enText
    }

    // Common App Titles
    val appTitle: String get() = t("RhinoBank 中国数据中心运营平台", "RhinoBank China Data Centre OS")
    val appSubtitle: String get() = t("数据中心基础设施、能源、算力与金融管理系统", "Data Centre Infrastructure, Energy, Compute & Financial Management System")
    val syntheticDataNotice: String get() = t("模拟数据 Synthetic Demo Data", "Synthetic Demo Data")
    val institutionalGrade: String get() = t("工业级生产系统 / OT-IT 隔离", "Industrial Grade / OT-IT Segregated")

    // Navigation Tabs
    val navCommandCenter: String get() = t("总览指挥", "Overview")
    val navDigitalTwin: String get() = t("数字孪生", "Digital Twin")
    val navComputePower: String get() = t("算电协同", "Compute-Power")
    val navEnergyPue: String get() = t("能源与PUE", "Energy & PUE")
    val navFinance: String get() = t("基础设施金融", "Finance")
    val navAlarms: String get() = t("运行告警", "Alerts")
    val navTechnician: String get() = t("现场巡检", "Field Ops")
    val navCopilot: String get() = t("智能运维助手", "AI Copilot")

    // Metric Labels
    val totalDataCentres: String get() = t("总数据中心数量", "Total Data Centres")
    val totalItLoad: String get() = t("总IT负载", "Total IT Load")
    val totalPower: String get() = t("总输入功率", "Total Facility Power")
    val totalGpuCount: String get() = t("总GPU数量", "Total GPUs")
    val totalComputeCapacity: String get() = t("总算力规模", "Total Compute Capacity")
    val livePue: String get() = t("实时PUE", "Live PUE")
    val designPue: String get() = t("设计PUE", "Design PUE")
    val computeUtilisation: String get() = t("算力利用率", "Compute Utilisation")
    val energyCostToday: String get() = t("今日能耗电费", "Energy Cost Today")
    val carbonEmissions: String get() = t("碳排放强度", "Carbon Intensity")
    val renewableShare: String get() = t("可再生能源比例", "Renewable Energy Share")
    val activeAlerts: String get() = t("活跃告警", "Active Alerts")
    val powerHeadroom: String get() = t("供电裕度", "Power Headroom")
    val coolingHeadroom: String get() = t("制冷裕度", "Cooling Headroom")

    // Systems & Equipment
    val dataHall: String get() = t("数据大厅", "Data Hall")
    val rack: String get() = t("机柜", "Rack")
    val server: String get() = t("服务器", "Server")
    val gpuCluster: String get() = t("GPU集群", "GPU Cluster")
    val singleLineDiagram: String get() = t("电气主接线图 (单线图)", "Single-Line Diagram (SLD)")
    val coolingLoop: String get() = t("液冷与冷冻水循环", "Liquid & Chilled Water Loop")
    val thermalMap: String get() = t("热场温区分布图", "Thermal Distribution Map")
    val coldAisle: String get() = t("冷通道", "Cold Aisle")
    val hotAisle: String get() = t("热通道", "Hot Aisle")

    // Energy & Tariffs
    val peakTariff: String get() = t("尖峰/峰段电价", "Critical/Peak Tariff")
    val shoulderTariff: String get() = t("平段电价", "Shoulder Tariff")
    val valleyTariff: String get() = t("谷段电价", "Valley Tariff")
    val greenCertificates: String get() = t("绿证交易", "Green Certificates")

    // Status
    val operational: String get() = t("正常运行", "Operational")
    val warning: String get() = t("异常预警", "Warning")
    val critical: String get() = t("严重告警", "Critical")
    val emergency: String get() = t("紧急故障", "Emergency")
    val maintenance: String get() = t("维护中", "Maintenance")
}
