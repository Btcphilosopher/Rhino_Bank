package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.data.ChinaDataCentreRepository
import com.example.core.i18n.I18n
import com.example.core.model.AlarmCategory
import com.example.core.model.AlarmSeverity
import com.example.ui.components.SectionHeader
import com.example.ui.components.SeverityBadge
import com.example.ui.theme.*

@Composable
fun AlarmsOperationsScreen() {
    val alarms by ChinaDataCentreRepository.alarms.collectAsState()
    var selectedCategoryFilter by remember { mutableStateOf<AlarmCategory?>(null) }

    val filteredAlarms = alarms.filter {
        selectedCategoryFilter == null || it.category == selectedCategoryFilter
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Navy900)
            .padding(horizontal = 12.dp),
        contentPadding = PaddingValues(vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Alarms Header
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderMuted, RoundedCornerShape(4.dp)),
                shape = RoundedCornerShape(4.dp),
                colors = CardDefaults.cardColors(containerColor = Slate800)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = I18n.t("分级告警与根因诊断引擎", "Hierarchical Alarm & Root-Cause Diagnosis"),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(2.dp))
                                .background(AmberIndustrial.copy(alpha = 0.2f))
                                .padding(horizontal = 5.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "实时动环联动",
                                fontSize = 9.sp,
                                color = AmberIndustrial,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = I18n.t(
                            "覆盖供电断路器、冷机/CDU工况、冷板测温、母线槽平衡度等动环与IT传感器事件",
                            "Covers breakers, chillers, CDUs, cold plates, busway balancing and telemetry triggers"
                        ),
                        fontSize = 10.sp,
                        color = TextSecondary
                    )
                }
            }
        }

        // Category Filter Chips
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilterChip(
                    selected = selectedCategoryFilter == null,
                    onClick = { selectedCategoryFilter = null },
                    label = { Text("全部 (${alarms.size})", fontSize = 10.sp) },
                    shape = RoundedCornerShape(3.dp),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = SteelBlueMuted,
                        selectedLabelColor = Color.White
                    )
                )

                FilterChip(
                    selected = selectedCategoryFilter == AlarmCategory.TEMPERATURE,
                    onClick = { selectedCategoryFilter = AlarmCategory.TEMPERATURE },
                    label = { Text("温场热点", fontSize = 10.sp) },
                    shape = RoundedCornerShape(3.dp),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = SteelBlueMuted,
                        selectedLabelColor = Color.White
                    )
                )

                FilterChip(
                    selected = selectedCategoryFilter == AlarmCategory.COOLING,
                    onClick = { selectedCategoryFilter = AlarmCategory.COOLING },
                    label = { Text("制冷COP", fontSize = 10.sp) },
                    shape = RoundedCornerShape(3.dp),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = SteelBlueMuted,
                        selectedLabelColor = Color.White
                    )
                )

                FilterChip(
                    selected = selectedCategoryFilter == AlarmCategory.POWER,
                    onClick = { selectedCategoryFilter = AlarmCategory.POWER },
                    label = { Text("配电平衡", fontSize = 10.sp) },
                    shape = RoundedCornerShape(3.dp),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = SteelBlueMuted,
                        selectedLabelColor = Color.White
                    )
                )
            }
        }

        // Alarm Items
        items(filteredAlarms) { alarm ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        if (!alarm.isAcknowledged) AmberIndustrial else BorderMuted,
                        RoundedCornerShape(4.dp)
                    )
                    .testTag("alarm_card_${alarm.id}"),
                shape = RoundedCornerShape(4.dp),
                colors = CardDefaults.cardColors(containerColor = Slate800)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            SeverityBadge(severity = alarm.severity)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "[${alarm.assetId}] ${alarm.timestamp}",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = TextSecondary
                            )
                        }

                        if (alarm.isAcknowledged) {
                            Text(
                                text = "已确认 (${alarm.acknowledgedBy})",
                                fontSize = 9.sp,
                                color = GreenIndustrial,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = I18n.t(alarm.messageZh, alarm.messageEn),
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "实测值: ${alarm.measurementVal} | 预警阈值: ${alarm.thresholdVal}",
                        fontSize = 9.5.sp,
                        color = AmberIndustrial,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "根因诊断: " + I18n.t(alarm.rootCauseZh, alarm.rootCauseEn),
                        fontSize = 9.sp,
                        color = TextSecondary
                    )

                    Text(
                        text = "处置建议: " + I18n.t(alarm.mitigationZh, alarm.mitigationEn),
                        fontSize = 9.sp,
                        color = CyanTealLight
                    )

                    if (!alarm.isAcknowledged) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = {
                                ChinaDataCentreRepository.acknowledgeAlarm(alarm.id, "运行值班长 / RhinoBank")
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(30.dp)
                                .testTag("ack_button_${alarm.id}"),
                            shape = RoundedCornerShape(3.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = SteelBlueMuted)
                        ) {
                            Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = I18n.t("值班工程师确认并转入处置工单", "Acknowledge & Transfer to Work Order"),
                                fontSize = 10.5.sp,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}
