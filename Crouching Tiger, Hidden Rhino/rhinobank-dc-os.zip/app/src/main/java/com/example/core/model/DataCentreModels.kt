package com.example.core.model

data class DataCentreNode(
    val id: String,
    val nameZh: String,
    val nameEn: String,
    val provinceZh: String,
    val provinceEn: String,
    val cityZh: String,
    val cityEn: String,
    val campusZh: String,
    val campusEn: String,
    val designItCapacityMw: Double,
    val actualItCapacityMw: Double,
    val totalPowerMw: Double,
    val designPue: Double,
    val livePue: Double,
    val wue: Double, // Water Usage Effectiveness (L/kWh)
    val cue: Double, // Carbon Usage Effectiveness (kgCO2e/kWh)
    val renewableRatio: Double, // e.g. 0.85
    val rackCount: Int,
    val serverCount: Int,
    val gpuCount: Int,
    val computePflops: Double,
    val coolingMethodZh: String,
    val coolingMethodEn: String,
    val status: String = "OPERATIONAL"
)

data class DataHall(
    val id: String,
    val dcId: String,
    val nameZh: String,
    val nameEn: String,
    val areaM2: Double,
    val rackCount: Int,
    val activeRackCount: Int,
    val avgKwPerRack: Double,
    val maxKwPerRack: Double,
    val coldAisleTempC: Double,
    val hotAisleTempC: Double,
    val humidityPercent: Double,
    val coolingTypeZh: String,
    val coolingTypeEn: String
)

data class RackNode(
    val id: String,
    val hallId: String,
    val rowCode: String,
    val rackNumber: String,
    val ratedKw: Double,
    val currentKw: Double,
    val powerFactor: Double,
    val inletTempC: Double,
    val outletTempC: Double,
    val totalUnitsU: Int = 42,
    val usedUnitsU: Int,
    val serverCount: Int,
    val gpuNodeCount: Int,
    val pduAStatus: String = "NORMAL",
    val pduBStatus: String = "NORMAL",
    val status: String = "NORMAL" // NORMAL, WARNING, CRITICAL
)

data class ServerNode(
    val id: String,
    val rackId: String,
    val unitLocation: String, // e.g. "U18-U22 (4U)"
    val manufacturer: String,
    val model: String,
    val serialNumber: String,
    val cpuModel: String,
    val ramGb: Int,
    val gpuModel: String,
    val gpuCount: Int,
    val powerDrawW: Double,
    val inletTempC: Double,
    val outletTempC: Double,
    val healthStatus: String = "HEALTHY"
)

data class GpuDevice(
    val id: String,
    val serverId: String,
    val index: Int,
    val model: String, // "NVIDIA H800 80GB" or "Huawei Ascend 910B 64GB"
    val utilPercent: Double,
    val vramTotalGb: Double,
    val vramUsedGb: Double,
    val tempC: Double,
    val powerDrawW: Double,
    val maxPowerW: Double,
    val isThrottling: Boolean,
    val interconnectBandwidthGbps: Double
)
