package com.example

import com.example.core.data.ChinaDataCentreRepository
import com.example.core.i18n.I18n
import com.example.core.i18n.Language
import com.example.core.model.PueDecomposition
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testPueCalculation() {
        val decomposition = PueDecomposition(
            itEquipmentLoadMw = 100.0,
            chillersLoadMw = 8.0,
            pumpsAndFansMw = 3.0,
            upsLossesMw = 2.0,
            transformersLossesMw = 1.0,
            lightingAndAuxMw = 0.5
        )
        assertEquals(114.5, decomposition.totalFacilityPowerMw, 0.001)
        assertEquals(1.145, decomposition.calculatedPue, 0.001)
    }

    @Test
    fun testBilingualToggle() {
        I18n.currentLanguage = Language.ZH
        assertEquals("实时PUE", I18n.livePue)

        I18n.toggleLanguage()
        assertEquals(Language.EN, I18n.currentLanguage)
        assertEquals("Live PUE", I18n.livePue)

        // Reset back to ZH
        I18n.currentLanguage = Language.ZH
        assertEquals("实时PUE", I18n.livePue)
    }

    @Test
    fun testDataCentreFleetTotals() {
        val dcs = ChinaDataCentreRepository.dataCentres
        assertTrue("Should have multiple data centres across China", dcs.size >= 6)

        val totalCapacity = dcs.sumOf { it.designItCapacityMw }
        assertTrue("Total fleet IT capacity should exceed 500 MW", totalCapacity > 500.0)
    }

    @Test
    fun testComputePowerCoordinationSavings() {
        val proposals = ChinaDataCentreRepository.shiftProposals.value
        assertTrue("Should have proposals", proposals.isNotEmpty())

        val proposal1 = proposals[0]
        assertEquals(153000.0, proposal1.dailySavingsRmb, 0.1)

        ChinaDataCentreRepository.approveProposal(proposal1.proposalId)
        val updated = ChinaDataCentreRepository.shiftProposals.value.first { it.proposalId == proposal1.proposalId }
        assertTrue(updated.isApproved)
    }

    @Test
    fun testCopilotKnowledgeBase() {
        val kb = ChinaDataCentreRepository.copilotKnowledgeBase
        assertTrue("Should have canned engineering diagnoses", kb.size >= 5)

        val pueQuestion = kb.first { it.questionZh.contains("PUE") }
        assertTrue(pueQuestion.sourceTelemetryZh.isNotEmpty())
        assertTrue(pueQuestion.calculationMethodZh.isNotEmpty())
        assertTrue(pueQuestion.confidencePercent > 90.0)
    }
}
