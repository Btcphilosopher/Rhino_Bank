import React, { useState, useEffect } from 'react';
import {
  Activity,
  ShieldCheck,
  Smartphone,
  Store,
  RefreshCw,
  Clock,
  Layers,
  HelpCircle,
} from 'lucide-react';
import { useSimulation } from '../../simulation/SimulationContext';

interface HeaderProps {
  onOpenConsumerWallet: () => void;
  onOpenMerchantTerminal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenConsumerWallet,
  onOpenMerchantTerminal,
}) => {
  const { macroModel, resetSimulationData } = useSimulation();
  const [timeStr, setTimeStr] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const d = new Date();
      const year = d.getFullYear();
      const month = String(d.getMonth() + 1).padStart(2, '0');
      const day = String(d.getDate()).padStart(2, '0');
      const hours = String(d.getHours()).padStart(2, '0');
      const mins = String(d.getMinutes()).padStart(2, '0');
      const secs = String(d.getSeconds()).padStart(2, '0');
      const days = ['日', '月', '火', '水', '木', '金', '土'];
      setTimeStr(`${year}年${month}月${day}日(${days[d.getDay()]}) ${hours}:${mins}:${secs} JST`);
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <header
      id="main-header"
      className="bg-slate-950 border-b border-slate-800 text-slate-100 px-5 py-2.5 flex flex-col md:flex-row md:items-center md:justify-between gap-3 sticky top-0 z-30 shadow-md"
    >
      {/* Title & Institutional Identity */}
      <div className="flex items-center gap-3.5">
        <div className="w-9 h-9 rounded bg-slate-900 border border-slate-700 flex items-center justify-center text-slate-300 font-bold text-sm tracking-wider shadow-inner">
          <Layers className="w-5 h-5 text-slate-300" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-base font-bold tracking-tight text-white flex items-center gap-2">
              <span>デジタル円 中央銀行デジタル通貨基盤</span>
              <span className="text-[10px] text-slate-400 font-normal tracking-wider border border-slate-800 bg-slate-900/90 px-1.5 py-0.5 rounded uppercase font-mono">
                DIGITAL YEN CBDC INFRASTRUCTURE
              </span>
            </h1>
          </div>
          <p className="text-[11px] text-slate-400 tracking-normal flex items-center gap-2">
            <span>中央銀行デジタル通貨・決済・清算・流通シミュレーションシステム</span>
            <span className="text-slate-600 hidden lg:inline">|</span>
            <span className="text-slate-500 hidden lg:inline font-mono text-[10px]">
              RTGS/DNS HYBRID PROTOCOL v3.8
            </span>
          </p>
        </div>
      </div>

      {/* Right status & interactive modal launchers */}
      <div className="flex items-center flex-wrap gap-2.5">
        {/* Real-time Clock */}
        <div className="hidden xl:flex items-center gap-1.5 text-xs text-slate-400 bg-slate-900/90 px-2.5 py-1 rounded border border-slate-800 font-mono-num">
          <Clock className="w-3.5 h-3.5 text-slate-500" />
          <span>{timeStr}</span>
        </div>

        {/* System Health Status */}
        <div className="flex items-center gap-1.5 px-2.5 py-1 bg-emerald-950/70 border border-emerald-800/80 rounded text-emerald-300 text-xs font-medium font-mono-num">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          <span>正常稼働</span>
        </div>

        {/* Required prominent Simulation badges */}
        <div className="flex items-center gap-1.5">
          <span className="bg-amber-950/70 border border-amber-800/80 text-amber-300 text-xs px-2.5 py-1 rounded font-medium flex items-center gap-1 font-mono-num">
            <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
            シミュレーション環境
          </span>
          <span className="bg-slate-900 border border-slate-700 text-slate-300 text-xs px-2.5 py-1 rounded font-medium font-mono-num">
            模擬データ
          </span>
        </div>

        {/* Fast Action Preview Buttons */}
        <div className="flex items-center gap-1.5 pl-2 border-l border-slate-800">
          <button
            id="btn-open-consumer-wallet"
            onClick={onOpenConsumerWallet}
            className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded transition shadow-sm active:scale-95"
            title="個人ウォレットの端末UIをシミュレート"
          >
            <Smartphone className="w-3.5 h-3.5 text-sky-400" />
            <span>個人端末</span>
          </button>
          <button
            id="btn-open-merchant-terminal"
            onClick={onOpenMerchantTerminal}
            className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded transition shadow-sm active:scale-95"
            title="店舗POS決済端末をシミュレート"
          >
            <Store className="w-3.5 h-3.5 text-amber-400" />
            <span>加盟店POS</span>
          </button>
          <button
            id="btn-reset-simulation"
            onClick={() => {
              if (window.confirm('シミュレーションデータを初期シード状態にリセットしますか？')) {
                resetSimulationData();
              }
            }}
            className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded border border-transparent hover:border-slate-700 transition"
            title="データ初期化"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </header>
  );
};
