import React from 'react';
import { useSimulation } from '../../simulation/SimulationContext';
import { Server, Activity, Shield, AlertCircle } from 'lucide-react';

export const StatusBar: React.FC = () => {
  const { institutions, clearingQueue, macroModel } = useSimulation();

  const totalApiRequests = institutions.reduce((acc, i) => acc + i.apiRequestsToday, 0);
  const avgLatency = Math.round(
    institutions.reduce((acc, i) => acc + i.latencyMs, 0) / institutions.length
  );
  const pendingClearing = clearingQueue.filter((q) => q.status !== '清算済').length;

  return (
    <footer
      id="status-bar"
      className="bg-slate-950 border-t border-slate-800 px-4 py-1.5 text-[11px] text-slate-400 flex flex-col sm:flex-row items-center justify-between gap-2 z-20 shrink-0 font-mono-num"
    >
      {/* Left: System Telemetry metrics */}
      <div className="flex items-center flex-wrap gap-4">
        <div className="flex items-center gap-1.5 text-slate-300">
          <Server className="w-3.5 h-3.5 text-slate-500" />
          <span className="text-slate-400">ノード群:</span>
          <span className="font-semibold text-emerald-400">5/5 接続正常</span>
        </div>

        <div className="flex items-center gap-1.5">
          <Activity className="w-3.5 h-3.5 text-slate-500" />
          <span className="text-slate-400">平均応答:</span>
          <span className="text-slate-200">{avgLatency}ms</span>
        </div>

        <div className="flex items-center gap-1.5">
          <span className="text-slate-400">本日API要求数:</span>
          <span className="text-slate-200">{totalApiRequests.toLocaleString()} req</span>
        </div>

        <div className="flex items-center gap-1.5">
          <span className="text-slate-400">清算待機キュー:</span>
          <span className={`${pendingClearing > 0 ? 'text-amber-400 font-bold' : 'text-slate-400'}`}>
            {pendingClearing}件
          </span>
        </div>
      </div>

      {/* Right: Institutional Disclaimer */}
      <div className="flex items-center gap-2 text-[10px] text-slate-500">
        <Shield className="w-3 h-3 text-slate-600" />
        <span className="truncate">
          【シミュレーション環境】本画面のデータはすべて模擬検証用です。実際の金融システムとの連動はありません。
        </span>
      </div>
    </footer>
  );
};
