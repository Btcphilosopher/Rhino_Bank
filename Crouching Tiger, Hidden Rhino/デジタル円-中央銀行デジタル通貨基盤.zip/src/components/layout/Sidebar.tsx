import React from 'react';
import {
  LayoutDashboard,
  Coins,
  TrendingUp,
  Wallet as WalletIcon,
  Building2,
  CreditCard,
  Layers,
  ArrowLeftRight,
  WifiOff,
  Code2,
  Droplets,
  ShieldAlert,
  FileCheck,
  MapPin,
  LineChart,
  Server,
  BookOpen,
  Play,
  Pause,
  RotateCcw,
  FastForward,
} from 'lucide-react';
import { NavigationItemKey } from '../../types';
import { useSimulation } from '../../simulation/SimulationContext';

interface SidebarProps {
  currentView: NavigationItemKey;
  onSelectView: (view: NavigationItemKey) => void;
}

interface NavItemDef {
  key: NavigationItemKey;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badgeCount?: number;
  badgeType?: 'alert' | 'info' | 'neutral';
  category?: string;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentView, onSelectView }) => {
  const {
    abnormalTxCount,
    clearingQueue,
    macroModel,
    setSimulationSpeed,
    toggleSimulationRunning,
    resetSimulationData,
  } = useSimulation();

  const pendingClearingCount = clearingQueue.filter((q) => q.status !== '清算済').length;

  const navItems: NavItemDef[] = [
    { key: 'dashboard', label: 'ダッシュボード', icon: LayoutDashboard },
    { key: 'issuance', label: 'デジタル円発行', icon: Coins },
    { key: 'circulation', label: '流通管理', icon: TrendingUp },
    { key: 'wallets', label: 'ウォレット管理', icon: WalletIcon },
    { key: 'institutions', label: '金融機関', icon: Building2 },
    { key: 'payment_processing', label: '決済処理', icon: CreditCard },
    {
      key: 'clearing_settlement',
      label: '清算・決済',
      icon: Layers,
      badgeCount: pendingClearingCount > 0 ? pendingClearingCount : undefined,
      badgeType: 'info',
    },
    { key: 'interbank', label: '銀行間決済', icon: ArrowLeftRight },
    { key: 'offline_payment', label: 'オフライン決済', icon: WifiOff },
    { key: 'programmable_payments', label: 'プログラマブル決済', icon: Code2 },
    { key: 'liquidity_management', label: '流動性管理', icon: Droplets },
    {
      key: 'risk_management',
      label: 'リスク管理',
      icon: ShieldAlert,
      badgeCount: abnormalTxCount > 0 ? abnormalTxCount : undefined,
      badgeType: 'alert',
    },
    { key: 'audit_logs', label: '監査ログ', icon: FileCheck },
    { key: 'regional_analytics', label: 'データ分析', icon: MapPin },
    { key: 'economic_simulation', label: '経済シミュレーション', icon: LineChart },
    { key: 'system_operations', label: 'システム運用', icon: Server },
    { key: 'ledger', label: '取引台帳', icon: BookOpen },
  ];

  return (
    <aside
      id="main-sidebar"
      className="w-64 bg-slate-950 border-r border-slate-800 flex flex-col justify-between shrink-0 select-none text-slate-300 z-20 overflow-y-auto"
    >
      {/* Navigation List */}
      <div className="py-2.5 px-2">
        <div className="px-2 py-1 mb-1">
          <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500 font-mono">
            基盤業務メニュー / WORKSTATION
          </span>
        </div>
        <nav className="space-y-0.5">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.key;
            return (
              <button
                key={item.key}
                id={`nav-item-${item.key}`}
                onClick={() => onSelectView(item.key)}
                className={`w-full flex items-center justify-between px-3 py-2 rounded text-xs font-medium transition-colors text-left ${
                  isActive
                    ? 'bg-slate-800 text-white font-semibold border-l-2 border-slate-300 shadow-sm'
                    : 'text-slate-300 hover:bg-slate-900 hover:text-slate-100'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <Icon
                    className={`w-4 h-4 shrink-0 ${
                      isActive ? 'text-slate-100' : 'text-slate-400'
                    }`}
                  />
                  <span className="truncate">{item.label}</span>
                </div>

                {item.badgeCount !== undefined && (
                  <span
                    className={`px-1.5 py-0.2 rounded text-[10px] font-mono-num font-bold ${
                      item.badgeType === 'alert'
                        ? 'bg-rose-950 text-rose-300 border border-rose-800'
                        : 'bg-sky-950 text-sky-300 border border-sky-800'
                    }`}
                  >
                    {item.badgeCount}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Simulation Speed & Engine Control Footer */}
      <div className="p-3 bg-slate-900/90 border-t border-slate-800 m-2 rounded">
        <div className="flex items-center justify-between mb-2">
          <span className="text-[11px] font-bold text-slate-300 flex items-center gap-1">
            <span
              className={`w-1.5 h-1.5 rounded-full ${
                macroModel.isRunning ? 'bg-emerald-400 animate-pulse' : 'bg-slate-500'
              }`}
            />
            シミュレータ制御
          </span>
          <span className="text-[10px] text-slate-500 font-mono-num">
            {macroModel.isRunning ? '稼働中' : '停止中'}
          </span>
        </div>

        {/* Speed selectors */}
        <div className="grid grid-cols-3 gap-1 mb-2">
          {([1, 10, 100] as const).map((spd) => (
            <button
              key={spd}
              id={`btn-sim-speed-${spd}`}
              onClick={() => setSimulationSpeed(spd)}
              className={`text-[10px] py-1 font-mono-num rounded border transition font-medium ${
                macroModel.simulationSpeed === spd
                  ? 'bg-slate-700 text-white border-slate-500'
                  : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
              }`}
            >
              ×{spd}
            </button>
          ))}
        </div>

        {/* Control Buttons */}
        <div className="flex items-center gap-1.5">
          <button
            id="btn-toggle-sim-running"
            onClick={toggleSimulationRunning}
            className={`flex-1 flex items-center justify-center gap-1 py-1 rounded text-[11px] font-medium transition border ${
              macroModel.isRunning
                ? 'bg-amber-950/60 border-amber-800 text-amber-300 hover:bg-amber-900/80'
                : 'bg-emerald-950/60 border-emerald-800 text-emerald-300 hover:bg-emerald-900/80'
            }`}
          >
            {macroModel.isRunning ? (
              <>
                <Pause className="w-3 h-3" />
                一時停止
              </>
            ) : (
              <>
                <Play className="w-3 h-3" />
                開始
              </>
            )}
          </button>
          <button
            id="btn-reset-sim-state"
            onClick={() => {
              if (window.confirm('シミュレータの全状態を初期化しますか？')) {
                resetSimulationData();
              }
            }}
            className="p-1 text-slate-400 hover:text-slate-200 bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded transition"
            title="状態リセット"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </aside>
  );
};
