import React, { useState } from 'react';
import { useSimulation } from '../../simulation/SimulationContext';
import { StatusBadge } from '../common/Badge';
import {
  Layers,
  RefreshCw,
  CheckCircle2,
  ArrowRight,
  ShieldCheck,
  Zap,
  Clock,
  Filter,
} from 'lucide-react';

export const ClearingSettlementView: React.FC = () => {
  const { clearingQueue, processClearingItem, processAllClearing, clearingProcessedAmount } = useSimulation();
  const [filterMode, setFilterMode] = useState<'all' | 'pending' | 'cleared'>('all');

  const filteredQueue = clearingQueue.filter((item) => {
    if (filterMode === 'pending') return item.status !== '清算済';
    if (filterMode === 'cleared') return item.status === '清算済';
    return true;
  });

  const pendingCount = clearingQueue.filter((q) => q.status !== '清算済').length;

  return (
    <div className="space-y-4 p-5 max-w-[1600px] mx-auto font-mono-num">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-sky-400" />
            <h2 className="text-base font-bold text-slate-100">中央銀行 清算・決済センター</h2>
            <span className="text-xs bg-slate-800 text-slate-300 border border-slate-700 px-2 py-0.5 rounded">
              累計清算額: ¥{clearingProcessedAmount.toLocaleString()}
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            即時グロス決済 (RTGS) および 時点ネット決済 (DNS) による銀行間債権債務の差額相殺と最終ファイナリティ付与
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={processAllClearing}
            disabled={pendingCount === 0}
            className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-600 rounded text-xs font-bold flex items-center gap-1.5 transition disabled:opacity-50"
          >
            <RefreshCw className="w-3.5 h-3.5 text-sky-400" />
            <span>全件即時相殺清算 (DNSバッチ執行)</span>
          </button>
        </div>
      </div>

      {/* Visual Settlement Pipeline Architecture */}
      <div className="bg-slate-900 border border-slate-800 rounded p-4">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>CBDC 清算・決済パイプライン（確定ファイナリティ工程）</span>
        </h3>

        <div className="grid grid-cols-2 md:grid-cols-7 gap-2 text-center text-xs">
          {[
            { step: '1', title: '取引受付', desc: 'メッセージ受領', status: '正常' },
            { step: '2', title: 'フォーマット検証', desc: 'ISO 20022準拠', status: '正常' },
            { step: '3', title: '残高確認', desc: '当預引当照会', status: '正常' },
            { step: '4', title: 'リスク確認', desc: 'AML/信用枠照合', status: '正常' },
            { step: '5', title: '相殺・清算', desc: '差額相殺計算', status: '正常' },
            { step: '6', title: '台帳更新', desc: 'CBDCコア記帳', status: '正常' },
            { step: '7', title: '確定完了', desc: 'Finality付与', status: '確定' },
          ].map((item, idx) => (
            <div key={idx} className="bg-slate-950 p-2.5 rounded border border-slate-800">
              <div className="text-[10px] text-slate-500 font-bold">STEP {item.step}</div>
              <div className="font-bold text-slate-200 mt-0.5">{item.title}</div>
              <div className="text-[10px] text-slate-400 mt-0.5">{item.desc}</div>
              <div className="text-[10px] text-emerald-400 mt-1 font-semibold">● {item.status}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Real-time Clearing Queue Table */}
      <div className="bg-slate-900 border border-slate-800 rounded p-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 pb-3 mb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-slate-400" />
            <h3 className="text-sm font-bold text-slate-100">
              リアルタイム清算待機キュー (Clearing Engine Queue)
            </h3>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 text-xs">
              <button
                onClick={() => setFilterMode('all')}
                className={`px-2.5 py-1 rounded border transition ${
                  filterMode === 'all'
                    ? 'bg-slate-700 text-white border-slate-500 font-bold'
                    : 'bg-slate-950 text-slate-400 border-slate-800'
                }`}
              >
                全件 ({clearingQueue.length})
              </button>
              <button
                onClick={() => setFilterMode('pending')}
                className={`px-2.5 py-1 rounded border transition ${
                  filterMode === 'pending'
                    ? 'bg-slate-700 text-white border-slate-500 font-bold'
                    : 'bg-slate-950 text-slate-400 border-slate-800'
                }`}
              >
                未清算 ({pendingCount})
              </button>
              <button
                onClick={() => setFilterMode('cleared')}
                className={`px-2.5 py-1 rounded border transition ${
                  filterMode === 'cleared'
                    ? 'bg-slate-700 text-white border-slate-500 font-bold'
                    : 'bg-slate-950 text-slate-400 border-slate-800'
                }`}
              >
                清算済 ({clearingQueue.length - pendingCount})
              </button>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="text-slate-400 border-b border-slate-800 bg-slate-950/60">
                <th className="py-2.5 px-2.5 font-medium">キューID</th>
                <th className="py-2.5 px-2.5 font-medium">対象取引番号</th>
                <th className="py-2.5 px-2.5 font-medium">送金金融機関</th>
                <th className="py-2.5 px-2.5 font-medium">受取金融機関</th>
                <th className="py-2.5 px-2.5 font-medium text-right">清算金額</th>
                <th className="py-2.5 px-2.5 font-medium">受付時刻</th>
                <th className="py-2.5 px-2.5 font-medium">所要時間</th>
                <th className="py-2.5 px-2.5 font-medium">方式</th>
                <th className="py-2.5 px-2.5 font-medium text-center">状態</th>
                <th className="py-2.5 px-2.5 font-medium text-center">操作</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredQueue.map((item) => (
                <tr key={item.id} className="hover:bg-slate-800/40">
                  <td className="py-2.5 px-2.5 font-semibold text-slate-300">{item.id}</td>
                  <td className="py-2.5 px-2.5 font-bold text-slate-200">{item.txnId}</td>
                  <td className="py-2.5 px-2.5 text-slate-300">{item.sourceBank}</td>
                  <td className="py-2.5 px-2.5 text-slate-300">{item.destBank}</td>
                  <td className="py-2.5 px-2.5 text-right font-bold text-slate-100">
                    ¥{item.amount.toLocaleString()}
                  </td>
                  <td className="py-2.5 px-2.5 text-slate-400">{item.queuedAt}</td>
                  <td className="py-2.5 px-2.5 text-slate-400">{item.processingTimeMs} ms</td>
                  <td className="py-2.5 px-2.5 text-slate-400 text-[11px]">{item.settlementMode}</td>
                  <td className="py-2.5 px-2.5 text-center">
                    <StatusBadge status={item.status} size="sm" />
                  </td>
                  <td className="py-2.5 px-2.5 text-center">
                    {item.status !== '清算済' ? (
                      <button
                        onClick={() => processClearingItem(item.id)}
                        className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-sky-300 border border-slate-700 rounded text-[11px] font-bold transition"
                      >
                        清算執行
                      </button>
                    ) : (
                      <span className="text-[11px] text-emerald-400 font-semibold">完了済</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
