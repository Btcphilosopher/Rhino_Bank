import React, { useState } from 'react';
import { useSimulation } from '../../simulation/SimulationContext';
import { StatusBadge } from '../common/Badge';
import {
  FileSpreadsheet,
  Search,
  Filter,
  Download,
  CheckCircle2,
  Clock,
  Layers,
} from 'lucide-react';

export const LedgerView: React.FC = () => {
  const { transactions } = useSimulation();

  const [searchTerm, setSearchTerm] = useState('');
  const [filterMethod, setFilterMethod] = useState('all');

  const filteredTxns = transactions.filter((txn) => {
    const matchesSearch =
      txn.id.includes(searchTerm) ||
      txn.sourceName.includes(searchTerm) ||
      txn.destName.includes(searchTerm) ||
      txn.purpose.includes(searchTerm) ||
      txn.sourceBank.includes(searchTerm) ||
      txn.destBank.includes(searchTerm);
    const matchesMethod = filterMethod === 'all' || txn.paymentMethod === filterMethod;
    return matchesSearch && matchesMethod;
  });

  const exportCSV = () => {
    const headers = ['台帳番号,取引番号,日時,送金元,送金元銀行,送金先,送金先銀行,決済方法,金額,目的,状態,ハッシュ\n'];
    const rows = filteredTxns.map(
      (t) =>
        `"${t.ledgerNumber}","${t.id}","${t.timestamp}","${t.sourceName}","${t.sourceBank}","${t.destName}","${t.destBank}","${t.paymentMethod}","${t.amount}","${t.purpose}","${t.status}","${t.hash}"\n`
    );
    const blob = new Blob([...headers, ...rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `CBDC_Ledger_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-4 p-5 max-w-[1600px] mx-auto font-mono-num">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5 text-sky-400" />
            <h2 className="text-base font-bold text-slate-100">
              デジタル円 中央確定取引台帳 (Central Core Ledger)
            </h2>
            <span className="text-xs bg-slate-800 text-slate-300 border border-slate-700 px-2 py-0.5 rounded">
              記帳総数: {transactions.length} 件
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            二層構造CBDCにおける全決済・振替・発行・償却の通番記帳と暗号学的確定ファイナリティ
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={exportCSV}
            className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded text-xs font-bold flex items-center gap-1.5 transition"
          >
            <Download className="w-3.5 h-3.5" />
            <span>台帳CSV出力</span>
          </button>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-slate-900 border border-slate-800 p-3 rounded flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="relative w-full sm:w-96">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="取引ID・口座名・銀行名・用途で検索..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950 border border-slate-700 rounded pl-9 pr-3 py-1.5 text-slate-100 placeholder-slate-500 focus:outline-none focus:border-sky-500"
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          <span className="text-slate-400 whitespace-nowrap">決済方式:</span>
          {['all', 'QRコード', 'NFC', 'ウォレット間送金', 'API決済', 'オフライン決済'].map(
            (m) => (
              <button
                key={m}
                onClick={() => setFilterMethod(m)}
                className={`px-2.5 py-1 rounded border transition whitespace-nowrap ${
                  filterMethod === m
                    ? 'bg-slate-700 text-white border-slate-500 font-bold'
                    : 'bg-slate-950 text-slate-400 border-slate-800'
                }`}
              >
                {m === 'all' ? '全方式' : m}
              </button>
            )
          )}
        </div>
      </div>

      {/* Ledger Table */}
      <div className="bg-slate-900 border border-slate-800 rounded p-4">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="text-slate-400 border-b border-slate-800 bg-slate-950/60">
                <th className="py-2.5 px-2.5 font-medium">通番</th>
                <th className="py-2.5 px-2.5 font-medium">取引番号 (Txn ID)</th>
                <th className="py-2.5 px-2.5 font-medium">日時 (JST)</th>
                <th className="py-2.5 px-2.5 font-medium">送金元</th>
                <th className="py-2.5 px-2.5 font-medium">受取先</th>
                <th className="py-2.5 px-2.5 font-medium">方式</th>
                <th className="py-2.5 px-2.5 font-medium">目的 / 摘要</th>
                <th className="py-2.5 px-2.5 font-medium text-right">決済金額</th>
                <th className="py-2.5 px-2.5 font-medium text-center">処理状態</th>
                <th className="py-2.5 px-2.5 font-medium">台帳ハッシュ</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredTxns.map((txn) => (
                <tr key={txn.id} className="hover:bg-slate-800/40">
                  <td className="py-2.5 px-2.5 text-slate-500 font-bold">#{txn.ledgerNumber}</td>
                  <td className="py-2.5 px-2.5 font-bold text-slate-200">{txn.id}</td>
                  <td className="py-2.5 px-2.5 text-slate-400">{txn.timestamp}</td>
                  <td className="py-2.5 px-2.5 text-slate-300">
                    <div className="font-semibold">{txn.sourceName}</div>
                    <div className="text-[10px] text-slate-500">{txn.sourceBank}</div>
                  </td>
                  <td className="py-2.5 px-2.5 text-slate-300">
                    <div className="font-semibold">{txn.destName}</div>
                    <div className="text-[10px] text-slate-500">{txn.destBank}</div>
                  </td>
                  <td className="py-2.5 px-2.5 text-slate-300">{txn.paymentMethod}</td>
                  <td className="py-2.5 px-2.5 text-slate-400 truncate max-w-[160px]">{txn.purpose}</td>
                  <td className="py-2.5 px-2.5 font-bold text-right text-slate-100">
                    ¥{txn.amount.toLocaleString()}
                  </td>
                  <td className="py-2.5 px-2.5 text-center">
                    <StatusBadge status={txn.status} size="sm" />
                  </td>
                  <td className="py-2.5 px-2.5 text-slate-500 text-[10px] font-mono truncate max-w-[120px]">
                    {txn.hash}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
