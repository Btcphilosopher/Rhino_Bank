import React from 'react';
import { useSimulation } from '../../simulation/SimulationContext';
import { StatusBadge } from '../common/Badge';
import {
  WifiOff,
  Wifi,
  Smartphone,
  Cpu,
  ArrowRight,
  ShieldCheck,
  AlertTriangle,
  RotateCcw,
  CheckCircle2,
  Lock,
  Layers,
  FileCheck,
} from 'lucide-react';

export const OfflinePaymentView: React.FC = () => {
  const { offlineSession, advanceOfflineStep, resetOfflineSession } = useSimulation();

  const steps: {
    key: typeof offlineSession.currentState;
    label: string;
    description: string;
    icon: React.ReactNode;
  }[] = [
    {
      key: '1_通信切断',
      label: '1. 通信切断・スタンドアロン移行',
      description: '災害・基地局途絶を想定したオフライン動作モード起動',
      icon: <WifiOff className="w-4 h-4 text-rose-400" />,
    },
    {
      key: '2_セキュアエレメント検証',
      label: '2. 耐タンパーSE・暗号署名検証',
      description: 'ハードウェア内部のセキュアエレメントによる残高と署名隔離検証',
      icon: <Cpu className="w-4 h-4 text-sky-400" />,
    },
    {
      key: '3_端末間取引実行',
      label: '3. 近距離P2P端末間決済実行',
      description: 'NFC/BLEによる暗号トークン・モノトニックカウンター安全受け渡し',
      icon: <Smartphone className="w-4 h-4 text-amber-400" />,
    },
    {
      key: '4_一時保存',
      label: '4. 暗号化ローカル保管',
      description: '端末内不揮発性ストレージへの電子署名済み領収トークン保持',
      icon: <Lock className="w-4 h-4 text-purple-400" />,
    },
    {
      key: '5_通信復旧待機',
      label: '5. 通信インフラ復旧検知',
      description: 'セルラー網・Wi-Fi接続の回復検知とCBDC中核ノードへの再接続',
      icon: <Wifi className="w-4 h-4 text-sky-400" />,
    },
    {
      key: '6_同期処理',
      label: '6. 台帳同期アップロード',
      description: '保留されていたオフライン署名トークンの中央中核基盤への一括送信',
      icon: <Layers className="w-4 h-4 text-indigo-400" />,
    },
    {
      key: '7_二重使用検知・照合',
      label: '7. 二重使用検知・正当性照合',
      description: 'カウンター重複・ロールバック攻撃の暗号学的突合・不正遮断',
      icon: <FileCheck className="w-4 h-4 text-emerald-400" />,
    },
    {
      key: '8_最終清算完了',
      label: '8. 中央コア台帳更新・清算完了',
      description: '正当なオフライン取引の最終確定と双方口座残高への正式記帳',
      icon: <CheckCircle2 className="w-4 h-4 text-emerald-400" />,
    },
  ];

  const currentStepIndex = steps.findIndex((s) => s.key === offlineSession.currentState);

  return (
    <div className="space-y-4 p-5 max-w-[1600px] mx-auto font-mono-num">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <WifiOff className="w-5 h-5 text-amber-400" />
            <h2 className="text-base font-bold text-slate-100">
              二者間オフライン決済シミュレーション (Dual Offline P2P)
            </h2>
            <span className="text-xs bg-slate-800 text-slate-300 border border-slate-700 px-2 py-0.5 rounded">
              耐タンパーSE暗号技術準拠
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            通信途絶・災害時におけるスマート端末間の暗号学的直接決済と通信復旧後の二重使用検知・台帳同期プロトコル
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => resetOfflineSession(false)}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded text-xs font-medium flex items-center gap-1.5 transition"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>正常系シナリオ 初期化</span>
          </button>
          <button
            onClick={() => resetOfflineSession(true)}
            className="px-3 py-1.5 bg-rose-950/70 hover:bg-rose-900 text-rose-300 border border-rose-800 rounded text-xs font-bold flex items-center gap-1.5 transition"
          >
            <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
            <span>二重使用攻撃 検知テスト</span>
          </button>
        </div>
      </div>

      {/* Main Grid: State Machine Stepper & Terminal State Card */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left 7 cols: Interactive Visual State Machine */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded p-4">
          <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-800">
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>オフライン決済 状態遷移マシン (State Machine)</span>
            </h3>
            <span className="text-xs text-slate-400">
              進捗: {currentStepIndex + 1} / {steps.length}
            </span>
          </div>

          <div className="space-y-2.5 text-xs">
            {steps.map((step, idx) => {
              const isCompleted = currentStepIndex > idx;
              const isCurrent = currentStepIndex === idx;
              const isPending = currentStepIndex < idx;

              return (
                <div
                  key={step.key}
                  className={`p-3 rounded border transition-all ${
                    isCurrent
                      ? 'bg-slate-800 border-sky-500 shadow-md ring-1 ring-sky-500/30'
                      : isCompleted
                      ? 'bg-emerald-950/40 border-emerald-800/80 text-emerald-200'
                      : 'bg-slate-950/60 border-slate-800/80 text-slate-500'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className="p-1 rounded bg-slate-900 border border-slate-700">
                        {step.icon}
                      </div>
                      <span className="font-bold text-slate-100">{step.label}</span>
                    </div>

                    <div>
                      {isCompleted && (
                        <span className="text-emerald-400 text-[11px] font-bold flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" /> 完了
                        </span>
                      )}
                      {isCurrent && (
                        <span className="px-2 py-0.5 bg-sky-950 text-sky-300 border border-sky-700 rounded text-[10px] font-bold animate-pulse">
                          現在実行中
                        </span>
                      )}
                      {isPending && <span className="text-[10px] text-slate-600">待機中</span>}
                    </div>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1 pl-8">{step.description}</p>
                </div>
              );
            })}
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between">
            <span className="text-[11px] text-slate-400">
              セッションID: {offlineSession.id}
            </span>
            {currentStepIndex < steps.length - 1 && (
              <button
                id="btn-advance-offline-step"
                onClick={advanceOfflineStep}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-600 rounded text-xs font-bold flex items-center gap-1.5 transition active:scale-95 shadow-sm"
              >
                <span>次のステップを実行</span>
                <ArrowRight className="w-3.5 h-3.5 text-sky-400" />
              </button>
            )}
            {currentStepIndex === steps.length - 1 && (
              <span className="text-xs text-emerald-400 font-bold flex items-center gap-1">
                <CheckCircle2 className="w-4 h-4" /> 全工程完了（CBDC台帳記帳済）
              </span>
            )}
          </div>
        </div>

        {/* Right 5 cols: Offline Device & Cryptographic Verification Card */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded p-4 flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-100 pb-3 mb-3 border-b border-slate-800 flex items-center gap-2">
              <Cpu className="w-4 h-4 text-amber-400" />
              <span>端末ハードウェア & 暗号署名検証情報</span>
            </h3>

            <div className="space-y-2.5 text-xs">
              <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-1.5">
                <div className="text-[10px] text-slate-500">送金側端末 (市民端末)</div>
                <div className="font-bold text-slate-200">{offlineSession.sourceDevice}</div>
                <div className="text-[11px] text-slate-400">口座: {offlineSession.sourceWalletId}</div>
              </div>

              <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-1.5">
                <div className="text-[10px] text-slate-500">受取側端末 (店舗/他者端末)</div>
                <div className="font-bold text-slate-200">{offlineSession.destDevice}</div>
                <div className="text-[11px] text-slate-400">口座: {offlineSession.destWalletId}</div>
              </div>

              <div className="p-3 bg-slate-950 rounded border border-slate-800">
                <div className="flex justify-between items-baseline mb-1">
                  <span className="text-slate-400">オフライン取引金額:</span>
                  <span className="text-base font-bold text-slate-100">
                    ¥{offlineSession.amount.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between text-[11px] text-slate-400">
                  <span>乱数ノンス:</span>
                  <span className="text-slate-300">{offlineSession.nonce}</span>
                </div>
              </div>

              <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-1 text-[11px]">
                <div className="text-slate-400">暗号学的署名 (ECDSA P-256):</div>
                <div className="text-[10px] text-emerald-400 font-mono break-all bg-slate-900 p-1.5 rounded border border-slate-800">
                  {offlineSession.secureElementSignature}
                </div>
              </div>

              {/* Status Note or Double Spend Warning */}
              <div
                className={`p-3 rounded border text-xs ${
                  offlineSession.doubleSpendDetected
                    ? 'bg-rose-950 border-rose-800 text-rose-300'
                    : 'bg-slate-950 border-slate-800 text-slate-300'
                }`}
              >
                <div className="font-bold mb-0.5">システム検証注記:</div>
                <div>{offlineSession.notes}</div>
              </div>
            </div>
          </div>

          <div className="pt-3 mt-3 border-t border-slate-800 text-[11px] text-slate-400">
            <span>※ 日銀CBDCオフライン決済実験仕様（耐タンパーIC）に準拠</span>
          </div>
        </div>
      </div>
    </div>
  );
};
