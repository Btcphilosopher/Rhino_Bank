import React, { useState } from 'react';
import { useSimulation } from '../../simulation/SimulationContext';
import { IssuanceType } from '../../types';
import { StatusBadge } from '../common/Badge';
import {
  Coins,
  ArrowDown,
  Building,
  UserCheck,
  CreditCard,
  Layers,
  RotateCcw,
  CheckCircle2,
  AlertCircle,
  FileCheck,
  Shield,
  ArrowRight,
  Send,
} from 'lucide-react';

export const IssuanceView: React.FC = () => {
  const {
    institutions,
    issuanceRecords,
    issueDigitalYen,
    totalCirculation,
  } = useSimulation();

  // Form inputs
  const [issuanceType, setIssuanceType] = useState<IssuanceType>('追加発行');
  const [targetBankId, setTargetBankId] = useState(institutions[0]?.id || '');
  const [amount, setAmount] = useState<number>(100000000000); // 1,000億円
  const [reason, setReason] = useState('日中決済集中時間帯における銀行間決済流動性の充足');
  const [remarks, setRemarks] = useState('日銀当座預金差入担保承認済 (担保コード: JGB-2026-9901)');
  const [operator, setOperator] = useState('日本銀行 業務局 発行清算課 (OP-702)');
  const [feedback, setFeedback] = useState<{ success: boolean; message: string } | null>(null);

  const selectedBank = institutions.find((b) => b.id === targetBankId) || institutions[0];

  const handleSimulate = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);

    const result = issueDigitalYen({
      type: issuanceType,
      targetBankId,
      amount,
      reason,
      remarks,
      operator,
    });

    if (result.success && result.record) {
      setFeedback({
        success: true,
        message: `【処理完了】${result.record.auditNumber} にて ${selectedBank?.name} 宛てに ¥${amount.toLocaleString()} の「${issuanceType}」が正常に執行・台帳記帳されました。`,
      });
    } else {
      setFeedback({
        success: false,
        message: result.error || '発行処理中にエラーが発生しました。',
      });
    }
  };

  const isDeduction = issuanceType === '回収' || issuanceType === '償却';
  const preBalance = selectedBank ? selectedBank.cbdcBalance : 0;
  const postBalance = isDeduction ? preBalance - amount : preBalance + amount;

  return (
    <div className="space-y-5 p-5 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <Coins className="w-5 h-5 text-amber-400" />
            <h2 className="text-base font-bold text-slate-100">デジタル円発行管理</h2>
            <span className="text-xs bg-slate-800 text-slate-300 border border-slate-700 px-2 py-0.5 rounded font-mono-num">
              発行総額: ¥{totalCirculation.toLocaleString()}
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            中央銀行（日本銀行）によるデジタル円の一次発行・当座預金担保引当・回収・償却のライフサイクル執行
          </p>
        </div>
        <div className="flex items-center gap-2 text-xs text-slate-400 font-mono-num bg-slate-950 px-3 py-1.5 rounded border border-slate-800">
          <Shield className="w-3.5 h-3.5 text-emerald-400" />
          <span>準備預金引当率: 100.0% (全額法定担保)</span>
        </div>
      </div>

      {/* Visual Monetary Lifecycle Diagram */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-2">
          <span>デジタル円 通貨ライフサイクル（二層構造モデル）</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-7 gap-2 text-center text-xs font-mono-num items-center">
          {/* Step 1: Central Bank */}
          <div className="bg-slate-950 p-3 rounded border border-slate-700/80 flex flex-col items-center">
            <div className="w-8 h-8 rounded-full bg-slate-800 border border-slate-600 flex items-center justify-center text-amber-400 mb-1.5">
              <Building className="w-4 h-4" />
            </div>
            <span className="font-bold text-slate-200">中央銀行</span>
            <span className="text-[10px] text-slate-400">日本銀行</span>
          </div>

          <div className="flex justify-center text-slate-600">
            <ArrowRight className="w-5 h-5 hidden md:block" />
            <ArrowDown className="w-5 h-5 md:hidden" />
          </div>

          {/* Step 2: Digital Yen Issuance */}
          <div className="bg-slate-950 p-3 rounded border border-amber-900/60 flex flex-col items-center">
            <div className="w-8 h-8 rounded-full bg-amber-950 border border-amber-700 flex items-center justify-center text-amber-300 mb-1.5">
              <Coins className="w-4 h-4" />
            </div>
            <span className="font-bold text-amber-300">デジタル円発行</span>
            <span className="text-[10px] text-slate-400">当預担保対価</span>
          </div>

          <div className="flex justify-center text-slate-600">
            <ArrowRight className="w-5 h-5 hidden md:block" />
            <ArrowDown className="w-5 h-5 md:hidden" />
          </div>

          {/* Step 3: Intermediary Banks */}
          <div className="bg-slate-950 p-3 rounded border border-slate-700/80 flex flex-col items-center">
            <div className="w-8 h-8 rounded-full bg-slate-800 border border-slate-600 flex items-center justify-center text-sky-400 mb-1.5">
              <Layers className="w-4 h-4" />
            </div>
            <span className="font-bold text-slate-200">仲介機関</span>
            <span className="text-[10px] text-slate-400">銀行・資金移動業者</span>
          </div>

          <div className="flex justify-center text-slate-600">
            <ArrowRight className="w-5 h-5 hidden md:block" />
            <ArrowDown className="w-5 h-5 md:hidden" />
          </div>

          {/* Step 4: End Users & Circulation */}
          <div className="bg-slate-950 p-3 rounded border border-emerald-900/60 flex flex-col items-center">
            <div className="w-8 h-8 rounded-full bg-emerald-950 border border-emerald-700 flex items-center justify-center text-emerald-300 mb-1.5">
              <CreditCard className="w-4 h-4" />
            </div>
            <span className="font-bold text-emerald-300">決済・流通</span>
            <span className="text-[10px] text-slate-400">個人・企業・加盟店</span>
          </div>
        </div>

        <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400 font-mono-num">
          <span>※ 余剰流動性は「回収 / 償却」プロセスにより随時中央銀行準備預金口座へ還流相殺されます。</span>
          <span className="text-slate-300">二層構造CBDCモデル準拠</span>
        </div>
      </div>

      {/* Simulator Form & Real-time balance calculator */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left 7 cols: Issuance Execution Simulator Form */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded p-4">
          <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-800">
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <FileCheck className="w-4 h-4 text-sky-400" />
              <span>デジタル円 発行・回収シミュレータ</span>
            </h3>
            <span className="text-[11px] text-slate-400 bg-slate-950 px-2 py-0.5 rounded border border-slate-800 font-mono-num">
              承認プロトコル: BOJ-AUTH-v3
            </span>
          </div>

          <form onSubmit={handleSimulate} className="space-y-4 text-xs font-mono-num">
            {feedback && (
              <div
                className={`p-3 rounded border ${
                  feedback.success
                    ? 'bg-emerald-950/70 border-emerald-800 text-emerald-300'
                    : 'bg-rose-950/70 border-rose-800 text-rose-300'
                }`}
              >
                <div className="flex items-start gap-2">
                  {feedback.success ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  )}
                  <span>{feedback.message}</span>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-400 font-medium mb-1">発行区分</label>
                <select
                  value={issuanceType}
                  onChange={(e) => setIssuanceType(e.target.value as IssuanceType)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-2 text-slate-100 focus:outline-none focus:border-sky-500"
                >
                  <option value="追加発行">追加発行（決済流動性供給）</option>
                  <option value="新規発行">新規発行（枠組み新規設定）</option>
                  <option value="回収">回収（日銀当預へ還流）</option>
                  <option value="償却">償却（過剰残高の減額消却）</option>
                  <option value="準備預金振替">準備預金振替（口座間相殺）</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">発行対象金融機関</label>
                <select
                  value={targetBankId}
                  onChange={(e) => setTargetBankId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-2 text-slate-100 focus:outline-none focus:border-sky-500"
                >
                  {institutions.map((bank) => (
                    <option key={bank.id} value={bank.id}>
                      {bank.name}（コード: {bank.code} / 現有: ¥{(bank.cbdcBalance / 100000000).toLocaleString()}億円）
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-400 font-medium mb-1">
                  発行・回収金額 (円)
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-slate-400">¥</span>
                  <input
                    type="number"
                    step="100000000"
                    value={amount}
                    onChange={(e) => setAmount(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 rounded pl-7 pr-3 py-2 text-slate-100 font-bold focus:outline-none focus:border-sky-500"
                    required
                  />
                </div>
                <span className="text-[10px] text-slate-400 mt-1 block">
                  換算表記: {(amount / 100000000).toLocaleString()} 億円
                </span>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">執行操作主体</label>
                <input
                  type="text"
                  value={operator}
                  onChange={(e) => setOperator(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-2 text-slate-100 focus:outline-none focus:border-sky-500"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-400 font-medium mb-1">発行理由 / 取引目的</label>
              <input
                type="text"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-2 text-slate-100 focus:outline-none focus:border-sky-500"
                required
              />
            </div>

            <div>
              <label className="block text-slate-400 font-medium mb-1">備考 / 担保・決裁番号</label>
              <input
                type="text"
                value={remarks}
                onChange={(e) => setRemarks(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-2 text-slate-100 focus:outline-none focus:border-sky-500"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                id="btn-submit-issuance"
                className="w-full py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-600 rounded font-bold transition flex items-center justify-center gap-2 active:scale-[0.99]"
              >
                <Send className="w-4 h-4 text-amber-400" />
                <span>中央銀行発行・回収トランザクション執行</span>
              </button>
            </div>
          </form>
        </div>

        {/* Right 5 cols: Live Simulation Audit Inspector */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded p-4 flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-100 pb-3 mb-3 border-b border-slate-800 flex items-center gap-2">
              <Shield className="w-4 h-4 text-emerald-400" />
              <span>発行執行前後の残高・監査試算</span>
            </h3>

            <div className="space-y-2.5 font-mono-num text-xs">
              <div className="p-3 bg-slate-950 rounded border border-slate-800">
                <div className="text-[11px] text-slate-400 mb-1">対象金融機関</div>
                <div className="text-sm font-bold text-slate-200">
                  {selectedBank?.name} (コード: {selectedBank?.code})
                </div>
              </div>

              <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">執行前保有残高:</span>
                  <span className="font-semibold text-slate-200">
                    ¥{preBalance.toLocaleString()}
                  </span>
                </div>
                <div className="flex items-center justify-between text-amber-300">
                  <span>{issuanceType} 金額:</span>
                  <span className="font-bold">
                    {isDeduction ? '-' : '+'}¥{amount.toLocaleString()}
                  </span>
                </div>
                <div className="border-t border-slate-800 pt-2 flex items-center justify-between text-emerald-400 font-bold">
                  <span>執行後想定残高:</span>
                  <span className="text-sm">¥{postBalance.toLocaleString()}</span>
                </div>
              </div>

              <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-1 text-[11px] text-slate-400">
                <div className="flex items-center justify-between">
                  <span>処理状態:</span>
                  <span className="text-emerald-400 font-medium">即時台帳確定予定</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>法定担保引当:</span>
                  <span className="text-slate-200">国債(JGB) 100% 充当</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>監査ログハッシュ:</span>
                  <span className="text-slate-400 text-[10px]">SHA-256 不変ブロック</span>
                </div>
              </div>
            </div>
          </div>

          <div className="pt-3 mt-3 border-t border-slate-800 text-[11px] text-slate-400 font-mono-num">
            <span>※ 日銀CBDC運用規則 第14条（流動性供給）に基づくシミュレーション</span>
          </div>
        </div>
      </div>

      {/* Issuance Ledger History */}
      <div className="bg-slate-900 border border-slate-800 rounded p-4">
        <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800">
          <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
            <Coins className="w-4 h-4 text-amber-400" />
            <span>デジタル円 発行・回収履歴台帳</span>
          </h3>
          <span className="text-xs text-slate-400 font-mono-num">
            記帳件数: {issuanceRecords.length}件
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono-num">
            <thead>
              <tr className="text-slate-400 border-b border-slate-800 bg-slate-950/60">
                <th className="py-2.5 px-2.5 font-medium">監査番号</th>
                <th className="py-2.5 px-2.5 font-medium">日時 (JST)</th>
                <th className="py-2.5 px-2.5 font-medium">区分</th>
                <th className="py-2.5 px-2.5 font-medium">対象金融機関</th>
                <th className="py-2.5 px-2.5 font-medium text-right">発行前残高</th>
                <th className="py-2.5 px-2.5 font-medium text-right">執行金額</th>
                <th className="py-2.5 px-2.5 font-medium text-right">発行後残高</th>
                <th className="py-2.5 px-2.5 font-medium">操作者</th>
                <th className="py-2.5 px-2.5 font-medium text-center">状態</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {issuanceRecords.map((rec) => (
                <tr key={rec.id} className="hover:bg-slate-800/40">
                  <td className="py-2.5 px-2.5 font-bold text-slate-200">{rec.auditNumber}</td>
                  <td className="py-2.5 px-2.5 text-slate-400">{rec.timestamp}</td>
                  <td className="py-2.5 px-2.5">
                    <span
                      className={`px-2 py-0.5 rounded text-[11px] font-medium ${
                        rec.type === '新規発行' || rec.type === '追加発行'
                          ? 'bg-amber-950 text-amber-300 border border-amber-800'
                          : 'bg-slate-800 text-slate-300 border border-slate-700'
                      }`}
                    >
                      {rec.type}
                    </span>
                  </td>
                  <td className="py-2.5 px-2.5 font-semibold text-slate-200">
                    {rec.targetBankName}
                  </td>
                  <td className="py-2.5 px-2.5 text-right text-slate-400">
                    ¥{rec.preBalance.toLocaleString()}
                  </td>
                  <td className="py-2.5 px-2.5 text-right font-bold text-slate-100">
                    ¥{rec.amount.toLocaleString()}
                  </td>
                  <td className="py-2.5 px-2.5 text-right font-semibold text-emerald-400">
                    ¥{rec.postBalance.toLocaleString()}
                  </td>
                  <td className="py-2.5 px-2.5 text-slate-400 truncate max-w-[160px]">
                    {rec.operator}
                  </td>
                  <td className="py-2.5 px-2.5 text-center">
                    <StatusBadge status={rec.status} size="sm" />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
