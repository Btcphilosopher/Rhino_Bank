import React, { useState } from 'react';
import { useSimulation } from '../../simulation/SimulationContext';
import { RiskAlert } from '../../types';
import { StatusBadge } from '../common/Badge';
import {
  ShieldAlert,
  AlertTriangle,
  Lock,
  CheckCircle2,
  XCircle,
  Eye,
  FileCheck,
  Search,
  Building,
} from 'lucide-react';

export const RiskManagementView: React.FC = () => {
  const { riskAlerts, resolveRiskAlert } = useSimulation();
  const [selectedAlertId, setSelectedAlertId] = useState<string>(
    riskAlerts[0]?.id || ''
  );
  const [filterStatus, setFilterStatus] = useState<string>('all');

  const selectedAlert =
    riskAlerts.find((a) => a.id === selectedAlertId) || riskAlerts[0];

  const filteredAlerts = riskAlerts.filter((a) => {
    if (filterStatus === 'all') return true;
    return a.status === filterStatus;
  });

  const handleAction = (alertId: string, action: RiskAlert['status']) => {
    resolveRiskAlert(alertId, action);
  };

  return (
    <div className="space-y-4 p-5 max-w-[1600px] mx-auto font-mono-num">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-rose-400" />
            <h2 className="text-base font-bold text-slate-100">
              AML / CFT 異常検知・リスク統括管理ワークステーション
            </h2>
            <span className="text-xs bg-rose-950 text-rose-300 border border-rose-800 px-2 py-0.5 rounded font-bold">
              AI異常スコアリング稼働中
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            二重譲渡試行・短時間多頻度高額送金・制裁対象ブラックリスト照合および口座即時凍結処理
          </p>
        </div>

        {/* Action filter */}
        <div className="flex items-center gap-1.5 text-xs">
          <span className="text-slate-400">ステータス:</span>
          {['all', '確認待ち', '調査中', '承認済', '凍結措置', '誤検知解除'].map((st) => (
            <button
              key={st}
              onClick={() => setFilterStatus(st)}
              className={`px-2.5 py-1 rounded border transition ${
                filterStatus === st
                  ? 'bg-slate-700 text-white border-slate-500 font-bold'
                  : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
              }`}
            >
              {st === 'all' ? '全件' : st}
            </button>
          ))}
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left 7 cols: Alerts List */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded p-4">
          <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800">
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <span>検知アラート一覧</span>
            </h3>
            <span className="text-xs text-slate-400">
              未解決: {riskAlerts.filter((a) => a.status === '確認待ち').length} 件
            </span>
          </div>

          <div className="space-y-2.5 max-h-[600px] overflow-y-auto pr-1">
            {filteredAlerts.map((alert) => {
              const isSelected = selectedAlert?.id === alert.id;
              return (
                <div
                  key={alert.id}
                  onClick={() => setSelectedAlertId(alert.id)}
                  className={`p-3 rounded border transition cursor-pointer ${
                    isSelected
                      ? 'bg-slate-800 border-rose-500 shadow-sm'
                      : 'bg-slate-950/70 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <div className="flex items-center gap-2 min-w-0">
                      <span
                        className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${
                          alert.riskLevel === '緊急' || alert.riskLevel === '高'
                            ? 'bg-rose-950 text-rose-300 border border-rose-800'
                            : 'bg-amber-950 text-amber-300 border border-amber-800'
                        }`}
                      >
                        リスク度: {alert.riskLevel} (スコア: {alert.score})
                      </span>
                      <span className="font-bold text-xs text-slate-100 truncate">
                        {alert.targetEntity}
                      </span>
                    </div>
                    <StatusBadge status={alert.status as any} size="sm" />
                  </div>

                  <p className="text-[11px] text-slate-400 mb-1.5 line-clamp-1">{alert.reason}</p>

                  <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-800/60">
                    <span className="text-slate-500 text-[10px]">
                      {alert.sourceBank} | {alert.timestamp}
                    </span>
                    <span className="font-bold text-rose-300">
                      ¥{alert.amount.toLocaleString()}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right 5 cols: Alert Resolution Detail Panel */}
        {selectedAlert && (
          <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded p-4 flex flex-col justify-between">
            <div className="space-y-3.5">
              <div className="pb-3 border-b border-slate-800 flex items-center justify-between">
                <div>
                  <span
                    className={`text-xs px-2 py-0.5 rounded font-bold ${
                      selectedAlert.riskLevel === '緊急' || selectedAlert.riskLevel === '高'
                        ? 'bg-rose-950 text-rose-300 border border-rose-800'
                        : 'bg-amber-950 text-amber-300 border border-amber-800'
                    }`}
                  >
                    リスク度: {selectedAlert.riskLevel}
                  </span>
                  <h3 className="text-base font-bold text-slate-100 mt-1">
                    {selectedAlert.targetEntity}
                  </h3>
                </div>
                <StatusBadge status={selectedAlert.status as any} size="sm" />
              </div>

              <div className="space-y-2 text-xs">
                <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-1">
                  <div className="text-[10px] text-slate-400">検知理由・違反ルール</div>
                  <div className="text-slate-200 font-semibold">{selectedAlert.reason}</div>
                </div>

                <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-1.5">
                  <div className="flex justify-between">
                    <span className="text-slate-400">対象取引ID:</span>
                    <span className="text-slate-200 font-bold">{selectedAlert.txnId}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">所属取扱銀行:</span>
                    <span className="text-slate-200 font-bold">{selectedAlert.sourceBank}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">対象金額:</span>
                    <span className="text-slate-100 font-bold">
                      ¥{selectedAlert.amount.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">AI リスクスコア:</span>
                    <span className="text-rose-400 font-bold">{selectedAlert.score} / 100</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">検知日時:</span>
                    <span className="text-slate-400">{selectedAlert.timestamp}</span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 space-y-2">
                <button
                  onClick={() => handleAction(selectedAlert.id, '凍結措置')}
                  className="w-full py-2 px-3 bg-rose-950 hover:bg-rose-900 text-rose-200 border border-rose-800 rounded text-xs font-bold transition flex items-center justify-center gap-1.5"
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>対象口座・取引の即時凍結執行 (Freeze)</span>
                </button>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => handleAction(selectedAlert.id, '承認済')}
                    className="py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded text-xs font-semibold flex items-center justify-center gap-1"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>正当取引として承認</span>
                  </button>

                  <button
                    onClick={() => handleAction(selectedAlert.id, '誤検知解除')}
                    className="py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded text-xs font-semibold flex items-center justify-center gap-1"
                  >
                    <XCircle className="w-3.5 h-3.5 text-slate-400" />
                    <span>誤検知として解除</span>
                  </button>
                </div>
              </div>
            </div>

            <div className="pt-3 mt-3 border-t border-slate-800 text-[11px] text-slate-400">
              <span>※ 処置内容は金融庁AMLガイドラインおよび不変監査ログに即時登録されます</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
