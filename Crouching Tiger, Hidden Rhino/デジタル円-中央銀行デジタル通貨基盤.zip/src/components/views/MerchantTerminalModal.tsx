import React, { useState } from 'react';
import { useSimulation } from '../../simulation/SimulationContext';
import {
  Store,
  QrCode,
  Smartphone,
  CheckCircle2,
  X,
  CreditCard,
  Layers,
  RotateCcw,
} from 'lucide-react';

interface MerchantTerminalModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MerchantTerminalModal: React.FC<MerchantTerminalModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { wallets, executePayment, transactions } = useSimulation();

  const merchantWallet =
    wallets.find((w) => w.category === '加盟店ウォレット') || wallets[3] || wallets[0];
  const citizenWallet =
    wallets.find((w) => w.category === '個人ウォレット') || wallets[0];

  const [billAmount, setBillAmount] = useState<number>(3400);
  const [billItem, setBillItem] = useState<string>('カフェ・ランチセット (2名分)');
  const [isWaitingPayment, setIsWaitingPayment] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState<boolean>(false);
  const [lastTxnId, setLastTxnId] = useState<string>('');

  if (!isOpen || !merchantWallet) return null;

  const handleCreateCharge = () => {
    setIsWaitingPayment(true);
    setPaymentSuccess(false);
  };

  const handleSimulateCustomerTap = async () => {
    const res = await executePayment({
      sourceWalletId: citizenWallet.id,
      destWalletId: merchantWallet.id,
      amount: billAmount,
      paymentMethod: 'NFC',
      purpose: billItem,
    });

    if (res.success && res.transaction) {
      setPaymentSuccess(true);
      setIsWaitingPayment(false);
      setLastTxnId(res.transaction.id);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-xs flex items-center justify-center z-50 p-4 font-mono-num">
      <div className="bg-slate-900 border border-slate-700 rounded-xl max-w-md w-full shadow-2xl overflow-hidden flex flex-col text-slate-100">
        {/* Terminal Header */}
        <div className="bg-slate-950 p-3.5 border-b border-slate-800 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-slate-300">
            <Store className="w-4 h-4 text-amber-400" />
            <span className="font-bold">{merchantWallet.name} クラウドPOS端末</span>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Terminal Screen Area */}
        <div className="p-5 space-y-4">
          {/* Merchant Balance overview */}
          <div className="bg-slate-950 p-3 rounded border border-slate-800 flex justify-between items-center text-xs">
            <div>
              <div className="text-[10px] text-slate-500">店舗売上プール残高 (CBDC即時着金)</div>
              <div className="text-base font-bold text-slate-100 mt-0.5">
                ¥{merchantWallet.balance.toLocaleString()}
              </div>
            </div>
            <span className="px-2 py-0.5 bg-emerald-950 text-emerald-300 border border-emerald-800 rounded text-[10px] font-bold">
              RTGS即時確定
            </span>
          </div>

          {/* Payment state machine in POS */}
          {!isWaitingPayment && !paymentSuccess && (
            <div className="space-y-3 text-xs">
              <div className="text-xs font-bold text-slate-300">新規会計・請求金額入力</div>
              <div>
                <label className="block text-slate-400 text-[11px] mb-1">お会計金額 (円)</label>
                <div className="relative">
                  <span className="absolute left-3 top-2 text-slate-400">¥</span>
                  <input
                    type="number"
                    value={billAmount}
                    onChange={(e) => setBillAmount(Number(e.target.value))}
                    min={1}
                    className="w-full bg-slate-950 border border-slate-700 rounded pl-7 pr-3 py-2 text-slate-100 font-bold focus:outline-none focus:border-sky-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 text-[11px] mb-1">商品・サービス名</label>
                <input
                  type="text"
                  value={billItem}
                  onChange={(e) => setBillItem(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-2 text-slate-100 focus:outline-none focus:border-sky-500"
                />
              </div>

              <button
                onClick={handleCreateCharge}
                className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-600 rounded font-bold transition flex items-center justify-center gap-2 shadow-sm"
              >
                <QrCode className="w-4 h-4 text-sky-400" />
                <span>デジタル円 請求コード生成 (NFC / QR待受)</span>
              </button>
            </div>
          )}

          {isWaitingPayment && (
            <div className="text-center space-y-3 p-3 bg-slate-950 rounded border border-slate-800 text-xs">
              <div className="text-sm font-bold text-slate-200">
                お支払い待ち: <span className="text-sky-400">¥{billAmount.toLocaleString()}</span>
              </div>
              <p className="text-[11px] text-slate-400">{billItem}</p>

              <div className="p-3 bg-white rounded-lg shadow-inner inline-block my-2">
                <QrCode className="w-32 h-32 text-slate-900" />
              </div>

              <div className="text-[10px] text-slate-400 animate-pulse">
                ● NFCタッチまたはQRコードスキャンをお待ちしています...
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  onClick={() => setIsWaitingPayment(false)}
                  className="w-1/2 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs"
                >
                  キャンセル
                </button>
                <button
                  onClick={handleSimulateCustomerTap}
                  className="w-1/2 py-2 bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-600 rounded text-xs font-bold flex items-center justify-center gap-1 shadow-xs"
                >
                  <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
                  <span>端末タッチ決済執行</span>
                </button>
              </div>
            </div>
          )}

          {paymentSuccess && (
            <div className="p-4 bg-emerald-950/60 border border-emerald-800 rounded text-center space-y-2 text-xs">
              <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
              <div className="text-base font-bold text-emerald-200">決済完了（即時着金確定）</div>
              <div className="text-xl font-bold text-white">¥{billAmount.toLocaleString()}</div>
              <div className="text-[11px] text-slate-300">{billItem}</div>
              <div className="text-[10px] text-slate-400 font-mono">取引ID: {lastTxnId}</div>

              <button
                onClick={() => setPaymentSuccess(false)}
                className="mt-3 px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded text-xs font-bold"
              >
                次の会計へ
              </button>
            </div>
          )}
        </div>

        {/* Terminal Footer */}
        <div className="p-2.5 bg-slate-950 border-t border-slate-800 text-center text-[10px] text-slate-500">
          加盟店識別子: POS-TYO-9912 | 日銀確定即時決済対応端末
        </div>
      </div>
    </div>
  );
};
