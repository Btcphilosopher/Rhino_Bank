import React, { useState } from 'react';
import { useSimulation } from '../../simulation/SimulationContext';
import { StatusBadge } from '../common/Badge';
import {
  Droplets,
  AlertTriangle,
  ShieldCheck,
  TrendingDown,
  ArrowUpRight,
  PlusCircle,
  Building2,
  RefreshCw,
} from 'lucide-react';

export const LiquidityManagementView: React.FC = () => {
  const { institutions, issueDigitalYen } = useSimulation();

  const [stressTested, setStressTested] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  const handleInjectLiquidity = (bankId: string) => {
    const bank = institutions.find((i) => i.id === bankId);
    if (!bank) return;

    issueDigitalYen({
      type: '追加発行',
      targetBankId: bank.id,
      amount: 50000000000, // 500億円
      reason: '日中流動性緊急バッファー供給（担保適格国債引当）',
      remarks: '日銀特融枠・緊急流動性ファシリティ執行',
      operator: '日銀 業務局 流動性管理課 (OP-301)',
    });

    setFeedback(`【流動性供給完了】${bank.name} に対し ¥500億円 の日中流動性を緊急供給しました。`);
  };

  return (
    <div className="space-y-4 p-5 max-w-[1600px] mx-auto font-mono-num">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <Droplets className="w-5 h-5 text-sky-400" />
            <h2 className="text-base font-bold text-slate-100">中央銀行 流動性・担保管理センター</h2>
            <span className="text-xs bg-slate-800 text-slate-300 border border-slate-700 px-2 py-0.5 rounded">
              リアルタイム LCR / Intraday Buffer
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            加盟各行の所要準備預金・日中決済流動性バッファー・担保適格資産(JGB)のリアルタイム監視およびストレステスト
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setStressTested(!stressTested)}
            className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded text-xs font-bold flex items-center gap-1.5 transition"
          >
            <TrendingDown className="w-3.5 h-3.5 text-amber-400" />
            <span>{stressTested ? 'ストレステスト解除' : '大規模決済集中 ストレステスト実行'}</span>
          </button>
        </div>
      </div>

      {feedback && (
        <div className="p-3 bg-emerald-950 border border-emerald-800 text-emerald-300 text-xs rounded flex items-center justify-between">
          <span>{feedback}</span>
          <button onClick={() => setFeedback(null)} className="text-slate-400 hover:text-white">✕</button>
        </div>
      )}

      {/* Intraday Warning Banner */}
      <div className="bg-amber-950/40 border border-amber-800/80 p-3.5 rounded flex items-start gap-3 text-xs">
        <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <div className="font-bold text-amber-200">
            日中流動性アラート: 中央東日本銀行 (コード: 0002)
          </div>
          <p className="text-slate-300">
            日中流動性残高が基準閾値 (¥1,000億円) を下回り、¥8,420億円 (84.2%) となっています。決済ピーク時間帯(14:00〜15:00)に向けた国債担保枠の追加差入れ、または中央銀行流動性供給ファシリティの利用を推奨します。
          </p>
        </div>
      </div>

      {/* Institutions Liquidity Table */}
      <div className="bg-slate-900 border border-slate-800 rounded p-4">
        <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800">
          <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
            <Building2 className="w-4 h-4 text-emerald-400" />
            <span>金融機関別 流動性充足状況 & 担保引当マトリクス</span>
          </h3>
          <span className="text-xs text-slate-400">最低流動性要求水準: 100.0%</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="text-slate-400 border-b border-slate-800 bg-slate-950/60">
                <th className="py-2.5 px-2.5 font-medium">金融機関名</th>
                <th className="py-2.5 px-2.5 font-medium text-right">所要準備額 (基準)</th>
                <th className="py-2.5 px-2.5 font-medium text-right">現在流動性残高</th>
                <th className="py-2.5 px-2.5 font-medium text-right">充足率 (LCR)</th>
                <th className="py-2.5 px-2.5 font-medium">担保適格国債</th>
                <th className="py-2.5 px-2.5 font-medium text-center">判定</th>
                <th className="py-2.5 px-2.5 font-medium text-center">緊急措置</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {institutions.map((inst) => {
                const ratio = stressTested ? inst.liquidityRatio * 0.72 : inst.liquidityRatio;
                const isAlert = ratio < 100;

                return (
                  <tr key={inst.id} className="hover:bg-slate-800/40">
                    <td className="py-2.5 px-2.5 font-bold text-slate-200">
                      {inst.name}
                      <span className="text-[10px] text-slate-500 ml-1.5 font-normal">
                        ({inst.code})
                      </span>
                    </td>
                    <td className="py-2.5 px-2.5 text-right text-slate-400">
                      ¥{inst.requiredReserve.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-2.5 text-right font-bold text-slate-100">
                      ¥{inst.liquidityReserve.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-2.5 text-right">
                      <span
                        className={`font-bold ${
                          isAlert ? 'text-amber-400' : 'text-emerald-400'
                        }`}
                      >
                        {ratio.toFixed(1)}%
                      </span>
                    </td>
                    <td className="py-2.5 px-2.5 text-slate-300">
                      JGB 担保差入済 (100%)
                    </td>
                    <td className="py-2.5 px-2.5 text-center">
                      {isAlert ? (
                        <span className="px-2 py-0.5 bg-amber-950 text-amber-300 border border-amber-800 rounded font-bold text-[10px]">
                          注意 (警戒域)
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 bg-emerald-950 text-emerald-300 border border-emerald-800 rounded font-bold text-[10px]">
                          適正 (安全)
                        </span>
                      )}
                    </td>
                    <td className="py-2.5 px-2.5 text-center">
                      <button
                        onClick={() => handleInjectLiquidity(inst.id)}
                        className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-sky-300 border border-slate-700 rounded text-[11px] font-bold transition flex items-center gap-1 mx-auto"
                      >
                        <PlusCircle className="w-3 h-3" />
                        <span>流動性供給</span>
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
