import React from 'react';
import { useSimulation } from '../../simulation/SimulationContext';
import { MetricCard } from '../common/MetricCard';
import {
  Activity,
  Sliders,
  Play,
  RotateCcw,
  TrendingUp,
  AlertTriangle,
  Layers,
  BarChart2,
} from 'lucide-react';

export const EconomicSimulationView: React.FC = () => {
  const { macroModel, updateMacroeconomicParams, setSimulationSpeed } = useSimulation();

  return (
    <div className="space-y-4 p-5 max-w-[1600px] mx-auto font-mono-num">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-sky-400" />
            <h2 className="text-base font-bold text-slate-100">
              デジタル円 マクロ経済シミュレーション サンドボックス
            </h2>
            <span className="text-xs bg-slate-800 text-slate-300 border border-slate-700 px-2 py-0.5 rounded">
              リアルタイム動的計量経済モデル
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            通貨政策パラメータ（流通量・普及速度・現金代替率・預金シフト）の変動による銀行流動性・信用創造への影響予測
          </p>
        </div>

        {/* Speed Controls */}
        <div className="flex items-center gap-1.5 text-xs bg-slate-950 p-1 rounded border border-slate-800">
          <span className="text-slate-400 px-2">実行速度:</span>
          {([1, 10, 100] as const).map((speed) => (
            <button
              key={speed}
              onClick={() => setSimulationSpeed(speed)}
              className={`px-3 py-1 rounded transition font-bold ${
                macroModel.simulationSpeed === speed
                  ? 'bg-sky-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {speed}x
            </button>
          ))}
        </div>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <MetricCard
          title="中核決済レイテンシ"
          value={`${macroModel.settlementVelocity} ms`}
          subLabel="即時確定ファイナリティ"
          subValue="超低遅延RTGS"
          change="目標達成"
          changeType="positive"
        />
        <MetricCard
          title="国民・企業 普及率"
          value={`${macroModel.walletAdoptionRate.toFixed(1)}%`}
          subLabel="普及シナリオ"
          subValue="第3フェーズ到達"
          change="急拡大期"
          changeType="positive"
        />
        <MetricCard
          title="現金代替率 (M0代替)"
          value={`${macroModel.cashSubstitutionRate.toFixed(1)}%`}
          subLabel="造幣・輸送コスト削減"
          subValue="年間約1,800億円削減"
          change="高効果"
          changeType="positive"
        />
        <MetricCard
          title="民間銀行預金シフト率"
          value={`${macroModel.bankDepositMigrationRate.toFixed(1)}%`}
          subLabel="流動性リスク監視"
          subValue="許容上限(15%)以下"
          change="安全水準"
          changeType="positive"
        />
      </div>

      {/* Interactive Parameter Sliders */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left 6 cols: Parameter Sliders */}
        <div className="lg:col-span-6 bg-slate-900 border border-slate-800 rounded p-5 space-y-4">
          <h3 className="text-sm font-bold text-slate-100 pb-2 border-b border-slate-800 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-sky-400" />
            <span>政策・市場シナリオ パラメータ調整</span>
          </h3>

          <div className="space-y-4 text-xs">
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>国民・企業 普及率 (Wallet Adoption Rate)</span>
                <span className="font-bold text-sky-400">
                  {macroModel.walletAdoptionRate.toFixed(1)}%
                </span>
              </div>
              <input
                type="range"
                min="5"
                max="98"
                step="0.5"
                value={macroModel.walletAdoptionRate}
                onChange={(e) =>
                  updateMacroeconomicParams({ walletAdoptionRate: Number(e.target.value) })
                }
                className="w-full accent-sky-500 bg-slate-950 rounded cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>現金代替率 (Cash Substitution Rate)</span>
                <span className="font-bold text-emerald-400">
                  {macroModel.cashSubstitutionRate.toFixed(1)}%
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="90"
                step="0.5"
                value={macroModel.cashSubstitutionRate}
                onChange={(e) =>
                  updateMacroeconomicParams({ cashSubstitutionRate: Number(e.target.value) })
                }
                className="w-full accent-emerald-500 bg-slate-950 rounded cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>銀行預金シフト率 (Deposit Migration Rate)</span>
                <span className="font-bold text-amber-400">
                  {macroModel.bankDepositMigrationRate.toFixed(1)}%
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="30"
                step="0.1"
                value={macroModel.bankDepositMigrationRate}
                onChange={(e) =>
                  updateMacroeconomicParams({ bankDepositMigrationRate: Number(e.target.value) })
                }
                className="w-full accent-amber-500 bg-slate-950 rounded cursor-pointer"
              />
              <span className="text-[10px] text-slate-500 mt-0.5 block">
                ※ 15%を超えると民間銀行の貸出原資逼迫の警戒シグナルが点灯します。
              </span>
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>秒間取引頻度 (Peak Frequency)</span>
                <span className="font-bold text-purple-400">
                  {macroModel.txFrequency.toLocaleString()} TPS
                </span>
              </div>
              <input
                type="range"
                min="500"
                max="30000"
                step="100"
                value={macroModel.txFrequency}
                onChange={(e) =>
                  updateMacroeconomicParams({ txFrequency: Number(e.target.value) })
                }
                className="w-full accent-purple-500 bg-slate-950 rounded cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Right 6 cols: Scenario Evaluation Output */}
        <div className="lg:col-span-6 bg-slate-900 border border-slate-800 rounded p-5 flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-100 pb-2 border-b border-slate-800 flex items-center gap-2">
              <BarChart2 className="w-4 h-4 text-emerald-400" />
              <span>マクロ経済 総合影響評価判定</span>
            </h3>

            <div className="space-y-3 mt-3 text-xs">
              <div className="p-3 bg-slate-950 rounded border border-slate-800">
                <div className="text-slate-400 text-[11px] mb-1">金融仲介機能（信用創造）への影響</div>
                <div className="text-slate-200 font-semibold">
                  {macroModel.bankDepositMigrationRate > 15 ? (
                    <span className="text-rose-400">
                      ⚠️ 預金流出警戒域: 民間銀行の貸出金利上昇および流動性補給ファシリティ発動の必要性あり
                    </span>
                  ) : (
                    <span className="text-emerald-400">
                      ● 安定維持: 保有上限（¥500万円/個人）規制により、ディスインテルメディエーションは極小化されています
                    </span>
                  )}
                </div>
              </div>

              <div className="p-3 bg-slate-950 rounded border border-slate-800">
                <div className="text-slate-400 text-[11px] mb-1">社会的決済コスト削減効果</div>
                <div className="text-slate-200 font-semibold">
                  現金取扱・ATM維持費・現金輸送コストを年間{' '}
                  <span className="text-sky-400 font-bold">
                    約{(macroModel.cashSubstitutionRate * 42).toFixed(0)} 億円
                  </span>{' '}
                  削減見込み
                </div>
              </div>

              <div className="p-3 bg-slate-950 rounded border border-slate-800">
                <div className="text-slate-400 text-[11px] mb-1">金融包摂・デジタル化進展度</div>
                <div className="text-slate-200 font-semibold">
                  オフライン決済対応により、災害時・無電化地域でも99.99%の決済継続性を担保
                </div>
              </div>
            </div>
          </div>

          <div className="pt-3 mt-3 border-t border-slate-800 text-[11px] text-slate-400">
            <span>※ 日銀金融研究所 CBDCワーキングペーパー計量モデル連動</span>
          </div>
        </div>
      </div>
    </div>
  );
};
