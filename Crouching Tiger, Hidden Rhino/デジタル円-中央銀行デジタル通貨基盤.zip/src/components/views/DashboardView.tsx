import React from 'react';
import { useSimulation } from '../../simulation/SimulationContext';
import { MetricCard } from '../common/MetricCard';
import { StatusBadge } from '../common/Badge';
import {
  TrendingUp,
  CreditCard,
  Building2,
  Layers,
  ArrowUpRight,
  ShieldCheck,
  AlertTriangle,
  RefreshCw,
  Wallet as WalletIcon,
  CheckCircle2,
  Clock,
} from 'lucide-react';
import { NavigationItemKey } from '../../types';

interface DashboardViewProps {
  onNavigate: (view: NavigationItemKey) => void;
  onOpenConsumerWallet: () => void;
  onOpenMerchantTerminal: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  onNavigate,
  onOpenConsumerWallet,
  onOpenMerchantTerminal,
}) => {
  const {
    totalCirculation,
    totalWalletsCount,
    activeWalletsCount,
    todayTxCount,
    todayTxAmount,
    realtimeSettlementVolume,
    clearingProcessedAmount,
    offlineTxCount,
    interbankTxCount,
    abnormalTxCount,
    institutions,
    transactions,
    clearingQueue,
    processAllClearing,
  } = useSimulation();

  const pendingClearing = clearingQueue.filter((q) => q.status !== '清算済');

  return (
    <div className="space-y-4 p-5 max-w-[1600px] mx-auto">
      {/* Top Banner: Operations Status */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-slate-100">デジタル円 運用状況</h2>
            <span className="text-[11px] bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded font-mono-num font-medium">
              ● RTGS / DNS 稼働中
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            全国デジタル円中核基盤・金融機関接続網・即時清算ネットワークのリアルタイム統括モニタ
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('issuance')}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded text-xs font-medium flex items-center gap-1.5 transition"
          >
            <ArrowUpRight className="w-3.5 h-3.5 text-slate-400" />
            <span>発行・回収管理</span>
          </button>
          <button
            onClick={() => onNavigate('clearing_settlement')}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded text-xs font-medium flex items-center gap-1.5 transition"
          >
            <Layers className="w-3.5 h-3.5 text-slate-400" />
            <span>清算処理</span>
          </button>
          <button
            onClick={onOpenConsumerWallet}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-sky-300 border border-slate-700 rounded text-xs font-medium flex items-center gap-1.5 transition"
          >
            <WalletIcon className="w-3.5 h-3.5 text-sky-400" />
            <span>端末決済テスト</span>
          </button>
        </div>
      </div>

      {/* Primary 12 Core Institutional Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
        <MetricCard
          id="metric-total-circulation"
          title="デジタル円流通残高"
          value={`¥${totalCirculation.toLocaleString()}`}
          subLabel="法定準備対比"
          subValue="100.0% 保全 (日銀当預)"
          change="+¥3000億 (本日)"
          changeType="positive"
          statusIndicator="normal"
        />

        <MetricCard
          id="metric-wallets-total"
          title="ウォレット総数"
          value={`${totalWalletsCount.toLocaleString()} 口座`}
          subLabel="個人 / 法人比"
          subValue="84.2% / 15.8%"
          change="+18,490 (週次)"
          changeType="positive"
          statusIndicator="normal"
        />

        <MetricCard
          id="metric-active-wallets"
          title="アクティブウォレット"
          value={`${activeWalletsCount.toLocaleString()} 口座`}
          subLabel="月間稼働率"
          subValue="68.4% (高頻度利用)"
          change="92.1% 稼働"
          changeType="positive"
          statusIndicator="normal"
        />

        <MetricCard
          id="metric-today-tx-count"
          title="本日の取引件数"
          value={`${todayTxCount.toLocaleString()} 件`}
          subLabel="秒間ピーク処理"
          subValue="14,200 TPS"
          change="平準比 +4.2%"
          changeType="neutral"
          statusIndicator="normal"
        />

        <MetricCard
          id="metric-today-tx-amount"
          title="本日の取引金額"
          value={`¥${todayTxAmount.toLocaleString()}`}
          subLabel="日中決済平均額"
          subValue="¥28,400 / 件"
          change="順調"
          changeType="positive"
          statusIndicator="normal"
        />

        <MetricCard
          id="metric-realtime-settlement"
          title="リアルタイム決済額"
          value={`¥${realtimeSettlementVolume.toLocaleString()}`}
          subLabel="平均処理時間"
          subValue="14ms (即時確定)"
          change="RTGS 100%"
          changeType="positive"
          statusIndicator="normal"
        />

        <MetricCard
          id="metric-clearing-amount"
          title="清算処理額"
          value={`¥${clearingProcessedAmount.toLocaleString()}`}
          subLabel="次回相殺予定"
          subValue="17:00 DNS清算"
          change="差額相殺 98.4%"
          changeType="positive"
          statusIndicator="normal"
        />

        <MetricCard
          id="metric-member-institutions"
          title="加盟金融機関数"
          value={`${institutions.length} 機関`}
          subLabel="API接続率"
          subValue="100% (全系オンライン)"
          change="正常"
          changeType="positive"
          statusIndicator="normal"
        />

        <MetricCard
          id="metric-merchant-count"
          title="加盟店数"
          value="828,000 店舗"
          subLabel="NFC / QR対応"
          subValue="全国普及率 72.4%"
          change="+4,100 (月次)"
          changeType="positive"
          statusIndicator="normal"
        />

        <MetricCard
          id="metric-offline-tx-count"
          title="オフライン決済件数"
          value={`${offlineTxCount.toLocaleString()} 件`}
          subLabel="セキュアSE照合"
          subValue="未同期: 0件"
          change="全件同期済"
          changeType="positive"
          statusIndicator="normal"
        />

        <MetricCard
          id="metric-interbank-count"
          title="銀行間決済件数"
          value={`${interbankTxCount.toLocaleString()} 件`}
          subLabel="中央銀行当預清算"
          subValue="待ち時間: 0.2秒"
          change="滞留なし"
          changeType="positive"
          statusIndicator="normal"
        />

        <MetricCard
          id="metric-abnormal-count"
          title="異常取引件数"
          value={`${abnormalTxCount} 件`}
          subLabel="リスク監視中"
          subValue="AMLルール判定"
          change={abnormalTxCount > 0 ? '要対応アラート有' : '全件正常'}
          changeType={abnormalTxCount > 0 ? 'alert' : 'positive'}
          statusIndicator={abnormalTxCount > 0 ? 'caution' : 'normal'}
        />
      </div>

      {/* Middle Section: Live Interbank Clearing Pipeline & Institutional Resiliency */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left 2 Cols: Real-time Clearing & Settlement Queue */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-sky-400" />
                <h3 className="text-sm font-bold text-slate-100">
                  即時グロス決済 (RTGS) / 時点ネット清算 (DNS) キュー
                </h3>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-400 font-mono-num">
                  待機中: {pendingClearing.length}件
                </span>
                {pendingClearing.length > 0 && (
                  <button
                    id="btn-quick-clear-all"
                    onClick={processAllClearing}
                    className="px-2.5 py-1 text-xs font-medium bg-sky-900/60 hover:bg-sky-800 text-sky-200 border border-sky-700 rounded transition font-mono-num flex items-center gap-1"
                  >
                    <RefreshCw className="w-3 h-3" />
                    一括清算実行
                  </button>
                )}
              </div>
            </div>

            {/* Pipeline Visual Diagram */}
            <div className="grid grid-cols-6 gap-1 bg-slate-950 p-2.5 rounded border border-slate-800 text-center text-xs mb-3 font-mono-num">
              <div className="bg-slate-900/80 p-2 rounded border border-slate-800">
                <div className="text-[10px] text-slate-500">STEP 1</div>
                <div className="font-semibold text-slate-300">取引受付</div>
                <div className="text-[10px] text-emerald-400 mt-1">● 正常</div>
              </div>
              <div className="bg-slate-900/80 p-2 rounded border border-slate-800">
                <div className="text-[10px] text-slate-500">STEP 2</div>
                <div className="font-semibold text-slate-300">署名検証</div>
                <div className="text-[10px] text-emerald-400 mt-1">● ECDSA</div>
              </div>
              <div className="bg-slate-900/80 p-2 rounded border border-slate-800">
                <div className="text-[10px] text-slate-500">STEP 3</div>
                <div className="font-semibold text-slate-300">残高引当</div>
                <div className="text-[10px] text-emerald-400 mt-1">● 即時照会</div>
              </div>
              <div className="bg-slate-900/80 p-2 rounded border border-slate-800">
                <div className="text-[10px] text-slate-500">STEP 4</div>
                <div className="font-semibold text-slate-300">リスク審査</div>
                <div className="text-[10px] text-sky-400 mt-1">● AML合致</div>
              </div>
              <div className="bg-slate-900/80 p-2 rounded border border-slate-800">
                <div className="text-[10px] text-slate-500">STEP 5</div>
                <div className="font-semibold text-slate-300">銀行間清算</div>
                <div className="text-[10px] text-emerald-400 mt-1">● 当預相殺</div>
              </div>
              <div className="bg-slate-900/80 p-2 rounded border border-slate-800">
                <div className="text-[10px] text-slate-500">STEP 6</div>
                <div className="font-semibold text-slate-300">台帳更新</div>
                <div className="text-[10px] text-emerald-400 mt-1">● 不変確定</div>
              </div>
            </div>

            {/* Queue Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono-num">
                <thead>
                  <tr className="text-slate-400 border-b border-slate-800 bg-slate-950/60">
                    <th className="py-2 px-2.5 font-medium">取引番号</th>
                    <th className="py-2 px-2.5 font-medium">送金元銀行</th>
                    <th className="py-2 px-2.5 font-medium">受取先銀行</th>
                    <th className="py-2 px-2.5 font-medium text-right">決済金額</th>
                    <th className="py-2 px-2.5 font-medium">受付時刻</th>
                    <th className="py-2 px-2.5 font-medium">清算モード</th>
                    <th className="py-2 px-2.5 font-medium text-center">状態</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {clearingQueue.slice(0, 5).map((item) => (
                    <tr key={item.id} className="hover:bg-slate-800/40">
                      <td className="py-2 px-2.5 font-semibold text-slate-200">{item.txnId}</td>
                      <td className="py-2 px-2.5 text-slate-300">{item.sourceBank}</td>
                      <td className="py-2 px-2.5 text-slate-300">{item.destBank}</td>
                      <td className="py-2 px-2.5 font-bold text-right text-slate-100">
                        ¥{item.amount.toLocaleString()}
                      </td>
                      <td className="py-2 px-2.5 text-slate-400">{item.queuedAt}</td>
                      <td className="py-2 px-2.5 text-slate-400 text-[11px]">{item.settlementMode}</td>
                      <td className="py-2 px-2.5 text-center">
                        <StatusBadge status={item.status} size="sm" />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="pt-3 mt-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
            <span>※ 全件即時確定ファイナリティ（日銀当座預金決済連動）</span>
            <button
              onClick={() => onNavigate('clearing_settlement')}
              className="text-sky-400 hover:text-sky-300 flex items-center gap-1 font-medium"
            >
              清算センター詳細へ →
            </button>
          </div>
        </div>

        {/* Right 1 Col: Financial Institutions Reserve & Liquidity State */}
        <div className="bg-slate-900 border border-slate-800 rounded p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Building2 className="w-4 h-4 text-emerald-400" />
                <h3 className="text-sm font-bold text-slate-100">主要加盟金融機関 状況</h3>
              </div>
              <button
                onClick={() => onNavigate('institutions')}
                className="text-xs text-sky-400 hover:text-sky-300 font-medium"
              >
                全一覧 →
              </button>
            </div>

            <div className="space-y-2.5 font-mono-num">
              {institutions.slice(0, 5).map((inst) => (
                <div
                  key={inst.id}
                  className="p-2.5 bg-slate-950/70 border border-slate-800 rounded hover:border-slate-700 transition"
                >
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="font-bold text-slate-200">{inst.name}</span>
                    <StatusBadge status={inst.apiStatus} size="sm" />
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span>CBDC保有:</span>
                    <span className="text-slate-200 font-semibold">
                      ¥{inst.cbdcBalance.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-400 mt-0.5">
                    <span>流動性比率:</span>
                    <span
                      className={`font-semibold ${
                        inst.liquidityRatio < 100 ? 'text-amber-400' : 'text-emerald-400'
                      }`}
                    >
                      {inst.liquidityRatio.toFixed(1)}% (要求: 100%)
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-3 mt-3 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
            <span className="flex items-center gap-1 text-emerald-400">
              <CheckCircle2 className="w-3.5 h-3.5" /> 全金融機関API接続正常
            </span>
            <button
              onClick={() => onNavigate('liquidity_management')}
              className="text-slate-300 hover:text-white"
            >
              流動性管理 →
            </button>
          </div>
        </div>
      </div>

      {/* Bottom Section: Recent Simulated Transactions Ledger */}
      <div className="bg-slate-900 border border-slate-800 rounded p-4">
        <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-slate-400" />
            <h3 className="text-sm font-bold text-slate-100">最新CBDC取引トランザクション（模擬台帳抜粋）</h3>
          </div>
          <button
            onClick={() => onNavigate('ledger')}
            className="text-xs text-sky-400 hover:text-sky-300 font-medium"
          >
            中央台帳全件を表示 →
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono-num">
            <thead>
              <tr className="text-slate-400 border-b border-slate-800 bg-slate-950/60">
                <th className="py-2 px-2.5 font-medium">台帳番号</th>
                <th className="py-2 px-2.5 font-medium">取引番号</th>
                <th className="py-2 px-2.5 font-medium">日時 (JST)</th>
                <th className="py-2 px-2.5 font-medium">送金元 (口座)</th>
                <th className="py-2 px-2.5 font-medium">送金先 (口座)</th>
                <th className="py-2 px-2.5 font-medium">決済方法</th>
                <th className="py-2 px-2.5 font-medium">取引目的</th>
                <th className="py-2 px-2.5 font-medium text-right">金額</th>
                <th className="py-2 px-2.5 font-medium text-center">処理状態</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {transactions.slice(0, 5).map((txn) => (
                <tr key={txn.id} className="hover:bg-slate-800/40">
                  <td className="py-2 px-2.5 text-slate-500 font-semibold">#{txn.ledgerNumber}</td>
                  <td className="py-2 px-2.5 font-bold text-slate-200">{txn.id}</td>
                  <td className="py-2 px-2.5 text-slate-400">{txn.timestamp}</td>
                  <td className="py-2 px-2.5 text-slate-300">
                    <div>{txn.sourceName}</div>
                    <div className="text-[10px] text-slate-500">{txn.sourceBank}</div>
                  </td>
                  <td className="py-2 px-2.5 text-slate-300">
                    <div>{txn.destName}</div>
                    <div className="text-[10px] text-slate-500">{txn.destBank}</div>
                  </td>
                  <td className="py-2 px-2.5 text-slate-300">{txn.paymentMethod}</td>
                  <td className="py-2 px-2.5 text-slate-400 truncate max-w-[180px]">{txn.purpose}</td>
                  <td className="py-2 px-2.5 font-bold text-right text-slate-100">
                    ¥{txn.amount.toLocaleString()}
                  </td>
                  <td className="py-2 px-2.5 text-center">
                    <StatusBadge status={txn.status} size="sm" />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
