import React, { useState } from 'react';
import { useSimulation } from '../../simulation/SimulationContext';
import { Institution } from '../../types';
import { StatusBadge } from '../common/Badge';
import {
  Building2,
  Server,
  Activity,
  ShieldAlert,
  Layers,
  ArrowUpRight,
  Droplets,
  CheckCircle2,
  AlertTriangle,
  Zap,
} from 'lucide-react';

export const InstitutionsView: React.FC = () => {
  const { institutions } = useSimulation();
  const [selectedInstId, setSelectedInstId] = useState<string>(institutions[0]?.id || '');

  const selectedInst = institutions.find((i) => i.id === selectedInstId) || institutions[0];

  return (
    <div className="space-y-4 p-5 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <Building2 className="w-5 h-5 text-emerald-400" />
            <h2 className="text-base font-bold text-slate-100">加盟金融機関・仲介機関連携基盤</h2>
            <span className="text-xs bg-slate-800 text-slate-300 border border-slate-700 px-2 py-0.5 rounded font-mono-num">
              加盟総数: {institutions.length} 行・機関
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            【模擬データ】全金融機関名はシステム検証用の架空組織です。中央銀行CBDC準備預金口座・APIゲートウェイ・流動性充足状況の監視
          </p>
        </div>
      </div>

      {/* Main Grid: Institutions Table & Selected Bank Detail Drawer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left 8 cols: Institutions Grid & Table */}
        <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded p-4 font-mono-num">
          <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800">
            <h3 className="text-sm font-bold text-slate-100">加盟金融機関 一覧・リアルタイム指標</h3>
            <span className="text-xs text-slate-400">プロトコル: BOJ-NET CBDC API v4</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="text-slate-400 border-b border-slate-800 bg-slate-950/60">
                  <th className="py-2.5 px-2.5 font-medium">金融機関名 / コード</th>
                  <th className="py-2.5 px-2.5 font-medium">業態種別</th>
                  <th className="py-2.5 px-2.5 font-medium text-right">デジタル円保有残高</th>
                  <th className="py-2.5 px-2.5 font-medium text-right">本日取引件数</th>
                  <th className="py-2.5 px-2.5 font-medium text-right">流動性比率</th>
                  <th className="py-2.5 px-2.5 font-medium">API接続</th>
                  <th className="py-2.5 px-2.5 font-medium text-center">異常</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {institutions.map((inst) => {
                  const isSelected = selectedInst?.id === inst.id;
                  return (
                    <tr
                      key={inst.id}
                      onClick={() => setSelectedInstId(inst.id)}
                      className={`cursor-pointer transition ${
                        isSelected
                          ? 'bg-slate-800/90 text-white font-semibold'
                          : 'hover:bg-slate-800/40 text-slate-300'
                      }`}
                    >
                      <td className="py-2.5 px-2.5">
                        <div className="font-bold text-slate-100">{inst.name}</div>
                        <div className="text-[10px] text-slate-400">コード: {inst.code}</div>
                      </td>
                      <td className="py-2.5 px-2.5">
                        <span className="text-[11px] bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                          {inst.type}
                        </span>
                      </td>
                      <td className="py-2.5 px-2.5 text-right font-bold text-slate-100">
                        ¥{inst.cbdcBalance.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-2.5 text-right text-slate-300">
                        {inst.todayTxCount.toLocaleString()} 件
                      </td>
                      <td className="py-2.5 px-2.5 text-right">
                        <span
                          className={`font-bold ${
                            inst.liquidityRatio < 100 ? 'text-amber-400' : 'text-emerald-400'
                          }`}
                        >
                          {inst.liquidityRatio.toFixed(1)}%
                        </span>
                      </td>
                      <td className="py-2.5 px-2.5">
                        <StatusBadge status={inst.apiStatus} size="sm" />
                      </td>
                      <td className="py-2.5 px-2.5 text-center">
                        {inst.abnormalCount > 0 ? (
                          <span className="px-1.5 py-0.5 bg-rose-950 text-rose-300 border border-rose-800 rounded font-bold text-[10px]">
                            {inst.abnormalCount}件
                          </span>
                        ) : (
                          <span className="text-slate-400 text-[11px]">0</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right 4 cols: Bank Detail Inspector */}
        {selectedInst && (
          <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded p-4 flex flex-col justify-between font-mono-num">
            <div className="space-y-3.5">
              <div className="pb-3 border-b border-slate-800">
                <div className="flex items-center justify-between">
                  <span className="text-xs bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-semibold">
                    {selectedInst.type}
                  </span>
                  <StatusBadge status={selectedInst.apiStatus} size="sm" />
                </div>
                <h3 className="text-base font-bold text-slate-100 mt-1">{selectedInst.name}</h3>
                <span className="text-xs text-slate-400">
                  金融機関コード: {selectedInst.code} | 接続ノード: {selectedInst.systemNode}
                </span>
              </div>

              {/* Balance Cards */}
              <div className="space-y-2 text-xs">
                <div className="p-3 bg-slate-950 rounded border border-slate-800">
                  <div className="text-[10px] text-slate-400">デジタル円保有残高</div>
                  <div className="text-base font-bold text-slate-100 mt-0.5">
                    ¥{selectedInst.cbdcBalance.toLocaleString()}
                  </div>
                </div>

                <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-1.5">
                  <div className="flex items-center justify-between text-slate-400">
                    <span>所要準備額:</span>
                    <span className="text-slate-200">
                      ¥{selectedInst.requiredReserve.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-slate-400">
                    <span>現在流動性残高:</span>
                    <span className="text-emerald-400 font-bold">
                      ¥{selectedInst.liquidityReserve.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-slate-400 border-t border-slate-800 pt-1">
                    <span>流動性充足率:</span>
                    <span
                      className={`font-bold ${
                        selectedInst.liquidityRatio < 100 ? 'text-amber-400' : 'text-emerald-400'
                      }`}
                    >
                      {selectedInst.liquidityRatio.toFixed(1)}% (基準: 100%)
                    </span>
                  </div>
                </div>

                <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-1 text-[11px] text-slate-400">
                  <div className="flex items-center justify-between">
                    <span>API応答レイテンシ:</span>
                    <span className="text-slate-200 font-semibold">{selectedInst.latencyMs} ms</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>エラー率:</span>
                    <span className="text-slate-200">{(selectedInst.errorRate * 100).toFixed(3)}%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>本日APIリクエスト数:</span>
                    <span className="text-slate-200">
                      {selectedInst.apiRequestsToday.toLocaleString()} req
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>最終ハートビート:</span>
                    <span className="text-slate-400">{selectedInst.lastHeartbeat}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="pt-3 mt-3 border-t border-slate-800 text-[11px] text-slate-400">
              <span>※ 日銀当座預金系・全銀システム相互接続ノード正常</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
