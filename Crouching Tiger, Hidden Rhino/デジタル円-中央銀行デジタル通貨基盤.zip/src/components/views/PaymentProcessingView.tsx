import React, { useState } from 'react';
import { useSimulation } from '../../simulation/SimulationContext';
import { PaymentMethod, Transaction } from '../../types';
import { StatusBadge } from '../common/Badge';
import {
  CreditCard,
  QrCode,
  Smartphone,
  Layers,
  Send,
  CheckCircle2,
  AlertCircle,
  WifiOff,
  Code2,
  ArrowRight,
  ShieldCheck,
  RotateCcw,
} from 'lucide-react';

export const PaymentProcessingView: React.FC = () => {
  const { wallets, executePayment, transactions } = useSimulation();

  const [sourceWalletId, setSourceWalletId] = useState<string>(wallets[0]?.id || '');
  const [destWalletId, setDestWalletId] = useState<string>(wallets[3]?.id || wallets[1]?.id || '');
  const [amount, setAmount] = useState<number>(8600);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('QRコード');
  const [purpose, setPurpose] = useState<string>('店頭物品購入 (小売決済)');
  
  // Execution pipeline simulation states
  const [isProcessing, setIsProcessing] = useState(false);
  const [currentStep, setCurrentStep] = useState<number>(0);
  const [lastExecutedTxn, setLastExecutedTxn] = useState<Transaction | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const sourceWallet = wallets.find((w) => w.id === sourceWalletId) || wallets[0];
  const destWallet = wallets.find((w) => w.id === destWalletId) || wallets[1];

  const handleStartPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    setErrorMessage(null);
    setLastExecutedTxn(null);
    setCurrentStep(1); // 1: 受付

    // Animate through pipeline steps
    setTimeout(() => setCurrentStep(2), 250); // 2: 署名検証
    setTimeout(() => setCurrentStep(3), 500); // 3: 残高照会
    setTimeout(() => setCurrentStep(4), 750); // 4: リスク審査
    setTimeout(async () => {
      setCurrentStep(5); // 5: 清算処理
      const res = await executePayment({
        sourceWalletId,
        destWalletId,
        amount,
        paymentMethod,
        purpose,
      });

      if (res.success && res.transaction) {
        setCurrentStep(6); // 6: 完了
        setLastExecutedTxn(res.transaction);
      } else {
        setErrorMessage(res.error || '決済処理が拒否されました。');
      }
      setIsProcessing(false);
    }, 1000);
  };

  const paymentMethods: { key: PaymentMethod; label: string; icon: React.ReactNode }[] = [
    { key: 'QRコード', label: 'QRコード決済', icon: <QrCode className="w-4 h-4 text-sky-400" /> },
    { key: 'NFC', label: 'NFCタッチ決済', icon: <Smartphone className="w-4 h-4 text-emerald-400" /> },
    { key: 'スマートフォン', label: 'スマホ端末間', icon: <Smartphone className="w-4 h-4 text-purple-400" /> },
    { key: 'カード型デバイス', label: 'カード型SEデバイス', icon: <CreditCard className="w-4 h-4 text-amber-400" /> },
    { key: 'ウォレット間送金', label: 'ウォレット直接送金', icon: <Send className="w-4 h-4 text-sky-400" /> },
    { key: 'API決済', label: '企業間API決済', icon: <Code2 className="w-4 h-4 text-blue-400" /> },
    { key: 'オフライン決済', label: 'オフラインP2P', icon: <WifiOff className="w-4 h-4 text-slate-400" /> },
  ];

  return (
    <div className="space-y-4 p-5 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-sky-400" />
            <h2 className="text-base font-bold text-slate-100">デジタル円決済処理 エンジン</h2>
            <span className="text-xs bg-slate-800 text-slate-300 border border-slate-700 px-2 py-0.5 rounded font-mono-num">
              決済確定: リアルタイム (RTGS)
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            QR/NFC/API/オフライン各チャネルからのトランザクション受信・署名検証・残高引当・清算連携
          </p>
        </div>
      </div>

      {/* Main Execution Simulator Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 font-mono-num">
        {/* Left 7 cols: Payment Simulator Form */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded p-5">
          <h3 className="text-sm font-bold text-slate-100 pb-3 mb-4 border-b border-slate-800 flex items-center gap-2">
            <Send className="w-4 h-4 text-sky-400" />
            <span>新規決済トランザクション 投入テスト</span>
          </h3>

          <form onSubmit={handleStartPayment} className="space-y-4 text-xs">
            {/* Payment Method Selector Pills */}
            <div>
              <label className="block text-slate-400 font-medium mb-1.5">決済方式の選択</label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                {paymentMethods.map((m) => (
                  <button
                    type="button"
                    key={m.key}
                    onClick={() => setPaymentMethod(m.key)}
                    className={`p-2 rounded border text-left flex items-center gap-2 transition ${
                      paymentMethod === m.key
                        ? 'bg-slate-800 border-sky-500 text-white font-bold'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {m.icon}
                    <span className="truncate">{m.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Source & Dest Wallets */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-400 font-medium mb-1">支払元 (送金側)</label>
                <select
                  value={sourceWalletId}
                  onChange={(e) => setSourceWalletId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-2 text-slate-100 focus:outline-none focus:border-sky-500"
                >
                  {wallets.map((w) => (
                    <option key={w.id} value={w.id}>
                      {w.name} (残: ¥{w.availableBalance.toLocaleString()})
                    </option>
                  ))}
                </select>
                <div className="text-[10px] text-slate-400 mt-1">
                  管理行: {sourceWallet?.bankName} | 口座: {sourceWallet?.accountNumber}
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">支払先 (受取側)</label>
                <select
                  value={destWalletId}
                  onChange={(e) => setDestWalletId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-2 text-slate-100 focus:outline-none focus:border-sky-500"
                >
                  {wallets
                    .filter((w) => w.id !== sourceWalletId)
                    .map((w) => (
                      <option key={w.id} value={w.id}>
                        {w.name} ({w.category})
                      </option>
                    ))}
                </select>
                <div className="text-[10px] text-slate-400 mt-1">
                  管理行: {destWallet?.bankName} | 口座: {destWallet?.accountNumber}
                </div>
              </div>
            </div>

            {/* Amount & Purpose */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-400 font-medium mb-1">決済金額 (円)</label>
                <div className="relative">
                  <span className="absolute left-3 top-2 text-slate-400 text-sm">¥</span>
                  <input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(Number(e.target.value))}
                    min={1}
                    className="w-full bg-slate-950 border border-slate-700 rounded pl-7 pr-3 py-2 text-slate-100 font-bold focus:outline-none focus:border-sky-500"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">取引目的 / 摘要</label>
                <input
                  type="text"
                  value={purpose}
                  onChange={(e) => setPurpose(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-2 text-slate-100 focus:outline-none focus:border-sky-500"
                  required
                />
              </div>
            </div>

            {/* Submit Button */}
            <div className="pt-2">
              <button
                type="submit"
                id="btn-execute-payment"
                disabled={isProcessing}
                className="w-full py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-600 rounded font-bold transition flex items-center justify-center gap-2 active:scale-[0.99] disabled:opacity-50"
              >
                {isProcessing ? (
                  <>
                    <RotateCcw className="w-4 h-4 animate-spin text-sky-400" />
                    <span>決済処理中（パイプライン執行中）...</span>
                  </>
                ) : (
                  <>
                    <CreditCard className="w-4 h-4 text-sky-400" />
                    <span>デジタル円 決済トランザクション送信</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>

        {/* Right 5 cols: Live Pipeline & Animated Confirmation Card */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded p-5 flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-100 pb-3 mb-3 border-b border-slate-800 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>決済パイプライン・リアルタイム遷移</span>
            </h3>

            {/* Step by step pipeline */}
            <div className="space-y-2 text-xs">
              {[
                { step: 1, label: '1. 取引受付 (Ingress Gateway)' },
                { step: 2, label: '2. 端末暗号署名検証 (ECDSA / SE)' },
                { step: 3, label: '3. 残高引当 & 限度額チェック' },
                { step: 4, label: '4. リスク判定エンジン (AML/CFT)' },
                { step: 5, label: '5. 銀行間決済・清算連携 (RTGS)' },
                { step: 6, label: '6. CBDC不変台帳記帳 (完了)' },
              ].map((s) => {
                const isPassed = currentStep >= s.step;
                const isCurrent = currentStep === s.step && isProcessing;
                return (
                  <div
                    key={s.step}
                    className={`p-2 rounded border flex items-center justify-between transition-all ${
                      isPassed
                        ? 'bg-emerald-950/60 border-emerald-800 text-emerald-300'
                        : isCurrent
                        ? 'bg-sky-950 border-sky-600 text-sky-200 animate-pulse'
                        : 'bg-slate-950/60 border-slate-800 text-slate-500'
                    }`}
                  >
                    <span>{s.label}</span>
                    {isPassed ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <span className="text-[10px] text-slate-600">待機</span>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Error Display */}
            {errorMessage && (
              <div className="mt-4 p-3 bg-rose-950 border border-rose-800 rounded text-rose-300 text-xs flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Animated Payment Confirmation */}
            {lastExecutedTxn && (
              <div className="mt-4 p-4 bg-slate-950 border border-emerald-800/80 rounded shadow-md space-y-2.5">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                    <span className="font-bold text-sm text-slate-100">決済完了</span>
                  </div>
                  <span className="text-xs bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded font-bold">
                    清算状態: {lastExecutedTxn.clearingStatus}
                  </span>
                </div>

                <div className="text-center py-2">
                  <div className="text-2xl font-bold text-slate-100">
                    ¥{lastExecutedTxn.amount.toLocaleString()}
                  </div>
                  <div className="text-xs text-slate-400 mt-0.5">{lastExecutedTxn.purpose}</div>
                </div>

                <div className="text-[11px] text-slate-400 space-y-1 bg-slate-900 p-2.5 rounded border border-slate-800">
                  <div className="flex justify-between">
                    <span>取引番号:</span>
                    <span className="text-slate-200 font-bold">{lastExecutedTxn.id}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>処理日時:</span>
                    <span className="text-slate-200">{lastExecutedTxn.timestamp}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>決済方式:</span>
                    <span className="text-slate-200">{lastExecutedTxn.paymentMethod}</span>
                  </div>
                  <div className="flex justify-between truncate">
                    <span>台帳ハッシュ:</span>
                    <span className="text-slate-500 text-[10px] truncate max-w-[200px]">
                      {lastExecutedTxn.hash}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="pt-3 mt-3 border-t border-slate-800 text-[11px] text-slate-400">
            <span>※ 日銀決済ネットワーク BOJ-NET 即時照合完了</span>
          </div>
        </div>
      </div>
    </div>
  );
};
