import React from 'react';
import {
  Server,
  Layers,
  ShieldCheck,
  Cpu,
  Database,
  ArrowRight,
  ArrowDown,
  Building2,
  Smartphone,
  CheckCircle2,
  Lock,
} from 'lucide-react';

export const SystemArchitectureView: React.FC = () => {
  return (
    <div className="space-y-4 p-5 max-w-[1600px] mx-auto font-mono-num">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded shadow-sm">
        <div className="flex items-center gap-2">
          <Layers className="w-5 h-5 text-sky-400" />
          <h2 className="text-base font-bold text-slate-100">
            デジタル円 システム基盤アーキテクチャ (System Architecture)
          </h2>
          <span className="text-xs bg-slate-800 text-slate-300 border border-slate-700 px-2 py-0.5 rounded">
            二層構造型 集中/分散ハイブリッド構成
          </span>
        </div>
        <p className="text-xs text-slate-400 mt-1">
          中央銀行中核台帳・仲介機関APIゲートウェイ・決済処理エンジン・即時清算RTGS・オフラインSE端末の全体トポロジー
        </p>
      </div>

      {/* Layer 1: Central Bank Core (中央銀行コア基盤) */}
      <div className="bg-slate-900 border border-slate-800 rounded p-4">
        <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span className="text-xs bg-amber-950 text-amber-300 border border-amber-800 px-2 py-0.5 rounded font-bold">
              第1層 (Layer 1)
            </span>
            <h3 className="text-sm font-bold text-slate-100">
              日本銀行 CBDC中核台帳・発行管理・即時清算基盤
            </h3>
          </div>
          <span className="text-xs text-emerald-400 font-bold flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" /> 全系冗長稼働 (Triple-Active)
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
            <div className="font-bold text-slate-200 flex items-center gap-1.5">
              <Database className="w-4 h-4 text-amber-400" />
              <span>不変集中取引台帳 (Core Ledger)</span>
            </div>
            <p className="text-[11px] text-slate-400">
              SHA-256暗号化マークルツリー・高スループット確定記帳エンジン
            </p>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
            <div className="font-bold text-slate-200 flex items-center gap-1.5">
              <Server className="w-4 h-4 text-sky-400" />
              <span>発行・償却管理エンジン</span>
            </div>
            <p className="text-[11px] text-slate-400">
              日銀当座預金・国債担保担保連動型のデジタル円供給・回収
            </p>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
            <div className="font-bold text-slate-200 flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-emerald-400" />
              <span>RTGS / DNS 即時清算機構</span>
            </div>
            <p className="text-[11px] text-slate-400">
              銀行間債権債務のリアルタイム確定ファイナリティ付与
            </p>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
            <div className="font-bold text-slate-200 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-rose-400" />
              <span>統括リスク・AML監視基盤</span>
            </div>
            <p className="text-[11px] text-slate-400">
              全網異常取引検知・不正口座即時凍結シグナル配信
            </p>
          </div>
        </div>
      </div>

      {/* Layer 2: Intermediary Institutions (第2層: 仲介機関・金融機関基盤) */}
      <div className="bg-slate-900 border border-slate-800 rounded p-4">
        <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span className="text-xs bg-sky-950 text-sky-300 border border-sky-800 px-2 py-0.5 rounded font-bold">
              第2層 (Layer 2)
            </span>
            <h3 className="text-sm font-bold text-slate-100">
              仲介金融機関 / 資金移動業者 接続ゲートウェイ
            </h3>
          </div>
          <span className="text-xs text-slate-400">プロトコル: ISO 20022 / mTLS gRPC</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
            <div className="font-bold text-slate-200 flex items-center gap-1.5">
              <Building2 className="w-4 h-4 text-sky-400" />
              <span>銀行口座連携 & KYCエンジン</span>
            </div>
            <p className="text-[11px] text-slate-400">
              本人確認・マイナンバー連携・ウォレット保有枠管理
            </p>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
            <div className="font-bold text-slate-200 flex items-center gap-1.5">
              <Cpu className="w-4 h-4 text-emerald-400" />
              <span>決済中継・オーケストレーション</span>
            </div>
            <p className="text-[11px] text-slate-400">
              QR/NFC決済リクエストの署名検証・残高引当代行
            </p>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
            <div className="font-bold text-slate-200 flex items-center gap-1.5">
              <Lock className="w-4 h-4 text-purple-400" />
              <span>日中流動性プール管理</span>
            </div>
            <p className="text-[11px] text-slate-400">
              各行の所要準備預金・決済枠モニタリング
            </p>
          </div>
        </div>
      </div>

      {/* Layer 3: End Points (第3層: エンドユーザー端末 & 加盟店デバイス) */}
      <div className="bg-slate-900 border border-slate-800 rounded p-4">
        <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span className="text-xs bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded font-bold">
              第3層 (Endpoints)
            </span>
            <h3 className="text-sm font-bold text-slate-100">
              利用者端末 (スマートフォン / SEカード / 加盟店POS)
            </h3>
          </div>
          <span className="text-xs text-slate-400">セキュアエレメント(SE) 暗号隔離</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
            <div className="font-bold text-slate-200 flex items-center gap-1.5">
              <Smartphone className="w-4 h-4 text-purple-400" />
              <span>市民リテールウォレット App</span>
            </div>
            <p className="text-[11px] text-slate-400">
              生体認証・QR表示/読取・オフラインP2P送金
            </p>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
            <div className="font-bold text-slate-200 flex items-center gap-1.5">
              <Building2 className="w-4 h-4 text-amber-400" />
              <span>加盟店決済端末 / クラウドPOS</span>
            </div>
            <p className="text-[11px] text-slate-400">
              即時着金確認・自動売上プール・売上清算連携
            </p>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
            <div className="font-bold text-slate-200 flex items-center gap-1.5">
              <Cpu className="w-4 h-4 text-emerald-400" />
              <span>ハードウェア耐タンパーSEチップ</span>
            </div>
            <p className="text-[11px] text-slate-400">
              オフライン残高保持・二重使用防止モノトニックカウンター
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
