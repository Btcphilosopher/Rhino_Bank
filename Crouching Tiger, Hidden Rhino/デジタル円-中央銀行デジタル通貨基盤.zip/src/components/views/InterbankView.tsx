import React, { useState } from 'react';
import { useSimulation } from '../../simulation/SimulationContext';
import { ArrowLeftRight, Building2, Send, CheckCircle2, Shield } from 'lucide-react';
import { StatusBadge } from '../common/Badge';

export const InterbankView: React.FC = () => {
  const { institutions, issueDigitalYen, transactions } = useSimulation();

  const [fromBankId, setFromBankId] = useState(institutions[0]?.id || '');
  const [toBankId, setToBankId] = useState(institutions[1]?.id || '');
  const [transferAmount, setTransferAmount] = useState<number>(5000000000); // 50億円
  const [message, setMessage] = useState<string | null>(null);

  const fromBank = institutions.find((i) => i.id === fromBankId) || institutions[0];
  const toBank = institutions.find((i) => i.id === toBankId) || institutions[1];

  const handleInterbankTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    if (fromBankId === toBankId) {
      setMessage('送金元と受取先は異なる金融機関を指定してください。');
      return;
    }

    // Call issuance deduction & addition (Central bank reserve book transfer)
    issueDigitalYen({
      type: '準備預金振替',
      targetBankId: toBankId,
      amount: transferAmount,
      reason: `銀行間コール決済・流動性融通 (${fromBank.name} → ${toBank.name})`,
      remarks: '日銀当座預金決済RTGS即時振替',
      operator: '日銀決済機構局 銀行間振替システム (BOJ-INT-09)',
    });

    setMessage(`【決済完了】${fromBank.name} から ${toBank.name} へ ¥${transferAmount.toLocaleString()} の銀行間即時決済が完了しました。`);
  };

  return (
    <div className="space-y-4 p-5 max-w-[1600px] mx-auto font-mono-num">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <ArrowLeftRight className="w-5 h-5 text-emerald-400" />
            <h2 className="text-base font-bold text-slate-100">銀行間決済・流動性融通センター</h2>
            <span className="text-xs bg-slate-800 text-slate-300 border border-slate-700 px-2 py-0.5 rounded">
              ネットワーク: BOJ-NET CBDC RTGS
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            加盟金融機関相互のCBDC準備金ポジション管理・日中コール資金移動・決済集中時間の流動性調整
          </p>
        </div>
      </div>

      {/* Grid: Left Matrix & Right Transfer execution */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left 7 cols: Interbank Net Settlement Matrix */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded p-4">
          <h3 className="text-sm font-bold text-slate-100 pb-3 mb-3 border-b border-slate-800 flex items-center gap-2">
            <Building2 className="w-4 h-4 text-sky-400" />
            <span>金融機関別 日中銀行間決済ポジション・残高マトリクス</span>
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="text-slate-400 border-b border-slate-800 bg-slate-950/60">
                  <th className="py-2.5 px-2.5 font-medium">金融機関名</th>
                  <th className="py-2.5 px-2.5 font-medium text-right">保有CBDC残高</th>
                  <th className="py-2.5 px-2.5 font-medium text-right">本日決済総額</th>
                  <th className="py-2.5 px-2.5 font-medium text-right">清算残高</th>
                  <th className="py-2.5 px-2.5 font-medium text-center">状態</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {institutions.map((inst) => (
                  <tr key={inst.id} className="hover:bg-slate-800/40">
                    <td className="py-2.5 px-2.5 font-bold text-slate-200">
                      {inst.name}
                      <span className="text-[10px] text-slate-400 ml-1.5 font-normal">
                        ({inst.code})
                      </span>
                    </td>
                    <td className="py-2.5 px-2.5 text-right font-bold text-slate-100">
                      ¥{inst.cbdcBalance.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-2.5 text-right text-slate-300">
                      ¥{inst.todayTxVolume.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-2.5 text-right text-sky-400 font-semibold">
                      ¥{inst.clearingBalance.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-2.5 text-center">
                      <StatusBadge status={inst.apiStatus} size="sm" />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right 5 cols: Direct Interbank Settlement Order */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded p-4 flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-100 pb-3 mb-3 border-b border-slate-800 flex items-center gap-2">
              <Send className="w-4 h-4 text-emerald-400" />
              <span>日銀当預 銀行間CBDC振替指図</span>
            </h3>

            {message && (
              <div className="p-3 mb-3 bg-emerald-950 border border-emerald-800 text-emerald-300 text-xs rounded">
                {message}
              </div>
            )}

            <form onSubmit={handleInterbankTransfer} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 font-medium mb-1">払出金融機関 (送金元)</label>
                <select
                  value={fromBankId}
                  onChange={(e) => setFromBankId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-2 text-slate-100 focus:outline-none focus:border-sky-500"
                >
                  {institutions.map((i) => (
                    <option key={i.id} value={i.id}>
                      {i.name} (残高: ¥{(i.cbdcBalance / 100000000).toLocaleString()}億円)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">受入金融機関 (受取先)</label>
                <select
                  value={toBankId}
                  onChange={(e) => setToBankId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-2 text-slate-100 focus:outline-none focus:border-sky-500"
                >
                  {institutions
                    .filter((i) => i.id !== fromBankId)
                    .map((i) => (
                      <option key={i.id} value={i.id}>
                        {i.name} (残高: ¥{(i.cbdcBalance / 100000000).toLocaleString()}億円)
                      </option>
                    ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">振替金額 (円)</label>
                <div className="relative">
                  <span className="absolute left-3 top-2 text-slate-400">¥</span>
                  <input
                    type="number"
                    value={transferAmount}
                    onChange={(e) => setTransferAmount(Number(e.target.value))}
                    step="100000000"
                    min={1}
                    className="w-full bg-slate-950 border border-slate-700 rounded pl-7 pr-3 py-2 text-slate-100 font-bold focus:outline-none focus:border-sky-500"
                    required
                  />
                </div>
                <span className="text-[10px] text-slate-400 mt-1 block">
                  換算: {(transferAmount / 100000000).toLocaleString()} 億円
                </span>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-600 rounded font-bold transition flex items-center justify-center gap-2"
                >
                  <ArrowLeftRight className="w-4 h-4 text-emerald-400" />
                  <span>銀行間即時決済 (RTGS振替) 執行</span>
                </button>
              </div>
            </form>
          </div>

          <div className="pt-3 mt-3 border-t border-slate-800 text-[11px] text-slate-400">
            <span>※ 日銀当預口座振替即時完了規則に準拠</span>
          </div>
        </div>
      </div>
    </div>
  );
};
