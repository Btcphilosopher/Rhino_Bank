import React, { useState } from 'react';
import { useSimulation } from '../../simulation/SimulationContext';
import { AuditLog } from '../../types';
import {
  FileText,
  Search,
  Download,
  ShieldCheck,
  Filter,
  CheckCircle2,
  AlertCircle,
  Hash,
} from 'lucide-react';

export const AuditLogView: React.FC = () => {
  const { auditLogs } = useSimulation();

  const [searchTerm, setSearchTerm] = useState('');
  const [filterSeverity, setFilterSeverity] = useState('all');

  const filteredLogs = auditLogs.filter((log) => {
    const matchesSearch =
      log.action.includes(searchTerm) ||
      log.operator.includes(searchTerm) ||
      log.institution.includes(searchTerm) ||
      log.id.includes(searchTerm);
    const matchesSeverity = filterSeverity === 'all' || log.severity === filterSeverity;
    return matchesSearch && matchesSeverity;
  });

  const exportCSV = () => {
    const headers = ['ID,日時,操作者,金融機関,操作内容,結果,重要度,ハッシュ\n'];
    const rows = filteredLogs.map(
      (l) =>
        `"${l.id}","${l.timestamp}","${l.operator}","${l.institution}","${l.action}","${l.outcome}","${l.severity}","${l.hash}"\n`
    );
    const blob = new Blob([...headers, ...rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `CBDC_Audit_Logs_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-4 p-5 max-w-[1600px] mx-auto font-mono-num">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-sky-400" />
            <h2 className="text-base font-bold text-slate-100">
              CBDC 不変性監査ログ台帳 (Tamper-Evident Audit Trail)
            </h2>
            <span className="text-xs bg-slate-800 text-slate-300 border border-slate-700 px-2 py-0.5 rounded">
              暗号学的チェーン照合: 正常
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            全操作者・金融機関の決済・発行・設定変更・口座凍結ログのSHA-256ハッシュリンク追記型記録
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={exportCSV}
            className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded text-xs font-bold flex items-center gap-1.5 transition"
          >
            <Download className="w-3.5 h-3.5" />
            <span>CSV 監査データ出力</span>
          </button>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-slate-900 border border-slate-800 p-3 rounded flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="relative w-full sm:w-96">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="操作者・機関名・操作内容で検索..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950 border border-slate-700 rounded pl-9 pr-3 py-1.5 text-slate-100 placeholder-slate-500 focus:outline-none focus:border-sky-500"
          />
        </div>

        <div className="flex items-center gap-1.5">
          <span className="text-slate-400">重要度:</span>
          {['all', '情報', '注意', '警告', '重大'].map((sev) => (
            <button
              key={sev}
              onClick={() => setFilterSeverity(sev)}
              className={`px-2.5 py-1 rounded border transition ${
                filterSeverity === sev
                  ? 'bg-slate-700 text-white border-slate-500 font-bold'
                  : 'bg-slate-950 text-slate-400 border-slate-800'
              }`}
            >
              {sev === 'all' ? '全レベル' : sev}
            </button>
          ))}
        </div>
      </div>

      {/* Logs Table */}
      <div className="bg-slate-900 border border-slate-800 rounded p-4">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="text-slate-400 border-b border-slate-800 bg-slate-950/60">
                <th className="py-2.5 px-2.5 font-medium">ログID</th>
                <th className="py-2.5 px-2.5 font-medium">日時 (JST)</th>
                <th className="py-2.5 px-2.5 font-medium">操作主体 (Operator)</th>
                <th className="py-2.5 px-2.5 font-medium">所属組織</th>
                <th className="py-2.5 px-2.5 font-medium">操作アクション</th>
                <th className="py-2.5 px-2.5 font-medium">結果</th>
                <th className="py-2.5 px-2.5 font-medium">重要度</th>
                <th className="py-2.5 px-2.5 font-medium">暗号ハッシュ (SHA-256)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-800/40">
                  <td className="py-2.5 px-2.5 font-bold text-slate-200">{log.id}</td>
                  <td className="py-2.5 px-2.5 text-slate-400">{log.timestamp}</td>
                  <td className="py-2.5 px-2.5 text-slate-200">{log.operator}</td>
                  <td className="py-2.5 px-2.5 text-slate-300">{log.institution}</td>
                  <td className="py-2.5 px-2.5 font-semibold text-slate-100">{log.action}</td>
                  <td className="py-2.5 px-2.5">
                    <span className="text-emerald-400 font-bold">{log.outcome}</span>
                  </td>
                  <td className="py-2.5 px-2.5">
                    <span
                      className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                        log.severity === '警告' || log.severity === '重大'
                          ? 'bg-rose-950 text-rose-300 border border-rose-800'
                          : 'bg-slate-800 text-slate-300 border border-slate-700'
                      }`}
                    >
                      {log.severity}
                    </span>
                  </td>
                  <td className="py-2.5 px-2.5 text-slate-500 font-mono text-[10px] truncate max-w-[150px]">
                    {log.hash}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
