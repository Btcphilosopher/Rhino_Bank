import React, { useState } from 'react';
import { useSimulation } from '../../simulation/SimulationContext';
import {
  Smartphone,
  QrCode,
  ArrowUpRight,
  ArrowDownLeft,
  WifiOff,
  Wifi,
  CheckCircle2,
  Lock,
  Send,
  RotateCcw,
  X,
  CreditCard,
} from 'lucide-react';

interface ConsumerWalletModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ConsumerWalletModal: React.FC<ConsumerWalletModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { wallets, executePayment, transactions } = useSimulation();

  // Find standard citizen wallet
  const citizenWallet =
    wallets.find((w) => w.category === '個人ウォレット') || wallets[0];
  const merchantWallet =
    wallets.find((w) => w.category === '加盟店ウォレット') || wallets[3] || wallets[1];

  const [activeTab, setActiveTab] = useState<'pay' | 'receive' | 'history'>('pay');
  const [payAmount, setPayAmount] = useState<number>(1280);
  const [payNote, setPayNote] = useState<string>('コンビニエンスストアお買い物');
  const [isOffline, setIsOffline] = useState(false);
  const [feedback, setFeedback] = useState<{ success: boolean; msg: string } | null>(null);

  if (!isOpen || !citizenWallet) return null;

  const handlePay = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);

    const res = await executePayment({
      sourceWalletId: citizenWallet.id,
      destWalletId: merchantWallet.id,
      amount: payAmount,
      paymentMethod: isOffline ? 'オフライン決済' : 'QRコード',
      purpose: payNote,
    });

    if (res.success) {
      setFeedback({
        success: true,
        msg: `【決済完了】${merchantWallet.name} へ ¥${payAmount.toLocaleString()} を支払いました。`,
      });
    } else {
      setFeedback({
        success: false,
        msg: res.error || '決済に失敗しました。',
      });
    }
  };

  const userTransactions = transactions
    .filter(
      (t) =>
        t.sourceWalletId === citizenWallet.id || t.destWalletId === citizenWallet.id
    )
    .slice(0, 4);

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-xs flex items-center justify-center z-50 p-4 font-mono-num">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-sm w-full shadow-2xl overflow-hidden flex flex-col text-slate-100">
        {/* Phone Top Notch / Header */}
        <div className="bg-slate-950 p-3 border-b border-slate-800 flex items-center justify-between text-xs">
          <div className="flex items-center gap-1.5 text-slate-400">
            <Smartphone className="w-4 h-4 text-sky-400" />
            <span className="font-bold text-slate-200">デジタル円ウォレット (市民版)</span>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Balance Card in Phone */}
        <div className="p-4 bg-gradient-to-b from-slate-900 to-slate-950 border-b border-slate-800">
          <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
            <span>{citizenWallet.name} 様</span>
            <span className="bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded text-[10px]">
              {citizenWallet.bankName}
            </span>
          </div>

          <div className="text-2xl font-bold text-slate-100 mt-1">
            ¥{citizenWallet.availableBalance.toLocaleString()}
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            日銀CBDC直接記帳残高 (保有枠上限: ¥5,000,000)
          </div>

          {/* Offline Toggle */}
          <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs">
            <div className="flex items-center gap-1.5">
              {isOffline ? (
                <WifiOff className="w-3.5 h-3.5 text-rose-400" />
              ) : (
                <Wifi className="w-3.5 h-3.5 text-emerald-400" />
              )}
              <span className="text-[11px] text-slate-300">
                {isOffline ? 'オフラインSE決済モード' : 'オンライン接続中'}
              </span>
            </div>
            <button
              onClick={() => setIsOffline(!isOffline)}
              className={`text-[10px] px-2 py-0.5 rounded border transition ${
                isOffline
                  ? 'bg-rose-950 text-rose-300 border-rose-800 font-bold'
                  : 'bg-slate-800 text-slate-300 border-slate-700'
              }`}
            >
              {isOffline ? 'オンライン切替' : '通信切断テスト'}
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="grid grid-cols-3 border-b border-slate-800 text-xs text-center bg-slate-950">
          <button
            onClick={() => setActiveTab('pay')}
            className={`py-2 border-b-2 transition ${
              activeTab === 'pay'
                ? 'border-sky-500 text-sky-400 font-bold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            支払う
          </button>
          <button
            onClick={() => setActiveTab('receive')}
            className={`py-2 border-b-2 transition ${
              activeTab === 'receive'
                ? 'border-sky-500 text-sky-400 font-bold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            受取QR
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`py-2 border-b-2 transition ${
              activeTab === 'history'
                ? 'border-sky-500 text-sky-400 font-bold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            履歴
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-4 flex-1 overflow-y-auto max-h-[320px] text-xs">
          {feedback && (
            <div
              className={`p-2.5 mb-3 rounded border text-[11px] ${
                feedback.success
                  ? 'bg-emerald-950 border-emerald-800 text-emerald-300'
                  : 'bg-rose-950 border-rose-800 text-rose-300'
              }`}
            >
              {feedback.msg}
            </div>
          )}

          {activeTab === 'pay' && (
            <form onSubmit={handlePay} className="space-y-3">
              <div>
                <label className="block text-slate-400 text-[11px] mb-1">支払先加盟店</label>
                <div className="p-2 bg-slate-950 rounded border border-slate-800 text-slate-200 font-bold">
                  {merchantWallet.name} ({merchantWallet.bankName})
                </div>
              </div>

              <div>
                <label className="block text-slate-400 text-[11px] mb-1">決済金額 (円)</label>
                <div className="relative">
                  <span className="absolute left-3 top-2 text-slate-400">¥</span>
                  <input
                    type="number"
                    value={payAmount}
                    onChange={(e) => setPayAmount(Number(e.target.value))}
                    min={1}
                    className="w-full bg-slate-950 border border-slate-700 rounded pl-7 pr-3 py-1.5 text-slate-100 font-bold focus:outline-none focus:border-sky-500"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 text-[11px] mb-1">摘要</label>
                <input
                  type="text"
                  value={payNote}
                  onChange={(e) => setPayNote(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-slate-100 focus:outline-none focus:border-sky-500"
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-600 rounded font-bold transition flex items-center justify-center gap-1.5 mt-2 shadow-xs"
              >
                <CreditCard className="w-3.5 h-3.5 text-sky-400" />
                <span>{isOffline ? 'オフラインで支払う' : 'タッチ / QR で支払う'}</span>
              </button>
            </form>
          )}

          {activeTab === 'receive' && (
            <div className="flex flex-col items-center justify-center p-3 text-center space-y-2">
              <div className="p-3 bg-white rounded-lg shadow-inner">
                <QrCode className="w-32 h-32 text-slate-900" />
              </div>
              <div className="font-bold text-slate-200 text-sm mt-1">{citizenWallet.name}</div>
              <div className="text-[10px] text-slate-400">
                デジタル円受取コード: {citizenWallet.id}
              </div>
            </div>
          )}

          {activeTab === 'history' && (
            <div className="space-y-2">
              {userTransactions.map((t) => (
                <div
                  key={t.id}
                  className="p-2 bg-slate-950 rounded border border-slate-800 text-[11px]"
                >
                  <div className="flex justify-between items-start">
                    <span className="font-bold text-slate-200 truncate max-w-[160px]">
                      {t.purpose}
                    </span>
                    <span
                      className={`font-bold ${
                        t.sourceWalletId === citizenWallet.id
                          ? 'text-slate-300'
                          : 'text-emerald-400'
                      }`}
                    >
                      {t.sourceWalletId === citizenWallet.id ? '-' : '+'}¥
                      {t.amount.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between text-[10px] text-slate-500 mt-1">
                    <span>{t.paymentMethod}</span>
                    <span>{t.timestamp.slice(11)}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Phone Footer */}
        <div className="p-2.5 bg-slate-950 border-t border-slate-800 text-center text-[10px] text-slate-500">
          耐タンパーセキュアエレメント SE-v4 認証済
        </div>
      </div>
    </div>
  );
};
