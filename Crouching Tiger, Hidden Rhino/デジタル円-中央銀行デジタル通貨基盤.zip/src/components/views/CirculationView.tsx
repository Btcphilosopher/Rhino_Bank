import React from 'react';
import { useSimulation } from '../../simulation/SimulationContext';
import { MetricCard } from '../common/MetricCard';
import { TrendingUp, PieChart, ArrowUpRight, ShieldCheck, Activity, BarChart2, Layers } from 'lucide-react';

export const CirculationView: React.FC = () => {
  const { totalCirculation, wallets, macroModel } = useSimulation();

  // Tier balances
  const personalTotal = wallets
    .filter((w) => w.category === '個人ウォレット')
    .reduce((acc, w) => acc + w.balance, 0);
  const corpTotal = wallets
    .filter((w) => w.category === '企業ウォレット')
    .reduce((acc, w) => acc + w.balance, 0);
  const merchantTotal = wallets
    .filter((w) => w.category === '加盟店ウォレット')
    .reduce((acc, w) => acc + w.balance, 0);
  const corpSettlementTotal = wallets
    .filter((w) => w.category === '法人決済ウォレット')
    .reduce((acc, w) => acc + w.balance, 0);

  return (
    <div className="space-y-5 p-5 max-w-[1600px] mx-auto">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded shadow-sm flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-emerald-400" />
            <h2 className="text-base font-bold text-slate-100">流通管理・マネーサプライ分析</h2>
            <span className="text-xs bg-slate-800 text-slate-300 border border-slate-700 px-2 py-0.5 rounded font-mono-num">
              流通総量: ¥{totalCirculation.toLocaleString()}
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            デジタル円の流通速度・経済セクター別保有比率・現金代替率・預金シフト傾向のリアルタイム計量分析
          </p>
        </div>
        <div className="flex items-center gap-2 text-xs text-slate-400 font-mono-num bg-slate-950 px-3 py-1.5 rounded border border-slate-800">
          <Activity className="w-3.5 h-3.5 text-emerald-400" />
          <span>貨幣流通速度 (Velocity): 8.42 回転/年</span>
        </div>
      </div>

      {/* Circulation Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <MetricCard
          title="マネタリーベース (CBDC構成比)"
          value="18.49 兆円"
          subLabel="日銀当座預金代替"
          subValue="全体の 3.4%"
          change="+0.8% (前月比)"
          changeType="positive"
        />
        <MetricCard
          title="貨幣流通速度 (V)"
          value="8.42"
          unit="回転/年"
          subLabel="現金(1.8)との対比"
          subValue="4.6倍の高回転"
          change="効率化達成"
          changeType="positive"
        />
        <MetricCard
          title="現金代替率 (M0比)"
          value={`${macroModel.cashSubstitutionRate.toFixed(1)}%`}
          subLabel="紙幣・硬貨減少幅"
          subValue="年間 -12.4兆円"
          change="目標レンジ内"
          changeType="positive"
        />
        <MetricCard
          title="銀行預金シフト率"
          value={`${macroModel.bankDepositMigrationRate.toFixed(1)}%`}
          subLabel="流動性影響モニタ"
          subValue="ディスインテルメディエーション無"
          change="低リスク"
          changeType="positive"
        />
      </div>

      {/* Sector Breakdown & Distribution Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left 6 cols: Category Distribution Breakdown */}
        <div className="lg:col-span-6 bg-slate-900 border border-slate-800 rounded p-4">
          <h3 className="text-sm font-bold text-slate-100 pb-3 mb-4 border-b border-slate-800 flex items-center gap-2">
            <PieChart className="w-4 h-4 text-sky-400" />
            <span>セクター別デジタル円 保有残高構成</span>
          </h3>

          <div className="space-y-4 font-mono-num text-xs">
            {/* Financial institutions */}
            <div>
              <div className="flex items-center justify-between mb-1.5 text-slate-300">
                <span className="font-semibold">金融機関 決済準備枠 (Interbank Reserve)</span>
                <span className="font-bold text-slate-100">¥18.49 兆円 (96.8%)</span>
              </div>
              <div className="w-full bg-slate-950 h-2.5 rounded-full overflow-hidden border border-slate-800">
                <div className="bg-sky-500 h-full rounded-full" style={{ width: '96.8%' }} />
              </div>
            </div>

            {/* Corporate Wallets */}
            <div>
              <div className="flex items-center justify-between mb-1.5 text-slate-300">
                <span className="font-semibold">企業・サプライチェーン保有 (Corporate)</span>
                <span className="font-bold text-slate-100">¥4.89 億円 (1.8%)</span>
              </div>
              <div className="w-full bg-slate-950 h-2.5 rounded-full overflow-hidden border border-slate-800">
                <div className="bg-amber-500 h-full rounded-full" style={{ width: '18%' }} />
              </div>
            </div>

            {/* Merchant Wallets */}
            <div>
              <div className="flex items-center justify-between mb-1.5 text-slate-300">
                <span className="font-semibold">加盟店売上プール (Merchant Sales Pool)</span>
                <span className="font-bold text-slate-100">¥4,280 万円 (0.9%)</span>
              </div>
              <div className="w-full bg-slate-950 h-2.5 rounded-full overflow-hidden border border-slate-800">
                <div className="bg-emerald-500 h-full rounded-full" style={{ width: '9%' }} />
              </div>
            </div>

            {/* Personal Wallets */}
            <div>
              <div className="flex items-center justify-between mb-1.5 text-slate-300">
                <span className="font-semibold">個人生活決済口座 (Citizen Retail Wallets)</span>
                <span className="font-bold text-slate-100">¥156.9 万円 (0.5%)</span>
              </div>
              <div className="w-full bg-slate-950 h-2.5 rounded-full overflow-hidden border border-slate-800">
                <div className="bg-purple-500 h-full rounded-full" style={{ width: '5%' }} />
              </div>
            </div>
          </div>

          <div className="mt-5 pt-3 border-t border-slate-800 text-[11px] text-slate-400 font-mono-num">
            <span>※ 法人・個人のウォレット保有上限（ホールディング・リミット）適用シミュレーション中</span>
          </div>
        </div>

        {/* Right 6 cols: Real-time Velocity & Monetary Parameters */}
        <div className="lg:col-span-6 bg-slate-900 border border-slate-800 rounded p-4 flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-100 pb-3 mb-4 border-b border-slate-800 flex items-center gap-2">
              <BarChart2 className="w-4 h-4 text-emerald-400" />
              <span>時間帯別 デジタル円決済速度・流通フロー</span>
            </h3>

            <div className="space-y-3 font-mono-num text-xs">
              <div className="p-3 bg-slate-950 rounded border border-slate-800">
                <div className="text-slate-400 mb-1">午前集中帯 (09:00 - 11:30)</div>
                <div className="text-slate-200 font-semibold flex items-center justify-between">
                  <span>銀行間大口RTGS決済 / 企業間仕入清算</span>
                  <span className="text-sky-400 font-bold">18,400 TPS (ピーク)</span>
                </div>
              </div>

              <div className="p-3 bg-slate-950 rounded border border-slate-800">
                <div className="text-slate-400 mb-1">昼間帯 (11:30 - 14:00)</div>
                <div className="text-slate-200 font-semibold flex items-center justify-between">
                  <span>個人リテール飲食・小売決済 (QR/NFC)</span>
                  <span className="text-emerald-400 font-bold">12,100 TPS</span>
                </div>
              </div>

              <div className="p-3 bg-slate-950 rounded border border-slate-800">
                <div className="text-slate-400 mb-1">夕刻・締め帯 (15:00 - 17:00)</div>
                <div className="text-slate-200 font-semibold flex items-center justify-between">
                  <span>全銀・ネット清算相殺 (DNSバッチ処理)</span>
                  <span className="text-amber-400 font-bold">4,900 TPS (高額集約)</span>
                </div>
              </div>
            </div>
          </div>

          <div className="pt-3 mt-3 border-t border-slate-800 text-[11px] text-slate-400 font-mono-num">
            <span>※ 日銀CBDC第2フェーズ実証実験（保有制限・利息付与の有無）想定仕様</span>
          </div>
        </div>
      </div>
    </div>
  );
};
