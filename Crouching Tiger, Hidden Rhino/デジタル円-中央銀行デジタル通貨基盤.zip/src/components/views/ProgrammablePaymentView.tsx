import React, { useState } from 'react';
import { useSimulation } from '../../simulation/SimulationContext';
import { ProgrammablePayment } from '../../types';
import { StatusBadge } from '../common/Badge';
import {
  Code2,
  Play,
  CheckCircle2,
  AlertCircle,
  Clock,
  FileCheck,
  Building,
  ArrowRight,
  Plus,
  Shield,
} from 'lucide-react';

export const ProgrammablePaymentView: React.FC = () => {
  const {
    programmablePayments,
    executeProgrammablePayment,
    toggleProgrammableCondition,
  } = useSimulation();

  const [selectedRuleId, setSelectedRuleId] = useState<string>(
    programmablePayments[0]?.id || ''
  );
  const [feedback, setFeedback] = useState<string | null>(null);

  const selectedRule =
    programmablePayments.find((p) => p.id === selectedRuleId) ||
    programmablePayments[0];

  const handleExecute = (ruleId: string) => {
    setFeedback(null);
    const res = executeProgrammablePayment(ruleId);
    if (res.success) {
      setFeedback(`【条件成立・自動執行】${selectedRule.title} のプログラム決済が正常に執行されました。`);
    } else {
      setFeedback(res.message || '条件未達のため執行できませんでした。');
    }
  };

  return (
    <div className="space-y-4 p-5 max-w-[1600px] mx-auto font-mono-num">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <Code2 className="w-5 h-5 text-indigo-400" />
            <h2 className="text-base font-bold text-slate-100">
              プログラマブル決済・条件付執行基盤
            </h2>
            <span className="text-xs bg-slate-800 text-slate-300 border border-slate-700 px-2 py-0.5 rounded">
              スマートコントラクト / ルール駆動型
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            給与振込・サプライチェーン納品検収連動・目的限定型補助金・定期請求書の自動執行条件管理
          </p>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left 7 cols: Programmable Rules List */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded p-4">
          <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800">
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <FileCheck className="w-4 h-4 text-sky-400" />
              <span>登録済み プログラマブル執行ルール</span>
            </h3>
            <span className="text-xs text-slate-400">
              登録数: {programmablePayments.length} 件
            </span>
          </div>

          <div className="space-y-2.5 max-h-[600px] overflow-y-auto pr-1">
            {programmablePayments.map((rule) => {
              const isSelected = selectedRule?.id === rule.id;
              return (
                <div
                  key={rule.id}
                  onClick={() => setSelectedRuleId(rule.id)}
                  className={`p-3 rounded border transition cursor-pointer ${
                    isSelected
                      ? 'bg-slate-800 border-indigo-500 shadow-sm'
                      : 'bg-slate-950/70 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="text-[10px] bg-slate-900 text-indigo-300 border border-indigo-900 px-1.5 py-0.5 rounded font-semibold whitespace-nowrap">
                        {rule.category}
                      </span>
                      <span className="font-bold text-xs text-slate-100 truncate">
                        {rule.title}
                      </span>
                    </div>
                    <StatusBadge status={rule.status} size="sm" />
                  </div>

                  <div className="text-[11px] text-slate-400 mb-1.5 truncate">
                    条件: <span className="text-slate-200">{rule.condition}</span>
                  </div>

                  <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-800/60">
                    <span className="text-slate-400 text-[11px]">
                      {rule.senderName} → {rule.receiverName}
                    </span>
                    <span className="font-bold text-slate-100">
                      ¥{rule.amount.toLocaleString()}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right 5 cols: Rule Detail & Trigger Execution */}
        {selectedRule && (
          <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded p-4 flex flex-col justify-between">
            <div className="space-y-3.5">
              <div className="pb-3 border-b border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-xs bg-indigo-950 text-indigo-300 border border-indigo-800 px-2 py-0.5 rounded font-semibold">
                    {selectedRule.category}
                  </span>
                  <h3 className="text-base font-bold text-slate-100 mt-1">
                    {selectedRule.title}
                  </h3>
                </div>
                <StatusBadge status={selectedRule.status} size="sm" />
              </div>

              {feedback && (
                <div className="p-3 bg-emerald-950 border border-emerald-800 text-emerald-300 text-xs rounded flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>{feedback}</span>
                </div>
              )}

              <div className="space-y-2 text-xs">
                <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-1.5">
                  <div className="text-[10px] text-slate-400">執行条件式 (Smart Trigger Logic)</div>
                  <div className="font-mono text-emerald-400 font-semibold bg-slate-900 p-2 rounded border border-slate-800">
                    {selectedRule.condition}
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
                    <span>条件判定状態:</span>
                    <span
                      className={`font-bold ${
                        selectedRule.conditionMet ? 'text-emerald-400' : 'text-amber-400'
                      }`}
                    >
                      {selectedRule.conditionMet ? '● 条件充足済' : '○ 条件未達 (待機中)'}
                    </span>
                  </div>
                </div>

                <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-1">
                  <div className="flex justify-between">
                    <span className="text-slate-400">送金元:</span>
                    <span className="text-slate-200 font-bold">
                      {selectedRule.senderName}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">送金先:</span>
                    <span className="text-slate-200 font-bold">{selectedRule.receiverName}</span>
                  </div>
                  <div className="flex justify-between pt-1 border-t border-slate-800">
                    <span className="text-slate-400">執行予定金額:</span>
                    <span className="text-base font-bold text-emerald-400">
                      ¥{selectedRule.amount.toLocaleString()}
                    </span>
                  </div>
                </div>

                <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-1 text-[11px] text-slate-400">
                  <div className="flex justify-between">
                    <span>ルールID:</span>
                    <span className="text-slate-200">{selectedRule.id}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>有効期限:</span>
                    <span className="text-slate-200">{selectedRule.validUntil}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>最終執行日時:</span>
                    <span className="text-slate-200">{selectedRule.executedAt || '未執行'}</span>
                  </div>
                </div>
              </div>

              <div className="pt-2 flex flex-col gap-2">
                <button
                  onClick={() => handleExecute(selectedRule.id)}
                  className="w-full py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-600 rounded text-xs font-bold transition flex items-center justify-center gap-2 active:scale-95"
                >
                  <Play className="w-4 h-4 text-emerald-400 fill-emerald-400" />
                  <span>条件判定シミュレーション & 即時自動執行</span>
                </button>

                <button
                  onClick={() => toggleProgrammableCondition(selectedRule.id)}
                  className="w-full py-1.5 px-3 bg-slate-950 hover:bg-slate-800 text-slate-300 border border-slate-800 rounded text-xs transition"
                >
                  {selectedRule.conditionMet ? '条件充足フラグをリセット' : '外部トリガー条件を「成立」に切替'}
                </button>
              </div>
            </div>

            <div className="pt-3 mt-3 border-t border-slate-800 text-[11px] text-slate-400">
              <span>※ プログラマブルCBDC論理実行エンジン 監査適合済</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
