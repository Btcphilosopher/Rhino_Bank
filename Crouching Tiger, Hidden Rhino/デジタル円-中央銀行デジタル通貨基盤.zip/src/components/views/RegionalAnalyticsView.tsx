import React, { useState } from 'react';
import { useSimulation } from '../../simulation/SimulationContext';
import { RegionalData } from '../../types';
import { MetricCard } from '../common/MetricCard';
import {
  MapPin,
  TrendingUp,
  Store,
  Users,
  CreditCard,
  Building,
  BarChart2,
} from 'lucide-react';

export const RegionalAnalyticsView: React.FC = () => {
  const { regionalData } = useSimulation();
  const [selectedRegionId, setSelectedRegionId] = useState<string>('REG-03'); // Kanto default

  const selectedRegion =
    regionalData.find((r) => r.id === selectedRegionId) || regionalData[2] || regionalData[0];

  return (
    <div className="space-y-4 p-5 max-w-[1600px] mx-auto font-mono-num">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <MapPin className="w-5 h-5 text-emerald-400" />
            <h2 className="text-base font-bold text-slate-100">
              全国地域別 デジタル円普及・流通動態分析
            </h2>
            <span className="text-xs bg-slate-800 text-slate-300 border border-slate-700 px-2 py-0.5 rounded">
              9大経済ブロック監視中
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            各地方都市・経済圏におけるCBDC保有残高・決済浸透率・加盟店普及状況およびキャッシュレス代替度
          </p>
        </div>
      </div>

      {/* Region Selector Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
        {regionalData.map((r) => (
          <button
            key={r.id}
            onClick={() => setSelectedRegionId(r.id)}
            className={`px-3 py-1.5 rounded border transition whitespace-nowrap ${
              selectedRegion?.id === r.id
                ? 'bg-slate-700 text-white border-slate-500 font-bold shadow-xs'
                : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
            }`}
          >
            {r.name} ({r.sharePercentage.toFixed(1)}%)
          </button>
        ))}
      </div>

      {/* Selected Region Detailed Cards */}
      {selectedRegion && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <MetricCard
            title={`${selectedRegion.name}圏 本日決済総額`}
            value={`¥${selectedRegion.txAmount.toLocaleString()}`}
            subLabel="全国比構成比"
            subValue={`${selectedRegion.sharePercentage.toFixed(1)}%`}
            change={`+${selectedRegion.growthRate.toFixed(1)}%`}
            changeType="positive"
          />
          <MetricCard
            title="開設ウォレット口座数"
            value={`${selectedRegion.walletCount.toLocaleString()} 口座`}
            subLabel="普及成長率"
            subValue={`前年比 +${selectedRegion.growthRate.toFixed(1)}%`}
            change="順調"
            changeType="positive"
          />
          <MetricCard
            title="本日取引件数"
            value={`${selectedRegion.txCount.toLocaleString()} 件`}
            subLabel="清算総額"
            subValue={`¥${selectedRegion.clearingAmount.toLocaleString()}`}
            change="活況"
            changeType="positive"
          />
          <MetricCard
            title="対応加盟店数"
            value={`${selectedRegion.merchantCount.toLocaleString()} 店`}
            subLabel="主要POS連動率"
            subValue="98.6% 稼働"
            change="+4.2%"
            changeType="positive"
          />
        </div>
      )}

      {/* 9 Regions Comprehensive Comparison Table */}
      <div className="bg-slate-900 border border-slate-800 rounded p-4">
        <h3 className="text-sm font-bold text-slate-100 pb-3 mb-3 border-b border-slate-800 flex items-center gap-2">
          <BarChart2 className="w-4 h-4 text-sky-400" />
          <span>全9地域ブロック 比較一覧表</span>
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="text-slate-400 border-b border-slate-800 bg-slate-950/60">
                <th className="py-2.5 px-2.5 font-medium">地域ブロック</th>
                <th className="py-2.5 px-2.5 font-medium text-right">本日決済総額</th>
                <th className="py-2.5 px-2.5 font-medium text-right">取引件数</th>
                <th className="py-2.5 px-2.5 font-medium text-right">ウォレット口座数</th>
                <th className="py-2.5 px-2.5 font-medium text-right">加盟店数</th>
                <th className="py-2.5 px-2.5 font-medium text-right">全国シェア</th>
                <th className="py-2.5 px-2.5 font-medium text-right">成長率</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {regionalData.map((r) => {
                const isSelected = selectedRegion?.id === r.id;
                return (
                  <tr
                    key={r.id}
                    onClick={() => setSelectedRegionId(r.id)}
                    className={`cursor-pointer transition ${
                      isSelected
                        ? 'bg-slate-800/80 font-bold text-white'
                        : 'hover:bg-slate-800/40 text-slate-300'
                    }`}
                  >
                    <td className="py-2.5 px-2.5 font-bold text-slate-200">
                      {r.name} <span className="text-[10px] text-slate-500 font-normal">({r.nameKana})</span>
                    </td>
                    <td className="py-2.5 px-2.5 text-right font-bold text-slate-100">
                      ¥{r.txAmount.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-2.5 text-right text-slate-300">
                      {r.txCount.toLocaleString()} 件
                    </td>
                    <td className="py-2.5 px-2.5 text-right text-slate-300">
                      {r.walletCount.toLocaleString()} 口座
                    </td>
                    <td className="py-2.5 px-2.5 text-right text-slate-300">
                      {r.merchantCount.toLocaleString()} 店
                    </td>
                    <td className="py-2.5 px-2.5 text-right text-emerald-400 font-semibold">
                      {r.sharePercentage.toFixed(1)}%
                    </td>
                    <td className="py-2.5 px-2.5 text-right text-sky-400 font-semibold">
                      +{r.growthRate.toFixed(1)}%
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
