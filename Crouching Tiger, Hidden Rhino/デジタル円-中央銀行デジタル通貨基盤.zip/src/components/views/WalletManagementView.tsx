import React, { useState } from 'react';
import { useSimulation } from '../../simulation/SimulationContext';
import { Wallet, WalletCategory, WalletStatus } from '../../types';
import { StatusBadge } from '../common/Badge';
import {
  Wallet as WalletIcon,
  Search,
  Filter,
  Shield,
  Lock,
  Unlock,
  Eye,
  Send,
  ArrowDownLeft,
  ArrowUpRight,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Building,
  User,
  Store,
} from 'lucide-react';

export const WalletManagementView: React.FC = () => {
  const { wallets, toggleWalletStatus, executePayment } = useSimulation();

  const [selectedWalletId, setSelectedWalletId] = useState<string>(wallets[0]?.id || '');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');

  // Quick action modal state
  const [actionModal, setActionModal] = useState<{
    isOpen: boolean;
    type: 'send' | 'receive' | 'hold';
    wallet?: Wallet;
  }>({ isOpen: false, type: 'send' });

  const [destWalletId, setDestWalletId] = useState<string>('');
  const [actionAmount, setActionAmount] = useState<number>(10000);
  const [actionPurpose, setActionPurpose] = useState<string>('口座間資金移動');
  const [modalFeedback, setModalFeedback] = useState<string | null>(null);

  const selectedWallet = wallets.find((w) => w.id === selectedWalletId) || wallets[0];

  const filteredWallets = wallets.filter((w) => {
    const matchesCategory = filterCategory === 'all' || w.category === filterCategory;
    const matchesSearch =
      w.name.includes(searchTerm) ||
      w.id.includes(searchTerm) ||
      w.bankName.includes(searchTerm) ||
      w.accountNumber.includes(searchTerm);
    return matchesCategory && matchesSearch;
  });

  const handleExecuteSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedWallet) return;
    setModalFeedback(null);

    const res = await executePayment({
      sourceWalletId: selectedWallet.id,
      destWalletId,
      amount: actionAmount,
      paymentMethod: 'ウォレット間送金',
      purpose: actionPurpose,
    });

    if (res.success) {
      setModalFeedback(`【送金完了】¥${actionAmount.toLocaleString()} を正常に送金しました。`);
      setTimeout(() => {
        setActionModal({ isOpen: false, type: 'send' });
        setModalFeedback(null);
      }, 1400);
    } else {
      setModalFeedback(res.error || '送金に失敗しました。');
    }
  };

  return (
    <div className="space-y-4 p-5 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <WalletIcon className="w-5 h-5 text-sky-400" />
            <h2 className="text-base font-bold text-slate-100">デジタル円 ウォレット管理基盤</h2>
            <span className="text-xs bg-slate-800 text-slate-300 border border-slate-700 px-2 py-0.5 rounded font-mono-num">
              管理総数: {wallets.length.toLocaleString()} 口座
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            個人・企業・加盟店・金融機関ウォレットの残高照会・本人確認(KYC)ステータス・リスク階層・利用停止管理
          </p>
        </div>
      </div>

      {/* Main Grid: Left Wallet List & Filter / Right Detailed Selected Wallet Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left 5 Cols: List & Filter */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded p-4 flex flex-col justify-between">
          <div>
            {/* Search & Filter Bar */}
            <div className="space-y-2 mb-3">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="氏名・企業名・ウォレットIDで検索..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded pl-9 pr-3 py-1.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-sky-500"
                />
              </div>

              <div className="flex items-center gap-1 overflow-x-auto pb-1 text-[11px] font-mono-num">
                {['all', '個人ウォレット', '企業ウォレット', '加盟店ウォレット', '金融機関ウォレット', '法人決済ウォレット'].map(
                  (cat) => (
                    <button
                      key={cat}
                      onClick={() => setFilterCategory(cat)}
                      className={`px-2 py-1 rounded whitespace-nowrap border transition ${
                        filterCategory === cat
                          ? 'bg-slate-700 text-white border-slate-500 font-semibold'
                          : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
                      }`}
                    >
                      {cat === 'all' ? '全種別' : cat}
                    </button>
                  )
                )}
              </div>
            </div>

            {/* List Table */}
            <div className="space-y-2 max-h-[620px] overflow-y-auto pr-1">
              {filteredWallets.map((w) => {
                const isSelected = selectedWallet?.id === w.id;
                return (
                  <div
                    key={w.id}
                    onClick={() => setSelectedWalletId(w.id)}
                    className={`p-3 rounded border transition cursor-pointer font-mono-num ${
                      isSelected
                        ? 'bg-slate-800 border-sky-600 shadow-sm'
                        : 'bg-slate-950/70 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <div className="flex items-center gap-1.5 min-w-0">
                        {w.category === '個人ウォレット' ? (
                          <User className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                        ) : w.category === '加盟店ウォレット' ? (
                          <Store className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                        ) : (
                          <Building className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        )}
                        <span className="font-bold text-xs text-slate-100 truncate">{w.name}</span>
                      </div>
                      <StatusBadge status={w.status} size="sm" />
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-slate-400">
                      <span className="truncate">{w.bankName}</span>
                      <span className="font-bold text-slate-200 text-xs">
                        ¥{w.balance.toLocaleString()}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-[10px] text-slate-500 mt-1 border-t border-slate-800/60 pt-1">
                      <span>{w.id}</span>
                      <span className="text-slate-400">KYC: {w.kycStatus}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="pt-3 mt-3 border-t border-slate-800 text-[11px] text-slate-400 font-mono-num flex items-center justify-between">
            <span>表示件数: {filteredWallets.length} 件</span>
            <span className="text-slate-500">2層目仲介機関管理規程準拠</span>
          </div>
        </div>

        {/* Right 7 Cols: Detailed Inspect & Administrative Actions */}
        {selectedWallet && (
          <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded p-5 flex flex-col justify-between font-mono-num">
            <div className="space-y-4">
              {/* Wallet Header Card */}
              <div className="bg-slate-950 p-4 rounded border border-slate-800">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 pb-3 mb-3 border-b border-slate-800">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-semibold">
                        {selectedWallet.category}
                      </span>
                      <h3 className="text-base font-bold text-slate-100">{selectedWallet.name}</h3>
                    </div>
                    <div className="text-xs text-slate-400 mt-0.5">
                      管理金融機関: <span className="text-slate-200">{selectedWallet.bankName}</span>{' '}
                      | 口座番号: <span className="text-slate-200">{selectedWallet.accountNumber}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <StatusBadge status={selectedWallet.status} size="md" />
                    <span
                      className={`text-xs px-2 py-0.5 rounded border font-semibold ${
                        selectedWallet.riskTier === '高' || selectedWallet.riskTier === '最重要監視'
                          ? 'bg-rose-950 text-rose-300 border-rose-800'
                          : 'bg-slate-800 text-slate-300 border-slate-700'
                      }`}
                    >
                      リスク区分: {selectedWallet.riskTier}
                    </span>
                  </div>
                </div>

                {/* Balances Display */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center">
                  <div className="bg-slate-900 p-3 rounded border border-slate-800">
                    <div className="text-[11px] text-slate-400 mb-1">デジタル円残高</div>
                    <div className="text-lg font-bold text-slate-100">
                      ¥{selectedWallet.balance.toLocaleString()}
                    </div>
                  </div>
                  <div className="bg-slate-900 p-3 rounded border border-slate-800">
                    <div className="text-[11px] text-slate-400 mb-1">利用可能額</div>
                    <div className="text-lg font-bold text-emerald-400">
                      ¥{selectedWallet.availableBalance.toLocaleString()}
                    </div>
                  </div>
                  <div className="bg-slate-900 p-3 rounded border border-slate-800">
                    <div className="text-[11px] text-slate-400 mb-1">保留額</div>
                    <div className="text-lg font-bold text-amber-400">
                      ¥{selectedWallet.heldAmount.toLocaleString()}
                    </div>
                  </div>
                </div>
              </div>

              {/* Attributes Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
                <div className="p-2.5 bg-slate-950 rounded border border-slate-800">
                  <div className="text-[10px] text-slate-500">本人確認 (KYC)</div>
                  <div className="font-bold text-slate-200 mt-0.5">{selectedWallet.kycStatus}</div>
                </div>
                <div className="p-2.5 bg-slate-950 rounded border border-slate-800">
                  <div className="text-[10px] text-slate-500">累計入金額</div>
                  <div className="font-bold text-slate-200 mt-0.5">
                    ¥{selectedWallet.totalDeposited.toLocaleString()}
                  </div>
                </div>
                <div className="p-2.5 bg-slate-950 rounded border border-slate-800">
                  <div className="text-[10px] text-slate-500">累計支払額</div>
                  <div className="font-bold text-slate-200 mt-0.5">
                    ¥{selectedWallet.totalPaid.toLocaleString()}
                  </div>
                </div>
                <div className="p-2.5 bg-slate-950 rounded border border-slate-800">
                  <div className="text-[10px] text-slate-500">取引件数</div>
                  <div className="font-bold text-slate-200 mt-0.5">
                    {selectedWallet.transactionCount} 件
                  </div>
                </div>
              </div>

              {/* Operations Control Actions */}
              <div className="bg-slate-950 p-4 rounded border border-slate-800 space-y-3">
                <div className="text-xs font-bold text-slate-300">口座管理・送金オペレーション</div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <button
                    onClick={() => {
                      const other = wallets.find((w) => w.id !== selectedWallet.id);
                      setDestWalletId(other ? other.id : '');
                      setActionModal({ isOpen: true, type: 'send', wallet: selectedWallet });
                    }}
                    className="py-2 px-3 bg-sky-950 hover:bg-sky-900 text-sky-200 border border-sky-800 rounded text-xs font-medium flex items-center justify-center gap-1.5 transition"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>送金</span>
                  </button>

                  <button
                    onClick={() => {
                      const other = wallets.find((w) => w.id !== selectedWallet.id);
                      if (other) {
                        executePayment({
                          sourceWalletId: other.id,
                          destWalletId: selectedWallet.id,
                          amount: 5000,
                          paymentMethod: 'ウォレット間送金',
                          purpose: '口座受取テスト決済',
                        });
                      }
                    }}
                    className="py-2 px-3 bg-emerald-950 hover:bg-emerald-900 text-emerald-200 border border-emerald-800 rounded text-xs font-medium flex items-center justify-center gap-1.5 transition"
                  >
                    <ArrowDownLeft className="w-3.5 h-3.5" />
                    <span>受取 (受入)</span>
                  </button>

                  {selectedWallet.status === '利用停止' ? (
                    <button
                      onClick={() => toggleWalletStatus(selectedWallet.id, '正常')}
                      className="py-2 px-3 bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-800 rounded text-xs font-medium flex items-center justify-center gap-1.5 transition"
                    >
                      <Unlock className="w-3.5 h-3.5" />
                      <span>利用再開</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => toggleWalletStatus(selectedWallet.id, '利用停止')}
                      className="py-2 px-3 bg-rose-950 hover:bg-rose-900 text-rose-300 border border-rose-800 rounded text-xs font-medium flex items-center justify-center gap-1.5 transition"
                    >
                      <Lock className="w-3.5 h-3.5" />
                      <span>利用停止</span>
                    </button>
                  )}

                  <button
                    onClick={() => {
                      alert(`【返金・調整処理】ウォレットID: ${selectedWallet.id} の直近取引照合を開始しました。`);
                    }}
                    className="py-2 px-3 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 rounded text-xs font-medium flex items-center justify-center gap-1.5 transition"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>返金・調整</span>
                  </button>
                </div>
              </div>
            </div>

            <div className="pt-3 mt-3 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
              <span>最終取引日時: {selectedWallet.lastTransactionAt}</span>
              <span>地域区分: {selectedWallet.region}</span>
            </div>
          </div>
        )}
      </div>

      {/* Send Modal */}
      {actionModal.isOpen && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-slate-900 border border-slate-700 rounded p-5 max-w-md w-full shadow-2xl font-mono-num">
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800">
              <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <Send className="w-4 h-4 text-sky-400" />
                <span>デジタル円 資金移動・送金指示</span>
              </h3>
              <button
                onClick={() => setActionModal({ isOpen: false, type: 'send' })}
                className="text-slate-400 hover:text-white text-xs"
              >
                ✕ 閉じる
              </button>
            </div>

            {modalFeedback && (
              <div className="p-3 mb-3 bg-emerald-950 border border-emerald-800 text-emerald-300 text-xs rounded">
                {modalFeedback}
              </div>
            )}

            <form onSubmit={handleExecuteSend} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 font-medium mb-1">送金元ウォレット</label>
                <div className="p-2 bg-slate-950 rounded border border-slate-800 text-slate-200">
                  {selectedWallet?.name}（利用可能: ¥{selectedWallet?.availableBalance.toLocaleString()}）
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">送金先ウォレット選択</label>
                <select
                  value={destWalletId}
                  onChange={(e) => setDestWalletId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-2 text-slate-100 focus:outline-none focus:border-sky-500"
                  required
                >
                  {wallets
                    .filter((w) => w.id !== selectedWallet?.id)
                    .map((w) => (
                      <option key={w.id} value={w.id}>
                        {w.name} ({w.bankName} / {w.id})
                      </option>
                    ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">送金金額 (円)</label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-slate-400">¥</span>
                  <input
                    type="number"
                    value={actionAmount}
                    onChange={(e) => setActionAmount(Number(e.target.value))}
                    max={selectedWallet?.availableBalance}
                    min={1}
                    className="w-full bg-slate-950 border border-slate-700 rounded pl-7 pr-3 py-2 text-slate-100 font-bold focus:outline-none focus:border-sky-500"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">取引目的</label>
                <input
                  type="text"
                  value={actionPurpose}
                  onChange={(e) => setActionPurpose(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-2 text-slate-100 focus:outline-none focus:border-sky-500"
                  required
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setActionModal({ isOpen: false, type: 'send' })}
                  className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded"
                >
                  キャンセル
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white font-bold rounded"
                >
                  送金実行
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
