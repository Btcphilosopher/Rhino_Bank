import React from 'react';
import { useSimulation } from '../../simulation/SimulationContext';
import { MetricCard } from '../common/MetricCard';
import { StatusBadge } from '../common/Badge';
import {
  Server,
  Activity,
  Cpu,
  Database,
  Layers,
  HardDrive,
  Wifi,
  ShieldCheck,
  CheckCircle2,
  RefreshCw,
} from 'lucide-react';

export const SystemOperationsView: React.FC = () => {
  const { institutions } = useSimulation();

  return (
    <div className="space-y-4 p-5 max-w-[1600px] mx-auto font-mono-num">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <Server className="w-5 h-5 text-sky-400" />
            <h2 className="text-base font-bold text-slate-100">
              CBDC 中核システム運用・監視センター (NOC / SOC)
            </h2>
            <span className="text-xs bg-slate-800 text-slate-300 border border-slate-700 px-2 py-0.5 rounded">
              可用性: 99.999% (SLA達成)
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            中核コンセンサスエンジン・メッセージキュー(MQ)・分散台帳DB・APIゲートウェイのインフラヘルスモニタ
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs text-emerald-400">
          <CheckCircle2 className="w-4 h-4" />
          <span>全サブシステム正常稼働中</span>
        </div>
      </div>

      {/* Cluster Node Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <MetricCard
          title="中核台帳 CPU使用率"
          value="18.4%"
          subLabel="32コア / 64スレッド"
          subValue="負荷平準化正常"
          change="安定"
          changeType="positive"
        />
        <MetricCard
          title="台帳インメモリDB使用量"
          value="42.8 GB"
          subLabel="総容量 256 GB"
          subValue="使用率 16.7%"
          change="余裕有"
          changeType="positive"
        />
        <MetricCard
          title="メッセージキュー (MQ) 滞留"
          value="0 件"
          subLabel="平均消費速度"
          subValue="24,000 msg/s"
          change="滞留ゼロ"
          changeType="positive"
        />
        <MetricCard
          title="平均エンドツーエンド遅延"
          value="14.2 ms"
          subLabel="99パーセンタイル"
          subValue="28.4 ms"
          change="超高速"
          changeType="positive"
        />
      </div>

      {/* Cluster Node Statuses Table */}
      <div className="bg-slate-900 border border-slate-800 rounded p-4">
        <h3 className="text-sm font-bold text-slate-100 pb-3 mb-3 border-b border-slate-800 flex items-center gap-2">
          <HardDrive className="w-4 h-4 text-emerald-400" />
          <span>中核クラスタ ノード稼働マトリクス</span>
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="text-slate-400 border-b border-slate-800 bg-slate-950/60">
                <th className="py-2.5 px-2.5 font-medium">ノード識別子</th>
                <th className="py-2.5 px-2.5 font-medium">役割 (Role)</th>
                <th className="py-2.5 px-2.5 font-medium">所在データセンター</th>
                <th className="py-2.5 px-2.5 font-medium text-right">CPU</th>
                <th className="py-2.5 px-2.5 font-medium text-right">メモリ</th>
                <th className="py-2.5 px-2.5 font-medium text-right">QPS / TPS</th>
                <th className="py-2.5 px-2.5 font-medium text-center">ヘルス状態</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {[
                { id: 'NODE-BOJ-CORE-01', role: '中核台帳コンセンサス (Primary)', dc: '東京 (中央データセンター)', cpu: '21%', mem: '48.2GB', qps: '14,200', status: '正常' },
                { id: 'NODE-BOJ-CORE-02', role: '中核台帳コンセンサス (Secondary)', dc: '大阪 (副データセンター)', cpu: '19%', mem: '47.9GB', qps: '14,198', status: '正常' },
                { id: 'NODE-BOJ-CORE-03', role: '中核台帳コンセンサス (Arbiter)', dc: '名古屋 (第三照合センター)', cpu: '14%', mem: '32.1GB', qps: '14,200', status: '正常' },
                { id: 'NODE-BOJ-CLEAR-01', role: 'RTGS即時清算エンジン', dc: '東京 (中央データセンター)', cpu: '28%', mem: '64.0GB', qps: '8,400', status: '正常' },
                { id: 'NODE-BOJ-AML-01', role: 'リアルタイム不正検知 (AI/Rule)', dc: '東京 (中央データセンター)', cpu: '34%', mem: '58.4GB', qps: '18,400', status: '正常' },
                { id: 'NODE-BOJ-GW-01', role: '金融機関接続API-GW (Edge)', dc: '東京・大阪 分散', cpu: '16%', mem: '24.2GB', qps: '24,800', status: '正常' },
              ].map((node) => (
                <tr key={node.id} className="hover:bg-slate-800/40">
                  <td className="py-2.5 px-2.5 font-bold text-slate-200">{node.id}</td>
                  <td className="py-2.5 px-2.5 text-slate-300">{node.role}</td>
                  <td className="py-2.5 px-2.5 text-slate-400">{node.dc}</td>
                  <td className="py-2.5 px-2.5 text-right text-slate-200">{node.cpu}</td>
                  <td className="py-2.5 px-2.5 text-right text-slate-200">{node.mem}</td>
                  <td className="py-2.5 px-2.5 text-right font-bold text-sky-400">{node.qps}</td>
                  <td className="py-2.5 px-2.5 text-center">
                    <StatusBadge status={node.status as any} size="sm" />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
