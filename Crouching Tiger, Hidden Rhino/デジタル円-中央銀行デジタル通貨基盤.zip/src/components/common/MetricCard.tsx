import React from 'react';

interface MetricCardProps {
  id?: string;
  title: string;
  value: string | number;
  unit?: string;
  subValue?: string;
  subLabel?: string;
  change?: string;
  changeType?: 'positive' | 'negative' | 'neutral' | 'alert';
  isMonospace?: boolean;
  statusIndicator?: 'normal' | 'caution' | 'alert';
  actionButton?: React.ReactNode;
}

export const MetricCard: React.FC<MetricCardProps> = ({
  id,
  title,
  value,
  unit,
  subValue,
  subLabel,
  change,
  changeType = 'neutral',
  isMonospace = true,
  statusIndicator,
  actionButton,
}) => {
  return (
    <div
      id={id}
      className="bg-slate-900/90 border border-slate-800 p-4 rounded relative overflow-hidden transition-all hover:border-slate-700"
    >
      <div className="flex items-center justify-between gap-2 mb-1.5">
        <div className="flex items-center gap-2">
          {statusIndicator && (
            <span
              className={`inline-block w-2 h-2 rounded-full ${
                statusIndicator === 'normal'
                  ? 'bg-emerald-500 shadow-sm shadow-emerald-500/50'
                  : statusIndicator === 'caution'
                  ? 'bg-amber-500 animate-pulse'
                  : 'bg-rose-500 animate-ping'
              }`}
            />
          )}
          <span className="text-xs text-slate-400 font-medium tracking-wide">
            {title}
          </span>
        </div>
        <span className="text-[10px] text-slate-500 bg-slate-800/80 px-1.5 py-0.5 rounded border border-slate-700/50 font-mono-num">
          模擬データ
        </span>
      </div>

      <div className="flex items-baseline justify-between gap-2 mt-1">
        <div className="flex items-baseline gap-1.5">
          <span
            className={`text-xl font-bold tracking-tight text-slate-100 ${
              isMonospace ? 'font-mono-num' : ''
            }`}
          >
            {typeof value === 'number' ? value.toLocaleString() : value}
          </span>
          {unit && <span className="text-xs text-slate-400">{unit}</span>}
        </div>
        {actionButton}
      </div>

      {(subValue || subLabel || change) && (
        <div className="flex items-center justify-between text-xs text-slate-400 pt-2.5 mt-2 border-t border-slate-800/80 font-mono-num">
          <div className="flex items-center gap-1.5 truncate">
            {subLabel && <span className="text-slate-500">{subLabel}:</span>}
            {subValue && <span className="text-slate-300 truncate">{subValue}</span>}
          </div>
          {change && (
            <span
              className={`text-[11px] font-medium px-1.5 py-0.5 rounded ${
                changeType === 'positive'
                  ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800/50'
                  : changeType === 'negative'
                  ? 'bg-rose-950/60 text-rose-400 border border-rose-800/50'
                  : changeType === 'alert'
                  ? 'bg-amber-950/60 text-amber-400 border border-amber-800/50'
                  : 'bg-slate-800 text-slate-400'
              }`}
            >
              {change}
            </span>
          )}
        </div>
      )}
    </div>
  );
};
