import React from 'react';

interface BadgeProps {
  status: string;
  type?: 'status' | 'method' | 'category' | 'risk' | 'severity';
  size?: 'sm' | 'md';
}

export const StatusBadge: React.FC<BadgeProps> = ({ status, type = 'status', size = 'sm' }) => {
  const sizeClass = size === 'sm' ? 'text-[11px] px-2 py-0.5' : 'text-xs px-2.5 py-1';

  let colorClass = 'bg-slate-800 text-slate-300 border-slate-700';

  // Status mappings
  if (['正常', '完了', '清算済', '認証済', '正常稼働', '成功', '承認済'].includes(status)) {
    colorClass = 'bg-emerald-950/70 text-emerald-300 border-emerald-800/60';
  } else if (['処理中', '照合中', '検証中', '高負荷', '確認中', '簡易確認'].includes(status)) {
    colorClass = 'bg-sky-950/70 text-sky-300 border-sky-800/60';
  } else if (['受付', '受付待ち', '条件待機中', '保留', '注意', '要再確認', '監視対象', '中'].includes(status)) {
    colorClass = 'bg-amber-950/70 text-amber-300 border-amber-800/60';
  } else if (['拒否', '異常', '障害', '利用停止', '凍結措置', '高', '緊急', '重大', 'エラー'].includes(status)) {
    colorClass = 'bg-rose-950/70 text-rose-300 border-rose-800/60 font-semibold';
  } else if (['メンテナンス', '縮退稼働', '制限中', '情報'].includes(status)) {
    colorClass = 'bg-slate-800 text-slate-400 border-slate-700';
  }

  return (
    <span
      className={`inline-flex items-center gap-1 rounded border font-medium whitespace-nowrap font-mono-num ${sizeClass} ${colorClass}`}
    >
      <span className="inline-block w-1.5 h-1.5 rounded-full bg-current opacity-80" />
      {status}
    </span>
  );
};
