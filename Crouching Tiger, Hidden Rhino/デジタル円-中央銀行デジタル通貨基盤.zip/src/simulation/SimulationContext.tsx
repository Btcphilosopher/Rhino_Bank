import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import {
  Wallet,
  Institution,
  Transaction,
  IssuanceRecord,
  ClearingQueueItem,
  ProgrammablePayment,
  OfflineSession,
  RiskAlert,
  AuditLog,
  RegionalData,
  MacroeconomicModel,
  SystemService,
  PaymentMethod,
  IssuanceType,
} from '../types';
import {
  INITIAL_INSTITUTIONS,
  INITIAL_WALLETS,
  INITIAL_TRANSACTIONS,
  INITIAL_ISSUANCE_RECORDS,
  INITIAL_CLEARING_QUEUE,
  INITIAL_PROGRAMMABLE_PAYMENTS,
  INITIAL_RISK_ALERTS,
  INITIAL_AUDIT_LOGS,
  REGIONAL_DATA,
  INITIAL_SYSTEM_SERVICES,
} from '../data/seedData';

interface SimulationContextType {
  // Data state
  wallets: Wallet[];
  institutions: Institution[];
  transactions: Transaction[];
  issuanceRecords: IssuanceRecord[];
  clearingQueue: ClearingQueueItem[];
  programmablePayments: ProgrammablePayment[];
  riskAlerts: RiskAlert[];
  auditLogs: AuditLog[];
  regionalData: RegionalData[];
  systemServices: SystemService[];
  macroModel: MacroeconomicModel;
  
  // Computed National Metrics
  totalCirculation: number;
  totalWalletsCount: number;
  activeWalletsCount: number;
  todayTxCount: number;
  todayTxAmount: number;
  realtimeSettlementVolume: number;
  clearingProcessedAmount: number;
  offlineTxCount: number;
  interbankTxCount: number;
  abnormalTxCount: number;

  // Actions
  executePayment: (params: {
    sourceWalletId: string;
    destWalletId: string;
    amount: number;
    paymentMethod: PaymentMethod;
    purpose: string;
  }) => Promise<{ success: boolean; transaction?: Transaction; error?: string }>;

  issueDigitalYen: (params: {
    type: IssuanceType;
    targetBankId: string;
    amount: number;
    reason: string;
    remarks: string;
    operator: string;
  }) => { success: boolean; record?: IssuanceRecord; error?: string };

  processClearingItem: (queueId: string) => void;
  processAllClearing: () => void;

  toggleWalletStatus: (walletId: string, status: Wallet['status']) => void;

  executeProgrammablePayment: (id: string) => { success: boolean; message: string };
  toggleProgrammableCondition: (id: string) => void;
  createProgrammablePayment: (params: Omit<ProgrammablePayment, 'id' | 'status' | 'conditionMet'>) => void;

  resolveRiskAlert: (alertId: string, action: RiskAlert['status']) => void;

  setSimulationSpeed: (speed: 1 | 10 | 100) => void;
  toggleSimulationRunning: () => void;
  updateMacroeconomicParams: (params: Partial<MacroeconomicModel>) => void;
  resetSimulationData: () => void;

  // Offline Simulation State & Actions
  offlineSession: OfflineSession;
  advanceOfflineStep: () => void;
  resetOfflineSession: (withDoubleSpend?: boolean) => void;
}

const defaultOfflineSession: OfflineSession = {
  id: 'OFF-SES-2026-0041',
  sourceDevice: 'スマート端末A (SEチップ: SE-JP-08819)',
  sourceWalletId: 'WLT-JP-8829-0012',
  destDevice: '加盟店端末B (SEチップ: SE-JP-99412)',
  destWalletId: 'WLT-MER-7712-4091',
  amount: 4500,
  nonce: '0x99a4c17e3f89b012',
  secureElementSignature: 'ECDSA_SE_P256:7f4a9b2184c90d81e3a6...[VERIFIED]',
  timestamp: new Date().toISOString(),
  currentState: '1_通信切断',
  doubleSpendDetected: false,
  notes: '基地局途絶・大規模災害想定オフラインP2P決済プロトコル',
};

const SimulationContext = createContext<SimulationContextType | undefined>(undefined);

export const SimulationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [wallets, setWallets] = useState<Wallet[]>(INITIAL_WALLETS);
  const [institutions, setInstitutions] = useState<Institution[]>(INITIAL_INSTITUTIONS);
  const [transactions, setTransactions] = useState<Transaction[]>(INITIAL_TRANSACTIONS);
  const [issuanceRecords, setIssuanceRecords] = useState<IssuanceRecord[]>(INITIAL_ISSUANCE_RECORDS);
  const [clearingQueue, setClearingQueue] = useState<ClearingQueueItem[]>(INITIAL_CLEARING_QUEUE);
  const [programmablePayments, setProgrammablePayments] = useState<ProgrammablePayment[]>(INITIAL_PROGRAMMABLE_PAYMENTS);
  const [riskAlerts, setRiskAlerts] = useState<RiskAlert[]>(INITIAL_RISK_ALERTS);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(INITIAL_AUDIT_LOGS);
  const [regionalData, setRegionalData] = useState<RegionalData[]>(REGIONAL_DATA);
  const [systemServices, setSystemServices] = useState<SystemService[]>(INITIAL_SYSTEM_SERVICES);
  const [offlineSession, setOfflineSession] = useState<OfflineSession>(defaultOfflineSession);

  const [macroModel, setMacroModel] = useState<MacroeconomicModel>({
    moneySupply: 18492700000000,
    txFrequency: 4200,
    settlementVelocity: 14,
    walletAdoptionRate: 68.4,
    interbankDemandRatio: 24.5,
    liquidityDemandBuffer: 4800,
    cashSubstitutionRate: 41.2,
    bankDepositMigrationRate: 12.8,
    simulationSpeed: 1,
    isRunning: true,
  });

  // Helper for generating SHA-256 style hash
  const generateSimulatedHash = (input: string) => {
    let hash = 0;
    for (let i = 0; i < input.length; i++) {
      hash = (hash << 5) - hash + input.charCodeAt(i);
      hash |= 0;
    }
    const hex = Math.abs(hash).toString(16).padStart(8, '0');
    return `0x${hex}${Math.random().toString(16).substring(2, 10)}${Math.random().toString(16).substring(2, 10)}`;
  };

  const addAuditLog = useCallback((operator: string, institution: string, action: string, target: string, outcome: AuditLog['outcome'], severity: AuditLog['severity']) => {
    const now = new Date();
    const timeStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
    const newLog: AuditLog = {
      id: `AUD-${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}-${Math.floor(1000 + Math.random() * 9000)}`,
      timestamp: timeStr,
      operator,
      institution,
      action,
      target,
      outcome,
      severity,
      hash: generateSimulatedHash(`${timeStr}-${action}-${target}`),
    };
    setAuditLogs((prev) => [newLog, ...prev.slice(0, 99)]);
  }, []);

  // Compute National Metrics
  const totalCirculation = useMemo(() => {
    return institutions.reduce((acc, inst) => acc + inst.cbdcBalance, 0);
  }, [institutions]);

  const totalWalletsCount = useMemo(() => {
    return institutions.reduce((acc, inst) => acc + inst.walletCount, 0);
  }, [institutions]);

  const activeWalletsCount = useMemo(() => {
    return Math.floor(totalWalletsCount * (macroModel.walletAdoptionRate / 100));
  }, [totalWalletsCount, macroModel.walletAdoptionRate]);

  const todayTxCount = useMemo(() => {
    return institutions.reduce((acc, inst) => acc + inst.todayTxCount, 0);
  }, [institutions]);

  const todayTxAmount = useMemo(() => {
    return institutions.reduce((acc, inst) => acc + inst.todayTxVolume, 0);
  }, [institutions]);

  const realtimeSettlementVolume = useMemo(() => {
    return 8293104000 + transactions.reduce((acc, t) => acc + (t.status === '完了' || t.status === '清算済' ? t.amount : 0), 0);
  }, [transactions]);

  const clearingProcessedAmount = useMemo(() => {
    return institutions.reduce((acc, inst) => acc + inst.clearingBalance, 0);
  }, [institutions]);

  const offlineTxCount = useMemo(() => {
    return transactions.filter((t) => t.paymentMethod === 'オフライン決済' || t.isOfflineSynced).length + 4128;
  }, [transactions]);

  const interbankTxCount = useMemo(() => {
    return 48920 + clearingQueue.length;
  }, [clearingQueue]);

  const abnormalTxCount = useMemo(() => {
    return riskAlerts.filter((r) => r.status === '確認待ち' || r.status === '調査中').length;
  }, [riskAlerts]);

  // Execute Payment
  const executePayment = useCallback(
    async (params: {
      sourceWalletId: string;
      destWalletId: string;
      amount: number;
      paymentMethod: PaymentMethod;
      purpose: string;
    }): Promise<{ success: boolean; transaction?: Transaction; error?: string }> => {
      const source = wallets.find((w) => w.id === params.sourceWalletId);
      const dest = wallets.find((w) => w.id === params.destWalletId);

      if (!source) return { success: false, error: '送金元ウォレットが見つかりません。' };
      if (!dest) return { success: false, error: '送金先ウォレットが見つかりません。' };
      if (source.status === '利用停止' || source.status === '制限中') {
        return { success: false, error: `送金元ウォレットは現在「${source.status}」のため取引できません。` };
      }
      if (dest.status === '利用停止') {
        return { success: false, error: '送金先ウォレットが利用停止状態です。' };
      }
      if (source.availableBalance < params.amount) {
        return { success: false, error: `残高不足です（利用可能残高: ¥${source.availableBalance.toLocaleString()} / 送金指定額: ¥${params.amount.toLocaleString()}）。` };
      }

      // Check Risk Engine
      let isRiskTriggered = false;
      if (params.amount >= 10000000) {
        isRiskTriggered = true;
      }

      const now = new Date();
      const timeStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
      const txnId = `TXN-${Math.floor(8839200 + Math.random() * 90000)}`;
      const ledgerNum = 84920200 + transactions.length;

      const newTxn: Transaction = {
        id: txnId,
        ledgerNumber: ledgerNum,
        timestamp: timeStr,
        sourceWalletId: source.id,
        sourceName: source.name,
        sourceBank: source.bankName,
        destWalletId: dest.id,
        destName: dest.name,
        destBank: dest.bankName,
        amount: params.amount,
        paymentMethod: params.paymentMethod,
        purpose: params.purpose,
        status: isRiskTriggered ? '保留' : '清算済',
        clearingStatus: isRiskTriggered ? '未清算' : '清算済',
        pipelineStep: isRiskTriggered ? 4 : 6,
        hash: generateSimulatedHash(`${txnId}-${params.amount}-${timeStr}`),
        notes: isRiskTriggered ? '大口取引ルール（¥10,000,000以上）検知による自動保留' : undefined,
      };

      // State updates
      if (!isRiskTriggered) {
        setWallets((prev) =>
          prev.map((w) => {
            if (w.id === source.id) {
              return {
                ...w,
                balance: w.balance - params.amount,
                availableBalance: w.availableBalance - params.amount,
                totalPaid: w.totalPaid + params.amount,
                transactionCount: w.transactionCount + 1,
                lastTransactionAt: timeStr,
              };
            }
            if (w.id === dest.id) {
              return {
                ...w,
                balance: w.balance + params.amount,
                availableBalance: w.availableBalance + params.amount,
                totalDeposited: w.totalDeposited + params.amount,
                transactionCount: w.transactionCount + 1,
                lastTransactionAt: timeStr,
              };
            }
            return w;
          })
        );

        // Update institutions if interbank
        if (source.bankId !== dest.bankId) {
          setInstitutions((prev) =>
            prev.map((inst) => {
              if (inst.id === source.bankId) {
                return {
                  ...inst,
                  todayTxCount: inst.todayTxCount + 1,
                  todayTxVolume: inst.todayTxVolume + params.amount,
                  clearingBalance: inst.clearingBalance + params.amount,
                };
              }
              if (inst.id === dest.bankId) {
                return {
                  ...inst,
                  todayTxCount: inst.todayTxCount + 1,
                  todayTxVolume: inst.todayTxVolume + params.amount,
                };
              }
              return inst;
            })
          );
        }

        addAuditLog(
          `端末決済API (${params.paymentMethod})`,
          source.bankName,
          `デジタル円送金・決済完了 (${source.name} → ${dest.name})`,
          `${txnId} (金額: ¥${params.amount.toLocaleString()})`,
          '成功',
          '情報'
        );
      } else {
        // Create risk alert
        const newRisk: RiskAlert = {
          id: `RSK-2026-${Math.floor(1000 + Math.random() * 9000)}`,
          txnId: newTxn.id,
          timestamp: timeStr,
          reason: `大口取引閾値超過 (指定額: ¥${params.amount.toLocaleString()})`,
          amount: params.amount,
          riskLevel: '高',
          status: '確認待ち',
          targetEntity: `${source.name} (${source.id})`,
          score: 85,
          sourceBank: source.bankName,
        };
        setRiskAlerts((prev) => [newRisk, ...prev]);

        addAuditLog(
          'リスク判定エンジン (RULE-AML-HIGH)',
          '中央銀行CBDCコア',
          `大口決済検知・取引保留処理`,
          `${txnId} (¥${params.amount.toLocaleString()})`,
          '警告',
          '警告'
        );
      }

      setTransactions((prev) => [newTxn, ...prev]);
      return { success: true, transaction: newTxn };
    },
    [wallets, transactions, addAuditLog]
  );

  // Digital Yen Issuance / Redemption
  const issueDigitalYen = useCallback(
    (params: {
      type: IssuanceType;
      targetBankId: string;
      amount: number;
      reason: string;
      remarks: string;
      operator: string;
    }): { success: boolean; record?: IssuanceRecord; error?: string } => {
      const bank = institutions.find((i) => i.id === params.targetBankId);
      if (!bank) return { success: false, error: '対象金融機関が見つかりません。' };
      if (params.amount <= 0) return { success: false, error: '有効な金額を入力してください。' };

      const isDeduction = params.type === '回収' || params.type === '償却';
      if (isDeduction && bank.cbdcBalance < params.amount) {
        return { success: false, error: `回収・償却金額が対象銀行のCBDC保有残高（¥${bank.cbdcBalance.toLocaleString()}）を超過しています。` };
      }

      const now = new Date();
      const timeStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
      const auditNum = `BOJ-CBDC-AUD-${Math.floor(990000 + Math.random() * 9999)}`;
      const preBalance = bank.cbdcBalance;
      const postBalance = isDeduction ? preBalance - params.amount : preBalance + params.amount;

      const record: IssuanceRecord = {
        id: `ISS-${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}-${Math.floor(100 + Math.random() * 900)}`,
        auditNumber: auditNum,
        timestamp: timeStr,
        type: params.type,
        targetBankId: bank.id,
        targetBankName: bank.name,
        amount: params.amount,
        preBalance,
        postBalance,
        status: '完了',
        operator: params.operator,
        reason: params.reason,
        remarks: params.remarks,
      };

      setIssuanceRecords((prev) => [record, ...prev]);

      // Update bank balance
      setInstitutions((prev) =>
        prev.map((inst) => {
          if (inst.id === bank.id) {
            return {
              ...inst,
              cbdcBalance: postBalance,
              liquidityReserve: isDeduction ? inst.liquidityReserve - params.amount : inst.liquidityReserve + params.amount,
            };
          }
          return inst;
        })
      );

      addAuditLog(
        params.operator,
        '日本銀行 業務局 発行清算課',
        `デジタル円${params.type}執行 (${bank.name})`,
        `${auditNum} (金額: ¥${params.amount.toLocaleString()})`,
        '成功',
        '情報'
      );

      return { success: true, record };
    },
    [institutions, addAuditLog]
  );

  // Clearing queue actions
  const processClearingItem = useCallback(
    (queueId: string) => {
      setClearingQueue((prev) =>
        prev.map((item) => {
          if (item.id === queueId) {
            return { ...item, status: '清算済' };
          }
          return item;
        })
      );

      addAuditLog(
        '清算センター自動スケジューラ',
        '中央銀行CBDC決済機構',
        `個別銀行間決済清算完了`,
        queueId,
        '成功',
        '情報'
      );
    },
    [addAuditLog]
  );

  const processAllClearing = useCallback(() => {
    setClearingQueue((prev) =>
      prev.map((item) => ({ ...item, status: '清算済' }))
    );

    addAuditLog(
      '清算センター自動バッチ',
      '中央銀行CBDC決済機構',
      `待機中全件一斉ネット清算執行 (DNS相殺)`,
      `対象件数: ${clearingQueue.filter((q) => q.status !== '清算済').length}件`,
      '成功',
      '情報'
    );
  }, [clearingQueue, addAuditLog]);

  // Wallet Management Actions
  const toggleWalletStatus = useCallback(
    (walletId: string, status: Wallet['status']) => {
      setWallets((prev) =>
        prev.map((w) => {
          if (w.id === walletId) {
            return { ...w, status };
          }
          return w;
        })
      );

      addAuditLog(
        '監督当局・金融機関管理者 (WLT-ADMIN-01)',
        '監督機構コンプライアンス課',
        `ウォレット利用状態変更 [${status}]`,
        walletId,
        '成功',
        status === '正常' ? '情報' : '警告'
      );
    },
    [addAuditLog]
  );

  // Programmable Payments
  const executeProgrammablePayment = useCallback(
    (id: string): { success: boolean; message: string } => {
      const prg = programmablePayments.find((p) => p.id === id);
      if (!prg) return { success: false, message: 'プログラマブル決済指示が見つかりません。' };
      if (!prg.conditionMet) {
        return { success: false, message: '条件が充足されていません。トリガー条件を確認してください。' };
      }

      // Execute payment
      executePayment({
        sourceWalletId: prg.senderWalletId,
        destWalletId: prg.receiverWalletId,
        amount: prg.amount,
        paymentMethod: 'API決済',
        purpose: `[プログラマブル執行] ${prg.title}`,
      });

      const now = new Date();
      const timeStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;

      setProgrammablePayments((prev) =>
        prev.map((p) => {
          if (p.id === id) {
            return { ...p, status: '実行完了', executedAt: timeStr };
          }
          return p;
        })
      );

      addAuditLog(
        'スマート指示執行エンジン (PRG-EXEC-01)',
        '中央銀行CBDCコア',
        `プログラマブル決済自動執行 (${prg.title})`,
        `${prg.id} (¥${prg.amount.toLocaleString()})`,
        '成功',
        '情報'
      );

      return { success: true, message: `プログラマブル決済「${prg.title}」の執行が完了しました。` };
    },
    [programmablePayments, executePayment, addAuditLog]
  );

  const toggleProgrammableCondition = useCallback((id: string) => {
    setProgrammablePayments((prev) =>
      prev.map((p) => {
        if (p.id === id) {
          const nextMet = !p.conditionMet;
          return {
            ...p,
            conditionMet: nextMet,
            status: nextMet ? '検証中' : '条件待機中',
          };
        }
        return p;
      })
    );
  }, []);

  const createProgrammablePayment = useCallback(
    (params: Omit<ProgrammablePayment, 'id' | 'status' | 'conditionMet'>) => {
      const newPrg: ProgrammablePayment = {
        ...params,
        id: `PRG-2026-${Math.floor(8800 + Math.random() * 900)}`,
        status: '条件待機中',
        conditionMet: false,
      };
      setProgrammablePayments((prev) => [newPrg, ...prev]);

      addAuditLog(
        '企業APIゲートウェイ',
        params.senderName,
        `条件付きプログラマブル決済指示新規登録`,
        `${newPrg.id} (金額: ¥${params.amount.toLocaleString()})`,
        '成功',
        '情報'
      );
    },
    [addAuditLog]
  );

  // Risk Management
  const resolveRiskAlert = useCallback(
    (alertId: string, action: RiskAlert['status']) => {
      setRiskAlerts((prev) =>
        prev.map((r) => {
          if (r.id === alertId) {
            return { ...r, status: action };
          }
          return r;
        })
      );

      // If approved or cleared, update associated transaction
      const targetAlert = riskAlerts.find((r) => r.id === alertId);
      if (targetAlert && action === '承認済') {
        setTransactions((prev) =>
          prev.map((t) => {
            if (t.id === targetAlert.txnId) {
              return {
                ...t,
                status: '清算済',
                clearingStatus: '清算済',
                pipelineStep: 6,
                notes: 'コンプライアンス管理者による審査承認完了',
              };
            }
            return t;
          })
        );
      } else if (targetAlert && action === '凍結措置') {
        setTransactions((prev) =>
          prev.map((t) => {
            if (t.id === targetAlert.txnId) {
              return {
                ...t,
                status: '異常',
                notes: '不正疑惑により取引凍結・口座調査中',
              };
            }
            return t;
          })
        );
      }

      addAuditLog(
        'AML審査官 (AML-OFFICER-02)',
        '中央銀行コンプライアンス局',
        `リスクアラート措置更新 [${action}]`,
        alertId,
        '成功',
        action === '凍結措置' ? '重大' : '情報'
      );
    },
    [riskAlerts, addAuditLog]
  );

  // Offline Simulation State Machine
  const advanceOfflineStep = useCallback(() => {
    setOfflineSession((prev) => {
      const states: OfflineSession['currentState'][] = [
        '1_通信切断',
        '2_セキュアエレメント検証',
        '3_端末間取引実行',
        '4_一時保存',
        '5_通信復旧待機',
        '6_同期処理',
        '7_二重使用検知・照合',
        '8_最終清算完了',
      ];
      const currentIndex = states.indexOf(prev.currentState);
      if (currentIndex < states.length - 1) {
        const nextState = states[currentIndex + 1];
        
        // If reaching final step, apply balance change
        if (nextState === '8_最終清算完了' && !prev.doubleSpendDetected) {
          executePayment({
            sourceWalletId: prev.sourceWalletId,
            destWalletId: prev.destWalletId,
            amount: prev.amount,
            paymentMethod: 'オフライン決済',
            purpose: '基地局途絶時セキュアエレメント二者間オフライン決済 (同期清算完了)',
          });
        }

        return {
          ...prev,
          currentState: nextState,
          notes:
            nextState === '7_二重使用検知・照合' && prev.doubleSpendDetected
              ? '【警告】暗号学的署名検証およびローカルカウンター照合により「二重使用」が検知されました。台帳更新を阻止します。'
              : prev.notes,
        };
      }
      return prev;
    });
  }, [executePayment]);

  const resetOfflineSession = useCallback((withDoubleSpend = false) => {
    setOfflineSession({
      ...defaultOfflineSession,
      timestamp: new Date().toISOString(),
      doubleSpendDetected: withDoubleSpend,
      currentState: '1_通信切断',
      notes: withDoubleSpend
        ? '【模擬二重使用シナリオ】同一セキュアエレメントの暗号署名を複数端末で不正複製したケースをテストします。'
        : '基地局途絶・大規模災害想定オフラインP2P決済プロトコル',
    });
  }, []);

  // Macroeconomic and System controls
  const setSimulationSpeed = useCallback((speed: 1 | 10 | 100) => {
    setMacroModel((prev) => ({ ...prev, simulationSpeed: speed }));
  }, []);

  const toggleSimulationRunning = useCallback(() => {
    setMacroModel((prev) => ({ ...prev, isRunning: !prev.isRunning }));
  }, []);

  const updateMacroeconomicParams = useCallback((params: Partial<MacroeconomicModel>) => {
    setMacroModel((prev) => ({ ...prev, ...params }));
  }, []);

  const resetSimulationData = useCallback(() => {
    setWallets(INITIAL_WALLETS);
    setInstitutions(INITIAL_INSTITUTIONS);
    setTransactions(INITIAL_TRANSACTIONS);
    setIssuanceRecords(INITIAL_ISSUANCE_RECORDS);
    setClearingQueue(INITIAL_CLEARING_QUEUE);
    setProgrammablePayments(INITIAL_PROGRAMMABLE_PAYMENTS);
    setRiskAlerts(INITIAL_RISK_ALERTS);
    setAuditLogs(INITIAL_AUDIT_LOGS);
    setRegionalData(REGIONAL_DATA);
    setSystemServices(INITIAL_SYSTEM_SERVICES);
    setOfflineSession(defaultOfflineSession);
  }, []);

  // Continuous background simulation tick (realistic banking background micro-settlements)
  useEffect(() => {
    if (!macroModel.isRunning) return;

    const intervalMs = Math.max(100, 2000 / macroModel.simulationSpeed);

    const timer = setInterval(() => {
      // Micro increment of transaction stats and fluctuating server metrics
      setInstitutions((prev) =>
        prev.map((inst) => {
          const deltaTx = Math.floor(Math.random() * 3 * macroModel.simulationSpeed) + 1;
          const deltaAmt = deltaTx * (Math.floor(Math.random() * 4000) + 400);
          return {
            ...inst,
            todayTxCount: inst.todayTxCount + deltaTx,
            todayTxVolume: inst.todayTxVolume + deltaAmt,
            latencyMs: Math.max(5, Math.min(80, inst.latencyMs + (Math.floor(Math.random() * 5) - 2))),
            apiRequestsToday: inst.apiRequestsToday + deltaTx * 4,
          };
        })
      );

      setSystemServices((prev) =>
        prev.map((svc) => ({
          ...svc,
          cpuPercent: Math.max(15, Math.min(85, svc.cpuPercent + (Math.floor(Math.random() * 5) - 2))),
          throughputQps: Math.max(1000, svc.throughputQps + (Math.floor(Math.random() * 100) - 45)),
        }))
      );
    }, intervalMs);

    return () => clearInterval(timer);
  }, [macroModel.isRunning, macroModel.simulationSpeed]);

  return (
    <SimulationContext.Provider
      value={{
        wallets,
        institutions,
        transactions,
        issuanceRecords,
        clearingQueue,
        programmablePayments,
        riskAlerts,
        auditLogs,
        regionalData,
        systemServices,
        macroModel,
        totalCirculation,
        totalWalletsCount,
        activeWalletsCount,
        todayTxCount,
        todayTxAmount,
        realtimeSettlementVolume,
        clearingProcessedAmount,
        offlineTxCount,
        interbankTxCount,
        abnormalTxCount,
        executePayment,
        issueDigitalYen,
        processClearingItem,
        processAllClearing,
        toggleWalletStatus,
        executeProgrammablePayment,
        toggleProgrammableCondition,
        createProgrammablePayment,
        resolveRiskAlert,
        setSimulationSpeed,
        toggleSimulationRunning,
        updateMacroeconomicParams,
        resetSimulationData,
        offlineSession,
        advanceOfflineStep,
        resetOfflineSession,
      }}
    >
      {children}
    </SimulationContext.Provider>
  );
};

export const useSimulation = () => {
  const context = useContext(SimulationContext);
  if (!context) {
    throw new Error('useSimulation must be used within a SimulationProvider');
  }
  return context;
};
