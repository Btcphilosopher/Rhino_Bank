/**
 * デジタル円 中央銀行デジタル通貨基盤 (DIGITAL YEN CBDC INFRASTRUCTURE)
 * 型定義一覧
 */

export type NavigationItemKey =
  | 'dashboard'
  | 'issuance'
  | 'circulation'
  | 'wallets'
  | 'institutions'
  | 'payment_processing'
  | 'clearing_settlement'
  | 'interbank'
  | 'offline_payment'
  | 'programmable_payments'
  | 'liquidity_management'
  | 'risk_management'
  | 'audit_logs'
  | 'regional_analytics'
  | 'economic_simulation'
  | 'system_architecture'
  | 'system_operations'
  | 'ledger';

export type WalletCategory =
  | '個人ウォレット'
  | '企業ウォレット'
  | '加盟店ウォレット'
  | '金融機関ウォレット'
  | '法人決済ウォレット';

export type KycStatus = '認証済' | '確認中' | '要再確認' | '簡易確認';
export type WalletStatus = '正常' | '利用停止' | '監視対象' | '制限中';
export type RiskTier = '低' | '中' | '高' | '最重要監視';

export interface Wallet {
  id: string;
  name: string;
  category: WalletCategory;
  bankId: string;
  bankName: string;
  balance: number;
  availableBalance: number;
  heldAmount: number;
  totalDeposited: number;
  totalPaid: number;
  transactionCount: number;
  kycStatus: KycStatus;
  status: WalletStatus;
  riskTier: RiskTier;
  lastTransactionAt: string;
  region: string;
  accountNumber: string;
}

export type InstitutionType =
  | '都市銀行'
  | '地方銀行'
  | '信託銀行'
  | '資金移動業者'
  | 'デジタル特化銀行';

export type ApiStatus = '正常' | '注意' | '障害' | 'メンテナンス';

export interface Institution {
  id: string;
  name: string;
  code: string;
  type: InstitutionType;
  cbdcBalance: number;
  walletCount: number;
  todayTxCount: number;
  todayTxVolume: number;
  clearingBalance: number;
  liquidityReserve: number;
  requiredReserve: number;
  liquidityRatio: number;
  apiStatus: ApiStatus;
  latencyMs: number;
  errorRate: number;
  abnormalCount: number;
  apiRequestsToday: number;
  lastHeartbeat: string;
  systemNode: string;
}

export type PaymentMethod =
  | 'QRコード'
  | 'NFC'
  | 'スマートフォン'
  | 'カード型デバイス'
  | 'ウォレット間送金'
  | 'API決済'
  | 'オフライン決済';

export type TransactionStatus =
  | '受付'
  | '処理中'
  | '承認'
  | '完了'
  | '清算済'
  | '拒否'
  | '保留'
  | '異常';

export type ClearingStatus = '未清算' | '照合中' | '清算済' | '相殺処理' | '繰延';

export interface Transaction {
  id: string;
  ledgerNumber: number;
  timestamp: string;
  sourceWalletId: string;
  sourceName: string;
  sourceBank: string;
  destWalletId: string;
  destName: string;
  destBank: string;
  amount: number;
  paymentMethod: PaymentMethod;
  purpose: string;
  status: TransactionStatus;
  clearingStatus: ClearingStatus;
  pipelineStep: number; // 1: 受付, 2: 検証, 3: 残高確認, 4: リスク確認, 5: 清算, 6: 台帳更新完了
  hash: string;
  isOfflineSynced?: boolean;
  notes?: string;
}

export type IssuanceType =
  | '新規発行'
  | '追加発行'
  | '回収'
  | '償却'
  | '準備預金振替';

export interface IssuanceRecord {
  id: string;
  auditNumber: string;
  timestamp: string;
  type: IssuanceType;
  targetBankId: string;
  targetBankName: string;
  amount: number;
  preBalance: number;
  postBalance: number;
  status: '完了' | '承認待ち' | '処理中' | '取消';
  operator: string;
  reason: string;
  remarks: string;
}

export interface ClearingQueueItem {
  id: string;
  txnId: string;
  sourceBank: string;
  destBank: string;
  amount: number;
  queuedAt: string;
  processingTimeMs: number;
  status: '受付待ち' | '処理中' | '照合中' | '清算済' | '保留' | 'エラー';
  settlementMode: 'RTGS (即時グロス決済)' | 'DNS (時点ネット決済)';
}

export interface ProgrammablePayment {
  id: string;
  title: string;
  senderName: string;
  senderWalletId: string;
  receiverName: string;
  receiverWalletId: string;
  amount: number;
  category: '給与支払' | '企業間決済' | 'サプライチェーン決済' | '補助金支払シミュレーション' | '請求書決済' | '定期支払';
  condition: string;
  conditionMet: boolean;
  status: '条件待機中' | '検証中' | '実行完了' | '期限切れ' | '取消';
  invoiceNumber?: string;
  validUntil: string;
  purpose: string;
  executedAt?: string;
}

export interface OfflineSession {
  id: string;
  sourceDevice: string;
  sourceWalletId: string;
  destDevice: string;
  destWalletId: string;
  amount: number;
  nonce: string;
  secureElementSignature: string;
  timestamp: string;
  currentState: 
    | '1_通信切断'
    | '2_セキュアエレメント検証'
    | '3_端末間取引実行'
    | '4_一時保存'
    | '5_通信復旧待機'
    | '6_同期処理'
    | '7_二重使用検知・照合'
    | '8_最終清算完了';
  doubleSpendDetected: boolean;
  notes: string;
}

export interface RiskAlert {
  id: string;
  txnId: string;
  timestamp: string;
  reason: string;
  amount: number;
  riskLevel: '低' | '中' | '高' | '緊急';
  status: '確認待ち' | '調査中' | '承認済' | '凍結措置' | '誤検知解除';
  targetEntity: string;
  score: number;
  sourceBank: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  operator: string;
  institution: string;
  action: string;
  target: string;
  outcome: '成功' | '警告' | '拒否' | '例外';
  severity: '情報' | '注意' | '警告' | '重大';
  hash: string;
}

export interface RegionalData {
  id: string;
  name: string;
  nameKana: string;
  txCount: number;
  txAmount: number;
  walletCount: number;
  merchantCount: number;
  clearingAmount: number;
  sharePercentage: number;
  growthRate: number;
}

export interface MacroeconomicModel {
  moneySupply: number; // デジタル円流通量 (e.g. 18.5兆円)
  txFrequency: number; // 取引頻度 (件/秒)
  settlementVelocity: number; // 決済速度 (ms)
  walletAdoptionRate: number; // ウォレット利用率 (%)
  interbankDemandRatio: number; // 銀行間決済需要 (%)
  liquidityDemandBuffer: number; // 流動性需要バッファ (億円)
  cashSubstitutionRate: number; // 現金代替率 (%)
  bankDepositMigrationRate: number; // 銀行預金移動率 (%)
  simulationSpeed: 1 | 10 | 100;
  isRunning: boolean;
}

export interface SystemService {
  name: string;
  category: '中核基盤' | '決済・清算' | '周辺サービス' | 'セキュリティ・監査';
  status: '正常稼働' | '高負荷' | '縮退稼働' | '点検中';
  latencyMs: number;
  throughputQps: number;
  errorRate: number;
  cpuPercent: number;
  memPercent: number;
  lastHeartbeat: string;
}
