import React, { useState } from 'react';
import { SimulationProvider } from './simulation/SimulationContext';
import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';
import { StatusBar } from './components/layout/StatusBar';
import { NavigationItemKey } from './types';

// Views
import { DashboardView } from './components/views/DashboardView';
import { IssuanceView } from './components/views/IssuanceView';
import { CirculationView } from './components/views/CirculationView';
import { WalletManagementView } from './components/views/WalletManagementView';
import { InstitutionsView } from './components/views/InstitutionsView';
import { PaymentProcessingView } from './components/views/PaymentProcessingView';
import { ClearingSettlementView } from './components/views/ClearingSettlementView';
import { InterbankView } from './components/views/InterbankView';
import { OfflinePaymentView } from './components/views/OfflinePaymentView';
import { ProgrammablePaymentView } from './components/views/ProgrammablePaymentView';
import { LiquidityManagementView } from './components/views/LiquidityManagementView';
import { RiskManagementView } from './components/views/RiskManagementView';
import { AuditLogView } from './components/views/AuditLogView';
import { RegionalAnalyticsView } from './components/views/RegionalAnalyticsView';
import { EconomicSimulationView } from './components/views/EconomicSimulationView';
import { SystemArchitectureView } from './components/views/SystemArchitectureView';
import { SystemOperationsView } from './components/views/SystemOperationsView';
import { LedgerView } from './components/views/LedgerView';

// Modals
import { ConsumerWalletModal } from './components/views/ConsumerWalletModal';
import { MerchantTerminalModal } from './components/views/MerchantTerminalModal';

const MainLayout: React.FC = () => {
  const [currentView, setCurrentView] = useState<NavigationItemKey>('dashboard');
  const [isConsumerModalOpen, setIsConsumerModalOpen] = useState(false);
  const [isMerchantModalOpen, setIsMerchantModalOpen] = useState(false);

  const renderActiveView = () => {
    switch (currentView) {
      case 'dashboard':
        return (
          <DashboardView
            onNavigate={(v) => setCurrentView(v)}
            onOpenConsumerWallet={() => setIsConsumerModalOpen(true)}
            onOpenMerchantTerminal={() => setIsMerchantModalOpen(true)}
          />
        );
      case 'issuance':
        return <IssuanceView />;
      case 'circulation':
        return <CirculationView />;
      case 'wallets':
        return <WalletManagementView />;
      case 'institutions':
        return <InstitutionsView />;
      case 'payment_processing':
        return <PaymentProcessingView />;
      case 'clearing_settlement':
        return <ClearingSettlementView />;
      case 'interbank':
        return <InterbankView />;
      case 'offline_payment':
        return <OfflinePaymentView />;
      case 'programmable_payments':
        return <ProgrammablePaymentView />;
      case 'liquidity_management':
        return <LiquidityManagementView />;
      case 'risk_management':
        return <RiskManagementView />;
      case 'audit_logs':
        return <AuditLogView />;
      case 'regional_analytics':
        return <RegionalAnalyticsView />;
      case 'economic_simulation':
        return <EconomicSimulationView />;
      case 'system_architecture':
        return <SystemArchitectureView />;
      case 'system_operations':
        return <SystemOperationsView />;
      case 'ledger':
        return <LedgerView />;
      default:
        return (
          <DashboardView
            onNavigate={(v) => setCurrentView(v)}
            onOpenConsumerWallet={() => setIsConsumerModalOpen(true)}
            onOpenMerchantTerminal={() => setIsMerchantModalOpen(true)}
          />
        );
    }
  };

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-slate-950 text-slate-100 select-none">
      {/* Top Header */}
      <Header
        onOpenConsumerWallet={() => setIsConsumerModalOpen(true)}
        onOpenMerchantTerminal={() => setIsMerchantModalOpen(true)}
      />

      {/* Main Body: Sidebar + Dynamic Main Content */}
      <div className="flex flex-1 overflow-hidden">
        <Sidebar
          currentView={currentView}
          onSelectView={(view: NavigationItemKey) => setCurrentView(view)}
        />

        <main className="flex-1 overflow-y-auto bg-slate-950">
          {renderActiveView()}
        </main>
      </div>

      {/* Bottom Fixed Status Bar */}
      <StatusBar />

      {/* Realistic Citizen & POS Simulators */}
      <ConsumerWalletModal
        isOpen={isConsumerModalOpen}
        onClose={() => setIsConsumerModalOpen(false)}
      />
      <MerchantTerminalModal
        isOpen={isMerchantModalOpen}
        onClose={() => setIsMerchantModalOpen(false)}
      />
    </div>
  );
};

export function App() {
  return (
    <SimulationProvider>
      <MainLayout />
    </SimulationProvider>
  );
}

export default App;
