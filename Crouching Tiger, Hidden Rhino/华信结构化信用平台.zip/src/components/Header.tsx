/**
 * 平台顶部通用状态栏与环境控制
 * Header component with environment tags, calculation core status, and user session
 */

import React from 'react';
import { ModelEnvironment } from '../types';
import { 
  ShieldCheck, 
  Cpu, 
  Activity, 
  Layers, 
  FileText, 
  RotateCw, 
  Download,
  AlertTriangle,
  UserCheck
} from 'lucide-react';

interface HeaderProps {
  environment: ModelEnvironment;
  onEnvironmentChange: (env: ModelEnvironment) => void;
  isCalculating: boolean;
  onRecalculate: () => void;
  onOpenAuditLog: () => void;
  onOpenTermSheet: () => void;
  simulationPaths: number;
  lastCalcTimeMs: number;
}

export const Header: React.FC<HeaderProps> = ({
  environment,
  onEnvironmentChange,
  isCalculating,
  onRecalculate,
  onOpenAuditLog,
  onOpenTermSheet,
  simulationPaths,
  lastCalcTimeMs,
}) => {
  const envColors: Record<ModelEnvironment, { bg: string; text: string; border: string }> = {
    PRODUCTION: { bg: 'bg-emerald-950/70', text: 'text-emerald-300', border: 'border-emerald-700/50' },
    STAGING: { bg: 'bg-blue-950/70', text: 'text-blue-300', border: 'border-blue-700/50' },
    SIMULATION: { bg: 'bg-cyan-950/70', text: 'text-cyan-300', border: 'border-cyan-700/50' },
    MODEL_VALIDATION: { bg: 'bg-purple-950/70', text: 'text-purple-300', border: 'border-purple-700/50' },
    RESEARCH: { bg: 'bg-amber-950/70', text: 'text-amber-300', border: 'border-amber-700/50' },
  };

  const currentEnvStyle = envColors[environment];

  return (
    <header className="bg-[#0e1420] border-b border-[#1e293b] px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs select-none sticky top-0 z-40 shadow-lg shadow-black/40">
      {/* 品牌与系统标识 */}
      <div className="flex items-center space-x-3">
        <div className="flex items-center space-x-2 bg-gradient-to-r from-blue-900/60 to-slate-900/80 px-2.5 py-1.5 rounded border border-blue-700/40">
          <Layers className="w-5 h-5 text-blue-400" />
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-bold text-sm text-slate-100 tracking-wider">华信结构化信用平台</span>
              <span className="text-[10px] font-mono text-blue-300/80 bg-blue-950/80 px-1.5 py-0.5 rounded border border-blue-800/40">
                HuaxinSyntheticCDO v3.7
              </span>
            </div>
            <div className="text-[10px] text-slate-400">全谱系合成 CDO 结构设计 · 定价 · 风险 · 生命周期引擎</div>
          </div>
        </div>

        {/* 隔离环境切换器 */}
        <div className="flex items-center space-x-1.5 bg-[#141d2d] px-2 py-1 rounded border border-[#23334d]">
          <span className="text-slate-400 text-[11px]">隔离环境:</span>
          <select
            value={environment}
            onChange={(e) => onEnvironmentChange(e.target.value as ModelEnvironment)}
            className={`font-mono font-semibold text-[11px] px-2 py-0.5 rounded border cursor-pointer focus:outline-none transition-colors ${currentEnvStyle.bg} ${currentEnvStyle.text} ${currentEnvStyle.border}`}
          >
            <option value="SIMULATION">SIMULATION (量化模拟)</option>
            <option value="MODEL_VALIDATION">MODEL_VALIDATION (模型验证)</option>
            <option value="RESEARCH">RESEARCH (定量研究)</option>
            <option value="STAGING">STAGING (预生产准入)</option>
            <option value="PRODUCTION">PRODUCTION (生产实盘交易)</option>
          </select>
        </div>
      </div>

      {/* 运行性能与核心引擎监控 */}
      <div className="hidden lg:flex items-center space-x-4 bg-[#111827]/90 px-3 py-1.5 rounded border border-[#1f2937] font-mono text-[11px]">
        <div className="flex items-center space-x-1.5 text-emerald-400">
          <Cpu className="w-3.5 h-3.5 animate-pulse" />
          <span className="text-slate-400">核心引擎:</span>
          <span className="font-semibold text-slate-200">Rust Core AVX-512</span>
        </div>
        <div className="h-3 w-px bg-slate-700" />
        <div className="flex items-center space-x-1.5 text-cyan-300">
          <Activity className="w-3.5 h-3.5" />
          <span className="text-slate-400">模拟路径:</span>
          <span className="font-semibold">{simulationPaths.toLocaleString()} paths</span>
        </div>
        <div className="h-3 w-px bg-slate-700" />
        <div className="text-slate-400">
          延迟: <span className="text-emerald-400 font-semibold">{lastCalcTimeMs} ms</span>
        </div>
        <div className="h-3 w-px bg-slate-700" />
        <div className="text-slate-400">
          CPU: <span className="text-slate-200 font-semibold">64%</span> | 内存: <span className="text-slate-200 font-semibold">3.2 GB</span>
        </div>
      </div>

      {/* 右侧快捷操作与用户 */}
      <div className="flex items-center space-x-2">
        <button
          onClick={onRecalculate}
          disabled={isCalculating}
          className="flex items-center space-x-1.5 bg-blue-600 hover:bg-blue-500 disabled:bg-blue-900/60 text-white font-medium px-3 py-1.5 rounded border border-blue-400/30 transition-all cursor-pointer shadow-sm active:scale-95"
          title="重新执行蒙特卡洛模拟与全组合定价"
        >
          <RotateCw className={`w-3.5 h-3.5 ${isCalculating ? 'animate-spin' : ''}`} />
          <span>{isCalculating ? '正在计算...' : '重新计量'}</span>
        </button>

        <button
          onClick={onOpenTermSheet}
          className="flex items-center space-x-1.5 bg-[#172236] hover:bg-[#20304c] text-slate-200 px-2.5 py-1.5 rounded border border-[#2b3e5f] transition-all cursor-pointer"
          title="查看与导出 ISDA 标准交易条款 Term Sheet"
        >
          <FileText className="w-3.5 h-3.5 text-blue-400" />
          <span>交易条款书</span>
        </button>

        <button
          onClick={onOpenAuditLog}
          className="flex items-center space-x-1.5 bg-[#172236] hover:bg-[#20304c] text-slate-200 px-2.5 py-1.5 rounded border border-[#2b3e5f] transition-all cursor-pointer"
          title="查看不可篡改审计日志"
        >
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>审计日志</span>
        </button>

        <div className="hidden sm:flex items-center space-x-1.5 bg-[#151d2c] px-2.5 py-1.5 rounded border border-[#223049] text-slate-300">
          <UserCheck className="w-3.5 h-3.5 text-cyan-400" />
          <span className="font-medium text-[11px]">张华 (量化主管)</span>
        </div>
      </div>
    </header>
  );
};
