/**
 * 数据血缘与可解释性弹窗 (Data Lineage & Explainability Chain)
 * 允许用户点击任何指标查看完整计算链与数学公式
 */

import React from 'react';
import { X, CheckCircle2, ArrowDown, Database, Cpu, HelpCircle } from 'lucide-react';
import { DataLineageChain } from '../../types';

interface DataLineageModalProps {
  isOpen: boolean;
  onClose: () => void;
  chainData: DataLineageChain | null;
}

export const DataLineageModal: React.FC<DataLineageModalProps> = ({ isOpen, onClose, chainData }) => {
  if (!isOpen || !chainData) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4">
      <div className="bg-[#0f172a] border border-[#1e293b] rounded-lg shadow-2xl max-w-3xl w-full max-h-[85vh] flex flex-col overflow-hidden text-slate-200 animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-[#1e293b] bg-[#111e38]">
          <div className="flex items-center space-x-2.5">
            <HelpCircle className="w-5 h-5 text-cyan-400" />
            <div>
              <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2">
                <span>量化数据血缘与可解释性追踪:</span>
                <span className="text-cyan-300 font-mono">{chainData.metricName}</span>
              </h3>
              <div className="text-[11px] text-slate-400">
                当前输出值: <span className="font-mono font-bold text-amber-300">{chainData.calculatedValue} {chainData.currencyOrUnit}</span>
                {chainData.isDemo && (
                  <span className="ml-2 text-[10px] bg-amber-950/80 text-amber-300 px-1.5 py-0.5 rounded border border-amber-800/40">
                    底层包含演示数据与模型假设
                  </span>
                )}
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded hover:bg-slate-700/50 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Lineage Steps Body */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs">
          <div className="p-3 bg-blue-950/30 border border-blue-900/50 rounded text-blue-200 text-[11px] leading-relaxed">
            <strong>可解释性合规准则:</strong> 本系统杜绝黑箱生成与伪造 AI 估值。该指标由确定性量化金融模型根据下述 6-8 级依赖链层层推导得出，可随时进行数学重算与监管回溯审计。
          </div>

          <div className="space-y-3">
            {chainData.steps.map((step, idx) => (
              <div key={idx} className="relative">
                <div className="bg-[#152136] border border-[#233554] rounded-md p-3 hover:border-blue-500/50 transition-colors">
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center space-x-2">
                      <span className="w-5 h-5 rounded-full bg-blue-600/80 text-white font-mono font-bold flex items-center justify-center text-[10px]">
                        {step.stepNumber}
                      </span>
                      <span className="font-semibold text-slate-100">{step.stepTitle}</span>
                    </div>
                    <span className="text-[10px] font-mono text-cyan-300 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/40">
                      {step.dataSourceOrModel}
                    </span>
                  </div>

                  <p className="text-slate-300 mb-2 leading-normal">{step.description}</p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2 bg-[#0d1524] p-2.5 rounded border border-[#1b2a45] font-mono text-[11px]">
                    <div>
                      <div className="text-slate-400 text-[10px] uppercase">计算公式 (Mathematical Formulation):</div>
                      <div className="text-emerald-300 font-bold">{step.formula}</div>
                    </div>
                    <div>
                      <div className="text-slate-400 text-[10px] uppercase">阶段输出 (Intermediate Output):</div>
                      <div className="text-amber-300 font-bold">{String(step.outputValue)}</div>
                    </div>
                  </div>

                  {step.inputValues && Object.keys(step.inputValues).length > 0 && (
                    <div className="mt-2 text-[10px] text-slate-400 flex flex-wrap gap-2">
                      <span className="font-semibold text-slate-300">输入参数:</span>
                      {Object.entries(step.inputValues).map(([k, v]) => (
                        <span key={k} className="bg-slate-800/60 px-1.5 py-0.5 rounded text-slate-300 font-mono">
                          {k} = {v}
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                {idx < chainData.steps.length - 1 && (
                  <div className="flex justify-center py-1">
                    <ArrowDown className="w-4 h-4 text-blue-400 animate-bounce" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-[#1e293b] bg-[#0c1424] flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center space-x-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>数据状态: 已通过模型审计与可重复性验证</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded font-medium transition-colors cursor-pointer"
          >
            完成查看
          </button>
        </div>
      </div>
    </div>
  );
};
