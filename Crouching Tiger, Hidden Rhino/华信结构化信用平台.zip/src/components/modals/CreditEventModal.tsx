/**
 * 信用事件触发与模拟结算弹窗 (Credit Event Engine Simulator)
 */

import React, { useState } from 'react';
import { X, AlertTriangle, Play, RefreshCw, CheckCircle } from 'lucide-react';
import { ReferenceEntity, CreditEventType, SettlementType } from '../../types';

interface CreditEventModalProps {
  isOpen: boolean;
  onClose: () => void;
  entities: ReferenceEntity[];
  onSimulateCreditEvent: (entityId: string, eventType: CreditEventType, recovery: number, settlementType: SettlementType) => void;
}

export const CreditEventModal: React.FC<CreditEventModalProps> = ({
  isOpen,
  onClose,
  entities,
  onSimulateCreditEvent,
}) => {
  if (!isOpen) return null;

  const [selectedEntityId, setSelectedEntityId] = useState(entities[0]?.id || '');
  const [eventType, setEventType] = useState<CreditEventType>('破产 (Bankruptcy)');
  const [auctionRecovery, setAuctionRecovery] = useState<number>(35); // 35%
  const [settlementType, setSettlementType] = useState<SettlementType>('拍卖结算 (Auction Settlement)');
  const [isProcessing, setIsProcessing] = useState(false);

  const selectedEntity = entities.find((e) => e.id === selectedEntityId) || entities[0];

  const handleConfirm = () => {
    setIsProcessing(true);
    setTimeout(() => {
      onSimulateCreditEvent(selectedEntityId, eventType, auctionRecovery / 100.0, settlementType);
      setIsProcessing(false);
      onClose();
    }, 400);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4">
      <div className="bg-[#0f172a] border border-red-900/40 rounded-lg shadow-2xl max-w-xl w-full flex flex-col overflow-hidden text-slate-200">
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-[#1e293b] bg-red-950/40">
          <div className="flex items-center space-x-2.5">
            <AlertTriangle className="w-5 h-5 text-red-400" />
            <h3 className="font-bold text-sm text-slate-100">模拟触发信用事件 (Credit Event Simulation)</h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-4 text-xs">
          <div className="bg-red-950/30 border border-red-900/50 p-2.5 rounded text-red-200 leading-normal">
            <strong>免责与测试提示:</strong> 当前处于 <span className="font-mono font-bold text-amber-300">SIMULATION</span> 模式。在此处触发的信用违约事件不会影响实盘合约，用于测试组合损失穿透、分层减记与保证金追加。
          </div>

          <div>
            <label className="block text-slate-300 font-medium mb-1">选择违约参考实体 (Reference Entity):</label>
            <select
              value={selectedEntityId}
              onChange={(e) => setSelectedEntityId(e.target.value)}
              className="w-full bg-[#152136] border border-[#273a5a] rounded p-2 text-slate-100 font-mono text-xs focus:outline-none focus:border-blue-500"
            >
              {entities.map((e) => (
                <option key={e.id} value={e.id}>
                  [{e.id}] {e.name} ({e.rating} · 5Y CDS {e.cdsSpread5Y}bp · 权重 {(e.weight * 100).toFixed(2)}%)
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-medium mb-1">信用事件类型 (ISDA 2014):</label>
              <select
                value={eventType}
                onChange={(e) => setEventType(e.target.value as CreditEventType)}
                className="w-full bg-[#152136] border border-[#273a5a] rounded p-2 text-slate-100 text-xs focus:outline-none focus:border-blue-500"
              >
                <option value="破产 (Bankruptcy)">破产 (Bankruptcy)</option>
                <option value="未能支付 (Failure to Pay)">未能支付 (Failure to Pay)</option>
                <option value="债务重组 (Restructuring)">债务重组 (Restructuring)</option>
                <option value="债务加速到期 (Obligation Acceleration)">债务加速到期</option>
                <option value="政府干预 (Governmental Intervention)">政府干预 (Governmental Intervention)</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">结算机制 (Settlement):</label>
              <select
                value={settlementType}
                onChange={(e) => setSettlementType(e.target.value as SettlementType)}
                className="w-full bg-[#152136] border border-[#273a5a] rounded p-2 text-slate-100 text-xs focus:outline-none focus:border-blue-500"
              >
                <option value="拍卖结算 (Auction Settlement)">拍卖结算 (Auction Settlement)</option>
                <option value="现金结算 (Cash Settlement)">现金结算 (Cash Settlement)</option>
                <option value="实物结算 (Physical Settlement)">实物结算 (Physical Settlement)</option>
              </select>
            </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="text-slate-300 font-medium">最终拍卖清偿回收率 (Auction Recovery Rate):</label>
              <span className="font-mono font-bold text-amber-300">{auctionRecovery}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={100}
              step={1}
              value={auctionRecovery}
              onChange={(e) => setAuctionRecovery(Number(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400 mt-1">
              <span>0% (完全损毁)</span>
              <span>40% (标准基准)</span>
              <span>100% (无损失)</span>
            </div>
          </div>

          {selectedEntity && (
            <div className="bg-[#0b1322] p-3 rounded border border-[#1b2b48] font-mono text-[11px] space-y-1 text-slate-300">
              <div className="text-slate-400 font-sans font-semibold text-[10px] uppercase">预计违约冲击估算:</div>
              <div>实体名义本金: <span className="text-slate-100">¥{(selectedEntity.notional / 1e8).toFixed(2)} 亿元</span></div>
              <div>实际违约损失 (LGD): <span className="text-red-400 font-bold">¥{((selectedEntity.notional * (1 - auctionRecovery / 100)) / 1e8).toFixed(2)} 亿元</span></div>
              <div>组合损失率增加: <span className="text-amber-300 font-bold">+{(selectedEntity.weight * (1 - auctionRecovery / 100) * 100).toFixed(3)}%</span></div>
            </div>
          )}
        </div>

        <div className="px-5 py-3 border-t border-[#1e293b] bg-[#0c1424] flex items-center justify-end space-x-2">
          <button
            onClick={onClose}
            className="px-3.5 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs cursor-pointer"
          >
            取消
          </button>
          <button
            onClick={handleConfirm}
            disabled={isProcessing}
            className="flex items-center space-x-1.5 px-4 py-1.5 rounded bg-red-600 hover:bg-red-500 text-white font-medium text-xs cursor-pointer shadow-sm transition-all"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>{isProcessing ? '正在穿透计算...' : '立即模拟触发'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
