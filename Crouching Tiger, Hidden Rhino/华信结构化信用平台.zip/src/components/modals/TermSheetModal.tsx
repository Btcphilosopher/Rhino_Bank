/**
 * ISDA 标准交易条款书 (Term Sheet / Confirmation Document)
 */

import React from 'react';
import { X, Download, FileText, CheckCircle, Printer } from 'lucide-react';
import { SyntheticCDODeal } from '../../types';

interface TermSheetModalProps {
  isOpen: boolean;
  onClose: () => void;
  deal: SyntheticCDODeal;
}

export const TermSheetModal: React.FC<TermSheetModalProps> = ({ isOpen, onClose, deal }) => {
  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4">
      <div className="bg-[#0f172a] border border-[#1e293b] rounded-lg shadow-2xl max-w-4xl w-full max-h-[90vh] flex flex-col overflow-hidden text-slate-200">
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-[#1e293b] bg-[#111e38]">
          <div className="flex items-center space-x-2.5">
            <FileText className="w-5 h-5 text-blue-400" />
            <div>
              <h3 className="font-bold text-sm text-slate-100">合成 CDO 交易经济条款确认书 (ISDA Standard Term Sheet)</h3>
              <div className="text-[11px] text-slate-400">Trade ID: <span className="font-mono text-cyan-300 font-bold">{deal.tradeId}</span></div>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={handlePrint}
              className="flex items-center space-x-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>打印 / 另存为 PDF</span>
            </button>
            <button onClick={onClose} className="text-slate-400 hover:text-white cursor-pointer">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="p-6 overflow-y-auto space-y-5 text-xs text-slate-300 font-sans">
          {/* Header Banner */}
          <div className="border-b border-slate-700 pb-3">
            <div className="text-base font-bold text-slate-100">华信结构化信用投资交易确认协议 (CONFIRMATION OF SYNTHETIC CDO TRANSACTION)</div>
            <div className="text-[11px] text-slate-400 mt-1">
              遵循国际掉期与衍生工具协会 (ISDA) 2014 Credit Derivatives Definitions 标准定义
            </div>
          </div>

          {/* Section 1: General Terms */}
          <div className="space-y-2">
            <div className="font-bold text-cyan-300 text-xs uppercase tracking-wider">一、一般交易条款 (General Terms)</div>
            <div className="grid grid-cols-2 gap-2 bg-[#142036] p-3 rounded border border-[#203254]">
              <div>交易名称 (Transaction Name): <span className="text-slate-100 font-medium">{deal.dealName}</span></div>
              <div>交易编号 (Trade ID): <span className="font-mono text-cyan-300">{deal.tradeId}</span></div>
              <div>交易对手 (Counterparty): <span className="text-slate-100 font-medium">{deal.counterparty} ({deal.counterpartyRating})</span></div>
              <div>总名义本金 (Total Notional): <span className="font-mono text-amber-300 font-bold">¥{(deal.totalNotional / 1e8).toFixed(2)} 亿元 ({deal.currency})</span></div>
              <div>生效日 (Effective Date): <span className="font-mono">{deal.effectiveDate}</span></div>
              <div>到期日 (Scheduled Termination Date): <span className="font-mono">{deal.maturityDate} ({deal.maturityYears} 年期)</span></div>
              <div>结算方式 (Settlement Type): <span className="text-slate-100">{deal.settlementType}</span></div>
              <div>机制类型 (Structure Type): <span className="text-emerald-300 font-medium">{deal.isPAUG ? 'Pay-As-You-Go (PAUG) 分段减记结算' : '标准到期清偿'}</span></div>
            </div>
          </div>

          {/* Section 2: Tranche Economics */}
          <div className="space-y-2">
            <div className="font-bold text-cyan-300 text-xs uppercase tracking-wider">二、分层经济条款与定价矩阵 (Tranche Economics)</div>
            <div className="border border-[#1e2d48] rounded overflow-hidden">
              <table className="w-full text-left font-mono text-[11px]">
                <thead className="bg-[#162540] text-slate-300">
                  <tr>
                    <th className="p-2">分层等级</th>
                    <th className="p-2">触发点 (A)</th>
                    <th className="p-2">终止点 (D)</th>
                    <th className="p-2">名义本金 (CNY)</th>
                    <th className="p-2">固定票息 / 利差</th>
                    <th className="p-2">平价利差 (Fair)</th>
                    <th className="p-2">前置费 (Upfront)</th>
                    <th className="p-2">预期损失率</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1c2a42]">
                  {deal.tranches.map((t) => (
                    <tr key={t.id} className="hover:bg-[#131e33]">
                      <td className="p-2 font-sans font-bold text-slate-100">{t.name}</td>
                      <td className="p-2 text-cyan-300">{(t.attachmentPoint * 100).toFixed(1)}%</td>
                      <td className="p-2 text-cyan-300">{(t.detachmentPoint * 100).toFixed(1)}%</td>
                      <td className="p-2 text-slate-200">¥{(t.notional / 1e8).toFixed(2)} 亿</td>
                      <td className="p-2 font-bold text-amber-300">{t.contractSpreadBp} bp</td>
                      <td className="p-2 text-slate-300">{t.fairSpreadBp} bp</td>
                      <td className="p-2 text-slate-300">{t.upfrontFeePercent.toFixed(2)}%</td>
                      <td className="p-2 text-red-300 font-bold">{t.expectedLossPercent.toFixed(2)}%</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Section 3: Credit Events */}
          <div className="space-y-2">
            <div className="font-bold text-cyan-300 text-xs uppercase tracking-wider">三、合格信用事件定义 (Credit Events Applicable)</div>
            <div className="bg-[#142036] p-3 rounded border border-[#203254] space-y-1 text-[11px] text-slate-300">
              <p>• <strong>破产 (Bankruptcy):</strong> 适用 (Applicable)。参考实体进入正式清算法律程序。</p>
              <p>• <strong>未能支付 (Failure to Pay):</strong> 适用 (Applicable)。宽限期 30 个工作日，最小违约金额阈值 USD 1,000,000 或等值人民币。</p>
              <p>• <strong>债务重组 (Restructuring):</strong> 适用 (Mod R / Modified Restructuring 约定)。</p>
              <p>• <strong>政府干预 (Governmental Intervention):</strong> 适用 (Applicable)。</p>
            </div>
          </div>

          {/* Section 4: Collateral & Margin */}
          <div className="space-y-2">
            <div className="font-bold text-cyan-300 text-xs uppercase tracking-wider">四、CSA 抵押品与保证金安排 (Credit Support Annex)</div>
            <div className="bg-[#142036] p-3 rounded border border-[#203254] grid grid-cols-3 gap-2 text-[11px]">
              <div>初始保证金 (Initial Margin): <span className="font-mono text-slate-100 font-bold">¥{(deal.initialMargin / 1e6).toFixed(0)} 万元</span></div>
              <div>变动保证金 (Variation Margin): <span className="font-mono text-slate-100 font-bold">¥{(deal.variationMargin / 1e6).toFixed(0)} 万元</span></div>
              <div>抵押品折扣 (Haircut): <span className="font-mono text-amber-300 font-bold">{(deal.collateralHaircut * 100).toFixed(1)}%</span></div>
            </div>
          </div>

          {/* Legal Notice Footer */}
          <div className="text-[10px] text-slate-400 border-t border-slate-700 pt-3 leading-relaxed">
            * 法律效力声明: 本文件为华信结构化信用系统基于模型参数生成的经济条款模板 (Economic Terms Data Model)，最终具有完全法律约束力的合同须由各方授权法律代表依据正式主协议 (ISDA Master Agreement) 签署执行。
          </div>
        </div>

        <div className="px-5 py-3 border-t border-[#1e293b] bg-[#0c1424] flex items-center justify-end space-x-2">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded font-medium text-xs cursor-pointer"
          >
            完成审阅
          </button>
        </div>
      </div>
    </div>
  );
};
