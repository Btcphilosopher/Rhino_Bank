/**
 * 不可篡改审计日志弹窗 (Immutable Audit Trail Modal)
 */

import React from 'react';
import { X, ShieldCheck, Lock, Search, Download } from 'lucide-react';
import { AuditLogItem } from '../../types';

interface AuditLogModalProps {
  isOpen: boolean;
  onClose: () => void;
  logs: AuditLogItem[];
}

export const AuditLogModal: React.FC<AuditLogModalProps> = ({ isOpen, onClose, logs }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4">
      <div className="bg-[#0f172a] border border-[#1e293b] rounded-lg shadow-2xl max-w-4xl w-full max-h-[85vh] flex flex-col overflow-hidden text-slate-200">
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-[#1e293b] bg-[#111e38]">
          <div className="flex items-center space-x-2.5">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <div>
              <h3 className="font-bold text-sm text-slate-100">系统审计追踪日志 (Immutable Audit Trail)</h3>
              <div className="text-[11px] text-slate-400">所有模型标定、交易修改与审批操作均自动生成 SHA-256 哈希存证，严禁删除</div>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 overflow-y-auto space-y-3 text-xs">
          <div className="overflow-x-auto border border-[#1e2d48] rounded">
            <table className="w-full text-left font-mono">
              <thead className="bg-[#15233c] text-slate-300 text-[11px] uppercase tracking-wider">
                <tr>
                  <th className="p-2.5">审计编号 / 时间</th>
                  <th className="p-2.5">操作人 / 角色</th>
                  <th className="p-2.5">操作类型</th>
                  <th className="p-2.5">目标实体 / 交易</th>
                  <th className="p-2.5">关键参数</th>
                  <th className="p-2.5 text-right">存证哈希 (SHA-256)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1c2a42] text-[11px]">
                {logs.map((log) => (
                  <tr key={log.id} className="hover:bg-[#131e33] transition-colors">
                    <td className="p-2.5 whitespace-nowrap">
                      <div className="font-bold text-blue-300">{log.id}</div>
                      <div className="text-[10px] text-slate-400">{log.timestamp}</div>
                    </td>
                    <td className="p-2.5 whitespace-nowrap">
                      <div className="text-slate-200 font-sans font-medium">{log.user}</div>
                      <div className="text-[10px] text-cyan-400 font-sans">{log.role}</div>
                    </td>
                    <td className="p-2.5 font-sans font-semibold text-amber-300">
                      {log.action}
                    </td>
                    <td className="p-2.5 text-slate-300 font-sans">
                      {log.targetEntity}
                    </td>
                    <td className="p-2.5 text-slate-400 max-w-xs truncate" title={log.parameters}>
                      {log.parameters}
                    </td>
                    <td className="p-2.5 text-right font-mono text-[10px] text-emerald-400/80">
                      <span className="bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-800/40">
                        {log.hash.slice(0, 16)}...
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="px-5 py-3 border-t border-[#1e293b] bg-[#0c1424] flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center space-x-1.5">
            <Lock className="w-3.5 h-3.5 text-slate-400" />
            <span>合规记录数: {logs.length} 条 · 审计链完整性: 正常 (100%)</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded font-medium cursor-pointer"
          >
            关闭
          </button>
        </div>
      </div>
    </div>
  );
};
