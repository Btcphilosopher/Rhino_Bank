/**
 * CDO² 嵌套分层与 XVA 交易台 (CDO Squared & XVA Desk)
 * CDO² 结构化多层穿透、交易对手信用风险敞口 (EAD)、CSA 抵押品与 CVA / DVA / FVA / MVA 综合计量
 */

import React, { useState } from 'react';
import { GitMerge, ShieldCheck, Activity, Layers, DollarSign, PieChart } from 'lucide-react';
import { CDOSquaredSubPool, calculateCDOSquaredTranches, computeXvaMetrics } from '../../math/xvaAndCdoSquaredEngine';

export const CdoSquaredAndXvaView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'CDO_SQUARED' | 'XVA_METRICS'>('CDO_SQUARED');
  const [collateralPostedM, setCollateralPostedM] = useState<number>(214); // ¥214 M
  const [haircutPct, setHaircutPct] = useState<number>(5); // 5%

  // CDO² 演示子资产池
  const subPools: CDOSquaredSubPool[] = [
    {
      id: 'subpool-1',
      name: 'Sub-CDO A (亚太投资级夹层池)',
      referencePoolName: 'iTraxx Asia ex-Japan 100',
      underlyingTrancheName: '3%–7% 夹层',
      attachment: 0.03,
      detachment: 0.07,
      weightInMaster: 0.50,
      notional: 2500000000,
      expectedLossRate: 0.078,
    },
    {
      id: 'subpool-2',
      name: 'Sub-CDO B (欧美高收益夹层池)',
      referencePoolName: 'CDX NA HY 100',
      underlyingTrancheName: '7%–10% 优先夹层',
      attachment: 0.07,
      detachment: 0.10,
      weightInMaster: 0.50,
      notional: 2500000000,
      expectedLossRate: 0.092,
    },
  ];

  const cdo2Master = calculateCDOSquaredTranches(5000000000, subPools);
  const xvaResults = computeXvaMetrics(320000000, 5000000000, 'A', collateralPostedM * 1e6, haircutPct / 100.0);

  return (
    <div className="space-y-4 text-slate-200">
      {/* 顶部标题栏 */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#101827] p-3.5 rounded-lg border border-[#1e293b]">
        <div>
          <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
            <GitMerge className="w-5 h-5 text-purple-400" />
            <span>CDO² 嵌套结构与 XVA 衍生品计量中心 (CDO² & XVA Desk)</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            CDO 平方嵌套分层穿透模型 · CSA 抵押品净额结算与 CVA/DVA/FVA/MVA 全面信用估值调整
          </p>
        </div>

        {/* 内部 Tab 切换 */}
        <div className="flex items-center space-x-1 bg-[#141d2d] p-1 rounded border border-[#23334d] text-xs">
          <button
            onClick={() => setActiveTab('CDO_SQUARED')}
            className={`px-3 py-1 rounded cursor-pointer transition-colors ${
              activeTab === 'CDO_SQUARED' ? 'bg-purple-600 text-white font-semibold' : 'text-slate-400 hover:text-white'
            }`}
          >
            CDO² 嵌套分层结构
          </button>
          <button
            onClick={() => setActiveTab('XVA_METRICS')}
            className={`px-3 py-1 rounded cursor-pointer transition-colors ${
              activeTab === 'XVA_METRICS' ? 'bg-purple-600 text-white font-semibold' : 'text-slate-400 hover:text-white'
            }`}
          >
            交易对手信用风险与 XVA
          </button>
        </div>
      </div>

      {activeTab === 'CDO_SQUARED' && (
        <div className="space-y-4">
          {/* CDO² 资产池分层结构 */}
          <div className="bg-[#101827] p-4 rounded-lg border border-[#1e293b] space-y-3">
            <div className="flex items-center justify-between border-b border-[#1e293b] pb-2">
              <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2">
                <Layers className="w-4 h-4 text-cyan-400" />
                <span>底层 Sub-CDO 组合输入 (Underlying Sub-CDO Tranche Portfolios)</span>
              </h3>
              <span className="text-[11px] text-slate-400 font-mono">
                Master CDO 总名义本金: ¥{(cdo2Master.totalNotional / 1e8).toFixed(1)} 亿元
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {subPools.map((sub) => (
                <div key={sub.id} className="bg-[#141e30] p-3 rounded-lg border border-[#20304a] text-xs space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-100">{sub.name}</span>
                    <span className="text-cyan-300 font-mono font-bold">权重 {(sub.weightInMaster * 100).toFixed(0)}%</span>
                  </div>
                  <div className="text-[11px] text-slate-400">参考池: {sub.referencePoolName}</div>
                  <div className="grid grid-cols-3 gap-2 font-mono text-[11px] pt-1">
                    <div>底层分层: <span className="text-slate-200">{sub.underlyingTrancheName}</span></div>
                    <div>名义本金: <span className="text-slate-200">¥{(sub.notional / 1e8).toFixed(1)} 亿</span></div>
                    <div>预期损失率: <span className="text-red-400 font-bold">{(sub.expectedLossRate * 100).toFixed(2)}%</span></div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Master CDO² 分层定价结果 */}
          <div className="bg-[#101827] p-4 rounded-lg border border-[#1e293b] space-y-3">
            <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2 border-b border-[#1e293b] pb-2">
              <PieChart className="w-4 h-4 text-purple-400" />
              <span>Master CDO² 最终分层结构与定价 (Master CDO² Tranches)</span>
            </h3>

            <div className="overflow-x-auto border border-[#1e2d48] rounded">
              <table className="w-full text-left font-mono text-xs">
                <thead className="bg-[#15233c] text-slate-300 text-[11px]">
                  <tr>
                    <th className="p-2.5">CDO² 分层名称</th>
                    <th className="p-2.5">触发点 (A)</th>
                    <th className="p-2.5">终止点 (D)</th>
                    <th className="p-2.5">名义本金 (CNY)</th>
                    <th className="p-2.5">预期损失率 (EL)</th>
                    <th className="p-2.5 text-right">平价利差 (Fair Spread)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1c2a42]">
                  {cdo2Master.masterTranches.map((t) => (
                    <tr key={t.name} className="hover:bg-[#131e33]">
                      <td className="p-2.5 font-sans font-bold text-slate-100">{t.name}</td>
                      <td className="p-2.5 text-cyan-300">{(t.attachment * 100).toFixed(1)}%</td>
                      <td className="p-2.5 text-cyan-300">{(t.detachment * 100).toFixed(1)}%</td>
                      <td className="p-2.5 text-slate-200">¥{(t.notional / 1e8).toFixed(2)} 亿元</td>
                      <td className="p-2.5 text-red-400 font-bold">{(t.expectedLossRate * 100).toFixed(2)}%</td>
                      <td className="p-2.5 text-right text-amber-300 font-bold">{t.fairSpreadBp} bp</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'XVA_METRICS' && (
        <div className="space-y-4">
          {/* XVA 核心指标 */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
            <div className="bg-[#121b2b] p-3 rounded-lg border border-[#1e2d45]">
              <div className="text-[11px] text-slate-400">净敞口 (Net EAD)</div>
              <div className="text-base font-bold font-mono text-amber-300 mt-1">
                ¥{(xvaResults.netExposureAtDefault / 1e6).toFixed(1)} M
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">Post-Collateral Haircut</div>
            </div>

            <div className="bg-[#121b2b] p-3 rounded-lg border border-[#1e2d45]">
              <div className="text-[11px] text-slate-400">信用估值调整 (CVA)</div>
              <div className="text-base font-bold font-mono text-red-400 mt-1">
                ¥{(xvaResults.cvaAmount / 1e6).toFixed(2)} M
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">Counterparty Default Risk</div>
            </div>

            <div className="bg-[#121b2b] p-3 rounded-lg border border-[#1e2d45]">
              <div className="text-[11px] text-slate-400">债务估值调整 (DVA)</div>
              <div className="text-base font-bold font-mono text-emerald-400 mt-1">
                ¥{(xvaResults.dvaAmount / 1e6).toFixed(2)} M
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">Own Credit Benefit</div>
            </div>

            <div className="bg-[#121b2b] p-3 rounded-lg border border-[#1e2d45]">
              <div className="text-[11px] text-slate-400">资金估值调整 (FVA)</div>
              <div className="text-base font-bold font-mono text-cyan-300 mt-1">
                ¥{(xvaResults.fvaAmount / 1e6).toFixed(2)} M
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">Funding Cost of Uncollateral</div>
            </div>

            <div className="bg-[#121b2b] p-3 rounded-lg border border-[#1e2d45]">
              <div className="text-[11px] text-slate-400">保证金估值调整 (MVA)</div>
              <div className="text-base font-bold font-mono text-purple-300 mt-1">
                ¥{(xvaResults.mvaAmount / 1e6).toFixed(2)} M
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">Initial Margin Financing</div>
            </div>

            <div className="bg-[#121b2b] p-3 rounded-lg border border-[#1e2d45]">
              <div className="text-[11px] text-slate-400">综合总 XVA 冲减</div>
              <div className="text-base font-bold font-mono text-red-300 mt-1">
                ¥{(xvaResults.totalXva / 1e6).toFixed(2)} M
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">Net Valuation Impact</div>
            </div>
          </div>

          {/* 抵押品交互与敞口演化 */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
            <div className="lg:col-span-4 bg-[#101827] p-4 rounded-lg border border-[#1e293b] space-y-3 text-xs">
              <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2 border-b border-[#1e293b] pb-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>CSA 抵押品与保证金控制台</span>
              </h3>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <span className="text-slate-400">已质押抵押品金额 (Collateral Posted):</span>
                  <span className="font-mono font-bold text-slate-200">¥{collateralPostedM} M</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={350}
                  step={5}
                  value={collateralPostedM}
                  onChange={(e) => setCollateralPostedM(Number(e.target.value))}
                  className="w-full accent-emerald-500 cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <span className="text-slate-400">抵押品折扣率 (Haircut):</span>
                  <span className="font-mono font-bold text-amber-300">{haircutPct}%</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={20}
                  step={1}
                  value={haircutPct}
                  onChange={(e) => setHaircutPct(Number(e.target.value))}
                  className="w-full accent-amber-500 cursor-pointer"
                />
              </div>

              <div className="bg-[#0b1322] p-3 rounded border border-[#1b2b48] space-y-1.5 font-mono text-[11px]">
                <div className="flex justify-between">
                  <span className="text-slate-400">折后有效抵押品:</span>
                  <span className="text-emerald-300 font-bold">¥{(xvaResults.effectiveCollateral / 1e6).toFixed(1)} M</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">未抵押风险暴露:</span>
                  <span className="text-red-400 font-bold">¥{(xvaResults.netExposureAtDefault / 1e6).toFixed(1)} M</span>
                </div>
              </div>
            </div>

            <div className="lg:col-span-8 bg-[#101827] p-4 rounded-lg border border-[#1e293b] space-y-3">
              <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2 border-b border-[#1e293b] pb-2">
                <Activity className="w-4 h-4 text-cyan-400" />
                <span>5 年期预期风险敞口剖面 (Expected Exposure Profile EE(t))</span>
              </h3>

              <div className="overflow-x-auto border border-[#1e2d48] rounded">
                <table className="w-full text-left font-mono text-xs">
                  <thead className="bg-[#15233c] text-slate-300 text-[10px]">
                    <tr>
                      <th className="p-2">期限节点 (Tenor)</th>
                      <th className="p-2">预期敞口 EE(t)</th>
                      <th className="p-2 text-right">折现敞口 Discounted EE(t)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1c2a42] text-[11px]">
                    {xvaResults.timeProfile.map((tp) => (
                      <tr key={tp.tenor} className="hover:bg-[#131e33]">
                        <td className="p-2 text-cyan-300 font-bold">{tp.tenor}</td>
                        <td className="p-2 text-slate-200">¥{(tp.expectedExposure / 1e6).toFixed(2)} M</td>
                        <td className="p-2 text-right text-emerald-400 font-bold">¥{(tp.discountedExposure / 1e6).toFixed(2)} M</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
