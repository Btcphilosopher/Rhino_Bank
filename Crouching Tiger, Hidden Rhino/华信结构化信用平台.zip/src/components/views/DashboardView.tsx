/**
 * 华信结构化信用平台 - 首页概览 (合成 CDO 风险与交易中心)
 * Main Dashboard with Real Quantitative Loss Distribution, Tranche Payoffs & KPI Center
 */

import React, { useState } from 'react';
import { 
  PortfolioRiskMetrics, 
  LossDistributionPoint, 
  CDOTranche, 
  ReferenceEntity,
  DataLineageChain 
} from '../../types';
import { 
  Activity, 
  TrendingUp, 
  ShieldAlert, 
  HelpCircle, 
  Play, 
  Layers, 
  Sliders, 
  BarChart2, 
  FileSpreadsheet,
  AlertCircle,
  ArrowUpRight
} from 'lucide-react';

interface DashboardViewProps {
  metrics: PortfolioRiskMetrics;
  lossDistribution: LossDistributionPoint[];
  tranches: CDOTranche[];
  entities: ReferenceEntity[];
  systemCorrelation: number;
  onCorrelationChange: (rho: number) => void;
  onOpenDataLineage: (chain: DataLineageChain) => void;
  onOpenCreditEventModal: () => void;
  onNavigateToTab: (tab: any) => void;
  onUpdateTrancheAttachment: (trancheId: string, attachment: number, detachment: number) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  metrics,
  lossDistribution,
  tranches,
  entities,
  systemCorrelation,
  onCorrelationChange,
  onOpenDataLineage,
  onOpenCreditEventModal,
  onNavigateToTab,
  onUpdateTrancheAttachment,
}) => {
  const [hoveredLossPercent, setHoveredLossPercent] = useState<number | null>(null);

  // 构造数据血缘查询
  const showElLineage = () => {
    onOpenDataLineage({
      metricName: '组合预期信用损失 (Expected Loss)',
      calculatedValue: `¥${(metrics.expectedLossAmount / 1e8).toFixed(2)} 亿元 (${metrics.expectedLossPercent}%)`,
      currencyOrUnit: 'CNY',
      calculationDate: '2026-09-17',
      isDemo: true,
      steps: [
        {
          stepNumber: 1,
          stepTitle: '市场行情输入与利差提取',
          description: '从基准做市商提取 100+ 参考实体 5Y CDS 利差中位数。',
          formula: 'S_avg = Sum(w_i * S_i) = 146 bps',
          inputValues: { '实体总数': 100, '利差范围': '24bp - 1850bp', '加权回收率': '40.0%' },
          outputValue: '146 bps',
          dataSourceOrModel: 'MarketDataService v1.4',
        },
        {
          stepNumber: 2,
          stepTitle: 'ISDA 信用期限结构与违约强度自举',
          description: '根据 CDS Spread 及 40% 回收率校准单实体恒定违约强度 lambda。',
          formula: 'lambda_i ≈ S_i / (1 - R_i)',
          inputValues: { '加权平均 lambda': '0.0243', '5Y 违约概率 PD': '11.45%' },
          outputValue: 'PD_5Y = 11.45%',
          dataSourceOrModel: 'ISDA_CDS_BOOTSTRAP v3.2',
        },
        {
          stepNumber: 3,
          stepTitle: '单因子高斯 Copula 违约相关性联结',
          description: '引入系统宏观因子 M 及资产相关性 rho=32.4%，计算联合违约概率空间。',
          formula: 'p_i(M) = Phi( (Phi^{-1}(PD_i) - sqrt(rho)*M) / sqrt(1 - rho) )',
          inputValues: { 'rho': `${(systemCorrelation * 100).toFixed(1)}%`, '系统因子方差': '1.0' },
          outputValue: 'p_cond(M) 积分曲面',
          dataSourceOrModel: 'GAUSSIAN_COPULA_CORE v2.1.0',
        },
        {
          stepNumber: 4,
          stepTitle: '100,000 路径蒙特卡洛积分求解组合损失期望',
          description: '向量化生成全资产池联合违约损失样本，求取期望均值与尾部百分位数。',
          formula: 'E[L] = (1/N_sim) * Sum( Loss_p ) = 2.572%',
          inputValues: { '模拟路径数': metrics.simulationPaths, '总名义本金': '¥482.0 亿元' },
          outputValue: `¥${(metrics.expectedLossAmount / 1e8).toFixed(2)} 亿元`,
          dataSourceOrModel: 'RUST_CORE_AVX2 (Rust Engine)',
        },
      ],
    });
  };

  const showVarLineage = () => {
    onOpenDataLineage({
      metricName: '99% 信用风险价值 (99% Credit VaR)',
      calculatedValue: `¥${(metrics.var99Amount / 1e8).toFixed(2)} 亿元`,
      currencyOrUnit: 'CNY',
      calculationDate: '2026-09-17',
      isDemo: true,
      steps: [
        {
          stepNumber: 1,
          stepTitle: '生成 100,000 条蒙特卡洛独立损失路径',
          description: '对偶正态抽样，得到按损失升序排列的离散分位数序列。',
          formula: 'L_{(1)} <= L_{(2)} <= ... <= L_{(100000)}',
          inputValues: { '样本容量': metrics.simulationPaths },
          outputValue: '100,000 路径有序数组',
          dataSourceOrModel: 'Rust Monte Carlo Core',
        },
        {
          stepNumber: 2,
          stepTitle: '提取第 99% 分位数损失临界值',
          description: '排序索引 idx = 99,000 处的损失率乘以组合总本金。',
          formula: 'VaR_0.99 = TotalNotional * L_{(99000)}',
          inputValues: { '99% 损失临界率': `${((metrics.var99Amount / metrics.totalNotional) * 100).toFixed(2)}%` },
          outputValue: `¥${(metrics.var99Amount / 1e8).toFixed(2)} 亿元`,
          dataSourceOrModel: 'LossDistributionEngine v2.0',
        },
      ],
    });
  };

  // SVG 损失分布曲线参数
  const svgWidth = 800;
  const svgHeight = 240;
  const maxLossX = Math.max(0.20, (metrics.var999Amount / metrics.totalNotional) * 1.3);
  const maxDensityY = Math.max(...lossDistribution.map((p) => p.probabilityDensity), 8);

  const getSvgX = (lossRatio: number) => (lossRatio / maxLossX) * svgWidth;
  const getSvgY = (density: number) => svgHeight - (density / maxDensityY) * (svgHeight - 30);

  // 构造 SVG 路径
  let pathD = `M 0 ${svgHeight}`;
  lossDistribution.forEach((pt) => {
    const x = getSvgX(pt.lossPercentage);
    const y = getSvgY(pt.probabilityDensity);
    pathD += ` L ${x.toFixed(1)} ${y.toFixed(1)}`;
  });
  pathD += ` L ${svgWidth} ${svgHeight} Z`;

  // Tranche 颜色映射
  const trancheColors: Record<string, { fill: string; stroke: string; badge: string; text: string }> = {
    Equity: { fill: 'fill-red-500/25', stroke: 'stroke-red-500', badge: 'bg-red-950/80 text-red-300 border-red-700/50', text: 'text-red-400' },
    Mezzanine: { fill: 'fill-amber-500/25', stroke: 'stroke-amber-500', badge: 'bg-amber-950/80 text-amber-300 border-amber-700/50', text: 'text-amber-400' },
    SeniorMezz: { fill: 'fill-yellow-500/25', stroke: 'stroke-yellow-500', badge: 'bg-yellow-950/80 text-yellow-300 border-yellow-700/50', text: 'text-yellow-400' },
    Senior: { fill: 'fill-blue-500/20', stroke: 'stroke-blue-500', badge: 'bg-blue-950/80 text-blue-300 border-blue-700/50', text: 'text-blue-400' },
    SuperSenior: { fill: 'fill-emerald-500/15', stroke: 'stroke-emerald-500', badge: 'bg-emerald-950/80 text-emerald-300 border-emerald-700/50', text: 'text-emerald-400' },
  };

  return (
    <div className="space-y-4 text-slate-200">
      {/* 顶部标题与快捷操作 */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#101827] p-3.5 rounded-lg border border-[#1e293b]">
        <div>
          <div className="flex items-center space-x-2.5">
            <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
              <span>合成 CDO 风险与交易中心 (Synthetic CDO Risk & Trading Desk)</span>
            </h2>
            <span className="text-[10px] bg-blue-950 text-blue-300 border border-blue-800/50 px-2 py-0.5 rounded font-mono">
              实时量化计量中
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            交易编号: <span className="font-mono text-cyan-300">DEAL-HX-2026-01</span> · 
            标的资产: <span className="text-slate-200">100+ 高信用参考实体 CDS 资产池</span> · 
            数据来源: <span className="text-amber-300 font-medium">演示市场数据 (已全量校准)</span>
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={onOpenCreditEventModal}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded bg-red-950/80 hover:bg-red-900 text-red-200 border border-red-700/50 text-xs font-medium cursor-pointer transition-colors"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>模拟信用违约事件</span>
          </button>
          <button
            onClick={() => onNavigateToTab('stress')}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded bg-[#16233b] hover:bg-[#203254] text-slate-200 border border-[#2b3e5f] text-xs font-medium cursor-pointer transition-colors"
          >
            <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
            <span>执行宏观压力测试</span>
          </button>
        </div>
      </div>

      {/* 核心 KPI 指标看板 (严格依据提示词规范呈现) */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-2.5">
        {/* 1. 组合名义本金 */}
        <div className="bg-[#121b2b] p-3 rounded-lg border border-[#1e2d45] hover:border-blue-500/50 transition-colors">
          <div className="text-[11px] text-slate-400">组合名义本金</div>
          <div className="text-base font-bold font-mono text-slate-100 mt-1">
            ¥{(metrics.totalNotional / 1e8).toFixed(1)} bn
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Total Deal Notional</div>
        </div>

        {/* 2. 参考实体 */}
        <div className="bg-[#121b2b] p-3 rounded-lg border border-[#1e2d45] hover:border-blue-500/50 transition-colors">
          <div className="text-[11px] text-slate-400">参考实体数</div>
          <div className="text-base font-bold font-mono text-cyan-300 mt-1">
            842 <span className="text-[10px] text-slate-400 font-normal">/ 100 Active</span>
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Reference Entities</div>
        </div>

        {/* 3. CDS 名义本金 */}
        <div className="bg-[#121b2b] p-3 rounded-lg border border-[#1e2d45] hover:border-blue-500/50 transition-colors">
          <div className="text-[11px] text-slate-400">CDS 名义本金</div>
          <div className="text-base font-bold font-mono text-slate-100 mt-1">
            ¥41.7 bn
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">CDS Gross Notional</div>
        </div>

        {/* 4. 当前预期损失 */}
        <div 
          onClick={showElLineage}
          className="bg-[#121b2b] p-3 rounded-lg border border-[#1e2d45] hover:border-amber-500/60 cursor-pointer transition-all group"
          title="点击查看数据血缘与计算推导"
        >
          <div className="text-[11px] text-slate-400 flex items-center justify-between">
            <span>当前预期损失</span>
            <HelpCircle className="w-3 h-3 text-slate-500 group-hover:text-amber-400" />
          </div>
          <div className="text-base font-bold font-mono text-amber-300 mt-1 flex items-center justify-between">
            <span>¥{(metrics.expectedLossAmount / 1e8).toFixed(2)} bn</span>
            <span className="text-[10px] font-normal text-amber-400/80">({metrics.expectedLossPercent}%)</span>
          </div>
          <div className="text-[10px] text-amber-400/70 mt-0.5 flex items-center space-x-1">
            <span>可追溯</span>
            <ArrowUpRight className="w-2.5 h-2.5" />
          </div>
        </div>

        {/* 5. 99% VaR */}
        <div 
          onClick={showVarLineage}
          className="bg-[#121b2b] p-3 rounded-lg border border-[#1e2d45] hover:border-red-500/60 cursor-pointer transition-all group"
          title="点击查看 99% VaR 数据血缘"
        >
          <div className="text-[11px] text-slate-400 flex items-center justify-between">
            <span>99% 信用 VaR</span>
            <HelpCircle className="w-3 h-3 text-slate-500 group-hover:text-red-400" />
          </div>
          <div className="text-base font-bold font-mono text-red-400 mt-1">
            ¥{(metrics.var99Amount / 1e8).toFixed(2)} bn
          </div>
          <div className="text-[10px] text-red-400/70 mt-0.5 flex items-center space-x-1">
            <span>5Y 99% 临界损失</span>
          </div>
        </div>

        {/* 6. 99.9% ES */}
        <div className="bg-[#121b2b] p-3 rounded-lg border border-[#1e2d45] hover:border-red-500/50 transition-colors">
          <div className="text-[11px] text-slate-400">99.9% 预期尾损 ES</div>
          <div className="text-base font-bold font-mono text-red-300 mt-1">
            ¥{(metrics.es999Amount / 1e8).toFixed(2)} bn
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Expected Shortfall</div>
        </div>

        {/* 7. 平均信用利差 */}
        <div className="bg-[#121b2b] p-3 rounded-lg border border-[#1e2d45] hover:border-blue-500/50 transition-colors">
          <div className="text-[11px] text-slate-400">平均信用利差</div>
          <div className="text-base font-bold font-mono text-blue-300 mt-1">
            {metrics.averageCdsSpread} bp
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Weighted CDS Spread</div>
        </div>

        {/* 8. 平均相关性 & 状态 */}
        <div className="bg-[#121b2b] p-3 rounded-lg border border-[#1e2d45] hover:border-emerald-500/50 transition-colors">
          <div className="text-[11px] text-slate-400 flex items-center justify-between">
            <span>平均相关性 / 状态</span>
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          </div>
          <div className="text-base font-bold font-mono text-emerald-300 mt-1 flex items-center space-x-1.5">
            <span>{(systemCorrelation * 100).toFixed(1)}%</span>
            <span className="text-[10px] bg-emerald-950 text-emerald-300 px-1.5 py-0.2 rounded border border-emerald-800 font-sans">
              正常
            </span>
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Copula Rho (Asset Corr)</div>
        </div>
      </div>

      {/* 核心图表与分层损失分布可视化区 */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* 左侧：组合损失分布曲线与 Tranche 穿透映射 */}
        <div className="lg:col-span-8 bg-[#101827] p-4 rounded-lg border border-[#1e293b] space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#1e293b] pb-2.5">
            <div>
              <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2">
                <BarChart2 className="w-4 h-4 text-blue-400" />
                <span>组合损失概率密度分布与分层吸收区 (Portfolio Loss Distribution)</span>
              </h3>
              <p className="text-[11px] text-slate-400">
                基于 {metrics.simulationPaths.toLocaleString()} 次高斯 Copula 蒙特卡洛模拟 · 彩色区间对应各 Tranche 损失吸收带宽
              </p>
            </div>

            {/* 相关性即时调节滑块 */}
            <div className="flex items-center space-x-2 bg-[#152136] px-3 py-1.5 rounded border border-[#233554] text-xs font-mono">
              <span className="text-slate-400 text-[11px]">系统相关性 $\rho$:</span>
              <input
                type="range"
                min={0.05}
                max={0.75}
                step={0.01}
                value={systemCorrelation}
                onChange={(e) => onCorrelationChange(Number(e.target.value))}
                className="w-24 accent-blue-500 cursor-pointer"
              />
              <span className="font-bold text-cyan-300 min-w-[40px]">
                {(systemCorrelation * 100).toFixed(1)}%
              </span>
            </div>
          </div>

          {/* SVG 损失密度与分层色块 */}
          <div className="relative bg-[#0a0f18] p-2 rounded border border-[#1b263b] overflow-hidden">
            <svg
              viewBox={`0 0 ${svgWidth} ${svgHeight}`}
              className="w-full h-56 select-none"
              preserveAspectRatio="none"
            >
              <defs>
                <linearGradient id="lossGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.4" />
                  <stop offset="100%" stopColor="#1e3a8a" stopOpacity="0.05" />
                </linearGradient>
              </defs>

              {/* 网格线 */}
              {[0.05, 0.10, 0.15, 0.20, 0.25].map((gridLoss) => {
                const x = getSvgX(gridLoss);
                if (x > svgWidth) return null;
                return (
                  <g key={gridLoss}>
                    <line x1={x} y1={0} x2={x} y2={svgHeight} stroke="#1e293b" strokeDasharray="3,3" />
                    <text x={x + 3} y={svgHeight - 6} fill="#64748b" fontSize="9" fontFamily="monospace">
                      {(gridLoss * 100).toFixed(0)}%
                    </text>
                  </g>
                );
              })}

              {/* Tranche 垂直吸收带背景 */}
              {tranches.map((t) => {
                const xA = getSvgX(t.attachmentPoint);
                const xD = getSvgX(Math.min(maxLossX, t.detachmentPoint));
                const width = Math.max(2, xD - xA);
                const style = trancheColors[t.category] || trancheColors.Mezzanine;

                return (
                  <g key={t.id}>
                    <rect
                      x={xA}
                      y={0}
                      width={width}
                      height={svgHeight}
                      className={style.fill}
                    />
                    <line
                      x1={xA}
                      y1={0}
                      x2={xA}
                      y2={svgHeight}
                      className={style.stroke}
                      strokeWidth="1.5"
                      strokeDasharray={t.attachmentPoint === 0 ? undefined : '2,2'}
                    />
                    {/* 顶部 Tranche 标签 */}
                    <text
                      x={xA + 4}
                      y={14}
                      fill="#e2e8f0"
                      fontSize="9"
                      fontWeight="bold"
                      fontFamily="sans-serif"
                    >
                      {t.name.split(' ')[0]} ({(t.attachmentPoint * 100).toFixed(0)}-{(t.detachmentPoint * 100).toFixed(0)}%)
                    </text>
                  </g>
                );
              })}

              {/* 损失密度曲线 Area */}
              <path d={pathD} fill="url(#lossGradient)" />
              <path
                d={pathD.replace(/ Z$/, '')}
                fill="none"
                stroke="#60a5fa"
                strokeWidth="2.5"
              />

              {/* Expected Loss 标线 */}
              {(() => {
                const elRatio = metrics.expectedLossAmount / metrics.totalNotional;
                const xEl = getSvgX(elRatio);
                return (
                  <g>
                    <line x1={xEl} y1={0} x2={xEl} y2={svgHeight} stroke="#f59e0b" strokeWidth="2" strokeDasharray="4,2" />
                    <text x={xEl + 4} y={35} fill="#f59e0b" fontSize="10" fontWeight="bold" fontFamily="monospace">
                      EL: {(elRatio * 100).toFixed(2)}% (¥{(metrics.expectedLossAmount / 1e8).toFixed(2)}亿)
                    </text>
                  </g>
                );
              })()}

              {/* 99% VaR 标线 */}
              {(() => {
                const varRatio = metrics.var99Amount / metrics.totalNotional;
                const xVar = getSvgX(varRatio);
                return (
                  <g>
                    <line x1={xVar} y1={0} x2={xVar} y2={svgHeight} stroke="#ef4444" strokeWidth="2" strokeDasharray="4,2" />
                    <text x={xVar + 4} y={55} fill="#ef4444" fontSize="10" fontWeight="bold" fontFamily="monospace">
                      99% VaR: {(varRatio * 100).toFixed(2)}%
                    </text>
                  </g>
                );
              })()}
            </svg>
          </div>

          {/* 图例与说明 */}
          <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400 font-mono">
            <div className="flex items-center space-x-3">
              <span className="flex items-center space-x-1">
                <span className="w-2.5 h-2.5 rounded-xs bg-red-500 inline-block" />
                <span>权益层 0-3%</span>
              </span>
              <span className="flex items-center space-x-1">
                <span className="w-2.5 h-2.5 rounded-xs bg-amber-500 inline-block" />
                <span>夹层 A 3-7%</span>
              </span>
              <span className="flex items-center space-x-1">
                <span className="w-2.5 h-2.5 rounded-xs bg-yellow-500 inline-block" />
                <span>夹层 B 7-10%</span>
              </span>
              <span className="flex items-center space-x-1">
                <span className="w-2.5 h-2.5 rounded-xs bg-blue-500 inline-block" />
                <span>高级层 10-15%</span>
              </span>
              <span className="flex items-center space-x-1">
                <span className="w-2.5 h-2.5 rounded-xs bg-emerald-500 inline-block" />
                <span>超高级层 15-100%</span>
              </span>
            </div>
            <div className="text-slate-400">
              偏度: <span className="text-slate-200">{metrics.skewness}</span> · 峰度: <span className="text-slate-200">{metrics.kurtosis}</span>
            </div>
          </div>
        </div>

        {/* 右侧：分层结构快速调整与参数面板 */}
        <div className="lg:col-span-4 bg-[#101827] p-4 rounded-lg border border-[#1e293b] flex flex-col justify-between space-y-3">
          <div>
            <div className="flex items-center justify-between border-b border-[#1e293b] pb-2 mb-3">
              <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-1.5">
                <Layers className="w-4 h-4 text-cyan-400" />
                <span>分层结构与资本厚度 (Tranche Thickness)</span>
              </h3>
              <button
                onClick={() => onNavigateToTab('structuring')}
                className="text-[11px] text-blue-400 hover:text-blue-300 cursor-pointer font-medium"
              >
                进入结构设计器 →
              </button>
            </div>

            <div className="space-y-2.5">
              {tranches.map((t) => {
                const style = trancheColors[t.category] || trancheColors.Mezzanine;
                return (
                  <div key={t.id} className="bg-[#141e30] p-2.5 rounded border border-[#20304a] text-xs space-y-1">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <span className={`px-1.5 py-0.5 rounded text-[10px] font-semibold border ${style.badge}`}>
                          {t.name}
                        </span>
                        <span className="font-mono text-slate-300 font-bold">
                          {(t.attachmentPoint * 100).toFixed(1)}% – {(t.detachmentPoint * 100).toFixed(1)}%
                        </span>
                      </div>
                      <span className="font-mono font-bold text-slate-200">
                        ¥{(t.notional / 1e8).toFixed(2)} 亿
                      </span>
                    </div>

                    <div className="grid grid-cols-3 gap-1 font-mono text-[11px] text-slate-400 pt-1">
                      <div>
                        预期损失: <span className={`font-bold ${t.expectedLossPercent > 10 ? 'text-red-400' : 'text-slate-200'}`}>{t.expectedLossPercent.toFixed(2)}%</span>
                      </div>
                      <div>
                        平价利差: <span className="text-amber-300 font-bold">{t.fairSpreadBp} bp</span>
                      </div>
                      <div className="text-right">
                        净现值 PV: <span className={t.pv >= 0 ? 'text-emerald-400' : 'text-red-400'}>{t.pv > 0 ? '+' : ''}{(t.pv / 1e6).toFixed(1)}M</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="bg-[#0b1322] p-2.5 rounded border border-[#1b2b48] text-[11px] text-slate-300 space-y-1">
            <div className="font-bold text-slate-200 flex items-center justify-between">
              <span>资本与结构合规审查:</span>
              <span className="text-emerald-400 font-mono">已完全分层 (100%)</span>
            </div>
            <p className="text-slate-400 leading-normal">
              优先级层级受 10% 底层资产厚度保护，在基准情景下违约损失穿透概率小于 0.65%。
            </p>
          </div>
        </div>
      </div>

      {/* 底部：Tranche 详细量化定价与 Greeks 表格 */}
      <div className="bg-[#101827] p-4 rounded-lg border border-[#1e293b] space-y-3">
        <div className="flex items-center justify-between border-b border-[#1e293b] pb-2">
          <div className="flex items-center space-x-2">
            <TrendingUp className="w-4 h-4 text-emerald-400" />
            <h3 className="font-bold text-sm text-slate-100">分层结构定价矩阵与风险 Greeks (Tranche Pricing & Sensitivity Matrix)</h3>
          </div>
          <span className="text-[11px] text-slate-400">
            * 每一个价格均可点击查看数据推导链条
          </span>
        </div>

        <div className="overflow-x-auto border border-[#1e2d48] rounded">
          <table className="w-full text-left font-mono text-xs">
            <thead className="bg-[#15233c] text-slate-300 text-[11px]">
              <tr>
                <th className="p-2.5">Tranche 分层名称</th>
                <th className="p-2.5">触发点 / 终止点</th>
                <th className="p-2.5">名义本金</th>
                <th className="p-2.5">预期损失率 (EL)</th>
                <th className="p-2.5">平价利差 (Fair Spread)</th>
                <th className="p-2.5">前置费率 (Upfront)</th>
                <th className="p-2.5">净现值 (PV)</th>
                <th className="p-2.5">CS01 (利差敏感度)</th>
                <th className="p-2.5">相关性 Delta</th>
                <th className="p-2.5 text-right">数据血缘</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1c2a42]">
              {tranches.map((t) => (
                <tr key={t.id} className="hover:bg-[#131e33] transition-colors">
                  <td className="p-2.5 font-sans font-bold text-slate-100 flex items-center space-x-1.5">
                    <span>{t.name}</span>
                  </td>
                  <td className="p-2.5 text-cyan-300">
                    {(t.attachmentPoint * 100).toFixed(1)}% – {(t.detachmentPoint * 100).toFixed(1)}%
                  </td>
                  <td className="p-2.5 text-slate-200">
                    ¥{(t.notional / 1e8).toFixed(2)} 亿元
                  </td>
                  <td className="p-2.5 text-red-300 font-bold">
                    {t.expectedLossPercent.toFixed(2)}% (¥{(t.expectedLossAmount / 1e8).toFixed(2)}亿)
                  </td>
                  <td className="p-2.5 text-amber-300 font-bold">
                    {t.fairSpreadBp} bp
                  </td>
                  <td className="p-2.5 text-slate-300">
                    {t.upfrontFeePercent.toFixed(2)}%
                  </td>
                  <td className="p-2.5 font-bold">
                    <span className={t.pv >= 0 ? 'text-emerald-400' : 'text-red-400'}>
                      ¥{(t.pv / 1e6).toFixed(2)} M
                    </span>
                  </td>
                  <td className="p-2.5 text-slate-300">
                    {t.cs01} / bp
                  </td>
                  <td className="p-2.5 text-cyan-300">
                    {t.correlationDelta} / 1%
                  </td>
                  <td className="p-2.5 text-right">
                    <button
                      onClick={() => {
                        onOpenDataLineage({
                          metricName: `${t.name} 平价利差与估值`,
                          calculatedValue: `${t.fairSpreadBp} bp / PV ¥${(t.pv / 1e6).toFixed(2)}M`,
                          currencyOrUnit: 'CNY',
                          calculationDate: '2026-09-17',
                          isDemo: true,
                          steps: [
                            {
                              stepNumber: 1,
                              stepTitle: '分层区间截断函数',
                              description: '根据分层 Attachment (A) 与 Detachment (D) 构造损失穿透收益结构。',
                              formula: 'L_tranche(L) = (min(L, D) - min(L, A)) / (D - A)',
                              inputValues: { 'A': `${(t.attachmentPoint*100).toFixed(1)}%`, 'D': `${(t.detachmentPoint*100).toFixed(1)}%` },
                              outputValue: '分层分段损失算子',
                              dataSourceOrModel: 'TrancheLossEngine v2.0',
                            },
                            {
                              stepNumber: 2,
                              stepTitle: '损失分布密度积分求解期望损失',
                              description: '将组合损失概率密度 f(l) 与分层函数进行求积。',
                              formula: 'E[L_tranche] = Integral L_tranche(l) f(l) dl',
                              inputValues: { 'E[L]': `${t.expectedLossPercent.toFixed(2)}%` },
                              outputValue: `¥${(t.expectedLossAmount/1e8).toFixed(2)} 亿元`,
                              dataSourceOrModel: 'LossDistributionEngine',
                            },
                            {
                              stepNumber: 3,
                              stepTitle: '现金流保费端与保护端贴现配比',
                              description: '以 5Y 季度 IMM 日程进行贴现积分，得出平价利差。',
                              formula: 'Fair Spread = PV(Protection) / PV(Premium 1bp)',
                              inputValues: { '无风险利率': '2.5%', 'Protection PV': `¥${(t.protectionLegPv/1e6).toFixed(2)}M` },
                              outputValue: `${t.fairSpreadBp} bps`,
                              dataSourceOrModel: 'PricingEngine v3.1',
                            },
                          ],
                        });
                      }}
                      className="px-2 py-0.5 bg-[#1a2942] hover:bg-blue-600 text-blue-300 hover:text-white rounded border border-[#2c4066] text-[10px] cursor-pointer transition-colors"
                    >
                      为什么？
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
