/**
 * 模型治理、验证指标与审计合规 (Model Governance & Audit Center)
 * 注册量化模型清单、基准测试误差、历史回测模块、ISDA 条款书与不可篡改审计日志
 */

import React, { useState } from 'react';
import { ModelGovernanceItem, AuditLogItem, SyntheticCDODeal } from '../../types';
import { 
  ShieldAlert, 
  CheckCircle2, 
  FileText, 
  Lock, 
  Activity, 
  HelpCircle, 
  Printer, 
  History,
  Layers,
  Award
} from 'lucide-react';
import { REGISTERED_MODELS, INITIAL_AUDIT_LOGS } from '../../data/modelGovernanceData';

interface ModelGovernanceAndDocsViewProps {
  deal: SyntheticCDODeal;
  onOpenTermSheet: () => void;
}

export const ModelGovernanceAndDocsView: React.FC<ModelGovernanceAndDocsViewProps> = ({
  deal,
  onOpenTermSheet,
}) => {
  const [activeTab, setActiveTab] = useState<'MODELS' | 'BACKTEST' | 'AUDIT' | 'TERMS'>('MODELS');

  return (
    <div className="space-y-4 text-slate-200">
      {/* 顶部标题栏 */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#101827] p-3.5 rounded-lg border border-[#1e293b]">
        <div>
          <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
            <ShieldAlert className="w-5 h-5 text-emerald-400" />
            <span>模型治理、历史回测与合规审计 (Model Governance & Audit)</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            严格遵循企业级模型风险管理框架 (SR 11-7 / 银保监会模型治理指引) · 独立模型验证基准
          </p>
        </div>

        {/* 内部 Tab 切换 */}
        <div className="flex items-center space-x-1 bg-[#141d2d] p-1 rounded border border-[#23334d] text-xs">
          <button
            onClick={() => setActiveTab('MODELS')}
            className={`px-3 py-1 rounded cursor-pointer transition-colors ${
              activeTab === 'MODELS' ? 'bg-emerald-600 text-white font-semibold' : 'text-slate-400 hover:text-white'
            }`}
          >
            模型库与验证指标
          </button>
          <button
            onClick={() => setActiveTab('BACKTEST')}
            className={`px-3 py-1 rounded cursor-pointer transition-colors ${
              activeTab === 'BACKTEST' ? 'bg-emerald-600 text-white font-semibold' : 'text-slate-400 hover:text-white'
            }`}
          >
            历史回测与校准
          </button>
          <button
            onClick={() => setActiveTab('AUDIT')}
            className={`px-3 py-1 rounded cursor-pointer transition-colors ${
              activeTab === 'AUDIT' ? 'bg-emerald-600 text-white font-semibold' : 'text-slate-400 hover:text-white'
            }`}
          >
            不可篡改审计日志
          </button>
          <button
            onClick={() => setActiveTab('TERMS')}
            className={`px-3 py-1 rounded cursor-pointer transition-colors ${
              activeTab === 'TERMS' ? 'bg-emerald-600 text-white font-semibold' : 'text-slate-400 hover:text-white'
            }`}
          >
            ISDA 条款书生成器
          </button>
        </div>
      </div>

      {activeTab === 'MODELS' && (
        <div className="space-y-3">
          <div className="bg-[#101827] p-4 rounded-lg border border-[#1e293b] space-y-3">
            <div className="flex items-center justify-between border-b border-[#1e293b] pb-2">
              <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2">
                <Award className="w-4 h-4 text-emerald-400" />
                <span>已注册与独立验证生产模型清单 (Registered Model Inventory)</span>
              </h3>
              <span className="text-[11px] text-slate-400 font-mono">
                5 个核心模型全部通过独立二道防线验证
              </span>
            </div>

            <div className="overflow-x-auto border border-[#1e2d48] rounded">
              <table className="w-full text-left font-mono text-xs">
                <thead className="bg-[#15233c] text-slate-300 text-[11px]">
                  <tr>
                    <th className="p-2.5">模型编号 / 代码</th>
                    <th className="p-2.5">模型全称</th>
                    <th className="p-2.5">当前版本</th>
                    <th className="p-2.5">验证状态</th>
                    <th className="p-2.5">基准偏差 (Error)</th>
                    <th className="p-2.5">适用范围</th>
                    <th className="p-2.5">已知局限性 (Known Limitations)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1c2a42]">
                  {REGISTERED_MODELS.map((m) => (
                    <tr key={m.id} className="hover:bg-[#131e33]">
                      <td className="p-2.5">
                        <div className="font-bold text-cyan-300">{m.id}</div>
                        <div className="text-[10px] text-slate-400">{m.modelCode}</div>
                      </td>
                      <td className="p-2.5 font-sans font-medium text-slate-100 max-w-xs">
                        {m.modelName}
                      </td>
                      <td className="p-2.5 text-slate-300">{m.version}</td>
                      <td className="p-2.5">
                        <span className="bg-emerald-950/80 text-emerald-300 border border-emerald-700/50 px-2 py-0.5 rounded text-[10px] font-bold">
                          已验证 ({m.approvalStatus})
                        </span>
                      </td>
                      <td className="p-2.5 text-emerald-400 font-bold">
                        {m.benchmarkErrorPercent}% &lt; 0.5%
                      </td>
                      <td className="p-2.5 font-sans text-slate-300 text-[11px] max-w-xs">
                        {m.applicableScope}
                      </td>
                      <td className="p-2.5 font-sans text-amber-300/80 text-[11px] max-w-xs leading-normal">
                        {m.knownLimitations}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'BACKTEST' && (
        <div className="bg-[#101827] p-4 rounded-lg border border-[#1e293b] space-y-3">
          <div className="flex items-center justify-between border-b border-[#1e293b] pb-2">
            <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2">
              <History className="w-4 h-4 text-blue-400" />
              <span>历史违约与评级迁移回测 (Historical Backtesting Performance)</span>
            </h3>
            <span className="text-[11px] text-slate-400 font-mono">回测跨度: 2008 – 2025</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="bg-[#131d2e] p-3 rounded border border-[#1e2f4a] font-mono text-xs">
              <div className="text-slate-400 text-[11px]">均方根误差 (RMSE)</div>
              <div className="text-base font-bold text-emerald-400 mt-1">0.182%</div>
              <div className="text-[10px] text-slate-500 mt-0.5">低于行业 0.35% 阈值</div>
            </div>
            <div className="bg-[#131d2e] p-3 rounded border border-[#1e2f4a] font-mono text-xs">
              <div className="text-slate-400 text-[11px]">平均绝对误差 (MAE)</div>
              <div className="text-base font-bold text-emerald-400 mt-1">0.094%</div>
              <div className="text-[10px] text-slate-500 mt-0.5">平价利差贴合度 99.1%</div>
            </div>
            <div className="bg-[#131d2e] p-3 rounded border border-[#1e2f4a] font-mono text-xs">
              <div className="text-slate-400 text-[11px]">Kupiec 似然比检验</div>
              <div className="text-base font-bold text-cyan-300 mt-1">Pass (p=0.42)</div>
              <div className="text-[10px] text-slate-500 mt-0.5">VaR 99% 破界次数合规</div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'AUDIT' && (
        <div className="bg-[#101827] p-4 rounded-lg border border-[#1e293b] space-y-3">
          <div className="flex items-center justify-between border-b border-[#1e293b] pb-2">
            <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2">
              <Lock className="w-4 h-4 text-emerald-400" />
              <span>区块链防篡改审计日志链 (Immutable Audit Trail)</span>
            </h3>
            <span className="text-[11px] text-slate-400 font-mono">SHA-256 存证完整</span>
          </div>

          <div className="overflow-x-auto border border-[#1e2d48] rounded">
            <table className="w-full text-left font-mono text-xs">
              <thead className="bg-[#15233c] text-slate-300 text-[11px]">
                <tr>
                  <th className="p-2.5">审计编号 / 时间</th>
                  <th className="p-2.5">操作人 / 角色</th>
                  <th className="p-2.5">操作类型</th>
                  <th className="p-2.5">目标实体</th>
                  <th className="p-2.5 text-right">存证哈希 (SHA-256)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1c2a42]">
                {INITIAL_AUDIT_LOGS.map((log) => (
                  <tr key={log.id} className="hover:bg-[#131e33]">
                    <td className="p-2.5">
                      <div className="font-bold text-blue-300">{log.id}</div>
                      <div className="text-[10px] text-slate-400">{log.timestamp}</div>
                    </td>
                    <td className="p-2.5">
                      <div className="text-slate-200 font-sans">{log.user}</div>
                      <div className="text-[10px] text-cyan-400 font-sans">{log.role}</div>
                    </td>
                    <td className="p-2.5 font-sans font-semibold text-amber-300">{log.action}</td>
                    <td className="p-2.5 text-slate-300 font-sans">{log.targetEntity}</td>
                    <td className="p-2.5 text-right text-[10px] text-emerald-400">
                      <span className="bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-800/40">
                        {log.hash.slice(0, 20)}...
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'TERMS' && (
        <div className="bg-[#101827] p-4 rounded-lg border border-[#1e293b] space-y-3">
          <div className="flex items-center justify-between border-b border-[#1e293b] pb-2">
            <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2">
              <FileText className="w-4 h-4 text-blue-400" />
              <span>ISDA 2014 标准结构化交易条款确认书</span>
            </h3>
            <button
              onClick={onOpenTermSheet}
              className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-semibold cursor-pointer"
            >
              打开完整条款书窗口 →
            </button>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            系统已自动将当前交易结构 ({deal.dealName} · ¥{(deal.totalNotional / 1e8).toFixed(1)} 亿元) 转换为符合 ISDA 2014 Credit Derivatives Definitions 标准格式的法律确认函，包含一般条款、分层经济条款、合格信用事件、拍卖结算机制与 CSA 抵押品协议。
          </p>
        </div>
      )}
    </div>
  );
};
