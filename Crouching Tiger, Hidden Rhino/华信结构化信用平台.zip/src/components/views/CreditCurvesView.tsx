/**
 * 信用曲线与违约模型 (Credit Curves & Default Models)
 * 期限结构利差曲面、ISDA 标准违约强度自举校准、生存概率 S(t) 与违约概率 F(t) 演化
 */

import React, { useState } from 'react';
import { ReferenceEntity, CreditCurvePoint } from '../../types';
import { 
  TrendingUp, 
  Activity, 
  HelpCircle, 
  Sliders, 
  Cpu, 
  CheckCircle2,
  BarChart3
} from 'lucide-react';
import { calibrateHazardRate, calculateSurvivalProb, generateCurveEvolution } from '../../math/hazardRate';

interface CreditCurvesViewProps {
  entities: ReferenceEntity[];
}

export const CreditCurvesView: React.FC<CreditCurvesViewProps> = ({ entities }) => {
  const [selectedEntityId, setSelectedEntityId] = useState<string>(entities[0]?.id || '');
  const [modelType, setModelType] = useState<string>('PIECEWISE_HAZARD');
  const [overrideSpread5Y, setOverrideSpread5Y] = useState<number>(146);
  const [overrideRecovery, setOverrideRecovery] = useState<number>(40);

  const selectedEntity = entities.find((e) => e.id === selectedEntityId) || entities[0];

  const effectiveSpread = overrideSpread5Y || (selectedEntity ? selectedEntity.cdsSpread5Y : 146);
  const effectiveRecovery = overrideRecovery / 100.0;
  const calibratedHazard = calibrateHazardRate(effectiveSpread, effectiveRecovery);

  // 生成 10 年期期限演化曲线 (10个时间节点)
  const curvePoints = generateCurveEvolution(calibratedHazard, 10, 1.0);

  return (
    <div className="space-y-4 text-slate-200">
      {/* 顶部标题栏 */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#101827] p-3.5 rounded-lg border border-[#1e293b]">
        <div>
          <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
            <TrendingUp className="w-5 h-5 text-emerald-400" />
            <span>信用曲线与违约模型 (Credit Curves & Default Models)</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            ISDA 标准违约强度 (Hazard Rate $\lambda$) 自举校准、全期限生存曲线与结构化强度模型标定
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <span className="text-xs bg-blue-950/80 text-blue-300 border border-blue-800/50 px-2.5 py-1 rounded font-mono">
            标准: ISDA Standard CDS Model v3.2
          </span>
        </div>
      </div>

      {/* 模型选择与校准交互区 */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* 左侧：参数校准面板 */}
        <div className="lg:col-span-4 bg-[#101827] p-4 rounded-lg border border-[#1e293b] space-y-3">
          <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2 border-b border-[#1e293b] pb-2">
            <Sliders className="w-4 h-4 text-cyan-400" />
            <span>违约强度校准引擎 (Hazard Calibration)</span>
          </h3>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block text-slate-400 mb-1">选择参考实体 (Reference Entity):</label>
              <select
                value={selectedEntityId}
                onChange={(e) => {
                  setSelectedEntityId(e.target.value);
                  const ent = entities.find((ent) => ent.id === e.target.value);
                  if (ent) {
                    setOverrideSpread5Y(ent.cdsSpread5Y);
                    setOverrideRecovery(Math.round(ent.recoveryRate * 100));
                  }
                }}
                className="w-full bg-[#152136] border border-[#273a5a] rounded p-2 text-slate-100 font-mono text-xs focus:outline-none focus:border-blue-500"
              >
                {entities.slice(0, 40).map((e) => (
                  <option key={e.id} value={e.id}>
                    [{e.id}] {e.name} ({e.rating} · 5Y {e.cdsSpread5Y}bp)
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-400 mb-1">模型算法选型 (Model Architecture):</label>
              <select
                value={modelType}
                onChange={(e) => setModelType(e.target.value)}
                className="w-full bg-[#152136] border border-[#273a5a] rounded p-2 text-slate-100 text-xs focus:outline-none focus:border-blue-500"
              >
                <option value="PIECEWISE_HAZARD">分段连续常数违约强度 (Piecewise Constant Hazard)</option>
                <option value="CONSTANT_HAZARD">单参数恒定强度模型 (Constant Intensity)</option>
                <option value="CIR_STOCHASTIC">CIR 随机违约强度扩散模型 (Cox-Ingersoll-Ross)</option>
                <option value="MERTON_STRUCTURAL">Merton 结构化资产价值违约模型 (Merton Model)</option>
              </select>
            </div>

            <div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-slate-400">5Y 平价 CDS 利差 (Spread):</span>
                <span className="font-mono font-bold text-amber-300">{effectiveSpread} bps</span>
              </div>
              <input
                type="range"
                min={20}
                max={1200}
                step={5}
                value={effectiveSpread}
                onChange={(e) => setOverrideSpread5Y(Number(e.target.value))}
                className="w-full accent-amber-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-slate-400">清偿回收率 (Recovery Rate $R$):</span>
                <span className="font-mono font-bold text-emerald-300">{overrideRecovery}%</span>
              </div>
              <input
                type="range"
                min={10}
                max={80}
                step={5}
                value={overrideRecovery}
                onChange={(e) => setOverrideRecovery(Number(e.target.value))}
                className="w-full accent-emerald-500 cursor-pointer"
              />
            </div>

            {/* 校准结果框 */}
            <div className="bg-[#0b1322] p-3 rounded border border-[#1b2b48] space-y-1.5 font-mono text-[11px]">
              <div className="text-slate-400 font-sans font-semibold text-[10px] uppercase">
                校准输出 (Calibrated Outputs):
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">年化违约强度 ($\lambda$):</span>
                <span className="text-emerald-300 font-bold">{(calibratedHazard * 100).toFixed(4)}% / 年</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">5年累积违约概率 ($F(5)$):</span>
                <span className="text-red-400 font-bold">{((1 - Math.exp(-calibratedHazard * 5)) * 100).toFixed(3)}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">5年生存概率 ($S(5)$):</span>
                <span className="text-cyan-300 font-bold">{(Math.exp(-calibratedHazard * 5) * 100).toFixed(3)}%</span>
              </div>
            </div>
          </div>
        </div>

        {/* 右侧：生存概率曲线 S(t) 与 累积违约概率 F(t) 演化图 */}
        <div className="lg:col-span-8 bg-[#101827] p-4 rounded-lg border border-[#1e293b] space-y-3">
          <div className="flex items-center justify-between border-b border-[#1e293b] pb-2">
            <div>
              <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2">
                <Activity className="w-4 h-4 text-blue-400" />
                <span>生存概率 $S(t)$ 与累积违约概率 $F(t)$ 期限结构</span>
              </h3>
              <p className="text-[11px] text-slate-400">
                公式: $S(t) = \exp(-\int_0^t \lambda(u)du)$, $F(t) = 1 - S(t)$
              </p>
            </div>
          </div>

          {/* 曲线图表 (SVG 绘制) */}
          <div className="bg-[#0a0f18] p-3 rounded border border-[#1b263b]">
            <svg viewBox="0 0 650 200" className="w-full h-48 select-none">
              {/* 网格与坐标轴 */}
              {[0, 2, 4, 6, 8, 10].map((t) => {
                const x = 40 + (t / 10) * 580;
                return (
                  <g key={t}>
                    <line x1={x} y1={20} x2={x} y2={170} stroke="#1e293b" strokeDasharray="3,3" />
                    <text x={x - 8} y={185} fill="#64748b" fontSize="10" fontFamily="monospace">
                      {t}Y
                    </text>
                  </g>
                );
              })}

              {[0, 25, 50, 75, 100].map((pct) => {
                const y = 170 - (pct / 100) * 150;
                return (
                  <g key={pct}>
                    <line x1={40} y1={y} x2={620} y2={y} stroke="#1e293b" strokeDasharray="2,2" />
                    <text x={10} y={y + 3} fill="#64748b" fontSize="9" fontFamily="monospace">
                      {pct}%
                    </text>
                  </g>
                );
              })}

              {/* 生存概率曲线 S(t) - 蓝色 */}
              {(() => {
                let d = 'M 40 20';
                curvePoints.forEach((pt) => {
                  const tenor = pt.tenorYears || 1;
                  const surv = pt.survivalProb ?? pt.survivalProbability ?? 0.95;
                  const x = 40 + (tenor / 10) * 580;
                  const y = 170 - surv * 150;
                  d += ` L ${x.toFixed(1)} ${y.toFixed(1)}`;
                });
                return (
                  <path d={d} fill="none" stroke="#38bdf8" strokeWidth="2.5" />
                );
              })()}

              {/* 违约概率曲线 F(t) - 红色 */}
              {(() => {
                let d = 'M 40 170';
                curvePoints.forEach((pt) => {
                  const tenor = pt.tenorYears || 1;
                  const cumDef = pt.cumDefaultProb ?? pt.cumulativeDefaultProb ?? 0.05;
                  const x = 40 + (tenor / 10) * 580;
                  const y = 170 - cumDef * 150;
                  d += ` L ${x.toFixed(1)} ${y.toFixed(1)}`;
                });
                return (
                  <path d={d} fill="none" stroke="#f87171" strokeWidth="2.5" strokeDasharray="4,2" />
                );
              })()}
            </svg>

            {/* 图例 */}
            <div className="flex items-center justify-center space-x-6 text-xs font-mono mt-1">
              <div className="flex items-center space-x-1.5">
                <span className="w-3 h-1 bg-[#38bdf8] inline-block" />
                <span className="text-slate-300">生存概率 S(t) (Survival Prob)</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <span className="w-3 h-1 bg-[#f87171] inline-block" />
                <span className="text-slate-300">累积违约概率 F(t) (Cumulative Default Prob)</span>
              </div>
            </div>
          </div>

          {/* 期限节点离散数值表 */}
          <div className="overflow-x-auto border border-[#1e2d48] rounded">
            <table className="w-full text-left font-mono text-xs">
              <thead className="bg-[#15233c] text-slate-300 text-[10px]">
                <tr>
                  <th className="p-2">期限 Tenor</th>
                  <th className="p-2">边际利差 Spread</th>
                  <th className="p-2">瞬时违约强度 &lambda;(t)</th>
                  <th className="p-2">累积违约率 F(t)</th>
                  <th className="p-2">生存概率 S(t)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1c2a42] text-[11px]">
                {curvePoints.slice(0, 6).map((pt) => (
                  <tr key={pt.tenorLabel || `${pt.tenorYears}Y`} className="hover:bg-[#131e33]">
                    <td className="p-2 text-cyan-300 font-bold">{pt.tenorLabel || `${pt.tenorYears}Y`}</td>
                    <td className="p-2 text-amber-300">{pt.cdsSpreadBp} bp</td>
                    <td className="p-2 text-emerald-300">{(pt.hazardRate * 100).toFixed(3)}%</td>
                    <td className="p-2 text-red-400 font-bold">{((pt.cumDefaultProb ?? pt.cumulativeDefaultProb ?? 0) * 100).toFixed(2)}%</td>
                    <td className="p-2 text-slate-200">{((pt.survivalProb ?? pt.survivalProbability ?? 1) * 100).toFixed(2)}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
