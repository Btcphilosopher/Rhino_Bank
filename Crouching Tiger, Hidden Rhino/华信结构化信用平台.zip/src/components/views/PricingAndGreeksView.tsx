/**
 * 定价与风险 Greeks 交易台 (Pricing & Greeks Desk)
 * 平价利差、净现值 PV、CS01、DV01、相关性 Delta、回收率敏感性及 2D 敏感度表面
 */

import React, { useState } from 'react';
import { CDOTranche, SyntheticCDODeal } from '../../types';
import { 
  Calculator, 
  TrendingUp, 
  Activity, 
  Zap, 
  Sliders, 
  DollarSign,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';
import { computeTrancheGreeks, calculateTrancheLossAndSpread } from '../../math/trancheAndPricingEngine';

interface PricingAndGreeksViewProps {
  deal: SyntheticCDODeal;
  tranches: CDOTranche[];
  onRecalculate: () => void;
}

export const PricingAndGreeksView: React.FC<PricingAndGreeksViewProps> = ({
  deal,
  tranches,
  onRecalculate,
}) => {
  const [spreadShockBp, setSpreadShockBp] = useState<number>(0);
  const [corrShockPct, setCorrShockPct] = useState<number>(0);
  const [recoveryShockPct, setRecoveryShockPct] = useState<number>(0);

  // 快速扰动触发
  const applyShock = (spread: number, corr: number, rec: number) => {
    setSpreadShockBp(spread);
    setCorrShockPct(corr);
    setRecoveryShockPct(rec);
  };

  return (
    <div className="space-y-4 text-slate-200">
      {/* 顶部标题栏 */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#101827] p-3.5 rounded-lg border border-[#1e293b]">
        <div>
          <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
            <Calculator className="w-5 h-5 text-blue-400" />
            <span>定价与风险 Greeks 交易台 (Pricing & Sensitivity Desk)</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            全生命周期净现值 (PV)、平价利差 (Fair Spread)、前置费率 (Upfront) 与一阶/二阶希腊字母精确计量
          </p>
        </div>

        {/* 快速即时冲击按钮组 */}
        <div className="flex items-center space-x-2">
          <button
            onClick={() => applyShock(1, 0, 0)}
            className="px-2.5 py-1.5 bg-[#15233c] hover:bg-blue-600 text-blue-300 hover:text-white rounded border border-[#273a5a] text-xs font-mono cursor-pointer transition-colors"
          >
            +1 bp CS01 冲击
          </button>
          <button
            onClick={() => applyShock(0, 5, 0)}
            className="px-2.5 py-1.5 bg-[#15233c] hover:bg-blue-600 text-cyan-300 hover:text-white rounded border border-[#273a5a] text-xs font-mono cursor-pointer transition-colors"
          >
            +5% 相关性冲击
          </button>
          <button
            onClick={() => applyShock(0, 0, -5)}
            className="px-2.5 py-1.5 bg-[#15233c] hover:bg-blue-600 text-amber-300 hover:text-white rounded border border-[#273a5a] text-xs font-mono cursor-pointer transition-colors"
          >
            -5% 回收率冲击
          </button>
          <button
            onClick={() => applyShock(0, 0, 0)}
            className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs cursor-pointer"
          >
            重置冲击
          </button>
        </div>
      </div>

      {/* 核心定价与 Greeks 综合矩阵 */}
      <div className="bg-[#101827] p-4 rounded-lg border border-[#1e293b] space-y-3">
        <div className="flex items-center justify-between border-b border-[#1e293b] pb-2">
          <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2">
            <TrendingUp className="w-4 h-4 text-emerald-400" />
            <span>分层全量经济价值与 Greeks 敏感度矩阵 (Comprehensive Pricing & Greeks)</span>
          </h3>
          <span className="text-[11px] text-slate-400 font-mono">
            基准无风险利率: 2.50% · 季度 IMM 贴现
          </span>
        </div>

        <div className="overflow-x-auto border border-[#1e2d48] rounded">
          <table className="w-full text-left font-mono text-xs">
            <thead className="bg-[#15233c] text-slate-300 text-[11px]">
              <tr>
                <th className="p-2.5">Tranche 分层</th>
                <th className="p-2.5">厚度 (A – D)</th>
                <th className="p-2.5">名义本金</th>
                <th className="p-2.5">平价利差 (Fair)</th>
                <th className="p-2.5">前置费率 (Upfront)</th>
                <th className="p-2.5">保护端 PV</th>
                <th className="p-2.5">保费端 PV</th>
                <th className="p-2.5">净现值 (PV)</th>
                <th className="p-2.5">CS01 (1bp)</th>
                <th className="p-2.5">DV01 (1bp 利率)</th>
                <th className="p-2.5">相关性 Delta (1%)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1c2a42]">
              {tranches.map((t) => {
                const effectiveFairSpread = Math.max(5, t.fairSpreadBp + spreadShockBp * 1.2 + corrShockPct * 8 - recoveryShockPct * 4);
                const effectivePv = t.pv - (spreadShockBp * t.cs01) + (corrShockPct * t.correlationDelta);

                return (
                  <tr key={t.id} className="hover:bg-[#131e33] transition-colors">
                    <td className="p-2.5 font-sans font-bold text-slate-100">{t.name}</td>
                    <td className="p-2.5 text-cyan-300">{(t.attachmentPoint * 100).toFixed(1)}%–{(t.detachmentPoint * 100).toFixed(1)}%</td>
                    <td className="p-2.5 text-slate-200">¥{(t.notional / 1e8).toFixed(2)} 亿</td>
                    <td className="p-2.5 text-amber-300 font-bold">{effectiveFairSpread.toFixed(0)} bp</td>
                    <td className="p-2.5 text-slate-300">{t.upfrontFeePercent.toFixed(2)}%</td>
                    <td className="p-2.5 text-red-300 font-bold">¥{(t.protectionLegPv / 1e6).toFixed(2)} M</td>
                    <td className="p-2.5 text-emerald-300 font-bold">¥{(t.premiumLegPv / 1e6).toFixed(2)} M</td>
                    <td className="p-2.5 font-bold">
                      <span className={effectivePv >= 0 ? 'text-emerald-400' : 'text-red-400'}>
                        ¥{(effectivePv / 1e6).toFixed(2)} M
                      </span>
                    </td>
                    <td className="p-2.5 text-slate-300 font-bold">¥{t.cs01.toLocaleString()}</td>
                    <td className="p-2.5 text-slate-400">¥{t.dv01.toLocaleString()}</td>
                    <td className="p-2.5 text-cyan-300">¥{t.correlationDelta.toLocaleString()}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* 2D 敏感度表面表 (利差变动 vs 相关性变动对权益层与夹层的影响) */}
      <div className="bg-[#101827] p-4 rounded-lg border border-[#1e293b] space-y-3">
        <div className="flex items-center justify-between border-b border-[#1e293b] pb-2">
          <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2">
            <Activity className="w-4 h-4 text-cyan-400" />
            <span>2D 联合敏感度表面矩阵: 夹层 A (3-7%) 平价利差 (Spread $\times$ Correlation)</span>
          </h3>
          <span className="text-[11px] text-slate-400 font-mono">单位: 基点 (bps)</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-center font-mono text-xs border-collapse">
            <thead>
              <tr className="bg-[#162540] text-slate-300 text-[11px]">
                <th className="p-2.5 text-left font-sans">底层利差 \ 相关性 $\rho$</th>
                <th className="p-2.5">15%</th>
                <th className="p-2.5">25%</th>
                <th className="p-2.5 bg-blue-950/60 text-cyan-300">32.4% (当前)</th>
                <th className="p-2.5">45%</th>
                <th className="p-2.5">60%</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1c2a42]">
              {[
                { spreadDelta: '-50 bp', base: 260 },
                { spreadDelta: '-20 bp', base: 310 },
                { spreadDelta: '0 bp (基准 146bp)', base: 345 },
                { spreadDelta: '+30 bp', base: 410 },
                { spreadDelta: '+70 bp', base: 520 },
                { spreadDelta: '+120 bp', base: 680 },
              ].map((row) => (
                <tr key={row.spreadDelta} className="hover:bg-[#131e33]">
                  <td className="p-2.5 text-left font-sans font-medium text-slate-200 bg-[#121c2d]">
                    {row.spreadDelta}
                  </td>
                  <td className="p-2.5 text-slate-300">{Math.round(row.base * 0.78)} bp</td>
                  <td className="p-2.5 text-slate-300">{Math.round(row.base * 0.91)} bp</td>
                  <td className="p-2.5 text-amber-300 font-bold bg-blue-950/30">{row.base} bp</td>
                  <td className="p-2.5 text-slate-300">{Math.round(row.base * 1.15)} bp</td>
                  <td className="p-2.5 text-red-300 font-bold">{Math.round(row.base * 1.38)} bp</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
