/**
 * 相关性与 Copula 模型 (Correlation & Copula Models)
 * 单因子高斯 Copula、条件违约概率 p(M)、跨行业相关性热力图与 Base Correlation 基础相关性曲面
 */

import React, { useState } from 'react';
import { GitFork, Sliders, Grid, HelpCircle, Activity, Layers } from 'lucide-react';
import { 
  calculateConditionalPD, 
  generateSectorCorrelationMatrix, 
  getBaseCorrelation, 
  interpolateBaseCorrelation 
} from '../../math/copulaEngine';

interface CorrelationViewProps {
  systemCorrelation: number;
  onCorrelationChange: (rho: number) => void;
}

export const CorrelationView: React.FC<CorrelationViewProps> = ({
  systemCorrelation,
  onCorrelationChange,
}) => {
  const [macroFactorM, setMacroFactorM] = useState<number>(0.0); // [-3.0, +3.0]
  const [basePD, setBasePD] = useState<number>(0.1145); // 11.45% 5Y PD
  const [activeTab, setActiveTab] = useState<'ONE_FACTOR' | 'SECTOR_HEATMAP' | 'BASE_CORRELATION'>('ONE_FACTOR');

  const sectorMatrix = generateSectorCorrelationMatrix();

  // 计算当前宏观状态下的条件违约概率
  const currentCondPD = calculateConditionalPD(basePD, systemCorrelation, macroFactorM);

  // 构造 M 在 [-3, 3] 范围内的条件违约曲线
  const mGrid = [-3, -2.5, -2, -1.5, -1, -0.5, 0, 0.5, 1, 1.5, 2, 2.5, 3];
  const condPdPoints = mGrid.map((m) => ({
    m,
    condPD: calculateConditionalPD(basePD, systemCorrelation, m),
  }));

  return (
    <div className="space-y-4 text-slate-200">
      {/* 顶部标题栏 */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#101827] p-3.5 rounded-lg border border-[#1e293b]">
        <div>
          <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
            <GitFork className="w-5 h-5 text-blue-400" />
            <span>违约相关性与 Copula 联结模型 (Correlation & Copula Architecture)</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            单因子高斯 Copula、行业异构相关性矩阵与指数 Base Correlation 期限-分层插值曲面
          </p>
        </div>

        {/* 内部 Tab 切换 */}
        <div className="flex items-center space-x-1 bg-[#141d2d] p-1 rounded border border-[#23334d] text-xs">
          <button
            onClick={() => setActiveTab('ONE_FACTOR')}
            className={`px-3 py-1 rounded cursor-pointer transition-colors ${
              activeTab === 'ONE_FACTOR' ? 'bg-blue-600 text-white font-semibold' : 'text-slate-400 hover:text-white'
            }`}
          >
            单因子高斯 Copula
          </button>
          <button
            onClick={() => setActiveTab('SECTOR_HEATMAP')}
            className={`px-3 py-1 rounded cursor-pointer transition-colors ${
              activeTab === 'SECTOR_HEATMAP' ? 'bg-blue-600 text-white font-semibold' : 'text-slate-400 hover:text-white'
            }`}
          >
            行业相关性矩阵
          </button>
          <button
            onClick={() => setActiveTab('BASE_CORRELATION')}
            className={`px-3 py-1 rounded cursor-pointer transition-colors ${
              activeTab === 'BASE_CORRELATION' ? 'bg-blue-600 text-white font-semibold' : 'text-slate-400 hover:text-white'
            }`}
          >
            Base Correlation 曲面
          </button>
        </div>
      </div>

      {activeTab === 'ONE_FACTOR' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* 左侧：单因子控制台 */}
          <div className="lg:col-span-4 bg-[#101827] p-4 rounded-lg border border-[#1e293b] space-y-3">
            <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2 border-b border-[#1e293b] pb-2">
              <Sliders className="w-4 h-4 text-cyan-400" />
              <span>潜在系统因子 (Systemic Factor $M$) 模拟</span>
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <div className="flex justify-between items-center mb-1">
                  <span className="text-slate-400">系统资产相关性 ($\rho$):</span>
                  <span className="font-mono font-bold text-cyan-300">{(systemCorrelation * 100).toFixed(1)}%</span>
                </div>
                <input
                  type="range"
                  min={0.05}
                  max={0.80}
                  step={0.01}
                  value={systemCorrelation}
                  onChange={(e) => onCorrelationChange(Number(e.target.value))}
                  className="w-full accent-blue-500 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400 mt-0.5">
                  <span>5% (极度分散)</span>
                  <span>32.4% (基准)</span>
                  <span>80% (危机联动)</span>
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <span className="text-slate-400">宏观经济环境冲击 (M ~ N(0, 1)):</span>
                  <span className="font-mono font-bold text-amber-300">{macroFactorM.toFixed(2)} &sigma;</span>
                </div>
                <input
                  type="range"
                  min={-3.0}
                  max={3.0}
                  step={0.1}
                  value={macroFactorM}
                  onChange={(e) => setMacroFactorM(Number(e.target.value))}
                  className="w-full accent-amber-500 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400 mt-0.5">
                  <span className="text-emerald-400">-3.0 (经济繁荣)</span>
                  <span>0.0 (中性)</span>
                  <span className="text-red-400">+3.0 (极端海啸)</span>
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <span className="text-slate-400">无条件边际违约概率 ($PD$):</span>
                  <span className="font-mono font-bold text-slate-200">{(basePD * 100).toFixed(2)}%</span>
                </div>
                <input
                  type="range"
                  min={0.01}
                  max={0.50}
                  step={0.005}
                  value={basePD}
                  onChange={(e) => setBasePD(Number(e.target.value))}
                  className="w-full accent-emerald-500 cursor-pointer"
                />
              </div>

              {/* 实时条件违约率输出 */}
              <div className="bg-[#0b1322] p-3 rounded border border-[#1b2b48] space-y-1.5 font-mono text-[11px]">
                <div className="text-slate-400 font-sans font-semibold text-[10px] uppercase">
                  当前条件违约概率 (Conditional PD):
                </div>
                <div className="text-xl font-bold text-red-400">
                  {(currentCondPD * 100).toFixed(3)}%
                </div>
                <p className="text-[10px] text-slate-400 font-sans leading-normal">
                  数学定义: p(M) = Φ( (Φ⁻¹(PD) - √ρ·M) / √(1-ρ) )
                </p>
              </div>
            </div>
          </div>

          {/* 右侧：条件违约概率曲面图 */}
          <div className="lg:col-span-8 bg-[#101827] p-4 rounded-lg border border-[#1e293b] space-y-3">
            <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2 border-b border-[#1e293b] pb-2">
              <Activity className="w-4 h-4 text-blue-400" />
              <span>宏观状态 $M$ 对条件违约概率 $p_i(M)$ 的非线性冲击曲线</span>
            </h3>

            {/* SVG 曲线 */}
            <div className="bg-[#0a0f18] p-3 rounded border border-[#1b263b]">
              <svg viewBox="0 0 650 200" className="w-full h-48 select-none">
                {/* 坐标轴与网格 */}
                {[-3, -2, -1, 0, 1, 2, 3].map((m) => {
                  const x = 50 + ((m + 3) / 6) * 560;
                  return (
                    <g key={m}>
                      <line x1={x} y1={20} x2={x} y2={170} stroke="#1e293b" strokeDasharray="3,3" />
                      <text x={x - 8} y={185} fill="#64748b" fontSize="10" fontFamily="monospace">
                        {m > 0 ? `+${m}` : m}
                      </text>
                    </g>
                  );
                })}

                {[0, 20, 40, 60, 80, 100].map((pct) => {
                  const y = 170 - (pct / 100) * 150;
                  return (
                    <g key={pct}>
                      <line x1={50} y1={y} x2={610} y2={y} stroke="#1e293b" strokeDasharray="2,2" />
                      <text x={12} y={y + 3} fill="#64748b" fontSize="9" fontFamily="monospace">
                        {pct}%
                      </text>
                    </g>
                  );
                })}

                {/* 绘制 p(M) 曲线 */}
                {(() => {
                  let d = 'M 50 170';
                  condPdPoints.forEach((pt, idx) => {
                    const x = 50 + ((pt.m + 3) / 6) * 560;
                    const y = 170 - pt.condPD * 150;
                    d += `${idx === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
                  });
                  return (
                    <path d={d} fill="none" stroke="#f87171" strokeWidth="3" />
                  );
                })()}

                {/* 当前 M 所在标线 */}
                {(() => {
                  const x = 50 + ((macroFactorM + 3) / 6) * 560;
                  const y = 170 - currentCondPD * 150;
                  return (
                    <g>
                      <line x1={x} y1={20} x2={x} y2={170} stroke="#38bdf8" strokeWidth="2" strokeDasharray="4,2" />
                      <circle cx={x} cy={y} r={5} fill="#f59e0b" stroke="#ffffff" strokeWidth="1.5" />
                    </g>
                  );
                })()}
              </svg>

              <div className="flex justify-between items-center text-xs text-slate-400 font-mono mt-2 px-2">
                <span>← 经济繁荣 / 信用环境极好 (M &lt; 0)</span>
                <span className="text-amber-300 font-bold">中性基准 M=0</span>
                <span>极端信用危机 / 联合违约雪崩 (M &gt; 0) →</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'SECTOR_HEATMAP' && (
        <div className="bg-[#101827] p-4 rounded-lg border border-[#1e293b] space-y-3">
          <div className="flex items-center justify-between border-b border-[#1e293b] pb-2">
            <div>
              <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2">
                <Grid className="w-4 h-4 text-emerald-400" />
                <span>7大核心行业板块间资产相关性矩阵 (Sector Cross-Correlation Matrix)</span>
              </h3>
              <p className="text-[11px] text-slate-400">
                对角线为行业内相关性 (45%-55%)，非对角线为行业间宏观因子溢出相关性 (20%-35%)
              </p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-center font-mono text-xs border-collapse">
              <thead>
                <tr className="bg-[#162540] text-slate-300 text-[11px]">
                  <th className="p-2.5 text-left font-sans">行业板块</th>
                  {sectorMatrix.sectors.map((sec) => (
                    <th key={sec} className="p-2.5 font-sans whitespace-nowrap">
                      {sec.split(' ')[0]}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {sectorMatrix.sectors.map((rowSec, rIdx) => (
                  <tr key={rowSec} className="border-b border-[#1c2a42]">
                    <td className="p-2.5 text-left font-sans font-medium text-slate-200 bg-[#121c2d] whitespace-nowrap">
                      {rowSec}
                    </td>
                    {sectorMatrix.sectors.map((colSec, cIdx) => {
                      const corr = sectorMatrix.matrix[rIdx][cIdx];
                      const isDiag = rIdx === cIdx;
                      const bgOpacity = (corr * 0.7).toFixed(2);

                      return (
                        <td
                          key={colSec}
                          className="p-2.5 font-bold"
                          style={{
                            backgroundColor: isDiag
                              ? `rgba(59, 130, 246, ${bgOpacity})`
                              : `rgba(16, 185, 129, ${bgOpacity})`,
                            color: corr > 0.4 ? '#ffffff' : '#94a3b8',
                          }}
                        >
                          {(corr * 100).toFixed(0)}%
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'BASE_CORRELATION' && (
        <div className="bg-[#101827] p-4 rounded-lg border border-[#1e293b] space-y-3">
          <div className="flex items-center justify-between border-b border-[#1e293b] pb-2">
            <div>
              <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2">
                <Layers className="w-4 h-4 text-cyan-400" />
                <span>标准指数 Base Correlation 基础相关性曲面矩阵 (CDX / iTraxx)</span>
              </h3>
              <p className="text-[11px] text-slate-400">
                将分层价格映射到 [0, K] 累积损失基础相关性 &rho;<sub>base</sub>(K)，解决相关性微笑与无套利定价
              </p>
            </div>
          </div>

          <div className="overflow-x-auto border border-[#1e2d48] rounded">
            <table className="w-full text-center font-mono text-xs">
              <thead className="bg-[#15233c] text-slate-300 text-[11px]">
                <tr>
                  <th className="p-2.5 text-left">分层触发点 (Attachment K)</th>
                  <th className="p-2.5">3 年期 (3Y)</th>
                  <th className="p-2.5">5 年期 (5Y - 基准)</th>
                  <th className="p-2.5">7 年期 (7Y)</th>
                  <th className="p-2.5">10 年期 (10Y)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1c2a42]">
                {[
                  { k: 0.03, name: '0% – 3% 权益层' },
                  { k: 0.07, name: '0% – 7% 初级夹层' },
                  { k: 0.10, name: '0% – 10% 高级夹层' },
                  { k: 0.15, name: '0% – 15% 次高级层' },
                  { k: 0.30, name: '0% – 30% 超高级层' },
                ].map((row) => (
                  <tr key={row.k} className="hover:bg-[#131e33]">
                    <td className="p-2.5 text-left font-sans font-bold text-slate-200">
                      {row.name}
                    </td>
                    <td className="p-2.5 text-slate-300">
                      {(getBaseCorrelation(row.k, 3) * 100).toFixed(1)}%
                    </td>
                    <td className="p-2.5 text-amber-300 font-bold bg-blue-950/30">
                      {(getBaseCorrelation(row.k, 5) * 100).toFixed(1)}%
                    </td>
                    <td className="p-2.5 text-slate-300">
                      {(getBaseCorrelation(row.k, 7) * 100).toFixed(1)}%
                    </td>
                    <td className="p-2.5 text-slate-300">
                      {(getBaseCorrelation(row.k, 10) * 100).toFixed(1)}%
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
