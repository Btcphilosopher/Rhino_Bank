/**
 * 结构设计器 (Deal Structuring & Tranche Designer)
 * 允许量化工程师配置交易要素、设计分层结构、校验厚度并执行平价标定
 */

import React, { useState } from 'react';
import { SyntheticCDODeal, CDOTranche, SettlementType } from '../../types';
import { 
  Layers, 
  Plus, 
  Trash2, 
  CheckCircle, 
  AlertTriangle, 
  Calculator, 
  FileText,
  Sliders,
  Settings2
} from 'lucide-react';

interface StructuringViewProps {
  deal: SyntheticCDODeal;
  onUpdateDeal: (updatedDeal: SyntheticCDODeal) => void;
  onNavigateToPricing: () => void;
}

export const StructuringView: React.FC<StructuringViewProps> = ({
  deal,
  onUpdateDeal,
  onNavigateToPricing,
}) => {
  const [dealName, setDealName] = useState(deal.dealName);
  const [totalNotionalBn, setTotalNotionalBn] = useState(deal.totalNotional / 1e8);
  const [maturityYears, setMaturityYears] = useState(deal.maturityYears);
  const [counterparty, setCounterparty] = useState(deal.counterparty);
  const [settlementType, setSettlementType] = useState<SettlementType>(deal.settlementType);
  const [isPAUG, setIsPAUG] = useState(deal.isPAUG);
  const [tranches, setTranches] = useState<CDOTranche[]>(deal.tranches);

  // 校验分层厚度是否严格等于 100%
  const totalThickness = tranches.reduce(
    (acc, t) => acc + (t.detachmentPoint - t.attachmentPoint),
    0
  );
  const isThicknessValid = Math.abs(totalThickness - 1.0) < 0.001;

  // 校验是否首尾相接 (D_i = A_{i+1})
  let isContiguous = true;
  for (let i = 0; i < tranches.length - 1; i++) {
    if (Math.abs(tranches[i].detachmentPoint - tranches[i + 1].attachmentPoint) > 0.001) {
      isContiguous = false;
      break;
    }
  }

  const handleTrancheChange = (
    id: string,
    field: keyof CDOTranche,
    val: number | string
  ) => {
    const updated = tranches.map((t) => {
      if (t.id !== id) return t;
      const copy = { ...t, [field]: val };
      if (field === 'attachmentPoint' || field === 'detachmentPoint') {
        const thickness = Number(copy.detachmentPoint) - Number(copy.attachmentPoint);
        copy.notional = totalNotionalBn * 1e8 * Math.max(0, thickness);
      }
      return copy;
    });
    setTranches(updated);
  };

  const handleSaveDeal = () => {
    onUpdateDeal({
      ...deal,
      dealName,
      totalNotional: totalNotionalBn * 1e8,
      maturityYears,
      counterparty,
      settlementType,
      isPAUG,
      tranches,
    });
  };

  const handleAddTranche = () => {
    const lastTranche = tranches[tranches.length - 1];
    const newAttach = lastTranche ? lastTranche.detachmentPoint : 0;
    const newDetach = Math.min(1.0, newAttach + 0.05);
    const newTranche: CDOTranche = {
      id: `tranche-${Date.now()}`,
      name: `新增自定义分层 ${(newAttach * 100).toFixed(0)}-${(newDetach * 100).toFixed(0)}%`,
      category: 'Mezzanine',
      attachmentPoint: newAttach,
      detachmentPoint: newDetach,
      notional: totalNotionalBn * 1e8 * (newDetach - newAttach),
      contractSpreadBp: 250,
      fairSpreadBp: 245,
      upfrontFeePercent: 1.2,
      expectedLossPercent: 4.5,
      expectedLossAmount: totalNotionalBn * 1e8 * (newDetach - newAttach) * 0.045,
      protectionLegPv: 8500000,
      premiumLegPv: 8200000,
      pv: -300000,
      cs01: 42000,
      dv01: -12000,
      correlationDelta: -85000,
      targetRating: 'BBB',
    };
    setTranches([...tranches, newTranche]);
  };

  const handleRemoveTranche = (id: string) => {
    if (tranches.length <= 1) return;
    setTranches(tranches.filter((t) => t.id !== id));
  };

  return (
    <div className="space-y-4 text-slate-200">
      {/* 顶部标题栏 */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#101827] p-3.5 rounded-lg border border-[#1e293b]">
        <div>
          <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
            <Layers className="w-5 h-5 text-blue-400" />
            <span>结构设计器 (Deal Structuring & Tranche Designer)</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            配置合成 CDO 经济要素，自定义吸收区间 (Attachment / Detachment)，自动校验厚度完整性
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={handleSaveDeal}
            className="px-3.5 py-1.5 rounded bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold cursor-pointer shadow-sm transition-all"
          >
            保存结构配置
          </button>
          <button
            onClick={onNavigateToPricing}
            className="flex items-center space-x-1 px-3.5 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold cursor-pointer shadow-sm transition-all"
          >
            <Calculator className="w-3.5 h-3.5" />
            <span>执行全分层定价 →</span>
          </button>
        </div>
      </div>

      {/* 交易主参数设置 */}
      <div className="bg-[#101827] p-4 rounded-lg border border-[#1e293b] space-y-3">
        <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2 border-b border-[#1e293b] pb-2">
          <Settings2 className="w-4 h-4 text-cyan-400" />
          <span>核心交易经济条款 (General Deal Economics)</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
          <div>
            <label className="block text-slate-400 mb-1">交易名称 (Deal Name):</label>
            <input
              type="text"
              value={dealName}
              onChange={(e) => setDealName(e.target.value)}
              className="w-full bg-[#152136] border border-[#273a5a] rounded p-2 text-slate-100 font-medium focus:outline-none focus:border-blue-500"
            />
          </div>

          <div>
            <label className="block text-slate-400 mb-1">总名义本金 (Total Notional):</label>
            <div className="relative">
              <input
                type="number"
                step="0.1"
                value={totalNotionalBn}
                onChange={(e) => setTotalNotionalBn(Number(e.target.value))}
                className="w-full bg-[#152136] border border-[#273a5a] rounded p-2 text-amber-300 font-mono font-bold focus:outline-none focus:border-blue-500"
              />
              <span className="absolute right-2.5 top-2 text-slate-400 font-mono">亿元 (CNY)</span>
            </div>
          </div>

          <div>
            <label className="block text-slate-400 mb-1">基准期限 (Tenor):</label>
            <select
              value={maturityYears}
              onChange={(e) => setMaturityYears(Number(e.target.value))}
              className="w-full bg-[#152136] border border-[#273a5a] rounded p-2 text-slate-100 font-mono focus:outline-none focus:border-blue-500"
            >
              <option value={1}>1 年期 (1Y)</option>
              <option value={3}>3 年期 (3Y)</option>
              <option value={5}>5 年期 (5Y - 国际标准)</option>
              <option value={7}>7 年期 (7Y)</option>
              <option value={10}>10 年期 (10Y)</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-400 mb-1">交易对手 (Counterparty):</label>
            <input
              type="text"
              value={counterparty}
              onChange={(e) => setCounterparty(e.target.value)}
              className="w-full bg-[#152136] border border-[#273a5a] rounded p-2 text-slate-100 focus:outline-none focus:border-blue-500"
            />
          </div>

          <div>
            <label className="block text-slate-400 mb-1">结算模式 (Settlement):</label>
            <select
              value={settlementType}
              onChange={(e) => setSettlementType(e.target.value as SettlementType)}
              className="w-full bg-[#152136] border border-[#273a5a] rounded p-2 text-slate-100 focus:outline-none focus:border-blue-500"
            >
              <option value="拍卖结算 (Auction Settlement)">拍卖结算 (Auction Settlement)</option>
              <option value="现金结算 (Cash Settlement)">现金结算 (Cash Settlement)</option>
              <option value="实物结算 (Physical Settlement)">实物结算 (Physical Settlement)</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-400 mb-1">结构机制 (Structure Mechanism):</label>
            <div className="flex items-center space-x-2 mt-2">
              <input
                type="checkbox"
                id="paug-check"
                checked={isPAUG}
                onChange={(e) => setIsPAUG(e.target.checked)}
                className="w-4 h-4 accent-blue-600 rounded cursor-pointer"
              />
              <label htmlFor="paug-check" className="text-slate-200 font-medium cursor-pointer">
                启用 Pay-As-You-Go (PAUG) 分段减记机制
              </label>
            </div>
          </div>
        </div>
      </div>

      {/* 分层配置表格与厚度校验 */}
      <div className="bg-[#101827] p-4 rounded-lg border border-[#1e293b] space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#1e293b] pb-2">
          <div className="flex items-center space-x-2">
            <Sliders className="w-4 h-4 text-blue-400" />
            <h3 className="font-bold text-sm text-slate-100">分层资本结构 (Tranche Capital Structure)</h3>
          </div>

          <div className="flex items-center space-x-3 text-xs font-mono">
            <div className={`flex items-center space-x-1 px-2.5 py-1 rounded border ${
              isThicknessValid && isContiguous
                ? 'bg-emerald-950/60 text-emerald-300 border-emerald-700/50'
                : 'bg-red-950/60 text-red-300 border-red-700/50'
            }`}>
              {isThicknessValid && isContiguous ? (
                <CheckCircle className="w-3.5 h-3.5" />
              ) : (
                <AlertTriangle className="w-3.5 h-3.5" />
              )}
              <span>
                总厚度: {(totalThickness * 100).toFixed(1)}% {isThicknessValid ? '(合规)' : '(非100%)'} · {isContiguous ? '连续无缝' : '存在缝隙'}
              </span>
            </div>

            <button
              onClick={handleAddTranche}
              className="flex items-center space-x-1 px-2.5 py-1 bg-[#1a273e] hover:bg-blue-600 text-slate-200 hover:text-white rounded border border-[#2b3e5f] cursor-pointer transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>添加分层</span>
            </button>
          </div>
        </div>

        <div className="overflow-x-auto border border-[#1e2d48] rounded">
          <table className="w-full text-left font-mono text-xs">
            <thead className="bg-[#15233c] text-slate-300 text-[11px]">
              <tr>
                <th className="p-2.5">分层名称</th>
                <th className="p-2.5">分层类别</th>
                <th className="p-2.5">触发点 Attachment (A)</th>
                <th className="p-2.5">终止点 Detachment (D)</th>
                <th className="p-2.5">厚度 (D - A)</th>
                <th className="p-2.5">名义本金 (CNY)</th>
                <th className="p-2.5">合约票息 (Spread bp)</th>
                <th className="p-2.5">目标评级</th>
                <th className="p-2.5 text-right">操作</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1c2a42]">
              {tranches.map((t, idx) => {
                const thickness = Math.max(0, t.detachmentPoint - t.attachmentPoint);
                return (
                  <tr key={t.id} className="hover:bg-[#131e33] transition-colors">
                    <td className="p-2">
                      <input
                        type="text"
                        value={t.name}
                        onChange={(e) => handleTrancheChange(t.id, 'name', e.target.value)}
                        className="bg-[#0f172a] border border-[#253755] rounded px-2 py-1 text-slate-100 font-sans font-medium w-44"
                      />
                    </td>
                    <td className="p-2">
                      <select
                        value={t.category}
                        onChange={(e) => handleTrancheChange(t.id, 'category', e.target.value as any)}
                        className="bg-[#0f172a] border border-[#253755] rounded px-2 py-1 text-slate-200 font-sans text-xs"
                      >
                        <option value="Equity">权益层 (Equity)</option>
                        <option value="Mezzanine">初级夹层 (Mezzanine)</option>
                        <option value="SeniorMezz">高级夹层 (Senior Mezz)</option>
                        <option value="Senior">优先级 (Senior)</option>
                        <option value="SuperSenior">超优先级 (Super Senior)</option>
                      </select>
                    </td>
                    <td className="p-2">
                      <input
                        type="number"
                        step="0.01"
                        min="0"
                        max="1"
                        value={t.attachmentPoint}
                        onChange={(e) => handleTrancheChange(t.id, 'attachmentPoint', Number(e.target.value))}
                        className="bg-[#0f172a] border border-[#253755] rounded px-2 py-1 text-cyan-300 font-bold w-20"
                      />
                    </td>
                    <td className="p-2">
                      <input
                        type="number"
                        step="0.01"
                        min="0"
                        max="1"
                        value={t.detachmentPoint}
                        onChange={(e) => handleTrancheChange(t.id, 'detachmentPoint', Number(e.target.value))}
                        className="bg-[#0f172a] border border-[#253755] rounded px-2 py-1 text-cyan-300 font-bold w-20"
                      />
                    </td>
                    <td className="p-2 text-amber-300 font-bold">
                      {(thickness * 100).toFixed(1)}%
                    </td>
                    <td className="p-2 text-slate-200">
                      ¥{((totalNotionalBn * thickness)).toFixed(2)} 亿元
                    </td>
                    <td className="p-2">
                      <input
                        type="number"
                        step="5"
                        value={t.contractSpreadBp}
                        onChange={(e) => handleTrancheChange(t.id, 'contractSpreadBp', Number(e.target.value))}
                        className="bg-[#0f172a] border border-[#253755] rounded px-2 py-1 text-amber-300 font-bold w-24"
                      />
                    </td>
                    <td className="p-2">
                      <select
                        value={t.targetRating}
                        onChange={(e) => handleTrancheChange(t.id, 'targetRating', e.target.value as any)}
                        className="bg-[#0f172a] border border-[#253755] rounded px-2 py-1 text-emerald-300 font-bold"
                      >
                        <option value="AAA">AAA</option>
                        <option value="AA">AA</option>
                        <option value="A">A</option>
                        <option value="BBB">BBB</option>
                        <option value="BB">BB</option>
                        <option value="NR">NR (未评级)</option>
                      </select>
                    </td>
                    <td className="p-2 text-right">
                      <button
                        onClick={() => handleRemoveTranche(t.id)}
                        disabled={tranches.length <= 1}
                        className="p-1 rounded text-red-400 hover:bg-red-950/60 disabled:opacity-30 cursor-pointer transition-colors"
                        title="删除该分层"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
