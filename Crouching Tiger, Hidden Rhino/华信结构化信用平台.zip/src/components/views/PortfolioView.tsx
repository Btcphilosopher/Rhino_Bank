/**
 * 参考组合管理 (Reference Portfolio Management)
 * 100+ 参考实体全景库、行业/评级/区域筛选、单实体期限结构曲线下钻与权重调配
 */

import React, { useState } from 'react';
import { ReferenceEntity, IndustrySector, Region, CreditRating } from '../../types';
import { 
  Database, 
  Search, 
  Filter, 
  TrendingUp, 
  PieChart, 
  AlertTriangle, 
  ExternalLink,
  Sliders,
  CheckCircle2,
  X
} from 'lucide-react';

interface PortfolioViewProps {
  entities: ReferenceEntity[];
  onUpdateEntityWeight: (id: string, newWeight: number) => void;
  onOpenCreditEventModal: () => void;
}

export const PortfolioView: React.FC<PortfolioViewProps> = ({
  entities,
  onUpdateEntityWeight,
  onOpenCreditEventModal,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSector, setSelectedSector] = useState<string>('ALL');
  const [selectedRating, setSelectedRating] = useState<string>('ALL');
  const [selectedEntityForModal, setSelectedEntityForModal] = useState<ReferenceEntity | null>(null);

  // 筛选过滤
  const filteredEntities = entities.filter((e) => {
    const matchSearch =
      e.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      e.ticker.toLowerCase().includes(searchTerm.toLowerCase()) ||
      e.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchSector = selectedSector === 'ALL' || e.sector === selectedSector;
    const matchRating = selectedRating === 'ALL' || e.rating === selectedRating;
    return matchSearch && matchSector && matchRating;
  });

  // 统计指标
  const totalNotional = entities.reduce((acc, e) => acc + e.notional, 0);
  const avgCdsSpread = Math.round(
    entities.reduce((acc, e) => acc + e.cdsSpread5Y * e.weight, 0)
  );
  const avgRecovery = (
    entities.reduce((acc, e) => acc + e.recoveryRate * e.weight, 0) * 100
  ).toFixed(1);
  const avg5YPd = (
    entities.reduce((acc, e) => acc + e.defaultProb5Y * e.weight, 0) * 100
  ).toFixed(2);

  return (
    <div className="space-y-4 text-slate-200">
      {/* 顶部标题栏 */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#101827] p-3.5 rounded-lg border border-[#1e293b]">
        <div>
          <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
            <Database className="w-5 h-5 text-blue-400" />
            <span>参考资产池与单一实体管理 (Reference Portfolio & Single Entities)</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            涵盖 100+ 全球与国内核心主权、金融、高新科技、能源化工及工业制造主体，附带多期限 CDS 利差与违约强度
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <span className="text-xs bg-amber-950/80 text-amber-300 border border-amber-800/50 px-2.5 py-1 rounded font-mono">
            标示: 演示市场参考数据 (已校准)
          </span>
          <button
            onClick={onOpenCreditEventModal}
            className="px-3 py-1.5 rounded bg-red-900/80 hover:bg-red-800 text-red-200 border border-red-700 text-xs font-semibold cursor-pointer"
          >
            违约模拟 →
          </button>
        </div>
      </div>

      {/* 组合基本面快照 */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="bg-[#121b2b] p-3 rounded-lg border border-[#1e2d45]">
          <div className="text-[11px] text-slate-400">活跃资产池实体数</div>
          <div className="text-base font-bold font-mono text-cyan-300 mt-1">
            {entities.length} 家
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">均匀加权权重: 1.00%</div>
        </div>

        <div className="bg-[#121b2b] p-3 rounded-lg border border-[#1e2d45]">
          <div className="text-[11px] text-slate-400">加权平均 5Y CDS 利差</div>
          <div className="text-base font-bold font-mono text-blue-300 mt-1">
            {avgCdsSpread} bp
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Spread Duration 4.45</div>
        </div>

        <div className="bg-[#121b2b] p-3 rounded-lg border border-[#1e2d45]">
          <div className="text-[11px] text-slate-400">组合加权清偿回收率</div>
          <div className="text-base font-bold font-mono text-emerald-300 mt-1">
            {avgRecovery}%
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">ISDA Senior Unsecured</div>
        </div>

        <div className="bg-[#121b2b] p-3 rounded-lg border border-[#1e2d45]">
          <div className="text-[11px] text-slate-400">5年期加权违约概率 (PD)</div>
          <div className="text-base font-bold font-mono text-amber-300 mt-1">
            {avg5YPd}%
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">基于自举违约强度 Calibrated</div>
        </div>
      </div>

      {/* 搜索与过滤工具栏 */}
      <div className="bg-[#101827] p-3.5 rounded-lg border border-[#1e293b] flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center space-x-2 flex-1 min-w-[240px]">
          <div className="relative w-full max-w-sm">
            <Search className="w-4 h-4 text-slate-400 absolute left-2.5 top-2.5" />
            <input
              type="text"
              placeholder="搜索实体名称、股票代码 (Ticker) 或 ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-[#152136] border border-[#273a5a] rounded pl-8 pr-3 py-1.5 text-slate-100 placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
          </div>
        </div>

        <div className="flex flex-wrap items-center space-x-2">
          {/* 行业筛选 */}
          <div className="flex items-center space-x-1">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={selectedSector}
              onChange={(e) => setSelectedSector(e.target.value)}
              className="bg-[#152136] border border-[#273a5a] rounded px-2.5 py-1.5 text-slate-200 text-xs focus:outline-none"
            >
              <option value="ALL">全部行业 (All Sectors)</option>
              <option value="金融服务 (Financials)">金融服务 (Financials)</option>
              <option value="主权与公共事业 (Sovereign & Utilities)">主权与公共事业</option>
              <option value="信息科技 (Technology)">信息科技 (Technology)</option>
              <option value="能源与化工 (Energy & Chemicals)">能源与化工</option>
              <option value="工业与制造 (Industrials)">工业与制造</option>
              <option value="房地产与建筑 (Real Estate)">房地产与建筑</option>
              <option value="消费品与零售 (Consumer Goods)">消费品与零售</option>
              <option value="通信与媒体 (Telecom & Media)">通信与媒体</option>
              <option value="医疗健康 (Healthcare)">医疗健康</option>
              <option value="交通运输 (Transportation)">交通运输</option>
            </select>
          </div>

          {/* 评级筛选 */}
          <select
            value={selectedRating}
            onChange={(e) => setSelectedRating(e.target.value)}
            className="bg-[#152136] border border-[#273a5a] rounded px-2.5 py-1.5 text-slate-200 text-xs focus:outline-none font-mono"
          >
            <option value="ALL">全部评级 (All Ratings)</option>
            <option value="AAA">AAA</option>
            <option value="AA">AA</option>
            <option value="AA-">AA-</option>
            <option value="A+">A+</option>
            <option value="A">A</option>
            <option value="A-">A-</option>
            <option value="BBB+">BBB+</option>
            <option value="BBB">BBB</option>
            <option value="BBB-">BBB-</option>
            <option value="BB-">BB-</option>
            <option value="B+">B+</option>
            <option value="CCC">CCC</option>
          </select>

          <span className="text-slate-400 text-[11px] font-mono">
            显示 {filteredEntities.length} / {entities.length} 个主体
          </span>
        </div>
      </div>

      {/* 实体数据表格 */}
      <div className="bg-[#101827] p-4 rounded-lg border border-[#1e293b] space-y-2">
        <div className="overflow-x-auto border border-[#1e2d48] rounded">
          <table className="w-full text-left font-mono text-xs">
            <thead className="bg-[#15233c] text-slate-300 text-[11px]">
              <tr>
                <th className="p-2.5">编号 / 代码</th>
                <th className="p-2.5">参考实体名称</th>
                <th className="p-2.5">行业板块</th>
                <th className="p-2.5">信用评级</th>
                <th className="p-2.5">1Y CDS</th>
                <th className="p-2.5">3Y CDS</th>
                <th className="p-2.5">5Y CDS (基准)</th>
                <th className="p-2.5">10Y CDS</th>
                <th className="p-2.5">回收率</th>
                <th className="p-2.5">5Y 违约率 (PD)</th>
                <th className="p-2.5">名义本金</th>
                <th className="p-2.5 text-right">期限结构曲线</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1c2a42]">
              {filteredEntities.map((e) => (
                <tr key={e.id} className="hover:bg-[#131e33] transition-colors">
                  <td className="p-2.5 text-cyan-400 font-bold">
                    <div>{e.id}</div>
                    <div className="text-[10px] text-slate-400 font-normal">{e.ticker}</div>
                  </td>
                  <td className="p-2.5 font-sans font-medium text-slate-100 max-w-xs truncate">
                    {e.name}
                  </td>
                  <td className="p-2.5 font-sans text-slate-300 text-[11px]">
                    {e.sector.split(' ')[0]}
                  </td>
                  <td className="p-2.5">
                    <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold border ${
                      e.rating.startsWith('A')
                        ? 'bg-emerald-950/80 text-emerald-300 border-emerald-700/50'
                        : e.rating.startsWith('BBB')
                        ? 'bg-blue-950/80 text-blue-300 border-blue-700/50'
                        : 'bg-red-950/80 text-red-300 border-red-700/50'
                    }`}>
                      {e.rating}
                    </span>
                  </td>
                  <td className="p-2.5 text-slate-400">{e.cdsSpread1Y} bp</td>
                  <td className="p-2.5 text-slate-300">{e.cdsSpread3Y} bp</td>
                  <td className="p-2.5 text-amber-300 font-bold">{e.cdsSpread5Y} bp</td>
                  <td className="p-2.5 text-slate-400">{e.cdsSpread10Y} bp</td>
                  <td className="p-2.5 text-slate-300">{(e.recoveryRate * 100).toFixed(0)}%</td>
                  <td className="p-2.5 text-red-400 font-bold">{(e.defaultProb5Y * 100).toFixed(2)}%</td>
                  <td className="p-2.5 text-slate-200">¥{(e.notional / 1e8).toFixed(2)} 亿</td>
                  <td className="p-2.5 text-right">
                    <button
                      onClick={() => setSelectedEntityForModal(e)}
                      className="px-2.5 py-1 bg-[#18263f] hover:bg-blue-600 text-blue-300 hover:text-white rounded border border-[#2b3e5f] text-[11px] cursor-pointer transition-colors"
                    >
                      下钻查看 →
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* 单一实体下钻曲线抽屉 / 模态框 */}
      {selectedEntityForModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4">
          <div className="bg-[#0f172a] border border-[#1e293b] rounded-lg shadow-2xl max-w-2xl w-full flex flex-col overflow-hidden text-slate-200">
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-[#1e293b] bg-[#111e38]">
              <div>
                <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2">
                  <span>{selectedEntityForModal.name}</span>
                  <span className="text-cyan-300 font-mono">({selectedEntityForModal.ticker})</span>
                </h3>
                <div className="text-[11px] text-slate-400">
                  {selectedEntityForModal.sector} · {selectedEntityForModal.region} · 评级 {selectedEntityForModal.rating}
                </div>
              </div>
              <button
                onClick={() => setSelectedEntityForModal(null)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs font-sans">
              {/* 期限结构柱状对比 */}
              <div className="space-y-2">
                <div className="font-bold text-cyan-300 text-xs">CDS 信用期限结构利差曲面 (Term Structure Curve)</div>
                <div className="grid grid-cols-5 gap-2 font-mono text-center">
                  <div className="bg-[#142036] p-2 rounded border border-[#203254]">
                    <div className="text-slate-400 text-[10px]">1Y</div>
                    <div className="text-slate-200 font-bold">{selectedEntityForModal.cdsSpread1Y} bp</div>
                  </div>
                  <div className="bg-[#142036] p-2 rounded border border-[#203254]">
                    <div className="text-slate-400 text-[10px]">3Y</div>
                    <div className="text-slate-200 font-bold">{selectedEntityForModal.cdsSpread3Y} bp</div>
                  </div>
                  <div className="bg-blue-950/60 p-2 rounded border border-blue-800/60">
                    <div className="text-blue-300 text-[10px] font-bold">5Y (基准)</div>
                    <div className="text-amber-300 font-bold">{selectedEntityForModal.cdsSpread5Y} bp</div>
                  </div>
                  <div className="bg-[#142036] p-2 rounded border border-[#203254]">
                    <div className="text-slate-400 text-[10px]">7Y</div>
                    <div className="text-slate-200 font-bold">{selectedEntityForModal.cdsSpread7Y} bp</div>
                  </div>
                  <div className="bg-[#142036] p-2 rounded border border-[#203254]">
                    <div className="text-slate-400 text-[10px]">10Y</div>
                    <div className="text-slate-200 font-bold">{selectedEntityForModal.cdsSpread10Y} bp</div>
                  </div>
                </div>
              </div>

              {/* 标定参数 */}
              <div className="bg-[#0b1322] p-3 rounded border border-[#1b2b48] grid grid-cols-2 gap-3 font-mono text-[11px]">
                <div>
                  <span className="text-slate-400">校准违约强度 ($\lambda$):</span>
                  <div className="text-emerald-300 font-bold">{selectedEntityForModal.hazardRate} / year</div>
                </div>
                <div>
                  <span className="text-slate-400">5Y 累积违约率 ($F(5)$):</span>
                  <div className="text-red-400 font-bold">{(selectedEntityForModal.defaultProb5Y * 100).toFixed(2)}%</div>
                </div>
                <div>
                  <span className="text-slate-400">违约损失率 (LGD):</span>
                  <div className="text-slate-200 font-bold">{((1 - selectedEntityForModal.recoveryRate) * 100).toFixed(0)}%</div>
                </div>
                <div>
                  <span className="text-slate-400">数据源更新时间:</span>
                  <div className="text-slate-400">{selectedEntityForModal.lastUpdated}</div>
                </div>
              </div>
            </div>

            <div className="px-5 py-3 border-t border-[#1e293b] bg-[#0c1424] flex items-center justify-end">
              <button
                onClick={() => setSelectedEntityForModal(null)}
                className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded font-medium text-xs cursor-pointer"
              >
                关闭
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
