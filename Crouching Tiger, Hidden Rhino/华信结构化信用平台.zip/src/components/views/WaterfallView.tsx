/**
 * 分层瀑布与现金流引擎 (Waterfall & Cashflow Engine)
 * 组合损失穿透吸收动画、ISDA 标准 PAUG 季度现金流排期与本金减记模拟
 */

import React, { useState } from 'react';
import { CDOTranche, SyntheticCDODeal, CashflowPeriod } from '../../types';
import { Workflow, Sliders, Calendar, ArrowDown, DollarSign, ShieldAlert } from 'lucide-react';
import { calculateTrancheLossWaterfall, generateStandardCashflows } from '../../math/waterfallAndPaugEngine';

interface WaterfallViewProps {
  deal: SyntheticCDODeal;
  tranches: CDOTranche[];
}

export const WaterfallView: React.FC<WaterfallViewProps> = ({ deal, tranches }) => {
  const [portfolioLossPct, setPortfolioLossPct] = useState<number>(4.2); // 4.2% 组合损失
  const [selectedTrancheId, setSelectedTrancheId] = useState<string>(tranches[0]?.id || '');

  const totalNotional = deal.totalNotional;
  const portfolioLossAmount = (portfolioLossPct / 100.0) * totalNotional;

  // 计算当前损失穿透情况
  const waterfallSteps = calculateTrancheLossWaterfall(totalNotional, portfolioLossPct / 100.0, tranches);

  // 生成选定 Tranche 的 20 季度现金流排期
  const selectedTranche = tranches.find((t) => t.id === selectedTrancheId) || tranches[0];
  const cashflows: CashflowPeriod[] = generateStandardCashflows(
    selectedTranche,
    deal.maturityYears,
    0.025, // 2.5% 无风险折现率
    0.005  // 每季平均边际减记
  );

  return (
    <div className="space-y-4 text-slate-200">
      {/* 顶部标题栏 */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#101827] p-3.5 rounded-lg border border-[#1e293b]">
        <div>
          <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
            <Workflow className="w-5 h-5 text-blue-400" />
            <span>损失瀑布穿透与 PAUG 现金流引擎 (Tranche Waterfall & PAUG Cashflows)</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            从权益层到超高级层的逐级损失吸收机制 · 20 季度现金流排期与本金动态减记
          </p>
        </div>

        {/* 组合累计损失滑块 */}
        <div className="flex items-center space-x-3 bg-[#152136] px-3.5 py-1.5 rounded border border-[#233554] text-xs font-mono">
          <span className="text-slate-400">设定底层资产池累计违约损失率:</span>
          <input
            type="range"
            min={0}
            max={35}
            step={0.1}
            value={portfolioLossPct}
            onChange={(e) => setPortfolioLossPct(Number(e.target.value))}
            className="w-36 accent-red-500 cursor-pointer"
          />
          <span className="font-bold text-red-400 min-w-[50px] text-sm">
            {portfolioLossPct.toFixed(1)}%
          </span>
          <span className="text-slate-400">
            (¥{(portfolioLossAmount / 1e8).toFixed(2)} 亿元)
          </span>
        </div>
      </div>

      {/* 视觉化损失瀑布穿透条 */}
      <div className="bg-[#101827] p-4 rounded-lg border border-[#1e293b] space-y-3">
        <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2 border-b border-[#1e293b] pb-2">
          <span>损失穿透吸收阶梯 (Loss Absorption Waterfall)</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
          {waterfallSteps.map((step) => {
            const isFullLoss = step.lossRate >= 0.999;
            const isPartialLoss = step.lossRate > 0 && step.lossRate < 0.999;
            const isSafe = step.lossRate === 0;

            return (
              <div
                key={step.trancheId}
                className={`p-3 rounded-lg border transition-all ${
                  isFullLoss
                    ? 'bg-red-950/40 border-red-700/60'
                    : isPartialLoss
                    ? 'bg-amber-950/40 border-amber-700/60'
                    : 'bg-[#131d2e] border-[#1e2f4a]'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-bold text-xs text-slate-100">{step.trancheName}</span>
                  <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded border ${
                    isFullLoss
                      ? 'bg-red-900 text-red-200 border-red-700'
                      : isPartialLoss
                      ? 'bg-amber-900 text-amber-200 border-amber-700'
                      : 'bg-emerald-950 text-emerald-300 border-emerald-700'
                  }`}>
                    {isFullLoss ? '全部击穿' : isPartialLoss ? '部分受损' : '本金安全'}
                  </span>
                </div>

                <div className="text-[11px] font-mono text-slate-400 space-y-1 mt-2">
                  <div>吸收区间: <span className="text-cyan-300">{(step.attachment * 100).toFixed(1)}%–{(step.detachment * 100).toFixed(1)}%</span></div>
                  <div>初始本金: <span className="text-slate-200">¥{(step.initialNotional / 1e8).toFixed(2)} 亿</span></div>
                  <div>已吸收损失: <span className="text-red-400 font-bold">¥{(step.absorbedLoss / 1e8).toFixed(2)} 亿</span></div>
                  <div>剩余有效本金: <span className="text-emerald-400 font-bold">¥{(step.remainingPrincipal / 1e8).toFixed(2)} 亿</span></div>
                </div>

                {/* 进度条 */}
                <div className="w-full bg-[#0a0f18] h-2 rounded-full mt-3 overflow-hidden border border-slate-700/40">
                  <div
                    className={`h-full ${isFullLoss ? 'bg-red-500' : isPartialLoss ? 'bg-amber-500' : 'bg-emerald-500'}`}
                    style={{ width: `${(step.lossRate * 100).toFixed(1)}%` }}
                  />
                </div>
                <div className="text-right text-[10px] font-mono text-slate-400 mt-1">
                  损失率: {(step.lossRate * 100).toFixed(1)}%
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 20 季度 ISDA PAUG 现金流日程表 */}
      <div className="bg-[#101827] p-4 rounded-lg border border-[#1e293b] space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#1e293b] pb-2">
          <div className="flex items-center space-x-2">
            <Calendar className="w-4 h-4 text-cyan-400" />
            <h3 className="font-bold text-sm text-slate-100">
              ISDA 标准 20 季度现金流与本金摊销排期 (20-Quarter Cashflow Schedule)
            </h3>
          </div>

          <div className="flex items-center space-x-2 text-xs">
            <span className="text-slate-400">查看分层现金流:</span>
            <select
              value={selectedTrancheId}
              onChange={(e) => setSelectedTrancheId(e.target.value)}
              className="bg-[#152136] border border-[#273a5a] rounded px-2.5 py-1 text-slate-100 font-sans focus:outline-none"
            >
              {tranches.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name} ({(t.attachmentPoint * 100).toFixed(0)}-{(t.detachmentPoint * 100).toFixed(0)}%)
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="overflow-x-auto border border-[#1e2d48] rounded max-h-72">
          <table className="w-full text-left font-mono text-xs">
            <thead className="bg-[#15233c] text-slate-300 text-[11px] sticky top-0">
              <tr>
                <th className="p-2.5">期数 (Period)</th>
                <th className="p-2.5">支付日期 (Date)</th>
                <th className="p-2.5">期初名义本金 (CNY)</th>
                <th className="p-2.5">违约本金减记 (Write-down)</th>
                <th className="p-2.5">期末存续本金 (CNY)</th>
                <th className="p-2.5">季度票息现金流</th>
                <th className="p-2.5">折现因子 DF(t)</th>
                <th className="p-2.5 text-right">折现净现金流 (Discounted PV)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1c2a42]">
              {cashflows.map((cf) => (
                <tr key={cf.period} className="hover:bg-[#131e33] transition-colors">
                  <td className="p-2 text-cyan-300 font-bold">第 {cf.period} 季 (Q{cf.period})</td>
                  <td className="p-2 text-slate-300">{cf.paymentDate}</td>
                  <td className="p-2 text-slate-200">¥{(cf.beginningNotional / 1e6).toFixed(2)} M</td>
                  <td className="p-2 text-red-400 font-bold">¥{(cf.principalWritedown / 1e6).toFixed(2)} M</td>
                  <td className="p-2 text-emerald-300">¥{(cf.endingNotional / 1e6).toFixed(2)} M</td>
                  <td className="p-2 text-amber-300 font-bold">¥{(cf.couponPayment / 1e6).toFixed(2)} M</td>
                  <td className="p-2 text-slate-400">{cf.discountFactor.toFixed(4)}</td>
                  <td className="p-2 text-right text-emerald-400 font-bold">¥{(cf.discountedNetCashflow / 1e6).toFixed(2)} M</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
