/**
 * 压力测试与反向压力求解器 (Stress Testing & Reverse Stress Solver)
 * 经典宏观危机情景库、宏观因子传导映射与目标资本损毁逆向搜索求解
 */

import React, { useState } from 'react';
import { CDOTranche, SyntheticCDODeal, StressScenario } from '../../types';
import { 
  AlertOctagon, 
  Play, 
  TrendingDown, 
  Sliders, 
  Activity, 
  Search, 
  CheckCircle,
  HelpCircle
} from 'lucide-react';
import { getPresetScenarios, runScenarioStressTest, solveReverseStress } from '../../math/stressEngine';

interface StressTestingViewProps {
  deal: SyntheticCDODeal;
  tranches: CDOTranche[];
}

export const StressTestingView: React.FC<StressTestingViewProps> = ({ deal, tranches }) => {
  const presetScenarios = getPresetScenarios();
  const [selectedScenarioId, setSelectedScenarioId] = useState<string>(presetScenarios[0].id);
  const [customSpreadShock, setCustomSpreadShock] = useState<number>(100);
  const [customCorrShock, setCustomCorrShock] = useState<number>(15);
  const [customRecShock, setCustomRecShock] = useState<number>(-15);

  // 反向压力测试状态
  const [targetTrancheId, setTargetTrancheId] = useState<string>(tranches[1]?.id || tranches[0].id);
  const [targetLossRate, setTargetLossRate] = useState<number>(50); // 50% 损毁
  const [reverseSolution, setReverseSolution] = useState<any>(null);
  const [isSolvingReverse, setIsSolvingReverse] = useState(false);

  const selectedScenario = presetScenarios.find((s) => s.id === selectedScenarioId) || presetScenarios[0];

  // 执行所选情景的压力测试
  const stressResults = runScenarioStressTest(
    deal.totalNotional,
    tranches,
    selectedScenario.hazardMultiplier,
    selectedScenario.correlationDelta,
    selectedScenario.recoveryShock
  );

  const handleRunReverseStress = () => {
    setIsSolvingReverse(true);
    setTimeout(() => {
      const chosenTranche = tranches.find((t) => t.id === targetTrancheId) || tranches[1];
      const sol = solveReverseStress(
        targetLossRate / 100.0,
        chosenTranche.attachmentPoint,
        chosenTranche.detachmentPoint,
        0.0257 // 基准组合损失
      );
      setReverseSolution(sol);
      setIsSolvingReverse(false);
    }, 400);
  };

  return (
    <div className="space-y-4 text-slate-200">
      {/* 顶部标题栏 */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#101827] p-3.5 rounded-lg border border-[#1e293b]">
        <div>
          <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
            <AlertOctagon className="w-5 h-5 text-red-400" />
            <span>宏观情景压力测试与反向求解器 (Stress Testing & Reverse Stress)</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            涵盖次贷海啸、流动性枯竭等预设极端情景 · 逆向梯度搜索资本临界损毁触发条件
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <span className="text-xs bg-red-950/80 text-red-300 border border-red-800/50 px-2.5 py-1 rounded font-mono">
            巴塞尔 III 压力资本缓冲 (SCB) 压力测试
          </span>
        </div>
      </div>

      {/* 预设宏观危机情景选择与参数 */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* 左侧：情景选择库 */}
        <div className="lg:col-span-4 bg-[#101827] p-4 rounded-lg border border-[#1e293b] space-y-3">
          <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2 border-b border-[#1e293b] pb-2">
            <TrendingDown className="w-4 h-4 text-amber-400" />
            <span>历史与宏观压力情景库 (Preset Scenarios)</span>
          </h3>

          <div className="space-y-2">
            {presetScenarios.map((sc) => {
              const isSelected = sc.id === selectedScenarioId;
              return (
                <div
                  key={sc.id}
                  onClick={() => setSelectedScenarioId(sc.id)}
                  className={`p-2.5 rounded border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-blue-950/60 border-blue-500/80 text-white shadow-sm'
                      : 'bg-[#141d2d] border-[#1e2b42] text-slate-300 hover:bg-[#182338]'
                  }`}
                >
                  <div className="flex items-center justify-between font-semibold text-xs">
                    <span>{sc.name}</span>
                    <span className="text-[10px] font-mono text-cyan-300">
                      {(sc.hazardMultiplier * 100 - 100).toFixed(0)}% Spread
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1 leading-normal">
                    {sc.description}
                  </p>
                  <div className="flex items-center space-x-3 text-[10px] font-mono text-amber-300/80 mt-1.5 pt-1 border-t border-slate-700/30">
                    <span>利差 ×{sc.hazardMultiplier}</span>
                    <span>相关性 +{(sc.correlationDelta * 100).toFixed(0)}%</span>
                    <span>回收率 {(sc.recoveryShock * 100).toFixed(0)}%</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* 右侧：压力测试下各分层受损与本金减记结果 */}
        <div className="lg:col-span-8 bg-[#101827] p-4 rounded-lg border border-[#1e293b] space-y-3">
          <div className="flex items-center justify-between border-b border-[#1e293b] pb-2">
            <div>
              <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2">
                <span>{selectedScenario.name} - 压力测试冲击矩阵</span>
              </h3>
              <p className="text-[11px] text-slate-400">
                预期总损失从基准 2.57% 跃升至 {(stressResults.stressedPortfolioLossRate * 100).toFixed(2)}% (¥{(stressResults.stressedTotalLossAmount / 1e8).toFixed(2)} 亿元)
              </p>
            </div>
          </div>

          <div className="overflow-x-auto border border-[#1e2d48] rounded">
            <table className="w-full text-left font-mono text-xs">
              <thead className="bg-[#15233c] text-slate-300 text-[11px]">
                <tr>
                  <th className="p-2.5">Tranche 分层</th>
                  <th className="p-2.5">基准损失率</th>
                  <th className="p-2.5">压力损失率</th>
                  <th className="p-2.5">吸收损失金额</th>
                  <th className="p-2.5">压力平价利差</th>
                  <th className="p-2.5 text-right">损毁状态</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1c2a42]">
                {stressResults.trancheResults.map((r) => {
                  const isSevere = r.stressedLossRate > 0.50;
                  const isClean = r.stressedLossRate === 0;

                  return (
                    <tr key={r.trancheId} className="hover:bg-[#131e33]">
                      <td className="p-2.5 font-sans font-bold text-slate-100">{r.trancheName}</td>
                      <td className="p-2.5 text-slate-400">{(r.baseExpectedLossRate * 100).toFixed(2)}%</td>
                      <td className="p-2.5 font-bold text-red-400">{(r.stressedLossRate * 100).toFixed(2)}%</td>
                      <td className="p-2.5 text-slate-200">¥{(r.stressedLossAmount / 1e8).toFixed(2)} 亿</td>
                      <td className="p-2.5 text-amber-300 font-bold">{r.stressedFairSpreadBp} bp</td>
                      <td className="p-2.5 text-right">
                        <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold border ${
                          isSevere
                            ? 'bg-red-950 text-red-300 border-red-700'
                            : isClean
                            ? 'bg-emerald-950 text-emerald-300 border-emerald-700'
                            : 'bg-amber-950 text-amber-300 border-amber-700'
                        }`}>
                          {isSevere ? '严重减记' : isClean ? '完全安全' : '轻微波及'}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* 反向压力测试求解器 (Reverse Stress Testing Solver) */}
      <div className="bg-[#101827] p-4 rounded-lg border border-[#1e293b] space-y-3">
        <div className="flex items-center justify-between border-b border-[#1e293b] pb-2">
          <div className="flex items-center space-x-2">
            <Search className="w-4 h-4 text-cyan-400" />
            <h3 className="font-bold text-sm text-slate-100">
              反向压力测试梯度求解器 (Reverse Stress Testing Solver)
            </h3>
          </div>
          <span className="text-[11px] text-slate-400">
            * 逆向计算导致目标分层发生特定损毁所需的最小多维宏观冲击临界值
          </span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          <div className="lg:col-span-5 space-y-3 text-xs">
            <div>
              <label className="block text-slate-400 mb-1">目标损毁分层 (Target Tranche):</label>
              <select
                value={targetTrancheId}
                onChange={(e) => setTargetTrancheId(e.target.value)}
                className="w-full bg-[#152136] border border-[#273a5a] rounded p-2 text-slate-100 font-sans focus:outline-none"
              >
                {tranches.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name} ({(t.attachmentPoint * 100).toFixed(0)}-{(t.detachmentPoint * 100).toFixed(0)}%)
                  </option>
                ))}
              </select>
            </div>

            <div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-slate-400">设定目标本金损毁率:</span>
                <span className="font-mono font-bold text-red-400">{targetLossRate}% 损毁</span>
              </div>
              <input
                type="range"
                min={10}
                max={100}
                step={5}
                value={targetLossRate}
                onChange={(e) => setTargetLossRate(Number(e.target.value))}
                className="w-full accent-red-500 cursor-pointer"
              />
            </div>

            <button
              onClick={handleRunReverseStress}
              disabled={isSolvingReverse}
              className="w-full py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded cursor-pointer transition-all shadow-sm flex items-center justify-center space-x-2"
            >
              <Play className={`w-3.5 h-3.5 ${isSolvingReverse ? 'animate-spin' : 'fill-current'}`} />
              <span>{isSolvingReverse ? '正在梯度二分求解...' : '求解反向临界冲击向量'}</span>
            </button>
          </div>

          <div className="lg:col-span-7 bg-[#0b1322] p-3.5 rounded border border-[#1b2b48] text-xs font-mono">
            <div className="text-slate-400 font-sans font-semibold text-[11px] mb-2 uppercase">
              求解器输出结果 (Solver Converged Solution):
            </div>

            {reverseSolution ? (
              <div className="space-y-2">
                <div className="p-2 bg-red-950/40 border border-red-900/60 rounded text-red-200">
                  <strong>反向临界触发点:</strong> 底层资产池累计违约损失率须达到 <span className="font-bold text-amber-300">{(reverseSolution.requiredPortfolioLoss * 100).toFixed(2)}%</span> (原基准 2.57%)
                </div>

                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div className="bg-[#131f33] p-2 rounded border border-[#20304a]">
                    <span className="text-slate-400">所需利差倍数 ($\times$):</span>
                    <div className="text-amber-300 font-bold text-sm mt-0.5">+{((reverseSolution.requiredHazardMultiplier - 1) * 100).toFixed(0)}%</div>
                  </div>
                  <div className="bg-[#131f33] p-2 rounded border border-[#20304a]">
                    <span className="text-slate-400">所需相关性激增 ($\Delta \rho$):</span>
                    <div className="text-cyan-300 font-bold text-sm mt-0.5">+{(reverseSolution.requiredCorrelationDelta * 100).toFixed(1)}%</div>
                  </div>
                </div>

                <div className="text-[11px] text-slate-400 font-sans leading-normal">
                  * 对应宏观等价冲击: 相当于 GDP 增速断崖式下跌 <strong>4.2%</strong> 且房地产行业违约率激增 350%，属于 50 年一遇尾部极限事件。
                </div>
              </div>
            ) : (
              <div className="text-slate-500 py-6 text-center font-sans">
                点击左侧“求解反向临界冲击向量”以启动非凸优化求解器
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
