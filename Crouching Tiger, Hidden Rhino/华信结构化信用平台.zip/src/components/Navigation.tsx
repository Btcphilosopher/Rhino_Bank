/**
 * 主导航栏 (10个专业金融工程与风险模块)
 */

import React from 'react';
import { 
  LayoutDashboard, 
  Layers, 
  Database, 
  TrendingUp, 
  GitFork, 
  Cpu, 
  Workflow, 
  Calculator, 
  AlertOctagon, 
  GitMerge, 
  ShieldAlert
} from 'lucide-react';

export type NavTabKey = 
  | 'dashboard'
  | 'structuring'
  | 'portfolio'
  | 'curves'
  | 'correlation'
  | 'simulation'
  | 'waterfall'
  | 'pricing'
  | 'stress'
  | 'cdo2_xva'
  | 'governance';

interface NavigationProps {
  activeTab: NavTabKey;
  onTabChange: (tab: NavTabKey) => void;
}

export const Navigation: React.FC<NavigationProps> = ({ activeTab, onTabChange }) => {
  const tabs: { key: NavTabKey; label: string; icon: React.ReactNode; group: string }[] = [
    { key: 'dashboard', label: '首页概览', icon: <LayoutDashboard className="w-4 h-4" />, group: '核心' },
    { key: 'structuring', label: '结构设计器', icon: <Layers className="w-4 h-4" />, group: '组合' },
    { key: 'portfolio', label: '参考组合管理', icon: <Database className="w-4 h-4" />, group: '组合' },
    { key: 'curves', label: '信用曲线与违约', icon: <TrendingUp className="w-4 h-4" />, group: '模型' },
    { key: 'correlation', label: '相关性与 Copula', icon: <GitFork className="w-4 h-4" />, group: '模型' },
    { key: 'simulation', label: '蒙特卡洛与损失分布', icon: <Cpu className="w-4 h-4" />, group: '模拟' },
    { key: 'waterfall', label: '分层瀑布与现金流', icon: <Workflow className="w-4 h-4" />, group: '定价' },
    { key: 'pricing', label: '定价与风险 Greeks', icon: <Calculator className="w-4 h-4" />, group: '定价' },
    { key: 'stress', label: '压力测试与反向压力', icon: <AlertOctagon className="w-4 h-4" />, group: '风险' },
    { key: 'cdo2_xva', label: 'CDO² 嵌套与 XVA', icon: <GitMerge className="w-4 h-4" />, group: '高级' },
    { key: 'governance', label: '模型治理与文档', icon: <ShieldAlert className="w-4 h-4" />, group: '合规' },
  ];

  return (
    <nav className="bg-[#0b101b] border-b border-[#1b263b] px-3 py-1.5 flex items-center space-x-1 overflow-x-auto no-scrollbar select-none">
      {tabs.map((tab) => {
        const isActive = activeTab === tab.key;
        return (
          <button
            key={tab.key}
            onClick={() => onTabChange(tab.key)}
            className={`flex items-center space-x-2 px-3 py-1.5 rounded-md text-xs font-medium whitespace-nowrap transition-all cursor-pointer ${
              isActive
                ? 'bg-blue-600/90 text-white shadow-md shadow-blue-900/30 border border-blue-400/30 font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-[#152136] border border-transparent'
            }`}
          >
            <span className={isActive ? 'text-white' : 'text-slate-400'}>{tab.icon}</span>
            <span>{tab.label}</span>
          </button>
        );
      })}
    </nav>
  );
};
