/**
 * 华信结构化信用平台 - 全量量化金融工程与数据模型类型定义
 * HuaxinSyntheticCDO Type System
 */

export type CreditRating = 'AAA' | 'AA+' | 'AA' | 'AA-' | 'A+' | 'A' | 'A-' | 'BBB+' | 'BBB' | 'BBB-' | 'BB+' | 'BB' | 'BB-' | 'B+' | 'B' | 'B-' | 'CCC' | 'CC' | 'C' | 'D';

export type IndustrySector = 
  | '金融服务 (Financials)'
  | '主权与公共事业 (Sovereign & Utilities)'
  | '信息科技 (Technology)'
  | '能源与化工 (Energy & Chemicals)'
  | '工业与制造 (Industrials)'
  | '房地产与建筑 (Real Estate)'
  | '消费品与零售 (Consumer Goods)'
  | '通信与媒体 (Telecom & Media)'
  | '医疗健康 (Healthcare)'
  | '交通运输 (Transportation)';

export type Region = '亚太 (APAC/CN)' | '北美 (North America)' | '欧洲 (Europe)' | '新兴市场 (Emerging Markets)';

export type Currency = 'CNY' | 'USD' | 'EUR' | 'HKD';

export type SettlementType = '现金结算 (Cash Settlement)' | '实物结算 (Physical Settlement)' | '拍卖结算 (Auction Settlement)';

export type CreditEventType = 
  | '破产 (Bankruptcy)'
  | '未能支付 (Failure to Pay)'
  | '债务重组 (Restructuring)'
  | '债务加速到期 (Obligation Acceleration)'
  | '政府干预 (Governmental Intervention)'
  | '拒绝承认/延期偿付 (Repudiation/Moratorium)';

export type TrancheCategory = 'Equity' | 'Mezzanine' | 'SeniorMezz' | 'Senior' | 'SuperSenior';

export type ModelEnvironment = 'RESEARCH' | 'MODEL_VALIDATION' | 'SIMULATION' | 'STAGING' | 'PRODUCTION';

export type LifecycleStatus = 
  | '结构设计 (Structuring)'
  | '定量定价 (Priced)'
  | '风险审批 (Risk Approved)'
  | '交易成交 (Traded)'
  | '确认完成 (Confirmed)'
  | '存续监控 (Active Monitoring)'
  | '信用事件触发 (Credit Event)'
  | '到期清算 (Matured)';

/**
 * 单一参考实体定义
 */
export interface ReferenceEntity {
  id: string;
  name: string;
  ticker: string;
  sector: IndustrySector;
  region: Region;
  rating: CreditRating;
  cdsSpread1Y: number; // in bps
  cdsSpread3Y: number;
  cdsSpread5Y: number; // benchmark
  cdsSpread7Y: number;
  cdsSpread10Y: number;
  recoveryRate: number; // 0.0 - 1.0 (e.g. 0.40 = 40%)
  hazardRate: number; // calibrated constant lambda, e.g. 0.024
  defaultProb5Y: number; // 5-year cumulative PD
  notional: number; // e.g. 50,000,000 CNY
  weight: number; // 0.0 - 1.0
  isDemoData: boolean;
  dataSource: string;
  lastUpdated: string;
  isDefaulted?: boolean;
  defaultEvent?: {
    eventType: CreditEventType;
    eventDate: string;
    auctionRecovery: number;
    realizedLoss: number;
  };
}

/**
 * 信用期限结构与曲线
 */
export interface CreditCurvePoint {
  tenor?: string;
  tenorYears: number;
  tenorLabel: string;
  cdsSpreadBp: number;
  hazardRate: number; // lambda(t)
  survivalProb: number; // S(t)
  survivalProbability?: number;
  cumDefaultProb: number; // F(t) = 1 - S(t)
  cumulativeDefaultProb?: number;
  discountFactor: number; // P(0, t)
}

/**
 * 违约模型类型
 */
export type DefaultModelType = 'CONSTANT_HAZARD' | 'PIECEWISE_HAZARD' | 'CIR_INTENSITY' | 'MERTON_STRUCTURAL';

export interface DefaultModelConfig {
  modelType: DefaultModelType;
  modelName: string;
  version: string;
  calibrationStatus: 'CALIBRATED' | 'REQUIRES_RECAL' | 'SYNTHETIC';
  rmseBp: number;
  lastCalibratedTime: string;
  parameters: {
    meanReversion?: number;
    longTermHazard?: number;
    volOfHazard?: number;
    constantHazardRate?: number;
  };
}

/**
 * 相关性与 Copula 模型
 */
export type CopulaModelType = 'ONE_FACTOR_GAUSSIAN' | 'MULTI_FACTOR_GAUSSIAN' | 'STUDENT_T' | 'BASE_CORRELATION';

export interface CopulaConfig {
  modelType: CopulaModelType;
  systemicCorrelation: number; // rho e.g. 0.324 (32.4%)
  degreesOfFreedom?: number; // for Student-t
  factorWeights?: { factor1: number; factor2: number; factor3: number };
  baseCorrelationSurface?: BaseCorrelationPoint[];
}

export interface BaseCorrelationPoint {
  attachment: number; // e.g. 0.03 for 3%
  tenorYears: number; // e.g. 5
  baseCorrelation: number; // e.g. 0.28
}

/**
 * Tranche 分层结构
 */
export interface CDOTranche {
  id: string;
  name: string;
  category: TrancheCategory;
  attachmentPoint: number; // A (e.g. 0.00 for 0%)
  detachmentPoint: number; // D (e.g. 0.03 for 3%)
  thickness?: number; // D - A (e.g. 0.03)
  notional: number; // Total Notional * Thickness
  contractSpreadBp: number; // Target coupon e.g. 500 bps or upfront
  fairSpreadBp: number; // Calibrated fair spread from pricing engine
  upfrontFeePercent: number; // Upfront payment % if fixed coupon
  expectedLossPercent: number; // E[L_tranche] / Tranche Notional
  expectedLossAmount: number; // in currency
  cleanPrice?: number; // e.g. 98.45%
  dirtyPrice?: number;
  pv: number; // Present value in currency
  protectionLegPv: number;
  premiumLegPv: number;
  cs01: number; // Value change per +1bp CDS spread
  dv01: number; // Value change per +1bp discount rate
  correlationDelta: number; // dPV / d(rho)
  recoveryDelta?: number; // dPV / d(R)
  absorbedLoss?: number; // Current realized or simulated loss absorbed
  remainingNotional?: number;
  currentLossRate?: number;
  targetRating?: CreditRating | string;
}

/**
 * 组合损失分布与风险计量统计
 */
export interface LossDistributionPoint {
  lossPercentage: number; // e.g. 0% to 100%
  lossAmount: number; // in currency
  probabilityDensity: number;
  cumulativeProbability: number;
}

export interface PortfolioRiskMetrics {
  totalNotional: number;
  entityCount: number;
  referenceEntityCount?: number;
  activeEntitiesCount?: number;
  averageCdsSpread: number; // in bps
  averageRecoveryRate?: number;
  averageHazardRate?: number;
  weightedAverageRecovery: number; // e.g. 0.40
  weightedAveragePd: number; // 5Y PD
  averageCorrelation: number; // rho
  expectedLossAmount: number; // EL in currency
  expectedLossPercent: number; // EL%
  unexpectedLossAmount: number; // UL in currency
  var95Amount: number; // 95% VaR
  var99Amount: number; // 99% VaR
  var999Amount: number; // 99.9% VaR
  es99Amount: number; // 99% Expected Shortfall (CVaR)
  es999Amount: number; // 99.9% Expected Shortfall
  tailLossPercent: number;
  skewness: number;
  kurtosis: number;
  simulationPaths: number;
  calculationTimeMs: number;
  timestamp?: string;
  engineUsed: 'RUST_CORE_AVX2' | 'VECTORIZED_WASM' | 'ANDERSEN_RECURSIVE';
}

/**
 * 现金流日程条目 (ISDA Standard CDO Cashflow)
 */
export interface CashflowItem {
  period: number;
  date: string;
  beginningNotional: number;
  creditEventsInPeriod: number;
  trancheLossAmount: number;
  trancheRecoveryAmount: number;
  couponPayment: number;
  endingNotional: number;
  discountFactor: number;
  netCashflow: number;
  discountedCashflow: number;
  isPayAsYouGoAdjusted: boolean;
}

export interface CashflowPeriod {
  period: number;
  paymentDate: string;
  beginningNotional: number;
  principalWritedown: number;
  endingNotional: number;
  couponPayment: number;
  discountFactor: number;
  discountedNetCashflow: number;
}

/**
 * 完整 Synthetic CDO 交易结构
 */
export interface SyntheticCDODeal {
  id: string;
  tradeId: string;
  dealName: string;
  series: string;
  totalNotional: number;
  currency: Currency;
  effectiveDate: string;
  maturityYears: number;
  maturityDate: string;
  paymentFrequency: 'Quarterly' | 'Semi-Annual' | 'Annual';
  settlementType: SettlementType;
  lifecycleStatus: LifecycleStatus;
  isPAUG: boolean; // Pay-As-You-Go mechanism enabled
  referencePortfolioId: string;
  counterparty: string;
  counterpartyRating: CreditRating;
  initialMargin: number;
  variationMargin: number;
  collateralBalance: number;
  collateralHaircut: number; // e.g. 0.05 (5%)
  tranches: CDOTranche[];
  notes: string;
  createdAt: string;
  updatedAt: string;
  modelEnvironment: ModelEnvironment;
}

/**
 * 压力测试场景
 */
export interface StressScenario {
  id: string;
  name: string;
  category: 'MARKET_SHOCK' | 'MACRO_SYSTEMIC' | 'TAIL_HISTORICAL' | 'CUSTOM';
  description: string;
  spreadShockBp: number; // e.g. +50bp
  recoveryHaircutPercent: number; // e.g. -20% (relative) or -0.10 absolute
  correlationShockPercent: number; // e.g. +15%
  defaultProbMultiplier: number; // e.g. 2.0x
  hazardMultiplier?: number;
  correlationDelta?: number;
  recoveryShock?: number;
  macroVariables?: {
    gdpGrowthChange: number; // e.g. -3.5%
    unemploymentRise: number; // e.g. +2.8%
    rateShockBp: number; // e.g. +150bp
    realEstateDrop: number; // e.g. -25%
  };
  portfolioLossImpact?: number;
  var99Impact?: number;
  trancheLossImpact?: Record<string, number>;
}

/**
 * 反向压力测试结果
 */
export interface ReverseStressTestResult {
  targetTrancheId: string;
  targetTrancheName: string;
  targetLossPercent: number; // e.g. 50%
  isSolved: boolean;
  requiredPdMultiplier: number;
  requiredCorrelation: number;
  requiredRecoveryDrop: number;
  requiredSpreadShockBp: number;
  iterations: number;
  solverMethod: 'Bisection & Multi-Variate Gradient Search';
}

/**
 * 模型治理条目
 */
export interface ModelGovernanceItem {
  id: string;
  modelName: string;
  modelCode: string;
  version: string;
  author: string;
  approvalStatus: 'VERIFIED' | 'UNDER_REVIEW' | 'REJECTED';
  approvalDate: string;
  lastValidatedDate: string;
  benchmarkErrorPercent: number;
  applicableScope: string;
  knownLimitations: string;
}

/**
 * 审计日志条目 (不可篡改)
 */
export interface AuditLogItem {
  id: string;
  timestamp: string;
  user: string;
  role: string;
  action: string;
  targetEntity: string;
  targetId: string;
  parameters: string;
  hash: string;
}

/**
 * 数据血缘解析节点
 */
export interface DataLineageChain {
  metricName: string;
  calculatedValue: string;
  currencyOrUnit: string;
  calculationDate: string;
  isDemo: boolean;
  steps: {
    stepNumber: number;
    stepTitle: string;
    description: string;
    formula: string;
    inputValues: Record<string, string | number>;
    outputValue: string | number;
    dataSourceOrModel: string;
  }[];
}
