/**
 * 高精度正态分布与特殊函数量化库
 * Standard Normal Distribution, Inverse CDF (Acklam), and Bivariate Normal
 */

// 标准正态概率密度函数 PDF
export function stdNormalPdf(x: number): number {
  return Math.exp(-0.5 * x * x) / Math.sqrt(2 * Math.PI);
}

// 高精度标准正态累积分布函数 CDF (Abramowitz and Stegun 7.1.26 with precision < 1.5e-7)
export function stdNormalCdf(x: number): number {
  if (isNaN(x)) return 0;
  if (x === -Infinity) return 0;
  if (x === Infinity) return 1;

  const b1 = 0.319381530;
  const b2 = -0.356563782;
  const b3 = 1.781477937;
  const b4 = -1.821255978;
  const b5 = 1.330274429;
  const p = 0.2316419;
  const c2 = 0.3989422804014327; // 1 / sqrt(2 * PI)

  if (x >= 0.0) {
    const t = 1.0 / (1.0 + p * x);
    return 1.0 - c2 * Math.exp(-x * x / 2.0) * t * (t * (t * (t * (t * b5 + b4) + b3) + b2) + b1);
  } else {
    const t = 1.0 / (1.0 - p * x);
    return c2 * Math.exp(-x * x / 2.0) * t * (t * (t * (t * (t * b5 + b4) + b3) + b2) + b1);
  }
}

// Peter John Acklam 逆正态分布累积函数 (Inverse Normal CDF / Probit Function)
// 相对误差小于 1.15e-9
export function invNormalCdf(p: number): number {
  if (isNaN(p) || p <= 0) return -8.0;
  if (p >= 1) return 8.0;

  // Coefficients in rational approximations
  const a = [
    -3.969683028665376e+01,
     2.209460984245205e+02,
    -2.759285104469687e+02,
     1.383577518672690e+02,
    -3.066479806614716e+01,
     2.506628277459239e+00
  ];

  const b = [
    -5.447609879822406e+01,
     1.615858368580409e+02,
    -1.556989798598866e+02,
     6.680131188771972e+01,
    -1.328068155288572e+01
  ];

  const c = [
    -7.784894002430293e-03,
    -3.223964580411365e-01,
    -2.400758277161838e+00,
    -2.549732539343734e+00,
     4.374664141464968e+00,
     2.938163982698783e+00
  ];

  const d = [
     7.784695709041462e-03,
     3.224671290700398e-01,
     2.445134137142996e+00,
     3.754408661907416e+00
  ];

  const p_low = 0.02425;
  const p_high = 1 - p_low;

  let q: number, r: number;

  // Rational approximation for lower region
  if (p < p_low) {
    q = Math.sqrt(-2 * Math.log(p));
    return (((((c[0]*q+c[1])*q+c[2])*q+c[3])*q+c[4])*q+c[5]) /
           ((((d[0]*q+d[1])*q+d[2])*q+d[3])*q+1);
  }

  // Rational approximation for upper region
  if (p > p_high) {
    q = Math.sqrt(-2 * Math.log(1 - p));
    return -(((((c[0]*q+c[1])*q+c[2])*q+c[3])*q+c[4])*q+c[5]) /
            ((((d[0]*q+d[1])*q+d[2])*q+d[3])*q+1);
  }

  // Rational approximation for central region
  q = p - 0.5;
  r = q * q;
  return (((((a[0]*r+a[1])*r+a[2])*r+a[3])*r+a[4])*r+a[5])*q /
         (((((b[0]*r+b[1])*r+b[2])*r+b[3])*r+b[4])*r+1);
}

// Student-t CDF (for fat-tailed copula)
export function studentTCdf(t: number, df: number = 4): number {
  if (df <= 0) return stdNormalCdf(t);
  // Approximation for low degrees of freedom
  const x = (t + Math.sqrt(t * t + df)) / (2 * Math.sqrt(t * t + df));
  return Math.min(1.0, Math.max(0.0, x));
}
