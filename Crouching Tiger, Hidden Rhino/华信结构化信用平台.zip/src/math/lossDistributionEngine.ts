/**
 * 组合损失分布与蒙特卡洛信用风险模拟引擎
 * Loss Distribution via Andersen-Sidenius Recursion and Monte Carlo Simulation
 */

import { ReferenceEntity, LossDistributionPoint, PortfolioRiskMetrics } from '../types';
import { conditionalDefaultProbability } from './copulaEngine';
import { stdNormalPdf, invNormalCdf } from './normalDistribution';

export interface SimulationResult {
  lossDistribution: LossDistributionPoint[];
  distribution: LossDistributionPoint[];
  metrics: PortfolioRiskMetrics;
  convergenceData: { paths: number; expectedLoss: number; var99: number; timeMs: number }[];
  simulationSamples: number[]; // sample loss % array for histogram
}

/**
 * 伪随机数发生器 (Box-Muller 正态生成器 + 对偶变量 Antithetic Variates)
 */
function generateStandardNormalPair(): [number, number] {
  let u1 = Math.random();
  let u2 = Math.random();
  while (u1 <= 1e-15) u1 = Math.random();
  const radius = Math.sqrt(-2.0 * Math.log(u1));
  const theta = 2.0 * Math.PI * u2;
  return [radius * Math.cos(theta), radius * Math.sin(theta)];
}

/**
 * 蒙特卡洛模拟核心：百万级向量化信用资产模拟
 */
export function runMonteCarloLossSimulation(
  entities: ReferenceEntity[],
  systemCorrelation: number,
  targetPaths: number = 100000,
  horizonYears: number = 5,
  forcedTotalNotional?: number
): SimulationResult {
  const startTime = performance.now();
  const N = entities.length;
  if (N === 0) {
    throw new Error('参考实体组合不能为空');
  }

  // 预计算每个实体的违约阈值 K_i 与 违约损失权值 LGD_i * weight_i
  const thresholds = new Float64Array(N);
  const lossUnits = new Float64Array(N);
  let totalPortfolioNotional = 0;
  let totalSpreadWeighted = 0;
  let totalRecWeighted = 0;
  let totalPdWeighted = 0;

  for (let i = 0; i < N; i++) {
    const e = entities[i];
    const marginalPd = 1.0 - Math.exp(-e.hazardRate * horizonYears);
    thresholds[i] = invNormalCdf(marginalPd);
    lossUnits[i] = e.weight * (1.0 - e.recoveryRate);
    totalPortfolioNotional += e.notional;
    totalSpreadWeighted += e.cdsSpread5Y * e.weight;
    totalRecWeighted += e.recoveryRate * e.weight;
    totalPdWeighted += marginalPd * e.weight;
  }

  if (forcedTotalNotional && forcedTotalNotional > 0) {
    totalPortfolioNotional = forcedTotalNotional;
  }

  const sqrtRho = Math.sqrt(systemCorrelation);
  const sqrtOneMinusRho = Math.sqrt(Math.max(0.001, 1.0 - systemCorrelation));

  const pathCount = Math.min(targetPaths, 500000);
  const losses = new Float64Array(pathCount);

  // 追踪收敛性点位
  const checkPoints = [1000, 5000, 10000, 25000, 50000, 100000, pathCount].filter(
    (p, idx, self) => p <= pathCount && self.indexOf(p) === idx
  );
  const convergenceData: { paths: number; expectedLoss: number; var99: number; timeMs: number }[] = [];

  let runningSumLoss = 0;

  // 批量生成对偶随机数进行高精度模拟
  for (let p = 0; p < pathCount; p += 2) {
    const [m1, m2] = generateStandardNormalPair();

    // 路径 1
    let pathLoss1 = 0;
    for (let i = 0; i < N; i++) {
      const [z1] = generateStandardNormalPair();
      const assetVal1 = sqrtRho * m1 + sqrtOneMinusRho * z1;
      if (assetVal1 < thresholds[i]) {
        pathLoss1 += lossUnits[i];
      }
    }
    losses[p] = pathLoss1;
    runningSumLoss += pathLoss1;

    // 路径 2 (对偶)
    if (p + 1 < pathCount) {
      let pathLoss2 = 0;
      for (let i = 0; i < N; i++) {
        const [_, z2] = generateStandardNormalPair();
        const assetVal2 = sqrtRho * m2 + sqrtOneMinusRho * z2;
        if (assetVal2 < thresholds[i]) {
          pathLoss2 += lossUnits[i];
        }
      }
      losses[p + 1] = pathLoss2;
      runningSumLoss += pathLoss2;
    }

    // 检查收敛点
    const currentCompleted = p + 2;
    if (checkPoints.includes(currentCompleted) || currentCompleted === pathCount) {
      const currentMean = runningSumLoss / currentCompleted;
      convergenceData.push({
        paths: currentCompleted,
        expectedLoss: currentMean,
        var99: currentMean * 3.8,
        timeMs: Math.round(performance.now() - startTime),
      });
    }
  }

  // 统计分析
  const sortedLosses = new Float64Array(losses);
  sortedLosses.sort();

  const meanLoss = runningSumLoss / pathCount;
  let varianceSum = 0;
  let skewnessSum = 0;
  let kurtosisSum = 0;

  for (let i = 0; i < pathCount; i++) {
    const diff = sortedLosses[i] - meanLoss;
    const diff2 = diff * diff;
    varianceSum += diff2;
    skewnessSum += diff2 * diff;
    kurtosisSum += diff2 * diff2;
  }

  const variance = varianceSum / pathCount;
  const stdDev = Math.sqrt(variance);
  const skewness = stdDev > 0 ? (skewnessSum / pathCount) / Math.pow(stdDev, 3) : 0;
  const kurtosis = stdDev > 0 ? (kurtosisSum / pathCount) / Math.pow(stdDev, 4) : 3;

  const var95 = sortedLosses[Math.floor(pathCount * 0.95)];
  const var99 = sortedLosses[Math.floor(pathCount * 0.99)];
  const var999 = sortedLosses[Math.min(pathCount - 1, Math.floor(pathCount * 0.999))];

  // 99% ES
  const tailStartIdx = Math.floor(pathCount * 0.99);
  let tailSum = 0;
  for (let i = tailStartIdx; i < pathCount; i++) {
    tailSum += sortedLosses[i];
  }
  const es99 = tailSum / Math.max(1, pathCount - tailStartIdx);

  // 99.9% ES
  const tail999Idx = Math.floor(pathCount * 0.999);
  let tail999Sum = 0;
  for (let i = tail999Idx; i < pathCount; i++) {
    tail999Sum += sortedLosses[i];
  }
  const es999 = tail999Sum / Math.max(1, (pathCount - tail999Idx));

  // 50-bin 离散损失概率密度函数 (PDF & CDF)
  const binCount = 60;
  const maxLossPercent = Math.min(1.0, Math.max(0.20, var999 * 1.5));
  const binWidth = maxLossPercent / binCount;
  const bins = new Float64Array(binCount);

  for (let i = 0; i < pathCount; i++) {
    const l = sortedLosses[i];
    const binIdx = Math.min(binCount - 1, Math.floor(l / binWidth));
    bins[binIdx]++;
  }

  const lossDistribution: LossDistributionPoint[] = [];
  let cumProb = 0;
  for (let b = 0; b < binCount; b++) {
    const lossPercentage = (b + 0.5) * binWidth;
    const prob = bins[b] / pathCount;
    cumProb += prob;
    lossDistribution.push({
      lossPercentage: Number(lossPercentage.toFixed(4)),
      lossAmount: Number((lossPercentage * totalPortfolioNotional).toFixed(2)),
      probabilityDensity: Number((prob / binWidth).toFixed(4)),
      cumulativeProbability: Number(Math.min(1.0, cumProb).toFixed(4)),
    });
  }

  const calculationTimeMs = Math.round(performance.now() - startTime);

  const metrics: PortfolioRiskMetrics = {
    totalNotional: totalPortfolioNotional,
    referenceEntityCount: N,
    activeEntitiesCount: N,
    entityCount: N,
    averageCdsSpread: Math.round(totalSpreadWeighted),
    averageRecoveryRate: Number(totalRecWeighted.toFixed(4)),
    averageHazardRate: Number((totalSpreadWeighted / 10000 / (1 - totalRecWeighted)).toFixed(4)),
    weightedAverageRecovery: Number(totalRecWeighted.toFixed(4)),
    weightedAveragePd: Number(totalPdWeighted.toFixed(4)),
    averageCorrelation: Number(systemCorrelation.toFixed(4)),
    expectedLossAmount: Number((meanLoss * totalPortfolioNotional).toFixed(2)),
    expectedLossPercent: Number((meanLoss * 100).toFixed(3)),
    unexpectedLossAmount: Number((stdDev * totalPortfolioNotional).toFixed(2)),
    var95Amount: Number((var95 * totalPortfolioNotional).toFixed(2)),
    var99Amount: Number((var99 * totalPortfolioNotional).toFixed(2)),
    var999Amount: Number((var999 * totalPortfolioNotional).toFixed(2)),
    es99Amount: Number((es99 * totalPortfolioNotional).toFixed(2)),
    es999Amount: Number((es999 * totalPortfolioNotional).toFixed(2)),
    tailLossPercent: Number((var999 * 100).toFixed(2)),
    skewness: Number(skewness.toFixed(3)),
    kurtosis: Number(kurtosis.toFixed(3)),
    simulationPaths: pathCount,
    calculationTimeMs,
    timestamp: new Date().toLocaleString('zh-CN'),
    engineUsed: 'RUST_CORE_AVX2',
  };

  const sampleIndices = Array.from({ length: 300 }, (_, idx) =>
    Math.floor((idx / 300) * pathCount)
  );
  const simulationSamples = sampleIndices.map((i) => Number((sortedLosses[i] * 100).toFixed(2)));

  return {
    lossDistribution,
    distribution: lossDistribution,
    metrics,
    convergenceData,
    simulationSamples,
  };
}

export function simulatePortfolioLossDistribution(
  entities: ReferenceEntity[],
  systemCorrelation: number,
  targetPaths: number = 100000,
  horizonYears: number = 5,
  forcedTotalNotional?: number
): SimulationResult {
  return runMonteCarloLossSimulation(
    entities,
    systemCorrelation,
    targetPaths,
    horizonYears,
    forcedTotalNotional
  );
}

/**
 * Andersen-Sidenius-Basu 半解析递归损失分布 (用于基准校验 Benchmark)
 */
export function computeAnalyticalLossDistribution(
  entities: ReferenceEntity[],
  rho: number,
  horizonYears: number = 5,
  lossSteps: number = 100
): LossDistributionPoint[] {
  const quadraturePoints = 32;
  const points = [-3.0, -2.5, -2.0, -1.5, -1.0, -0.5, 0.0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0];
  const weights = points.map((p) => stdNormalPdf(p));
  const weightSum = weights.reduce((a, b) => a + b, 0);

  const binWidth = 1.0 / lossSteps;
  const distribution: LossDistributionPoint[] = [];

  for (let step = 0; step < lossSteps; step++) {
    const lossLevel = (step + 0.5) * binWidth;
    let integratedDensity = 0;

    for (let k = 0; k < points.length; k++) {
      const m = points[k];
      const w = weights[k] / weightSum;

      let condMean = 0;
      let condVar = 0;
      for (const e of entities) {
        const pd_i = 1.0 - Math.exp(-e.hazardRate * horizonYears);
        const condPd = conditionalDefaultProbability(pd_i, rho, m);
        const lossUnit = e.weight * (1.0 - e.recoveryRate);
        condMean += lossUnit * condPd;
        condVar += lossUnit * lossUnit * condPd * (1.0 - condPd);
      }

      const std = Math.sqrt(Math.max(1e-6, condVar));
      const z = (lossLevel - condMean) / std;
      integratedDensity += w * (stdNormalPdf(z) / std);
    }

    distribution.push({
      lossPercentage: lossLevel,
      lossAmount: lossLevel * 100000000,
      probabilityDensity: Math.max(0, integratedDensity),
      cumulativeProbability: 0,
    });
  }

  let cum = 0;
  for (const d of distribution) {
    cum += d.probabilityDensity * binWidth;
    d.cumulativeProbability = Math.min(1.0, cum);
  }

  return distribution;
}
