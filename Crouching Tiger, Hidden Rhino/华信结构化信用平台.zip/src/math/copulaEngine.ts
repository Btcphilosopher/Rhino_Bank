/**
 * 信用相关性与 Copula 联结函数引擎
 * One-Factor Gaussian Copula, Multi-Factor Copula, and Base Correlation Surface
 */

import { stdNormalCdf, invNormalCdf } from './normalDistribution';
import { BaseCorrelationPoint } from '../types';

/**
 * 单因子高斯 Copula 条件违约概率计算 (Li Model / Vasicek Conditional PD)
 * 资产价值方程: V_i = sqrt(rho) * M + sqrt(1 - rho) * Z_i
 * 违约条件: V_i < Phi^{-1}(PD_i)
 * 给定系统宏观因子 M 时的条件违约概率 p_i(M):
 * p_i(M) = Phi( (Phi^{-1}(PD_i) - sqrt(rho) * M) / sqrt(1 - rho) )
 */
export function conditionalDefaultProbability(
  marginalPd: number,
  rho: number,
  marketFactorM: number
): number {
  if (marginalPd <= 0) return 0;
  if (marginalPd >= 1) return 1;
  if (rho <= 0.0001) return marginalPd;
  if (rho >= 0.9999) return marketFactorM < invNormalCdf(marginalPd) ? 1 : 0;

  const thresholdK = invNormalCdf(marginalPd);
  const sqrtRho = Math.sqrt(rho);
  const sqrtOneMinusRho = Math.sqrt(1.0 - rho);

  const conditionalArg = (thresholdK - sqrtRho * marketFactorM) / sqrtOneMinusRho;
  return stdNormalCdf(conditionalArg);
}

export function calculateConditionalPD(
  marginalPd: number,
  rho: number,
  marketFactorM: number
): number {
  return conditionalDefaultProbability(marginalPd, rho, marketFactorM);
}

/**
 * 多因子高斯 Copula 条件违约概率
 * V_i = beta_m * M + beta_sec * S_sec + sqrt(1 - beta_m^2 - beta_sec^2) * Z_i
 */
export function multiFactorConditionalPd(
  marginalPd: number,
  marketBeta: number,
  sectorBeta: number,
  marketFactorM: number,
  sectorFactorS: number
): number {
  const idiosyncraticWeight = Math.sqrt(Math.max(0.01, 1.0 - marketBeta * marketBeta - sectorBeta * sectorBeta));
  const thresholdK = invNormalCdf(marginalPd);
  const arg = (thresholdK - marketBeta * marketFactorM - sectorBeta * sectorFactorS) / idiosyncraticWeight;
  return stdNormalCdf(arg);
}

/**
 * Base Correlation 曲面插值 (Bilinear / Cubic Spline over Attachment and Maturity)
 */
export function interpolateBaseCorrelation(
  attachment: number,
  maturityYears: number,
  surfaceGrid?: BaseCorrelationPoint[]
): number {
  if (!surfaceGrid || surfaceGrid.length === 0) {
    // 默认 Base Correlation 拟合函数 (典型市场结构: 权益层低相关性，高级层高相关性)
    return Math.min(0.75, Math.max(0.12, 0.18 + 0.45 * Math.sqrt(Math.min(1.0, attachment)) + 0.012 * Math.log(Math.max(1, maturityYears))));
  }

  // 寻找最近的网格点
  const matching = surfaceGrid.filter((p) => Math.abs(p.tenorYears - maturityYears) <= 1.0);
  if (matching.length === 0) {
    return 0.25 + 0.35 * Math.sqrt(attachment);
  }

  // 按 attachment 排序并线性插值
  matching.sort((a, b) => a.attachment - b.attachment);
  if (attachment <= matching[0].attachment) return matching[0].baseCorrelation;
  if (attachment >= matching[matching.length - 1].attachment) return matching[matching.length - 1].baseCorrelation;

  for (let i = 0; i < matching.length - 1; i++) {
    const p1 = matching[i];
    const p2 = matching[i + 1];
    if (attachment >= p1.attachment && attachment <= p2.attachment) {
      const alpha = (attachment - p1.attachment) / (p2.attachment - p1.attachment);
      return p1.baseCorrelation * (1 - alpha) + p2.baseCorrelation * alpha;
    }
  }

  return 0.30;
}

export function getBaseCorrelation(attachment: number, maturityYears: number = 5): number {
  return interpolateBaseCorrelation(attachment, maturityYears);
}

/**
 * 行业相关性矩阵预设 (专业信用风险矩阵 7大行业)
 */
export const STANDARD_INDUSTRY_CORRELATION_MATRIX = {
  sectors: ['金融服务 (Financials)', '房地产 (Real Estate)', '能源化工 (Energy)', '信息科技 (Technology)', '工业制造 (Industrials)', '消费零售 (Consumer)', '公用事业 (Utilities)'],
  matrix: [
    [1.00, 0.48, 0.35, 0.32, 0.42, 0.38, 0.28], // 金融服务
    [0.48, 1.00, 0.52, 0.26, 0.46, 0.41, 0.30], // 房地产
    [0.35, 0.52, 1.00, 0.36, 0.54, 0.34, 0.44], // 能源化工
    [0.32, 0.26, 0.36, 1.00, 0.40, 0.45, 0.22], // 信息科技
    [0.42, 0.46, 0.54, 0.40, 1.00, 0.49, 0.36], // 工业制造
    [0.38, 0.41, 0.34, 0.45, 0.49, 1.00, 0.31], // 消费零售
    [0.28, 0.30, 0.44, 0.22, 0.36, 0.31, 1.00], // 公用事业
  ]
};

export function generateSectorCorrelationMatrix() {
  return STANDARD_INDUSTRY_CORRELATION_MATRIX;
}
