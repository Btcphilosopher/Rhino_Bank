/**
 * CDO 分层定价、损失分解与信用风险 Greeks 计算引擎
 * Tranche Loss Function, Fair Spread Calibration, Upfront Pricing, and Greeks
 */

import { CDOTranche, LossDistributionPoint, ReferenceEntity } from '../types';

/**
 * 分层损失分段线性函数:
 * L_tranche(L) = (min(L, Detachment) - min(L, Attachment)) / (Detachment - Attachment)
 */
export function calculateTrancheLossFromPortfolioLoss(
  portfolioLoss: number, // 0.0 to 1.0 (e.g. 0.05 for 5%)
  attachment: number,    // A (e.g. 0.03 for 3%)
  detachment: number     // D (e.g. 0.07 for 7%)
): number {
  if (detachment <= attachment) return 0;
  const clampedMin = Math.min(portfolioLoss, detachment);
  const clampedMax = Math.min(portfolioLoss, attachment);
  const lossInTranche = clampedMin - clampedMax;
  return Math.max(0.0, Math.min(1.0, lossInTranche / (detachment - attachment)));
}

/**
 * 计算 Tranche 期望损失率 E[L_tranche]:
 * E[L_tranche] = Integral_0^1 L_tranche(l) * f(l) dl
 */
export function computeExpectedTrancheLoss(
  distribution: LossDistributionPoint[],
  attachment: number,
  detachment: number
): number {
  if (detachment <= attachment || distribution.length === 0) return 0;

  let expectedLossRate = 0;
  let totalProbWeight = 0;

  for (let i = 0; i < distribution.length; i++) {
    const pt = distribution[i];
    const prevProb = i === 0 ? 0 : distribution[i - 1].cumulativeProbability;
    const intervalProb = Math.max(0, pt.cumulativeProbability - prevProb);

    const trancheLossAtPoint = calculateTrancheLossFromPortfolioLoss(
      pt.lossPercentage,
      attachment,
      detachment
    );

    expectedLossRate += trancheLossAtPoint * intervalProb;
    totalProbWeight += intervalProb;
  }

  return totalProbWeight > 0 ? expectedLossRate / totalProbWeight : expectedLossRate;
}

/**
 * 定价单个 Tranche:
 * Protection Leg PV = Notional * Sum_k P(0, tk) * (E[L_tranche(tk)] - E[L_tranche(t_{k-1})])
 * Premium Leg PV (for 1 bp) = Notional * 0.0001 * Sum_k dt * P(0, tk) * (1 - E[L_tranche(tk)])
 * Fair Spread = Protection Leg PV / Premium Leg PV (for 1 bp)
 */
export function priceCDOTranche(
  tranche: CDOTranche,
  totalDealNotional: number,
  distribution: LossDistributionPoint[],
  maturityYears: number = 5,
  riskFreeRate: number = 0.025,
  referenceSpreadAvgBp: number = 146
): CDOTranche {
  const thickness = tranche.detachmentPoint - tranche.attachmentPoint;
  const trancheNotional = totalDealNotional * thickness;

  const expectedLossRate = computeExpectedTrancheLoss(
    distribution,
    tranche.attachmentPoint,
    tranche.detachmentPoint
  );

  const expectedLossAmount = trancheNotional * expectedLossRate;

  // 季度贴现日程
  const quarterlyPeriods = maturityYears * 4;
  const dt = 0.25;

  let pvProtectionLeg = 0;
  let pvPremiumLegUnitBp = 0;
  let prevPeriodLoss = 0;

  for (let q = 1; q <= quarterlyPeriods; q++) {
    const t = q * dt;
    const df = Math.exp(-riskFreeRate * t);
    
    const timeScale = Math.pow(t / maturityYears, 0.85);
    const periodExpectedLoss = expectedLossRate * timeScale;
    const marginalLossInPeriod = Math.max(0, periodExpectedLoss - prevPeriodLoss);

    // 保护端
    pvProtectionLeg += trancheNotional * marginalLossInPeriod * df;

    // 保费端
    const avgOutstandingRatio = Math.max(0.01, 1.0 - (prevPeriodLoss + periodExpectedLoss) / 2.0);
    pvPremiumLegUnitBp += trancheNotional * 0.0001 * dt * df * avgOutstandingRatio;

    prevPeriodLoss = periodExpectedLoss;
  }

  // 计算平价利差 Fair Spread (bps)
  const fairSpreadBp = pvPremiumLegUnitBp > 0 
    ? Math.round(pvProtectionLeg / pvPremiumLegUnitBp)
    : 0;

  // 实际交易中 Tranche 的 PV 计算
  const actualPremiumLegPv = tranche.contractSpreadBp * pvPremiumLegUnitBp;
  const netPv = actualPremiumLegPv - pvProtectionLeg;

  // Upfront Fee
  const upfrontFeePercent = trancheNotional > 0
    ? ((pvProtectionLeg - actualPremiumLegPv) / trancheNotional) * 100
    : 0;

  // Clean Price
  const cleanPrice = Math.max(0, Math.min(100, 100.0 - (expectedLossRate * 100 * 0.82)));
  const dirtyPrice = cleanPrice + (tranche.contractSpreadBp / 10000) * (dt * 0.5) * 100;

  // 计算 Greeks
  const cs01 = Number((-pvProtectionLeg * 0.0068).toFixed(2));
  const dv01 = Number((-trancheNotional * 0.0001 * maturityYears * 0.9).toFixed(2));
  
  let correlationDeltaSign = 1;
  if (tranche.category === 'Equity') correlationDeltaSign = -1;
  else if (tranche.category === 'Mezzanine') correlationDeltaSign = -0.3;
  else if (tranche.category === 'SeniorMezz') correlationDeltaSign = 0.4;
  else correlationDeltaSign = 0.9;

  const correlationDelta = Number((correlationDeltaSign * trancheNotional * 0.00025 * (1 - expectedLossRate)).toFixed(2));
  const recoveryDelta = Number((-trancheNotional * expectedLossRate * 0.15).toFixed(2));

  return {
    ...tranche,
    thickness,
    notional: trancheNotional,
    fairSpreadBp,
    upfrontFeePercent: Number(upfrontFeePercent.toFixed(2)),
    expectedLossPercent: Number((expectedLossRate * 100).toFixed(3)),
    expectedLossAmount: Math.round(expectedLossAmount),
    cleanPrice: Number(cleanPrice.toFixed(3)),
    dirtyPrice: Number(dirtyPrice.toFixed(3)),
    pv: Math.round(netPv),
    protectionLegPv: Math.round(pvProtectionLeg),
    premiumLegPv: Math.round(actualPremiumLegPv),
    cs01,
    dv01,
    correlationDelta,
    recoveryDelta,
    absorbedLoss: 0,
    remainingNotional: trancheNotional,
    currentLossRate: 0,
  };
}

export function calculateTrancheLossAndSpread(
  distribution: LossDistributionPoint[],
  attachment: number,
  detachment: number,
  trancheNotional: number,
  maturityYears: number = 5,
  riskFreeRate: number = 0.025,
  contractSpreadBp: number = 100
): {
  expectedLossRate: number;
  expectedLossAmount: number;
  fairSpreadBp: number;
  upfrontFeePercent: number;
  protectionLegPv: number;
  premiumLegPv: number;
  pv: number;
} {
  const expectedLossRate = computeExpectedTrancheLoss(distribution, attachment, detachment);
  const expectedLossAmount = trancheNotional * expectedLossRate;

  const quarterlyPeriods = maturityYears * 4;
  const dt = 0.25;

  let pvProtectionLeg = 0;
  let pvPremiumLegUnitBp = 0;
  let prevPeriodLoss = 0;

  for (let q = 1; q <= quarterlyPeriods; q++) {
    const t = q * dt;
    const df = Math.exp(-riskFreeRate * t);
    const timeScale = Math.pow(t / maturityYears, 0.85);
    const periodExpectedLoss = expectedLossRate * timeScale;
    const marginalLossInPeriod = Math.max(0, periodExpectedLoss - prevPeriodLoss);

    pvProtectionLeg += trancheNotional * marginalLossInPeriod * df;
    const avgOutstandingRatio = Math.max(0.01, 1.0 - (prevPeriodLoss + periodExpectedLoss) / 2.0);
    pvPremiumLegUnitBp += trancheNotional * 0.0001 * dt * df * avgOutstandingRatio;

    prevPeriodLoss = periodExpectedLoss;
  }

  const fairSpreadBp = pvPremiumLegUnitBp > 0 
    ? Math.round(pvProtectionLeg / pvPremiumLegUnitBp)
    : 0;

  const actualPremiumLegPv = contractSpreadBp * pvPremiumLegUnitBp;
  const netPv = actualPremiumLegPv - pvProtectionLeg;

  const upfrontFeePercent = trancheNotional > 0
    ? ((pvProtectionLeg - actualPremiumLegPv) / trancheNotional) * 100
    : 0;

  return {
    expectedLossRate,
    expectedLossAmount: Math.round(expectedLossAmount),
    fairSpreadBp,
    upfrontFeePercent: Number(upfrontFeePercent.toFixed(2)),
    protectionLegPv: Math.round(pvProtectionLeg),
    premiumLegPv: Math.round(actualPremiumLegPv),
    pv: Math.round(netPv),
  };
}

export function computeTrancheGreeks(
  trancheNotional: number,
  expectedLossRate: number,
  contractSpreadBp: number,
  fairSpreadBp: number
): {
  cs01: number;
  dv01: number;
  correlationDelta: number;
} {
  const cs01 = Math.round(-trancheNotional * 0.000085 * (1 + expectedLossRate * 3));
  const dv01 = Math.round(-trancheNotional * 0.000045 * 4.2);
  const correlationDelta = Math.round(trancheNotional * 0.00015 * (0.5 - expectedLossRate));

  return { cs01, dv01, correlationDelta };
}

/**
 * 标定标准 5-Tranche 结构
 */
export function buildStandardTranches(
  totalNotional: number,
  distribution: LossDistributionPoint[],
  avgSpreadBp: number = 146
): CDOTranche[] {
  const definitions: {
    id: string;
    name: string;
    category: CDOTranche['category'];
    A: number;
    D: number;
    contractSpreadBp: number;
  }[] = [
    { id: 'tranche-equity', name: '权益层 (Equity)', category: 'Equity', A: 0.00, D: 0.03, contractSpreadBp: 1500 },
    { id: 'tranche-mezz', name: '夹层 A (Mezzanine A)', category: 'Mezzanine', A: 0.03, D: 0.07, contractSpreadBp: 420 },
    { id: 'tranche-seniormezz', name: '夹层 B (Senior Mezz B)', category: 'SeniorMezz', A: 0.07, D: 0.10, contractSpreadBp: 180 },
    { id: 'tranche-senior', name: '高级层 (Senior)', category: 'Senior', A: 0.10, D: 0.15, contractSpreadBp: 75 },
    { id: 'tranche-supersenior', name: '超高级层 (Super Senior)', category: 'SuperSenior', A: 0.15, D: 1.00, contractSpreadBp: 28 },
  ];

  return definitions.map((def) => {
    const rawTranche: CDOTranche = {
      id: def.id,
      name: def.name,
      category: def.category,
      attachmentPoint: def.A,
      detachmentPoint: def.D,
      thickness: def.D - def.A,
      notional: totalNotional * (def.D - def.A),
      contractSpreadBp: def.contractSpreadBp,
      fairSpreadBp: 0,
      upfrontFeePercent: 0,
      expectedLossPercent: 0,
      expectedLossAmount: 0,
      cleanPrice: 100,
      dirtyPrice: 100,
      pv: 0,
      protectionLegPv: 0,
      premiumLegPv: 0,
      cs01: 0,
      dv01: 0,
      correlationDelta: 0,
      recoveryDelta: 0,
      absorbedLoss: 0,
      remainingNotional: totalNotional * (def.D - def.A),
      currentLossRate: 0,
    };

    return priceCDOTranche(rawTranche, totalNotional, distribution, 5, 0.025, avgSpreadBp);
  });
}
