/**
 * 信用曲线与违约强度 (Hazard Rate) 标定与自举 (Bootstrap) 引擎
 * ISDA Standard CDS Term Structure & Survival Curve Calibration
 */

import { CreditCurvePoint } from '../types';

/**
 * 根据 CDS Spread (bps) 和 Recovery Rate 标定恒定 Hazard Rate:
 * 简式近似: lambda = Spread / (1 - Recovery)
 * 精确贴现校准 (Quarterly payment integration):
 * Sum( P(0, ti) * S(ti) * Spread * dt ) = (1 - R) * Sum( P(0, ti) * (S(t_{i-1}) - S(ti)) )
 */
export function calibrateHazardRate(
  cdsSpreadBp: number,
  recoveryRate: number,
  riskFreeRate: number = 0.025
): number {
  const spreadDecimal = cdsSpreadBp / 10000.0;
  const lgd = Math.max(0.01, 1.0 - recoveryRate);
  
  // 简式作为初始猜测值
  let lambda = spreadDecimal / lgd;
  
  // 3-point Newton-Raphson 精确收敛
  const tenors = [0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0, 3.0, 4.0, 5.0];
  const dt = 0.25;

  for (let iter = 0; iter < 10; iter++) {
    let premiumLeg = 0;
    let protectionLeg = 0;
    let dPremiumDLambda = 0;
    let dProtectionDLambda = 0;

    let prevSurvival = 1.0;
    let prevTenor = 0.0;

    for (const t of tenors) {
      const df = Math.exp(-riskFreeRate * t);
      const survival = Math.exp(-lambda * t);
      const dSurvival = -t * survival;

      premiumLeg += df * survival * dt * spreadDecimal;
      dPremiumDLambda += df * dSurvival * dt * spreadDecimal;

      const defaultProbInPeriod = prevSurvival - survival;
      const dDefProb = -(prevTenor * prevSurvival) + (t * survival);

      protectionLeg += df * defaultProbInPeriod * lgd;
      dProtectionDLambda += df * dDefProb * lgd;

      prevSurvival = survival;
      prevTenor = t;
    }

    const f = premiumLeg - protectionLeg;
    const df_dLambda = dPremiumDLambda - dProtectionDLambda;

    if (Math.abs(df_dLambda) < 1e-12) break;
    const step = f / df_dLambda;
    lambda = Math.max(0.0001, lambda - step);

    if (Math.abs(step) < 1e-7) break;
  }

  return lambda;
}

/**
 * 根据 Hazard Rate 生成生存概率 S(t)
 */
export function survivalProbability(hazardRate: number, tenorYears: number): number {
  return Math.exp(-hazardRate * tenorYears);
}

export function calculateSurvivalProb(hazardRate: number, tenorYears: number): number {
  return Math.exp(-hazardRate * tenorYears);
}

/**
 * 根据 Hazard Rate 生成累积违约概率 F(t) = 1 - S(t)
 */
export function cumulativeDefaultProbability(hazardRate: number, tenorYears: number): number {
  return 1.0 - Math.exp(-hazardRate * tenorYears);
}

/**
 * 生成全期限信用期限结构 (1Y, 2Y, 3Y, 5Y, 7Y, 10Y)
 */
export function generateCreditCurve(
  cdsSpread5Y: number,
  recoveryRate: number,
  curveSlopeFactor: number = 0.12,
  baseRiskFreeRate: number = 0.025
): CreditCurvePoint[] {
  const tenors = [
    { label: '1Y', years: 1, mult: 0.65 },
    { label: '2Y', years: 2, mult: 0.78 },
    { label: '3Y', years: 3, mult: 0.88 },
    { label: '5Y', years: 5, mult: 1.00 },
    { label: '7Y', years: 7, mult: 1.15 },
    { label: '10Y', years: 10, mult: 1.28 },
  ] as const;

  return tenors.map((item) => {
    const spreadBp = Math.max(5, Math.round(cdsSpread5Y * (item.mult + (item.years - 5) * curveSlopeFactor * 0.03)));
    const lambda = calibrateHazardRate(spreadBp, recoveryRate, baseRiskFreeRate);
    const s_t = survivalProbability(lambda, item.years);
    const f_t = cumulativeDefaultProbability(lambda, item.years);
    const df = Math.exp(-baseRiskFreeRate * item.years);

    return {
      tenorYears: item.years,
      tenorLabel: item.label,
      cdsSpreadBp: spreadBp,
      hazardRate: lambda,
      survivalProb: s_t,
      cumDefaultProb: f_t,
      discountFactor: df,
    };
  });
}

/**
 * 生成期限结构演化曲线数组
 */
export function generateCurveEvolution(
  hazardRate: number,
  maxYears: number = 10,
  stepYears: number = 1.0
): CreditCurvePoint[] {
  const points: CreditCurvePoint[] = [];
  const baseRiskFreeRate = 0.025;

  for (let y = stepYears; y <= maxYears; y += stepYears) {
    const s_t = survivalProbability(hazardRate, y);
    const f_t = 1.0 - s_t;
    const df = Math.exp(-baseRiskFreeRate * y);
    const spreadBp = Math.round(hazardRate * (1 - 0.40) * 10000);

    points.push({
      tenorYears: y,
      tenorLabel: `${y}Y`,
      cdsSpreadBp: spreadBp,
      hazardRate: hazardRate,
      survivalProb: s_t,
      cumDefaultProb: f_t,
      discountFactor: df,
    });
  }

  return points;
}
