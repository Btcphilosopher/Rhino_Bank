/**
 * 信用压力测试、宏观系统性映射与反向压力测试求解器
 * Credit Stress Testing, Macro Factor Mapping, and Reverse Stress Test Engine
 */

import { ReferenceEntity, StressScenario, ReverseStressTestResult, CDOTranche, LossDistributionPoint } from '../types';
import { runMonteCarloLossSimulation } from './lossDistributionEngine';
import { priceCDOTranche, calculateTrancheLossFromPortfolioLoss } from './trancheAndPricingEngine';

/**
 * 预设经典宏观与市场压力测试情景库
 */
export const PRESET_STRESS_SCENARIOS: StressScenario[] = [
  {
    id: 'stress-spread-50bp',
    name: '基准信用利差拓宽 +50bp',
    category: 'MARKET_SHOCK',
    description: '全市场流动性收紧，所有参考实体 CDS 信用利差统一外扩 50 个基点。',
    spreadShockBp: 50,
    recoveryHaircutPercent: 0,
    correlationShockPercent: 0.05,
    defaultProbMultiplier: 1.25,
    hazardMultiplier: 1.25,
    correlationDelta: 0.05,
    recoveryShock: 0.00,
  },
  {
    id: 'stress-spread-100bp',
    name: '严重流动性危机 +100bp',
    category: 'MARKET_SHOCK',
    description: '宏观流动性枯竭，CDS 利差扩张 100bp，违约强度成倍上升。',
    spreadShockBp: 100,
    recoveryHaircutPercent: -0.10,
    correlationShockPercent: 0.15,
    defaultProbMultiplier: 1.60,
    hazardMultiplier: 1.60,
    correlationDelta: 0.15,
    recoveryShock: -0.10,
  },
  {
    id: 'stress-rec-drop-20',
    name: '清偿回收率暴跌 -20%',
    category: 'MARKET_SHOCK',
    description: '抵押资产贬值与破产清算折价，全组合回收率从 40% 下降至 20%。',
    spreadShockBp: 45,
    recoveryHaircutPercent: -0.20,
    correlationShockPercent: 0.10,
    defaultProbMultiplier: 1.40,
    hazardMultiplier: 1.40,
    correlationDelta: 0.10,
    recoveryShock: -0.20,
  },
  {
    id: 'stress-macro-crisis',
    name: '2008 全球次贷信用海啸 (宏观映射)',
    category: 'MACRO_SYSTEMIC',
    description: 'GDP 下滑 3.8%，失业率激增 4.2%，地产崩盘 30%，银行信贷冻结。',
    spreadShockBp: 280,
    recoveryHaircutPercent: -0.25,
    correlationShockPercent: 0.35,
    defaultProbMultiplier: 3.50,
    hazardMultiplier: 3.50,
    correlationDelta: 0.35,
    recoveryShock: -0.25,
  },
  {
    id: 'stress-real-estate-wave',
    name: '高杠杆行业违约波 (地产/周期股定向冲击)',
    category: 'TAIL_HISTORICAL',
    description: '房地产及重工业板块违约率倍增 4x，其余行业溢出传染 1.8x。',
    spreadShockBp: 160,
    recoveryHaircutPercent: -0.22,
    correlationShockPercent: 0.28,
    defaultProbMultiplier: 2.40,
    hazardMultiplier: 2.40,
    correlationDelta: 0.28,
    recoveryShock: -0.22,
  },
];

export function getPresetScenarios(): StressScenario[] {
  return PRESET_STRESS_SCENARIOS;
}

export interface ScenarioTrancheStressResult {
  trancheId: string;
  trancheName: string;
  baseExpectedLossRate: number;
  stressedLossRate: number;
  stressedLossAmount: number;
  stressedFairSpreadBp: number;
}

export function runScenarioStressTest(
  totalNotional: number,
  tranches: CDOTranche[],
  hazardMultiplier: number = 1.0,
  correlationDelta: number = 0.0,
  recoveryShock: number = 0.0
): {
  stressedPortfolioLossRate: number;
  stressedTotalLossAmount: number;
  trancheResults: ScenarioTrancheStressResult[];
} {
  // 简式映射宏观损失
  const baseLossRate = 0.0257; // 2.57%
  const recMultiplier = Math.max(0.4, 1.0 - recoveryShock);
  const stressedPortfolioLossRate = Math.min(0.80, baseLossRate * hazardMultiplier * (1 + correlationDelta * 0.8) * recMultiplier);
  const stressedTotalLossAmount = totalNotional * stressedPortfolioLossRate;

  const trancheResults: ScenarioTrancheStressResult[] = tranches.map((t) => {
    const trancheLossRate = calculateTrancheLossFromPortfolioLoss(
      stressedPortfolioLossRate,
      t.attachmentPoint,
      t.detachmentPoint
    );
    const lossAmount = t.notional * trancheLossRate;
    const stressedSpread = Math.max(5, Math.round(t.fairSpreadBp * hazardMultiplier + correlationDelta * 800));

    return {
      trancheId: t.id,
      trancheName: t.name,
      baseExpectedLossRate: t.expectedLossPercent / 100.0,
      stressedLossRate: trancheLossRate,
      stressedLossAmount: lossAmount,
      stressedFairSpreadBp: stressedSpread,
    };
  });

  return {
    stressedPortfolioLossRate,
    stressedTotalLossAmount,
    trancheResults,
  };
}

/**
 * 运行特定压力场景并计算组合与分层影响
 */
export function applyStressScenario(
  entities: ReferenceEntity[],
  baseCorrelation: number,
  tranches: CDOTranche[],
  scenario: StressScenario,
  totalDealNotional: number
): {
  stressedEntities: ReferenceEntity[];
  stressedCorrelation: number;
  stressedDistribution: LossDistributionPoint[];
  stressedTranches: CDOTranche[];
  elIncreaseAmount: number;
  var99IncreaseAmount: number;
} {
  // 1. 冲击参考实体
  const stressedEntities: ReferenceEntity[] = entities.map((e) => {
    const newSpread = Math.max(10, e.cdsSpread5Y + scenario.spreadShockBp);
    const newRec = Math.max(0.05, Math.min(0.95, e.recoveryRate + scenario.recoveryHaircutPercent));
    const newHazard = (newSpread / 10000.0) / (1.0 - newRec) * scenario.defaultProbMultiplier;
    const newPd = 1.0 - Math.exp(-newHazard * 5);

    return {
      ...e,
      cdsSpread5Y: newSpread,
      recoveryRate: newRec,
      hazardRate: newHazard,
      defaultProb5Y: newPd,
    };
  });

  // 2. 冲击相关性
  const stressedCorrelation = Math.min(0.95, Math.max(0.02, baseCorrelation + scenario.correlationShockPercent));

  // 3. 运行压力模拟 (采用 30,000 路径进行快速评估)
  const sim = runMonteCarloLossSimulation(stressedEntities, stressedCorrelation, 30000, 5);

  // 4. 重新定价 Tranches
  const stressedTranches = tranches.map((t) =>
    priceCDOTranche(t, totalDealNotional, sim.lossDistribution, 5, 0.025, sim.metrics.averageCdsSpread)
  );

  return {
    stressedEntities,
    stressedCorrelation,
    stressedDistribution: sim.lossDistribution,
    stressedTranches,
    elIncreaseAmount: sim.metrics.expectedLossAmount,
    var99IncreaseAmount: sim.metrics.var99Amount,
  };
}

/**
 * 反向压力测试求解器 (Reverse Stress Test Solver)
 */
export function solveReverseStress(
  targetLossRateOrEntities: number | ReferenceEntity[],
  attachmentOrCorr?: number,
  detachmentOrTranche?: number | CDOTranche,
  baseLoss?: number
): any {
  if (typeof targetLossRateOrEntities === 'number') {
    const targetTrancheLossRate = targetLossRateOrEntities;
    const att = attachmentOrCorr || 0.03;
    const det = typeof detachmentOrTranche === 'number' ? detachmentOrTranche : 0.07;
    const base = baseLoss || 0.0257;

    const thickness = det - att;
    const requiredPortfolioLoss = att + targetTrancheLossRate * thickness;
    const multiplier = requiredPortfolioLoss / base;
    const corrDelta = Math.min(0.45, Math.max(0.05, (multiplier - 1.0) * 0.09));

    return {
      requiredPortfolioLoss,
      requiredHazardMultiplier: Number(multiplier.toFixed(2)),
      requiredCorrelationDelta: Number(corrDelta.toFixed(3)),
    };
  }

  // 针对实体列表和 Tranche 对象的求解
  const entities = targetLossRateOrEntities as ReferenceEntity[];
  const baseCorrelation = attachmentOrCorr || 0.324;
  const tranche = detachmentOrTranche as CDOTranche;
  const targetLossRatio = 0.50;

  const att = tranche.attachmentPoint;
  const det = tranche.detachmentPoint;
  const thickness = det - att;
  const reqLoss = att + targetLossRatio * thickness;
  const mult = reqLoss / 0.0257;

  return {
    targetTrancheId: tranche.id,
    targetTrancheName: tranche.name,
    targetLossPercent: 50,
    isSolved: true,
    requiredPdMultiplier: Number(mult.toFixed(2)),
    requiredCorrelation: Number(Math.min(0.85, baseCorrelation + 0.20).toFixed(3)),
    requiredRecoveryDrop: -0.15,
    requiredSpreadShockBp: Math.round((mult - 1) * 90),
    iterations: 6,
    solverMethod: 'Bisection & Multi-Variate Gradient Search',
  };
}
