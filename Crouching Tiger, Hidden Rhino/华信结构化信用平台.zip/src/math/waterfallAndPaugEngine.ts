/**
 * 分层损失瀑布引擎与 PAUG 现金流生成引擎
 * Tranche Loss Waterfall & Pay-As-You-Go Cash Flow Schedule
 */

import { CDOTranche, CashflowItem, CashflowPeriod } from '../types';
import { calculateTrancheLossFromPortfolioLoss } from './trancheAndPricingEngine';

export interface WaterfallStepResult {
  trancheId: string;
  trancheName: string;
  category: CDOTranche['category'];
  attachment: number;
  detachment: number;
  initialNotional: number;
  absorbedLossAmount: number;
  remainingNotional: number;
  lossPercentage: number;
  isTriggered: boolean;
  isWipedOut: boolean;
  absorbedLoss: number;
  remainingPrincipal: number;
  lossRate: number;
}

/**
 * 运行损失瀑布穿透计算
 * 将输入组合总损失率 (0% - 100%) 依次穿透分配至各分层
 */
export function evaluateLossWaterfall(
  tranches: CDOTranche[],
  totalPortfolioNotional: number,
  portfolioLossRate: number // 0.0 to 1.0 (e.g. 0.05 for 5% portfolio loss)
): { steps: WaterfallStepResult[]; totalAbsorbed: number; unallocatedLoss: number } {
  const totalLossAmount = totalPortfolioNotional * portfolioLossRate;
  let runningAbsorbed = 0;

  const steps: WaterfallStepResult[] = tranches.map((t) => {
    const trancheLossRatio = calculateTrancheLossFromPortfolioLoss(
      portfolioLossRate,
      t.attachmentPoint,
      t.detachmentPoint
    );

    const trancheLossAmount = t.notional * trancheLossRatio;
    const remaining = Math.max(0, t.notional - trancheLossAmount);
    runningAbsorbed += trancheLossAmount;

    return {
      trancheId: t.id,
      trancheName: t.name,
      category: t.category,
      attachment: t.attachmentPoint,
      detachment: t.detachmentPoint,
      initialNotional: t.notional,
      absorbedLossAmount: Math.round(trancheLossAmount),
      absorbedLoss: Math.round(trancheLossAmount),
      remainingNotional: Math.round(remaining),
      remainingPrincipal: Math.round(remaining),
      lossPercentage: Number((trancheLossRatio * 100).toFixed(2)),
      lossRate: trancheLossRatio,
      isTriggered: trancheLossRatio > 0.0001,
      isWipedOut: trancheLossRatio >= 0.9999,
    };
  });

  return {
    steps,
    totalAbsorbed: runningAbsorbed,
    unallocatedLoss: Math.max(0, totalLossAmount - runningAbsorbed),
  };
}

export function calculateTrancheLossWaterfall(
  totalPortfolioNotional: number,
  portfolioLossRate: number,
  tranches: CDOTranche[]
): WaterfallStepResult[] {
  return evaluateLossWaterfall(tranches, totalPortfolioNotional, portfolioLossRate).steps;
}

/**
 * 生成 ISDA 标准 5年期 20季度 PAUG (Pay-As-You-Go) 现金流时间序列
 */
export function generatePaugCashflowSchedule(
  tranche: CDOTranche,
  maturityYears: number = 5,
  riskFreeRate: number = 0.025,
  simulatedCreditEventsCount: number = 3
): CashflowItem[] {
  const schedule: CashflowItem[] = [];
  const totalQuarters = maturityYears * 4;
  const quarterlyCouponRate = (tranche.contractSpreadBp / 10000) * 0.25;

  let currentNotional = tranche.notional;
  const startDate = new Date(2026, 8, 20); // 2026-09-20 IMM date

  // 设定在第 4、8、12 季度发生代表性信用事件
  const eventQuarters = [4, 8, 12, 16];

  for (let q = 1; q <= totalQuarters; q++) {
    const periodDate = new Date(startDate);
    periodDate.setMonth(periodDate.getMonth() + q * 3);
    const dateStr = periodDate.toISOString().split('T')[0];

    const begNotional = currentNotional;
    let periodEvents = 0;
    let lossInPeriod = 0;
    let recInPeriod = 0;

    if (eventQuarters.includes(q) && tranche.expectedLossPercent > 0) {
      periodEvents = 1;
      let lossScale = 0;
      if (tranche.category === 'Equity') lossScale = 0.22;
      else if (tranche.category === 'Mezzanine') lossScale = 0.08;
      else if (tranche.category === 'SeniorMezz') lossScale = 0.03;
      else if (tranche.category === 'Senior') lossScale = 0.008;

      lossInPeriod = Math.min(begNotional, tranche.notional * lossScale);
      recInPeriod = lossInPeriod * 0.40; // 40% 回收
    }

    const endNotional = Math.max(0, begNotional - lossInPeriod);
    currentNotional = endNotional;

    const avgNotional = (begNotional + endNotional) / 2.0;
    const coupon = avgNotional * quarterlyCouponRate;

    const tYears = q * 0.25;
    const df = Math.exp(-riskFreeRate * tYears);

    const netCash = coupon - lossInPeriod;
    const discCash = netCash * df;

    schedule.push({
      period: q,
      date: dateStr,
      beginningNotional: Math.round(begNotional),
      creditEventsInPeriod: periodEvents,
      trancheLossAmount: Math.round(lossInPeriod),
      trancheRecoveryAmount: Math.round(recInPeriod),
      couponPayment: Math.round(coupon),
      endingNotional: Math.round(endNotional),
      discountFactor: Number(df.toFixed(4)),
      netCashflow: Math.round(netCash),
      discountedCashflow: Math.round(discCash),
      isPayAsYouGoAdjusted: lossInPeriod > 0,
    });
  }

  return schedule;
}

export function generateStandardCashflows(
  tranche: CDOTranche,
  maturityYears: number = 5,
  riskFreeRate: number = 0.025,
  marginalWritedown: number = 0.005
): CashflowPeriod[] {
  const schedule = generatePaugCashflowSchedule(tranche, maturityYears, riskFreeRate);
  return schedule.map((item) => ({
    period: item.period,
    paymentDate: item.date,
    beginningNotional: item.beginningNotional,
    principalWritedown: item.trancheLossAmount,
    endingNotional: item.endingNotional,
    couponPayment: item.couponPayment,
    discountFactor: item.discountFactor,
    discountedNetCashflow: item.discountedCashflow,
  }));
}
