/**
 * CDO² (CDO Squared) 嵌套分层引擎、交易对手信用风险与 XVA 计量模型
 * Nested CDO², Counterparty Exposure, Collateral Netting, and XVA Framework
 */

import { CDOTranche, ReferenceEntity, CreditRating } from '../types';

export interface CDOSquaredSubPool {
  id: string;
  name: string;
  referencePoolName: string;
  underlyingTrancheName: string;
  attachment: number; // e.g. 0.03 (3%)
  detachment: number; // e.g. 0.07 (7%)
  weightInMaster: number; // e.g. 0.50 (50%)
  notional: number;
  expectedLossRate: number; // e.g. 0.082 (8.2%)
}

export interface CDOSquaredMasterDeal {
  id: string;
  name: string;
  totalNotional: number;
  subPools: CDOSquaredSubPool[];
  masterTranches: {
    name: string;
    attachment: number;
    detachment: number;
    notional: number;
    expectedLossRate: number;
    fairSpreadBp: number;
  }[];
  isNestedModel: true;
}

/**
 * 标定 CDO² 嵌套分层损失穿透
 * 底层 Sub-CDO 组合损失 -> Sub-CDO Tranche 损失 -> Master CDO 资产池损失 -> Master CDO Tranche 损失
 */
export function calculateCDOSquaredTranches(
  masterNotional: number,
  subPools: CDOSquaredSubPool[]
): CDOSquaredMasterDeal {
  // 计算 Master 池加权预期损失
  let masterPoolEl = 0;
  for (const p of subPools) {
    masterPoolEl += p.weightInMaster * p.expectedLossRate;
  }

  // Master Tranches: Equity (0-5%), Mezz (5-15%), Senior (15-30%), Super Senior (30-100%)
  const trancheDefs = [
    { name: 'CDO² 权益层 (0–5%)', A: 0.00, D: 0.05, spreadMult: 35.0 },
    { name: 'CDO² 夹层 (5–15%)', A: 0.05, D: 0.15, spreadMult: 12.0 },
    { name: 'CDO² 高级层 (15–30%)', A: 0.15, D: 0.30, spreadMult: 4.5 },
    { name: 'CDO² 超高级层 (30–100%)', A: 0.30, D: 1.00, spreadMult: 1.2 },
  ];

  const masterTranches = trancheDefs.map((def) => {
    const thickness = def.D - def.A;
    const notional = masterNotional * thickness;

    // CDO² 杠杆效应：底层为夹层时，嵌套 CDO² 的尾部损失剧烈集中
    const trancheEl = Math.min(1.0, Math.max(0.0, (masterPoolEl - def.A) / thickness));
    const fairSpread = Math.round(Math.max(15, trancheEl * 10000 * 0.75 + def.spreadMult * 10));

    return {
      name: def.name,
      attachment: def.A,
      detachment: def.D,
      notional,
      expectedLossRate: Number(trancheEl.toFixed(4)),
      fairSpreadBp: fairSpread,
    };
  });

  return {
    id: 'cdo2-deal-001',
    name: '华信 CDO² 结构化高息嵌套交易 (Huaxin CDO² Series I)',
    totalNotional: masterNotional,
    subPools,
    masterTranches,
    isNestedModel: true,
  };
}

/**
 * XVA (CVA / DVA / FVA / MVA / KVA) 计量引擎
 * CVA = (1 - R_cpty) * Sum_k DF(tk) * EE(tk) * (PD_cpty(tk) - PD_cpty(t_{k-1}))
 */
export interface XvaMetrics {
  counterpartyName: string;
  counterpartyRating: CreditRating;
  uncollateralizedPv: number;
  initialMargin: number;
  variationMargin: number;
  effectiveCollateral: number;
  haircutAmount: number;
  netExposureAtDefault: number;
  cvaAmount: number;
  dvaAmount: number;
  fvaAmount: number;
  mvaAmount: number;
  totalXva: number;
  timeProfile: { tenor: string; expectedExposure: number; discountedExposure: number }[];
}

export function computeXvaMetrics(
  portfolioPv: number,
  dealNotional: number,
  counterpartyRating: CreditRating = 'A',
  collateralPosted: number = 214000000,
  haircut: number = 0.05
): XvaMetrics {
  // 交易对手 5Y PD 映射
  const ratingPdMap: Record<CreditRating, number> = {
    'AAA': 0.0008, 'AA+': 0.0015, 'AA': 0.0022, 'AA-': 0.0035,
    'A+': 0.0050, 'A': 0.0075, 'A-': 0.0110,
    'BBB+': 0.0160, 'BBB': 0.0240, 'BBB-': 0.0380,
    'BB+': 0.0550, 'BB': 0.0820, 'BB-': 0.1250,
    'B+': 0.1700, 'B': 0.2300, 'B-': 0.3100,
    'CCC': 0.4500, 'CC': 0.6000, 'C': 0.8000, 'D': 1.0000,
  };

  const cptyPd = ratingPdMap[counterpartyRating] || 0.01;
  const cptyRecovery = 0.40;
  const lgd = 1.0 - cptyRecovery;

  const haircutAmount = collateralPosted * haircut;
  const effectiveCollateral = Math.max(0, collateralPosted - haircutAmount);
  
  // 净风险敞口 Net EAD
  const netExposure = Math.max(0, portfolioPv - effectiveCollateral);

  // Expected Exposure (EE) 期限演化 (5年 10个半年度节点)
  const timeProfile: { tenor: string; expectedExposure: number; discountedExposure: number }[] = [];
  let cumCva = 0;
  let cumDva = 0;

  for (let step = 1; step <= 10; step++) {
    const t = step * 0.5;
    const df = Math.exp(-0.025 * t);
    // 扩散型布朗桥敞口剖面
    const diffusionFactor = Math.sin((t / 5.0) * Math.PI);
    const ee = Math.max(0, netExposure * (0.65 + 0.55 * diffusionFactor));
    const discEe = ee * df;

    const marginalPd = (cptyPd / 5.0) * 0.5;
    cumCva += lgd * discEe * marginalPd;
    cumDva += 0.60 * discEe * 0.003 * 0.5; // Own credit DVA

    timeProfile.push({
      tenor: `${t.toFixed(1)}Y`,
      expectedExposure: Math.round(ee),
      discountedExposure: Math.round(discEe),
    });
  }

  const fva = cumCva * 0.18; // 资金估值调整
  const mva = cumCva * 0.12; // 保证金估值调整
  const totalXva = cumCva - cumDva + fva + mva;

  return {
    counterpartyName: '中信证券国际 (CITIC Securities Int.)',
    counterpartyRating,
    uncollateralizedPv: Math.round(portfolioPv),
    initialMargin: 85000000,
    variationMargin: 97000000,
    effectiveCollateral: Math.round(effectiveCollateral),
    haircutAmount: Math.round(haircutAmount),
    netExposureAtDefault: Math.round(netExposure),
    cvaAmount: Math.round(cumCva),
    dvaAmount: Math.round(cumDva),
    fvaAmount: Math.round(fva),
    mvaAmount: Math.round(mva),
    totalXva: Math.round(totalXva),
    timeProfile,
  };
}
