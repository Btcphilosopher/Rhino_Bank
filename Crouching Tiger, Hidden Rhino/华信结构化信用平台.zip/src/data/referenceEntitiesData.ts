/**
 * 华信结构化信用平台 - 100+ 参考实体高质量数据集
 * Reference Portfolio Dataset with Multi-Sector, Ratings, CDS Spreads & Hazard Rates
 */

import { ReferenceEntity, CreditRating, IndustrySector, Region } from '../types';
import { calibrateHazardRate } from '../math/hazardRate';

const rawEntitySeeds: {
  name: string;
  ticker: string;
  sector: IndustrySector;
  region: Region;
  rating: CreditRating;
  cds5Y: number;
  recovery: number;
}[] = [
  // 1. 金融服务 (Financials)
  { name: '中国工商银行 (ICBC)', ticker: '1398.HK', sector: '金融服务 (Financials)', region: '亚太 (APAC/CN)', rating: 'A', cds5Y: 48, recovery: 0.40 },
  { name: '中国建设银行 (CCB)', ticker: '0939.HK', sector: '金融服务 (Financials)', region: '亚太 (APAC/CN)', rating: 'A', cds5Y: 50, recovery: 0.40 },
  { name: '中国农业银行 (ABC)', ticker: '1288.HK', sector: '金融服务 (Financials)', region: '亚太 (APAC/CN)', rating: 'A', cds5Y: 52, recovery: 0.40 },
  { name: '中国银行 (BOC)', ticker: '3988.HK', sector: '金融服务 (Financials)', region: '亚太 (APAC/CN)', rating: 'A', cds5Y: 51, recovery: 0.40 },
  { name: '招商银行 (CMB)', ticker: '3968.HK', sector: '金融服务 (Financials)', region: '亚太 (APAC/CN)', rating: 'BBB+', cds5Y: 68, recovery: 0.40 },
  { name: '中信证券 (CITIC Sec)', ticker: '6030.HK', sector: '金融服务 (Financials)', region: '亚太 (APAC/CN)', rating: 'BBB', cds5Y: 88, recovery: 0.40 },
  { name: '中国平安保险 (Ping An)', ticker: '2318.HK', sector: '金融服务 (Financials)', region: '亚太 (APAC/CN)', rating: 'A-', cds5Y: 72, recovery: 0.40 },
  { name: '中国人寿 (China Life)', ticker: '2628.HK', sector: '金融服务 (Financials)', region: '亚太 (APAC/CN)', rating: 'A+', cds5Y: 58, recovery: 0.40 },
  { name: '摩根大通 (JPMorgan Chase)', ticker: 'JPM.N', sector: '金融服务 (Financials)', region: '北美 (North America)', rating: 'A+', cds5Y: 55, recovery: 0.40 },
  { name: '美国银行 (Bank of America)', ticker: 'BAC.N', sector: '金融服务 (Financials)', region: '北美 (North America)', rating: 'A-', cds5Y: 68, recovery: 0.40 },
  { name: '高盛集团 (Goldman Sachs)', ticker: 'GS.N', sector: '金融服务 (Financials)', region: '北美 (North America)', rating: 'BBB+', cds5Y: 82, recovery: 0.40 },
  { name: '法国巴黎银行 (BNP Paribas)', ticker: 'BNP.PA', sector: '金融服务 (Financials)', region: '欧洲 (Europe)', rating: 'A+', cds5Y: 62, recovery: 0.40 },
  { name: '汇丰控股 (HSBC Holdings)', ticker: 'HSBA.L', sector: '金融服务 (Financials)', region: '欧洲 (Europe)', rating: 'A', cds5Y: 60, recovery: 0.40 },

  // 2. 主权与公用事业 (Sovereign & Utilities)
  { name: '中国主权债基准 (China Sovereign)', ticker: 'CNGOV', sector: '主权与公共事业 (Sovereign & Utilities)', region: '亚太 (APAC/CN)', rating: 'A+', cds5Y: 42, recovery: 0.50 },
  { name: '国家电网 (State Grid)', ticker: 'STGRID', sector: '主权与公共事业 (Sovereign & Utilities)', region: '亚太 (APAC/CN)', rating: 'A+', cds5Y: 46, recovery: 0.45 },
  { name: '中国南方电网 (CSG)', ticker: 'CSGCN', sector: '主权与公共事业 (Sovereign & Utilities)', region: '亚太 (APAC/CN)', rating: 'A', cds5Y: 50, recovery: 0.45 },
  { name: '三峡集团 (CTG)', ticker: 'TGCN', sector: '主权与公共事业 (Sovereign & Utilities)', region: '亚太 (APAC/CN)', rating: 'A', cds5Y: 53, recovery: 0.40 },
  { name: '法国电力 (EDF)', ticker: 'EDF.PA', sector: '主权与公共事业 (Sovereign & Utilities)', region: '欧洲 (Europe)', rating: 'BBB', cds5Y: 95, recovery: 0.40 },
  { name: '杜克能源 (Duke Energy)', ticker: 'DUK.N', sector: '主权与公共事业 (Sovereign & Utilities)', region: '北美 (North America)', rating: 'A-', cds5Y: 65, recovery: 0.40 },

  // 3. 信息科技 (Technology)
  { name: '腾讯控股 (Tencent)', ticker: '0700.HK', sector: '信息科技 (Technology)', region: '亚太 (APAC/CN)', rating: 'A+', cds5Y: 56, recovery: 0.40 },
  { name: '阿里巴巴集团 (Alibaba)', ticker: '9988.HK', sector: '信息科技 (Technology)', region: '亚太 (APAC/CN)', rating: 'A+', cds5Y: 64, recovery: 0.40 },
  { name: '华为投资控股 (Huawei)', ticker: 'HUAW', sector: '信息科技 (Technology)', region: '亚太 (APAC/CN)', rating: 'A-', cds5Y: 85, recovery: 0.40 },
  { name: '百度 (Baidu)', ticker: 'BIDU.O', sector: '信息科技 (Technology)', region: '亚太 (APAC/CN)', rating: 'A', cds5Y: 78, recovery: 0.40 },
  { name: '美团 (Meituan)', ticker: '3690.HK', sector: '信息科技 (Technology)', region: '亚太 (APAC/CN)', rating: 'BBB', cds5Y: 125, recovery: 0.40 },
  { name: '中芯国际 (SMIC)', ticker: '0981.HK', sector: '信息科技 (Technology)', region: '亚太 (APAC/CN)', rating: 'BBB-', cds5Y: 155, recovery: 0.40 },
  { name: '苹果公司 (Apple Inc.)', ticker: 'AAPL.O', sector: '信息科技 (Technology)', region: '北美 (North America)', rating: 'AAA', cds5Y: 25, recovery: 0.40 },
  { name: '微软公司 (Microsoft)', ticker: 'MSFT.O', sector: '信息科技 (Technology)', region: '北美 (North America)', rating: 'AAA', cds5Y: 24, recovery: 0.40 },
  { name: '英伟达 (NVIDIA)', ticker: 'NVDA.O', sector: '信息科技 (Technology)', region: '北美 (North America)', rating: 'AA-', cds5Y: 34, recovery: 0.40 },
  { name: '阿斯麦 (ASML Holding)', ticker: 'ASML.AS', sector: '信息科技 (Technology)', region: '欧洲 (Europe)', rating: 'AA-', cds5Y: 38, recovery: 0.40 },
  { name: '台积电 (TSMC)', ticker: '2330.TW', sector: '信息科技 (Technology)', region: '亚太 (APAC/CN)', rating: 'AA-', cds5Y: 36, recovery: 0.40 },

  // 4. 能源与化工 (Energy & Chemicals)
  { name: '中国石油 (PetroChina)', ticker: '0857.HK', sector: '能源与化工 (Energy & Chemicals)', region: '亚太 (APAC/CN)', rating: 'A+', cds5Y: 52, recovery: 0.40 },
  { name: '中国石化 (Sinopec)', ticker: '0386.HK', sector: '能源与化工 (Energy & Chemicals)', region: '亚太 (APAC/CN)', rating: 'A+', cds5Y: 54, recovery: 0.40 },
  { name: '中国海油 (CNOOC)', ticker: '0883.HK', sector: '能源与化工 (Energy & Chemicals)', region: '亚太 (APAC/CN)', rating: 'A+', cds5Y: 50, recovery: 0.40 },
  { name: '万华化学 (Wanhua Chem)', ticker: '600309.SH', sector: '能源与化工 (Energy & Chemicals)', region: '亚太 (APAC/CN)', rating: 'BBB+', cds5Y: 98, recovery: 0.40 },
  { name: '沙特阿美 (Saudi Aramco)', ticker: '2222.SE', sector: '能源与化工 (Energy & Chemicals)', region: '新兴市场 (Emerging Markets)', rating: 'A', cds5Y: 60, recovery: 0.40 },
  { name: '埃克森美孚 (ExxonMobil)', ticker: 'XOM.N', sector: '能源与化工 (Energy & Chemicals)', region: '北美 (North America)', rating: 'AA-', cds5Y: 38, recovery: 0.40 },
  { name: '壳牌公司 (Shell Plc)', ticker: 'SHEL.L', sector: '能源与化工 (Energy & Chemicals)', region: '欧洲 (Europe)', rating: 'A+', cds5Y: 45, recovery: 0.40 },

  // 5. 工业与制造 (Industrials)
  { name: '宁德时代 (CATL)', ticker: '300750.SZ', sector: '工业与制造 (Industrials)', region: '亚太 (APAC/CN)', rating: 'BBB+', cds5Y: 92, recovery: 0.40 },
  { name: '中国中车 (CRRC)', ticker: '1766.HK', sector: '工业与制造 (Industrials)', region: '亚太 (APAC/CN)', rating: 'A', cds5Y: 62, recovery: 0.40 },
  { name: '中国宝武钢铁 (Baowu)', ticker: 'BAOWU', sector: '工业与制造 (Industrials)', region: '亚太 (APAC/CN)', rating: 'A-', cds5Y: 82, recovery: 0.35 },
  { name: '三一重工 (Sany Heavy)', ticker: '600031.SH', sector: '工业与制造 (Industrials)', region: '亚太 (APAC/CN)', rating: 'BBB', cds5Y: 135, recovery: 0.35 },
  { name: '西门子 (Siemens AG)', ticker: 'SIE.DE', sector: '工业与制造 (Industrials)', region: '欧洲 (Europe)', rating: 'A+', cds5Y: 48, recovery: 0.40 },
  { name: '通用电气 (GE Aerospace)', ticker: 'GE.N', sector: '工业与制造 (Industrials)', region: '北美 (North America)', rating: 'BBB+', cds5Y: 78, recovery: 0.40 },
  { name: '波音公司 (Boeing)', ticker: 'BA.N', sector: '工业与制造 (Industrials)', region: '北美 (North America)', rating: 'BBB-', cds5Y: 195, recovery: 0.35 },

  // 6. 房地产与建筑 (Real Estate & Construction) - 包含部分高收益 / 困境实体用于尾部风险
  { name: '中国海外发展 (COLI)', ticker: '0688.HK', sector: '房地产与建筑 (Real Estate)', region: '亚太 (APAC/CN)', rating: 'BBB+', cds5Y: 145, recovery: 0.35 },
  { name: '华润置地 (CR Land)', ticker: '1109.HK', sector: '房地产与建筑 (Real Estate)', region: '亚太 (APAC/CN)', rating: 'BBB+', cds5Y: 138, recovery: 0.35 },
  { name: '中国铁建 (CRCC)', ticker: '1186.HK', sector: '房地产与建筑 (Real Estate)', region: '亚太 (APAC/CN)', rating: 'A-', cds5Y: 85, recovery: 0.35 },
  { name: '万科企业 (Vanke Group)', ticker: '2202.HK', sector: '房地产与建筑 (Real Estate)', region: '亚太 (APAC/CN)', rating: 'BB-', cds5Y: 480, recovery: 0.30 },
  { name: '龙湖集团 (Longfor)', ticker: '0960.HK', sector: '房地产与建筑 (Real Estate)', region: '亚太 (APAC/CN)', rating: 'B+', cds5Y: 620, recovery: 0.25 },
  { name: '西蒙地产 (Simon Property)', ticker: 'SPG.N', sector: '房地产与建筑 (Real Estate)', region: '北美 (North America)', rating: 'A-', cds5Y: 88, recovery: 0.40 },
  { name: '恒大重组实体 (Evergrande Entity)', ticker: '3333.HK', sector: '房地产与建筑 (Real Estate)', region: '亚太 (APAC/CN)', rating: 'CCC', cds5Y: 1850, recovery: 0.15 },

  // 7. 消费品与零售 (Consumer Goods)
  { name: '贵州茅台 (Kweichow Moutai)', ticker: '600519.SH', sector: '消费品与零售 (Consumer Goods)', region: '亚太 (APAC/CN)', rating: 'AA', cds5Y: 38, recovery: 0.40 },
  { name: '五粮液 (Wuliangye)', ticker: '000858.SZ', sector: '消费品与零售 (Consumer Goods)', region: '亚太 (APAC/CN)', rating: 'AA-', cds5Y: 45, recovery: 0.40 },
  { name: '伊利股份 (Yili Group)', ticker: '600887.SH', sector: '消费品与零售 (Consumer Goods)', region: '亚太 (APAC/CN)', rating: 'A-', cds5Y: 76, recovery: 0.40 },
  { name: '农夫山泉 (Nongfu Spring)', ticker: '9633.HK', sector: '消费品与零售 (Consumer Goods)', region: '亚太 (APAC/CN)', rating: 'A', cds5Y: 62, recovery: 0.40 },
  { name: '雀巢公司 (Nestlé)', ticker: 'NESN.SW', sector: '消费品与零售 (Consumer Goods)', region: '欧洲 (Europe)', rating: 'AA+', cds5Y: 30, recovery: 0.40 },
  { name: '沃尔玛 (Walmart)', ticker: 'WMT.N', sector: '消费品与零售 (Consumer Goods)', region: '北美 (North America)', rating: 'AA', cds5Y: 32, recovery: 0.40 },

  // 8. 医疗健康与通信 (Healthcare & Telecom)
  { name: '中国移动 (China Mobile)', ticker: '0941.HK', sector: '通信与媒体 (Telecom & Media)', region: '亚太 (APAC/CN)', rating: 'A+', cds5Y: 44, recovery: 0.45 },
  { name: '中国电信 (China Telecom)', ticker: '0728.HK', sector: '通信与媒体 (Telecom & Media)', region: '亚太 (APAC/CN)', rating: 'A', cds5Y: 48, recovery: 0.45 },
  { name: '辉瑞制药 (Pfizer)', ticker: 'PFE.N', sector: '医疗健康 (Healthcare)', region: '北美 (North America)', rating: 'A', cds5Y: 58, recovery: 0.40 },
  { name: '罗氏控股 (Roche)', ticker: 'ROG.SW', sector: '医疗健康 (Healthcare)', region: '欧洲 (Europe)', rating: 'AA', cds5Y: 32, recovery: 0.40 },
  { name: '药明康德 (WuXi AppTec)', ticker: '2359.HK', sector: '医疗健康 (Healthcare)', region: '亚太 (APAC/CN)', rating: 'BBB', cds5Y: 140, recovery: 0.35 },

  // 9. 交通运输与航空 (Transportation)
  { name: '中远海控 (COSCO Shipping)', ticker: '1919.HK', sector: '交通运输 (Transportation)', region: '亚太 (APAC/CN)', rating: 'BBB+', cds5Y: 105, recovery: 0.35 },
  { name: '京沪高铁 (CR Jinghu)', ticker: '601816.SH', sector: '交通运输 (Transportation)', region: '亚太 (APAC/CN)', rating: 'A+', cds5Y: 49, recovery: 0.45 },
  { name: '达美航空 (Delta Air Lines)', ticker: 'DAL.N', sector: '交通运输 (Transportation)', region: '北美 (North America)', rating: 'BBB-', cds5Y: 175, recovery: 0.35 },
  { name: '马士基 (A.P. Moller-Maersk)', ticker: 'MAERSKb.CO', sector: '交通运输 (Transportation)', region: '欧洲 (Europe)', rating: 'BBB+', cds5Y: 96, recovery: 0.40 },
];

/**
 * 扩充生成 100+ 代表性参考实体组合 (标准化总名义本金 ¥48.2 bn)
 */
export function buildMasterReferencePortfolio(totalTargetNotional: number = 48200000000): ReferenceEntity[] {
  const list: ReferenceEntity[] = [];
  const targetCount = 100;
  const singleNotional = totalTargetNotional / targetCount;
  const weight = 1.0 / targetCount;

  for (let i = 0; i < targetCount; i++) {
    const seed = rawEntitySeeds[i % rawEntitySeeds.length];
    const suffix = i >= rawEntitySeeds.length ? ` (分部/子公司 ${Math.floor(i / rawEntitySeeds.length) + 1})` : '';
    const id = `ENT-${String(i + 1).padStart(4, '0')}`;

    // 微小利差扰动以保持真实分散度
    const jitter = ((i * 7 + 13) % 21) - 10;
    const cds5Y = Math.max(15, seed.cds5Y + jitter);
    const cds1Y = Math.round(cds5Y * 0.68);
    const cds3Y = Math.round(cds5Y * 0.86);
    const cds7Y = Math.round(cds5Y * 1.14);
    const cds10Y = Math.round(cds5Y * 1.28);

    const hazard = calibrateHazardRate(cds5Y, seed.recovery);
    const pd5Y = 1.0 - Math.exp(-hazard * 5);

    list.push({
      id,
      name: `${seed.name}${suffix}`,
      ticker: seed.ticker,
      sector: seed.sector,
      region: seed.region,
      rating: seed.rating,
      cdsSpread1Y: cds1Y,
      cdsSpread3Y: cds3Y,
      cdsSpread5Y: cds5Y,
      cdsSpread7Y: cds7Y,
      cdsSpread10Y: cds10Y,
      recoveryRate: seed.recovery,
      hazardRate: Number(hazard.toFixed(5)),
      defaultProb5Y: Number(pd5Y.toFixed(4)),
      notional: singleNotional,
      weight,
      isDemoData: true,
      dataSource: '华信量化信用数据服务 (Huaxin Synthetic Market Data Feed)',
      lastUpdated: '2026-09-17 10:45:00 CST',
    });
  }

  return list;
}
