/**
 * 标准化信用指数分层数据 (CDX / iTraxx Index Tranches & Bespoke Tranche Presets)
 */

export interface IndexTrancheSeries {
  indexCode: string;
  name: string;
  series: number;
  version: number;
  currency: string;
  underlyingCount: number;
  indexSpreadBp: number;
  tranches: {
    name: string;
    attachment: number;
    detachment: number;
    standardCouponBp: number;
    quotedUpfrontPercent: number;
    fairSpreadBp: number;
    expectedLossPercent: number;
  }[];
}

export const STANDARD_CREDIT_INDICES: IndexTrancheSeries[] = [
  {
    indexCode: 'CDX.NA.IG',
    name: '北美投资级信用违约互换指数 (CDX North American Investment Grade)',
    series: 42,
    version: 1,
    currency: 'USD',
    underlyingCount: 125,
    indexSpreadBp: 52,
    tranches: [
      { name: '0% – 3% 权益层 (Equity)', attachment: 0.00, detachment: 0.03, standardCouponBp: 500, quotedUpfrontPercent: 26.4, fairSpreadBp: 1420, expectedLossPercent: 24.5 },
      { name: '3% – 7% 初级夹层 (Junior Mezz)', attachment: 0.03, detachment: 0.07, standardCouponBp: 100, quotedUpfrontPercent: 4.8, fairSpreadBp: 340, expectedLossPercent: 6.2 },
      { name: '7% – 10% 高级夹层 (Senior Mezz)', attachment: 0.07, detachment: 0.10, standardCouponBp: 100, quotedUpfrontPercent: -1.2, fairSpreadBp: 145, expectedLossPercent: 1.8 },
      { name: '10% – 15% 次高级层 (Sub-Senior)', attachment: 0.10, detachment: 0.15, standardCouponBp: 100, quotedUpfrontPercent: -3.6, fairSpreadBp: 65, expectedLossPercent: 0.6 },
      { name: '15% – 30% 超高级层 (Super Senior)', attachment: 0.15, detachment: 0.30, standardCouponBp: 100, quotedUpfrontPercent: -4.8, fairSpreadBp: 22, expectedLossPercent: 0.1 },
    ],
  },
  {
    indexCode: 'iTraxx.Europe',
    name: '欧洲主要投资级信用违约互换指数 (iTraxx Europe Benchmark)',
    series: 41,
    version: 1,
    currency: 'EUR',
    underlyingCount: 125,
    indexSpreadBp: 58,
    tranches: [
      { name: '0% – 3% 权益层 (Equity)', attachment: 0.00, detachment: 0.03, standardCouponBp: 500, quotedUpfrontPercent: 29.1, fairSpreadBp: 1510, expectedLossPercent: 27.2 },
      { name: '3% – 6% 夹层 A (Mezzanine A)', attachment: 0.03, detachment: 0.06, standardCouponBp: 100, quotedUpfrontPercent: 6.2, fairSpreadBp: 385, expectedLossPercent: 7.8 },
      { name: '6% – 9% 夹层 B (Mezzanine B)', attachment: 0.06, detachment: 0.09, standardCouponBp: 100, quotedUpfrontPercent: 0.5, fairSpreadBp: 165, expectedLossPercent: 2.3 },
      { name: '9% – 12% 高级层 (Senior)', attachment: 0.09, detachment: 0.12, standardCouponBp: 100, quotedUpfrontPercent: -2.8, fairSpreadBp: 78, expectedLossPercent: 0.8 },
      { name: '12% – 22% 超高级层 (Super Senior)', attachment: 0.12, detachment: 0.22, standardCouponBp: 100, quotedUpfrontPercent: -4.5, fairSpreadBp: 28, expectedLossPercent: 0.2 },
    ],
  },
  {
    indexCode: 'CSCC.China50',
    name: '华信中国优质央国企与核心主体信用指数 (China Sovereign & Core Corporates)',
    series: 8,
    version: 2,
    currency: 'CNY',
    underlyingCount: 50,
    indexSpreadBp: 64,
    tranches: [
      { name: '0% – 3% 权益层 (Equity)', attachment: 0.00, detachment: 0.03, standardCouponBp: 500, quotedUpfrontPercent: 24.8, fairSpreadBp: 1380, expectedLossPercent: 22.8 },
      { name: '3% – 7% 夹层 (Mezzanine)', attachment: 0.03, detachment: 0.07, standardCouponBp: 200, quotedUpfrontPercent: 2.1, fairSpreadBp: 320, expectedLossPercent: 5.4 },
      { name: '7% – 10% 优先夹层 (Senior Mezz)', attachment: 0.07, detachment: 0.10, standardCouponBp: 100, quotedUpfrontPercent: -0.8, fairSpreadBp: 135, expectedLossPercent: 1.5 },
      { name: '10% – 15% 优先级 (Senior)', attachment: 0.10, detachment: 0.15, standardCouponBp: 50, quotedUpfrontPercent: -1.5, fairSpreadBp: 58, expectedLossPercent: 0.4 },
      { name: '15% – 100% 超优先级 (Super Senior)', attachment: 0.15, detachment: 1.00, standardCouponBp: 25, quotedUpfrontPercent: -2.2, fairSpreadBp: 16, expectedLossPercent: 0.05 },
    ],
  },
];
