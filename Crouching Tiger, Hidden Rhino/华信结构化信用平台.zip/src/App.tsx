/**
 * 华信结构化信用平台 (HuaxinSyntheticCDO v3.7)
 * 主应用程序入口与状态流转中枢
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  ModelEnvironment, 
  ReferenceEntity, 
  SyntheticCDODeal, 
  CDOTranche, 
  LossDistributionPoint, 
  PortfolioRiskMetrics, 
  DataLineageChain, 
  AuditLogItem,
  CreditEventType,
  SettlementType
} from './types';
import { buildMasterReferencePortfolio } from './data/referenceEntitiesData';
import { INITIAL_AUDIT_LOGS } from './data/modelGovernanceData';
import { simulatePortfolioLossDistribution } from './math/lossDistributionEngine';
import { calculateTrancheLossAndSpread, computeTrancheGreeks } from './math/trancheAndPricingEngine';

import { Header } from './components/Header';
import { Navigation, NavTabKey } from './components/Navigation';
import { DashboardView } from './components/views/DashboardView';
import { StructuringView } from './components/views/StructuringView';
import { PortfolioView } from './components/views/PortfolioView';
import { CreditCurvesView } from './components/views/CreditCurvesView';
import { CorrelationView } from './components/views/CorrelationView';
import { SimulationView } from './components/views/SimulationView';
import { WaterfallView } from './components/views/WaterfallView';
import { PricingAndGreeksView } from './components/views/PricingAndGreeksView';
import { StressTestingView } from './components/views/StressTestingView';
import { CdoSquaredAndXvaView } from './components/views/CdoSquaredAndXvaView';
import { ModelGovernanceAndDocsView } from './components/views/ModelGovernanceAndDocsView';

import { DataLineageModal } from './components/modals/DataLineageModal';
import { CreditEventModal } from './components/modals/CreditEventModal';
import { AuditLogModal } from './components/modals/AuditLogModal';
import { TermSheetModal } from './components/modals/TermSheetModal';

export default function App() {
  const [environment, setEnvironment] = useState<ModelEnvironment>('SIMULATION');
  const [activeTab, setActiveTab] = useState<NavTabKey>('dashboard');
  const [isCalculating, setIsCalculating] = useState(false);
  const [lastCalcTimeMs, setLastCalcTimeMs] = useState<number>(145);
  const [simulationPaths, setSimulationPaths] = useState<number>(100000);
  const [systemCorrelation, setSystemCorrelation] = useState<number>(0.324);

  // 1. 实体库初始加载
  const [entities, setEntities] = useState<ReferenceEntity[]>(() => buildMasterReferencePortfolio(48200000000));

  // 2. 初始合成 CDO 交易结构
  const initialTranches: CDOTranche[] = [
    {
      id: 'tr-01',
      name: '0%–3% 权益层 (Equity)',
      category: 'Equity',
      attachmentPoint: 0.00,
      detachmentPoint: 0.03,
      notional: 1446000000,
      contractSpreadBp: 1500,
      fairSpreadBp: 1420,
      upfrontFeePercent: 26.4,
      expectedLossPercent: 25.8,
      expectedLossAmount: 373068000,
      protectionLegPv: 345000000,
      premiumLegPv: 365000000,
      pv: 20000000,
      cs01: -185000,
      dv01: 24000,
      correlationDelta: 450000,
      targetRating: 'NR',
    },
    {
      id: 'tr-02',
      name: '3%–7% 夹层 A (Mezzanine A)',
      category: 'Mezzanine',
      attachmentPoint: 0.03,
      detachmentPoint: 0.07,
      notional: 1928000000,
      contractSpreadBp: 350,
      fairSpreadBp: 345,
      upfrontFeePercent: 3.8,
      expectedLossPercent: 6.4,
      expectedLossAmount: 123392000,
      protectionLegPv: 115000000,
      premiumLegPv: 118000000,
      pv: 3000000,
      cs01: 142000,
      dv01: -32000,
      correlationDelta: -280000,
      targetRating: 'BBB',
    },
    {
      id: 'tr-03',
      name: '7%–10% 夹层 B (Mezzanine B)',
      category: 'SeniorMezz',
      attachmentPoint: 0.07,
      detachmentPoint: 0.10,
      notional: 1446000000,
      contractSpreadBp: 150,
      fairSpreadBp: 148,
      upfrontFeePercent: 0.5,
      expectedLossPercent: 1.9,
      expectedLossAmount: 27474000,
      protectionLegPv: 26000000,
      premiumLegPv: 27000000,
      pv: 1000000,
      cs01: 85000,
      dv01: -18000,
      correlationDelta: -120000,
      targetRating: 'A',
    },
    {
      id: 'tr-04',
      name: '10%–15% 高级层 (Senior)',
      category: 'Senior',
      attachmentPoint: 0.10,
      detachmentPoint: 0.15,
      notional: 2410000000,
      contractSpreadBp: 65,
      fairSpreadBp: 62,
      upfrontFeePercent: -0.8,
      expectedLossPercent: 0.5,
      expectedLossAmount: 12050000,
      protectionLegPv: 11500000,
      premiumLegPv: 12200000,
      pv: 700000,
      cs01: 52000,
      dv01: -9500,
      correlationDelta: -65000,
      targetRating: 'AA',
    },
    {
      id: 'tr-05',
      name: '15%–100% 超高级层 (Super Senior)',
      category: 'SuperSenior',
      attachmentPoint: 0.15,
      detachmentPoint: 1.00,
      notional: 40970000000,
      contractSpreadBp: 18,
      fairSpreadBp: 16,
      upfrontFeePercent: -1.5,
      expectedLossPercent: 0.05,
      expectedLossAmount: 20485000,
      protectionLegPv: 19500000,
      premiumLegPv: 21000000,
      pv: 1500000,
      cs01: 18000,
      dv01: -4500,
      correlationDelta: -15000,
      targetRating: 'AAA',
    },
  ];

  const [deal, setDeal] = useState<SyntheticCDODeal>({
    id: 'deal-001',
    dealName: '华信稳健结构化信用一期 (Huaxin Synthetic Master 2026-1)',
    tradeId: 'DEAL-HX-2026-01',
    effectiveDate: '2026-09-20',
    maturityDate: '2031-09-20',
    maturityYears: 5,
    currency: 'CNY',
    totalNotional: 48200000000,
    settlementType: '拍卖结算 (Auction Settlement)',
    isPAUG: true,
    counterparty: '中信证券国际 (CITIC Securities Int.)',
    counterpartyRating: 'A',
    initialMargin: 85000000,
    variationMargin: 97000000,
    collateralHaircut: 0.05,
    tranches: initialTranches,
  });

  // 3. 损失分布与风险指标状态
  const [lossDistribution, setLossDistribution] = useState<LossDistributionPoint[]>([]);
  const [riskMetrics, setRiskMetrics] = useState<PortfolioRiskMetrics>({
    totalNotional: 48200000000,
    referenceEntityCount: 100,
    activeEntitiesCount: 100,
    averageCdsSpread: 146,
    averageRecoveryRate: 0.40,
    averageHazardRate: 0.0243,
    expectedLossAmount: 1240000000,
    expectedLossPercent: 2.57,
    var95Amount: 3250000000,
    var99Amount: 4830000000,
    var999Amount: 7210000000,
    es99Amount: 5850000000,
    es999Amount: 7850000000,
    skewness: 2.84,
    kurtosis: 14.62,
    simulationPaths: 100000,
    calculationTimeMs: 145,
    timestamp: '2026-09-17 11:00:00 CST',
  });

  // 4. 审计日志
  const [auditLogs, setAuditLogs] = useState<AuditLogItem[]>(INITIAL_AUDIT_LOGS);

  // 5. 模态框状态
  const [activeLineageChain, setActiveLineageChain] = useState<DataLineageChain | null>(null);
  const [isCreditEventModalOpen, setIsCreditEventModalOpen] = useState(false);
  const [isAuditLogModalOpen, setIsAuditLogModalOpen] = useState(false);
  const [isTermSheetModalOpen, setIsTermSheetModalOpen] = useState(false);

  // 重新计算全组合损失分布与 Tranche 定价
  const runFullCalculation = (paths: number = simulationPaths, rho: number = systemCorrelation) => {
    setIsCalculating(true);
    const start = performance.now();

    // 向量化蒙特卡洛计算
    setTimeout(() => {
      const result = simulatePortfolioLossDistribution(
        entities,
        rho,
        paths,
        5.0,
        deal.totalNotional
      );

      const end = performance.now();
      const elapsed = Math.round(end - start) + 12;

      setLossDistribution(result.distribution);
      setRiskMetrics({
        ...result.metrics,
        simulationPaths: paths,
        calculationTimeMs: elapsed,
      });
      setLastCalcTimeMs(elapsed);

      // 同步更新 Tranches 定价
      const updatedTranches = deal.tranches.map((t) => {
        const pr = calculateTrancheLossAndSpread(
          result.distribution,
          t.attachmentPoint,
          t.detachmentPoint,
          t.notional,
          5.0,
          0.025,
          t.contractSpreadBp
        );
        const greeks = computeTrancheGreeks(
          t.notional,
          pr.expectedLossRate,
          t.contractSpreadBp,
          pr.fairSpreadBp
        );

        return {
          ...t,
          fairSpreadBp: pr.fairSpreadBp,
          upfrontFeePercent: pr.upfrontFeePercent,
          expectedLossPercent: Number((pr.expectedLossRate * 100).toFixed(2)),
          expectedLossAmount: pr.expectedLossAmount,
          protectionLegPv: pr.protectionLegPv,
          premiumLegPv: pr.premiumLegPv,
          pv: pr.pv,
          cs01: greeks.cs01,
          dv01: greeks.dv01,
          correlationDelta: greeks.correlationDelta,
        };
      });

      setDeal((prev) => ({ ...prev, tranches: updatedTranches }));
      setIsCalculating(false);
    }, 150);
  };

  // 初始化首次运行
  useEffect(() => {
    runFullCalculation(simulationPaths, systemCorrelation);
  }, []);

  // 处理相关性调整
  const handleCorrelationChange = (newRho: number) => {
    setSystemCorrelation(newRho);
    runFullCalculation(simulationPaths, newRho);
  };

  // 处理分层更新
  const handleUpdateDeal = (updatedDeal: SyntheticCDODeal) => {
    setDeal(updatedDeal);
    runFullCalculation(simulationPaths, systemCorrelation);
  };

  // 模拟信用事件处理
  const handleSimulateCreditEvent = (
    entityId: string,
    eventType: CreditEventType,
    auctionRecovery: number,
    settlementType: SettlementType
  ) => {
    const target = entities.find((e) => e.id === entityId);
    if (!target) return;

    // 调整违约实体 CDS 与违约率
    const updatedEntities = entities.map((e) => {
      if (e.id !== entityId) return e;
      return {
        ...e,
        recoveryRate: auctionRecovery,
        cdsSpread5Y: 5000,
        defaultProb5Y: 1.0,
        hazardRate: 0.9999,
      };
    });
    setEntities(updatedEntities);

    // 记录审计日志
    const newLog: AuditLogItem = {
      id: `AUD-${Date.now()}`,
      timestamp: new Date().toLocaleString('zh-CN'),
      user: '张华 (量化主管 - Quantitative Lead)',
      role: '风险计量官',
      action: `模拟触发信用事件: ${eventType}`,
      targetEntity: `[${target.id}] ${target.name}`,
      targetId: target.id,
      parameters: `Auction Recovery=${(auctionRecovery * 100).toFixed(0)}%, Settlement=${settlementType}`,
      hash: `a8b9c0${Date.now()}fe1234567890abcdef1234567890abcdef`,
    };
    setAuditLogs([newLog, ...auditLogs]);

    runFullCalculation(simulationPaths, systemCorrelation);
  };

  return (
    <div className="min-h-screen bg-[#070b13] text-slate-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* 顶部通用控制与状态栏 */}
      <Header
        environment={environment}
        onEnvironmentChange={setEnvironment}
        isCalculating={isCalculating}
        onRecalculate={() => runFullCalculation(simulationPaths, systemCorrelation)}
        onOpenAuditLog={() => setIsAuditLogModalOpen(true)}
        onOpenTermSheet={() => setIsTermSheetModalOpen(true)}
        simulationPaths={simulationPaths}
        lastCalcTimeMs={lastCalcTimeMs}
      />

      {/* 主导航条 */}
      <Navigation activeTab={activeTab} onTabChange={setActiveTab} />

      {/* 主视图区域 */}
      <main className="flex-1 p-4 max-w-[1680px] w-full mx-auto">
        {activeTab === 'dashboard' && (
          <DashboardView
            metrics={riskMetrics}
            lossDistribution={lossDistribution}
            tranches={deal.tranches}
            entities={entities}
            systemCorrelation={systemCorrelation}
            onCorrelationChange={handleCorrelationChange}
            onOpenDataLineage={(chain) => setActiveLineageChain(chain)}
            onOpenCreditEventModal={() => setIsCreditEventModalOpen(true)}
            onNavigateToTab={setActiveTab}
            onUpdateTrancheAttachment={() => {}}
          />
        )}

        {activeTab === 'structuring' && (
          <StructuringView
            deal={deal}
            onUpdateDeal={handleUpdateDeal}
            onNavigateToPricing={() => setActiveTab('pricing')}
          />
        )}

        {activeTab === 'portfolio' && (
          <PortfolioView
            entities={entities}
            onUpdateEntityWeight={() => {}}
            onOpenCreditEventModal={() => setIsCreditEventModalOpen(true)}
          />
        )}

        {activeTab === 'curves' && (
          <CreditCurvesView entities={entities} />
        )}

        {activeTab === 'correlation' && (
          <CorrelationView
            systemCorrelation={systemCorrelation}
            onCorrelationChange={handleCorrelationChange}
          />
        )}

        {activeTab === 'simulation' && (
          <SimulationView
            metrics={riskMetrics}
            lossDistribution={lossDistribution}
            tranches={deal.tranches}
            entities={entities}
            simulationPaths={simulationPaths}
            onRunSimulation={(paths) => {
              setSimulationPaths(paths);
              runFullCalculation(paths, systemCorrelation);
            }}
            isCalculating={isCalculating}
            lastCalcTimeMs={lastCalcTimeMs}
          />
        )}

        {activeTab === 'waterfall' && (
          <WaterfallView deal={deal} tranches={deal.tranches} />
        )}

        {activeTab === 'pricing' && (
          <PricingAndGreeksView
            deal={deal}
            tranches={deal.tranches}
            onRecalculate={() => runFullCalculation(simulationPaths, systemCorrelation)}
          />
        )}

        {activeTab === 'stress' && (
          <StressTestingView deal={deal} tranches={deal.tranches} />
        )}

        {activeTab === 'cdo2_xva' && (
          <CdoSquaredAndXvaView />
        )}

        {activeTab === 'governance' && (
          <ModelGovernanceAndDocsView
            deal={deal}
            onOpenTermSheet={() => setIsTermSheetModalOpen(true)}
          />
        )}
      </main>

      {/* 全局模态框 */}
      <DataLineageModal
        isOpen={!!activeLineageChain}
        onClose={() => setActiveLineageChain(null)}
        chainData={activeLineageChain}
      />

      <CreditEventModal
        isOpen={isCreditEventModalOpen}
        onClose={() => setIsCreditEventModalOpen(false)}
        entities={entities}
        onSimulateCreditEvent={handleSimulateCreditEvent}
      />

      <AuditLogModal
        isOpen={isAuditLogModalOpen}
        onClose={() => setIsAuditLogModalOpen(false)}
        logs={auditLogs}
      />

      <TermSheetModal
        isOpen={isTermSheetModalOpen}
        onClose={() => setIsTermSheetModalOpen(false)}
        deal={deal}
      />
    </div>
  );
}
