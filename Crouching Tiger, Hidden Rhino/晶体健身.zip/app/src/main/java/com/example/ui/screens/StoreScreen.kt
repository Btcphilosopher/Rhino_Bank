package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Product
import com.example.state.FitnessViewModel
import com.example.ui.theme.ConcreteGrey
import com.example.ui.theme.DeepRed
import com.example.ui.theme.RestrainedJade
import com.example.ui.theme.WarmWhite

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoreScreen(viewModel: FitnessViewModel) {
    val products by viewModel.products.collectAsState()
    val cart by viewModel.cart.collectAsState()

    var activeCategory by remember { mutableStateOf("全部") }
    val categories = listOf("全部", "装备", "补剂", "周边")

    var selectedProductForVariant by remember { mutableStateOf<Product?>(null) }
    var selectedVariant by remember { mutableStateOf("") }

    var showCartView by remember { mutableStateOf(false) }
    var addressInput by remember { mutableStateOf("上海市黄浦区南京东路19号202室") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (!showCartView) {
            // Screen Title & Cart Indicator
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "晶体特许商场",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = DeepRed,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "专业装备与功能性营养 / SPORT STORE",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }

                // Floating Cart Badge button
                IconButton(
                    onClick = { showCartView = true },
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(DeepRed)
                ) {
                    BadgedBox(
                        badge = {
                            if (cart.isNotEmpty()) {
                                Badge(containerColor = Color.White) {
                                    Text(
                                        "${cart.sumOf { it.quantity }}",
                                        color = DeepRed,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                        }
                    ) {
                        Icon(Icons.Default.ShoppingCart, contentDescription = "Cart", tint = WarmWhite)
                    }
                }
            }

            // Categories Filter Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { cat ->
                    Box(
                        modifier = Modifier
                            .weight(1.1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (activeCategory == cat) DeepRed else MaterialTheme.colorScheme.surfaceVariant)
                            .clickable { activeCategory = cat }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = cat,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (activeCategory == cat) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Products Grid / List
            val filteredProducts = products.filter { activeCategory == "全部" || it.category == activeCategory }

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredProducts) { prod ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                    ) {
                        Row(modifier = Modifier.padding(12.dp)) {
                            // Symbolic product avatar placeholder
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(DeepRed.copy(alpha = 0.08f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    if (prod.category == "装备") Icons.Default.Handyman else Icons.Default.LocalMall,
                                    contentDescription = "Prod",
                                    tint = DeepRed,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(prod.name, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                Text(prod.description, fontSize = 11.sp, color = ConcreteGrey, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("¥ ${prod.price}", fontSize = 14.sp, fontWeight = FontWeight.Black, color = DeepRed)
                                    Button(
                                        onClick = {
                                            selectedProductForVariant = prod
                                            selectedVariant = prod.variants.firstOrNull() ?: ""
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = DeepRed),
                                        shape = RoundedCornerShape(4.dp),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        modifier = Modifier.height(28.dp).testTag("btn_buy_${prod.id}")
                                    ) {
                                        Text("加购物车", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Cart and checkout sheet view
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { showCartView = false }) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
                Text("我的结算车 / CART DETAILS", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Box(modifier = Modifier.size(40.dp))
            }

            if (cart.isEmpty()) {
                Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("购物车空空如也。先去商场物色专业装备吧！", color = ConcreteGrey, fontSize = 12.sp)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1.2f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(cart) { item ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.product.name, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    Text("规格/尺码: ${item.selectedVariant}", fontSize = 11.sp, color = ConcreteGrey)
                                    Text("单价: ¥${item.product.price}", fontSize = 11.sp, color = DeepRed, fontWeight = FontWeight.Bold)
                                }
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    IconButton(
                                        onClick = { viewModel.removeFromCart(item.product.id, item.selectedVariant) },
                                        modifier = Modifier.size(28.dp).testTag("btn_remove_cart_${item.product.id}")
                                    ) {
                                        Icon(Icons.Default.Remove, contentDescription = "Sub", modifier = Modifier.size(16.dp))
                                    }
                                    Text("${item.quantity}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    IconButton(
                                        onClick = { viewModel.addToCart(item.product, item.selectedVariant) },
                                        modifier = Modifier.size(28.dp).testTag("btn_add_cart_${item.product.id}")
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = "Add", modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }

                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))

                // Address checkout section
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("配送信息 (同城特快配):", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        OutlinedTextField(
                            value = addressInput,
                            onValueChange = { addressInput = it },
                            placeholder = { Text("请输入收货地址...") },
                            modifier = Modifier.fillMaxWidth().testTag("checkout_address_field"),
                            singleLine = true
                        )

                        val totalAmount = cart.sumOf { it.product.price * it.quantity }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("应付总额:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("¥ $totalAmount", fontSize = 16.sp, fontWeight = FontWeight.Black, color = DeepRed)
                        }

                        Button(
                            onClick = {
                                if (addressInput.isNotBlank()) {
                                    viewModel.checkoutCart(addressInput)
                                    showCartView = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = RestrainedJade),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.fillMaxWidth().height(40.dp).testTag("btn_purchase_cart")
                        ) {
                            Icon(Icons.Default.Payment, contentDescription = "Pay", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("模拟安全支付", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // Specifications / Variant popup
    if (selectedProductForVariant != null) {
        val prod = selectedProductForVariant!!
        AlertDialog(
            onDismissRequest = { selectedProductForVariant = null },
            title = { Text("请选择商品规格", fontSize = 15.sp, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(prod.name, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text("单价: ¥${prod.price}", fontSize = 12.sp, color = DeepRed, fontWeight = FontWeight.Bold)

                    Text("可用规格 / 选项:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ConcreteGrey)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        prod.variants.forEach { variant ->
                            val isSelected = selectedVariant == variant
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSelected) DeepRed else MaterialTheme.colorScheme.surfaceVariant)
                                    .clickable { selectedVariant = variant }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = variant,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.addToCart(prod, selectedVariant)
                        selectedProductForVariant = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DeepRed),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.testTag("btn_confirm_variant")
                ) {
                    Text("确定加入")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedProductForVariant = null }) {
                    Text("取消")
                }
            }
        )
    }
}
