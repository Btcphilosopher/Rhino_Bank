package com.example.state

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlin.random.Random

class FitnessViewModel : ViewModel() {

    // Virtual Clock (starting in Sept 2026 as per brand requirement)
    private val _currentTime = MutableStateFlow(LocalDateTime.of(2026, 9, 19, 10, 0))
    val currentTime: StateFlow<LocalDateTime> = _currentTime.asStateFlow()

    // Core Repositories
    private val _currentUser = MutableStateFlow(MockData.demoUser)
    val currentUser: StateFlow<Member> = _currentUser.asStateFlow()

    private val _membership = MutableStateFlow(
        Membership(
            type = "晶体极速月卡 (Jingtian Monthly Pass)",
            status = "ACTIVE",
            startDate = "2026-09-19",
            renewalDate = "2026-10-19",
            remainingVisits = 18,
            classCredits = 8,
            guestPasses = 2,
            freezeStatus = "NORMAL",
            upgradeOptions = listOf("天际至尊年卡", "社群私教包"),
            price = 399.0
        )
    )
    val membership: StateFlow<Membership> = _membership.asStateFlow()

    private val _gyms = MutableStateFlow(MockData.gyms)
    val gyms: StateFlow<List<Gym>> = _gyms.asStateFlow()

    private val _coaches = MutableStateFlow(MockData.coaches)
    val coaches: StateFlow<List<Coach>> = _coaches.asStateFlow()

    private val _exercises = MutableStateFlow(MockData.exercises)
    val exercises: StateFlow<List<Exercise>> = _exercises.asStateFlow()

    private val _classes = MutableStateFlow(MockData.classes)
    val classes: StateFlow<List<GymClass>> = _classes.asStateFlow()

    private val _equipments = MutableStateFlow(MockData.equipments)
    val equipments: StateFlow<List<Equipment>> = _equipments.asStateFlow()

    private val _workoutTemplates = MutableStateFlow(MockData.workoutTemplates)
    val workoutTemplates: StateFlow<List<Workout>> = _workoutTemplates.asStateFlow()

    private val _workoutRecords = MutableStateFlow(MockData.workoutRecords)
    val workoutRecords: StateFlow<List<WorkoutRecord>> = _workoutRecords.asStateFlow()

    private val _communityPosts = MutableStateFlow(MockData.communityPosts)
    val communityPosts: StateFlow<List<CommunityPost>> = _communityPosts.asStateFlow()

    private val _products = MutableStateFlow(MockData.products)
    val products: StateFlow<List<Product>> = _products.asStateFlow()

    private val _facilityRequests = MutableStateFlow(MockData.facilityRequests)
    val facilityRequests: StateFlow<List<FacilityRequest>> = _facilityRequests.asStateFlow()

    private val _challenges = MutableStateFlow(MockData.challenges)
    val challenges: StateFlow<List<Challenge>> = _challenges.asStateFlow()

    private val _notifications = MutableStateFlow(MockData.notifications)
    val notifications: StateFlow<List<AppNotification>> = _notifications.asStateFlow()

    private val _events = MutableStateFlow(MockData.events)
    val events: StateFlow<List<LiveEvent>> = _events.asStateFlow()

    private val _bodyAssessments = MutableStateFlow(MockData.bodyAssessments)
    val bodyAssessments: StateFlow<List<FitnessAssessment>> = _bodyAssessments.asStateFlow()

    private val _recoveryLogs = MutableStateFlow(
        listOf(
            RecoveryLog("rec_log_1", "2026-09-19", 8, 7.5, 3, 2, 8, 4, "继续维持中高强度力量训练，建议在复合起重量前充分热身并进行膝关节活动度释放。"),
            RecoveryLog("rec_log_2", "2026-09-18", 6, 6.0, 5, 4, 6, 7, "中枢神经疲劳风险处于边缘区，建议今晚缩短力量组数，多安排15分钟泡沫轴放松。")
        )
    )
    val recoveryLogs: StateFlow<List<RecoveryLog>> = _recoveryLogs.asStateFlow()

    private val _nutritionLogs = MutableStateFlow(
        listOf(
            NutritionLog(
                id = "nut_log_1",
                date = "2026-09-19",
                foodItems = listOf(
                    FoodItem("糙米饭", 160, 3.5, 35.0, 1.0, "150g"),
                    FoodItem("香煎鸡胸肉", 240, 32.0, 0.0, 6.0, "200g"),
                    FoodItem("白灼西兰花", 45, 3.0, 8.0, 0.5, "150g"),
                    FoodItem("水煮鸡蛋", 150, 13.0, 1.0, 10.0, "2只")
                ),
                totalCalories = 595,
                totalProtein = 51.5,
                totalCarbs = 44.0,
                totalFats = 17.5,
                hydrationMl = 1800
            )
        )
    )
    val nutritionLogs: StateFlow<List<NutritionLog>> = _nutritionLogs.asStateFlow()

    // Interactive user state
    private val _cart = MutableStateFlow<List<CartItem>>(emptyList())
    val cart: StateFlow<List<CartItem>> = _cart.asStateFlow()

    private val _activeWorkout = MutableStateFlow<Workout?>(MockData.initialActiveWorkout)
    val activeWorkout: StateFlow<Workout?> = _activeWorkout.asStateFlow()

    private val _simulationLog = MutableStateFlow<List<String>>(
        listOf("晶体数智健身系统初始化完毕。", "初始 demonstration 数据成功加载。")
    )
    val simulationLog: StateFlow<List<String>> = _simulationLog.asStateFlow()

    private val _aiMessages = MutableStateFlow<List<Pair<String, String>>>(
        listOf(
            "assistant" to "您好，我是您的 晶体AI智能健身助手 🤖。我可以为您解惑器械、设计训练课、分析您的体测结果及提供恢复建议。\n\n**晶体智能分析依据：** 基于您今日提交的 16.2% 体脂率报告、历史 100 场训练记录、以及轻微左膝膝盖不适的反馈。\n\n您今日的推荐课程是【下肢力量训练】，有什么想问我的吗？"
        )
    )
    val aiMessages: StateFlow<List<Pair<String, String>>> = _aiMessages.asStateFlow()

    private val _activeTab = MutableStateFlow("Home")
    val activeTab: StateFlow<String> = _activeTab.asStateFlow()

    // ----------------------------------------
    // NAVIGATION
    // ----------------------------------------
    fun setActiveTab(tab: String) {
        _activeTab.value = tab
    }

    // ----------------------------------------
    // MEMBERSHIP OPERATIONS
    // ----------------------------------------
    fun renewMembership() {
        _membership.update { current ->
            val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
            val newRenewalDate = _currentTime.value.plusMonths(1).format(formatter)
            addLog("用户主动发起会员续费，扣款 ¥${current.price} 成功(模拟)。有效期延长至 $newRenewalDate")
            addNotification("会员自动续期成功", "感谢您的续费支持！您的【${current.type}】有效期成功延长至 $newRenewalDate。")
            current.copy(
                status = "ACTIVE",
                renewalDate = newRenewalDate,
                remainingVisits = current.remainingVisits + 12,
                classCredits = current.classCredits + 8
            )
        }
    }

    // ----------------------------------------
    // GYM ACCESS SIMULATION
    // ----------------------------------------
    fun enterGymSimulate(gymName: String) {
        if (_membership.value.remainingVisits <= 0) {
            addNotification("入场受限", "您的会员卡剩余次数不足，请先进行续费。")
            addLog("入场失败：会员卡剩余次数为 0。")
            return
        }

        _membership.update { it.copy(remainingVisits = it.remainingVisits - 1) }
        _gyms.update { list ->
            list.map { g ->
                if (g.name == gymName) {
                    addLog("会员 ${MockData.demoUser.name} NFC 刷卡成功，进入场馆: $gymName")
                    g.copy(
                        currentOccupancy = g.currentOccupancy + 1,
                        crowdingEstimate = ((g.currentOccupancy + 1).toDouble() / (g.equipmentCount + 10) * 100).toInt().coerceIn(0, 100)
                    )
                } else g
            }
        }
        val timestamp = _currentTime.value.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"))
        addNotification("模拟 NFC 入场成功", "欢迎进入【$gymName】！祝您今日训练愉快！当前时间：$timestamp")

        // Auto locker allocation
        val randomLocker = "0" + (10 + Random.nextInt(89)) + "号更衣柜"
        val newRequest = FacilityRequest(
            id = "req_" + (Random.nextInt(1000) + 1000),
            requestType = "智能更衣柜分配",
            lockerNumber = randomLocker,
            status = "COMPLETED",
            timestamp = timestamp,
            estCompletion = "已完成",
            staffResponse = "密码锁已激活，您的密码为:【${100000 + Random.nextInt(899999)}】"
        )
        _facilityRequests.update { listOf(newRequest) + it }
    }

    // ----------------------------------------
    // CLASS BOOKING
    // ----------------------------------------
    fun bookClass(classId: String) {
        var bookedClassName = ""
        var success = false

        _classes.update { list ->
            list.map { c ->
                if (c.id == classId) {
                    if (c.remainingSpaces > 0 && !c.isBooked) {
                        bookedClassName = c.name
                        success = true
                        c.copy(remainingSpaces = c.remainingSpaces - 1, isBooked = true)
                    } else if (c.isBooked) {
                        // Already booked
                        c
                    } else if (c.remainingSpaces == 0) {
                        // Waitlist
                        bookedClassName = c.name
                        success = true
                        c.copy(waitlistCount = c.waitlistCount + 1, isWaitlisted = true)
                    } else c
                } else c
            }
        }

        if (success) {
            val isWaitlist = _classes.value.firstOrNull { it.id == classId }?.isWaitlisted == true
            val title = if (isWaitlist) "排队候补成功" else "操课预约成功"
            val content = if (isWaitlist) {
                "您预约的【$bookedClassName】当前席位已满，已自动为您加入第 ${_classes.value.firstOrNull { it.id == classId }?.waitlistCount} 位候补队列。"
            } else {
                "您已成功预约《$bookedClassName》，请在开课前10分钟到指定区凭会员码签到。"
            }

            addNotification(title, content)
            addLog("预约课程: $bookedClassName - " + (if (isWaitlist) "候补中" else "确认成功"))
        }
    }

    fun cancelClass(classId: String) {
        var cancelledClassName = ""
        var isWaitlisted = false

        _classes.update { list ->
            list.map { c ->
                if (c.id == classId) {
                    cancelledClassName = c.name
                    isWaitlisted = c.isWaitlisted
                    if (c.isWaitlisted) {
                        c.copy(waitlistCount = (c.waitlistCount - 1).coerceAtLeast(0), isWaitlisted = false)
                    } else if (c.isBooked) {
                        c.copy(remainingSpaces = c.remainingSpaces + 1, isBooked = false)
                    } else c
                } else c
            }
        }

        addNotification("取消操课成功", "您已取消《$cancelledClassName》的预约。系统已自动流转空余名额。")
        addLog("取消预约课程: $cancelledClassName")
    }

    // ----------------------------------------
    // PERSONAL TRAINER BOOKING
    // ----------------------------------------
    fun bookTrainer(coachId: String, timeSlot: String) {
        val coach = _coaches.value.firstOrNull { it.id == coachId } ?: return
        addNotification("私教课程预约成功", "您已预约 ${coach.name} 在 [$timeSlot] 的私教评估专项。请准时抵达私教专属接待区。")
        addLog("预约教练: ${coach.name} / 时段: $timeSlot / 价格: ¥${coach.sessionPrice}")
    }

    // ----------------------------------------
    // OPERATIONS TICKET FEEDBACK LOOP
    // ----------------------------------------
    fun resolveFacilityRequest(reqId: String, eqName: String?) {
        _facilityRequests.update { list ->
            list.map { req ->
                if (req.id == reqId) {
                    addLog("工单已结案：已闭环修复 $reqId (${req.requestType})")
                    req.copy(status = "COMPLETED", staffResponse = "工单已由系统值班经理手动通过数字孪生闭环，故障点已全面修复并复位就绪。")
                } else req
            }
        }
        if (eqName != null) {
            _equipments.update { list ->
                list.map { eq ->
                    if (eq.name == eqName) {
                        eq.copy(status = "OPERATIONAL")
                    } else eq
                }
            }
        }
    }

    // ----------------------------------------
    // WORKOUT EDITOR / BUILDER
    // ----------------------------------------
    fun createWorkoutPlan(name: String, objective: String, selectedExercises: List<Exercise>) {
        val exercisesList = selectedExercises.map { ex ->
            WorkoutExercise(
                exerciseId = ex.id,
                nameZh = ex.nameZh,
                nameEn = ex.nameEn,
                category = ex.category,
                sets = (1..3).map { s -> WorkoutSet(s, weightKg = if (ex.category == "力量训练") 40.0 else 0.0, reps = 10, isCompleted = false) }
            )
        }
        val newWorkout = Workout(
            id = "w_custom_" + (Random.nextInt(9000) + 1000),
            name = name,
            objective = objective,
            durationMinutes = selectedExercises.size * 12,
            exercises = exercisesList,
            isTemplate = true
        )
        _workoutTemplates.update { list -> list + newWorkout }
        addLog("新建训练计划《$name》成功。动作数量：${selectedExercises.size}")
        addNotification("计划保存成功", "您的专属健身计划《$name》已保存至“我的计划模板”中。")
    }

    fun deleteWorkoutTemplate(id: String) {
        _workoutTemplates.update { list -> list.filter { it.id != id } }
        addLog("删除了训练计划模板: $id")
    }

    // ----------------------------------------
    // ACTIVE WORKOUT INTERACTION
    // ----------------------------------------
    fun startWorkout(workout: Workout) {
        _activeWorkout.value = workout
        _activeTab.value = "Training" // Jump to training tab
        addLog("启动了训练课：《${workout.name}》。专注于每一个收缩离心！")
        addNotification("训练课开启", "《${workout.name}》已载入。大字、高对比度安全运动模式已激活。")
    }

    fun updateSetRepAndWeight(exerciseId: String, setIndex: Int, weight: Double, reps: Int) {
        _activeWorkout.update { current ->
            current?.let { workout ->
                val updatedExercises = workout.exercises.map { we ->
                    if (we.exerciseId == exerciseId) {
                        val updatedSets = we.sets.map { s ->
                            if (s.setIndex == setIndex) {
                                s.copy(weightKg = weight, reps = reps)
                            } else s
                        }
                        we.copy(sets = updatedSets)
                    } else we
                }
                workout.copy(exercises = updatedExercises)
            }
        }
    }

    fun completeActiveSet(exerciseId: String, setIndex: Int) {
        _activeWorkout.update { current ->
            current?.let { workout ->
                val updatedExercises = workout.exercises.map { we ->
                    if (we.exerciseId == exerciseId) {
                        val updatedSets = we.sets.map { s ->
                            if (s.setIndex == setIndex) {
                                s.copy(isCompleted = !s.isCompleted)
                            } else s
                        }
                        we.copy(sets = updatedSets)
                    } else we
                }
                workout.copy(exercises = updatedExercises)
            }
        }
        addLog("标记了动作组完成状态变更: $exerciseId - 第 $setIndex 组")
    }

    fun completeWorkout() {
        val active = _activeWorkout.value ?: return

        // Compute values
        val recExercises = active.exercises.map { we ->
            WorkoutRecordExercise(
                exerciseId = we.exerciseId,
                nameZh = we.nameZh,
                nameEn = we.nameEn,
                category = we.category,
                sets = we.sets.map { s -> WorkoutRecordSet(s.setIndex, s.weightKg, s.reps, s.isCompleted) }
            )
        }

        val completedSetsCount = recExercises.flatMap { it.sets }.count { it.isCompleted }
        if (completedSetsCount == 0) {
            _activeWorkout.value = null
            addLog("中止了训练课: ${active.name}")
            return
        }

        val totalReps = recExercises.sumOf { e -> e.sets.filter { it.isCompleted }.sumOf { s -> s.reps } }
        val totalVolume = recExercises.sumOf { e -> e.sets.filter { it.isCompleted }.sumOf { s -> s.weightKg * s.reps } }
        val calories = active.durationMinutes * 6 + (Random.nextInt(5) * 15)

        val newRecord = WorkoutRecord(
            id = "rec_new_" + (Random.nextInt(9000) + 1000),
            workoutName = active.name.replace("林哲·今日推荐：", "").replace("模板 - ", ""),
            durationMinutes = active.durationMinutes,
            exercises = recExercises,
            totalVolumeKg = totalVolume,
            totalReps = totalReps,
            caloriesBurned = calories,
            date = _currentTime.value.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")),
            notes = "林哲通过数智生态独立自主完成训练。总体积达 ${totalVolume}kg，心率心肺匹配良好。"
        )

        // Append to records
        _workoutRecords.update { listOf(newRecord) + it }

        // Update challenge progress
        _challenges.update { list ->
            list.map { ch ->
                if (ch.id == "ch_1" && ch.isJoined) { // 30-day consistency
                    val newProgress = (ch.currentValue + 1).coerceAtMost(ch.targetValue)
                    ch.copy(currentValue = newProgress, progressPercentage = (newProgress / ch.targetValue * 100).toInt())
                } else if (ch.id == "ch_3" && ch.isJoined) { // strength squat
                    val squatsSetsCompleted = recExercises.filter { it.exerciseId == "ex_squat" }.flatMap { it.sets }.count { it.isCompleted }
                    val newProgress = (ch.currentValue + squatsSetsCompleted).coerceAtMost(ch.targetValue)
                    ch.copy(currentValue = newProgress, progressPercentage = (newProgress / ch.targetValue * 100).toInt())
                } else ch
            }
        }

        _activeWorkout.value = null
        addLog("训练圆满结束！累积生成 1 份数据报告：总体积 ${totalVolume}kg，消耗 ${calories}kcal")
        addNotification("今日训练圆满完成", "恭喜！您成功完成了《${newRecord.workoutName}》。数据报告已加密存储，可在“体测及分析数据”中核验。")
    }

    // ----------------------------------------
    // COMMERCE SHOPPING
    // ----------------------------------------
    fun addToCart(product: Product, variant: String) {
        _cart.update { current ->
            val existing = current.firstOrNull { it.product.id == product.id && it.selectedVariant == variant }
            if (existing != null) {
                current.map { if (it.product.id == product.id && it.selectedVariant == variant) it.copy(quantity = it.quantity + 1) else it }
            } else {
                current + CartItem(product, 1, variant)
            }
        }
        addLog("商品加入购物车: ${product.name} (规格: $variant)")
    }

    fun removeFromCart(productId: String, variant: String) {
        _cart.update { current -> current.filter { !(it.product.id == productId && it.selectedVariant == variant) } }
        addLog("从购物车移除商品: $productId")
    }

    fun checkoutCart(address: String) {
        val currentCart = _cart.value
        if (currentCart.isEmpty()) return

        val total = currentCart.sumOf { it.product.price * it.quantity }
        val orderId = "ORD2026" + (Random.nextInt(90000) + 10000)

        addLog("发起商场结算(模拟)：订单 $orderId，总金额 ¥$total，配送地址: $address")
        addNotification("晶体商城支付成功", "订单【$orderId】支付 ¥$total 成功。由于这是概念模拟，我们已为您分配同城特快单(模拟)，预计今晚送达。")

        _cart.value = emptyList()
    }

    // ----------------------------------------
    // CHALLENGE JOINING
    // ----------------------------------------
    fun joinChallenge(id: String) {
        _challenges.update { list ->
            list.map { ch ->
                if (ch.id == id) {
                    addLog("用户加入健身体验挑战: ${ch.title}")
                    ch.copy(isJoined = true)
                } else ch
            }
        }
    }

    // ----------------------------------------
    // REGISTER LOCAL EVENT
    // ----------------------------------------
    fun toggleEventRegistration(eventId: String) {
        _events.update { list ->
            list.map { ev ->
                if (ev.id == eventId) {
                    if (ev.registrationStatus == "REGISTERED") {
                        addLog("取消注册活动: ${ev.name}")
                        ev.copy(registrationStatus = "NOT_REGISTERED", attendeesCount = ev.attendeesCount - 1)
                    } else {
                        addLog("成功注册社区健身体能活动: ${ev.name}")
                        ev.copy(registrationStatus = "REGISTERED", attendeesCount = ev.attendeesCount + 1)
                    }
                } else ev
            }
        }
    }

    // ----------------------------------------
    // EQUIPMENT DIGITAL TWIN & SIMULATOR
    // ----------------------------------------
    fun connectEquipment(id: String) {
        _equipments.update { list ->
            list.map { eq ->
                if (eq.id == id) {
                    addLog("智能设备连接握手成功: ${eq.name} [IP/BLE 广播已解析]")
                    eq.copy(status = "IN_USE")
                } else eq
            }
        }
    }

    fun disconnectEquipment(id: String) {
        _equipments.update { list ->
            list.map { eq ->
                if (eq.id == id) {
                    addLog("主动断开智能设备联接: ${eq.name}")
                    eq.copy(status = "OPERATIONAL")
                } else eq
            }
        }
    }

    fun triggerEquipmentFault(id: String) {
        var eqName = ""
        _equipments.update { list ->
            list.map { eq ->
                if (eq.id == id) {
                    eqName = eq.name
                    addLog("⚠️ 警报：检测到故障！故障源 ${eq.name}，自动上报智慧运保控制后台")
                    eq.copy(
                        status = "MAINTENANCE",
                        faultHistory = eq.faultHistory + ("${_currentTime.value.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"))}: 动力传动阻力轴抱死故障警报")
                    )
                } else eq
            }
        }

        // Generate automatic facility request ticket
        val ticketId = "req_auto_" + (Random.nextInt(9000) + 1000)
        val newTicket = FacilityRequest(
            id = ticketId,
            requestType = "设备故障保修 - $eqName",
            lockerNumber = "设备区",
            status = "SUBMITTED",
            timestamp = _currentTime.value.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")),
            estCompletion = "1小时内",
            staffResponse = "已收到设备故障遥测数据。已自动指派设备保障专员携专用传感轴承前往现场维修。"
        )
        _facilityRequests.update { listOf(newTicket) + it }
        addNotification("自动保障工单生成", "由于智能设备【$eqName】产生遥测异常，智慧保障系统已自动生成工单 $ticketId 派工。")
    }

    fun updateEquipmentTwin(id: String, newStatus: String) {
        _equipments.update { list ->
            list.map { eq ->
                if (eq.id == id) {
                    addLog("运营调试：修改设备 ${eq.name} 状态为 $newStatus")
                    eq.copy(status = newStatus)
                } else eq
            }
        }
    }

    // ----------------------------------------
    // NUTRITION RECORDING
    // ----------------------------------------
    fun addHydration(amountMl: Int) {
        _nutritionLogs.update { list ->
            list.map { log ->
                if (log.date == "2026-09-19") {
                    log.copy(hydrationMl = log.hydrationMl + amountMl)
                } else log
            }
        }
        addLog("记录了水分摄入: +${amountMl}ml")
    }

    fun logCustomMeal(name: String, calories: Int, protein: Double, carbs: Double, fats: Double) {
        _nutritionLogs.update { list ->
            list.map { log ->
                if (log.date == "2026-09-19") {
                    val newFood = FoodItem(name, calories, protein, carbs, fats, "1份")
                    val newItems = log.foodItems + newFood
                    log.copy(
                        foodItems = newItems,
                        totalCalories = log.totalCalories + calories,
                        totalProtein = log.totalProtein + protein,
                        totalCarbs = log.totalCarbs + carbs,
                        totalFats = log.totalFats + fats
                    )
                } else log
            }
        }
        addLog("记录了餐食饮食: $name - $calories kcal")
    }

    // ----------------------------------------
    // RECOVERY LOGGING
    // ----------------------------------------
    fun submitRecoveryJournal(energy: Int, sleep: Double, soreness: Int, stress: Int, motivation: Int) {
        val perceivedExertion = (soreness + stress) / 2
        val suggestion = when {
            energy < 4 || soreness > 7 -> "中枢神经呈显著负荷。今日强烈建议：选择“静态拉伸恢复”或“膈肌深呼吸冥想”，避免任何中大重量推拉深蹲！给肌肉关节充足的重建重建时间。"
            soreness > 4 -> "肌肉有轻微微损伤和酸胀。今日推荐：选择中等强度的功能有氧训练（如智能划船机）或安排低强度臀腿恢复性拉伸活动。"
            else -> "身体状态充沛，肌肉反应积极！今日推荐：执行【晶体下肢力量突破计划】或大重量胸背拉推动作，把握黄金超量恢复期。"
        }
        val dateStr = _currentTime.value.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))
        val log = RecoveryLog("rec_log_new", dateStr, energy, sleep, soreness, stress, motivation, perceivedExertion, suggestion)

        _recoveryLogs.update { listOf(log) + it.filter { item -> item.date != dateStr } }
        addLog("用户提交了自我恢复及疲劳度评测：精力指数 $energy，酸痛度 $soreness")
        addNotification("疲劳状态智能评估生成", "恢复评估已生成：“${suggestion.take(30)}...” 请根据建议谨慎控制今日运动输出强度。")
    }

    // ----------------------------------------
    // GENERAL UTILITIES
    // ----------------------------------------
    private fun addLog(message: String) {
        val timeStr = _currentTime.value.format(DateTimeFormatter.ofPattern("HH:mm:ss"))
        _simulationLog.update { listOf("[$timeStr] $message") + it.take(40) }
    }

    private fun addNotification(title: String, content: String) {
        val timeStr = _currentTime.value.format(DateTimeFormatter.ofPattern("HH:mm"))
        val notif = AppNotification("not_dyn_" + Random.nextInt(10000), title, content, timeStr)
        _notifications.update { listOf(notif) + it }
    }

    // ----------------------------------------
    // AI ASSISTANT SIMULATED DIALOG
    // ----------------------------------------
    fun sendAiAssistantMessage(userText: String) {
        if (userText.isBlank()) return
        _aiMessages.update { it + ("user" to userText) }

        viewModelScope.launch {
            val response = when {
                userText.contains("膝盖") || userText.contains("疼") || userText.contains("不适") -> {
                    "**【晶体AI膝关节运动保护指导】**\n\n您反馈过有轻微左膝膝盖不适。基于这个身体限制，本系统的保护规则如下：\n\n*   **依据：** 2026-09-19 体测中心 - 运动对称性限制条件。\n*   **假设：** 您的膝关节在过度屈膝（如低于平面的深蹲）或瞬间震动（如硬地跑步）时存在髌骨磨损和张力过高风险。\n*   **用户可调整：** 您可以随时在“我的-Onboarding配置”中调整膝关节受限状态。\n\n**训练指导意见：**\n1. 避免最大负重1RM测试。进行深蹲时下蹲深度控制在脚大腿与水平面平行处即可。\n2. 力量训练前，使用泡沫轴将股四头肌、髂胫束滚压放松，打碎粘连以平衡髌骨张力。\n3. 如果想做有氧，建议将**智能跑步机**更换为**智能划船机**（零负荷冲击），能最大程度避免膝部剪切力。"
                }
                userText.contains("计划") || userText.contains("下肢") || userText.contains("训练") -> {
                    "**【林哲专属下肢力量计划智能解析】**\n\n*   **依据：** 基于您选择的 `Build Strength` 目标以及 `基础训练者` 的体能层级。\n*   **假设：** 您一周可训练3天，每次希望在50-60分钟内获取高机械张力刺激。\n*   **用户可调整：** 您今日的推荐课程包含了 4组杠铃深蹲 (最高100kg)。如果您今天感到劳累，可以一键调整深蹲起始负荷至60kg，或一键替换为倒蹬机 (对腰椎无轴向压力)。\n\n**推荐动作：** 杠铃深蹲 4组 + 箭步蹲 3组 + 壶铃摇摆 2组。这能充分兼顾股四头肌和股后链，并极大拉高运动后超量卡路里氧耗。"
                }
                userText.contains("体测") || userText.contains("体脂") || userText.contains("骨骼肌") -> {
                    "**【林哲 3D 深度体测简报析】**\n\n*   **依据：** 2026-09-19 DEXA 高精测定。\n*   **假设：** 基础代谢为 1720 kcal/day，理想骨骼肌平衡值为35.5kg - 37.0kg。\n*   **用户可调整：** 当前测得体脂率 16.2%，处于健康干练范围。若目标是极限脱脂，可在“营养日记”中将碳水比例从45%调至35%，并配合高频有氧。\n\n**数智优化方向：** 您的左侧腿部肌肉比右侧微少 0.2kg。建议在下肢训练中强化“哑铃箭步蹲”等单侧力量，并在起立阶段主导左腿发力，重构神经支配对称性。"
                }
                else -> {
                    "**【晶体智能健身问答】**\n\n*   **依据：** 晶体运动物理学与现代科学运动指导大纲。\n*   **假设：** 您目前处于力量训练间歇或寻求科学健身常识解答。\n*   **用户可调整：** 您可以使用顶部的模拟控制器快速“推进虚拟时间”，查看计划执行24小时后的卡路里和恢复值变化。\n\n有什么我可以进一步协助您的？无论是想纠正“杠铃硬拉”中驼背的错误、还是挑选“健身商城”中的缓震鞋，我都随时为您护航。"
                }
            }
            _aiMessages.update { it + ("assistant" to response) }
        }
    }

    // ----------------------------------------
    // DETERMINISTIC SIMULATION ENGINE (CRITICAL)
    // ----------------------------------------
    fun advanceOneHour() {
        val nextTime = _currentTime.value.plusHours(1)
        _currentTime.value = nextTime
        addLog("⚙️ 推进模拟时钟至 ${nextTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"))}")

        // 1. Simulates gym occupancy fluctuation based on hourly peaks
        val hour = nextTime.hour
        _gyms.update { list ->
            list.map { g ->
                val peakIndex = (hour - 8).coerceIn(0, g.peakHours.size - 1)
                val basePeak = if (hour in 8..22) g.peakHours[peakIndex] else 5
                val randomOffset = Random.nextInt(-5, 6)
                val targetOccupancy = (((basePeak + randomOffset).toDouble() / 100) * (g.equipmentCount + 20)).toInt().coerceIn(2, g.equipmentCount + 15)
                g.copy(
                    currentOccupancy = targetOccupancy,
                    crowdingEstimate = (targetOccupancy.toDouble() / (g.equipmentCount + 10) * 100).toInt().coerceIn(0, 100)
                )
            }
        }

        // 2. Simulates active equipment sessions & telemetry updates on random operational units
        _equipments.update { list ->
            list.map { eq ->
                if (eq.status == "IN_USE") {
                    // Update telemetry metrics randomly
                    val activeHours = eq.usageHours + 1
                    val newHeartRate = 110 + Random.nextInt(50)
                    val newReps = if (eq.type == "TREADMILL") 0 else eq.reps + Random.nextInt(5, 12)
                    eq.copy(
                        usageHours = activeHours,
                        heartRatePlaceholder = newHeartRate,
                        reps = newReps,
                        power = if (eq.type == "BIKE" || eq.type == "ROWER") 150.0 + Random.nextInt(150) else eq.power,
                        speed = if (eq.type == "TREADMILL") 8.0 + Random.nextDouble() * 5.0 else eq.speed
                    )
                } else if (eq.status == "OPERATIONAL" && Random.nextDouble() < 0.25) {
                    // Randomly lease operational units to virtual members
                    eq.copy(status = "IN_USE", heartRatePlaceholder = 120 + Random.nextInt(40))
                } else if (eq.status == "IN_USE" && Random.nextDouble() < 0.3) {
                    // Release back to operational
                    eq.copy(status = "OPERATIONAL", heartRatePlaceholder = 0, power = 0.0, speed = 0.0, reps = 0)
                } else eq
            }
        }

        // 3. Random event: Equipment fault simulation (very minor 3% chance per hour)
        if (Random.nextDouble() < 0.03) {
            val operationalEq = _equipments.value.filter { it.status == "OPERATIONAL" || it.status == "IN_USE" }
            if (operationalEq.isNotEmpty()) {
                val chosen = operationalEq.random()
                triggerEquipmentFault(chosen.id)
            }
        }

        // 4. Update order delivery statuses (SHIPPED -> DELIVERED)
        addLog("数智生态状态自动同步完毕：设备心率、运动瓦特已重计算并上链。")
    }

    fun advanceOneDay() {
        val nextTime = _currentTime.value.plusDays(1)
        _currentTime.value = nextTime
        addLog("📅 推进模拟时钟：跨越 24 小时至 ${nextTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))}")

        // 1. Refresh user daily rings & streaks
        _currentUser.update { current ->
            addLog("新的一天开启，林哲的每日运动目标、饮水量等数据已自动重置并校准。")
            current
        }

        _recoveryLogs.update { logs ->
            // Simulate daily healing of muscle soreness
            logs.map { l ->
                val nextSoreness = (l.sorenessLevel - 2).coerceAtLeast(1)
                l.copy(
                    date = nextTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")),
                    sorenessLevel = nextSoreness,
                    energyLevel = (l.energyLevel + 1).coerceAtMost(10)
                )
            }
        }

        // 2. Simulate random class cancellations and waitlist promotions
        _classes.update { list ->
            list.map { c ->
                if (c.waitlistCount > 0 && Random.nextBoolean()) {
                    val promoted = c.waitlistCount - 1
                    addNotification("课程候补成功通知", "您的《${c.name}》候补排队成功。系统已自动划扣名额！")
                    c.copy(waitlistCount = promoted, isBooked = true, isWaitlisted = false)
                } else c
            }
        }

        // 3. Automated billing/expiry alert
        val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
        val expiryDate = java.time.LocalDate.parse(_membership.value.renewalDate)
        val currentDate = nextTime.toLocalDate()
        if (currentDate.isAfter(expiryDate) || currentDate.isEqual(expiryDate)) {
            _membership.update { it.copy(status = "EXPIRED", remainingVisits = 0) }
            addNotification("会员卡已过期", "您的 晶体极速月卡 已达到有效期 (${_membership.value.renewalDate})。请及时进行续费续卡。")
            addLog("系统扫描：会员卡已过期。自动限制 NFC 场馆出入权限。")
        }
    }

    fun generateAttendance() {
        _gyms.update { list ->
            list.map { g ->
                val fullOccupancy = (g.equipmentCount + 5).coerceAtLeast(30)
                addLog("模拟控制：对 ${g.name} 注入大客流模拟，场馆负荷拉升")
                g.copy(currentOccupancy = fullOccupancy, crowdingEstimate = 95)
            }
        }
        addNotification("场馆超载仿真触发", "已手动将所有店面的人流系数调至 95% 饱和度。您可以观察到场馆运营后台的红色过载警报。")
    }

    fun simulateClassBooking() {
        var count = 0
        _classes.update { list ->
            list.map { c ->
                if (c.remainingSpaces > 0 && Random.nextDouble() < 0.6) {
                    val bookCount = Random.nextInt(1, c.remainingSpaces + 1)
                    count += bookCount
                    c.copy(remainingSpaces = c.remainingSpaces - bookCount)
                } else c
            }
        }
        addLog("模拟控制：系统注入了数十名虚拟会员的一键预约操课，消耗 $count 席位。")
        addNotification("虚拟会员抢课完毕", "虚拟会员已自动填补了大部分操课。多个高能 HIIT 和瑜伽项目已进入“排队候补”状态。")
    }

    fun resetSimulation() {
        _currentTime.value = LocalDateTime.of(2026, 9, 19, 10, 0)
        _currentUser.value = MockData.demoUser
        _membership.value = Membership(
            type = "晶体极速月卡 (Jingtian Monthly Pass)",
            status = "ACTIVE",
            startDate = "2026-09-19",
            renewalDate = "2026-10-19",
            remainingVisits = 18,
            classCredits = 8,
            guestPasses = 2,
            freezeStatus = "NORMAL",
            upgradeOptions = listOf("天际至尊年卡", "社群私教包"),
            price = 399.0
        )
        _gyms.value = MockData.gyms
        _coaches.value = MockData.coaches
        _exercises.value = MockData.exercises
        _classes.value = MockData.classes
        _equipments.value = MockData.equipments
        _workoutTemplates.value = MockData.workoutTemplates
        _workoutRecords.value = MockData.workoutRecords
        _communityPosts.value = MockData.communityPosts
        _products.value = MockData.products
        _facilityRequests.value = MockData.facilityRequests
        _challenges.value = MockData.challenges
        _notifications.value = MockData.notifications
        _events.value = MockData.events
        _bodyAssessments.value = MockData.bodyAssessments
        _cart.value = emptyList()
        _activeWorkout.value = MockData.initialActiveWorkout
        _aiMessages.value = listOf(
            "assistant" to "您好，我是您的 晶体AI智能健身助手 🤖。我可以为您解惑器械、设计训练课、分析您的体测结果及提供恢复建议。\n\n**晶体智能分析依据：** 基于您今日提交的 16.2% 体脂率报告、历史 100 场训练记录、以及轻微左膝膝盖不适的反馈。\n\n您今日的推荐课程是【下肢力量训练】，有什么想问我的吗？"
        )
        _simulationLog.value = listOf("模拟环境已重置，所有数据包和设备传感器已恢复至原始基准。")
        addNotification("模拟生态已全面重置", "晶体生态内的 5家门店、15台互联设备、100场记录、虚拟用户及购物车已重置为纯净状态。")
    }
}
