package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Exercise
import com.example.data.Workout
import com.example.data.WorkoutExercise
import com.example.data.WorkoutSet
import com.example.state.FitnessViewModel
import com.example.ui.theme.DeepRed
import com.example.ui.theme.RestrainedJade
import com.example.ui.theme.SubtleAmber
import com.example.ui.theme.WarmWhite
import com.example.ui.theme.ConcreteGrey
import com.example.ui.theme.GraphiteDark
import com.example.ui.theme.GraphiteSurface
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrainingScreen(viewModel: FitnessViewModel) {
    val activeWorkout by viewModel.activeWorkout.collectAsState()
    val workoutTemplates by viewModel.workoutTemplates.collectAsState()
    val exercises by viewModel.exercises.collectAsState()

    var activeSubTab by remember { mutableStateOf("Plans") } // "Plans", "Library"
    var showCreator by remember { mutableStateOf(false) }

    if (activeWorkout != null) {
        // Render hard-core Full-Screen Active Workout Mode
        ActiveWorkoutView(
            workout = activeWorkout!!,
            onCompleteSet = { exId, setIndex -> viewModel.completeActiveSet(exId, setIndex) },
            onUpdateSet = { exId, setIndex, w, r -> viewModel.updateSetRepAndWeight(exId, setIndex, w, r) },
            onFinishWorkout = { viewModel.completeWorkout() },
            onCancelWorkout = { viewModel.completeWorkout() } // Just auto-wrap
        )
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Screen Title
            Column {
                Text(
                    text = "晶体硬核训练",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = DeepRed,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "训练计划与运动指南 / PLANS & LIBRARY",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            // Sub tabs
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(4.dp)
            ) {
                TabButton(
                    title = "训练计划模板 (${workoutTemplates.size})",
                    isActive = activeSubTab == "Plans",
                    modifier = Modifier.weight(1f),
                    onClick = { activeSubTab = "Plans" }
                )
                TabButton(
                    title = "动作指南库 (${exercises.size})",
                    isActive = activeSubTab == "Library",
                    modifier = Modifier.weight(1f),
                    onClick = { activeSubTab = "Library" }
                )
            }

            if (activeSubTab == "Plans") {
                // Plans List & Creator Trigger
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("预设或自定义模板:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Button(
                        onClick = { showCreator = true },
                        colors = ButtonDefaults.buttonColors(containerColor = DeepRed),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("btn_open_plan_creator")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add", modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("新建自定义计划", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(workoutTemplates) { template ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = template.name,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    IconButton(
                                        onClick = { viewModel.deleteWorkoutTemplate(template.id) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = ConcreteGrey, modifier = Modifier.size(16.dp))
                                    }
                                }
                                Text(
                                    text = "主攻目标: ${if (template.objective == "Build Strength") "力量突破" else "耐力心肺"} | 预估 ${template.durationMinutes}分钟",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                )

                                Spacer(modifier = Modifier.height(10.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = template.exercises.joinToString(" • ") { it.nameZh }.take(28) + "...",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
                                        modifier = Modifier.weight(1f)
                                    )
                                    Button(
                                        onClick = { viewModel.startWorkout(template) },
                                        colors = ButtonDefaults.buttonColors(containerColor = RestrainedJade),
                                        shape = RoundedCornerShape(4.dp),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        modifier = Modifier.height(28.dp).testTag("btn_start_plan_${template.id}")
                                    ) {
                                        Text("启动训练", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                // Exercise Library
                var searchQuery by remember { mutableStateOf("") }
                var selectedCategory by remember { mutableStateOf("全部") }
                val categories = listOf("全部", "力量训练", "有氧训练", "功能训练", "灵活性与恢复")

                TextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("搜索动作名称, 目标肌群...", fontSize = 12.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", modifier = Modifier.size(16.dp)) },
                    singleLine = true,
                    colors = TextFieldDefaults.colors()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    categories.forEach { cat ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (selectedCategory == cat) DeepRed else MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { selectedCategory = cat }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = cat.replace("与恢复", ""),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (selectedCategory == cat) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                val filteredExercises = exercises.filter {
                    (selectedCategory == "全部" || it.category == selectedCategory) &&
                            (it.nameZh.contains(searchQuery, true) || it.targetMuscles.contains(searchQuery, true))
                }

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredExercises) { ex ->
                        var isExpanded by remember { mutableStateOf(false) }

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.08f))
                        ) {
                            Column(
                                modifier = Modifier
                                    .clickable { isExpanded = !isExpanded }
                                    .padding(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(ex.nameZh, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(ex.nameEn, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f))
                                    }
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(DeepRed.copy(alpha = 0.08f))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(ex.difficulty, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = DeepRed)
                                    }
                                }

                                Spacer(modifier = Modifier.height(4.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("肌肉: ${ex.targetMuscles}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
                                    Text("器械: ${ex.equipment}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
                                }

                                AnimatedVisibility(visible = isExpanded) {
                                    Column(modifier = Modifier.padding(top = 10.dp)) {
                                        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.08f))
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text("动作描述:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DeepRed)
                                        Text(ex.description, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 14.sp)

                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text("⚠️ 安全警示:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SubtleAmber)
                                        Text(ex.safetyNotes, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 14.sp)

                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text("❌ 常见错误:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DeepRed)
                                        Text(ex.commonMistakes, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 14.sp)

                                        Spacer(modifier = Modifier.height(8.dp))
                                        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                            Text("推荐组数: ${ex.suggestedSets} 组", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            Text("推荐次数: ${ex.suggestedReps} 次", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            Text("休息: ${ex.restSeconds}秒", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Interactive custom workout builder dialog
    if (showCreator) {
        WorkoutCreatorDialog(
            exercises = exercises,
            onDismiss = { showCreator = false },
            onSave = { name, objective, selected ->
                viewModel.createWorkoutPlan(name, objective, selected)
                showCreator = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkoutCreatorDialog(
    exercises: List<Exercise>,
    onDismiss: () -> Unit,
    onSave: (String, String, List<Exercise>) -> Unit
) {
    var planName by remember { mutableStateOf("") }
    var objective by remember { mutableStateOf("Build Strength") }
    val selectedExercises = remember { mutableStateListOf<Exercise>() }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("晶体训练计划编辑器", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 400.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = planName,
                    onValueChange = { planName = it },
                    label = { Text("计划名称 (例如: 臀腿轰炸)") },
                    modifier = Modifier.fillMaxWidth().testTag("creator_plan_name"),
                    singleLine = true
                )

                Text("目标分类:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Build Strength" to "绝对力量", "Improve Endurance" to "耐力心肺").forEach { (v, l) ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (objective == v) DeepRed else MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { objective = v }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(l, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (objective == v) Color.White else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }

                Text("勾选动作加入计划 (${selectedExercises.size}):", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                        .padding(8.dp)
                ) {
                    exercises.forEach { ex ->
                        val isChecked = selectedExercises.contains(ex)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (isChecked) selectedExercises.remove(ex) else selectedExercises.add(ex)
                                }
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = isChecked,
                                onCheckedChange = {
                                    if (isChecked) selectedExercises.remove(ex) else selectedExercises.add(ex)
                                }
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text(ex.nameZh, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text(ex.category, fontSize = 10.sp, color = ConcreteGrey)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (planName.isNotBlank() && selectedExercises.isNotEmpty()) {
                        onSave(planName, objective, selectedExercises)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = DeepRed),
                enabled = planName.isNotBlank() && selectedExercises.isNotEmpty(),
                modifier = Modifier.testTag("creator_save_button")
            ) {
                Text("保存计划模板")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("取消") }
        }
    )
}

@Composable
fun ActiveWorkoutView(
    workout: Workout,
    onCompleteSet: (String, Int) -> Unit,
    onUpdateSet: (String, Int, Double, Int) -> Unit,
    onFinishWorkout: () -> Unit,
    onCancelWorkout: () -> Unit
) {
    var activeExerciseIndex by remember { mutableStateOf(0) }
    val currentExercise = workout.exercises.getOrNull(activeExerciseIndex)

    var restTimeLeft by remember { mutableStateOf(0) }
    var isTimerRunning by remember { mutableStateOf(false) }

    LaunchedEffect(restTimeLeft, isTimerRunning) {
        if (isTimerRunning && restTimeLeft > 0) {
            delay(1000)
            restTimeLeft -= 1
            if (restTimeLeft == 0) {
                isTimerRunning = false
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(GraphiteDark)
            .padding(16.dp)
            .testTag("active_workout_screen")
    ) {
        // High Contrast Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("晶体硬核运动舱 · 高对比度安全模式", fontSize = 10.sp, color = DeepRed, fontWeight = FontWeight.Bold)
                Text("正在进行: ${workout.name}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.width(220.dp))
            }
            Button(
                onClick = onFinishWorkout,
                colors = ButtonDefaults.buttonColors(containerColor = DeepRed),
                shape = RoundedCornerShape(6.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                modifier = Modifier.height(32.dp).testTag("btn_finish_active_workout")
            ) {
                Text("结束训练", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (currentExercise != null) {
            // Exercise Progress indicator
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "动作 ${activeExerciseIndex + 1}/${workout.exercises.size}",
                    fontSize = 12.sp,
                    color = Color.White.copy(alpha = 0.6f),
                    fontWeight = FontWeight.Bold
                )
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    TextButton(
                        onClick = { if (activeExerciseIndex > 0) activeExerciseIndex -= 1 },
                        enabled = activeExerciseIndex > 0,
                        colors = ButtonDefaults.textButtonColors(contentColor = Color.White)
                    ) {
                        Text("上一个", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    TextButton(
                        onClick = { if (activeExerciseIndex < workout.exercises.size - 1) activeExerciseIndex += 1 },
                        enabled = activeExerciseIndex < workout.exercises.size - 1,
                        colors = ButtonDefaults.textButtonColors(contentColor = Color.White)
                    ) {
                        Text("下一个", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Current Exercise Title Block
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.15f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(currentExercise.nameZh, fontSize = 22.sp, fontWeight = FontWeight.Black, color = Color.White)
                    Text(currentExercise.nameEn, fontSize = 12.sp, color = Color.White.copy(alpha = 0.4f))
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("目标：${currentExercise.category} | 涉及：深蹲架、杠铃", fontSize = 11.sp, color = Color.White.copy(alpha = 0.7f))
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Rest Timer Display
            if (restTimeLeft > 0) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = SubtleAmber.copy(alpha = 0.15f)),
                    border = BorderStroke(1.dp, SubtleAmber)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.HourglassEmpty, contentDescription = "Rest", tint = SubtleAmber, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("重组休整倒计时: $restTimeLeft 秒", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = SubtleAmber)
                        }
                        TextButton(onClick = { restTimeLeft = 0; isTimerRunning = false }) {
                            Text("跳过休息", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Sets Checklist Block
            Text("动作组清单 (点击勾选圆圈完成):", fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f), fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(6.dp))

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                itemsIndexed(currentExercise.sets) { index, set ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = if (set.isCompleted) RestrainedJade.copy(alpha = 0.15f) else GraphiteSurface),
                        border = BorderStroke(1.dp, if (set.isCompleted) RestrainedJade else Color.White.copy(alpha = 0.1f))
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Check Circle
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (set.isCompleted) RestrainedJade else Color.White.copy(alpha = 0.08f))
                                    .clickable {
                                        onCompleteSet(currentExercise.exerciseId, set.setIndex)
                                        if (!set.isCompleted) {
                                            restTimeLeft = 60 // Start 60s rest timer
                                            isTimerRunning = true
                                        }
                                    }
                                    .testTag("set_check_${currentExercise.exerciseId}_${set.setIndex}"),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    if (set.isCompleted) Icons.Default.Check else Icons.Default.PlayArrow,
                                    contentDescription = "Check",
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(16.dp))

                            // Set index details
                            Text(
                                "第 ${set.setIndex} 组",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.width(60.dp)
                            )

                            // Weight adjustment
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                TextButton(
                                    onClick = { onUpdateSet(currentExercise.exerciseId, set.setIndex, (set.weightKg - 5.0).coerceAtLeast(0.0), set.reps) },
                                    modifier = Modifier.size(28.dp),
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Text("-", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                }
                                Text("${set.weightKg.toInt()}kg", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                TextButton(
                                    onClick = { onUpdateSet(currentExercise.exerciseId, set.setIndex, set.weightKg + 5.0, set.reps) },
                                    modifier = Modifier.size(28.dp),
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Text("+", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            // Reps adjustment
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                TextButton(
                                    onClick = { onUpdateSet(currentExercise.exerciseId, set.setIndex, set.weightKg, (set.reps - 1).coerceAtLeast(1)) },
                                    modifier = Modifier.size(28.dp),
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Text("-", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                }
                                Text("${set.reps}次", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                TextButton(
                                    onClick = { onUpdateSet(currentExercise.exerciseId, set.setIndex, set.weightKg, set.reps + 1) },
                                    modifier = Modifier.size(28.dp),
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Text("+", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TabButton(
    title: String,
    isActive: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (isActive) MaterialTheme.colorScheme.background else Color.Transparent)
            .clickable { onClick() }
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = title,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
        )
    }
}
