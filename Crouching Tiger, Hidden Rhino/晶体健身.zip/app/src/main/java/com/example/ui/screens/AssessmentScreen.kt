package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.state.FitnessViewModel
import com.example.ui.theme.ConcreteGrey
import com.example.ui.theme.DeepRed
import com.example.ui.theme.RestrainedJade
import com.example.ui.theme.SubtleAmber
import com.example.ui.theme.WarmWhite
import com.example.ui.theme.GraphiteDark
import com.example.ui.theme.GraphiteSurface

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssessmentScreen(viewModel: FitnessViewModel) {
    val bodyAssessments by viewModel.bodyAssessments.collectAsState()
    val recoveryLogs by viewModel.recoveryLogs.collectAsState()

    val latestAssessment = bodyAssessments.firstOrNull()
    val latestRecovery = recoveryLogs.firstOrNull()

    // Interactive Journal Form States
    var energyInput by remember { mutableStateOf(8) }
    var sleepInput by remember { mutableStateOf(7.5) }
    var sorenessInput by remember { mutableStateOf(3) }
    var stressInput by remember { mutableStateOf(3) }
    var motivationInput by remember { mutableStateOf(8) }

    var activeTab by remember { mutableStateOf("DEXA") } // "DEXA", "Symmetry", "Recovery"

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Screen Title
        Column {
            Text(
                text = "晶体体测及康复实验室",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = DeepRed,
                letterSpacing = 1.sp
            )
            Text(
                text = "高精体能评估与生物还原 / CLINICAL ASSESSMENT LAB",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        // Horizontal Navigation Tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(4.dp)
        ) {
            TabButton(
                title = "3D & DEXA 身体成分",
                isActive = activeTab == "DEXA",
                modifier = Modifier.weight(1f),
                onClick = { activeTab = "DEXA" }
            )
            TabButton(
                title = "骨骼及体态对称性",
                isActive = activeTab == "Symmetry",
                modifier = Modifier.weight(1f),
                onClick = { activeTab = "Symmetry" }
            )
            TabButton(
                title = "神经疲劳与睡眠日志",
                isActive = activeTab == "Recovery",
                modifier = Modifier.weight(1f),
                onClick = { activeTab = "Recovery" }
            )
        }

        when (activeTab) {
            "DEXA" -> {
                if (latestAssessment != null) {
                    // Quick Stats grid
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricCard(title = "体脂率", value = "${latestAssessment.bodyFatPercentage}%", desc = "干练型", modifier = Modifier.weight(1f), color = DeepRed)
                        MetricCard(title = "骨骼肌量", value = "${latestAssessment.muscleMassKg} kg", desc = "高储备", modifier = Modifier.weight(1f), color = RestrainedJade)
                        MetricCard(title = "内脏脂肪", value = "${latestAssessment.visceralFatLevel}", desc = "正常范围", modifier = Modifier.weight(1f), color = SubtleAmber)
                    }

                    // Historical trends logs list
                    Text("体成分 DEXA 历史演变趋势 (Historical Progression):", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ConcreteGrey)
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        bodyAssessments.forEach { record ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.08f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(record.date, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        Text("测量设备: 3D光感扫描仪 v2", fontSize = 10.sp, color = ConcreteGrey)
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                        TrendValueColumn("体重", "${record.weightKg}kg", "稳定")
                                        TrendValueColumn("肌肉", "${record.muscleMassKg}kg", "+0.4kg", RestrainedJade)
                                        TrendValueColumn("体脂", "${record.bodyFatPercentage}%", "-0.8%", DeepRed)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            "Symmetry" -> {
                // Postural Symmetry evaluation
                Text("人体力学体态及对称性评测报告:", fontSize = 12.sp, fontWeight = FontWeight.Bold)

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.12f))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        SymmetryRow(title = "骨盆旋转 (Pelvic Rotation)", status = "Symmetric", details = "两侧骨盆髂前上棘高度对称，旋转偏差度 1°", isWarning = false)
                        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.08f))
                        SymmetryRow(title = "高低肩 (Shoulder Tilt)", status = "Symmetric", details = "双肩峰倾斜偏差小于 0.4cm，符合健康水平", isWarning = false)
                        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.08f))
                        SymmetryRow(title = "头前伸 (Forward Head Tilt)", status = "Normal", details = "颈椎外耳道重力线偏前 3°，属于正常功能范围", isWarning = false)
                        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.08f))
                        SymmetryRow(title = "下肢肌力不平衡", status = "Asymmetric (⚠️ 异常)", details = "左腿腿部肌肉重 12.1kg vs 右腿 12.3kg。不对称度产生 0.2kg 缺口。建议多做单腿动作纠正神经募集。", isWarning = true)
                    }
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = RestrainedJade.copy(alpha = 0.08f)),
                    border = BorderStroke(1.dp, RestrainedJade.copy(alpha = 0.15f))
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.VerifiedUser, contentDescription = "Safe", tint = RestrainedJade)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("神经发育对称性指导建议", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = RestrainedJade)
                            Text("我们已为您将左、右侧肢体肌肉肌力不平横问题，录入今日智能推荐计划。在“动作指南库”中检索【保加利亚剪步蹲】，可获得最大程度的修正指导。", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface, lineHeight = 15.sp)
                        }
                    }
                }
            }
            "Recovery" -> {
                // Sleep and recovery input questionnaire
                Text("中枢神经疲劳 & 自我康复测定日志:", fontSize = 12.sp, fontWeight = FontWeight.Bold)

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text("请提供您今日的主观身体状态 (1-10分):", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = DeepRed)

                        // Energy slider
                        Column {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("精力指数 (Energy Level):", fontSize = 11.sp)
                                Text("$energyInput / 10分", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DeepRed)
                            }
                            Slider(
                                value = energyInput.toFloat(),
                                onValueChange = { energyInput = it.toInt() },
                                valueRange = 1f..10f,
                                steps = 8,
                                modifier = Modifier.testTag("slider_energy")
                            )
                        }

                        // Soreness slider
                        Column {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("肌肉酸痛度 (Muscle Soreness):", fontSize = 11.sp)
                                Text("$sorenessInput / 10分", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DeepRed)
                            }
                            Slider(
                                value = sorenessInput.toFloat(),
                                onValueChange = { sorenessInput = it.toInt() },
                                valueRange = 1f..10f,
                                steps = 8,
                                modifier = Modifier.testTag("slider_soreness")
                            )
                        }

                        // Sleep input
                        Column {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("睡眠时长 (Sleep Duration):", fontSize = 11.sp)
                                Text("$sleepInput 小时", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DeepRed)
                            }
                            Slider(
                                value = sleepInput.toFloat(),
                                onValueChange = { sleepInput = Math.round(it * 2) / 2.0 },
                                valueRange = 4f..12f,
                                steps = 15,
                                modifier = Modifier.testTag("slider_sleep")
                            )
                        }

                        // Submit action
                        Button(
                            onClick = {
                                viewModel.submitRecoveryJournal(
                                    energy = energyInput,
                                    sleep = sleepInput,
                                    soreness = sorenessInput,
                                    stress = stressInput,
                                    motivation = motivationInput
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = DeepRed),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(40.dp)
                                .testTag("btn_submit_recovery_journal")
                        ) {
                            Icon(Icons.Default.Save, contentDescription = "Save", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("提交康复评估并同步给 AI 助手", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // AI Generated recommendation block
                if (latestRecovery != null) {
                    Text("数智系统生成的最新康复决策建议:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ConcreteGrey)
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.12f))
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.OfflineBolt, contentDescription = "Active", tint = SubtleAmber, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "主客观融合诊断报告 (基于 ${latestRecovery.date})",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = latestRecovery.suggestion,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                lineHeight = 15.sp
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                Text("中枢精力: ${latestRecovery.energyLevel}/10", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Text("肌肉酸痛: ${latestRecovery.sorenessLevel}/10", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = DeepRed)
                                Text("自发意愿: ${latestRecovery.motivationLevel}/10", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = RestrainedJade)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetricCard(title: String, value: String, desc: String, modifier: Modifier = Modifier, color: Color) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(title, fontSize = 11.sp, color = ConcreteGrey, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, fontSize = 16.sp, fontWeight = FontWeight.Black, color = color)
            Spacer(modifier = Modifier.height(2.dp))
            Text(desc, fontSize = 9.sp, color = ConcreteGrey)
        }
    }
}

@Composable
fun TrendValueColumn(title: String, valStr: String, label: String, color: Color = MaterialTheme.colorScheme.onSurfaceVariant) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, fontSize = 9.sp, color = ConcreteGrey)
        Text(valStr, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Text(label, fontSize = 9.sp, color = color, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun SymmetryRow(title: String, status: String, details: String, isWarning: Boolean) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(title, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (isWarning) DeepRed.copy(alpha = 0.1f) else RestrainedJade.copy(alpha = 0.1f))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = status,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isWarning) DeepRed else RestrainedJade
                )
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(details, fontSize = 11.sp, color = ConcreteGrey, lineHeight = 15.sp)
    }
}
