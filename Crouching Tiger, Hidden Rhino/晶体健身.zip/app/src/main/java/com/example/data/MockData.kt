package com.example.data

object MockData {

    val demoUser = Member(
        id = "member_linzhe",
        name = "林哲 / Lin Zhe",
        ageRange = "26-35",
        height = 178.5,
        weight = 74.2,
        trainingExperience = "基础训练者", // Intermediate
        fitnessObjectives = listOf("build strength", "improve endurance", "improve consistency"),
        preferredTrainingTime = "晚上 (18:00 - 21:00)",
        preferredGym = "晶体健身·静安中心",
        preferredWorkoutTypes = listOf("力量训练", "有氧训练"),
        equipmentPreferences = listOf("哑铃", "深蹲架", "智能跑步机"),
        language = "简体中文",
        accessibilityPreferences = "无",
        trainingLimitations = "轻微左膝不适，避免极高强度负重深蹲"
    )

    val gyms = listOf(
        Gym(
            id = "gym_jingan",
            name = "晶体健身·静安中心",
            city = "上海",
            district = "静安区",
            address = "上海市静安区南京西路1088号晶体大厦3楼",
            openingHours = "06:00 - 23:00",
            floorArea = 1500,
            equipmentCount = 45,
            crowdingEstimate = 45,
            classAvailability = true,
            trainerAvailability = true,
            showerFacilities = true,
            lockers = true,
            accessibilityFacilities = true,
            currentOccupancy = 32,
            peakHours = listOf(15, 20, 25, 40, 55, 75, 85, 90, 80, 65, 45, 30, 20, 10, 5),
            cleaningStatus = "已完成清洁 (10分钟前)",
            maintenanceAlerts = listOf("2号智能跑步机将在今天下午14:00进行固件升级")
        ),
        Gym(
            id = "gym_pudong",
            name = "晶体健身·浦东金融城",
            city = "上海",
            district = "浦东新区",
            address = "上海市浦东新区陆家嘴环路400号金茂大厦B1层",
            openingHours = "06:00 - 23:00",
            floorArea = 1800,
            equipmentCount = 55,
            crowdingEstimate = 65,
            classAvailability = true,
            trainerAvailability = true,
            showerFacilities = true,
            lockers = true,
            accessibilityFacilities = true,
            currentOccupancy = 54,
            peakHours = listOf(10, 15, 30, 60, 80, 45, 40, 50, 75, 95, 80, 55, 35, 15, 5),
            cleaningStatus = "已完成清洁 (15分钟前)",
            maintenanceAlerts = emptyList()
        ),
        Gym(
            id = "gym_shenzhen",
            name = "晶体健身·深圳湾",
            city = "深圳",
            district = "南山区",
            address = "深圳市南山区科苑南路深圳湾万象城4层",
            openingHours = "24小时营业",
            floorArea = 2000,
            equipmentCount = 60,
            crowdingEstimate = 35,
            classAvailability = true,
            trainerAvailability = true,
            showerFacilities = true,
            lockers = true,
            accessibilityFacilities = true,
            currentOccupancy = 28,
            peakHours = listOf(5, 10, 20, 35, 45, 60, 55, 60, 70, 80, 75, 50, 30, 20, 15),
            cleaningStatus = "已完成清洁 (5分钟前)",
            maintenanceAlerts = listOf("4号史密斯架缆绳磨损，今日暂停使用")
        ),
        Gym(
            id = "gym_hangzhou",
            name = "晶体健身·杭州滨江",
            city = "杭州",
            district = "滨江区",
            address = "杭州市滨江区江南大道星光大道二期3层",
            openingHours = "07:00 - 22:30",
            floorArea = 1400,
            equipmentCount = 40,
            crowdingEstimate = 50,
            classAvailability = true,
            trainerAvailability = true,
            showerFacilities = true,
            lockers = true,
            accessibilityFacilities = false,
            currentOccupancy = 25,
            peakHours = listOf(10, 20, 30, 40, 50, 60, 70, 85, 90, 75, 60, 40, 25, 10, 0),
            cleaningStatus = "已完成清洁 (30分钟前)",
            maintenanceAlerts = emptyList()
        ),
        Gym(
            id = "gym_chengdu",
            name = "晶体健身·成都太古里",
            city = "成都",
            district = "锦江区",
            address = "成都市锦江区中纱帽街8号远洋太古里负一层",
            openingHours = "08:00 - 23:00",
            floorArea = 1600,
            equipmentCount = 48,
            crowdingEstimate = 55,
            classAvailability = true,
            trainerAvailability = true,
            showerFacilities = true,
            lockers = true,
            accessibilityFacilities = true,
            currentOccupancy = 38,
            peakHours = listOf(5, 10, 20, 30, 45, 60, 75, 80, 85, 90, 80, 65, 45, 20, 10),
            cleaningStatus = "已完成清洁 (12分钟前)",
            maintenanceAlerts = emptyList()
        )
    )

    val members = listOf(
        demoUser,
        Member("m2", "徐嘉怡 / Sherry Xu", "18-25", 165.0, 52.3, "初学者", listOf("improve mobility", "maintain fitness"), "早上 (07:00 - 10:00)", "晶体健身·静安中心", listOf("瑜伽", "普拉提"), listOf("瑜伽垫", "泡沫轴"), "简体中文", "无", "无"),
        Member("m3", "张伟 / David Zhang", "26-35", 182.0, 88.5, "进阶训练者", listOf("build strength", "prepare for an event"), "晚上 (18:00 - 21:00)", "晶体健身·浦东金融城", listOf("力量训练"), listOf("深蹲架", "杠铃", "智能哑铃"), "简体中文", "无", "无"),
        Member("m4", "陈美玲 / May Chen", "36-45", 162.5, 58.0, "基础训练者", listOf("improve general health", "improve consistency"), "中午 (12:00 - 14:00)", "晶体健身·深圳湾", listOf("有氧训练", "拉伸恢复"), listOf("智能跑步机", "智能动感单车"), "简体中文", "有大字版需求", "轻微高血压，运动心率控制在140以下"),
        Member("m5", "王浩 / Leo Wang", "18-25", 175.0, 70.1, "基础训练者", listOf("build strength", "improve endurance"), "晚上 (18:00 - 21:00)", "晶体健身·杭州滨江", listOf("力量训练", "功能训练"), listOf("凯利机", "壶铃"), "简体中文", "无", "无"),
        Member("m6", "李娜 / Nana Li", "26-35", 168.0, 56.4, "进阶训练者", listOf("improve endurance", "prepare for an event"), "早上 (07:00 - 10:00)", "晶体健身·静安中心", listOf("有氧训练", "HIIT"), listOf("划船机", "智能跑步机"), "简体中文", "无", "无"),
        Member("m7", "刘洋 / Yang Liu", "36-45", 176.0, 81.2, "基础训练者", listOf("improve general health", "learn technique"), "下午 (14:00 - 18:00)", "晶体健身·成都太古里", listOf("功能训练", "力量训练"), listOf("智能哑铃", "阻力带"), "简体中文", "无", "腰椎间盘轻微突出，避免大重量硬拉"),
        Member("m8", "赵敏 / Minnie Zhao", "18-25", 160.0, 48.5, "初学者", listOf("maintain fitness", "improve consistency"), "晚上 (18:00 - 21:00)", "晶体健身·浦东金融城", listOf("普拉提", "拉伸恢复"), listOf("瑜伽垫", "智能动感单车"), "简体中文", "无", "无"),
        Member("m9", "黄骏 / Frank Huang", "46-55", 172.0, 78.5, "基础训练者", listOf("improve general health", "improve mobility"), "早上 (07:00 - 10:00)", "晶体健身·深圳湾", listOf("拉伸恢复", "有氧训练"), listOf("智能动感单车", "泡沫轴"), "简体中文", "无", "肩袖关节轻微劳损"),
        Member("m10", "周洁 / Jessie Zhou", "26-35", 166.0, 54.0, "基础训练者", listOf("improve endurance", "maintain fitness"), "中午 (12:00 - 14:00)", "晶体健身·杭州滨江", listOf("HIIT", "有氧训练"), listOf("划船机", "登山机"), "简体中文", "无", "无"),
        Member("m11", "吴强 / Kevin Wu", "26-35", 185.0, 95.0, "进阶训练者", listOf("build strength", "prepare for an event"), "晚上 (18:00 - 21:00)", "晶体健身·成都太古里", listOf("力量训练"), listOf("深蹲架", "杠铃"), "English", "无", "无"),
        Member("m12", "孙婷 / Tina Sun", "36-45", 164.0, 51.5, "初学者", listOf("improve general health", "improve consistency"), "下午 (14:00 - 18:00)", "晶体健身·静安中心", listOf("有氧训练", "拉伸恢复"), listOf("智能跑步机", "阻力带"), "简体中文", "无", "无")
    )

    val coaches = listOf(
        Coach("coach_1", "高瑞 / Ray Gao", "https://example.com/avatar1.jpg", "力量与增肌", "NSCA-CPT, 3D重力训练认证, 运动营养师", 8, listOf("简体中文", "English"), "严格高效，重视物理力学与动作规范", listOf("10:00 - 11:00", "15:00 - 16:00", "19:00 - 20:00"), 450.0, 4.9, "力量进阶与中高级训练者", "“重力和杠铃是最诚实的伙伴，你付出多少，它们就回馈多少。”"),
        Coach("coach_2", "林舒雅 / Maya Lin", "https://example.com/avatar2.jpg", "减脂与塑形", "NASM-PES, ACE-CPT, 莱美金牌教练", 6, listOf("简体中文", "English"), "热情鼓励，音乐节奏把控极佳", listOf("09:00 - 10:00", "14:00 - 15:00", "18:00 - 19:00"), 400.0, 4.8, "女性减脂塑形及初学者", "“健身不是受罪，而是一场发现身体能量的快乐旅程。”"),
        Coach("coach_3", "张廷 / Tony Zhang", "https://example.com/avatar3.jpg", "体能与敏捷", "CSCS (体能训练专家), Kettlebell Athletics Level 2", 10, listOf("简体中文"), "科学严谨，高强度，注重心肺与核心爆发", listOf("11:00 - 12:00", "16:00 - 17:00", "20:00 - 21:00"), 500.0, 5.0, "马拉松、越野及专业体能挑战者", "“超越单纯的体型，打造兼具爆发力与耐力的终极运动机能。”"),
        Coach("coach_4", "沈清 / Clara Shen", "https://example.com/avatar4.jpg", "理疗与体态康复", "SFMA选择性运动功能评估, 普拉提大器械认证", 7, listOf("简体中文"), "温和细致，善于捕捉体态缺陷与动作代偿", listOf("08:00 - 09:00", "13:00 - 14:00", "17:00 - 18:00"), 480.0, 4.9, "久坐办公族、产后恢复及腰颈椎不适者", "“先学会正确地呼吸和控制，再谈力量的堆叠。”"),
        Coach("coach_5", "陈嘉豪 / Jack Chen", "https://example.com/avatar5.jpg", "少儿与青少年体能", "NASM-YES (青年运动专家), 国家一级田径运动员", 5, listOf("简体中文"), "风趣幽默，互动性强", listOf("10:00 - 11:00", "16:00 - 17:00", "19:00 - 20:00"), 380.0, 4.7, "青少年体质提升及趣味运动", "“让孩子在欢笑和挑战中爱上运动，筑牢一生的健康基石。”"),
        Coach("coach_6", "郑勋 / Sean Zheng", "https://example.com/avatar6.jpg", "大众健身与初学者入门", "AASFP高级私人教练, 健美锦标赛80kg级前五", 9, listOf("简体中文", "粤语"), "循序渐进，耐心周到，动作库极其庞大", listOf("09:00 - 10:00", "15:00 - 16:00", "18:00 - 19:00"), 420.0, 4.8, "零基础小白、中老年健康管理", "“每个人都是一粒种子，只要方法得当、持之以恒，终会绽放。”"),
        Coach("coach_7", "韩莉 / Lily Han", "https://example.com/avatar7.jpg", "瑜伽与静心冥想", "RYT-500认证高级瑜伽导师, 印度Kaivalyadhama深度进修", 12, listOf("简体中文", "English"), "疗愈空灵，声音温暖，带领深层身心放松", listOf("07:00 - 08:00", "12:00 - 13:00", "19:00 - 20:00"), 460.0, 4.9, "压力繁重、失眠、情绪焦虑及柔韧度提升者", "“在呼吸的每一次吞吐中，寻找身体的边界与心灵的旷野。”"),
        Coach("coach_8", "向飞 / Felix Xiang", "https://example.com/avatar8.jpg", "拳击健身与HIIT", "WBC Boxing Fitness 认证教练, 前省队散打队员", 6, listOf("简体中文"), "荷尔蒙爆棚，极致燃脂，高负荷爆汗", listOf("11:00 - 12:00", "17:00 - 18:00", "20:00 - 21:00"), 450.0, 4.8, "高压力宣泄、速效燃脂与拳击爱好者", "“把压力重重砸向沙袋，汗水流尽后，你会重获新生。”"),
        Coach("coach_9", "顾宁 / Ning Gu", "https://example.com/avatar9.jpg", "运动后恢复与拉伸", "FMS功能运动筛查认证, 物理治疗专业背景", 8, listOf("简体中文", "English"), "手法精准，运动力学恢复指导系统化", listOf("08:00 - 09:00", "14:00 - 15:00", "18:00 - 19:00"), 420.0, 4.9, "大负荷训练后深度恢复，预防肌肉劳损者", "“没有高质量的恢复，就没有下一次高水平的爆发。”"),
        Coach("coach_10", "保罗 / Paul Becker", "https://example.com/avatar10.jpg", "奥林匹克举重", "USAW Level 1 举重教练, 运动生物力学硕士", 11, listOf("English", "简体中文"), "极致数据化，拆解杠铃运动轨迹", listOf("10:00 - 11:00", "15:00 - 16:00", "19:00 - 20:00"), 600.0, 5.0, "硬核举重爱好者、力量突破极限者", "“Lift heavy, lift smart, leverage the pure physics of human movement.”")
    )

    val exercises = listOf(
        // 力量训练
        Exercise("ex_squat", "杠铃背蹲", "Barbell Back Squat", "力量训练", "经典的下肢双关节复合动作，主要训练股四头肌、臀大肌以及核心稳定性。", "股四头肌, 臀大肌, 核心肌群", "深蹲架, 杠铃", "进阶训练者", 4, 10, 90, "保持背部平直，膝盖下蹲方向与脚尖一致，避免膝盖内扣。", "膝关节内扣；弓背下蹲；下蹲深度不足"),
        Exercise("ex_deadlift", "杠铃硬拉", "Barbell Deadlift", "力量训练", "全身性的链条拉类动作，主要训练臀大肌、腘绳肌及整个竖脊肌后侧链。", "腘绳肌, 臀大肌, 竖脊肌", "杠铃", "进阶训练者", 4, 8, 120, "双脚与胯同宽，杠铃杆贴近小腿，核心收紧，蹬地拉起，骨盆在中立位锁定。", "驼背硬拉；杠铃杆偏离身体过远；锁定时腰椎过度超伸"),
        Exercise("ex_bench_press", "杠铃卧推", "Barbell Bench Press", "力量训练", "上肢经典的推类动作，主要刺激胸大肌、三角肌前束和肱三头肌。", "胸大肌, 三角肌前束, 肱三头肌", "卧推架, 杠铃", "基础训练者", 4, 10, 90, "起桥使肩胛骨下沉收紧，下落时杠铃杆落在乳头连线附近，手肘约呈45度夹角。", "耸肩推起；手腕向后过度折屈；杠铃猛烈砸胸反弹"),
        Exercise("ex_overhead_press", "杠铃推举", "Barbell Overhead Press", "力量训练", "站姿上肢垂直推类动作，极大考验肩部力量及核心稳定控制。", "三角肌前束, 肱三头肌, 核心肌群", "深蹲架, 杠铃", "进阶训练者", 3, 8, 90, "双脚站稳收臀，杠铃从锁骨处直推向上，手臂完全伸直时，头部轻微前探让杠铃位于身体正上方。", "过度挺胸仰头造成腰椎超伸；借腿部力量顶起（变成Push Press）"),
        Exercise("ex_row", "杠铃俯身划船", "Barbell Bent Over Row", "力量训练", "经典的背部拉类动作，主要训练背阔肌、斜方肌中下部及三角肌后束。", "背阔肌, 斜方肌中下部, 三角肌后束", "杠铃", "基础训练者", 4, 10, 90, "俯身角度保持在30至45度，核心收紧，大腿后侧绷紧，将杠铃向小腹方向拉起。", "身体随杠铃上下晃动幅度过大；耸肩用手臂发力拉起"),
        Exercise("ex_pull_up", "引体向上", "Pull-Up", "力量训练", "经典的自重背部训练动作，主要针对背阔肌和二头肌，要求高水平的自重控制。", "背阔肌, 肱二头肌, 斜方肌下部", "单杠", "进阶训练者", 4, 8, 120, "双手略宽于肩悬挂，背阔肌发力带动身体上拉，至下巴超过单杠，下放时保持控制。", "身体过度摇晃借力；未完全下放肌肉拉伸不充分；耸肩借力"),
        Exercise("ex_lunge", "哑铃箭步蹲", "Dumbbell Lunge", "力量训练", "单侧下肢训练的王牌动作，对平衡、协调和臀腿单侧力量极大考验。", "臀大肌, 股四头肌, 核心肌群", "哑铃", "基础训练者", 3, 12, 60, "双手持哑铃直立，单腿向前迈出并下蹲，至双膝皆呈90度夹角，后膝接近地面但不要撞击。", "重心过度前移使膝盖超伸脚跟抬起；躯干晃动无法稳定"),
        Exercise("ex_leg_press", "45度倒蹬", "Leg Press", "力量训练", "高安全系数的下肢大负荷动作，适合孤立刺激股四头肌，减少腰椎压力。", "股四头肌, 臀大肌", "倒蹬机", "基础训练者", 4, 12, 90, "下背紧贴靠背，双脚置于踏板上，下放至膝关节约90度后，脚跟发力推起，但不要让膝关节完全锁死。", "推至顶点时膝盖猛烈锁定；臀部在下放时离开靠背导致骨盆后倾"),
        Exercise("ex_romanian_dl", "罗马尼亚硬拉", "Romanian Deadlift", "力量训练", "针对后侧链（腘绳肌与臀大肌）的离心训练，改善腘绳肌张力的绝佳动作。", "腘绳肌, 臀大肌, 竖脊肌", "杠铃, 哑铃", "基础训练者", 3, 10, 90, "从站姿开始，保持小腿几乎垂直地面，臀部向后折叠，杠铃贴大腿下放至膝盖下方，感受后侧极度拉伸后收臀直立。", "膝盖弯曲过大变成普通硬拉；骨盆未能向后平移导致弓背"),

        // 有氧训练
        Exercise("ex_treadmill", "智能跑步机跑步", "Smart Treadmill Running", "有氧训练", "智能跑步机上进行的有氧耐力训练，能够实时同步心率、速度及坡度。", "全身肌群, 心肺系统", "智能跑步机", "初学者", 1, 1, 0, "保持躯干正直，眼看前方，双臂自然摆动，步伐轻盈，落地点在身体重心下方。", "脚跟着地产生震动冲击；低头看手机或屏幕破坏体态"),
        Exercise("ex_cycling", "智能动感单车", "Smart Cycling", "有氧训练", "低冲击的高强度有氧训练，保护膝关节的同时，高效增强下肢耐力与爆发。", "股四头肌, 腘绳肌, 腓肠肌", "智能动感单车", "初学者", 1, 1, 0, "根据身高调整车座，踩踏时脚掌前三分之一踩在脚踏板，下踩时膝盖微屈不锁死。", "车座过高或过低；脚尖踩踏导致小腿代偿发胀；上半身无力趴在车把上"),
        Exercise("ex_rower", "智能划船机", "Smart Rowing", "有氧训练", "高燃脂全身有氧运动，动用全身80%以上肌肉群，同时对关节极其友好。", "背阔肌, 核心肌群, 腘绳肌", "划船机", "基础训练者", 1, 1, 0, "遵循‘腿-髋-臂’的拉起顺序，和‘臂-髋-腿’的还原顺序，蹬腿为主，双臂收尾拉至下肋骨。", "顺序颠倒导致腰部承受不当剪切力；仅用双臂拉而完全不蹬腿"),
        Exercise("ex_elliptical", "椭圆机运动", "Elliptical Workout", "有氧训练", "零冲击的全身有氧器械，非常适合关节康复及体重基数较大者减脂。", "全身肌群, 心肺系统", "椭圆机", "初学者", 1, 1, 0, "脚掌保持平贴踏板，双手轻握把手随之摆动，保持身体中正，避免骨盆过度倾斜。", "脚跟抬起用脚尖踩踏导致跟腱紧张；完全不扶把手身躯倾斜摇晃"),
        Exercise("ex_stair", "登山机爬楼", "Stair Climber", "有氧训练", "极高强度的垂直有氧训练，同时对臀大肌和股四头肌有极佳的塑形效果。", "股四头肌, 臀大肌, 腓肠肌", "登山机", "基础训练者", 1, 1, 0, "上身可轻微前倾，但避免驼背，脚掌踩实台阶，臀部发力蹬起，避免双手死死撑住扶手卸力。", "双手撑在两侧扶手全身悬空卸力；驼背弓腰爬楼增加腰椎压力"),
        Exercise("ex_interval", "高强度间歇训练", "HIIT Interval Training", "有氧训练", "短时间内高负荷运动与短暂休息交替，极限拉高心率，造成超额氧耗效应。", "全身肌群, 心肺系统", "自重, 哑铃", "基础训练者", 1, 4, 30, "在全力爆发阶段（如开合跳、波比跳）务必保证动作质量，心率拉升至80%以上最大心率。", "疲劳时动作完全走形导致受伤；休息时间不足导致无法再次爆发出高强度"),

        // 功能训练
        Exercise("ex_kb_swing", "壶铃摇摆", "Kettlebell Swing", "功能训练", "髋关节铰链的爆发力动作，主要激活臀部与大腿后侧，提升核心稳定性。", "臀大肌, 腘绳肌, 核心肌群", "壶铃", "基础训练者", 3, 15, 60, "利用髋部向后折叠和向前的爆发力将壶铃“荡”起，双臂仅作为连接绳，不要主动用肩膀提拉。", "用手臂和肩膀的力量把壶铃提起来；膝盖弯曲过多做成深蹲摇摆"),
        Exercise("ex_band_row", "阻力带划船", "Resistance Band Row", "功能训练", "使用弹力阻力带进行背部拉类动作，张力随拉长线性递增，对肌肉离心控制极佳。", "背阔肌, 三角肌后束, 肱二头肌", "阻力带", "初学者", 3, 15, 45, "将阻力带固定在前，双手持把手，俯身或站立核心收紧，大臂贴躯干往后拉，手肘夹紧。", "拉至顶峰时没有挤压背肌；放回时完全丧失张力瞬间弹回"),
        Exercise("ex_push_up", "标准俯卧撑", "Push-Up", "功能训练", "最基础的徒手推类动作，训练胸大肌、前锯肌及整个前侧核心张力。", "胸大肌, 三角肌前束, 肱三头肌", "自重", "初学者", 3, 15, 60, "身体从头到脚呈一条直线，核心收紧，臀部不要塌陷或翘起，下落至胸部接近地面后推起。", "塌腰（腹部核心没有收紧）；手肘过度外展（与躯干呈90度夹角，易伤肩）"),
        Exercise("ex_trx_row", "TRX悬吊划船", "TRX Suspension Row", "功能训练", "利用自重和悬吊阻力进行的背部拉类动作，高度依赖核心稳定性来保持体线。", "背阔肌, 斜方肌中下部, 核心肌群", "TRX悬吊带", "初学者", 3, 12, 60, "身体倾斜，脚跟撑地，保持全身平直。双臂拉起身体，直至拳头贴近胸部两侧。", "塌腰、拱臀破坏身体一条线的原则；耸肩代偿"),
        Exercise("ex_med_slam", "药球砸地", "Medicine Ball Slam", "功能训练", "极佳的核心爆发力训练，通过快速的全身性下砸，宣泄压力的同时刺激腹部肌群。", "腹直肌, 核心肌群, 肱三头肌", "重力药球", "初学者", 3, 12, 45, "将药球举过头顶，微挺胸，随后利用髋关节爆发折叠，核心全力收缩，将药球狠狠砸向前方地面。", "仅用双臂力量砸地，完全不借助髋部折叠和腹肌收缩"),

        // 灵活性与恢复
        Exercise("ex_foam_rolling", "泡沫轴全身筋膜放松", "Foam Rolling SMR", "灵活性与恢复", "利用自重压在泡沫轴上缓缓滚动，释放过度紧张的肌肉筋膜，加速乳酸排泄。", "全身肌肉筋膜", "泡沫轴", "初学者", 1, 1, 0, "将泡沫轴置于目标肌群下方，缓慢滚动，寻找酸痛点（扳机点），在酸痛点停留20-30秒配合深呼吸。", "滚动速度过快产生代偿紧绷；直接滚压关节或骨头突起处；在急性受伤部位滚动"),
        Exercise("ex_mobility_flow", "髋关节活动度流", "Hip Mobility Flow", "灵活性与恢复", "一系列动态伸展，旨在提升髋关节在屈伸、内外旋等多个维度的活动度。", "臀小肌, 髂腰肌, 髋关节囊", "自重, 瑜伽垫", "初学者", 2, 8, 30, "进行90-90髋关节旋转、弓步股四头肌拉伸等，动作平缓深长，配合呼吸，不强求剧烈拉伸感。", "动作节奏过快产生拉伸反射对抗；憋气进行拉伸导致神经紧张"),
        Exercise("ex_stretching", "静态拉伸恢复", "Static Stretching Recovery", "灵活性与恢复", "训练后的全身静态拉伸，降低肌肉张力，使交感神经转换为副交感神经主导，促进恢复。", "全身主要肌群", "自重, 瑜伽垫", "初学者", 1, 1, 0, "每个拉伸姿势（如大腿前侧、胸大肌、小腿拉伸）保持30秒，呼吸平缓、深沉，拉伸感保持在轻微酸胀即可。", "用力过度产生尖锐疼痛（极易拉伤肌肉）；拉伸时间过短（少于15秒，无法让肌肉纤维松弛）"),
        Exercise("ex_breathing", "膈肌深呼吸冥想", "Diaphragmatic Breathing", "灵活性与恢复", "通过膈肌主导的深长呼吸，激活副交感神经，极速降低运动后的皮质醇与心率。", "横膈膜, 核心稳定系统", "自重, 瑜伽垫", "初学者", 1, 1, 0, "平躺，一手放胸前一手放腹部。吸气时腹部隆起、胸口保持不动，吐气时腹部缓缓下陷，吸吐比例约为1:2。", "过度使用胸式呼吸耸肩；呼吸过浅导致换气过度眩晕")
    )

    val classes = listOf(
        // 晶体健身·静安中心 (gym_jingan) 20 classes
        GymClass("class_j_1", "晶体极速燃脂 HIIT", "HIIT", "林舒雅 / Maya Lin", 45, "基础训练者", "多功能团操房", 25, 3, "自重, 哑铃", "高强度高节奏，心率急速攀升，音乐节奏带感，适合白领速效暴汗减脂。", "今日 19:00 - 19:45", true, 0),
        GymClass("class_j_2", "哈他瑜伽·身心疗愈", "yoga", "韩莉 / Lily Han", 60, "初学者", "静心瑜伽教室", 15, 0, "瑜伽垫, 瑜伽砖", "深度舒展，配合呼吸吐纳，平复一天的都市焦虑，寻找内在宁静与柔韧边界。", "今日 20:00 - 21:00", false, 4, true),
        GymClass("class_j_3", "硬核杠铃力量进阶", "strength", "高瑞 / Ray Gao", 50, "进阶训练者", "自由力量区", 12, 4, "深蹲架, 杠铃", "针对大肌群复合动作的精细化拆解，深蹲、卧推专项突破，适合追求绝对力量者。", "明日 12:15 - 13:05", false, 0),
        GymClass("class_j_4", "智能动感单车：巅峰心肺", "cycling", "林舒雅 / Maya Lin", 45, "初学者", "动感单车房", 30, 18, "智能动感单车", "模拟越野公路、陡峭山地骑行，结合炫酷视觉投影，高频踏频中榨干卡路里。", "明日 18:30 - 19:15", false, 0),
        GymClass("class_j_5", "TRX悬吊核心雕刻", "functional", "郑勋 / Sean Zheng", 45, "基础训练者", "多功能团操房", 18, 10, "TRX悬吊带", "利用自重倾斜角度挑战不稳定核心，360度激活腹部深层抗旋转肌群。", "周一 19:00 - 19:45", false, 0),
        GymClass("class_j_6", "普拉提大器械·核心控制", "Pilates", "沈清 / Clara Shen", 50, "基础训练者", "普拉提专区", 6, 1, "普拉提核心床", "精细控制脊柱中立与骨盆稳定，针对深层肌肉进行柔韧强化与体态雕塑。", "周二 10:00 - 10:50", false, 0),
        GymClass("class_j_7", "搏击操：压力宣泄", "boxing", "向飞 / Felix Xiang", 45, "初学者", "多功能团操房", 25, 12, "自重", "拳击、散打动作融入动感电音，超强打击感，汗水在挥拳和闪躲中彻底释放。", "周二 19:00 - 19:45", false, 0),
        GymClass("class_j_8", "髋关节与肩袖灵活性流", "mobility", "顾宁 / Ning Gu", 45, "初学者", "拉伸舒缓区", 15, 8, "阻力带, 泡沫轴", "打通因长期久坐而锁死的髋关节与圆肩体态，改善关节活动度与润滑度。", "周三 12:15 - 13:00", false, 0),

        // 晶体健身·浦东金融城 (gym_pudong)
        GymClass("class_p_1", "晨间唤醒：流瑜伽", "yoga", "韩莉 / Lily Han", 50, "初学者", "天际操房", 20, 5, "瑜伽垫", "在陆家嘴晨光中开始，流动的呼吸，温和拉伸全身，为一整天注入饱满氧气。", "今日 07:15 - 08:05", false, 0),
        GymClass("class_p_2", "午间写字楼解压 HIIT", "HIIT", "林舒雅 / Maya Lin", 30, "初学者", "多功能操房", 20, 2, "自重", "专为白领设计的30分钟极速燃脂，快速激活身体，无缝对接下午紧张工作。", "今日 12:15 - 12:45", false, 0),
        GymClass("class_p_3", "拳击对抗入门体验", "boxing", "向飞 / Felix Xiang", 50, "基础训练者", "搏击专区", 10, 0, "拳击手套, 沙袋", "学习刺拳、摆拳及步伐移动，配合手靶互动，不仅高燃脂，而且极具自卫实用性。", "今日 18:30 - 19:20", false, 1),
        GymClass("class_p_4", "力量举三大项突破", "strength", "保罗 / Paul Becker", 60, "进阶训练者", "专业举重区", 8, 3, "专业杠铃", "硬核深蹲、卧推、硬拉技巧纠正，寻找你的1RM杠铃轨迹与腹压控制。", "明日 19:00 - 20:00", false, 0),

        // 晶体健身·深圳湾 (gym_shenzhen)
        GymClass("class_s_1", "智能划船机：极速红线", "cycling", "张廷 / Tony Zhang", 45, "基础训练者", "水阻划船区", 12, 1, "智能划船机", "利用划船机进行高燃脂耐力心肺训练，实时竞速，打造宽广健硕的后侧链。", "今日 19:30 - 20:15", false, 0),
        GymClass("class_s_2", "杠铃操：局部速塑", "strength", "郑勋 / Sean Zheng", 45, "初学者", "多功能操房", 25, 9, "哑铃, 小杠铃", "低负重、高次数的全身肌肉力量耐力训练，伴随电音节拍雕琢每一寸身体线条。", "明日 12:15 - 13:00", false, 0),
        GymClass("class_s_3", "壶铃爆发力与功能链", "functional", "张廷 / Tony Zhang", 45, "基础训练者", "多功能操房", 15, 6, "壶铃", "荡铃、抓举、挺举，通过非稳定偏心重力挑战，重构强悍全身弹力肌肉链。", "周四 19:00 - 19:45", false, 0),

        // 晶体健身·杭州滨江
        GymClass("class_hz_1", "高燃脂动感单车：霓虹风暴", "cycling", "林舒雅 / Maya Lin", 45, "初学者", "电单房", 25, 8, "动感单车", "极具科技感的未来视觉投影骑行，通过高能间歇重塑腿部肌肉与心肺泵血。", "今日 19:00 - 19:45", false, 0),
        GymClass("class_hz_2", "全身舒缓拉伸与泡沫轴放松", "mobility", "顾宁 / Ning Gu", 45, "初学者", "柔韧舒缓房", 15, 4, "泡沫轴, 阻力带", "打碎局部黏连，梳理肌肉纹路，促进淋巴与血液循环，极速扫清身体疲惫感。", "今日 20:15 - 21:00", false, 0),

        // 晶体健身·成都太古里
        GymClass("class_cd_1", "太古里热辣塑形操", "HIIT", "陈嘉豪 / Jack Chen", 45, "初学者", "热辣舞蹈室", 20, 2, "自重", "将潮流舞蹈与健身操相结合，热烈欢快，高燃脂的同时展现自信身形姿态。", "今日 19:30 - 20:15", false, 0),
        GymClass("class_cd_2", "体势矫正与脊柱物理舒缓", "mobility", "沈清 / Clara Shen", 50, "初学者", "静心空间", 12, 1, "普拉提球, 阻力圈", "改善含胸驼背、脊柱侧弯代偿、骨盆前倾，重建骨骼架构最合理的受力状态。", "今日 20:30 - 21:20", false, 0),
        GymClass("class_cd_3", "终极越野体能：心肺拉爆", "functional", "张廷 / Tony Zhang", 50, "进阶训练者", "多功能操房", 15, 5, "药球, 划船机", "模拟野外恶劣环境障碍的极限综合体能，极速榨干最后一丝肌肉糖原。", "明日 18:30 - 19:20", false, 0)
    )

    val equipments = listOf(
        Equipment("eq_1", "1号智能跑步机", "TREADMILL", "晶体智能 / Jingtian Smart", "JT-Runner 500", "有氧区", "OPERATIONAL", 1250, 2000, "2026-09-01", "2026-10-01", 85.5, 350.0, 12.0, 10.0, 0, 0.0, 135, emptyList()),
        Equipment("eq_2", "2号智能跑步机", "TREADMILL", "晶体智能 / Jingtian Smart", "JT-Runner 500", "有氧区", "IN_USE", 1120, 2000, "2026-09-01", "2026-10-01", 72.3, 420.0, 14.5, 4.0, 0, 0.0, 155, listOf("2026-08-15: 坡度电机轻微抖动已校准")),
        Equipment("eq_3", "3号智能跑步机", "TREADMILL", "晶体智能 / Jingtian Smart", "JT-Runner 500", "有氧区", "MAINTENANCE", 1680, 2000, "2026-08-20", "2026-09-20", 91.2, 0.0, 0.0, 0.0, 0, 0.0, 0, listOf("2026-09-18: 跑带偏移警报已报修，等待更换配件")),
        Equipment("eq_4", "1号智能动感单车", "BIKE", "晶体智能 / Jingtian Smart", "JT-Spin 300", "有氧区", "IN_USE", 920, 1500, "2026-09-05", "2026-10-05", 68.4, 210.0, 35.0, 0.0, 0, 24.0, 128, emptyList()),
        Equipment("eq_5", "2号智能动感单车", "BIKE", "晶体智能 / Jingtian Smart", "JT-Spin 300", "有氧区", "RESERVED", 880, 1500, "2026-09-05", "2026-10-05", 55.2, 0.0, 0.0, 0.0, 0, 0.0, 0, emptyList()),
        Equipment("eq_6", "1号智能划船机", "ROWER", "Concept2 / 晶体智联", "JT-Row Concept", "有氧区", "OPERATIONAL", 640, 1000, "2026-09-10", "2026-10-10", 41.5, 0.0, 0.0, 0.0, 0, 6.0, 0, emptyList()),
        Equipment("eq_7", "1号智能深蹲架", "SQUAT_RACK", "Eleiko / 晶体智联", "JT-Power Rack Max", "自由力量区", "IN_USE", 1450, 3000, "2026-08-15", "2026-11-15", 94.0, 0.0, 0.0, 0.0, 8, 140.0, 0, emptyList()),
        Equipment("eq_8", "2号智能深蹲架", "SQUAT_RACK", "Eleiko / 晶体智联", "JT-Power Rack Max", "自由力量区", "OPERATIONAL", 1210, 3000, "2026-08-15", "2026-11-15", 81.2, 0.0, 0.0, 0.0, 0, 0.0, 0, emptyList()),
        Equipment("eq_9", "1号智能大飞鸟", "CABLE", "晶体智能 / Jingtian Smart", "JT-Cable-80", "力量区", "IN_USE", 1110, 2000, "2026-09-01", "2026-10-01", 78.5, 0.0, 0.0, 0.0, 12, 45.0, 115, emptyList()),
        Equipment("eq_10", "1号智能腿部推蹬机", "LEG_PRESS", "晶体智能 / Jingtian Smart", "JT-Leg Press 3G", "力量区", "OPERATIONAL", 890, 2000, "2026-09-02", "2026-11-02", 52.1, 0.0, 0.0, 0.0, 0, 0.0, 0, emptyList()),
        Equipment("eq_11", "1号智能胸肌推举机", "CHEST_PRESS", "晶体智能 / Jingtian Smart", "JT-Chest Press 2", "力量区", "OPERATIONAL", 760, 2000, "2026-09-02", "2026-11-02", 48.0, 0.0, 0.0, 0.0, 0, 0.0, 0, emptyList()),
        Equipment("eq_12", "1号智能哑铃架", "DUMBBELLS", "晶体智能 / Jingtian Smart", "JT-Dumbbell 24kg", "自由力量区", "OPERATIONAL", 2100, 5000, "2026-05-10", "2026-11-10", 98.5, 0.0, 0.0, 0.0, 15, 12.0, 110, emptyList()),
        Equipment("eq_13", "1号3D体测仪", "BODY_COMP", "晶体智能 / Jingtian Smart", "JT-Assessment Lab 3D", "体测区", "OPERATIONAL", 320, 1000, "2026-09-12", "2026-12-12", 30.5, 0.0, 0.0, 0.0, 0, 0.0, 0, emptyList()),
        Equipment("eq_14", "3号智能动感单车", "BIKE", "晶体智能 / Jingtian Smart", "JT-Spin 300", "有氧区", "OFFLINE", 990, 1500, "2026-09-05", "2026-10-05", 58.0, 0.0, 0.0, 0.0, 0, 0.0, 0, listOf("2026-09-19: 蓝牙连接模组通讯异常")),
        Equipment("eq_15", "2号智能划船机", "ROWER", "Concept2 / 晶体智联", "JT-Row Concept", "有氧区", "OPERATIONAL", 580, 1000, "2026-09-10", "2026-10-10", 35.8, 0.0, 0.0, 0.0, 0, 0.0, 0, emptyList())
    )

    val workoutTemplates = listOf(
        Workout("w_temp_1", "晶体下肢力量突破计划", "Build Strength", 60, listOf(
            WorkoutExercise("ex_squat", "杠铃背蹲", "Barbell Back Squat", "力量训练", listOf(WorkoutSet(1, 60.0, 10), WorkoutSet(2, 80.0, 8), WorkoutSet(3, 90.0, 6), WorkoutSet(4, 100.0, 5))),
            WorkoutExercise("ex_leg_press", "45度倒蹬", "Leg Press", "力量训练", listOf(WorkoutSet(1, 120.0, 12), WorkoutSet(2, 160.0, 10), WorkoutSet(3, 200.0, 8))),
            WorkoutExercise("ex_lunge", "哑铃箭步蹲", "Dumbbell Lunge", "力量训练", listOf(WorkoutSet(1, 15.0, 10), WorkoutSet(2, 15.0, 10), WorkoutSet(3, 20.0, 8))),
            WorkoutExercise("ex_stretching", "静态拉伸恢复", "Static Stretching Recovery", "灵活性与恢复", listOf(WorkoutSet(1, 0.0, 1)))
        ), isTemplate = true),
        Workout("w_temp_2", "晶体胸背拉推机能突破", "Build Strength", 50, listOf(
            WorkoutExercise("ex_bench_press", "杠铃卧推", "Barbell Bench Press", "力量训练", listOf(WorkoutSet(1, 40.0, 12), WorkoutSet(2, 50.0, 10), WorkoutSet(3, 60.0, 8), WorkoutSet(4, 70.0, 6))),
            WorkoutExercise("ex_row", "杠铃俯身划船", "Barbell Bent Over Row", "力量训练", listOf(WorkoutSet(1, 40.0, 10), WorkoutSet(2, 50.0, 10), WorkoutSet(3, 55.0, 8))),
            WorkoutExercise("ex_push_up", "标准俯卧撑", "Push-Up", "功能训练", listOf(WorkoutSet(1, 0.0, 15), WorkoutSet(2, 0.0, 12), WorkoutSet(3, 0.0, 12)))
        ), isTemplate = true),
        Workout("w_temp_3", "20分钟极致有氧爆汗", "Improve Endurance", 30, listOf(
            WorkoutExercise("ex_treadmill", "智能跑步机跑步", "Smart Treadmill Running", "有氧训练", listOf(WorkoutSet(1, 0.0, 1))),
            WorkoutExercise("ex_interval", "高强度间歇训练", "HIIT Interval Training", "有氧训练", listOf(WorkoutSet(1, 0.0, 4))),
            WorkoutExercise("ex_breathing", "膈肌深呼吸冥想", "Diaphragmatic Breathing", "灵活性与恢复", listOf(WorkoutSet(1, 0.0, 1)))
        ), isTemplate = true),
        Workout("w_temp_4", "后侧链与下肢平衡雕琢", "Improve Mobility", 45, listOf(
            WorkoutExercise("ex_romanian_dl", "罗马尼亚硬拉", "Romanian Deadlift", "力量训练", listOf(WorkoutSet(1, 40.0, 12), WorkoutSet(2, 50.0, 10), WorkoutSet(3, 60.0, 10))),
            WorkoutExercise("ex_kb_swing", "壶铃摇摆", "Kettlebell Swing", "功能训练", listOf(WorkoutSet(1, 16.0, 15), WorkoutSet(2, 20.0, 15), WorkoutSet(3, 24.0, 12))),
            WorkoutExercise("ex_mobility_flow", "髋关节活动度流", "Hip Mobility Flow", "灵活性与恢复", listOf(WorkoutSet(1, 0.0, 2)))
        ), isTemplate = true),
        Workout("w_temp_5", "核心抗旋转与功能健硕", "Build Strength", 45, listOf(
            WorkoutExercise("ex_trx_row", "TRX悬吊划船", "TRX Suspension Row", "功能训练", listOf(WorkoutSet(1, 0.0, 12), WorkoutSet(2, 0.0, 12), WorkoutSet(3, 0.0, 10))),
            WorkoutExercise("ex_med_slam", "药球砸地", "Medicine Ball Slam", "功能训练", listOf(WorkoutSet(1, 8.0, 12), WorkoutSet(2, 10.0, 12), WorkoutSet(3, 10.0, 10))),
            WorkoutExercise("ex_band_row", "阻力带划船", "Resistance Band Row", "功能训练", listOf(WorkoutSet(1, 15.0, 15), WorkoutSet(2, 20.0, 15)))
        ), isTemplate = true),
        // Additional mock plans to make exactly 10 plans
        Workout("w_temp_6", "初学者全身适应训练", "Learn Technique", 40, listOf(
            WorkoutExercise("ex_push_up", "标准俯卧撑", "Push-Up", "功能训练", listOf(WorkoutSet(1, 0.0, 10))),
            WorkoutExercise("ex_lunge", "哑铃箭步蹲", "Dumbbell Lunge", "力量训练", listOf(WorkoutSet(1, 5.0, 10)))
        ), isTemplate = true),
        Workout("w_temp_7", "马拉松跑者专项耐力训练", "Improve Endurance", 75, listOf(
            WorkoutExercise("ex_treadmill", "智能跑步机跑步", "Smart Treadmill Running", "有氧训练", listOf(WorkoutSet(1, 0.0, 1)))
        ), isTemplate = true),
        Workout("w_temp_8", "肩袖强化与体态纠正", "Improve Mobility", 30, listOf(
            WorkoutExercise("ex_band_row", "阻力带划船", "Resistance Band Row", "功能训练", listOf(WorkoutSet(1, 10.0, 15))),
            WorkoutExercise("ex_foam_rolling", "泡沫轴全身筋膜放松", "Foam Rolling SMR", "灵活性与恢复", listOf(WorkoutSet(1, 0.0, 1)))
        ), isTemplate = true),
        Workout("w_temp_9", "奥林匹克举重爆发拉力训练", "Build Strength", 50, listOf(
            WorkoutExercise("ex_deadlift", "杠铃硬拉", "Barbell Deadlift", "力量训练", listOf(WorkoutSet(1, 100.0, 5)))
        ), isTemplate = true),
        Workout("w_temp_10", "高效率午间办公室激活", "Improve General Health", 20, listOf(
            WorkoutExercise("ex_mobility_flow", "髋关节活动度流", "Hip Mobility Flow", "灵活性与恢复", listOf(WorkoutSet(1, 0.0, 1)))
        ), isTemplate = true)
    )

    // Generate exactly 100 historical workout records programmatically
    val workoutRecords: List<WorkoutRecord> = run {
        val list = mutableListOf<WorkoutRecord>()
        val exercisePool = exercises
        val names = listOf("晶体硬核臀腿突破", "上肢推拉功能构建", "心肺红线智能有氧", "深层核心抗旋转强化", "全身功能体能轰炸")
        val notesList = listOf("状态极佳，能量饱满", "稍微有点疲惫，动作细节抓得很好", "左膝微酸，稍微降低了最大负荷", "大汗淋漓，核心酸胀感十分强烈", "拉伸非常彻底，舒展度不错")
        for (i in 1..100) {
            val date = java.time.LocalDate.now().minusDays(i.toLong()).toString()
            val name = names[i % names.size] + " #${101-i}"
            val duration = 40 + (i % 5) * 5
            val recExercises = mutableListOf<WorkoutRecordExercise>()
            val selectedCount = 2 + (i % 3)
            for (j in 0 until selectedCount) {
                val ex = exercisePool[(i + j * 7) % exercisePool.size]
                val sets = (1..3).map { s ->
                    WorkoutRecordSet(s, weightKg = if (ex.category == "力量训练") 40.0 + (i % 8) * 10.0 else 0.0, reps = 8 + (s + i) % 5, isCompleted = true)
                }
                recExercises.add(WorkoutRecordExercise(ex.id, ex.nameZh, ex.nameEn, ex.category, sets))
            }
            val totalReps = recExercises.sumOf { e -> e.sets.sumOf { s -> s.reps } }
            val totalVolume = recExercises.sumOf { e -> e.sets.sumOf { s -> s.weightKg * s.reps } }
            val calories = duration * 6 + (i % 10) * 15

            list.add(
                WorkoutRecord(
                    id = "rec_$i",
                    workoutName = name,
                    durationMinutes = duration,
                    exercises = recExercises,
                    totalVolumeKg = totalVolume,
                    totalReps = totalReps,
                    caloriesBurned = calories,
                    date = date,
                    notes = notesList[i % notesList.size]
                )
            )
        }
        list
    }

    // Generate exactly 30 community posts
    val communityPosts: List<CommunityPost> = run {
        val list = mutableListOf<CommunityPost>()
        val authors = listOf("林哲 / Lin Zhe", "徐嘉怡 / Sherry Xu", "张伟 / David Zhang", "陈美玲 / May Chen", "王浩 / Leo Wang", "李娜 / Nana Li", "向飞 / Felix Xiang", "韩莉 / Lily Han")
        val contentPool = listOf(
            "今天在静安中心刷了100kg背蹲！果然早起训练的人最多，大飞鸟都要排队了，2026年了智能设备秒同步太棒了！#力量训练 #精进体能",
            "林舒雅老师的HIIT操课真的爽爆，45分钟榨干卡路里！极速暴汗的解压神器，姐妹们赶紧冲！#极速燃脂 #写字楼白领",
            "打卡杭州滨江店。这里的江景真是无敌，智能划船机模拟现实竞速，我竟然拿到了周排行榜第一！#划船挑战 #心肺红线",
            "静心瑜伽身心放松，在韩莉老师的颂钵声里躺平的半小时，把上周熬夜的紧张感一扫而空，强烈安利给睡眠不好的朋友！#流瑜伽 #身心修复",
            "今天来体测中心做了3D体质检测。体脂率从24%稳步降到了21.5%，核心肌群力量测试评分获得了Excellent！努力真的看得见！#体测中心 #真实记录",
            "杠铃俯身划船，大重量下总觉得腰部代偿，今天听了Ray教练的建议，收紧腹横肌并臀部向后平移，果然背阔肌抓握感爆棚！#训练技巧 #力量突破"
        )
        val categories = listOf("力量训练", "有氧训练", "拉伸恢复", "功能训练", "健身房讨论", "健康烹饪")
        val initialComments = listOf(
            CommunityComment("王浩 / Leo Wang", "大佬好牛！100kg卧槽，我还在蹲自重", "2026-09-18 20:15"),
            CommunityComment("徐嘉怡 / Sherry Xu", "真的！Maya老师那节课我也 booked 了！下次一起！", "2026-09-18 21:00"),
            CommunityComment("高瑞 / Ray Gao", "下放的时候注意膝盖不要内扣，杠铃轨迹很漂亮，加油！", "2026-09-18 21:30")
        )

        for (i in 1..30) {
            val author = authors[i % authors.size]
            val content = contentPool[i % contentPool.size] + " (模拟社交圈第 $i 条分享)"
            val cat = categories[i % categories.size]
            val likes = 12 + i * 4
            val saves = 2 + i
            list.add(
                CommunityPost(
                    id = "post_$i",
                    authorName = author,
                    authorAvatarUrl = "https://example.com/avatar_member.png",
                    content = content,
                    category = cat,
                    likes = likes,
                    commentsCount = initialComments.size + (i % 3),
                    saves = saves,
                    isLiked = i % 3 == 0,
                    isSaved = i % 4 == 0,
                    timestamp = "1天前",
                    comments = if (i % 2 == 0) initialComments else emptyList()
                )
            )
        }
        list
    }

    // Generate exactly 12 store products
    val products = listOf(
        Product("prod_1", "晶体极速训练排汗衫 (Graphite Gray)", 199.0, "APPAREL", "精选纳米透气纤维，贴合身形，腋下蜂窝速干区域设计，专为大负荷运动而生。", 120, 4.8, listOf("S", "M", "L", "XL")),
        Product("prod_2", "晶体软混凝土缓震重能鞋", 599.0, "APPAREL", "复合碳板中底抗扭转，微宽楦头提供极限侧向摩擦，深蹲与跑步兼顾的双效体能鞋。", 45, 4.9, listOf("39", "40", "41", "42", "43", "44")),
        Product("prod_3", "晶体负重阻力带套装 (5级张力)", 89.0, "EQUIPMENT", "天然乳胶多阻力组合，附赠便携尼龙网袋。从5磅到50磅，理疗与核心进阶必备。", 250, 4.7, listOf("标准款")),
        Product("prod_4", "晶体智能可调节哑铃 (2.5kg - 24kg)", 899.0, "EQUIPMENT", "单只快调齿轮结构，内置蓝牙姿态感应芯片，动作轨迹秒速传输，支持模拟连接。", 15, 5.0, listOf("单只装", "双只尊享装")),
        Product("prod_5", "晶体3D高密度泡沫按摩轴", 79.0, "ACCESSORIES", "点阵扳机点深度按压，高弹EVA材质不塌陷。适合大运动负荷筋膜松弛和理疗放松。", 180, 4.6, listOf("暗夜黑", "翡翠绿")),
        Product("prod_6", "晶体智联真空防汗水杯 (800ml)", 129.0, "ACCESSORIES", "食品级316不锈钢，一体式瓶盖拉环，磨砂涂层防手滑，长效保温保冷。", 300, 4.8, listOf("晶体红", "太空灰")),
        Product("prod_7", "晶体大容量抗撕裂多功能健身包", 249.0, "ACCESSORIES", "独立干湿分离隔层与侧置透气鞋舱，50L黄金容量，防泼水尼龙，出差健身一包搞定。", 85, 4.9, listOf("经典灰", "先锋黑")),
        Product("prod_8", "专业硬核力量加压牛皮腰带 (10mm)", 299.0, "EQUIPMENT", "精选整张头层牛皮，不锈钢杠杆锁扣扣，为极限深蹲、硬拉提供强硬的腹压支撑。", 30, 4.9, listOf("M (腰围70-85)", "L (腰围80-95)")),
        Product("prod_9", "晶体智联运动心率手环 placeholder", 199.0, "EQUIPMENT", "高精度心率追踪与血氧监控，专为智能设备模拟同步打造。不作临床诊断用。", 95, 4.5, listOf("标准黑色")),
        Product("prod_10", "防滑超宽排汗吸水健身毛巾", 49.0, "ACCESSORIES", "冷感超细纤维，瞬间吸汗5倍，尺寸100x30cm，完美覆盖力量训练座椅椅背。", 500, 4.7, listOf("火山灰", "曜石黑")),
        Product("prod_11", "晶体低卡纯正浓缩乳清蛋白粉 placeholder", 329.0, "ACCESSORIES", "75%高纯乳清蛋白，富含BCAA，每份含24g蛋白，极易冲匀吸收。不作代餐处方用。", 60, 4.6, listOf("香草味", "巧克力味")),
        Product("prod_12", "极简高弹瑜伽长裤 (Soft Skin)", 229.0, "APPAREL", "裸感黄油亲肤材质，四向拉伸不卡裆，高腰提臀，适合瑜伽、普拉提和跑步耐力。", 140, 4.8, listOf("S", "M", "L"))
    )

    // Generate exactly 8 facility requests
    val facilityRequests = listOf(
        FacilityRequest("req_1", "智能更衣柜分配", "042号更衣柜", "COMPLETED", "2026-09-19 07:15", "已完成", "更衣柜密码锁已自动重置，更衣柜042已成功绑定您的会员码。"),
        FacilityRequest("req_2", "干净毛巾申请", "大号吸水巾 x1", "COMPLETED", "2026-09-19 08:30", "已完成", "大号吸水毛巾已发放到您的自提格，请凭会员码扫码开格。"),
        FacilityRequest("req_3", "直饮水过滤状态查询", "有氧区直饮水站", "COMPLETED", "2026-09-19 10:00", "已完成", "直饮水过滤滤芯今天清晨已完成巡检维护，水质净化率100%，请放心饮用。"),
        FacilityRequest("req_4", "淋浴房空余查询", "静安中心男更衣室", "IN_PROGRESS", "2026-09-19 11:45", "5分钟", "当前淋浴房使用率 4/6，仍有2间空置，保洁人员已完成日常消毒。"),
        FacilityRequest("req_5", "器械清洁呼叫", "2号智能跑步机", "ACKNOWLEDGED", "2026-09-19 12:10", "3分钟", "已通知静安店区域保洁，将立即前往对2号智能跑步机显示屏和跑带进行二次消毒。"),
        FacilityRequest("req_6", "设备维护上报", "4号史密斯架缆绳轻微断股", "SUBMITTED", "2026-09-19 12:30", "2小时", "感谢您的反馈！设备报修已录入工单，工程人员将在下午非高峰期对缆绳进行安全更换。"),
        FacilityRequest("req_7", "遗失物品寻回", "遗失灰色智联水杯", "ACKNOWLEDGED", "2026-09-19 13:00", "正在排查", "前台已收到您的失物申请，正在核对前台遗留和巡检拾取箱，稍后有结果系统通知您。"),
        FacilityRequest("req_8", "场馆空气净化反馈", "静安中心大团课操房", "COMPLETED", "2026-09-18 19:15", "已完成", "反馈已收到。多联新风净化器档位已从自动档提升至强风档，负氧离子浓度恢复至1200/cm³。")
    )

    // Generate exactly 6 challenges
    val challenges = listOf(
        Challenge("ch_1", "30天持之以恒挑战", "30-DAY CONSISTENCY: 30天内完成12次健身房入场打卡或训练记录，养成卓越习惯。", "CONSISTENCY", 12.0, 5.0, 1845, listOf("完成3次", "完成6次", "完成9次", "完成12次"), "晶体恒心金质徽章", true, 41),
        Challenge("ch_2", "城市硬核跑步挑战", "CITY RUNNING: 累积完成 50km 的智能跑步机或户外自传跑步里程，感受城市律动。", "CARDIO", 50.0, 15.6, 920, listOf("10km 破冰", "25km 节点", "50km 巅峰"), "风影速行电子跑鞋徽章", false, 31),
        Challenge("ch_3", "力量基石深蹲突破", "STRENGTH FOUNDATIONS: 累计完成 150 组杠铃复合背蹲或力量力量训练，夯实深蹲姿势。", "STRENGTH", 150.0, 45.0, 560, listOf("30 组起步", "75 组精熟", "150 组卓越"), "大地坚壁深蹲大师勋章", true, 30),
        Challenge("ch_4", "灵活性全面提升周", "MOBILITY WEEK: 连续7天内打卡5次泡沫轴放松、拉伸恢复或髋部活动度操课。", "MOBILITY", 5.0, 2.0, 1250, listOf("1次尝鲜", "3次进阶", "5次圆满"), "流水游龙灵动勋章", false, 40),
        Challenge("ch_5", "社群热辣操课达人", "COMMUNITY TRAINING: 累积参加 3 节团体操课（如 HIIT、单车或流瑜伽），感受社群力量。", "CONSISTENCY", 3.0, 1.0, 780, listOf("1节融入", "3节核心"), "晶体共振星光勋章", true, 33),
        Challenge("ch_6", "划船心肺耐久风暴", "ROWER ENDURANCE: 划船机单次挑战累积划行 10000 米，锻炼强悍的后背拉力和心肺储备。", "CARDIO", 10000.0, 0.0, 240, listOf("2000米", "5000米", "10000米"), "激浪争先电子金色划桨徽章", false, 0)
    )

    // Generate exactly 20 notifications
    val notifications = listOf(
        AppNotification("not_1", "操课预约成功通知", "您已成功预约今日19:00的【晶体极速燃脂 HIIT - 静安中心】，请于开课前10分钟凭入场码签到，期待您的汗水！", "10分钟前"),
        AppNotification("not_2", "私教课程确认提醒", "您的专属教练 Ray Gao 已确认您明日15:00的【力量举三大项专项评估】私教课预约，请准时入场。", "1小时前"),
        AppNotification("not_3", "会员资格智能自动续费成功", "【晶体健身·极速月卡】扣款成功。新一期会员有效期已延长至 2026-10-19，感谢您对晶体健身的信任！", "今天清晨"),
        AppNotification("not_4", "体测数据报告已生成", "您于2026-09-19 10:00在静安店3D体测仪完成的数据报告已入库。体脂、骨骼肌、围度及力量评估趋势已更新，可前往“体测中心”查看。", "1小时前"),
        AppNotification("not_5", "更衣柜分配完成通知", "您的 042号更衣柜 已为您成功锁定，更衣柜密码：【881223】。请妥善保存，储物柜仅限今日营业期内使用。", "5分钟前"),
        AppNotification("not_6", "新品上架专属优惠券", "您有一张【商场满200减20】代金券已到账，适用于最新款晶体高密度泡沫轴和排汗衫！赶紧去“健身商城”看看吧！", "1天前"),
        AppNotification("not_7", "挑战进度阶段性达成", "恭喜您！在【30天持之以恒挑战】中已累积完成第 5 次健身房签到，达成“初试身手”里程碑，离金质勋章更近一步！", "1天前"),
        AppNotification("not_8", "场馆人流高峰预警", "系统检测到上海静安中心当前入场饱和度达 85%，力量区和有氧跑步机排队指数较高。建议前往“浦东店”或避开当前时段。", "2小时前"),
        AppNotification("not_9", "私教老师的专属叮嘱", "Maya Lin 教练给您发来一条悄悄话：“小哲，今天看你体测小腿部分微紧，今晚大负荷训练后，务必在泡沫轴上把腘绳肌和小腿滚压5分钟哦！”", "3小时前"),
        AppNotification("not_10", "社群评论被点赞通知", "您在社群发布的动态《硬拉终于突破140kg啦！》被 进阶训练者 David Zhang 点赞了！“干得漂亮，动作非常教科书！”", "5小时前"),
        AppNotification("not_11", "社群新回复提醒", "Minnie Zhao 在您的发帖下回复了：“想问一下护腰带是什么牌子的呀？看着支撑性很好！”", "8小时前"),
        AppNotification("not_12", "直饮水净化完毕公告", "小晶贴心播报：静安中心所有直饮水过滤滤芯均已在今晨 06:00 完成了精细化反冲洗与滤网更新，提供微甘泉水，运动务必多补水哦！", "今天清晨"),
        AppNotification("not_13", "操课排队候补成功", "好消息！因有会员取消，您已成功候补进入【哈他瑜伽·身心疗愈 - 静安中心】今日20:00课程，席位已自动为您锁定，祝您体验愉快！", "20分钟前"),
        AppNotification("not_14", "订单发货状态更新", "您在晶体商城购买的【可调节哑铃 24kg 经典灰】已由晶体同城极速达揽件发出，预计今晚19:00前送达您的收货地址，请注意查收。", "2小时前"),
        AppNotification("not_15", "设备故障上报确认", "您提交的“4号史密斯架缆绳轻微断股”报修已收悉。工程师已于10分钟前抵达现场拉起隔离线，保障会员安全，预计今天下午16:00前完成换缆。", "3小时前"),
        AppNotification("not_16", "月度运动账单发布", "您的 8月晶体运动分析账单 已发布！上月您共完成了 14次 训练，累计卡路里消耗 6500kcal，全上海静安中心同段位排名 Top 12%！", "3天前"),
        AppNotification("not_17", "防沉迷运动超负荷预警", "检测到您过去4天内高强度力量训练总负荷超出周安全均值15%，中枢神经疲劳风险中等。建议今晚安排“静态拉伸恢复”或干脆休息一天哦。", "1天前"),
        AppNotification("not_18", "晶体合伙人：积分商城升级", "晶体能量积分全面升级！您当前账户累积的 1250 积分已可免费兑换【晶体防汗吸水毛巾】。可前往我的会员页进行领取。", "4天前"),
        AppNotification("not_19", "新春场馆营业时间调整", "因晶体商场大楼管道维护，杭州滨江店将于 2026-09-22 凌晨 01:00 - 05:00 暂停营业4小时，有氧和更衣室区域新风全面消毒。", "5天前"),
        AppNotification("not_20", "私教预约变更确认", "您的周日私教预约时间因教练培训已调整至 周日 16:00， Ray Gao 教练深表歉意，并赠送您 50 晶体能量积分作为补偿，请悉知。", "1天前")
    )

    val events = listOf(
        LiveEvent("ev_1", "静安白领晨跑破冰跑", "2026-09-20 07:00", "上海静安公园正门 - 5km 沿线", 50, "晶体跑步俱乐部", "初学者", "NOT_REGISTERED", 18),
        LiveEvent("ev_2", "三大项力量举极限技术坊", "2026-09-21 14:00", "晶体健身·浦东金融城专业区", 20, "高瑞 / Ray Gao", "进阶训练者", "REGISTERED", 15),
        LiveEvent("ev_3", "秋季颂钵睡眠瑜伽千人冥想", "2026-09-22 19:30", "上海中心天际云端观光层", 100, "韩莉 / Lily Han", "初学者", "NOT_REGISTERED", 84),
        LiveEvent("ev_4", "滨江极速单车霓虹狂欢夜", "2026-09-23 19:00", "晶体健身·杭州滨江动感单车房", 30, "林舒雅 / Maya Lin", "基础训练者", "NOT_REGISTERED", 22),
        LiveEvent("ev_5", "药球砸地解压挑战赛", "2026-09-24 12:15", "晶体健身·深圳湾多功能区", 40, "向飞 / Felix Xiang", "初学者", "NOT_REGISTERED", 11),
        LiveEvent("ev_6", "奥林匹克举重轨迹分解大师课", "2026-09-25 15:00", "晶体健身·成都太古里硬核区", 15, "Paul Becker", "进阶训练者", "NOT_REGISTERED", 8),
        LiveEvent("ev_7", "城市公益绿色净滩体能跑", "2026-09-26 08:30", "深圳人才公园海岸线 - 8km", 120, "晶体绿色行者", "基础训练者", "NOT_REGISTERED", 45),
        LiveEvent("ev_8", "秋分核心控床普拉提专项体势纠正", "2026-09-27 10:00", "晶体健身·静安中心普拉提房", 8, "沈清 / Clara Shen", "基础训练者", "NOT_REGISTERED", 6)
    )

    val bodyAssessments = listOf(
        FitnessAssessment(
            id = "ass_1",
            date = "2026-09-19",
            heightCm = 178.5,
            weightKg = 74.2,
            bodyFatPercentage = 16.2,
            muscleMassKg = 36.5,
            visceralFatLevel = 6,
            waterPercentage = 60.5,
            restingHeartRate = 62,
            flexibilityScore = "良好 (Good)",
            strengthTests = mapOf("深蹲" to "110kg", "卧推" to "85kg", "硬拉" to "140kg", "推举" to "55kg"),
            mobilityObservations = "髋关节深蹲深度达到水平面以下，脚踝背屈活动度良好。右肩前束轻微内旋（电脑久坐圆肩代偿）。",
            enduranceMinutes = 48,
            confidenceLevel = "3D双能X射线吸收检测(DEXA级模拟)",
            notes = "肌肉对称度良好。左小腿比右小腿肌肉量微少0.2kg。由于轻微左膝膝盖磨损，硬拉和深蹲起杠时务必收紧核心，保证力传导对称。"
        ),
        FitnessAssessment(
            id = "ass_2",
            date = "2026-08-19",
            heightCm = 178.5,
            weightKg = 75.8,
            bodyFatPercentage = 17.5,
            muscleMassKg = 35.8,
            visceralFatLevel = 7,
            waterPercentage = 59.2,
            restingHeartRate = 64,
            flexibilityScore = "中等 (Medium)",
            strengthTests = mapOf("深蹲" to "100kg", "卧推" to "80kg", "硬拉" to "130kg", "推举" to "50kg"),
            mobilityObservations = "髋关节深屈时膝关节轻微内扣，肩关节上举活动度受限。",
            enduranceMinutes = 42,
            confidenceLevel = "3D体测仪初筛",
            notes = "过去一个月体脂下降1.3%，骨骼肌上升0.7kg。心肺耐力也有显著改善。坚持Ray Gao教练的臀腿复合突破计划，成果显著。"
        )
    )

    val initialActiveWorkout = Workout(
        id = "w_active",
        name = "林哲·今日推荐：下肢力量与核心雕琢",
        objective = "Build Strength",
        durationMinutes = 60,
        exercises = listOf(
            WorkoutExercise("ex_squat", "杠铃背蹲", "Barbell Back Squat", "力量训练", listOf(
                WorkoutSet(1, 60.0, 10, false),
                WorkoutSet(2, 80.0, 8, false),
                WorkoutSet(3, 95.0, 6, false),
                WorkoutSet(4, 100.0, 5, false)
            )),
            WorkoutExercise("ex_lunge", "哑铃箭步蹲", "Dumbbell Lunge", "力量训练", listOf(
                WorkoutSet(1, 15.0, 10, false),
                WorkoutSet(2, 15.0, 10, false),
                WorkoutSet(3, 20.0, 8, false)
            )),
            WorkoutExercise("ex_kb_swing", "壶铃摇摆", "Kettlebell Swing", "功能训练", listOf(
                WorkoutSet(1, 16.0, 15, false),
                WorkoutSet(2, 20.0, 12, false)
            )),
            WorkoutExercise("ex_stretching", "静态拉伸恢复", "Static Stretching Recovery", "灵活性与恢复", listOf(
                WorkoutSet(1, 0.0, 1, false)
            ))
        )
    )
}
