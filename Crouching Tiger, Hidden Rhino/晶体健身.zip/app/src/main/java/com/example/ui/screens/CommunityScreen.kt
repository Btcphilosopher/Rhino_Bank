package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.state.FitnessViewModel
import com.example.ui.theme.ConcreteGrey
import com.example.ui.theme.DeepRed
import com.example.ui.theme.RestrainedJade
import com.example.ui.theme.SubtleAmber
import com.example.ui.theme.WarmWhite

@Composable
fun CommunityScreen(viewModel: FitnessViewModel) {
    val challenges by viewModel.challenges.collectAsState()
    val events by viewModel.events.collectAsState()
    val communityPosts by viewModel.communityPosts.collectAsState()

    var activeTab by remember { mutableStateOf("Social") } // "Social", "Challenges", "Events"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Screen Title
        Column {
            Text(
                text = "晶体社群空间",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = DeepRed,
                letterSpacing = 1.sp
            )
            Text(
                text = "同城竞技、操课预约与社群互动 / JINGTIAN COMMUNITY",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        // Horizontal navigation tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(4.dp)
        ) {
            TabButton(
                title = "社区分享广场",
                isActive = activeTab == "Social",
                modifier = Modifier.weight(1f),
                onClick = { activeTab = "Social" }
            )
            TabButton(
                title = "健身体验挑战",
                isActive = activeTab == "Challenges",
                modifier = Modifier.weight(1f),
                onClick = { activeTab = "Challenges" }
            )
            TabButton(
                title = "同城极速赛事",
                isActive = activeTab == "Events",
                modifier = Modifier.weight(1f),
                onClick = { activeTab = "Events" }
            )
        }

        when (activeTab) {
            "Social" -> {
                // Social square list
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .testTag("community_post_list"),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(communityPosts) { post ->
                        var isLiked by remember { mutableStateOf(false) }
                        var localLikesCount by remember { mutableStateOf(post.likes) }

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                // Author details
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(DeepRed.copy(alpha = 0.1f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = post.authorName.take(1),
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = DeepRed
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(post.authorName, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        Text(post.timestamp, fontSize = 9.sp, color = ConcreteGrey)
                                    }
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(MaterialTheme.colorScheme.surfaceVariant)
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(post.category, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = DeepRed)
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = post.content,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    lineHeight = 16.sp
                                )

                                Spacer(modifier = Modifier.height(12.dp))
                                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.05f))
                                Spacer(modifier = Modifier.height(8.dp))

                                // Social Actions Row
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.clickable {
                                            if (isLiked) {
                                                isLiked = false
                                                localLikesCount -= 1
                                            } else {
                                                isLiked = true
                                                localLikesCount += 1
                                            }
                                        }
                                    ) {
                                        Icon(
                                            if (isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                            contentDescription = "Like",
                                            tint = if (isLiked) DeepRed else ConcreteGrey,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("${localLikesCount} 赞", fontSize = 11.sp, color = ConcreteGrey)
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Comment, contentDescription = "Comment", tint = ConcreteGrey, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("${post.commentsCount} 评论", fontSize = 11.sp, color = ConcreteGrey)
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Share, contentDescription = "Share", tint = ConcreteGrey, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("分享", fontSize = 11.sp, color = ConcreteGrey)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            "Challenges" -> {
                // Interactive challenge cards with Join & progression trackers
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .testTag("challenges_list"),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(challenges) { ch ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(ch.title, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                        Text(ch.description, fontSize = 11.sp, color = ConcreteGrey, lineHeight = 14.sp)
                                    }
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(DeepRed.copy(alpha = 0.08f))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text("积分: +${if (ch.category == "STRENGTH") 300 else 150}", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = DeepRed)
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                if (ch.isJoined) {
                                    // Joined - render progress indicators
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("当前进度: ${ch.currentValue.toInt()}/${ch.targetValue.toInt()} ${if (ch.category == "CARDIO") "km" else "次"}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        Text("${ch.progressPercentage}%", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DeepRed)
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    LinearProgressIndicator(
                                        progress = ch.progressPercentage / 100f,
                                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                                        color = DeepRed,
                                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text("活动状态：挑战进行中，数据实时由手环及训练课回填。", fontSize = 10.sp, color = RestrainedJade, fontWeight = FontWeight.Bold)
                                } else {
                                    // Click to join
                                    Button(
                                        onClick = { viewModel.joinChallenge(ch.id) },
                                        colors = ButtonDefaults.buttonColors(containerColor = DeepRed),
                                        shape = RoundedCornerShape(4.dp),
                                        modifier = Modifier.fillMaxWidth().height(32.dp).testTag("btn_join_challenge_${ch.id}"),
                                        contentPadding = PaddingValues(0.dp)
                                    ) {
                                        Text("加入体验挑战并瓜分荣誉勋章", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            "Events" -> {
                // Interactive 同城赛事 lists with interactive registration buttons
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(events) { ev ->
                        val isRegistered = ev.registrationStatus == "REGISTERED"

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.08f))
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(ev.name, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(SubtleAmber.copy(alpha = 0.1f))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(ev.difficulty, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = SubtleAmber)
                                    }
                                }

                                Spacer(modifier = Modifier.height(4.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Text("时间: ${ev.date}", fontSize = 10.sp, color = ConcreteGrey)
                                    Text("地点: ${ev.venue}", fontSize = 10.sp, color = ConcreteGrey)
                                    Text("热度: ${ev.attendeesCount}人报名", fontSize = 10.sp, color = ConcreteGrey, fontWeight = FontWeight.Bold)
                                }

                                Spacer(modifier = Modifier.height(12.dp))
                                Button(
                                    onClick = { viewModel.toggleEventRegistration(ev.id) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isRegistered) RestrainedJade else DeepRed
                                    ),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.fillMaxWidth().height(32.dp).testTag("btn_register_event_${ev.id}"),
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Text(
                                        text = if (isRegistered) "✓ 已预约入场 (取消预约)" else "一键锁定席位",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
