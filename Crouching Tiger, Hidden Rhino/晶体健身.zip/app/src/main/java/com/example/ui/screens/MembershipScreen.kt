package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.state.FitnessViewModel
import com.example.ui.theme.ConcreteGrey
import com.example.ui.theme.DeepRed
import com.example.ui.theme.RestrainedJade
import com.example.ui.theme.SubtleAmber
import com.example.ui.theme.WarmWhite
import com.example.ui.theme.GraphiteDark
import com.example.ui.theme.GraphiteSurface
import kotlinx.coroutines.delay

@Composable
fun MembershipScreen(viewModel: FitnessViewModel) {
    val currentUser by viewModel.currentUser.collectAsState()
    val membership by viewModel.membership.collectAsState()

    var qrCodeToken by remember { mutableStateOf(100000 + (Math.random() * 899999).toInt()) }

    // Simulates QR Code refreshing every 10 seconds (security simulation)
    LaunchedEffect(Unit) {
        while (true) {
            delay(10000)
            qrCodeToken = 100000 + (Math.random() * 899999).toInt()
        }
    }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Screen Title
        Column {
            Text(
                text = "晶体会员中心",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = DeepRed,
                letterSpacing = 1.sp
            )
            Text(
                text = "电子入场凭证与资产权益 / MEMBERSHIP BARCODE",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        // Access Pass / QR Card Block
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.15f))
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "晶体数智空间通行码",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                Text(
                    text = "SUPPORT NFC SWIPE & BARCODE SIGN-IN",
                    color = Color.White.copy(alpha = 0.4f),
                    fontSize = 9.sp,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(18.dp))

                // Beautiful high-fidelity QR Code simulation
                Box(
                    modifier = Modifier
                        .size(160.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.White)
                        .padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        // Drawing static pattern representing an elegant high-end QR matrix
                        val strokeWidth = 3.dp.toPx()
                        drawRect(Color.Black, size = size.copy(width = 40.dp.toPx(), height = 40.dp.toPx()), style = Stroke(width = strokeWidth))
                        drawRect(Color.Black, size = size.copy(width = 20.dp.toPx(), height = 20.dp.toPx()), topLeft = androidx.compose.ui.geometry.Offset(10.dp.toPx(), 10.dp.toPx()))

                        drawRect(Color.Black, size = size.copy(width = 40.dp.toPx(), height = 40.dp.toPx()), topLeft = androidx.compose.ui.geometry.Offset(size.width - 40.dp.toPx(), 0f), style = Stroke(width = strokeWidth))
                        drawRect(Color.Black, size = size.copy(width = 20.dp.toPx(), height = 20.dp.toPx()), topLeft = androidx.compose.ui.geometry.Offset(size.width - 30.dp.toPx(), 10.dp.toPx()))

                        drawRect(Color.Black, size = size.copy(width = 40.dp.toPx(), height = 40.dp.toPx()), topLeft = androidx.compose.ui.geometry.Offset(0f, size.height - 40.dp.toPx()), style = Stroke(width = strokeWidth))
                        drawRect(Color.Black, size = size.copy(width = 20.dp.toPx(), height = 20.dp.toPx()), topLeft = androidx.compose.ui.geometry.Offset(10.dp.toPx(), size.height - 30.dp.toPx()))

                        // Decorative inner blocks
                        drawRect(Color.Black, size = size.copy(width = 15.dp.toPx(), height = 15.dp.toPx()), topLeft = androidx.compose.ui.geometry.Offset(size.width / 2 - 7.dp.toPx(), size.height / 2 - 7.dp.toPx()))
                        drawRect(Color.Black, size = size.copy(width = 25.dp.toPx(), height = 15.dp.toPx()), topLeft = androidx.compose.ui.geometry.Offset(size.width - 60.dp.toPx(), size.height - 50.dp.toPx()))
                        drawRect(Color.Black, size = size.copy(width = 15.dp.toPx(), height = 25.dp.toPx()), topLeft = androidx.compose.ui.geometry.Offset(50.dp.toPx(), size.height - 80.dp.toPx()))
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "动态密钥: $qrCodeToken (每10秒自动更新)",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                )
                Text(
                    text = "请向闸机扫描仪出示此码，或将手机贴近 NFC 感应区",
                    color = Color.White.copy(alpha = 0.6f),
                    fontSize = 10.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        // Assets and Credits Info Cards
        Text("我的会员权益与剩余额度 (Member Assets):", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ConcreteGrey)

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            CreditCard(title = "团操预约币", value = "${membership.classCredits}个", desc = "本月剩余", icon = Icons.Default.DirectionsRun, modifier = Modifier.weight(1f))
            CreditCard(title = "免费体验券", value = "${membership.guestPasses}张", desc = "邀请好友", icon = Icons.Default.CardGiftcard, modifier = Modifier.weight(1f))
        }

        // Additional Membership Operations
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.08f))
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("增值及卡片管理 (Card Management):", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ConcreteGrey)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { viewModel.renewMembership() },
                        colors = ButtonDefaults.buttonColors(containerColor = DeepRed),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(vertical = 4.dp)
                    ) {
                        Text("一键续期会员卡", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { /* Simulated action */ },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(vertical = 4.dp)
                    ) {
                        Text("办理停卡/请假", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
        }

        // Financial Invoice History Log
        Text("消费交易与电子发票账单 (Invoices & Receipts):", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ConcreteGrey)

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            InvoiceItemRow(title = "晶体极速月卡 - 会员充值 (模拟)", date = "2026-09-19 10:04", price = "¥399.00", status = "交易成功")
            InvoiceItemRow(title = "智能护膝 3D加强型 - 晶体特许商场 (模拟)", date = "2026-09-18 14:15", price = "¥128.00", status = "已开票")
            InvoiceItemRow(title = "晶体会员开卡礼 - 基础权益包 (模拟)", date = "2026-09-01 08:00", price = "¥0.00", status = "已完成")
        }
    }
}

@Composable
fun CreditCard(title: String, value: String, desc: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.08f))
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(DeepRed.copy(alpha = 0.06f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = DeepRed, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(title, fontSize = 10.sp, color = ConcreteGrey, fontWeight = FontWeight.SemiBold)
                Text(value, fontSize = 14.sp, fontWeight = FontWeight.Black, color = DeepRed)
                Text(desc, fontSize = 9.sp, color = ConcreteGrey)
            }
        }
    }
}

@Composable
fun InvoiceItemRow(title: String, date: String, price: String, status: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.05f))
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(date, fontSize = 9.sp, color = ConcreteGrey)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column(horizontalAlignment = Alignment.End) {
                Text(price, fontSize = 12.sp, fontWeight = FontWeight.Black, color = DeepRed)
                Text(status, fontSize = 9.sp, color = RestrainedJade, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}
