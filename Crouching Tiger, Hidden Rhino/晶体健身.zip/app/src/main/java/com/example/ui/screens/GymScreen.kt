package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Gym
import com.example.data.Equipment
import com.example.state.FitnessViewModel
import com.example.ui.theme.ConcreteGrey
import com.example.ui.theme.DeepRed
import com.example.ui.theme.RestrainedJade
import com.example.ui.theme.SubtleAmber
import com.example.ui.theme.WarmWhite
import com.example.ui.theme.GraphiteDark
import com.example.ui.theme.GraphiteSurface

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GymScreen(viewModel: FitnessViewModel) {
    val gyms by viewModel.gyms.collectAsState()
    val equipments by viewModel.equipments.collectAsState()
    val facilityRequests by viewModel.facilityRequests.collectAsState()

    var selectedCity by remember { mutableStateOf("全部") }
    val cities = listOf("全部", "上海", "北京", "深圳", "广州", "杭州", "成都", "南京")

    var activeGymDetail by remember { mutableStateOf<Gym?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (activeGymDetail == null) {
            // Screen Title
            Column {
                Text(
                    text = "晶体全国场馆",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = DeepRed,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "数智场馆寻找与互联 / SMART GYMS FINDER",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            // City Filter Row
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(cities) { city ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (selectedCity == city) DeepRed else MaterialTheme.colorScheme.surfaceVariant)
                            .clickable { selectedCity = city }
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = city,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (selectedCity == city) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Gyms List
            val filteredGyms = gyms.filter { selectedCity == "全部" || it.city == selectedCity }

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredGyms) { gym ->
                    // Crowding color calculation
                    val crowdColor = when {
                        gym.crowdingEstimate > 80 -> DeepRed
                        gym.crowdingEstimate > 50 -> SubtleAmber
                        else -> RestrainedJade
                    }

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Top
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = gym.name,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = gym.address,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(crowdColor.copy(alpha = 0.1f))
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = "人流: ${gym.crowdingEstimate}% " + (if (gym.crowdingEstimate > 80) "拥挤" else if (gym.crowdingEstimate > 50) "适中" else "畅通"),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = crowdColor
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Features grid
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                FeatureIconLabel(icon = Icons.Default.FitnessCenter, label = "器械x${gym.equipmentCount}")
                                FeatureIconLabel(icon = Icons.Default.HotTub, label = "桑拿淋浴")
                                FeatureIconLabel(icon = Icons.Default.LocalCafe, label = "蛋白吧")
                                FeatureIconLabel(icon = Icons.Default.LocalParking, label = "免费停车")
                            }

                            Spacer(modifier = Modifier.height(14.dp))
                            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.08f))
                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "营业时间: ${gym.openingHours}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                )

                                Button(
                                    onClick = { activeGymDetail = gym },
                                    colors = ButtonDefaults.buttonColors(containerColor = DeepRed),
                                    shape = RoundedCornerShape(4.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                    modifier = Modifier.height(30.dp).testTag("btn_enter_twin_${gym.id}")
                                ) {
                                    Text("进入物联网数字孪生", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Interactive Smart Floor Plan and Equipment Twin Detail view
            val gym = activeGymDetail!!
            val gymEquipments = equipments

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { activeGymDetail = null }) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
                Text(
                    text = "${gym.name} - 智能空间数字孪生",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(RestrainedJade.copy(alpha = 0.1f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text("IOT ACTIVE", color = RestrainedJade, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Locker Management Bar
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    val activeLocker = facilityRequests.firstOrNull { it.requestType == "智能更衣柜分配" }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Lock, contentDescription = "Lock", tint = DeepRed, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text("我的更衣柜分配", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text(
                                text = activeLocker?.lockerNumber ?: "暂未分配更衣柜（需刷NFC入场）",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                        }
                    }
                    if (activeLocker != null) {
                        Text(
                            text = "密码: " + activeLocker.staffResponse.substringAfter("【").substringBefore("】"),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = RestrainedJade
                        )
                    }
                }
            }

            // Interactive Twin Equipment List Header
            Text(
                text = "物联网智能设备孪生传感器实时状态:",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
            )

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(gymEquipments) { eq ->
                    var isExpanded by remember { mutableStateOf(false) }

                    // Color calculation based on status
                    val (statusLabel, statusColor) = when (eq.status) {
                        "OPERATIONAL" -> "闲置中 (OPERATIONAL)" to RestrainedJade
                        "IN_USE" -> "工作中 (IN_USE)" to MaterialTheme.colorScheme.primary
                        "MAINTENANCE" -> "故障保修中 (FAULT)" to DeepRed
                        else -> "停机" to ConcreteGrey
                    }

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, statusColor.copy(alpha = 0.3f))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { isExpanded = !isExpanded },
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        if (eq.type == "TREADMILL") Icons.Default.DirectionsRun else Icons.Default.FitnessCenter,
                                        contentDescription = "Equip",
                                        tint = statusColor,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(eq.name, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        Text("类型: ${eq.type} | 累计运行 ${eq.usageHours}小时", fontSize = 10.sp, color = ConcreteGrey)
                                    }
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(statusColor.copy(alpha = 0.1f))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(statusLabel, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = statusColor)
                                }
                            }

                            // Interactive sensor twin expanded details
                            AnimatedVisibility(visible = isExpanded) {
                                Column(modifier = Modifier.padding(top = 12.dp)) {
                                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.08f))
                                    Spacer(modifier = Modifier.height(8.dp))

                                    Text("物联网遥测监控 (Live Telemetry):", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ConcreteGrey)
                                    Spacer(modifier = Modifier.height(6.dp))

                                    // Metric sensor grid
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        SensorBox(
                                            title = "实时心率",
                                            value = if (eq.status == "IN_USE") "${eq.heartRatePlaceholder} BPM" else "--",
                                            modifier = Modifier.weight(1f)
                                        )
                                        SensorBox(
                                            title = if (eq.type == "TREADMILL") "速度" else "阻力/次数",
                                            value = if (eq.status == "IN_USE") {
                                                if (eq.type == "TREADMILL") String.format("%.1f km/h", eq.speed) else "${eq.reps} 次"
                                            } else "--",
                                            modifier = Modifier.weight(1f)
                                        )
                                        SensorBox(
                                            title = "输出功率",
                                            value = if (eq.status == "IN_USE") "${eq.power.toInt()} W" else "--",
                                            modifier = Modifier.weight(1f)
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(12.dp))

                                    // Interactivity actions
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        if (eq.status == "OPERATIONAL") {
                                            Button(
                                                onClick = { viewModel.connectEquipment(eq.id) },
                                                colors = ButtonDefaults.buttonColors(containerColor = RestrainedJade),
                                                shape = RoundedCornerShape(4.dp),
                                                modifier = Modifier
                                                    .weight(1.2f)
                                                    .height(30.dp)
                                                    .testTag("btn_connect_iot_${eq.id}"),
                                                contentPadding = PaddingValues(0.dp)
                                            ) {
                                                Text("NFC联机设备", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }
                                        } else if (eq.status == "IN_USE") {
                                            Button(
                                                onClick = { viewModel.disconnectEquipment(eq.id) },
                                                colors = ButtonDefaults.buttonColors(containerColor = ConcreteGrey),
                                                shape = RoundedCornerShape(4.dp),
                                                modifier = Modifier
                                                    .weight(1.2f)
                                                    .height(30.dp)
                                                    .testTag("btn_disconnect_iot_${eq.id}"),
                                                contentPadding = PaddingValues(0.dp)
                                            ) {
                                                Text("断开设备联接", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }

                                        if (eq.status != "MAINTENANCE") {
                                            Button(
                                                onClick = { viewModel.triggerEquipmentFault(eq.id) },
                                                colors = ButtonDefaults.buttonColors(containerColor = DeepRed),
                                                shape = RoundedCornerShape(4.dp),
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .height(30.dp)
                                                    .testTag("btn_fault_iot_${eq.id}"),
                                                contentPadding = PaddingValues(0.dp)
                                            ) {
                                                Text("触发故障警报", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FeatureIconLabel(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = ConcreteGrey, modifier = Modifier.size(13.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text(label, fontSize = 10.sp, color = ConcreteGrey, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SensorBox(title: String, value: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.1f), RoundedCornerShape(6.dp))
            .padding(8.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, fontSize = 9.sp, color = ConcreteGrey, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(2.dp))
            Text(value, fontSize = 13.sp, fontWeight = FontWeight.Black, color = DeepRed)
        }
    }
}
