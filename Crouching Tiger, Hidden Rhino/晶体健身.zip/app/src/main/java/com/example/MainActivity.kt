package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.state.FitnessViewModel
import com.example.ui.screens.*
import com.example.ui.theme.DeepRed
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.WarmWhite

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val viewModel: FitnessViewModel = viewModel()
                MainNavigationScaffold(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainNavigationScaffold(viewModel: FitnessViewModel) {
    val activeTab by viewModel.activeTab.collectAsState()
    var isMoreMenuVisible by remember { mutableStateOf(false) }
    var isAiChatVisible by remember { mutableStateOf(false) }

    // Primary bottoms tabs list
    val bottomTabs = listOf(
        Triple("Home", "主页", Icons.Default.Home),
        Triple("Training", "训练", Icons.Default.FitnessCenter),
        Triple("Gym", "场馆", Icons.Default.Place),
        Triple("Assessment", "体测", Icons.Default.Assessment)
    )

    // Additional sub tabs rendering in "More" panel grid
    val subTabs = listOf(
        Triple("Analytics", "数据分析", Icons.Default.TrendingUp),
        Triple("Community", "社群同城", Icons.Default.Groups),
        Triple("Store", "特许商城", Icons.Default.Storefront),
        Triple("Pass", "电子会员", Icons.Default.QrCode),
        Triple("Profile", "个人终端", Icons.Default.AccountBox),
        Triple("Operators", "运保中枢", Icons.Default.SettingsInputComponent)
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            Column {
                Spacer(modifier = Modifier.height(30.dp)) // Offset safe insets
                SimulationPanel(viewModel = viewModel)
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                tonalElevation = 8.dp,
                modifier = Modifier.testTag("app_navigation_bar")
            ) {
                bottomTabs.forEach { (tabId, label, icon) ->
                    val isSelected = activeTab == tabId
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = {
                            isMoreMenuVisible = false
                            viewModel.setActiveTab(tabId)
                        },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = DeepRed,
                            indicatorColor = DeepRed,
                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                        ),
                        modifier = Modifier.testTag("nav_tab_$tabId")
                    )
                }

                // "More" Menu Item
                val isMoreActive = subTabs.any { it.first == activeTab }
                NavigationBarItem(
                    selected = isMoreActive || isMoreMenuVisible,
                    onClick = { isMoreMenuVisible = !isMoreMenuVisible },
                    icon = { Icon(Icons.Default.Menu, contentDescription = "更多") },
                    label = { Text("更多", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = DeepRed,
                        indicatorColor = DeepRed,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                    ),
                    modifier = Modifier.testTag("nav_tab_more")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Main views multiplexing based on selected tab
            when (activeTab) {
                "Home" -> HomeScreen(
                    viewModel = viewModel,
                    onNavigate = { tab -> viewModel.setActiveTab(tab) },
                    onOpenAiChat = { isAiChatVisible = true }
                )
                "Training" -> TrainingScreen(viewModel = viewModel)
                "Gym" -> GymScreen(viewModel = viewModel)
                "Assessment" -> AssessmentScreen(viewModel = viewModel)
                "Analytics" -> AnalyticsScreen(viewModel = viewModel)
                "Community" -> CommunityScreen(viewModel = viewModel)
                "Store" -> StoreScreen(viewModel = viewModel)
                "Pass" -> MembershipScreen(viewModel = viewModel)
                "Profile" -> ProfileScreen(viewModel = viewModel)
                "Operators" -> OperationsConsole(viewModel = viewModel)
                else -> HomeScreen(
                    viewModel = viewModel,
                    onNavigate = { tab -> viewModel.setActiveTab(tab) },
                    onOpenAiChat = { isAiChatVisible = true }
                )
            }

            // More Options Grid Panel (Sub Menu Overlay)
            AnimatedVisibility(
                visible = isMoreMenuVisible,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.5f))
                        .clickable { isMoreMenuVisible = false }
                ) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter)
                            .padding(16.dp)
                            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), RoundedCornerShape(16.dp))
                            .clickable(enabled = false) {}, // Intercept click
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "探索更多数智版块",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = DeepRed,
                                modifier = Modifier.padding(bottom = 12.dp)
                            )

                            LazyVerticalGrid(
                                columns = GridCells.Fixed(3),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(180.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(subTabs) { (tabId, label, icon) ->
                                    val isTabSelected = activeTab == tabId
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(
                                                if (isTabSelected) DeepRed else MaterialTheme.colorScheme.surfaceVariant
                                            )
                                            .border(
                                                1.dp,
                                                if (isTabSelected) Color.Transparent else MaterialTheme.colorScheme.outline.copy(alpha = 0.1f),
                                                RoundedCornerShape(10.dp)
                                            )
                                            .clickable {
                                                isMoreMenuVisible = false
                                                viewModel.setActiveTab(tabId)
                                            }
                                            .padding(10.dp)
                                            .testTag("grid_tab_$tabId"),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Icon(
                                                icon,
                                                contentDescription = label,
                                                tint = if (isTabSelected) WarmWhite else MaterialTheme.colorScheme.onSurfaceVariant,
                                                modifier = Modifier.size(22.dp)
                                            )
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(
                                                text = label,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isTabSelected) WarmWhite else MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Real-Time AI Chat Assistant Overlay
            AiAssistantOverlay(
                viewModel = viewModel,
                isVisible = isAiChatVisible,
                onClose = { isAiChatVisible = false }
            )
        }
    }
}
