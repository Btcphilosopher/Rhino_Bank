package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.FacilityRequest
import com.example.state.FitnessViewModel
import com.example.ui.theme.ConcreteGrey
import com.example.ui.theme.DeepRed
import com.example.ui.theme.RestrainedJade
import com.example.ui.theme.SubtleAmber
import com.example.ui.theme.WarmWhite

@Composable
fun OperationsConsole(viewModel: FitnessViewModel) {
    val facilityRequests by viewModel.facilityRequests.collectAsState()
    val equipments by viewModel.equipments.collectAsState()
    val gyms by viewModel.gyms.collectAsState()

    var activeTab by remember { mutableStateOf("Metrics") } // "Metrics", "Tickets"

    // Operational synthetic aggregates
    val totalFootTraffic = gyms.sumOf { it.currentOccupancy }
    val failureCount = equipments.count { it.status == "MAINTENANCE" }
    val failureRate = if (equipments.isNotEmpty()) (failureCount.toDouble() / equipments.size * 100).toInt() else 0
    val totalRevenue = 48500.0 + (gyms.sumOf { it.crowdingEstimate } * 120)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Screen Title
        Column {
            Text(
                text = "晶体全国运管后台",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = DeepRed,
                letterSpacing = 1.sp
            )
            Text(
                text = "智慧中枢、客流分析与工单调度 / OPERATIONS CONSOLE",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        // Horizontal navigation tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(4.dp)
        ) {
            TabButton(
                title = "场馆运营报表 (BI)",
                isActive = activeTab == "Metrics",
                modifier = Modifier.weight(1f),
                onClick = { activeTab = "Metrics" }
            )
            TabButton(
                title = "运保保修工单 (${facilityRequests.size})",
                isActive = activeTab == "Tickets",
                modifier = Modifier.weight(1f),
                onClick = { activeTab = "Tickets" }
            )
        }

        when (activeTab) {
            "Metrics" -> {
                // Renders operational synthetic charts / metrics
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StatsBox(title = "全店瞬时人流", value = "$totalFootTraffic 人", desc = "实时传感器回传", modifier = Modifier.weight(1f))
                        StatsBox(title = "故障率 / 告警率", value = "$failureRate %", desc = "15台遥测物联网", modifier = Modifier.weight(1f))
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StatsBox(title = "峰值功耗消耗", value = "14.2 kW", desc = "绿电智能深蹲架", modifier = Modifier.weight(1f))
                        StatsBox(title = "今日模拟总营收", value = "¥ ${totalRevenue.toInt()}", desc = "会员卡、私教、特许", modifier = Modifier.weight(1f))
                    }

                    // Smart Facility Overload Banner
                    if (totalFootTraffic > 80) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = DeepRed.copy(alpha = 0.08f)),
                            border = BorderStroke(1.dp, DeepRed)
                        ) {
                            Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Warning, contentDescription = "Warning", tint = DeepRed)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text("⚠️ 空间饱和度溢出警告", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = DeepRed)
                                    Text("当前店面人流综合负荷已超过警戒值。系统已自动开启新风负压除菌增氧模式(模拟)，并建议前台闸机临时进行间歇控流。", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface, lineHeight = 15.sp)
                                }
                            }
                        }
                    } else {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = RestrainedJade.copy(alpha = 0.08f)),
                            border = BorderStroke(1.dp, RestrainedJade)
                        ) {
                            Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CloudQueue, contentDescription = "Normal", tint = RestrainedJade)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text("环境指标正常 (Air Quality Normal)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = RestrainedJade)
                                    Text("全国 5 家场馆各项传感器表现指标均处于 A 级基线，新风循环系统阻力在预定公差内，水循环无滴漏。", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface, lineHeight = 15.sp)
                                }
                            }
                        }
                    }
                }
            }
            "Tickets" -> {
                // Renders active facility and repair tickets lists. Tapping displays note details
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .testTag("operations_tickets_list"),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(facilityRequests) { req ->
                        var isExpanded by remember { mutableStateOf(false) }

                        val (statusLabel, statusColor) = when (req.status) {
                            "SUBMITTED" -> "待响应 (SUBMITTED)" to DeepRed
                            "IN_PROGRESS" -> "派遣中 (PROGRESS)" to SubtleAmber
                            "COMPLETED" -> "完成 (COMPLETED)" to RestrainedJade
                            else -> "已受理" to ConcreteGrey
                        }

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, statusColor.copy(alpha = 0.2f))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { isExpanded = !isExpanded },
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(req.requestType, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        Text("时间: ${req.timestamp} | 预计: ${req.estCompletion}", fontSize = 10.sp, color = ConcreteGrey)
                                    }
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(statusColor.copy(alpha = 0.1f))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(statusLabel, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = statusColor)
                                    }
                                }

                                AnimatedVisibility(visible = isExpanded) {
                                    Column(modifier = Modifier.padding(top = 10.dp)) {
                                        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.08f))
                                        Spacer(modifier = Modifier.height(6.dp))

                                        Text("工单位置 / 信息:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ConcreteGrey)
                                        Text("位置: ${req.lockerNumber}", fontSize = 11.sp)

                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text("运管专员响应记录 (Staff Response):", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ConcreteGrey)
                                        Text(req.staffResponse, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface, lineHeight = 15.sp)

                                        // Complete digital twin feedback loop action!
                                        if (req.status != "COMPLETED") {
                                            Spacer(modifier = Modifier.height(12.dp))
                                            Button(
                                                onClick = {
                                                    val eqName = if (req.requestType.startsWith("设备故障保修 - ")) {
                                                        req.requestType.substringAfter("设备故障保修 - ")
                                                    } else null
                                                    viewModel.resolveFacilityRequest(req.id, eqName)
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = RestrainedJade),
                                                shape = RoundedCornerShape(4.dp),
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(30.dp)
                                                    .testTag("btn_resolve_ticket_${req.id}"),
                                                contentPadding = PaddingValues(0.dp)
                                            ) {
                                                Text("一键标记修复且恢复IOT设备运行 (闭环)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
