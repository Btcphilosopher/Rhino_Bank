package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val GraphiteDark = Color(0xFF111214)
val GraphiteSurface = Color(0xFF1A1C1E)
val WarmWhite = Color(0xFFFAFAF8)
val SoftConcrete = Color(0xFFF1F2EF)
val ConcreteGrey = Color(0xFF8E9294)
val DeepRed = Color(0xFF9E1B1B)
val RestrainedJade = Color(0xFF3A6B5C)
val SubtleAmber = Color(0xFFD97706)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)
