package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.state.FitnessViewModel
import com.example.ui.theme.ConcreteGrey
import com.example.ui.theme.DeepRed
import com.example.ui.theme.RestrainedJade
import com.example.ui.theme.SubtleAmber
import com.example.ui.theme.WarmWhite

@Composable
fun ProfileScreen(viewModel: FitnessViewModel) {
    val currentUser by viewModel.currentUser.collectAsState()

    var activeSubView by remember { mutableStateOf("Profile") } // "Profile", "Privacy"

    // Interactive Onboarding states
    var selectedGoal by remember { mutableStateOf("Build Strength") }
    var kneeLimitationToggled by remember { mutableStateOf(true) }

    // Privacy toggles
    var iotTelemetryEnabled by remember { mutableStateOf(true) }
    var cloudSovereigntyToggled by remember { mutableStateOf(true) }
    var dexaTrackingEnabled by remember { mutableStateOf(true) }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (activeSubView == "Profile") {
            // Screen Title
            Column {
                Text(
                    text = "晶体个人终端",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = DeepRed,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "账户画像及数智Onboarding / PROFILE & CONFIG",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            // User Profile Header
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.08f))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(DeepRed),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = currentUser.name.take(1),
                            color = Color.White,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = currentUser.name,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "常驻场馆: ${currentUser.preferredGym}",
                            fontSize = 11.sp,
                            color = ConcreteGrey
                        )
                    }
                }
            }

            // Profile bio metrics details
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    BioCol(title = "年龄 (Age)", value = "28岁")
                    Divider(modifier = Modifier.height(24.dp).width(1.dp).align(Alignment.CenterVertically))
                    BioCol(title = "身高 (Height)", value = "180 cm")
                    Divider(modifier = Modifier.height(24.dp).width(1.dp).align(Alignment.CenterVertically))
                    BioCol(title = "体重 (Weight)", value = "78.0 kg")
                    Divider(modifier = Modifier.height(24.dp).width(1.dp).align(Alignment.CenterVertically))
                    BioCol(title = "体能评级 (Level)", value = "Level 2")
                }
            }

            // Onboarding Adjustments Configuration
            Text("数智 Onboarding 生物特征配置 (Onboarding Profile):", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ConcreteGrey)

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("核心训练目标 (Core Goal):", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = DeepRed)

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        GoalOption(
                            title = "力量突破突破 (Build Strength)",
                            desc = "主攻渐进负重抗阻训练，重塑对称性骨骼肌储备。",
                            isSelected = selectedGoal == "Build Strength",
                            onClick = { selectedGoal = "Build Strength" }
                        )
                        GoalOption(
                            title = "心肺机能强化 (Improve Endurance)",
                            desc = "主攻高能间歇有氧，强化最大摄氧量及无氧阈值。",
                            isSelected = selectedGoal == "Improve Endurance",
                            onClick = { selectedGoal = "Improve Endurance" }
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.08f))

                    // Physical Constraints Checklist (Dynamic rule parameters)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("左膝膝盖不适限制 (Left Knee Restriction)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("开启后，AI智能决策引擎将自动避免极限深蹲等大惯性膝关节冲击动作。", fontSize = 11.sp, color = ConcreteGrey)
                        }
                        Switch(
                            checked = kneeLimitationToggled,
                            onCheckedChange = { kneeLimitationToggled = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = DeepRed, checkedTrackColor = DeepRed.copy(alpha = 0.4f)),
                            modifier = Modifier.testTag("switch_knee_restriction")
                        )
                    }
                }
            }

            // Privacy menu redirection trigger
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { activeSubView = "Privacy" },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Security, contentDescription = "Security", tint = DeepRed)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("隐私合规及数据主权中心", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("审计及关闭传感器监控、遥测上链规则", fontSize = 11.sp, color = ConcreteGrey)
                        }
                    }
                    Icon(Icons.Default.ChevronRight, contentDescription = "Next")
                }
            }
        } else {
            // Privacy Center Detailed layout page
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { activeSubView = "Profile" }) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
                Text("隐私及数据自主权审计中心", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Box(modifier = Modifier.size(40.dp))
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("生物特征与物联网监控审计 (Audit Toggles):", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = DeepRed)

                    PrivacyToggleRow(
                        title = "智能物联网设备心率与遥测同步",
                        desc = "如果关闭，在使用跑步机或深蹲架时，手环及传感器将停止捕获实时心肺及阻力体积遥测。",
                        isEnabled = iotTelemetryEnabled,
                        onToggle = { iotTelemetryEnabled = it }
                    )

                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.08f))

                    PrivacyToggleRow(
                        title = "DEXA 3D 深度体测历史存档",
                        desc = "如果关闭，我们将清除并在本地隔离以往的3D光感及体脂演变图表趋势。",
                        isEnabled = dexaTrackingEnabled,
                        onToggle = { dexaTrackingEnabled = it }
                    )

                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.08f))

                    PrivacyToggleRow(
                        title = "数字主权保护 & 本地隔离加密",
                        desc = "强制将所有健身计划、活动指标、打卡历史、购物账单物理隔离存储于本地，不进行任何跨店面及第三方的聚合云存储。",
                        isEnabled = cloudSovereigntyToggled,
                        onToggle = { cloudSovereigntyToggled = it }
                    )
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = RestrainedJade.copy(alpha = 0.08f)),
                border = BorderStroke(1.dp, RestrainedJade.copy(alpha = 0.15f))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Gavel, contentDescription = "Compliance", tint = RestrainedJade)
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "晶体系统严格遵循 Simplified Chinese (中国) 数据合规性，用户拥有完全的查阅、修改及彻底抹除数据的决定权。本软件为概念展示原型，不收集任何外部真实隐私。",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        lineHeight = 14.sp
                    )
                }
            }

            Button(
                onClick = { activeSubView = "Profile" },
                colors = ButtonDefaults.buttonColors(containerColor = DeepRed),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth().height(40.dp)
            ) {
                Text("返回个人终端", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun BioCol(title: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(horizontal = 4.dp)) {
        Text(title, fontSize = 10.sp, color = ConcreteGrey)
        Spacer(modifier = Modifier.height(2.dp))
        Text(value, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun GoalOption(title: String, desc: String, isSelected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) DeepRed.copy(alpha = 0.06f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            .border(
                1.dp,
                if (isSelected) DeepRed else MaterialTheme.colorScheme.outline.copy(alpha = 0.1f),
                RoundedCornerShape(8.dp)
            )
            .clickable { onClick() }
            .padding(12.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(14.dp)
                        .clip(CircleShape)
                        .border(1.5.dp, if (isSelected) DeepRed else ConcreteGrey, CircleShape)
                        .background(if (isSelected) DeepRed else Color.Transparent)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (isSelected) DeepRed else MaterialTheme.colorScheme.onSurface)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(desc, fontSize = 11.sp, color = ConcreteGrey, modifier = Modifier.padding(start = 24.dp), lineHeight = 14.sp)
        }
    }
}

@Composable
fun PrivacyToggleRow(title: String, desc: String, isEnabled: Boolean, onToggle: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(2.dp))
            Text(desc, fontSize = 11.sp, color = ConcreteGrey, lineHeight = 14.sp)
        }
        Switch(
            checked = isEnabled,
            onCheckedChange = onToggle,
            colors = SwitchDefaults.colors(checkedThumbColor = DeepRed, checkedTrackColor = DeepRed.copy(alpha = 0.4f))
        )
    }
}
