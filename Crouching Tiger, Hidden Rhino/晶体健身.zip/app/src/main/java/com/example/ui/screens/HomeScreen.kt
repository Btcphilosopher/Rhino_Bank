package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.shape.CircleShape
import com.example.state.FitnessViewModel
import com.example.ui.theme.ConcreteGrey
import com.example.ui.theme.DeepRed
import com.example.ui.theme.RestrainedJade
import com.example.ui.theme.SubtleAmber
import com.example.ui.theme.WarmWhite

@Composable
fun HomeScreen(
    viewModel: FitnessViewModel,
    onNavigate: (String) -> Unit,
    onOpenAiChat: () -> Unit
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val membership by viewModel.membership.collectAsState()
    val activeWorkout by viewModel.activeWorkout.collectAsState()
    val workoutRecords by viewModel.workoutRecords.collectAsState()
    val classes by viewModel.classes.collectAsState()

    val todayRecommendedWorkout = viewModel.activeWorkout.collectAsState().value

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcoming & Profile header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "晶体数智空间",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = DeepRed,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "你好，${currentUser.name} 👋",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }
            IconButton(
                onClick = onOpenAiChat,
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(DeepRed)
            ) {
                Icon(Icons.Default.SmartToy, contentDescription = "AI Assistant", tint = WarmWhite)
            }
        }

        // Smart Recommendation Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = DeepRed.copy(alpha = 0.08f)),
            border = BorderStroke(1.dp, DeepRed.copy(alpha = 0.15f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Lightbulb, contentDescription = "Recommendation", tint = DeepRed, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "今日AI推介：下肢力量训练 (Lower-body)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = DeepRed
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "依据：根据您最新的DEXA体测，左腿股四头肌肌肉力量比右侧少0.2kg。今日推荐低冲击单侧主导下肢力量训练，重塑对称性。",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f),
                    lineHeight = 15.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "规则引擎检测：未触发急性疲劳(酸痛指数 3/10)。膝关节安全防护开启。",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = RestrainedJade
                )
            }
        }

        // Today's Training Section
        Column {
            SectionHeader(title = "今日推荐训练 / TODAY'S WORKOUT", onActionClick = { onNavigate("Training") })
            Spacer(modifier = Modifier.height(8.dp))

            if (todayRecommendedWorkout != null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.12f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = todayRecommendedWorkout.name,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Text("时长: ${todayRecommendedWorkout.durationMinutes}分钟", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
                                    Text("目标: 力量突破", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
                                }
                            }
                            Button(
                                onClick = { viewModel.startWorkout(todayRecommendedWorkout) },
                                colors = ButtonDefaults.buttonColors(containerColor = DeepRed),
                                modifier = Modifier.testTag("btn_start_today_workout"),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text("开启训练", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                        Spacer(modifier = Modifier.height(12.dp))

                        // Exercise list summary
                        todayRecommendedWorkout.exercises.take(3).forEach { we ->
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(we.nameZh, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("${we.sets.size} 组 | ${we.sets.firstOrNull()?.reps ?: 10}次", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
                            }
                        }
                    }
                }
            } else {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Box(modifier = Modifier.padding(16.dp), contentAlignment = Alignment.Center) {
                        Text("今日推荐训练已完成！查看“数据分析”查看最新的记录包。", fontSize = 12.sp, color = RestrainedJade, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Daily Activity Rings Section
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1.3f)) {
                    Text(
                        text = "今日运动指标 / DAILY ACTIVITY",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    ActivityMetricRow(title = "步数 (Steps)", value = "6,845", target = "/10,000 步", iconColor = DeepRed)
                    ActivityMetricRow(title = "卡路里 (Burned)", value = "${450 + (workoutRecords.firstOrNull()?.caloriesBurned ?: 0)}", target = "/600 kcal", iconColor = SubtleAmber)
                    ActivityMetricRow(title = "运动时长 (Active)", value = "45", target = "/60 分钟", iconColor = RestrainedJade)
                    ActivityMetricRow(title = "本周打卡 (Streak)", value = "${workoutRecords.filter { true }.size % 7 + 3}", target = "天数", iconColor = MaterialTheme.colorScheme.primary)
                }

                Spacer(modifier = Modifier.width(16.dp))

                Box(
                    modifier = Modifier
                        .size(110.dp)
                        .weight(0.9f),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.size(90.dp)) {
                        // Outer Ring (Steps)
                        drawArc(
                            color = Color.LightGray.copy(alpha = 0.3f),
                            startAngle = 0f,
                            sweepAngle = 360f,
                            useCenter = false,
                            style = Stroke(width = 8.dp.toPx(), cap = StrokeCap.Round)
                        )
                        drawArc(
                            color = DeepRed,
                            startAngle = -90f,
                            sweepAngle = 246f, // 68.4%
                            useCenter = false,
                            style = Stroke(width = 8.dp.toPx(), cap = StrokeCap.Round)
                        )

                        // Middle Ring (Calories)
                        drawArc(
                            color = Color.LightGray.copy(alpha = 0.3f),
                            startAngle = 0f,
                            sweepAngle = 360f,
                            useCenter = false,
                            style = Stroke(width = 8.dp.toPx(), cap = StrokeCap.Round),
                            size = size.copy(width = size.width - 32f, height = size.height - 32f),
                            topLeft = androidx.compose.ui.geometry.Offset(16f, 16f)
                        )
                        drawArc(
                            color = SubtleAmber,
                            startAngle = -90f,
                            sweepAngle = 280f, // ~78%
                            useCenter = false,
                            style = Stroke(width = 8.dp.toPx(), cap = StrokeCap.Round),
                            size = size.copy(width = size.width - 32f, height = size.height - 32f),
                            topLeft = androidx.compose.ui.geometry.Offset(16f, 16f)
                        )
                    }
                    Icon(
                        Icons.Default.TrendingUp,
                        contentDescription = "Trending",
                        tint = DeepRed,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // Membership Info Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.12f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CardMembership, contentDescription = "Membership", tint = DeepRed)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = membership.type,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (membership.status == "ACTIVE") RestrainedJade else DeepRed)
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (membership.status == "ACTIVE") "使用中" else "已过期",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("最近场馆", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                        Text(currentUser.preferredGym, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("剩余次数", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                        Text("${membership.remainingVisits} 次", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = DeepRed)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("到期时间", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                        Text(membership.renewalDate, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { viewModel.enterGymSimulate(currentUser.preferredGym) },
                        colors = ButtonDefaults.buttonColors(containerColor = RestrainedJade),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_nfc_entry"),
                        contentPadding = PaddingValues(vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.Nfc, contentDescription = "NFC", modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("模拟NFC入场", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { viewModel.renewMembership() },
                        colors = ButtonDefaults.buttonColors(containerColor = DeepRed),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_renew_membership"),
                        contentPadding = PaddingValues(vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.Payment, contentDescription = "Pay", modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("一键充值/续卡", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Upcoming bookings / reservations
        Column {
            Text(
                text = "即将开始的日程 / UPCOMING RESERVATIONS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
            )
            Spacer(modifier = Modifier.height(8.dp))

            val bookedClasses = classes.filter { it.isBooked }
            if (bookedClasses.isNotEmpty()) {
                bookedClasses.forEach { c ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 6.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.08f))
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(DeepRed.copy(alpha = 0.1f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Schedule, contentDescription = "Class", tint = DeepRed, modifier = Modifier.size(18.dp))
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(c.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("时段: ${c.timeSlot} | 房间: ${c.location}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
                            }
                            TextButton(
                                onClick = { viewModel.cancelClass(c.id) },
                                contentPadding = PaddingValues(horizontal = 8.dp)
                            ) {
                                Text("取消预约", fontSize = 10.sp, color = DeepRed)
                            }
                        }
                    }
                }
            } else {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Info, contentDescription = "Info", tint = ConcreteGrey, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("今日暂无团体课及私教课程预约。去“预约操课”或“寻找教练”看看吧。", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
                    }
                }
            }
        }
    }
}

@Composable
fun SectionHeader(
    title: String,
    onActionClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
        )
        Text(
            text = "查看全部",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = DeepRed,
            modifier = Modifier.clickable { onActionClick() }
        )
    }
}

@Composable
fun ActivityMetricRow(
    title: String,
    value: String,
    target: String,
    iconColor: Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(iconColor)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = title, fontSize = 11.sp, modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f))
        Row {
            Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(text = " $target", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f))
        }
    }
}
