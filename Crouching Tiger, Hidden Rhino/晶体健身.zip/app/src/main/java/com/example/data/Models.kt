package com.example.data

data class Member(
    val id: String,
    val name: String,
    val ageRange: String,
    val height: Double,
    val weight: Double,
    val trainingExperience: String,
    val fitnessObjectives: List<String>,
    val preferredTrainingTime: String,
    val preferredGym: String,
    val preferredWorkoutTypes: List<String>,
    val equipmentPreferences: List<String>,
    val language: String,
    val accessibilityPreferences: String,
    val trainingLimitations: String
)

data class Membership(
    val type: String,
    val status: String,
    val startDate: String,
    val renewalDate: String,
    val remainingVisits: Int,
    val classCredits: Int,
    val guestPasses: Int,
    val freezeStatus: String,
    val upgradeOptions: List<String>,
    val price: Double
)

data class Gym(
    val id: String,
    val name: String,
    val city: String,
    val district: String,
    val address: String,
    val openingHours: String,
    val floorArea: Int,
    val equipmentCount: Int,
    val crowdingEstimate: Int, // Percentage (0-100)
    val classAvailability: Boolean,
    val trainerAvailability: Boolean,
    val showerFacilities: Boolean,
    val lockers: Boolean,
    val accessibilityFacilities: Boolean,
    val currentOccupancy: Int,
    val peakHours: List<Int>, // list of hourly percentages starting from 8am to 10pm
    val cleaningStatus: String,
    val maintenanceAlerts: List<String>
)

data class Coach(
    val id: String,
    val name: String,
    val avatarUrl: String,
    val speciality: String,
    val certifications: String,
    val experienceYears: Int,
    val languages: List<String>,
    val coachingStyle: String,
    val availableTimes: List<String>,
    val sessionPrice: Double,
    val rating: Double,
    val clientFocus: String,
    val trainingPhilosophy: String
)

data class GymClass(
    val id: String,
    val name: String,
    val category: String, // strength, HIIT, cycling, yoga, Pilates, boxing, mobility, etc.
    val instructor: String,
    val durationMinutes: Int,
    val difficulty: String,
    val location: String,
    val capacity: Int,
    val remainingSpaces: Int,
    val equipment: String,
    val description: String,
    val timeSlot: String,
    val isBooked: Boolean = false,
    val waitlistCount: Int = 0,
    val isWaitlisted: Boolean = false
)

data class Booking(
    val id: String,
    val type: String, // "CLASS" or "COACH"
    val targetId: String,
    val targetName: String,
    val timeSlot: String,
    val price: Double,
    val status: String, // "CONFIRMED", "WAITLISTED", "CANCELLED"
    val date: String
)

data class Exercise(
    val id: String,
    val nameZh: String,
    val nameEn: String,
    val category: String, // "力量训练", "有氧训练", "功能训练", "灵活性与恢复"
    val description: String,
    val targetMuscles: String,
    val equipment: String,
    val difficulty: String,
    val suggestedSets: Int,
    val suggestedReps: Int,
    val restSeconds: Int,
    val safetyNotes: String,
    val commonMistakes: String
)

data class WorkoutSet(
    val setIndex: Int,
    val weightKg: Double,
    val reps: Int,
    val isCompleted: Boolean = false
)

data class WorkoutExercise(
    val exerciseId: String,
    val nameZh: String,
    val nameEn: String,
    val category: String,
    val sets: List<WorkoutSet>
)

data class Workout(
    val id: String,
    val name: String,
    val objective: String,
    val durationMinutes: Int,
    val exercises: List<WorkoutExercise>,
    val isTemplate: Boolean = false
)

data class WorkoutRecordSet(
    val setIndex: Int,
    val weightKg: Double,
    val reps: Int,
    val isCompleted: Boolean
)

data class WorkoutRecordExercise(
    val exerciseId: String,
    val nameZh: String,
    val nameEn: String,
    val category: String,
    val sets: List<WorkoutRecordSet>
)

data class WorkoutRecord(
    val id: String,
    val workoutName: String,
    val durationMinutes: Int,
    val exercises: List<WorkoutRecordExercise>,
    val totalVolumeKg: Double,
    val totalReps: Int,
    val caloriesBurned: Int,
    val date: String,
    val notes: String
)

data class Equipment(
    val id: String,
    val name: String,
    val type: String, // "TREADMILL", "BIKE", "ROWER", "CABLE", "SQUAT_RACK", "LEG_PRESS", "CHEST_PRESS", "DUMBBELLS", "BODY_COMP"
    val manufacturer: String,
    val model: String,
    val locationZone: String, // e.g. "有氧区", "力量区", "自由力量区", "体测区"
    val status: String, // "OPERATIONAL" (正常), "RESERVED" (已预订), "IN_USE" (使用中), "MAINTENANCE" (故障维护), "OFFLINE" (离线), "INSPECTING" (检测中)
    val usageHours: Int,
    val maintenanceInterval: Int,
    val lastInspection: String,
    val nextInspection: String,
    val utilizationRate: Double,
    // Live simulation data
    val power: Double,
    val speed: Double,
    val incline: Double,
    val reps: Int,
    val resistance: Double,
    val heartRatePlaceholder: Int,
    val faultHistory: List<String>
)

data class FitnessAssessment(
    val id: String,
    val date: String,
    val heightCm: Double,
    val weightKg: Double,
    val bodyFatPercentage: Double,
    val muscleMassKg: Double,
    val visceralFatLevel: Int,
    val waterPercentage: Double,
    val restingHeartRate: Int,
    val flexibilityScore: String, // e.g., "Good", "Excellent"
    val strengthTests: Map<String, String>, // exercise -> metric (e.g. Squat -> 120kg)
    val mobilityObservations: String,
    val enduranceMinutes: Int,
    val confidenceLevel: String,
    val notes: String
)

data class RecoveryLog(
    val id: String,
    val date: String,
    val energyLevel: Int, // 1-10
    val sleepDurationHours: Double,
    val sorenessLevel: Int, // 1-10
    val stressLevel: Int, // 1-10
    val motivationLevel: Int, // 1-10
    val perceivedExertion: Int, // 1-10
    val suggestion: String
)

data class FoodItem(
    val name: String,
    val calories: Int,
    val protein: Double,
    val carbs: Double,
    val fats: Double,
    val portionSize: String
)

data class NutritionLog(
    val id: String,
    val date: String,
    val foodItems: List<FoodItem>,
    val totalCalories: Int,
    val totalProtein: Double,
    val totalCarbs: Double,
    val totalFats: Double,
    val hydrationMl: Int
)

data class Challenge(
    val id: String,
    val title: String,
    val description: String,
    val category: String, // "STRENGTH", "CONSISTENCY", "CARDIO", "MOBILITY"
    val targetValue: Double,
    val currentValue: Double,
    val participantsCount: Int,
    val milestones: List<String>,
    val badge: String,
    val isJoined: Boolean = false,
    val progressPercentage: Int = 0
)

data class CommunityComment(
    val authorName: String,
    val content: String,
    val timestamp: String
)

data class CommunityPost(
    val id: String,
    val authorName: String,
    val authorAvatarUrl: String,
    val content: String,
    val category: String,
    val likes: Int,
    val commentsCount: Int,
    val saves: Int,
    val isLiked: Boolean = false,
    val isSaved: Boolean = false,
    val timestamp: String,
    val comments: List<CommunityComment> = emptyList()
)

data class Product(
    val id: String,
    val name: String,
    val price: Double,
    val category: String, // "APPAREL", "EQUIPMENT", "ACCESSORIES"
    val description: String,
    val stock: Int,
    val rating: Double,
    val variants: List<String>
)

data class CartItem(
    val product: Product,
    val quantity: Int,
    val selectedVariant: String
)

data class StoreOrder(
    val id: String,
    val items: List<CartItem>,
    val totalAmount: Double,
    val status: String, // "PENDING", "PAID", "SHIPPED", "DELIVERED"
    val timestamp: String,
    val trackingNumber: String,
    val deliveryStatus: String
)

data class FacilityRequest(
    val id: String,
    val requestType: String, // "LOCKER", "TOWEL", "WATER", "CLEANING"
    val lockerNumber: String,
    val status: String, // "SUBMITTED", "ACKNOWLEDGED", "IN_PROGRESS", "COMPLETED", "CANCELLED"
    val timestamp: String,
    val estCompletion: String,
    val staffResponse: String
)

data class AppNotification(
    val id: String,
    val title: String,
    val content: String,
    val timestamp: String,
    val isRead: Boolean = false
)

data class LiveEvent(
    val id: String,
    val name: String,
    val date: String,
    val venue: String,
    val capacity: Int,
    val organizer: String,
    val difficulty: String,
    val registrationStatus: String, // "NOT_REGISTERED", "REGISTERED"
    val attendeesCount: Int,
    val discussion: List<CommunityComment> = emptyList()
)
