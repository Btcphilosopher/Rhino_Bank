package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.state.FitnessViewModel
import com.example.ui.theme.ConcreteGrey
import com.example.ui.theme.DeepRed
import com.example.ui.theme.RestrainedJade
import com.example.ui.theme.SubtleAmber

@Composable
fun AnalyticsScreen(viewModel: FitnessViewModel) {
    val workoutRecords by viewModel.workoutRecords.collectAsState()

    // Aggregate stats
    val totalSessions = workoutRecords.size
    val totalVolumeKg = workoutRecords.sumOf { it.totalVolumeKg }
    val totalCalories = workoutRecords.sumOf { it.caloriesBurned }
    val avgDuration = if (workoutRecords.isNotEmpty()) workoutRecords.sumOf { it.durationMinutes } / workoutRecords.size else 0

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Screen Title
        Column {
            Text(
                text = "晶体运动生物计算",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = DeepRed,
                letterSpacing = 1.sp
            )
            Text(
                text = "训练负荷与心肺遥测分析 / PERFORMANCE ANALYTICS",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        // Summary Aggregates Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            StatsBox(title = "总训练天数", value = "$totalSessions 天", desc = "本月至今", modifier = Modifier.weight(1f))
            StatsBox(title = "累计总体积", value = String.format("%.1f 吨", totalVolumeKg / 1000.0), desc = "高压负荷", modifier = Modifier.weight(1f))
            StatsBox(title = "总能量消耗", value = "${totalCalories / 1000} Kcal", desc = "有效代谢", modifier = Modifier.weight(1f))
        }

        // Cardio & Endurance Estimates
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.08f))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "心肺能级预估 / CARDIO TELEMETRY ESTIMATE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = ConcreteGrey
                )
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    CardioMetricItem(title = "最大摄氧量 (VO₂ Max)", value = "48.5 ml/kg/min", status = "优异 (Excellent)", statusColor = RestrainedJade)
                    CardioMetricItem(title = "静息心率 (RHR)", value = "58 BPM", status = "强悍 (Athletic)", statusColor = RestrainedJade)
                    CardioMetricItem(title = "无氧阈值功率 (FTP)", value = "240 W", status = "中高阻力阶梯", statusColor = SubtleAmber)
                }
            }
        }

        // Chronological training list header
        Text(
            text = "硬核训练历史记录明细 (${workoutRecords.size}次历史训练):",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
        )

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .testTag("workout_history_list"),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(workoutRecords) { record ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = record.workoutName,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(RestrainedJade.copy(alpha = 0.1f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = record.date,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = RestrainedJade
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("时长: ${record.durationMinutes} 分钟", fontSize = 11.sp, color = ConcreteGrey)
                            Text("体积: ${record.totalVolumeKg.toInt()} kg", fontSize = 11.sp, color = ConcreteGrey)
                            Text("能量: ${record.caloriesBurned} Kcal", fontSize = 11.sp, color = ConcreteGrey)
                            Text("动作数: ${record.exercises.size}个", fontSize = 11.sp, color = ConcreteGrey)
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.05f))
                        Spacer(modifier = Modifier.height(8.dp))

                        // Exercises summary detail
                        record.exercises.forEach { ex ->
                            val completedCount = ex.sets.count { it.isCompleted }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(ex.nameZh, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f))
                                Text(
                                    text = "${ex.sets.size}组中完成 ${completedCount}组 | 均重 ${ex.sets.firstOrNull()?.weightKg?.toInt() ?: 0}kg",
                                    fontSize = 11.sp,
                                    color = ConcreteGrey
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatsBox(title: String, value: String, desc: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.12f), RoundedCornerShape(8.dp))
            .padding(10.dp)
    ) {
        Column {
            Text(title, fontSize = 10.sp, color = ConcreteGrey, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, fontSize = 15.sp, fontWeight = FontWeight.Black, color = DeepRed)
            Spacer(modifier = Modifier.height(2.dp))
            Text(desc, fontSize = 9.sp, color = ConcreteGrey)
        }
    }
}

@Composable
fun CardioMetricItem(title: String, value: String, status: String, statusColor: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, fontSize = 9.sp, color = ConcreteGrey)
        Spacer(modifier = Modifier.height(2.dp))
        Text(value, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(2.dp))
        Text(status, fontSize = 9.sp, color = statusColor, fontWeight = FontWeight.Bold)
    }
}
