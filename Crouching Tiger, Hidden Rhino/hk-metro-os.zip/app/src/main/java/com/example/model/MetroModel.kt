package com.example.model

import androidx.compose.ui.graphics.Color
import java.util.UUID

// Bilingual string representation
data class BilingualString(
    val en: String,
    val zh: String
) {
    fun get(isZh: Boolean): String = if (isZh) zh else en
}

// Stations and Infrastructure
data class Station(
    val id: String,
    val name: BilingualString,
    val lines: List<String>,
    val exits: List<StationExit>,
    val facilities: List<Facility>,
    val crowding: CrowdingLevel = CrowdingLevel.LOW,
    val isClosed: Boolean = false
)

enum class CrowdingLevel(val label: BilingualString, val levelHex: String) {
    LOW(BilingualString("LOW", "低"), "#34C759"),
    MODERATE(BilingualString("MODERATE", "中"), "#007AFF"),
    BUSY(BilingualString("BUSY", "高"), "#FF9500"),
    VERY_BUSY(BilingualString("VERY BUSY", "極高"), "#FF3B30"),
    CRITICAL(BilingualString("CRITICAL", "飽和"), "#8E1E1E")
}

data class StationExit(
    val code: String, // e.g. "A", "C1", "D2"
    val destinations: List<BilingualString>,
    val distanceMeters: Int,
    val isAccessible: Boolean,
    val hasLift: Boolean,
    val hasEscalator: Boolean
)

data class Facility(
    val id: String,
    val type: FacilityType,
    val name: BilingualString,
    var status: FacilityStatus
)

enum class FacilityType(val label: BilingualString, val iconName: String) {
    LIFT(BilingualString("Lift", "升降機"), "lift"),
    ESCALATOR(BilingualString("Escalator", "扶手電梯"), "escalator"),
    TOILET(BilingualString("Toilet", "洗手間"), "wc"),
    CUSTOMER_SERVICE(BilingualString("Customer Service", "客務中心"), "support"),
    ATM(BilingualString("ATM", "自動櫃員機"), "atm"),
    RETAIL(BilingualString("Shops", "車站商店"), "store")
}

enum class FacilityStatus(val label: BilingualString, val isOperable: Boolean) {
    OPEN(BilingualString("OPEN", "運作正常"), true),
    CLOSED(BilingualString("CLOSED", "關閉"), false),
    OUT_OF_SERVICE(BilingualString("OUT OF SERVICE", "暫停服務"), false)
}

// Lines
data class MetroLine(
    val id: String,
    val name: BilingualString,
    val color: Color,
    val stations: List<String>, // ordered list of station IDs
    val headwaySeconds: Int,
    var serviceStatus: LineServiceStatus = LineServiceStatus.NORMAL
)

enum class LineServiceStatus(val label: BilingualString, val colorHex: String) {
    NORMAL(BilingualString("NORMAL SERVICE", "班次正常"), "#34C759"),
    MINOR_DELAY(BilingualString("MINOR DELAY", "微幅延誤"), "#FF9500"),
    MAJOR_DELAY(BilingualString("MAJOR DELAY", "嚴重延誤"), "#FF3B30"),
    SUSPENDED(BilingualString("SUSPENDED", "服務暫停"), "#8E1E1E")
}

// Journey & Route Graph
data class RouteNode(
    val stationId: String,
    val type: NodeType,
    val details: String = "" // "Platform 3", "Concourse"
)

enum class NodeType {
    STATION, PLATFORM, CONCOURSE, ENTRANCE, EXIT
}

data class RouteEdge(
    val fromNode: RouteNode,
    val toNode: RouteNode,
    val type: EdgeType,
    val travelTimeSeconds: Int,
    val lineId: String? = null // if rail journey
)

enum class EdgeType {
    RAIL, WALK, TRANSFER, VERTICAL_LIFT, VERTICAL_ESCALATOR, VERTICAL_STAIR
}

data class RouteSegment(
    val type: EdgeType,
    val lineId: String?,
    val fromStationId: String,
    val toStationId: String,
    val details: BilingualString,
    val durationSeconds: Int,
    val platform: String? = null
)

data class JourneyResult(
    val fromStationId: String,
    val toStationId: String,
    val totalDurationMinutes: Int,
    val walkingDurationMinutes: Int,
    val interchangesCount: Int,
    val totalFare: Double,
    val segments: List<RouteSegment>,
    val timeline: List<TimelineItem>,
    val isAccessible: Boolean
)

data class TimelineItem(
    val time: String,
    val event: BilingualString
)

// Simulated Live Trains
data class LiveTrain(
    val trainId: String,
    val lineId: String,
    val direction: TrainDirection,
    var currentStationId: String,
    var nextStationId: String,
    var progressFraction: Float, // 0.0f (at currentStationId) to 1.0f (at nextStationId)
    var speedKmh: Int,
    var status: TrainStatus,
    var etaSeconds: Int,
    val platform: String,
    val carCrowding: List<Int> // 8 integer values representing percentage capacity of each car
)

enum class TrainDirection(val label: BilingualString) {
    UP(BilingualString("Inbound", "往市區")),
    DOWN(BilingualString("Outbound", "往新界/離島")),
    EAST(BilingualString("Eastbound", "往東行")),
    WEST(BilingualString("Westbound", "往西行"))
}

enum class TrainStatus(val label: BilingualString) {
    ON_TIME(BilingualString("On Time", "準時")),
    APPROACHING(BilingualString("Approaching", "即將抵達")),
    DWELLING(BilingualString("Dwelling", "正在上落客")),
    DEPARTED(BilingualString("Departed", "已駛離")),
    DELAYED(BilingualString("Delayed", "延誤")),
    HELD(BilingualString("Held", "列車扣留")),
    OUT_OF_SERVICE(BilingualString("Out of Service", "不提供服務"))
}

// Disruption Management
data class ServiceDisruption(
    val id: String,
    val lineId: String,
    val severity: DisruptionSeverity,
    val title: BilingualString,
    val cause: BilingualString,
    val affectedStations: List<String>,
    val expectedDuration: BilingualString,
    val alternative: BilingualString,
    val timestamp: String
)

enum class DisruptionSeverity {
    INFO, NOTICE, WARNING, URGENT, CRITICAL
}

// Ticketing and Fares
enum class PassengerType(val label: BilingualString) {
    ADULT(BilingualString("Adult", "成人")),
    CONCESSION(BilingualString("Concession (Elderly/Student)", "特惠 (長者/學生)")),
    TOURIST(BilingualString("Tourist Day Pass", "遊客地鐵一日通"))
}

enum class PaymentMethod(val label: BilingualString) {
    OCTOPUS(BilingualString("Octopus Card", "八達通")),
    CONTACTLESS_BANK_CARD(BilingualString("Contactless Bank Card", "感應式信用卡")),
    QR(BilingualString("QR Transit Code", "乘車碼")),
    DIGITAL_TICKET(BilingualString("Single Journey QR Ticket", "單程電子車票"))
}

data class Ticket(
    val id: String,
    val type: String, // Single, Day Pass, Tourist Pass, Airport Express
    val title: BilingualString,
    val fare: Double,
    val purchaseTime: String,
    val expiryTime: String,
    var status: TicketStatus = TicketStatus.ACTIVE
)

enum class TicketStatus(val label: BilingualString) {
    ACTIVE(BilingualString("Unused", "未使用")),
    USED(BilingualString("Used", "已使用")),
    EXPIRED(BilingualString("Expired", "已過期"))
}

data class TapJourneyRecord(
    val id: String,
    val cardToken: String,
    val entryStationId: String,
    val exitStationId: String?,
    val entryTime: String,
    val exitTime: String?,
    val fare: Double,
    val status: String // "IN_PROGRESS", "COMPLETED"
)

data class TravelHistoryItem(
    val date: String,
    val fromStationId: String,
    val toStationId: String,
    val durationMinutes: Int,
    val fare: Double,
    val paymentMethod: PaymentMethod
)

// Rewards
data class RewardOffer(
    val id: String,
    val title: BilingualString,
    val pointsCost: Int,
    val detail: BilingualString,
    val expiry: String
)

// Digital Twin & Assets
data class Asset(
    val id: String,
    val name: BilingualString,
    val type: AssetType,
    val location: String, // Station ID or Line ID
    var status: AssetHealthStatus,
    val ageYears: Double,
    val failureCount: Int,
    val lastInspectionDate: String,
    val nextServiceDate: String,
    val maintenanceHistory: List<String>
)

enum class AssetType(val label: BilingualString) {
    TRAIN(BilingualString("Rolling Stock", "列車車體")),
    TRACK(BilingualString("Permanent Way (Track)", "軌道")),
    SIGNAL(BilingualString("ATC Signaling System", "信號系統")),
    ESCALATOR(BilingualString("Heavy Duty Escalator", "重型扶手電梯")),
    LIFT(BilingualString("Hydraulic Passenger Lift", "垂直升降機")),
    GATE(BilingualString("Smart Ticketing Gate", "智慧閘機")),
    AIR_CONDITIONING(BilingualString("Station HVAC", "空調通風系統")),
    POWER_SYSTEM(BilingualString("Traction Substations", "牽引供電系統"))
}

enum class AssetHealthStatus(val label: BilingualString, val colorHex: String) {
    NORMAL(BilingualString("HEALTHY", "運行良好"), "#34C759"),
    INSPECTION(BilingualString("DUE FOR INSPECTION", "待檢"), "#FF9500"),
    REPAIR_NEEDED(BilingualString("REPAIR REQ", "需維修"), "#FF3B30"),
    CRITICAL(BilingualString("CRITICAL FAULT", "故障中"), "#8E1E1E")
}

// Universal Telemetry Event Schema
data class TelemetryEvent(
    val eventId: String = UUID.randomUUID().toString(),
    val timestamp: String,
    val type: String, // e.g., "train.position", "lift.outage", "payment.tap"
    val entityId: String,
    val source: String, // "SIMULATED_DATA_FEED"
    val payload: Map<String, String>
)
