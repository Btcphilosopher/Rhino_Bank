package com.example.engine

import androidx.compose.ui.graphics.Color
import com.example.model.*
import java.util.PriorityQueue

object RoutingEngine {

    // Define standard HK Metro lines and colors
    val LINES = mapOf(
        "ISL" to MetroLine("ISL", BilingualString("Island Line", "港島綫"), Color(0xFF007BC4), listOf("CEN", "ADM", "CAB", "QUB", "TAK"), 120),
        "TWL" to MetroLine("TWL", BilingualString("Tsuen Wan Line", "荃灣綫"), Color(0xFFE21118), listOf("CEN", "ADM", "TST", "MOK"), 120),
        "KTL" to MetroLine("KTL", BilingualString("Kwun Tong Line", "觀塘綫"), Color(0xFF00913A), listOf("MOK", "QUB"), 150), // simplified connection
        "TKO" to MetroLine("TKO", BilingualString("Tseung Kwan O Line", "將軍澳綫"), Color(0xFF7E318C), listOf("QUB", "TKO"), 180),
        "TCL" to MetroLine("TCL", BilingualString("Tung Chung Line", "東涌綫"), Color(0xFFED6D00), listOf("HOK", "KOW", "TSY", "SUN"), 240),
        "AEL" to MetroLine("AEL", BilingualString("Airport Express", "機場快綫"), Color(0xFF00767A), listOf("HOK", "KOW", "TSY", "AIR"), 600),
        "EAL" to MetroLine("EAL", BilingualString("East Rail Line", "東鐵綫"), Color(0xFF55B1E5), listOf("ADM", "SHA"), 180),
        "TML" to MetroLine("TML", BilingualString("Tuen Ma Line", "屯馬綫"), Color(0xFF9E652E), listOf("TUM", "YUL", "MOK", "QUB"), 240) // simplified
    )

    // Define standard stations with bilingual names, lines, exits, and facilities
    val STATIONS = mapOf(
        "CEN" to Station(
            id = "CEN",
            name = BilingualString("Central", "中環"),
            lines = listOf("ISL", "TWL"),
            exits = listOf(
                StationExit("A", listOf(BilingualString("Conaught Road Central", "干諾道中"), BilingualString("Bus Terminus", "巴士總站")), 150, true, true, true),
                StationExit("C", listOf(BilingualString("Li Yuen Street East", "利源東街"), BilingualString("World-Wide House", "環球大廈")), 120, false, false, true),
                StationExit("D1", listOf(BilingualString("Pedder Street", "畢打街"), BilingualString("Queen's Road Central", "皇后大道中")), 90, false, false, false),
                StationExit("D2", listOf(BilingualString("Lan Kwai Fong", "蘭桂坊"), BilingualString("Theatre Lane", "戲院里")), 80, true, true, true)
            ),
            facilities = listOf(
                Facility("CEN-L1", FacilityType.LIFT, BilingualString("Lift from Concourse to Platform 3", "大堂至 3 號月台升降機"), FacilityStatus.OPEN),
                Facility("CEN-E1", FacilityType.ESCALATOR, BilingualString("Escalator to Exit A", "往 A 出口扶手電梯"), FacilityStatus.OPEN),
                Facility("CEN-T1", FacilityType.TOILET, BilingualString("Universal Toilet near Concourse A", "大堂 A 附近通用洗手間"), FacilityStatus.OPEN),
                Facility("CEN-CS1", FacilityType.CUSTOMER_SERVICE, BilingualString("Customer Service Center Near Exit D", "D 出口附近客務中心"), FacilityStatus.OPEN),
                Facility("CEN-S1", FacilityType.RETAIL, BilingualString("Circle K Store", "OK 便利店"), FacilityStatus.OPEN)
            ),
            crowding = CrowdingLevel.MODERATE
        ),
        "ADM" to Station(
            id = "ADM",
            name = BilingualString("Admiralty", "金鐘"),
            lines = listOf("ISL", "TWL", "EAL"),
            exits = listOf(
                StationExit("A", listOf(BilingualString("Admiralty Centre", "金鐘中心"), BilingualString("Government Offices", "政府合署")), 100, true, true, true),
                StationExit("C1", listOf(BilingualString("Queensway Plaza", "金鐘廊"), BilingualString("Taxi Stand", "德士站")), 110, true, true, true),
                StationExit("F", listOf(BilingualString("Pacific Place", "太古廣場"), BilingualString("High Court", "高等法院")), 250, true, true, true)
            ),
            facilities = listOf(
                Facility("ADM-L1", FacilityType.LIFT, BilingualString("Interchange Lift Platform L1 to L3", "L1 至 L3 層轉乘升降機"), FacilityStatus.OPEN),
                Facility("ADM-L2", FacilityType.LIFT, BilingualString("Concourse to Ground Level Lift", "地面至大堂升降機"), FacilityStatus.OPEN),
                Facility("ADM-E1", FacilityType.ESCALATOR, BilingualString("High Speed Escalator L3 to L1", "L3 至 L1 高速扶手電梯"), FacilityStatus.OPEN),
                Facility("ADM-T1", FacilityType.TOILET, BilingualString("Main Station Toilet Level L2", "L2 層主站洗手間"), FacilityStatus.OPEN),
                Facility("ADM-CS1", FacilityType.CUSTOMER_SERVICE, BilingualString("Admiralty Central Customer Service", "金鐘中央客務中心"), FacilityStatus.OPEN)
            ),
            crowding = CrowdingLevel.BUSY
        ),
        "TST" to Station(
            id = "TST",
            name = BilingualString("Tsim Sha Tsui", "尖沙咀"),
            lines = listOf("TWL"),
            exits = listOf(
                StationExit("A1", listOf(BilingualString("Kowloon Park", "九龍公園"), BilingualString("Mosque", "清真寺")), 140, true, true, true),
                StationExit("C1", listOf(BilingualString("Peking Road", "北京道"), BilingualString("Chungking Mansions", "重慶大廈")), 130, false, false, true),
                StationExit("E", listOf(BilingualString("Nathan Road", "彌敦道"), BilingualString("Cultural Centre", "香港文化中心")), 100, true, true, true)
            ),
            facilities = listOf(
                Facility("TST-L1", FacilityType.LIFT, BilingualString("Lift at Exit A1 to Street", "A1 出口至地面升降機"), FacilityStatus.OPEN),
                Facility("TST-E1", FacilityType.ESCALATOR, BilingualString("Escalator to Exit C1", "往 C1 出口扶手電梯"), FacilityStatus.OPEN),
                Facility("TST-T1", FacilityType.TOILET, BilingualString("Toilets inside Paid Area", "付費區內洗手間"), FacilityStatus.OPEN)
            ),
            crowding = CrowdingLevel.VERY_BUSY
        ),
        "MOK" to Station(
            id = "MOK",
            name = BilingualString("Mong Kok", "旺角"),
            lines = listOf("TWL", "KTL", "TML"),
            exits = listOf(
                StationExit("A1", listOf(BilingualString("Mong Kok Road", "旺角道")), 90, false, false, false),
                StationExit("C3", listOf(BilingualString("Langham Place", "朗豪坊"), BilingualString("Grand Destiny Hotel", "朗豪酒店")), 70, true, true, true),
                StationExit("E2", listOf(BilingualString("Ladies Market", "女人街"), BilingualString("Sai Yeung Choi Street", "西洋菜南街")), 150, false, false, true)
            ),
            facilities = listOf(
                Facility("MOK-L1", FacilityType.LIFT, BilingualString("Platform to Concourse Lift", "月台至大堂升降機"), FacilityStatus.OPEN),
                Facility("MOK-T1", FacilityType.TOILET, BilingualString("Mong Kok Toilet concourse level", "大堂層洗手間"), FacilityStatus.OPEN)
            ),
            crowding = CrowdingLevel.CRITICAL
        ),
        "CAB" to Station(
            id = "CAB",
            name = BilingualString("Causeway Bay", "銅鑼灣"),
            lines = listOf("ISL"),
            exits = listOf(
                StationExit("A", listOf(BilingualString("Times Square", "時代廣場"), BilingualString("Russell Street", "羅素街")), 200, true, true, true),
                StationExit("D1", listOf(BilingualString("SOGO Department Store", "崇光百貨")), 100, false, false, true),
                StationExit("F1", listOf(BilingualString("Hysan Place", "希慎廣場")), 120, true, true, true)
            ),
            facilities = listOf(
                Facility("CAB-L1", FacilityType.LIFT, BilingualString("Times Square Exit Lift", "時代廣場出口升降機"), FacilityStatus.OPEN),
                Facility("CAB-T1", FacilityType.TOILET, BilingualString("Causeway Bay Toilet near Exit F", "F 出口附近洗手間"), FacilityStatus.OPEN)
            ),
            crowding = CrowdingLevel.BUSY
        ),
        "TAK" to Station(
            id = "TAK",
            name = BilingualString("Tai Koo", "太古"),
            lines = listOf("ISL"),
            exits = listOf(
                StationExit("A", listOf(BilingualString("Kornhill Plaza", "康怡廣場")), 90, true, true, true),
                StationExit("D1", listOf(BilingualString("Cityplaza", "太古城中心"), BilingualString("One Island East", "港島東中心")), 120, true, true, true)
            ),
            facilities = listOf(
                Facility("TAK-L1", FacilityType.LIFT, BilingualString("Cityplaza Concourse Lift", "太古城中心大堂升降機"), FacilityStatus.OPEN)
            ),
            crowding = CrowdingLevel.MODERATE
        ),
        "QUB" to Station(
            id = "QUB",
            name = BilingualString("Quarry Bay", "鰂魚涌"),
            lines = listOf("ISL", "TKO", "KTL", "TML"),
            exits = listOf(
                StationExit("A", listOf(BilingualString("Taikoo Place", "太古坊"), BilingualString("King's Road", "英皇道")), 150, true, true, true),
                StationExit("C", listOf(BilingualString("Model Housing Estate", "模範邨")), 100, false, false, true)
            ),
            facilities = listOf(
                Facility("QUB-L1", FacilityType.LIFT, BilingualString("Interchange Platform Lift", "轉乘月台升降機"), FacilityStatus.OPEN)
            ),
            crowding = CrowdingLevel.BUSY
        ),
        "TKO" to Station(
            id = "TKO",
            name = BilingualString("Tseung Kwan O", "將軍澳"),
            lines = listOf("TKO"),
            exits = listOf(
                StationExit("A1", listOf(BilingualString("PopCorn Shopping Mall", "PopCorn 商場")), 60, true, true, true),
                StationExit("C", listOf(BilingualString("Tseung Kwan O Plaza", "將軍澳廣場")), 110, true, true, true)
            ),
            facilities = listOf(
                Facility("TKO-L1", FacilityType.LIFT, BilingualString("Concourse to Street Level Lift", "大堂至地面升降機"), FacilityStatus.OPEN)
            ),
            crowding = CrowdingLevel.MODERATE
        ),
        "SHA" to Station(
            id = "SHA",
            name = BilingualString("Shatin", "沙田"),
            lines = listOf("EAL"),
            exits = listOf(
                StationExit("A", listOf(BilingualString("New Town Plaza", "新城市廣場"), BilingualString("Shatin Bus Terminus", "沙田巴士總站")), 80, true, true, true),
                StationExit("B", listOf(BilingualString("Pai Tau Village", "排頭村")), 120, true, true, false)
            ),
            facilities = listOf(
                Facility("SHA-L1", FacilityType.LIFT, BilingualString("Platform to New Town Plaza Lift", "月台往新城市廣場升降機"), FacilityStatus.OPEN)
            ),
            crowding = CrowdingLevel.BUSY
        ),
        "TUM" to Station(
            id = "TUM",
            name = BilingualString("Tuen Mun", "屯門"),
            lines = listOf("TML"),
            exits = listOf(
                StationExit("A", listOf(BilingualString("V City Shopping Centre", "V City 商場")), 70, true, true, true),
                StationExit("C", listOf(BilingualString("Tuen Mun Town Plaza", "屯門市廣場")), 150, true, true, true)
            ),
            facilities = listOf(
                Facility("TUM-L1", FacilityType.LIFT, BilingualString("Concourse to Light Rail Platform Lift", "大堂至輕鐵月台升降機"), FacilityStatus.OPEN)
            ),
            crowding = CrowdingLevel.MODERATE
        ),
        "YUL" to Station(
            id = "YUL",
            name = BilingualString("Yuen Long", "元朗"),
            lines = listOf("TML"),
            exits = listOf(
                StationExit("B", listOf(BilingualString("YOHO MALL", "形點商場")), 80, true, true, true),
                StationExit("F", listOf(BilingualString("Yuen Long Light Rail Stop", "元朗輕鐵站")), 90, true, true, true)
            ),
            facilities = listOf(
                Facility("YUL-L1", FacilityType.LIFT, BilingualString("Exit B Mall Connector Lift", "B 出口商場連接升降機"), FacilityStatus.OPEN)
            ),
            crowding = CrowdingLevel.MODERATE
        ),
        "HOK" to Station(
            id = "HOK",
            name = BilingualString("Hong Kong", "香港"),
            lines = listOf("TCL", "AEL"),
            exits = listOf(
                StationExit("A", listOf(BilingualString("ifc Mall", "國際金融中心商場"), BilingualString("Central Piers", "中環碼頭")), 120, true, true, true),
                StationExit("E", listOf(BilingualString("Exchange Square", "交易廣場")), 100, true, true, true)
            ),
            facilities = listOf(
                Facility("HOK-L1", FacilityType.LIFT, BilingualString("In-town Check-in Hall Lift", "市區預辦登機大堂升降機"), FacilityStatus.OPEN),
                Facility("HOK-T1", FacilityType.TOILET, BilingualString("Universal Toilet Floor L1", "L1 層通用洗手間"), FacilityStatus.OPEN)
            ),
            crowding = CrowdingLevel.MODERATE
        ),
        "KOW" to Station(
            id = "KOW",
            name = BilingualString("Kowloon", "九龍"),
            lines = listOf("TCL", "AEL"),
            exits = listOf(
                StationExit("B", listOf(BilingualString("Elements Mall", "圓方商場")), 100, true, true, true),
                StationExit("M", listOf(BilingualString("West Kowloon Station link", "西九龍站連接通道")), 140, true, true, true)
            ),
            facilities = listOf(
                Facility("KOW-L1", FacilityType.LIFT, BilingualString("Elements Mall Interchange Lift", "圓方商場轉乘升降機"), FacilityStatus.OPEN)
            ),
            crowding = CrowdingLevel.LOW
        ),
        "TSY" to Station(
            id = "TSY",
            name = BilingualString("Tsing Yi", "青衣"),
            lines = listOf("TCL", "AEL"),
            exits = listOf(
                StationExit("A", listOf(BilingualString("Maritime Square", "青衣城")), 80, true, true, true)
            ),
            facilities = listOf(
                Facility("TSY-L1", FacilityType.LIFT, BilingualString("Maritime Square Connector", "青衣城連接升降機"), FacilityStatus.OPEN)
            ),
            crowding = CrowdingLevel.MODERATE
        ),
        "AIR" to Station(
            id = "AIR",
            name = BilingualString("Airport", "機場"),
            lines = listOf("AEL"),
            exits = listOf(
                StationExit("T1", listOf(BilingualString("Terminal 1 Departures", "一號客運大樓離港")), 50, true, true, true),
                StationExit("T2", listOf(BilingualString("SkyPlaza / Terminal 2", "二號客運大樓 / 翔天廊")), 60, true, true, true)
            ),
            facilities = listOf(
                Facility("AIR-L1", FacilityType.LIFT, BilingualString("Platform to Terminal 1 Elevator", "月台至一號客運大樓升降機"), FacilityStatus.OPEN),
                Facility("AIR-T1", FacilityType.TOILET, BilingualString("Airport Platform Toilets", "機場月台洗手間"), FacilityStatus.OPEN)
            ),
            crowding = CrowdingLevel.MODERATE
        ),
        "SUN" to Station(
            id = "SUN",
            name = BilingualString("Sunny Bay", "欣澳"),
            lines = listOf("TCL"),
            exits = listOf(
                StationExit("A", listOf(BilingualString("Disneyland Resort Line Connection", "迪士尼綫轉乘")), 40, true, true, false)
            ),
            facilities = listOf(),
            crowding = CrowdingLevel.LOW
        ),
        "WKS" to Station(
            id = "WKS",
            name = BilingualString("West Kowloon", "西九龍"),
            lines = listOf("HSR"),
            exits = listOf(
                StationExit("G", listOf(BilingualString("Green Plaza", "綠化空間")), 110, true, true, true),
                StationExit("N", listOf(BilingualString("Austin Station Interchange", "柯士甸站連接")), 130, true, true, true)
            ),
            facilities = listOf(
                Facility("WKS-L1", FacilityType.LIFT, BilingualString("Main Ticket Hall Lift", "主售票大堂升降機"), FacilityStatus.OPEN)
            ),
            crowding = CrowdingLevel.MODERATE
        )
    )

    // Average travel times between sequential stations on lines (in seconds)
    private val INTER_STATION_TIMES = mapOf(
        // Island Line
        ("CEN" to "ADM") to 150,
        ("ADM" to "CAB") to 180,
        ("CAB" to "QUB") to 210,
        ("QUB" to "TAK") to 160,
        // Tsuen Wan Line
        ("CEN" to "ADM") to 150,
        ("ADM" to "TST") to 180,
        ("TST" to "MOK") to 240,
        // Kwun Tong Line
        ("MOK" to "QUB") to 420, // aggregated
        // Tseung Kwan O Line
        ("QUB" to "TKO") to 280,
        // Tung Chung Line
        ("HOK" to "KOW") to 180,
        ("KOW" to "TSY") to 360,
        ("TSY" to "SUN") to 480,
        // Airport Express
        ("HOK" to "KOW") to 180,
        ("KOW" to "TSY") to 360,
        ("TSY" to "AIR") to 840,
        // East Rail Line
        ("ADM" to "SHA") to 620,
        // Tuen Ma Line
        ("TUM" to "YUL") to 380,
        ("YUL" to "MOK") to 820,
        ("MOK" to "QUB") to 420
    )

    // Station Walk Interchange linkages
    // Central <-> Hong Kong (walk)
    // Kowloon <-> West Kowloon (walk)
    val PHYSICAL_INTERCHANGES = listOf(
        Triple("CEN", "HOK", 300), // Central <-> Hong Kong (5 minutes walk)
        Triple("KOW", "WKS", 420)  // Kowloon <-> West Kowloon (7 minutes walk)
    )

    fun getTravelTime(s1: String, s2: String): Int {
        val direct = INTER_STATION_TIMES[s1 to s2] ?: INTER_STATION_TIMES[s2 to s1]
        if (direct != null) return direct

        // Check virtual interchanges
        val interchange = PHYSICAL_INTERCHANGES.find { 
            (it.first == s1 && it.second == s2) || (it.first == s2 && it.second == s1) 
        }
        if (interchange != null) return interchange.third

        return -1
    }

    // A Dijkstra-based shortest-path implementation
    // Supports: FASTEST, LEAST_WALKING, FEWEST_INTERCHANGES, ACCESSIBLE
    fun calculateRoute(
        fromId: String,
        toId: String,
        preference: RoutePreference,
        activeDisruptions: List<ServiceDisruption> = emptyList(),
        outOfServiceLifts: Set<String> = emptySet()
    ): JourneyResult? {
        if (!STATIONS.containsKey(fromId) || !STATIONS.containsKey(toId)) return null
        if (fromId == toId) {
            return createZeroDistanceJourney(fromId)
        }

        // Standard graph representation for the routing solver
        // We'll search across Station Nodes.
        // Key: StationId. Value: List of Edges (NeighborStationId, EdgeType, WeightSec, LineId)
        val graph = mutableMapOf<String, MutableList<SolverEdge>>()
        
        // Build the graph dynamically, injecting weights and disruptions
        for ((lineId, line) in LINES) {
            // Check if this line is completely suspended
            val isSuspended = activeDisruptions.any { it.lineId == lineId && it.severity == DisruptionSeverity.CRITICAL }
            if (isSuspended) continue

            // Check if there is a delay on this line
            val delayDisruption = activeDisruptions.find { it.lineId == lineId }
            val delayPenalty = when (delayDisruption?.severity) {
                DisruptionSeverity.WARNING -> 600 // 10 mins
                DisruptionSeverity.URGENT -> 1200 // 20 mins
                else -> 0
            }

            for (i in 0 until line.stations.size - 1) {
                val s1 = line.stations[i]
                val s2 = line.stations[i + 1]
                val baseTime = getTravelTime(s1, s2)
                if (baseTime > 0) {
                    val finalWeight = baseTime + delayPenalty
                    
                    // Add edges in both directions
                    graph.getOrPut(s1) { mutableListOf() }.add(SolverEdge(s2, EdgeType.RAIL, finalWeight, lineId))
                    graph.getOrPut(s2) { mutableListOf() }.add(SolverEdge(s1, EdgeType.RAIL, finalWeight, lineId))
                }
            }
        }

        // Add physical transfer edges (e.g., Central <-> Hong Kong)
        for (interchange in PHYSICAL_INTERCHANGES) {
            val s1 = interchange.first
            val s2 = interchange.second
            var walkTime = interchange.third

            // If wheelchair accessible mode is enabled, check if transfer remains available (or applies lift penalty)
            if (preference == RoutePreference.ACCESSIBLE) {
                val hasOutage = outOfServiceLifts.any { it.startsWith(s1) || it.startsWith(s2) }
                if (hasOutage) {
                    walkTime += 300 // Add 5 minutes lift detours
                }
            }

            graph.getOrPut(s1) { mutableListOf() }.add(SolverEdge(s2, EdgeType.WALK, walkTime, null))
            graph.getOrPut(s2) { mutableListOf() }.add(SolverEdge(s1, EdgeType.WALK, walkTime, null))
        }

        // Dijkstra algorithm
        val dist = mutableMapOf<String, Int>()
        val parent = mutableMapOf<String, SolverEdge>()
        
        // Priority Queue elements: Pair of (StationId, PathWeight)
        val pq = PriorityQueue<Pair<String, Int>>(compareBy { it.second })

        dist[fromId] = 0
        pq.add(fromId to 0)

        while (pq.isNotEmpty()) {
            val (current, currentDist) = pq.poll() ?: break

            if (current == toId) break // Found destination
            if (currentDist > (dist[current] ?: Int.MAX_VALUE)) continue

            val edges = graph[current] ?: continue
            for (edge in edges) {
                // Determine weight penalty based on passenger preferences
                var edgeWeight = edge.weightSeconds

                // Accessibility check: Ensure that the target station is open and exits are accessible
                if (preference == RoutePreference.ACCESSIBLE) {
                    val targetStation = STATIONS[edge.target]
                    val isStationInaccessible = targetStation?.isClosed == true || 
                        outOfServiceLifts.any { it.startsWith(edge.target) }
                    
                    if (isStationInaccessible) {
                        edgeWeight += 3600 // Huge penalty to force detour
                    }
                }

                // If LEAST_WALKING, increase weight for pedestrian transfers
                if (preference == RoutePreference.LEAST_WALKING && edge.type == EdgeType.WALK) {
                    edgeWeight *= 3 // Penalize walking transfers heavily
                }

                // If FEWEST_INTERCHANGES, penalize switching lines
                if (preference == RoutePreference.FEWEST_INTERCHANGES) {
                    val prevEdge = parent[current]
                    if (prevEdge != null && prevEdge.lineId != edge.lineId) {
                        edgeWeight += 600 // 10 minutes penalty for switching lines
                    }
                }

                val newDist = currentDist + edgeWeight
                if (newDist < (dist[edge.target] ?: Int.MAX_VALUE)) {
                    dist[edge.target] = newDist
                    parent[edge.target] = SolverEdge(current, edge.type, edge.weightSeconds, edge.lineId)
                    pq.add(edge.target to newDist)
                }
            }
        }

        // Reconstruct path
        val pathEdges = mutableListOf<SolverEdge>()
        var curr = toId
        while (curr != fromId) {
            val pEdge = parent[curr] ?: return null // No path found
            pathEdges.add(pEdge)
            curr = pEdge.target
        }
        pathEdges.reverse()

        // Distribute segments and translate them
        val segments = mutableListOf<RouteSegment>()
        var accumulatedTime = 0
        var totalWalkTime = 0
        var interchanges = 0
        var prevLineId: String? = null

        // Group sequentials by lineId or walk type to make neat route segments
        var currentFrom = fromId
        var currentType = pathEdges.first().type
        var currentLineId = pathEdges.first().lineId
        var segmentDuration = 0
        
        for (i in pathEdges.indices) {
            val edge = pathEdges[i]
            val nextStation = if (i == pathEdges.size - 1) toId else pathEdges[i+1].target
            
            segmentDuration += edge.weightSeconds
            accumulatedTime += edge.weightSeconds
            if (edge.type == EdgeType.WALK) {
                totalWalkTime += edge.weightSeconds
            }

            val lineChanged = edge.lineId != currentLineId || edge.type != currentType
            if (lineChanged || i == pathEdges.size - 1) {
                // Complete segment
                val actualTo = edge.target
                val lineLabel = currentLineId?.let { LINES[it]?.name?.get(false) } ?: "Walk"
                val segmentDetails = if (currentType == EdgeType.RAIL) {
                    BilingualString(
                        "Board $lineLabel at ${STATIONS[currentFrom]?.name?.en} Platform 2",
                        "於 ${STATIONS[currentFrom]?.name?.zh} 2 號月台乘搭 $lineLabel"
                    )
                } else {
                    BilingualString(
                        "Walk between ${STATIONS[currentFrom]?.name?.en} and ${STATIONS[actualTo]?.name?.en}",
                        "於 ${STATIONS[currentFrom]?.name?.zh} 及 ${STATIONS[actualTo]?.name?.zh} 之間步行轉乘"
                    )
                }

                if (currentType == EdgeType.RAIL && prevLineId != null && prevLineId != currentLineId) {
                    interchanges++
                }
                if (currentType == EdgeType.RAIL) {
                    prevLineId = currentLineId
                }

                segments.add(
                    RouteSegment(
                        type = currentType,
                        lineId = currentLineId,
                        fromStationId = currentFrom,
                        toStationId = actualTo,
                        details = segmentDetails,
                        durationSeconds = segmentDuration,
                        platform = if (currentType == EdgeType.RAIL) "Platform 2" else null
                    )
                )

                // Start next segment
                currentFrom = edge.target
                currentType = edge.type
                currentLineId = edge.lineId
                segmentDuration = 0
            }
        }

        // Clean up last segment edge cases if any
        if (segmentDuration > 0) {
            val lineLabel = currentLineId?.let { LINES[it]?.name?.get(false) } ?: "Walk"
            segments.add(
                RouteSegment(
                    type = currentType,
                    lineId = currentLineId,
                    fromStationId = currentFrom,
                    toStationId = toId,
                    details = BilingualString(
                        "Board $lineLabel to ${STATIONS[toId]?.name?.en}",
                        "乘搭 $lineLabel 抵達 ${STATIONS[toId]?.name?.zh}"
                    ),
                    durationSeconds = segmentDuration
                )
            )
        }

        // Calculate Fares
        val baseFare = calculateFare(fromId, toId, PassengerType.ADULT, PaymentMethod.OCTOPUS)

        // Build Timeline
        val timeline = mutableListOf<TimelineItem>()
        var runningTimeSec = 0
        val startTime = "08:42" // Base departure time
        
        timeline.add(
            TimelineItem(
                formatTimeOffset(startTime, 0),
                BilingualString("Enter ${STATIONS[fromId]?.name?.en} Station", "進入 ${STATIONS[fromId]?.name?.zh}")
            )
        )

        for (seg in segments) {
            val fromName = STATIONS[seg.fromStationId]?.name
            val toName = STATIONS[seg.toStationId]?.name
            
            if (seg.type == EdgeType.RAIL) {
                runningTimeSec += 120 // Walk to platform
                timeline.add(
                    TimelineItem(
                        formatTimeOffset(startTime, runningTimeSec),
                        BilingualString("Platform 2: Board ${LINES[seg.lineId]?.name?.en}", "2 號月台：登上 ${LINES[seg.lineId]?.name?.zh}")
                    )
                )
                runningTimeSec += seg.durationSeconds
                timeline.add(
                    TimelineItem(
                        formatTimeOffset(startTime, runningTimeSec),
                        BilingualString("Departing train arrives at ${toName?.en}", "列車抵達 ${toName?.zh}")
                    )
                )
            } else {
                timeline.add(
                    TimelineItem(
                        formatTimeOffset(startTime, runningTimeSec),
                        BilingualString("Begin transfer walking corridor", "開始步行轉乘通道")
                    )
                )
                runningTimeSec += seg.durationSeconds
                timeline.add(
                    TimelineItem(
                        formatTimeOffset(startTime, runningTimeSec),
                        BilingualString("Arrived at transfer platform", "抵達轉乘月台")
                    )
                )
            }
        }

        timeline.add(
            TimelineItem(
                formatTimeOffset(startTime, runningTimeSec + 60),
                BilingualString("Tap out through gate. Arrived.", "出閘，行程結束。")
            )
        )

        val totalMinutes = Math.max(1, (runningTimeSec + 180) / 60)
        val walkMinutes = Math.max(1, (totalWalkTime + 120) / 60)

        // Accessibility confirmation
        val isAccessible = segments.none { seg ->
            seg.type == EdgeType.WALK && outOfServiceLifts.any { lift ->
                lift.startsWith(seg.fromStationId) || lift.startsWith(seg.toStationId)
            }
        }

        return JourneyResult(
            fromStationId = fromId,
            toStationId = toId,
            totalDurationMinutes = totalMinutes,
            walkingDurationMinutes = walkMinutes,
            interchangesCount = interchanges,
            totalFare = baseFare,
            segments = segments,
            timeline = timeline,
            isAccessible = isAccessible
        )
    }

    private fun createZeroDistanceJourney(stationId: String): JourneyResult {
        val sName = STATIONS[stationId]?.name ?: BilingualString("Here", "此站")
        return JourneyResult(
            fromStationId = stationId,
            toStationId = stationId,
            totalDurationMinutes = 0,
            walkingDurationMinutes = 0,
            interchangesCount = 0,
            totalFare = 0.0,
            segments = emptyList(),
            timeline = listOf(
                TimelineItem("08:42", BilingualString("You are already at ${sName.en}", "你已身處 ${sName.zh}"))
            ),
            isAccessible = true
        )
    }

    // Dynamic Fare Engine with support for multiple Payment rails, Passenger Types, and Discounts
    fun calculateFare(
        fromId: String,
        toId: String,
        passenger: PassengerType,
        payment: PaymentMethod
    ): Double {
        if (fromId == toId) return 0.0

        // Fictional fare matrix based on physical distance / zone counts
        var baseFare = 4.80 // Minimum fare in HKD

        val isAirportJourney = fromId == "AIR" || toId == "AIR"
        val isHsrJourney = fromId == "WKS" || toId == "WKS"

        if (isAirportJourney) {
            baseFare = 110.00 // Airport Express Flat rate
        } else if (isHsrJourney) {
            baseFare = 85.00 // High Speed Rail Base Fare
        } else {
            // Count nodes traversal
            val s1 = STATIONS[fromId]
            val s2 = STATIONS[toId]
            if (s1 != null && s2 != null) {
                val path = runBFSCount(fromId, toId)
                baseFare = 4.80 + (path * 1.80)
            }
        }

        // Concessions and promotions
        var finalFare = baseFare
        if (passenger == PassengerType.CONCESSION) {
            finalFare = if (isAirportJourney) baseFare * 0.5 else 2.00 // Government $2 JoyYou/Elderly Scheme
        } else if (passenger == PassengerType.TOURIST) {
            finalFare = if (isAirportJourney) baseFare else 0.00 // Unlimited travel included in tourist day pass
        }

        // Payment rail rules and discounts
        when (payment) {
            PaymentMethod.OCTOPUS -> finalFare *= 0.95 // 5% Octopus Card discount
            PaymentMethod.CONTACTLESS_BANK_CARD -> finalFare *= 1.0 // Standard Visa/MC transit rate
            PaymentMethod.QR -> finalFare *= 1.0
            PaymentMethod.DIGITAL_TICKET -> finalFare += 1.00 // Single journey physical overhead
        }

        return Math.round(finalFare * 10) / 10.0 // Round to 1 decimal place
    }

    private fun runBFSCount(fromId: String, toId: String): Int {
        val queue = ArrayDeque<Pair<String, Int>>()
        val visited = mutableSetOf<String>()
        queue.add(fromId to 0)
        visited.add(fromId)

        while (queue.isNotEmpty()) {
            val (curr, dist) = queue.removeFirst()
            if (curr == toId) return dist

            val station = STATIONS[curr] ?: continue
            for (lineId in station.lines) {
                val lineStations = LINES[lineId]?.stations ?: continue
                val index = lineStations.indexOf(curr)
                if (index > 0) {
                    val prev = lineStations[index - 1]
                    if (visited.add(prev)) queue.add(prev to dist + 1)
                }
                if (index < lineStations.size - 1) {
                    val next = lineStations[index + 1]
                    if (visited.add(next)) queue.add(next to dist + 1)
                }
            }
            // Add virtual walk interchange linkages
            for (inter in PHYSICAL_INTERCHANGES) {
                if (inter.first == curr && visited.add(inter.second)) queue.add(inter.second to dist + 1)
                if (inter.second == curr && visited.add(inter.first)) queue.add(inter.first to dist + 1)
            }
        }
        return 3 // Default fallback
    }

    private fun formatTimeOffset(baseTime: String, offsetSeconds: Int): String {
        val parts = baseTime.split(":")
        val hours = parts[0].toInt()
        val minutes = parts[1].toInt()
        
        val totalMinutes = hours * 60 + minutes + (offsetSeconds / 60)
        val finalHours = (totalMinutes / 60) % 24
        val finalMinutes = totalMinutes % 60
        
        return String.format("%02d:%02d", finalHours, finalMinutes)
    }

    private data class SolverEdge(
        val target: String,
        val type: EdgeType,
        val weightSeconds: Int,
        val lineId: String?
    )
}

enum class RoutePreference {
    FASTEST, LEAST_WALKING, FEWEST_INTERCHANGES, ACCESSIBLE
}
