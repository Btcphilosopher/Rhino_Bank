package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.RoutePreference
import com.example.engine.RoutingEngine
import com.example.model.*
import com.example.viewmodel.MetroViewModel
import com.example.viewmodel.SimScenario
import com.example.viewmodel.TapState
import com.example.viewmodel.TwinObject

// ==========================================
// 1. HOME DASHBOARD SCREEN
// ==========================================
@Composable
fun HomeScreen(
    viewModel: MetroViewModel,
    isZh: Boolean,
    onNavigateToTab: (String) -> Unit
) {
    val liveTrains by viewModel.liveTrains.collectAsState()
    val activeDisruptions by viewModel.activeDisruptions.collectAsState()

    // Find next train departing from Central
    val centralNextTrain = liveTrains.find { it.currentStationId == "CEN" }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("home_screen_column")
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome Header Section
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isZh) "早晨" else "GOOD MORNING",
                        color = Color.LightGray,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.DirectionsTransit,
                            contentDescription = null,
                            tint = Color(0xFFC80A12),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isZh) "中環" else "CENTRAL",
                            color = Color.White,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }
        }

        // Live Next Train Counter Card (Bilingual Next Train block)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("next_train_card"),
                border = BorderStroke(1.dp, Color(0xFFC80A12))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isZh) "下一班列車" else "NEXT TRAIN",
                            color = Color(0xFFC80A12),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Badge(containerColor = Color(0xFF007BC4)) {
                            Text("Island Line 港島綫", color = Color.White, fontSize = 9.sp, modifier = Modifier.padding(2.dp))
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("CENTRAL", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(Icons.AutoMirrored.Filled.ArrowForward, null, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("TAI KOO", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                            Text(if (isZh) "中環 往 太古 (經金鐘)" else "Central to Tai Koo via Admiralty", color = Color.Gray, fontSize = 11.sp)
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            val etaMin = centralNextTrain?.etaSeconds?.div(60) ?: 2
                            Text(
                                text = if (isZh) "$etaMin 分鐘" else "$etaMin MIN",
                                color = Color(0xFFC80A12),
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = if (isZh) "月台 3" else "Platform 3",
                                fontSize = 11.sp,
                                color = Color.DarkGray,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Service Status Overview (Dynamic Bilingual)
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isZh) "車務狀況" else "SERVICE STATUS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.DarkGray
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    if (activeDisruptions.isEmpty()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .background(Color(0xFF34C759), CircleShape)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = if (isZh) "所有路綫正常運作" else "ALL LINES NORMAL SERVICE",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF34C759)
                            )
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            for (dis in activeDisruptions) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .background(Color(0xFFFF3B30), CircleShape)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = dis.title.get(isZh),
                                        color = Color(0xFFFF3B30),
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Quick Personal Journey Shortcuts
        item {
            Column {
                Text(
                    text = if (isZh) "常用快速行程" else "PERSONAL JOURNEYS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Gray,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val shortcuts = listOf(
                        "HOME" to if (isZh) "回家" else "HOME",
                        "WORK" to if (isZh) "上班" else "WORK",
                        "AIRPORT" to if (isZh) "機場" else "AIRPORT",
                        "BORDER" to if (isZh) "過境" else "BORDER"
                    )
                    for (sh in shortcuts) {
                        Button(
                            onClick = {
                                viewModel.setJourneyShortcut(sh.first)
                                onNavigateToTab("JOURNEY")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp)
                        ) {
                            Text(sh.second, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Nearby Station Information Section
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isZh) "附近車站設施" else "NEARBY STATION FACILITIES",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.DarkGray
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = if (isZh) "香港站 / 中環站 (已連接)" else "Hong Kong Station / Central Station (Connected)",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (isZh) "設有：市區預辦登機 | 升降機 | 洗手間 | 商店" else "Features: In-Town Check-in | Lifts | Toilet | Shops",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }
            }
        }
    }
}


// ==========================================
// 2. JOURNEY PLANNER TIMELINE SCREEN
// ==========================================
@Composable
fun JourneyPlannerScreen(
    viewModel: MetroViewModel,
    isZh: Boolean
) {
    val fromId by viewModel.fromStation.collectAsState()
    val toId by viewModel.toStation.collectAsState()
    val calculatedRoute by viewModel.calculatedRoute.collectAsState()
    val pref by viewModel.routePreference.collectAsState()
    val activeDisruptions by viewModel.activeDisruptions.collectAsState()

    var showFromPicker by remember { mutableStateOf(false) }
    var showToPicker by remember { mutableStateOf(false) }

    val stations = RoutingEngine.STATIONS.values.toList()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("journey_planner_screen")
            .padding(16.dp)
    ) {
        // From/To inputs
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // From Station Button Selector
            OutlinedButton(
                onClick = { showFromPicker = true },
                modifier = Modifier
                    .weight(1f)
                    .testTag("from_station_picker_btn")
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (isZh) "出發地 FROM" else "FROM", fontSize = 10.sp, color = Color.Gray)
                    Text(
                        text = RoutingEngine.STATIONS[fromId]?.name?.get(isZh) ?: fromId,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                }
            }

            // Swap icon
            IconButton(
                onClick = {
                    val tmp = fromId
                    viewModel.setFromStation(toId)
                    viewModel.setToStation(tmp)
                },
                modifier = Modifier.align(Alignment.CenterVertically)
            ) {
                Icon(Icons.Default.SwapHoriz, "swap", tint = Color(0xFFC80A12))
            }

            // To Station Button Selector
            OutlinedButton(
                onClick = { showToPicker = true },
                modifier = Modifier
                    .weight(1f)
                    .testTag("to_station_picker_btn")
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (isZh) "目的地 TO" else "TO", fontSize = 10.sp, color = Color.Gray)
                    Text(
                        text = RoutingEngine.STATIONS[toId]?.name?.get(isZh) ?: toId,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                }
            }
        }

        // Selection Pickers visibility drawers
        if (showFromPicker) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Text(if (isZh) "選擇起點車站" else "SELECT START STATION", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Row(modifier = Modifier.fillMaxWidth()) {
                        stations.take(6).forEach { station ->
                            Button(
                                onClick = {
                                    viewModel.setFromStation(station.id)
                                    showFromPicker = false
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                modifier = Modifier
                                    .padding(4.dp)
                                    .weight(1f),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text(station.name.get(isZh), fontSize = 9.sp)
                            }
                        }
                    }
                }
            }
        }

        if (showToPicker) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Text(if (isZh) "選擇終點車站" else "SELECT DESTINATION", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Row(modifier = Modifier.fillMaxWidth()) {
                        stations.take(6).forEach { station ->
                            Button(
                                onClick = {
                                    viewModel.setToStation(station.id)
                                    showToPicker = false
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                modifier = Modifier
                                    .padding(4.dp)
                                    .weight(1f),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text(station.name.get(isZh), fontSize = 9.sp)
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Preference Selection Filters row
        Text(
            text = if (isZh) "路線偏好選擇" else "ROUTE CRITERIA PREFERENCE",
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Gray
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            val preferences = listOf(
                RoutePreference.FASTEST to (if (isZh) "最快" else "FASTEST"),
                RoutePreference.LEAST_WALKING to (if (isZh) "最少步行" else "MIN WALK"),
                RoutePreference.FEWEST_INTERCHANGES to (if (isZh) "最少轉乘" else "FEW TRANS"),
                RoutePreference.ACCESSIBLE to (if (isZh) "無障礙" else "STEP-FREE")
            )
            for (p in preferences) {
                val isSelected = pref == p.first
                Button(
                    onClick = { viewModel.setRoutePreference(p.first) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSelected) Color(0xFFC80A12) else MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = if (isSelected) Color.White else Color.Black
                    ),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(vertical = 6.dp, horizontal = 2.dp)
                ) {
                    Text(p.second, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Route calculation display card
        calculatedRoute?.let { route ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Summary Header row
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = if (isZh) "預估總時間" else "ESTIMATED TOTAL",
                                    fontSize = 10.sp,
                                    color = Color.Gray
                                )
                                Text(
                                    text = "${route.totalDurationMinutes} MIN / 分鐘",
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFFC80A12)
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = if (isZh) "成人八達通票價" else "OCTOPUS FARE",
                                    fontSize = 10.sp,
                                    color = Color.Gray
                                )
                                Text(
                                    text = "HK$${String.format("%.1f", route.totalFare)}",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black
                                )
                            }
                        }
                    }

                    // Accessibility notice badge if route is verified
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Badge(containerColor = if (route.isAccessible) Color(0xFF34C759) else Color(0xFFFF9500)) {
                                Text(
                                    text = if (route.isAccessible) {
                                        if (isZh) "無障礙路線符合" else "ACCESSIBLE ROUTE FOUND"
                                    } else {
                                        if (isZh) "注意：非全無障礙" else "PARTIAL BARRIER-FREE ONLY"
                                    },
                                    color = Color.White,
                                    fontSize = 9.sp,
                                    modifier = Modifier.padding(3.dp),
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Badge(containerColor = MaterialTheme.colorScheme.secondary) {
                                Text(
                                    text = if (isZh) "步行 ${route.walkingDurationMinutes} 分鐘" else "Walk: ${route.walkingDurationMinutes}m",
                                    color = Color.White,
                                    fontSize = 9.sp,
                                    modifier = Modifier.padding(3.dp)
                                )
                            }
                        }
                    }

                    // Interactive Bilingual Timeline nodes
                    item {
                        Divider(modifier = Modifier.padding(vertical = 8.dp))
                        Text(
                            text = if (isZh) "行程導航指示" else "JOURNEY PATH WAYFINDING",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Gray
                        )
                    }

                    items(route.timeline) { item ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color.Black),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = item.time,
                                    color = Color.Yellow,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = item.event.get(isZh),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Fast exit selection hints
                    item {
                        Divider(modifier = Modifier.padding(vertical = 10.dp))
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF121212)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.FlashOn, null, tint = Color.Yellow, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (isZh) "捷徑快速出站車廂提示" else "FAST EXIT CARRIAGE POSITIONING",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = if (isZh) "乘車指示：請登上第 4 卡車廂 ｜ 離站：使用 D2 出口 ｜ 步行：約 90 米 (約 1:40)" else "Position: Board Carriage 4 | Outbound: Exit D2 | Distance: 90 meters (1:40)",
                                    fontSize = 11.sp,
                                    color = Color.LightGray
                                )
                            }
                        }
                    }
                }
            }
        } ?: run {
            // Null route fallback
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isZh) "列車服務受阻，或無可行轉乘路線。" else "No route matches current filters or active disruptions.",
                    textAlign = TextAlign.Center,
                    color = Color.Gray,
                    fontSize = 14.sp
                )
            }
        }
    }
}


// ==========================================
// 3. STATION DIGITAL TWIN & ASSETS SCREEN
// ==========================================
@Composable
fun StationTwinScreen(
    viewModel: MetroViewModel,
    isZh: Boolean
) {
    val twinStationId by viewModel.selectedTwinStationId.collectAsState()
    val selectedTwinObject by viewModel.selectedTwinObject.collectAsState()
    val assets by viewModel.assets.collectAsState()

    var twinLevel by remember { mutableStateOf("PLATFORM") } // STREET, CONCOURSE, PLATFORM, TRAIN

    val mockLevels = listOf(
        "STREET" to (if (isZh) "街道層" else "STREET LEVEL"),
        "CONCOURSE" to (if (isZh) "大堂層" else "CONCOURSE"),
        "PLATFORM" to (if (isZh) "月台層" else "PLATFORMS"),
        "TRAIN" to (if (isZh) "列車車廂" else "INSIDE TRAIN")
    )

    val simulatedObjects = listOf(
        TwinObject("OBJ-01", "Station Main Lift L2", "大堂中央 L2 號升降機", "AST-801", BilingualString("Hydraulic passenger access", "大堂至地面油壓客用升降機")),
        TwinObject("OBJ-02", "Interchange Escalator E3", "轉乘扶手電梯 E3", "AST-511", BilingualString("Heavy duty platform link", "L1至L2層重型扶手電梯")),
        TwinObject("OBJ-03", "Auto-Turnstile Gate 12", "智慧刷卡閘機 12", "AST-951", BilingualString("NFC Octopus Reader", "付費區自動閘機閘口")),
        TwinObject("OBJ-04", "ATC Signal Transceiver 4A", "信號收發盒 4A", "AST-102", BilingualString("Automatic signaling box", "軌道安全自動化控制天線箱"))
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("station_twin_screen")
            .padding(16.dp)
    ) {
        // Station selection header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (isZh) "車站數碼雙生系統" else "STATION DIGITAL TWIN OS",
                fontSize = 14.sp,
                fontWeight = FontWeight.Black,
                color = Color(0xFFC80A12)
            )

            // Select Admiralty or Central
            Row {
                Button(
                    onClick = { viewModel.selectTwinObject(null) },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text("ADMIRALTY 金鐘", fontSize = 10.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Level selector selector rows
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            for (lvl in mockLevels) {
                val isSelected = twinLevel == lvl.first
                Button(
                    onClick = { twinLevel = lvl.first },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSelected) Color(0xFFC80A12) else MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = if (isSelected) Color.White else Color.Black
                    ),
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(4.dp),
                    contentPadding = PaddingValues(vertical = 4.dp, horizontal = 2.dp)
                ) {
                    Text(lvl.second, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 3D Schematic layout rendering using geometric lines representation
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Black)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                // Render stylized isometric vectors representation on Canvas
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "ADMIRALTY DIGITAL-TWIN SCHEMATIC",
                        color = Color.LightGray,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    // Represent schematic nodes vertically matching chosen levels
                    Box(modifier = Modifier.fillMaxWidth().height(100.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceAround,
                            modifier = Modifier.fillMaxWidth().align(Alignment.Center)
                        ) {
                            for (obj in simulatedObjects) {
                                val isSelected = selectedTwinObject?.id == obj.id
                                Card(
                                    modifier = Modifier
                                        .size(60.dp)
                                        .clickable { viewModel.selectTwinObject(obj) }
                                        .border(
                                            2.dp,
                                            if (isSelected) Color(0xFFC80A12) else Color.White,
                                            RoundedCornerShape(6.dp)
                                        ),
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF23232C))
                                ) {
                                    Column(
                                        modifier = Modifier.padding(4.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        Icon(
                                            imageVector = when (obj.id) {
                                                "OBJ-01" -> Icons.Default.Elevator
                                                "OBJ-02" -> Icons.Default.TrendingUp
                                                "OBJ-03" -> Icons.Default.ConfirmationNumber
                                                else -> Icons.Default.CellTower
                                            },
                                            contentDescription = null,
                                            tint = if (isSelected) Color(0xFFC80A12) else Color.Yellow,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Text(
                                            text = if (isZh) obj.nameZh.take(4) else obj.nameEn.take(10),
                                            fontSize = 8.sp,
                                            color = Color.White,
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                }
                            }
                        }
                    }
                    Text(
                        text = "SELECT OBJECT TO RETRIEVE ASSET TELEMETRY",
                        color = Color.Gray,
                        fontSize = 8.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Selected Asset Telemetry Display Desk
        selectedTwinObject?.let { obj ->
            val correspondingAsset = assets.find { it.id == obj.assetId }
            correspondingAsset?.let { asset ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .testTag("asset_telemetry_card"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "ASSET ID: ${asset.id}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.Gray
                                    )
                                    Text(
                                        text = asset.name.get(isZh),
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Badge(containerColor = Color(android.graphics.Color.parseColor(asset.status.colorHex))) {
                                    Text(
                                        text = asset.status.label.get(isZh),
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        modifier = Modifier.padding(4.dp),
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Divider(modifier = Modifier.padding(vertical = 6.dp))
                        }

                        // Specific telemetry fields
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(if (isZh) "設備種類" else "ASSET TYPE", fontSize = 9.sp, color = Color.Gray)
                                    Text(asset.type.label.get(isZh), fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(if (isZh) "運作壽命 (年)" else "AGE (YEARS)", fontSize = 9.sp, color = Color.Gray)
                                    Text("${asset.ageYears} Yrs", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(if (isZh) "上次維護日期" else "LAST INSPECTION", fontSize = 9.sp, color = Color.Gray)
                                    Text(asset.lastInspectionDate, fontSize = 11.sp)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(if (isZh) "下一次保養" else "NEXT MAINTENANCE", fontSize = 9.sp, color = Color.Gray)
                                    Text(asset.nextServiceDate, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        // Maintenance History list
                        item {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = if (isZh) "設備保養記錄歷史" else "MAINTENANCE SERVICE HISTORY LOGS",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray
                            )
                        }

                        items(asset.maintenanceHistory) { record ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.05f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(modifier = Modifier.padding(6.dp)) {
                                    Icon(Icons.Default.Build, null, modifier = Modifier.size(12.dp), tint = Color.DarkGray)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(record, fontSize = 11.sp)
                                }
                            }
                        }

                        // Fail-safe simulation triggers (Trigger lift outage/repair)
                        if (asset.type == AssetType.LIFT) {
                            item {
                                Spacer(modifier = Modifier.height(4.dp))
                                Button(
                                    onClick = { viewModel.triggerLiftOutage(twinStationId, asset.id) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF3B30)),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(if (isZh) "模擬升降機發生故障" else "SIMULATE LIFT OUTAGE FAULT", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        } ?: run {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isZh) "未選擇硬體設備，請點擊上圖的傳感器節點。" else "No asset selected. Tap on a structural sensor icon above to view real-time data.",
                    color = Color.Gray,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}


// ==========================================
// 4. TICKETS & CONTACTLESS PAYMENT GATE SCREEN
// ==========================================
@Composable
fun TicketsScreen(
    viewModel: MetroViewModel,
    isZh: Boolean
) {
    val balance by viewModel.octopusBalance.collectAsState()
    val points by viewModel.metroPoints.collectAsState()
    val tapState by viewModel.tapState.collectAsState()
    val tapRecord by viewModel.tapRecord.collectAsState()
    val history by viewModel.travelHistory.collectAsState()
    val activeTickets by viewModel.activeTickets.collectAsState()

    var activeTab by remember { mutableStateOf("TAP") } // TAP, SHOP, HISTORY

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("tickets_screen")
            .padding(16.dp)
    ) {
        // Octopus & Points balance bar
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondary)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(if (isZh) "我的虛擬八達通餘額" else "SIMULATED OCTOPUS BALANCE", fontSize = 10.sp, color = Color.LightGray)
                    Text("HK$${String.format("%.1f", balance)}", fontSize = 24.sp, fontWeight = FontWeight.Black, color = Color.White)
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(if (isZh) "港鐵獎賞積分" else "METRO POINTS", fontSize = 10.sp, color = Color.LightGray)
                    Text("$points PTS", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFF9500))
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Tickets sub nav row
        Row(modifier = Modifier.fillMaxWidth()) {
            val tabs = listOf(
                "TAP" to (if (isZh) "刷卡閘機模擬" else "GATE SIMULATOR"),
                "SHOP" to (if (isZh) "購買電子車票" else "TICKET PRODUCT"),
                "HISTORY" to (if (isZh) "乘車歷史記錄" else "JOURNEY HISTORY")
            )
            for (t in tabs) {
                val isSelected = activeTab == t.first
                Button(
                    onClick = { activeTab = t.first },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSelected) Color(0xFFC80A12) else MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = if (isSelected) Color.White else Color.Black
                    ),
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(4.dp),
                    contentPadding = PaddingValues(vertical = 4.dp, horizontal = 2.dp)
                ) {
                    Text(t.second, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        when (activeTab) {
            "TAP" -> {
                // TAP IN / OUT Simulator screen
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (isZh) "無感支付閘機通行模擬" else "NFC CONTACTLESS TRANSIT GATE SIMULATION",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Gray
                        )

                        // Visual indicator of current gate state
                        Card(
                            modifier = Modifier
                                .size(130.dp)
                                .clip(CircleShape),
                            colors = CardDefaults.cardColors(
                                containerColor = when (tapState) {
                                    TapState.TAPPED_IN -> Color(0xFF34C759)
                                    TapState.TAPPED_OUT -> Color(0xFF007AFF)
                                    else -> Color(0xFFC80A12)
                                }
                            )
                        ) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        imageVector = when (tapState) {
                                            TapState.TAPPED_IN -> Icons.Default.Done
                                            TapState.TAPPED_OUT -> Icons.Default.ReceiptLong
                                            else -> Icons.Default.Nfc
                                        },
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(36.dp)
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = tapState.label.get(isZh),
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }

                        // Simulation buttons
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            when (tapState) {
                                TapState.OUT_OF_STATION -> {
                                    Button(
                                        onClick = { viewModel.triggerTapIn("CEN", PaymentMethod.OCTOPUS) },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF34C759)),
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(if (isZh) "模擬 於中環站 刷卡進閘" else "TAP IN AT CENTRAL", fontWeight = FontWeight.Bold)
                                    }
                                }
                                TapState.TAPPED_IN -> {
                                    Button(
                                        onClick = { viewModel.triggerTapOut("TST", PaymentMethod.OCTOPUS) },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF007AFF)),
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(if (isZh) "模擬 於尖沙咀站 刷卡出閘" else "TAP OUT AT TSIM SHA TSUI", fontWeight = FontWeight.Bold)
                                    }
                                }
                                TapState.TAPPED_OUT -> {
                                    // Show final receipt
                                    tapRecord?.let { record ->
                                        Card(
                                            modifier = Modifier.fillMaxWidth(),
                                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                                        ) {
                                            Column(modifier = Modifier.padding(10.dp)) {
                                                Text(if (isZh) "模擬乘車電子票據" else "SIMULATED RIDE RECEIPT", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                                                Text("ID: ${record.id} | Token: ${record.cardToken.take(15)}...", fontSize = 9.sp, color = Color.Gray)
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text(if (isZh) "起點站：中環站 (${record.entryTime})" else "From: Central (${record.entryTime})", fontSize = 12.sp)
                                                Text(if (isZh) "訖點站：尖沙咀站 (${record.exitTime})" else "To: Tsim Sha Tsui (${record.exitTime})", fontSize = 12.sp)
                                                Text(if (isZh) "實扣金額：HK$${record.fare}" else "Deducted: HK$${record.fare}", fontWeight = FontWeight.Bold, color = Color(0xFFC80A12))
                                            }
                                        }
                                    }

                                    Button(
                                        onClick = { viewModel.resetTapJourney() },
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(if (isZh) "重設進出站模擬" else "RESET SIMULATOR")
                                    }
                                }
                            }
                        }
                    }
                }
            }

            "SHOP" -> {
                // Buy mock tickets products
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val ticketProducts = listOf(
                        Triple("Tourist Day Pass / 遊客地鐵一日通", 65.0, BilingualString("24-hours unlimited rides", "24小時內無限乘搭")),
                        Triple("Airport Express Single (Kowloon) / 機場快綫單程 (九龍)", 105.0, BilingualString("Fast link to airport from Kowloon", "九龍站特快直達機場")),
                        Triple("Airport Express Single (Central) / 機場快綫單程 (香港)", 115.0, BilingualString("Fast link from Hong Kong Station", "香港站特快直達機場")),
                        Triple("Mainland HSR (Futian) / 廣深港高鐵 (福田)", 85.0, BilingualString("High speed connection to Shenzhen", "高鐵西九龍直達深圳福田"))
                    )

                    items(ticketProducts) { prod ->
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(prod.first, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text(prod.third.get(isZh), color = Color.Gray, fontSize = 11.sp)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("HK$${prod.second}", fontWeight = FontWeight.Bold, color = Color(0xFFC80A12))
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Button(
                                        onClick = {
                                            viewModel.purchaseTicket(
                                                type = prod.first,
                                                title = BilingualString(prod.first, prod.first),
                                                fare = prod.second
                                            )
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC80A12)),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(if (isZh) "購買" else "BUY", fontSize = 10.sp)
                                    }
                                }
                            }
                        }
                    }

                    // Render active bought tickets list
                    if (activeTickets.isNotEmpty()) {
                        item {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(if (isZh) "已購買之電子票券" else "YOUR ACTIVE E-TICKETS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                        }

                        items(activeTickets) { ticket ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF23232C)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(ticket.title.get(isZh), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        Text("ACTIVE", color = Color(0xFF34C759), fontWeight = FontWeight.Bold, fontSize = 10.sp)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("ID: ${ticket.id} | Valid Until: ${ticket.expiryTime}", color = Color.LightGray, fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }
            }

            "HISTORY" -> {
                // Ride History logs
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(history) { item ->
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(item.date, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = Color.Gray)
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(RoutingEngine.STATIONS[item.fromStationId]?.name?.get(isZh) ?: item.fromStationId, fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Icon(Icons.AutoMirrored.Filled.ArrowForward, null, modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(RoutingEngine.STATIONS[item.toStationId]?.name?.get(isZh) ?: item.toStationId, fontWeight = FontWeight.Bold)
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text("HK$${item.fare}", fontWeight = FontWeight.Bold, color = Color(0xFFC80A12))
                                    Text(item.paymentMethod.label.get(isZh), fontSize = 10.sp, color = Color.Gray)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


// ==========================================
// 5. METRO SIMULATOR & CONTROL CENTER SCREEN
// ==========================================
@Composable
fun SimulatorScreen(
    viewModel: MetroViewModel,
    isZh: Boolean
) {
    val scenario by viewModel.simulationScenario.collectAsState()
    val trainCount by viewModel.simTrainCount.collectAsState()
    val headwaySec by viewModel.simHeadwaySec.collectAsState()
    val demand by viewModel.simPassengerDemand.collectAsState()
    val telemetryStream by viewModel.telemetryStream.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("simulator_screen")
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = if (isZh) "港鐵智慧營運監控中心" else "METRO CONTROL DECK SIMULATOR",
                fontSize = 14.sp,
                fontWeight = FontWeight.Black,
                color = Color(0xFFC80A12)
            )
            Text(
                text = if (isZh) "分析調度、突發故障應對及流量仿真系統" else "Simulate structural parameters, load scenarios, and telemetry alerts",
                fontSize = 11.sp,
                color = Color.Gray
            )
        }

        // Scenario Loader Selection
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(if (isZh) "突發營運情境載入" else "LOAD OPERATING SCENARIO", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    val scenarios = listOf(
                        SimScenario.NORMAL to (if (isZh) "常規離峰" else "NORMAL"),
                        SimScenario.PEAK to (if (isZh) "尖峰大客流" else "PEAK DEMAND"),
                        SimScenario.RAIN to (if (isZh) "暴雨慢駛" else "TYPHOON/RAIN"),
                        SimScenario.TRAIN_FAILURE to (if (isZh) "列車故障" else "TRAIN BLOCK"),
                        SimScenario.SIGNAL_FAILURE to (if (isZh) "信號中斷" else "SIGNAL FAIL")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        scenarios.take(3).forEach { sc ->
                            val isSelected = scenario == sc.first
                            Button(
                                onClick = { viewModel.setSimulationScenario(sc.first) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSelected) Color(0xFFC80A12) else MaterialTheme.colorScheme.surfaceVariant,
                                    contentColor = if (isSelected) Color.White else Color.Black
                                ),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text(sc.second, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        scenarios.drop(3).forEach { sc ->
                            val isSelected = scenario == sc.first
                            Button(
                                onClick = { viewModel.setSimulationScenario(sc.first) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSelected) Color(0xFFC80A12) else MaterialTheme.colorScheme.surfaceVariant,
                                    contentColor = if (isSelected) Color.White else Color.Black
                                ),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text(sc.second, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Live stats numerical grid
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Card(modifier = Modifier.weight(1f)) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(if (isZh) "營運中列車數" else "ACTIVE TRAINS", fontSize = 8.sp, color = Color.Gray)
                        Text("$trainCount SETS", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
                Card(modifier = Modifier.weight(1f)) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(if (isZh) "設計發車班距" else "HEADWAY RATIO", fontSize = 8.sp, color = Color.Gray)
                        Text("${headwaySec}s", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
                Card(modifier = Modifier.weight(1f)) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(if (isZh) "仿真客流級別" else "PASSENGER DEMAND", fontSize = 8.sp, color = Color.Gray)
                        Text(demand, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFFC80A12))
                    }
                }
            }
        }

        // Dynamic event stream log list
        item {
            Text(
                text = if (isZh) "數碼雙生即時事件遙測流" else "DIGITAL TWIN TELEMETRY EVENT STREAM",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Gray
            )
        }

        items(telemetryStream) { event ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.Black),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "[${event.timestamp}]",
                            color = Color(0xFF34C759),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = event.type,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = event.entityId,
                            color = Color.Yellow,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    // payload key/values summary
                    Text(
                        text = event.payload.entries.take(2).joinToString { "${it.key}=${it.value}" },
                        color = Color.LightGray,
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}


// ==========================================
// 6. ACCESSIBILITY VOICE WAYFINDING SCREEN
// ==========================================
@Composable
fun AccessibilityScreen(
    viewModel: MetroViewModel,
    isZh: Boolean
) {
    val outOfServiceLifts by viewModel.outOfServiceLifts.collectAsState()
    var activeSpeakerInstruction by remember { mutableStateOf<String?>(null) }
    var selectedAssistanceType by remember { mutableStateOf("WHEELCHAIR") }

    val simulatedVoiceGuides = mapOf(
        "WHEELCHAIR" to listOf(
            BilingualString("Proceed to Exit C elevator.", "請向 C 出口升降機方向前進。"),
            BilingualString("The wheelchair access ramp is 20 meters ahead.", "無障礙斜道位於前方 20 米處。"),
            BilingualString("Platform 2 elevator is on your right.", "前往 2 號月台的升降機位於你右側。")
        ),
        "LOW_VISION" to listOf(
            BilingualString("Turn left after the ticket barrier.", "出閘機後請向左轉。"),
            BilingualString("Follow the yellow tactile guide path.", "請沿著黃色盲道觸覺引路帶前行。"),
            BilingualString("Platform 1 edge is 3 meters ahead.", "前方 3 米為 1 號月台邊緣，請注意安全。")
        )
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("accessibility_screen")
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = if (isZh) "無障礙鐵路智慧出行" else "ACCESSIBLE MOBILITY CONTROL",
            fontSize = 14.sp,
            fontWeight = FontWeight.Black,
            color = Color(0xFFC80A12)
        )

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(if (isZh) "特定客群貼心出行模式" else "CUSTOM COHORT ASSISTANCE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                Spacer(modifier = Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    val cohorts = listOf(
                        "WHEELCHAIR" to (if (isZh) "輪椅輔助" else "WHEELCHAIR"),
                        "LOW_VISION" to (if (isZh) "視障引導" else "LOW VISION")
                    )
                    for (co in cohorts) {
                        val isSelected = selectedAssistanceType == co.first
                        Button(
                            onClick = { 
                                selectedAssistanceType = co.first
                                activeSpeakerInstruction = null
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSelected) Color(0xFFC80A12) else MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = if (isSelected) Color.White else Color.Black
                            ),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(co.second, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Voice instruction wayfinding triggers
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = if (isZh) "智慧語音路綫導引廣播" else "INTELLIGENT VOICE WAYFINDING",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Gray
                )
                Spacer(modifier = Modifier.height(10.dp))

                val guides = simulatedVoiceGuides[selectedAssistanceType] ?: emptyList()
                guides.forEachIndexed { idx, guide ->
                    Button(
                        onClick = { activeSpeakerInstruction = guide.get(isZh) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp),
                        colors = MaterialTheme.getSecondaryColorScheme()
                    ) {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("Broadcasting Guide #${idx + 1}", fontSize = 11.sp)
                            Icon(Icons.Default.VolumeUp, null, modifier = Modifier.size(14.dp))
                        }
                    }
                }
            }
        }

        // Active speaker simulation overlay
        activeSpeakerInstruction?.let { instr ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.Black),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.RecordVoiceOver, null, tint = Color.Yellow, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "\" $instr \"",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Active Lift Outages / Maintenance warnings
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = if (isZh) "實時無障礙設施保養通報" else "LIVE ACCESSIBLE EQUIPMENT NOTICES",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Gray
                )
                Spacer(modifier = Modifier.height(10.dp))

                if (outOfServiceLifts.isEmpty()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircle, null, tint = Color(0xFF34C759), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (isZh) "全港港鐵垂直升降機運作正常" else "All station lifts operating normally.", fontSize = 12.sp)
                    }
                } else {
                    outOfServiceLifts.forEach { lift ->
                        val parts = lift.split(":")
                        val sName = RoutingEngine.STATIONS[parts[0]]?.name?.get(isZh) ?: parts[0]
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 4.dp)) {
                            Icon(Icons.Default.Error, null, tint = Color(0xFFFF3B30), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isZh) "$sName 升降機暫停服務，路綫引導已尋求代替無障礙路線。" else "$sName Lift Out of Service. Routing engine updated.",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFFF3B30)
                            )
                        }
                    }
                }
            }
        }
    }
}

// MaterialTheme helper extensions for layout convenience
@Composable
private fun MaterialTheme.getSecondaryColorScheme() = ButtonDefaults.buttonColors(
    containerColor = MaterialTheme.colorScheme.surfaceVariant,
    contentColor = Color.Black
)
