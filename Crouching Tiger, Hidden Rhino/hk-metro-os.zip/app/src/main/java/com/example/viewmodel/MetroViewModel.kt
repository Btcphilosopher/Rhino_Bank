package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.engine.RoutePreference
import com.example.engine.RoutingEngine
import com.example.model.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MetroViewModel : ViewModel() {

    // General app settings
    private val _isZh = MutableStateFlow(false)
    val isZh: StateFlow<Boolean> = _isZh.asStateFlow()

    fun toggleLanguage() {
        _isZh.update { !it }
    }

    // Navigation and Routing Selection States
    private val _fromStation = MutableStateFlow("CEN")
    val fromStation: StateFlow<String> = _fromStation.asStateFlow()

    private val _toStation = MutableStateFlow("TST")
    val toStation: StateFlow<String> = _toStation.asStateFlow()

    private val _routePreference = MutableStateFlow(RoutePreference.FASTEST)
    val routePreference: StateFlow<RoutePreference> = _routePreference.asStateFlow()

    private val _calculatedRoute = MutableStateFlow<JourneyResult?>(null)
    val calculatedRoute: StateFlow<JourneyResult?> = _calculatedRoute.asStateFlow()

    // Real-Time Simulation State
    private val _liveTrains = MutableStateFlow<List<LiveTrain>>(emptyList())
    val liveTrains: StateFlow<List<LiveTrain>> = _liveTrains.asStateFlow()

    private val _activeDisruptions = MutableStateFlow<List<ServiceDisruption>>(emptyList())
    val activeDisruptions: StateFlow<List<ServiceDisruption>> = _activeDisruptions.asStateFlow()

    private val _outOfServiceLifts = MutableStateFlow<Set<String>>(emptySet())
    val outOfServiceLifts: StateFlow<Set<String>> = _outOfServiceLifts.asStateFlow()

    // Ticketing and Account Simulator
    private val _octopusBalance = MutableStateFlow(128.5)
    val octopusBalance: StateFlow<Double> = _octopusBalance.asStateFlow()

    private val _metroPoints = MutableStateFlow(1840)
    val metroPoints: StateFlow<Int> = _metroPoints.asStateFlow()

    private val _tapState = MutableStateFlow<TapState>(TapState.OUT_OF_STATION)
    val tapState: StateFlow<TapState> = _tapState.asStateFlow()

    private val _tapRecord = MutableStateFlow<TapJourneyRecord?>(null)
    val tapRecord: StateFlow<TapJourneyRecord?> = _tapRecord.asStateFlow()

    private val _travelHistory = MutableStateFlow<List<TravelHistoryItem>>(emptyList())
    val travelHistory: StateFlow<List<TravelHistoryItem>> = _travelHistory.asStateFlow()

    private val _activeTickets = MutableStateFlow<List<Ticket>>(emptyList())
    val activeTickets: StateFlow<List<Ticket>> = _activeTickets.asStateFlow()

    // Station Digital Twin selection
    private val _selectedTwinStationId = MutableStateFlow("ADM")
    val selectedTwinStationId: StateFlow<String> = _selectedTwinStationId.asStateFlow()

    private val _selectedTwinObject = MutableStateFlow<TwinObject?>(null)
    val selectedTwinObject: StateFlow<TwinObject?> = _selectedTwinObject.asStateFlow()

    // Simulator variables & digital twin control deck
    private val _simulationScenario = MutableStateFlow(SimScenario.NORMAL)
    val simulationScenario: StateFlow<SimScenario> = _simulationScenario.asStateFlow()

    private val _simTrainCount = MutableStateFlow(18)
    val simTrainCount: StateFlow<Int> = _simTrainCount.asStateFlow()

    private val _simHeadwaySec = MutableStateFlow(120)
    val simHeadwaySec: StateFlow<Int> = _simHeadwaySec.asStateFlow()

    private val _simPassengerDemand = MutableStateFlow("HIGH")
    val simPassengerDemand: StateFlow<String> = _simPassengerDemand.asStateFlow()

    private val _simCrowdingMap = MutableStateFlow<Map<String, CrowdingLevel>>(emptyMap())
    val simCrowdingMap: StateFlow<Map<String, CrowdingLevel>> = _simCrowdingMap.asStateFlow()

    // Asset management telemetry list
    private val _assets = MutableStateFlow<List<Asset>>(emptyList())
    val assets: StateFlow<List<Asset>> = _assets.asStateFlow()

    // Universal Search Query (CTRL+K)
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _searchResults = MutableStateFlow<List<SearchResult>>(emptyList())
    val searchResults: StateFlow<List<SearchResult>> = _searchResults.asStateFlow()

    // Event Logs / Telemetry Streams
    private val _telemetryStream = MutableStateFlow<List<TelemetryEvent>>(emptyList())
    val telemetryStream: StateFlow<List<TelemetryEvent>> = _telemetryStream.asStateFlow()

    private var simJob: Job? = null

    init {
        // Initialize static simulated trains
        initializeTrains()
        // Initialize asset telemetry list
        initializeAssets()
        // Initialize travel history
        initializeTravelHistory()
        // Run background simulation update loop
        startSimulationLoop()
        // Execute initial route calculation Central -> Tsim Sha Tsui
        calculateRoute()
    }

    fun setFromStation(id: String) {
        _fromStation.update { id }
        calculateRoute()
    }

    fun setToStation(id: String) {
        _toStation.update { id }
        calculateRoute()
    }

    fun setRoutePreference(pref: RoutePreference) {
        _routePreference.update { pref }
        calculateRoute()
    }

    fun calculateRoute() {
        val result = RoutingEngine.calculateRoute(
            fromId = _fromStation.value,
            toId = _toStation.value,
            preference = _routePreference.value,
            activeDisruptions = _activeDisruptions.value,
            outOfServiceLifts = _outOfServiceLifts.value
        )
        _calculatedRoute.update { result }
        logTelemetry("journey.calculation", _fromStation.value, mapOf("to" to _toStation.value, "pref" to _routePreference.value.name))
    }

    // Pre-configured Journeys Shortcut buttons
    fun setJourneyShortcut(shortcut: String) {
        when (shortcut) {
            "HOME" -> {
                _fromStation.update { "CEN" }
                _toStation.update { "TAK" }
            }
            "WORK" -> {
                _fromStation.update { "CEN" }
                _toStation.update { "TST" }
            }
            "AIRPORT" -> {
                _fromStation.update { "CEN" }
                _toStation.update { "AIR" }
            }
            "FREQUENT" -> {
                _fromStation.update { "CEN" }
                _toStation.update { "SHA" }
            }
            "BORDER" -> {
                _fromStation.update { "CEN" }
                _toStation.update { "WKS" } // West Kowloon Connection to Mainland
            }
        }
        calculateRoute()
    }

    // Real-Time Train Engine Loop
    private fun initializeTrains() {
        val list = mutableListOf<LiveTrain>()
        val lines = RoutingEngine.LINES
        var count = 1
        for ((lineId, line) in lines) {
            if (line.stations.size >= 2) {
                list.add(
                    LiveTrain(
                        trainId = "TR-2${count++}0",
                        lineId = lineId,
                        direction = TrainDirection.UP,
                        currentStationId = line.stations[0],
                        nextStationId = line.stations[1],
                        progressFraction = 0.2f,
                        speedKmh = 68,
                        status = TrainStatus.ON_TIME,
                        etaSeconds = 85,
                        platform = "Platform 1",
                        carCrowding = List(8) { (15..75).random() }
                    )
                )
                list.add(
                    LiveTrain(
                        trainId = "TR-2${count++}1",
                        lineId = lineId,
                        direction = TrainDirection.DOWN,
                        currentStationId = line.stations.last(),
                        nextStationId = line.stations[line.stations.size - 2],
                        progressFraction = 0.5f,
                        speedKmh = 72,
                        status = TrainStatus.ON_TIME,
                        etaSeconds = 120,
                        platform = "Platform 2",
                        carCrowding = List(8) { (20..85).random() }
                    )
                )
            }
        }
        _liveTrains.update { list }
    }

    private fun startSimulationLoop() {
        simJob?.cancel()
        simJob = viewModelScope.launch {
            while (true) {
                delay(1000) // Ticks every 1 second
                tickSimulation()
            }
        }
    }

    private fun tickSimulation() {
        // Move trains
        _liveTrains.update { currentTrains ->
            currentTrains.map { train ->
                val line = RoutingEngine.LINES[train.lineId]
                if (line == null || line.stations.size < 2) return@map train

                var nextFraction = train.progressFraction + 0.04f // Speed rate increment
                var currentStation = train.currentStationId
                var nextStation = train.nextStationId
                var trainStatus = train.status
                var speed = train.speedKmh

                // Handle dwelling state when arriving
                if (nextFraction >= 1.0f) {
                    nextFraction = 0.0f
                    // Move stations
                    val sIndex = line.stations.indexOf(nextStation)
                    val isUp = train.direction == TrainDirection.UP

                    if (isUp) {
                        if (sIndex < line.stations.size - 1) {
                            currentStation = nextStation
                            nextStation = line.stations[sIndex + 1]
                            trainStatus = TrainStatus.DWELLING
                            speed = 0
                        } else {
                            // Turn back
                            train.copy(direction = TrainDirection.DOWN)
                            currentStation = nextStation
                            nextStation = line.stations[line.stations.size - 2]
                            trainStatus = TrainStatus.DWELLING
                            speed = 0
                        }
                    } else {
                        if (sIndex > 0) {
                            currentStation = nextStation
                            nextStation = line.stations[sIndex - 1]
                            trainStatus = TrainStatus.DWELLING
                            speed = 0
                        } else {
                            // Turn back
                            train.copy(direction = TrainDirection.UP)
                            currentStation = nextStation
                            nextStation = line.stations[1]
                            trainStatus = TrainStatus.DWELLING
                            speed = 0
                        }
                    }
                } else if (nextFraction in 0.01f..0.15f) {
                    trainStatus = TrainStatus.DWELLING
                    speed = 0
                } else if (nextFraction in 0.16f..0.30f) {
                    trainStatus = TrainStatus.DEPARTED
                    speed = (40..60).random()
                } else if (nextFraction in 0.31f..0.85f) {
                    trainStatus = TrainStatus.ON_TIME
                    speed = (70..85).random()
                } else {
                    trainStatus = TrainStatus.APPROACHING
                    speed = (20..35).random()
                }

                // Check active disruptions affecting this train
                val delayDisruption = _activeDisruptions.value.find { it.lineId == train.lineId }
                if (delayDisruption != null) {
                    trainStatus = TrainStatus.DELAYED
                    speed = Math.max(0, speed - 30)
                }

                val eta = if (speed == 0) 10 else ((1.0f - nextFraction) * 120).toInt()

                train.copy(
                    currentStationId = currentStation,
                    nextStationId = nextStation,
                    progressFraction = nextFraction,
                    speedKmh = speed,
                    status = trainStatus,
                    etaSeconds = eta,
                    carCrowding = train.carCrowding.map {
                        // Dynamically fluctuate occupancy slightly
                        val delta = (-3..3).random()
                        Math.min(100, Math.max(5, it + delta))
                    }
                )
            }
        }

        // Fluctuate crowding rates
        val map = mutableMapOf<String, CrowdingLevel>()
        for ((id, s) in RoutingEngine.STATIONS) {
            val randomFactor = (0..20).random()
            val finalCrowd = when {
                _simulationScenario.value == SimScenario.PEAK -> {
                    if (id in listOf("CEN", "ADM", "TST", "MOK")) CrowdingLevel.CRITICAL else CrowdingLevel.BUSY
                }
                randomFactor > 18 -> CrowdingLevel.VERY_BUSY
                randomFactor > 14 -> CrowdingLevel.BUSY
                randomFactor > 8 -> CrowdingLevel.MODERATE
                else -> CrowdingLevel.LOW
            }
            map[id] = finalCrowd
        }
        _simCrowdingMap.update { map }

        // Periodically update some asset status
        if ((0..10).random() > 8) {
            _assets.update { currentAssets ->
                currentAssets.map { asset ->
                    if (asset.id == _selectedTwinObject.value?.assetId) {
                        // Keep selected object synced
                        return@map asset
                    }
                    if ((0..100).random() > 96) {
                        val newStatus = AssetHealthStatus.values().random()
                        asset.copy(status = newStatus)
                    } else {
                        asset
                    }
                }
            }
        }

        // Keep simulated logs streaming
        if ((0..10).random() > 7) {
            val randomTrain = _liveTrains.value.randomOrNull()
            if (randomTrain != null) {
                logTelemetry(
                    "train.position",
                    randomTrain.trainId,
                    mapOf("line" to randomTrain.lineId, "speed" to "${randomTrain.speedKmh}km/h", "next" to randomTrain.nextStationId)
                )
            }
        }
    }

    // Asset Initializer
    private fun initializeAssets() {
        val list = listOf(
            Asset("AST-041", BilingualString("M-Train Set 213", "M-Train 列車 213"), AssetType.TRAIN, "TWL", AssetHealthStatus.NORMAL, 8.5, 2, "2026-08-01", "2026-10-01", listOf("Annual brake inspection completed.", "Traction motor filter replaced.")),
            Asset("AST-102", BilingualString("Alstom signaling box 4A", "阿爾斯通信號箱 4A"), AssetType.SIGNAL, "ADM", AssetHealthStatus.NORMAL, 4.2, 0, "2026-09-10", "2026-11-10", listOf("Firmware patch v3.92 uploaded.")),
            Asset("AST-511", BilingualString("Escalator E3 Lower Link", "E3 號扶手電梯下部齒輪"), AssetType.ESCALATOR, "TST", AssetHealthStatus.NORMAL, 12.0, 5, "2026-07-15", "2026-09-30", listOf("Lubrication pack renewed.", "Emergency safety brake verified.")),
            Asset("AST-801", BilingualString("Otis Lift L2 Shaft Elevator", "奧的斯 L2 號升降機槽"), AssetType.LIFT, "CEN", AssetHealthStatus.NORMAL, 6.1, 1, "2026-08-22", "2026-10-22", listOf("Wire ropes load tests passed.")),
            Asset("AST-951", BilingualString("Smart Turnstile Gate 12", "智慧三桿出入閘機 12"), AssetType.GATE, "MOK", AssetHealthStatus.NORMAL, 1.5, 0, "2026-09-02", "2026-12-02", listOf("Octopus NFC reader recalibrated."))
        )
        _assets.update { list }
    }

    private fun initializeTravelHistory() {
        val list = listOf(
            TravelHistoryItem("16 SEP", "CEN", "TST", 14, 11.2, PaymentMethod.OCTOPUS),
            TravelHistoryItem("15 SEP", "ADM", "TAK", 18, 8.5, PaymentMethod.OCTOPUS),
            TravelHistoryItem("12 SEP", "CEN", "AIR", 24, 105.0, PaymentMethod.CONTACTLESS_BANK_CARD)
        )
        _travelHistory.update { list }
    }

    // Disruption Controls
    fun triggerDisruption(
        lineId: String,
        severity: DisruptionSeverity,
        title: BilingualString,
        cause: BilingualString,
        alternative: BilingualString
    ) {
        val dId = "DIS-${System.currentTimeMillis() % 10000}"
        val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        val timestamp = sdf.format(Date()) + " HKT"

        val disp = ServiceDisruption(
            id = dId,
            lineId = lineId,
            severity = severity,
            title = title,
            cause = cause,
            affectedStations = RoutingEngine.LINES[lineId]?.stations ?: emptyList(),
            expectedDuration = BilingualString("Approx. 25 mins", "預計需時約 25 分鐘"),
            alternative = alternative,
            timestamp = timestamp
        )

        _activeDisruptions.update { it + disp }
        
        // Update line status in RoutingEngine metadata
        RoutingEngine.LINES[lineId]?.serviceStatus = when (severity) {
            DisruptionSeverity.CRITICAL -> LineServiceStatus.SUSPENDED
            DisruptionSeverity.URGENT -> LineServiceStatus.MAJOR_DELAY
            else -> LineServiceStatus.MINOR_DELAY
        }

        logTelemetry("service.alert", lineId, mapOf("severity" to severity.name, "cause" to cause.en))
        calculateRoute() // Recalculate route to account for delay/suspension!
    }

    fun clearAllDisruptions() {
        _activeDisruptions.update { emptyList() }
        for (line in RoutingEngine.LINES.values) {
            line.serviceStatus = LineServiceStatus.NORMAL
        }
        _outOfServiceLifts.update { emptySet() }
        calculateRoute()
        logTelemetry("service.restored", "ALL", mapOf("status" to "NORMAL"))
    }

    // Lift Outages Accessibility simulation
    fun triggerLiftOutage(stationId: String, liftAssetId: String) {
        _outOfServiceLifts.update { it + "$stationId:$liftAssetId" }
        _assets.update { current ->
            current.map {
                if (it.id == liftAssetId) it.copy(status = AssetHealthStatus.CRITICAL) else it
            }
        }
        logTelemetry("lift.outage", liftAssetId, mapOf("station" to stationId))
        calculateRoute() // Recalculate routing immediately!
    }

    // Tap In / Tap Out Simulator
    fun triggerTapIn(stationId: String, payment: PaymentMethod) {
        if (_tapState.value != TapState.OUT_OF_STATION) return

        val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        val timeString = sdf.format(Date())

        val record = TapJourneyRecord(
            id = "TAP-${(1000..9999).random()}",
            cardToken = "NFC_TOKEN_OCT_" + UUID.randomUUID().toString().substring(0, 8).uppercase(),
            entryStationId = stationId,
            exitStationId = null,
            entryTime = timeString,
            exitTime = null,
            fare = 0.0,
            status = "IN_PROGRESS"
        )

        _tapRecord.update { record }
        _tapState.update { TapState.TAPPED_IN }
        logTelemetry("payment.tap_in", stationId, mapOf("payment" to payment.name))
    }

    fun triggerTapOut(stationId: String, payment: PaymentMethod) {
        val currentRecord = _tapRecord.value ?: return
        if (_tapState.value != TapState.TAPPED_IN) return

        val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        val timeString = sdf.format(Date())

        // Calculate fare
        val finalFare = RoutingEngine.calculateFare(currentRecord.entryStationId, stationId, PassengerType.ADULT, payment)

        // Deduct Octopus balance
        if (payment == PaymentMethod.OCTOPUS) {
            _octopusBalance.update { Math.max(-35.0, it - finalFare) } // Octopus supports down to -$35
        }
        // Earn points
        val pointsEarned = (finalFare * 10).toInt()
        _metroPoints.update { it + pointsEarned }

        val completedRecord = currentRecord.copy(
            exitStationId = stationId,
            exitTime = timeString,
            fare = finalFare,
            status = "COMPLETED"
        )

        // Add to history
        val historyItem = TravelHistoryItem(
            date = "TODAY",
            fromStationId = currentRecord.entryStationId,
            toStationId = stationId,
            durationMinutes = 12, // simplified duration
            fare = finalFare,
            paymentMethod = payment
        )

        _travelHistory.update { listOf(historyItem) + it }
        _tapRecord.update { completedRecord }
        _tapState.update { TapState.TAPPED_OUT }
        logTelemetry("payment.tap_out", stationId, mapOf("fare" to "HK$$finalFare", "points_earned" to "$pointsEarned"))
    }

    fun resetTapJourney() {
        _tapState.update { TapState.OUT_OF_STATION }
        _tapRecord.update { null }
    }

    // Buy Digital Tickets
    fun purchaseTicket(type: String, title: BilingualString, fare: Double) {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
        val purchaseStr = sdf.format(Date())
        val expiryStr = sdf.format(Date().time + 86400000) // 1 day validity

        val ticket = Ticket(
            id = "TCK-${(1000..9999).random()}",
            type = type,
            title = title,
            fare = fare,
            purchaseTime = purchaseStr,
            expiryTime = expiryStr
        )
        _activeTickets.update { listOf(ticket) + it }
        _octopusBalance.update { Math.max(0.0, it - fare) }
        logTelemetry("ticket.purchase", ticket.id, mapOf("fare" to "HK$$fare"))
    }

    // Simulation Controller
    fun setSimulationScenario(scen: SimScenario) {
        _simulationScenario.update { scen }
        when (scen) {
            SimScenario.NORMAL -> {
                _simTrainCount.update { 18 }
                _simHeadwaySec.update { 120 }
                _simPassengerDemand.update { "NORMAL" }
                clearAllDisruptions()
            }
            SimScenario.PEAK -> {
                _simTrainCount.update { 32 }
                _simHeadwaySec.update { 90 }
                _simPassengerDemand.update { "CRITICAL" }
            }
            SimScenario.RAIN -> {
                _simPassengerDemand.update { "HIGH" }
                triggerDisruption(
                    "TWL", DisruptionSeverity.NOTICE,
                    BilingualString("Inclement Weather: Reduced Speeds", "惡劣天氣：列車慢駛"),
                    BilingualString("Heavy downpour across Kowloon", "九龍區暴雨導致路軌濕滑"),
                    BilingualString("Use Island Line for southern links", "往來港島請利用港島綫")
                )
            }
            SimScenario.TRAIN_FAILURE -> {
                triggerDisruption(
                    "ISL", DisruptionSeverity.URGENT,
                    BilingualString("Mechanical Train Failure at Admiralty", "金鐘站列車機械故障"),
                    BilingualString("Traction motor fault on Island Line train", "港島綫列車動力牽引故障"),
                    BilingualString("Take Tsuen Wan Line or local buses", "請轉乘荃灣綫或路面巴士")
                )
            }
            SimScenario.SIGNAL_FAILURE -> {
                triggerDisruption(
                    "TKL", DisruptionSeverity.CRITICAL, // Tseung Kwan O line code
                    BilingualString("ATC Signal Transmission Blackout", "自動列車控制信號傳輸中斷"),
                    BilingualString("Fiber optic signaling cable cut near Quarry Bay", "鰂魚涌附近信號光纖斷裂"),
                    BilingualString("Services suspended. Shuttle buses deployed", "服務暫停，已安排免費接駁巴士")
                )
            }
        }
        logTelemetry("simulation.scenario_change", scen.name, mapOf("headway" to "${_simHeadwaySec.value}s"))
    }

    fun selectTwinObject(obj: TwinObject?) {
        _selectedTwinObject.update { obj }
        logTelemetry("twin.select", obj?.assetId ?: "NONE", mapOf("name" to (obj?.nameEn ?: "")))
    }

    // Universal search query logic
    fun setSearchQuery(query: String) {
        _searchQuery.update { query }
        if (query.isBlank()) {
            _searchResults.update { emptyList() }
            return
        }

        val results = mutableListOf<SearchResult>()
        val lowercaseQuery = query.lowercase()

        // Match stations
        for ((id, station) in RoutingEngine.STATIONS) {
            val nameEn = station.name.en.lowercase()
            val nameZh = station.name.zh
            if (nameEn.contains(lowercaseQuery) || nameZh.contains(lowercaseQuery) || id.lowercase().contains(lowercaseQuery)) {
                results.add(
                    SearchResult(
                        type = "STATION",
                        title = station.name,
                        subtitle = BilingualString("Station Code: $id | Lines: ${station.lines.joinToString()}", "車站代碼：$id | 路線：${station.lines.joinToString()}"),
                        entityId = id
                    )
                )
            }
        }

        // Match assets
        for (asset in _assets.value) {
            val nameEn = asset.name.en.lowercase()
            val nameZh = asset.name.zh
            val assetId = asset.id.lowercase()
            if (nameEn.contains(lowercaseQuery) || nameZh.contains(lowercaseQuery) || assetId.contains(lowercaseQuery)) {
                results.add(
                    SearchResult(
                        type = "ASSET",
                        title = asset.name,
                        subtitle = BilingualString("Asset ID: ${asset.id} | Health: ${asset.status.label.en}", "設備代碼：${asset.id} | 狀態：${asset.status.label.zh}"),
                        entityId = asset.id
                    )
                )
            }
        }

        _searchResults.update { results }
    }

    // Event Stream Log helper
    private fun logTelemetry(type: String, entityId: String, payload: Map<String, String>) {
        val sdf = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())
        val timestamp = sdf.format(Date())

        val event = TelemetryEvent(
            timestamp = timestamp,
            type = type,
            entityId = entityId,
            source = "SIM_LIVE_DATA",
            payload = payload
        )

        _telemetryStream.update { current ->
            // Keep maximum 30 recent events in cache
            (listOf(event) + current).take(30)
        }
    }
}

enum class TapState(val label: BilingualString) {
    OUT_OF_STATION(BilingualString("Outside Gates", "閘外")),
    TAPPED_IN(BilingualString("Inside Paid Area", "付費區內")),
    TAPPED_OUT(BilingualString("Exit Tap Received", "出閘完畢"))
}

enum class SimScenario(val label: BilingualString) {
    NORMAL(BilingualString("Standard Off-Peak", "離峰正常運作")),
    PEAK(BilingualString("AM/PM Super Peak Density", "尖峰大客流運作")),
    RAIN(BilingualString("Typhoon/Severe Rain Sloped Speeds", "颱風/暴雨慢駛")),
    TRAIN_FAILURE(BilingualString("Admiralty Train Obstruction", "金鐘站列車故障")),
    SIGNAL_FAILURE(BilingualString("ATC Signal Transmission Failure", "自動信號系統中斷"))
}

data class TwinObject(
    val id: String,
    val nameEn: String,
    val nameZh: String,
    val assetId: String,
    val description: BilingualString
)

data class SearchResult(
    val type: String, // STATION, ASSET, LINE, EXIT
    val title: BilingualString,
    val subtitle: BilingualString,
    val entityId: String
)
