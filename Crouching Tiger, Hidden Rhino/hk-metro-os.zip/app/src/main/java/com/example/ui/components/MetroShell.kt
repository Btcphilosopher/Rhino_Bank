package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BilingualString
import com.example.ui.screens.*
import com.example.viewmodel.MetroViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MetroShell(
    viewModel: MetroViewModel,
    modifier: Modifier = Modifier
) {
    val isZh by viewModel.isZh.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val searchResults by viewModel.searchResults.collectAsState()

    var activeTab by remember { mutableStateOf("HOME") }
    var mapMode by remember { mutableStateOf(MapMode.SYSTEM) }

    val liveTrains by viewModel.liveTrains.collectAsState()
    val crowdingMap by viewModel.simCrowdingMap.collectAsState()
    val outOfServiceLifts by viewModel.outOfServiceLifts.collectAsState()

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    // Definition of all 14 available bilingual application targets
    val sidebarMenu = listOf(
        Triple("HOME", BilingualString("HOME", "主頁"), Icons.Default.Home),
        Triple("JOURNEY", BilingualString("JOURNEY", "行程規劃"), Icons.Default.Directions),
        Triple("MAP", BilingualString("MAP OS", "鐵路系統地圖"), Icons.Default.Map),
        Triple("STATIONS", BilingualString("STATIONS TWIN", "車站數碼雙生"), Icons.Default.Domain),
        Triple("TICKETS", BilingualString("TICKETS", "車票乘車碼"), Icons.Default.ConfirmationNumber),
        Triple("ACCESSIBILITY", BilingualString("ACCESSIBILITY", "無障礙服務"), Icons.Default.WheelchairPickup),
        Triple("SIMULATOR", BilingualString("TWIN SIMULATOR", "系統運作仿真"), Icons.Default.Speed)
    )

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                modifier = Modifier.width(280.dp),
                drawerShape = RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp),
                drawerContainerColor = Color(0xFF1E1E24)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                ) {
                    // Drawer Brand Identity Header
                    Text(
                        text = "HONG KONG METRO",
                        color = Color(0xFFC80A12),
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "香港都市鐵路智慧出行系統",
                        color = Color.White,
                        fontWeight = FontWeight.Medium,
                        fontSize = 11.sp
                    )
                    Text(
                        text = "Confidential Rail OS Engine",
                        color = Color.Gray,
                        fontSize = 8.sp,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )
                    Divider(color = Color.DarkGray, thickness = 1.dp)

                    Spacer(modifier = Modifier.height(12.dp))

                    // List drawer operational units
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        items(sidebarMenu) { item ->
                            val isSelected = activeTab == item.first
                            NavigationDrawerItem(
                                label = {
                                    Column {
                                        Text(
                                            text = item.second.zh,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            color = if (isSelected) Color.White else Color.LightGray
                                        )
                                        Text(
                                            text = item.second.en,
                                            fontSize = 9.sp,
                                            color = if (isSelected) Color.White else Color.Gray
                                        )
                                    }
                                },
                                selected = isSelected,
                                onClick = {
                                    activeTab = item.first
                                    androidx.compose.ui.platform.LocalFocusManager.toString()
                                    scope.launch { drawerState.close() }
                                },
                                icon = {
                                    Icon(
                                        imageVector = item.third,
                                        contentDescription = null,
                                        tint = if (isSelected) Color.White else Color(0xFFC80A12),
                                        modifier = Modifier.size(20.dp)
                                    )
                                },
                                colors = NavigationDrawerItemDefaults.colors(
                                    selectedContainerColor = Color(0xFFC80A12),
                                    unselectedContainerColor = Color.Transparent
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.padding(horizontal = 4.dp)
                            )
                        }
                    }
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                // Enterprise Bilingual Top Bar with universal search & toggle
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = "HONG KONG METRO",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp,
                                color = Color.White
                            )
                            Text(
                                text = "香港都市鐵路智慧出行平台",
                                fontSize = 10.sp,
                                color = Color.LightGray,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Default.Menu, contentDescription = "Menu Drawer", tint = Color.White)
                        }
                    },
                    actions = {
                        // Quick Bilingual toggle button
                        TextButton(onClick = { viewModel.toggleLanguage() }) {
                            Text(
                                text = if (isZh) "ENGLISH" else "繁體中文",
                                color = Color.Yellow,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF1E1E24))
                )
            },
            bottomBar = {
                // Default Primary Bottom Navigation for core passenger activities
                NavigationBar(
                    containerColor = Color(0xFF1E1E24)
                ) {
                    val bottomTabs = listOf(
                        Triple("HOME", BilingualString("HOME", "主頁"), Icons.Default.Home),
                        Triple("JOURNEY", BilingualString("JOURNEY", "行程"), Icons.Default.Directions),
                        Triple("MAP", BilingualString("MAP OS", "地圖"), Icons.Default.Map),
                        Triple("TICKETS", BilingualString("TICKETS", "車票"), Icons.Default.ConfirmationNumber)
                    )

                    bottomTabs.forEach { tab ->
                        val isSelected = activeTab == tab.first
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { activeTab = tab.first },
                            label = {
                                Text(
                                    text = tab.second.get(isZh),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.White else Color.LightGray
                                )
                            },
                            icon = {
                                Icon(
                                    imageVector = tab.third,
                                    contentDescription = null,
                                    tint = if (isSelected) Color.White else Color(0xFFC80A12),
                                    modifier = Modifier.size(20.dp)
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = Color(0xFFC80A12)
                            )
                        )
                    }
                }
            },
            modifier = modifier
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                // Universal Ctrl+K Universal search floating bar
                TextField(
                    value = searchQuery,
                    onValueChange = { viewModel.setSearchQuery(it) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                        .testTag("universal_search_field"),
                    placeholder = {
                        Text(
                            text = if (isZh) "🔍 輸入站名、設備編碼或路線 (如 '中環', 'AST-041')" else "🔍 Search stations, equipment, routes (e.g. 'Central')",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                        focusedIndicatorColor = Color(0xFFC80A12),
                        unfocusedIndicatorColor = Color.Transparent
                    ),
                    shape = RoundedCornerShape(8.dp),
                    singleLine = true,
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                Icon(Icons.Default.Close, null, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                )

                // Search Results Floating Panel Overlay Drawer if matching rows
                AnimatedVisibility(visible = searchQuery.isNotEmpty()) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                            .heightIn(max = 200.dp),
                        elevation = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant).let { CardDefaults.cardElevation(8.dp) }
                    ) {
                        if (searchResults.isEmpty()) {
                            Box(modifier = Modifier.padding(16.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
                                Text(if (isZh) "無相符結果" else "No matching results", color = Color.Gray, fontSize = 11.sp)
                            }
                        } else {
                            LazyColumn(modifier = Modifier.padding(8.dp)) {
                                items(searchResults) { res ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                // Handle selection action
                                                if (res.type == "STATION") {
                                                    viewModel.setToStation(res.entityId)
                                                    activeTab = "JOURNEY"
                                                } else if (res.type == "ASSET") {
                                                    // Move to twin station twin and focus object
                                                    val obj = com.example.viewmodel.TwinObject(
                                                        res.entityId,
                                                        res.title.en,
                                                        res.title.zh,
                                                        res.entityId,
                                                        BilingualString("Retrieved via system index", "經系統搜尋調取")
                                                    )
                                                    viewModel.selectTwinObject(obj)
                                                    activeTab = "STATIONS"
                                                }
                                                viewModel.setSearchQuery("")
                                            }
                                            .padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = when (res.type) {
                                                "STATION" -> Icons.Default.DirectionsTransit
                                                else -> Icons.Default.Build
                                            },
                                            contentDescription = null,
                                            tint = Color(0xFFC80A12),
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(res.title.get(isZh), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            Text(res.subtitle.get(isZh), fontSize = 10.sp, color = Color.Gray)
                                        }
                                    }
                                    Divider()
                                }
                            }
                        }
                    }
                }

                // Render Active Content Frame according to active tab select state
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    when (activeTab) {
                        "HOME" -> HomeScreen(viewModel, isZh) { tab -> activeTab = tab }
                        "JOURNEY" -> JourneyPlannerScreen(viewModel, isZh)
                        "STATIONS" -> StationTwinScreen(viewModel, isZh)
                        "TICKETS" -> TicketsScreen(viewModel, isZh)
                        "ACCESSIBILITY" -> AccessibilityScreen(viewModel, isZh)
                        "SIMULATOR" -> SimulatorScreen(viewModel, isZh)
                        "MAP" -> {
                            // Active interactive Canvas Schematic OS Map Mode
                            Column(modifier = Modifier.fillMaxSize()) {
                                // Mode Select bar
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFF1E1E24))
                                        .padding(8.dp),
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    for (m in MapMode.values()) {
                                        val isSelected = mapMode == m
                                        Button(
                                            onClick = { mapMode = m },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = if (isSelected) Color(0xFFC80A12) else Color.DarkGray,
                                                contentColor = Color.White
                                            ),
                                            modifier = Modifier.weight(1f),
                                            shape = RoundedCornerShape(4.dp),
                                            contentPadding = PaddingValues(0.dp)
                                        ) {
                                            Text(m.label.get(isZh), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }

                                // Interactive Canvas map
                                MetroMapCanvas(
                                    modifier = Modifier.fillMaxSize(),
                                    liveTrains = liveTrains,
                                    crowdingMap = crowdingMap,
                                    outOfServiceLifts = outOfServiceLifts,
                                    isZh = isZh,
                                    mode = mapMode,
                                    onStationSelect = { stationId ->
                                        viewModel.setFromStation(stationId)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
