package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Fictional Hong Kong Metro OS - Professional Color Palette
val MetroRed = Color(0xFFC80A12)       // Deep metropolitan red (Primary system identity)
val DarkCharcoal = Color(0xFF1E1E1E)   // Dark Charcoal for clean dark surfaces and headers
val OffWhite = Color(0xFFF9F9FB)       // Clean, high-density light background
val WarmGrey = Color(0xFFF4F4F6)       // Soft, high-quality container background
val StationGrey = Color(0xFFE5E5EA)    // Structural borders and inactive lines
val LightGrey = Color(0xFF8E8E93)      // Secondary text and auxiliary indicators

val AlertAmber = Color(0xFFFF9500)     // Restrained amber for warnings and minor delays
val AlertGreen = Color(0xFF34C759)     // Controlled green for normal service status
val AlertBlue = Color(0xFF007AFF)      // Limited blue for Airport Express & info accents

// Specific MTR-inspired lines
val LineIsland = Color(0xFF007BC4)     // Island Line Blue
val LineTsuenWan = Color(0xFFE21118)   // Tsuen Wan Line Red
val LineKwunTong = Color(0xFF00913A)   // Kwun Tong Line Green
val LineTseungKwanO = Color(0xFF7E318C)// Tseung Kwan O Line Purple
val LineTungChung = Color(0xFFED6D00)  // Tung Chung Line Orange
val LineAirportExpress = Color(0xFF00767A) // Airport Express Teal
val LineEastRail = Color(0xFF55B1E5)   // East Rail Line Light Blue
val LineTuenMa = Color(0xFF9E652E)     // Tuen Ma Line Brown
val LineSouthIsland = Color(0xFFB5BD00) // South Island Line Lime Green
val LineDisneyland = Color(0xFFF58220)  // Disneyland Resort Line
val LineLightRail = Color(0xFFD6A400)   // Light Rail Yellow
val LineHighSpeed = Color(0xFF6C757D)   // High Speed Rail Grey
