package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = MetroRed,
    onPrimary = Color.White,
    secondary = DarkCharcoal,
    onSecondary = Color.White,
    background = Color(0xFF121212),
    surface = Color(0xFF1E1E1E),
    onBackground = Color.White,
    onSurface = Color.White,
    outline = StationGrey
)

private val LightColorScheme = lightColorScheme(
    primary = MetroRed,
    onPrimary = Color.White,
    secondary = DarkCharcoal,
    onSecondary = Color.White,
    background = OffWhite,
    surface = Color.White,
    onBackground = DarkCharcoal,
    onSurface = DarkCharcoal,
    outline = StationGrey,
    surfaceVariant = WarmGrey
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Disable dynamic colors to enforce the corporate identity
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
