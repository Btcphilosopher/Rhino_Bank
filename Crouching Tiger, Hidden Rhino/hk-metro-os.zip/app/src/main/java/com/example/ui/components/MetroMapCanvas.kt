package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.RoutingEngine
import com.example.model.BilingualString
import com.example.model.CrowdingLevel
import com.example.model.LiveTrain
import kotlin.math.cos
import kotlin.math.sin

@OptIn(ExperimentalTextApi::class)
@Composable
fun MetroMapCanvas(
    modifier: Modifier = Modifier,
    liveTrains: List<LiveTrain>,
    crowdingMap: Map<String, CrowdingLevel>,
    outOfServiceLifts: Set<String>,
    isZh: Boolean,
    mode: MapMode,
    onStationSelect: (String) -> Unit = {}
) {
    // Zoom / pan state for high-density navigation exploration
    var scale by remember { mutableStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    val transformState = rememberTransformableState { zoomChange, offsetChange, _ ->
        scale = (scale * zoomChange).coerceIn(0.5f, 3f)
        offset += offsetChange
    }

    // Animation for pulsing elements
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    val textMeasurer = rememberTextMeasurer()

    Box(
        modifier = modifier
            .testTag("metro_map_container")
            .background(Color(0xFF1E1E24))
            .transformable(state = transformState)
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer(
                    scaleX = scale,
                    scaleY = scale,
                    translationX = offset.x,
                    translationY = offset.y
                )
        ) {
            val width = size.width
            val height = size.height

            // Helper to map coordinate values
            fun getPos(stationId: String): Offset {
                return when (stationId) {
                    "CEN" -> Offset(width * 0.25f, height * 0.60f)
                    "ADM" -> Offset(width * 0.45f, height * 0.60f)
                    "CAB" -> Offset(width * 0.65f, height * 0.60f)
                    "QUB" -> Offset(width * 0.82f, height * 0.60f)
                    "TAK" -> Offset(width * 0.92f, height * 0.68f)
                    
                    "TST" -> Offset(width * 0.45f, height * 0.40f)
                    "MOK" -> Offset(width * 0.45f, height * 0.22f)
                    "SHA" -> Offset(width * 0.65f, height * 0.22f)
                    "TUM" -> Offset(width * 0.10f, height * 0.22f)
                    "YUL" -> Offset(width * 0.22f, height * 0.22f)
                    
                    "HOK" -> Offset(width * 0.25f, height * 0.72f)
                    "KOW" -> Offset(width * 0.45f, height * 0.72f)
                    "TSY" -> Offset(width * 0.60f, height * 0.72f)
                    "SUN" -> Offset(width * 0.70f, height * 0.72f)
                    "AIR" -> Offset(width * 0.85f, height * 0.72f)
                    "WKS" -> Offset(width * 0.45f, height * 0.86f)
                    else -> Offset(width * 0.5f, height * 0.5f)
                }
            }

            // 1. Draw Physical Virtual Interchanges (Dashed corridors)
            // Central <-> Hong Kong
            val cenOffset = getPos("CEN")
            val hokOffset = getPos("HOK")
            drawLine(
                color = Color.LightGray,
                start = cenOffset,
                end = hokOffset,
                strokeWidth = 6f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 15f), 0f)
            )

            // Kowloon <-> West Kowloon (HSR)
            val kowOffset = getPos("KOW")
            val wksOffset = getPos("WKS")
            drawLine(
                color = Color.LightGray,
                start = kowOffset,
                end = wksOffset,
                strokeWidth = 6f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 15f), 0f)
            )

            // 2. Draw Network Transit Lines
            for ((lineId, line) in RoutingEngine.LINES) {
                // Determine color
                val lineColor = line.color
                val pathPoints = line.stations.map { getPos(it) }
                
                // Draw line links
                for (i in 0 until pathPoints.size - 1) {
                    val isDisrupted = mode == MapMode.DISRUPTION && line.serviceStatus != com.example.model.LineServiceStatus.NORMAL
                    val strokeCol = if (isDisrupted) Color(0xFFFF3B30) else lineColor
                    val widthScale = if (isDisrupted) 14f else 10f

                    drawLine(
                        color = strokeCol,
                        start = pathPoints[i],
                        end = pathPoints[i + 1],
                        strokeWidth = widthScale,
                        pathEffect = if (lineId == "HSR") PathEffect.dashPathEffect(floatArrayOf(20f, 10f)) else null
                    )
                }
            }

            // 3. Draw Station Nodes
            for ((id, station) in RoutingEngine.STATIONS) {
                val pos = getPos(id)
                
                // Determine node color according to chosen map mode
                val nodeColor = when (mode) {
                    MapMode.CROWDING -> {
                        val crowd = crowdingMap[id] ?: CrowdingLevel.LOW
                        Color(android.graphics.Color.parseColor(crowd.levelHex))
                    }
                    MapMode.ACCESSIBILITY -> {
                        val isFaulty = outOfServiceLifts.any { it.startsWith(id) }
                        if (isFaulty) Color(0xFFFF3B30) else Color(0xFF34C759)
                    }
                    else -> Color.White
                }

                // Node size
                val radius = if (station.lines.size > 1) 14f else 9f
                
                // Draw background shadow / highlight ring
                drawCircle(
                    color = Color.Black.copy(alpha = 0.5f),
                    radius = radius + 4f,
                    center = pos
                )

                // Draw central node
                drawCircle(
                    color = nodeColor,
                    radius = radius,
                    center = pos
                )

                // Draw outline
                drawCircle(
                    color = if (station.lines.size > 1) Color.DarkGray else Color.Black,
                    radius = radius,
                    center = pos,
                    style = Stroke(width = 3f)
                )

                // Pulsing highlight for lift outages in accessibility mode
                if (mode == MapMode.ACCESSIBILITY && outOfServiceLifts.any { it.startsWith(id) }) {
                    drawCircle(
                        color = Color(0xFFFF3B30).copy(alpha = pulseAlpha * 0.4f),
                        radius = radius + 15f,
                        center = pos
                    )
                }

                // Draw Station Name Bilingual Label
                val labelText = if (isZh) station.name.zh else station.name.en
                val textLayout = textMeasurer.measure(
                    text = AnnotatedString(labelText),
                    style = TextStyle(
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        background = Color.Black.copy(alpha = 0.7f)
                    )
                )
                
                // Shift text to prevent overlap
                val textOffset = Offset(
                    pos.x - (textLayout.size.width / 2),
                    pos.y + 12f
                )
                drawText(textLayout, topLeft = textOffset)
            }

            // 4. Draw Simulated Real-Time Live Trains
            for (train in liveTrains) {
                val line = RoutingEngine.LINES[train.lineId] ?: continue
                val s1 = getPos(train.currentStationId)
                val s2 = getPos(train.nextStationId)

                // Calculate current interpolated coordinates of moving train
                val currentX = s1.x + (s2.x - s1.x) * train.progressFraction
                val currentY = s1.y + (s2.y - s1.y) * train.progressFraction
                val trainPos = Offset(currentX, currentY)

                // Render train triangle/dot indicating direction
                drawCircle(
                    color = Color.Black,
                    radius = 11f,
                    center = trainPos
                )
                drawCircle(
                    color = line.color,
                    radius = 8f,
                    center = trainPos
                )
                drawCircle(
                    color = Color.White,
                    radius = 4f,
                    center = trainPos
                )

                // Draw simulated train ID label above
                val trainIdLayout = textMeasurer.measure(
                    text = AnnotatedString(train.trainId),
                    style = TextStyle(
                        color = Color.Yellow,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.SemiBold,
                        background = Color.Black.copy(alpha = 0.8f)
                    )
                )
                drawText(
                    trainIdLayout,
                    topLeft = Offset(trainPos.x - (trainIdLayout.size.width / 2), trainPos.y - 18f)
                )
            }
        }

        // Static overlay watermark
        Card(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.85f))
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    text = "SIMULATED LIVE RAIL DATA",
                    color = Color(0xFFFF9500),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "模擬實時鐵路系統運作中",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = "Scale: ${String.format("%.1fx", scale)} | Mode: ${mode.name}",
                    color = Color.LightGray,
                    fontSize = 9.sp
                )
            }
        }
    }
}

enum class MapMode(val label: BilingualString) {
    SYSTEM(BilingualString("Schematic", "示意地圖")),
    CROWDING(BilingualString("Crowding Heat", "客流擁擠度")),
    ACCESSIBILITY(BilingualString("Barrier-Free Lifts", "無障礙設施")),
    DISRUPTION(BilingualString("Disruptions & Delays", "延誤受阻線路"))
}
