import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

// Define dirname equivalent in ESM
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Initialize Gemini AI Client
  let ai: GoogleGenAI | null = null;
  const apiKey = process.env.GEMINI_API_KEY;

  if (apiKey) {
    ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
    console.log("RhinoQuant Gemini AI Client initialized successfully.");
  } else {
    console.warn("WARNING: GEMINI_API_KEY is not defined. AI Market Bulletins will be unavailable.");
  }

  // API Route: Economic and Commodities Commentary from Gemini
  app.post("/api/gemini-commentary", async (req, res) => {
    try {
      if (!ai) {
        return res.status(503).json({
          error: "Gemini API Key is missing. Please add your GEMINI_API_KEY in the secrets settings to enable real-time economic briefings.",
        });
      }

      const {
        selectedGood,
        selectedRegion,
        currentIndexValue,
        forecastModel,
        activeScenario,
        weights,
        priceHistory,
      } = req.body;

      // Construct a high-context prompt for Gemini (3.6-flash is perfect for fast, high-quality analysis)
      const prompt = `
You are the Chief Quantitative Economist and Commodity Risk Advisor at Rhino Bank, specialising in regional economics for Yorkshire and the Humber.
Provide an institutional-grade investment risk and economic intelligence briefing based on the following real-time data from the RhinoQuant Yorkshire Spot Pricing Platform.

[MARKET ENVIRONMENT STATE]
- Focus Commodity: ${selectedGood?.name} (${selectedGood?.category})
- Current Benchmark Spot Price: ${selectedGood?.price} GBP/tonne (Regional Premium: ${selectedGood?.regionalPremium}%)
- Target Region: ${selectedRegion}
- Regional Goods Price Index (RGPI) Current State: ${currentIndexValue.toFixed(2)}
- active Stress Test Scenario: "${activeScenario?.name}" (${activeScenario?.description})
- Category Weights in RGPI:
  * Construction: ${weights?.construction}%
  * Industrial Metals: ${weights?.metals}%
  * Energy: ${weights?.energy}%
  * Agriculture: ${weights?.agriculture}%
  * Industrial Products: ${weights?.products}%
- Forecasting Model Configured: ${forecastModel}

[INSTRUCTIONS]
Write a highly professional, dense, and structured financial intelligence briefing (3-4 paragraphs) suitable for Rhino Bank's Commercial Lending Board and Regional Risk Committee.
Address:
1. **Macro-Commodity Analysis**: Evaluate the commodity's spot price, volatility, and Yorkshire regional premium. Discuss how localized demand in counties like West Yorkshire or Humber affects risk.
2. **Scenario Stress-Testing & Commercial Exposure**: Critically analyze the impact of the active scenario ("${activeScenario?.name}") on infrastructure finance, agricultural credit risk, or manufacturing clients.
3. **Strategic Lending Guidance**: Provide sharp, actionable RAG (Red/Amber/Green) credit allocation advice for Rhino Bank underwriters regarding Yorkshire developers, farmers, or industrial processors.

Do not use conversational fluff. Write in a sophisticated, authoritative financial tone. Keep your analysis realistic, mathematically sound, and deeply grounded in Yorkshire's industrial geography (e.g. Leeds manufacturing, Humber ports, North Yorkshire farms, Sheffield steel).
`;

      const response = await ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents: prompt,
        config: {
          temperature: 0.7,
        },
      });

      res.json({
        commentary: response.text || "No commentary generated.",
      });
    } catch (error: any) {
      console.error("Gemini API Error:", error);
      res.status(500).json({ error: error.message || "An error occurred during content generation." });
    }
  });

  // API Route: Health check
  app.get("/api/health", (req, res) => {
    res.json({ status: "healthy", platform: "RhinoQuant Yorkshire Spot Pricing Server" });
  });

  // Vite integration for dev server
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
