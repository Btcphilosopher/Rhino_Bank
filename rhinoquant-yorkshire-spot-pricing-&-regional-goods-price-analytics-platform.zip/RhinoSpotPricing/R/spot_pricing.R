#==============================================================================
# File: R/spot_pricing.R
# Description: Spot Pricing Engine calculating price momentum and rolling statistics
#==============================================================================

calculate_spot_pricing <- function(market_observations) {
  log_info("Calculating current spot metrics and rolling statistics...")
  
  # Convert observations to data.table for rapid aggregation
  dt <- as.data.table(market_observations)
  
  # Calculate pricing metrics by commodity
  spot_metrics <- dt[, .(
    price = last(price),
    prev_price = nth(price, -2),
    daily_change = ((last(price) - nth(price, -2)) / nth(price, -2)) * 100,
    weekly_change = ((last(price) - nth(price, -6)) / nth(price, -6)) * 100,
    monthly_change = ((last(price) - nth(price, -22)) / nth(price, -22)) * 100,
    annual_change = ((last(price) - first(price)) / first(price)) * 100,
    volatility = sd(diff(log(price))) * sqrt(252) * 100, # Ann. Volatility
    percentile = ecdf(price)(last(price)) * 100
  ), by = .(commodity_id, category)]
  
  # Add regional premium calculation
  catalogue <- GoodsCatalogue$new()
  catalogue$load_from_config("config/settings.json")
  
  spot_metrics[, national_benchmark := sapply(commodity_id, function(cid) {
    bench <- catalogue$goods_db[id == cid, national_benchmark]
    if(length(bench) == 0) return(NA_real_)
    bench
  })]
  
  spot_metrics[, regional_premium := ((price - national_benchmark) / national_benchmark) * 100]
  
  return(spot_metrics)
}
