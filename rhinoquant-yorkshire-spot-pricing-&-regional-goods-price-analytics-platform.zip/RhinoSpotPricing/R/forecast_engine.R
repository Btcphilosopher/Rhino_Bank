#==============================================================================
# File: R/forecast_engine.R
# Description: Time series forecasting (ARIMA / ETS) with predictive bounds
#==============================================================================

fit_predictive_models <- function(spot_metrics, horizon = 12) {
  log_info(paste("Fitting predictive ARIMA & ETS models for horizon =", horizon))
  
  forecast_outputs <- list()
  
  for (cid in unique(spot_metrics$commodity_id)) {
    # Generate historical time series (xts format, converted to ts)
    hist_prices <- get_historical_prices(cid)
    ts_series <- ts(hist_prices$price, frequency = 12)
    
    # Fit Auto-ARIMA model
    arima_fit <- forecast::auto.arima(ts_series, stepwise = TRUE, approximation = FALSE)
    arima_fc <- forecast::forecast(arima_fit, h = horizon)
    
    # Fit ETS Model as a validator
    ets_fit <- forecast::ets(ts_series)
    ets_fc <- forecast::forecast(ets_fit, h = horizon)
    
    forecast_outputs[[cid]] <- list(
      arima = list(
        mean = as.numeric(arima_fc$mean),
        lower80 = as.numeric(arima_fc$lower[, "80%"]),
        upper80 = as.numeric(arima_fc$upper[, "80%"]),
        lower95 = as.numeric(arima_fc$lower[, "95%"]),
        upper95 = as.numeric(arima_fc$upper[, "95%"])
      ),
      ets = list(
        mean = as.numeric(ets_fc$mean),
        lower80 = as.numeric(ets_fc$lower[, "80%"]),
        upper80 = as.numeric(ets_fc$upper[, "80%"])
      )
    )
  }
  
  return(forecast_outputs)
}
