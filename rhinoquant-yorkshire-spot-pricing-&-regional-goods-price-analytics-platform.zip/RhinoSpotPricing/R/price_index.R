#==============================================================================
# File: R/price_index.R
# Description: Calculates composite Regional Goods Price Index (RGPI)
#==============================================================================

calculate_rgpi <- function(spot_metrics, weights) {
  log_info("Calculating composite Regional Goods Price Index (RGPI)...")
  
  # Check weights total to 100% or normalize
  total_w <- sum(unlist(weights))
  norm_w <- lapply(weights, function(w) w / total_w)
  
  # Group spot metrics by sector category
  sector_indices <- spot_metrics[, .(
    sector_index = mean(price / national_benchmark) * 100
  ), by = category]
  
  # Laspeyres aggregater
  rgpi <- 0
  for (cat in names(norm_w)) {
    sec_idx <- sector_indices[category == cat, sector_index]
    if (length(sec_idx) == 0) sec_idx <- 100 # Baseline fallback
    rgpi <- rgpi + (sec_idx * norm_w[[cat]])
  }
  
  log_info(paste("Calculated RGPI Composite Value:", round(rgpi, 2)))
  return(rgpi)
}
