#==============================================================================
# File: R/validation.R
# Description: Data quality control and outlier detection
#==============================================================================

validate_market_observations <- function(observations) {
  log_info("Executing data quality checks on market observations...")
  
  dt <- as.data.table(observations)
  initial_count := nrow(dt)
  
  # 1. Strip missing records
  clean_dt <- na.omit(dt, cols = c("price", "commodity_id"))
  dropped_nas <- initial_count - nrow(clean_dt)
  
  # 2. Statistical Outlier Detection (3-Sigma Rule on price log-returns)
  clean_dt[, log_return := c(0, diff(log(price))), by = commodity_id]
  clean_dt[, outlier := abs(log_return - mean(log_return)) > 3 * sd(log_return), by = commodity_id]
  
  outliers_flagged <- nrow(clean_dt[outlier == TRUE])
  if (outliers_flagged > 0) {
    log_warning(paste("FLAGGED", outliers_flagged, "statistical outliers in raw commodity observations."))
  }
  
  log_success(paste("Validation complete. Cleansed:", dropped_nas, "NAs. Outliers:", outliers_flagged))
  return(clean_dt)
}
