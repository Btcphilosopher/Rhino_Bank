#==============================================================================
# R6 Class: GoodsCatalogue
# File: R/goods_catalogue.R
#==============================================================================
library(R6)

GoodsCatalogue <- R6Class("GoodsCatalogue",
  public = list(
    goods_db = NULL,
    
    initialize = function() {
      self$goods_db <- data.table(
        id = character(),
        name = character(),
        category = character(),
        unit = character(),
        national_benchmark = numeric(),
        description = character()
      )
    },
    
    load_from_config = function(config_path) {
      log_info(paste("Loading goods catalogue from", config_path))
      # Seed standard commodities
      self$add_good("sand", "Marine Aggregates (Sand)", "construction", "GBP/tonne", 23.44, "Washed sand for high-spec concrete.")
      self$add_good("limestone", "Crushed Limestone", "construction", "GBP/tonne", 19.89, "Grade 1 Carboniferous crushed limestone.")
      self$add_good("steel", "Heavy Structural Steel", "metals", "GBP/tonne", 769.63, "Heavy structural steel H-beams.")
      self$add_good("copper", "Grade A Copper Cathodes", "metals", "GBP/tonne", 8220.00, "Cathodes used in industrial transformers.")
      self$add_good("electricity", "Industrial Power (Baseload)", "energy", "GBP/MWh", 94.77, "Baseload wholesale electricity.")
      self$add_good("hydrogen", "Green Hydrogen (H2)", "energy", "GBP/kg", 6.59, "Electrolyzer green hydrogen benchmark.")
      self$add_good("wheat", "Feed Wheat", "agriculture", "GBP/tonne", 200.62, "Winter feed wheat, ex-farm Yorkshire.")
      self$add_good("cable", "Armoured Cable", "products", "GBP/100m", 1344.54, "Copper-cored SWA armoured electrical cabling.")
    },
    
    add_good = function(id, name, category, unit, benchmark, desc) {
      new_row <- data.table(
        id = id,
        name = name,
        category = category,
        unit = unit,
        national_benchmark = benchmark,
        description = desc
      )
      self$goods_db <- rbind(self$goods_db, new_row)
    },
    
    get_goods_by_category = function(cat) {
      return(self$goods_db[category == cat])
    }
  )
)
