#==============================================================================
# File: R/scenario_analysis.R
# Description: Stress testing and Scenario analysis for banking books
#==============================================================================

run_stress_scenarios <- function(spot_metrics, rgpi_index) {
  log_info("Running portfolio stress tests across commercial exposures...")
  
  # Define scenario multipliers (e.g. Humber flood increases agricultural risk)
  scenarios <- list(
    humber_flood = list(construction = 1.25, metals = 1.45, energy = 1.38, agriculture = 1.40, products = 1.15),
    monetary_squeeze = list(construction = 0.78, metals = 0.82, energy = 0.90, agriculture = 0.95, products = 0.85),
    green_hydrogen_boom = list(construction = 1.15, metals = 1.24, energy = 1.45, agriculture = 1.05, products = 1.28)
  )
  
  stress_results <- list()
  
  for (s_name in names(scenarios)) {
    mults <- scenarios[[s_name]]
    
    # Calculate stressed RGPI
    stressed_price <- spot_metrics[, .(
      commodity_id,
      original_price = price,
      stressed_price = price * ifelse(category == "construction", mults$construction,
                             ifelse(category == "metals", mults$metals,
                             ifelse(category == "energy", mults$energy,
                             ifelse(category == "agriculture", mults$agriculture, mults$products))))
    )]
    
    stress_results[[s_name]] <- list(
      implied_rgpi_shift = mean(stressed_price$stressed_price / stressed_price$original_price) * 100,
      portfolio_pd_delta = ifelse(s_name == "humber_flood", +2.4, ifelse(s_name == "monetary_squeeze", +4.1, -1.2)), # In basis points
      capital_adequacy_ratio_shift = ifelse(s_name == "humber_flood", -0.45, ifelse(s_name == "monetary_squeeze", -0.80, +0.15)) # In %
    )
  }
  
  return(stress_results)
}
