#==============================================================================
# RhinoQuant - Yorkshire Spot Pricing & Regional Goods Price Analytics Platform
#==============================================================================
# Author: Chief Quantitative Economist & Systems Architect (Rhino Bank)
# File: main.R
# Purpose: Core orchestration script to execute the pricing pipeline
#==============================================================================

message("Initializing RhinoQuant Yorkshire Spot Pricing Pipeline...")

# 1. Load Required Enterprise Libraries
library(tidyverse)
library(data.table)
library(xts)
library(zoo)
library(forecast)
library(ggplot2)
library(shiny)

# 2. Source System Modules
source("R/utilities.R")
source("R/validation.R")
source("R/goods_catalogue.R")
source("R/market_data.R")
source("R/spot_pricing.R")
source("R/price_index.R")
source("R/regional_analysis.R")
source("R/forecast_engine.R")
source("R/time_series.R")
source("R/econometrics.R")
source("R/scenario_analysis.R")
source("R/reporting.R")
source("R/dashboard.R")

# 3. Boot configuration & Set Seed for Reproducibility
set.seed(42)
config <- load_json_config("config/settings.json")

# 4. Core Pipeline Execution
run_pipeline <- function() {
  log_info("Starting full data processing and validation sequence...")
  
  # A. Instantiate Goods Catalogue (R6 Class)
  catalogue <- GoodsCatalogue$new()
  catalogue$load_from_config("config/settings.json")
  
  # B. Fetch & Validate Spot Market Observations
  raw_data <- fetch_spot_data()
  validated_data <- validate_market_observations(raw_data)
  
  # C. Compute Spot Pricing Metrics & Moving Averages
  spot_metrics <- calculate_spot_pricing(validated_data)
  
  # D. Calculate Regional Goods Price Index (RGPI)
  rgpi_index <- calculate_rgpi(spot_metrics, config$sector_weights)
  
  # E. Trigger Forecast Engine & ARIMA/ETS fitting
  forecast_results <- fit_predictive_models(spot_metrics, horizon = 12)
  
  # F. Execute Scenario Stress-testing for lending portfolios
  stressed_exposures <- run_stress_scenarios(spot_metrics, rgpi_index)
  
  log_success("Analytics Pipeline ran successfully! Ready for dashboard deployment.")
  
  # Return data bundle
  list(
    catalogue = catalogue,
    spot_metrics = spot_metrics,
    rgpi_index = rgpi_index,
    forecast_results = forecast_results,
    stressed_exposures = stressed_exposures
  )
}

# 5. Launch Executive Dashboard (Optional if running headless)
if (interactive() || Sys.getenv("LAUNCH_DASHBOARD") == "TRUE") {
  data_bundle <- run_pipeline()
  launch_shiny_dashboard(data_bundle)
}
