export interface CommodityGood {
  id: string;
  name: string;
  category: "construction" | "metals" | "energy" | "agriculture" | "products";
  unit: string;
  price: number; // in GBP
  prevPrice: number;
  dailyChange: number; // percentage
  weeklyChange: number;
  monthlyChange: number;
  annualChange: number;
  volatility: number; // percentage
  percentile: number; // historical percentile 0-100
  regionalPremium: number; // percentage in Yorkshire over National
  nationalBenchmark: number; // national price
  description: string;
}

export interface RegionMetric {
  id: string;
  name: string; // e.g., "West Yorkshire"
  localAuthorities: string[];
  gdpShare: number; // percentage of Yorkshire GDP
  premiumAdjustment: number; // standard regional price delta
  dominantSector: string;
}

export interface SectorWeight {
  construction: number;
  metals: number;
  energy: number;
  agriculture: number;
  products: number;
}

export interface Scenario {
  id: string;
  name: string;
  description: string;
  constructionImpact: number; // price multiplier e.g. 1.2
  metalsImpact: number;
  energyImpact: number;
  agricultureImpact: number;
  productsImpact: number;
  macroSentiment: "Bullish" | "Bearish" | "Stable" | "Highly Volatile";
  severity: "Minor" | "Moderate" | "Severe" | "Extreme";
}

export interface ForecastPoint {
  date: string;
  historical?: number;
  forecast?: number;
  lower80?: number;
  upper80?: number;
  lower95?: number;
  upper95?: number;
}

export interface RFile {
  name: string;
  path: string;
  category: "R" | "tests" | "config" | "docs" | "root";
  description: string;
  code: string;
}

export interface TerminalLine {
  text: string;
  type: "input" | "output" | "error" | "success" | "system";
  timestamp: string;
}
