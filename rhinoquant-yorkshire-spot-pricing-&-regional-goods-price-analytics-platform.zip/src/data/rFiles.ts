import { RFile } from "../types/pricing";

export const R_FILES: RFile[] = [
  {
    name: "main.R",
    path: "/RhinoSpotPricing/main.R",
    category: "root",
    description: "Primary system entry point. Boots settings, loads libraries, builds catalogues, starts validation checks, and launches the Yorkshire Futurist Shiny Executive Dashboard.",
    code: `#==============================================================================
# RhinoQuant - Yorkshire Spot Pricing & Regional Goods Price Analytics Platform
#==============================================================================
# Author: Chief Quantitative Economist & Systems Architect (Rhino Bank)
# File: main.R
# Purpose: Core orchestration script to execute the pricing pipeline
#==============================================================================

message("Initializing RhinoQuant Yorkshire Spot Pricing Pipeline...")

# 1. Load Required Enterprise Libraries
library(tidyverse)
library(data.table)
library(xts)
library(zoo)
library(forecast)
library(ggplot2)
library(shiny)

# 2. Source System Modules
source("R/utilities.R")
source("R/validation.R")
source("R/goods_catalogue.R")
source("R/market_data.R")
source("R/spot_pricing.R")
source("R/price_index.R")
source("R/regional_analysis.R")
source("R/forecast_engine.R")
source("R/time_series.R")
source("R/econometrics.R")
source("R/scenario_analysis.R")
source("R/reporting.R")
source("R/dashboard.R")

# 3. Boot configuration & Set Seed for Reproducibility
set.seed(42)
config <- load_json_config("config/settings.json")

# 4. Core Pipeline Execution
run_pipeline <- function() {
  log_info("Starting full data processing and validation sequence...")
  
  # A. Instantiate Goods Catalogue (R6 Class)
  catalogue <- GoodsCatalogue$new()
  catalogue$load_from_config(config$goods_catalogue_path)
  
  # B. Fetch & Validate Spot Market Observations
  raw_data <- fetch_spot_data()
  validated_data <- validate_market_observations(raw_data)
  
  # C. Compute Spot Pricing Metrics & Moving Averages
  spot_metrics <- calculate_spot_pricing(validated_data)
  
  # D. Calculate Regional Goods Price Index (RGPI)
  rgpi_index <- calculate_rgpi(spot_metrics, config$sector_weights)
  
  # E. Trigger Forecast Engine & ARIMA/ETS fitting
  forecast_results <- fit_predictive_models(spot_metrics, horizon = 12)
  
  # F. Execute Scenario Stress-testing for lending portfolios
  stressed_exposures <- run_stress_scenarios(spot_metrics, rgpi_index)
  
  log_success("Analytics Pipeline ran successfully! Ready for dashboard deployment.")
  
  # Return data bundle
  list(
    catalogue = catalogue,
    spot_metrics = spot_metrics,
    rgpi_index = rgpi_index,
    forecast_results = forecast_results,
    stressed_exposures = stressed_exposures
  )
}

# 5. Launch Executive Dashboard (Optional if running headless)
if (interactive() || Sys.getenv("LAUNCH_DASHBOARD") == "TRUE") {
  data_bundle <- run_pipeline()
  launch_shiny_dashboard(data_bundle)
}
`
  },
  {
    name: "goods_catalogue.R",
    path: "/RhinoSpotPricing/R/goods_catalogue.R",
    category: "R",
    description: "Configures and manages the available standard goods database, their baseline national benchmarks, units, categories, and Yorkshire-specific distribution weights.",
    code: `#==============================================================================
# R6 Class: GoodsCatalogue
# File: R/goods_catalogue.R
#==============================================================================
library(R6)

GoodsCatalogue <- R6Class("GoodsCatalogue",
  public = list(
    goods_db = NULL,
    
    initialize = function() {
      self$goods_db <- data.table(
        id = character(),
        name = character(),
        category = character(),
        unit = character(),
        national_benchmark = numeric(),
        description = character()
      )
    },
    
    load_from_config = function(config_path) {
      log_info(paste("Loading goods catalogue from", config_path))
      # In real execution, read JSON. For now, seed standard commodities:
      self$add_good("sand", "Marine Aggregates (Sand)", "construction", "GBP/tonne", 23.44, "Washed sand for high-spec concrete.")
      self$add_good("limestone", "Crushed Limestone", "construction", "GBP/tonne", 19.89, "Grade 1 Carboniferous crushed limestone.")
      self$add_good("steel", "Heavy Structural Steel", "metals", "GBP/tonne", 769.63, "Heavy structural steel H-beams.")
      self$add_good("copper", "Grade A Copper Cathodes", "metals", "GBP/tonne", 8220.00, "Cathodes used in industrial transformers.")
      self$add_good("electricity", "Industrial Power (Baseload)", "energy", "GBP/MWh", 94.77, "Baseload wholesale electricity.")
      self$add_good("hydrogen", "Green Hydrogen (H2)", "energy", "GBP/kg", 6.59, "Electrolyzer green hydrogen benchmark.")
      self$add_good("wheat", "Feed Wheat", "agriculture", "GBP/tonne", 200.62, "Winter feed wheat, ex-farm Yorkshire.")
      self$add_good("cable", "Armoured Cable", "products", "GBP/100m", 1344.54, "Copper-cored SWA armoured electrical cabling.")
    },
    
    add_good = function(id, name, category, unit, benchmark, desc) {
      new_row <- data.table(
        id = id,
        name = name,
        category = category,
        unit = unit,
        national_benchmark = benchmark,
        description = desc
      )
      self$goods_db <- rbind(self$goods_db, new_row)
    },
    
    get_goods_by_category = function(cat) {
      return(self$goods_db[category == cat])
    }
  )
)
`
  },
  {
    name: "spot_pricing.R",
    path: "/RhinoSpotPricing/R/spot_pricing.R",
    category: "R",
    description: "Calculates local spot benchmarks, volatility, price momentum (daily/weekly/monthly changes), percentiles, and regional premiums/discounts.",
    code: `#==============================================================================
# File: R/spot_pricing.R
# Description: Spot Pricing Engine calculating price momentum and rolling statistics
#==============================================================================

calculate_spot_pricing <- function(market_observations) {
  log_info("Calculating current spot metrics and rolling statistics...")
  
  # Convert observations to data.table for rapid aggregation
  dt <- as.data.table(market_observations)
  
  # Calculate pricing metrics by commodity
  spot_metrics <- dt[, .(
    price = last(price),
    prev_price = nth(price, -2),
    daily_change = ((last(price) - nth(price, -2)) / nth(price, -2)) * 100,
    weekly_change = ((last(price) - nth(price, -6)) / nth(price, -6)) * 100,
    monthly_change = ((last(price) - nth(price, -22)) / nth(price, -22)) * 100,
    annual_change = ((last(price) - first(price)) / first(price)) * 100,
    volatility = sd(diff(log(price))) * sqrt(252) * 100, # Ann. Volatility
    percentile = ecdf(price)(last(price)) * 100
  ), by = .(commodity_id, category)]
  
  # Add regional premium calculation
  # Local spot is compared to National Benchmark loaded from Catalogue
  catalogue <- GoodsCatalogue$new()
  catalogue$load_from_config("config/catalogue.json")
  
  spot_metrics[, national_benchmark := sapply(commodity_id, function(cid) {
    bench <- catalogue$goods_db[id == cid, national_benchmark]
    if(length(bench) == 0) return(NA_real_)
    bench
  })]
  
  spot_metrics[, regional_premium := ((price - national_benchmark) / national_benchmark) * 100]
  
  return(spot_metrics)
}
`
  },
  {
    name: "price_index.R",
    path: "/RhinoSpotPricing/R/price_index.R",
    category: "R",
    description: "Calculates the Regional Goods Price Index (RGPI) using a Laspeyres-type formula, allowing dynamic custom category weights for construction, energy, etc.",
    code: `#==============================================================================
# File: R/price_index.R
# Description: Calculates composite Regional Goods Price Index (RGPI)
#==============================================================================

calculate_rgpi <- function(spot_metrics, weights) {
  log_info("Calculating composite Regional Goods Price Index (RGPI)...")
  
  # Check weights total to 100% or normalize
  total_w <- sum(unlist(weights))
  norm_w <- lapply(weights, function(w) w / total_w)
  
  # Group spot metrics by sector category
  sector_indices <- spot_metrics[, .(
    sector_index = mean(price / national_benchmark) * 100
  ), by = category]
  
  # Laspeyres aggregater
  rgpi <- 0
  for (cat in names(norm_w)) {
    sec_idx <- sector_indices[category == cat, sector_index]
    if (length(sec_idx) == 0) sec_idx <- 100 # Baseline fallback
    rgpi <- rgpi + (sec_idx * norm_w[[cat]])
  }
  
  log_info(paste("Calculated RGPI Composite Value:", round(rgpi, 2)))
  return(rgpi)
}
`
  },
  {
    name: "forecast_engine.R",
    path: "/RhinoSpotPricing/R/forecast_engine.R",
    category: "R",
    description: "Predictive engine fitting ARIMA and ETS (Exponential Smoothing) models to historical prices and outputting 80% and 95% confidence intervals.",
    code: `#==============================================================================
# File: R/forecast_engine.R
# Description: Time series forecasting (ARIMA / ETS) with predictive bounds
#==============================================================================

fit_predictive_models <- function(spot_metrics, horizon = 12) {
  log_info(paste("Fitting predictive ARIMA & ETS models for horizon =", horizon))
  
  forecast_outputs <- list()
  
  for (cid in unique(spot_metrics$commodity_id)) {
    # Generate historical time series (xts format, converted to ts)
    hist_prices <- get_historical_prices(cid)
    ts_series <- ts(hist_prices$price, frequency = 12)
    
    # Fit Auto-ARIMA model
    arima_fit <- forecast::auto.arima(ts_series, stepwise = TRUE, approximation = FALSE)
    arima_fc <- forecast::forecast(arima_fit, h = horizon)
    
    # Fit ETS Model as a validator
    ets_fit <- forecast::ets(ts_series)
    ets_fc <- forecast::forecast(ets_fit, h = horizon)
    
    forecast_outputs[[cid]] <- list(
      arima = list(
        mean = as.numeric(arima_fc$mean),
        lower80 = as.numeric(arima_fc$lower[, "80%"]),
        upper80 = as.numeric(arima_fc$upper[, "80%"]),
        lower95 = as.numeric(arima_fc$lower[, "95%"]),
        upper95 = as.numeric(arima_fc$upper[, "95%"])
      ),
      ets = list(
        mean = as.numeric(ets_fc$mean),
        lower80 = as.numeric(ets_fc$lower[, "80%"]),
        upper80 = as.numeric(ets_fc$upper[, "80%"])
      )
    )
  }
  
  return(forecast_outputs)
}
`
  },
  {
    name: "econometrics.R",
    path: "/RhinoSpotPricing/R/econometrics.R",
    category: "R",
    description: "Contains multivariate regressions, seasonal decomposition (STL), and statistical outlier-detection models to examine macroeconomic drivers of pricing.",
    code: `#==============================================================================
# File: R/econometrics.R
# Description: Econometric modelling, STL decomposition, and outlier detection
#==============================================================================

run_regression_analysis <- function(commodity_id, macro_indicators) {
  log_info(paste("Running multivariate OLS regression on", commodity_id))
  
  prices <- get_historical_prices(commodity_id)
  dataset <- merge(prices, macro_indicators, by = "date")
  
  # Fit Linear Model: Commodity Price as function of Inflation, Lending Rates, GDP
  model <- lm(price ~ inflation + base_rate + industrial_gdp, data = dataset)
  model_summary <- summary(model)
  
  return(list(
    coefficients = model_summary$coefficients,
    r_squared = model_summary$r.squared,
    adj_r_squared = model_summary$adj.r.squared,
    f_statistic = model_summary$fstatistic,
    p_value = pf(model_summary$fstatistic[1], model_summary$fstatistic[2], model_summary$fstatistic[3], lower.tail=FALSE)
  ))
}

run_seasonal_decomposition <- function(commodity_id) {
  prices <- get_historical_prices(commodity_id)
  ts_series <- ts(prices$price, frequency = 12)
  
  # STL Decomposition: Seasonal, Trend, and Remainder
  decomp <- stl(ts_series, s.window = "periodic")
  
  return(list(
    trend = as.numeric(decomp$time.series[, "trend"]),
    seasonal = as.numeric(decomp$time.series[, "seasonal"]),
    remainder = as.numeric(decomp$time.series[, "remainder"])
  ))
}
`
  },
  {
    name: "scenario_analysis.R",
    path: "/RhinoSpotPricing/R/scenario_analysis.R",
    category: "R",
    description: "Simulates macroeconomic stress-tests (Humber flooding, monetary hikes, green energy surges) to calculate impacts on Yorkshire's commercial debt portfolios.",
    code: `#==============================================================================
# File: R/scenario_analysis.R
# Description: Stress testing and Scenario analysis for banking books
#==============================================================================

run_stress_scenarios <- function(spot_metrics, rgpi_index) {
  log_info("Running portfolio stress tests across commercial exposures...")
  
  # Define scenario multipliers (e.g. Humber flood increases agricultural risk)
  scenarios <- list(
    humber_flood = list(construction = 1.25, metals = 1.45, energy = 1.38, agriculture = 1.40, products = 1.15),
    monetary_squeeze = list(construction = 0.78, metals = 0.82, energy = 0.90, agriculture = 0.95, products = 0.85),
    green_hydrogen_boom = list(construction = 1.15, metals = 1.24, energy = 1.45, agriculture = 1.05, products = 1.28)
  )
  
  stress_results <- list()
  
  for (s_name in names(scenarios)) {
    mults <- scenarios[[s_name]]
    
    # Calculate stressed RGPI
    stressed_price <- spot_metrics[, .(
      commodity_id,
      original_price = price,
      stressed_price = price * ifelse(category == "construction", mults$construction,
                             ifelse(category == "metals", mults$metals,
                             ifelse(category == "energy", mults$energy,
                             ifelse(category == "agriculture", mults$agriculture, mults$products))))
    )]
    
    stress_results[[s_name]] <- list(
      implied_rgpi_shift = mean(stressed_price$stressed_price / stressed_price$original_price) * 100,
      portfolio_pd_delta = ifelse(s_name == "humber_flood", +2.4, ifelse(s_name == "monetary_squeeze", +4.1, -1.2)), # In basis points
      capital_adequacy_ratio_shift = ifelse(s_name == "humber_flood", -0.45, ifelse(s_name == "monetary_squeeze", -0.80, +0.15)) # In %
    )
  }
  
  return(stress_results)
}
`
  },
  {
    name: "validation.R",
    path: "/RhinoSpotPricing/R/validation.R",
    category: "R",
    description: "Ensures spot data integrity by identifying missing values, flagging statistical outliers, and validating transaction reporting bounds.",
    code: `#==============================================================================
# File: R/validation.R
# Description: Data quality control and outlier detection
#==============================================================================

validate_market_observations <- function(observations) {
  log_info("Executing data quality checks on market observations...")
  
  dt <- as.data.table(observations)
  initial_count <- nrow(dt)
  
  # 1. Strip missing records
  clean_dt <- na.omit(dt, cols = c("price", "commodity_id"))
  dropped_nas <- initial_count - nrow(clean_dt)
  
  # 2. Statistical Outlier Detection (3-Sigma Rule on price log-returns)
  clean_dt[, log_return := c(0, diff(log(price))), by = commodity_id]
  clean_dt[, outlier := abs(log_return - mean(log_return)) > 3 * sd(log_return), by = commodity_id]
  
  outliers_flagged <- nrow(clean_dt[outlier == TRUE])
  if (outliers_flagged > 0) {
    log_warning(paste("FLAGGED", outliers_flagged, "statistical outliers in raw commodity observations."))
  }
  
  log_success(paste("Validation complete. Cleansed:", dropped_nas, "NAs. Outliers:", outliers_flagged))
  return(clean_dt)
}
`
  },
  {
    name: "test_analytics.R",
    path: "/RhinoSpotPricing/tests/test_analytics.R",
    category: "tests",
    description: "Unit testing suite leveraging 'testthat' to guarantee forecast outputs, Laspeyres index maths, and outlier detection models.",
    code: `#==============================================================================
# File: tests/test_analytics.R
# Description: Unit tests for econometrics and pricing models
#==============================================================================
library(testthat)

context("RhinoQuant Analytical Calculations")

test_that("Goods catalogue loads correct items and benchmarks", {
  catalogue <- GoodsCatalogue$new()
  catalogue$load_from_config("config/catalogue.json")
  
  expect_true(nrow(catalogue$goods_db) >= 8)
  expect_equal(catalogue$goods_db[id == "steel", category], "metals")
  expect_equal(catalogue$goods_db[id == "hydrogen", national_benchmark], 6.59)
})

test_that("RGPI weight normalization is robust", {
  spot_metrics <- data.table(
    commodity_id = c("sand", "steel", "electricity", "wheat", "cable"),
    category = c("construction", "metals", "energy", "agriculture", "products"),
    price = c(20, 700, 90, 200, 1000),
    national_benchmark = c(20, 700, 90, 200, 1000)
  )
  
  # Balanced weights
  weights <- list(construction = 20, metals = 20, energy = 20, agriculture = 20, products = 20)
  rgpi <- calculate_rgpi(spot_metrics, weights)
  
  expect_equal(rgpi, 100.0)
})

test_that("Forecast engine returns proper predictive bands", {
  hist_data <- data.table(
    commodity_id = rep("steel", 24),
    price = seq(600, 800, length.out = 24)
  )
  
  # Stub test forecasting auto arima
  forecasts <- fit_predictive_models(spot_metrics = data.table(commodity_id = "steel"), horizon = 3)
  expect_length(forecasts, 1)
  expect_true(all(forecasts$steel$arima$upper80 >= forecasts$steel$arima$mean))
})
`
  },
  {
    name: "settings.json",
    path: "/RhinoSpotPricing/config/settings.json",
    category: "config",
    description: "Database configurations, default Laspeyres sector weights, forecasting horizons, and model execution hyperparameters.",
    code: `{
  "platform_name": "RhinoQuant Yorkshire Spot Pricing Platform",
  "base_currency": "GBP",
  "goods_catalogue_path": "config/catalogue.json",
  "default_forecast_horizon": 12,
  "sector_weights": {
    "construction": 25.0,
    "metals": 25.0,
    "energy": 20.0,
    "agriculture": 15.0,
    "products": 15.0
  },
  "geographies": [
    "west_yorkshire",
    "south_yorkshire",
    "north_yorkshire",
    "east_riding",
    "humber_region"
  ],
  "validation_rules": {
    "sigma_outlier_threshold": 3.0,
    "allow_missing_dates": false,
    "max_price_volatility_pct": 50.0
  }
}`
  }
];
