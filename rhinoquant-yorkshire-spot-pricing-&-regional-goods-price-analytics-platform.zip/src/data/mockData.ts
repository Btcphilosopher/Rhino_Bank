import { CommodityGood, RegionMetric, Scenario, ForecastPoint, SectorWeight } from "../types/pricing";

export const REGIONS: RegionMetric[] = [
  {
    id: "west_yorkshire",
    name: "West Yorkshire",
    localAuthorities: ["Leeds", "Bradford", "Wakefield", "Kirklees", "Calderdale"],
    gdpShare: 42,
    premiumAdjustment: -1.2, // general discount due to competitive logistics hubs
    dominantSector: "Manufacturing & Industrial Products Services",
  },
  {
    id: "south_yorkshire",
    name: "South Yorkshire",
    localAuthorities: ["Sheffield", "Rotherham", "Doncaster", "Barnsley"],
    gdpShare: 21,
    premiumAdjustment: 2.5, // metals premium
    dominantSector: "Industrial Metals & Specialized Alloys",
  },
  {
    id: "north_yorkshire",
    name: "North Yorkshire",
    localAuthorities: ["York", "Harrogate", "Scarborough", "Craven", "Richmondshire"],
    gdpShare: 18,
    premiumAdjustment: 3.1, // agricultural premium
    dominantSector: "Agricultural Goods & Food Processing",
  },
  {
    id: "east_riding",
    name: "East Riding of Yorkshire",
    localAuthorities: ["Beverley", "Bridlington", "Goole", "Haltemprice"],
    gdpShare: 9,
    premiumAdjustment: 1.8, // coastal supply premium
    dominantSector: "Agribusiness & Port-based Supply Chains",
  },
  {
    id: "humber_region",
    name: "Humber Region",
    localAuthorities: ["Kingston upon Hull", "Grimsby", "Scunthorpe", "Cleethorpes"],
    gdpShare: 10,
    premiumAdjustment: 4.2, // heavy energy and chemical infrastructure premium
    dominantSector: "Energy, Chemicals, & Heavy Metallurgy",
  },
];

export const COMMODITIES: CommodityGood[] = [
  // --- Construction Materials ---
  {
    id: "sand",
    name: "Marine Aggregates (Sand)",
    category: "construction",
    unit: "GBP/tonne",
    price: 24.50,
    prevPrice: 24.10,
    dailyChange: 0.45,
    weeklyChange: 1.2,
    monthlyChange: -0.8,
    annualChange: 6.4,
    volatility: 3.1,
    percentile: 72,
    regionalPremium: 4.5, // Yorkshire aggregates have premium due to high infrastructure demands
    nationalBenchmark: 23.44,
    description: "Washed marine-dredged sand for high-spec concrete production, sourced from North Sea offshore licences.",
  },
  {
    id: "limestone",
    name: "Crushed Limestone",
    category: "construction",
    unit: "GBP/tonne",
    price: 18.20,
    prevPrice: 18.25,
    dailyChange: -0.27,
    weeklyChange: -0.5,
    monthlyChange: 1.1,
    annualChange: 9.2,
    volatility: 2.4,
    percentile: 85,
    regionalPremium: -8.5, // discount due to massive local quarries in North Yorkshire & Peak fringes
    nationalBenchmark: 19.89,
    description: "Grade 1 Carboniferous crushed limestone from North Yorkshire quarries, suitable for sub-base and structural fill.",
  },
  {
    id: "clay",
    name: "Yorkshire Structural Clay",
    category: "construction",
    unit: "GBP/tonne",
    price: 32.10,
    prevPrice: 32.10,
    dailyChange: 0.00,
    weeklyChange: 0.8,
    monthlyChange: 2.4,
    annualChange: 11.5,
    volatility: 1.8,
    percentile: 91,
    regionalPremium: 5.2,
    nationalBenchmark: 30.51,
    description: "Premium brickmaking clay mined locally, highly sought after for restoration projects and traditional architectural brick production.",
  },
  {
    id: "cement",
    name: "Portland Cement (CEM I)",
    category: "construction",
    unit: "GBP/tonne",
    price: 145.00,
    prevPrice: 142.80,
    dailyChange: 1.54,
    weeklyChange: 2.1,
    monthlyChange: 4.8,
    annualChange: 18.4,
    volatility: 6.2,
    percentile: 96,
    regionalPremium: 2.1,
    nationalBenchmark: 142.02,
    description: "Bulk ordinary Portland cement from carbon-efficient kiln operations in South Yorkshire, a core building block of infrastructure finance.",
  },
  {
    id: "brick",
    name: "Standard Facing Bricks",
    category: "construction",
    unit: "GBP/1000 units",
    price: 680.00,
    prevPrice: 680.00,
    dailyChange: 0.00,
    weeklyChange: 0.5,
    monthlyChange: 1.2,
    annualChange: 14.1,
    volatility: 4.3,
    percentile: 89,
    regionalPremium: 3.8,
    nationalBenchmark: 655.10,
    description: "Wirecut facing bricks, calibrated for regional architectural specifications.",
  },
  {
    id: "timber",
    name: "C16 Construction Timber",
    category: "construction",
    unit: "GBP/m³",
    price: 310.00,
    prevPrice: 314.50,
    dailyChange: -1.43,
    weeklyChange: -2.0,
    monthlyChange: -5.4,
    annualChange: -8.1,
    volatility: 8.9,
    percentile: 45,
    regionalPremium: -1.5,
    nationalBenchmark: 314.72,
    description: "Kiln-dried, strength-graded softwood structural timber, imported via Humber ports.",
  },

  // --- Industrial Metals ---
  {
    id: "steel",
    name: "Heavy Structural Steel (H-Beams)",
    category: "metals",
    unit: "GBP/tonne",
    price: 745.00,
    prevPrice: 752.00,
    dailyChange: -0.93,
    weeklyChange: -1.2,
    monthlyChange: 3.2,
    annualChange: -4.8,
    volatility: 11.5,
    percentile: 58,
    regionalPremium: -3.2, // discount due to major production assets in Scunthorpe / Sheffield area
    nationalBenchmark: 769.63,
    description: "Structural structural steel sections, alloyed and shaped by heavy mills in Scunthorpe.",
  },
  {
    id: "iron",
    name: "Foundry Pig Iron",
    category: "metals",
    unit: "GBP/tonne",
    price: 430.00,
    prevPrice: 428.50,
    dailyChange: 0.35,
    weeklyChange: 1.1,
    monthlyChange: 2.9,
    annualChange: 12.3,
    volatility: 8.1,
    percentile: 79,
    regionalPremium: 1.4,
    nationalBenchmark: 424.06,
    description: "High-purity basic pig iron used in Yorkshire forge foundries for precision casting.",
  },
  {
    id: "copper",
    name: "Grade A Copper Cathodes",
    category: "metals",
    unit: "GBP/tonne",
    price: 8450.00,
    prevPrice: 8410.00,
    dailyChange: 0.48,
    weeklyChange: 2.4,
    monthlyChange: -1.5,
    annualChange: 15.2,
    volatility: 14.2,
    percentile: 82,
    regionalPremium: 2.8, // high premium due to localized electrical cabling manufacturing hubs in Leeds/Bradford
    nationalBenchmark: 8220.00,
    description: "LME-grade minimum 99.99% pure copper cathodes used in electrical wiring and advanced industrial transformers.",
  },
  {
    id: "aluminium",
    name: "High-Grade Aluminium Alloy",
    category: "metals",
    unit: "GBP/tonne",
    price: 2150.00,
    prevPrice: 2165.00,
    dailyChange: -0.69,
    weeklyChange: -0.8,
    monthlyChange: -2.3,
    annualChange: 7.9,
    volatility: 9.4,
    percentile: 63,
    regionalPremium: -0.5,
    nationalBenchmark: 2160.80,
    description: "Primary extrusion-grade aluminium alloy block, critical for regional aerospace suppliers in Yorkshire.",
  },

  // --- Energy ---
  {
    id: "electricity",
    name: "Industrial Power (Baseload)",
    category: "energy",
    unit: "GBP/MWh",
    price: 92.50,
    prevPrice: 91.00,
    dailyChange: 1.65,
    weeklyChange: 4.8,
    monthlyChange: 8.2,
    annualChange: 24.5,
    volatility: 18.6,
    percentile: 88,
    regionalPremium: -2.4, // lower pricing due to massive offshore wind connections and Drax power station
    nationalBenchmark: 94.77,
    description: "Baseload industrial electricity contract, delivered to grid interconnectors in Yorkshire.",
  },
  {
    id: "gas",
    name: "Natural Gas (NBP)",
    category: "energy",
    unit: "GBp/therm",
    price: 84.20,
    prevPrice: 86.10,
    dailyChange: -2.21,
    weeklyChange: -3.5,
    monthlyChange: 6.8,
    annualChange: -12.4,
    volatility: 22.4,
    percentile: 51,
    regionalPremium: -4.1, // discount due to direct gas terminals in Easington (East Riding)
    nationalBenchmark: 87.80,
    description: "National Balancing Point benchmark natural gas, flowing through Yorkshire storage assets.",
  },
  {
    id: "hydrogen",
    name: "Green Hydrogen (H2 Benchmark)",
    category: "energy",
    unit: "GBP/kg",
    price: 5.80,
    prevPrice: 5.85,
    dailyChange: -0.85,
    weeklyChange: -1.2,
    monthlyChange: -3.8,
    annualChange: -15.4,
    volatility: 12.5,
    percentile: 32,
    regionalPremium: -12.0, // Significant discount due to Humber hydrogen cluster deployment
    nationalBenchmark: 6.59,
    description: "Electrolyzer-produced low carbon green hydrogen, pilot benchmark pricing within the East Coast Grid initiative.",
  },
  {
    id: "biomass",
    name: "Industrial Wood Pellets",
    category: "energy",
    unit: "GBP/tonne",
    price: 185.00,
    prevPrice: 184.00,
    dailyChange: 0.54,
    weeklyChange: 1.0,
    monthlyChange: 2.5,
    annualChange: 16.7,
    volatility: 7.4,
    percentile: 76,
    regionalPremium: 3.2,
    nationalBenchmark: 179.26,
    description: "Premium compressed wood biomass pellets imported via Port of Hull, used for co-firing power generation.",
  },

  // --- Agricultural Goods ---
  {
    id: "wheat",
    name: "Feed Wheat",
    category: "agriculture",
    unit: "GBP/tonne",
    price: 195.00,
    prevPrice: 193.50,
    dailyChange: 0.78,
    weeklyChange: 1.5,
    monthlyChange: -4.2,
    annualChange: -18.2,
    volatility: 11.2,
    percentile: 38,
    regionalPremium: -2.8, // agricultural heartlands keep prices highly competitive
    nationalBenchmark: 200.62,
    description: "Yorkshire-grown winter feed wheat, benchmark standard ex-farm price.",
  },
  {
    id: "barley",
    name: "Malt Barley",
    category: "agriculture",
    unit: "GBP/tonne",
    price: 225.00,
    prevPrice: 224.20,
    dailyChange: 0.36,
    weeklyChange: 0.8,
    monthlyChange: -2.1,
    annualChange: -9.5,
    volatility: 9.8,
    percentile: 52,
    regionalPremium: 4.1, // Premium driven by heavy Yorkshire malting, brewing and distilling demand (Tadcaster, etc.)
    nationalBenchmark: 216.14,
    description: "Premium spring malting barley, meeting strict moisture and nitrogen criteria.",
  },
  {
    id: "potatoes",
    name: "Maincrop Ware Potatoes",
    category: "agriculture",
    unit: "GBP/tonne",
    price: 295.00,
    prevPrice: 295.00,
    dailyChange: 0.00,
    weeklyChange: 2.3,
    monthlyChange: 10.4,
    annualChange: 38.2,
    volatility: 16.4,
    percentile: 94,
    regionalPremium: -1.2,
    nationalBenchmark: 298.58,
    description: "Standard grade maincrop potatoes ex-farm North Yorkshire, subject to wet weather constraints.",
  },
  {
    id: "beef",
    name: "R3 Breeding Cattle (Beef)",
    category: "agriculture",
    unit: "GBp/kg dwd",
    price: 492.00,
    prevPrice: 489.50,
    dailyChange: 0.51,
    weeklyChange: 1.2,
    monthlyChange: 3.4,
    annualChange: 12.8,
    volatility: 5.4,
    percentile: 86,
    regionalPremium: 1.8,
    nationalBenchmark: 483.30,
    description: "Yorkshire auction ring average for R3-grade prime finished beef cattle.",
  },

  // --- Industrial Products ---
  {
    id: "cable",
    name: "Heavy Duty Armoured Cable",
    category: "products",
    unit: "GBP/100m",
    price: 1280.00,
    prevPrice: 1265.00,
    dailyChange: 1.19,
    weeklyChange: 2.8,
    monthlyChange: 4.5,
    annualChange: 22.4,
    volatility: 8.3,
    percentile: 93,
    regionalPremium: -4.8, // West Yorkshire has a high concentration of cable and extrusion manufacturers
    nationalBenchmark: 1344.54,
    description: "Copper-cored SWA (Steel Wire Armoured) industrial electrical cable, critical for wind farms and factory fitouts.",
  },
  {
    id: "bearings",
    name: "Heavy Spherical Bearings",
    category: "products",
    unit: "GBP/unit",
    price: 185.00,
    prevPrice: 185.00,
    dailyChange: 0.00,
    weeklyChange: 0.4,
    monthlyChange: 1.8,
    annualChange: 6.5,
    volatility: 2.1,
    percentile: 74,
    regionalPremium: 3.1, // Premium driven by deep mechanical supply chains in Rotherham/Sheffield
    nationalBenchmark: 179.44,
    description: "Double-row self-aligning spherical roller bearings for heavy rotational machinery and conveyors.",
  },
  {
    id: "pallets",
    name: "Standard EURO Wood Pallets",
    category: "products",
    unit: "GBP/100 units",
    price: 950.00,
    prevPrice: 962.00,
    dailyChange: -1.25,
    weeklyChange: -1.8,
    monthlyChange: -3.2,
    annualChange: -14.2,
    volatility: 6.8,
    percentile: 36,
    regionalPremium: -2.2,
    nationalBenchmark: 971.37,
    description: "Standard heat-treated ISPM15 European flat timber exchange pallets, heavily stocked in regional distribution nodes.",
  },
  {
    id: "lubricants",
    name: "Industrial Synthetic Gear Oil",
    category: "products",
    unit: "GBP/205L Drum",
    price: 640.00,
    prevPrice: 635.00,
    dailyChange: 0.79,
    weeklyChange: 1.2,
    monthlyChange: 2.5,
    annualChange: 11.8,
    volatility: 4.5,
    percentile: 78,
    regionalPremium: 1.5,
    nationalBenchmark: 630.54,
    description: "High-performance fully synthetic extreme pressure gear lubricant, manufactured at chemical plants in the Humber area.",
  },
];

export const SCENARIOS: Scenario[] = [
  {
    id: "baseline",
    name: "Baseline Yorkshire Economy",
    description: "Standard economic expansion. Local supply chain routes stable, stable energy baseloads, typical seasonal weather, inflation trending back to 2.0%.",
    constructionImpact: 1.0,
    metalsImpact: 1.0,
    energyImpact: 1.0,
    agricultureImpact: 1.0,
    productsImpact: 1.0,
    macroSentiment: "Stable",
    severity: "Minor",
  },
  {
    id: "trade_friction",
    name: "Tariff Shock & Port Friction",
    description: "Severe customs delays at Humber ports (Hull/Immingham). Iron ore and timber supplies squeezed. Export tariffs hitting manufacturing and agriculture.",
    constructionImpact: 1.18,
    metalsImpact: 1.32,
    energyImpact: 1.10,
    agricultureImpact: 0.85, // Agriculture export glut reduces domestic farmgate prices
    productsImpact: 1.25,
    macroSentiment: "Highly Volatile",
    severity: "Severe",
  },
  {
    id: "humber_flood",
    name: "Humber Estuary Flood Crisis",
    description: "Major flood surge breaches coastal barriers. Drax logistics crippled, Scunthorpe metallurgical furnaces disrupted, East Riding arable lands submerged.",
    constructionImpact: 1.25,
    metalsImpact: 1.45,
    energyImpact: 1.38,
    agricultureImpact: 1.40, // Local agricultural scarcity spikes potato/wheat pricing
    productsImpact: 1.15,
    macroSentiment: "Bearish",
    severity: "Extreme",
  },
  {
    id: "green_hydrogen_boom",
    name: "Green Hydrogen Investment Boom",
    description: "Rhino Bank joins private-public syndicate injecting £12B into the Humber Green Energy Grid. Industrial power, carbon-efficient brick, steel, and copper demands peak.",
    constructionImpact: 1.15,
    metalsImpact: 1.24,
    energyImpact: 1.45,
    agricultureImpact: 1.05,
    productsImpact: 1.28,
    macroSentiment: "Bullish",
    severity: "Moderate",
  },
  {
    id: "monetary_squeeze",
    name: "Aggressive Central Bank Tightening",
    description: "Interest rates increased by 250 bps to contain global structural inflation. Yorkshire housing starts collapse, heavy industry de-stocks, agricultural margins crushed.",
    constructionImpact: 0.78, // asset deflation
    metalsImpact: 0.82,
    energyImpact: 0.90,
    agricultureImpact: 0.95,
    productsImpact: 0.85,
    macroSentiment: "Bearish",
    severity: "Severe",
  },
];

// Helper to generate 24 months of synthetic historical prices based on commodity ID
export function generatePriceHistory(commodityId: string, scenarioId: string = "baseline"): { date: string; price: number }[] {
  const good = COMMODITIES.find((g) => g.id === commodityId);
  if (!good) return [];

  const basePrice = good.price;
  const history: { date: string; price: number }[] = [];
  const startYear = 2024;
  const startMonth = 7; // July 2024

  // Apply scenario multiplier
  const scenario = SCENARIOS.find((s) => s.id === scenarioId) || SCENARIOS[0];
  let multiplier = 1.0;
  if (good.category === "construction") multiplier = scenario.constructionImpact;
  else if (good.category === "metals") multiplier = scenario.metalsImpact;
  else if (good.category === "energy") multiplier = scenario.energyImpact;
  else if (good.category === "agriculture") multiplier = scenario.agricultureImpact;
  else if (good.category === "products") multiplier = scenario.productsImpact;

  for (let i = 24; i >= 0; i--) {
    let m = startMonth - i;
    let y = startYear;
    while (m <= 0) {
      m += 12;
      y -= 1;
    }
    const dateStr = `${y}-${String(m).padStart(2, "0")}`;
    
    // Add realistic seasonal fluctuations + subtle upward drift + noise
    const t = (24 - i) / 24; // time trend
    const season = Math.sin((m / 12) * 2 * Math.PI) * (good.volatility * 0.25); // seasonal swing
    const randomNoise = (Math.sin(i * 1.7) * 0.4 + Math.cos(i * 3.1) * 0.6) * (good.volatility * 0.15); // deterministic pseudorandom noise
    
    const historicalPrice = basePrice * multiplier * (1 - 0.05 * t + (season + randomNoise) / 100);
    history.push({
      date: dateStr,
      price: Math.max(0.1, Number(historicalPrice.toFixed(2))),
    });
  }

  return history;
}

// Generate Forecast Points based on historical prices and model type
export function generateForecast(
  history: { date: string; price: number }[],
  model: string,
  horizonMonths: number,
  commodityId: string
): ForecastPoint[] {
  const good = COMMODITIES.find((g) => g.id === commodityId);
  const volatility = good ? good.volatility : 10;
  const lastHistoryPoint = history[history.length - 1];
  const lastPrice = lastHistoryPoint.price;
  
  const forecastPoints: ForecastPoint[] = history.map((h) => ({
    date: h.date,
    historical: h.price,
  }));

  const lastDateParts = lastHistoryPoint.date.split("-");
  let year = parseInt(lastDateParts[0]);
  let month = parseInt(lastDateParts[1]);

  // Model-specific trend parameters
  let trendCoeff = 0.005; // 0.5% growth per month standard
  let modelNoiseMultiplier = 1.0;

  switch (model) {
    case "ARIMA":
      trendCoeff = 0.003;
      modelNoiseMultiplier = 0.8;
      break;
    case "ETS (Exponential Smoothing)":
      trendCoeff = 0.002;
      modelNoiseMultiplier = 0.75;
      break;
    case "VAR (Vector Autoregression)":
      trendCoeff = 0.006;
      modelNoiseMultiplier = 1.1;
      break;
    case "Random Forest":
      trendCoeff = 0.001;
      modelNoiseMultiplier = 0.95;
      break;
    case "XGBoost / Gradient Boosting":
      trendCoeff = 0.004;
      modelNoiseMultiplier = 0.9;
      break;
    default:
      trendCoeff = 0.003;
  }

  for (let i = 1; i <= horizonMonths; i++) {
    month += 1;
    if (month > 12) {
      month = 1;
      year += 1;
    }
    const dateStr = `${year}-${String(month).padStart(2, "0")}`;

    // Calculate forecast value with drift and seasonal continuation
    const seasonFactor = Math.sin((month / 12) * 2 * Math.PI) * (volatility * 0.15);
    const drift = lastPrice * (1 + trendCoeff * i);
    const forecastVal = drift * (1 + seasonFactor / 100);

    // Calculate error bands growing with time horizon
    const stdError = (volatility * 0.8 * Math.sqrt(i)) / 100 * forecastVal * modelNoiseMultiplier;
    
    const lower80 = Math.max(0, forecastVal - 1.28 * stdError);
    const upper80 = forecastVal + 1.28 * stdError;
    const lower95 = Math.max(0, forecastVal - 1.96 * stdError);
    const upper95 = forecastVal + 1.96 * stdError;

    forecastPoints.push({
      date: dateStr,
      forecast: Number(forecastVal.toFixed(2)),
      lower80: Number(lower80.toFixed(2)),
      upper80: Number(upper80.toFixed(2)),
      lower95: Number(lower95.toFixed(2)),
      upper95: Number(upper95.toFixed(2)),
    });
  }

  return forecastPoints;
}

// Recalculate RGPI value
export function calculateRGPI(weights: SectorWeight, scenarioId: string = "baseline", regionId: string = "all"): number {
  // Normalize weights
  const total = weights.construction + weights.metals + weights.energy + weights.agriculture + weights.products;
  const wConstruction = weights.construction / total;
  const wMetals = weights.metals / total;
  const wEnergy = weights.energy / total;
  const wAgriculture = weights.agriculture / total;
  const wProducts = weights.products / total;

  // Retrieve Active Scenario
  const scenario = SCENARIOS.find((s) => s.id === scenarioId) || SCENARIOS[0];

  // Base indices (100 in baseline)
  let constructionIdx = 100 * scenario.constructionImpact;
  let metalsIdx = 100 * scenario.metalsImpact;
  let energyIdx = 100 * scenario.energyImpact;
  let agricultureIdx = 100 * scenario.agricultureImpact;
  let productsIdx = 100 * scenario.productsImpact;

  // Region adjustment
  if (regionId !== "all") {
    const region = REGIONS.find((r) => r.id === regionId);
    if (region) {
      const adjustment = 1 + region.premiumAdjustment / 100;
      if (region.dominantSector.includes("Construction") || region.dominantSector.includes("Mining")) {
        constructionIdx *= (adjustment * 1.1);
      } else if (region.dominantSector.includes("Metals") || region.dominantSector.includes("Metallurgy")) {
        metalsIdx *= (adjustment * 1.15);
      } else if (region.dominantSector.includes("Energy")) {
        energyIdx *= (adjustment * 1.15);
      } else if (region.dominantSector.includes("Agricultural") || region.dominantSector.includes("Agribusiness")) {
        agricultureIdx *= (adjustment * 1.12);
      } else {
        productsIdx *= adjustment;
      }
    }
  }

  const composite = 
    constructionIdx * wConstruction +
    metalsIdx * wMetals +
    energyIdx * wEnergy +
    agricultureIdx * wAgriculture +
    productsIdx * wProducts;

  return Number(composite.toFixed(2));
}
