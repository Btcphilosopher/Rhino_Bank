import React, { useState, useMemo } from "react";
import {
  REGIONS,
  COMMODITIES,
  SCENARIOS,
  generatePriceHistory,
  generateForecast,
  calculateRGPI,
} from "./data/mockData";
import { CommodityGood, Scenario, SectorWeight } from "./types/pricing";
import YorkshireMap from "./components/YorkshireMap";
import CodeExplorer from "./components/CodeExplorer";
import ForecastChart from "./components/ForecastChart";
import SectorIndexRecalculator from "./components/SectorIndexRecalculator";
import ScenarioSimulator from "./components/ScenarioSimulator";
import GeminiRiskAdvisor from "./components/GeminiRiskAdvisor";
import {
  TrendingUp,
  Scale,
  Map,
  ShieldAlert,
  Sparkles,
  Code2,
  FileSpreadsheet,
  Download,
  Flame,
  Info,
  DollarSign,
  Heart,
} from "lucide-react";

export default function App() {
  // State variables for our economics platform
  const [selectedCategory, setSelectedCategory] = useState<string>("metals");
  const [selectedGoodId, setSelectedGoodId] = useState<string>("steel");
  const [selectedRegionId, setSelectedRegionId] = useState<string>("west_yorkshire");
  
  const [weights, setWeights] = useState<SectorWeight>({
    construction: 25.0,
    metals: 25.0,
    energy: 20.0,
    agriculture: 15.0,
    products: 15.0,
  });

  const [forecastModel, setForecastModel] = useState<string>("ARIMA");
  const [forecastHorizon, setForecastHorizon] = useState<number>(6);
  const [activeScenario, setActiveScenario] = useState<Scenario>(SCENARIOS[0]);
  const [activeTab, setActiveTab] = useState<string>("spot");

  // Helper selectors
  const activeGood = useMemo(() => {
    const rawGood = COMMODITIES.find((g) => g.id === selectedGoodId) || COMMODITIES[0];
    
    // Apply active scenario price multiplier
    let multiplier = 1.0;
    if (rawGood.category === "construction") multiplier = activeScenario.constructionImpact;
    else if (rawGood.category === "metals") multiplier = activeScenario.metalsImpact;
    else if (rawGood.category === "energy") multiplier = activeScenario.energyImpact;
    else if (rawGood.category === "agriculture") multiplier = activeScenario.agricultureImpact;
    else if (rawGood.category === "products") multiplier = activeScenario.productsImpact;

    return {
      ...rawGood,
      price: Number((rawGood.price * multiplier).toFixed(2)),
      prevPrice: Number((rawGood.prevPrice * multiplier).toFixed(2)),
    };
  }, [selectedGoodId, activeScenario]);

  const activeRegion = useMemo(() => {
    return REGIONS.find((r) => r.id === selectedRegionId) || REGIONS[0];
  }, [selectedRegionId]);

  // Dynamically calculate the active commodities database adjusted for scenario
  const scenarioCommodities = useMemo(() => {
    return COMMODITIES.map((g) => {
      let multiplier = 1.0;
      if (g.category === "construction") multiplier = activeScenario.constructionImpact;
      else if (g.category === "metals") multiplier = activeScenario.metalsImpact;
      else if (g.category === "energy") multiplier = activeScenario.energyImpact;
      else if (g.category === "agriculture") multiplier = activeScenario.agricultureImpact;
      else if (g.category === "products") multiplier = activeScenario.productsImpact;

      return {
        ...g,
        price: Number((g.price * multiplier).toFixed(2)),
        prevPrice: Number((g.prevPrice * multiplier).toFixed(2)),
      };
    });
  }, [activeScenario]);

  // Calculate prices based on active category
  const filteredCommodities = useMemo(() => {
    return scenarioCommodities.filter((c) => c.category === selectedCategory);
  }, [scenarioCommodities, selectedCategory]);

  // Compute live RGPI composite index based on active weights, scenario, and region choice
  const calculatedIndex = useMemo(() => {
    return calculateRGPI(weights, activeScenario.id, selectedRegionId);
  }, [weights, activeScenario, selectedRegionId]);

  // Generate historical prices for chart
  const historicalSeries = useMemo(() => {
    return generatePriceHistory(selectedGoodId, activeScenario.id);
  }, [selectedGoodId, activeScenario]);

  // Generate predictive forecasts for chart
  const forecastSeries = useMemo(() => {
    return generateForecast(historicalSeries, forecastModel, forecastHorizon, selectedGoodId);
  }, [historicalSeries, forecastModel, forecastHorizon, selectedGoodId]);

  // Map of regional premiums by region ID for selected good
  const regionalPremiumMap = useMemo(() => {
    const premiums: { [key: string]: number } = {};
    REGIONS.forEach((region) => {
      // Local premium is default commodity premium adjusted by county multiplier offsets
      premiums[region.id] = activeGood.regionalPremium + region.premiumAdjustment;
    });
    return premiums;
  }, [activeGood]);

  // Dynamic regional adjusted price for focus HUD
  const regionalAdjustedPrice = useMemo(() => {
    const premiumPercent = regionalPremiumMap[selectedRegionId] || 0;
    return Number((activeGood.price * (1 + premiumPercent / 100)).toFixed(2));
  }, [activeGood, selectedRegionId, regionalPremiumMap]);

  // Export commodity data sheet as standard CSV format
  const handleExportCSV = () => {
    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "Commodity ID,Commodity Name,Category,Unit,Current Spot (GBP),National Baseline,Regional Premium (%),Annual Change (%)\n";

    scenarioCommodities.forEach((item) => {
      csvContent += `"${item.id}","${item.name}","${item.category}","${item.unit}",${item.price},${item.nationalBenchmark},${item.regionalPremium},${item.annualChange}\n`;
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.href = encodedUri;
    link.setAttribute("download", `RhinoQuant_Yorkshire_SpotPricing_${activeScenario.id}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-[#050608] bg-[radial-gradient(circle_at_0%_0%,#1a1c24_0%,transparent_50%),radial-gradient(circle_at_100%_100%,#0c121e_0%,transparent_50%)] text-slate-100 flex flex-col justify-between font-sans antialiased selection:bg-teal-500/30 selection:text-teal-300">
      
      {/* Platform Header */}
      <header className="bg-black/20 backdrop-blur-md border-b border-white/5 py-3.5 px-4 md:px-8 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="bg-teal-500/10 border border-teal-500/30 p-2 rounded-xl">
            <Flame className="w-6 h-6 text-teal-400 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base font-bold tracking-tight text-white uppercase font-mono">
                RhinoQuant Yorkshire
              </h1>
              <span className="px-1.5 py-0.5 rounded text-[9px] font-mono font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20">
                Lending Core
              </span>
            </div>
            <p className="text-xs text-slate-500">
              Spot Pricing & Regional Goods Price Analytics Platform — Rhino Bank Group
            </p>
          </div>
        </div>

        {/* Global HUD metrics */}
        <div className="flex flex-wrap items-center gap-3 md:gap-5">
          <div className="bg-white/5 backdrop-blur-sm border border-white/10 px-3 py-1.5 rounded-lg flex flex-col text-right font-mono min-w-[90px]">
            <span className="text-[9px] text-slate-500 uppercase tracking-wider block">RGPI Composite</span>
            <span className="text-xs font-bold text-teal-400 mt-0.5">{calculatedIndex.toFixed(2)}</span>
          </div>

          <div className="bg-white/5 backdrop-blur-sm border border-white/10 px-3 py-1.5 rounded-lg flex flex-col text-right font-mono min-w-[90px]">
            <span className="text-[9px] text-slate-500 uppercase tracking-wider block">Active Scenario</span>
            <span className="text-xs font-bold text-rose-400 mt-0.5 line-clamp-1 max-w-[130px]" title={activeScenario.name}>
              {activeScenario.name.split(" ")[0]}
            </span>
          </div>

          <div className="bg-white/5 backdrop-blur-sm border border-white/10 px-3 py-1.5 rounded-lg flex flex-col text-right font-mono min-w-[90px]">
            <span className="text-[9px] text-slate-500 uppercase tracking-wider block">Server Node</span>
            <span className="text-xs font-bold text-emerald-400 mt-0.5 flex items-center gap-1 justify-end">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> Connected
            </span>
          </div>
        </div>
      </header>

      {/* Main Core Section */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 lg:p-8 space-y-6">
        
        {/* KPI Dashboard Ribbon */}
        <section id="kpi-ribbon" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          
          {/* Card 1 */}
          <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-4 flex flex-col justify-between shadow-lg shadow-black/20">
            <span className="text-[10px] font-mono uppercase tracking-wider text-slate-500 block mb-1">
              Active Focus Commodity
            </span>
            <div className="flex items-center justify-between mt-1">
              <div>
                <span className="text-base font-bold text-white block">{activeGood.name}</span>
                <span className="text-[11px] font-mono text-slate-400 block mt-0.5">
                  £{activeGood.price.toLocaleString()} {activeGood.unit}
                </span>
              </div>
              <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
                activeGood.dailyChange >= 0 
                  ? "bg-emerald-500/10 text-emerald-400" 
                  : "bg-rose-500/10 text-rose-400"
              }`}>
                {activeGood.dailyChange >= 0 ? "+" : ""}{activeGood.dailyChange.toFixed(2)}%
              </span>
            </div>
          </div>

          {/* Card 2 */}
          <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-4 flex flex-col justify-between shadow-lg shadow-black/20">
            <span className="text-[10px] font-mono uppercase tracking-wider text-slate-500 block mb-1">
              County Price Adjusted
            </span>
            <div className="flex items-center justify-between mt-1">
              <div>
                <span className="text-base font-bold text-white block">
                  £{regionalAdjustedPrice.toLocaleString()} {activeGood.unit.split("/")[1] || "tonne"}
                </span>
                <span className="text-[11px] font-mono text-slate-400 block mt-0.5">
                  Delivered in {activeRegion.name}
                </span>
              </div>
              <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
                (regionalPremiumMap[selectedRegionId] || 0) >= 0 
                  ? "bg-rose-500/10 text-rose-400" 
                  : "bg-emerald-500/10 text-emerald-400"
              }`}>
                {(regionalPremiumMap[selectedRegionId] || 0) >= 0 ? "+" : ""}
                {(regionalPremiumMap[selectedRegionId] || 0).toFixed(1)}% premium
              </span>
            </div>
          </div>

          {/* Card 3 */}
          <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-4 flex flex-col justify-between shadow-lg shadow-black/20">
            <span className="text-[10px] font-mono uppercase tracking-wider text-slate-500 block mb-1">
              Historical Volatility (252-day)
            </span>
            <div className="flex items-center justify-between mt-1">
              <div>
                <span className="text-base font-bold text-white block">
                  {activeGood.volatility.toFixed(1)}% Rolling Vol
                </span>
                <span className="text-[11px] font-mono text-slate-400 block mt-0.5">
                  Percentile: {activeGood.percentile}th (High)
                </span>
              </div>
              <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-400">
                Sigma: {activeGood.volatility > 10 ? "Elevated" : "Standard"}
              </span>
            </div>
          </div>

          {/* Card 4 */}
          <div className="bg-blue-500/5 backdrop-blur-sm border border-blue-500/20 rounded-xl p-4 flex flex-col justify-between shadow-lg shadow-black/20">
            <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block mb-1">
              Underwritten Portfolio Stress
            </span>
            <div className="flex items-center justify-between mt-1">
              <div>
                <span className="text-base font-bold text-white block">
                  {activeScenario.severity === "Extreme" ? "Severe Loss Delta" : "Adequate Capital"}
                </span>
                <span className="text-[11px] font-mono text-slate-400 block mt-0.5" title={activeScenario.description}>
                  RAG: {activeScenario.severity === "Extreme" || activeScenario.severity === "Severe" ? "Amber-Red" : "Green"}
                </span>
              </div>
              <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
                activeScenario.severity === "Extreme" || activeScenario.severity === "Severe"
                  ? "bg-rose-500/10 text-rose-400"
                  : "bg-emerald-500/10 text-emerald-400"
              }`}>
                {activeScenario.severity}
              </span>
            </div>
          </div>

        </section>

        {/* Dashboard Grid Workspace */}
        <section className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          
          {/* Left Navigation: Goods Catalogue Board */}
          <div className="lg:col-span-1 bg-black/40 backdrop-blur-xl border border-white/5 rounded-xl p-4 flex flex-col justify-between shadow-xl">
            <div>
              <div className="flex items-center justify-between border-b border-white/10 pb-2 mb-3">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Goods Catalogue
                </h3>
                <span className="px-2 py-0.5 rounded text-[9px] font-mono bg-white/5 border border-white/10 text-slate-300">
                  {COMMODITIES.length} Standardized
                </span>
              </div>

              {/* Category selector */}
              <div className="grid grid-cols-5 gap-1 mb-3">
                {(["metals", "construction", "energy", "agriculture", "products"] as const).map((cat) => (
                  <button
                    key={cat}
                    onClick={() => {
                      setSelectedCategory(cat);
                      // Auto-select first item in newly selected category
                      const firstInCat = COMMODITIES.find((c) => c.category === cat);
                      if (firstInCat) setSelectedGoodId(firstInCat.id);
                    }}
                    className={`px-1 py-1.5 text-[9px] font-bold rounded text-center uppercase tracking-wider transition-all border ${
                      selectedCategory === cat
                        ? "bg-teal-500/10 text-teal-400 border-teal-500/20 font-semibold"
                        : "hover:bg-white/5 border-transparent text-slate-500 hover:text-slate-300"
                    }`}
                  >
                    {cat.slice(0, 4)}
                  </button>
                ))}
              </div>

              {/* Commodities list under selected category */}
              <div className="space-y-1.5 max-h-[360px] overflow-y-auto pr-1">
                {filteredCommodities.map((item) => {
                  const isSelected = selectedGoodId === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => setSelectedGoodId(item.id)}
                      className={`w-full flex items-center justify-between p-2.5 rounded-lg text-left text-xs transition-all border ${
                        isSelected
                          ? "bg-teal-500/10 border-teal-500/20 text-teal-300"
                          : "hover:bg-white/5 border-transparent hover:border-white/10 text-slate-400 hover:text-slate-200"
                      }`}
                    >
                      <div className="flex flex-col">
                        <span className="font-semibold text-white truncate max-w-[120px]" title={item.name}>
                          {item.name}
                        </span>
                        <span className="text-[10px] text-slate-500 mt-0.5">
                          {item.unit}
                        </span>
                      </div>
                      <div className="text-right font-mono">
                        <div className="font-bold text-slate-300">£{item.price.toLocaleString()}</div>
                        <div className={`text-[10px] ${item.dailyChange >= 0 ? "text-emerald-400" : "text-rose-400"}`}>
                          {item.dailyChange >= 0 ? "+" : ""}{item.dailyChange.toFixed(1)}%
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Profile Overview Card for Selected Commodity */}
            <div className="mt-4 pt-4 border-t border-white/10 space-y-2">
              <div className="flex items-start gap-1.5 bg-white/[0.02] p-2.5 rounded border border-white/5">
                <Info className="w-4 h-4 text-teal-400 shrink-0 mt-0.5" />
                <div className="text-[10px] text-slate-400 leading-normal">
                  <span className="font-bold text-slate-300 block mb-0.5">Specifications:</span>
                  {activeGood.description}
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleExportCSV}
                  className="w-full flex items-center justify-center gap-1 bg-white/5 hover:bg-white/10 text-slate-200 py-1.5 rounded text-[10px] font-mono font-bold transition-all border border-white/10"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
                  Export Catalogue CSV
                </button>
              </div>
            </div>

          </div>

          {/* Right Workspace: Tabbed Dashboard Analytics */}
          <div className="lg:col-span-3 flex flex-col gap-5">
            
            {/* Modular Tab Navigation */}
            <div className="bg-black/40 backdrop-blur-xl border border-white/5 rounded-xl p-2 flex flex-wrap gap-1 shadow-lg">
              {[
                { id: "spot", label: "Spot & Forecasting", icon: TrendingUp },
                { id: "gis", label: "Yorkshire Spatial GIS", icon: Map },
                { id: "weights", label: "RGPI Index Weights", icon: Scale },
                { id: "stress", label: "Scenario Simulator", icon: ShieldAlert },
                { id: "ai", label: "AI Credit Advisor", icon: Sparkles },
                { id: "code", label: "Quantitative R Code", icon: Code2 },
              ].map((tab) => {
                const Icon = tab.icon;
                const isSelected = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-mono font-bold transition-all ${
                      isSelected
                        ? "bg-blue-600/20 border border-blue-500/50 text-blue-400 backdrop-blur-sm"
                        : "text-slate-400 hover:text-slate-200 hover:bg-white/5"
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    {tab.label}
                  </button>
                );
              })}
            </div>

            {/* Active Workspace Rendering */}
            <div className="transition-all duration-300">
              
              {/* Tab 1: Spot Pricing & Predictive Forecasting */}
              {activeTab === "spot" && (
                <ForecastChart
                  good={activeGood}
                  forecastData={forecastSeries}
                  model={forecastModel}
                  onSelectModel={setForecastModel}
                  horizon={forecastHorizon}
                  onSelectHorizon={setForecastHorizon}
                />
              )}

              {/* Tab 2: GIS Geographical Map */}
              {activeTab === "gis" && (
                <YorkshireMap
                  selectedRegionId={selectedRegionId}
                  onSelectRegion={setSelectedRegionId}
                  regionalPremiumMap={regionalPremiumMap}
                />
              )}

              {/* Tab 3: RGPI Calculator Custom Allocations */}
              {activeTab === "weights" && (
                <SectorIndexRecalculator
                  weights={weights}
                  onChangeWeights={setWeights}
                  calculatedIndex={calculatedIndex}
                />
              )}

              {/* Tab 4: Macro Scenario stress testing */}
              {activeTab === "stress" && (
                <ScenarioSimulator
                  activeScenario={activeScenario}
                  onSelectScenario={setActiveScenario}
                />
              )}

              {/* Tab 5: AI Credit Risk Advisory Memorandum */}
              {activeTab === "ai" && (
                <GeminiRiskAdvisor
                  selectedGood={activeGood}
                  selectedRegionName={activeRegion.name}
                  currentIndexValue={calculatedIndex}
                  forecastModel={forecastModel}
                  activeScenario={activeScenario}
                  weights={weights}
                />
              )}

              {/* Tab 6: Quantitative Code Explorer */}
              {activeTab === "code" && <CodeExplorer />}

            </div>

          </div>

        </section>

      </main>

      {/* Platform Footer */}
      <footer className="bg-black/40 backdrop-blur-md border-t border-white/5 py-4 px-4 md:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500 font-mono">
        <div className="flex items-center gap-1 text-[11px]">
          <span>© 2026 Rhino Bank Group Quantitative Research</span>
          <span className="text-slate-700">|</span>
          <span className="text-teal-500/80">Leeds Hub Node</span>
        </div>
        
        <div className="flex items-center gap-2 text-[10px]">
          <span className="flex items-center gap-1">
            <Heart className="w-3.5 h-3.5 text-rose-500/80 fill-current" />
            Made with Yorkshire Craftsmanship
          </span>
        </div>
      </footer>

    </div>
  );
}
