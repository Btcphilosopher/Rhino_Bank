import React, { useState, useEffect, useRef } from "react";
import { R_FILES } from "../data/rFiles";
import { RFile, TerminalLine } from "../types/pricing";
import { FileCode, Play, Terminal, CheckCircle2, ShieldAlert, Cpu, HardDrive } from "lucide-react";

export default function CodeExplorer() {
  const [selectedFile, setSelectedFile] = useState<RFile>(R_FILES[0]);
  const [terminalLines, setTerminalLines] = useState<TerminalLine[]>([
    {
      text: 'R version 4.4.1 (2024-06-14) -- "Race About Face"\nCopyright (C) 2024 The R Foundation for Statistical Computing\nPlatform: x86_64-pc-linux-gnu (64-bit)\n\nRhinoQuant Yorkshire Econometrics Pipeline loaded.',
      type: "system",
      timestamp: "04:57:14",
    },
  ]);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const terminalEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (terminalEndRef.current) {
      terminalEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [terminalLines]);

  const addTerminalLine = (text: string, type: "input" | "output" | "error" | "success" | "system") => {
    const timeStr = new Date().toLocaleTimeString();
    setTerminalLines((prev) => [...prev, { text, type, timestamp: timeStr }]);
  };

  const handleRunScript = () => {
    if (isRunning) return;
    setIsRunning(true);

    const isTest = selectedFile.name === "test_analytics.R";
    addTerminalLine(`source("${selectedFile.name}")`, "input");

    if (isTest) {
      setTimeout(() => {
        addTerminalLine("Executing unit test suite using testthat...", "system");
      }, 500);

      setTimeout(() => {
        addTerminalLine("✔ Context: RhinoQuant Analytical Calculations", "output");
        addTerminalLine("✔ Goods catalogue loads correct items and benchmarks (3.2ms)", "success");
      }, 1100);

      setTimeout(() => {
        addTerminalLine("✔ RGPI weight normalization is robust (1.4ms)", "success");
        addTerminalLine("✔ Forecast engine returns proper predictive bands (6.8ms)", "success");
      }, 1800);

      setTimeout(() => {
        addTerminalLine("All tests passed successfully! 3/3 tests matched baseline.", "success");
        setIsRunning(false);
      }, 2300);
    } else {
      setTimeout(() => {
        addTerminalLine(`Booting RhinoQuant pipeline from config in ${selectedFile.name}...`, "system");
      }, 400);

      setTimeout(() => {
        addTerminalLine("Loading packages: tidyverse, data.table, R6, forecast, xts, zoo", "output");
        addTerminalLine("GoodsCatalogue instance: Loaded 8 benchmark commodities.", "output");
      }, 1000);

      setTimeout(() => {
        addTerminalLine("Validation step: Cleansed 0 NA records. Outlier detector active.", "output");
        addTerminalLine("Computing Laspeyres pricing indices & regional momentum...", "output");
      }, 1600);

      setTimeout(() => {
        addTerminalLine("Auto-ARIMA fit: converged with minimum AIC/BIC indices.", "output");
        addTerminalLine("Scenario Stress Analysis: portfolio capital requirements projected.", "output");
      }, 2200);

      setTimeout(() => {
        addTerminalLine("Analytics pipeline execution complete! Completed in 45.2ms.", "success");
        setIsRunning(false);
      }, 2600);
    }
  };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
      {/* File Tree Panel */}
      <div className="xl:col-span-1 bg-white/5 backdrop-blur-md border border-white/10 rounded-xl p-4 flex flex-col justify-between shadow-lg shadow-black/20">
        <div>
          <div className="flex items-center gap-2 mb-4 border-b border-white/10 pb-2">
            <HardDrive className="w-4 h-4 text-teal-400" />
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">
              /RhinoSpotPricing Project
            </h3>
          </div>

          <div className="space-y-1 max-h-[350px] overflow-y-auto pr-1">
            {R_FILES.map((file) => (
              <button
                key={file.path}
                onClick={() => setSelectedFile(file)}
                className={`w-full flex items-start gap-2.5 px-3 py-2.5 rounded-lg text-left text-xs transition-all ${
                  selectedFile.path === file.path
                    ? "bg-teal-500/10 border border-teal-500/30 text-teal-300"
                    : "hover:bg-white/5 border border-transparent text-slate-400 hover:text-slate-200"
                }`}
              >
                <FileCode className={`w-4 h-4 mt-0.5 shrink-0 ${
                  selectedFile.path === file.path ? "text-teal-400" : "text-slate-500"
                }`} />
                <div>
                  <div className="font-semibold font-mono">{file.name}</div>
                  <div className="text-[10px] text-slate-500 mt-0.5 line-clamp-1">
                    {file.description}
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        <div className="mt-4 pt-4 border-t border-white/10 text-[11px] font-mono text-slate-500 flex flex-col gap-1.5">
          <div className="flex items-center justify-between">
            <span>R Engine Runtime:</span>
            <span className="text-emerald-400 font-bold flex items-center gap-1">
              <Cpu className="w-3.5 h-3.5" /> Stable
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span>Compiler Host:</span>
            <span>R v4.4.1 x86_64</span>
          </div>
        </div>
      </div>

      {/* Code Editor and Terminal */}
      <div className="xl:col-span-3 flex flex-col gap-4">
        {/* Editor Screen */}
        <div className="bg-black/30 border border-white/10 rounded-xl flex flex-col overflow-hidden backdrop-blur-sm shadow-lg shadow-black/20">
          {/* Header Bar */}
          <div className="bg-white/5 border-b border-white/10 px-4 py-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-rose-500/80"></span>
              <span className="w-3 h-3 rounded-full bg-amber-500/80"></span>
              <span className="w-3 h-3 rounded-full bg-emerald-500/80"></span>
              <span className="text-xs text-slate-400 font-mono ml-2 border-l border-white/10 pl-3">
                {selectedFile.path}
              </span>
            </div>

            <button
              onClick={handleRunScript}
              disabled={isRunning}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-mono font-bold transition-all ${
                isRunning
                  ? "bg-white/5 border border-white/10 text-slate-500 cursor-not-allowed"
                  : "bg-teal-500 text-[#090d16] hover:bg-teal-400 active:scale-95"
              }`}
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              {selectedFile.name.endsWith(".R") ? "Run R Script" : "Validate Config"}
            </button>
          </div>

          {/* Code Viewer Stage */}
          <div className="p-4 overflow-x-auto h-[320px] overflow-y-auto font-mono text-xs text-slate-300 relative">
            <pre className="grid grid-cols-[30px_1fr] gap-4">
              {/* Line numbers column */}
              <div className="text-slate-600 text-right select-none pr-1 border-r border-white/10">
                {selectedFile.code.split("\n").map((_, i) => (
                  <div key={i}>{i + 1}</div>
                ))}
              </div>
              {/* Actual Code with custom light highlighting */}
              <div className="whitespace-pre overflow-x-auto pr-4 text-slate-300">
                {selectedFile.code.split("\n").map((line, i) => {
                  let lineClass = "text-slate-300";
                  if (line.trim().startsWith("#")) {
                    lineClass = "text-slate-500 italic"; // comments
                  } else if (line.includes("library(") || line.includes("source(")) {
                    lineClass = "text-amber-400"; // imports
                  } else if (line.includes("function") || line.includes("R6Class")) {
                    lineClass = "text-teal-400 font-bold"; // function declarations
                  } else if (line.includes("test_that") || line.includes("expect_")) {
                    lineClass = "text-indigo-400"; // test logic
                  }
                  return (
                    <div key={i} className={`${lineClass} min-h-[16px]`}>
                      {line}
                    </div>
                  );
                })}
              </div>
            </pre>
          </div>
        </div>

        {/* Console Terminal */}
        <div className="bg-black/40 border border-white/10 rounded-xl overflow-hidden flex flex-col backdrop-blur-sm shadow-lg">
          <div className="bg-white/5 border-b border-white/10 px-4 py-2.5 flex items-center gap-2">
            <Terminal className="w-3.5 h-3.5 text-teal-400" />
            <span className="text-xs font-mono font-bold text-slate-300">R Console terminal</span>
          </div>

          <div className="p-4 h-[180px] overflow-y-auto font-mono text-[11px] space-y-2 select-text">
            {terminalLines.map((line, idx) => (
              <div key={idx} className="leading-5">
                {line.type === "input" && (
                  <span className="text-teal-400 font-bold">&gt; {line.text}</span>
                )}
                {line.type === "output" && (
                  <span className="text-slate-300">{line.text}</span>
                )}
                {line.type === "system" && (
                  <span className="text-slate-500 italic">{line.text}</span>
                )}
                {line.type === "success" && (
                  <span className="text-emerald-400 font-medium flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3 shrink-0 inline" /> {line.text}
                  </span>
                )}
                {line.type === "error" && (
                  <span className="text-rose-400 font-bold flex items-center gap-1">
                    <ShieldAlert className="w-3 h-3 shrink-0 inline" /> {line.text}
                  </span>
                )}
              </div>
            ))}
            <div ref={terminalEndRef} />
          </div>
        </div>
      </div>
    </div>
  );
}
