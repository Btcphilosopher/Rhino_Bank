import React, { useState } from "react";
import { SCENARIOS } from "../data/mockData";
import { Scenario } from "../types/pricing";
import { ShieldAlert, TrendingUp, Cpu, HardDrive, DollarSign, HelpCircle, AlertCircle } from "lucide-react";

interface ScenarioSimulatorProps {
  activeScenario: Scenario;
  onSelectScenario: (scenario: Scenario) => void;
  onCustomMultiplierAdjust?: (mults: { [key: string]: number }) => void;
}

export default function ScenarioSimulator({
  activeScenario,
  onSelectScenario,
}: ScenarioSimulatorProps) {
  // Custom stress testing sliders (User Levers)
  const [interestRateOffset, setInterestRateOffset] = useState<number>(0);
  const [fuelSurchargePct, setFuelSurchargePct] = useState<number>(0);
  const [portDelayDays, setPortDelayDays] = useState<number>(0);

  // Math to show simulated portfolios shifts
  const simulatedPDShift = activeScenario.id === "baseline" 
    ? (interestRateOffset * 0.4 + fuelSurchargePct * 0.15).toFixed(2)
    : (activeScenario.id === "humber_flood" ? 2.40 + interestRateOffset * 0.5 + fuelSurchargePct * 0.2
       : activeScenario.id === "monetary_squeeze" ? 4.10 + interestRateOffset * 0.8
       : activeScenario.id === "trade_friction" ? 1.85 + portDelayDays * 0.25 + fuelSurchargePct * 0.15
       : -1.20 + interestRateOffset * 0.2).toFixed(2);

  const capitalAdequacyImpact = activeScenario.id === "baseline"
    ? (-interestRateOffset * 0.08 - fuelSurchargePct * 0.02).toFixed(2)
    : (activeScenario.id === "humber_flood" ? -0.45 - interestRateOffset * 0.1 - fuelSurchargePct * 0.04
       : activeScenario.id === "monetary_squeeze" ? -0.80 - interestRateOffset * 0.18
       : activeScenario.id === "trade_friction" ? -0.30 - portDelayDays * 0.05
       : 0.15 - interestRateOffset * 0.05).toFixed(2);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
      {/* Scenario Picker Panel */}
      <div className="lg:col-span-3 bg-white/5 backdrop-blur-md border border-white/10 rounded-xl p-5 flex flex-col justify-between shadow-lg shadow-black/20">
        <div>
          <div className="flex items-center gap-2 border-b border-white/10 pb-3 mb-4">
            <ShieldAlert className="w-4 h-4 text-rose-400" />
            <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-400">
              Select Macro Stress Scenario
            </h3>
          </div>

          <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
            {SCENARIOS.map((scenario) => {
              const isActive = activeScenario.id === scenario.id;
              return (
                <button
                  key={scenario.id}
                  onClick={() => onSelectScenario(scenario)}
                  className={`w-full flex flex-col p-3 rounded-lg border text-left transition-all backdrop-blur-sm ${
                    isActive
                      ? "bg-rose-500/10 border-rose-500/50 text-rose-200"
                      : "bg-white/5 border-white/10 hover:border-white/20 hover:bg-white/10 text-slate-400"
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <span className="text-xs font-bold text-white">{scenario.name}</span>
                    <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded ${
                      scenario.severity === "Extreme" ? "bg-rose-500/20 text-rose-400 border border-rose-500/30" :
                      scenario.severity === "Severe" ? "bg-amber-500/20 text-amber-400 border border-amber-500/30" :
                      scenario.severity === "Moderate" ? "bg-sky-500/20 text-sky-400 border border-sky-500/30" :
                      "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                    }`}>
                      {scenario.severity}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1 leading-relaxed line-clamp-2">
                    {scenario.description}
                  </p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Custom levers section */}
        <div className="border-t border-white/10 pt-4 mt-4 space-y-3.5">
          <div className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">
            Custom Underwriter stress levers
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {/* Lever 1 */}
            <div className="space-y-1">
              <div className="flex justify-between text-[10px] font-mono">
                <span className="text-slate-400">Interest Rate Offset</span>
                <span className="text-teal-400 font-bold">{interestRateOffset >= 0 ? "+" : ""}{interestRateOffset}%</span>
              </div>
              <input
                type="range"
                min="-1"
                max="4"
                step="0.25"
                value={interestRateOffset}
                onChange={(e) => setInterestRateOffset(parseFloat(e.target.value))}
                className="w-full h-1 bg-white/10 rounded appearance-none cursor-pointer accent-teal-400 focus:outline-none"
              />
            </div>

            {/* Lever 2 */}
            <div className="space-y-1">
              <div className="flex justify-between text-[10px] font-mono">
                <span className="text-slate-400">Fuel Surcharge</span>
                <span className="text-teal-400 font-bold">+{fuelSurchargePct}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="30"
                step="2"
                value={fuelSurchargePct}
                onChange={(e) => setFuelSurchargePct(parseFloat(e.target.value))}
                className="w-full h-1 bg-white/10 rounded appearance-none cursor-pointer accent-teal-400 focus:outline-none"
              />
            </div>

            {/* Lever 3 */}
            <div className="space-y-1">
              <div className="flex justify-between text-[10px] font-mono">
                <span className="text-slate-400">Humber Port Delays</span>
                <span className="text-teal-400 font-bold">+{portDelayDays} days</span>
              </div>
              <input
                type="range"
                min="0"
                max="14"
                step="1"
                value={portDelayDays}
                onChange={(e) => setPortDelayDays(parseInt(e.target.value))}
                className="w-full h-1 bg-white/10 rounded appearance-none cursor-pointer accent-teal-400 focus:outline-none"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Stress impacts HUD */}
      <div className="lg:col-span-2 flex flex-col gap-4">
        {/* Scenario Details Panel */}
        <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-xl p-5 flex flex-col justify-between flex-1 shadow-lg shadow-black/20">
          <div>
            <div className="border-b border-white/10 pb-3 mb-3">
              <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider block mb-0.5">
                Stress Simulation Parameters
              </span>
              <h4 className="text-sm font-bold text-slate-200">
                {activeScenario.name}
              </h4>
            </div>

            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                <div className="bg-white/5 p-2 rounded border border-white/10">
                  <span className="text-slate-500 block text-[9px] uppercase">Macro Sentiment</span>
                  <span className={`font-bold block mt-0.5 ${
                    activeScenario.macroSentiment === "Bullish" ? "text-emerald-400" :
                    activeScenario.macroSentiment === "Stable" ? "text-slate-300" :
                    activeScenario.macroSentiment === "Highly Volatile" ? "text-amber-400" :
                    "text-rose-400"
                  }`}>
                    {activeScenario.macroSentiment}
                  </span>
                </div>
                <div className="bg-white/5 p-2 rounded border border-white/10">
                  <span className="text-slate-500 block text-[9px] uppercase">Risk Severity</span>
                  <span className="font-bold text-rose-400 block mt-0.5">
                    {activeScenario.severity}
                  </span>
                </div>
              </div>

              {/* Price Multipliers */}
              <div>
                <span className="text-[10px] font-mono text-slate-500 uppercase block tracking-wider mb-1.5">
                  Sector Stress Multipliers
                </span>
                <div className="grid grid-cols-5 gap-1 text-center font-mono text-[10px]">
                  <div className="bg-emerald-950/20 border border-emerald-500/25 p-1 rounded text-emerald-300">
                    <span className="block text-[8px] text-slate-500">Const</span>
                    <span className="font-bold">{activeScenario.constructionImpact}x</span>
                  </div>
                  <div className="bg-cyan-950/20 border border-cyan-500/25 p-1 rounded text-cyan-300">
                    <span className="block text-[8px] text-slate-500">Metl</span>
                    <span className="font-bold">{activeScenario.metalsImpact}x</span>
                  </div>
                  <div className="bg-indigo-950/20 border border-indigo-500/25 p-1 rounded text-indigo-300">
                    <span className="block text-[8px] text-slate-500">Engy</span>
                    <span className="font-bold">{activeScenario.energyImpact}x</span>
                  </div>
                  <div className="bg-blue-950/20 border border-blue-500/25 p-1 rounded text-blue-300">
                    <span className="block text-[8px] text-slate-500">Agri</span>
                    <span className="font-bold">{activeScenario.agricultureImpact}x</span>
                  </div>
                  <div className="bg-purple-950/20 border border-purple-500/25 p-1 rounded text-purple-300">
                    <span className="block text-[8px] text-slate-500">Prod</span>
                    <span className="font-bold">{activeScenario.productsImpact}x</span>
                  </div>
                </div>
              </div>

              {/* Portfolio Implied Delinquency Default Shifts */}
              <div className="border-t border-white/10 pt-3 space-y-2">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-slate-400 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5 text-rose-400" />
                    Portfolio PD Delta (implied):
                  </span>
                  <span className={`font-bold ${parseFloat(simulatedPDShift) >= 0 ? "text-rose-400" : "text-emerald-400"}`}>
                    {parseFloat(simulatedPDShift) >= 0 ? "+" : ""}
                    {simulatedPDShift} bps
                  </span>
                </div>

                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-slate-400 flex items-center gap-1">
                    <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
                    Capital Adequacy Ratio (CAR):
                  </span>
                  <span className={`font-bold ${parseFloat(capitalAdequacyImpact) >= 0 ? "text-emerald-400" : "text-rose-400"}`}>
                    {parseFloat(capitalAdequacyImpact) >= 0 ? "+" : ""}
                    {capitalAdequacyImpact}% delta
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="border-t border-white/10 pt-3 text-[9px] font-mono text-slate-500 leading-tight text-center">
            Under stress, portfolios rebalance dynamically based on Basel IV risk-weighted assets rules.
          </div>
        </div>
      </div>
    </div>
  );
}
