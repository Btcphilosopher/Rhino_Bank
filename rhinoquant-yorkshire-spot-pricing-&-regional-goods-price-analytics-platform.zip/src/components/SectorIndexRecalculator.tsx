import React, { useMemo } from "react";
import { SectorWeight } from "../types/pricing";
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip } from "recharts";
import { Scale, RefreshCw, BarChart3, AlertTriangle } from "lucide-react";

interface SectorIndexRecalculatorProps {
  weights: SectorWeight;
  onChangeWeights: (w: SectorWeight) => void;
  calculatedIndex: number;
}

const SECTOR_METADATA = [
  { id: "construction", name: "Construction Materials", color: "#10b981", desc: "Marine Aggregates, Limestone, Structural Clay, Cement, Timber." },
  { id: "metals", name: "Industrial Metals", color: "#06b6d4", desc: "Structural Steel, Foundry Pig Iron, Copper Cathodes, Extrusion Alloys." },
  { id: "energy", name: "Energy Products", color: "#6366f1", desc: "Industrial Grid Baseload, Natural Gas (NBP), Pilot Green Hydrogen, Biomass." },
  { id: "agriculture", name: "Agricultural Goods", color: "#3b82f6", desc: "Feed Wheat, Malt Barley, Ware Potatoes, Breeding Finished Cattle." },
  { id: "products", name: "Industrial Products", color: "#a855f7", desc: "Armoured Cabling, Spherical Roller Bearings, EURO Wood Pallets, Gear Oils." },
];

export default function SectorIndexRecalculator({
  weights,
  onChangeWeights,
  calculatedIndex,
}: SectorIndexRecalculatorProps) {
  // Construct Pie Data
  const chartData = useMemo(() => {
    return SECTOR_METADATA.map((sec) => ({
      name: sec.name,
      value: weights[sec.id as keyof SectorWeight],
      color: sec.color,
    }));
  }, [weights]);

  // Adjust a specific slider and re-proportion the rest so the sum remains exactly 100%
  const handleSliderChange = (sectorId: keyof SectorWeight, newValue: number) => {
    const sectors = Object.keys(weights) as (keyof SectorWeight)[];
    const otherSectors = sectors.filter((s) => s !== sectorId);
    
    // Sum of other sectors currently
    const otherSum = otherSectors.reduce((acc, s) => acc + weights[s], 0);
    const targetOtherSum = 100 - newValue;

    const newWeights = { ...weights };
    newWeights[sectorId] = newValue;

    if (otherSum > 0) {
      // Re-distribute remaining weight proportionally
      otherSectors.forEach((s) => {
        const proportion = weights[s] / otherSum;
        newWeights[s] = Math.round(proportion * targetOtherSum * 10) / 10;
      });
    } else {
      // If others were zero, divide remainder equally
      const equalShare = targetOtherSum / otherSectors.length;
      otherSectors.forEach((s) => {
        newWeights[s] = Math.round(equalShare * 10) / 10;
      });
    }

    // Micro-adjust to make sure the total is exactly 100
    const finalSum = Object.values(newWeights).reduce((a, b) => a + b, 0);
    const delta = 100 - finalSum;
    if (delta !== 0) {
      // Add drift to the first other sector
      newWeights[otherSectors[0]] = Math.round((newWeights[otherSectors[0]] + delta) * 10) / 10;
    }

    onChangeWeights(newWeights);
  };

  const handleResetWeights = () => {
    onChangeWeights({
      construction: 25.0,
      metals: 25.0,
      energy: 20.0,
      agriculture: 15.0,
      products: 15.0,
    });
  };

  const indexVariance = calculatedIndex - 100;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
      {/* Configuration Sliders */}
      <div className="lg:col-span-3 bg-white/5 backdrop-blur-md border border-white/10 rounded-xl p-5 flex flex-col justify-between shadow-lg shadow-black/20">
        <div>
          <div className="flex items-center justify-between border-b border-white/10 pb-3 mb-4">
            <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-2">
              <Scale className="w-4 h-4 text-teal-400" />
              Laspeyres Weight Calibration
            </h3>
            <button
              onClick={handleResetWeights}
              className="flex items-center gap-1 text-[11px] font-mono text-slate-400 hover:text-teal-400 border border-white/10 hover:border-teal-500/30 rounded px-2 py-0.5 bg-white/5 hover:bg-white/10 transition-colors"
            >
              <RefreshCw className="w-3 h-3" />
              Reset Baseline (Balanced)
            </button>
          </div>

          <p className="text-xs text-slate-500 mb-6 leading-relaxed">
            Adjust sector allocations to recalculate the composite price index. Modifying these allocations shifts index sensitivity toward specific regional infrastructure projects or supply chain dependencies.
          </p>

          <div className="space-y-4">
            {SECTOR_METADATA.map((sec) => {
              const currentVal = weights[sec.id as keyof SectorWeight];
              return (
                <div key={sec.id} className="space-y-1.5">
                  <div className="flex justify-between text-xs">
                    <span className="font-semibold text-slate-300 flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full" style={{ backgroundColor: sec.color }}></span>
                      {sec.name}
                    </span>
                    <span className="font-mono text-slate-400 font-bold">{currentVal.toFixed(1)}%</span>
                  </div>
                  <input
                    type="range"
                    min="5"
                    max="80"
                    step="0.5"
                    value={currentVal}
                    onChange={(e) => handleSliderChange(sec.id as keyof SectorWeight, parseFloat(e.target.value))}
                    className="w-full h-1 bg-white/10 rounded-lg appearance-none cursor-pointer accent-teal-400 focus:outline-none"
                  />
                  <span className="text-[10px] text-slate-500 block leading-tight">{sec.desc}</span>
                </div>
              );
            })}
          </div>
        </div>

        <div className="border-t border-white/10 pt-3.5 mt-4 text-[10px] text-slate-500 font-mono flex items-center gap-1.5">
          <BarChart3 className="w-3.5 h-3.5" />
          <span>Calculations run instantly using a server-validated econometrics pipeline.</span>
        </div>
      </div>

      {/* Visualizer and Live Output */}
      <div className="lg:col-span-2 flex flex-col gap-4">
        {/* Live Index Readout HUD */}
        <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-xl p-5 flex flex-col justify-between text-center relative overflow-hidden flex-1 shadow-lg shadow-black/20">
          {/* Subtle indicator background glow */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 bg-teal-500/5 rounded-full blur-3xl pointer-events-none" />

          <div>
            <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider block mb-1">
              Regional Goods Price Index (RGPI)
            </span>
            <div className="text-4xl font-extrabold font-mono tracking-tight text-white my-3">
              {calculatedIndex.toFixed(2)}
            </div>
            <div className="flex items-center justify-center gap-1.5 text-xs font-mono font-bold">
              <span className={`px-2 py-0.5 rounded ${
                indexVariance >= 0 
                  ? "bg-rose-500/10 text-rose-400 border border-rose-500/20" 
                  : "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
              }`}>
                {indexVariance >= 0 ? "+" : ""}
                {indexVariance.toFixed(2)}% vs. National Baseline
              </span>
            </div>
          </div>

          {/* Allocation Donut Chart */}
          <div className="h-[120px] w-full my-3 flex justify-center items-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={chartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={36}
                  outerRadius={50}
                  paddingAngle={3}
                  dataKey="value"
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: "rgba(10, 15, 28, 0.9)",
                    backdropFilter: "blur(8px)",
                    border: "1px solid rgba(255, 255, 255, 0.15)",
                    borderRadius: "8px",
                    fontFamily: "monospace",
                    fontSize: "10px",
                  }}
                  itemStyle={{ color: "#f1f5f9" }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="border-t border-white/10 pt-3 text-[10px] font-mono text-slate-400 flex items-center justify-center gap-1">
            <AlertTriangle className="w-3.5 h-3.5 text-slate-500" />
            <span>Base index calibrated at 100.00 (June 2024).</span>
          </div>
        </div>
      </div>
    </div>
  );
}
