import React, { useState, useEffect } from "react";
import { CommodityGood, Scenario, SectorWeight } from "../types/pricing";
import Markdown from "react-markdown";
import { Sparkles, Loader2, AlertCircle, RefreshCw, FileText, Download } from "lucide-react";

interface GeminiRiskAdvisorProps {
  selectedGood: CommodityGood;
  selectedRegionName: string;
  currentIndexValue: number;
  forecastModel: string;
  activeScenario: Scenario;
  weights: SectorWeight;
}

const LOADING_STEPS = [
  "Establishing secure connection to Rhino Bank Economic Core...",
  "Loading localized spot matrices for West Yorkshire and Humber...",
  "Retrieving industrial steel production statistics from Sheffield mills...",
  "Checking agricultural yield models from North Yorkshire agribusiness partners...",
  "Assessing green hydrogen energy storage benchmarks in Immingham terminals...",
  "Calculating portfolio Probability of Default (PD) deltas...",
  "Summoning Gemini AI Quantitative Risk Engine...",
];

export default function GeminiRiskAdvisor({
  selectedGood,
  selectedRegionName,
  currentIndexValue,
  forecastModel,
  activeScenario,
  weights,
}: GeminiRiskAdvisorProps) {
  const [commentary, setCommentary] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>("");
  const [loadingStepIdx, setLoadingStepIdx] = useState<number>(0);

  // Rotate loading messages for supreme realism
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (loading) {
      interval = setInterval(() => {
        setLoadingStepIdx((prev) => (prev + 1) % LOADING_STEPS.length);
      }, 2500);
    } else {
      setLoadingStepIdx(0);
    }
    return () => clearInterval(interval);
  }, [loading]);

  const generateAIBriefing = async () => {
    setLoading(true);
    setError("");
    setCommentary("");
    
    try {
      const response = await fetch("/api/gemini-commentary", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          selectedGood,
          selectedRegion: selectedRegionName,
          currentIndexValue,
          forecastModel,
          activeScenario,
          weights,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Failed to contact risk core server.");
      }

      setCommentary(data.commentary);
    } catch (err: any) {
      setError(err.message || "An unexpected network error occurred.");
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadMemo = () => {
    if (!commentary) return;
    const blob = new Blob([commentary], { type: "text/markdown;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", `RhinoBank_CommodityRiskMemo_${selectedGood.id}.md`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div id="gemini-risk-advisor-box" className="bg-white/5 backdrop-blur-md border border-white/10 rounded-xl p-5 flex flex-col justify-between shadow-lg shadow-black/20">
      <div>
        <div className="flex items-center justify-between border-b border-white/10 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-teal-400 animate-pulse" />
            <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-400">
              Rhino Bank AI Risk Advisory Node
            </h3>
          </div>
          <span className="text-[10px] font-mono bg-teal-500/10 text-teal-400 border border-teal-500/20 px-2 py-0.5 rounded">
            Gemini Pro Core
          </span>
        </div>

        <p className="text-xs text-slate-500 mb-5 leading-relaxed">
          Request an institutional-grade macro-lending and credit risk assessment memorandum compiled dynamically by our server-side LLM based on your active spot price configuration.
        </p>

        {/* Action Button */}
        {!commentary && !loading && !error && (
          <div className="flex flex-col items-center justify-center py-8 border border-dashed border-white/15 rounded-lg bg-black/20">
            <Sparkles className="w-10 h-10 text-slate-700 mb-3" />
            <span className="text-xs font-mono text-slate-400 mb-4 text-center px-4">
              State: Ready to draft advisory memorandum for <span className="text-teal-400">{selectedGood.name}</span> in <span className="text-teal-400">{selectedRegionName}</span> under scenario <span className="text-teal-400">"{activeScenario.name}"</span>.
            </span>
            <button
              onClick={generateAIBriefing}
              className="px-4 py-2 bg-teal-500 text-[#090d16] rounded-lg text-xs font-mono font-bold hover:bg-teal-400 transition-all flex items-center gap-1.5 active:scale-95 shadow-lg shadow-teal-500/10"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              Compile Advisory Memorandum
            </button>
          </div>
        )}

        {/* Loading HUD */}
        {loading && (
          <div className="flex flex-col items-center justify-center py-12">
            <Loader2 className="w-8 h-8 text-teal-400 animate-spin mb-4" />
            <span className="text-xs font-mono text-slate-300 font-semibold mb-2">
              Generating Credit Briefing...
            </span>
            <span className="text-[11px] font-mono text-slate-500 text-center px-6 animate-pulse max-w-[400px]">
              {LOADING_STEPS[loadingStepIdx]}
            </span>
          </div>
        )}

        {/* Error State */}
        {error && (
          <div className="p-4 bg-rose-500/10 border border-rose-500/30 rounded-lg text-xs text-rose-400 space-y-3">
            <div className="flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold block">Advisory Node Disrupted</span>
                <span className="leading-relaxed block mt-1">
                  {error}
                </span>
              </div>
            </div>
            <div className="flex items-center gap-2 pt-2 border-t border-rose-500/10">
              <button
                onClick={generateAIBriefing}
                className="px-3 py-1.5 bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 rounded font-mono text-[10px] transition-colors"
              >
                Retry Connection
              </button>
              <span className="text-[10px] text-rose-500 italic">
                *Ensure your GEMINI_API_KEY is configured in the secrets menu.
              </span>
            </div>
          </div>
        )}

        {/* Completed Memo Display */}
        {commentary && (
          <div className="border border-white/10 bg-black/40 rounded-xl overflow-hidden flex flex-col backdrop-blur-sm shadow-inner">
            {/* Memo Header */}
            <div className="bg-white/5 border-b border-white/10 px-4 py-3 flex items-center justify-between text-xs font-mono text-slate-400">
              <div className="flex items-center gap-1.5 text-teal-400">
                <FileText className="w-4 h-4" />
                MEMORANDUM | Rhino Bank Risk Committee
              </div>
              <button
                onClick={handleDownloadMemo}
                className="flex items-center gap-1 px-2.5 py-1 rounded bg-white/10 hover:bg-white/15 border border-white/10 text-[10px] text-slate-200 transition-colors"
              >
                <Download className="w-3 h-3" />
                Export MD
              </button>
            </div>

            {/* Memo Content */}
            <div className="p-5 font-sans text-xs text-slate-300 leading-relaxed max-h-[350px] overflow-y-auto select-text">
              <div className="border-b border-slate-800 pb-3 mb-4 space-y-1 font-mono text-[10px] text-slate-500">
                <div>TO: Commercial Lending Directorate & Regional Underwriters</div>
                <div>FROM: Chief Quantitative Economist & Commodity Risk Advisor</div>
                <div>DATE: {new Date().toLocaleDateString()}</div>
                <div>REGARDING: Structured Exposure & Spot Pricing Outlook — {selectedGood.name} ({selectedRegionName})</div>
              </div>

              {/* Markdown Content */}
              <div className="markdown-body prose prose-invert max-w-none text-slate-300 prose-xs prose-headings:text-teal-400 prose-headings:font-mono prose-headings:text-xs prose-headings:mt-4 prose-p:mb-3">
                <Markdown>{commentary}</Markdown>
              </div>
            </div>
          </div>
        )}
      </div>

      {commentary && (
        <div className="mt-4 pt-3.5 border-t border-white/10 flex items-center justify-between text-[10px] font-mono text-slate-500">
          <span>RAG Assessment: Active Analysis Node</span>
          <button
            onClick={generateAIBriefing}
            className="text-teal-500 hover:text-teal-400 hover:underline flex items-center gap-1"
          >
            <RefreshCw className="w-3 h-3" /> Re-Draft Memorandum
          </button>
        </div>
      )}
    </div>
  );
}
