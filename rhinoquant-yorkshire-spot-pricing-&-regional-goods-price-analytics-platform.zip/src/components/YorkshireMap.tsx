import React, { useState } from "react";
import { REGIONS } from "../data/mockData";
import { RegionMetric } from "../types/pricing";
import { Map, Pin, CheckCircle2, TrendingUp, HelpCircle } from "lucide-react";

interface YorkshireMapProps {
  selectedRegionId: string;
  onSelectRegion: (id: string) => void;
  regionalPremiumMap: { [key: string]: number }; // premium by region
}

export default function YorkshireMap({
  selectedRegionId,
  onSelectRegion,
  regionalPremiumMap,
}: YorkshireMapProps) {
  const [hoveredRegion, setHoveredRegion] = useState<RegionMetric | null>(null);

  // Clean SVG paths custom-drawn to form a premium, abstract map of Yorkshire
  const svgPaths = {
    north_yorkshire: {
      path: "M 100,50 L 250,30 L 320,80 L 280,160 L 190,170 L 110,130 Z",
      labelX: 180,
      labelY: 90,
      color: "fill-emerald-500/10 hover:fill-emerald-500/25 stroke-emerald-500/40",
      activeColor: "fill-emerald-500/30 stroke-emerald-400",
    },
    west_yorkshire: {
      path: "M 110,130 L 190,170 L 190,220 L 130,240 L 90,190 Z",
      labelX: 140,
      labelY: 185,
      color: "fill-teal-500/10 hover:fill-teal-500/25 stroke-teal-500/40",
      activeColor: "fill-teal-500/30 stroke-teal-400",
    },
    south_yorkshire: {
      path: "M 190,220 L 260,200 L 270,260 L 170,280 L 130,240 Z",
      labelX: 195,
      labelY: 245,
      color: "fill-cyan-500/10 hover:fill-cyan-500/25 stroke-cyan-500/40",
      activeColor: "fill-cyan-500/30 stroke-cyan-400",
    },
    east_riding: {
      path: "M 190,170 L 280,160 L 340,150 L 320,210 L 260,200 Z",
      labelX: 275,
      labelY: 180,
      color: "fill-sky-500/10 hover:fill-sky-500/25 stroke-sky-500/40",
      activeColor: "fill-sky-500/30 stroke-sky-400",
    },
    humber_region: {
      path: "M 260,200 L 320,210 L 350,230 L 310,270 L 270,260 Z",
      labelX: 300,
      labelY: 235,
      color: "fill-indigo-500/10 hover:fill-indigo-500/25 stroke-indigo-500/40",
      activeColor: "fill-indigo-500/30 stroke-indigo-400",
    },
  };

  const getRegionPremium = (id: string) => {
    return regionalPremiumMap[id] ?? 0;
  };

  const activeRegion = REGIONS.find((r) => r.id === selectedRegionId) || null;

  return (
    <div id="yorkshire-map-container" className="grid grid-cols-1 lg:grid-cols-5 gap-6">
      {/* Interactive Map Visualizer */}
      <div className="lg:col-span-3 bg-white/5 backdrop-blur-md border border-white/10 rounded-xl p-5 flex flex-col justify-between relative overflow-hidden shadow-lg shadow-black/20">
        <div className="absolute top-0 right-0 p-3 bg-teal-500/10 text-teal-400 text-xs rounded-bl-lg font-mono border-l border-b border-white/10 flex items-center gap-1.5">
          <Map className="w-3.5 h-3.5 animate-pulse" />
          Interactive GIS Grid
        </div>

        <div>
          <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-2 mb-2">
            Yorkshire & Humber Spatial Grid
          </h3>
          <p className="text-xs text-slate-500">
            Click on any sub-region to load regional spot premiums, localized industrial sectors, and lending exposures.
          </p>
        </div>

        {/* Map Stage */}
        <div className="my-6 flex justify-center items-center h-[300px]">
          <svg
            viewBox="0 0 400 300"
            className="w-full h-full max-w-[420px] transition-all duration-300 select-none"
          >
            {/* Background grids */}
            <g className="opacity-10 stroke-slate-500 stroke-[0.5]" strokeDasharray="3,3">
              <line x1="50" y1="0" x2="50" y2="300" />
              <line x1="100" y1="0" x2="100" y2="300" />
              <line x1="150" y1="0" x2="150" y2="300" />
              <line x1="200" y1="0" x2="200" y2="300" />
              <line x1="250" y1="0" x2="250" y2="300" />
              <line x1="300" y1="0" x2="300" y2="300" />
              <line x1="350" y1="0" x2="350" y2="300" />
              <line x1="0" y1="50" x2="400" y2="50" />
              <line x1="0" y1="100" x2="400" y2="100" />
              <line x1="0" y1="150" x2="400" y2="150" />
              <line x1="0" y1="200" x2="400" y2="200" />
              <line x1="0" y1="250" x2="400" y2="250" />
            </g>

            {/* Region Paths */}
            {REGIONS.map((region) => {
              const geom = svgPaths[region.id as keyof typeof svgPaths];
              if (!geom) return null;
              const isActive = selectedRegionId === region.id;
              const premium = getRegionPremium(region.id);

              return (
                <g key={region.id} className="cursor-pointer">
                  <path
                    d={geom.path}
                    className={`transition-all duration-300 stroke-2 ${
                      isActive ? geom.activeColor : geom.color
                    }`}
                    onClick={() => onSelectRegion(region.id)}
                    onMouseEnter={() => setHoveredRegion(region)}
                    onMouseLeave={() => setHoveredRegion(null)}
                  />
                  {/* Premium Tag Indicator in map */}
                  <g transform={`translate(${geom.labelX}, ${geom.labelY})`}>
                    <rect
                      x="-35"
                      y="-12"
                      width="70"
                      height="20"
                      rx="4"
                      className={`fill-black/80 border pointer-events-none transition-colors duration-200 ${
                        isActive ? "stroke-teal-500/60" : "stroke-white/10"
                      }`}
                    />
                    <text
                      textAnchor="middle"
                      y="2"
                      className="text-[9px] font-mono font-medium fill-slate-300 pointer-events-none"
                    >
                      {region.name.split(" ")[0]} {premium >= 0 ? "+" : ""}
                      {premium.toFixed(1)}%
                    </text>
                  </g>
                </g>
              );
            })}
          </svg>
        </div>

        {/* Legend */}
        <div className="flex items-center justify-between text-[10px] font-mono border-t border-white/10 pt-3 text-slate-400">
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded bg-emerald-500/20 border border-emerald-500/50"></span>
            North (Agri)
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded bg-teal-500/20 border border-teal-500/50"></span>
            West (Mfg)
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded bg-cyan-500/20 border border-cyan-500/50"></span>
            South (Metals)
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded bg-sky-500/20 border border-sky-500/50"></span>
            East (Agri)
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded bg-indigo-500/20 border border-indigo-500/50"></span>
            Humber (Energy)
          </span>
        </div>
      </div>

      {/* Information HUD */}
      <div className="lg:col-span-2 flex flex-col gap-4">
        {/* Active Region Details */}
        <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-xl p-5 flex-1 flex flex-col justify-between shadow-lg shadow-black/20">
          <div>
            <div className="flex items-center justify-between border-b border-white/10 pb-3 mb-3">
              <div className="flex items-center gap-2">
                <Pin className="w-4 h-4 text-teal-400" />
                <h4 className="text-base font-bold text-white">
                  {activeRegion ? activeRegion.name : "Yorkshire & Humber"}
                </h4>
              </div>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-teal-500/10 text-teal-400 border border-teal-500/20">
                GDP: {activeRegion ? `${activeRegion.gdpShare}%` : "100%"}
              </span>
            </div>

            {activeRegion ? (
              <div className="space-y-3.5">
                <div>
                  <span className="text-[10px] font-mono text-slate-500 uppercase block tracking-wider">
                    Dominant Economic Hub
                  </span>
                  <span className="text-xs font-medium text-slate-200">
                    {activeRegion.dominantSector}
                  </span>
                </div>

                <div>
                  <span className="text-[10px] font-mono text-slate-500 uppercase block tracking-wider">
                    Local Authorities Surveyed
                  </span>
                  <div className="flex flex-wrap gap-1.5 mt-1">
                    {activeRegion.localAuthorities.map((la) => (
                      <span
                        key={la}
                        className="px-2 py-0.5 rounded bg-white/5 text-[10px] text-slate-300 border border-white/10"
                      >
                        {la}
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <span className="text-[10px] font-mono text-slate-500 uppercase block tracking-wider">
                    Premium Offset vs. National
                  </span>
                  <span
                    className={`text-sm font-bold flex items-center gap-1 font-mono ${
                      activeRegion.premiumAdjustment >= 0
                        ? "text-rose-400"
                        : "text-emerald-400"
                    }`}
                  >
                    <TrendingUp className="w-3.5 h-3.5" />
                    {activeRegion.premiumAdjustment >= 0 ? "+" : ""}
                    {activeRegion.premiumAdjustment}% Base Offset
                  </span>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-6 text-slate-500 text-center">
                <HelpCircle className="w-8 h-8 text-slate-700 mb-2" />
                <p className="text-xs">No active region selected.</p>
              </div>
            )}
          </div>

          <div className="border-t border-white/10 pt-3 mt-4">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Lending Exposure Risk:</span>
              <span className="font-bold font-mono text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> Low-Moderate (RAG: Green)
              </span>
            </div>
          </div>
        </div>

        {/* Hover overlay micro hud */}
        <div className="bg-white/5 backdrop-blur border border-white/10 rounded-xl p-3 flex items-center justify-between text-xs font-mono text-slate-400 min-h-[50px] shadow-lg">
          <span>GIS Focal Point:</span>
          <span className="text-slate-200 font-bold">
            {hoveredRegion ? hoveredRegion.name : activeRegion ? activeRegion.name : "None"}
          </span>
        </div>
      </div>
    </div>
  );
}
