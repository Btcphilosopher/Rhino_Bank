// ============================================================================
// RHINO BANK | RHINOQUANT SYNTH-CDO
// Synthetic Reference Credit Portfolio Generator & Curated Institutional Assets
// ============================================================================

import { ReferenceAsset, SyntheticCDO, StressScenario, OracleFeed, OraclePriceFeed } from '../types';

// Curated Institutional Reference Assets
const SEED_COMPANIES: Array<{
  name: string;
  ticker: string;
  sector: ReferenceAsset['sector'];
  geography: ReferenceAsset['geography'];
  assetClass: ReferenceAsset['assetClass'];
  baseRating: ReferenceAsset['rating'];
  baseSpreadBps: number;
  basePd: number;
}> = [
  // Technology
  { name: 'ARM Holdings Plc', ticker: 'ARM.L', sector: 'Technology', geography: 'United Kingdom', assetClass: 'Corporate Bond', baseRating: 'AA', baseSpreadBps: 45, basePd: 0.003 },
  { name: 'ASML Holding NV', ticker: 'ASML.AS', sector: 'Technology', geography: 'European Union', assetClass: 'Corporate Bond', baseRating: 'AAA', baseSpreadBps: 32, basePd: 0.001 },
  { name: 'Sage Group Plc', ticker: 'SGE.L', sector: 'Technology', geography: 'United Kingdom', assetClass: 'Corporate Loan', baseRating: 'A', baseSpreadBps: 68, basePd: 0.007 },
  { name: 'Nvidia Corp Enterprise Notes', ticker: 'NVDA.US', sector: 'Technology', geography: 'United States', assetClass: 'Corporate Bond', baseRating: 'AAA', baseSpreadBps: 38, basePd: 0.002 },
  { name: 'SAP SE Cloud Infrastructure', ticker: 'SAP.DE', sector: 'Technology', geography: 'European Union', assetClass: 'Corporate Loan', baseRating: 'A', baseSpreadBps: 58, basePd: 0.006 },
  { name: 'Infineon Technologies', ticker: 'IFX.DE', sector: 'Technology', geography: 'European Union', assetClass: 'Corporate Bond', baseRating: 'BBB', baseSpreadBps: 110, basePd: 0.014 },
  
  // Financials & Prime Brokerage
  { name: 'Barclays Bank Plc', ticker: 'BARC.L', sector: 'Financials', geography: 'United Kingdom', assetClass: 'Corporate Bond', baseRating: 'A', baseSpreadBps: 85, basePd: 0.008 },
  { name: 'BNP Paribas SA', ticker: 'BNP.PA', sector: 'Financials', geography: 'European Union', assetClass: 'Corporate Bond', baseRating: 'AA', baseSpreadBps: 52, basePd: 0.004 },
  { name: 'UBS Group AG Tier 2', ticker: 'UBSG.SW', sector: 'Financials', geography: 'Switzerland', assetClass: 'Corporate Bond', baseRating: 'A', baseSpreadBps: 92, basePd: 0.009 },
  { name: 'London Stock Exchange Group', ticker: 'LSEG.L', sector: 'Financials', geography: 'United Kingdom', assetClass: 'Corporate Loan', baseRating: 'AA', baseSpreadBps: 48, basePd: 0.003 },
  { name: 'Prudential Plc Subordinated', ticker: 'PRU.L', sector: 'Financials', geography: 'United Kingdom', assetClass: 'Corporate Bond', baseRating: 'BBB', baseSpreadBps: 145, basePd: 0.018 },
  { name: 'Goldman Sachs International', ticker: 'GS.US', sector: 'Financials', geography: 'United States', assetClass: 'Corporate Loan', baseRating: 'A', baseSpreadBps: 78, basePd: 0.007 },

  // Energy & Utilities
  { name: 'BP Capital Markets Plc', ticker: 'BP.L', sector: 'Energy & Utilities', geography: 'United Kingdom', assetClass: 'Corporate Bond', baseRating: 'A', baseSpreadBps: 72, basePd: 0.007 },
  { name: 'Shell International Finance', ticker: 'SHEL.L', sector: 'Energy & Utilities', geography: 'United Kingdom', assetClass: 'Corporate Bond', baseRating: 'AA', baseSpreadBps: 44, basePd: 0.003 },
  { name: 'TotalEnergies SE', ticker: 'TTE.PA', sector: 'Energy & Utilities', geography: 'European Union', assetClass: 'Corporate Bond', baseRating: 'AA', baseSpreadBps: 46, basePd: 0.004 },
  { name: 'National Grid Electricity Tran.', ticker: 'NG.L', sector: 'Energy & Utilities', geography: 'United Kingdom', assetClass: 'Corporate Loan', baseRating: 'BBB', baseSpreadBps: 98, basePd: 0.012 },
  { name: 'Iberdrola Green Bond', ticker: 'IBE.MC', sector: 'Energy & Utilities', geography: 'European Union', assetClass: 'Corporate Bond', baseRating: 'A', baseSpreadBps: 64, basePd: 0.006 },
  { name: 'Glencore Finance Europe', ticker: 'GLEN.L', sector: 'Energy & Utilities', geography: 'Switzerland', assetClass: 'Corporate Loan', baseRating: 'BBB', baseSpreadBps: 135, basePd: 0.017 },

  // Healthcare
  { name: 'AstraZeneca Plc', ticker: 'AZN.L', sector: 'Healthcare', geography: 'United Kingdom', assetClass: 'Corporate Bond', baseRating: 'AA', baseSpreadBps: 40, basePd: 0.003 },
  { name: 'GSK Plc Senior Secured', ticker: 'GSK.L', sector: 'Healthcare', geography: 'United Kingdom', assetClass: 'Corporate Bond', baseRating: 'A', baseSpreadBps: 60, basePd: 0.006 },
  { name: 'Novartis AG International', ticker: 'NOVN.SW', sector: 'Healthcare', geography: 'Switzerland', assetClass: 'Corporate Bond', baseRating: 'AAA', baseSpreadBps: 30, basePd: 0.001 },
  { name: 'Sanofi SA Euro Bond', ticker: 'SAN.PA', sector: 'Healthcare', geography: 'European Union', assetClass: 'Corporate Bond', baseRating: 'AA', baseSpreadBps: 42, basePd: 0.003 },
  { name: 'Fresenius Medical Care', ticker: 'FME.DE', sector: 'Healthcare', geography: 'European Union', assetClass: 'Corporate Loan', baseRating: 'BBB', baseSpreadBps: 120, basePd: 0.015 },

  // Consumer & Retail
  { name: 'Unilever NV/Plc', ticker: 'ULVR.L', sector: 'Consumer & Retail', geography: 'United Kingdom', assetClass: 'Corporate Bond', baseRating: 'A', baseSpreadBps: 54, basePd: 0.005 },
  { name: 'Diageo Capital Plc', ticker: 'DGE.L', sector: 'Consumer & Retail', geography: 'United Kingdom', assetClass: 'Corporate Bond', baseRating: 'A', baseSpreadBps: 62, basePd: 0.006 },
  { name: 'LVMH Moet Hennessy', ticker: 'MC.PA', sector: 'Consumer & Retail', geography: 'European Union', assetClass: 'Corporate Bond', baseRating: 'AA', baseSpreadBps: 39, basePd: 0.003 },
  { name: 'Tesco Corporate Treasury', ticker: 'TSCO.L', sector: 'Consumer & Retail', geography: 'United Kingdom', assetClass: 'Corporate Loan', baseRating: 'BBB', baseSpreadBps: 105, basePd: 0.013 },
  { name: 'Nestlé Finance Intl', ticker: 'NESN.SW', sector: 'Consumer & Retail', geography: 'Switzerland', assetClass: 'Corporate Bond', baseRating: 'AAA', baseSpreadBps: 28, basePd: 0.001 },

  // Commercial Real Estate & RMBS
  { name: 'Canary Wharf Prime Properties', ticker: 'CW-CRE.L', sector: 'Commercial Real Estate', geography: 'United Kingdom', assetClass: 'Commercial Real Estate (CRE)', baseRating: 'BBB', baseSpreadBps: 180, basePd: 0.022 },
  { name: 'Frankfurt Logistic Hub RMBS', ticker: 'FRA-LOG.DE', sector: 'Commercial Real Estate', geography: 'European Union', assetClass: 'Commercial Real Estate (CRE)', baseRating: 'A', baseSpreadBps: 115, basePd: 0.013 },
  { name: 'British Land Secured Notes', ticker: 'BLND.L', sector: 'Commercial Real Estate', geography: 'United Kingdom', assetClass: 'Commercial Real Estate (CRE)', baseRating: 'BBB', baseSpreadBps: 160, basePd: 0.019 },
  { name: 'Unibail-Rodamco-Westfield', ticker: 'URW.PA', sector: 'Commercial Real Estate', geography: 'European Union', assetClass: 'Corporate Loan', baseRating: 'BBB', baseSpreadBps: 195, basePd: 0.025 },

  // Sovereign & Supranational
  { name: 'UK HM Treasury Gilt Index Ref', ticker: 'UKT-REF', sector: 'Sovereign & Supranational', geography: 'United Kingdom', assetClass: 'Sovereign Debt', baseRating: 'AA', baseSpreadBps: 18, basePd: 0.0008 },
  { name: 'German Bund Federal Sovereign Ref', ticker: 'DBR-REF', sector: 'Sovereign & Supranational', geography: 'European Union', assetClass: 'Sovereign Debt', baseRating: 'AAA', baseSpreadBps: 12, basePd: 0.0004 },
  { name: 'European Investment Bank (EIB)', ticker: 'EIB.EU', sector: 'Sovereign & Supranational', geography: 'European Union', assetClass: 'Sovereign Debt', baseRating: 'AAA', baseSpreadBps: 15, basePd: 0.0005 },

  // Digital Asset & DeFi Prime (Institutional, Regulated Collateralized)
  { name: 'Aave Prime Institutional Vault 01', ticker: 'AAVE-INST-01', sector: 'Digital Asset & DeFi Prime', geography: 'Global / Decentralized', assetClass: 'Institutional DeFi Lending', baseRating: 'BBB', baseSpreadBps: 220, basePd: 0.024 },
  { name: 'Morpho Blue BTC-Secured Vault', ticker: 'MB-BTC-VLT', sector: 'Digital Asset & DeFi Prime', geography: 'Global / Decentralized', assetClass: 'Institutional DeFi Lending', baseRating: 'A', baseSpreadBps: 175, basePd: 0.018 },
  { name: 'FalconX Prime Institutional Credit Line', ticker: 'FLCX-CRE-09', sector: 'Digital Asset & DeFi Prime', geography: 'United States', assetClass: 'Corporate Loan', baseRating: 'BBB', baseSpreadBps: 240, basePd: 0.026 },
  { name: 'Wintermute Liquidity Provision Line', ticker: 'WNT-LQ-12', sector: 'Digital Asset & DeFi Prime', geography: 'United Kingdom', assetClass: 'Corporate Loan', baseRating: 'BBB', baseSpreadBps: 210, basePd: 0.022 },
  { name: 'Coinbase Custodial Yield Note', ticker: 'COIN-CYN', sector: 'Digital Asset & DeFi Prime', geography: 'United States', assetClass: 'Corporate Bond', baseRating: 'BBB', baseSpreadBps: 190, basePd: 0.020 }
];

// Generate 1,000+ realistic synthetic reference assets
export function generateSyntheticReferencePortfolio(targetCount = 1000, seedNotional = 1000000000): ReferenceAsset[] {
  const assets: ReferenceAsset[] = [];
  const seedLen = SEED_COMPANIES.length;

  for (let i = 0; i < targetCount; i++) {
    const seed = SEED_COMPANIES[i % seedLen];
    const isExactSeed = i < seedLen;
    
    // Slight randomization for synthetic expansion
    const id = `REF-${String(i + 1).padStart(5, '0')}`;
    const nameSuffix = isExactSeed ? '' : ` Series ${Math.floor(i / seedLen) + 1} (${seed.assetClass})`;
    const name = `${seed.name}${nameSuffix}`;
    const ticker = isExactSeed ? seed.ticker : `${seed.ticker.split('.')[0]}-S${Math.floor(i / seedLen) + 1}`;
    
    // Rating variations for realistic dispersion
    let rating = seed.baseRating;
    if (!isExactSeed) {
      const rand = Math.sin(i * 997.3) * 0.5 + 0.5;
      if (rand < 0.08) rating = 'AAA';
      else if (rand < 0.25) rating = 'AA';
      else if (rand < 0.55) rating = 'A';
      else if (rand < 0.85) rating = 'BBB';
      else if (rand < 0.95) rating = 'BB';
      else rating = 'B';
    }

    // Spread and PD tied to rating
    let pd = seed.basePd;
    let spreadBps = seed.baseSpreadBps;
    switch (rating) {
      case 'AAA': pd = 0.0005 + (i % 5) * 0.0001; spreadBps = 25 + (i % 15); break;
      case 'AA':  pd = 0.0025 + (i % 10) * 0.0002; spreadBps = 48 + (i % 25); break;
      case 'A':   pd = 0.0065 + (i % 15) * 0.0003; spreadBps = 75 + (i % 35); break;
      case 'BBB': pd = 0.0140 + (i % 20) * 0.0005; spreadBps = 140 + (i % 60); break;
      case 'BB':  pd = 0.0380 + (i % 25) * 0.0010; spreadBps = 290 + (i % 110); break;
      case 'B':   pd = 0.0750 + (i % 30) * 0.0020; spreadBps = 490 + (i % 180); break;
      case 'CCC': pd = 0.1600; spreadBps = 850; break;
      case 'D':   pd = 1.0000; spreadBps = 2500; break;
    }

    // LGD: Corporate typically 60% (recovery 40%), Sovereign 20% (recovery 80%), CRE 50%
    let lgd = 0.60;
    if (seed.assetClass === 'Sovereign Debt') lgd = 0.25;
    else if (seed.assetClass === 'Commercial Real Estate (CRE)') lgd = 0.50;
    else if (seed.assetClass === 'Institutional DeFi Lending') lgd = 0.45; // Overcollateralized protocol mitigates
    else lgd = 0.55 + ((i % 10) * 0.01);

    const recovery = 1 - lgd;
    
    // Correlation factor to systematic factor (typically 0.25 to 0.45)
    const correlationBeta = 0.22 + ((i % 25) * 0.01);

    // Uniform or lognormal notional allocation summing roughly to target
    const avgNotional = seedNotional / targetCount;
    const notionalVariation = 0.6 + ((i % 9) * 0.1); // 0.6x to 1.4x average
    const notional = Math.round(avgNotional * notionalVariation);

    assets.push({
      id,
      name,
      ticker,
      assetClass: seed.assetClass,
      rating,
      sector: seed.sector,
      geography: seed.geography,
      notional,
      spreadBps: Math.round(spreadBps),
      pd: Number(pd.toFixed(5)),
      lgd: Number(lgd.toFixed(4)),
      recovery: Number(recovery.toFixed(4)),
      correlationBeta: Number(correlationBeta.toFixed(4)),
      maturityYears: 3 + (i % 5) // 3 to 7 years
    });
  }

  return assets;
}

// Generate Default CDO Deals
export function getInitialDemoCDOs(): SyntheticCDO[] {
  const notional1 = 1000000000; // £1 Billion GBP
  
  return [
    {
      id: 'CDO-RHINO-001',
      dealCode: 'RHINO-SYNTH-I (UK/EU CREDIT)',
      name: 'RhinoQuant Global Investment Grade & Sub-Sovereign Synth-CDO I',
      currency: 'GBP',
      status: 'Active',
      totalNotional: notional1,
      maturityYears: 5,
      effectiveDate: '2026-03-01',
      maturityDate: '2031-03-01',
      portfolioId: 'PORT-GLOBAL-IG-1000',
      portfolioName: 'Global High-Grade 1,000 Reference Credit Index',
      assetCount: 1000,
      avgRating: 'A',
      weightedAvgSpreadBps: 88,
      weightedAvgPd: 0.0094,
      weightedAvgLgd: 0.575,
      portfolioExpectedLossUsd: 5405000,
      portfolioExpectedLossPct: 0.0054,
      systematicCorrelation: 0.30,
      correlationModel: 'Gaussian_Copula_1Factor',
      tranches: [
        {
          id: 'TR-001-EQ',
          cdoId: 'CDO-RHINO-001',
          type: 'EQUITY',
          name: 'Equity Tranche (First Loss 0–3%)',
          attachmentPct: 0.00,
          detachmentPct: 0.03,
          notional: 30000000, // £30M
          couponBps: 1850, // 18.50% coupon / spread
          expectedLossPct: 0.142,
          expectedReturnPct: 0.178,
          spreadBps: 1850,
          duration: 2.1,
          var99: 18500000,
          cvar99: 24200000,
          dv01: 6300,
          cs01: 15400,
          lossProbability: 0.284,
          tokenSymbol: 'RHINO-CDO1-EQ',
          tokenContractAddress: '0x71C...b901',
          totalSupply: 30000000,
          currentNav: 1.024,
          tokenHoldersCount: 4,
          investorEligibility: ['Rhino Quant Prop Desk', 'QIB Institutional Hedge Funds']
        },
        {
          id: 'TR-001-JR',
          cdoId: 'CDO-RHINO-001',
          type: 'JUNIOR',
          name: 'Junior Tranche (3–7%)',
          attachmentPct: 0.03,
          detachmentPct: 0.07,
          notional: 40000000, // £40M
          couponBps: 680, // 6.80% spread
          expectedLossPct: 0.028,
          expectedReturnPct: 0.074,
          spreadBps: 680,
          duration: 3.4,
          var99: 12400000,
          cvar99: 17800000,
          dv01: 13600,
          cs01: 27200,
          lossProbability: 0.082,
          tokenSymbol: 'RHINO-CDO1-JR',
          tokenContractAddress: '0x84D...c812',
          totalSupply: 40000000,
          currentNav: 1.008,
          tokenHoldersCount: 9,
          investorEligibility: ['Qualified Institutional Buyers', 'Tier-1 Asset Managers']
        },
        {
          id: 'TR-001-MZ',
          cdoId: 'CDO-RHINO-001',
          type: 'MEZZANINE',
          name: 'Mezzanine Tranche (7–15%)',
          attachmentPct: 0.07,
          detachmentPct: 0.15,
          notional: 80000000, // £80M
          couponBps: 310, // 3.10% spread
          expectedLossPct: 0.0042,
          expectedReturnPct: 0.048,
          spreadBps: 310,
          duration: 4.2,
          var99: 8200000,
          cvar99: 12500000,
          dv01: 33600,
          cs01: 67200,
          lossProbability: 0.016,
          tokenSymbol: 'RHINO-CDO1-MZ',
          tokenContractAddress: '0x99F...a434',
          totalSupply: 80000000,
          currentNav: 1.002,
          tokenHoldersCount: 16,
          investorEligibility: ['Global Pension Funds', 'Family Offices', 'Insurers']
        },
        {
          id: 'TR-001-SR',
          cdoId: 'CDO-RHINO-001',
          type: 'SENIOR',
          name: 'Super Senior Tranche (15–100%)',
          attachmentPct: 0.15,
          detachmentPct: 1.00,
          notional: 850000000, // £850M
          couponBps: 92, // 0.92% spread over SONIA
          expectedLossPct: 0.0001,
          expectedReturnPct: 0.0195,
          spreadBps: 92,
          duration: 4.8,
          var99: 1500000,
          cvar99: 2800000,
          dv01: 408000,
          cs01: 816000,
          lossProbability: 0.0004,
          tokenSymbol: 'RHINO-CDO1-SR',
          tokenContractAddress: '0xAA1...e770',
          totalSupply: 850000000,
          currentNav: 1.000,
          tokenHoldersCount: 28,
          investorEligibility: ['Central Banks', 'Sovereign Wealth Funds', 'Tier-1 Banks']
        }
      ],
      collateral: {
        btcQty: 1000,
        btcPriceUsd: 96450,
        btcHaircutPct: 0.25, // 25% Haircut
        btcVolatilityAnnual: 0.52,
        usdtQty: 25000000,
        usdtPriceUsd: 1.0001,
        usdtHaircutPct: 0.05, // 5% Haircut
        usdtLiquidityScore: 98,
        fiatCash: 15000000,
        grossCollateralUsd: 136450000, // (1000*96450) + 25M + 15M = $136.45M
        eligibleCollateralUsd: 111087500, // (96.45M * 0.75) + (25M * 0.95) + 15M = $111.0875M
        requiredInitialMarginUsd: 55000000,
        requiredVariationMarginUsd: 4200000,
        requiredMaintenanceMarginUsd: 45000000,
        collateralRatio: 1.876, // 187.6% (Safe)
        marginStatus: 'SAFE',
        marginBufferUsd: 51887500,
        liquidationDistancePct: 0.468, // BTC can drop ~47% before margin call
        lastValuationTimestamp: new Date().toISOString()
      },
      protectionPremiumIncomeAnnual: 8800000,
      collateralReinvestmentYieldAnnual: 4850000,
      trancheCouponObligationsAnnual: 11520000,
      rhinoStructuringFeeBps: 45, // £4.5M upfront
      rhinoManagementFeeBps: 20, // £2.0M / year
      netCashFlowAnnual: 2130000,
      jurisdiction: 'UK_FCA',
      investorClass: 'Eligible_Counterparty',
      multiSigRequired: 3,
      multiSigCurrent: 3,
      sanctionsCheckPassed: true,
      kycRequiredLevel: 'TIER_3_INSTITUTIONAL',
      createdAt: '2026-02-15',
      lastUpdated: '2026-08-25T07:45:00Z'
    },
    {
      id: 'CDO-RHINO-002',
      dealCode: 'RHINO-DEFI-PRIME-II ($500M)',
      name: 'RhinoQuant Institutional DeFi & Digital Infrastructure Synthetic CDO',
      currency: 'USD',
      status: 'Approved',
      totalNotional: 500000000,
      maturityYears: 3,
      effectiveDate: '2026-04-01',
      maturityDate: '2029-04-01',
      portfolioId: 'PORT-DEFI-PRIME-500',
      portfolioName: 'DeFi Overcollateralized Lending & Institutional Staking Notes',
      assetCount: 450,
      avgRating: 'BBB',
      weightedAvgSpreadBps: 215,
      weightedAvgPd: 0.0215,
      weightedAvgLgd: 0.48,
      portfolioExpectedLossUsd: 5160000,
      portfolioExpectedLossPct: 0.0103,
      systematicCorrelation: 0.42,
      correlationModel: 'Gaussian_Copula_1Factor',
      tranches: [
        {
          id: 'TR-002-EQ',
          cdoId: 'CDO-RHINO-002',
          type: 'EQUITY',
          name: 'Equity Tranche (0–5%)',
          attachmentPct: 0.00,
          detachmentPct: 0.05,
          notional: 25000000,
          couponBps: 2450,
          expectedLossPct: 0.185,
          expectedReturnPct: 0.224,
          spreadBps: 2450,
          duration: 1.8,
          var99: 16500000,
          cvar99: 21400000,
          dv01: 4500,
          cs01: 11200,
          lossProbability: 0.36,
          tokenSymbol: 'RHINO-CDO2-EQ',
          tokenContractAddress: '0xCC4...1890',
          totalSupply: 25000000,
          currentNav: 1.000,
          tokenHoldersCount: 2,
          investorEligibility: ['Rhino Quant Desk']
        },
        {
          id: 'TR-002-JR',
          cdoId: 'CDO-RHINO-002',
          type: 'JUNIOR',
          name: 'Junior Tranche (5–12%)',
          attachmentPct: 0.05,
          detachmentPct: 0.12,
          notional: 35000000,
          couponBps: 940,
          expectedLossPct: 0.045,
          expectedReturnPct: 0.098,
          spreadBps: 940,
          duration: 2.4,
          var99: 14200000,
          cvar99: 19800000,
          dv01: 8400,
          cs01: 21000,
          lossProbability: 0.12,
          tokenSymbol: 'RHINO-CDO2-JR',
          tokenContractAddress: '0xDD8...9011',
          totalSupply: 35000000,
          currentNav: 1.000,
          tokenHoldersCount: 5,
          investorEligibility: ['Institutional Crypto Funds']
        },
        {
          id: 'TR-002-MZ',
          cdoId: 'CDO-RHINO-002',
          type: 'MEZZANINE',
          name: 'Mezzanine Tranche (12–25%)',
          attachmentPct: 0.12,
          detachmentPct: 0.25,
          notional: 65000000,
          couponBps: 450,
          expectedLossPct: 0.009,
          expectedReturnPct: 0.056,
          spreadBps: 450,
          duration: 2.7,
          var99: 9800000,
          cvar99: 14500000,
          dv01: 17500,
          cs01: 43800,
          lossProbability: 0.03,
          tokenSymbol: 'RHINO-CDO2-MZ',
          tokenContractAddress: '0xEE3...4412',
          totalSupply: 65000000,
          currentNav: 1.000,
          tokenHoldersCount: 11,
          investorEligibility: ['Tier-1 Asset Managers']
        },
        {
          id: 'TR-002-SR',
          cdoId: 'CDO-RHINO-002',
          type: 'SENIOR',
          name: 'Senior Tranche (25–100%)',
          attachmentPct: 0.25,
          detachmentPct: 1.00,
          notional: 375000000,
          couponBps: 160,
          expectedLossPct: 0.0003,
          expectedReturnPct: 0.024,
          spreadBps: 160,
          duration: 2.9,
          var99: 2500000,
          cvar99: 4200000,
          dv01: 108750,
          cs01: 271875,
          lossProbability: 0.001,
          tokenSymbol: 'RHINO-CDO2-SR',
          tokenContractAddress: '0xFF2...7710',
          totalSupply: 375000000,
          currentNav: 1.000,
          tokenHoldersCount: 19,
          investorEligibility: ['Global Banks', 'Insurers']
        }
      ],
      collateral: {
        btcQty: 600,
        btcPriceUsd: 96450,
        btcHaircutPct: 0.25,
        btcVolatilityAnnual: 0.55,
        usdtQty: 40000000,
        usdtPriceUsd: 1.0001,
        usdtHaircutPct: 0.05,
        usdtLiquidityScore: 97,
        fiatCash: 10000000,
        grossCollateralUsd: 107870000,
        eligibleCollateralUsd: 91402500,
        requiredInitialMarginUsd: 42000000,
        requiredVariationMarginUsd: 1800000,
        requiredMaintenanceMarginUsd: 34000000,
        collateralRatio: 2.086,
        marginStatus: 'SAFE',
        marginBufferUsd: 47602500,
        liquidationDistancePct: 0.521,
        lastValuationTimestamp: new Date().toISOString()
      },
      protectionPremiumIncomeAnnual: 10750000,
      collateralReinvestmentYieldAnnual: 4100000,
      trancheCouponObligationsAnnual: 11990000,
      rhinoStructuringFeeBps: 60,
      rhinoManagementFeeBps: 25,
      netCashFlowAnnual: 2860000,
      jurisdiction: 'ADGM_FSRA',
      investorClass: 'Institutional_DeFi',
      multiSigRequired: 3,
      multiSigCurrent: 3,
      sanctionsCheckPassed: true,
      kycRequiredLevel: 'TIER_3_INSTITUTIONAL',
      createdAt: '2026-03-01',
      lastUpdated: '2026-08-25T08:12:00Z'
    }
  ];
}

// Curated Institutional Stress Scenarios
export const PRESET_STRESS_SCENARIOS: StressScenario[] = [
  {
    id: 'SCEN-2008-SUBPRIME',
    name: '2008-Style Global Credit Crisis',
    category: 'HISTORICAL',
    description: 'Systemic corporate credit crunch, correlated default surge across financials & CRE, recovery rates plummet to historical troughs.',
    btcPriceChangePct: -45,
    btcHaircutShiftPct: 15,
    usdtPriceChangePct: -1.5,
    usdtHaircutShiftPct: 10,
    creditDefaultMultiplier: 3.8,
    recoveryRateHaircutPct: -40,
    correlationShiftPct: 45,
    interestRateShiftBps: -250
  },
  {
    id: 'SCEN-COVID-SHOCK',
    name: 'March 2020 Liquidity Seize & Pandemic Shock',
    category: 'HISTORICAL',
    description: 'Acute cross-asset dash for cash, extreme basis widening, short-term crypto liquidity dislocation and sudden rating downgrades.',
    btcPriceChangePct: -50,
    btcHaircutShiftPct: 20,
    usdtPriceChangePct: -2.0,
    usdtHaircutShiftPct: 8,
    creditDefaultMultiplier: 2.2,
    recoveryRateHaircutPct: -20,
    correlationShiftPct: 35,
    interestRateShiftBps: -150
  },
  {
    id: 'SCEN-BTC-CRASH-75',
    name: 'Digital Asset Flash Crash (-75% BTC Drawdown)',
    category: 'CRYPTO_LIQUIDITY',
    description: 'Catastrophic digital asset drawdowns testing collateral sufficiency, triggering maximum margin calls and automated liquidation thresholds.',
    btcPriceChangePct: -75,
    btcHaircutShiftPct: 25,
    usdtPriceChangePct: -3.5,
    usdtHaircutShiftPct: 15,
    creditDefaultMultiplier: 1.4,
    recoveryRateHaircutPct: -10,
    correlationShiftPct: 15,
    interestRateShiftBps: 0
  },
  {
    id: 'SCEN-USDT-DEPEG',
    name: 'Stablecoin Run & USDT De-Pegging Crisis',
    category: 'CRYPTO_LIQUIDITY',
    description: 'Severe secondary market stablecoin discount, banking rails friction, heightened custody haircuts and tier-1 fiat flight.',
    btcPriceChangePct: -25,
    btcHaircutShiftPct: 10,
    usdtPriceChangePct: -12.0,
    usdtHaircutShiftPct: 35,
    creditDefaultMultiplier: 1.3,
    recoveryRateHaircutPct: -5,
    correlationShiftPct: 20,
    interestRateShiftBps: 50
  },
  {
    id: 'SCEN-STAGFLATION-RATES',
    name: 'Stagflationary Rate Shock (+400 bps Surge)',
    category: 'MACRO_RATES',
    description: 'Aggressive central bank rate hiking cycle, interest coverage erosion on leveraged loans, commercial real estate refinancing distress.',
    btcPriceChangePct: -30,
    btcHaircutShiftPct: 10,
    usdtPriceChangePct: 0.0,
    usdtHaircutShiftPct: 5,
    creditDefaultMultiplier: 2.6,
    recoveryRateHaircutPct: -30,
    correlationShiftPct: 25,
    interestRateShiftBps: 400
  },
  {
    id: 'SCEN-COMBINED-MAX',
    name: 'Combined Macro Credit + Digital Asset Meltdown',
    category: 'COMBINED',
    description: 'Severe dual crisis: BTC crashes -60%, USDT haircut doubles, credit default rate surges 3.5x, correlation spikes to 0.70.',
    btcPriceChangePct: -60,
    btcHaircutShiftPct: 25,
    usdtPriceChangePct: -5.0,
    usdtHaircutShiftPct: 20,
    creditDefaultMultiplier: 3.5,
    recoveryRateHaircutPct: -35,
    correlationShiftPct: 50,
    interestRateShiftBps: 200
  }
];

// Curated Market Oracle Feeds
export const INITIAL_ORACLE_FEEDS: OracleFeed[] = [
  {
    symbol: 'BTC/USD',
    name: 'Bitcoin Reference Rate (BRR)',
    price: 96450.00,
    currency: 'USD',
    change24hPct: 1.84,
    source: 'Rhino Consensus / Pyth / Chainlink',
    confidence: 0.9998,
    stalenessSec: 2,
    isStale: false,
    deviation24hPct: 1.4,
    status: 'HEALTHY'
  },
  {
    symbol: 'USDT/USD',
    name: 'Tether USD Peg Feed',
    price: 1.0001,
    currency: 'USD',
    change24hPct: 0.02,
    source: 'Curve 3Pool / Binance / Kraken TWAP',
    confidence: 0.9999,
    stalenessSec: 1,
    isStale: false,
    deviation24hPct: 0.05,
    status: 'HEALTHY'
  },
  {
    symbol: 'UK-SONIA',
    name: 'Sterling Overnight Index Average',
    price: 4.70,
    currency: '%',
    change24hPct: 0.00,
    source: 'Bank of England Fix',
    confidence: 1.0000,
    stalenessSec: 120,
    isStale: false,
    deviation24hPct: 0.00,
    status: 'HEALTHY'
  },
  {
    symbol: 'US-SOFR',
    name: 'Secured Overnight Financing Rate',
    price: 4.85,
    currency: '%',
    change24hPct: -0.01,
    source: 'Federal Reserve NY Fix',
    confidence: 1.0000,
    stalenessSec: 150,
    isStale: false,
    deviation24hPct: 0.01,
    status: 'HEALTHY'
  },
  {
    symbol: 'CDX.NA.IG',
    name: 'Markit CDX North American IG (5Y)',
    price: 52.4,
    currency: 'bps',
    change24hPct: -1.2,
    source: 'S&P Global Markit',
    confidence: 0.9985,
    stalenessSec: 15,
    isStale: false,
    deviation24hPct: 0.8,
    status: 'HEALTHY'
  },
  {
    symbol: 'ITRAXX.EUR',
    name: 'iTraxx Europe Main Index (5Y)',
    price: 58.6,
    currency: 'bps',
    change24hPct: -0.9,
    source: 'S&P Global Markit',
    confidence: 0.9982,
    stalenessSec: 18,
    isStale: false,
    deviation24hPct: 0.6,
    status: 'HEALTHY'
  }
];

export const SAMPLE_CDO_DEAL: SyntheticCDO = getInitialDemoCDOs()[0];

export const DEFAULT_ORACLE_PRICES: OraclePriceFeed = {
  btcUsd: 96450,
  usdtUsd: 1.0001,
  gbpUsd: 1.2850,
  sofrRatePct: 4.85,
  soniaRatePct: 4.70,
  cdxSpreadBps: 52.4,
  lastUpdated: new Date().toISOString()
};

