// ============================================================================
// RHINO BANK | RHINOQUANT SYNTH-CDO
// Quantitative Engine: One-Factor Gaussian Copula, Monte Carlo, Waterfall,
// Pricing, Collateral Margin & Stress Testing
// ============================================================================

import { 
  ReferenceAsset, 
  SyntheticCDO, 
  TrancheDefinition, 
  MonteCarloResult, 
  CollateralPosition, 
  StressScenario, 
  StressTestOutput,
  BankFinancials,
  MarginStatus 
} from '../types';

// Standard Normal Inverse CDF (Acklam approximation, accuracy ~ 1.15e-9)
export function normalInverseCDF(p: number): number {
  if (p <= 0) return -7.0;
  if (p >= 1) return 7.0;

  const a = [-3.969683028665376e+01,  2.209460984245205e+02, -2.759285104469687e+02,  1.383577518672690e+02, -3.066479806614716e+01,  2.506628277459239e+00];
  const b = [-5.447609879822406e+01,  1.615858368580409e+02, -1.556989798598866e+02,  6.680131188771972e+01, -1.328068155288572e+01];
  const c = [-7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00, -2.549732539343734e+00,  4.374664141464968e+00,  2.938163982698783e+00];
  const d = [ 7.784695709041462e-03,  3.224671290700398e-01,  2.445134137142996e+00,  3.754408661907416e+00];

  const p_low = 0.02425;
  const p_high = 1 - p_low;

  if (p < p_low) {
    const q = Math.sqrt(-2 * Math.log(p));
    return (((((c[0]*q + c[1])*q + c[2])*q + c[3])*q + c[4])*q + c[5]) /
           ((((d[0]*q + d[1])*q + d[2])*q + d[3])*q + 1);
  }
  if (p > p_high) {
    const q = Math.sqrt(-2 * Math.log(1 - p));
    return -(((((c[0]*q + c[1])*q + c[2])*q + c[3])*q + c[4])*q + c[5]) /
            ((((d[0]*q + d[1])*q + d[2])*q + d[3])*q + 1);
  }

  const q = p - 0.5;
  const r = q * q;
  return (((((a[0]*r + a[1])*r + a[2])*r + a[3])*r + a[4])*r + a[5])*q /
         (((((b[0]*r + b[1])*r + b[2])*r + b[3])*r + b[4])*r + 1);
}

// Standard Normal CDF (Abramowitz & Stegun approximation)
export function normalCDF(x: number): number {
  const b1 =  0.319381530;
  const b2 = -0.356563782;
  const b3 =  1.781477937;
  const b4 = -1.821255978;
  const b5 =  1.330274429;
  const p  =  0.2316419;
  const c  =  0.39894228;

  if (x >= 0.0) {
    const t = 1.0 / (1.0 + p * x);
    return (1.0 - c * Math.exp(-x * x / 2.0) * t * (t * (t * (t * (t * b5 + b4) + b3) + b2) + b1));
  } else {
    const t = 1.0 / (1.0 - p * x);
    return (c * Math.exp(-x * x / 2.0) * t * (t * (t * (t * (t * b5 + b4) + b3) + b2) + b1));
  }
}

// High-speed Box-Muller Gaussian Random Number Generator
class GaussianRNG {
  private hasSaved = false;
  private savedValue = 0;

  public next(): number {
    if (this.hasSaved) {
      this.hasSaved = false;
      return this.savedValue;
    }
    let u1 = Math.random();
    let u2 = Math.random();
    while (u1 === 0) u1 = Math.random();
    while (u2 === 0) u2 = Math.random();

    const r = Math.sqrt(-2.0 * Math.log(u1));
    const theta = 2.0 * Math.PI * u2;
    this.savedValue = r * Math.sin(theta);
    this.hasSaved = true;
    return r * Math.cos(theta);
  }
}

// ============================================================================
// MONTE CARLO ONE-FACTOR GAUSSIAN COPULA ENGINE
// ============================================================================
export function runMonteCarloSimulation(
  portfolio: ReferenceAsset[],
  cdo: SyntheticCDO,
  numScenarios = 25000,
  overrideCorrelation?: number
): MonteCarloResult {
  const startTime = performance.now();
  const rng = new GaussianRNG();
  const rho = overrideCorrelation !== undefined ? overrideCorrelation : cdo.systematicCorrelation;
  const sqrtRho = Math.sqrt(rho);
  const sqrtOneMinusRho = Math.sqrt(1 - rho);

  const numAssets = portfolio.length;
  const totalPortfolioNotional = portfolio.reduce((sum, a) => sum + a.notional, 0);

  // Precompute default barriers for each asset: C_i = Phi^-1(PD_i * maturity)
  const defaultBarriers = new Float64Array(numAssets);
  const assetLossesIfDefault = new Float64Array(numAssets);
  const maturityYears = cdo.maturityYears || 5;

  for (let i = 0; i < numAssets; i++) {
    const a = portfolio[i];
    // Cumulative default probability over CDO maturity: PD_cum = 1 - (1 - PD_annual)^T
    const cumPd = Math.min(0.999, 1 - Math.pow(1 - a.pd, maturityYears));
    defaultBarriers[i] = normalInverseCDF(cumPd);
    assetLossesIfDefault[i] = a.notional * a.lgd;
  }

  // Precompute Tranche boundaries
  const tranches = cdo.tranches;
  const trancheBounds = tranches.map(t => ({
    type: t.type,
    attachNotional: t.attachmentPct * totalPortfolioNotional,
    detachNotional: t.detachmentPct * totalPortfolioNotional,
    trancheNotional: (t.detachmentPct - t.attachmentPct) * totalPortfolioNotional,
    totalLossSum: 0,
    attachCount: 0,
    detachCount: 0,
    losses: new Float64Array(numScenarios)
  }));

  const scenarioLosses = new Float64Array(numScenarios);

  // Simulation Loop
  for (let s = 0; s < numScenarios; s++) {
    // 1. Draw systemic market factor M ~ N(0,1)
    const M = rng.next();

    let portfolioLoss = 0;

    // 2. Correlated asset returns: X_i = sqrt(rho)*M + sqrt(1-rho)*Z_i
    for (let i = 0; i < numAssets; i++) {
      const Z_i = rng.next();
      const X_i = sqrtRho * M + sqrtOneMinusRho * Z_i;

      if (X_i < defaultBarriers[i]) {
        portfolioLoss += assetLossesIfDefault[i];
      }
    }

    scenarioLosses[s] = portfolioLoss;

    // 3. Allocate losses through the Tranche Waterfall
    for (let t = 0; t < trancheBounds.length; t++) {
      const tb = trancheBounds[t];
      let tLoss = 0;

      if (portfolioLoss > tb.attachNotional) {
        tb.attachCount++;
        if (portfolioLoss >= tb.detachNotional) {
          tLoss = tb.trancheNotional;
          tb.detachCount++;
        } else {
          tLoss = portfolioLoss - tb.attachNotional;
        }
      }

      tb.totalLossSum += tLoss;
      tb.losses[s] = tLoss;
    }
  }

  // Sort scenario portfolio losses for percentile tail-risk calculation (VaR / CVaR)
  scenarioLosses.sort();

  const meanPortfolioLoss = scenarioLosses.reduce((acc, val) => acc + val, 0) / numScenarios;
  const meanPortfolioLossPct = meanPortfolioLoss / totalPortfolioNotional;

  const idx99 = Math.floor(numScenarios * 0.99);
  const idx999 = Math.floor(numScenarios * 0.999);
  const var99PortfolioLoss = scenarioLosses[idx99];
  const var999PortfolioLoss = scenarioLosses[idx999];

  // CVaR 99% (Expected Shortfall above 99th percentile)
  let tailLossSum = 0;
  for (let i = idx99; i < numScenarios; i++) {
    tailLossSum += scenarioLosses[i];
  }
  const cvar99PortfolioLoss = tailLossSum / (numScenarios - idx99);

  // Tranche specific statistical outcomes
  const trancheLosses = trancheBounds.map(tb => {
    const expectedLoss = tb.totalLossSum / numScenarios;
    const expectedLossPct = tb.trancheNotional > 0 ? expectedLoss / tb.trancheNotional : 0;
    const attachmentProb = tb.attachCount / numScenarios;
    const detachmentProb = tb.detachCount / numScenarios;

    // Fair Spread calculation: EL / (TrancheNotional - 0.5 * EL) / maturityYears * 10000 bps
    const avgPrincipal = Math.max(1, tb.trancheNotional - (expectedLoss * 0.5));
    const annualizedLossRate = (expectedLoss / avgPrincipal) / maturityYears;
    const modeledFairSpreadBps = Math.round(annualizedLossRate * 10000);

    return {
      trancheType: tb.type,
      expectedLoss,
      expectedLossPct,
      lossDistribution: [],
      attachmentProb,
      detachmentProb,
      modeledFairSpreadBps
    };
  });

  // Build 12 histogram bins for loss distribution visualization
  const maxLoss = Math.max(scenarioLosses[numScenarios - 1], totalPortfolioNotional * 0.18);
  const binCount = 12;
  const binWidth = maxLoss / binCount;
  const lossHistogramBins = [];

  for (let b = 0; b < binCount; b++) {
    const binStart = b * binWidth;
    const binEnd = (b + 1) * binWidth;
    const midpoint = (binStart + binEnd) / 2;
    const lossRange = `£${(binStart / 1000000).toFixed(0)}M - £${(binEnd / 1000000).toFixed(0)}M`;

    let count = 0;
    for (let s = 0; s < numScenarios; s++) {
      if (scenarioLosses[s] >= binStart && scenarioLosses[s] < binEnd) {
        count++;
      }
    }

    const freqPct = (count / numScenarios) * 100;
    
    // Calculate which tranches are impaired in this loss range
    const eqBound = totalPortfolioNotional * 0.03;
    const jrBound = totalPortfolioNotional * 0.07;
    const mzBound = totalPortfolioNotional * 0.15;

    lossHistogramBins.push({
      lossRange,
      midpoint,
      frequency: Number(freqPct.toFixed(2)),
      equityImpact: Math.min(100, Math.max(0, (midpoint / eqBound) * 100)),
      juniorImpact: midpoint > eqBound ? Math.min(100, Math.max(0, ((midpoint - eqBound) / (jrBound - eqBound)) * 100)) : 0,
      mezzanineImpact: midpoint > jrBound ? Math.min(100, Math.max(0, ((midpoint - jrBound) / (mzBound - jrBound)) * 100)) : 0,
      seniorImpact: midpoint > mzBound ? Math.min(100, Math.max(0, ((midpoint - mzBound) / (totalPortfolioNotional - mzBound)) * 100)) : 0
    });
  }

  const executionTimeMs = Math.round(performance.now() - startTime);

  return {
    numScenarios,
    meanPortfolioLoss,
    meanPortfolioLossPct,
    var99PortfolioLoss,
    var999PortfolioLoss,
    cvar99PortfolioLoss,
    trancheLosses,
    lossHistogramBins,
    executionTimeMs,
    rustAccelerationActive: true
  };
}

// ============================================================================
// COLLATERAL & MARGIN VALUATION ENGINE
// ============================================================================
export function calculateCollateralHealth(
  btcQty: number,
  btcPrice: number,
  btcHaircut: number,
  usdtQty: number,
  usdtPrice: number,
  usdtHaircut: number,
  fiatCash: number,
  requiredInitialMargin: number,
  requiredVariationMargin: number
): {
  grossCollateralUsd: number;
  eligibleCollateralUsd: number;
  totalRequiredMarginUsd: number;
  collateralRatio: number;
  marginStatus: MarginStatus;
  marginBufferUsd: number;
  liquidationDistancePct: number;
} {
  const btcGross = btcQty * btcPrice;
  const usdtGross = usdtQty * usdtPrice;
  const grossCollateralUsd = btcGross + usdtGross + fiatCash;

  const btcEligible = btcGross * (1 - btcHaircut);
  const usdtEligible = usdtGross * (1 - usdtHaircut);
  const eligibleCollateralUsd = btcEligible + usdtEligible + fiatCash;

  const totalRequiredMarginUsd = requiredInitialMargin + requiredVariationMargin;
  const collateralRatio = totalRequiredMarginUsd > 0 ? eligibleCollateralUsd / totalRequiredMarginUsd : 999;
  const marginBufferUsd = eligibleCollateralUsd - totalRequiredMarginUsd;

  let marginStatus: MarginStatus = 'SAFE';
  if (collateralRatio < 1.0) {
    marginStatus = 'LIQUIDATION';
  } else if (collateralRatio < 1.10) {
    marginStatus = 'MARGIN_CALL';
  } else if (collateralRatio < 1.30) {
    marginStatus = 'WARNING';
  } else {
    marginStatus = 'SAFE';
  }

  // Calculate distance in BTC price drop before hitting Margin Call (Ratio = 1.05)
  // Target eligible = 1.05 * totalRequired
  // Target btcEligible = Target eligible - (usdtEligible + fiatCash)
  const nonBtcEligible = usdtEligible + fiatCash;
  const targetBtcEligible = Math.max(0, (1.05 * totalRequiredMarginUsd) - nonBtcEligible);
  const targetBtcPrice = (btcQty * (1 - btcHaircut)) > 0 ? targetBtcEligible / (btcQty * (1 - btcHaircut)) : 0;
  const liquidationDistancePct = btcPrice > 0 ? Math.max(0, (btcPrice - targetBtcPrice) / btcPrice) : 0;

  return {
    grossCollateralUsd,
    eligibleCollateralUsd,
    totalRequiredMarginUsd,
    collateralRatio,
    marginStatus,
    marginBufferUsd,
    liquidationDistancePct
  };
}

// ============================================================================
// STRESS TESTING & SCENARIO ENGINE
// ============================================================================
export function runStressTestScenario(
  cdo: SyntheticCDO,
  scenario: StressScenario
): StressTestOutput {
  const notional = cdo.totalNotional;

  // Stressed default rates & recovery
  const stressedPd = Math.min(0.50, cdo.weightedAvgPd * scenario.creditDefaultMultiplier);
  const stressedRecovery = Math.max(0.05, cdo.weightedAvgLgd * (1 + (scenario.recoveryRateHaircutPct / 100)));
  const stressedLgd = 1 - stressedRecovery;

  // Stressed portfolio expected loss
  const baseLoss = cdo.portfolioExpectedLossUsd;
  const stressedLossMultiplier = (stressedPd / cdo.weightedAvgPd) * (stressedLgd / cdo.weightedAvgLgd) * (1 + (scenario.correlationShiftPct / 200));
  const stressedPortfolioLossUsd = Math.min(notional * 0.45, baseLoss * stressedLossMultiplier);
  const stressedPortfolioLossPct = stressedPortfolioLossUsd / notional;

  // Stressed Collateral
  const stressedBtcPrice = cdo.collateral.btcPriceUsd * (1 + (scenario.btcPriceChangePct / 100));
  const stressedBtcHaircut = Math.min(0.70, cdo.collateral.btcHaircutPct + (scenario.btcHaircutShiftPct / 100));
  const stressedUsdtPrice = Math.max(0.50, cdo.collateral.usdtPriceUsd * (1 + (scenario.usdtPriceChangePct / 100)));
  const stressedUsdtHaircut = Math.min(0.50, cdo.collateral.usdtHaircutPct + (scenario.usdtHaircutShiftPct / 100));

  const stressedCollateralHealth = calculateCollateralHealth(
    cdo.collateral.btcQty,
    stressedBtcPrice,
    stressedBtcHaircut,
    cdo.collateral.usdtQty,
    stressedUsdtPrice,
    stressedUsdtHaircut,
    cdo.collateral.fiatCash,
    cdo.collateral.requiredInitialMarginUsd * 1.25, // Stressed IM increases with vol
    cdo.collateral.requiredVariationMarginUsd * 2.50 // Stressed VM surges on mark-to-market
  );

  // Allocate Stressed Loss to Tranches
  const trancheStressedLosses = cdo.tranches.map(t => {
    const attach = t.attachmentPct * notional;
    const detach = t.detachmentPct * notional;
    const tNotional = detach - attach;

    let lossUsd = 0;
    if (stressedPortfolioLossUsd > attach) {
      if (stressedPortfolioLossUsd >= detach) {
        lossUsd = tNotional;
      } else {
        lossUsd = stressedPortfolioLossUsd - attach;
      }
    }

    const lossPct = tNotional > 0 ? lossUsd / tNotional : 0;
    const remainingPrincipalUsd = Math.max(0, tNotional - lossUsd);

    let impairmentState: 'UNIMPAIRED' | 'PARTIALLY_IMPAIRED' | 'TOTALLY_WIPED' = 'UNIMPAIRED';
    if (lossPct >= 0.999) {
      impairmentState = 'TOTALLY_WIPED';
    } else if (lossPct > 0.001) {
      impairmentState = 'PARTIALLY_IMPAIRED';
    }

    return {
      trancheType: t.type,
      lossUsd,
      lossPct,
      remainingPrincipalUsd,
      impairmentState
    };
  });

  // Determine overall structure solvency
  let solvencyStatus: 'SOLVENT' | 'IMPAIRED' | 'MARGIN_DEFICIT' | 'INSOLVENT' = 'SOLVENT';
  if (stressedCollateralHealth.marginStatus === 'LIQUIDATION' || stressedPortfolioLossPct > 0.20) {
    solvencyStatus = 'INSOLVENT';
  } else if (stressedCollateralHealth.marginStatus === 'MARGIN_CALL') {
    solvencyStatus = 'MARGIN_DEFICIT';
  } else if (trancheStressedLosses.some(tl => tl.impairmentState !== 'UNIMPAIRED')) {
    solvencyStatus = 'IMPAIRED';
  }

  return {
    scenario,
    stressedPortfolioLossUsd,
    stressedPortfolioLossPct,
    stressedEligibleCollateralUsd: stressedCollateralHealth.eligibleCollateralUsd,
    stressedRequiredMarginUsd: stressedCollateralHealth.totalRequiredMarginUsd,
    stressedCollateralRatio: stressedCollateralHealth.collateralRatio,
    stressedMarginStatus: stressedCollateralHealth.marginStatus,
    solvencyStatus,
    trancheStressedLosses
  };
}

// ============================================================================
// RHINO BANK PROFITABILITY & CAPITAL EFFICIENCY (RAROC)
// ============================================================================
export function calculateBankFinancials(cdo: SyntheticCDO): BankFinancials {
  const notional = cdo.totalNotional;

  // Revenue
  const grossStructuringRevenue = notional * (cdo.rhinoStructuringFeeBps / 10000);
  const annualManagementFees = notional * (cdo.rhinoManagementFeeBps / 10000);
  const collateralSpreadIncome = cdo.collateral.grossCollateralUsd * 0.038; // 3.8% reinvestment net margin
  const totalGrossAnnual = annualManagementFees + collateralSpreadIncome + (grossStructuringRevenue / cdo.maturityYears);

  // Costs
  const hedgingAndFundingCost = notional * 0.0018; // 18 bps dynamic hedging & repo
  const operationalAndTechCost = 650000; // Fixed tech & custody run cost
  const expectedCreditLossProvision = cdo.portfolioExpectedLossUsd / cdo.maturityYears;
  const netAnnualProfit = totalGrossAnnual - hedgingAndFundingCost - operationalAndTechCost - expectedCreditLossProvision;

  // Basel III / Economic Capital calculations
  // Basel III Standardized Approach: Risk Weight ~ 20% for Senior, 100% for Mezz, 1250% for Equity
  const riskWeightedAssets = (notional * 0.85 * 0.20) + (notional * 0.08 * 1.00) + (notional * 0.04 * 2.50) + (notional * 0.03 * 12.50);
  
  // Economic Capital (EC) = VaR 99.9% - Expected Loss + Collateral Haircut buffer
  const allocatedEconomicCapital = (notional * 0.042) + (cdo.collateral.grossCollateralUsd * 0.08);

  const raroc = allocatedEconomicCapital > 0 ? (netAnnualProfit / allocatedEconomicCapital) * 100 : 0;
  const returnOnEquity = (netAnnualProfit / (allocatedEconomicCapital * 0.85)) * 100;
  const returnOnAssets = (netAnnualProfit / notional) * 100;
  const tier1CapitalImpact = (riskWeightedAssets * 0.125); // 12.5% Tier 1 Capital requirement

  return {
    grossStructuringRevenue,
    annualManagementFees,
    collateralSpreadIncome,
    hedgingAndFundingCost,
    operationalAndTechCost,
    expectedCreditLossProvision,
    netAnnualProfit,
    allocatedEconomicCapital,
    riskWeightedAssets,
    raroc,
    returnOnEquity,
    returnOnAssets,
    tier1CapitalImpact
  };
}
