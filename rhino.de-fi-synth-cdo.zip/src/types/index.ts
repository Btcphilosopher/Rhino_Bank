// ============================================================================
// RHINO BANK | RHINOQUANT SYNTH-CDO ENGINE
// Core Types and Data Models for Institutional Structured Credit Platform
// ============================================================================

export type Currency = 'GBP' | 'USD' | 'EUR';

export type CreditRating = 'AAA' | 'AA' | 'A' | 'BBB' | 'BB' | 'B' | 'CCC' | 'D';

export type Sector = 
  | 'Technology' 
  | 'Financials' 
  | 'Energy & Utilities' 
  | 'Healthcare' 
  | 'Consumer & Retail' 
  | 'Industrials & Aerospace' 
  | 'Commercial Real Estate' 
  | 'Sovereign & Supranational' 
  | 'Digital Asset & DeFi Prime';

export type Geography = 
  | 'United Kingdom' 
  | 'United States' 
  | 'European Union' 
  | 'Switzerland' 
  | 'Asia-Pacific' 
  | 'Global / Decentralized';

export type AssetClass = 
  | 'Corporate Loan' 
  | 'Corporate Bond' 
  | 'Sovereign Debt' 
  | 'Commercial Real Estate (CRE)' 
  | 'Residential Mortgage (RMBS)' 
  | 'Institutional DeFi Lending' 
  | 'Infrastructure Debt';

export type TrancheType = 'EQUITY' | 'JUNIOR' | 'MEZZANINE' | 'SENIOR';

export type MarginStatus = 'SAFE' | 'WARNING' | 'MARGIN_CALL' | 'LIQUIDATION';

export type UserRole = 
  | 'Trader' 
  | 'Structurer' 
  | 'Risk Manager' 
  | 'Treasury' 
  | 'Compliance Officer' 
  | 'Administrator';

export type CDOStatus = 
  | 'Draft' 
  | 'Simulated' 
  | 'Pending_Approval' 
  | 'Approved' 
  | 'Issued' 
  | 'Active' 
  | 'Matured' 
  | 'Liquidated';

export interface ReferenceAsset {
  id: string;
  name: string;
  ticker: string;
  assetClass: AssetClass;
  rating: CreditRating;
  sector: Sector;
  geography: Geography;
  notional: number; // in base currency
  spreadBps: number; // CDS spread in basis points
  pd: number; // Probability of default (annual, e.g. 0.015 = 1.5%)
  lgd: number; // Loss Given Default (e.g. 0.60 = 60%)
  recovery: number; // Recovery rate = 1 - LGD
  correlationBeta: number; // Factor loading to systematic market factor (0.0 - 1.0)
  maturityYears: number;
  isDefaulted?: boolean;
  defaultTime?: number;
}

export interface TrancheDefinition {
  id: string;
  cdoId: string;
  type: TrancheType;
  name: string;
  attachmentPct: number; // e.g. 0.0 for Equity (0%)
  detachmentPct: number; // e.g. 0.03 for Equity (3%)
  notional: number;
  couponBps: number; // Fixed/Floating spread paid to tranche investor
  
  // Modeled Metrics
  expectedLossPct: number;
  expectedReturnPct: number;
  spreadBps: number;
  duration: number; // Effective spread duration
  var99: number; // 99% Value at Risk (£/$)
  cvar99: number; // 99% Conditional VaR / Expected Shortfall
  dv01: number; // Dollar Value of a 01 (interest rate delta)
  cs01: number; // Credit Spread 01 (credit spread delta)
  lossProbability: number; // Probability of attaching
  
  // DeFi Tokenized Representation
  tokenSymbol: string;
  tokenContractAddress: string;
  totalSupply: number;
  currentNav: number;
  tokenHoldersCount: number;
  investorEligibility: string[];
}

export interface CollateralPosition {
  btcQty: number;
  btcPriceUsd: number;
  btcHaircutPct: number; // Base haircut e.g. 25% (0.25)
  btcVolatilityAnnual: number; // e.g. 55%
  
  usdtQty: number;
  usdtPriceUsd: number;
  usdtHaircutPct: number; // Base haircut e.g. 5% (0.05)
  usdtLiquidityScore: number; // 0 - 100
  
  fiatCash: number; // Cash collateral held in segregated Rhino Bank custodial account
  
  grossCollateralUsd: number;
  eligibleCollateralUsd: number;
  requiredInitialMarginUsd: number;
  requiredVariationMarginUsd: number;
  requiredMaintenanceMarginUsd: number;
  
  collateralRatio: number; // Eligible / Required
  marginStatus: MarginStatus;
  marginBufferUsd: number;
  liquidationDistancePct: number;
  lastValuationTimestamp: string;
}

export interface SyntheticCDO {
  id: string;
  dealCode: string;
  name: string;
  currency: Currency;
  status: CDOStatus;
  
  totalNotional: number;
  maturityYears: number;
  effectiveDate: string;
  maturityDate: string;
  
  // Reference Portfolio
  portfolioId: string;
  portfolioName: string;
  assetCount: number;
  avgRating: CreditRating;
  weightedAvgSpreadBps: number;
  weightedAvgPd: number;
  weightedAvgLgd: number;
  portfolioExpectedLossUsd: number;
  portfolioExpectedLossPct: number;
  
  // Copula & Correlation
  systematicCorrelation: number; // rho e.g. 0.30
  correlationModel: 'Gaussian_Copula_1Factor' | 'MultiFactor_Sector' | 'Student_T_Copula';
  
  // Tranches
  tranches: TrancheDefinition[];
  
  // Collateralization
  collateral: CollateralPosition;
  
  // Cash Flow & Fees
  protectionPremiumIncomeAnnual: number;
  collateralReinvestmentYieldAnnual: number;
  trancheCouponObligationsAnnual: number;
  rhinoStructuringFeeBps: number; // Upfront fee
  rhinoManagementFeeBps: number; // Annual fee
  netCashFlowAnnual: number;
  
  // Compliance & Governance
  jurisdiction: 'UK_FCA' | 'EU_ESMA' | 'US_CFTC_SEC' | 'ADGM_FSRA' | 'FINMA_CH';
  investorClass: 'Eligible_Counterparty' | 'Professional_Only' | 'Institutional_DeFi';
  multiSigRequired: number; // e.g. 3
  multiSigCurrent: number; // e.g. 3
  sanctionsCheckPassed: boolean;
  kycRequiredLevel: 'TIER_3_INSTITUTIONAL' | 'TIER_2_QUALIFIED';
  
  createdAt: string;
  lastUpdated: string;
}

export interface MonteCarloResult {
  numScenarios: number;
  meanPortfolioLoss: number;
  meanPortfolioLossPct: number;
  var99PortfolioLoss: number;
  var999PortfolioLoss: number;
  cvar99PortfolioLoss: number;
  
  trancheLosses: {
    trancheType: TrancheType;
    expectedLoss: number;
    expectedLossPct: number;
    lossDistribution: number[]; // Binned histogram counts
    attachmentProb: number;
    detachmentProb: number;
    modeledFairSpreadBps: number;
  }[];
  
  lossHistogramBins: {
    lossRange: string;
    midpoint: number;
    frequency: number;
    equityImpact: number;
    juniorImpact: number;
    mezzanineImpact: number;
    seniorImpact: number;
  }[];
  
  executionTimeMs: number;
  rustAccelerationActive: boolean;
}

export interface StressScenario {
  id: string;
  name: string;
  category: 'HISTORICAL' | 'CRYPTO_LIQUIDITY' | 'MACRO_RATES' | 'COMBINED';
  description: string;
  btcPriceChangePct: number; // e.g. -40%
  btcHaircutShiftPct: number; // e.g. +15%
  usdtPriceChangePct: number; // e.g. -2%
  usdtHaircutShiftPct: number; // e.g. +10%
  creditDefaultMultiplier: number; // e.g. 2.5x
  recoveryRateHaircutPct: number; // e.g. -25%
  correlationShiftPct: number; // e.g. +30%
  interestRateShiftBps: number; // e.g. +300 bps
}

export interface StressTestOutput {
  scenario: StressScenario;
  stressedPortfolioLossUsd: number;
  stressedPortfolioLossPct: number;
  stressedEligibleCollateralUsd: number;
  stressedRequiredMarginUsd: number;
  stressedCollateralRatio: number;
  stressedMarginStatus: MarginStatus;
  solvencyStatus: 'SOLVENT' | 'IMPAIRED' | 'MARGIN_DEFICIT' | 'INSOLVENT';
  
  trancheStressedLosses: {
    trancheType: TrancheType;
    lossUsd: number;
    lossPct: number;
    remainingPrincipalUsd: number;
    impairmentState: 'UNIMPAIRED' | 'PARTIALLY_IMPAIRED' | 'TOTALLY_WIPED';
  }[];
}

export interface BankFinancials {
  grossStructuringRevenue: number;
  annualManagementFees: number;
  collateralSpreadIncome: number;
  hedgingAndFundingCost: number;
  operationalAndTechCost: number;
  expectedCreditLossProvision: number;
  netAnnualProfit: number;
  
  allocatedEconomicCapital: number;
  riskWeightedAssets: number;
  raroc: number; // Risk-Adjusted Return on Capital (%)
  returnOnEquity: number; // ROE (%)
  returnOnAssets: number; // ROA (%)
  tier1CapitalImpact: number;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  actor: string;
  role: UserRole;
  action: string;
  cdoDealCode: string;
  details: string;
  txHash: string;
  blockNumber: number;
  ipLocation: string;
  status: 'VERIFIED' | 'COMMITTED' | 'ALERT';
}

export interface OraclePriceFeed {
  btcUsd: number;
  usdtUsd: number;
  gbpUsd: number;
  sofrRatePct: number;
  soniaRatePct: number;
  cdxSpreadBps: number;
  lastUpdated: string;
}

export interface OracleFeed {
  symbol: string;
  name: string;
  price: number;
  currency: string;
  change24hPct: number;
  source: string;
  confidence: number;
  stalenessSec: number;
  isStale: boolean;
  deviation24hPct: number;
  status: 'HEALTHY' | 'WARNING' | 'CIRCUIT_BREAKER';
}
