// ============================================================================
// RHINO BANK | RHINOQUANT SYNTH-CDO
// Audit Ledger, Cryptographic Event Log & Regulatory Verification Desk (Sophisticated Dark)
// ============================================================================

import React, { useState } from 'react';
import { AuditLogEntry } from '../types';
import { 
  Search, 
  Download 
} from 'lucide-react';

interface AuditLedgerViewProps {
  auditLogs: AuditLogEntry[];
}

export const AuditLedgerView: React.FC<AuditLedgerViewProps> = ({ auditLogs }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  const filteredLogs = auditLogs.filter(log => {
    const matchesSearch = 
      log.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.details.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.actor.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.txHash.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesCat = selectedCategory === 'ALL' || log.role === selectedCategory;

    return matchesSearch && matchesCat;
  });

  const handleExportCSV = () => {
    const headers = ['Timestamp', 'BlockNumber', 'Action', 'Actor', 'Role', 'TxHash', 'Details'];
    const rows = auditLogs.map(l => [
      l.timestamp,
      l.blockNumber,
      `"${l.action}"`,
      `"${l.actor}"`,
      `"${l.role}"`,
      `"${l.txHash}"`,
      `"${l.details.replace(/"/g, '""')}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `rhinoquant_audit_trail_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div id="audit-ledger-workspace" className="space-y-6 font-mono">
      {/* Top Banner */}
      <div className="bg-[#161618] border border-[#1F1F21] p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-xs">
            <span className="px-2 py-0.5 border border-[#2D5A27] text-[#2D5A27] font-semibold text-[10px] uppercase tracking-wider">
              Compliance Audit Trail
            </span>
            <span className="text-[#555] uppercase text-[10px]">Cryptographically Chained Event Log</span>
          </div>
          <h1 className="text-base font-bold text-white tracking-tight mt-1.5">
            Immutable Audit Ledger & Institutional Governance Trail
          </h1>
          <p className="text-xs text-[#777] mt-0.5">
            Full tamper-evident record of deal structuring, risk parameter updates, collateral rebalances, and multi-sig approvals.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={handleExportCSV}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-[#0F0F10] hover:bg-[#1A1A1C] text-[#888] hover:text-white border border-[#1F1F21] text-xs uppercase tracking-wider transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-[#2D5A27]" />
            <span>Export Regulatory CSV</span>
          </button>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-[#161618] border border-[#1F1F21] p-4 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center space-x-2 flex-1 min-w-[240px]">
          <div className="relative w-full max-w-sm">
            <Search className="w-3.5 h-3.5 text-[#555] absolute left-2.5 top-2.5" />
            <input
              type="text"
              placeholder="Search audit actions, actors, or tx hashes..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full bg-[#0F0F10] border border-[#1F1F21] rounded-sm pl-8 pr-3 py-1.5 text-xs text-white placeholder-[#555] focus:outline-none focus:border-[#2D5A27]"
            />
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <select
            value={selectedCategory}
            onChange={e => setSelectedCategory(e.target.value)}
            className="bg-[#0F0F10] border border-[#1F1F21] rounded-sm px-3 py-1.5 text-xs text-[#888] focus:outline-none focus:border-[#2D5A27]"
          >
            <option value="ALL">All Roles</option>
            <option value="Structurer">Structurer</option>
            <option value="Risk Manager">Risk Manager</option>
            <option value="Treasury">Treasury</option>
            <option value="Compliance Officer">Compliance Officer</option>
            <option value="Administrator">Administrator</option>
          </select>
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="bg-[#161618] border border-[#1F1F21] overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="bg-[#0F0F10] border-b border-[#1F1F21] text-[#555] text-[10px] uppercase tracking-wider">
                <th className="py-3 px-4 font-semibold">Block / Time</th>
                <th className="py-3 px-4 font-semibold">Action</th>
                <th className="py-3 px-4 font-semibold">Actor & Role</th>
                <th className="py-3 px-4 font-semibold">Tx Hash</th>
                <th className="py-3 px-4 font-semibold">State Audit Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1F1F21] text-[#D1D1D1]">
              {filteredLogs.map(log => (
                <tr key={log.id} className="hover:bg-[#1A1A1C] transition-colors">
                  <td className="py-3 px-4">
                    <div className="font-bold text-white">#{log.blockNumber}</div>
                    <div className="text-[10px] text-[#555]">{new Date(log.timestamp).toLocaleTimeString('en-GB')} BST</div>
                  </td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded-sm text-[10px] font-bold bg-[#2D5A27]/15 text-[#2D5A27] border border-[#2D5A27]/30 uppercase tracking-wider">
                      {log.action}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-semibold text-white">{log.actor}</div>
                    <div className="text-[10px] text-[#555] uppercase">{log.role}</div>
                  </td>
                  <td className="py-3 px-4 font-mono text-[#777] text-[11px]">
                    {log.txHash.slice(0, 10)}...{log.txHash.slice(-6)}
                  </td>
                  <td className="py-3 px-4 text-[#888] text-[11px]">
                    {log.details}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
