// ============================================================================
// RHINO BANK | RHINOQUANT SYNTH-CDO
// Rhino Bank Balance Sheet, Economic Capital, Basel III RWA & RAROC Desk (Sophisticated Dark)
// ============================================================================

import React from 'react';
import { 
  SyntheticCDO, 
  BankFinancials 
} from '../types';
import { calculateBankFinancials } from '../services/quantEngine';
import { 
  ShieldCheck, 
  TrendingUp, 
  DollarSign, 
  Layers, 
  Building2, 
  FileSpreadsheet 
} from 'lucide-react';

interface RiskRarocViewProps {
  cdo: SyntheticCDO;
  currencySymbol: string;
}

export const RiskRarocView: React.FC<RiskRarocViewProps> = ({
  cdo,
  currencySymbol
}) => {
  const financials: BankFinancials = calculateBankFinancials(cdo);

  // Risk Heatmap Matrix Data
  const riskCategories = [
    { name: 'Credit Default Risk', level: 'LOW', score: 1, desc: 'Portfolio weighted average rating is A / BBB with diversified single-name exposures.' },
    { name: 'Systematic Correlation Risk', level: 'MEDIUM', score: 2, desc: 'Li copula correlation estimated at 30% baseline. Contagion risk exists in crisis.' },
    { name: 'Secondary Market Liquidity', level: 'MEDIUM', score: 2, desc: 'Structured synthetic credit tranches require bilateral unwind or protocol redemption.' },
    { name: 'Collateral & Haircut Risk', level: 'LOW', score: 1, desc: '25% BTC haircut and 5% USDT haircut provides 187% coverage above required margin.' },
    { name: 'Digital Asset Volatility (BTC)', level: 'HIGH', score: 3, desc: 'Bitcoin spot volatility ~52% annual requires continuous dynamic mark-to-market.' },
    { name: 'Stablecoin Peg Risk (USDT)', level: 'LOW', score: 1, desc: 'Tether primary liquidity depth monitored across 4 tier-1 OTC trading desks.' }
  ];

  return (
    <div id="risk-raroc-workspace" className="space-y-6 font-mono">
      {/* Top Banner */}
      <div className="bg-[#161618] border border-[#1F1F21] p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-xs">
            <span className="px-2 py-0.5 border border-[#2D5A27] text-[#2D5A27] font-semibold text-[10px] uppercase tracking-wider">
              Rhino Bank Balance Sheet Desk
            </span>
            <span className="text-[#555] uppercase text-[10px]">Structured Credit & Capital Book</span>
          </div>
          <h1 className="text-base font-bold text-white tracking-tight mt-1.5">
            Capital Adequacy, Economic Capital & RAROC Analytics
          </h1>
          <p className="text-xs text-[#777] mt-0.5">
            Basel III Standardised Approach for Securitisation (SEC-SA) and internal Economic Capital allocation.
          </p>
        </div>

        <div className="flex items-center space-x-3 text-xs">
          <div className="px-3 py-1.5 bg-[#0F0F10] border border-[#2D5A27]/40 text-[#2D5A27]">
            RAROC: <strong className="text-white text-sm">{financials.raroc.toFixed(1)}%</strong>
          </div>
          <div className="px-3 py-1.5 bg-[#0F0F10] border border-[#1F1F21] text-[#888]">
            ROE: <strong className="text-white text-sm">{financials.returnOnEquity.toFixed(1)}%</strong>
          </div>
        </div>
      </div>

      {/* Top 4 KPI Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#161618] border border-[#1F1F21] p-4">
          <div className="text-[10px] text-[#555] uppercase font-bold tracking-wider mb-1 flex items-center justify-between">
            <span>Net Annual Profit</span>
            <DollarSign className="w-3.5 h-3.5 text-[#2D5A27]" />
          </div>
          <div className="text-lg font-light text-[#2D5A27] tracking-tight">
            {currencySymbol}{(financials.netAnnualProfit / 1000000).toFixed(2)}M / yr
          </div>
          <div className="text-[10px] text-[#555] mt-1">
            After ECL Provisions & Hedging Costs
          </div>
        </div>

        <div className="bg-[#161618] border border-[#1F1F21] p-4">
          <div className="text-[10px] text-[#555] uppercase font-bold tracking-wider mb-1 flex items-center justify-between">
            <span>Economic Capital (EC)</span>
            <Building2 className="w-3.5 h-3.5 text-[#555]" />
          </div>
          <div className="text-lg font-light text-white tracking-tight">
            {currencySymbol}{(financials.allocatedEconomicCapital / 1000000).toFixed(2)}M
          </div>
          <div className="text-[10px] text-[#555] mt-1">
            99.9% VaR Tail Buffer Allocation
          </div>
        </div>

        <div className="bg-[#161618] border border-[#1F1F21] p-4">
          <div className="text-[10px] text-[#555] uppercase font-bold tracking-wider mb-1 flex items-center justify-between">
            <span>Risk-Weighted Assets</span>
            <Layers className="w-3.5 h-3.5 text-[#F7931A]" />
          </div>
          <div className="text-lg font-light text-white tracking-tight">
            {currencySymbol}{(financials.riskWeightedAssets / 1000000).toFixed(0)}M
          </div>
          <div className="text-[10px] text-[#555] mt-1">
            Tier 1 Requirement: {currencySymbol}{(financials.tier1CapitalImpact / 1000000).toFixed(1)}M
          </div>
        </div>

        <div className="bg-[#161618] border border-[#1F1F21] p-4">
          <div className="text-[10px] text-[#555] uppercase font-bold tracking-wider mb-1 flex items-center justify-between">
            <span>RAROC (Capital Efficiency)</span>
            <TrendingUp className="w-3.5 h-3.5 text-[#2D5A27]" />
          </div>
          <div className="text-lg font-light text-[#2D5A27] tracking-tight">
            {financials.raroc.toFixed(1)}%
          </div>
          <div className="text-[10px] text-[#555] mt-1">
            Hurdle: 12.5% (Exceeded +{(financials.raroc - 12.5).toFixed(1)}%)
          </div>
        </div>
      </div>

      {/* Main Grid: Bank P&L Breakdown vs. Institutional Risk Heatmap */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Bank Profitability Breakdown */}
        <div className="lg:col-span-6 bg-[#161618] border border-[#1F1F21] p-5 space-y-4">
          <div className="border-b border-[#1F1F21] pb-3">
            <h2 className="text-xs font-bold uppercase tracking-[0.2em] text-white flex items-center gap-2">
              <FileSpreadsheet className="w-4 h-4 text-[#2D5A27]" />
              Rhino Bank Structured Credit P&L Schedule
            </h2>
            <p className="text-[10px] text-[#555] uppercase mt-0.5">Annualized revenue, operational overhead, and capital charges</p>
          </div>

          <div className="space-y-3 text-xs">
            {/* Revenue Items */}
            <div className="p-4 bg-[#0F0F10] border border-[#1F1F21] space-y-2">
              <div className="text-[10px] font-bold uppercase tracking-wider text-[#2D5A27]">Desk Revenues (Annual)</div>
              <div className="flex justify-between text-[#888]">
                <span>Annual Management Fee ({cdo.rhinoManagementFeeBps} bps):</span>
                <span className="text-white font-bold">+{currencySymbol}{(financials.annualManagementFees / 1000000).toFixed(2)}M</span>
              </div>
              <div className="flex justify-between text-[#888]">
                <span>Collateral Reinvestment Spread (3.8% net):</span>
                <span className="text-white font-bold">+{currencySymbol}{(financials.collateralSpreadIncome / 1000000).toFixed(2)}M</span>
              </div>
              <div className="flex justify-between text-[#888]">
                <span>Upfront Structuring Fee Amortisation ({cdo.rhinoStructuringFeeBps} bps / 5 yrs):</span>
                <span className="text-white font-bold">+{currencySymbol}{((financials.grossStructuringRevenue / cdo.maturityYears) / 1000000).toFixed(2)}M</span>
              </div>
            </div>

            {/* Cost Items */}
            <div className="p-4 bg-[#0F0F10] border border-[#1F1F21] space-y-2">
              <div className="text-[10px] font-bold uppercase tracking-wider text-[#E04444]">Costs & ECL Charges (Annual)</div>
              <div className="flex justify-between text-[#888]">
                <span>Dynamic Hedging & Funding Spread:</span>
                <span className="text-[#E04444] font-semibold">-{currencySymbol}{(financials.hedgingAndFundingCost / 1000000).toFixed(2)}M</span>
              </div>
              <div className="flex justify-between text-[#888]">
                <span>Technology, Custody & Node Infrastructure:</span>
                <span className="text-[#E04444] font-semibold">-{currencySymbol}{(financials.operationalAndTechCost / 1000000).toFixed(2)}M</span>
              </div>
              <div className="flex justify-between text-[#888]">
                <span>IFRS 9 Expected Credit Loss (ECL) Provision:</span>
                <span className="text-[#E04444] font-semibold">-{currencySymbol}{(financials.expectedCreditLossProvision / 1000000).toFixed(2)}M</span>
              </div>
            </div>

            {/* Bottom Line */}
            <div className="p-3.5 bg-[#2D5A27]/15 border border-[#2D5A27]/30 flex items-center justify-between text-xs">
              <span className="font-bold text-[#2D5A27] uppercase tracking-wider">Rhino Bank Net Desk Profit:</span>
              <span className="text-sm font-bold text-[#2D5A27]">
                +{currencySymbol}{(financials.netAnnualProfit / 1000000).toFixed(2)}M
              </span>
            </div>
          </div>
        </div>

        {/* Right Column: Institutional Risk Heatmap Matrix */}
        <div className="lg:col-span-6 bg-[#161618] border border-[#1F1F21] p-5 space-y-4">
          <div className="border-b border-[#1F1F21] pb-3 flex items-center justify-between">
            <h2 className="text-xs font-bold uppercase tracking-[0.2em] text-white flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#2D5A27]" />
              Institutional Risk Heatmap Matrix
            </h2>
            <div className="flex items-center space-x-2 text-[9px] uppercase font-bold tracking-wider">
              <span className="text-[#2D5A27]">■ Low</span>
              <span className="text-[#F7931A]">■ Med</span>
              <span className="text-[#E04444]">■ High</span>
            </div>
          </div>

          <div className="space-y-2 text-xs">
            {riskCategories.map(cat => (
              <div key={cat.name} className="p-3 bg-[#0F0F10] border border-[#1F1F21] space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white text-xs">{cat.name}</span>
                  <div className="flex items-center space-x-1.5">
                    <span className={`w-2 h-2 rounded-sm ${
                      cat.score === 1 ? 'bg-[#2D5A27]' :
                      cat.score === 2 ? 'bg-[#F7931A]' : 'bg-[#E04444]'
                    }`} />
                    <span className={`text-[9px] font-bold uppercase tracking-wider ${
                      cat.score === 1 ? 'text-[#2D5A27]' :
                      cat.score === 2 ? 'text-[#F7931A]' : 'text-[#E04444]'
                    }`}>
                      {cat.level}
                    </span>
                  </div>
                </div>
                <p className="text-[11px] text-[#777] leading-relaxed">{cat.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
