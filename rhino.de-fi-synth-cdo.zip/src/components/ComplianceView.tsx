// ============================================================================
// RHINO BANK | RHINOQUANT SYNTH-CDO
// Institutional Compliance, Governance, Jurisdictional Rules & Multi-Sig Desk (Sophisticated Dark)
// ============================================================================

import React, { useState } from 'react';
import { 
  SyntheticCDO, 
  UserRole 
} from '../types';
import { 
  Globe, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  KeyRound 
} from 'lucide-react';

interface ComplianceViewProps {
  cdo: SyntheticCDO;
  currentUserRole: UserRole;
}

export const ComplianceView: React.FC<ComplianceViewProps> = ({
  cdo,
  currentUserRole
}) => {
  const [multiSigSigners, setMultiSigSigners] = useState([
    { role: 'Risk Manager', name: 'Alastair Vance (CRO)', signed: true, timestamp: '2026-08-25T07:15:00Z', hash: '0x99a...e401' },
    { role: 'Structurer', name: 'Helena Sterling (Head of Structuring)', signed: true, timestamp: '2026-08-25T07:22:00Z', hash: '0x88b...d312' },
    { role: 'Treasury', name: 'Marcus Thorne (Custody Lead)', signed: true, timestamp: '2026-08-25T07:28:00Z', hash: '0x77c...b223' },
    { role: 'Compliance Officer', name: 'Victoria Cross (Legal & Compliance)', signed: true, timestamp: '2026-08-25T07:35:00Z', hash: '0x66d...a114' },
    { role: 'Administrator', name: 'Rhino HSM Root Enclave', signed: true, timestamp: '2026-08-25T07:40:00Z', hash: '0x55e...9005' }
  ]);

  const [selectedJurisdiction, setSelectedJurisdiction] = useState(cdo.jurisdiction);
  const [investorTier, setInvestorTier] = useState(cdo.investorClass);
  const [signSuccessFeedback, setSignSuccessFeedback] = useState<string | null>(null);

  const handleSignMultiSig = () => {
    setMultiSigSigners(prev =>
      prev.map(s => (s.role === currentUserRole ? { ...s, signed: true, timestamp: new Date().toISOString() } : s))
    );
    setSignSuccessFeedback(`Recorded cryptographic signature from ${currentUserRole} on Multi-Sig Approval Registry.`);
    setTimeout(() => setSignSuccessFeedback(null), 4000);
  };

  const totalSigned = multiSigSigners.filter(s => s.signed).length;

  return (
    <div id="compliance-workspace" className="space-y-6 font-mono">
      {/* Top Banner */}
      <div className="bg-[#161618] border border-[#1F1F21] p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-xs">
            <span className="px-2 py-0.5 border border-[#2D5A27] text-[#2D5A27] font-semibold text-[10px] uppercase tracking-wider">
              Compliance & Governance Desk
            </span>
            <span className="px-2 py-0.5 bg-[#0F0F10] text-[#2D5A27] border border-[#2D5A27]/40 text-[10px] font-bold uppercase tracking-wider">
              Multi-Sig: {totalSigned}/5 Approved
            </span>
            <span className="text-[#555] uppercase text-[10px]">UK FCA & MiFID II Framework</span>
          </div>
          <h1 className="text-base font-bold text-white tracking-tight mt-1.5">
            Jurisdictional Rules, Investor Eligibility & Multi-Signature Governance
          </h1>
          <p className="text-xs text-[#777] mt-0.5">
            Strict Institutional Mandate: Tokenized synthetic structures are restricted to Eligible Counterparties and require 3-of-5 executive signatures.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={handleSignMultiSig}
            className="flex items-center space-x-1.5 px-4 py-2 bg-[#2D5A27] hover:bg-[#346B2D] text-white font-bold text-xs uppercase tracking-[0.2em] transition-colors"
          >
            <KeyRound className="w-3.5 h-3.5" />
            <span>Sign with {currentUserRole.toUpperCase()} Key</span>
          </button>
        </div>
      </div>

      {signSuccessFeedback && (
        <div className="p-3.5 bg-[#2D5A27]/15 border border-[#2D5A27]/30 text-[#2D5A27] text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4" />
          <span>{signSuccessFeedback}</span>
        </div>
      )}

      {/* Main Grid: Multi-Sig Approval Queue vs. Configurable Compliance Rules */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: 3-of-5 Multi-Sig Approval Queue */}
        <div className="lg:col-span-6 bg-[#161618] border border-[#1F1F21] p-5 space-y-4">
          <div className="border-b border-[#1F1F21] pb-3 flex items-center justify-between">
            <h2 className="text-xs font-bold uppercase tracking-[0.2em] text-white flex items-center gap-2">
              <KeyRound className="w-4 h-4 text-[#2D5A27]" />
              3-of-5 Multi-Sig Deal Issuance Queue
            </h2>
            <span className="text-[10px] text-[#555] uppercase">
              Quorum: 3 Signatures Required
            </span>
          </div>

          <div className="space-y-2.5 text-xs">
            {multiSigSigners.map((signer) => (
              <div
                key={signer.name}
                className="p-3.5 bg-[#0F0F10] border border-[#1F1F21] flex items-center justify-between"
              >
                <div className="space-y-0.5">
                  <div className="flex items-center space-x-2">
                    <span className="font-bold text-white text-xs">{signer.name}</span>
                    <span className="text-[9px] px-1.5 py-0.5 bg-[#161618] text-[#888] border border-[#1F1F21] uppercase">
                      {signer.role}
                    </span>
                  </div>
                  <div className="text-[10px] text-[#555] font-mono">
                    Key Hash: {signer.hash} | {new Date(signer.timestamp).toLocaleTimeString('en-GB')} BST
                  </div>
                </div>

                <div>
                  {signer.signed ? (
                    <span className="flex items-center gap-1 text-[#2D5A27] font-bold text-xs uppercase tracking-wider">
                      <CheckCircle2 className="w-4 h-4" />
                      Signed
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 text-[#555] text-xs uppercase tracking-wider">
                      <Clock className="w-4 h-4" />
                      Pending
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column: Configurable Compliance & Jurisdictional Module */}
        <div className="lg:col-span-6 bg-[#161618] border border-[#1F1F21] p-5 space-y-4">
          <div className="border-b border-[#1F1F21] pb-3">
            <h2 className="text-xs font-bold uppercase tracking-[0.2em] text-white flex items-center gap-2">
              <Globe className="w-4 h-4 text-[#2D5A27]" />
              Configurable Jurisdiction & Eligibility Parameters
            </h2>
            <p className="text-[10px] text-[#555] uppercase mt-0.5">
              Dynamic rule enforcement across international regulatory authorities
            </p>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <label className="text-[10px] text-[#555] uppercase font-bold tracking-wider">Governing Jurisdiction & Regulator:</label>
              <select
                value={selectedJurisdiction}
                onChange={e => setSelectedJurisdiction(e.target.value as any)}
                className="w-full mt-1 bg-[#0F0F10] border border-[#1F1F21] rounded-sm px-3 py-1.5 text-xs text-white"
              >
                <option value="UK_FCA">United Kingdom (FCA / PRA - English Law)</option>
                <option value="EU_ESMA">European Union (ESMA - MiFID II Securitisation)</option>
                <option value="ADGM_FSRA">Abu Dhabi Global Market (FSRA - Digital Securities)</option>
                <option value="FINMA_CH">Switzerland (FINMA - DLT Act Securitisation)</option>
                <option value="US_CFTC_SEC">United States (CFTC / SEC - QIB Reg S / 144A Only)</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] text-[#555] uppercase font-bold tracking-wider">Investor Categorization Tier:</label>
              <select
                value={investorTier}
                onChange={e => setInvestorTier(e.target.value as any)}
                className="w-full mt-1 bg-[#0F0F10] border border-[#1F1F21] rounded-sm px-3 py-1.5 text-xs text-white"
              >
                <option value="Eligible_Counterparty">Eligible Counterparty (ECP) - Tier 1 Institutional Only</option>
                <option value="Professional_Only">Professional Clients (MiFID II Annex II)</option>
                <option value="Institutional_DeFi">Institutional DeFi Permissioned Vault Participant</option>
              </select>
            </div>

            <div className="p-3.5 bg-[#0F0F10] border border-[#1F1F21] space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[#888]">Sanctions Screening & PEP Verification:</span>
                <span className="text-[#2D5A27] font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  OFAC / UK HMT CLEARED
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[#888]">ERC-3643 Secondary Whitelist Transfer Lock:</span>
                <span className="text-[#2D5A27] font-bold">ENFORCED</span>
              </div>
            </div>

            {/* Legal Notice */}
            <div className="p-3.5 bg-[#0F0F10] border border-[#1F1F21] text-[#888] text-[11px] space-y-1">
              <div className="font-bold flex items-center gap-1 text-[#F7931A]">
                <AlertTriangle className="w-3.5 h-3.5 text-[#F7931A]" />
                INSTITUTIONAL LEGAL NOTICE:
              </div>
              <p className="leading-relaxed text-[#777] text-[10px]">
                Synthetic CDO notes reference underlying credit derivatives and do NOT confer equity or debt ownership in reference entities. Digital asset collateral is held under English trust and custodial escrow.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
