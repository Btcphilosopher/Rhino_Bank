// ============================================================================
// RHINO BANK | RHINOQUANT SYNTH-CDO
// Synthetic Reference Credit Portfolio Engine & 1,000+ Asset Explorer (Sophisticated Dark)
// ============================================================================

import React, { useState, useMemo } from 'react';
import { ReferenceAsset } from '../types';
import { 
  Search, 
  PieChart, 
  ShieldCheck, 
  ChevronRight, 
  ChevronLeft 
} from 'lucide-react';

interface PortfolioViewProps {
  portfolio: ReferenceAsset[];
  portfolioName: string;
  currencySymbol: string;
}

export const PortfolioView: React.FC<PortfolioViewProps> = ({
  portfolio,
  portfolioName,
  currencySymbol
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRating, setSelectedRating] = useState<string>('ALL');
  const [selectedSector, setSelectedSector] = useState<string>('ALL');
  const [selectedAssetClass, setSelectedAssetClass] = useState<string>('ALL');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 20;

  // Filtered Assets
  const filteredAssets = useMemo(() => {
    return portfolio.filter(asset => {
      const matchesSearch = 
        asset.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        asset.ticker.toLowerCase().includes(searchTerm.toLowerCase()) ||
        asset.id.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesRating = selectedRating === 'ALL' || asset.rating === selectedRating;
      const matchesSector = selectedSector === 'ALL' || asset.sector === selectedSector;
      const matchesAssetClass = selectedAssetClass === 'ALL' || asset.assetClass === selectedAssetClass;

      return matchesSearch && matchesRating && matchesSector && matchesAssetClass;
    });
  }, [portfolio, searchTerm, selectedRating, selectedSector, selectedAssetClass]);

  // Aggregation Metrics
  const metrics = useMemo(() => {
    const totalNotional = portfolio.reduce((s, a) => s + a.notional, 0);
    const weightedSpread = portfolio.reduce((s, a) => s + (a.spreadBps * a.notional), 0) / totalNotional;
    const weightedPd = portfolio.reduce((s, a) => s + (a.pd * a.notional), 0) / totalNotional;
    const weightedLgd = portfolio.reduce((s, a) => s + (a.lgd * a.notional), 0) / totalNotional;

    const sectorCounts: Record<string, number> = {};
    const ratingCounts: Record<string, number> = {};

    portfolio.forEach(a => {
      sectorCounts[a.sector] = (sectorCounts[a.sector] || 0) + a.notional;
      ratingCounts[a.rating] = (ratingCounts[a.rating] || 0) + a.notional;
    });

    return {
      totalNotional,
      weightedSpread,
      weightedPd,
      weightedLgd,
      sectorCounts,
      ratingCounts
    };
  }, [portfolio]);

  const totalPages = Math.ceil(filteredAssets.length / itemsPerPage);
  const paginatedAssets = filteredAssets.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  return (
    <div id="portfolio-workspace" className="space-y-6 font-mono">
      {/* Portfolio Header & Summary */}
      <div className="bg-[#161618] border border-[#1F1F21] p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-xs">
            <span className="px-2 py-0.5 border border-[#2D5A27] text-[#2D5A27] font-semibold text-[10px] uppercase tracking-wider">
              Synthetic Reference Portfolio
            </span>
            <span className="text-[#555] uppercase text-[10px]">
              {portfolio.length} Curated Institutional Exposures
            </span>
          </div>
          <h1 className="text-base font-bold text-white tracking-tight mt-1.5">{portfolioName}</h1>
          <p className="text-xs text-[#777] mt-0.5">
            Multi-Sector corporate loans, bonds, sovereign debt, CRE and DeFi prime facilities.
          </p>
        </div>

        {/* Aggregate KPI Badges */}
        <div className="flex flex-wrap items-center gap-3 text-xs">
          <div className="px-3.5 py-2 bg-[#0F0F10] border border-[#1F1F21]">
            <div className="text-[9px] text-[#555] uppercase font-bold tracking-wider">Total Notional</div>
            <div className="text-sm font-light text-white">
              {currencySymbol}{(metrics.totalNotional / 1000000).toFixed(0)}M
            </div>
          </div>
          <div className="px-3.5 py-2 bg-[#0F0F10] border border-[#1F1F21]">
            <div className="text-[9px] text-[#555] uppercase font-bold tracking-wider">Weighted Spread</div>
            <div className="text-sm font-light text-[#2D5A27]">
              {metrics.weightedSpread.toFixed(1)} bps
            </div>
          </div>
          <div className="px-3.5 py-2 bg-[#0F0F10] border border-[#1F1F21]">
            <div className="text-[9px] text-[#555] uppercase font-bold tracking-wider">Weighted PD</div>
            <div className="text-sm font-light text-[#A0A0A0]">
              {(metrics.weightedPd * 100).toFixed(2)}% / yr
            </div>
          </div>
          <div className="px-3.5 py-2 bg-[#0F0F10] border border-[#1F1F21]">
            <div className="text-[9px] text-[#555] uppercase font-bold tracking-wider">Weighted LGD</div>
            <div className="text-sm font-light text-[#888]">
              {(metrics.weightedLgd * 100).toFixed(1)}%
            </div>
          </div>
        </div>
      </div>

      {/* Sector & Rating Breakdown Bars */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Rating Dispersion */}
        <div className="bg-[#161618] border border-[#1F1F21] p-5 space-y-3">
          <div className="text-xs font-bold uppercase tracking-wider text-white flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-[#2D5A27]" />
              Credit Rating Dispersion
            </span>
            <span className="text-[10px] text-[#555] font-normal uppercase">S&P / Moody's Equiv.</span>
          </div>

          <div className="grid grid-cols-6 gap-2 pt-1">
            {['AAA', 'AA', 'A', 'BBB', 'BB', 'B'].map(rating => {
              const notional = metrics.ratingCounts[rating] || 0;
              const pct = (notional / metrics.totalNotional) * 100;
              return (
                <div key={rating} className="bg-[#0F0F10] border border-[#1F1F21] p-2.5 text-center">
                  <div className={`text-xs font-bold ${
                    rating === 'AAA' ? 'text-[#2D5A27]' :
                    rating === 'AA' ? 'text-[#26A17B]' :
                    rating === 'A' ? 'text-[#A0A0A0]' :
                    rating === 'BBB' ? 'text-[#F7931A]' : 'text-[#E04444]'
                  }`}>
                    {rating}
                  </div>
                  <div className="text-xs text-white font-semibold mt-1">{pct.toFixed(1)}%</div>
                  <div className="text-[9px] text-[#555] mt-0.5">{currencySymbol}{(notional / 1000000).toFixed(0)}M</div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Sector Exposure Breakdown (Styled with Design HTML pattern) */}
        <div className="bg-[#161618] border border-[#1F1F21] p-5 space-y-3">
          <div className="text-xs font-bold uppercase tracking-wider text-white flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <PieChart className="w-3.5 h-3.5 text-[#2D5A27]" />
              Credit Exposure Distribution
            </span>
            <span className="text-[10px] text-[#555] font-normal uppercase">Sector Weights</span>
          </div>

          <div className="space-y-2 pt-1">
            {(Object.entries(metrics.sectorCounts) as [string, number][])
              .sort((a, b) => (b[1] as number) - (a[1] as number))
              .slice(0, 4)
              .map(([sector, notional]) => {
                const numNotional = Number(notional);
                const pct = (numNotional / metrics.totalNotional) * 100;
                return (
                  <div key={sector} className="space-y-1">
                    <div className="flex justify-between text-[11px] text-[#888]">
                      <span className="truncate max-w-[220px]">{sector}</span>
                      <span className="text-white font-semibold">{pct.toFixed(1)}% ({currencySymbol}{(numNotional / 1000000).toFixed(0)}M)</span>
                    </div>
                    <div className="h-1.5 w-full bg-[#0F0F10] border border-[#1F1F21] overflow-hidden">
                      <div style={{ width: `${pct}%` }} className="bg-[#2D5A27] h-full" />
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      </div>

      {/* Filter Controls & Search */}
      <div className="bg-[#161618] border border-[#1F1F21] p-3.5 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center space-x-2 flex-1 min-w-[240px]">
          <div className="relative w-full max-w-sm">
            <Search className="w-3.5 h-3.5 text-[#555] absolute left-2.5 top-2.5" />
            <input
              type="text"
              placeholder="Search by company name, ticker or ID..."
              value={searchTerm}
              onChange={e => { setSearchTerm(e.target.value); setCurrentPage(1); }}
              className="w-full bg-[#0F0F10] border border-[#1F1F21] rounded-sm pl-8 pr-3 py-1.5 text-xs text-white placeholder-[#555] focus:outline-none focus:border-[#2D5A27]"
            />
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Rating Filter */}
          <select
            value={selectedRating}
            onChange={e => { setSelectedRating(e.target.value); setCurrentPage(1); }}
            className="bg-[#0F0F10] border border-[#1F1F21] rounded-sm px-2.5 py-1.5 text-xs text-[#D1D1D1] focus:outline-none focus:border-[#2D5A27]"
          >
            <option value="ALL">All Ratings</option>
            <option value="AAA">Rating AAA</option>
            <option value="AA">Rating AA</option>
            <option value="A">Rating A</option>
            <option value="BBB">Rating BBB</option>
            <option value="BB">Rating BB</option>
            <option value="B">Rating B</option>
          </select>

          {/* Sector Filter */}
          <select
            value={selectedSector}
            onChange={e => { setSelectedSector(e.target.value); setCurrentPage(1); }}
            className="bg-[#0F0F10] border border-[#1F1F21] rounded-sm px-2.5 py-1.5 text-xs text-[#D1D1D1] focus:outline-none focus:border-[#2D5A27]"
          >
            <option value="ALL">All Sectors</option>
            <option value="Technology">Technology</option>
            <option value="Financials">Financials</option>
            <option value="Energy & Utilities">Energy & Utilities</option>
            <option value="Healthcare">Healthcare</option>
            <option value="Consumer & Retail">Consumer & Retail</option>
            <option value="Commercial Real Estate">Commercial Real Estate</option>
            <option value="Sovereign & Supranational">Sovereign & Supranational</option>
            <option value="Digital Asset & DeFi Prime">Digital Asset & DeFi Prime</option>
          </select>

          {/* Asset Class */}
          <select
            value={selectedAssetClass}
            onChange={e => { setSelectedAssetClass(e.target.value); setCurrentPage(1); }}
            className="bg-[#0F0F10] border border-[#1F1F21] rounded-sm px-2.5 py-1.5 text-xs text-[#D1D1D1] focus:outline-none focus:border-[#2D5A27]"
          >
            <option value="ALL">All Asset Classes</option>
            <option value="Corporate Bond">Corporate Bond</option>
            <option value="Corporate Loan">Corporate Loan</option>
            <option value="Sovereign Debt">Sovereign Debt</option>
            <option value="Commercial Real Estate (CRE)">Commercial Real Estate</option>
            <option value="Institutional DeFi Lending">Institutional DeFi Lending</option>
          </select>
        </div>
      </div>

      {/* Asset Table Matrix */}
      <div className="bg-[#161618] border border-[#1F1F21] overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="bg-[#0F0F10] border-b border-[#1F1F21] text-[#555] text-[10px] uppercase">
                <th className="py-2.5 px-3 font-semibold">ID / Ticker</th>
                <th className="py-2.5 px-3 font-semibold">Reference Entity</th>
                <th className="py-2.5 px-2 font-semibold">Rating</th>
                <th className="py-2.5 px-3 font-semibold">Sector</th>
                <th className="py-2.5 px-3 font-semibold">Geography</th>
                <th className="py-2.5 px-3 font-semibold text-right">Notional</th>
                <th className="py-2.5 px-3 font-semibold text-right">Spread</th>
                <th className="py-2.5 px-3 font-semibold text-right">PD (Annual)</th>
                <th className="py-2.5 px-3 font-semibold text-right">LGD</th>
                <th className="py-2.5 px-3 font-semibold text-right">Beta (ρ)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1F1F21] text-[#D1D1D1]">
              {paginatedAssets.map(asset => (
                <tr key={asset.id} className="hover:bg-[#1A1A1C] transition-colors">
                  <td className="py-2.5 px-3">
                    <div className="font-bold text-white">{asset.ticker}</div>
                    <div className="text-[9px] text-[#555]">{asset.id}</div>
                  </td>
                  <td className="py-2.5 px-3">
                    <div className="font-semibold text-white truncate max-w-[200px]">{asset.name}</div>
                    <div className="text-[10px] text-[#777]">{asset.assetClass}</div>
                  </td>
                  <td className="py-2.5 px-2">
                    <span className={`px-1.5 py-0.5 rounded-sm text-[10px] font-bold border ${
                      asset.rating === 'AAA' ? 'bg-[#2D5A27]/20 text-[#2D5A27] border-[#2D5A27]/40' :
                      asset.rating === 'AA' ? 'bg-[#26A17B]/20 text-[#26A17B] border-[#26A17B]/40' :
                      asset.rating === 'A' ? 'bg-[#555]/20 text-[#D1D1D1] border-[#555]/40' :
                      asset.rating === 'BBB' ? 'bg-[#F7931A]/20 text-[#F7931A] border-[#F7931A]/40' :
                      'bg-[#E04444]/20 text-[#E04444] border-[#E04444]/40'
                    }`}>
                      {asset.rating}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-[#888] truncate max-w-[140px]">{asset.sector}</td>
                  <td className="py-2.5 px-3 text-[#777]">{asset.geography}</td>
                  <td className="py-2.5 px-3 text-right font-semibold text-white">
                    {currencySymbol}{(asset.notional / 1000000).toFixed(2)}M
                  </td>
                  <td className="py-2.5 px-3 text-right text-[#2D5A27] font-semibold">
                    {asset.spreadBps} bps
                  </td>
                  <td className="py-2.5 px-3 text-right text-[#A0A0A0]">
                    {(asset.pd * 100).toFixed(3)}%
                  </td>
                  <td className="py-2.5 px-3 text-right text-[#888]">
                    {(asset.lgd * 100).toFixed(1)}%
                  </td>
                  <td className="py-2.5 px-3 text-right text-[#555]">
                    {asset.correlationBeta.toFixed(2)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination Footer */}
        <div className="bg-[#0F0F10] px-4 py-2.5 border-t border-[#1F1F21] flex items-center justify-between text-xs text-[#555]">
          <div>
            Showing <span className="text-white font-bold">{((currentPage - 1) * itemsPerPage) + 1}</span> to{' '}
            <span className="text-white font-bold">{Math.min(currentPage * itemsPerPage, filteredAssets.length)}</span> of{' '}
            <span className="text-white font-bold">{filteredAssets.length}</span> assets
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="p-1 rounded-sm bg-[#161618] hover:bg-[#1A1A1C] disabled:opacity-30 disabled:cursor-not-allowed border border-[#1F1F21] text-[#D1D1D1]"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="font-bold text-white px-2">Page {currentPage} of {totalPages}</span>
            <button
              onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="p-1 rounded-sm bg-[#161618] hover:bg-[#1A1A1C] disabled:opacity-30 disabled:cursor-not-allowed border border-[#1F1F21] text-[#D1D1D1]"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
