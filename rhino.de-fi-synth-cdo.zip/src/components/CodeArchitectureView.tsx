// ============================================================================
// RHINO BANK | RHINOQUANT SYNTH-CDO
// Architecture Repository: Rust Kernels, R Quant Models, Solidity & SQL Schema (Sophisticated Dark)
// ============================================================================

import React, { useState } from 'react';
import { CODE_MODULES } from '../data/rustAndRCode';
import { 
  FileCode2, 
  Copy, 
  Check, 
  Cpu, 
  Database, 
  ShieldCheck, 
  Terminal 
} from 'lucide-react';

export const CodeArchitectureView: React.FC = () => {
  const [selectedModuleId, setSelectedModuleId] = useState<string>(CODE_MODULES[0].id);
  const [copied, setCopied] = useState(false);

  const currentModule = CODE_MODULES.find(m => m.id === selectedModuleId) || CODE_MODULES[0];

  const handleCopy = () => {
    navigator.clipboard.writeText(currentModule.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div id="architecture-workspace" className="space-y-6 font-mono">
      {/* Top Banner */}
      <div className="bg-[#161618] border border-[#1F1F21] p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-xs">
            <span className="px-2 py-0.5 border border-[#2D5A27] text-[#2D5A27] font-semibold text-[10px] uppercase tracking-wider">
              Quantitative Systems Repository
            </span>
            <span className="text-[#555] uppercase text-[10px]">Production-Grade Rust, R, Solidity & SQL</span>
          </div>
          <h1 className="text-base font-bold text-white tracking-tight mt-1.5">
            Institutional Quantitative Core & Smart Contract Architecture
          </h1>
          <p className="text-xs text-[#777] mt-0.5">
            Full reference implementations of the SIMD Rust Monte Carlo kernel, R copula analytical models, ERC-3643 contracts, and PostgreSQL schema.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={handleCopy}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-[#0F0F10] hover:bg-[#1A1A1C] text-[#888] hover:text-white border border-[#1F1F21] text-xs uppercase tracking-wider transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-[#2D5A27]" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy Source Code'}</span>
          </button>
        </div>
      </div>

      {/* Codebase Selector Tabs */}
      <div className="flex flex-wrap gap-2 p-2 bg-[#161618] border border-[#1F1F21] text-xs">
        {CODE_MODULES.map(mod => {
          let Icon = FileCode2;
          if (mod.language === 'rust') Icon = Cpu;
          else if (mod.language === 'r') Icon = Terminal;
          else if (mod.language === 'sql') Icon = Database;
          else if (mod.language === 'solidity') Icon = ShieldCheck;

          return (
            <button
              key={mod.id}
              onClick={() => { setSelectedModuleId(mod.id); setCopied(false); }}
              className={`flex items-center space-x-2 px-3 py-1.5 transition-colors uppercase text-[11px] tracking-wider ${
                selectedModuleId === mod.id
                  ? 'bg-[#2D5A27] text-white font-bold'
                  : 'bg-[#0F0F10] text-[#888] hover:bg-[#1A1A1C] hover:text-white border border-[#1F1F21]'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{mod.name.split('-')[0].trim()}</span>
            </button>
          );
        })}
      </div>

      {/* Code Display Card */}
      <div className="bg-[#161618] border border-[#1F1F21] overflow-hidden">
        {/* Code Header Bar */}
        <div className="bg-[#0F0F10] px-4 py-3 border-b border-[#1F1F21] flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center space-x-2">
            <FileCode2 className="w-4 h-4 text-[#2D5A27]" />
            <span className="font-bold text-white tracking-wider">{currentModule.filePath}</span>
            <span className="px-1.5 py-0.5 bg-[#161618] text-[#888] text-[9px] border border-[#1F1F21] uppercase">
              {currentModule.language}
            </span>
          </div>
          <p className="text-[11px] text-[#777] max-w-xl truncate">{currentModule.description}</p>
        </div>

        {/* Code Block Content */}
        <div className="p-4 bg-[#0A0A0B] overflow-x-auto max-h-[580px] overflow-y-auto">
          <pre className="text-[11px] leading-relaxed text-[#D1D1D1] font-mono select-all whitespace-pre">
            {currentModule.code}
          </pre>
        </div>

        {/* Footer info */}
        <div className="bg-[#0F0F10] px-4 py-2.5 border-t border-[#1F1F21] flex items-center justify-between text-[10px] text-[#555] uppercase tracking-wider">
          <span>Target: x86_64-unknown-linux-gnu / AVX-512 SIMD Vectorized</span>
          <span>Rhino Bank Quantitative Systems Group</span>
        </div>
      </div>
    </div>
  );
};
