// ============================================================================
// RHINO BANK | RHINOQUANT SYNTH-CDO
// Sophisticated Dark Top Terminal Bar, Live Oracle Consensus & Role Enclave
// ============================================================================

import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Layers, 
  Activity, 
  Cpu, 
  Lock, 
  UserCheck, 
  ChevronDown, 
  Plus, 
  CheckCircle2
} from 'lucide-react';
import { SyntheticCDO, UserRole, OraclePriceFeed } from '../types';
import { getInitialDemoCDOs } from '../services/portfolioData';

interface HeaderProps {
  activeCDO: SyntheticCDO;
  onSelectCDO?: (cdo: SyntheticCDO) => void;
  currentUserRole: UserRole;
  setCurrentUserRole: (role: UserRole) => void;
  oraclePrices: OraclePriceFeed;
  activeTab?: string;
  setActiveTab?: (tab: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeCDO,
  onSelectCDO,
  currentUserRole,
  setCurrentUserRole,
  oraclePrices
}) => {
  const [timeLondon, setTimeLondon] = useState<string>('');
  const [isRoleDropdownOpen, setIsRoleDropdownOpen] = useState(false);
  const [isCdoDropdownOpen, setIsCdoDropdownOpen] = useState(false);
  const allCDOs = getInitialDemoCDOs();

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeLondon(
        now.toLocaleTimeString('en-GB', {
          timeZone: 'Europe/London',
          hour12: false,
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit'
        })
      );
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const allRoles: UserRole[] = [
    'Structurer',
    'Trader',
    'Risk Manager',
    'Treasury',
    'Compliance Officer',
    'Administrator'
  ];

  return (
    <header id="rhino-header" className="h-16 border-b border-[#1F1F21] flex items-center justify-between px-6 bg-[#0F0F10] text-[#D1D1D1] select-none shrink-0 z-30 font-mono">
      {/* Active Deal Identity & Grade Badge */}
      <div className="flex items-center gap-4">
        {/* Deal Selector Dropdown */}
        <div className="relative">
          <button
            id="cdo-selector-btn"
            onClick={() => setIsCdoDropdownOpen(!isCdoDropdownOpen)}
            className="flex items-center gap-2 px-3 py-1.5 bg-[#161618] hover:bg-[#1A1A1C] border border-[#1F1F21] rounded text-xs transition-colors"
          >
            <Layers className="w-3.5 h-3.5 text-[#2D5A27]" />
            <div className="text-left">
              <span className="text-[10px] text-[#555] uppercase tracking-widest font-semibold block leading-none">
                Structure //
              </span>
              <span className="text-xs text-white font-bold tracking-tight">
                {activeCDO.dealCode}
              </span>
            </div>
            <ChevronDown className="w-3 h-3 text-[#666] ml-1" />
          </button>

          {isCdoDropdownOpen && (
            <div className="absolute left-0 mt-1.5 w-80 bg-[#161618] border border-[#1F1F21] rounded shadow-2xl py-1 z-50">
              <div className="px-3 py-1.5 text-[9px] uppercase font-bold text-[#555] tracking-widest border-b border-[#1F1F21]">
                Active Synthetic CDO Deals
              </div>
              {allCDOs.map(cdo => (
                <button
                  key={cdo.id}
                  onClick={() => {
                    if (onSelectCDO) onSelectCDO(cdo);
                    setIsCdoDropdownOpen(false);
                  }}
                  className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between hover:bg-[#1A1A1C] transition-colors ${
                    cdo.id === activeCDO.id ? 'bg-[#1A1A1C] text-[#2D5A27] font-bold border-l-2 border-[#2D5A27]' : 'text-[#D1D1D1]'
                  }`}
                >
                  <div>
                    <div className="font-bold text-white">{cdo.dealCode}</div>
                    <div className="text-[10px] text-[#777] truncate max-w-[200px]">{cdo.name}</div>
                  </div>
                  <span className="text-[10px] font-mono px-1.5 py-0.5 bg-[#0F0F10] border border-[#1F1F21] text-[#999]">
                    {cdo.currency === 'GBP' ? '£' : '$'}{(cdo.totalNotional / 1000000).toFixed(0)}M
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="hidden sm:flex items-center gap-2">
          <div className="px-2 py-0.5 border border-[#2D5A27] text-[#2D5A27] text-[9px] rounded-sm uppercase tracking-wider font-semibold">
            Institutional Grade
          </div>
          <span className="text-xs text-[#555] font-mono">
            {activeCDO.name}
          </span>
        </div>
      </div>

      {/* Live Market Feeds & GMT Clock */}
      <div className="flex items-center gap-5 text-[11px] font-mono">
        <div className="hidden md:flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <span className="text-[#555]">USDT:</span>
            <span className="text-[#26A17B] font-bold">${oraclePrices.usdtUsd.toFixed(4)}</span>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-[#555]">BTC:</span>
            <span className="text-[#F7931A] font-bold">${oraclePrices.btcUsd.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
          </div>

          <div className="hidden lg:flex items-center gap-1.5">
            <span className="text-[#555]">SONIA:</span>
            <span className="text-white font-medium">{oraclePrices.soniaRatePct.toFixed(2)}%</span>
          </div>

          <div className="hidden xl:flex items-center gap-1.5">
            <span className="text-[#555]">CDX:</span>
            <span className="text-white font-medium">{oraclePrices.cdxSpreadBps.toFixed(1)} bps</span>
          </div>
        </div>

        {/* London Clock */}
        <div className="text-white font-mono text-xs bg-[#161618] px-2.5 py-1 border border-[#1F1F21] rounded-sm flex items-center gap-1.5">
          <Activity className="w-3 h-3 text-[#2D5A27] animate-pulse" />
          <span>{timeLondon || '14:02:11'} GMT</span>
        </div>

        {/* User Role Switcher */}
        <div className="relative">
          <button
            id="user-role-btn"
            onClick={() => setIsRoleDropdownOpen(!isRoleDropdownOpen)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-sm bg-[#161618] hover:bg-[#1A1A1C] border border-[#1F1F21] text-xs font-mono text-white transition-colors"
          >
            <UserCheck className="w-3.5 h-3.5 text-[#2D5A27]" />
            <span className="font-semibold">{currentUserRole}</span>
            <ChevronDown className="w-3 h-3 text-[#666]" />
          </button>

          {isRoleDropdownOpen && (
            <div className="absolute right-0 mt-1.5 w-48 bg-[#161618] border border-[#1F1F21] rounded-sm shadow-2xl py-1 z-50">
              <div className="px-3 py-1.5 text-[9px] uppercase font-bold text-[#555] tracking-widest border-b border-[#1F1F21]">
                Switch Access Clearance
              </div>
              {allRoles.map(role => (
                <button
                  key={role}
                  onClick={() => {
                    setCurrentUserRole(role);
                    setIsRoleDropdownOpen(false);
                  }}
                  className={`w-full text-left px-3 py-1.5 text-xs flex items-center justify-between hover:bg-[#1A1A1C] transition-colors ${
                    role === currentUserRole ? 'bg-[#1A1A1C] text-[#2D5A27] font-bold border-l-2 border-[#2D5A27]' : 'text-[#D1D1D1]'
                  }`}
                >
                  <span>{role}</span>
                  {role === currentUserRole && <CheckCircle2 className="w-3 h-3 text-[#2D5A27]" />}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
