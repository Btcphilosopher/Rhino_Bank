// ============================================================================
// RHINO BANK | RHINOQUANT SYNTH-CDO
// Gaussian Copula Engine & High-Performance Monte Carlo Simulation (Sophisticated Dark)
// ============================================================================

import React, { useState } from 'react';
import { 
  SyntheticCDO, 
  ReferenceAsset, 
  MonteCarloResult 
} from '../types';
import { runMonteCarloSimulation } from '../services/quantEngine';
import { 
  Play, 
  Cpu, 
  Activity, 
  TrendingUp, 
  ShieldAlert, 
  Sliders, 
  FileCode2, 
  Layers 
} from 'lucide-react';

interface MonteCarloViewProps {
  cdo: SyntheticCDO;
  portfolio: ReferenceAsset[];
  currencySymbol: string;
}

export const MonteCarloView: React.FC<MonteCarloViewProps> = ({
  cdo,
  portfolio,
  currencySymbol
}) => {
  const [numScenarios, setNumScenarios] = useState<number>(50000);
  const [correlationRho, setCorrelationRho] = useState<number>(cdo.systematicCorrelation);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [simulationResult, setSimulationResult] = useState<MonteCarloResult>(() =>
    runMonteCarloSimulation(portfolio, cdo, 25000, cdo.systematicCorrelation)
  );

  const handleRunSimulation = () => {
    setIsSimulating(true);
    setTimeout(() => {
      const res = runMonteCarloSimulation(portfolio, cdo, numScenarios, correlationRho);
      setSimulationResult(res);
      setIsSimulating(false);
    }, 150);
  };

  const totalNotional = cdo.totalNotional;

  return (
    <div id="monte-carlo-workspace" className="space-y-6 font-mono">
      {/* Simulation Control Deck */}
      <div className="bg-[#161618] border border-[#1F1F21] p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between border-b border-[#1F1F21] pb-3 gap-3">
          <div>
            <div className="flex items-center space-x-2 text-xs">
              <span className="px-2 py-0.5 border border-[#2D5A27] text-[#2D5A27] font-semibold text-[10px] uppercase tracking-wider">
                Quantitative Copula Core
              </span>
              <span className="text-[#555] uppercase text-[10px]">
                1-Factor Gaussian Copula | Li (2000) Factor Model
              </span>
            </div>
            <h1 className="text-base font-bold text-white tracking-tight mt-1.5">
              Monte Carlo Portfolio Loss & Tail-Risk Simulation
            </h1>
          </div>

          <div className="flex items-center space-x-3">
            <div className="flex items-center space-x-1.5 px-3 py-1.5 bg-[#0F0F10] border border-[#1F1F21] text-xs text-[#888]">
              <Cpu className="w-3.5 h-3.5 text-[#2D5A27]" />
              <span>Rust SIMD Kernel: <strong className="text-[#2D5A27]">OPTIMIZED</strong></span>
            </div>

            <button
              onClick={handleRunSimulation}
              disabled={isSimulating}
              className="flex items-center space-x-2 px-4 py-1.5 bg-[#2D5A27] hover:bg-[#346B2D] text-white font-bold text-xs uppercase tracking-[0.2em] transition-colors shadow-sm disabled:opacity-50"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>{isSimulating ? 'SIMULATING...' : `RUN ${numScenarios.toLocaleString()} PATHS`}</span>
            </button>
          </div>
        </div>

        {/* Interactive Parameter Controls */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Correlation Rho Slider */}
          <div className="bg-[#0F0F10] border border-[#1F1F21] p-4 space-y-2.5">
            <div className="flex items-center justify-between text-xs">
              <span className="text-[#888] uppercase text-[10px] font-bold tracking-wider flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-[#2D5A27]" />
                Systematic Asset Correlation (ρ):
              </span>
              <span className="text-[#2D5A27] font-bold text-sm">
                {(correlationRho * 100).toFixed(0)}%
              </span>
            </div>
            <input
              type="range"
              min="0.05"
              max="0.80"
              step="0.01"
              value={correlationRho}
              onChange={e => setCorrelationRho(Number(e.target.value))}
              className="w-full h-1.5 bg-[#1F1F21] rounded appearance-none cursor-pointer accent-[#2D5A27]"
            />
            <div className="flex justify-between text-[9px] text-[#555] uppercase">
              <span>5% (Idiosyncratic)</span>
              <span>30% (Baseline IG)</span>
              <span>55% (High Stress)</span>
              <span>80% (Systemic Crisis)</span>
            </div>
          </div>

          {/* Scenario Count & Batch Size */}
          <div className="bg-[#0F0F10] border border-[#1F1F21] p-4 space-y-2.5">
            <div className="text-xs text-[#888] uppercase text-[10px] font-bold tracking-wider flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 text-[#2D5A27]" />
                Monte Carlo Sample Size:
              </span>
              <span className="text-[#555]">
                Kernel Time: <strong className="text-white">{simulationResult.executionTimeMs} ms</strong>
              </span>
            </div>
            <div className="grid grid-cols-4 gap-2">
              {[10000, 25000, 50000, 100000].map(count => (
                <button
                  key={count}
                  onClick={() => setNumScenarios(count)}
                  className={`py-1.5 text-xs text-center border transition-colors ${
                    numScenarios === count
                      ? 'bg-[#2D5A27]/20 border-[#2D5A27] text-[#2D5A27] font-bold'
                      : 'bg-[#161618] border-[#1F1F21] text-[#888] hover:bg-[#1A1A1C] hover:text-white'
                  }`}
                >
                  {(count / 1000).toFixed(0)}k Paths
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Top 4 Tail-Risk KPI Badges */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#161618] border border-[#1F1F21] p-4">
          <div className="text-[10px] text-[#555] uppercase font-bold tracking-wider mb-1 flex items-center justify-between">
            <span>Expected Loss (Mean)</span>
            <TrendingUp className="w-3.5 h-3.5 text-[#2D5A27]" />
          </div>
          <div className="text-lg font-light text-white tracking-tight">
            {currencySymbol}{(simulationResult.meanPortfolioLoss / 1000000).toFixed(2)}M
          </div>
          <div className="text-[10px] text-[#555] mt-1">
            {(simulationResult.meanPortfolioLossPct * 100).toFixed(3)}% of Total Notional
          </div>
        </div>

        <div className="bg-[#161618] border border-[#1F1F21] p-4">
          <div className="text-[10px] text-[#555] uppercase font-bold tracking-wider mb-1 flex items-center justify-between">
            <span>99.0% VaR (1-in-100Y)</span>
            <ShieldAlert className="w-3.5 h-3.5 text-[#F7931A]" />
          </div>
          <div className="text-lg font-light text-[#F7931A] tracking-tight">
            {currencySymbol}{(simulationResult.var99PortfolioLoss / 1000000).toFixed(2)}M
          </div>
          <div className="text-[10px] text-[#555] mt-1">
            {((simulationResult.var99PortfolioLoss / totalNotional) * 100).toFixed(2)}% of Portfolio
          </div>
        </div>

        <div className="bg-[#161618] border border-[#1F1F21] p-4">
          <div className="text-[10px] text-[#555] uppercase font-bold tracking-wider mb-1 flex items-center justify-between">
            <span>99.9% Basel III VaR</span>
            <ShieldAlert className="w-3.5 h-3.5 text-[#E04444]" />
          </div>
          <div className="text-lg font-light text-[#E04444] tracking-tight">
            {currencySymbol}{(simulationResult.var999PortfolioLoss / 1000000).toFixed(2)}M
          </div>
          <div className="text-[10px] text-[#555] mt-1">
            {((simulationResult.var999PortfolioLoss / totalNotional) * 100).toFixed(2)}% Economic Capital Basis
          </div>
        </div>

        <div className="bg-[#161618] border border-[#1F1F21] p-4">
          <div className="text-[10px] text-[#555] uppercase font-bold tracking-wider mb-1 flex items-center justify-between">
            <span>99.0% Expected Shortfall</span>
            <Activity className="w-3.5 h-3.5 text-[#E04444]" />
          </div>
          <div className="text-lg font-light text-[#E04444] tracking-tight">
            {currencySymbol}{(simulationResult.cvar99PortfolioLoss / 1000000).toFixed(2)}M
          </div>
          <div className="text-[10px] text-[#555] mt-1">
            Tail Shortfall beyond 99th %ile
          </div>
        </div>
      </div>

      {/* Simulated Loss Histogram Chart */}
      <div className="bg-[#161618] border border-[#1F1F21] p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between border-b border-[#1F1F21] pb-3 gap-2">
          <div>
            <h2 className="text-xs font-bold uppercase tracking-[0.2em] text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-[#2D5A27]" />
              Simulated Portfolio Loss Frequency Distribution
            </h2>
            <p className="text-[10px] text-[#555] uppercase mt-0.5">
              Correlated joint default probability distribution across {simulationResult.numScenarios.toLocaleString()} simulated market states (ρ = {(correlationRho * 100).toFixed(0)}%)
            </p>
          </div>
          <div className="flex items-center space-x-3 text-[10px] uppercase">
            <span className="flex items-center gap-1 text-[#E04444]">
              <span className="w-2 h-2 rounded-sm bg-[#E04444]"></span> Equity Zone (0–3%)
            </span>
            <span className="flex items-center gap-1 text-[#F7931A]">
              <span className="w-2 h-2 rounded-sm bg-[#F7931A]"></span> Junior Zone (3–7%)
            </span>
            <span className="flex items-center gap-1 text-[#888]">
              <span className="w-2 h-2 rounded-sm bg-[#555]"></span> Mezzanine Zone (7–15%)
            </span>
          </div>
        </div>

        {/* Graphical Histogram Bars */}
        <div className="grid grid-cols-12 gap-1.5 h-48 items-end pt-4 border-b border-[#1F1F21] px-2">
          {simulationResult.lossHistogramBins.map((bin, idx) => {
            const maxFreq = Math.max(...simulationResult.lossHistogramBins.map(b => b.frequency), 1);
            const heightPct = Math.max(8, (bin.frequency / maxFreq) * 100);

            let barColor = 'bg-[#2D5A27]';
            if (bin.mezzanineImpact > 0) barColor = 'bg-[#555]';
            else if (bin.juniorImpact > 0) barColor = 'bg-[#F7931A]';
            else if (bin.equityImpact > 0) barColor = 'bg-[#E04444]';

            return (
              <div key={idx} className="flex flex-col items-center h-full justify-end group relative">
                {/* Tooltip */}
                <div className="absolute -top-12 bg-[#0F0F10] border border-[#1F1F21] rounded-sm px-2 py-1 text-[10px] text-white opacity-0 group-hover:opacity-100 transition-opacity z-20 pointer-events-none whitespace-nowrap shadow-xl">
                  <div>Loss: {bin.lossRange}</div>
                  <div>Frequency: {bin.frequency}% ({Math.round((bin.frequency / 100) * simulationResult.numScenarios)} paths)</div>
                </div>

                <div className="text-[10px] text-[#555] mb-1 font-semibold">{bin.frequency}%</div>
                <div
                  style={{ height: `${heightPct}%` }}
                  className={`w-full rounded-t-sm ${barColor} opacity-85 group-hover:opacity-100 transition-all duration-300 border-t border-x border-white/10`}
                />
              </div>
            );
          })}
        </div>

        {/* Histogram X-Axis Labels */}
        <div className="grid grid-cols-12 gap-1 text-center text-[9px] text-[#555] uppercase">
          {simulationResult.lossHistogramBins.map((bin, idx) => (
            <div key={idx} className="truncate">{bin.lossRange.split('-')[0]}</div>
          ))}
        </div>
      </div>

      {/* Tranche Statistical Outcomes Table */}
      <div className="bg-[#161618] border border-[#1F1F21] p-5 space-y-4">
        <div className="border-b border-[#1F1F21] pb-3">
          <h2 className="text-xs font-bold uppercase tracking-[0.2em] text-white flex items-center gap-2">
            <FileCode2 className="w-4 h-4 text-[#2D5A27]" />
            Copula-Modeled Tranche Fair Spreads & Attachment Probabilities
          </h2>
          <p className="text-[10px] text-[#555] uppercase mt-0.5">
            Empirical attachment/detachment rates and risk-neutral pricing generated by Monte Carlo iterations
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-[#1F1F21] text-[#555] text-[10px] uppercase">
                <th className="pb-3 font-semibold">Tranche</th>
                <th className="pb-3 font-semibold text-right">Expected Loss</th>
                <th className="pb-3 font-semibold text-right">Loss %</th>
                <th className="pb-3 font-semibold text-right">Attachment Prob</th>
                <th className="pb-3 font-semibold text-right">Detachment Prob</th>
                <th className="pb-3 font-semibold text-right">Fair CDS Spread</th>
                <th className="pb-3 font-semibold text-right">Coupon Paid</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1F1F21] text-[#D1D1D1]">
              {simulationResult.trancheLosses.map(tl => {
                const tranche = cdo.tranches.find(t => t.type === tl.trancheType);
                return (
                  <tr key={tl.trancheType} className="hover:bg-[#1A1A1C] transition-colors">
                    <td className="py-2.5 font-bold flex items-center space-x-2 text-white">
                      <span className={`w-2 h-2 rounded-full ${
                        tl.trancheType === 'EQUITY' ? 'bg-[#E04444]' :
                        tl.trancheType === 'JUNIOR' ? 'bg-[#F7931A]' :
                        tl.trancheType === 'MEZZANINE' ? 'bg-[#888]' : 'bg-[#2D5A27]'
                      }`}></span>
                      <span>{tranche?.name || tl.trancheType}</span>
                    </td>
                    <td className="py-2.5 text-right font-semibold text-white">
                      {currencySymbol}{(tl.expectedLoss / 1000000).toFixed(2)}M
                    </td>
                    <td className="py-2.5 text-right text-[#888]">
                      {(tl.expectedLossPct * 100).toFixed(2)}%
                    </td>
                    <td className="py-2.5 text-right text-[#F7931A] font-semibold">
                      {(tl.attachmentProb * 100).toFixed(2)}%
                    </td>
                    <td className="py-2.5 text-right text-[#E04444]">
                      {(tl.detachmentProb * 100).toFixed(2)}%
                    </td>
                    <td className="py-2.5 text-right font-bold text-[#2D5A27]">
                      {tl.modeledFairSpreadBps} bps
                    </td>
                    <td className="py-2.5 text-right text-[#777]">
                      +{tranche?.couponBps} bps
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
