// ============================================================================
// RHINO BANK | RHINOQUANT SYNTH-CDO
// BTC & USDT Institutional Collateral, Haircuts, Margin & Liquidation Desk (Sophisticated Dark)
// ============================================================================

import React, { useState } from 'react';
import { 
  CollateralPosition 
} from '../types';
import { calculateCollateralHealth } from '../services/quantEngine';
import { 
  Coins, 
  ShieldCheck, 
  AlertTriangle, 
  Flame, 
  PlusCircle, 
  Sliders, 
  Lock, 
  CheckCircle 
} from 'lucide-react';

interface CollateralDeskViewProps {
  collateral: CollateralPosition;
  currencySymbol: string;
  onDepositCollateral: (asset: 'BTC' | 'USDT' | 'FIAT', amount: number) => void;
}

export const CollateralDeskView: React.FC<CollateralDeskViewProps> = ({
  collateral,
  currencySymbol,
  onDepositCollateral
}) => {
  // Local state for interactive haircut testing & price shifts
  const [btcPriceShiftPct, setBtcPriceShiftPct] = useState<number>(0);
  const [btcCustomHaircut, setBtcCustomHaircut] = useState<number>(collateral.btcHaircutPct * 100);
  const [usdtCustomHaircut, setUsdtCustomHaircut] = useState<number>(collateral.usdtHaircutPct * 100);
  const [usdtPriceShiftPct, setUsdtPriceShiftPct] = useState<number>(0);

  // Deposit input
  const [depositAsset, setDepositAsset] = useState<'BTC' | 'USDT' | 'FIAT'>('BTC');
  const [depositAmount, setDepositAmount] = useState<number>(100);
  const [depositFeedback, setDepositFeedback] = useState<string | null>(null);

  // Dynamic valuation calculation
  const liveBtcPrice = collateral.btcPriceUsd * (1 + (btcPriceShiftPct / 100));
  const liveUsdtPrice = collateral.usdtPriceUsd * (1 + (usdtPriceShiftPct / 100));

  const health = calculateCollateralHealth(
    collateral.btcQty,
    liveBtcPrice,
    btcCustomHaircut / 100,
    collateral.usdtQty,
    liveUsdtPrice,
    usdtCustomHaircut / 100,
    collateral.fiatCash,
    collateral.requiredInitialMarginUsd,
    collateral.requiredVariationMarginUsd
  );

  const handleExecuteDeposit = () => {
    onDepositCollateral(depositAsset, depositAmount);
    setDepositFeedback(`Successfully deposited ${depositAmount.toLocaleString()} ${depositAsset} into segregated custodial vault.`);
    setTimeout(() => setDepositFeedback(null), 4000);
  };

  // Color theme for Margin Status
  let statusBadgeColor = 'border-[#2D5A27] text-[#2D5A27] bg-[#2D5A27]/15';
  let gaugeFillColor = 'bg-[#2D5A27]';
  if (health.marginStatus === 'WARNING') {
    statusBadgeColor = 'border-[#F7931A] text-[#F7931A] bg-[#F7931A]/15';
    gaugeFillColor = 'bg-[#F7931A]';
  } else if (health.marginStatus === 'MARGIN_CALL') {
    statusBadgeColor = 'border-[#F7931A] text-[#F7931A] bg-[#F7931A]/15';
    gaugeFillColor = 'bg-[#F7931A]';
  } else if (health.marginStatus === 'LIQUIDATION') {
    statusBadgeColor = 'border-[#E04444] text-[#E04444] bg-[#E04444]/15';
    gaugeFillColor = 'bg-[#E04444]';
  }

  return (
    <div id="collateral-desk-workspace" className="space-y-6 font-mono">
      {/* Top Banner */}
      <div className="bg-[#161618] border border-[#1F1F21] p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-xs">
            <span className="px-2 py-0.5 border border-[#2D5A27] text-[#2D5A27] font-semibold text-[10px] uppercase tracking-wider">
              Institutional Collateral Desk
            </span>
            <span className={`px-2 py-0.5 rounded-sm text-[10px] font-bold border uppercase tracking-wider ${statusBadgeColor}`}>
              Health: {health.marginStatus}
            </span>
            <span className="text-[#555] uppercase text-[10px]">Segregated Custody Vault</span>
          </div>
          <h1 className="text-base font-bold text-white tracking-tight mt-1.5">
            Digital Asset Collateral & Haircut Valuation Engine
          </h1>
          <p className="text-xs text-[#777] mt-0.5">
            Rhino Bank Policy: Nominal market values are strictly haircutted. BTC requires min 25% haircut; USDT requires 5% haircut.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <div className="flex items-center space-x-1.5 px-3 py-1.5 bg-[#0F0F10] border border-[#1F1F21] text-xs text-[#888]">
            <Lock className="w-3.5 h-3.5 text-[#2D5A27]" />
            <span>Multi-Sig HSM Cold Storage (London City Enclave)</span>
          </div>
        </div>
      </div>

      {/* Top 4 KPI Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#161618] border border-[#1F1F21] p-4">
          <div className="text-[10px] text-[#555] uppercase font-bold tracking-wider mb-1 flex items-center justify-between">
            <span>Gross Collateral</span>
            <Coins className="w-3.5 h-3.5 text-[#555]" />
          </div>
          <div className="text-lg font-light text-white tracking-tight">
            ${(health.grossCollateralUsd / 1000000).toFixed(2)}M
          </div>
          <div className="text-[10px] text-[#555] mt-1">
            Nominal Unadjusted Market Value
          </div>
        </div>

        <div className="bg-[#161618] border border-[#1F1F21] p-4">
          <div className="text-[10px] text-[#555] uppercase font-bold tracking-wider mb-1 flex items-center justify-between">
            <span>Eligible Collateral</span>
            <ShieldCheck className="w-3.5 h-3.5 text-[#2D5A27]" />
          </div>
          <div className="text-lg font-light text-[#2D5A27] tracking-tight">
            ${(health.eligibleCollateralUsd / 1000000).toFixed(2)}M
          </div>
          <div className="text-[10px] text-[#555] mt-1">
            Haircut Deduction: -${((health.grossCollateralUsd - health.eligibleCollateralUsd) / 1000000).toFixed(2)}M
          </div>
        </div>

        <div className="bg-[#161618] border border-[#1F1F21] p-4">
          <div className="text-[10px] text-[#555] uppercase font-bold tracking-wider mb-1 flex items-center justify-between">
            <span>Total Margin Required</span>
            <AlertTriangle className="w-3.5 h-3.5 text-[#F7931A]" />
          </div>
          <div className="text-lg font-light text-white tracking-tight">
            ${(health.totalRequiredMarginUsd / 1000000).toFixed(2)}M
          </div>
          <div className="text-[10px] text-[#555] mt-1">
            IM: ${(collateral.requiredInitialMarginUsd / 1000000).toFixed(1)}M | VM: ${(collateral.requiredVariationMarginUsd / 1000000).toFixed(1)}M
          </div>
        </div>

        <div className="bg-[#161618] border border-[#1F1F21] p-4">
          <div className="text-[10px] text-[#555] uppercase font-bold tracking-wider mb-1 flex items-center justify-between">
            <span>Collateral Coverage</span>
            <Flame className="w-3.5 h-3.5 text-[#2D5A27]" />
          </div>
          <div className={`text-lg font-light tracking-tight ${
            health.collateralRatio >= 1.30 ? 'text-[#2D5A27]' :
            health.collateralRatio >= 1.10 ? 'text-[#F7931A]' : 'text-[#E04444]'
          }`}>
            {(health.collateralRatio * 100).toFixed(1)}% ({health.collateralRatio.toFixed(2)}x)
          </div>
          <div className="text-[10px] text-[#555] mt-1">
            Buffer: +${(health.marginBufferUsd / 1000000).toFixed(2)}M
          </div>
        </div>
      </div>

      {/* Main Grid: BTC Collateral Card vs. USDT Collateral Card */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Bitcoin (BTC) Collateral Vault */}
        <div className="bg-[#161618] border border-[#1F1F21] p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-[#1F1F21] pb-3">
            <div className="flex items-center space-x-2">
              <div className="w-7 h-7 rounded-sm bg-[#F7931A]/20 border border-[#F7931A]/40 flex items-center justify-center text-[#F7931A] font-bold text-sm">
                ₿
              </div>
              <div>
                <h2 className="text-xs font-bold uppercase tracking-[0.2em] text-white">
                  Bitcoin (BTC) Custodial Collateral
                </h2>
                <p className="text-[10px] text-[#555] uppercase mt-0.5">Segregated Institutional Vault (Native BTC)</p>
              </div>
            </div>
            <span className="text-xs px-2 py-0.5 rounded-sm bg-[#0F0F10] text-[#F7931A] border border-[#1F1F21] font-bold">
              {collateral.btcQty.toLocaleString()} BTC
            </span>
          </div>

          {/* BTC Metrics Grid */}
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="p-3 bg-[#0F0F10] border border-[#1F1F21]">
              <div className="text-[9px] text-[#555] uppercase font-bold tracking-wider">Oracle Price</div>
              <div className="text-sm font-light text-white mt-1">
                ${liveBtcPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
              {btcPriceShiftPct !== 0 && (
                <div className={`text-[9px] mt-0.5 ${btcPriceShiftPct >= 0 ? 'text-[#2D5A27]' : 'text-[#E04444]'}`}>
                  Shift: {btcPriceShiftPct >= 0 ? '+' : ''}{btcPriceShiftPct}%
                </div>
              )}
            </div>

            <div className="p-3 bg-[#0F0F10] border border-[#1F1F21]">
              <div className="text-[9px] text-[#555] uppercase font-bold tracking-wider">Gross Value</div>
              <div className="text-sm font-light text-white mt-1">
                ${((collateral.btcQty * liveBtcPrice) / 1000000).toFixed(2)}M
              </div>
              <div className="text-[9px] text-[#555] mt-0.5">Nominal 100%</div>
            </div>

            <div className="p-3 bg-[#0F0F10] border border-[#1F1F21]">
              <div className="text-[9px] text-[#555] uppercase font-bold tracking-wider">Applied Haircut</div>
              <div className="text-sm font-light text-[#F7931A] mt-1">
                {btcCustomHaircut.toFixed(0)}%
              </div>
              <div className="text-[9px] text-[#555] mt-0.5">Base Policy: 25%</div>
            </div>

            <div className="p-3 bg-[#0F0F10] border border-[#1F1F21]">
              <div className="text-[9px] text-[#555] uppercase font-bold tracking-wider">Eligible Collateral</div>
              <div className="text-sm font-light text-[#2D5A27] mt-1">
                ${(((collateral.btcQty * liveBtcPrice) * (1 - (btcCustomHaircut / 100))) / 1000000).toFixed(2)}M
              </div>
              <div className="text-[9px] text-[#555] mt-0.5">After haircut deduction</div>
            </div>
          </div>

          {/* Interactive BTC Stress Sliders */}
          <div className="p-4 bg-[#0F0F10] border border-[#1F1F21] space-y-3">
            <div className="space-y-1">
              <div className="flex justify-between text-[10px]">
                <span className="text-[#888] uppercase tracking-wider flex items-center gap-1">
                  <Sliders className="w-3 h-3 text-[#F7931A]" />
                  Simulate BTC Spot Price Drop:
                </span>
                <span className={`font-bold ${btcPriceShiftPct < 0 ? 'text-[#E04444]' : 'text-[#888]'}`}>
                  {btcPriceShiftPct}% (${liveBtcPrice.toLocaleString(undefined, { maximumFractionDigits: 0 })})
                </span>
              </div>
              <input
                type="range"
                min="-75"
                max="50"
                step="1"
                value={btcPriceShiftPct}
                onChange={e => setBtcPriceShiftPct(Number(e.target.value))}
                className="w-full h-1.5 bg-[#1F1F21] rounded appearance-none cursor-pointer accent-[#F7931A]"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-[10px]">
                <span className="text-[#888] uppercase tracking-wider flex items-center gap-1">
                  <Sliders className="w-3 h-3 text-[#F7931A]" />
                  Adjust BTC Haircut Rate:
                </span>
                <span className="text-[#F7931A] font-bold">{btcCustomHaircut}%</span>
              </div>
              <input
                type="range"
                min="15"
                max="60"
                step="1"
                value={btcCustomHaircut}
                onChange={e => setBtcCustomHaircut(Number(e.target.value))}
                className="w-full h-1.5 bg-[#1F1F21] rounded appearance-none cursor-pointer accent-[#F7931A]"
              />
            </div>
          </div>
        </div>

        {/* Tether (USDT) Collateral Vault */}
        <div className="bg-[#161618] border border-[#1F1F21] p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-[#1F1F21] pb-3">
            <div className="flex items-center space-x-2">
              <div className="w-7 h-7 rounded-sm bg-[#26A17B]/20 border border-[#26A17B]/40 flex items-center justify-center text-[#26A17B] font-bold text-sm">
                ₮
              </div>
              <div>
                <h2 className="text-xs font-bold uppercase tracking-[0.2em] text-white">
                  Tether (USDT) Liquidity Collateral
                </h2>
                <p className="text-[10px] text-[#555] uppercase mt-0.5">Segregated Custody Account (ERC-20)</p>
              </div>
            </div>
            <span className="text-xs px-2 py-0.5 rounded-sm bg-[#0F0F10] text-[#26A17B] border border-[#1F1F21] font-bold">
              {collateral.usdtQty.toLocaleString()} USDT
            </span>
          </div>

          {/* USDT Metrics Grid */}
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="p-3 bg-[#0F0F10] border border-[#1F1F21]">
              <div className="text-[9px] text-[#555] uppercase font-bold tracking-wider">Peg Valuation</div>
              <div className="text-sm font-light text-white mt-1">
                ${liveUsdtPrice.toFixed(4)}
              </div>
              <div className="text-[9px] text-[#26A17B] mt-0.5">Liquidity Score: {collateral.usdtLiquidityScore}/100</div>
            </div>

            <div className="p-3 bg-[#0F0F10] border border-[#1F1F21]">
              <div className="text-[9px] text-[#555] uppercase font-bold tracking-wider">Gross Value</div>
              <div className="text-sm font-light text-white mt-1">
                ${((collateral.usdtQty * liveUsdtPrice) / 1000000).toFixed(2)}M
              </div>
              <div className="text-[9px] text-[#555] mt-0.5">Nominal 100%</div>
            </div>

            <div className="p-3 bg-[#0F0F10] border border-[#1F1F21]">
              <div className="text-[9px] text-[#555] uppercase font-bold tracking-wider">Applied Haircut</div>
              <div className="text-sm font-light text-[#26A17B] mt-1">
                {usdtCustomHaircut.toFixed(0)}%
              </div>
              <div className="text-[9px] text-[#555] mt-0.5">Base Policy: 5%</div>
            </div>

            <div className="p-3 bg-[#0F0F10] border border-[#1F1F21]">
              <div className="text-[9px] text-[#555] uppercase font-bold tracking-wider">Eligible Collateral</div>
              <div className="text-sm font-light text-[#2D5A27] mt-1">
                ${(((collateral.usdtQty * liveUsdtPrice) * (1 - (usdtCustomHaircut / 100))) / 1000000).toFixed(2)}M
              </div>
              <div className="text-[9px] text-[#555] mt-0.5">After haircut deduction</div>
            </div>
          </div>

          {/* Interactive USDT Stress Sliders */}
          <div className="p-4 bg-[#0F0F10] border border-[#1F1F21] space-y-3">
            <div className="space-y-1">
              <div className="flex justify-between text-[10px]">
                <span className="text-[#888] uppercase tracking-wider flex items-center gap-1">
                  <Sliders className="w-3 h-3 text-[#26A17B]" />
                  Simulate USDT De-Peg Deviation:
                </span>
                <span className={`font-bold ${usdtPriceShiftPct < 0 ? 'text-[#E04444]' : 'text-[#888]'}`}>
                  {usdtPriceShiftPct}% (${liveUsdtPrice.toFixed(4)})
                </span>
              </div>
              <input
                type="range"
                min="-20"
                max="5"
                step="0.5"
                value={usdtPriceShiftPct}
                onChange={e => setUsdtPriceShiftPct(Number(e.target.value))}
                className="w-full h-1.5 bg-[#1F1F21] rounded appearance-none cursor-pointer accent-[#26A17B]"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-[10px]">
                <span className="text-[#888] uppercase tracking-wider flex items-center gap-1">
                  <Sliders className="w-3 h-3 text-[#26A17B]" />
                  Adjust USDT Haircut Rate:
                </span>
                <span className="text-[#26A17B] font-bold">{usdtCustomHaircut}%</span>
              </div>
              <input
                type="range"
                min="2"
                max="30"
                step="1"
                value={usdtCustomHaircut}
                onChange={e => setUsdtCustomHaircut(Number(e.target.value))}
                className="w-full h-1.5 bg-[#1F1F21] rounded appearance-none cursor-pointer accent-[#26A17B]"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Margin Health Status, Liquidation Distance & Deposit Simulator */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Margin Health Gauge & Liquidation Distance */}
        <div className="lg:col-span-7 bg-[#161618] border border-[#1F1F21] p-5 space-y-4">
          <div className="border-b border-[#1F1F21] pb-3 flex items-center justify-between">
            <h2 className="text-xs font-bold uppercase tracking-[0.2em] text-white flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#2D5A27]" />
              Margin Health & Liquidation Buffer Gauge
            </h2>
            <span className={`px-2 py-0.5 rounded-sm text-[10px] font-bold border uppercase tracking-wider ${statusBadgeColor}`}>
              {health.marginStatus}
            </span>
          </div>

          {/* Visual Health Gauge Bar */}
          <div className="space-y-2">
            <div className="h-4 w-full bg-[#0F0F10] border border-[#1F1F21] overflow-hidden relative">
              <div
                style={{ width: `${Math.min(100, (health.collateralRatio / 2.2) * 100)}%` }}
                className={`h-full ${gaugeFillColor} transition-all duration-300`}
              />
              {/* Threshold markers */}
              <div className="absolute top-0 bottom-0 left-[45.45%] w-0.5 bg-[#E04444]" title="Liquidation Threshold 1.0x" />
              <div className="absolute top-0 bottom-0 left-[50%] w-0.5 bg-[#F7931A]" title="Margin Call 1.1x" />
              <div className="absolute top-0 bottom-0 left-[59.09%] w-0.5 bg-[#2D5A27]" title="Safe Threshold 1.3x" />
            </div>

            <div className="flex justify-between text-[9px] text-[#555] uppercase">
              <span className="text-[#E04444]">0.0x (Deficit)</span>
              <span className="text-[#E04444]">1.0x (Liquidation)</span>
              <span className="text-[#F7931A]">1.1x (Call)</span>
              <span className="text-[#2D5A27]">1.3x (Safe Policy)</span>
              <span>2.0x+ (Robust)</span>
            </div>
          </div>

          {/* Liquidation Distance Details */}
          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="p-3 bg-[#0F0F10] border border-[#1F1F21]">
              <div className="text-[9px] text-[#555] uppercase font-bold tracking-wider">BTC Liquidation Distance</div>
              <div className="text-sm font-light text-white mt-1">
                -{(health.liquidationDistancePct * 100).toFixed(1)}%
              </div>
              <div className="text-[10px] text-[#777] mt-0.5">
                BTC spot can fall to ${(liveBtcPrice * (1 - health.liquidationDistancePct)).toLocaleString(undefined, { maximumFractionDigits: 0 })} before Margin Call
              </div>
            </div>

            <div className="p-3 bg-[#0F0F10] border border-[#1F1F21]">
              <div className="text-[9px] text-[#555] uppercase font-bold tracking-wider">Cash / Margin Buffer</div>
              <div className="text-sm font-light text-[#2D5A27] mt-1">
                +${(health.marginBufferUsd / 1000000).toFixed(2)}M
              </div>
              <div className="text-[10px] text-[#777] mt-0.5">
                Excess eligible collateral above combined IM+VM requirements
              </div>
            </div>
          </div>
        </div>

        {/* Deposit Collateral Simulator */}
        <div className="lg:col-span-5 bg-[#161618] border border-[#1F1F21] p-5 space-y-4">
          <div className="border-b border-[#1F1F21] pb-3">
            <h2 className="text-xs font-bold uppercase tracking-[0.2em] text-white flex items-center gap-2">
              <PlusCircle className="w-4 h-4 text-[#2D5A27]" />
              Deposit Collateral to Vault
            </h2>
            <p className="text-[10px] text-[#555] uppercase mt-0.5">Simulate institutional top-up & multi-sig settlement</p>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <label className="text-[10px] text-[#555] uppercase font-bold tracking-wider">Select Asset:</label>
              <div className="grid grid-cols-3 gap-2 mt-1">
                {(['BTC', 'USDT', 'FIAT'] as const).map(asset => (
                  <button
                    key={asset}
                    onClick={() => setDepositAsset(asset)}
                    className={`py-1.5 text-xs border transition-colors ${
                      depositAsset === asset
                        ? 'bg-[#2D5A27]/20 border-[#2D5A27] text-[#2D5A27] font-bold'
                        : 'bg-[#0F0F10] border-[#1F1F21] text-[#888] hover:bg-[#1A1A1C] hover:text-white'
                    }`}
                  >
                    {asset === 'FIAT' ? 'Fiat (£ Cash)' : asset}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-[10px] text-[#555] uppercase font-bold tracking-wider">Deposit Amount:</label>
              <div className="relative mt-1">
                <input
                  type="number"
                  value={depositAmount}
                  onChange={e => setDepositAmount(Number(e.target.value))}
                  className="w-full bg-[#0F0F10] border border-[#1F1F21] rounded-sm px-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#2D5A27]"
                />
              </div>
            </div>

            <button
              onClick={handleExecuteDeposit}
              className="w-full py-2 bg-[#2D5A27] hover:bg-[#346B2D] text-white font-bold text-xs uppercase tracking-[0.2em] transition-colors shadow-sm"
            >
              Execute Deposit ({depositAmount.toLocaleString()} {depositAsset})
            </button>

            {depositFeedback && (
              <div className="p-2.5 bg-[#2D5A27]/15 border border-[#2D5A27]/30 text-[#2D5A27] text-[11px] flex items-center gap-1.5">
                <CheckCircle className="w-3.5 h-3.5" />
                <span>{depositFeedback}</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
