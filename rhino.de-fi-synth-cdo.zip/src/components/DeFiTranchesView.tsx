// ============================================================================
// RHINO BANK | RHINOQUANT SYNTH-CDO
// DeFi Tokenized Tranches, ERC-3643 Permissioned Securities & Smart Contracts (Sophisticated Dark)
// ============================================================================

import React, { useState } from 'react';
import { 
  SyntheticCDO, 
  TrancheType, 
  UserRole 
} from '../types';
import { StructuredCreditContractSimulator, SmartContractState } from '../services/contractEngine';
import { 
  Zap, 
  Coins, 
  FileCode2, 
  CheckCircle, 
  AlertCircle 
} from 'lucide-react';

interface DeFiTranchesViewProps {
  cdo: SyntheticCDO;
  currentUserRole: UserRole;
  currencySymbol: string;
}

export const DeFiTranchesView: React.FC<DeFiTranchesViewProps> = ({
  cdo,
  currentUserRole,
  currencySymbol
}) => {
  const [simulator] = useState(() => new StructuredCreditContractSimulator(cdo));
  const [contractState, setContractState] = useState<SmartContractState>(simulator.getContractState());
  const [auditLogs, setAuditLogs] = useState(simulator.getAuditLedger());
  
  // Interactive action modal / forms
  const [mintTrancheType, setMintTrancheType] = useState<TrancheType>('SENIOR');
  const [mintAmount, setMintAmount] = useState<number>(5000000);
  const [mintRecipient, setMintRecipient] = useState<string>('0x742d35Cc6634C0532925a3b844Bc454e4438f44e');
  const [actionFeedback, setActionFeedback] = useState<string | null>(null);

  const handleIssueTranche = () => {
    const res = simulator.issueTrancheTokens(
      mintTrancheType,
      mintAmount,
      mintRecipient,
      `${currentUserRole.toLowerCase()}@rhinobank.com`,
      currentUserRole
    );
    setContractState({ ...simulator.getContractState() });
    setAuditLogs([...simulator.getAuditLedger()]);
    setActionFeedback(res.message);
    setTimeout(() => setActionFeedback(null), 4000);
  };

  const handleDistributeCoupons = () => {
    const res = simulator.distributeCoupons(
      `${currentUserRole.toLowerCase()}@rhinobank.com`,
      currentUserRole
    );
    setContractState({ ...simulator.getContractState() });
    setAuditLogs([...simulator.getAuditLedger()]);
    setActionFeedback(res.message);
    setTimeout(() => setActionFeedback(null), 4000);
  };

  const handleSettleDemoDefault = () => {
    const res = simulator.settleCreditDefault(
      'REF-00042',
      'Canary Wharf Commercial Loan Series 3',
      1500000,
      `${currentUserRole.toLowerCase()}@rhinobank.com`,
      currentUserRole
    );
    setContractState({ ...simulator.getContractState() });
    setAuditLogs([...simulator.getAuditLedger()]);
    setActionFeedback(res.message);
    setTimeout(() => setActionFeedback(null), 4000);
  };

  return (
    <div id="defi-tranches-workspace" className="space-y-6 font-mono">
      {/* Top Banner */}
      <div className="bg-[#161618] border border-[#1F1F21] p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-xs">
            <span className="px-2 py-0.5 border border-[#2D5A27] text-[#2D5A27] font-semibold text-[10px] uppercase tracking-wider">
              DeFi Settlement Layer
            </span>
            <span className="px-2 py-0.5 bg-[#0F0F10] text-[#D1D1D1] border border-[#1F1F21] text-[10px] font-bold uppercase tracking-wider">
              ERC-3643 Permissioned Securities
            </span>
            <span className="text-[#555] uppercase text-[10px]">Rhino-Settlement-L2</span>
          </div>
          <h1 className="text-base font-bold text-white tracking-tight mt-1.5">
            Tokenized Tranche Issuance & Smart Contract State
          </h1>
          <p className="text-xs text-[#777] mt-0.5">
            Institutional permissioned digital securities: Whitelisted QIB transfer restrictions, on-chain collateral vault custody, and automated coupon distribution.
          </p>
        </div>

        <div className="flex items-center space-x-2 text-xs">
          <div className="px-3 py-1.5 bg-[#0F0F10] border border-[#1F1F21] text-[#888]">
            Contract: <span className="text-[#2D5A27] font-bold">{contractState.contractAddress.slice(0, 10)}...{contractState.contractAddress.slice(-6)}</span>
          </div>
          <div className="px-3 py-1.5 bg-[#0F0F10] border border-[#1F1F21] text-[#888]">
            Block: <span className="text-white font-bold">#{contractState.currentBlock.toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* 4 Tokenized Tranche Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {cdo.tranches.map(tranche => (
          <div key={tranche.id} className="bg-[#161618] border border-[#1F1F21] p-4 space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className={`px-2 py-0.5 rounded-sm text-[10px] font-bold border uppercase tracking-wider ${
                tranche.type === 'EQUITY' ? 'bg-[#E04444]/15 text-[#E04444] border-[#E04444]/30' :
                tranche.type === 'JUNIOR' ? 'bg-[#F7931A]/15 text-[#F7931A] border-[#F7931A]/30' :
                tranche.type === 'MEZZANINE' ? 'bg-[#555]/15 text-[#888] border-[#555]/30' :
                'bg-[#2D5A27]/15 text-[#2D5A27] border-[#2D5A27]/30'
              }`}>
                {tranche.type}
              </span>
              <span className="text-xs font-bold text-white">{tranche.tokenSymbol}</span>
            </div>

            <div className="text-lg font-light text-white tracking-tight">
              {currencySymbol}{(tranche.notional / 1000000).toFixed(0)}M
            </div>

            <div className="space-y-1.5 text-[11px] text-[#888] border-t border-[#1F1F21] pt-2.5">
              <div className="flex justify-between">
                <span>Subordination:</span>
                <span className="text-white">{(tranche.attachmentPct * 100).toFixed(0)}% – {(tranche.detachmentPct * 100).toFixed(0)}%</span>
              </div>
              <div className="flex justify-between">
                <span>Coupon Spread:</span>
                <span className="text-[#2D5A27] font-bold">+{tranche.couponBps} bps</span>
              </div>
              <div className="flex justify-between">
                <span>Current Token NAV:</span>
                <span className="text-white font-bold">{tranche.currentNav.toFixed(3)}</span>
              </div>
              <div className="flex justify-between">
                <span>Verified Holders:</span>
                <span className="text-[#D1D1D1]">{tranche.tokenHoldersCount} QIBs</span>
              </div>
            </div>

            <div className="text-[9px] text-[#555] truncate pt-2 border-t border-[#1F1F21]">
              Contract: {tranche.tokenContractAddress}
            </div>
          </div>
        ))}
      </div>

      {/* Smart Contract Interaction Desk & Live Execution */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Execution Controls */}
        <div className="lg:col-span-6 bg-[#161618] border border-[#1F1F21] p-5 space-y-4">
          <div className="border-b border-[#1F1F21] pb-3">
            <h2 className="text-xs font-bold uppercase tracking-[0.2em] text-white flex items-center gap-2">
              <Zap className="w-4 h-4 text-[#2D5A27]" />
              Smart Contract Method Workbench
            </h2>
            <p className="text-[10px] text-[#555] uppercase mt-0.5">
              Direct simulated RPC execution on Rhino-Settlement-L2
            </p>
          </div>

          <div className="space-y-3 text-xs">
            {/* Method 1: Issue Tranche Tokens */}
            <div className="p-4 bg-[#0F0F10] border border-[#1F1F21] space-y-3">
              <div className="text-[10px] font-bold text-[#2D5A27] uppercase tracking-wider flex items-center gap-1">
                <span>issueTranche(trancheType, recipient, amount)</span>
              </div>
              
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[9px] text-[#555] uppercase font-bold tracking-wider">Tranche:</label>
                  <select
                    value={mintTrancheType}
                    onChange={e => setMintTrancheType(e.target.value as TrancheType)}
                    className="w-full bg-[#161618] border border-[#1F1F21] rounded-sm px-2 py-1 text-xs text-white"
                  >
                    <option value="SENIOR">Senior Tranche</option>
                    <option value="MEZZANINE">Mezzanine Tranche</option>
                    <option value="JUNIOR">Junior Tranche</option>
                    <option value="EQUITY">Equity Tranche</option>
                  </select>
                </div>
                <div>
                  <label className="text-[9px] text-[#555] uppercase font-bold tracking-wider">Amount (£):</label>
                  <input
                    type="number"
                    value={mintAmount}
                    onChange={e => setMintAmount(Number(e.target.value))}
                    className="w-full bg-[#161618] border border-[#1F1F21] rounded-sm px-2 py-1 text-xs text-white"
                  />
                </div>
              </div>

              <div>
                <label className="text-[9px] text-[#555] uppercase font-bold tracking-wider">QIB Recipient Address:</label>
                <input
                  type="text"
                  value={mintRecipient}
                  onChange={e => setMintRecipient(e.target.value)}
                  className="w-full bg-[#161618] border border-[#1F1F21] rounded-sm px-2 py-1 text-xs text-[#888]"
                />
              </div>

              <button
                onClick={handleIssueTranche}
                className="w-full py-2 bg-[#2D5A27] hover:bg-[#346B2D] text-white font-bold text-xs uppercase tracking-[0.2em] transition-colors"
              >
                Mint & Issue Tokens
              </button>
            </div>

            {/* Quick Actions Grid */}
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={handleDistributeCoupons}
                className="p-3 bg-[#0F0F10] border border-[#1F1F21] hover:border-[#2D5A27] text-left transition-colors"
              >
                <div className="text-[11px] font-bold text-white flex items-center gap-1.5">
                  <Coins className="w-3.5 h-3.5 text-[#2D5A27]" />
                  distributeCoupons()
                </div>
                <div className="text-[10px] text-[#777] mt-1">
                  Execute quarterly interest waterfall payout across all 4 tranches.
                </div>
              </button>

              <button
                onClick={handleSettleDemoDefault}
                className="p-3 bg-[#0F0F10] border border-[#1F1F21] hover:border-[#E04444] text-left transition-colors"
              >
                <div className="text-[11px] font-bold text-[#E04444] flex items-center gap-1.5">
                  <AlertCircle className="w-3.5 h-3.5 text-[#E04444]" />
                  settleCreditDefault()
                </div>
                <div className="text-[10px] text-[#777] mt-1">
                  Simulate £1.5M credit loss settlement absorbed by Equity first.
                </div>
              </button>
            </div>

            {actionFeedback && (
              <div className="p-2.5 bg-[#2D5A27]/15 border border-[#2D5A27]/30 text-[#2D5A27] text-xs flex items-center gap-2">
                <CheckCircle className="w-4 h-4" />
                <span>{actionFeedback}</span>
              </div>
            )}
          </div>
        </div>

        {/* Live On-Chain Audit & Settlement Event Stream */}
        <div className="lg:col-span-6 bg-[#161618] border border-[#1F1F21] p-5 space-y-4">
          <div className="border-b border-[#1F1F21] pb-3 flex items-center justify-between">
            <h2 className="text-xs font-bold uppercase tracking-[0.2em] text-white flex items-center gap-2">
              <FileCode2 className="w-4 h-4 text-[#2D5A27]" />
              Immutable On-Chain Event Stream
            </h2>
            <span className="text-[10px] text-[#555] uppercase">
              {auditLogs.length} Verified Ledger Events
            </span>
          </div>

          <div className="space-y-2.5 max-h-[380px] overflow-y-auto pr-1">
            {auditLogs.map(log => (
              <div key={log.id} className="p-3 bg-[#0F0F10] border border-[#1F1F21] space-y-1 text-xs">
                <div className="flex items-center justify-between text-[10px]">
                  <span className="font-bold text-[#2D5A27] uppercase">{log.action}</span>
                  <span className="text-[#555]">Block #{log.blockNumber}</span>
                </div>
                <p className="text-[#D1D1D1] text-[11px]">{log.details}</p>
                <div className="flex items-center justify-between text-[10px] text-[#555] pt-1.5 border-t border-[#1F1F21]">
                  <span>Actor: {log.actor} ({log.role})</span>
                  <span className="font-mono text-[#777]">{log.txHash.slice(0, 10)}...</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
