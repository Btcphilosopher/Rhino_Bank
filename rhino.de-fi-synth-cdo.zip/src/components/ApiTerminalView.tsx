// ============================================================================
// RHINO BANK | RHINOQUANT SYNTH-CDO
// Institutional REST API Layer & Interactive OpenAPI / Swagger Terminal (Sophisticated Dark)
// ============================================================================

import React, { useState } from 'react';
import { SyntheticCDO, ReferenceAsset } from '../types';
import { runMonteCarloSimulation, calculateCollateralHealth } from '../services/quantEngine';
import { 
  FileJson, 
  Send, 
  Copy, 
  Check, 
  Globe 
} from 'lucide-react';

interface ApiTerminalViewProps {
  cdo: SyntheticCDO;
  portfolio: ReferenceAsset[];
}

export const ApiTerminalView: React.FC<ApiTerminalViewProps> = ({
  cdo,
  portfolio
}) => {
  const [selectedEndpoint, setSelectedEndpoint] = useState<string>('/api/v1/cdo/simulate');
  const [requestBody, setRequestBody] = useState<string>(
    JSON.stringify(
      {
        dealId: cdo.id,
        numScenarios: 25000,
        systematicCorrelation: 0.30,
        confidenceInterval: 0.99
      },
      null,
      2
    )
  );

  const [responseStatus, setResponseStatus] = useState<number | null>(null);
  const [responseLatency, setResponseLatency] = useState<number | null>(null);
  const [responsePayload, setResponsePayload] = useState<any | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [copied, setCopied] = useState(false);

  const endpoints = [
    {
      method: 'POST',
      path: '/api/v1/cdo/simulate',
      desc: 'Execute 1-Factor Gaussian Copula Monte Carlo simulation on CDO portfolio.',
      defaultBody: {
        dealId: cdo.id,
        numScenarios: 25000,
        systematicCorrelation: 0.30,
        confidenceInterval: 0.99
      }
    },
    {
      method: 'GET',
      path: '/api/v1/collateral/margin-health',
      desc: 'Query live collateral valuation, haircuts, and margin health ratio.',
      defaultBody: null
    },
    {
      method: 'POST',
      path: '/api/v1/stress-test/run',
      desc: 'Execute multi-factor macro stress test and tranche impairment projection.',
      defaultBody: {
        dealId: cdo.id,
        scenarioId: 'BTC_FLASH_CRASH',
        btcPriceChangePct: -75,
        creditDefaultMultiplier: 2.5
      }
    },
    {
      method: 'GET',
      path: '/api/v1/tokens/tranches',
      desc: 'List ERC-3643 tokenized tranche smart contracts and whitelist permissions.',
      defaultBody: null
    }
  ];

  const handleSelectEndpoint = (ep: typeof endpoints[0]) => {
    setSelectedEndpoint(ep.path);
    if (ep.defaultBody) {
      setRequestBody(JSON.stringify(ep.defaultBody, null, 2));
    } else {
      setRequestBody('');
    }
    setResponseStatus(null);
    setResponsePayload(null);
  };

  const handleExecuteRequest = () => {
    setIsLoading(true);
    const start = performance.now();

    setTimeout(() => {
      let result: any = {};

      if (selectedEndpoint === '/api/v1/cdo/simulate') {
        const mc = runMonteCarloSimulation(portfolio, cdo, 25000, 0.30);
        result = {
          status: 'SUCCESS',
          dealId: cdo.id,
          numScenarios: mc.numScenarios,
          meanLossUsd: mc.meanPortfolioLoss,
          var99Usd: mc.var99PortfolioLoss,
          cvar99Usd: mc.cvar99PortfolioLoss,
          executionTimeMs: mc.executionTimeMs,
          tranches: mc.trancheLosses
        };
      } else if (selectedEndpoint === '/api/v1/collateral/margin-health') {
        const health = calculateCollateralHealth(
          cdo.collateral.btcQty,
          cdo.collateral.btcPriceUsd,
          cdo.collateral.btcHaircutPct,
          cdo.collateral.usdtQty,
          cdo.collateral.usdtPriceUsd,
          cdo.collateral.usdtHaircutPct,
          cdo.collateral.fiatCash,
          cdo.collateral.requiredInitialMarginUsd,
          cdo.collateral.requiredVariationMarginUsd
        );
        result = {
          status: 'SUCCESS',
          marginStatus: health.marginStatus,
          collateralRatio: health.collateralRatio,
          eligibleCollateralUsd: health.eligibleCollateralUsd,
          grossCollateralUsd: health.grossCollateralUsd,
          totalRequiredMarginUsd: health.totalRequiredMarginUsd,
          liquidationDistancePct: health.liquidationDistancePct
        };
      } else if (selectedEndpoint === '/api/v1/tokens/tranches') {
        result = {
          status: 'SUCCESS',
          dealId: cdo.id,
          tokenStandard: 'ERC-3643 (Permissioned)',
          network: 'Rhino-Settlement-L2 (ChainID: 8842)',
          tranches: cdo.tranches.map(t => ({
            type: t.type,
            symbol: t.tokenSymbol,
            contractAddress: t.tokenContractAddress,
            nav: t.currentNav,
            holders: t.tokenHoldersCount
          }))
        };
      } else {
        result = {
          status: 'SUCCESS',
          scenario: 'BTC_FLASH_CRASH',
          solvencyStatus: 'IMPAIRED',
          stressedPortfolioLossUsd: 48500000,
          stressedCollateralRatio: 1.14,
          stressedMarginStatus: 'WARNING'
        };
      }

      const elapsed = Math.round(performance.now() - start);
      setResponseStatus(200);
      setResponseLatency(elapsed + 18);
      setResponsePayload(result);
      setIsLoading(false);
    }, 120);
  };

  const handleCopyResponse = () => {
    if (!responsePayload) return;
    navigator.clipboard.writeText(JSON.stringify(responsePayload, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div id="api-terminal-workspace" className="space-y-6 font-mono">
      {/* Top Banner */}
      <div className="bg-[#161618] border border-[#1F1F21] p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-xs">
            <span className="px-2 py-0.5 border border-[#2D5A27] text-[#2D5A27] font-semibold text-[10px] uppercase tracking-wider">
              REST / OpenAPI Gateway
            </span>
            <span className="text-[#555] uppercase text-[10px]">Institutional Integration Layer</span>
          </div>
          <h1 className="text-base font-bold text-white tracking-tight mt-1.5">
            RhinoQuant Programmatic API & Simulation Workbench
          </h1>
          <p className="text-xs text-[#777] mt-0.5">
            Integrate Bloomberg AIM, Aladdin, Murex or proprietary algorithmic trading engines with high-speed JSON endpoints.
          </p>
        </div>

        <div className="flex items-center space-x-2 text-xs">
          <span className="px-3 py-1.5 bg-[#0F0F10] border border-[#1F1F21] text-[#888]">
            Host: <strong className="text-[#2D5A27]">api.rhinoquant.bank.internal</strong>
          </span>
        </div>
      </div>

      {/* Main Layout: Endpoint List vs. Request/Response Workbench */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Endpoint Selector List */}
        <div className="lg:col-span-4 bg-[#161618] border border-[#1F1F21] p-4 space-y-3">
          <div className="text-xs font-bold uppercase tracking-[0.2em] text-white border-b border-[#1F1F21] pb-3">
            Available REST Endpoints
          </div>

          <div className="space-y-2">
            {endpoints.map(ep => (
              <button
                key={ep.path}
                onClick={() => handleSelectEndpoint(ep)}
                className={`w-full p-3 text-left border transition-all text-xs ${
                  selectedEndpoint === ep.path
                    ? 'bg-[#1A1A1C] border-[#2D5A27] border-l-2 text-white'
                    : 'bg-[#0F0F10] border-[#1F1F21] text-[#888] hover:bg-[#1A1A1C] hover:text-white'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <span className={`px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider ${
                    ep.method === 'POST' ? 'bg-[#2D5A27]/20 text-[#2D5A27]' : 'bg-[#0F0F10] text-[#D1D1D1] border border-[#1F1F21]'
                  }`}>
                    {ep.method}
                  </span>
                  <span className="font-bold font-mono text-[11px] truncate">{ep.path}</span>
                </div>
                <p className="text-[10px] text-[#777] mt-1.5 line-clamp-1">{ep.desc}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Request / Response Console */}
        <div className="lg:col-span-8 space-y-4">
          {/* Request Header and Body */}
          <div className="bg-[#161618] border border-[#1F1F21] p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-[#1F1F21] pb-3">
              <div className="flex items-center space-x-2 text-xs">
                <Globe className="w-4 h-4 text-[#2D5A27]" />
                <span className="font-bold text-white tracking-wider">{selectedEndpoint}</span>
              </div>

              <button
                onClick={handleExecuteRequest}
                disabled={isLoading}
                className="flex items-center space-x-1.5 px-4 py-2 bg-[#2D5A27] hover:bg-[#346B2D] text-white font-bold text-xs uppercase tracking-[0.2em] transition-colors shadow-sm disabled:opacity-50"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{isLoading ? 'Executing...' : 'Send Request'}</span>
              </button>
            </div>

            {requestBody ? (
              <div className="space-y-1.5">
                <label className="text-[10px] text-[#555] uppercase font-bold tracking-wider">JSON Request Body:</label>
                <textarea
                  value={requestBody}
                  onChange={e => setRequestBody(e.target.value)}
                  rows={6}
                  className="w-full bg-[#0F0F10] border border-[#1F1F21] rounded-sm p-3 text-xs text-[#2D5A27] font-mono focus:outline-none focus:border-[#2D5A27]"
                />
              </div>
            ) : (
              <div className="text-[11px] text-[#555] italic py-2">
                No payload body required for this GET request.
              </div>
            )}
          </div>

          {/* Response Inspector */}
          <div className="bg-[#161618] border border-[#1F1F21] p-5 space-y-3">
            <div className="flex items-center justify-between border-b border-[#1F1F21] pb-3 text-xs">
              <div className="flex items-center space-x-3">
                <FileJson className="w-4 h-4 text-[#2D5A27]" />
                <span className="font-bold text-white uppercase tracking-wider text-xs">Response Body</span>
                {responseStatus && (
                  <span className="px-2 py-0.5 bg-[#2D5A27]/20 text-[#2D5A27] font-bold text-[10px] border border-[#2D5A27]/30 uppercase">
                    HTTP {responseStatus} OK
                  </span>
                )}
                {responseLatency && (
                  <span className="text-[#555] text-[10px]">
                    Latency: <strong className="text-white">{responseLatency} ms</strong>
                  </span>
                )}
              </div>

              {responsePayload && (
                <button
                  onClick={handleCopyResponse}
                  className="flex items-center space-x-1 text-[#888] hover:text-white text-[11px]"
                >
                  {copied ? <Check className="w-3 h-3 text-[#2D5A27]" /> : <Copy className="w-3 h-3" />}
                  <span>{copied ? 'Copied' : 'Copy JSON'}</span>
                </button>
              )}
            </div>

            <div className="bg-[#0F0F10] border border-[#1F1F21] p-4 max-h-[300px] overflow-y-auto font-mono text-xs">
              {responsePayload ? (
                <pre className="text-[#D1D1D1] whitespace-pre">
                  {JSON.stringify(responsePayload, null, 2)}
                </pre>
              ) : (
                <div className="text-[#555] italic py-6 text-center text-xs">
                  Click "Send Request" to execute the live quantitative simulation via the REST gateway.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
