// ============================================================================
// RHINO BANK | RHINOQUANT SYNTH-CDO
// CDO Structuring Desk & Interactive Tranche Waterfall Visualizer (Sophisticated Dark)
// ============================================================================

import React, { useState } from 'react';
import { 
  SyntheticCDO, 
  TrancheDefinition 
} from '../types';
import { 
  Sliders, 
  TrendingUp, 
  ShieldAlert, 
  Coins, 
  ArrowDownRight, 
  Layers, 
  FileText, 
  Play, 
  Zap, 
  DollarSign 
} from 'lucide-react';

interface CdoDeskViewProps {
  cdo: SyntheticCDO;
  onUpdateTranches?: (newTranches: TrancheDefinition[]) => void;
  onNavigateTab?: (tabId: string) => void;
  currencySymbol?: string;
}

export const CdoDeskView: React.FC<CdoDeskViewProps> = ({
  cdo,
  onNavigateTab
}) => {
  const [simulatedPortfolioLossUsd, setSimulatedPortfolioLossUsd] = useState<number>(
    cdo.portfolioExpectedLossUsd * 2.5
  );

  const currencySymbol = cdo.currency === 'GBP' ? '£' : '$';
  const totalNotional = cdo.totalNotional;

  // Calculate dynamic tranche loss allocation for simulated slider
  const trancheLossAllocations = cdo.tranches.map(tranche => {
    const attachNotional = tranche.attachmentPct * totalNotional;
    const detachNotional = tranche.detachmentPct * totalNotional;
    const trancheCapacity = detachNotional - attachNotional;

    let lossUsd = 0;
    if (simulatedPortfolioLossUsd > attachNotional) {
      if (simulatedPortfolioLossUsd >= detachNotional) {
        lossUsd = trancheCapacity;
      } else {
        lossUsd = simulatedPortfolioLossUsd - attachNotional;
      }
    }

    const lossPct = trancheCapacity > 0 ? (lossUsd / trancheCapacity) * 100 : 0;
    const remainingPrincipal = Math.max(0, trancheCapacity - lossUsd);

    return {
      ...tranche,
      attachNotional,
      detachNotional,
      trancheCapacity,
      lossUsd,
      lossPct,
      remainingPrincipal
    };
  });

  return (
    <div id="cdo-desk-workspace" className="space-y-6 font-mono">
      {/* Top Banner & Structure Headline */}
      <div className="bg-[#161618] border border-[#1F1F21] p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-[10px] px-2 py-0.5 border border-[#2D5A27] text-[#2D5A27] font-semibold uppercase tracking-wider">
              SYNTHETIC CDO
            </span>
            <span className="text-[10px] px-2 py-0.5 bg-[#0F0F10] text-[#888] border border-[#1F1F21] uppercase">
              STATUS: {cdo.status.toUpperCase()}
            </span>
            <span className="text-[10px] text-[#555] uppercase">
              JURISDICTION: {cdo.jurisdiction.replace('_', ' ')}
            </span>
          </div>
          <h1 className="text-base font-bold text-white tracking-tight mt-1.5">{cdo.name}</h1>
          <p className="text-xs text-[#777] mt-0.5">
            Reference Portfolio: {cdo.portfolioName} ({cdo.assetCount} assets, Avg Rating {cdo.avgRating}, Weighted Spread {cdo.weightedAvgSpreadBps} bps)
          </p>
        </div>

        <div className="flex items-center space-x-2.5">
          <button
            onClick={() => onNavigateTab && onNavigateTab('copula-montecarlo')}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-[#0F0F10] hover:bg-[#1A1A1C] text-[#D1D1D1] border border-[#1F1F21] text-xs transition-colors"
          >
            <Play className="w-3.5 h-3.5 text-[#2D5A27]" />
            <span className="uppercase text-[10px] tracking-wider font-semibold">Run Copula Sim</span>
          </button>
          <button
            onClick={() => onNavigateTab && onNavigateTab('stress-testing')}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-[#0F0F10] hover:bg-[#1A1A1C] text-[#D1D1D1] border border-[#1F1F21] text-xs transition-colors"
          >
            <ShieldAlert className="w-3.5 h-3.5 text-[#F7931A]" />
            <span className="uppercase text-[10px] tracking-wider font-semibold">Stress Matrix</span>
          </button>
          <button
            onClick={() => onNavigateTab && onNavigateTab('collateral-desk')}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-[#2D5A27] hover:bg-[#346B2D] text-white font-bold text-xs uppercase tracking-[0.2em] transition-colors"
          >
            <Zap className="w-3.5 h-3.5" />
            <span className="text-[10px]">Collateral Desk</span>
          </button>
        </div>
      </div>

      {/* Top 4 KPI Metrics (Matching Sophisticated Dark spec) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#161618] border border-[#1F1F21] p-4">
          <div className="text-[10px] text-[#555] uppercase font-bold tracking-wider mb-1 flex items-center justify-between">
            <span>Reference Notional</span>
            <Layers className="w-3.5 h-3.5 text-[#2D5A27]" />
          </div>
          <div className="text-lg font-light text-white tracking-tight">
            {currencySymbol}{(cdo.totalNotional).toLocaleString()}
          </div>
          <div className="text-[10px] text-[#555] mt-1 flex justify-between">
            <span>Maturity: {cdo.maturityYears} Y</span>
            <span className="text-[#888]">{cdo.currency} Base</span>
          </div>
        </div>

        <div className="bg-[#161618] border border-[#1F1F21] p-4">
          <div className="text-[10px] text-[#555] uppercase font-bold tracking-wider mb-1 flex items-center justify-between">
            <span>Expected Loss (EL)</span>
            <TrendingUp className="w-3.5 h-3.5 text-[#A0A0A0]" />
          </div>
          <div className="text-lg font-light text-[#A0A0A0] tracking-tight">
            {(cdo.portfolioExpectedLossPct * 100).toFixed(2)}% ({currencySymbol}{(cdo.portfolioExpectedLossUsd / 1000000).toFixed(2)}M)
          </div>
          <div className="text-[10px] text-[#555] mt-1 flex justify-between">
            <span>PD: {(cdo.weightedAvgPd * 100).toFixed(2)}%</span>
            <span>LGD: {(cdo.weightedAvgLgd * 100).toFixed(0)}%</span>
          </div>
        </div>

        <div className="bg-[#161618] border border-[#1F1F21] p-4">
          <div className="text-[10px] text-[#555] uppercase font-bold tracking-wider mb-1 flex items-center justify-between">
            <span>Collateral Ratio</span>
            <Coins className="w-3.5 h-3.5 text-[#2D5A27]" />
          </div>
          <div className="text-lg font-light text-[#2D5A27] tracking-tight">
            {(cdo.collateral.collateralRatio * 100).toFixed(1)}%
          </div>
          <div className="text-[10px] text-[#555] mt-1 flex justify-between">
            <span>Eligible: ${(cdo.collateral.eligibleCollateralUsd / 1000000).toFixed(1)}M</span>
            <span className="text-[#26A17B] font-bold">{cdo.collateral.marginStatus}</span>
          </div>
        </div>

        <div className="bg-[#161618] border border-[#1F1F21] p-4">
          <div className="text-[10px] text-[#555] uppercase font-bold tracking-wider mb-1 flex items-center justify-between">
            <span>Rhino Desk Net Flow</span>
            <DollarSign className="w-3.5 h-3.5 text-[#26A17B]" />
          </div>
          <div className="text-lg font-light text-[#26A17B] tracking-tight">
            +{currencySymbol}{(cdo.netCashFlowAnnual / 1000000).toFixed(2)}M / yr
          </div>
          <div className="text-[10px] text-[#555] mt-1 flex justify-between">
            <span>Upfront: {cdo.rhinoStructuringFeeBps} bps</span>
            <span>Mgmt: {cdo.rhinoManagementFeeBps} bps</span>
          </div>
        </div>
      </div>

      {/* Main Structural Section: Waterfall Visualizer & Priority of Payments */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Interactive Waterfall Loss Distribution Visualizer */}
        <div className="lg:col-span-7 bg-[#161618] border border-[#1F1F21] p-6 space-y-5">
          <div className="flex justify-between items-end border-b border-[#1F1F21] pb-3">
            <div>
              <h3 className="text-xs font-bold uppercase tracking-[0.2em] text-white">
                Synthetic CDO Tranche Waterfall
              </h3>
              <p className="text-[10px] text-[#555] uppercase mt-0.5">
                Deterministic subordination: Losses flow from Equity (0%) upwards into Senior (100%)
              </p>
            </div>
            <div className="text-[10px] text-[#777] uppercase font-mono">
              Mode: One-Factor Gaussian Copula
            </div>
          </div>

          {/* Interactive Loss Simulator Slider */}
          <div className="bg-[#0F0F10] border border-[#1F1F21] p-4 space-y-2.5">
            <div className="flex items-center justify-between text-xs">
              <span className="text-[#888] uppercase tracking-wider text-[10px] font-bold flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-[#2D5A27]" />
                Simulate Portfolio Credit Loss:
              </span>
              <span className="text-white font-bold">
                {currencySymbol}{(simulatedPortfolioLossUsd / 1000000).toFixed(1)}M 
                <span className="text-[#555] font-normal ml-1.5">
                  ({((simulatedPortfolioLossUsd / totalNotional) * 100).toFixed(2)}% of Portfolio)
                </span>
              </span>
            </div>
            <input
              type="range"
              min="0"
              max={totalNotional * 0.25}
              step={totalNotional * 0.001}
              value={simulatedPortfolioLossUsd}
              onChange={e => setSimulatedPortfolioLossUsd(Number(e.target.value))}
              className="w-full h-1.5 bg-[#1F1F21] rounded appearance-none cursor-pointer accent-[#2D5A27]"
            />
            <div className="flex justify-between text-[9px] text-[#555] uppercase">
              <span>£0M (No Defaults)</span>
              <span>£30M (Equity Detach)</span>
              <span>£70M (Junior Detach)</span>
              <span>£150M (Mezz Detach)</span>
              <span>£250M+ (Senior Stress)</span>
            </div>
          </div>

          {/* Graphical Waterfall Bars matching Sophisticated Dark design */}
          <div className="space-y-4 pt-1">
            {trancheLossAllocations.map(tranche => {
              let borderColor = 'border-[#2D5A27]/30';
              let fillBg = 'bg-[#2D5A27]/30 border-r border-[#2D5A27]';
              let labelColor = 'text-[#2D5A27]';

              if (tranche.type === 'EQUITY') {
                borderColor = 'border-[#E04444]/30';
                fillBg = 'bg-[#E04444]/30 border-r border-[#E04444]';
                labelColor = 'text-[#E04444]';
              } else if (tranche.type === 'JUNIOR') {
                borderColor = 'border-[#F7931A]/30';
                fillBg = 'bg-[#F7931A]/20 border-r border-[#F7931A]';
                labelColor = 'text-[#F7931A]';
              } else if (tranche.type === 'MEZZANINE') {
                borderColor = 'border-[#555]/30';
                fillBg = 'bg-[#555]/30 border-r border-[#666]';
                labelColor = 'text-[#888]';
              }

              const capacityPct = (tranche.trancheCapacity / totalNotional) * 100;

              return (
                <div key={tranche.id} className="relative">
                  <div className="flex justify-between text-[10px] mb-1 uppercase text-[#888]">
                    <span className="font-semibold text-white">
                      {tranche.name} ({tranche.rating}) — <span className={labelColor}>{tranche.type}</span>
                    </span>
                    <span className="text-[#666]">
                      {(tranche.attachmentPct * 100).toFixed(0)}% – {(tranche.detachmentPct * 100).toFixed(0)}% (Spread: +{tranche.couponBps} bps)
                    </span>
                  </div>

                  <div className={`h-8 bg-[#0F0F10] border ${borderColor} relative overflow-hidden flex`}>
                    {/* Loss Impaired Section */}
                    {tranche.lossPct > 0 && (
                      <div 
                        style={{ width: `${(tranche.lossUsd / totalNotional) * 100}%` }}
                        className="h-full bg-[#E04444]/80 border-r border-[#E04444] flex items-center justify-center text-[9px] text-white font-bold"
                      >
                        {tranche.lossPct > 10 && `-${tranche.lossPct.toFixed(0)}%`}
                      </div>
                    )}
                    {/* Remaining Principal Section */}
                    <div 
                      style={{ width: `${(tranche.remainingPrincipal / totalNotional) * 100}%` }}
                      className={`h-full ${fillBg}`}
                    />
                    
                    <div className="absolute top-0 right-0 h-full flex items-center pr-3 text-[10px] text-white">
                      {currencySymbol}{(tranche.notional / 1000000).toFixed(0)}M Notional
                    </div>
                  </div>

                  <div className="flex justify-between text-[9px] text-[#555] mt-1">
                    <span>
                      Loss: {currencySymbol}{(tranche.lossUsd / 1000000).toFixed(2)}M ({tranche.lossPct.toFixed(1)}% impaired)
                    </span>
                    <span className="text-[#888]">
                      Protected Principal: <strong className="text-white">{currencySymbol}{(tranche.remainingPrincipal / 1000000).toFixed(2)}M</strong>
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Priority of Payments & Institutional Cashflow Engine */}
        <div className="lg:col-span-5 bg-[#161618] border border-[#1F1F21] p-6 space-y-4">
          <div className="border-b border-[#1F1F21] pb-3">
            <h3 className="text-xs font-bold uppercase tracking-[0.2em] text-white flex items-center gap-2">
              <ArrowDownRight className="w-4 h-4 text-[#2D5A27]" />
              Priority of Payments Waterfall
            </h3>
            <p className="text-[10px] text-[#555] uppercase mt-0.5">
              Annual cash collections and distribution mechanics
            </p>
          </div>

          <div className="space-y-2.5 text-xs">
            {/* Step 1: Gross Cash Collections */}
            <div className="p-3 bg-[#0F0F10] border border-[#1F1F21] space-y-1">
              <div className="text-[9px] text-[#2D5A27] font-bold uppercase tracking-wider">
                1. Gross Collections (Annual Inflow)
              </div>
              <div className="flex justify-between text-[#888] text-[11px]">
                <span>CDS Protection Premium:</span>
                <span className="text-white font-bold">+{currencySymbol}{(cdo.protectionPremiumIncomeAnnual / 1000000).toFixed(2)}M</span>
              </div>
              <div className="flex justify-between text-[#888] text-[11px]">
                <span>Segregated Collateral Yield:</span>
                <span className="text-white font-bold">+{currencySymbol}{(cdo.collateralReinvestmentYieldAnnual / 1000000).toFixed(2)}M</span>
              </div>
              <div className="border-t border-[#1F1F21] pt-1 flex justify-between text-[#2D5A27] font-bold text-[11px]">
                <span>Total Annual Cash Inflow:</span>
                <span>+{currencySymbol}{((cdo.protectionPremiumIncomeAnnual + cdo.collateralReinvestmentYieldAnnual) / 1000000).toFixed(2)}M</span>
              </div>
            </div>

            {/* Step 2: Senior Fees & Operational Costs */}
            <div className="p-3 bg-[#0F0F10] border border-[#1F1F21] space-y-1">
              <div className="text-[9px] text-[#F7931A] font-bold uppercase tracking-wider">
                2. Senior Fees & Structuring Expenses
              </div>
              <div className="flex justify-between text-[#888] text-[11px]">
                <span>Rhino Mgmt Fee ({cdo.rhinoManagementFeeBps} bps):</span>
                <span className="text-[#E04444]">-{currencySymbol}{((cdo.totalNotional * cdo.rhinoManagementFeeBps / 10000) / 1000000).toFixed(2)}M</span>
              </div>
              <div className="flex justify-between text-[#888] text-[11px]">
                <span>Trustee, Custody & Gas Reserve:</span>
                <span className="text-[#E04444]">-{currencySymbol}0.65M</span>
              </div>
            </div>

            {/* Step 3: Tranche Coupon Distribution Waterfall */}
            <div className="p-3 bg-[#0F0F10] border border-[#1F1F21] space-y-1">
              <div className="text-[9px] text-[#888] font-bold uppercase tracking-wider">
                3. Tranche Interest Priority
              </div>
              <div className="flex justify-between text-[#888] text-[11px]">
                <span>Senior (92 bps over SONIA):</span>
                <span className="text-white">-{currencySymbol}7.82M</span>
              </div>
              <div className="flex justify-between text-[#888] text-[11px]">
                <span>Mezzanine (310 bps):</span>
                <span className="text-white">-{currencySymbol}2.48M</span>
              </div>
              <div className="flex justify-between text-[#888] text-[11px]">
                <span>Junior (680 bps):</span>
                <span className="text-white">-{currencySymbol}2.72M</span>
              </div>
              <div className="flex justify-between text-[#888] text-[11px]">
                <span>Equity Residual Yield:</span>
                <span className="text-white">-{currencySymbol}5.55M</span>
              </div>
            </div>

            {/* Step 4: Net Rhino Bank Desk Profitability */}
            <div className="p-3 bg-[#2D5A27]/20 border border-[#2D5A27] flex items-center justify-between text-[#2D5A27]">
              <span className="font-bold uppercase tracking-wider text-[10px]">Net Annual Desk Spread:</span>
              <span className="text-sm font-bold text-white">
                +{currencySymbol}{(cdo.netCashFlowAnnual / 1000000).toFixed(2)}M
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Comprehensive Tranche Pricing & Quantitative Sensitivity Matrix */}
      <div className="bg-[#161618] border border-[#1F1F21] p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-[#1F1F21] pb-3">
          <div>
            <h3 className="text-xs font-bold uppercase tracking-[0.2em] text-white flex items-center gap-2">
              <FileText className="w-4 h-4 text-[#2D5A27]" />
              Tranche Pricing & Quantitative Sensitivity Matrix
            </h3>
            <p className="text-[10px] text-[#555] uppercase mt-0.5">
              Modelled fair spreads, tail-risk 99% VaR/CVaR, DV01 (Interest Rate Delta), CS01 (Spread Delta)
            </p>
          </div>
          <span className="text-[9px] px-2 py-0.5 border border-[#2D5A27] text-[#2D5A27] uppercase tracking-wider font-semibold">
            Simulated / Verified
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-[11px] font-mono">
            <thead>
              <tr className="border-b border-[#1F1F21] text-[#555] uppercase text-[10px]">
                <th className="pb-3 font-semibold">Tranche</th>
                <th className="pb-3 font-semibold">Attach – Detach</th>
                <th className="pb-3 font-semibold text-right">Notional</th>
                <th className="pb-3 font-semibold text-right">Coupon</th>
                <th className="pb-3 font-semibold text-right">Expected Loss</th>
                <th className="pb-3 font-semibold text-right">99% VaR</th>
                <th className="pb-3 font-semibold text-right">99% CVaR</th>
                <th className="pb-3 font-semibold text-right">DV01</th>
                <th className="pb-3 font-semibold text-right">CS01</th>
                <th className="pb-3 font-semibold text-right">Token NAV</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1F1F21] text-[#D1D1D1]">
              {cdo.tranches.map(tranche => (
                <tr key={tranche.id} className="hover:bg-[#1A1A1C] transition-colors">
                  <td className="py-2.5 font-bold flex items-center space-x-2 text-white">
                    <span className={`w-2 h-2 rounded-full ${
                      tranche.type === 'EQUITY' ? 'bg-[#E04444]' :
                      tranche.type === 'JUNIOR' ? 'bg-[#F7931A]' :
                      tranche.type === 'MEZZANINE' ? 'bg-[#888]' : 'bg-[#2D5A27]'
                    }`}></span>
                    <span>{tranche.name}</span>
                  </td>
                  <td className="py-2.5 text-[#777]">
                    {(tranche.attachmentPct * 100).toFixed(0)}% – {(tranche.detachmentPct * 100).toFixed(0)}%
                  </td>
                  <td className="py-2.5 text-right font-semibold text-white">
                    {currencySymbol}{(tranche.notional / 1000000).toFixed(0)}M
                  </td>
                  <td className="py-2.5 text-right text-[#2D5A27] font-semibold">
                    +{tranche.couponBps} bps
                  </td>
                  <td className="py-2.5 text-right text-[#888]">
                    {(tranche.expectedLossPct * 100).toFixed(2)}%
                  </td>
                  <td className="py-2.5 text-right text-[#E04444]">
                    {currencySymbol}{(tranche.var99 / 1000000).toFixed(1)}M
                  </td>
                  <td className="py-2.5 text-right text-[#E04444]">
                    {currencySymbol}{(tranche.cvar99 / 1000000).toFixed(1)}M
                  </td>
                  <td className="py-2.5 text-right text-[#777]">
                    {currencySymbol}{tranche.dv01.toLocaleString()}
                  </td>
                  <td className="py-2.5 text-right text-[#777]">
                    {currencySymbol}{tranche.cs01.toLocaleString()}
                  </td>
                  <td className="py-2.5 text-right font-bold text-white">
                    {tranche.currentNav.toFixed(3)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
