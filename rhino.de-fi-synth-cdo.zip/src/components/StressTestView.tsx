// ============================================================================
// RHINO BANK | RHINOQUANT SYNTH-CDO
// Stress Testing Terminal & Macro / Digital Asset Scenario Library (Sophisticated Dark)
// ============================================================================

import React, { useState } from 'react';
import { 
  SyntheticCDO, 
  StressScenario, 
  StressTestOutput 
} from '../types';
import { PRESET_STRESS_SCENARIOS } from '../services/portfolioData';
import { runStressTestScenario } from '../services/quantEngine';
import { 
  ShieldAlert, 
  Sliders, 
  Flame, 
  Layers, 
  AlertTriangle, 
  CheckCircle2, 
  XCircle, 
  TrendingDown, 
  Zap 
} from 'lucide-react';

interface StressTestViewProps {
  cdo: SyntheticCDO;
  currencySymbol: string;
}

export const StressTestView: React.FC<StressTestViewProps> = ({
  cdo,
  currencySymbol
}) => {
  const [selectedScenarioId, setSelectedScenarioId] = useState<string>(
    PRESET_STRESS_SCENARIOS[0].id
  );

  // Custom scenario overrides
  const [customBtcDrop, setCustomBtcDrop] = useState<number>(-45);
  const [customDefaultMult, setCustomDefaultMult] = useState<number>(3.0);
  const [customRecoveryHaircut, setCustomRecoveryHaircut] = useState<number>(-30);
  const [customCorrelationShift, setCustomCorrelationShift] = useState<number>(35);
  const [customUsdtDrop, setCustomUsdtDrop] = useState<number>(-2);

  const activePreset = PRESET_STRESS_SCENARIOS.find(s => s.id === selectedScenarioId) || PRESET_STRESS_SCENARIOS[0];

  // Build active test scenario
  const currentScenario: StressScenario = selectedScenarioId === 'CUSTOM' ? {
    id: 'CUSTOM',
    name: 'Custom Rhino Desk Stress Test Matrix',
    category: 'COMBINED',
    description: 'Bespoke multi-factor macro credit & digital asset stress parameterization.',
    btcPriceChangePct: customBtcDrop,
    btcHaircutShiftPct: 15,
    usdtPriceChangePct: customUsdtDrop,
    usdtHaircutShiftPct: 10,
    creditDefaultMultiplier: customDefaultMult,
    recoveryRateHaircutPct: customRecoveryHaircut,
    correlationShiftPct: customCorrelationShift,
    interestRateShiftBps: 200
  } : activePreset;

  const stressOutput: StressTestOutput = runStressTestScenario(cdo, currentScenario);

  // Solvency badge styling
  let solvencyColor = 'border-[#2D5A27] text-[#2D5A27] bg-[#2D5A27]/15';
  if (stressOutput.solvencyStatus === 'IMPAIRED') {
    solvencyColor = 'border-[#F7931A] text-[#F7931A] bg-[#F7931A]/15';
  } else if (stressOutput.solvencyStatus === 'MARGIN_DEFICIT') {
    solvencyColor = 'border-[#F7931A] text-[#F7931A] bg-[#F7931A]/15';
  } else if (stressOutput.solvencyStatus === 'INSOLVENT') {
    solvencyColor = 'border-[#E04444] text-[#E04444] bg-[#E04444]/15';
  }

  return (
    <div id="stress-test-workspace" className="space-y-6 font-mono">
      {/* Top Banner */}
      <div className="bg-[#161618] border border-[#1F1F21] p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-xs">
            <span className="px-2 py-0.5 border border-[#F7931A] text-[#F7931A] font-semibold text-[10px] uppercase tracking-wider">
              Stress Testing Terminal
            </span>
            <span className={`px-2 py-0.5 rounded-sm text-[10px] font-bold border uppercase tracking-wider ${solvencyColor}`}>
              Solvency: {stressOutput.solvencyStatus}
            </span>
            <span className="text-[#555] uppercase text-[10px]">Basel III / BoE CCAR Matrix</span>
          </div>
          <h1 className="text-base font-bold text-white tracking-tight mt-1.5">
            Macro Credit & Digital Asset Extreme Shock Simulator
          </h1>
          <p className="text-xs text-[#777] mt-0.5">
            Evaluates tranche principal impairment, default cascades, and collateral margin calls under systemic crisis.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => setSelectedScenarioId('CUSTOM')}
            className={`px-3 py-1.5 text-xs font-bold uppercase tracking-[0.2em] transition-colors ${
              selectedScenarioId === 'CUSTOM'
                ? 'bg-[#2D5A27] text-white border border-[#2D5A27]'
                : 'bg-[#0F0F10] text-[#888] border border-[#1F1F21] hover:bg-[#1A1A1C] hover:text-white'
            }`}
          >
            Custom Matrix
          </button>
        </div>
      </div>

      {/* Preset Scenario Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {PRESET_STRESS_SCENARIOS.map(scen => (
          <button
            key={scen.id}
            onClick={() => setSelectedScenarioId(scen.id)}
            className={`p-4 text-left border transition-all ${
              selectedScenarioId === scen.id
                ? 'bg-[#1A1A1C] border-[#2D5A27] border-l-2'
                : 'bg-[#161618] border-[#1F1F21] hover:bg-[#1A1A1C]'
            }`}
          >
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-white truncate max-w-[200px]">{scen.name}</span>
              <span className="text-[9px] px-1.5 py-0.5 bg-[#0F0F10] text-[#555] border border-[#1F1F21] uppercase font-bold">
                {scen.category}
              </span>
            </div>
            <p className="text-[11px] text-[#777] mt-1.5 line-clamp-2">{scen.description}</p>
            <div className="mt-3 pt-2 border-t border-[#1F1F21] flex justify-between text-[10px] text-[#888]">
              <span className="text-[#E04444]">BTC: {scen.btcPriceChangePct}%</span>
              <span className="text-[#F7931A]">PD: {scen.creditDefaultMultiplier}x</span>
              <span className="text-white">ρ: +{scen.correlationShiftPct}%</span>
            </div>
          </button>
        ))}
      </div>

      {/* Custom Stress Matrix Parameter Sliders */}
      {selectedScenarioId === 'CUSTOM' && (
        <div className="bg-[#161618] border border-[#2D5A27]/50 p-5 space-y-4">
          <div className="text-xs font-bold text-[#2D5A27] uppercase tracking-[0.2em] flex items-center gap-1.5">
            <Sliders className="w-3.5 h-3.5" />
            Bespoke Stress Matrix Parameter Controls
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
            <div className="space-y-1.5 bg-[#0F0F10] p-3 border border-[#1F1F21]">
              <div className="flex justify-between text-[10px]">
                <span className="text-[#888] uppercase">BTC Spot Drop:</span>
                <span className="text-[#E04444] font-bold">{customBtcDrop}%</span>
              </div>
              <input
                type="range"
                min="-85"
                max="0"
                step="5"
                value={customBtcDrop}
                onChange={e => setCustomBtcDrop(Number(e.target.value))}
                className="w-full h-1.5 bg-[#1F1F21] rounded appearance-none cursor-pointer accent-[#E04444]"
              />
            </div>

            <div className="space-y-1.5 bg-[#0F0F10] p-3 border border-[#1F1F21]">
              <div className="flex justify-between text-[10px]">
                <span className="text-[#888] uppercase">Default Multiplier:</span>
                <span className="text-[#F7931A] font-bold">{customDefaultMult}x</span>
              </div>
              <input
                type="range"
                min="1.0"
                max="5.0"
                step="0.2"
                value={customDefaultMult}
                onChange={e => setCustomDefaultMult(Number(e.target.value))}
                className="w-full h-1.5 bg-[#1F1F21] rounded appearance-none cursor-pointer accent-[#F7931A]"
              />
            </div>

            <div className="space-y-1.5 bg-[#0F0F10] p-3 border border-[#1F1F21]">
              <div className="flex justify-between text-[10px]">
                <span className="text-[#888] uppercase">Recovery Haircut:</span>
                <span className="text-[#888] font-bold">{customRecoveryHaircut}%</span>
              </div>
              <input
                type="range"
                min="-60"
                max="0"
                step="5"
                value={customRecoveryHaircut}
                onChange={e => setCustomRecoveryHaircut(Number(e.target.value))}
                className="w-full h-1.5 bg-[#1F1F21] rounded appearance-none cursor-pointer accent-[#888]"
              />
            </div>

            <div className="space-y-1.5 bg-[#0F0F10] p-3 border border-[#1F1F21]">
              <div className="flex justify-between text-[10px]">
                <span className="text-[#888] uppercase">Correlation Shift (ρ):</span>
                <span className="text-[#2D5A27] font-bold">+{customCorrelationShift}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="60"
                step="5"
                value={customCorrelationShift}
                onChange={e => setCustomCorrelationShift(Number(e.target.value))}
                className="w-full h-1.5 bg-[#1F1F21] rounded appearance-none cursor-pointer accent-[#2D5A27]"
              />
            </div>
          </div>
        </div>
      )}

      {/* Stress Outcome KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#161618] border border-[#1F1F21] p-4">
          <div className="text-[10px] text-[#555] uppercase font-bold tracking-wider mb-1 flex items-center justify-between">
            <span>Stressed Loss</span>
            <TrendingDown className="w-3.5 h-3.5 text-[#E04444]" />
          </div>
          <div className="text-lg font-light text-[#E04444] tracking-tight">
            {currencySymbol}{(stressOutput.stressedPortfolioLossUsd / 1000000).toFixed(2)}M
          </div>
          <div className="text-[10px] text-[#555] mt-1">
            {(stressOutput.stressedPortfolioLossPct * 100).toFixed(2)}% Portfolio Loss
          </div>
        </div>

        <div className="bg-[#161618] border border-[#1F1F21] p-4">
          <div className="text-[10px] text-[#555] uppercase font-bold tracking-wider mb-1 flex items-center justify-between">
            <span>Stressed Collateral</span>
            <ShieldAlert className="w-3.5 h-3.5 text-[#F7931A]" />
          </div>
          <div className="text-lg font-light text-white tracking-tight">
            ${(stressOutput.stressedEligibleCollateralUsd / 1000000).toFixed(2)}M
          </div>
          <div className="text-[10px] text-[#555] mt-1">
            Required: ${(stressOutput.stressedRequiredMarginUsd / 1000000).toFixed(2)}M
          </div>
        </div>

        <div className="bg-[#161618] border border-[#1F1F21] p-4">
          <div className="text-[10px] text-[#555] uppercase font-bold tracking-wider mb-1 flex items-center justify-between">
            <span>Stressed Collateral Ratio</span>
            <Flame className="w-3.5 h-3.5 text-[#E04444]" />
          </div>
          <div className={`text-lg font-light tracking-tight ${
            stressOutput.stressedCollateralRatio >= 1.30 ? 'text-[#2D5A27]' :
            stressOutput.stressedCollateralRatio >= 1.10 ? 'text-[#F7931A]' : 'text-[#E04444]'
          }`}>
            {(stressOutput.stressedCollateralRatio * 100).toFixed(1)}% ({stressOutput.stressedCollateralRatio.toFixed(2)}x)
          </div>
          <div className="text-[10px] text-[#555] mt-1">
            Margin State: <strong className="text-white">{stressOutput.stressedMarginStatus}</strong>
          </div>
        </div>

        <div className="bg-[#161618] border border-[#1F1F21] p-4">
          <div className="text-[10px] text-[#555] uppercase font-bold tracking-wider mb-1 flex items-center justify-between">
            <span>CDO Solvency Outcome</span>
            <Zap className="w-3.5 h-3.5 text-[#2D5A27]" />
          </div>
          <div className="text-lg font-light text-white tracking-tight mt-1 flex items-center gap-1.5">
            {stressOutput.solvencyStatus === 'SOLVENT' && <CheckCircle2 className="w-4 h-4 text-[#2D5A27]" />}
            {stressOutput.solvencyStatus === 'IMPAIRED' && <AlertTriangle className="w-4 h-4 text-[#F7931A]" />}
            {stressOutput.solvencyStatus === 'INSOLVENT' && <XCircle className="w-4 h-4 text-[#E04444]" />}
            <span>{stressOutput.solvencyStatus}</span>
          </div>
          <div className="text-[10px] text-[#555] mt-1">
            Structure Capital Integrity
          </div>
        </div>
      </div>

      {/* Tranche Impairment Table */}
      <div className="bg-[#161618] border border-[#1F1F21] p-5 space-y-4">
        <div className="border-b border-[#1F1F21] pb-3">
          <h2 className="text-xs font-bold uppercase tracking-[0.2em] text-white flex items-center gap-2">
            <Layers className="w-4 h-4 text-[#2D5A27]" />
            Tranche Capital Impairment Under {currentScenario.name.toUpperCase()}
          </h2>
          <p className="text-[10px] text-[#555] uppercase mt-0.5">
            Tranche subordination protection & loss absorption breakdown
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-[#1F1F21] text-[#555] text-[10px] uppercase">
                <th className="pb-3 font-semibold">Tranche</th>
                <th className="pb-3 font-semibold text-right">Original Notional</th>
                <th className="pb-3 font-semibold text-right">Stressed Loss</th>
                <th className="pb-3 font-semibold text-right">Loss %</th>
                <th className="pb-3 font-semibold text-right">Remaining Principal</th>
                <th className="pb-3 font-semibold text-right">Impairment Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1F1F21] text-[#D1D1D1]">
              {stressOutput.trancheStressedLosses.map(tl => {
                const tranche = cdo.tranches.find(t => t.type === tl.trancheType);
                return (
                  <tr key={tl.trancheType} className="hover:bg-[#1A1A1C] transition-colors">
                    <td className="py-2.5 font-bold flex items-center space-x-2 text-white">
                      <span className={`w-2 h-2 rounded-full ${
                        tl.trancheType === 'EQUITY' ? 'bg-[#E04444]' :
                        tl.trancheType === 'JUNIOR' ? 'bg-[#F7931A]' :
                        tl.trancheType === 'MEZZANINE' ? 'bg-[#888]' : 'bg-[#2D5A27]'
                      }`}></span>
                      <span>{tranche?.name || tl.trancheType}</span>
                    </td>
                    <td className="py-2.5 text-right font-semibold text-white">
                      {currencySymbol}{((tranche?.notional || 0) / 1000000).toFixed(0)}M
                    </td>
                    <td className="py-2.5 text-right text-[#E04444] font-bold">
                      {currencySymbol}{(tl.lossUsd / 1000000).toFixed(2)}M
                    </td>
                    <td className="py-2.5 text-right text-[#E04444]">
                      {(tl.lossPct * 100).toFixed(1)}%
                    </td>
                    <td className="py-2.5 text-right font-bold text-white">
                      {currencySymbol}{(tl.remainingPrincipalUsd / 1000000).toFixed(2)}M
                    </td>
                    <td className="py-2.5 text-right">
                      <span className={`px-2 py-0.5 rounded-sm text-[10px] font-bold border uppercase tracking-wider ${
                        tl.impairmentState === 'UNIMPAIRED' ? 'bg-[#2D5A27]/15 text-[#2D5A27] border-[#2D5A27]/30' :
                        tl.impairmentState === 'PARTIALLY_IMPAIRED' ? 'bg-[#F7931A]/15 text-[#F7931A] border-[#F7931A]/30' :
                        'bg-[#E04444]/15 text-[#E04444] border-[#E04444]/30'
                      }`}>
                        {tl.impairmentState.replace('_', ' ')}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
