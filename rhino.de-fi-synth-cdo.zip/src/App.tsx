// ============================================================================
// RHINO BANK | RHINOQUANT SYNTH-CDO
// Institutional Structured Credit & Synthetic CDO Platform (Sophisticated Dark)
// ============================================================================

import React, { useState, useEffect } from 'react';
import { 
  SyntheticCDO, 
  ReferenceAsset, 
  UserRole, 
  AuditLogEntry,
  OraclePriceFeed
} from './types';
import { 
  SAMPLE_CDO_DEAL, 
  DEFAULT_ORACLE_PRICES, 
  generateSyntheticReferencePortfolio 
} from './services/portfolioData';
import { Header } from './components/Header';
import { CdoDeskView } from './components/CdoDeskView';
import { PortfolioView } from './components/PortfolioView';
import { MonteCarloView } from './components/MonteCarloView';
import { CollateralDeskView } from './components/CollateralDeskView';
import { StressTestView } from './components/StressTestView';
import { DeFiTranchesView } from './components/DeFiTranchesView';
import { RiskRarocView } from './components/RiskRarocView';
import { ComplianceView } from './components/ComplianceView';
import { ApiTerminalView } from './components/ApiTerminalView';
import { CodeArchitectureView } from './components/CodeArchitectureView';
import { AuditLedgerView } from './components/AuditLedgerView';
import { 
  Layers, 
  Database, 
  Cpu, 
  Coins, 
  ShieldAlert, 
  KeyRound, 
  TrendingUp, 
  ShieldCheck, 
  Terminal, 
  FileCode2, 
  History
} from 'lucide-react';

export default function App() {
  // Global Deal State
  const [activeCDO, setActiveCDO] = useState<SyntheticCDO>(SAMPLE_CDO_DEAL);
  const [portfolio, setPortfolio] = useState<ReferenceAsset[]>(() =>
    generateSyntheticReferencePortfolio(1000, 1000000000)
  );

  // Active Navigation & Role State
  const [activeTab, setActiveTab] = useState<string>('CDO_DESK');
  const [currentUserRole, setCurrentUserRole] = useState<UserRole>('Structurer');
  const [currencySymbol] = useState<string>('£');

  // Live Oracle Feeds
  const [oraclePrices, setOraclePrices] = useState<OraclePriceFeed>(DEFAULT_ORACLE_PRICES);

  // Global Cryptographic Audit Log
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([
    {
      id: 'LOG-0001',
      blockNumber: 19482010,
      timestamp: '2026-08-25T06:00:00Z',
      action: 'DEAL_ORIGINATION',
      actor: 'Helena Sterling (Head of Structuring)',
      role: 'Structurer',
      cdoDealCode: 'RHINO-SYNTH-I',
      ipLocation: 'London City Enclave (Node-01)',
      status: 'VERIFIED',
      txHash: '0x3a4f8910b21a8f9c9402e8471e98d281a94e82b719482010',
      details: 'Originated RhinoQuant Synthetic CDO 2026-1 (£1.0B notional) referencing 1,000 diversified corporate & DeFi exposures.'
    },
    {
      id: 'LOG-0002',
      blockNumber: 19482015,
      timestamp: '2026-08-25T06:15:00Z',
      action: 'COLLATERAL_DEPOSIT',
      actor: 'Marcus Thorne (Custody Lead)',
      role: 'Treasury',
      cdoDealCode: 'RHINO-SYNTH-I',
      ipLocation: 'London City Enclave (Node-02)',
      status: 'VERIFIED',
      txHash: '0x9924e819b18374a9f992019481928374b661928471928374',
      details: 'Deposited 1,000 BTC ($96.45M gross) and 25,000,000 USDT ($25.0M gross) into segregated institutional vault.'
    },
    {
      id: 'LOG-0003',
      blockNumber: 19482020,
      timestamp: '2026-08-25T06:30:00Z',
      action: 'SIMULATION_VALIDATION',
      actor: 'Alastair Vance (CRO)',
      role: 'Risk Manager',
      cdoDealCode: 'RHINO-SYNTH-I',
      ipLocation: 'London City Enclave (Node-01)',
      status: 'VERIFIED',
      txHash: '0x77c294819a847182948192837461928374a8192837461928',
      details: 'Validated 1-Factor Gaussian Copula Monte Carlo (50,000 paths). 99% VaR: £18.5M (1.85%).'
    }
  ]);

  // Handle deposit collateral from Collateral Desk
  const handleDepositCollateral = (asset: 'BTC' | 'USDT' | 'FIAT', amount: number) => {
    setActiveCDO(prev => {
      const col = { ...prev.collateral };
      if (asset === 'BTC') col.btcQty += amount;
      else if (asset === 'USDT') col.usdtQty += amount;
      else col.fiatCash += amount;
      return { ...prev, collateral: col };
    });

    const newLog: AuditLogEntry = {
      id: `LOG-000${auditLogs.length + 1}`,
      blockNumber: 19482020 + auditLogs.length,
      timestamp: new Date().toISOString(),
      action: 'COLLATERAL_TOP_UP',
      actor: `${currentUserRole} Desk Officer`,
      role: currentUserRole,
      cdoDealCode: activeCDO.dealCode,
      ipLocation: 'London City Enclave (Node-01)',
      status: 'VERIFIED',
      txHash: '0x' + Math.random().toString(16).substring(2, 42),
      details: `Added ${amount.toLocaleString()} ${asset} into Rhino segregated custody vault.`
    };

    setAuditLogs(prev => [newLog, ...prev]);
  };

  // Real-time market oracle ticker ticks
  useEffect(() => {
    const interval = setInterval(() => {
      setOraclePrices(prev => {
        const btcDelta = (Math.random() - 0.49) * 25;
        const usdtDelta = (Math.random() - 0.5) * 0.00005;
        return {
          ...prev,
          btcUsd: Math.max(90000, prev.btcUsd + btcDelta),
          usdtUsd: +(prev.usdtUsd + usdtDelta).toFixed(4),
          lastUpdated: new Date().toISOString()
        };
      });
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const navItems = [
    { id: 'CDO_DESK', num: '01', label: 'CDO Structurer', icon: Layers, section: 'core' },
    { id: 'PORTFOLIO', num: '02', label: 'Credit Portfolios', icon: Database, section: 'core' },
    { id: 'MONTE_CARLO', num: '03', label: 'Copula Monte Carlo', icon: Cpu, section: 'core' },
    { id: 'COLLATERAL', num: '04', label: 'DeFi Collateral', icon: Coins, section: 'core' },
    { id: 'STRESS_TEST', num: '05', label: 'Stress Testing', icon: ShieldAlert, section: 'core' },
    { id: 'DEFI_TRANCHES', num: '06', label: 'ERC-3643 Tranches', icon: KeyRound, section: 'core' },
    { id: 'RISK_RAROC', num: '07', label: 'Balance Sheet RAROC', icon: TrendingUp, section: 'core' },
    { id: 'COMPLIANCE', num: '08', label: 'Multi-Sig Governance', icon: ShieldCheck, section: 'governance' },
    { id: 'API_TERMINAL', num: '09', label: 'REST API Terminal', icon: Terminal, section: 'governance' },
    { id: 'ARCHITECTURE', num: '10', label: 'Quant Code Suite', icon: FileCode2, section: 'governance' },
    { id: 'AUDIT_TRAIL', num: '11', label: 'Audit Trail Ledger', icon: History, section: 'governance' },
  ];

  return (
    <div className="bg-[#0A0A0B] text-[#D1D1D1] font-mono h-screen w-screen flex overflow-hidden selection:bg-[#2D5A27] selection:text-white">
      {/* Institutional Sidebar */}
      <aside className="w-60 xl:w-64 border-r border-[#1F1F21] flex flex-col bg-[#0F0F10] shrink-0 select-none">
        {/* Brand Header */}
        <div className="p-5 border-b border-[#1F1F21]">
          <div className="flex items-center gap-2.5">
            <div className="w-6 h-6 bg-[#2D5A27] rounded-sm flex items-center justify-center font-bold text-white text-[11px] shadow-sm">
              RB
            </div>
            <div>
              <span className="font-semibold text-white tracking-widest text-xs uppercase block">
                Rhino Bank
              </span>
            </div>
          </div>
          <div className="text-[10px] text-[#555] mt-1 font-mono tracking-tighter uppercase">
            Quant Terminal v3.7.0
          </div>
        </div>

        {/* Navigation Item Tree */}
        <nav className="flex-1 px-3 py-3 space-y-0.5 overflow-y-auto">
          <div className="px-3 py-1.5 text-[9px] font-bold text-[#555] uppercase tracking-widest">
            Core Systems
          </div>
          {navItems.filter(i => i.section === 'core').map(item => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-md text-xs transition-colors text-left ${
                  isActive
                    ? 'text-white bg-[#1A1A1C] rounded-md border-l-2 border-[#2D5A27] font-semibold'
                    : 'text-[#888] hover:text-white hover:bg-[#161618]'
                }`}
              >
                <span className={`text-[10px] font-mono ${isActive ? 'text-[#2D5A27]' : 'text-[#555]'}`}>
                  {item.num}
                </span>
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-white' : 'text-[#666]'}`} />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}

          <div className="pt-4 px-3 py-1.5 text-[9px] font-bold text-[#555] uppercase tracking-widest">
            Governance & Repo
          </div>
          {navItems.filter(i => i.section === 'governance').map(item => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-md text-xs transition-colors text-left ${
                  isActive
                    ? 'text-white bg-[#1A1A1C] rounded-md border-l-2 border-[#2D5A27] font-semibold'
                    : 'text-[#888] hover:text-white hover:bg-[#161618]'
                }`}
              >
                <span className={`text-[10px] font-mono ${isActive ? 'text-[#2D5A27]' : 'text-[#555]'}`}>
                  {item.num}
                </span>
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-white' : 'text-[#666]'}`} />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Bottom Telemetry Status Box */}
        <div className="p-3.5 border-t border-[#1F1F21] bg-[#0A0A0B] text-[10px] space-y-1.5">
          <div className="flex justify-between items-center">
            <span className="text-[#555] uppercase">BTC Node</span>
            <span className="text-[#2D5A27] font-bold flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-[#2D5A27]"></span>
              CONNECTED
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-[#555] uppercase">Monte Carlo</span>
            <span className="text-[#2D5A27] font-bold">AVX-512</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-[#555] uppercase">HSM Clearance</span>
            <span className="text-[#26A17B] font-bold">LEVEL-4 QIB</span>
          </div>
        </div>
      </aside>

      {/* Main Terminal Viewport */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Institutional Top Header */}
        <Header
          activeCDO={activeCDO}
          onSelectCDO={setActiveCDO}
          currentUserRole={currentUserRole}
          setCurrentUserRole={setCurrentUserRole}
          oraclePrices={oraclePrices}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
        />

        {/* Dynamic Workspace Body */}
        <main className="flex-1 overflow-y-auto p-6 bg-[#0A0A0B] space-y-6">
          {activeTab === 'CDO_DESK' && (
            <CdoDeskView
              cdo={activeCDO}
              onNavigateTab={(tab) => {
                if (tab === 'copula-montecarlo') setActiveTab('MONTE_CARLO');
                else if (tab === 'collateral-desk') setActiveTab('COLLATERAL');
                else if (tab === 'portfolio-viewer') setActiveTab('PORTFOLIO');
                else if (tab === 'stress-testing') setActiveTab('STRESS_TEST');
              }}
            />
          )}

          {activeTab === 'PORTFOLIO' && (
            <PortfolioView
              portfolio={portfolio}
              portfolioName={activeCDO.name}
              currencySymbol={currencySymbol}
            />
          )}

          {activeTab === 'MONTE_CARLO' && (
            <MonteCarloView
              cdo={activeCDO}
              portfolio={portfolio}
              currencySymbol={currencySymbol}
            />
          )}

          {activeTab === 'COLLATERAL' && (
            <CollateralDeskView
              collateral={activeCDO.collateral}
              currencySymbol={currencySymbol}
              onDepositCollateral={handleDepositCollateral}
            />
          )}

          {activeTab === 'STRESS_TEST' && (
            <StressTestView
              cdo={activeCDO}
              currencySymbol={currencySymbol}
            />
          )}

          {activeTab === 'DEFI_TRANCHES' && (
            <DeFiTranchesView
              cdo={activeCDO}
              currentUserRole={currentUserRole}
              currencySymbol={currencySymbol}
            />
          )}

          {activeTab === 'RISK_RAROC' && (
            <RiskRarocView
              cdo={activeCDO}
              currencySymbol={currencySymbol}
            />
          )}

          {activeTab === 'COMPLIANCE' && (
            <ComplianceView
              cdo={activeCDO}
              currentUserRole={currentUserRole}
            />
          )}

          {activeTab === 'API_TERMINAL' && (
            <ApiTerminalView
              cdo={activeCDO}
              portfolio={portfolio}
            />
          )}

          {activeTab === 'ARCHITECTURE' && (
            <CodeArchitectureView />
          )}

          {activeTab === 'AUDIT_TRAIL' && (
            <AuditLedgerView
              auditLogs={auditLogs}
            />
          )}
        </main>
      </div>
    </div>
  );
}
