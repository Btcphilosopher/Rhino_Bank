import React, { useState } from 'react';
import { RhinoProvider, useRhino } from './context/RhinoContext';
import { Header } from './components/Header';
import { ExecutiveDashboard } from './components/ExecutiveDashboard';
import { TraderWorkspace } from './components/TraderWorkspace';
import { SpotMarketsView } from './components/SpotMarketsView';
import { ForwardCurvesView } from './components/ForwardCurvesView';
import { PhysicalTwinView } from './components/PhysicalTwinView';
import { ArbitrageScreenerView } from './components/ArbitrageScreenerView';
import { RiskEngineView } from './components/RiskEngineView';
import { TradingSimulatorView } from './components/TradingSimulatorView';
import { ResearchMlView } from './components/ResearchMlView';
import { GovernanceAuditApiView } from './components/GovernanceAuditApiView';
import { AlertsDrawer } from './components/AlertsDrawer';
import { Shield, Info } from 'lucide-react';

const MainAppContent: React.FC = () => {
  const { currentView } = useRhino();
  const [isAlertsOpen, setIsAlertsOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#0a0a0b] text-gray-200 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* Platform Header */}
      <Header onToggleAlerts={() => setIsAlertsOpen(!isAlertsOpen)} />

      {/* Main View Area */}
      <main className="flex-1 bg-[#0a0a0b] overflow-hidden">
        {currentView === 'EXECUTIVE' && <ExecutiveDashboard />}
        {currentView === 'TRADER' && <TraderWorkspace />}
        {currentView === 'SPOT_MARKETS' && <SpotMarketsView />}
        {currentView === 'CURVES_CRACK' && <ForwardCurvesView />}
        {currentView === 'PHYSICAL_TWIN' && <PhysicalTwinView />}
        {currentView === 'ARBITRAGE' && <ArbitrageScreenerView />}
        {currentView === 'RISK_MONTECARLO' && <RiskEngineView />}
        {currentView === 'SIMULATOR' && <TradingSimulatorView />}
        {currentView === 'RESEARCH_ML' && <ResearchMlView />}
        {currentView === 'GOVERNANCE_AUDIT' && <GovernanceAuditApiView />}
      </main>

      {/* Platform Regulatory & Compliance Footer */}
      <footer className="bg-[#0d0d0f] border-t border-gray-800/80 px-4 py-2 text-[11px] font-mono text-gray-400 flex flex-col sm:flex-row items-center justify-between gap-2">
        <div className="flex items-center space-x-2">
          <Shield className="w-3.5 h-3.5 text-blue-500" />
          <span>RHINOQUANT ENERGY MARKETS v2.4 ENTERPRISE • RHINO BANK QUANTITATIVE DESK</span>
        </div>
        <div className="flex items-center space-x-4">
          <span className="flex items-center space-x-1">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>DATA ENGINE: SIMULATED LIVE</span>
          </span>
          <span className="text-gray-700">|</span>
          <span className="text-blue-400">PAPER SIMULATOR ONLY (NO EXTERNAL TRADE EXECUTION)</span>
        </div>
      </footer>

      {/* System Alerts Side Drawer */}
      <AlertsDrawer isOpen={isAlertsOpen} onClose={() => setIsAlertsOpen(false)} />
    </div>
  );
};

export default function App() {
  return (
    <RhinoProvider>
      <MainAppContent />
    </RhinoProvider>
  );
}
