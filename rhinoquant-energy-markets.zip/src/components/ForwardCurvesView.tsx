import React, { useState } from 'react';
import { useRhino } from '../context/RhinoContext';
import { 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid, 
  Legend 
} from 'recharts';
import { 
  TrendingUp, 
  Sliders, 
  Zap, 
  Layers, 
  RefreshCw,
  Cpu
} from 'lucide-react';

export const ForwardCurvesView: React.FC = () => {
  const { 
    forwardTenors, 
    products, 
    refineries, 
    updateRefineryThroughput,
    crudeGrades 
  } = useRhino();

  const [selectedCommodity, setSelectedCommodity] = useState<'BRENT' | 'WTI' | 'TTF' | 'HH'>('BRENT');
  const [selectedRefineryId, setSelectedRefineryId] = useState<string>(refineries[0]?.id || 'ref-usgc-complex');

  const brentSpot = crudeGrades.find(g => g.code === 'BRENT')?.baseSpotPrice || 78.45;
  const wtiSpot = crudeGrades.find(g => g.code === 'WTI')?.baseSpotPrice || 74.30;
  const rbobGasoline = products.find(p => p.code === 'GASOLINE')?.spotPrice || 98.40;
  const ulsdDiesel = products.find(p => p.code === 'DIESEL')?.spotPrice || 104.20;

  // Calculate 3-2-1 Crack Margin ($/bbl)
  const crack321Wti = ((2 * rbobGasoline) + (1 * ulsdDiesel) - (3 * wtiSpot)) / 3;
  const crack321Brent = ((2 * rbobGasoline) + (1 * ulsdDiesel) - (3 * brentSpot)) / 3;

  // Selected refinery model
  const activeRefinery = refineries.find(r => r.id === selectedRefineryId) || refineries[0];

  // Curve slope & regime classification
  const promptPrice = forwardTenors[0]?.brentPrice || 78.45;
  const m12Price = forwardTenors[forwardTenors.length - 1]?.brentPrice || 77.10;
  const curveSpread = m12Price - promptPrice;
  const regime = curveSpread > 0.5 ? 'CONTANGO' : curveSpread < -0.5 ? 'BACKWARDATION' : 'FLAT';

  return (
    <div className="p-4 space-y-4 overflow-y-auto max-h-[calc(100vh-100px)]">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-[#111114] border border-gray-800 p-3.5 rounded-lg">
        <div>
          <h1 className="text-lg font-bold text-white font-sans flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-blue-500" />
            <span>Forward Curves, Contango Analysis & Crack Spreads</span>
          </h1>
          <p className="text-xs text-gray-400 mt-0.5">
            Prompt M1-M12 futures structure, calendar spread curves, refinery 3-2-1/5-3-2 cracks & digital twin yield simulator.
          </p>
        </div>

        <div className="flex bg-[#0a0a0b] p-1 rounded border border-gray-800 text-xs font-mono">
          {(['BRENT', 'WTI', 'TTF', 'HH'] as const).map((c) => (
            <button
              key={c}
              onClick={() => setSelectedCommodity(c)}
              className={`px-3 py-1 rounded transition-colors ${selectedCommodity === c ? 'bg-blue-600 text-white font-bold' : 'text-gray-400 hover:text-gray-200'}`}
            >
              {c} CURVE
            </button>
          ))}
        </div>
      </div>

      {/* Grid Row 1: Forward Curve Chart & Regime Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Curve Chart (2 Spans) */}
        <div className="lg:col-span-2 bg-[#111114] border border-gray-800 rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-gray-800 pb-2">
            <span className="text-[10px] uppercase font-bold tracking-widest text-gray-400 font-mono">FORWARD TENOR CURVE (PROMPT TO M12)</span>
            <span className={`px-2 py-0.5 rounded text-xs font-mono font-bold ${
              regime === 'CONTANGO' ? 'bg-blue-950/40 text-blue-400 border border-blue-800/60' : 'bg-sky-500/20 text-sky-400 border border-sky-500/30'
            }`}>
              REGIME: {regime}
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={forwardTenors}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1f2937" vertical={false} />
                <XAxis dataKey="monthCode" stroke="#9ca3af" fontSize={11} />
                <YAxis domain={['auto', 'auto']} stroke="#9ca3af" fontSize={11} tickFormatter={(v) => `$${v}`} />
                <Tooltip contentStyle={{ backgroundColor: '#111114', borderColor: '#374151', borderRadius: '6px', fontSize: '11px', color: '#f3f4f6' }} />
                <Legend wrapperStyle={{ fontSize: '11px', color: '#9ca3af' }} />
                <Line type="monotone" dataKey="brentPrice" name="Brent Futures" stroke="#2563eb" strokeWidth={2} activeDot={{ r: 6 }} />
                <Line type="monotone" dataKey="wtiPrice" name="WTI Midland" stroke="#10b981" strokeWidth={2} />
                <Line type="monotone" dataKey="ttfPrice" name="TTF Gas ($/MMBtu)" stroke="#06b6d4" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Structure Metrics (1 Span) */}
        <div className="bg-[#111114] border border-gray-800 rounded-lg p-4 space-y-3 font-mono text-xs">
          <div className="border-b border-gray-800 pb-2 font-bold text-gray-200 flex justify-between">
            <span>CURVE STRUCTURE METRICS</span>
            <span className="text-blue-400">{selectedCommodity}</span>
          </div>

          <div className="space-y-2">
            <div className="bg-[#0a0a0b] p-2.5 rounded border border-gray-800 flex justify-between">
              <span className="text-gray-400">Prompt M1 Price:</span>
              <span className="text-gray-100 font-bold">${promptPrice.toFixed(2)}</span>
            </div>
            <div className="bg-[#0a0a0b] p-2.5 rounded border border-gray-800 flex justify-between">
              <span className="text-gray-400">M12 Month Price:</span>
              <span className="text-gray-100 font-bold">${m12Price.toFixed(2)}</span>
            </div>
            <div className="bg-[#0a0a0b] p-2.5 rounded border border-gray-800 flex justify-between">
              <span className="text-gray-400">M1 - M12 Spread:</span>
              <span className={`font-bold ${curveSpread >= 0 ? 'text-blue-400' : 'text-sky-400'}`}>
                {curveSpread >= 0 ? '+' : ''}${curveSpread.toFixed(2)} / bbl
              </span>
            </div>
            <div className="bg-[#0a0a0b] p-2.5 rounded border border-gray-800 flex justify-between">
              <span className="text-gray-400">Historical Slope Percentile:</span>
              <span className="text-gray-200 font-bold">62nd Percentile</span>
            </div>
          </div>
        </div>
      </div>

      {/* Grid Row 2: Crack Spreads & Refinery Digital Twin */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Crack Spread Engine Panel */}
        <div className="bg-[#111114] border border-gray-800 rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-gray-800 pb-2">
            <span className="text-[10px] uppercase font-bold tracking-widest text-gray-400 font-mono flex items-center gap-2">
              <Sliders className="w-4 h-4 text-emerald-400" />
              <span>REFINERY CRACK SPREAD ANALYTICS</span>
            </span>
            <span className="text-[10px] text-gray-400 font-mono">USGC & NWE Benchmarks</span>
          </div>

          <div className="grid grid-cols-2 gap-3 font-mono text-xs">
            <div className="bg-[#0a0a0b] p-3.5 rounded border border-gray-800 space-y-1">
              <div className="text-gray-400 text-[10px]">3-2-1 CRACK SPREAD (WTI)</div>
              <div className="text-2xl font-extrabold text-emerald-400">${crack321Wti.toFixed(2)} <span className="text-xs font-normal text-gray-400">/ bbl</span></div>
              <div className="text-[10px] text-gray-500 mt-1">3 bbl Crude → 2 bbl Gasoline + 1 bbl Diesel</div>
            </div>

            <div className="bg-[#0a0a0b] p-3.5 rounded border border-gray-800 space-y-1">
              <div className="text-gray-400 text-[10px]">3-2-1 CRACK SPREAD (BRENT)</div>
              <div className="text-2xl font-extrabold text-emerald-400">${crack321Brent.toFixed(2)} <span className="text-xs font-normal text-gray-400">/ bbl</span></div>
              <div className="text-[10px] text-gray-500 mt-1">North Sea Refined Product Margin</div>
            </div>
          </div>

          <div className="bg-[#0a0a0b] p-3 rounded border border-gray-800 space-y-2 font-mono text-xs">
            <div className="text-gray-300 font-bold border-b border-gray-800 pb-1">Refined Petroleum Product Spot Prices</div>
            <div className="grid grid-cols-3 gap-2">
              {products.map(p => (
                <div key={p.id} className="bg-[#111114] p-2 rounded">
                  <div className="text-[10px] text-gray-400">{p.name}</div>
                  <div className="font-bold text-gray-100">${p.spotPrice.toFixed(2)}</div>
                  <div className="text-[10px] text-emerald-400">Diff: +${p.differential.toFixed(2)}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Digital Twin Refinery Simulator Panel */}
        <div className="bg-[#111114] border border-gray-800 rounded-lg p-4 space-y-3 font-mono text-xs">
          <div className="flex items-center justify-between border-b border-gray-800 pb-2">
            <span className="text-[10px] uppercase font-bold tracking-widest text-gray-400 font-mono flex items-center gap-2">
              <Cpu className="w-4 h-4 text-blue-400" />
              <span>DIGITAL TWIN REFINERY MODEL</span>
            </span>
            <select
              value={selectedRefineryId}
              onChange={e => setSelectedRefineryId(e.target.value)}
              className="bg-[#0a0a0b] text-blue-400 font-bold border border-gray-800 px-2 py-0.5 rounded text-xs"
            >
              {refineries.map(r => (
                <option key={r.id} value={r.id}>{r.name}</option>
              ))}
            </select>
          </div>

          <div className="bg-[#0a0a0b] p-3 rounded border border-gray-800 space-y-2">
            <div className="flex justify-between items-center text-gray-300 font-sans font-bold">
              <span>{activeRefinery.name} ({activeRefinery.location})</span>
              <span className="text-emerald-400 text-xs font-mono font-normal">Cap: {activeRefinery.capacityBpd.toLocaleString()} bpd</span>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-gray-400">
                <span>Crude Throughput (bpd):</span>
                <span className="text-gray-100 font-bold">{activeRefinery.currentThroughputBpd.toLocaleString()} bpd</span>
              </div>
              <input
                type="range"
                min="100000"
                max={activeRefinery.capacityBpd}
                step="10000"
                value={activeRefinery.currentThroughputBpd}
                onChange={e => updateRefineryThroughput(activeRefinery.id, Number(e.target.value))}
                className="w-full accent-blue-600 bg-gray-800"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div className="bg-[#0a0a0b] p-2.5 rounded border border-gray-800 space-y-1">
              <div className="text-gray-400 text-[10px]">NET MARGIN PER BBL</div>
              <div className="text-lg font-bold text-emerald-400">${activeRefinery.netMarginPerBbl.toFixed(2)} / bbl</div>
            </div>
            <div className="bg-[#0a0a0b] p-2.5 rounded border border-gray-800 space-y-1">
              <div className="text-gray-400 text-[10px]">EST. DAILY NET PROFIT</div>
              <div className="text-lg font-bold text-blue-400">${(activeRefinery.dailyProfit / 1e6).toFixed(2)}M / day</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
