import React, { useState } from 'react';
import { useRhino } from '../context/RhinoContext';
import { ModelGovernance, AuditLogEntry } from '../types';
import { 
  FileText, 
  ShieldCheck, 
  Terminal, 
  Code, 
  Play, 
  CheckCircle2, 
  Search, 
  Info 
} from 'lucide-react';

export const GovernanceAuditApiView: React.FC = () => {
  const { governanceModels, auditLogs, userRole } = useRhino();

  const [activeTab, setActiveTab] = useState<'GOVERNANCE' | 'AUDIT_LOGS' | 'API_SANDBOX'>('GOVERNANCE');
  const [selectedApiEndpoint, setSelectedApiEndpoint] = useState<string>('/api/v1/health');
  const [apiResponse, setApiResponse] = useState<any>(null);
  const [loadingApi, setLoadingApi] = useState<boolean>(false);

  const handleTestApiCall = async (endpoint: string) => {
    setSelectedApiEndpoint(endpoint);
    setLoadingApi(true);
    setApiResponse(null);

    try {
      const res = await fetch(endpoint);
      const data = await res.json();
      setApiResponse(data);
    } catch (err: any) {
      setApiResponse({ error: err.message });
    } finally {
      setLoadingApi(false);
    }
  };

  return (
    <div className="p-4 space-y-4 overflow-y-auto max-h-[calc(100vh-100px)]">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-[#111114] border border-gray-800 p-3.5 rounded-lg">
        <div>
          <h1 className="text-lg font-bold text-white font-sans flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-500" />
            <span>Model Governance, Audit Trail & API Explorer</span>
          </h1>
          <p className="text-xs text-gray-400 mt-0.5">
            Model validation governance, immutable audit logs of user actions & enterprise REST API integration endpoints.
          </p>
        </div>

        <div className="flex bg-[#0a0a0b] p-1 rounded border border-gray-800 text-xs font-mono">
          <button
            onClick={() => setActiveTab('GOVERNANCE')}
            className={`px-3 py-1 rounded transition-colors ${activeTab === 'GOVERNANCE' ? 'bg-blue-600 text-white font-bold' : 'text-gray-400 hover:text-gray-200'}`}
          >
            MODEL GOVERNANCE
          </button>
          <button
            onClick={() => setActiveTab('AUDIT_LOGS')}
            className={`px-3 py-1 rounded transition-colors ${activeTab === 'AUDIT_LOGS' ? 'bg-blue-600 text-white font-bold' : 'text-gray-400 hover:text-gray-200'}`}
          >
            AUDIT TRAIL LOGS
          </button>
          <button
            onClick={() => setActiveTab('API_SANDBOX')}
            className={`px-3 py-1 rounded transition-colors ${activeTab === 'API_SANDBOX' ? 'bg-blue-600 text-white font-bold' : 'text-gray-400 hover:text-gray-200'}`}
          >
            API EXPLORER
          </button>
        </div>
      </div>

      {/* Tab 1: MODEL GOVERNANCE */}
      {activeTab === 'GOVERNANCE' && (
        <div className="space-y-4">
          <div className="bg-[#111114] border border-gray-800 rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-gray-800 pb-2">
              <span className="text-[10px] uppercase font-bold tracking-widest text-gray-400 font-mono flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>QUANTITATIVE MODEL GOVERNANCE REGISTRY</span>
              </span>
              <span className="text-[10px] text-gray-400 font-mono">Compliance Requirement 58</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {governanceModels.map(m => (
                <div key={m.modelId} className="bg-[#0a0a0b] border border-gray-800 p-4 rounded-lg space-y-3 font-mono text-xs">
                  <div className="flex justify-between items-center border-b border-gray-800 pb-2">
                    <span className="font-bold text-white font-sans text-sm">{m.name}</span>
                    <span className="bg-emerald-500/20 text-emerald-400 text-[10px] px-2 py-0.5 rounded font-bold">
                      {m.validationStatus}
                    </span>
                  </div>

                  <div className="space-y-1 text-gray-400 text-[11px]">
                    <div>Model ID: <span className="text-blue-400 font-bold">{m.modelId}</span></div>
                    <div>Version: <span className="text-gray-200">{m.version}</span></div>
                    <div>Author: <span className="text-gray-200">{m.author}</span></div>
                    <div>Validated: <span className="text-gray-200">{m.lastValidatedDate}</span></div>
                  </div>

                  <div className="space-y-1 pt-1 border-t border-gray-800 text-[10px]">
                    <div className="text-gray-400">Inputs: <span className="text-gray-300">{m.inputs.join(', ')}</span></div>
                    <div className="text-gray-400">Outputs: <span className="text-gray-300">{m.outputs.join(', ')}</span></div>
                  </div>

                  <div className="bg-[#111114] p-2 rounded text-[10px] text-gray-400 border border-gray-800">
                    <span className="text-blue-400 font-bold">Assumptions: </span>{m.assumptions}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: AUDIT TRAIL LOGS */}
      {activeTab === 'AUDIT_LOGS' && (
        <div className="bg-[#111114] border border-gray-800 rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-gray-800 pb-2">
            <span className="text-[10px] uppercase font-bold tracking-widest text-gray-400 font-mono flex items-center gap-2">
              <Terminal className="w-4 h-4 text-blue-400" />
              <span>IMMUTABLE AUDIT LOG & REPRODUCIBILITY TRAIL</span>
            </span>
            <span className="text-[10px] text-gray-400 font-mono">Total Logged Actions: {auditLogs.length}</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left font-mono text-xs">
              <thead>
                <tr className="border-b border-gray-800 text-gray-400 text-[11px]">
                  <th className="py-2 px-2">TIMESTAMP</th>
                  <th className="py-2 px-2">USER</th>
                  <th className="py-2 px-2">ROLE</th>
                  <th className="py-2 px-2">MODULE</th>
                  <th className="py-2 px-2">ACTION</th>
                  <th className="py-2 px-2">ACTION DETAILS</th>
                </tr>
              </thead>
              <tbody>
                {auditLogs.map(log => (
                  <tr key={log.id} className="border-b border-gray-800/60 hover:bg-gray-800/40">
                    <td className="py-2 px-2 text-gray-400 text-[11px] whitespace-nowrap">{log.timestamp}</td>
                    <td className="py-2 px-2 font-bold text-gray-200 font-sans">{log.user}</td>
                    <td className="py-2 px-2 text-blue-400 font-bold text-[10px]">{log.role}</td>
                    <td className="py-2 px-2 text-blue-400 text-[10px]">{log.module}</td>
                    <td className="py-2 px-2 font-bold text-emerald-400">{log.action}</td>
                    <td className="py-2 px-2 text-gray-300">{log.details}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 3: API EXPLORER */}
      {activeTab === 'API_SANDBOX' && (
        <div className="bg-[#111114] border border-gray-800 rounded-lg p-4 space-y-4 font-mono text-xs">
          <div className="flex items-center justify-between border-b border-gray-800 pb-2">
            <span className="text-[10px] uppercase font-bold tracking-widest text-gray-400 font-mono flex items-center gap-2">
              <Code className="w-4 h-4 text-blue-400" />
              <span>ENTERPRISE REST API ENDPOINT EXPLORER</span>
            </span>
            <span className="text-emerald-400 font-bold">Requirement 60 APIs</span>
          </div>

          <div className="flex flex-wrap gap-2">
            {[
              '/api/v1/health',
              '/api/v1/markets'
            ].map(ep => (
              <button
                key={ep}
                onClick={() => handleTestApiCall(ep)}
                className={`px-3 py-1.5 rounded border transition-colors ${
                  selectedApiEndpoint === ep ? 'bg-blue-600 text-white font-bold border-blue-500' : 'bg-[#0a0a0b] text-gray-300 border-gray-800 hover:text-white'
                }`}
              >
                GET {ep}
              </button>
            ))}
          </div>

          {/* Response Box */}
          <div className="bg-[#0a0a0b] p-4 rounded border border-gray-800 space-y-2">
            <div className="flex justify-between items-center text-gray-400 border-b border-gray-800 pb-2">
              <span>ENDPOINT: <span className="text-blue-400 font-bold">{selectedApiEndpoint}</span></span>
              <span>STATUS: <span className="text-emerald-400 font-bold">200 OK</span></span>
            </div>
            {loadingApi ? (
              <div className="text-gray-400 py-4">Executing API request...</div>
            ) : (
              <pre className="text-gray-200 text-xs overflow-x-auto max-h-60 pt-2 font-mono">
                {JSON.stringify(apiResponse || { message: "Click an endpoint above to execute API call" }, null, 2)}
              </pre>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
