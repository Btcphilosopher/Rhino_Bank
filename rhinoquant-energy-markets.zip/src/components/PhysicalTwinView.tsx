import React, { useState } from 'react';
import { useRhino } from '../context/RhinoContext';
import { PhysicalAssetNode } from '../types';
import { 
  Truck, 
  Layers, 
  AlertTriangle, 
  CheckCircle2, 
  Play, 
  Pause, 
  Database, 
  Ship, 
  MapPin,
  ArrowRight
} from 'lucide-react';

export const PhysicalTwinView: React.FC = () => {
  const { physicalNodes, toggleNodeStatus, storageArbs } = useRhino();
  const [selectedNodeId, setSelectedNodeId] = useState<string>(physicalNodes[0]?.id || 'node-permian');

  const activeNode = physicalNodes.find(n => n.id === selectedNodeId) || physicalNodes[0];

  return (
    <div className="p-4 space-y-4 overflow-y-auto max-h-[calc(100vh-100px)]">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-[#111114] border border-gray-800 p-3.5 rounded-lg">
        <div>
          <h1 className="text-lg font-bold text-white font-sans flex items-center gap-2">
            <Truck className="w-5 h-5 text-blue-500" />
            <span>Physical Commodity Model & Digital Twin Logistics Engine</span>
          </h1>
          <p className="text-xs text-gray-400 mt-0.5">
            End-to-end supply chain flow: Production → Pipelines → Storage → Ports → Shipping → Refineries → Customers.
          </p>
        </div>

        <div className="flex items-center space-x-2 text-xs font-mono">
          <span className="text-gray-400">System Flow Status:</span>
          <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded font-bold">
            96.4% FLOW EFFICIENCY
          </span>
        </div>
      </div>

      {/* Main Grid: Interactive Supply Chain Twin Network Map */}
      <div className="bg-[#111114] border border-gray-800 rounded-lg p-4 space-y-4">
        <div className="flex items-center justify-between border-b border-gray-800 pb-2">
          <span className="text-[10px] uppercase font-bold tracking-widest text-gray-400 font-mono flex items-center gap-2">
            <Layers className="w-4 h-4 text-blue-400" />
            <span>COMMODITY SUPPLY CHAIN GRAPH & BOTTLENECK SIMULATOR</span>
          </span>
          <span className="text-[10px] text-gray-400 font-mono">Click node to inspect node parameters or toggle disruption status</span>
        </div>

        {/* Visual Node Flow Layout */}
        <div className="grid grid-cols-1 md:grid-cols-4 lg:grid-cols-7 gap-3 font-mono text-xs">
          {physicalNodes.map((node, index) => {
            const isSelected = selectedNodeId === node.id;
            return (
              <div
                key={node.id}
                onClick={() => setSelectedNodeId(node.id)}
                className={`p-3 rounded-lg border cursor-pointer transition-all space-y-2 relative ${
                  isSelected 
                    ? 'bg-blue-950/40 border-blue-500 shadow-lg ring-1 ring-blue-500' 
                    : node.status === 'OUTAGE' 
                    ? 'bg-rose-950/40 border-rose-500/60' 
                    : node.status === 'CONGESTED' 
                    ? 'bg-amber-950/40 border-amber-500/60' 
                    : 'bg-[#0a0a0b] border-gray-800 hover:border-gray-700'
                }`}
              >
                <div className="flex items-center justify-between text-[10px] text-gray-400 font-bold border-b border-gray-800 pb-1">
                  <span>{node.type}</span>
                  <span className={`px-1 py-0.5 rounded text-[9px] ${
                    node.status === 'NORMAL' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400 font-bold'
                  }`}>
                    {node.status}
                  </span>
                </div>

                <div className="font-bold text-white font-sans truncate">{node.name}</div>
                <div className="text-[10px] text-gray-400 truncate">{node.location}</div>

                <div className="space-y-1 pt-1">
                  <div className="flex justify-between text-[10px] text-gray-400">
                    <span>Utilisation:</span>
                    <span className="text-gray-200 font-bold">{node.utilisationPct}%</span>
                  </div>
                  <div className="w-full bg-gray-800 h-1.5 rounded">
                    <div 
                      className={`h-1.5 rounded ${node.utilisationPct > 90 ? 'bg-rose-400' : 'bg-emerald-400'}`}
                      style={{ width: `${node.utilisationPct}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Grid Row 2: Selected Node Parameters & Disruption Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 font-mono text-xs">
        {/* Left Column (2 Spans): Selected Node Details */}
        <div className="lg:col-span-2 bg-[#111114] border border-gray-800 rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-gray-800 pb-2">
            <span className="text-xs font-bold text-gray-200 font-sans flex items-center gap-2">
              <MapPin className="w-4 h-4 text-blue-400" />
              <span>NODE TELEMETRY & DISRUPTION CONTROLS ({activeNode.name})</span>
            </span>
            <span className="text-blue-400 font-bold">{activeNode.id}</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-[#0a0a0b] p-2.5 rounded border border-gray-800">
              <div className="text-[10px] text-gray-400">MAX CAPACITY</div>
              <div className="text-base font-bold text-white mt-0.5">{activeNode.capacity.toLocaleString()} kbpd</div>
            </div>
            <div className="bg-[#0a0a0b] p-2.5 rounded border border-gray-800">
              <div className="text-[10px] text-gray-400">CURRENT INFLOW</div>
              <div className="text-base font-bold text-emerald-400 mt-0.5">{activeNode.inflow.toLocaleString()} kbpd</div>
            </div>
            <div className="bg-[#0a0a0b] p-2.5 rounded border border-gray-800">
              <div className="text-[10px] text-gray-400">CURRENT OUTFLOW</div>
              <div className="text-base font-bold text-emerald-400 mt-0.5">{activeNode.outflow.toLocaleString()} kbpd</div>
            </div>
            <div className="bg-[#0a0a0b] p-2.5 rounded border border-gray-800">
              <div className="text-[10px] text-gray-400">TARIFF / TARIFF COST</div>
              <div className="text-base font-bold text-gray-200 mt-0.5">${activeNode.costPerUnit.toFixed(2)} / unit</div>
            </div>
          </div>

          <div className="bg-[#0a0a0b] p-3 rounded border border-gray-800 space-y-2">
            <div className="text-gray-300 font-bold border-b border-gray-800 pb-1">SIMULATE DISRUPTION ON NODE</div>
            <div className="flex items-center space-x-2">
              {(['NORMAL', 'CONGESTED', 'BOTTLENECK', 'OUTAGE'] as const).map(status => (
                <button
                  key={status}
                  onClick={() => toggleNodeStatus(activeNode.id, status)}
                  className={`px-3 py-1.5 rounded font-bold border text-xs transition-colors ${
                    activeNode.status === status
                      ? 'bg-blue-600 text-white border-blue-500'
                      : 'bg-[#111114] text-gray-400 border-gray-800 hover:text-gray-200'
                  }`}
                >
                  SET {status}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column (1 Span): Storage Carry Economics */}
        <div className="bg-[#111114] border border-gray-800 rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-gray-800 pb-2">
            <span className="text-[10px] uppercase font-bold tracking-widest text-gray-400 font-mono flex items-center gap-2">
              <Database className="w-4 h-4 text-blue-400" />
              <span>STORAGE ARBITRAGE CARRY</span>
            </span>
          </div>

          <div className="space-y-3">
            {storageArbs.map(stg => (
              <div key={stg.id} className="bg-[#0a0a0b] p-3 rounded border border-gray-800 space-y-2 text-xs font-mono">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-white font-sans">{stg.commodity}</span>
                  <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                    stg.decision === 'BUY_STORE_SELL' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
                  }`}>
                    {stg.decision}
                  </span>
                </div>
                <div className="text-gray-400 text-[11px]">{stg.location}</div>
                <div className="flex justify-between text-gray-300">
                  <span>Gross 12M Spread:</span>
                  <span className="text-emerald-400 font-bold">+${stg.grossSpread.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-gray-300">
                  <span>Net Storage Value:</span>
                  <span className={`font-bold ${stg.netArbitrageValue >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    ${stg.netArbitrageValue.toFixed(2)} / unit
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
