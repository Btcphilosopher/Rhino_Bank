import React, { useState } from 'react';
import { useRhino } from '../context/RhinoContext';
import { CrudeGrade, GasHub, LngRoute } from '../types';
import { calculateCrudePrice, calculateGasBasis } from '../engine';
import { 
  BarChart3, 
  Plus, 
  Sliders, 
  Flame, 
  Ship, 
  Layers, 
  Info,
  Check,
  Globe
} from 'lucide-react';

export const SpotMarketsView: React.FC = () => {
  const { 
    crudeGrades, 
    gasHubs, 
    lngRoutes, 
    addCrudeGrade, 
    userRole 
  } = useRhino();

  const [activeSubTab, setActiveSubTab] = useState<'CRUDE_DATABASE' | 'GAS_HUBS' | 'LNG_MARKET'>('CRUDE_DATABASE');
  const [showAddGradeModal, setShowAddGradeModal] = useState(false);

  // New crude grade form state
  const [newGradeName, setNewGradeName] = useState('Guyana Liza Sweet');
  const [newGradeCode, setNewGradeCode] = useState('LIZA');
  const [newGradeRegion, setNewGradeRegion] = useState('South America (Guyana)');
  const [newBenchmarkRef, setNewBenchmarkRef] = useState<'BRENT' | 'WTI' | 'DUBAI' | 'CUSTOM'>('BRENT');
  const [newApiGravity, setNewApiGravity] = useState<number>(32.1);
  const [newSulphur, setNewSulphur] = useState<number>(0.58);
  const [newDensity, setNewDensity] = useState<number>(860);
  const [newLocation, setNewLocation] = useState('Liza Destiny FPSO');
  const [newDeliveryBasis, setNewDeliveryBasis] = useState<'FOB' | 'CIF' | 'DES' | 'DAP' | 'CFR'>('FOB');
  const [newBaseSpot, setNewBaseSpot] = useState<number>(78.45);
  const [newGradeDiff, setNewGradeDiff] = useState<number>(1.20);
  const [newLocDiff, setNewLocDiff] = useState<number>(-0.40);

  const selectedBenchmarkGrade = crudeGrades[0];
  const [calcSelectedGradeId, setCalcSelectedGradeId] = useState<string>(crudeGrades[1]?.id || crudeGrades[0].id);
  const activeCalcGrade = crudeGrades.find(g => g.id === calcSelectedGradeId) || crudeGrades[0];

  const calcDeliveredPrice = calculateCrudePrice(activeCalcGrade);

  const handleCreateGrade = (e: React.FormEvent) => {
    e.preventDefault();
    addCrudeGrade({
      name: newGradeName,
      code: newGradeCode,
      region: newGradeRegion,
      benchmarkReference: newBenchmarkRef,
      specs: {
        apiGravity: newApiGravity,
        sulphurPercent: newSulphur,
        densityKgM3: newDensity,
        viscosityCst: 5.2
      },
      location: newLocation,
      deliveryBasis: newDeliveryBasis,
      baseSpotPrice: newBaseSpot,
      gradeDifferential: newGradeDiff,
      locationDifferential: newLocDiff,
      qualityAdjustment: 0.15,
      freightCost: 1.80,
      otherCosts: 0.10,
      bid: newBaseSpot - 0.05,
      offer: newBaseSpot + 0.05,
      change1D: 0.50,
      change1DPct: 0.64,
      volume24h: 450
    });
    setShowAddGradeModal(false);
  };

  return (
    <div className="p-4 space-y-4 overflow-y-auto max-h-[calc(100vh-100px)]">
      {/* Top Header & Sub-nav */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-[#111114] border border-gray-800 p-3.5 rounded-lg">
        <div>
          <h1 className="text-lg font-bold text-white font-sans flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-blue-500" />
            <span>Spot Markets & Crude Quality Database</span>
          </h1>
          <p className="text-xs text-gray-400 mt-0.5">
            Physical benchmark differentials, crude specifications database, regional gas hubs & LNG cargo economics.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <div className="flex bg-[#0a0a0b] p-1 rounded border border-gray-800 text-xs font-mono">
            <button
              onClick={() => setActiveSubTab('CRUDE_DATABASE')}
              className={`px-3 py-1 rounded transition-colors ${activeSubTab === 'CRUDE_DATABASE' ? 'bg-blue-600 text-white font-bold' : 'text-gray-400 hover:text-gray-200'}`}
            >
              CRUDE DATABASE
            </button>
            <button
              onClick={() => setActiveSubTab('GAS_HUBS')}
              className={`px-3 py-1 rounded transition-colors ${activeSubTab === 'GAS_HUBS' ? 'bg-blue-600 text-white font-bold' : 'text-gray-400 hover:text-gray-200'}`}
            >
              GAS HUBS & BASIS
            </button>
            <button
              onClick={() => setActiveSubTab('LNG_MARKET')}
              className={`px-3 py-1 rounded transition-colors ${activeSubTab === 'LNG_MARKET' ? 'bg-blue-600 text-white font-bold' : 'text-gray-400 hover:text-gray-200'}`}
            >
              LNG CARGOES
            </button>
          </div>

          {activeSubTab === 'CRUDE_DATABASE' && (
            <button
              onClick={() => setShowAddGradeModal(true)}
              className="bg-blue-600 hover:bg-blue-500 text-white font-bold px-3 py-1.5 rounded text-xs font-mono flex items-center space-x-1 shadow transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>CUSTOM GRADE</span>
            </button>
          )}
        </div>
      </div>

      {/* Sub-tab 1: CRUDE DATABASE & DIFFERENTIAL ENGINE */}
      {activeSubTab === 'CRUDE_DATABASE' && (
        <div className="space-y-4">
          {/* Section: Crude Differential Formula Breakdown */}
          <div className="bg-[#111114] border border-gray-800 rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-gray-800 pb-2">
              <span className="text-[10px] uppercase font-bold tracking-widest text-gray-400 font-mono flex items-center gap-2">
                <Sliders className="w-4 h-4 text-blue-400" />
                <span>CRUDE DIFFERENTIAL ENGINE FORMULA MODEL</span>
              </span>
              <div className="text-xs font-mono text-gray-400">
                Grade: <select 
                  value={calcSelectedGradeId} 
                  onChange={e => setCalcSelectedGradeId(e.target.value)}
                  className="bg-[#0a0a0b] text-blue-400 font-bold border border-gray-800 px-2 py-0.5 rounded"
                >
                  {crudeGrades.map(g => (
                    <option key={g.id} value={g.id}>{g.name} ({g.code})</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Formula visualization */}
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2 text-center font-mono text-xs">
              <div className="bg-[#0a0a0b] p-2.5 rounded border border-gray-800">
                <div className="text-[10px] text-gray-400">BENCHMARK</div>
                <div className="text-sm font-bold text-gray-200 mt-1">${activeCalcGrade.baseSpotPrice.toFixed(2)}</div>
                <div className="text-[9px] text-gray-500">{activeCalcGrade.benchmarkReference}</div>
              </div>
              <div className="flex items-center justify-center text-gray-500 font-bold text-base">+</div>
              <div className="bg-[#0a0a0b] p-2.5 rounded border border-gray-800">
                <div className="text-[10px] text-gray-400">GRADE DIFF</div>
                <div className={`text-sm font-bold mt-1 ${activeCalcGrade.gradeDifferential >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {activeCalcGrade.gradeDifferential >= 0 ? '+' : ''}${activeCalcGrade.gradeDifferential.toFixed(2)}
                </div>
              </div>
              <div className="flex items-center justify-center text-gray-500 font-bold text-base">+</div>
              <div className="bg-[#0a0a0b] p-2.5 rounded border border-gray-800">
                <div className="text-[10px] text-gray-400">LOC DIFF</div>
                <div className={`text-sm font-bold mt-1 ${activeCalcGrade.locationDifferential >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {activeCalcGrade.locationDifferential >= 0 ? '+' : ''}${activeCalcGrade.locationDifferential.toFixed(2)}
                </div>
              </div>
              <div className="flex items-center justify-center text-gray-500 font-bold text-base">+</div>
              <div className="bg-[#0a0a0b] p-2.5 rounded border border-gray-800">
                <div className="text-[10px] text-gray-400">FREIGHT + OTHER</div>
                <div className="text-sm font-bold text-gray-200 mt-1">${(activeCalcGrade.freightCost + activeCalcGrade.otherCosts).toFixed(2)}</div>
              </div>
            </div>

            <div className="bg-blue-950/30 border border-blue-800/50 p-3 rounded flex items-center justify-between text-xs font-mono">
              <div>
                <span className="text-blue-400 font-bold">THEORETICAL DELIVERED CRUDE PRICE ({activeCalcGrade.code}): </span>
                <span className="text-white font-extrabold text-sm ml-2">${calcDeliveredPrice.toFixed(2)} / bbl</span>
              </div>
              <span className="text-[11px] text-gray-400">Delivery Basis: {activeCalcGrade.deliveryBasis} ({activeCalcGrade.location})</span>
            </div>
          </div>

          {/* Section: Crude Grades Database Table */}
          <div className="bg-[#111114] border border-gray-800 rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-gray-800 pb-2">
              <span className="text-[10px] uppercase font-bold tracking-widest text-gray-400 font-mono">GLOBAL CRUDE QUALITY SPECIFICATIONS DATABASE</span>
              <span className="text-[10px] text-gray-400 font-mono">Total Crude Grades: {crudeGrades.length}</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left font-mono text-xs">
                <thead>
                  <tr className="border-b border-gray-800 text-gray-400 text-[11px]">
                    <th className="py-2 px-2">CRUDE GRADE</th>
                    <th className="py-2 px-2">BENCHMARK</th>
                    <th className="py-2 px-2">REGION</th>
                    <th className="py-2 px-2 text-right">API° GRAVITY</th>
                    <th className="py-2 px-2 text-right">SULPHUR %</th>
                    <th className="py-2 px-2 text-right">DENSITY (kg/m³)</th>
                    <th className="py-2 px-2 text-right">SPOT PRICE</th>
                    <th className="py-2 px-2 text-right">BID / OFFER</th>
                    <th className="py-2 px-2 text-right">1D CHANGE</th>
                    <th className="py-2 px-2">BASIS / LOC</th>
                  </tr>
                </thead>
                <tbody>
                  {crudeGrades.map(g => (
                    <tr key={g.id} className="border-b border-gray-800/60 hover:bg-gray-800/40">
                      <td className="py-2 px-2 font-bold text-white font-sans flex items-center space-x-1.5">
                        <span>{g.name}</span>
                        {g.isCustom && <span className="bg-blue-950/40 text-blue-400 border border-blue-800/60 text-[9px] px-1 rounded font-mono">CUSTOM</span>}
                      </td>
                      <td className="py-2 px-2 text-gray-400 text-[10px]">{g.benchmarkReference}</td>
                      <td className="py-2 px-2 text-gray-300 text-[11px]">{g.region}</td>
                      <td className="py-2 px-2 text-right text-blue-400 font-bold">{g.specs.apiGravity}°</td>
                      <td className="py-2 px-2 text-right text-gray-300">{g.specs.sulphurPercent}%</td>
                      <td className="py-2 px-2 text-right text-gray-400">{g.specs.densityKgM3}</td>
                      <td className="py-2 px-2 text-right text-white font-bold">${g.baseSpotPrice.toFixed(2)}</td>
                      <td className="py-2 px-2 text-right text-gray-400 text-[11px]">${g.bid.toFixed(2)} / ${g.offer.toFixed(2)}</td>
                      <td className={`py-2 px-2 text-right font-bold ${g.change1D >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                        {g.change1D >= 0 ? '+' : ''}${g.change1D.toFixed(2)}
                      </td>
                      <td className="py-2 px-2 text-gray-400 text-[10px]">{g.deliveryBasis} ({g.location})</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Sub-tab 2: GAS HUBS & BASIS MATRIX */}
      {activeSubTab === 'GAS_HUBS' && (
        <div className="space-y-4">
          <div className="bg-[#111114] border border-gray-800 rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-gray-800 pb-2">
              <span className="text-[10px] uppercase font-bold tracking-widest text-gray-400 font-mono flex items-center gap-2">
                <Flame className="w-4 h-4 text-blue-400" />
                <span>REGIONAL NATURAL GAS HUBS & BASIS SPREAD MATRIX</span>
              </span>
              <span className="text-[10px] text-gray-400 font-mono">Reference Hub: Henry Hub (HH)</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {gasHubs.map(hub => {
                const hh = gasHubs.find(h => h.code === 'HH') || gasHubs[0];
                const basisInfo = calculateGasBasis(hub, hh);
                return (
                  <div key={hub.id} className="bg-[#0a0a0b] border border-gray-800 p-3.5 rounded space-y-2 font-mono">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white text-sm font-sans">{hub.name} ({hub.code})</span>
                      <span className="text-[10px] bg-gray-800 text-gray-400 px-1.5 py-0.5 rounded">{hub.region}</span>
                    </div>

                    <div className="text-2xl font-extrabold text-blue-400">
                      ${hub.spotPrice.toFixed(2)} <span className="text-xs text-gray-400 font-normal">/ MMBtu</span>
                    </div>

                    <div className="text-xs text-gray-400 space-y-1 border-t border-gray-800/80 pt-2">
                      <div className="flex justify-between">
                        <span>Basis vs HH:</span>
                        <span className={`font-bold ${basisInfo.basis >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                          {basisInfo.basis >= 0 ? '+' : ''}${basisInfo.basis.toFixed(2)}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>30D Volatility:</span>
                        <span className="text-gray-200">{hub.volatility30D}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span>5Y Percentile:</span>
                        <span className="text-gray-200">{hub.percentile5Y}th %ile</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Sub-tab 3: LNG CARGOES & SHIPPING ECONOMICS */}
      {activeSubTab === 'LNG_MARKET' && (
        <div className="space-y-4">
          <div className="bg-[#111114] border border-gray-800 rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-gray-800 pb-2">
              <span className="text-[10px] uppercase font-bold tracking-widest text-gray-400 font-mono flex items-center gap-2">
                <Ship className="w-4 h-4 text-sky-400" />
                <span>GLOBAL LNG CARGO ARBITRAGE & SHIPPING ROUTES</span>
              </span>
              <span className="text-[10px] text-gray-400 font-mono font-bold">Sabine Pass / Freeport Export Desks</span>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
              {lngRoutes.map(route => (
                <div key={route.id} className="bg-[#0a0a0b] border border-gray-800 p-4 rounded-lg space-y-3 font-mono text-xs">
                  <div className="font-bold font-sans border-b border-gray-800 pb-2 text-sm text-blue-400">
                    {route.name}
                  </div>

                  <div className="space-y-1.5 text-gray-300">
                    <div className="flex justify-between"><span>Voyage Distance:</span><span className="text-white font-bold">{route.distanceNmi.toLocaleString()} nmi</span></div>
                    <div className="flex justify-between"><span>Charter Rate:</span><span className="text-white">${route.charterRateDay.toLocaleString()} / day</span></div>
                    <div className="flex justify-between"><span>Roundtrip Days:</span><span className="text-white">{route.roundTripDays} days</span></div>
                    <div className="flex justify-between text-gray-400"><span>Freight $/MMBtu:</span><span className="text-gray-200">${route.totalFreightPerMmbtu.toFixed(2)}</span></div>
                    <div className="flex justify-between text-gray-400"><span>Liquefaction Fee:</span><span className="text-gray-200">${route.liquefactionCostMmbtu.toFixed(2)}</span></div>
                  </div>

                  <div className="bg-emerald-500/10 border border-emerald-500/30 p-2.5 rounded flex items-center justify-between font-mono">
                    <span className="text-gray-300">Net Arb Edge:</span>
                    <span className="text-emerald-400 font-extrabold text-base">+${route.netArbValueMmbtu.toFixed(2)} / MMBtu</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Modal: Add Custom Crude Grade */}
      {showAddGradeModal && (
        <div className="fixed inset-0 bg-[#0a0a0b]/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#111114] border border-gray-800 rounded-lg max-w-md w-full p-4 space-y-4 shadow-2xl font-sans">
            <div className="flex items-center justify-between border-b border-gray-800 pb-2">
              <h3 className="text-sm font-bold text-white font-mono">CREATE CUSTOM CRUDE GRADE</h3>
              <button onClick={() => setShowAddGradeModal(false)} className="text-gray-400 hover:text-white text-xs font-mono">✕</button>
            </div>

            <form onSubmit={handleCreateGrade} className="space-y-3 text-xs">
              <div>
                <label className="block text-gray-400 mb-1 font-mono">CRUDE NAME</label>
                <input type="text" value={newGradeName} onChange={e => setNewGradeName(e.target.value)} required className="w-full bg-[#0a0a0b] border border-gray-800 rounded px-2.5 py-1 text-gray-200" />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-gray-400 mb-1 font-mono">CODE</label>
                  <input type="text" value={newGradeCode} onChange={e => setNewGradeCode(e.target.value)} required className="w-full bg-[#0a0a0b] border border-gray-800 rounded px-2.5 py-1 text-gray-200" />
                </div>
                <div>
                  <label className="block text-gray-400 mb-1 font-mono">BENCHMARK REF</label>
                  <select value={newBenchmarkRef} onChange={e => setNewBenchmarkRef(e.target.value as any)} className="w-full bg-[#0a0a0b] border border-gray-800 rounded px-2 py-1 text-gray-200">
                    <option value="BRENT">BRENT</option>
                    <option value="WTI">WTI</option>
                    <option value="DUBAI">DUBAI</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 font-mono">
                <div>
                  <label className="block text-gray-400 mb-1">API°</label>
                  <input type="number" step="0.1" value={newApiGravity} onChange={e => setNewApiGravity(Number(e.target.value))} className="w-full bg-[#0a0a0b] border border-gray-800 rounded px-2 py-1 text-blue-400 font-bold" />
                </div>
                <div>
                  <label className="block text-gray-400 mb-1">SULPHUR %</label>
                  <input type="number" step="0.01" value={newSulphur} onChange={e => setNewSulphur(Number(e.target.value))} className="w-full bg-[#0a0a0b] border border-gray-800 rounded px-2 py-1 text-gray-200" />
                </div>
                <div>
                  <label className="block text-gray-400 mb-1">DENSITY</label>
                  <input type="number" value={newDensity} onChange={e => setNewDensity(Number(e.target.value))} className="w-full bg-[#0a0a0b] border border-gray-800 rounded px-2 py-1 text-gray-200" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 font-mono">
                <div>
                  <label className="block text-gray-400 mb-1">BASE SPOT ($)</label>
                  <input type="number" step="0.1" value={newBaseSpot} onChange={e => setNewBaseSpot(Number(e.target.value))} className="w-full bg-[#0a0a0b] border border-gray-800 rounded px-2 py-1 text-gray-200 font-bold" />
                </div>
                <div>
                  <label className="block text-gray-400 mb-1">GRADE DIFF ($)</label>
                  <input type="number" step="0.1" value={newGradeDiff} onChange={e => setNewGradeDiff(Number(e.target.value))} className="w-full bg-[#0a0a0b] border border-gray-800 rounded px-2 py-1 text-emerald-400 font-bold" />
                </div>
              </div>

              <div className="pt-2 flex justify-end space-x-2 font-mono">
                <button type="button" onClick={() => setShowAddGradeModal(false)} className="px-3 py-1.5 rounded bg-gray-800 text-gray-300">Cancel</button>
                <button type="submit" className="px-3 py-1.5 rounded bg-blue-600 text-white font-bold">Save Grade</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
