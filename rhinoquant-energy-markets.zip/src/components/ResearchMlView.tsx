import React, { useState } from 'react';
import { useRhino } from '../context/RhinoContext';
import { PriceForecast, AnomalySignal } from '../types';
import { 
  BrainCircuit, 
  Sparkles, 
  Send, 
  AlertTriangle, 
  TrendingUp, 
  Activity, 
  CheckCircle2,
  Bot
} from 'lucide-react';

export const ResearchMlView: React.FC = () => {
  const { forecasts, anomalies, crudeGrades, gasHubs, riskMetrics } = useRhino();

  const [aiPrompt, setAiPrompt] = useState<string>('What is the impact of a 20% Brent price spike on TTF natural gas basis and refinery crack margins?');
  const [aiResult, setAiResult] = useState<string | null>(null);
  const [isLoadingAi, setIsLoadingAi] = useState<boolean>(false);

  const handleRunAiAnalysis = async (promptText?: string) => {
    const textToSubmit = promptText || aiPrompt;
    setIsLoadingAi(true);
    setAiResult(null);

    try {
      const res = await fetch('/api/v1/ai-research', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: textToSubmit,
          context: {
            crudeSpot: crudeGrades.map(c => ({ code: c.code, price: c.baseSpotPrice })),
            gasHubs: gasHubs.map(h => ({ code: h.code, price: h.spotPrice })),
            var99: riskMetrics.var99_1D
          }
        })
      });

      const data = await res.json();
      setAiResult(data.result || data.error);
    } catch (err: any) {
      setAiResult(`Analysis failed: ${err.message}`);
    } finally {
      setIsLoadingAi(false);
    }
  };

  return (
    <div className="p-4 space-y-4 overflow-y-auto max-h-[calc(100vh-100px)]">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-[#111114] border border-gray-800 p-3.5 rounded-lg">
        <div>
          <h1 className="text-lg font-bold text-white font-sans flex items-center gap-2">
            <BrainCircuit className="w-5 h-5 text-blue-500" />
            <span>Machine Learning & Quantitative Research Terminal</span>
          </h1>
          <p className="text-xs text-gray-400 mt-0.5">
            ARIMA / ML forecasting, statistical z-score anomaly detection, market regime engines & Gemini AI quantitative research assistant.
          </p>
        </div>

        <div className="bg-blue-950/40 border border-blue-800/60 px-3 py-1 rounded text-xs font-mono text-blue-400 font-bold">
          GEMINI 2.5 FLASH QUANT STRATEGIST READY
        </div>
      </div>

      {/* Grid Row 1: Gemini AI Market Intelligence Analyst Assistant */}
      <div className="bg-[#111114] border border-gray-800 rounded-lg p-4 space-y-3 font-sans">
        <div className="flex items-center justify-between border-b border-gray-800 pb-2">
          <span className="text-[10px] uppercase font-bold tracking-widest text-gray-400 font-mono flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-blue-400" />
            <span>GEMINI QUANTITATIVE RESEARCH ASSISTANT</span>
          </span>
          <span className="text-[10px] text-gray-400 font-mono">Institutional Synthesis Engine</span>
        </div>

        <div className="space-y-3">
          <div className="flex gap-2">
            <input
              type="text"
              value={aiPrompt}
              onChange={e => setAiPrompt(e.target.value)}
              placeholder="Ask a quantitative energy research question..."
              className="flex-1 bg-[#0a0a0b] border border-gray-800 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500 font-sans"
            />
            <button
              onClick={() => handleRunAiAnalysis()}
              disabled={isLoadingAi}
              className="bg-blue-600 hover:bg-blue-500 disabled:bg-gray-800 text-white font-bold px-4 py-2 rounded text-xs font-mono transition-colors flex items-center space-x-1.5 shadow"
            >
              {isLoadingAi ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div> : <Send className="w-4 h-4" />}
              <span>{isLoadingAi ? 'ANALYZING...' : 'RUN AI ANALYSIS'}</span>
            </button>
          </div>

          {/* Quick Preset Prompts */}
          <div className="flex flex-wrap gap-2 text-xs font-mono">
            <span className="text-gray-400 text-[11px] self-center">Preset Queries:</span>
            {[
              'Analyze Brent-WTI spread carry economics',
              'Evaluate TTF vs JKM regional gas arbitrage',
              'Explain current Waha hub negative basis anomaly'
            ].map(promptText => (
              <button
                key={promptText}
                onClick={() => {
                  setAiPrompt(promptText);
                  handleRunAiAnalysis(promptText);
                }}
                className="bg-[#0a0a0b] hover:bg-gray-800 text-gray-300 border border-gray-800 px-2.5 py-1 rounded text-[11px]"
              >
                {promptText}
              </button>
            ))}
          </div>

          {/* AI Result Box */}
          {aiResult && (
            <div className="bg-[#0a0a0b] border border-blue-500/40 p-4 rounded-lg space-y-2 text-xs font-mono text-gray-200 whitespace-pre-wrap leading-relaxed shadow-inner">
              <div className="flex items-center space-x-2 text-blue-400 font-bold border-b border-gray-800 pb-2">
                <Bot className="w-4 h-4" />
                <span>RHINOQUANT STRATEGIST RESPONSE</span>
              </div>
              <div className="pt-1">{aiResult}</div>
            </div>
          )}
        </div>
      </div>

      {/* Grid Row 2: Price Forecasting Models & Anomaly Detection Table */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 font-mono text-xs">
        
        {/* Price Forecasting Framework */}
        <div className="bg-[#111114] border border-gray-800 rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-gray-800 pb-2">
            <span className="text-[10px] uppercase font-bold tracking-widest text-gray-400 font-mono flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              <span>ML PRICE FORECASTING FRAMEWORK (30-DAY HORIZON)</span>
            </span>
          </div>

          <div className="space-y-3">
            {forecasts.map(fc => (
              <div key={fc.instrument} className="bg-[#0a0a0b] p-3.5 rounded border border-gray-800 space-y-2">
                <div className="flex justify-between items-center font-sans font-bold text-white">
                  <span>{fc.instrument}</span>
                  <span className="text-xs font-mono text-blue-400 bg-blue-950/40 px-2 py-0.5 rounded border border-blue-800/60">
                    Model: {fc.modelName}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 text-xs pt-1">
                  <div>
                    <div className="text-gray-400 text-[10px]">CURRENT SPOT</div>
                    <div className="font-bold text-white">${fc.currentPrice.toFixed(2)}</div>
                  </div>
                  <div>
                    <div className="text-gray-400 text-[10px]">30D FORECAST</div>
                    <div className="font-bold text-emerald-400">${fc.forecastPrice.toFixed(2)}</div>
                  </div>
                  <div>
                    <div className="text-gray-400 text-[10px]">95% CONFIDENCE BAND</div>
                    <div className="font-bold text-gray-300">${fc.lowerConfidence95.toFixed(2)} - ${fc.upperConfidence95.toFixed(2)}</div>
                  </div>
                </div>

                <div className="text-[10px] text-gray-400 pt-1 border-t border-gray-800">
                  <span>Assumptions: {fc.assumptions.join(' • ')}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Anomaly Detection Engine */}
        <div className="bg-[#111114] border border-gray-800 rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-gray-800 pb-2">
            <span className="text-[10px] uppercase font-bold tracking-widest text-gray-400 font-mono flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400" />
              <span>STATISTICAL ANOMALY DETECTION SIGNALS</span>
            </span>
          </div>

          <div className="space-y-2">
            {anomalies.map(anom => (
              <div key={anom.id} className="bg-[#0a0a0b] p-3 rounded border border-gray-800 space-y-1.5">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-white font-sans">{anom.instrument} ({anom.metric})</span>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    anom.status === 'EXTREME' ? 'bg-rose-500/20 text-rose-400' : 'bg-blue-950/40 text-blue-400 border border-blue-800/60'
                  }`}>
                    {anom.status} (Z: {anom.zScore})
                  </span>
                </div>
                <div className="text-[11px] text-gray-300">{anom.signalExplanation}</div>
                <div className="text-[10px] text-gray-500 text-right">{anom.timestamp}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
