import React, { useState } from 'react';
import { useRhino } from '../context/RhinoContext';
import { PhysicalArbitrage } from '../types';
import { 
  Compass, 
  ShieldAlert, 
  ArrowRight, 
  Info, 
  CheckCircle2, 
  Sliders, 
  TrendingUp, 
  DollarSign 
} from 'lucide-react';

export const ArbitrageScreenerView: React.FC = () => {
  const { physicalArbs, executePaperTrade } = useRhino();
  const [selectedArbId, setSelectedArbId] = useState<string>(physicalArbs[0]?.id || 'arb-wti-rotterdam');

  const activeArb = physicalArbs.find(a => a.id === selectedArbId) || physicalArbs[0];

  const handleExecuteArbTrade = (arb: PhysicalArbitrage) => {
    executePaperTrade({
      instrument: `PHYSICAL-ARB-${arb.instrument.toUpperCase()}`,
      type: 'PHYSICAL_INVENTORY',
      side: 'LONG',
      quantity: arb.volumeUnits,
      unit: arb.instrument.includes('LNG') ? 'MMBtu' : 'bbl',
      price: arb.buySpotPrice,
      counterparty: 'Physical Arbitrage Desk'
    });
  };

  return (
    <div className="p-4 space-y-4 overflow-y-auto max-h-[calc(100vh-100px)]">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-[#111114] border border-gray-800 p-3.5 rounded-lg">
        <div>
          <h1 className="text-lg font-bold text-white font-sans flex items-center gap-2">
            <Compass className="w-5 h-5 text-blue-500" />
            <span>Institutional Energy Arbitrage Screener</span>
          </h1>
          <p className="text-xs text-gray-400 mt-0.5">
            Geographic physical trade edge analysis with fully transparent cost driver attribution & model confidence scores.
          </p>
        </div>

        <div className="bg-blue-950/40 border border-blue-800/60 px-3 py-1.5 rounded text-xs font-mono text-blue-400 flex items-center gap-2">
          <Info className="w-4 h-4 text-blue-400" />
          <span>MODELLED OPPORTUNITIES ONLY — NOT GUARANTEED PROFIT</span>
        </div>
      </div>

      {/* Grid: Opportunity Cards list (Left 2 Spans) & Breakdown (Right 1 Span) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 font-mono text-xs">
        
        {/* Left Column (2 Spans): Opportunity Cards Grid */}
        <div className="lg:col-span-2 space-y-3">
          <div className="flex items-center justify-between border-b border-gray-800 pb-2">
            <span className="text-[10px] uppercase font-bold tracking-widest text-gray-400 font-mono">IDENTIFIED ARBITRAGE OPPORTUNITIES</span>
            <span className="text-gray-400 text-[10px]">Active Cards: {physicalArbs.length}</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {physicalArbs.map(arb => {
              const isSelected = selectedArbId === arb.id;
              return (
                <div
                  key={arb.id}
                  onClick={() => setSelectedArbId(arb.id)}
                  className={`p-4 rounded-lg border cursor-pointer transition-all space-y-3 ${
                    isSelected
                      ? 'bg-blue-950/30 border-blue-500 shadow-lg ring-1 ring-blue-500'
                      : 'bg-[#111114] border-gray-800 hover:border-gray-700'
                  }`}
                >
                  <div className="flex items-center justify-between border-b border-gray-800 pb-2">
                    <span className="font-bold text-white font-sans text-sm">{arb.instrument}</span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      arb.riskRating === 'LOW' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-blue-950/40 text-blue-400 border border-blue-800/60'
                    }`}>
                      {arb.riskRating} RISK
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-gray-400 text-[11px]">
                    <span>{arb.originLocation}</span>
                    <ArrowRight className="w-3.5 h-3.5 text-gray-500 shrink-0 mx-1" />
                    <span>{arb.destinationLocation}</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 bg-[#0a0a0b] p-2.5 rounded border border-gray-800">
                    <div>
                      <div className="text-[10px] text-gray-400">ESTIMATED EDGE</div>
                      <div className="text-lg font-extrabold text-emerald-400">+${arb.netEdgePerUnit.toFixed(2)} <span className="text-xs font-normal text-gray-400">/ unit</span></div>
                    </div>
                    <div>
                      <div className="text-[10px] text-gray-400">TOTAL ARB VALUE</div>
                      <div className="text-lg font-extrabold text-white">${(arb.totalEdgeUSD / 1e6).toFixed(2)}M</div>
                    </div>
                  </div>

                  <div className="flex justify-between items-center text-[10px] text-gray-400 pt-1">
                    <span>Model Confidence: <span className="text-blue-400 font-bold">{arb.modelConfidence}%</span></span>
                    <span>Updated: {arb.dataTimestamp}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column (1 Span): Detailed Cost Driver Breakdown Modal Card */}
        <div className="bg-[#111114] border border-gray-800 rounded-lg p-4 space-y-4">
          <div className="flex items-center justify-between border-b border-gray-800 pb-2">
            <span className="text-[10px] uppercase font-bold tracking-widest text-gray-400 font-mono">OPPORTUNITY COST ATTRIBUTION</span>
            <span className="text-blue-400 font-bold">{activeArb.instrument}</span>
          </div>

          <div className="space-y-2">
            <div className="bg-[#0a0a0b] p-2.5 rounded border border-gray-800 flex justify-between">
              <span className="text-gray-400">Origin Purchase Spot:</span>
              <span className="text-gray-100 font-bold">${activeArb.buySpotPrice.toFixed(2)}</span>
            </div>
            <div className="bg-[#0a0a0b] p-2.5 rounded border border-gray-800 flex justify-between">
              <span className="text-gray-400">Destination Target Sale:</span>
              <span className="text-gray-100 font-bold">${activeArb.sellTargetPrice.toFixed(2)}</span>
            </div>
            <div className="bg-[#0a0a0b] p-2.5 rounded border border-gray-800 flex justify-between text-rose-400">
              <span>(-) Freight & Shipping:</span>
              <span>-${activeArb.transportCost.toFixed(2)}</span>
            </div>
            <div className="bg-[#0a0a0b] p-2.5 rounded border border-gray-800 flex justify-between text-rose-400">
              <span>(-) Storage Costs:</span>
              <span>-${activeArb.storageCost.toFixed(2)}</span>
            </div>
            <div className="bg-[#0a0a0b] p-2.5 rounded border border-gray-800 flex justify-between text-rose-400">
              <span>(-) Financing & Capital:</span>
              <span>-${activeArb.financingCost.toFixed(2)}</span>
            </div>
            <div className="bg-[#0a0a0b] p-2.5 rounded border border-gray-800 flex justify-between text-rose-400">
              <span>(-) In-transit Loss & Fees:</span>
              <span>-${(activeArb.lossCost + activeArb.fees).toFixed(2)}</span>
            </div>
          </div>

          <div className="bg-emerald-500/10 border border-emerald-500/30 p-3 rounded space-y-1">
            <div className="flex justify-between items-center text-xs">
              <span className="text-gray-300">NET ARBITRAGE EDGE:</span>
              <span className="text-emerald-400 font-extrabold text-base">+${activeArb.netEdgePerUnit.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center text-[11px] text-gray-400">
              <span>Total Projected Edge:</span>
              <span className="text-white font-bold">${(activeArb.totalEdgeUSD / 1e6).toFixed(2)}M</span>
            </div>
          </div>

          <button
            onClick={() => handleExecuteArbTrade(activeArb)}
            className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-2.5 rounded font-mono transition-colors shadow"
          >
            SIMULATE ARBITRAGE EXECUTION
          </button>
        </div>
      </div>
    </div>
  );
};
