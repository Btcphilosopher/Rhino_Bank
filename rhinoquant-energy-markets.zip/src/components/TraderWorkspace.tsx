import React, { useState } from 'react';
import { useRhino } from '../context/RhinoContext';
import { CrudeGrade, Position } from '../types';
import { 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid 
} from 'recharts';
import { 
  Activity, 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Send, 
  CheckCircle2, 
  Sliders, 
  Layers, 
  XCircle,
  Eye
} from 'lucide-react';

export const TraderWorkspace: React.FC = () => {
  const { 
    crudeGrades, 
    gasHubs, 
    products, 
    positions, 
    executePaperTrade, 
    userRole 
  } = useRhino();

  const [selectedInstrument, setSelectedInstrument] = useState<string>('BRENT');
  const [orderSide, setOrderSide] = useState<'LONG' | 'SHORT'>('LONG');
  const [orderType, setOrderType] = useState<Position['type']>('FUTURES');
  const [orderCategory, setOrderCategory] = useState<'MARKET' | 'LIMIT' | 'STOP' | 'ICEBERG'>('LIMIT');
  const [quantity, setQuantity] = useState<number>(50000);
  const [limitPrice, setLimitPrice] = useState<number>(78.45);
  const [counterparty, setCounterparty] = useState<string>('ICE Futures Europe');
  const [tradeExecutedMsg, setTradeExecutedMsg] = useState<string | null>(null);

  // Selected item details
  const currentCrude = crudeGrades.find(c => c.code === selectedInstrument);
  const currentPrice = currentCrude ? currentCrude.baseSpotPrice : 78.45;

  // Generate historical chart points for selected instrument
  const chartPoints = Array.from({ length: 30 }, (_, i) => {
    const base = currentPrice;
    const noise = (Math.sin(i * 0.4) * 1.5) + ((Math.random() - 0.48) * 0.8);
    return {
      time: `Day ${i + 1}`,
      price: Number((base + noise).toFixed(2))
    };
  });

  const handleTradeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    executePaperTrade({
      instrument: `${selectedInstrument}-SPOT`,
      type: orderType,
      side: orderSide,
      quantity,
      unit: selectedInstrument.includes('HH') || selectedInstrument.includes('TTF') ? 'MMBtu' : 'bbl',
      price: limitPrice,
      counterparty
    });

    setTradeExecutedMsg(`Paper Trade Executed: ${orderSide} ${quantity.toLocaleString()} units @ $${limitPrice}`);
    setTimeout(() => setTradeExecutedMsg(null), 4000);
  };

  return (
    <div className="p-3 space-y-3 overflow-y-auto max-h-[calc(100vh-100px)] font-sans">
      {/* Top Ticker Notification / Banner */}
      {tradeExecutedMsg && (
        <div className="bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 px-3 py-2 rounded text-xs font-mono flex items-center justify-between shadow animate-fade-in">
          <div className="flex items-center space-x-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{tradeExecutedMsg}</span>
          </div>
          <span className="text-[10px] text-gray-400">PAPER SIMULATOR RECORDED</span>
        </div>
      )}

      {/* Main Trading Layout: 3 Columns (Watchlist | Chart | Order Ticket) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3">
        
        {/* Left Column (3 Spans): Market Watch List */}
        <div className="lg:col-span-3 bg-[#111114] border border-gray-800 rounded-lg p-3 space-y-2 flex flex-col">
          <div className="flex items-center justify-between border-b border-gray-800 pb-2">
            <span className="text-[10px] uppercase font-bold tracking-widest text-gray-400 font-mono">SPOT WATCHLIST</span>
            <span className="text-[10px] bg-gray-800 px-1.5 py-0.5 rounded text-gray-400 font-mono">LIVE FEED</span>
          </div>

          <div className="space-y-1.5 overflow-y-auto max-h-[420px] pr-1 scrollbar-thin">
            <div className="text-[10px] font-mono font-semibold text-blue-400 uppercase tracking-wider pt-1">Crude Oil Benchmarks</div>
            {crudeGrades.map(c => (
              <button
                key={c.id}
                onClick={() => {
                  setSelectedInstrument(c.code);
                  setLimitPrice(c.baseSpotPrice);
                }}
                className={`w-full text-left p-2 rounded border text-xs font-mono transition-all flex items-center justify-between ${
                  selectedInstrument === c.code
                    ? 'bg-blue-950/40 border-blue-500 text-blue-300 font-bold'
                    : 'bg-[#0a0a0b] border-gray-800 hover:border-gray-700 text-gray-300'
                }`}
              >
                <div>
                  <div className="font-semibold text-white font-sans">{c.code}</div>
                  <div className="text-[10px] text-gray-400">{c.region}</div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-white">${c.baseSpotPrice.toFixed(2)}</div>
                  <div className={`text-[10px] ${c.change1D >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                    {c.change1D >= 0 ? '+' : ''}{c.change1D.toFixed(2)} ({c.change1DPct}%)
                  </div>
                </div>
              </button>
            ))}

            <div className="text-[10px] font-mono font-semibold text-blue-400 uppercase tracking-wider pt-2">Gas Hubs</div>
            {gasHubs.map(h => (
              <button
                key={h.id}
                onClick={() => {
                  setSelectedInstrument(h.code);
                  setLimitPrice(h.spotPrice);
                }}
                className={`w-full text-left p-2 rounded border text-xs font-mono transition-all flex items-center justify-between ${
                  selectedInstrument === h.code
                    ? 'bg-blue-950/40 border-blue-500 text-blue-300 font-bold'
                    : 'bg-[#0a0a0b] border-gray-800 hover:border-gray-700 text-gray-300'
                }`}
              >
                <div>
                  <div className="font-semibold text-white font-sans">{h.code}</div>
                  <div className="text-[10px] text-gray-400">{h.region}</div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-white">${h.spotPrice.toFixed(2)}</div>
                  <div className={`text-[10px] ${h.change1D >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                    {h.change1D >= 0 ? '+' : ''}{h.change1D.toFixed(2)}
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Center Column (6 Spans): Chart & Depth */}
        <div className="lg:col-span-6 space-y-3">
          {/* Main Candlestick/Line Chart Panel */}
          <div className="bg-[#111114] border border-gray-800 rounded-lg p-3 space-y-2">
            <div className="flex items-center justify-between border-b border-gray-800 pb-2">
              <div className="flex items-center space-x-2">
                <span className="text-base font-bold text-white font-sans">{selectedInstrument} SPOT</span>
                <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                  ${currentPrice.toFixed(2)} USD
                </span>
              </div>
              <div className="flex items-center space-x-1 text-xs font-mono bg-[#0a0a0b] p-0.5 rounded border border-gray-800">
                {['1D', '1W', '1M', '3M', '1Y'].map(tf => (
                  <button key={tf} className={`px-2 py-0.5 rounded ${tf === '1M' ? 'bg-blue-600 text-white font-bold' : 'text-gray-400'}`}>
                    {tf}
                  </button>
                ))}
              </div>
            </div>

            <div className="h-64 w-full pt-2">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartPoints}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                  <XAxis dataKey="time" stroke="#71717a" fontSize={10} />
                  <YAxis domain={['auto', 'auto']} stroke="#71717a" fontSize={10} tickFormatter={(v) => `$${v}`} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#0d0d0f', borderColor: '#27272a', borderRadius: '6px', fontSize: '11px', color: '#e5e7eb' }}
                  />
                  <Line type="monotone" dataKey="price" stroke="#3b82f6" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Level 2 Bid/Offer Order Book Matrix */}
          <div className="bg-[#111114] border border-gray-800 rounded-lg p-3 space-y-2">
            <div className="flex items-center justify-between border-b border-gray-800 pb-1.5">
              <span className="text-[10px] uppercase font-bold tracking-widest text-gray-400 font-mono">LEVEL 2 SPOT DEPTH ({selectedInstrument})</span>
              <span className="text-[10px] text-gray-400 font-mono">Spread: $0.06 / bbl</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs font-mono">
              {/* Bids */}
              <div className="space-y-1 bg-[#0a0a0b] p-2 rounded border border-gray-800">
                <div className="text-[10px] text-green-500 font-bold border-b border-gray-800 pb-1 flex justify-between">
                  <span>BID QTY</span>
                  <span>PRICE</span>
                </div>
                <div className="flex justify-between text-gray-300"><span>120,000</span><span className="text-green-500 font-bold">${(currentPrice - 0.03).toFixed(2)}</span></div>
                <div className="flex justify-between text-gray-400"><span>85,000</span><span>${(currentPrice - 0.05).toFixed(2)}</span></div>
                <div className="flex justify-between text-gray-500"><span>200,000</span><span>${(currentPrice - 0.08).toFixed(2)}</span></div>
              </div>
              {/* Offers */}
              <div className="space-y-1 bg-[#0a0a0b] p-2 rounded border border-gray-800">
                <div className="text-[10px] text-red-500 font-bold border-b border-gray-800 pb-1 flex justify-between">
                  <span>PRICE</span>
                  <span>OFFER QTY</span>
                </div>
                <div className="flex justify-between text-gray-300"><span className="text-red-500 font-bold">${(currentPrice + 0.03).toFixed(2)}</span><span>95,000</span></div>
                <div className="flex justify-between text-gray-400"><span>${(currentPrice + 0.06).toFixed(2)}</span><span>150,000</span></div>
                <div className="flex justify-between text-gray-500"><span>${(currentPrice + 0.09).toFixed(2)}</span><span>310,000</span></div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column (3 Spans): Order Execution Ticket */}
        <div className="lg:col-span-3 bg-[#111114] border border-gray-800 rounded-lg p-3 space-y-3">
          <div className="flex items-center justify-between border-b border-gray-800 pb-2">
            <span className="text-[10px] uppercase font-bold tracking-widest text-gray-400 font-mono">SIMULATED ORDER TICKET</span>
            <span className="text-[10px] bg-blue-950/40 text-blue-400 border border-blue-800/60 px-1.5 py-0.5 rounded font-mono">PAPER ONLY</span>
          </div>

          <form onSubmit={handleTradeSubmit} className="space-y-3 text-xs">
            {/* Long / Short Buttons */}
            <div className="grid grid-cols-2 gap-1.5 font-mono">
              <button
                type="button"
                onClick={() => setOrderSide('LONG')}
                className={`py-2 rounded font-bold border transition-colors ${
                  orderSide === 'LONG'
                    ? 'bg-emerald-500 text-slate-950 border-emerald-400 shadow'
                    : 'bg-[#0a0a0b] text-gray-400 border-gray-800 hover:text-gray-200'
                }`}
              >
                BUY / LONG
              </button>
              <button
                type="button"
                onClick={() => setOrderSide('SHORT')}
                className={`py-2 rounded font-bold border transition-colors ${
                  orderSide === 'SHORT'
                    ? 'bg-rose-500 text-slate-950 border-rose-400 shadow'
                    : 'bg-[#0a0a0b] text-gray-400 border-gray-800 hover:text-gray-200'
                }`}
              >
                SELL / SHORT
              </button>
            </div>

            {/* Instrument Selection */}
            <div>
              <label className="block text-gray-400 text-[11px] mb-1 font-mono">INSTRUMENT</label>
              <input
                type="text"
                readOnly
                value={`${selectedInstrument}-SPOT`}
                className="w-full bg-[#0a0a0b] border border-gray-800 rounded px-2.5 py-1.5 font-mono text-gray-200 font-bold"
              />
            </div>

            {/* Order Category (Market / Limit / Stop / Iceberg) */}
            <div>
              <label className="block text-gray-400 text-[11px] mb-1 font-mono">ORDER TYPE</label>
              <div className="grid grid-cols-2 gap-1 font-mono text-[10px]">
                {(['MARKET', 'LIMIT', 'STOP', 'ICEBERG'] as const).map(cat => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setOrderCategory(cat)}
                    className={`py-1 rounded border text-center ${
                      orderCategory === cat ? 'bg-blue-950/40 text-blue-400 border-blue-500 font-bold' : 'bg-[#0a0a0b] text-gray-400 border-gray-800'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Quantity */}
            <div>
              <label className="block text-gray-400 text-[11px] mb-1 font-mono">QUANTITY (BARRELS / MMBTU)</label>
              <input
                type="number"
                step="5000"
                value={quantity}
                onChange={e => setQuantity(Number(e.target.value))}
                className="w-full bg-[#0a0a0b] border border-gray-800 rounded px-2.5 py-1.5 font-mono text-white font-bold"
              />
            </div>

            {/* Price */}
            <div>
              <label className="block text-gray-400 text-[11px] mb-1 font-mono">LIMIT PRICE ($)</label>
              <input
                type="number"
                step="0.05"
                value={limitPrice}
                onChange={e => setLimitPrice(Number(e.target.value))}
                className="w-full bg-[#0a0a0b] border border-gray-800 rounded px-2.5 py-1.5 font-mono text-blue-400 font-bold"
              />
            </div>

            {/* Counterparty */}
            <div>
              <label className="block text-gray-400 text-[11px] mb-1 font-mono">COUNTERPARTY</label>
              <input
                type="text"
                value={counterparty}
                onChange={e => setCounterparty(e.target.value)}
                className="w-full bg-[#0a0a0b] border border-gray-800 rounded px-2.5 py-1.5 font-mono text-gray-300"
              />
            </div>

            {/* Order Value Estimation */}
            <div className="bg-[#0a0a0b] p-2 rounded border border-gray-800 space-y-1 font-mono text-[11px]">
              <div className="flex justify-between text-gray-400">
                <span>Est. Order Value:</span>
                <span className="text-gray-200 font-bold">${((quantity * limitPrice) / 1e6).toFixed(2)}M</span>
              </div>
              <div className="flex justify-between text-gray-400"><span>Role Auth:</span><span className="text-blue-400 font-bold">{userRole}</span></div>
            </div>

            <button
              type="submit"
              className={`w-full py-2.5 rounded font-bold font-mono transition-all shadow flex items-center justify-center space-x-2 ${
                orderSide === 'LONG'
                  ? 'bg-emerald-500 text-slate-950 hover:bg-emerald-400'
                  : 'bg-rose-500 text-slate-950 hover:bg-rose-400'
              }`}
            >
              <Send className="w-4 h-4" />
              <span>SUBMIT SIMULATED ORDER</span>
            </button>
          </form>
        </div>
      </div>

      {/* Bottom Panel: Active Paper Positions & Live P&L Table */}
      <div className="bg-[#111114] border border-gray-800 rounded-lg p-3 space-y-2">
        <div className="flex items-center justify-between border-b border-gray-800 pb-2">
          <span className="text-[10px] uppercase font-bold tracking-widest text-gray-400 font-mono">PORTFOLIO POSITIONS & UNREALIZED P&L ATTRIBUTION</span>
          <span className="text-[10px] text-gray-400 font-mono">Total Positions: {positions.length}</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead>
              <tr className="border-b border-gray-800 text-gray-400 text-[11px]">
                <th className="py-1.5 px-2">INSTRUMENT</th>
                <th className="py-1.5 px-2">TYPE</th>
                <th className="py-1.5 px-2">SIDE</th>
                <th className="py-1.5 px-2 text-right">QUANTITY</th>
                <th className="py-1.5 px-2 text-right">ENTRY PRICE</th>
                <th className="py-1.5 px-2 text-right">MARKET PRICE</th>
                <th className="py-1.5 px-2 text-right">MARKET VALUE</th>
                <th className="py-1.5 px-2 text-right">UNREALIZED P&L</th>
                <th className="py-1.5 px-2">COUNTERPARTY</th>
              </tr>
            </thead>
            <tbody>
              {positions.map(p => (
                <tr key={p.id} className="border-b border-gray-800/60 hover:bg-gray-800/40">
                  <td className="py-2 px-2 font-bold text-white font-sans">{p.instrument}</td>
                  <td className="py-2 px-2 text-gray-400 text-[10px]">{p.type}</td>
                  <td className="py-2 px-2">
                    <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${p.side === 'LONG' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'}`}>
                      {p.side}
                    </span>
                  </td>
                  <td className="py-2 px-2 text-right text-gray-200">{p.quantity.toLocaleString()} {p.unit}</td>
                  <td className="py-2 px-2 text-right text-gray-300">${p.entryPrice.toFixed(2)}</td>
                  <td className="py-2 px-2 text-right text-blue-400 font-bold">${p.currentPrice.toFixed(2)}</td>
                  <td className="py-2 px-2 text-right text-gray-200">${(p.marketValue / 1e6).toFixed(2)}M</td>
                  <td className={`py-2 px-2 text-right font-bold ${p.unrealizedPnL >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {p.unrealizedPnL >= 0 ? '+' : ''}${(p.unrealizedPnL / 1e3).toFixed(0)}k
                  </td>
                  <td className="py-2 px-2 text-gray-400 text-[11px]">{p.counterparty}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
