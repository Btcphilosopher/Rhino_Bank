import React, { useState } from 'react';
import { useRhino } from '../context/RhinoContext';
import { runMonteCarloSimulation } from '../engine';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid 
} from 'recharts';
import { 
  ShieldAlert, 
  Zap, 
  Activity, 
  AlertTriangle, 
  Play, 
  CheckCircle2, 
  Sliders, 
  Info 
} from 'lucide-react';

export const RiskEngineView: React.FC = () => {
  const { 
    riskMetrics, 
    stressScenarios, 
    applyScenario, 
    resetScenario, 
    activeScenarioId,
    positions 
  } = useRhino();

  const [numSimulations, setNumSimulations] = useState<number>(1000);
  const [horizonDays, setHorizonDays] = useState<number>(21);
  const [dailyVolPct, setDailyVolPct] = useState<number>(0.02);

  // Run Monte Carlo simulation calculation
  const totalPortfolioValue = positions.reduce((acc, p) => acc + p.marketValue, 0) || 150000000;
  const mcResult = runMonteCarloSimulation(totalPortfolioValue, dailyVolPct, 0.05, horizonDays, numSimulations);

  return (
    <div className="p-4 space-y-4 overflow-y-auto max-h-[calc(100vh-100px)]">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-[#111114] border border-gray-800 p-3.5 rounded-lg">
        <div>
          <h1 className="text-lg font-bold text-white font-sans flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-blue-500" />
            <span>Institutional Risk & Monte Carlo Simulation Engine</span>
          </h1>
          <p className="text-xs text-gray-400 mt-0.5">
            Value at Risk (VaR 95%/99%), Expected Shortfall, stress testing scenarios, & stochastic Monte Carlo P&L distribution.
          </p>
        </div>

        {activeScenarioId && (
          <button 
            onClick={resetScenario}
            className="bg-blue-950/40 text-blue-400 border border-blue-800/60 px-3 py-1 rounded text-xs font-mono font-bold hover:bg-blue-900/40"
          >
            RESET SCENARIOS TO BASELINE
          </button>
        )}
      </div>

      {/* KPI Row: Risk Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 font-mono">
        <div className="bg-[#111114] border border-gray-800 p-3.5 rounded-lg space-y-1">
          <div className="text-[10px] text-gray-400">1D 95% VALUE AT RISK (VaR)</div>
          <div className="text-2xl font-extrabold text-blue-400">${(riskMetrics.var95_1D / 1e6).toFixed(2)}M</div>
          <div className="text-[10px] text-gray-500">Historical / Parametric 95% Confidence</div>
        </div>

        <div className="bg-[#111114] border border-gray-800 p-3.5 rounded-lg space-y-1">
          <div className="text-[10px] text-gray-400">1D 99% VALUE AT RISK (VaR)</div>
          <div className="text-2xl font-extrabold text-rose-400">${(riskMetrics.var99_1D / 1e6).toFixed(2)}M</div>
          <div className="text-[10px] text-gray-500">Regulatory Basel III Benchmark</div>
        </div>

        <div className="bg-[#111114] border border-gray-800 p-3.5 rounded-lg space-y-1">
          <div className="text-[10px] text-gray-400">99% EXPECTED SHORTFALL (CVaR)</div>
          <div className="text-2xl font-extrabold text-rose-500">${(riskMetrics.expectedShortfall99 / 1e6).toFixed(2)}M</div>
          <div className="text-[10px] text-gray-500">Average Tail Loss Beyond 99% VaR</div>
        </div>

        <div className="bg-[#111114] border border-gray-800 p-3.5 rounded-lg space-y-1">
          <div className="text-[10px] text-gray-400">MAX STRESS LOSS</div>
          <div className="text-2xl font-extrabold text-white">${(riskMetrics.stressLossMax / 1e6).toFixed(2)}M</div>
          <div className="text-[10px] text-gray-500">Worst-case Macro Scenario</div>
        </div>
      </div>

      {/* Main Grid: Monte Carlo Simulation (Left 2 Spans) & Stress Scenarios (Right 1 Span) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 font-mono text-xs">
        
        {/* Left Column (2 Spans): Monte Carlo Engine */}
        <div className="lg:col-span-2 bg-[#111114] border border-gray-800 rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-gray-800 pb-2">
            <span className="text-[10px] uppercase font-bold tracking-widest text-gray-400 font-mono flex items-center gap-2">
              <Activity className="w-4 h-4 text-blue-400" />
              <span>MONTE CARLO STOCHASTIC P&L DISTRIBUTION (10,000 PATHS)</span>
            </span>
            <span className="text-emerald-400 font-bold">Win Probability: {mcResult.winProbability}%</span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={mcResult.histogram}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1f2937" vertical={false} />
                <XAxis dataKey="pnlRange" stroke="#9ca3af" fontSize={9} interval={1} />
                <YAxis stroke="#9ca3af" fontSize={10} />
                <Tooltip contentStyle={{ backgroundColor: '#111114', borderColor: '#374151', borderRadius: '6px', fontSize: '11px', color: '#f3f4f6' }} />
                <Bar dataKey="frequency" name="Path Frequency" fill="#2563eb" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-3 gap-2 bg-[#0a0a0b] p-3 rounded border border-gray-800">
            <div>
              <div className="text-[10px] text-gray-400">SIMULATED 95% VaR</div>
              <div className="text-sm font-bold text-blue-400">${(mcResult.var95 / 1e6).toFixed(2)}M</div>
            </div>
            <div>
              <div className="text-[10px] text-gray-400">SIMULATED 99% VaR</div>
              <div className="text-sm font-bold text-rose-400">${(mcResult.var99 / 1e6).toFixed(2)}M</div>
            </div>
            <div>
              <div className="text-[10px] text-gray-400">EXPECTED SHORTFALL</div>
              <div className="text-sm font-bold text-rose-500">${(mcResult.expectedShortfall99 / 1e6).toFixed(2)}M</div>
            </div>
          </div>
        </div>

        {/* Right Column (1 Span): Stress Testing Engine Controls */}
        <div className="bg-[#111114] border border-gray-800 rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-gray-800 pb-2">
            <span className="text-[10px] uppercase font-bold tracking-widest text-gray-400 font-mono flex items-center gap-2">
              <Zap className="w-4 h-4 text-blue-400" />
              <span>STRESS SCENARIO SIMULATOR</span>
            </span>
          </div>

          <div className="space-y-2">
            {stressScenarios.map(scen => (
              <div
                key={scen.id}
                onClick={() => applyScenario(scen.id)}
                className={`p-3 rounded border cursor-pointer transition-all space-y-1.5 ${
                  activeScenarioId === scen.id
                    ? 'bg-blue-950/40 border-blue-500 text-blue-300 font-bold'
                    : 'bg-[#0a0a0b] border-gray-800 hover:border-gray-700 text-gray-300'
                }`}
              >
                <div className="flex justify-between items-center font-sans">
                  <span className="font-bold text-white">{scen.name}</span>
                  <span className={`font-mono text-xs font-bold ${scen.projectedPnLChange >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {scen.projectedPnLChange >= 0 ? '+' : ''}${(scen.projectedPnLChange / 1e6).toFixed(1)}M
                  </span>
                </div>
                <div className="text-[10px] text-gray-400">{scen.description}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
