import React from 'react';
import { useRhino } from '../context/RhinoContext';
import { Bell, X, AlertTriangle, Info, ShieldAlert, Check } from 'lucide-react';

export const AlertsDrawer: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
  const { alerts, markAlertRead } = useRhino();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-950/60 backdrop-blur-xs font-sans">
      <div className="w-full max-w-sm bg-slate-900 border-l border-slate-800 h-full p-4 flex flex-col space-y-4 shadow-2xl animate-in slide-in-from-right duration-200">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-2">
            <Bell className="w-5 h-5 text-amber-500" />
            <h2 className="text-sm font-bold text-slate-100 font-mono">SYSTEM ALERTS & NOTIFICATIONS</h2>
          </div>
          <button 
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto space-y-2 pr-1 font-mono text-xs">
          {alerts.length === 0 ? (
            <div className="text-slate-500 text-center py-8">No active system alerts.</div>
          ) : (
            alerts.map(alert => (
              <div 
                key={alert.id}
                className={`p-3 rounded border space-y-1.5 transition-all ${
                  alert.read ? 'bg-slate-950/60 border-slate-800 text-slate-400' : 'bg-slate-950 border-amber-500/50 text-slate-200 shadow'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                    alert.severity === 'CRITICAL' ? 'bg-rose-500/20 text-rose-400' : alert.severity === 'WARNING' ? 'bg-amber-500/20 text-amber-400' : 'bg-sky-500/20 text-sky-400'
                  }`}>
                    {alert.severity}
                  </span>
                  <span className="text-[10px] text-slate-500">{alert.timestamp}</span>
                </div>

                <div className="text-xs font-sans leading-snug">{alert.message}</div>

                {!alert.read && (
                  <button
                    onClick={() => markAlertRead(alert.id)}
                    className="text-[10px] text-amber-400 hover:underline flex items-center space-x-1 pt-1"
                  >
                    <Check className="w-3 h-3" />
                    <span>Mark as Read</span>
                  </button>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
