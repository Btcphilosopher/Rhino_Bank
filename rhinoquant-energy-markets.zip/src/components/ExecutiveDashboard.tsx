import React from 'react';
import { useRhino } from '../context/RhinoContext';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid, 
  Legend, 
  AreaChart, 
  Area 
} from 'recharts';
import { 
  TrendingUp, 
  ShieldAlert, 
  Activity, 
  DollarSign, 
  AlertTriangle, 
  Zap, 
  CheckCircle,
  PieChart as PieChartIcon,
  Layers
} from 'lucide-react';

export const ExecutiveDashboard: React.FC = () => {
  const { 
    positions, 
    pnlHistory, 
    riskMetrics, 
    crudeGrades, 
    gasHubs, 
    physicalNodes, 
    anomalies,
    applyScenario,
    resetScenario,
    activeScenarioId,
    setActiveView
  } = useRhino();

  const totalMarketValue = positions.reduce((acc, p) => acc + p.marketValue, 0);
  const totalUnrealizedPnL = positions.reduce((acc, p) => acc + p.unrealizedPnL, 0);
  const totalRealizedPnL = positions.reduce((acc, p) => acc + p.realizedPnL, 0);
  const brentSpot = crudeGrades.find(g => g.code === 'BRENT')?.baseSpotPrice || 78.45;
  const ttfSpot = gasHubs.find(h => h.code === 'TTF')?.spotPrice || 11.45;

  const congestedNodes = physicalNodes.filter(n => n.status === 'CONGESTED' || n.status === 'BOTTLENECK' || n.status === 'OUTAGE');

  return (
    <div className="p-4 space-y-4 overflow-y-auto max-h-[calc(100vh-100px)]">
      {/* Top Banner Executive Heading */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3 bg-[#111114] border border-gray-800 p-4 rounded-lg shadow-sm">
        <div>
          <h1 className="text-xl font-bold text-white font-sans flex items-center gap-2">
            <span>Rhino Bank Executive Command Center</span>
            <span className="text-xs bg-blue-950/40 text-blue-400 border border-blue-800/60 px-2 py-0.5 rounded font-mono">
              INSTITUTIONAL DESK
            </span>
          </h1>
          <p className="text-xs text-gray-400 mt-1">
            Real-time multi-asset energy risk, physical flow monitoring, P&L attribution & capital utilization for senior management.
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <button 
            onClick={() => setActiveView('RISK_MONTECARLO')}
            className="px-3 py-1.5 rounded text-xs font-semibold bg-blue-600 text-white hover:bg-blue-500 shadow transition-colors flex items-center gap-1.5"
          >
            <ShieldAlert className="w-4 h-4" />
            <span>Launch Stress Engine</span>
          </button>
          <button 
            onClick={() => setActiveView('TRADER')}
            className="px-3 py-1.5 rounded text-xs font-semibold bg-[#1a1a1e] text-gray-200 border border-gray-800 hover:bg-gray-800 transition-colors flex items-center gap-1.5"
          >
            <Activity className="w-4 h-4" />
            <span>Open Trader Desk</span>
          </button>
        </div>
      </div>

      {/* KPI Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Card 1: Portfolio P&L */}
        <div className="bg-[#111114] border border-gray-800 p-3.5 rounded-lg space-y-1">
          <div className="flex items-center justify-between text-[10px] uppercase font-bold tracking-widest text-gray-400 font-mono">
            <span>PORTFOLIO UNREALIZED P&L</span>
            <DollarSign className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-extrabold font-mono text-emerald-400">
            +${(totalUnrealizedPnL / 1e6).toFixed(2)}M
          </div>
          <div className="text-[11px] text-gray-400 flex items-center justify-between">
            <span>Realized YTD: <span className="text-gray-200 font-mono">+${(totalRealizedPnL / 1e3).toFixed(0)}k</span></span>
            <span className="text-emerald-400 font-mono">+4.2%</span>
          </div>
        </div>

        {/* Card 2: 1D 99% VaR */}
        <div className="bg-[#111114] border border-gray-800 p-3.5 rounded-lg space-y-1">
          <div className="flex items-center justify-between text-[10px] uppercase font-bold tracking-widest text-gray-400 font-mono">
            <span>1D 99% VALUE AT RISK (VaR)</span>
            <ShieldAlert className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-extrabold font-mono text-white">
            ${(riskMetrics.var99_1D / 1e6).toFixed(2)}M
          </div>
          <div className="text-[11px] text-gray-400 flex items-center justify-between">
            <span>Limit: <span className="text-gray-300 font-mono">${(riskMetrics.varLimitUSD / 1e6).toFixed(1)}M</span></span>
            <span className={riskMetrics.var99_1D > riskMetrics.varLimitUSD * 0.9 ? 'text-rose-400 font-bold' : 'text-emerald-400'}>
              {((riskMetrics.var99_1D / riskMetrics.varLimitUSD) * 100).toFixed(0)}% Utilized
            </span>
          </div>
        </div>

        {/* Card 3: Capital Utilisation */}
        <div className="bg-[#111114] border border-gray-800 p-3.5 rounded-lg space-y-1">
          <div className="flex items-center justify-between text-[10px] uppercase font-bold tracking-widest text-gray-400 font-mono">
            <span>DESK CAPITAL UTILISATION</span>
            <PieChartIcon className="w-4 h-4 text-sky-400" />
          </div>
          <div className="text-2xl font-extrabold font-mono text-sky-400">
            {riskMetrics.capitalUtilisationPct}%
          </div>
          <div className="w-full bg-gray-800 rounded-full h-1.5 mt-2">
            <div 
              className="bg-sky-400 h-1.5 rounded-full" 
              style={{ width: `${riskMetrics.capitalUtilisationPct}%` }}
            ></div>
          </div>
        </div>

        {/* Card 4: Physical Bottlenecks & Anomalies */}
        <div className="bg-[#111114] border border-gray-800 p-3.5 rounded-lg space-y-1">
          <div className="flex items-center justify-between text-[10px] uppercase font-bold tracking-widest text-gray-400 font-mono">
            <span>BOTTLENECKS & ANOMALIES</span>
            <AlertTriangle className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-2xl font-extrabold font-mono text-rose-400 flex items-center gap-2">
            <span>{congestedNodes.length + anomalies.length}</span>
            <span className="text-xs text-gray-400 font-sans font-normal">Active Alerts</span>
          </div>
          <div className="text-[11px] text-gray-400 truncate">
            {congestedNodes.length > 0 ? `${congestedNodes[0].name} Congested` : 'Physical Flows Nominal'}
          </div>
        </div>
      </div>

      {/* Main Grid: Charts & Scenarios */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left Column (2 spans): P&L Attribution History Chart */}
        <div className="lg:col-span-2 bg-[#111114] border border-gray-800 p-4 rounded-lg space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-gray-200 font-sans flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-blue-400" />
              <span>Daily Portfolio P&L Attribution ($ USD)</span>
            </h2>
            <span className="text-xs font-mono text-gray-400">7-Day Rolling Attribution</span>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={pnlHistory}>
                <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                <XAxis dataKey="date" stroke="#a1a1aa" fontSize={11} tickLine={false} />
                <YAxis stroke="#a1a1aa" fontSize={11} tickFormatter={(val) => `$${(val / 1e3).toFixed(0)}k`} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0d0d0f', borderColor: '#27272a', borderRadius: '6px', fontSize: '12px', color: '#e5e7eb' }} 
                  formatter={(val: any) => [`$${Number(val).toLocaleString()}`, '']}
                />
                <Legend wrapperStyle={{ fontSize: '11px', color: '#d4d4d8' }} />
                <Bar dataKey="priceEffect" name="Price Effect" fill="#10b981" stackId="a" />
                <Bar dataKey="basisEffect" name="Basis Effect" fill="#3b82f6" stackId="a" />
                <Bar dataKey="fxEffect" name="FX Effect" fill="#8b5cf6" stackId="a" />
                <Bar dataKey="freightEffect" name="Freight Effect" fill="#f59e0b" stackId="a" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Right Column (1 span): Quick Stress Testing Controls */}
        <div className="bg-[#111114] border border-gray-800 p-4 rounded-lg space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-gray-200 font-sans flex items-center gap-2">
              <Zap className="w-4 h-4 text-blue-400" />
              <span>Executive Scenario Controls</span>
            </h2>
            {activeScenarioId && (
              <button 
                onClick={resetScenario}
                className="text-[11px] font-mono text-blue-400 hover:underline"
              >
                Reset
              </button>
            )}
          </div>
          <p className="text-xs text-gray-400">
            Instant macro stress testing for board-level risk reviews:
          </p>

          <div className="space-y-2">
            <button
              onClick={() => applyScenario('scen-oil-up20')}
              className={`w-full text-left p-2.5 rounded border text-xs font-mono transition-all flex items-center justify-between ${
                activeScenarioId === 'scen-oil-up20'
                  ? 'bg-blue-950/40 border-blue-500 text-blue-300 font-bold'
                  : 'bg-[#0a0a0b] border-gray-800 hover:border-gray-700 text-gray-300'
              }`}
            >
              <div>
                <div className="font-semibold text-white font-sans">Oil Supply Shock (+20%)</div>
                <div className="text-[10px] text-gray-400 mt-0.5">Middle East Strait freeze</div>
              </div>
              <span className="text-emerald-400 font-bold">+$6.8M</span>
            </button>

            <button
              onClick={() => applyScenario('scen-oil-down20')}
              className={`w-full text-left p-2.5 rounded border text-xs font-mono transition-all flex items-center justify-between ${
                activeScenarioId === 'scen-oil-down20'
                  ? 'bg-blue-950/40 border-blue-500 text-blue-300 font-bold'
                  : 'bg-[#0a0a0b] border-gray-800 hover:border-gray-700 text-gray-300'
              }`}
            >
              <div>
                <div className="font-semibold text-white font-sans">Demand Collapse (-20%)</div>
                <div className="text-[10px] text-gray-400 mt-0.5">Global macro recession</div>
              </div>
              <span className="text-rose-400 font-bold">-$7.2M</span>
            </button>

            <button
              onClick={() => applyScenario('scen-gas-up50')}
              className={`w-full text-left p-2.5 rounded border text-xs font-mono transition-all flex items-center justify-between ${
                activeScenarioId === 'scen-gas-up50'
                  ? 'bg-blue-950/40 border-blue-500 text-blue-300 font-bold'
                  : 'bg-[#0a0a0b] border-gray-800 hover:border-gray-700 text-gray-300'
              }`}
            >
              <div>
                <div className="font-semibold text-white font-sans">European Gas Crisis (+50%)</div>
                <div className="text-[10px] text-gray-400 mt-0.5">TTF freeze & pipeline stoppage</div>
              </div>
              <span className="text-rose-400 font-bold">-$4.1M</span>
            </button>
          </div>
        </div>
      </div>

      {/* Bottom Row: Physical Flows & Asset Twin Summary */}
      <div className="bg-[#111114] border border-gray-800 p-4 rounded-lg space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-gray-200 font-sans flex items-center gap-2">
            <Layers className="w-4 h-4 text-sky-400" />
            <span>Key Infrastructure & Logistics Twin Status</span>
          </h2>
          <button 
            onClick={() => setActiveView('PHYSICAL_TWIN')}
            className="text-xs font-mono text-sky-400 hover:underline"
          >
            View Full Digital Twin →
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          {physicalNodes.slice(0, 4).map(node => (
            <div key={node.id} className="bg-[#0a0a0b] border border-gray-800 p-3 rounded space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-gray-200 truncate">{node.name}</span>
                <span className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-bold ${
                  node.status === 'NORMAL' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
                }`}>
                  {node.status}
                </span>
              </div>
              <div className="text-xs text-gray-400 flex justify-between font-mono">
                <span>Utilisation:</span>
                <span className="text-gray-200">{node.utilisationPct}%</span>
              </div>
              <div className="w-full bg-gray-800 h-1 rounded">
                <div 
                  className={`h-1 rounded ${node.utilisationPct > 90 ? 'bg-rose-400' : 'bg-emerald-400'}`} 
                  style={{ width: `${node.utilisationPct}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
