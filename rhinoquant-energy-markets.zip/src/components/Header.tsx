import React, { useState } from 'react';
import { useRhino, WorkspaceView } from '../context/RhinoContext';
import { UserRole, DataMode } from '../types';
import { 
  Activity, 
  BarChart3, 
  Sliders, 
  Layers, 
  Truck, 
  Compass, 
  ShieldAlert, 
  TrendingUp, 
  BrainCircuit, 
  FileText, 
  Bell, 
  Play, 
  Pause, 
  ChevronDown,
  Building2
} from 'lucide-react';

export const Header: React.FC<{ onToggleAlerts: () => void }> = ({ onToggleAlerts }) => {
  const { 
    activeView, 
    setActiveView, 
    userRole, 
    setUserRole, 
    dataMode, 
    setDataMode, 
    isLiveTicking, 
    setIsLiveTicking,
    crudeGrades,
    gasHubs,
    alerts,
    activeScenarioId,
    resetScenario
  } = useRhino();

  const [showRoleDropdown, setShowRoleDropdown] = useState(false);

  const brent = crudeGrades.find(g => g.code === 'BRENT');
  const wti = crudeGrades.find(g => g.code === 'WTI');
  const hh = gasHubs.find(h => h.code === 'HH');
  const ttf = gasHubs.find(h => h.code === 'TTF');
  const jkm = gasHubs.find(h => h.code === 'JKM');

  const unreadAlertsCount = alerts.filter(a => !a.read).length;

  const rolesList: UserRole[] = [
    'TRADER',
    'ANALYST',
    'RISK MANAGER',
    'PORTFOLIO MANAGER',
    'OPERATIONS',
    'TREASURY',
    'COMPLIANCE',
    'EXECUTIVE',
    'ADMINISTRATOR'
  ];

  const views: { id: WorkspaceView; label: string; icon: React.ReactNode }[] = [
    { id: 'EXECUTIVE', label: 'Executive Desk', icon: <Building2 className="w-4 h-4" /> },
    { id: 'TRADER', label: 'Trading Workspace', icon: <Activity className="w-4 h-4" /> },
    { id: 'SPOT_MARKETS', label: 'Spot & Differentials', icon: <BarChart3 className="w-4 h-4" /> },
    { id: 'CURVES_CRACK', label: 'Curves & Cracks', icon: <TrendingUp className="w-4 h-4" /> },
    { id: 'PHYSICAL_TWIN', label: 'Physical Digital Twin', icon: <Truck className="w-4 h-4" /> },
    { id: 'ARBITRAGE', label: 'Arb Screener', icon: <Compass className="w-4 h-4" /> },
    { id: 'RISK_MONTECARLO', label: 'Risk & Monte Carlo', icon: <ShieldAlert className="w-4 h-4" /> },
    { id: 'SIMULATOR', label: 'Paper Trading', icon: <Sliders className="w-4 h-4" /> },
    { id: 'RESEARCH_ML', label: 'Research & ML', icon: <BrainCircuit className="w-4 h-4" /> },
    { id: 'GOVERNANCE_AUDIT', label: 'Governance & API', icon: <FileText className="w-4 h-4" /> }
  ];

  return (
    <header className="bg-[#0d0d0f] border-b border-gray-800/80 text-gray-200 flex flex-col shrink-0 select-none">
      {/* Top Brand & Status Bar */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-gray-800/80 bg-[#0a0a0b] text-xs font-mono">
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2">
            <div className="w-6 h-6 rounded bg-blue-600 text-white font-black font-sans flex items-center justify-center text-xs tracking-tighter shadow-sm shadow-blue-600/30">
              RQ
            </div>
            <span className="font-extrabold tracking-wider text-white text-sm font-sans">
              RHINO<span className="text-blue-500 font-bold">QUANT</span> <span className="text-gray-400 font-medium text-xs">ENERGY MARKETS</span>
            </span>
          </div>
          <span className="text-gray-700">|</span>
          <span className="text-gray-400 font-sans text-xs hidden sm:inline">Rhino Bank Institutional Spot & Risk Engine</span>
          {activeScenarioId && (
            <div className="flex items-center space-x-2 bg-blue-950/40 text-blue-400 border border-blue-800/60 px-2 py-0.5 rounded text-[11px]">
              <span>Scenario Active</span>
              <button 
                onClick={resetScenario}
                className="text-blue-300 underline hover:text-white font-sans ml-1"
              >
                Reset Baseline
              </button>
            </div>
          )}
        </div>

        {/* Ticker Ribbon */}
        <div className="hidden lg:flex items-center space-x-4 text-xs font-mono overflow-hidden max-w-xl">
          {brent && (
            <div className="flex items-center space-x-1">
              <span className="text-gray-400">BRENT</span>
              <span className="text-white font-bold">${brent.baseSpotPrice.toFixed(2)}</span>
              <span className={brent.change1D >= 0 ? 'text-green-500' : 'text-red-500'}>
                {brent.change1D >= 0 ? '+' : ''}{brent.change1D.toFixed(2)}
              </span>
            </div>
          )}
          {wti && (
            <div className="flex items-center space-x-1">
              <span className="text-gray-400">WTI</span>
              <span className="text-white font-bold">${wti.baseSpotPrice.toFixed(2)}</span>
              <span className={wti.change1D >= 0 ? 'text-green-500' : 'text-red-500'}>
                {wti.change1D >= 0 ? '+' : ''}{wti.change1D.toFixed(2)}
              </span>
            </div>
          )}
          {hh && (
            <div className="flex items-center space-x-1">
              <span className="text-gray-400">HH</span>
              <span className="text-white font-bold">${hh.spotPrice.toFixed(2)}</span>
              <span className={hh.change1D >= 0 ? 'text-green-500' : 'text-red-500'}>
                {hh.change1D >= 0 ? '+' : ''}{hh.change1D.toFixed(2)}
              </span>
            </div>
          )}
          {ttf && (
            <div className="flex items-center space-x-1">
              <span className="text-gray-400">TTF</span>
              <span className="text-white font-bold">${ttf.spotPrice.toFixed(2)}</span>
              <span className={ttf.change1D >= 0 ? 'text-green-500' : 'text-red-500'}>
                {ttf.change1D >= 0 ? '+' : ''}{ttf.change1D.toFixed(2)}
              </span>
            </div>
          )}
          {jkm && (
            <div className="flex items-center space-x-1">
              <span className="text-gray-400">JKM</span>
              <span className="text-white font-bold">${jkm.spotPrice.toFixed(2)}</span>
              <span className={jkm.change1D >= 0 ? 'text-green-500' : 'text-red-500'}>
                {jkm.change1D >= 0 ? '+' : ''}{jkm.change1D.toFixed(2)}
              </span>
            </div>
          )}
        </div>

        {/* User Role & Controls */}
        <div className="flex items-center space-x-3">
          {/* Live Ticker Toggle */}
          <button 
            onClick={() => setIsLiveTicking(!isLiveTicking)}
            className={`flex items-center space-x-1 px-2 py-0.5 rounded border text-[11px] font-mono transition-colors ${
              isLiveTicking 
                ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/20' 
                : 'bg-gray-800 text-gray-400 border-gray-700 hover:text-gray-200'
            }`}
            title="Toggle simulated real-time market data feed"
          >
            {isLiveTicking ? <Pause className="w-3 h-3 text-emerald-400" /> : <Play className="w-3 h-3" />}
            <span>{isLiveTicking ? 'FEED: LIVE' : 'FEED: PAUSED'}</span>
          </button>

          {/* Data Mode Switcher */}
          <div className="flex items-center rounded border border-gray-800 bg-[#111114] p-0.5 text-[11px] font-mono">
            {(['LIVE', 'SIMULATED'] as DataMode[]).map((mode) => (
              <button
                key={mode}
                onClick={() => setDataMode(mode)}
                className={`px-2 py-0.5 rounded transition-colors ${dataMode === mode ? 'bg-blue-600 text-white font-bold' : 'text-gray-400 hover:text-gray-200'}`}
              >
                {mode}
              </button>
            ))}
          </div>

          {/* User Role Selector Dropdown */}
          <div className="relative">
            <button
              onClick={() => setShowRoleDropdown(!showRoleDropdown)}
              className="flex items-center space-x-1.5 bg-[#111114] hover:bg-gray-800 text-gray-200 border border-gray-800 px-2.5 py-1 rounded text-xs font-mono transition-colors"
            >
              <span className="text-gray-400 text-[10px]">ROLE:</span>
              <span className="font-semibold text-blue-400">{userRole}</span>
              <ChevronDown className="w-3 h-3 text-gray-400" />
            </button>
            {showRoleDropdown && (
              <div className="absolute right-0 mt-1 w-48 bg-[#111114] border border-gray-800 rounded shadow-2xl z-50 py-1 text-xs">
                {rolesList.map(r => (
                  <button
                    key={r}
                    onClick={() => {
                      setUserRole(r);
                      setShowRoleDropdown(false);
                    }}
                    className={`w-full text-left px-3 py-1.5 hover:bg-gray-800/80 flex items-center justify-between ${userRole === r ? 'text-blue-400 font-bold bg-blue-950/30' : 'text-gray-300'}`}
                  >
                    <span>{r}</span>
                    {userRole === r && <span className="w-1.5 h-1.5 rounded-full bg-blue-400"></span>}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Alerts Drawer Button */}
          <button
            onClick={onToggleAlerts}
            className="relative p-1.5 rounded bg-[#111114] hover:bg-gray-800 text-gray-300 border border-gray-800 transition-colors"
            title="System Alerts & Risk Breaches"
          >
            <Bell className="w-4 h-4" />
            {unreadAlertsCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white font-mono text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center animate-pulse">
                {unreadAlertsCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Navigation View Tabs */}
      <nav className="flex items-center overflow-x-auto px-2 py-1 space-x-1 bg-[#0d0d0f]">
        {views.map(view => {
          const isActive = activeView === view.id;
          return (
            <button
              key={view.id}
              onClick={() => setActiveView(view.id)}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded text-xs font-medium whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-blue-600 text-white font-semibold shadow-sm shadow-blue-900/40'
                  : 'text-gray-400 hover:text-gray-100 hover:bg-gray-800/50'
              }`}
            >
              {view.icon}
              <span>{view.label}</span>
            </button>
          );
        })}
      </nav>
    </header>
  );
};
