import React, { useState } from 'react';
import { useRhino } from '../context/RhinoContext';
import { runBacktest, BacktestResult } from '../engine';
import { 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid, 
  Legend 
} from 'recharts';
import { 
  Sliders, 
  TrendingUp, 
  RotateCcw, 
  Activity, 
  CheckCircle2, 
  DollarSign, 
  BarChart3 
} from 'lucide-react';

export const TradingSimulatorView: React.FC = () => {
  const { positions, pnlHistory, userRole } = useRhino();

  const [selectedStrategy, setSelectedStrategy] = useState<'TREND_FOLLOWING' | 'STORAGE_CARRY' | 'CRACK_ARBITRAGE' | 'MEAN_REVERSION'>('STORAGE_CARRY');
  const [backtestDays, setBacktestDays] = useState<number>(180);

  // Run backtest evaluation
  const backtestResult: BacktestResult = runBacktest(selectedStrategy, backtestDays);

  return (
    <div className="p-4 space-y-4 overflow-y-auto max-h-[calc(100vh-100px)]">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-[#111114] border border-gray-800 p-3.5 rounded-lg">
        <div>
          <h1 className="text-lg font-bold text-white font-sans flex items-center gap-2">
            <Sliders className="w-5 h-5 text-blue-500" />
            <span>Paper Trading & Research Backtesting Simulator</span>
          </h1>
          <p className="text-xs text-gray-400 mt-0.5">
            Simulated paper execution (Buy, Sell, Hedge, Store, Transport) & strategy backtesting without look-ahead bias.
          </p>
        </div>

        <div className="flex bg-[#0a0a0b] p-1 rounded border border-gray-800 text-xs font-mono">
          {(['STORAGE_CARRY', 'CRACK_ARBITRAGE', 'TREND_FOLLOWING', 'MEAN_REVERSION'] as const).map(s => (
            <button
              key={s}
              onClick={() => setSelectedStrategy(s)}
              className={`px-3 py-1 rounded transition-colors ${selectedStrategy === s ? 'bg-blue-600 text-white font-bold' : 'text-gray-400 hover:text-gray-200'}`}
            >
              {s.replace('_', ' ')}
            </button>
          ))}
        </div>
      </div>

      {/* Grid Row 1: Backtest Performance Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 font-mono text-xs">
        <div className="bg-[#111114] border border-gray-800 p-3 rounded-lg space-y-1">
          <div className="text-[10px] text-gray-400">TOTAL RETURN</div>
          <div className="text-xl font-extrabold text-emerald-400">+{backtestResult.totalReturnPct}%</div>
          <div className="text-[10px] text-gray-500">{backtestDays} Days Backtest</div>
        </div>

        <div className="bg-[#111114] border border-gray-800 p-3 rounded-lg space-y-1">
          <div className="text-[10px] text-gray-400">SHARPE RATIO</div>
          <div className="text-xl font-extrabold text-blue-400">{backtestResult.sharpeRatio}</div>
          <div className="text-[10px] text-gray-500">Risk-Adjusted Return</div>
        </div>

        <div className="bg-[#111114] border border-gray-800 p-3 rounded-lg space-y-1">
          <div className="text-[10px] text-gray-400">SORTINO RATIO</div>
          <div className="text-xl font-extrabold text-blue-400">{backtestResult.sortinoRatio}</div>
          <div className="text-[10px] text-gray-500">Downside Vol Ratio</div>
        </div>

        <div className="bg-[#111114] border border-gray-800 p-3 rounded-lg space-y-1">
          <div className="text-[10px] text-gray-400">MAX DRAWDOWN</div>
          <div className="text-xl font-extrabold text-rose-400">-{backtestResult.maxDrawdownPct}%</div>
          <div className="text-[10px] text-gray-500">Peak-to-Trough Decline</div>
        </div>

        <div className="bg-[#111114] border border-gray-800 p-3 rounded-lg space-y-1">
          <div className="text-[10px] text-gray-400">WIN RATE / TRADES</div>
          <div className="text-xl font-extrabold text-white">{backtestResult.winRatePct}%</div>
          <div className="text-[10px] text-gray-500">{backtestResult.tradesCount} Simulated Trades</div>
        </div>
      </div>

      {/* Grid Row 2: Equity Curve Chart */}
      <div className="bg-[#111114] border border-gray-800 rounded-lg p-4 space-y-3">
        <div className="flex items-center justify-between border-b border-gray-800 pb-2">
          <span className="text-[10px] uppercase font-bold tracking-widest text-gray-400 font-mono">BACKTEST EQUITY CURVE VS BENCHMARK ($10M CAPITAL)</span>
          <span className="text-blue-400 font-bold font-mono">Strategy: {backtestResult.strategyName}</span>
        </div>

        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={backtestResult.equityCurve}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1f2937" vertical={false} />
              <XAxis dataKey="date" stroke="#9ca3af" fontSize={10} interval={15} />
              <YAxis stroke="#9ca3af" fontSize={10} tickFormatter={(v) => `$${(v / 1e6).toFixed(1)}M`} />
              <Tooltip contentStyle={{ backgroundColor: '#111114', borderColor: '#374151', borderRadius: '6px', fontSize: '11px', color: '#f3f4f6' }} />
              <Legend wrapperStyle={{ fontSize: '11px', color: '#9ca3af' }} />
              <Line type="monotone" dataKey="portfolioValue" name="Strategy Portfolio" stroke="#10b981" strokeWidth={2.5} dot={false} />
              <Line type="monotone" dataKey="benchmarkValue" name="Brent Benchmark" stroke="#6b7280" strokeWidth={1.5} strokeDasharray="4 4" dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
