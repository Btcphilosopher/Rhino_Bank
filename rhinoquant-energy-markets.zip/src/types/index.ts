// RHINOQUANT ENERGY MARKETS - Institutional Types

export type UserRole = 
  | 'TRADER'
  | 'ANALYST'
  | 'RISK MANAGER'
  | 'PORTFOLIO MANAGER'
  | 'OPERATIONS'
  | 'TREASURY'
  | 'COMPLIANCE'
  | 'EXECUTIVE'
  | 'ADMINISTRATOR';

export type DataMode = 'LIVE' | 'DELAYED' | 'HISTORICAL' | 'SIMULATED';

export interface QualitySpecs {
  apiGravity: number; // e.g., 37.9 for Brent
  sulphurPercent: number; // e.g., 0.45%
  densityKgM3: number; // e.g., 835
  viscosityCst: number; // e.g., 4.2
  tanNumber?: number; // Total Acid Number
}

export interface CrudeGrade {
  id: string;
  name: string;
  code: string;
  region: string;
  benchmarkReference: 'BRENT' | 'WTI' | 'DUBAI' | 'CUSTOM';
  specs: QualitySpecs;
  location: string;
  deliveryBasis: 'FOB' | 'CIF' | 'DES' | 'DAP' | 'CFR';
  baseSpotPrice: number;
  gradeDifferential: number;
  locationDifferential: number;
  qualityAdjustment: number;
  freightCost: number;
  otherCosts: number;
  bid: number;
  offer: number;
  change1D: number;
  change1DPct: number;
  volume24h: number; // kbpd (thousand barrels per day)
  lastUpdated: string;
  isCustom?: boolean;
}

export interface GasHub {
  id: string;
  name: string;
  code: string;
  region: 'US' | 'EUROPE' | 'UK' | 'ASIA' | 'LATAM';
  spotPrice: number; // $/MMBtu
  currency: string;
  unit: string; // e.g. $/MMBtu, €/MWh, p/th
  bid: number;
  offer: number;
  change1D: number;
  change1DPct: number;
  volatility30D: number;
  volume24h: number;
  deliveryPeriod: string;
  location: string;
  basisVsHenryHub: number;
  percentile5Y: number;
}

export interface LngRoute {
  id: string;
  name: string;
  originPort: string;
  destinationPort: string;
  distanceNmi: number;
  charterRateDay: number; // $/day
  boilOffRatePctDay: number; // %/day
  canalTolls: number; // $
  fuelCostTonne: number; // $
  roundTripDays: number;
  totalFreightPerMmbtu: number;
  liquefactionCostMmbtu: number;
  regasificationCostMmbtu: number;
  netArbValueMmbtu: number;
}

export interface ForwardTenor {
  monthCode: string; // e.g. M1 (Oct 26), M2 (Nov 26) ... M12
  label: string;
  brentPrice: number;
  wtiPrice: number;
  ttfPrice: number;
  henryHubPrice: number;
  change1D: number;
}

export interface ForwardCurveAnalysis {
  commodity: string;
  regime: 'CONTANGO' | 'BACKWARDATION' | 'FLAT' | 'INVERTED';
  m1_m2_spread: number;
  m1_m6_spread: number;
  m1_m12_spread: number;
  slope: number;
  curvature: number;
  historicalPercentile: number;
}

export interface PetroleumProduct {
  id: string;
  name: string;
  code: string;
  category: 'Gasoline' | 'Diesel' | 'Jet Fuel' | 'Fuel Oil' | 'Naphtha' | 'LPG';
  spotPrice: number; // $/bbl
  benchmarkRef: string; // e.g. RBOB, ULSD, Jet NWE
  differential: number;
  change1D: number;
  inventoryMbbl: number;
  daysOfSupply: number;
}

export interface RefineryModel {
  id: string;
  name: string;
  location: string;
  capacityBpd: number;
  currentThroughputBpd: number;
  crudeInputGradeId: string;
  operatingCostPerBbl: number;
  energyCostPerBbl: number;
  yieldsPct: {
    gasoline: number;
    diesel: number;
    jetFuel: number;
    fuelOil: number;
    naphthaLpg: number;
  };
  crack321Margin: number; // $/bbl
  crack532Margin: number; // $/bbl
  netMarginPerBbl: number; // $/bbl
  dailyProfit: number; // $
}

export interface PhysicalAssetNode {
  id: string;
  name: string;
  type: 'PRODUCER' | 'PIPELINE' | 'STORAGE' | 'PORT' | 'SHIPPING' | 'REFINERY' | 'DEMAND_CENTER';
  location: string;
  lat: number;
  lng: number;
  capacity: number; // kbpd or bcf
  currentLevel: number; // kbpd or bcf
  utilisationPct: number;
  inflow: number;
  outflow: number;
  costPerUnit: number;
  status: 'NORMAL' | 'CONGESTED' | 'BOTTLENECK' | 'OUTAGE';
  connectedTo: string[]; // target node IDs
}

export interface PhysicalArbitrage {
  id: string;
  instrument: string;
  originLocation: string;
  destinationLocation: string;
  buySpotPrice: number;
  sellTargetPrice: number;
  transportCost: number;
  storageCost: number;
  financingCost: number;
  lossCost: number;
  fees: number;
  netEdgePerUnit: number; // $/bbl or $/MMBtu
  totalEdgeUSD: number;
  volumeUnits: number;
  riskRating: 'LOW' | 'MEDIUM' | 'HIGH';
  modelConfidence: number; // 0 - 100%
  dataTimestamp: string;
}

export interface StorageArbitrage {
  id: string;
  location: string;
  commodity: string;
  spotPrice: number;
  forward12MPrice: number;
  grossSpread: number;
  storageCostMonthly: number;
  financingRatePct: number;
  insuranceAndLossesPct: number;
  netArbitrageValue: number;
  decision: 'BUY_STORE_SELL' | 'SELL_SPOT_ALTERNATIVE' | 'NEUTRAL';
}

export interface Position {
  id: string;
  instrument: string; // e.g. "BRENT-FUT-DEC26", "HENRYHUB-PHYSICAL"
  type: 'PHYSICAL_INVENTORY' | 'FUTURES' | 'SWAP' | 'OPTION';
  side: 'LONG' | 'SHORT';
  quantity: number; // Barrels or MMBtu
  unit: 'bbl' | 'MMBtu';
  entryPrice: number;
  currentPrice: number;
  marketValue: number;
  unrealizedPnL: number;
  realizedPnL: number;
  counterparty: string;
  delta: number;
  basisExposure: number;
  fxExposureUSD: number;
}

export interface DailyPnLAttribution {
  date: string;
  totalPnL: number;
  priceEffect: number;
  volumeEffect: number;
  basisEffect: number;
  fxEffect: number;
  freightEffect: number;
  storageEffect: number;
  financingEffect: number;
  hedgeEffect: number;
  operatingCostEffect: number;
}

export interface RiskMetrics {
  var95_1D: number; // $
  var99_1D: number; // $
  expectedShortfall99: number; // $
  stressLossMax: number; // $
  portfolioDelta: number; // bbl equivalent
  basisExposure: number; // $
  fxExposureEUR: number; // €
  fxExposureGBP: number; // £
  capitalUtilisationPct: number;
  varLimitUSD: number;
  limitBreachesCount: number;
}

export interface StressScenario {
  id: string;
  name: string;
  description: string;
  oilPriceChangePct: number;
  gasPriceChangePct: number;
  freightChangePct: number;
  usdChangePct: number;
  pipelineOutage: boolean;
  projectedPnLChange: number;
  projectedVarChange: number;
}

export interface AnomalySignal {
  id: string;
  instrument: string;
  metric: string;
  value: number;
  zScore: number;
  status: 'NORMAL' | 'WATCH' | 'ANOMALY' | 'EXTREME';
  signalExplanation: string;
  timestamp: string;
}

export interface PriceForecast {
  instrument: string;
  horizonDays: number;
  modelName: string; // 'ARIMA', 'GradientBoosting', 'LSTM', 'EWMA'
  currentPrice: number;
  forecastPrice: number;
  lowerConfidence95: number;
  upperConfidence95: number;
  confidenceScore: number;
  assumptions: string[];
}

export interface ModelGovernance {
  modelId: string;
  name: string;
  version: string;
  author: string;
  validationStatus: 'VALIDATED' | 'UNDER_REVIEW' | 'EXPERIMENTAL';
  lastValidatedDate: string;
  inputs: string[];
  outputs: string[];
  assumptions: string;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  user: string;
  role: UserRole;
  action: string;
  details: string;
  module: string;
}

export interface SystemAlert {
  id: string;
  timestamp: string;
  severity: 'INFO' | 'WARNING' | 'CRITICAL';
  category: 'PRICE' | 'SPREAD' | 'LIMIT' | 'STORAGE' | 'COUNTERPARTY' | 'DATA';
  message: string;
  read: boolean;
}
