import { 
  CrudeGrade, 
  GasHub, 
  LngRoute, 
  ForwardTenor, 
  PetroleumProduct, 
  RefineryModel, 
  PhysicalAssetNode, 
  PhysicalArbitrage, 
  StorageArbitrage, 
  Position, 
  DailyPnLAttribution, 
  RiskMetrics, 
  StressScenario, 
  AnomalySignal, 
  PriceForecast, 
  ModelGovernance, 
  AuditLogEntry, 
  SystemAlert 
} from '../types';

export const INITIAL_CRUDE_GRADES: CrudeGrade[] = [
  {
    id: 'crude-brent',
    name: 'Brent Crude',
    code: 'BRENT',
    region: 'North Sea (UK/Norway)',
    benchmarkReference: 'BRENT',
    specs: { apiGravity: 38.3, sulphurPercent: 0.37, densityKgM3: 835, viscosityCst: 4.1 },
    location: 'Sullom Voe / Houdini',
    deliveryBasis: 'FOB',
    baseSpotPrice: 78.45,
    gradeDifferential: 0.0,
    locationDifferential: 0.0,
    qualityAdjustment: 0.0,
    freightCost: 0.0,
    otherCosts: 0.0,
    bid: 78.42,
    offer: 78.48,
    change1D: 1.25,
    change1DPct: 1.62,
    volume24h: 1250,
    lastUpdated: '12:45:02 UTC'
  },
  {
    id: 'crude-wti',
    name: 'WTI Midland',
    code: 'WTI',
    region: 'US Permian Basin',
    benchmarkReference: 'WTI',
    specs: { apiGravity: 40.8, sulphurPercent: 0.22, densityKgM3: 821, viscosityCst: 3.5 },
    location: 'Cushing, Oklahoma',
    deliveryBasis: 'FOB',
    baseSpotPrice: 74.30,
    gradeDifferential: 0.0,
    locationDifferential: -0.45,
    qualityAdjustment: 0.20,
    freightCost: 1.85,
    otherCosts: 0.10,
    bid: 74.25,
    offer: 74.35,
    change1D: 0.95,
    change1DPct: 1.30,
    volume24h: 1890,
    lastUpdated: '12:45:00 UTC'
  },
  {
    id: 'crude-dubai',
    name: 'Dubai / Oman',
    code: 'DUBAI',
    region: 'Middle East (UAE/Oman)',
    benchmarkReference: 'DUBAI',
    specs: { apiGravity: 31.0, sulphurPercent: 2.04, densityKgM3: 869, viscosityCst: 9.2 },
    location: 'Mina al Fahal / Mina al Ahmadi',
    deliveryBasis: 'FOB',
    baseSpotPrice: 77.10,
    gradeDifferential: -1.35,
    locationDifferential: 0.40,
    qualityAdjustment: -0.80,
    freightCost: 2.10,
    otherCosts: 0.15,
    bid: 77.05,
    offer: 77.15,
    change1D: 0.80,
    change1DPct: 1.05,
    volume24h: 1420,
    lastUpdated: '12:44:55 UTC'
  },
  {
    id: 'crude-urals',
    name: 'Urals Crude',
    code: 'URALS',
    region: 'Russia (Baltic / Black Sea)',
    benchmarkReference: 'BRENT',
    specs: { apiGravity: 31.8, sulphurPercent: 1.35, densityKgM3: 865, viscosityCst: 8.4 },
    location: 'Primorsk / Novorossiysk',
    deliveryBasis: 'FOB',
    baseSpotPrice: 66.80,
    gradeDifferential: -11.65,
    locationDifferential: -1.20,
    qualityAdjustment: -0.90,
    freightCost: 3.40,
    otherCosts: 0.25,
    bid: 66.70,
    offer: 66.90,
    change1D: -0.40,
    change1DPct: -0.60,
    volume24h: 850,
    lastUpdated: '12:43:10 UTC'
  },
  {
    id: 'crude-tapis',
    name: 'Tapis Crude',
    code: 'TAPIS',
    region: 'Malaysia Asia-Pacific',
    benchmarkReference: 'BRENT',
    specs: { apiGravity: 45.5, sulphurPercent: 0.04, densityKgM3: 799, viscosityCst: 2.8 },
    location: 'Terengganu Terminal',
    deliveryBasis: 'FOB',
    baseSpotPrice: 83.20,
    gradeDifferential: 4.75,
    locationDifferential: 1.10,
    qualityAdjustment: 1.40,
    freightCost: 1.50,
    otherCosts: 0.12,
    bid: 83.10,
    offer: 83.30,
    change1D: 1.45,
    change1DPct: 1.77,
    volume24h: 310,
    lastUpdated: '12:41:00 UTC'
  },
  {
    id: 'crude-wcs',
    name: 'Western Canadian Select',
    code: 'WCS',
    region: 'Canada Hardisty',
    benchmarkReference: 'WTI',
    specs: { apiGravity: 20.5, sulphurPercent: 3.50, densityKgM3: 928, viscosityCst: 240 },
    location: 'Hardisty, Alberta',
    deliveryBasis: 'DAP',
    baseSpotPrice: 58.60,
    gradeDifferential: -15.70,
    locationDifferential: -2.50,
    qualityAdjustment: -2.10,
    freightCost: 4.50,
    otherCosts: 0.35,
    bid: 58.50,
    offer: 58.70,
    change1D: 0.60,
    change1DPct: 1.03,
    volume24h: 640,
    lastUpdated: '12:44:12 UTC'
  }
];

export const INITIAL_GAS_HUBS: GasHub[] = [
  {
    id: 'hub-hh',
    name: 'Henry Hub',
    code: 'HH',
    region: 'US',
    spotPrice: 2.85,
    currency: 'USD',
    unit: '$/MMBtu',
    bid: 2.84,
    offer: 2.86,
    change1D: 0.12,
    change1DPct: 4.40,
    volatility30D: 34.2,
    volume24h: 8400,
    deliveryPeriod: 'Day-Ahead',
    location: 'Erath, Louisiana',
    basisVsHenryHub: 0.00,
    percentile5Y: 42
  },
  {
    id: 'hub-ttf',
    name: 'Title Transfer Facility (TTF)',
    code: 'TTF',
    region: 'EUROPE',
    spotPrice: 11.45, // approx €36/MWh -> ~$11.45/MMBtu
    currency: 'USD',
    unit: '$/MMBtu',
    bid: 11.40,
    offer: 11.50,
    change1D: -0.35,
    change1DPct: -2.96,
    volatility30D: 48.6,
    volume24h: 14200,
    deliveryPeriod: 'Month-Ahead',
    location: 'Netherlands Gas Transport Hub',
    basisVsHenryHub: 8.60,
    percentile5Y: 68
  },
  {
    id: 'hub-nbp',
    name: 'National Balancing Point (NBP)',
    code: 'NBP',
    region: 'UK',
    spotPrice: 11.10,
    currency: 'USD',
    unit: '$/MMBtu',
    bid: 11.05,
    offer: 11.15,
    change1D: -0.30,
    change1DPct: -2.63,
    volatility30D: 46.1,
    volume24h: 6100,
    deliveryPeriod: 'Day-Ahead',
    location: 'Bacton Terminal, UK',
    basisVsHenryHub: 8.25,
    percentile5Y: 65
  },
  {
    id: 'hub-jkm',
    name: 'Japan Korea Marker (JKM)',
    code: 'JKM',
    region: 'ASIA',
    spotPrice: 13.80,
    currency: 'USD',
    unit: '$/MMBtu',
    bid: 13.72,
    offer: 13.88,
    change1D: 0.45,
    change1DPct: 3.37,
    volatility30D: 52.0,
    volume24h: 9800,
    deliveryPeriod: 'Second-Month',
    location: 'Tokyo Bay / Incheon DES',
    basisVsHenryHub: 10.95,
    percentile5Y: 74
  },
  {
    id: 'hub-waha',
    name: 'Waha Hub Texas',
    code: 'WAHA',
    region: 'US',
    spotPrice: 1.45,
    currency: 'USD',
    unit: '$/MMBtu',
    bid: 1.42,
    offer: 1.48,
    change1D: 0.18,
    change1DPct: 14.17,
    volatility30D: 82.5,
    volume24h: 3200,
    deliveryPeriod: 'Day-Ahead',
    location: 'Pecos County, West Texas',
    basisVsHenryHub: -1.40,
    percentile5Y: 18
  }
];

export const INITIAL_LNG_ROUTES: LngRoute[] = [
  {
    id: 'lng-us-nwe',
    name: 'Sabine Pass (US) → Gate Terminal Rotterdam (NWE)',
    originPort: 'Sabine Pass, US Gulf Coast',
    destinationPort: 'Gate Terminal, Rotterdam',
    distanceNmi: 4950,
    charterRateDay: 65000,
    boilOffRatePctDay: 0.12,
    canalTolls: 0,
    fuelCostTonne: 620,
    roundTripDays: 24,
    totalFreightPerMmbtu: 1.85,
    liquefactionCostMmbtu: 2.50,
    regasificationCostMmbtu: 0.45,
    netArbValueMmbtu: 3.80
  },
  {
    id: 'lng-us-asia',
    name: 'Freeport (US) → Tokyo Bay (Japan) via Panama',
    originPort: 'Freeport, US Gulf Coast',
    destinationPort: 'Tokyo Bay LNG Port',
    distanceNmi: 9700,
    charterRateDay: 70000,
    boilOffRatePctDay: 0.12,
    canalTolls: 450000,
    fuelCostTonne: 640,
    roundTripDays: 44,
    totalFreightPerMmbtu: 3.40,
    liquefactionCostMmbtu: 2.50,
    regasificationCostMmbtu: 0.55,
    netArbValueMmbtu: 4.50
  },
  {
    id: 'lng-qatar-europe',
    name: 'Ras Laffan (Qatar) → Isle of Grain (UK)',
    originPort: 'Ras Laffan, Qatar',
    destinationPort: 'Isle of Grain, UK',
    distanceNmi: 6400,
    charterRateDay: 68000,
    boilOffRatePctDay: 0.11,
    canalTolls: 380000,
    fuelCostTonne: 610,
    roundTripDays: 30,
    totalFreightPerMmbtu: 2.15,
    liquefactionCostMmbtu: 1.80,
    regasificationCostMmbtu: 0.40,
    netArbValueMmbtu: 5.95
  }
];

export const INITIAL_FORWARD_TENORS: ForwardTenor[] = [
  { monthCode: 'Spot', label: 'Prompt', brentPrice: 78.45, wtiPrice: 74.30, ttfPrice: 11.45, henryHubPrice: 2.85, change1D: 1.25 },
  { monthCode: 'M1', label: 'Oct 26', brentPrice: 78.90, wtiPrice: 74.85, ttfPrice: 11.80, henryHubPrice: 2.98, change1D: 1.10 },
  { monthCode: 'M2', label: 'Nov 26', brentPrice: 79.25, wtiPrice: 75.20, ttfPrice: 12.35, henryHubPrice: 3.25, change1D: 0.95 },
  { monthCode: 'M3', label: 'Dec 26', brentPrice: 79.50, wtiPrice: 75.50, ttfPrice: 13.10, henryHubPrice: 3.65, change1D: 0.80 },
  { monthCode: 'M4', label: 'Jan 27', brentPrice: 79.35, wtiPrice: 75.30, ttfPrice: 13.40, henryHubPrice: 3.72, change1D: 0.50 },
  { monthCode: 'M5', label: 'Feb 27', brentPrice: 79.10, wtiPrice: 75.05, ttfPrice: 13.05, henryHubPrice: 3.55, change1D: 0.30 },
  { monthCode: 'M6', label: 'Mar 27', brentPrice: 78.75, wtiPrice: 74.70, ttfPrice: 12.20, henryHubPrice: 3.10, change1D: 0.10 },
  { monthCode: 'M9', label: 'Jun 27', brentPrice: 77.90, wtiPrice: 73.80, ttfPrice: 11.15, henryHubPrice: 2.80, change1D: -0.25 },
  { monthCode: 'M12', label: 'Sep 27', brentPrice: 77.10, wtiPrice: 73.00, ttfPrice: 10.90, henryHubPrice: 2.75, change1D: -0.40 }
];

export const INITIAL_PRODUCTS: PetroleumProduct[] = [
  { id: 'prod-rbob', name: 'RBOB Gasoline', code: 'GASOLINE', category: 'Gasoline', spotPrice: 98.40, benchmarkRef: 'WTI', differential: 24.10, change1D: 1.80, inventoryMbbl: 221000, daysOfSupply: 25.4 },
  { id: 'prod-ulsd', name: 'ULSD Diesel 10ppm', code: 'DIESEL', category: 'Diesel', spotPrice: 104.20, benchmarkRef: 'Brent', differential: 25.75, change1D: 2.10, inventoryMbbl: 118000, daysOfSupply: 29.1 },
  { id: 'prod-jet', name: 'Jet Fuel A-1', code: 'JET', category: 'Jet Fuel', spotPrice: 106.80, benchmarkRef: 'Brent', differential: 28.35, change1D: 2.45, inventoryMbbl: 41000, daysOfSupply: 22.8 },
  { id: 'prod-hfo', name: '3.5% High Sulfur Fuel Oil', code: 'HSFO', category: 'Fuel Oil', spotPrice: 62.10, benchmarkRef: 'Brent', differential: -16.35, change1D: 0.40, inventoryMbbl: 89000, daysOfSupply: 38.2 },
  { id: 'prod-naphtha', name: 'Naphtha C5+', code: 'NAPHTHA', category: 'Naphtha', spotPrice: 74.50, benchmarkRef: 'Brent', differential: -3.95, change1D: 0.90, inventoryMbbl: 34000, daysOfSupply: 18.5 }
];

export const INITIAL_REFINERIES: RefineryModel[] = [
  {
    id: 'ref-usgc-complex',
    name: 'US Gulf Coast Complex Refinery',
    location: 'Houston Ship Channel, TX',
    capacityBpd: 520000,
    currentThroughputBpd: 495000,
    crudeInputGradeId: 'crude-wti',
    operatingCostPerBbl: 4.80,
    energyCostPerBbl: 2.10,
    yieldsPct: { gasoline: 48, diesel: 32, jetFuel: 11, fuelOil: 5, naphthaLpg: 4 },
    crack321Margin: 22.85,
    crack532Margin: 24.10,
    netMarginPerBbl: 15.95,
    dailyProfit: 7895250
  },
  {
    id: 'ref-rotterdam-hydro',
    name: 'Rotterdam Hydrocracker & FCC',
    location: 'Maasvlakte, Netherlands',
    capacityBpd: 380000,
    currentThroughputBpd: 350000,
    crudeInputGradeId: 'crude-brent',
    operatingCostPerBbl: 5.60,
    energyCostPerBbl: 3.40,
    yieldsPct: { gasoline: 38, diesel: 42, jetFuel: 12, fuelOil: 4, naphthaLpg: 4 },
    crack321Margin: 20.40,
    crack532Margin: 21.80,
    netMarginPerBbl: 11.40,
    dailyProfit: 3990000
  }
];

export const INITIAL_PHYSICAL_NODES: PhysicalAssetNode[] = [
  { id: 'node-permian', name: 'Permian Basin Oil Fields', type: 'PRODUCER', location: 'West Texas / SE New Mexico', lat: 31.9, lng: -102.3, capacity: 6200, currentLevel: 5850, utilisationPct: 94.3, inflow: 0, outflow: 5850, costPerUnit: 28.50, status: 'NORMAL', connectedTo: ['node-keystone-pipe', 'node-cushing-storage'] },
  { id: 'node-cushing-storage', name: 'Cushing Terminal & Storage', type: 'STORAGE', location: 'Cushing, OK', lat: 35.9, lng: -96.7, capacity: 76000, currentLevel: 31200, utilisationPct: 41.0, inflow: 1850, outflow: 1720, costPerUnit: 0.45, status: 'NORMAL', connectedTo: ['node-usgc-pipe'] },
  { id: 'node-keystone-pipe', name: 'Keystone / Capline Pipeline', type: 'PIPELINE', location: 'Midwest to Gulf Coast', lat: 38.5, lng: -90.2, capacity: 830, currentLevel: 810, utilisationPct: 97.6, inflow: 810, outflow: 810, costPerUnit: 2.10, status: 'CONGESTED', connectedTo: ['node-houston-port'] },
  { id: 'node-usgc-pipe', name: 'Seaway Oil Pipeline', type: 'PIPELINE', location: 'Cushing to Houston', lat: 33.1, lng: -96.5, capacity: 850, currentLevel: 790, utilisationPct: 92.9, inflow: 790, outflow: 790, costPerUnit: 1.80, status: 'NORMAL', connectedTo: ['node-houston-port'] },
  { id: 'node-houston-port', name: 'Houston VLCC Export Terminal', type: 'PORT', location: 'Galveston Bay, TX', lat: 29.3, lng: -94.7, capacity: 2400, currentLevel: 1950, utilisationPct: 81.25, inflow: 1950, outflow: 1950, costPerUnit: 0.85, status: 'NORMAL', connectedTo: ['node-rotterdam-port', 'node-chiba-port'] },
  { id: 'node-rotterdam-port', name: 'Port of Rotterdam Crude Terminal', type: 'PORT', location: 'Rotterdam, NL', lat: 51.9, lng: 4.1, capacity: 3200, currentLevel: 2650, utilisationPct: 82.8, inflow: 1950, outflow: 1950, costPerUnit: 0.95, status: 'NORMAL', connectedTo: ['node-rotterdam-refinery'] },
  { id: 'node-rotterdam-refinery', name: 'Rotterdam Complex Refinery', type: 'REFINERY', location: 'Maasvlakte, NL', lat: 51.95, lng: 4.05, capacity: 380, currentLevel: 350, utilisationPct: 92.1, inflow: 350, outflow: 345, costPerUnit: 5.60, status: 'NORMAL', connectedTo: [] },
  { id: 'node-chiba-port', name: 'Tokyo Bay Chiba Terminal', type: 'PORT', location: 'Tokyo Bay, Japan', lat: 35.5, lng: 140.0, capacity: 1800, currentLevel: 1420, utilisationPct: 78.8, inflow: 800, outflow: 800, costPerUnit: 1.10, status: 'NORMAL', connectedTo: [] }
];

export const INITIAL_PHYSICAL_ARBS: PhysicalArbitrage[] = [
  {
    id: 'arb-wti-rotterdam',
    instrument: 'WTI Midland physical cargo',
    originLocation: 'Houston VLCC Terminal, US',
    destinationLocation: 'Rotterdam DES, NWE',
    buySpotPrice: 74.30,
    sellTargetPrice: 79.80,
    transportCost: 2.15,
    storageCost: 0.40,
    financingCost: 0.35,
    lossCost: 0.15,
    fees: 0.10,
    netEdgePerUnit: 2.35,
    totalEdgeUSD: 4700000,
    volumeUnits: 2000000,
    riskRating: 'LOW',
    modelConfidence: 91,
    dataTimestamp: '12:45 UTC'
  },
  {
    id: 'arb-lng-us-jkm',
    instrument: 'LNG Sabine Pass spot cargo',
    originLocation: 'Sabine Pass, US Gulf',
    destinationLocation: 'Tokyo Bay DES, Japan',
    buySpotPrice: 2.85, // feed gas $/MMBtu
    sellTargetPrice: 13.80, // JKM $/MMBtu
    transportCost: 3.40,
    storageCost: 0.30,
    financingCost: 0.45,
    lossCost: 0.25,
    fees: 2.50, // liquefaction fee
    netEdgePerUnit: 4.05,
    totalEdgeUSD: 13770000,
    volumeUnits: 3400000, // MMBtu cargo
    riskRating: 'MEDIUM',
    modelConfidence: 86,
    dataTimestamp: '12:45 UTC'
  }
];

export const INITIAL_STORAGE_ARBS: StorageArbitrage[] = [
  {
    id: 'stg-cushing-wti',
    location: 'Cushing OK Tank Farm',
    commodity: 'WTI Crude Oil',
    spotPrice: 74.30,
    forward12MPrice: 77.10,
    grossSpread: 2.80,
    storageCostMonthly: 0.18, // $2.16 total 12M
    financingRatePct: 5.25, // $3.90 total 12M
    insuranceAndLossesPct: 0.40,
    netArbitrageValue: -3.56,
    decision: 'SELL_SPOT_ALTERNATIVE'
  },
  {
    id: 'stg-ttf-gas',
    location: 'Bergermeer Gas Storage Netherlands',
    commodity: 'TTF Natural Gas',
    spotPrice: 11.45,
    forward12MPrice: 13.40,
    grossSpread: 1.95,
    storageCostMonthly: 0.08, // $0.96 total 12M
    financingRatePct: 4.5, // $0.51
    insuranceAndLossesPct: 0.15,
    netArbitrageValue: 0.33,
    decision: 'BUY_STORE_SELL'
  }
];

export const INITIAL_POSITIONS: Position[] = [
  {
    id: 'pos-1',
    instrument: 'BRENT-FUT-DEC26',
    type: 'FUTURES',
    side: 'LONG',
    quantity: 500000,
    unit: 'bbl',
    entryPrice: 76.50,
    currentPrice: 78.45,
    marketValue: 39225000,
    unrealizedPnL: 975000,
    realizedPnL: 120000,
    counterparty: 'ICE Futures Europe',
    delta: 500000,
    basisExposure: 0,
    fxExposureUSD: 0
  },
  {
    id: 'pos-2',
    instrument: 'WTI-PHYSICAL-CUSHING',
    type: 'PHYSICAL_INVENTORY',
    side: 'LONG',
    quantity: 1200000,
    unit: 'bbl',
    entryPrice: 73.80,
    currentPrice: 74.30,
    marketValue: 89160000,
    unrealizedPnL: 600000,
    realizedPnL: 45000,
    counterparty: 'Enterprise Products Partners',
    delta: 1200000,
    basisExposure: -540000,
    fxExposureUSD: 0
  },
  {
    id: 'pos-3',
    instrument: 'TTF-SWAP-WINTER26',
    type: 'SWAP',
    side: 'SHORT',
    quantity: 2500000,
    unit: 'MMBtu',
    entryPrice: 12.10,
    currentPrice: 11.45,
    marketValue: 28625000,
    unrealizedPnL: 1625000,
    realizedPnL: -80000,
    counterparty: 'Shell Energy Trading',
    delta: -2500000,
    basisExposure: 420000,
    fxExposureUSD: 2450000
  }
];

export const INITIAL_PNL_ATTRIBUTION: DailyPnLAttribution[] = [
  { date: '2026-08-25', totalPnL: 450000, priceEffect: 520000, volumeEffect: 0, basisEffect: -40000, fxEffect: 12000, freightEffect: -18000, storageEffect: -12000, financingEffect: -8000, hedgeEffect: -10000, operatingCostEffect: 6000 },
  { date: '2026-08-26', totalPnL: -280000, priceEffect: -310000, volumeEffect: 0, basisEffect: 45000, fxEffect: -5000, freightEffect: -15000, storageEffect: -12000, financingEffect: -8000, hedgeEffect: 30000, operatingCostEffect: -5000 },
  { date: '2026-08-27', totalPnL: 890000, priceEffect: 940000, volumeEffect: 25000, basisEffect: -35000, fxEffect: 18000, freightEffect: -20000, storageEffect: -12000, financingEffect: -8000, hedgeEffect: -22000, operatingCostEffect: 4000 },
  { date: '2026-08-28', totalPnL: 620000, priceEffect: 680000, volumeEffect: 0, basisEffect: -15000, fxEffect: 8000, freightEffect: -14000, storageEffect: -12000, financingEffect: -8000, hedgeEffect: -24000, operatingCostEffect: 5000 },
  { date: '2026-08-29', totalPnL: 1150000, priceEffect: 1210000, volumeEffect: 40000, basisEffect: -28000, fxEffect: 22000, freightEffect: -22000, storageEffect: -12000, financingEffect: -8000, hedgeEffect: -50000, operatingCostEffect: 6000 },
  { date: '2026-08-30', totalPnL: 410000, priceEffect: 390000, volumeEffect: 0, basisEffect: 18000, fxEffect: -4000, freightEffect: -12000, storageEffect: -12000, financingEffect: -8000, hedgeEffect: 42000, operatingCostEffect: -4000 },
  { date: '2026-09-01', totalPnL: 3200000, priceEffect: 3180000, volumeEffect: 65000, basisEffect: 85000, fxEffect: 31000, freightEffect: -45000, storageEffect: -24000, financingEffect: -16000, hedgeEffect: -86000, operatingCostEffect: 10000 }
];

export const INITIAL_RISK: RiskMetrics = {
  var95_1D: 2450000,
  var99_1D: 3820000,
  expectedShortfall99: 4750000,
  stressLossMax: 14200000,
  portfolioDelta: 1700000,
  basisExposure: 1200000,
  fxExposureEUR: 14500000,
  fxExposureGBP: 6200000,
  capitalUtilisationPct: 64.2,
  varLimitUSD: 5000000,
  limitBreachesCount: 0
};

export const INITIAL_STRESS_SCENARIOS: StressScenario[] = [
  { id: 'scen-oil-up20', name: 'Oil Supply Shock (+20% Oil)', description: 'Middle East Strait geopolitical freeze causing instant +20% spike in Brent & WTI spot', oilPriceChangePct: 20, gasPriceChangePct: 10, freightChangePct: 15, usdChangePct: 2, pipelineOutage: false, projectedPnLChange: 6800000, projectedVarChange: 1800000 },
  { id: 'scen-oil-down20', name: 'Demand Collapse (-20% Oil)', description: 'Global macroeconomic recession leading to steep drop in refined product demand', oilPriceChangePct: -20, gasPriceChangePct: -15, freightChangePct: -10, usdChangePct: -1, pipelineOutage: false, projectedPnLChange: -7200000, projectedVarChange: 2100000 },
  { id: 'scen-gas-up50', name: 'European Gas Crisis (+50% Gas)', description: 'Extreme winter freeze combined with pipeline supply disruption across Baltic NWE', oilPriceChangePct: 5, gasPriceChangePct: 50, freightChangePct: 25, usdChangePct: 3, pipelineOutage: false, projectedPnLChange: -4100000, projectedVarChange: 3500000 },
  { id: 'scen-pipeline-outage', name: 'Keystone Pipeline Outage', description: 'Immediate 10-day shutdown of Permian to USGC arterial pipeline', oilPriceChangePct: 3, gasPriceChangePct: 0, freightChangePct: 35, usdChangePct: 0, pipelineOutage: true, projectedPnLChange: -1850000, projectedVarChange: 1400000 }
];

export const INITIAL_ANOMALIES: AnomalySignal[] = [
  { id: 'anom-1', instrument: 'Waha Hub Gas', metric: 'Basis Spread vs Henry Hub', value: -1.40, zScore: -3.2, status: 'EXTREME', signalExplanation: 'Permian pipeline bottleneck causing extreme localized gas oversupply and negative basis pricing', timestamp: '12:44:00 UTC' },
  { id: 'anom-2', instrument: 'TTF vs NBP', metric: 'Cross-Channel Gas Basis', value: 0.35, zScore: 2.4, status: 'ANOMALY', signalExplanation: 'Bacton interconnector maintenance leading to temporary cross-channel dislocation', timestamp: '12:40:00 UTC' },
  { id: 'anom-3', instrument: 'ULSD Diesel 10ppm', metric: '3-2-1 Crack Spread', value: 25.75, zScore: 1.8, status: 'WATCH', signalExplanation: 'Low European refinery inventories boosting prompt middle distillate cracks', timestamp: '12:35:00 UTC' }
];

export const INITIAL_FORECASTS: PriceForecast[] = [
  { instrument: 'Brent Crude Spot', horizonDays: 30, modelName: 'ARIMA(2,1,2)', currentPrice: 78.45, forecastPrice: 81.20, lowerConfidence95: 74.50, upperConfidence95: 87.90, confidenceScore: 84, assumptions: ['OPEC+ quota adherence', 'US SPR refill pacing', 'Standard seasonal refinery demand'] },
  { instrument: 'TTF Natural Gas Spot', horizonDays: 30, modelName: 'Gradient Boosting Regressor', currentPrice: 11.45, forecastPrice: 12.80, lowerConfidence95: 9.80, upperConfidence95: 15.60, confidenceScore: 78, assumptions: ['European gas storage at 88% capacity', 'LNG import terminal utilization', 'Normal winter heating degree days'] }
];

export const INITIAL_GOVERNANCE: ModelGovernance[] = [
  { modelId: 'MOD-VAR-MC01', name: 'RhinoQuant Monte Carlo VaR Engine', version: 'v2.4.1', author: 'Dr. E. Vance, Head of Risk Quant', validationStatus: 'VALIDATED', lastValidatedDate: '2026-07-15', inputs: ['Historical Volatility (252D)', 'EWMA Decay λ=0.94', 'Cross-asset covariance matrix'], outputs: ['1D VaR 95%', '1D VaR 99%', 'Expected Shortfall 99%'], assumptions: 'Multivariate student-t return distribution with 6 degrees of freedom' },
  { modelId: 'MOD-REFINERY-YLD03', name: 'Digital Twin Refinery Yield Model', version: 'v1.8.0', author: 'M. Sterling, Process Systems Lead', validationStatus: 'VALIDATED', lastValidatedDate: '2026-08-01', inputs: ['API Gravity', 'Sulphur %', 'Catalytic Cracker Operating Temp'], outputs: ['Gasoline %', 'Diesel %', 'Jet %', 'Fuel Oil %', 'Theoretical Margin'], assumptions: 'Linear programming yield optimization based on AspenTech calibration data' },
  { modelId: 'MOD-PHYS-ARB05', name: 'Geographic Energy Arbitrage Model', version: 'v3.1.0', author: 'J. Thornton, Physical Desks Quant', validationStatus: 'VALIDATED', lastValidatedDate: '2026-08-20', inputs: ['Spot Prices', 'Charter Rates', 'Boil-off Rates', 'Canal Tolls', 'Demurrage', 'Cost of Capital'], outputs: ['Net Edge USD', 'Model Confidence Score'], assumptions: 'Freight rates updated daily via Baltic Exchange API feed' }
];

export const INITIAL_AUDIT_LOGS: AuditLogEntry[] = [
  { id: 'aud-101', timestamp: '2026-09-01 12:44:10', user: 'Alex Mercer (Head Trader)', role: 'TRADER', action: 'SIMULATED_ORDER_EXECUTION', details: 'Executed paper buy limit 50,000 bbl BRENT-FUT-DEC26 @ $78.45', module: 'TRADING_SIMULATOR' },
  { id: 'aud-102', timestamp: '2026-09-01 12:30:45', user: 'Elena Rostova (Chief Risk Officer)', role: 'RISK MANAGER', action: 'STRESS_SCENARIO_RUN', details: 'Executed Stress Scenario: European Gas Crisis (+50% Gas)', module: 'RISK_ENGINE' },
  { id: 'aud-103', timestamp: '2026-09-01 11:15:20', user: 'David K. (Senior Analyst)', role: 'ANALYST', action: 'CRUDE_GRADE_CREATE', details: 'Added custom crude grade: "Guyana Liza Sweet" (API 32.1, Sulphur 0.58%)', module: 'SPOT_MARKETS' }
];

export const INITIAL_ALERTS: SystemAlert[] = [
  { id: 'alt-1', timestamp: '12:44:00 UTC', severity: 'CRITICAL', category: 'PRICE', message: 'Waha Gas Hub basis drop to -$1.40/MMBtu triggered EXTREME anomaly alert (Z-score -3.2)', read: false },
  { id: 'alt-2', timestamp: '12:35:00 UTC', severity: 'WARNING', category: 'STORAGE', message: 'Permian pipeline bottleneck capacity utilisation reached 97.6%', read: false },
  { id: 'alt-3', timestamp: '12:10:00 UTC', severity: 'INFO', category: 'DATA', message: 'Market Data Engine re-synchronized all 12 prompt forward curve tenors.', read: true }
];
