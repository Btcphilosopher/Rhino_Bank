import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { 
  UserRole, 
  DataMode, 
  CrudeGrade, 
  GasHub, 
  LngRoute, 
  ForwardTenor, 
  PetroleumProduct, 
  RefineryModel, 
  PhysicalAssetNode, 
  PhysicalArbitrage, 
  StorageArbitrage, 
  Position, 
  DailyPnLAttribution, 
  RiskMetrics, 
  StressScenario, 
  AnomalySignal, 
  PriceForecast, 
  ModelGovernance, 
  AuditLogEntry, 
  SystemAlert 
} from '../types';

import {
  INITIAL_CRUDE_GRADES,
  INITIAL_GAS_HUBS,
  INITIAL_LNG_ROUTES,
  INITIAL_FORWARD_TENORS,
  INITIAL_PRODUCTS,
  INITIAL_REFINERIES,
  INITIAL_PHYSICAL_NODES,
  INITIAL_PHYSICAL_ARBS,
  INITIAL_STORAGE_ARBS,
  INITIAL_POSITIONS,
  INITIAL_PNL_ATTRIBUTION,
  INITIAL_RISK,
  INITIAL_STRESS_SCENARIOS,
  INITIAL_ANOMALIES,
  INITIAL_FORECASTS,
  INITIAL_GOVERNANCE,
  INITIAL_AUDIT_LOGS,
  INITIAL_ALERTS
} from '../data/mockMarketData';

import { calculateCrudePrice, simulateRefineryEconomics, evaluateStorageArbitrage } from '../engine';

export type WorkspaceView = 
  | 'EXECUTIVE'
  | 'TRADER'
  | 'SPOT_MARKETS'
  | 'CURVES_CRACK'
  | 'PHYSICAL_TWIN'
  | 'ARBITRAGE'
  | 'RISK_MONTECARLO'
  | 'SIMULATOR'
  | 'RESEARCH_ML'
  | 'GOVERNANCE_AUDIT';

interface RhinoContextType {
  activeView: WorkspaceView;
  setActiveView: (view: WorkspaceView) => void;
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;
  dataMode: DataMode;
  setDataMode: (mode: DataMode) => void;
  isLiveTicking: boolean;
  setIsLiveTicking: (ticking: boolean) => void;

  crudeGrades: CrudeGrade[];
  gasHubs: GasHub[];
  lngRoutes: LngRoute[];
  forwardTenors: ForwardTenor[];
  products: PetroleumProduct[];
  refineries: RefineryModel[];
  physicalNodes: PhysicalAssetNode[];
  physicalArbs: PhysicalArbitrage[];
  storageArbs: StorageArbitrage[];
  positions: Position[];
  pnlHistory: DailyPnLAttribution[];
  riskMetrics: RiskMetrics;
  stressScenarios: StressScenario[];
  activeScenarioId: string | null;
  anomalies: AnomalySignal[];
  forecasts: PriceForecast[];
  governanceModels: ModelGovernance[];
  auditLogs: AuditLogEntry[];
  alerts: SystemAlert[];

  // Actions
  addCrudeGrade: (newGrade: Omit<CrudeGrade, 'id' | 'lastUpdated'>) => void;
  executePaperTrade: (trade: { instrument: string; type: Position['type']; side: 'LONG' | 'SHORT'; quantity: number; unit: 'bbl' | 'MMBtu'; price: number; counterparty: string }) => void;
  applyScenario: (scenarioId: string) => void;
  resetScenario: () => void;
  updateRefineryThroughput: (refineryId: string, throughput: number) => void;
  toggleNodeStatus: (nodeId: string, status: PhysicalAssetNode['status']) => void;
  markAlertRead: (alertId: string) => void;
  addAuditEntry: (action: string, details: string, module: string) => void;
}

const RhinoContext = createContext<RhinoContextType | undefined>(undefined);

export const RhinoProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [activeView, setActiveView] = useState<WorkspaceView>('TRADER');
  const [userRole, setUserRole] = useState<UserRole>('TRADER');
  const [dataMode, setDataMode] = useState<DataMode>('LIVE');
  const [isLiveTicking, setIsLiveTicking] = useState<boolean>(true);

  const [crudeGrades, setCrudeGrades] = useState<CrudeGrade[]>(INITIAL_CRUDE_GRADES);
  const [gasHubs, setGasHubs] = useState<GasHub[]>(INITIAL_GAS_HUBS);
  const [lngRoutes] = useState<LngRoute[]>(INITIAL_LNG_ROUTES);
  const [forwardTenors, setForwardTenors] = useState<ForwardTenor[]>(INITIAL_FORWARD_TENORS);
  const [products, setProducts] = useState<PetroleumProduct[]>(INITIAL_PRODUCTS);
  const [refineries, setRefineries] = useState<RefineryModel[]>(INITIAL_REFINERIES);
  const [physicalNodes, setPhysicalNodes] = useState<PhysicalAssetNode[]>(INITIAL_PHYSICAL_NODES);
  const [physicalArbs] = useState<PhysicalArbitrage[]>(INITIAL_PHYSICAL_ARBS);
  const [storageArbs] = useState<StorageArbitrage[]>(INITIAL_STORAGE_ARBS);
  const [positions, setPositions] = useState<Position[]>(INITIAL_POSITIONS);
  const [pnlHistory] = useState<DailyPnLAttribution[]>(INITIAL_PNL_ATTRIBUTION);
  const [riskMetrics, setRiskMetrics] = useState<RiskMetrics>(INITIAL_RISK);
  const [stressScenarios] = useState<StressScenario[]>(INITIAL_STRESS_SCENARIOS);
  const [activeScenarioId, setActiveScenarioId] = useState<string | null>(null);
  const [anomalies] = useState<AnomalySignal[]>(INITIAL_ANOMALIES);
  const [forecasts] = useState<PriceForecast[]>(INITIAL_FORECASTS);
  const [governanceModels] = useState<ModelGovernance[]>(INITIAL_GOVERNANCE);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>(INITIAL_AUDIT_LOGS);
  const [alerts, setAlerts] = useState<SystemAlert[]>(INITIAL_ALERTS);

  // Simulated live ticking interval (1.5 seconds)
  useEffect(() => {
    if (!isLiveTicking) return;

    const interval = setInterval(() => {
      setCrudeGrades(prev => 
        prev.map(c => {
          const delta = (Math.random() - 0.49) * 0.15;
          const newBase = Math.max(10, c.baseSpotPrice + delta);
          const newBid = Number((newBase - 0.03).toFixed(2));
          const newOffer = Number((newBase + 0.03).toFixed(2));
          const change1D = Number((c.change1D + delta).toFixed(2));
          const change1DPct = Number(((change1D / newBase) * 100).toFixed(2));
          return {
            ...c,
            baseSpotPrice: Number(newBase.toFixed(2)),
            bid: newBid,
            offer: newOffer,
            change1D,
            change1DPct,
            lastUpdated: new Date().toISOString().substring(11, 19) + ' UTC'
          };
        })
      );

      setGasHubs(prev =>
        prev.map(h => {
          const delta = (Math.random() - 0.49) * 0.04;
          const newPrice = Math.max(0.5, h.spotPrice + delta);
          return {
            ...h,
            spotPrice: Number(newPrice.toFixed(2)),
            bid: Number((newPrice - 0.01).toFixed(2)),
            offer: Number((newPrice + 0.01).toFixed(2)),
            change1D: Number((h.change1D + delta).toFixed(2))
          };
        })
      );

      // Re-evaluate refinery margins with updated spot prices
      setRefineries(prev =>
        prev.map(ref => {
          const brent = crudeGrades.find(g => g.code === 'BRENT')?.baseSpotPrice || 78.45;
          const gaso = products.find(p => p.category === 'Gasoline')?.spotPrice || 98.40;
          const dies = products.find(p => p.category === 'Diesel')?.spotPrice || 104.20;
          const jet = products.find(p => p.category === 'Jet Fuel')?.spotPrice || 106.80;
          const hfo = products.find(p => p.category === 'Fuel Oil')?.spotPrice || 62.10;
          const nap = products.find(p => p.category === 'Naphtha')?.spotPrice || 74.50;
          return simulateRefineryEconomics(ref, brent, gaso, dies, jet, hfo, nap);
        })
      );

      // Update position current prices & unrealized PnL
      setPositions(prev =>
        prev.map(pos => {
          let currentPrice = pos.currentPrice;
          if (pos.instrument.includes('BRENT')) {
            const brent = crudeGrades.find(g => g.code === 'BRENT');
            if (brent) currentPrice = brent.baseSpotPrice;
          } else if (pos.instrument.includes('WTI')) {
            const wti = crudeGrades.find(g => g.code === 'WTI');
            if (wti) currentPrice = wti.baseSpotPrice;
          } else if (pos.instrument.includes('TTF')) {
            const ttf = gasHubs.find(h => h.code === 'TTF');
            if (ttf) currentPrice = ttf.spotPrice;
          }
          const priceDiff = currentPrice - pos.entryPrice;
          const multiplier = pos.side === 'LONG' ? 1 : -1;
          const unrealizedPnL = priceDiff * pos.quantity * multiplier;
          const marketValue = currentPrice * pos.quantity;

          return {
            ...pos,
            currentPrice: Number(currentPrice.toFixed(2)),
            marketValue: Math.round(marketValue),
            unrealizedPnL: Math.round(unrealizedPnL)
          };
        })
      );
    }, 1500);

    return () => clearInterval(interval);
  }, [isLiveTicking, crudeGrades, gasHubs, products]);

  // Actions implementation
  const addCrudeGrade = (newGrade: Omit<CrudeGrade, 'id' | 'lastUpdated'>) => {
    const id = `crude-${Date.now()}`;
    const grade: CrudeGrade = {
      ...newGrade,
      id,
      lastUpdated: new Date().toISOString().substring(11, 19) + ' UTC',
      isCustom: true
    };
    setCrudeGrades(prev => [grade, ...prev]);
    addAuditEntry('CREATE_CRUDE_GRADE', `Created custom grade "${newGrade.name}" (${newGrade.code})`, 'CRUDE_DATABASE');
  };

  const executePaperTrade = (trade: { instrument: string; type: Position['type']; side: 'LONG' | 'SHORT'; quantity: number; unit: 'bbl' | 'MMBtu'; price: number; counterparty: string }) => {
    const newPos: Position = {
      id: `pos-${Date.now()}`,
      instrument: trade.instrument,
      type: trade.type,
      side: trade.side,
      quantity: trade.quantity,
      unit: trade.unit,
      entryPrice: trade.price,
      currentPrice: trade.price,
      marketValue: trade.price * trade.quantity,
      unrealizedPnL: 0,
      realizedPnL: 0,
      counterparty: trade.counterparty,
      delta: trade.side === 'LONG' ? trade.quantity : -trade.quantity,
      basisExposure: trade.instrument.includes('PHYSICAL') ? -trade.quantity * 0.4 : 0,
      fxExposureUSD: trade.instrument.includes('TTF') ? 1200000 : 0
    };

    setPositions(prev => [newPos, ...prev]);
    
    // Recalculate portfolio risk
    setRiskMetrics(prev => ({
      ...prev,
      portfolioDelta: prev.portfolioDelta + newPos.delta,
      var95_1D: Math.round(prev.var95_1D * 1.05),
      var99_1D: Math.round(prev.var99_1D * 1.05)
    }));

    addAuditEntry('SIMULATE_TRADE', `Simulated ${trade.side} ${trade.quantity.toLocaleString()} ${trade.unit} ${trade.instrument} @ $${trade.price}`, 'TRADING_SIMULATOR');
  };

  const applyScenario = (scenarioId: string) => {
    const scenario = stressScenarios.find(s => s.id === scenarioId);
    if (!scenario) return;

    setActiveScenarioId(scenarioId);

    // Shock prices
    setCrudeGrades(prev =>
      prev.map(c => {
        const shocked = c.baseSpotPrice * (1 + scenario.oilPriceChangePct / 100);
        return {
          ...c,
          baseSpotPrice: Number(shocked.toFixed(2)),
          bid: Number((shocked - 0.05).toFixed(2)),
          offer: Number((shocked + 0.05).toFixed(2))
        };
      })
    );

    setGasHubs(prev =>
      prev.map(h => {
        const shocked = h.spotPrice * (1 + scenario.gasPriceChangePct / 100);
        return {
          ...h,
          spotPrice: Number(shocked.toFixed(2))
        };
      })
    );

    // Shock node statuses if pipeline outage
    if (scenario.pipelineOutage) {
      setPhysicalNodes(prev =>
        prev.map(n => n.type === 'PIPELINE' ? { ...n, status: 'OUTAGE', utilisationPct: 0 } : n)
      );
    }

    setRiskMetrics(prev => ({
      ...prev,
      stressLossMax: Math.abs(scenario.projectedPnLChange),
      var95_1D: prev.var95_1D + scenario.projectedVarChange
    }));

    addAuditEntry('STRESS_SCENARIO_APPLIED', `Applied stress scenario: "${scenario.name}"`, 'RISK_ENGINE');
  };

  const resetScenario = () => {
    setActiveScenarioId(null);
    setCrudeGrades(INITIAL_CRUDE_GRADES);
    setGasHubs(INITIAL_GAS_HUBS);
    setPhysicalNodes(INITIAL_PHYSICAL_NODES);
    setRiskMetrics(INITIAL_RISK);
    addAuditEntry('SCENARIO_RESET', 'Reset market data to baseline state', 'SCENARIO_ENGINE');
  };

  const updateRefineryThroughput = (refineryId: string, throughput: number) => {
    setRefineries(prev =>
      prev.map(r => r.id === refineryId ? { ...r, currentThroughputBpd: throughput, dailyProfit: Math.round(r.netMarginPerBbl * throughput) } : r)
    );
    addAuditEntry('UPDATE_REFINERY', `Updated refinery throughput to ${throughput.toLocaleString()} bpd`, 'REFINERY_MODEL');
  };

  const toggleNodeStatus = (nodeId: string, status: PhysicalAssetNode['status']) => {
    setPhysicalNodes(prev =>
      prev.map(n => n.id === nodeId ? { ...n, status } : n)
    );
    addAuditEntry('TOGGLE_NODE_STATUS', `Node ${nodeId} status updated to ${status}`, 'PHYSICAL_TWIN');
  };

  const markAlertRead = (alertId: string) => {
    setAlerts(prev => prev.map(a => a.id === alertId ? { ...a, read: true } : a));
  };

  const addAuditEntry = (action: string, details: string, module: string) => {
    const entry: AuditLogEntry = {
      id: `aud-${Date.now()}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      user: 'Current User',
      role: userRole,
      action,
      details,
      module
    };
    setAuditLogs(prev => [entry, ...prev]);
  };

  return (
    <RhinoContext.Provider value={{
      activeView,
      setActiveView,
      userRole,
      setUserRole,
      dataMode,
      setDataMode,
      isLiveTicking,
      setIsLiveTicking,
      crudeGrades,
      gasHubs,
      lngRoutes,
      forwardTenors,
      products,
      refineries,
      physicalNodes,
      physicalArbs,
      storageArbs,
      positions,
      pnlHistory,
      riskMetrics,
      stressScenarios,
      activeScenarioId,
      anomalies,
      forecasts,
      governanceModels,
      auditLogs,
      alerts,
      addCrudeGrade,
      executePaperTrade,
      applyScenario,
      resetScenario,
      updateRefineryThroughput,
      toggleNodeStatus,
      markAlertRead,
      addAuditEntry
    }}>
      {children}
    </RhinoContext.Provider>
  );
};

export const useRhino = () => {
  const context = useContext(RhinoContext);
  if (!context) throw new Error('useRhino must be used within RhinoProvider');
  return context;
};
