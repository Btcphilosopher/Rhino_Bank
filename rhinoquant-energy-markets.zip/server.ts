import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini API lazily on demand
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    aiClient = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  }
  return aiClient;
}

// REST APIs specified in Requirement 60
app.get("/api/v1/health", (req, res) => {
  res.json({
    status: "OK",
    system: "RHINOQUANT ENERGY MARKETS API",
    version: "v2.4.0-institutional",
    timestamp: new Date().toISOString(),
    capabilities: [
      "SPOT_MARKETS", "FORWARD_CURVES", "PHYSICAL_FLOWS", "REFINERY_TWIN",
      "ARBITRAGE_ENGINE", "RISK_VAR", "MONTE_CARLO", "AI_INTELLIGENCE"
    ]
  });
});

app.get("/api/v1/markets", (req, res) => {
  res.json({
    crudeBenchmarks: ["BRENT", "WTI", "DUBAI", "URALS", "TAPIS", "WCS"],
    gasHubs: ["HENRY_HUB", "TTF", "NBP", "JKM", "WAHA"],
    products: ["GASOLINE", "DIESEL", "JET_FUEL", "FUEL_OIL", "NAPHTHA"],
    status: "ACTIVE"
  });
});

// Gemini AI Energy Market Intelligence endpoint
app.post("/api/v1/ai-research", async (req, res) => {
  try {
    const { prompt, context } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      return res.json({
        result: `[REASONING ENGINE] (Simulated Mode - GEMINI_API_KEY pending in environment)\n\nAnalysis for "${prompt}":\n- **Crude Market Dynamic**: Brent-WTI spread at $4.15/bbl favors US export flows to Rotterdam.\n- **Gas & LNG**: TTF at $11.45/MMBtu provides $3.80/MMBtu net arb for Sabine Pass LNG cargoes.\n- **Risk Advisory**: Monitor 1D 99% VaR limit closely during high volatility regimes.`
      });
    }

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [
        {
          role: "user",
          parts: [
            {
              text: `You are the lead quantitative strategist and physical oil & gas commodity analyst for Rhino Bank's RHINOQUANT ENERGY MARKETS platform.
Provide an institutional-grade, highly analytical research memo responding to the following trader query:

USER QUERY: ${prompt}

CURRENT MARKET CONTEXT:
${JSON.stringify(context || {}, null, 2)}

Format with key headings:
1. Executive Summary
2. Physical Supply & Demand Drivers
3. Quantitative Edge & Spread Valuation
4. Risk Controls & VaR Implication`
            }
          ]
        }
      ]
    });

    res.json({ result: response.text });
  } catch (err: any) {
    console.error("Gemini AI API Error:", err);
    res.status(500).json({ error: "Failed to generate market intelligence", details: err.message });
  }
});

async function startServer() {
  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[RHINOQUANT] Energy Markets Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
